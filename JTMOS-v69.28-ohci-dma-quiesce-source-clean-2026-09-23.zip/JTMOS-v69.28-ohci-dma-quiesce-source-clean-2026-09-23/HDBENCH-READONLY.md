# JTMOS hdbench V1

`hdbench.bin` measures sequential hard-disk read throughput without exposing a
disk-write operation.  The default mode uses the active `hda` backend directly
and bypasses the DAPI cache.  `--raw-pio` requests the physical ATA task-file
PIO read path and refuses to run if the active controller is AHCI-only.

Examples:

```
hdbench
hdbench --raw-pio
hdbench --mib 128 --chunk-kib 64 --passes 3
hdbench --raw-pio --lba 2048 --mib 16
```

The benchmark syscall is intentionally narrower than the privileged raw-block
API.  It always targets `hda`, validates the complete LBA range, limits one call
to 1 GiB and one request to 128 KiB, allocates the data buffer in the kernel,
and discards every sector after timing it.  Ring 3 receives only geometry,
elapsed time, progress and status.  It never receives disk contents, a device
handle, an ATA command byte, a flush operation or any write operation.

Normal mode calls the uncached native read backend.  On legacy IDE and the
NVIDIA MCP61 rescue driver, RAW PIO is available and uses READ PIO/READ PIO EXT.
On AHCI, RAW PIO reports unsupported instead of silently substituting DMA.
Neither mode drains the DAPI write-back cache, issues FLUSH CACHE, or invokes a
write command.
