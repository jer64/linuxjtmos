#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$HERE/.." && pwd)
FLOPPY=${1:-"$ROOT/jtm32.img"}
HDD=${2:-"$ROOT/qemu-hda-64m.img"}
LOG=${3:-"$ROOT/serial_ide_test.log"}

if ! command -v qemu-system-i386 >/dev/null 2>&1; then
    echo "qemu-system-i386 not found" >&2
    exit 127
fi

if [ ! -f "$FLOPPY" ]; then
    echo "Floppy image not found: $FLOPPY" >&2
    echo "Pass V37 image as first argument." >&2
    exit 1
fi

if [ ! -f "$HDD" ]; then
    echo "Creating blank 64 MiB raw ATA disk: $HDD"
    dd if=/dev/zero of="$HDD" bs=1M count=64 status=none
fi

rm -f "$LOG"
echo "Floppy: $FLOPPY"
echo "IDE HDD: $HDD (primary master, raw)"
echo "Serial: $LOG"

exec qemu-system-i386 \
  -machine pc \
  -m 64 \
  -drive file="$FLOPPY",format=raw,if=floppy,index=0 \
  -drive file="$HDD",format=raw,if=ide,index=0,media=disk \
  -boot a \
  -serial file:"$LOG" \
  -monitor none \
  -no-reboot -no-shutdown
