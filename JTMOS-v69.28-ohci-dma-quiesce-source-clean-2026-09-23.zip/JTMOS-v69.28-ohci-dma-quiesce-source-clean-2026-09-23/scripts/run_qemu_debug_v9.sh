#!/bin/sh
set -u
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$HERE/.." && pwd)
IMG=${1:-"$ROOT/GraOS-boot-test-v9-expertfix-2026-08-19.img"}
LOGDIR=${2:-"$ROOT/qemu-debug-v9"}
SERIAL="$LOGDIR/serial_output.log"
CPU="$LOGDIR/qemu_cpu.log"
ANALYSIS="$LOGDIR/analysis.txt"
SYM="$ROOT/kernel32/kernel32.sym"

mkdir -p "$LOGDIR"
rm -f "$SERIAL" "$CPU" "$ANALYSIS"

if ! command -v qemu-system-i386 >/dev/null 2>&1; then
    echo "ERROR: qemu-system-i386 not found." >&2
    echo "Ubuntu/Debian: sudo apt install qemu-system-x86" >&2
    exit 127
fi

printf '%s\n' \
  "JTMOS/GraOS V9 debug" \
  "  image:  $IMG" \
  "  serial: $SERIAL" \
  "  cpu:    $CPU" \
  "Close QEMU after the fault/black screen; analysis then runs."

qemu-system-i386 \
  -m 64 \
  -drive file="$IMG",format=raw,if=floppy \
  -boot a \
  -serial file:"$SERIAL" \
  -monitor none \
  -no-reboot -no-shutdown \
  -d int,guest_errors,cpu_reset \
  -D "$CPU"
STATUS=$?

python3 "$HERE/analyze_qemu_v6.py" \
  --serial "$SERIAL" --cpu "$CPU" --sym "$SYM" --out "$ANALYSIS" || true

echo "Analysis: $ANALYSIS"
exit $STATUS
