#!/usr/bin/env python3
import sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else 'kernel32/kernel32.bin')
n=p.stat().st_size
loader=512*1024
empirical=384*1024
print(f'{p}: {n} bytes ({n/1024:.1f} KiB)')
print(f'physical end when loaded at 0x10000: 0x{0x10000+n:x}')
print(f'legacy loader limit: {loader} bytes; headroom {loader-n} bytes')
if n > loader:
    print('ERROR: exceeds legacy loader limit')
    raise SystemExit(2)
if n > empirical:
    print('WARNING: above 384 KiB experimental safety band; use small profile while isolating legacy-loader/kernel-size faults.')
else:
    print('PASS: below 384 KiB experimental safety band.')
