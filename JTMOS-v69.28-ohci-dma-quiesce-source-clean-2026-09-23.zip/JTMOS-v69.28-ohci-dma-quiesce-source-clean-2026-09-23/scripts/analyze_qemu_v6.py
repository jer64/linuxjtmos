#!/usr/bin/env python3
import argparse, re
from pathlib import Path

VECTORS = {
    0x00:'divide error',0x01:'debug',0x02:'NMI',0x03:'breakpoint',0x04:'overflow',
    0x05:'BOUND range',0x06:'invalid opcode',0x07:'device not available',
    0x08:'double fault',0x09:'coprocessor segment overrun',0x0a:'invalid TSS',
    0x0b:'segment not present',0x0c:'stack fault',0x0d:'general protection',
    0x0e:'page fault',0x10:'x87 floating point',0x11:'alignment check',
    0x12:'machine check',0x13:'SIMD floating point'
}

def read_symbols(path):
    syms=[]
    if not path.exists(): return syms
    for line in path.read_text(errors='replace').splitlines():
        m=re.match(r'^([0-9A-Fa-f]{8,16})\s+(\S+)', line.strip())
        if m:
            syms.append((int(m.group(1),16),m.group(2)))
    syms.sort()
    return syms

def nearest(syms, addr):
    lo=None
    for a,n in syms:
        if a>addr: break
        lo=(a,n)
    if not lo: return None
    return f'{lo[1]}+0x{addr-lo[0]:x} (symbol 0x{lo[0]:08x})'

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--serial',default='jtmos-serial.log')
    ap.add_argument('--cpu',default='qemu-cpu.log')
    ap.add_argument('--sym',default='kernel32.sym')
    ap.add_argument('--out',default='analysis.txt')
    a=ap.parse_args()
    serial=Path(a.serial); cpu=Path(a.cpu); sym=Path(a.sym)
    syms=read_symbols(sym)
    report=[]
    report.append('JTMOS / GraOS V6 QEMU debug analysis')
    report.append('='*44)

    if serial.exists():
        raw=serial.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')
        txt=raw.decode('latin1','replace')
        lines=txt.splitlines()
        report.append(f'\nSerial log: {serial} ({serial.stat().st_size} bytes, {len(lines)} lines)')
        marker='[JTMOS V6] early COM1 serial debug active'
        report.append('Kernel entry marker: ' + ('FOUND' if marker in txt else 'NOT FOUND'))
        report.append('\nLast serial lines:')
        report.extend('  '+x for x in lines[-80:])
        if marker not in txt:
            report.append('\nDIAGNOSIS: no V6 kernel-entry marker was received. The failure is before _boot_up_c, or COM1 is not attached to QEMU serial output.')
        elif lines:
            report.append('\nDIAGNOSIS: the kernel reached its C entry. The final serial line above is the best boot-stage boundary if no CPU exception follows.')
    else:
        report.append(f'\nSerial log missing: {serial}')

    exc=[]
    if cpu.exists():
        lines=cpu.read_text(errors='replace').splitlines()
        for idx,line in enumerate(lines):
            m=re.search(r'\bv=([0-9a-fA-F]{2})\b.*?\bIP=[0-9a-fA-F]+:([0-9a-fA-F]+).*?\bpc=([0-9a-fA-F]+)',line)
            if m:
                vec=int(m.group(1),16); ip=int(m.group(2),16); pc=int(m.group(3),16)
                exc.append((idx+1,vec,ip,pc,line))
        report.append(f'\nQEMU CPU log: {cpu} ({cpu.stat().st_size} bytes)')
        report.append(f'Exception records found: {len(exc)}')
        if exc:
            report.append('\nLast exceptions:')
            for ln,vec,ip,pc,line in exc[-16:]:
                n=VECTORS.get(vec,'interrupt/exception')
                where=nearest(syms,pc) or nearest(syms,ip) or 'no matching kernel symbol'
                report.append(f'  line {ln}: v={vec:02x} ({n}), pc=0x{pc:08x} -> {where}')
            ln,vec,ip,pc,line=exc[-1]
            report.append('\nPrimary interpretation:')
            if vec==0x08:
                prior=[x for x in exc[:-1] if x[1] in (0x0a,0x0b,0x0c,0x0d,0x0e,0x06)]
                if prior:
                    p=prior[-1]; where=nearest(syms,p[3]) or 'no symbol'
                    report.append(f'  Last event is a double fault; inspect the preceding v={p[1]:02x} at 0x{p[3]:08x} -> {where}. The double fault is probably secondary.')
                else:
                    report.append('  Last event is a double fault and no earlier #TS/#NP/#SS/#GP/#PF/#UD was found. Inspect the mapped double-fault PC and stack/TSS setup.')
            elif vec==0x0d:
                report.append('  General protection fault: inspect descriptor privilege/type, selector, IRET/task-switch state, or protected I/O at the mapped PC.')
            elif vec==0x0e:
                report.append('  Page fault: use CR2 from the surrounding QEMU register dump; compare it with framebuffer, heap and page-table mappings.')
            elif vec==0x0a:
                report.append('  Invalid TSS: inspect TSS descriptor, backlink/NT, ESP0/SS0 and task-gate/task-switch setup.')
            elif vec==0x06:
                report.append('  Invalid opcode: verify that control flow landed in code and that the CPU target/instruction set matches the generated binary.')
            else:
                report.append(f'  Last vector is v={vec:02x} ({VECTORS.get(vec,"unknown")}); inspect the mapped symbol and surrounding register dump.')
        else:
            report.append('\nNo CPU exception record was found. If serial output stops, this is more likely a hang/spin/wait than an exception/triple fault.')
    else:
        report.append(f'\nCPU log missing: {cpu}')

    out='\n'.join(report)+'\n'
    Path(a.out).write_text(out)
    print(out)

if __name__=='__main__': main()
