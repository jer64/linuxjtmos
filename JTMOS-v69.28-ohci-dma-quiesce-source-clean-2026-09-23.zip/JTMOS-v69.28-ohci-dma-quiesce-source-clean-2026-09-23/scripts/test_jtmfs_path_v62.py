#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
pc=(root/'kernel32/fs/jtmfs/jtmfsPath.c').read_text()
pa=(root/'kernel32/fs/jtmfs/jtmfsAccess.c').read_text()
sh=(root/'kernel32/sh/sh.c').read_text()
sc=(root/'kernel32/core/int/scs.c').read_text()
cd=(root/'kernel32/fs/_chdir.c').read_text()
lc=(root/'libc/libc/process/process.c').read_text()
checks=[
 ('canonical cwd includes device colon', 'strcat(result, ":")' in pc),
 ('canonical device root includes slash', 'strcat(result, \"/\")' in pc),
 ('relative first component is not implicit device', 'plain first component named "hda" is now an' in pc),
 ('explicit device path supported', 'explicit device-absolute path' in pc),
 ('legacy /hda compatibility retained', 'Compatibility: old JTMOS paths such as /hda/bin' in pc),
 ('device root parent stays on device', "relative '..' at" in pc),
 ('chdir commits only resolved DNR/DB', pa.find('jtmfsResolvePathAt') < pa.find('SetThreadDNR', pa.find('int jtmfs_chdir'))),
 ('_chdir is not a stub', 'return jtmfs_chdir(path);' in cd),
 ('SYS_chdir translates user pointer', 'A2K(scall_ebx)' in sc[sc.find('DWORD scall_chdir'):sc.find('DWORD scall_mkfs')]),
 ('SYS_getcwd honors buffer size', 'max_len = (int)scall_ecx' in sc),
 ('SMSH prompt uses cwd', 'printf("%s# ", cwd)' in sh),
 ('legacy libc getcwd returns buffer', 'return rv < 0 ? NULL : buf;' in lc),
]
for name,ok in checks:
 print(('PASS' if ok else 'FAIL')+': '+name)
if not all(ok for _,ok in checks): raise SystemExit(1)
