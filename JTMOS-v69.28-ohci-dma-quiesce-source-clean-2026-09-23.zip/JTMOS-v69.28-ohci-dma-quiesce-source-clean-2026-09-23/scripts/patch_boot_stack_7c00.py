#!/usr/bin/env python3
from pathlib import Path
import sys
if len(sys.argv) != 2:
    raise SystemExit('usage: patch_boot_stack_7c00.py boot32/boot.bin')
p=Path(sys.argv[1])
b=bytearray(p.read_bytes())
old=bytes.fromhex('66 BC 00 00 09 00')   # mov esp,0x00090000 in 16-bit code
new=bytes.fromhex('66 BC 00 7C 00 00')   # mov esp,0x00007C00
if new in b:
    print('PASS: boot.bin protected-mode stack already ESP=0x7C00')
elif b.count(old) == 1:
    i=b.index(old)
    b[i:i+len(old)] = new
    p.write_bytes(b)
    print(f'PASS: patched boot.bin protected-mode stack to ESP=0x7C00 at file offset 0x{i:x}')
else:
    raise SystemExit(f'ERROR: expected exactly one legacy ESP=0x90000 sequence, found {b.count(old)}')
