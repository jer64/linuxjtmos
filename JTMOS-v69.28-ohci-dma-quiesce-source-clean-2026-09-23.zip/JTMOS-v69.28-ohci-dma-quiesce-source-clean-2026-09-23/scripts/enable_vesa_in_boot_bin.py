#!/usr/bin/env python3
import sys
raise SystemExit("ERROR: prebuilt 8-bpp VESA boot patching was removed in JTMOS V67.8.45; install NASM and rebuild boot32/boot.asm, whose VBE diagnostic path validates 32-bpp direct color before switching modes")
