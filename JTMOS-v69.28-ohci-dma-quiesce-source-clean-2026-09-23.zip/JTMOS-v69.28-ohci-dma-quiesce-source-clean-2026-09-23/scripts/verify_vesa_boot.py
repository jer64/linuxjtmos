#!/usr/bin/env python3
from pathlib import Path
import sys
if len(sys.argv) != 2:
    raise SystemExit('usage: verify_vesa_boot.py boot.bin')
b=Path(sys.argv[1]).read_bytes()
req={
 'VBE get mode info (AX=4F01h)': b'\xb8\x01\x4f',
 'VBE set mode (AX=4F02h)': b'\xb8\x02\x4f',
 'mode 101h + LFB (BX=4101h)': b'\xbb\x01\x41',
 'VBE success check (AX=004Fh)': b'\x3d\x4f\x00',
}
missing=[k for k,v in req.items() if v not in b]
if missing:
    raise SystemExit('ERROR: boot.bin VESA validation failed: '+', '.join(missing))
if b[510:512] != b'\x55\xaa':
    raise SystemExit('ERROR: boot signature 55AA missing')
if len(b)>18*512:
    raise SystemExit('ERROR: boot.bin exceeds 9 KiB boot track')
print(f'PASS: VESA/VBE boot loader present ({len(b)} bytes)')
