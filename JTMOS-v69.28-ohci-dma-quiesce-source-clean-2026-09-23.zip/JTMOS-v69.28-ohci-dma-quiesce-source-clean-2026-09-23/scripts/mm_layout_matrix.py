#!/usr/bin/env python3
"""Pure arithmetic cross-check of the dynamic JTMOS physical MM layout."""
PAGE=4096
DYN=0x00B00000
DB_MIN=1*1024*1024
BITMAP=128*1024
MD32=48
PTR32=4
PER_SLOT=MD32+PTR32
USER_PT_BYTES=4*1024*1024
USER_PT_PER_PROCESS=4096*4
PROC_CAP=USER_PT_BYTES//USER_PT_PER_PROCESS

def align_up(v): return (v+PAGE-1)&~(PAGE-1)
def db_size(ram):
    pages=(ram-DYN)//PAGE
    return max(DB_MIN,align_up(BITMAP+pages*PER_SLOT+PAGE))

print(f"process PTE capacity: {PROC_CAP}")
print("RAM MiB | DB KiB | DB start    | free MiB | free pages | descriptor capacity")
for mib in (16,24,32,48,64,80,96,128,256,512,1024,1536,2047):
    ram=mib*1024*1024
    if ram <= DYN+DB_MIN:
        print(f"{mib:7d} | insufficient RAM")
        continue
    db=db_size(ram)
    db_start=ram-db
    pages=(db_start-DYN)//PAGE
    cap=(db-BITMAP)//PER_SLOT
    status="PASS" if cap >= pages else "FAIL"
    print(f"{mib:7d} | {db//1024:6d} | 0x{db_start:08x} | {pages*PAGE//(1024*1024):8d} | {pages:10d} | {cap:10d} {status}")
