#!/usr/bin/env python3
import sys
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit('usage: patch_boot_clear_memory.py boot.bin')
p = Path(sys.argv[1])
b = bytearray(p.read_bytes())

# clear_memory starts with AX=1000h and historically loaded DS, then later
# incremented ES while the store still used DS.  Correct encoding uses ES both
# for the initial segment load and the segment override on the word store.
bad = bytes.fromhex('b800108ed8bf0000b80000b90800bf0000b800003e8905')
good = bytes.fromhex('b800108ec0bf0000b80000b90800bf0000b80000268905')

n_bad = b.count(bad)
n_good = b.count(good)
if n_bad == 1:
    i = b.index(bad)
    b[i:i+len(bad)] = good
    p.write_bytes(b)
    print(f'patched boot clear_memory at file offset 0x{i:x}: DS -> ES')
elif n_good == 1 and n_bad == 0:
    print('boot clear_memory already uses ES correctly')
else:
    raise SystemExit(f'ERROR: clear_memory signature unexpected (bad={n_bad}, good={n_good})')
