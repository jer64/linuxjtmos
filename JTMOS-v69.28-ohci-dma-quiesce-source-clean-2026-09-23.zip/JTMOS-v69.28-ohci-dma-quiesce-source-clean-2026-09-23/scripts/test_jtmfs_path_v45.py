#!/usr/bin/env python3
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
pc=(root/'kernel32/fs/jtmfs/jtmfsPath.c').read_text()
pa=(root/'kernel32/fs/jtmfs/jtmfsAccess.c').read_text()
jc=(root/'kernel32/fs/jtmfs/jtmfs.c').read_text()
ff=(root/'kernel32/fs/jtmfs/fsfind.c').read_text()
checks=[]
def ck(name, cond):
    checks.append((name,bool(cond)))
# Strip comments before checking for implementation side effects.
code_no_comments=re.sub(r'/\*.*?\*/|//.*', '', pc, flags=re.S)
ck('resolver has no SetThread side effects', 'SetThreadDNR' not in code_no_comments and 'SetThreadDB' not in code_no_comments)
ck('resolver does not call jtmfs_chdir', 'jtmfs_chdir(' not in code_no_comments)
ck('chdir resolves before commit', pa.find('jtmfsResolvePathAt') < pa.find('SetThreadDNR', pa.find('int jtmfs_chdir')))
ck('GetCWD uses reverse resolver', 'jtmfsBuildPath(GetCurrentDNR(), GetCurrentDB()' in pa)
ck('root DIRNAME slash preserved', 'if(!strcmp(name, "/"))' in jc and 'strcpy(dirname, "/")' in jc)
ck('explicit device paths recognized', 'explicit device-absolute path' in pc and 'has_device_colon(component)' in pc)
ck('parent from device root stays on device', "relative '..' at" in pc and 'return JTMFS_PATH_OK' in pc)
ck('lookup debug sleep removed', 'dsleep(1);' not in ff)
ck('CreateDirectory passes resolved basename', 'jtmfs_createdirectory(dnr, newBlock, db, r.name)' in pa)
for name,ok in checks:
    print(('PASS' if ok else 'FAIL')+': '+name)
if not all(ok for _,ok in checks):
    raise SystemExit(1)
