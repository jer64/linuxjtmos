#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PROFILE="${1:-small}"
case "$PROFILE" in
  small) CFG="$ROOT/kernel32/modules.small.conf" ;;
  full)  CFG="$ROOT/kernel32/modules.full.conf" ;;
  *)     CFG="$(realpath "$PROFILE")" ;;
esac
export JTMOS_MODULE_CONFIG="$CFG"
cd "$ROOT/kernel32"
./autogen.pl > generated.mak
make -j"${JOBS:-4}" -f generated.mak
make linkit -f generated.mak
cp "$CFG" modules.last-built.conf
cd "$ROOT"
./scripts/check_kernel_size.py kernel32/kernel32.bin
if command -v nasm >/dev/null 2>&1; then
  (cd boot32 && nasm -f bin boot.asm -o boot.bin)
else
  echo 'NOTE: nasm not installed; keeping existing boot32/boot.bin.' >&2
fi
python3 scripts/make_minimal_boot_image.py boot32/boot.bin kernel32/kernel32.bin "JTMOS-${PROFILE}-boot.img"
echo "Built: $ROOT/JTMOS-${PROFILE}-boot.img"
