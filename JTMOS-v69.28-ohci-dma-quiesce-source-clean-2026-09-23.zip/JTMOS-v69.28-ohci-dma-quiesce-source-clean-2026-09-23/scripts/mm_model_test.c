/*
 * Host-side model test for JTMOS kernel32/mm.
 *
 * This does not execute privileged CR0/CR3/INVLPG instructions. It mirrors
 * the physical bitmap, descriptor DB capacity, first-fit physical allocator,
 * virtual mapping window and the fixed low-memory/page-table layout so the
 * invariants can be stress-tested with ASan/UBSan on a normal host.
 */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PAGE_SIZE               4096u
#define BITMAP_PAGES            (1024u*1024u)
#define BITMAP_BYTES            (BITMAP_PAGES/8u)
#define DB_BYTES                (1024u*1024u)
#define PAGE_DIRECTORY_PHYS     0x002ff000u
#define KERNEL_PT_PHYS          0x00300000u
#define KERNEL_PT_BYTES         (4u*1024u*1024u)
#define USER_PT_PHYS            0x00700000u
#define USER_PT_BYTES           (4u*1024u*1024u)
#define STRUCTURES_END          (USER_PT_PHYS + USER_PT_BYTES)
#define DYNAMIC_START           STRUCTURES_END
#define VIRTUAL_START           0x40000000u
#define VIRTUAL_END             0x70000000u
#define USER_PAGES              4096u
#define N_MAX_THREADS_MODEL     250u

/* IA-32 layout of MD: two 32-bit pointer/address fields + five signed ints,
 * isFree int, and 20-byte name = 48 bytes. Keep it pointer-size independent. */
typedef struct {
    uint32_t p;
    int32_t PID;
    int32_t page;
    int32_t pages;
    int32_t bytes;
    int32_t isFree;
    uint32_t mapad;
    char name[20];
} MD32;

typedef struct {
    uint32_t page, pages, mapad;
    int used;
} Desc;

typedef struct {
    uint8_t bitmap[BITMAP_BYTES];
    uint32_t *pte;
    Desc *desc;
    uint32_t desc_cap;
    uint32_t ram_end;
    uint32_t db_start;
    uint32_t free_baseline_pages;
    uint32_t search_walk;
} Sim;

static int bit_get(const Sim *s, uint32_t p) {
    return !!(s->bitmap[p >> 3] & (uint8_t)(1u << (p & 7u)));
}
static void bit_set(Sim *s, uint32_t p, int state) {
    uint8_t m = (uint8_t)(1u << (p & 7u));
    if (state) s->bitmap[p >> 3] |= m;
    else s->bitmap[p >> 3] &= (uint8_t)~m;
}
static void region_set(Sim *s, uint32_t sp, uint32_t ep, int state) {
    uint32_t i;
    assert(sp <= ep && ep <= BITMAP_PAGES);
    for (i = sp; i < ep; ++i) bit_set(s, i, state);
}
static uint32_t count_free(const Sim *s) {
    uint32_t i, n = 0;
    for (i = 0; i < BITMAP_PAGES; ++i) if (!bit_get(s, i)) ++n;
    return n;
}
static uint32_t find_phys(const Sim *s, uint32_t pages) {
    uint32_t i, c = 0, sp = 0;
    if (!pages) return 0;
    for (i = 1; i < BITMAP_PAGES; ++i) {
        if (!bit_get(s, i)) {
            if (!c) sp = i;
            if (++c >= pages) return sp;
        } else {
            c = sp = 0;
        }
    }
    return 0;
}
static int virt_free(const Sim *s, uint32_t fp, uint32_t pages) {
    uint32_t i;
    if (fp >= BITMAP_PAGES || pages > BITMAP_PAGES - fp) return 0;
    for (i = 0; i < pages; ++i) if (s->pte[fp+i] & 1u) return 0;
    return 1;
}
static uint32_t find_virt(Sim *s, uint32_t amount) {
    const uint32_t start = VIRTUAL_START / PAGE_SIZE;
    const uint32_t end = VIRTUAL_END / PAGE_SIZE;
    const uint32_t span = end - start;
    uint32_t ad = 0, cnt = 0, scanned;
    if (!amount || amount > span) return 0;
    for (scanned = 0; scanned < span; ++scanned, ++s->search_walk) {
        if (s->search_walk >= end) {
            s->search_walk = start;
            cnt = ad = 0;
        }
        if (!(s->pte[s->search_walk] & 1u)) {
            if (!cnt) ad = s->search_walk * PAGE_SIZE;
            if (++cnt >= amount) {
                ++s->search_walk;
                if (s->search_walk >= end) s->search_walk = start;
                return ad;
            }
        } else {
            cnt = ad = 0;
        }
    }
    return 0;
}
static int find_desc(const Sim *s) {
    uint32_t i;
    for (i = 0; i < s->desc_cap; ++i) if (!s->desc[i].used) return (int)i;
    return -1;
}
static int sim_alloc(Sim *s, uint32_t bytes) {
    uint32_t pages, sp, va, vp, i;
    int d;
    if (!bytes) return -1;
    pages = (bytes + PAGE_SIZE - 1u) / PAGE_SIZE;
    sp = find_phys(s, pages);
    if (!sp) return -1;
    d = find_desc(s);
    if (d < 0) return -1;
    va = find_virt(s, pages);
    if (!va) return -1;
    vp = va/PAGE_SIZE;
    assert(virt_free(s, vp, pages));
    region_set(s, sp, sp+pages, 1);
    for (i=0;i<pages;++i) s->pte[vp+i] = ((sp+i)*PAGE_SIZE) | 3u;
    s->desc[d].page=sp; s->desc[d].pages=pages; s->desc[d].mapad=va; s->desc[d].used=1;
    return d;
}
static void sim_free(Sim *s, int d) {
    uint32_t i, vp;
    assert(d >= 0 && (uint32_t)d < s->desc_cap && s->desc[d].used);
    vp=s->desc[d].mapad/PAGE_SIZE;
    for(i=0;i<s->desc[d].pages;++i) s->pte[vp+i]=2u;
    region_set(s,s->desc[d].page,s->desc[d].page+s->desc[d].pages,0);
    memset(&s->desc[d],0,sizeof(s->desc[d]));
}
static uint32_t descriptor_capacity(void) {
    const uint32_t payload = DB_BYTES - BITMAP_BYTES;
    const uint32_t unit = 4u + (uint32_t)sizeof(MD32);
    uint32_t n=payload/unit;
    while (n && n*4u + n*(uint32_t)sizeof(MD32) > payload) --n;
    return n;
}
static void sim_init(Sim *s, uint32_t ram_mb) {
    uint32_t i, id_pages;
    memset(s,0,sizeof(*s));
    s->ram_end=ram_mb*1024u*1024u;
    assert(s->ram_end > DYNAMIC_START + DB_BYTES);
    s->db_start=s->ram_end-DB_BYTES;
    s->desc_cap=descriptor_capacity();
    s->pte=(uint32_t*)calloc(BITMAP_PAGES,sizeof(uint32_t));
    s->desc=(Desc*)calloc(s->desc_cap,sizeof(Desc));
    assert(s->pte && s->desc);
    memset(s->bitmap,0xff,sizeof(s->bitmap));
    region_set(s,DYNAMIC_START/PAGE_SIZE,s->db_start/PAGE_SIZE,0);
    /* Fixed paging structures are below DYNAMIC_START; reserve anyway to model
       pg_reserve_internal_pages() exactly. */
    region_set(s,PAGE_DIRECTORY_PHYS/PAGE_SIZE,STRUCTURES_END/PAGE_SIZE,1);
    id_pages=STRUCTURES_END/PAGE_SIZE;
    for(i=1;i<id_pages;++i) s->pte[i]=(i*PAGE_SIZE)|3u;
    s->pte[0]=2u;
    s->search_walk=VIRTUAL_START/PAGE_SIZE;
    s->free_baseline_pages=count_free(s);
}
static void sim_destroy(Sim *s) { free(s->pte); free(s->desc); }

static void verify_layout(const Sim *s) {
    uint32_t expected=(s->db_start-DYNAMIC_START)/PAGE_SIZE;
    uint32_t per_process=USER_PAGES*4u;
    uint32_t process_capacity=USER_PT_BYTES/per_process;
    assert(PAGE_DIRECTORY_PHYS < KERNEL_PT_PHYS);
    assert(KERNEL_PT_PHYS + KERNEL_PT_BYTES == USER_PT_PHYS);
    assert(USER_PT_PHYS + USER_PT_BYTES == DYNAMIC_START);
    assert(s->db_start > DYNAMIC_START);
    assert(s->free_baseline_pages == expected);
    assert(process_capacity == 256u);
    assert(process_capacity >= N_MAX_THREADS_MODEL);
    assert(s->desc_cap == 17644u);
    assert(s->pte[(STRUCTURES_END/PAGE_SIZE)-1u] & 1u);
    printf("layout: RAM=%u MiB, dyn=%#x..%#x (%u pages / %u MiB), DB=%#x..%#x\n",
           s->ram_end/(1024u*1024u),DYNAMIC_START,s->db_start,expected,
           expected*PAGE_SIZE/(1024u*1024u),s->db_start,s->ram_end);
    printf("layout: paging=%#x..%#x, user-PT capacity=%u processes, descriptors=%u\n",
           PAGE_DIRECTORY_PHYS,STRUCTURES_END,process_capacity,s->desc_cap);
}
static void test_rounding(Sim *s) {
    int a=sim_alloc(s,1), b=sim_alloc(s,4096), c=sim_alloc(s,4097);
    assert(a>=0&&b>=0&&c>=0);
    assert(s->desc[a].pages==1 && s->desc[b].pages==1 && s->desc[c].pages==2);
    sim_free(s,a);sim_free(s,b);sim_free(s,c);
    assert(count_free(s)==s->free_baseline_pages);
}
static void test_exhaustion(Sim *s) {
    int *ids=(int*)malloc(sizeof(int)*s->free_baseline_pages);
    uint32_t n=0,i;
    assert(ids);
    while(n<s->free_baseline_pages) {
        int d=sim_alloc(s,1);
        if(d<0) break;
        ids[n++]=d;
    }
    assert(n==s->free_baseline_pages); /* 64 MiB: descriptor cap is larger. */
    assert(sim_alloc(s,1)<0);
    for(i=0;i<n;++i) sim_free(s,ids[i]);
    assert(count_free(s)==s->free_baseline_pages);
    free(ids);
    printf("exhaustion: allocated/freed all %u physical pages without DB overlap\n",n);
}
static uint32_t rnd_state=0x19082026u;
static uint32_t rnd(void){rnd_state=rnd_state*1664525u+1013904223u;return rnd_state;}
static void test_random(Sim *s) {
    int active[1024];
    uint32_t n=0,step;
    for(step=0;step<30000u;++step) {
        if(n && (n>=1024u || (rnd()&3u)==0u)) {
            uint32_t k=rnd()%n;
            sim_free(s,active[k]);
            active[k]=active[--n];
        } else {
            uint32_t bytes;
            int d;
            if((rnd()&7u)<6u) bytes=1u+(rnd()%(64u*1024u));
            else bytes=1u+(rnd()%(512u*1024u));
            d=sim_alloc(s,bytes);
            if(d>=0) active[n++]=d;
        }
        if((step%1000u)==0u) {
            uint32_t i,j;
            for(i=0;i<n;++i) {
                const Desc *a=&s->desc[active[i]];
                assert(a->page*PAGE_SIZE>=DYNAMIC_START);
                assert((a->page+a->pages)*PAGE_SIZE<=s->db_start);
                assert(a->mapad>=VIRTUAL_START && a->mapad+a->pages*PAGE_SIZE<=VIRTUAL_END);
                for(j=i+1;j<n;++j) {
                    const Desc *b=&s->desc[active[j]];
                    assert(a->page+a->pages<=b->page || b->page+b->pages<=a->page);
                }
            }
        }
    }
    while(n) sim_free(s,active[--n]);
    assert(count_free(s)==s->free_baseline_pages);
    printf("random: 30,000 alloc/free operations; invariants and rollback PASS\n");
}
int main(void) {
    Sim s;
    assert(sizeof(MD32)==48u);
    sim_init(&s,64u);
    verify_layout(&s);
    test_rounding(&s);
    test_exhaustion(&s);
    test_random(&s);
    printf("PASS: JTMOS MM model returned exactly to baseline (%u pages / %u bytes free).\n",
           s.free_baseline_pages,s.free_baseline_pages*PAGE_SIZE);
    sim_destroy(&s);
    return 0;
}
