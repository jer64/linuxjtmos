#!/usr/bin/env python3
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]

def text(rel): return (root/rel).read_text(errors='replace')
def must(cond,msg):
    if not cond:
        print('FAIL:',msg)
        sys.exit(1)
    print('PASS:',msg)

ser=text('kernel32/drivers/serial/serial.c')
serh=text('kernel32/drivers/serial/serial.h')
sm=text('kernel32/drivers/mouse/SerialMouse.c')
ps=text('kernel32/drivers/mouse/ps2mouse.c')
kb=text('kernel32/drivers/keyboard/keyb.c')
hw=text('kernel32/core/hwdet/hwdet.c')
ci=text('kernel32/core/int/int.c')
gpf=text('kernel32/core/cp/gpf.c')
aslib=text('kernel32/core/asm/aslib.asm')
slip=text('kernel32/drivers/slip/slip.c')+text('kernel32/drivers/slip/slipLogin.c')

must('if(serialInitialized)' in ser, 'serial_init has active re-entry guard')
must('SERIAL_ENABLED && !serialInitialized' in hw, 'hwdet skips redundant serial_init')
must('for(i=0; i<4; i++)' in ser, 'serial TX flusher services COM1..COM4')
must('serial_drain_rx(0);' in ser and 'serial_drain_rx(2);' in ser, 'IRQ4 services COM1+COM3')
must('serial_drain_rx(1);' in ser and 'serial_drain_rx(3);' in ser, 'IRQ3 services COM2+COM4')
must('if(lsr==0xFF) break' in ser, 'phantom/floating UART cannot spin RX drain')
must('serial_probe_uart' in ser, 'UART presence probing is active')
must('if(serialInitialized) return -1;' in ser, 'legacy serial_get1 cannot bypass managed RX after init')
must('serial_get_owned' in slip and 'SERIAL_OWNER_SLIP' in slip, 'SLIP consumes only its claimed FIFO')
must('serial_get_owned' in sm and 'SERIAL_OWNER_SERMOUSE' in sm, 'serial mouse consumes only its claimed FIFO')
must('SetSerialPortSpeedOwned(i,1200,SERIAL_OWNER_SERMOUSE)' in sm, 'serial mouse configures 1200 bps under ownership')
must('status&KBD_STAT_MOUSE_OBF' in ps, 'PS/2 IRQ checks AUX source bit')
irq=re.search(r'void ps2mouse_irqhandler12\(void\).*?\n}',ps,re.S)
must(irq is not None and len(re.findall(r'inportb\(0x60\)',irq.group(0)))==1, 'PS/2 IRQ reads exactly one 0x60 byte per IRQ')
must('if(status&KBD_STAT_MOUSE_OBF)' in kb, 'keyboard IRQ refuses AUX bytes')
must('ps2mouse_kbcmd(0xD4)' in ps and 'ps2mouse_send_byte((BYTE)value)' in ps, 'every PS/2 mouse command byte/parameter uses AUX routing')
must('data==PS2_ACK || data==PS2_RESEND' in ps, 'ACK/RESEND excluded from motion packet stream')
must('waitpesc();' not in ci, 'compiled interrupt C path no longer calls raw waitpesc')
must('inportb(0x60)' not in gpf, 'compiled GPF path has no direct 0x60 read')
wait=re.search(r'waitpesc:\s*(.*?)(?:\n\S|\Z)',aslib,re.S)
must('waitpesc:' in aslib and re.search(r'waitpesc:\s+ret',aslib) is not None, 'future NASM waitpesc build is a no-op')
for sym in ['serial_rx_dropped','serial_hw_overrun','serial_hw_framing','serial_hw_parity']:
    must(sym in serh, f'{sym} diagnostic exported')
print('ALL STATIC SERIAL/MOUSE SAFETY CHECKS PASSED')
