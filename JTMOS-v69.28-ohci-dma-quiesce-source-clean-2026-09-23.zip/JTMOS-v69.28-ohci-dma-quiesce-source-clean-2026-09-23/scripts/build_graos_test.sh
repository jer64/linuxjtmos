#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT=${1:-"$ROOT/GraOS-boot-test.img"}
PKG=${2:-"$ROOT/GraOS-boot-payload.pkg"}

echo "--- Verifying boot source: 32-bpp direct-color GraOS contract"
grep -Eq '^%define[[:space:]]+BOOT_VESA_GRAPHICS[[:space:]]+1' "$ROOT/boot32/boot.asm" || { echo "ERROR: BOOT_VESA_GRAPHICS is not active in boot32/boot.asm" >&2; exit 1; }
grep -q '^select_vesa_resolution:' "$ROOT/boot32/boot.asm" || { echo "ERROR: BIOS VBE mode-list selector missing" >&2; exit 1; }
grep -q 'mov ax,0x4F00' "$ROOT/boot32/boot.asm" || { echo "ERROR: VBE controller-info query missing" >&2; exit 1; }
grep -q 'GRAOS_VESA_WIDTH 1024' "$ROOT/boot32/boot.asm" || { echo "ERROR: GraOS width contract is not 1024" >&2; exit 1; }
grep -q 'GRAOS_VESA_HEIGHT 768' "$ROOT/boot32/boot.asm" || { echo "ERROR: GraOS height contract is not 768" >&2; exit 1; }
grep -Eiq 'mov[[:space:]]+esp,0x0*7c00' "$ROOT/boot32/boot.asm" || { echo "ERROR: boot32/boot.asm does not set ESP=0x7C00" >&2; exit 1; }
if grep -Eq 'movl?[[:space:]]+\$?0x[0-9A-Fa-f]+,[[:space:]]*%?esp|mov[[:space:]]+esp,[[:space:]]*0x[0-9A-Fa-f]+' "$ROOT/kernel32/init/start.c"; then
    echo "ERROR: kernel32/init/start.c must inherit ESP from boot32; it must not rewrite ESP" >&2
    exit 1
fi

echo "--- Verifying palette-safe early boot"
grep -Eq '^int[[:space:]]+vga_debug_palette_effects[[:space:]]*=[[:space:]]*0;' "$ROOT/kernel32/init/keropt.c" || { echo "ERROR: vga_debug_palette_effects must default to 0" >&2; exit 1; }
grep -q 'if(vga_debug_palette_effects)' "$ROOT/kernel32/core/int/int.c" || { echo "ERROR: init_safe_idt VGA DAC writes are not guarded" >&2; exit 1; }

echo "--- Building VESA boot loader"
if command -v nasm >/dev/null 2>&1; then
    (
        cd "$ROOT/boot32"
        nasm -f bin boot.asm -o boot.bin.new
        mv boot.bin.new boot.bin
    )
else
    echo "ERROR: NASM is required; the unsafe prebuilt 8-bpp VESA patch path has been removed" >&2
    exit 1
fi
"$ROOT/scripts/verify_vesa_boot.py" "$ROOT/boot32/boot.bin"
"$ROOT/scripts/patch_boot_stack_7c00.py" "$ROOT/boot32/boot.bin"
"$ROOT/scripts/patch_boot_clear_memory.py" "$ROOT/boot32/boot.bin"

"$ROOT/scripts/build_graos_apps.sh"
cd "$ROOT/kernel32"
JTMOS_MODULE_CONFIG=modules.graos-vesa.conf ./autogen.pl > generated.mak
make -j2 -f generated.mak
make -f generated.mak linkit
cd "$ROOT"
"$ROOT/scripts/make_graos_boot_image.py" \
  "$ROOT/boot32/boot.bin" \
  "$ROOT/kernel32/kernel32.bin" \
  "$ROOT/kernel32/graos_boot_payload" \
  "$OUT" "$PKG"
(cd "$(dirname "$OUT")" && sha256sum "$(basename "$OUT")") > "$OUT.sha256"
echo "Built: $OUT"
echo "Checksum: $OUT.sha256"
