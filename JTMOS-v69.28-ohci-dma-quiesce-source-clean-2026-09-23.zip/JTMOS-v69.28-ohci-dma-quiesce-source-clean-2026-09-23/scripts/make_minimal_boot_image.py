#!/usr/bin/env python3
import hashlib, struct, sys
from pathlib import Path

FLOPPY_SIZE = 1440 * 1024
SECTOR = 512
BOOT_TRACK_SECTORS = 18
KERNEL_OFFSET = BOOT_TRACK_SECTORS * SECTOR
CHECKSUM_BYTES = 512 * 1024
LOADER_LIMIT = 512 * 1024

if len(sys.argv) != 4:
    raise SystemExit('usage: make_minimal_boot_image.py BOOT.BIN KERNEL.BIN OUT.IMG')
boot_path, kernel_path, out_path = map(Path, sys.argv[1:])
boot = bytearray(boot_path.read_bytes())
kernel = kernel_path.read_bytes()
if len(boot) > KERNEL_OFFSET:
    raise SystemExit(f'boot loader too large: {len(boot)} > {KERNEL_OFFSET}')
if len(kernel) > LOADER_LIMIT:
    raise SystemExit(f'kernel too large for legacy loader: {len(kernel)} > {LOADER_LIMIT}')
if len(boot) < 512 or boot[510:512] != b'\x55\xaa':
    raise SystemExit('boot signature 55AA missing')
checksum_region = kernel[:CHECKSUM_BYTES].ljust(CHECKSUM_BYTES, b'\0')
checksum = sum(checksum_region) & 0xffff
struct.pack_into('<H', boot, 501, checksum)
img = bytearray(FLOPPY_SIZE)
img[:len(boot)] = boot
img[KERNEL_OFFSET:KERNEL_OFFSET+len(kernel)] = kernel
out_path.write_bytes(img)
print(f'boot={len(boot)} bytes')
print(f'kernel={len(kernel)} bytes')
print(f'kernel physical range=0x10000..0x{0x10000+len(kernel)-1:x}')
print(f'legacy loader headroom={LOADER_LIMIT-len(kernel)} bytes')
print(f'checksum=0x{checksum:04x}')
print(f'sha256={hashlib.sha256(img).hexdigest()}')
