#!/usr/bin/env python3
import hashlib
import struct
import sys
from pathlib import Path

FLOPPY_SIZE = 1440 * 1024
SECTOR = 512
BOOT_TRACK_SECTORS = 18
KERNEL_FIRST_SECTOR = 18
# The legacy loader reads 57 full 18-sector tracks before ES exceeds LOADLIMIT.
KERNEL_LOAD_SECTORS = 57 * 18
PACKAGE_SECTOR = KERNEL_FIRST_SECTOR + KERNEL_LOAD_SECTORS  # 1044
PACKAGE_MAGIC = b"GRAOSPK1"
FILES = ["graos.bin", "mousecursor.raw", "title_close98.raw", "title_minimize98.raw", "jtmos_poster.raw"]

def build_package(payload_dir: Path) -> bytes:
    header = bytearray(SECTOR)
    header[:8] = PACKAGE_MAGIC
    struct.pack_into("<I", header, 8, len(FILES))
    struct.pack_into("<I", header, 12, 1)
    body = bytearray()
    rel_sector = 1
    for i, name in enumerate(FILES):
        data = (payload_dir / name).read_bytes()
        encoded = name.encode("ascii")
        if len(encoded) >= 32:
            raise SystemExit(f"payload filename too long: {name}")
        off = 16 + i * 40
        header[off:off+len(encoded)] = encoded
        struct.pack_into("<II", header, off+32, rel_sector, len(data))
        body.extend(data)
        pad = (-len(data)) % SECTOR
        if pad:
            body.extend(b"\0" * pad)
        rel_sector += (len(data) + SECTOR - 1) // SECTOR
    return bytes(header) + bytes(body)

def main():
    if len(sys.argv) != 6:
        raise SystemExit("usage: make_graos_boot_image.py BOOT.BIN KERNEL.BIN PAYLOAD_DIR OUT.IMG OUT.PKG")
    boot_path, kernel_path, payload_dir, out_img, out_pkg = map(Path, sys.argv[1:])
    boot = bytearray(boot_path.read_bytes())
    kernel = kernel_path.read_bytes()
    if len(kernel) > KERNEL_LOAD_SECTORS * SECTOR:
        raise SystemExit(f"kernel too large for legacy loader: {len(kernel)} > {KERNEL_LOAD_SECTORS*SECTOR}")
    if len(boot) > BOOT_TRACK_SECTORS * SECTOR:
        raise SystemExit("boot loader exceeds first 9K track")

    # Kernel checksum routine sums exactly 0x10000..0x8ffff (512 KiB).
    checksum_region = kernel[:512*1024].ljust(512*1024, b"\0")
    checksum = sum(checksum_region) & 0xffff
    # correct_kchecksum is deliberately located at byte 501 of sector 0.
    struct.pack_into("<H", boot, 501, checksum)
    if boot[510:512] != b"\x55\xaa":
        raise SystemExit("boot signature 55AA missing")

    package = build_package(payload_dir)
    pkg_end = PACKAGE_SECTOR * SECTOR + len(package)
    if pkg_end > FLOPPY_SIZE:
        raise SystemExit(f"GraOS package does not fit floppy ({pkg_end} > {FLOPPY_SIZE})")

    image = bytearray(FLOPPY_SIZE)
    image[:len(boot)] = boot
    k_off = KERNEL_FIRST_SECTOR * SECTOR
    image[k_off:k_off+len(kernel)] = kernel
    p_off = PACKAGE_SECTOR * SECTOR
    image[p_off:p_off+len(package)] = package

    out_img.write_bytes(image)
    out_pkg.write_bytes(package)
    print(f"kernel={len(kernel)} bytes")
    print(f"checksum=0x{checksum:04x}")
    print(f"package_sector={PACKAGE_SECTOR}")
    print(f"package={len(package)} bytes")
    print(f"image={len(image)} bytes")
    print(f"sha256={hashlib.sha256(image).hexdigest()}")

if __name__ == "__main__":
    main()
