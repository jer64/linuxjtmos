#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$HERE/.." && pwd)
LOGDIR=${1:-"$ROOT/qemu-debug-v6"}
OUT=${2:-"$ROOT/GraOS-v6-qemu-debug-logs.zip"}
python3 "$HERE/analyze_qemu_v6.py" --serial "$LOGDIR/jtmos-serial.log" --cpu "$LOGDIR/qemu-cpu.log" --sym "$ROOT/kernel32/kernel32.sym" --out "$LOGDIR/analysis.txt" || true
(cd "$LOGDIR" && zip -9 -q "$OUT" jtmos-serial.log qemu-cpu.log analysis.txt 2>/dev/null || true)
echo "$OUT"
