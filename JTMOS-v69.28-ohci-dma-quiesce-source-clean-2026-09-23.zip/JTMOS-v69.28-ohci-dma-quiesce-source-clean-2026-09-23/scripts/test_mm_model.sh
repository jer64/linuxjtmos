#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CC="${CC:-gcc}"
OUT="${TMPDIR:-/tmp}/jtmos-mm-model-test"
CFLAGS=(-std=c99 -O1 -g -Wall -Wextra -Werror)
if "$CC" -x c -fsanitize=address,undefined -o /tmp/jtmos-san-probe - <<<'int main(void){return 0;}' >/dev/null 2>&1; then
  CFLAGS+=(-fsanitize=address,undefined -fno-omit-frame-pointer)
fi
"$CC" "${CFLAGS[@]}" "$ROOT/scripts/mm_model_test.c" -o "$OUT"
"$OUT"
