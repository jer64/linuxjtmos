#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
LIBC="$ROOT/libc"
GUI="$LIBC/apps/gui"
APPS="$LIBC/apps"
PAYLOAD="$ROOT/kernel32/graos_boot_payload"
CFLAGS="-m32 -std=gnu89 -w -c -O2 -march=i486 -DCPU=i586 -fno-pie -fno-stack-protector -fcommon -I$LIBC/include"
gcc -m32 -c "$LIBC/libc/stlibc/stlibc_gas.S" -o "$LIBC/libc/stlibc.o"
# Keep the message-queue GraOS client in libc synchronized with the server ABI.
(cd "$LIBC/libc/graosClient" && \
 gcc $CFLAGS graosClient.c -o graosClient.o && \
 ar rcs "$LIBC/lib/libcjtmos.a" graosClient.o)
(cd "$GUI" && make -f graos.mak clean >/dev/null 2>&1 || true && make -f graos.mak)
rm -rf "$PAYLOAD" && mkdir -p "$PAYLOAD"
cp "$GUI/graos.bin" "$PAYLOAD/graos.bin"
cp "$GUI/mousecursor.raw" "$PAYLOAD/mousecursor.raw"
cp "$GUI/title_close98.raw" "$PAYLOAD/title_close98.raw"
cp "$GUI/title_minimize98.raw" "$PAYLOAD/title_minimize98.raw"
cp "$GUI/jtmos_poster.raw" "$PAYLOAD/jtmos_poster.raw"
echo "GraOS staged: graos + RGBA cursor + RGBA chrome + RGBA startup poster"
