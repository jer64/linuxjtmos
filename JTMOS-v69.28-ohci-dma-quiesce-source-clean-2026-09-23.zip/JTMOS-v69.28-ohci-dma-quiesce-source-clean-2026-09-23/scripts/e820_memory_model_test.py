#!/usr/bin/env python3
"""Model the exact V67.4 E820 managed-range and dynamic-MM-DB arithmetic."""
PAGE=4096
PG_END=0x00B00000
MANAGED_MAX=0x7FF00000
MM_BITMAP_BYTES=128*1024
MM_DB_MIN=1024*1024
MD32=48
PTR32=4

def align_up(v,a=PAGE): return (v+a-1)&~(a-1)
def align_down(v,a=PAGE): return v&~(a-1)

def managed_end(entries):
    best=0
    usable=0
    for base,length,typ in entries:
        if typ != 1 or length <= 0 or base >= 2**32:
            continue
        end=min(base+length,0xffffffff)
        usable=min(0xffffffff,usable+max(0,end-base))
        if base <= PG_END < end:
            best=max(best,align_down(min(end,MANAGED_MAX)))
    return best,usable

def db_layout(end):
    pages=(end-PG_END)//PAGE
    per=PTR32+MD32
    db=max(MM_DB_MIN,align_up(MM_BITMAP_BYTES+pages*per+PAGE))
    dyn_pages=(end-db-PG_END)//PAGE
    capacity=(db-MM_BITMAP_BYTES)//per
    return db,dyn_pages,capacity

def qemu_map(mib):
    top=mib*1024*1024
    return [
        (0x00000000,0x0009fc00,1),
        (0x0009fc00,0x00060400,2),
        (0x00100000,top-0x00100000,1),
    ]

for mib in (16,24,32,64,80,96,128,256,512,1024,1536,2047):
    end,usable=managed_end(qemu_map(mib))
    assert end == min(mib*1024*1024,MANAGED_MAX), (mib,hex(end))
    db,pages,cap=db_layout(end)
    assert cap >= pages, (mib,pages,cap)
    print(f"PASS {mib:4} MiB -> top=0x{end:08x} DB={db//1024:6} KiB pages={pages:7} cap={cap:7}")

# A reserved hole above the kernel must stop the one-range allocator at the hole.
hole=[
    (0x00100000,31*1024*1024,1), # ends at 32 MiB
    (0x02000000,4*1024*1024,2),
    (0x02400000,28*1024*1024,1),
]
end,_=managed_end(hole)
assert end==0x02000000, hex(end)
print("PASS reserved-hole safety -> managed top stops at 32 MiB")

# A map with no usable extent containing the fixed paging area must be rejected.
bad=[(0x00100000,8*1024*1024,1),(0x00900000,8*1024*1024,2)]
end,_=managed_end(bad)
assert end==0
print("PASS missing-kernel-containing usable range -> rejected")
