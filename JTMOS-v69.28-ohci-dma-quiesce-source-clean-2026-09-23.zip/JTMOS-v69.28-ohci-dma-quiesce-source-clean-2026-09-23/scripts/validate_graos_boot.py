#!/usr/bin/env python3
import hashlib
import struct
import sys
from pathlib import Path

SECTOR=512
KERNEL_FIRST=18
PACKAGE_SECTOR=1044
EXPECTED=['graos.bin','mousecursor.raw','title_close98.raw','title_minimize98.raw','jtmos_poster.raw']

def fail(msg):
    raise SystemExit('FAIL: '+msg)

def main():
    root=Path(__file__).resolve().parent.parent
    img=Path(sys.argv[1]) if len(sys.argv)>1 else root/'GraOS-boot-test.img'
    data=img.read_bytes()
    if len(data)!=1440*1024: fail(f'wrong image size {len(data)}')
    if data[510:512]!=b'\x55\xaa': fail('missing 55AA boot signature')
    stored=struct.unpack_from('<H',data,501)[0]
    measured=sum(data[KERNEL_FIRST*SECTOR:KERNEL_FIRST*SECTOR+512*1024])&0xffff
    if stored!=measured: fail(f'kernel checksum {stored:04x}!={measured:04x}')
    base=PACKAGE_SECTOR*SECTOR
    if data[base:base+8]!=b'GRAOSPK1': fail('missing GRAOSPK1 package')
    count=struct.unpack_from('<I',data,base+8)[0]
    if count!=len(EXPECTED): fail(f'payload count {count}')
    found=[]
    payload=root/'kernel32/graos_boot_payload'
    for i in range(count):
        e=base+16+i*40
        name=data[e:e+32].split(b'\0',1)[0].decode('ascii')
        rel,size=struct.unpack_from('<II',data,e+32)
        if name not in EXPECTED: fail(f'unexpected payload {name}')
        filedata=data[(PACKAGE_SECTOR+rel)*SECTOR:(PACKAGE_SECTOR+rel)*SECTOR+size]
        src=(payload/name).read_bytes()
        if filedata!=src: fail(f'payload mismatch {name}')
        found.append(name)
    if found!=EXPECTED: fail(f'payload order mismatch: {found}')
    kernel=(root/'kernel32/kernel32.bin').read_bytes()
    if len(kernel)>512*1024: fail(f'kernel exceeds 512 KiB: {len(kernel)}')
    for name in ('graos.bin',):
        b=(payload/name).read_bytes()
        if b'[VALID JTMOS EXECUTABLE BINARY FILE FCE2E37BE38BA000]' not in b:
            fail(f'missing JTMOS executable marker in {name}')
        if b'[JTMOS LIBC (C) 2002 Jari Tuominen]' not in b:
            fail(f'missing JTMOS LIBC marker in {name}')
    print('PASS')
    print(f'image={img}')
    print(f'kernel={len(kernel)} bytes')
    print(f'checksum=0x{stored:04x}')
    print(f'payload_files={count}')
    print(f'sha256={hashlib.sha256(data).hexdigest()}')

if __name__=='__main__':
    main()
