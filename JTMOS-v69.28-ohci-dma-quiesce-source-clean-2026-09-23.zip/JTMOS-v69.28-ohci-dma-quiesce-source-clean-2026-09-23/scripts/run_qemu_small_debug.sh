#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
IMG="${1:-$ROOT/JTMOS-small-boot.img}"
OUT="${2:-$ROOT/qemu-small-debug}"
mkdir -p "$OUT"
rm -f "$OUT/serial_output.log" "$OUT/qemu_cpu.log"
exec qemu-system-i386 -m 64 \
  -drive "file=$IMG,format=raw,if=floppy" -boot a \
  -serial "file:$OUT/serial_output.log" \
  -monitor none -no-reboot -no-shutdown \
  -d int,guest_errors,cpu_reset -D "$OUT/qemu_cpu.log"
