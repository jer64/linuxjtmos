#!/bin/sh
set -u
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$HERE/.." && pwd)
IMG=${1:-"$ROOT/GraOS-boot-test-v6-debug-2026-08-19.img"}
LOGDIR=${2:-"$ROOT/qemu-debug-v6"}
SERIAL="$LOGDIR/jtmos-serial.log"
CPU="$LOGDIR/qemu-cpu.log"
ANALYSIS="$LOGDIR/analysis.txt"
SYM="$ROOT/kernel32/kernel32.sym"

mkdir -p "$LOGDIR"
rm -f "$SERIAL" "$CPU" "$ANALYSIS"

if ! command -v qemu-system-i386 >/dev/null 2>&1; then
    echo "ERROR: qemu-system-i386 not found." >&2
    echo "Ubuntu/Debian: sudo apt install qemu-system-x86" >&2
    exit 127
fi

printf '%s\n' "JTMOS V6 debug logs:" "  serial: $SERIAL" "  cpu:    $CPU" "Close QEMU after the black/fault screen to run automatic analysis."

qemu-system-i386 \
  -m 64 \
  -drive file="$IMG",format=raw,if=floppy \
  -boot a \
  -serial file:"$SERIAL" \
  -monitor none \
  -no-reboot -no-shutdown \
  -d int,guest_errors,cpu_reset \
  -D "$CPU"
STATUS=$?

python3 "$HERE/analyze_qemu_v6.py" \
  --serial "$SERIAL" --cpu "$CPU" --sym "$SYM" --out "$ANALYSIS" || true

echo "Analysis: $ANALYSIS"
exit $STATUS
