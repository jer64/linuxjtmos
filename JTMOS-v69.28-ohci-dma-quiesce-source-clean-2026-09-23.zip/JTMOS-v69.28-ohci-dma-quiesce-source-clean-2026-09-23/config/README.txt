JTMOS build configuration
=========================

Boot display
------------
The maintained default lives in config/boot.mk:

    BOOT_DISPLAY ?= text

Supported values:

    text   VGA text handoff.  Works with QEMU -display curses and headless VMs.
    vesa   Enter BIOS VESA/VBE graphics mode before kernel32.

You can either edit config/boot.mk or override it for one build:

    make image
    make BOOT_DISPLAY=vesa image

Convenience aliases:

    make image-headless
    make image-gui

Changing BOOT_DISPLAY automatically invalidates the boot32pm binary through a
profile stamp, so switching text -> vesa -> text cannot accidentally reuse a
boot.bin assembled for the previous mode.

There is intentionally no BIOS-display "auto" mode: QEMU's curses/GTK/SDL
backend is a host-side choice and cannot be detected reliably by the guest BIOS
loader.  Keeping the choice explicit avoids a black curses screen.

Kernel console profile
----------------------
BOOT_DISPLAY also selects safe kernel early-console defaults:

    text:  serial_console_redirect=0, vesa_early_serial_only=0
    vesa:  serial_console_redirect=1, vesa_early_serial_only=1

The values are compiled through an auto-generated kernel32/console_profile.generated.h.
They may be overridden for diagnostics, for example:

    make BOOT_DISPLAY=text KERNEL_SERIAL_CONSOLE_REDIRECT=1 image

The Linode/headless release intentionally uses 0/0 so normal curses/VGA output is
not duplicated to the UART and the VESA-only early serial bypass never suppresses
the text terminal.

Linode kernel module profile
----------------------------
`make image-linode` also selects `kernel32/modules.linode.conf`.  It keeps the
network stack, SQSH/application loader and PCI support used by the server demo,
but sets:

    AUDIO_DRIVERS=0

The kernel autogenerator therefore omits drivers/audio, drivers/hda, drivers/sb
and drivers/gus from kernel32.bin.  The Linode QEMU wrapper also sets
`JTMOS_AUDIO=off`.  Since V68.197 all normal QEMU launchers also default to
`JTMOS_AUDIO=off`, so an emulated GUS is created only when explicitly requested
with `JTMOS_AUDIO=gus`.  The Linode module profile additionally removes the audio
drivers at build time.  Normal `make image`, `make image-headless` and
`make image-gui` continue to use modules.conf unless KERNEL_MODULE_CONFIG is
overridden explicitly.
