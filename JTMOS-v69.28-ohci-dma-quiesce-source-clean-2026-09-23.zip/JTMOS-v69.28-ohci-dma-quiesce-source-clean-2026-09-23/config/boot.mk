# JTMOS boot display profile.
#
# vesa  - BIOS selects and enters a VBE/LFB graphics mode before kernel32.
#         This is the normal physical/GraOS release default, including images
#         later installed to HDD with rootinstall.
# text  - Explicit VGA text/curses fallback for headless/Linode systems and
#         low-overhead diagnostics (`make image-headless`).
#
# Command-line values override this file, for example:
#   make BOOT_DISPLAY=vesa image
BOOT_DISPLAY ?= vesa

# Kernel early-console defaults follow BOOT_DISPLAY in the top-level Makefile.
# text/headless: serial_console_redirect=0, vesa_early_serial_only=0
# vesa/gui:      serial_console_redirect=1, vesa_early_serial_only=1
# Either value can still be overridden explicitly on the make command line.
