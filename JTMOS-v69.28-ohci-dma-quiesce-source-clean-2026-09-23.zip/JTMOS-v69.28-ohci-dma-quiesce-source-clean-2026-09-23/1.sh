#!/bin/sh
# JTMOS V68.197 convenient headless development launcher.
# Defaults: curses display, bridged networking (real DHCP/LAN address), no GUS.
# Every setting remains overridable from the environment.
set -eu
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export JTMOS_DISPLAY=${JTMOS_DISPLAY:-curses}
export JTMOS_USB_INPUT=${JTMOS_USB_INPUT:-off}
export JTMOS_NET_MODE=${JTMOS_NET_MODE:-bridge}
export JTMOS_BRIDGE=${JTMOS_BRIDGE:-br0}
export JTMOS_AUDIO=${JTMOS_AUDIO:-off}
exec "$DIR/run_jtmos_qemu.sh" "$@"
