# JTMOS versioning

JTMOS public releases use the compact **MAJOR.MINOR** format.
The legacy release gate calls the same two-component scheme **MAJOR.RELEASE**; here RELEASE and MINOR refer to the same second component.

- `69` is the current JTMOS major generation.
- The second component is the minor release number and is reset when the major generation increases.
- Current release: **V69.28**.
- Current normal release: **V69.19**.

The older multi-component version strings are historical lineage identifiers,
not new public version numbers.  V68.100 corresponds to the old lineage
`68.8.57.10.18.16.100`; V68.101 is the first maintenance/restoration release
after that public renumbering.

Build scripts should read the public version from the root `VERSION` file rather
than hard-code it in multiple places.


## V69.28

V69.28 fixes an OHCI DMA race exposed by `sqa sys` under QEMU. OHCI list-enable
changes are now synchronized to the next SOF before fixed ED/TD memory is
reused. HcPeriodCurrentED is treated as the controller-owned, read-only status
register defined by OHCI 1.0a. If a safe frame boundary is not observed,
control requests and root-hub rebuilds are deferred without recycling their
descriptors. The periodic watchdog now republishes only the existing live
schedule; it never rebuilds active TD/ED storage on a frame-counter stall.


## V69.27

V69.27 hardens the OHCI USB 1.1 root-port input transport. Endpoint-zero
control TDs are quiesced before reuse and failed requests cannot continue DMA
into the next transaction. Root-port changes now stop and rebuild the periodic
HID schedule, release held input state and re-enumerate connected devices with
non-colliding addresses. A frame-counter watchdog republishes a stalled OHCI
schedule. Idle USB mouse samples no longer displace PS/2, and the initialized
PS/2 mouse device remains registered as the logical fallback after unplug.


## V69.26

V69.26 decouples native USB HID progress from whichever console task is blocked
in `getch()`. A permanent `KUSB-HID` kernel service starts only after the
storage-safe PIT phase has ended and continuously pumps the OHCI transport from
ordinary process context while sleeping between polls. Terminal keyboard FIFO
enqueues now wake the exact foreground consumer with `SchedulerWakeThread()`.
When the worker is alive, SMSH and GraOS no longer perform synchronous OHCI
polls themselves; those paths become automatic recovery fallbacks if the
worker is unavailable. SMSH boot diagnostics now expose worker state, PID and poll
count so a future input stall can be distinguished from an IRQ/scheduler stall.


## V69.25

V69.25 fixes SMSH normal-boot media selection. DOSBOOT-only `ramextract` is now
used only when a valid persistent UTILS.ISO RAM handoff exists. Native boot32
and QEMU boots instead extract from the validated `sys:` bootstrap alias, with
a direct `cdrom` fallback for older media layouts. This prevents a healthy boot
from stopping at `ram:/bin#` merely because no DOSBOOT RAM bank was present.
The V69.24 NMI Guard Dog and GraOS first-frame startup recovery remain intact.


## V69.24

V69.24 hardens the x86 NMI watchdog into a two-stage Guard Dog. The autonomous
watchdog source now explicitly re-enables the PC/AT hardware NMI gate at port
0x70 after vector 2 and the source are ready, fixing the boot-time mask that a
software `INT 2` test could not detect. Fail-stop targets retain the immediate
TF/#DB containment path without forcing IF from NMI context. The KNMI-RESCUE
worker can quarantine and terminate a still-pending AUTOKILL target once normal
process-context scheduling is available. A PID-generation check prevents stale watchdog state from killing a
reused slot, and `nmi watchdog killprobe` provides an end-to-end hard-loop test.


## V69.23

V69.23 completes the keyboard recovery for both supported boot configurations.
The BIOS-preserve PS/2 path now sends the idempotent F4 Enable Scanning command
after repairing the i8042 IRQ1 command byte.  The QEMU OHCI keyboard control
fallback remains available after idle periodic reports and retries temporary
control errors instead of disabling itself permanently.  Periodic TD recycling
now skips the endpoint for one frame before republishing it, and concurrent
keyboard/mouse pollers are serialized.  Invalid HID rollover reports are
rejected before USB can claim logical-keyboard ownership.  Both QEMU launchers
default to USB/OHCI and accept `JTMOS_USB_INPUT=ps2` for an explicit PS/2 test.

The 2026-09-22 GraOS startup hotfix restores the documented normal-boot path:
SMSH launches GraOS after the RAM utilities payload is extracted.  The launcher
serializes competing requests, waits for the launched process to publish its
post-first-frame `guiserver` identity, and only then moves keyboard focus.  A
failed or timed-out launch is torn down and the graphical adapter is returned
to the SMSH text console.  Live-name filtering also prevents a dead GraOS PID
slot from blocking the next launch.


## V69.22

V69.22 restores interactive keyboard input after the APIC transition.  The
BIOS-preserve PS/2 path now non-destructively verifies the i8042 command-byte
IRQ1 enable bit without resetting the keyboard, USB no longer claims logical
keyboard ownership from an all-zero idle report, and QEMU usb-kbd receives a
throttled HID GET_REPORT rescue path when the OHCI periodic interrupt queue has
not yet retired a keyboard TD.  I/O APIC IRQ mask writes are read back and SMSH
prints IRQ1 redirection plus USB report/event diagnostics before waiting for
interactive input.


## V69.21

V69.21 fixes the APIC/ACPI early-boot page fault introduced in V69.20.  The
ACPI RSDP locator no longer dereferences the BIOS Data Area through linear page
zero after JTMOS null-pointer protection has unmapped that page.  BIOS low
memory needed for ACPI discovery is read through JTMOS's persistent 0x10000000
low-memory alias instead.  This preserves the null-page guard while allowing
the standards-defined EBDA pointer at physical 0x40e and the EBDA/BIOS RSDP
search regions to be inspected safely.

## V69 generation

V69.0 starts the JTMOS 69 generation. The major number was increased from 68 to 69 and the minor number was reset to 0. V68.227 is the direct predecessor.


## V69.1

V69.1 is the first minor release in the JTMOS 69 generation. It carries the NMI/watchdog ownership, rescue-publication and PMU/LVTPC shutdown hardening completed after the V69.0 baseline.


## V69.2

V69.2 adds the Linux-style `du` utility (`-c`, `-h`, `-s`, including combined forms such as `-chs`), a GraOS Ctrl+Shift+N shortcut that always spawns a fresh SQSH terminal window, and changes PATH list separation to the Windows-style semicolon (`;`) while preserving `:` exclusively for JTMOS device-qualified paths.


## V69.3

V69.3 accelerates JTMFS directory-heavy workloads with a ReiserFS-style immutable B+tree plus a bounded namespace delta layer. File length and FAT-endpoint updates keep the existing name index, creates use an indexed free-slot cursor, and `getsize`/`stat`-style length queries use logarithmic name lookup while retaining the safe linear fallback.


## V69.4

V69.4 hardens JTMFS overwrite semantics. Existing files opened with `O_TRUNC`
are written through a same-directory staging entry; close first syncs the new
data, atomically publishes its FAT chain over the old dirent, and only then
releases the old chain. The new built-in `jtmfsck` command performs the existing
media-backed consistency scan and adds a conservative `-r` mode that reclaims
only allocation units proven unreachable by a structurally unambiguous scan.


## V69.5

V69.5 completes the next JTMFS performance pass. The cached directory B+tree
keeps a 256-bit monotonic name-presence filter so negative create/open lookups
can bypass the tree, and internal separator selection uses binary search. The
DAPI block cache replaces its 256-entry linear lookup with 512 hash buckets,
adds safe 8-block read-ahead for legacy one-block readers, and sends already
coalesced transfers of 8 or more blocks directly to multiblock-capable devices.
The on-disk JTMFS layout, V69.4 atomic overwrite ordering and jtmfsck rules are
unchanged.


## V69.6

V69.6 makes Ring 3 mandatory for both ELF32 and legacy raw applications. The
legacy 0x80000000 ABI is retained through per-process user page tables, while
kernel mappings remain supervisor-only. The INT 0x7F dispatcher now derives
privilege from the CPU-created caller CS and blocks legacy kernel-control
syscalls from CPL3. Scheduler switch validation rejects application TSS state
with kernel selectors, IOPL/NT/VM bits, invalid user EIP/ESP or an exposed I/O
bitmap. Ordinary application faults continue through process quarantine rather
than system panic, and Ring3 signal/priority and SQSH builtin bridges cannot
terminate/boost kernel services or invoke reset/root/raw-disk administration.

V69.6 final containment hardening:
- legacy Ring3 page publication is bounded to the exact process allocation; it no longer walks into adjacent allocator mappings;
- legacy requests larger than MM_USER_SIZE are rejected;
- application priority/runnable publication is the final loader step after mappings, ownership, selectors and application type are complete.


## V69.7

V69.7 expands the Ring3 ABI so ordinary applications no longer need legacy
Ring0 helpers for normal filesystem, timing or scheduler work. New mediated
syscalls provide `rmdir`, `fsync`, `sync`, `truncate`, `ftruncate`, `access`,
`gettimeofday`, `nanosleep` and `sched_yield`. `SwitchToThread()` now maps to
`sched_yield`, and the compatibility `KillThread()` wrapper maps to the
type/ownership-checked POSIX signal path rather than the privileged raw thread
termination syscall.

The wider API is paired with a syscall-boundary hardening pass: the global FD
table is treated as a per-process capability table by checking FD ownership on
read/write/close/lseek/fstat/fsync/ftruncate, including redirected stdio. Common
pathname syscalls copy NUL-terminated strings through validated user mappings
before entering JTMFS, and stat/date/device-name outputs validate the complete
user destination range. Raw storage, generic devicecall/registration, IDT/PIC
control, kernel allocation and mkfs remain Ring0-only. Copy paths in `cp`, `mv`
and SQSH use Ring3 `fsync`, bwBASIC uses the real mediated `rmdir`, and programs
such as Filer/ircII can use the libc `access` service without a kernel bridge.
V69.7 expands the mediated Ring3 application ABI so ordinary programs no longer
need legacy Ring0 compatibility calls for normal operating-system services. It
adds Ring3-safe rmdir, fsync/sync, truncate/ftruncate, access, gettimeofday,
nanosleep and sched_yield syscalls, hardens global FD slots with per-process
ownership checks, and migrates the legacy SwitchToThread/KillThread libc APIs to
the safe scheduler-yield and POSIX signal paths. Raw block, mkfs, IDT/PIC,
device registration and kernel allocation interfaces remain privileged.


## V69.8

V69.8 removes repeated physical journal scans from the JTMFS V4 pathname hot
path. After the first conservative post-mount/disk-change recovery check, a
RAM-only clean token lets `JtmfsDbRecover()` return without disk I/O while the
existing per-volume mutation-lock ordering is retained. Cold recovery now
addresses the exact circular redo slot derived from the sequence number instead
of linearly scanning every journal slot.

Verified direct journal/superblock writes invalidate only the logical DAPI
cache sector they changed rather than dropping the complete per-device cache.
The HDA/hdaN metadata path also avoids an immediately duplicated post-redo ATA
flush when the preceding WAL/FlexFAT durability barrier already made the state
persistent. The JTMFS on-disk layout and V69.4 atomic-overwrite/jtmfsck rules are
unchanged.


## V69.9

V69.9 restores GraOS startup when boot32 has already installed a valid
640x480x32 recovery framebuffer. The kernel now prepares the protected-mode
VBox/Bochs BGA provider without replacing the visible console, identity-maps the
future 1024x768x32 aperture, and tracks that mapping independently so
`SYS_graosgraphics` can transition GraOS to its native mode.



## V69.18

V69.18 repairs the NMI watchdog against the Intel IA-32 architecture rules.
Performance-monitoring interrupts delivered through the Local APIC automatically
mask LVTPC; the NMI acknowledgement path now clears that mask on every overflow,
so PMU NMIs recur instead of silently stopping after the first event.  Intel
architectural PMU v1 (Core Solo/Core Duo), v2+, and the legacy P6/i686 two-counter
interface are handled separately; the P6 fallback is not used when CPUID.0AH
enumerates an architectural PMU.

The official QEMU runner additionally uses a host-clocked IB700 watchdog with
`-watchdog-action inject-nmi`.  IRQ0 pings that watchdog, so a guest hard loop
or CLI/IF=0 stall causes a real vector-2 injection even when the guest PIT and
scheduler stop making progress.  The internal SMSH `nzip` builtin is moved to
an expendable guarded Ring0 worker.  That worker alone opts into fail-stop NMI
containment; the long-lived SMSH thread remains protected.  A watchdog NMI arms
TF, #DB enters ordinary exception containment, and the bad worker/process is
quarantined/reaped instead of taking the shell and operating system with it.


## V69.17

V69.17 makes the autonomous NMI watchdog fail-stop for ordinary Ring3 applications.
A stalled THREAD_TYPE_APPLICATION no longer needs an opt-in recoverable flag: after
the scheduler/IRQ heartbeat exceeds the watchdog threshold, the owned PMU NMI
suspends the task and arms EFLAGS.TF.  The CPU then raises #DB after at most one
retired instruction even when IF=0, and the normal exception containment path
quarantines/reaps the process.  CPU_IDLE now reports the crash reason visibly, and
boot/status output warns clearly when no PMU->LAPIC NMI source is active.


## V69.16

V69.16 corrects Ring3 syscall resume validation in the scheduler.  A preempted
application may legitimately have a temporary kernel CS/SS/EIP/ESP TSS snapshot
while INT 0x7F is active; that context is accepted only when the syscall depth and
per-process ss0:esp0 kernel-stack bounds prove it is an in-flight syscall.


## V69.15

V69.15 hardens KIdleThread so legacy short sleeps age from PIT ticks even when
CPU_IDLE owns the processor, while preserving an O(1) steady-state idle path.
The HLT burst is shortened to 16 wakeups so idle maintenance runs promptly.
The physical VT0 EGA page at `0xB8000` now has a working top-right disk LED
(green read, red write); the previous macro mismatch that disabled it is fixed.
`hdbench` V2 performs the same strictly read-only benchmark in bounded 1 MiB
kernel calls and displays visible progress. GraOS V56 retains and regression-
checks the animated per-client hourglass/busy cursor introduced in V69.11.


## V69.14

V69.14 adds `hdbench.bin`, a strictly read-only sequential hard-disk benchmark.
Its normal mode measures the active `hda` backend without DAPI cache effects;
`--raw-pio` selects ATA task-file PIO on legacy IDE and NVIDIA MCP61 hardware
and fails explicitly on AHCI-only controllers. A narrow Ring3 service performs
the reads into a kernel-owned discard buffer and returns only timing/progress
metadata, so the privileged raw-block API and disk contents remain unavailable
to applications. The service contains no write or cache-flush operation.


## V69.13

V69.13 / GraOS V56 adds a native Ring3 MP3 Layer III music player and repairs
the MPEG-1 Program Stream video player. Both applications now include a GraOS
file browser, accept a path from the command line, and handle 48 kHz source
audio by resampling it to the 44.1 kHz hardware limit. The MP3 player accepts a
single file or a directory playlist; the MPEG-1 player preserves video aspect
ratio while fitting the desktop.

The Control Panel exposes both players with dedicated music and video icons.
The applications remain in the optional `media.sqa` package on
`utilities.iso`, keeping the compact rescue/system payload unchanged.


## V69.12

V69.12 / GraOS V55 hardens GUI startup against transient graphics-provider
failures. GraOS now retries the protected-mode display takeover, retries a full
frame after re-acquiring the provider, and ignores a stale `guiserver` name
whose process no longer owns memory. The existing LFB mapping guards remain
mandatory, so recovery never permits drawing through an unmapped framebuffer.

## V69.11

V69.11 promotes the GraOS busy cursor into a complete graphical wait-cursor
facility. GraOS V54 draws an animated classic hourglass after a 150 ms delay,
tracks nested busy requests per application, keeps concurrent clients isolated,
and removes dead-client ownership automatically. Filer now uses the public
GraOS busy API while scanning directories and deleting files, so slow JTMFS
operations visibly show progress without freezing or permanently stranding the
cursor.

## V69.10

V69.10 hardens GraOS startup and application failure handling. Graphics takeover
now refuses a prepared NV6150 or VBox/BGA provider unless its framebuffer is
actually mapped. The userspace GraOS runtime validates reply/event sender PIDs,
revalidates the named server while waiting, and discards queued events across a
server restart. GraOS periodically reclaims windows and busy state belonging to
exited Ring3 clients so an application fault does not leave stale GUI resources
or target a recycled PID. Legacy `wintest`, `wintest2` and `wintest3` clients
also gain explicit error handling and clean server-loss exits.

## V69.20

V69.20 introduces an ACPI MADT-driven xAPIC interrupt-controller backend.
Local APIC and I/O APIC become the preferred external IRQ path while the 8259A
remains an automatic compatibility fallback. Existing JTMOS IRQ numbers 0..15
and vectors 0x68..0x77 are preserved, including ACPI Interrupt Source Override
translation from ISA IRQs to GSIs. The 8254 PIT remains the scheduler clock in
this release; its high-resolution rollover logic now reads controller-neutral
IRR/ISR state. SMSH adds `apic [status]` diagnostics. x2APIC, MSI/MSI-X, ACPI
`_PRT` PCI routing and non-legacy I/O-APIC inputs remain future work.
