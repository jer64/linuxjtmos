JTMOS V65 plain-PID + external UNZ launch correction
======================================================
Date: 2026-08-22

Process identifiers
-------------------
The active V65 kernel now uses the thread-table index directly as PID.
UNIPID generation, RPID translation and thread_uniqid storage are not used by
the active kernel path.

valid_pid(pid) is the active range validator.  unif(pid) remains only as a
source-compatibility wrapper for old code.  The historical syscall slot 70 is
kept ABI-compatible as an identity operation so old binaries are not forced to
renumber their syscall table.  New code should use ordinary PIDs.

Launch scheduling
-----------------
centralprocess_createproc() now explicitly yields to the PID returned by
LaunchAppEx() with SwitchToThreadEx(pid) after the new process has received its
command line, terminal and name.  This makes the first execution of a newly
loaded ELF32 program deterministic instead of relying on a later round-robin
scheduler pass.

A pre-existing bug in GetThreadLimit() was also corrected: the routine used an
uninitialized local pid variable after validating its old UNIPID argument.
It now indexes descriptors directly with the validated pid parameter.

UNZ bootstrap
-------------
The V65 release payload is install.img.nz.  The previous no-argument unz path
started with findfirst()/findnext(), but those syscalls are still incomplete in
this kernel.  The standalone unz now does this first:

    unz.bin
      -> print startup marker
      -> open install.img.nz directly when present
      -> nzip decompress to install.img
      -> SQA extract install.img
      -> remove temporary install.img after a successful extraction

The startup marker is:

    unz: JTMOS installer starting

If that line is not visible at runtime, execution did not reach unz main() and
the next diagnostic target is the ELF32/TSS execution path rather than nzip or
SQA parsing.

Compatibility
-------------
GetThreadUniquePID() and SYS_getthreaduniquepid are retained only as deprecated
identity compatibility names.  They do not create or decode unique identifiers.
