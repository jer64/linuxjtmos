#!/bin/sh
set -eu
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
# Linode/headless demo profile. Build the image with `make image-linode` so
# serial_console_redirect=0 and vesa_early_serial_only=0 are compiled in.
# - VGA text/curses console
# - no USB GUI/input overhead
# - no emulated sound card; Linode kernel also omits audio/HDA/SB/GUS drivers
# - HTTP demo visible on host TCP/8080
# - TELNET dev console stays host-local; reach it through an SSH tunnel
export JTMOS_DISPLAY=${JTMOS_DISPLAY:-curses}
export JTMOS_USB_INPUT=${JTMOS_USB_INPUT:-off}
export JTMOS_AUDIO=${JTMOS_AUDIO:-off}
export JTMOS_BOOT_DEBUG_LOG=${JTMOS_BOOT_DEBUG_LOG:-$DIR/boot32pm_debug.log}
export JTMOS_NET_MODE=${JTMOS_NET_MODE:-user}
export JTMOS_HTTP_HOST_ADDR=${JTMOS_HTTP_HOST_ADDR:-0.0.0.0}
export JTMOS_HTTP_HOST_PORT=${JTMOS_HTTP_HOST_PORT:-8080}
export JTMOS_TELNET_HOST_ADDR=${JTMOS_TELNET_HOST_ADDR:-127.0.0.1}
export JTMOS_TELNET_HOST_PORT=${JTMOS_TELNET_HOST_PORT:-2323}

# V16.84: image-linode builds both root media.  For older/incomplete build trees,
# gracefully use whichever root medium exists instead of requiring both.
if [ -z "${JTMOS_ROOT_FLOPPY+x}" ] && [ ! -f "$DIR/root1440.img" ]; then
  export JTMOS_ROOT_FLOPPY=none
fi
if [ -z "${JTMOS_ROOT_CDROM+x}" ] && [ ! -f "$DIR/utilities.iso" ]; then
  export JTMOS_ROOT_CDROM=none
fi
if [ "${JTMOS_ROOT_FLOPPY:-$DIR/root1440.img}" = none ] && \
   [ "${JTMOS_ROOT_CDROM:-$DIR/utilities.iso}" = none ]; then
  echo "JTMOS Linode root media missing. Run: make image-linode" >&2
  exit 1
fi
exec "$DIR/run_jtmos_qemu.sh" "$@"
