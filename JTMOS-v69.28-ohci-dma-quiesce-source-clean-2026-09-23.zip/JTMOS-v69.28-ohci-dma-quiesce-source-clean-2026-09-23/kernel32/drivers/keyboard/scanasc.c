// =========================================================
// scanasc.c - Scan code to character conversion for JTMOS.
// (C) 2002-2026 by Jari Tuominen / JTMOS contributors
// =========================================================
#include "basdef.h"
#include "cpu.h"
#include "io.h"
#include "keyb.h"
#include "sysglvar.h"
#include "ega.h"
#include "int.h"
#include "vga.h"
#include "kernel32.h"
#include "driver_sys.h"
#include "driver_api.h"
#include "ps2mouse.h"
#include "scanasc.h"
#include "keymap.h"

int reset_attempt=0;
static int reset_chord_latched=0;

static int special_key_from_scancode(int mark)
{
    switch(mark)
    {
        case SCODE_ESCAPE: return 27;
        case 0x0f: return '\t';
        case 0x0e: return '\b';
        case SCODE_ENTER:
        case SCODE_KEYPADENTER: return '\n';

        case SCODE_F1: case SCODE_F2: case SCODE_F3: case SCODE_F4:
        case SCODE_F5: case SCODE_F6: case SCODE_F7: case SCODE_F8:
        case SCODE_F9: case SCODE_F10: case SCODE_F11: case SCODE_F12:
            return 0xFF00 + mark;

        /* Extended navigation codes produced by keyb.c. */
        case SCODE_CURSORBLOCKUP: case SCODE_CURSORBLOCKLEFT:
        case SCODE_CURSORBLOCKRIGHT: case SCODE_CURSORBLOCKDOWN:
        case SCODE_INSERT: case SCODE_HOME: case SCODE_PGUP:
        case SCODE_DELETE: case SCODE_END: case SCODE_PGDN:
            return 0xFF00 + mark;

        /* Historical non-E0 keypad/navigation handling retained for
         * compatibility. */
        case SCODE_KEYPAD7: case SCODE_KEYPAD8: case SCODE_KEYPAD9:
        case SCODE_KEYPAD4: case SCODE_KEYPAD6:
        case SCODE_KEYPAD1: case SCODE_KEYPAD2: case SCODE_KEYPAD3:
        case SCODE_KEYPAD0:
            return 0xFF00 + mark;

        case SCODE_SCROLLLOCK:
            return 0xFF00 + mark;
        default:
            return 0;
    }
}

int scan_to_asc(int mark)
{
    int ad;
    int translated;
    int shift;
    int altgr;
    int caps;

repeatcheck:
    /* Preserve the historical keyboard-macro output protocol. */
    if(kbstr.ExtraKey==0xfe)
    {
        kbstr.ExtraKey=0xfd;
        return -2;
    }
    if(kbstr.ExtraKey==0xfd)
    {
        if(!(ad=kbstr.macro[kbstr.i_macro]))
        {
            kbstr.ExtraKey=0;
            goto repeatcheck;
        }
        kbstr.i_macro++;
        return ad;
    }
    if(kbstr.ExtraKey==0xff || kbstr.ExtraKeyCode)
    {
        ad=kbstr.ExtraKeyCode;
        kbstr.ExtraKey=0;
        kbstr.counter=0;
        kbstr.ExtraKeyCode=0;
        return ad;
    }

#ifdef __KEYDEBUG__
    printk("[key 0x"); p8(mark); printk("]");
#endif

    /* Ctrl+Alt+Del remains the explicit reset chord.  Accept both the
     * dedicated E0 Delete key and the keypad Del/. physical key (set-1 0x53),
     * regardless of NumLock state.  Right Ctrl is valid; Right Alt remains
     * AltGr and is deliberately not treated as the reset Alt key. */
    if((kbstr.ktab[SCODE_LEFTCONTROL] || kbstr.ktab[SCODE_RIGHTCONTROL]) &&
       kbstr.ktab[SCODE_LEFTALT] &&
       (kbstr.ktab[SCODE_DELETE] || kbstr.ktab[SCODE_KEYPADDELETE]))
    {
        if(!reset_chord_latched)
        {
            reset_chord_latched=1;
            if(!reset_attempt && Multitasking)
                reboot_now=TRUE;
            else
                system_reset1();
            reset_attempt++;
        }
    }
    else
        reset_chord_latched=0;

    shift = (kbstr.ktab[SCODE_LSHIFT] || kbstr.ktab[SCODE_RSHIFT]) ? 1 : 0;

    /* Desktop/global key chords are encoded before ordinary keymap lookup so
     * userspace GraOS can distinguish them without polling modifier state.
     * Right Alt is deliberately excluded: on Finnish/European layouts it is
     * AltGr and must remain available for printable characters. */
    if(kbstr.ktab[SCODE_LEFTALT] && mark==0x0f)
        return shift ? JKEY_SHIFT_ALT_TAB : JKEY_ALT_TAB;
    if(kbstr.ktab[SCODE_LEFTALT] && mark==SCODE_F4)
        return JKEY_ALT_F4;
    if((kbstr.ktab[SCODE_LEFTCONTROL] || kbstr.ktab[SCODE_RIGHTCONTROL]) &&
       mark==SCODE_ESCAPE)
        return JKEY_START_MENU;
    if((kbstr.ktab[SCODE_LEFTCONTROL] || kbstr.ktab[SCODE_RIGHTCONTROL]) &&
       shift && mark==SCODE_N)
        return JKEY_CTRL_SHIFT_N;

    /* Encode Windows-key chords before the ordinary keymap.  A plain Win
     * press is emitted on key release by keyb.c, so Win+R and friends do not
     * flash the Start menu first. */
    if(kbstr.ktab[SCODE_LWIN] || kbstr.ktab[SCODE_RWIN]) {
        if(mark==SCODE_R) return JKEY_WIN_R;
        if(mark==SCODE_E) return JKEY_WIN_E;
        if(mark==SCODE_M) return shift ? JKEY_SHIFT_WIN_M : JKEY_WIN_M;
        if(mark==SCODE_D) return JKEY_WIN_D;
        if(mark==SCODE_X) return JKEY_WIN_X;
        if(mark==0x0f) return shift ? JKEY_SHIFT_WIN_TAB : JKEY_WIN_TAB;
        if(mark==SCODE_LWIN || mark==SCODE_RWIN) return 0;
    }
    /* Plain Tab is ASCII 9, but Shift+Tab needs a distinct value so GraOS
     * can traverse focus backwards after modifier state has left the driver. */
    if(mark==0x0f && shift) return 0x0f00;
    altgr = kbstr.ktab[SCODE_RIGHTALT] ? 1 : 0;
    caps = (kbstr.led_status & LED_CAPS_LOCK) ? 1 : 0;

    translated=KeyboardTranslateScancode(KeyboardGetLayout(),mark,
                                         shift,altgr,caps);
    if(translated!=KEYMAP_UNMAPPED)
        return translated;

    return special_key_from_scancode(mark);
}
