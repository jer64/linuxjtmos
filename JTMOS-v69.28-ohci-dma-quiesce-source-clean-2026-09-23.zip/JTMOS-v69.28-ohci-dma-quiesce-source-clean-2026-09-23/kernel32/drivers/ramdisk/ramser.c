////////////////////////////////////////////////////////////////////////////////////////////
// ramser.c
// RAM disk driver service.
// (C) 2004 by Jari Tuominen.
////////////////////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <jtmos/dcpacket.h>
#include "ramdisk.h"
#include "ramser.h"
#include "fs/api.h"

//
static char ramser_started=FALSE;

//////////////////////////////////////////////////////////////////////////////////
//
// DRIVER MAIN INIT
//
void ramDriverInit(void)
{
	//
	static THREAD RAMThread;

        //
	ramser_started=FALSE;
        if(ThreadCreateStack(&RAMThread,JTMOS_MIN_DYNAMIC_STACK)!=0)
        { printk("KRAMDISK: stack allocation failed.\n"); return; }
        RAMThread.pid=create_thread(RAMThread.stack,RAMThread.l_stack,ramDriverMain);
        if(RAMThread.pid<=0)
        { ThreadDestroyStack(&RAMThread); printk("KRAMDISK: thread creation failed.\n"); return; }
        IdentifyThread(RAMThread.pid,"KRAMDISK");

	//
	if( driver_TestDevice(ND("ram")) )
		dprintk("device ram registration failure\n");
	else
	{
		//
		chdir("/ram");
		mkfs("");
	}

	//
}

/* Historical DEVICE_CALL_PARS declaration lives in driver_dcpacket.h. */
//
int ramDeviceCall(
        DCPACKET *dc JTM_UNUSED,
        int clientPID JTM_UNUSED, int n_call,
        int p1,int p2,int p3,int p4,
        void *po1,void *po2)
{
	//
	return rdDevCall(n_call,p1,p2,p3,p4,po1,po2);
}

//
// int ramDeviceCall(int n_call,
//        int p1,int p2,int p3,int p4,
//        void *po1,void *po2)

// Init hard disk service
void ramServiceInit(void)
{
	// Start message box
	startMessageBox();

	//
	rd_createdefaultramdisk();

	// Found RAM disk:

	// Register device
	registerNewDevice("ram",
		NULL,0,
		GetCurrentThread(), DEVICE_TYPE_NONKERNELDRV,
		0);
}

// Hard disk service main
void ramServiceMain(void)
{
	static MSG m;
	DCPACKET *dc;
	int x,rval;
	int t JTM_UNUSED,lt JTM_UNUSED;
	DWORD ad1 JTM_UNUSED,ad2 JTM_UNUSED;

	//--------------------------------------------------
	// Get DCPACKET PTR
	dc = (DCPACKET *)m.buf;

	//--------------------------------------------------
	// Loop
	//
	for(lt=GetSeconds(); ;)
	{
		//--------------------------------------------------
		// Probe for packet
		//
		if( receiveMessage(&m) )
		{
			// Report
			if(devser_debug)
				DumpDC(dc, __FUNCTION__);

			//----------------------------------------------------------
			// Message received
			rval = ramDeviceCall(
				dc, m.sndPID,
				dc->n_function,
				dc->par1,dc->par2,dc->par3,dc->par4,
				dc->p1,dc->p2);

			// Store return value
			globalcopy(GetCurrentThread(), JTM_PTR_TO_DWORD(&rval),
				m.sndPID, JTM_PTR_TO_DWORD(dc->rval),
				4);

			// Flag as completed
			x = TRUE;
			globalcopy(GetCurrentThread(),JTM_PTR_TO_DWORD(&x),
				m.sndPID,JTM_PTR_TO_DWORD(dc->done),
				4);

			// Go back to client
			SwitchToThreadEx(m.sndPID);
			continue;
		}

		//--------------------------------------------------
		// Schedule
		//
		SwitchToThread();
	}
}

// End hard disk service
void ramServiceEnd(void)
{
	//
}

//////////////////////////////////////////////////////////////////////////////////
// Start ram disk driver
void ramDriverMain(void)
{
	BYTE *p;

	//
	if( getdevicenrbyname("ram")>0 )
	{
		//
		printf("RAM disk driver is already installed.\n");
		return;
	}

	// Test malloc
	p = malloc(1024*64);
	if(p==NULL)
	{
		//
		printf("Malloc isn't working, returns NULL pointer.\n");
		return;
	}
	free(p);

	//
	printf("RAM disk driver 1.0\n");
	printf("(C) 2001-2004 by Jari Tuominen\n");
	ramServiceInit();
	ramser_started = TRUE;
	ramServiceMain();
	ramServiceEnd();
	return;
}

//


