#ifndef __INCLUDED_VBOXBGA_H__
#define __INCLUDED_VBOXBGA_H__

/*
 * VirtualBox/Bochs Graphics Adapter (BGA) support.
 *
 * This is a deliberately small protected-mode mode-setting driver for the
 * legacy VirtualBox VBoxVGA/BGA-compatible interface and the compatible
 * Bochs/QEMU DISPI interface at I/O ports 0x01CE/0x01CF.
 */

#define VBOX_BGA_GRAOS_WIDTH   1024
#define VBOX_BGA_GRAOS_HEIGHT  768
#define VBOX_BGA_FALLBACK_WIDTH  640
#define VBOX_BGA_FALLBACK_HEIGHT 480
#define VBOX_BGA_GRAOS_BPP     32

extern int vbox_bga_active;
extern int vbox_bga_prepared;
extern WORD vbox_bga_id;
extern DWORD vbox_bga_lfb_phys;

int VBoxBgaProbe(void);
int VBoxBgaPrepareGraOS(void);
int VBoxBgaSetMode(int width, int height, int bpp);
int VBoxBgaSetupGraOS(void);
int VBoxBgaIsActive(void);
int VBoxBgaIsPrepared(void);
DWORD VBoxBgaGetFramebufferPhysical(void);
DWORD VBoxBgaGetFramebufferBytes(void);
int VBoxBgaFramebufferMapped(void);
void VBoxBgaSetFramebufferMapped(int mapped);

#endif
