//==================================================================
// PS/2 mouse driver for JTMOS.
//
// (C) 2002-2008,2017 by Jari Tuominen(jari.t.tuominen@gmail.com).
//
// It might sound alittle odd, but both PS/2 mouse and keyboard
// work through the INTEL 8042 keyboard controller.
// This is why we also program/read mouse via the controller.
//
// -- PORTS --------------------------------------------------
// 0x60 8042 Keyboard input/output buffer register
// 0x61 8042 system control port (for compatibility with 8255)
// 0x64 8042 keyboard command/status register
//
// Note: keyboard and PS/2 mouse use same I/O system.
//==================================================================
/*
 * Supports graphic modes: 640x480x2		(0x11)
 *                         80x25 textmode	(0x03)
 *
 * Support means arrow displaying for the specified mode,
 * in future perhaps more.
 *
 * User should call ps2mouse_modechange function to give
 * new parameters for the mouse driver to work with,
 * like f.e. screen metrics(width,height,bpp).
 *
 * UPDATE:
 * The PS/2 mouse driver seems to be somewhat working now.
 * Still needs some testing to make sure.
 */

// #define __PS2MOUSEKVIIK__
#include "basdef.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "ega.h"
#include "syssh.h"
#include "io.h"
#include "floppy.h"
#include "dma.h"
#include "cpu.h"
#include "mouse.h"
#include "ps2mouse.h"
#include "input_policy.h"
#include "kernel32.h"
#include "dispadmin.h"
#include "sysgfx.h"
#include "driver_sys.h"
#include "delay.h"
#include "vesa.h"
#include "vga.h"

//#define PS2MOUSE_DEBUG_PORTWRITE
//
int ps2mouse_enabled=0;
int ps2mouse_counter=0,ps2mouse_first_time,
	PS2MOUSE_TEST_OK=0;
volatile DWORD ps2mouse_irq_count=0;
volatile DWORD ps2mouse_byte_count=0;
volatile DWORD ps2mouse_packet_count=0;
volatile int ps2mouse_stream_status=-1;
static BYTE ps2mouse_packet[4];
static int ps2mouse_packet_pos=0;
static int ps2mouse_packet_size=3;
static int ps2mouse_device_id=0;
static DWORD ps2mouse_poll_calls=0;
static DWORD ps2mouse_remote_poll_count=0;

#define PS2_ACK                     0xFA
#define PS2_RESEND                  0xFE
#define PS2_CMD_DISABLE_REPORTING   0xF5
#define PS2_CMD_ENABLE_REPORTING    0xF4
#define PS2_CMD_GET_ID              0xF2
#define PS2_CMD_SET_STREAM          0xEA
#define PS2_CMD_REQUEST_PACKET      0xEB
#define PS2_CMD_SET_DEFAULTS        0xF6
#define PS2_CMD_RESET               0xFF

#define I8042_CMD_READ_CBYTE        0x20
#define I8042_CMD_WRITE_CBYTE       0x60
#define I8042_CMD_ENABLE_AUX        0xA8
#define I8042_CMD_TEST_AUX          0xA9
#define I8042_CMD_DISABLE_KBD       0xAD
#define I8042_CMD_ENABLE_KBD        0xAE
#define I8042_CMD_WRITE_AUX         0xD4
#define I8042_CBYTE_IRQ12           0x02
#define I8042_CBYTE_AUX_DISABLED    0x20
#define I8042_SPIN_LIMIT            200000UL
/* Preserve the BIOS/POST PS/2 state during normal boot.  Active controller
 * and device programming is diagnostic/manual only. */
#define PS2MOUSE_BIOS_PRESERVE      1

static void ps2mouse_process_packet(const BYTE *pkt);
static void ps2mouse_feed_stream_byte(BYTE data);

//
void ps2mouse_delay(void)
{
	unsigned long i;
	for(i=0;i<256;i++) inportb(0x80);
}

/* 8042 writes must wait for IBF to become clear. Never read port 0x60 merely
 * to make room for a write: doing that steals keyboard or AUX bytes. */
static int i8042_wait_input_empty(void)
{
	unsigned long i;
	for(i=0;i<I8042_SPIN_LIMIT;i++)
	{
		if(!(inportb(0x64)&KBD_STAT_IBF)) return 0;
		inportb(0x80);
	}
	return 1;
}

static int i8042_wait_aux_byte(BYTE *value)
{
	unsigned long i;
	BYTE status;
	for(i=0;i<I8042_SPIN_LIMIT;i++)
	{
		status=inportb(0x64);
		if(status&KBD_STAT_OBF)
		{
            BYTE data=inportb(0x60);
            if(!(status&KBD_STAT_MOUSE_OBF))
            {
                /* CPU interrupts are disabled during command traffic. Route a
                 * coincident keyboard byte through IRQ1's normal decoder and
                 * continue waiting for the AUX reply. */
                keyb_receive_ps2_byte(data);
                continue;
            }
			*value=data;
			return 0;
		}
		inportb(0x80);
	}
	return 1;
}

int ps2mouse_kbwrite(int value)
{
	if(i8042_wait_input_empty()) return 1;
	outportb(0x60,value);
	ps2mouse_delay();
	return 0;
}

// non-zero will be an error
int ps2mouse_kbcmd(int cmd)
{
	if(i8042_wait_input_empty()) return 1;
	outportb(0x64,cmd);
	ps2mouse_delay();
	return 0;
}

// Note: to see what does 'DEVICE_CALL_PARS' mean,
// check driver_api.h.
//
int ps2mouse_device_call(DEVICE_CALL_PARS)
{
	//
	switch(n_call)
	{
		//
		case DEVICE_CMD_INIT:
		break;	

		//
		default:
		break;
	}
	return 0;
}

// Registers device 'ps2mouse'. Returns its DNR or a negative error.
int ps2mouse_register_device(void)
{
	int dnr;

	/* Registration means that the kernel PS/2 driver is active.  Hardware
	 * stream setup is a separate step and may fail without removing the driver
	 * from DEVDB; this makes lsdev useful for diagnostics. */
	dnr=driver_getdevicenrbyname("ps2mouse");
	if(dnr>=0)
		return dnr;

	dnr=driver_register_new_device("ps2mouse",
					ps2mouse_device_call,DEVICE_TYPE_CHAR);
	if(dnr<0)
		printk("PS/2 mouse: DEVDB registration failed (%d).\n",dnr);
	return dnr;
}

/* Drain already queued AUX movement bytes before starting a synchronous
 * command exchange.  They are fed through the normal packet assembler rather
 * than mistaken for the command ACK.  Keyboard output is never consumed. */
static void ps2mouse_drain_pending_stream(void)
{
	unsigned long i;
	BYTE status,data;

	for(i=0;i<64;i++)
	{
		status=inportb(0x64);
		if(!(status&KBD_STAT_OBF)) return;
		if(!(status&KBD_STAT_MOUSE_OBF)) return;
		data=inportb(0x60);
		ps2mouse_byte_count++;
		ps2mouse_feed_stream_byte(data);
	}
}

/* Empty the controller output register before a controller command that
 * returns a byte.  This is done only during one-time PS/2 attach while IRQ1
 * and IRQ12 cannot race us.  AUX bytes are still fed to the packet assembler;
 * keyboard bytes are routed through the normal keyboard decoder rather than
 * being mistaken for the controller command-byte response. */
static int i8042_flush_output(void)
{
    int n=0;
    BYTE status,data;

    while(n<64)
    {
        status=inportb(0x64);
        if(!(status&KBD_STAT_OBF))
            break;
        data=inportb(0x60);
        if(status&KBD_STAT_MOUSE_OBF)
        {
            ps2mouse_byte_count++;
            ps2mouse_feed_stream_byte(data);
        }
        else
            keyb_receive_ps2_byte(data);
        n++;
    }
    return n;
}

/* Read/modify/write the i8042 controller command byte instead of replacing it
 * with a hard-coded value.  Replacing the whole byte was the historical JTMOS
 * bug: it could alter firmware-owned keyboard/controller policy while trying
 * to enable IRQ12. */
static int i8042_read_command_byte(BYTE *value)
{
    unsigned long i;
    BYTE status;

    if(value==NULL) return 1;
    i8042_flush_output();
    if(i8042_wait_input_empty()) return 2;
    outportb(0x64,I8042_CMD_READ_CBYTE);

    for(i=0;i<I8042_SPIN_LIMIT;i++)
    {
        status=inportb(0x64);
        if(status&KBD_STAT_OBF)
        {
            *value=inportb(0x60);
            return 0;
        }
        inportb(0x80);
    }
    return 3;
}

static int i8042_write_command_byte(BYTE value)
{
    if(i8042_wait_input_empty()) return 1;
    outportb(0x64,I8042_CMD_WRITE_CBYTE);
    if(i8042_wait_input_empty()) return 2;
    outportb(0x60,value);
    ps2mouse_delay();
    return 0;
}

// Send one byte to the AUX device and synchronously consume its ACK.
static int ps2mouse_send_byte(BYTE value)
{
	int tries;
	BYTE reply;

	for(tries=0;tries<3;tries++)
	{
		ps2mouse_drain_pending_stream();
		if(ps2mouse_kbcmd(I8042_CMD_WRITE_AUX)) return 1;
		if(ps2mouse_kbwrite(value)) return 2;
		if(i8042_wait_aux_byte(&reply)) return 3;
		if(reply==PS2_ACK) return 0;
		if(reply!=PS2_RESEND) return 4;
	}
	return 5;
}

/* If value!=-1 both bytes are AUX-device bytes, so both require a 0xD4
 * prefix and their own ACK. The historical code sent the second byte directly
 * to port 0x60, which addresses the keyboard rather than the mouse. */
int ps2mouse_writemouse(BYTE mousecmd, long value)
{
	int rv;
#ifdef PS2MOUSE_DEBUG_PORTWRITE
	printk("Write mouse(%x,%x); ",mousecmd,value);
#endif
	rv=ps2mouse_send_byte(mousecmd);
	if(rv) return rv;
	if(value!=-1)
	{
		rv=ps2mouse_send_byte((BYTE)value);
		if(rv) return rv;
	}
#ifdef PS2MOUSE_DEBUG_PORTWRITE
	printk("Done.\n");
#endif
	return 0;
}

/* Boot-time AUX command helper.  Some BIOS USB-legacy implementations route
 * mouse replies through the i8042 data port but fail to mark status bit 5.
 * During attach we temporarily disable the keyboard interface, so accepting
 * an untagged OBF byte is safe and makes the driver work with those bridges. */
static int i8042_wait_mouse_reply(BYTE *value,int accept_untagged)
{
    unsigned long i;
    BYTE status,data;

    if(value==NULL) return 1;
    for(i=0;i<I8042_SPIN_LIMIT;i++)
    {
        status=inportb(0x64);
        if(status&KBD_STAT_OBF)
        {
            data=inportb(0x60);
            if((status&KBD_STAT_MOUSE_OBF) || accept_untagged)
            {
                *value=data;
                return 0;
            }
            keyb_receive_ps2_byte(data);
        }
        inportb(0x80);
    }
    return 2;
}

static int ps2mouse_send_byte_attach(BYTE value)
{
    int tries,n;
    BYTE reply;

    for(tries=0;tries<3;tries++)
    {
        if(ps2mouse_kbcmd(I8042_CMD_WRITE_AUX)) return 1;
        if(ps2mouse_kbwrite(value)) return 2;

        /* A stream byte can already be queued ahead of the command ACK.  Do
         * not mistake it for a protocol failure; feed it to the packet parser
         * and keep waiting for FA/FE. */
        for(n=0;n<8;n++)
        {
            if(i8042_wait_mouse_reply(&reply,1)) return 3;
            if(reply==PS2_ACK) return 0;
            if(reply==PS2_RESEND) break;
            ps2mouse_byte_count++;
            ps2mouse_feed_stream_byte(reply);
        }
    }
    return 5;
}

static int ps2mouse_reset_attach(void)
{
    unsigned long i;
    BYTE reply;
    int rv;

    rv=ps2mouse_send_byte_attach(PS2_CMD_RESET);
    if(rv) return rv;

    /* Reset reply after ACK is BAT 0xAA and commonly a device id 0x00. */
    for(i=0;i<4;i++)
    {
        if(i8042_wait_mouse_reply(&reply,1)) return 6;
        if(reply==0xAA) return 0;
        if(reply==0xFC || reply==0xFD) return 7;
    }
    return 8;
}

//
int kbread1(void)
{
	BYTE status=inportb(0x64);
	if(!(status&KBD_STAT_OBF)) return -1;
	if(!(status&KBD_STAT_MOUSE_OBF)) return -1;
	return inportb(0x60);
}

//
void ps2mouse_drawgraphicalarrow(int t_x,int t_y)
{
	int x,y,i,i2 JTM_UNUSED,i3 JTM_UNUSED,i4 JTM_UNUSED;

	//
	for(y=0,i=0; y<32; y++)
	{
		//
		for(x=0; x<32; x++,i++)
		{
			//
			if(mouse_arrow[i]==mcga_color_to_rgba(206))
			            vga_xorpixel_m11(x+t_x,y+t_y);
			else
			if(mouse_arrow[i]==mcga_color_to_rgba(0))
			{
				if( (x+y)&1 )
				vga_xorpixel_m11(x+t_x,y+t_y);
		 	}
		}
		//
	}
}

//
void ps2mouse_drawarrow(void)
{
	int ad,ad2 JTM_UNUSED,ad3 JTM_UNUSED,ad4 JTM_UNUSED,i JTM_UNUSED,i2 JTM_UNUSED,i3 JTM_UNUSED,i4 JTM_UNUSED;

	//
	if( !mouse_isVisible() )return;

	/* GraOS owns cursor composition in a VESA linear framebuffer.  Once a
	 * caller has selected pixel coordinates (>80x25), never feed those pixel
	 * coordinates to the historical EGA/B8000 cursor renderer.  The old code
	 * could calculate offsets such as y*80+x with x=319,y=239 and write far
	 * beyond the 4000-byte VGA text screen.  Kernel mouse coordinates must
	 * continue to update, but cursor drawing is userspace's responsibility. */
	if(VesaGraOSReady() &&
	   (mouse.frame.x2 >= 80 || mouse.frame.y2 >= 25))
		return;

	// Don't redraw it if the location hasn't changed.
	// (This shouldn't be done if the arrow is animated,
	//  which is not yet a supported feature.)
	if(mouse.x == mouse.lx
		&&
	    mouse.y == mouse.ly)
	{
		return;
	}

	//
	/* The VESA 80x25 mirror is logically text mode even though the physical
	 * adapter is already in VBE 0x101.  Reuse the original EGA cursor code. */
	switch(vesa_text_console_enabled ? 3 : dispadmin_getcurrentmode())
	{
		// 80x25
		case 3:
		/* A text cursor is valid only inside the 80x25 cell grid. */
		if(mouse.x<0 || mouse.x>=80 || mouse.y<0 || mouse.y>=25)
			return;
		if(!ps2mouse_first_time &&
		   mouse.lx>=0 && mouse.lx<80 && mouse.ly>=0 && mouse.ly<25)
		{
			ad=mouse.ly*80+mouse.lx;
			storemark(mouse.ch,((ad)<<1)+1 );
		} 

		//
		ad=mouse.y*80+mouse.x;
		mouse.ch=getmark( (ad<<1)+1 );
		storemark( (( getmark((ad<<1)+1) &0x0f)|0x40)^PS2MOUSE_XORCOLOR, (ad<<1)+1 );
		break;

		// 640x480
		case 0x11:
		if(!ps2mouse_first_time)
		{
			ps2mouse_drawgraphicalarrow(mouse.lx,mouse.ly);
		}
		ps2mouse_drawgraphicalarrow(mouse.x,mouse.y);
		break;

		//
		default:
		break;
	}
}

/*
 PS/2 IRQ HANDLER (IRQ #12)

 The standard PS72 mouse sends movement
 (and button) information to th the host
 using following 3-byte packet

 BYTE1:
 	Bit7		Bit6		Bit5		Bit4		Bit3		Bit2		Bit0
	Y overflow	X overflow	Y sign bit	X sign bit	Middle Btn	Right Btn	Left Btn

 BYTE2:
	X Movement

 BYTE3:
	Y Movement


 */
static void ps2mouse_process_packet(const BYTE *pkt)
{
    /* Keep draining the AUX stream even when USB owns the logical mouse, but
     * never let the lower-priority PS/2 source overwrite USB cursor/buttons. */
    if(!input_policy_mouse_event(INPUT_BACKEND_PS2)) return;
	int dx,dy;

	ps2mouse_packet_count++;

	/* Bit 3 is always one in the first byte of a standard PS/2 packet. */
	if(!(pkt[0]&0x08)) return;

	mouse.buttons=pkt[0]&0x07;
    /* IntelliMouse Explorer ID 4 carries buttons 4/5 in byte four.  Existing
     * JTMOS callers still see the original low three button bits unchanged. */
    if(ps2mouse_packet_size==4 && ps2mouse_device_id==4)
    {
        if(pkt[3]&0x10) mouse.buttons|=0x08;
        if(pkt[3]&0x20) mouse.buttons|=0x10;
    }
	dx=pkt[1];
	dy=pkt[2];
	if(pkt[0]&0x10) dx-=256;
	if(pkt[0]&0x20) dy-=256;

	/* Ignore saturated movement while still accepting button state. */
	if(pkt[0]&0x40) dx=0;
	if(pkt[0]&0x80) dy=0;

	mouse.mx=(char)dx;
	mouse.my=(char)dy;
	mouse.lx=mouse.x;
	mouse.ly=mouse.y;
	mouse.x+=dx;
	mouse.y-=dy;

	if(mouse.x<=mouse.frame.x1) mouse.x=mouse.frame.x1;
	if(mouse.x>=mouse.frame.x2) mouse.x=mouse.frame.x2;
	if(mouse.y<=mouse.frame.y1) mouse.y=mouse.frame.y1;
	if(mouse.y>=mouse.frame.y2) mouse.y=mouse.frame.y2;

	if(mouse.isVisible) ps2mouse_drawarrow();
	ps2mouse_first_time=0;
}

static void ps2mouse_feed_stream_byte(BYTE data)
{
	/* ACK/RESEND are command replies only while looking for the first packet
	 * byte.  Bytes 2/3 are signed deltas and may legally be 0xFA or 0xFE. */
	if(ps2mouse_packet_pos==0 && (data==PS2_ACK || data==PS2_RESEND)) return;

	if(ps2mouse_packet_pos==0 && !(data&0x08))
		return;

	ps2mouse_packet[ps2mouse_packet_pos++]=data;
	if(ps2mouse_packet_pos>=ps2mouse_packet_size)
	{
		ps2mouse_process_packet(ps2mouse_packet);
		ps2mouse_packet_pos=0;
	}
}

/* Shared i8042 receive hook used when an AUX byte is delivered through the
 * keyboard IRQ path on BIOS/USB-legacy hardware. */
void ps2mouse_receive_byte(BYTE data)
{
    if(!ps2mouse_enabled) return;
    ps2mouse_byte_count++;
    ps2mouse_feed_stream_byte(data);
}

/* Request one complete packet synchronously.  This is a low-rate fallback for
 * machines/emulators where the AUX output exists but IRQ12 never arrives.  It
 * is intentionally not the primary receive path. */
static int JTM_UNUSED ps2mouse_request_packet(void)
{
    int flags,rv,i;
    BYTE pkt[4];

    flags=get_eflags();
    disable();
    disable_irq(1);
    disable_irq(12);

    /* A missing IRQ12 often means BIOS/USB-legacy forwarding rather than a
     * dead pointing device.  Silence the keyboard clock so a synchronous AUX
     * Read Data exchange may safely accept OBF bytes even when status bit 5 is
     * not implemented by the legacy bridge. */
    (void)ps2mouse_kbcmd(I8042_CMD_DISABLE_KBD);
    rv=ps2mouse_send_byte_attach(PS2_CMD_REQUEST_PACKET);
    if(rv) goto done;

    for(i=0;i<ps2mouse_packet_size;i++)
    {
        rv=i8042_wait_mouse_reply(&pkt[i],1);
        if(rv) goto done;
        ps2mouse_byte_count++;
    }
    if(!(pkt[0]&0x08))
    {
        rv=9;
        goto done;
    }
    ps2mouse_process_packet(pkt);
    ps2mouse_remote_poll_count++;
    rv=0;

done:
    ps2mouse_packet_pos=0;
    (void)ps2mouse_kbcmd(I8042_CMD_ENABLE_KBD);
    enable_irq(1);
    enable_irq(12);
    set_eflags(flags);
    return rv;
}

/*
 * Non-blocking AUX fallback used by the mouse input syscall.  Normally IRQ12
 * consumes movement packets first.  If an AUX byte is still pending, drain a
 * bounded number of bytes with interrupts disabled so the packet assembler
 * cannot race the IRQ handler.  Keyboard bytes are deliberately left in the
 * 8042 output register for IRQ1.
 */
int ps2mouse_poll(void)
{
    int flags,processed=0;
    BYTE status,data;

    if(!ps2mouse_enabled)
        return 0;

    flags=get_eflags();
    disable();
    while(processed<24)
    {
        status=inportb(0x64);
        if(!(status&KBD_STAT_OBF))
            break;
        if(!(status&KBD_STAT_MOUSE_OBF))
            break;
        data=inportb(0x60);
        ps2mouse_byte_count++;
        ps2mouse_feed_stream_byte(data);
        processed++;
    }
    set_eflags(flags);

    /* If IRQ12 has never fired, ask the mouse for one packet occasionally.
     * This preserves a usable pointing device even on firmware/VM setups that
     * do not deliver the slave-PIC interrupt.  Streaming remains preferred. */
    ps2mouse_poll_calls++;
#if !PS2MOUSE_BIOS_PRESERVE
    if(processed==0 && ps2mouse_irq_count==0 &&
       (ps2mouse_poll_calls&31UL)==0)
    {
        if(ps2mouse_request_packet()==0)
            processed=ps2mouse_packet_size;
    }
#endif
    return processed;
}

void ps2mouse_irqhandler12(void)
{
	BYTE status,data;

	PS2MOUSE_TEST_OK=1;
	ps2mouse_irq_count++;
	status=inportb(0x64);

	/* IRQ12 identifies the second/AUX PS/2 port.  As with IRQ1, consume one
	 * pending output byte rather than making delivery depend on status bit 5;
	 * source disambiguation by status is needed for polling, not for an IRQ
	 * that is already tied to the AUX channel. */
	if(status&KBD_STAT_OBF)
	{
		data=inportb(0x60);
        if(status&KBD_STAT_MOUSE_OBF)
        {
            ps2mouse_byte_count++;
            ps2mouse_feed_stream_byte(data);
        }
        else
            keyb_receive_ps2_byte(data);
	}

	/* IRQ12 is on the slave PIC: acknowledge slave first, then master. */
	pic_send_eoi(12);
}

//
static void ps2mouse_install_irq_gate(void)
{
    setint(S_VEC+(12-8),ps2mouse_asmirqhandler12,SEG_CODE32,0x8e00);
}

void ps2mouse_setupirqs(void)
{
    int flags;
    flags=get_eflags();
    disable();
    ps2mouse_install_irq_gate();
    enable_irq(12);
    set_eflags(flags);
}

// SET MOUSE UPDATE RATE
// returns back the rate if succesful
int ps2mouse_setrate(BYTE rate)
{
	int flags,rv;
	flags=get_eflags(); disable();
	rv=ps2mouse_writemouse(0xF3,rate);
	set_eflags(flags);
	if(rv) return -1;
	mouse.rate=rate;
	return rate;
}

/*
	Valid values for ps2mouse_setresolution
	0x00	1 count/mm
	0x01	2 count/mm
	0x02	4 count/mm
	0x03	8 count/mm
 */
// SET MOUSE RESOLUTION
// returns zero on success
int ps2mouse_setresolution(int value)
{
	int flags,rv;
	flags=get_eflags(); disable();
	rv=ps2mouse_writemouse(0xE8,value);
	set_eflags(flags);
	if(rv) return 1;
	mouse.resolution=value;
	return 0;
}

/*
 * Robust i8042/PS2 attach sequence for real hardware and BIOS USB legacy.
 *
 * Do not make optional protocol commands (F5/F2/EA) prerequisites for mouse
 * input.  Several legacy bridges implement only the essential classic PS/2
 * command subset.  The minimum contract is: enable AUX, enable IRQ12, set
 * defaults if accepted, and always attempt F4 Enable Data Reporting.  If F4
 * fails, reset the device once and retry.  During the synchronous exchange
 * the keyboard interface is disabled so untagged legacy replies on port 0x60
 * cannot be confused with keyboard scan codes.
 */
int ps2mouse_hardwareinit(void)
{
    /* Never reprogram the lower-priority AUX device after native USB has
     * claimed the single logical mouse. */
    if(input_policy_mouse_backend()==INPUT_BACKEND_USB)
        return 90;
    int flags,rv=0,cmdrv,reset_rv;
    BYTE oldcb=0,newcb=0,test=0;
    unsigned long i;

    flags=get_eflags();
    disable();

    /* Both i8042 children share port 0x60.  Mask their PIC lines and stop the
     * keyboard clock while the AUX device replies synchronously. */
    disable_irq(1);
    disable_irq(12);
    ps2mouse_install_irq_gate();
    ps2mouse_packet_pos=0;
    ps2mouse_packet_size=3;
    ps2mouse_device_id=0;

    (void)ps2mouse_kbcmd(I8042_CMD_DISABLE_KBD);
    i8042_flush_output();

    if(ps2mouse_kbcmd(I8042_CMD_ENABLE_AUX))
    {
        rv=1;
        goto done;
    }

    /* Command-byte RMW is preferred but not fatal on USB-legacy emulators
     * that implement device forwarding without a fully readable 8042 CByte. */
    if(i8042_read_command_byte(&oldcb)==0)
    {
        newcb=(BYTE)((oldcb|I8042_CBYTE_IRQ12)&~I8042_CBYTE_AUX_DISABLED);
        if(newcb!=oldcb && i8042_write_command_byte(newcb))
            printk("PS/2 mouse: warning: i8042 command-byte write failed; continuing.\n");
        else
            keyb_controller_byte=newcb;
    }
    else
        printk("PS/2 mouse: warning: i8042 command-byte read failed; trying AUX commands anyway.\n");

    /* Second-port test is useful on real 8042 hardware but is advisory only. */
    if(ps2mouse_kbcmd(I8042_CMD_TEST_AUX)==0)
    {
        for(i=0;i<I8042_SPIN_LIMIT;i++)
        {
            if(inportb(0x64)&KBD_STAT_OBF)
            {
                test=inportb(0x60);
                if(test!=0)
                    printk("PS/2 mouse: AUX port test returned %x; continuing.\n",(unsigned int)test);
                break;
            }
            inportb(0x80);
        }
    }

    /* F6 is widely supported and returns the device to classic 3-byte packet
     * defaults.  It is optional; F4 is the only command whose failure means
     * streaming could not be established. */
    cmdrv=ps2mouse_send_byte_attach(PS2_CMD_SET_DEFAULTS);
    if(cmdrv)
        printk("PS/2 mouse: Set Defaults (F6) warning %d.\n",cmdrv);

    cmdrv=ps2mouse_send_byte_attach(PS2_CMD_ENABLE_REPORTING);
    if(cmdrv)
    {
        printk("PS/2 mouse: Enable Reporting (F4) warning %d; resetting device once.\n",cmdrv);
        reset_rv=ps2mouse_reset_attach();
        if(reset_rv)
            printk("PS/2 mouse: reset/BAT warning %d.\n",reset_rv);
        (void)ps2mouse_send_byte_attach(PS2_CMD_SET_DEFAULTS);
        cmdrv=ps2mouse_send_byte_attach(PS2_CMD_ENABLE_REPORTING);
        if(cmdrv)
        {
            rv=6;
            goto done;
        }
    }

    ps2mouse_stream_status=0;

done:
    ps2mouse_packet_pos=0;

    /* Always restore the keyboard interface and both PIC receive paths. */
    (void)ps2mouse_kbcmd(I8042_CMD_ENABLE_KBD);
    enable_irq(1);
    enable_irq(12);
    set_eflags(flags);

    if(rv)
        ps2mouse_stream_status=-rv;
    return rv;
}

// APPLY VIDEOMODE CHANGE (software-side defaults only).
// V67.4 deliberately preserves the firmware-provided PS/2 hardware state.
// No scaling/rate/resolution command is sent to the physical device here.
void ps2mouse_modeChange(int mode1)
{
	/*
	 * Coordinate changes are software state only.  In particular, changing
	 * from the boot text console to VESA must not send F3/E6/E7/E8 commands
	 * to the PS/2 device: the working firmware-provided stream is preserved.
	 */
	if(!ps2mouse_enabled) return;

	switch(mode1)
	{
		case 3:
			mouse.rate=PS2MOUSE_DEFAULT_RATE;
			mouse.resolution=PS2MOUSE_DEFAULT_RESOLUTION;
			break;

		case 0x11:
		case 0x12:
		case 0x13:
		default:
			mouse.rate=PS2MOUSE_DEFAULT_RATE2;
			mouse.resolution=PS2MOUSE_DEFAULT_RESOLUTION2;
			break;
	}
}

// INIT MOUSE
void ps2mouse_init(void)
{
    int rv JTM_UNUSED,dnr;

    if(ps2mouse_enabled)
    {
        printk("PS/2 mouse driver is already enabled.\n");
        return;
    }
    if(input_policy_mouse_backend()==INPUT_BACKEND_USB)
    {
        printk("PS/2 mouse: skipped because USB already owns the single logical mouse.\n");
        return;
    }

    printk("PS/2 mouse driver 1.3 (USB-priority fallback attach)\n");

    dnr=ps2mouse_register_device();
    if(dnr<0)
    {
        printk("PS/2 mouse: driver not activated because DEVDB registration failed.\n");
        return;
    }
    printk("PS/2 mouse: registered as ps2mouse: DNR=%d.\n",dnr);
    ps2mouse_packet_pos=0;
    ps2mouse_packet_size=3;
    ps2mouse_device_id=0;
    ps2mouse_irq_count=0;
    ps2mouse_byte_count=0;
    ps2mouse_packet_count=0;
    ps2mouse_poll_calls=0;
    ps2mouse_remote_poll_count=0;
    ps2mouse_stream_status=-1;

    /* Mark ownership before enabling IRQ12 so keyboard polling preserves AUX
     * bytes.  Keep the legacy kernel cursor hidden during boot; GraOS draws
     * the only visible mouse cursor in the VESA framebuffer. */
    mouse_hidecursor();
    ps2mouse_enabled=1;
    mouse_modeChange(dispadmin_getcurrentmode());

#if PS2MOUSE_BIOS_PRESERVE
    /* Passive attach only.  Do not touch A7/A8, AD/AE, the command byte, F4,
     * F6 or FF during normal boot.  BIOS already left a working stream on the
     * target hardware; JTMOS only installs IRQ12 and passively drains AUX. */
    {
        int flags=get_eflags();
        disable();
        disable_irq(12);
        ps2mouse_install_irq_gate();
        enable_irq(12);
        set_eflags(flags);
    }
    rv=0;
    ps2mouse_stream_status=1; /* BIOS-preserved/passive */
    printk("PS/2 mouse: BIOS-preserve passive attach, IRQ12 enabled; no reset/init commands sent.\n");
#else
    rv=ps2mouse_hardwareinit();
    if(rv==0)
        printk("PS/2 mouse: ready, IRQ12 enabled, id=%d packet=%d bytes.\n",
               ps2mouse_device_id,ps2mouse_packet_size);
    else
        printk("PS/2 mouse: init stage %d failed; IRQ12/poll/request fallback active.\n",rv);
#endif

    mouse_hidecursor();
    mouse.lx=-1;
    mouse.ly=-1;
    ps2mouse_first_time=1;
}

/*
 * GraOS transition.  The PS/2/AUX hardware is normally attached much earlier,
 * immediately after keyboard initialization.  Here we only retry a failed
 * stream once, transfer cursor ownership to userspace and expand the coordinate
 * frame to the 1024x768 desktop.
 */
int ps2mouse_prepare_graos(void)
{
    int rv=0;

    if(!ps2mouse_enabled)
        ps2mouse_init();

    if(!ps2mouse_enabled)
        return 1;

#if PS2MOUSE_BIOS_PRESERVE
    /* GraOS must not reprogram a working firmware-provided PS/2 stream.  Drain
     * only already-pending AUX bytes; no request/reset/configuration command. */
    (void)ps2mouse_poll();
#else
    if(ps2mouse_stream_status<0)
    {
        printk("PS/2 mouse: retrying AUX stream setup before GraOS.\n");
        rv=ps2mouse_hardwareinit();
    }
    if(ps2mouse_irq_count==0 && ps2mouse_packet_count==0)
    {
        ps2mouse_poll_calls=31;
        (void)ps2mouse_poll();
    }
#endif

    mouse_hidecursor();
    mouse_setframe(0,0,GRAOS_VESA_WIDTH-1,GRAOS_VESA_HEIGHT-1);
    mouse_setposition(GRAOS_VESA_WIDTH/2,GRAOS_VESA_HEIGHT/2);
    mouse.lx=-1;
    mouse.ly=-1;
    return rv;
}


//






