// ===============================================
// SerialMouse.c - Serial Mouse Driver
// (C) 2002-2006 by Jari Tuominen
// Receive ownership / buffering repair 2026.
//
// COM1: 0x3F8, IRQ4
// COM2: 0x2F8, IRQ3
// ===============================================
#include "kernel32.h"
#include "mouse.h"
#include "ps2mouse.h"
#include "SerialMouse.h"
#include "SerialMouseDev.h"
#include "serial.h"
#include "scheduler.h"

THREAD MouseThread;
static int serial_mouse_active[4] = {0,0,0,0};

static void SerialMouse_ProcessByte(int nCom, int inbyte)
{
	int accel;
	SERMOUSE *s;

	if(nCom<0 || nCom>3) return;
	s=&mouse.serial[nCom];

	if(mouse.resolution==PS2MOUSE_DEFAULT_RESOLUTION)
		s->div=1;
	else if(mouse.resolution==PS2MOUSE_DEFAULT_RESOLUTION2)
		s->div=1;
	else
		s->div=1;

	accel=sermouse_acceleration;
	s->signal=0xFF;

	/* Microsoft 3-byte serial mouse packets have bit 6 set in byte zero and
	 * clear in movement bytes. Drop data until a real packet boundary appears. */
	if(inbyte&0x40)
		s->bytenum=0;
	else if(s->bytenum==0)
		return;

	if(s->bytenum<0 || s->bytenum>=3)
		s->bytenum=0;

	s->combytes[s->bytenum++]=(BYTE)inbyte;
	if(s->bytenum<3) return;

	s->dx=((s->combytes[0]&0x03)<<6)+(s->combytes[1]&0x3F);
	s->dy=((s->combytes[0]&0x0C)<<4)+(s->combytes[2]&0x3F);
	if(s->dx>=128) s->dx-=256;
	if(s->dy>=128) s->dy-=256;

	s->x+=((s->dx)/s->div)*accel;
	s->y+=((s->dy)/s->div)*accel;
	LimitToRectArea(&s->x,&s->y,
		mouse.frame.x1,mouse.frame.y1,mouse.frame.x2,mouse.frame.y2);

	mouse.lx=mouse.x;
	mouse.ly=mouse.y;
	mouse.x+=((s->dx)/s->div)*accel;
	mouse.y+=((s->dy)/s->div)*accel;
	LimitToRectArea(&mouse.x,&mouse.y,
		mouse.frame.x1,mouse.frame.y1,mouse.frame.x2,mouse.frame.y2);

	/* Microsoft 3-byte protocol: left=bit5, right=bit4. Bit6 is the sync bit,
	 * not a third button. Extensions may provide middle-button data separately. */
	s->button1=(s->combytes[0]&0x20) ? 1 : 0;
	s->button2=(s->combytes[0]&0x10) ? 1 : 0;
	s->button3=0;

	if(s->button1) mouse.buttons|=1; else mouse.buttons&=~1;
	if(s->button2) mouse.buttons|=2; else mouse.buttons&=~2;
	mouse.buttons&=~4;

	s->bytenum=0;
	if(mouse.isVisible) ps2mouse_drawarrow();
	ps2mouse_first_time=0;
}

/* One software consumer owns each enabled serial-mouse line. The UART ISR is
 * still the only hardware RBR reader; this task only drains owner-tagged FIFOs. */
void MouseThreadProgram(void)
{
	int i,ch,work;
	while(1)
	{
		work=0;
		for(i=0;i<4;i++)
		{
			if(!serial_mouse_active[i]) continue;
			while((ch=serial_get_owned(i,SERIAL_OWNER_SERMOUSE))!=-1)
			{
				SerialMouse_ProcessByte(i,ch);
				work=1;
			}
		}
		if(!work) SchedulerWaitPause(2000UL);
	}
}

void init_MouseThread(void)
{
	if(ThreadCreateStack(&MouseThread,JTMOS_MIN_DYNAMIC_STACK)!=0) return;
	MouseThread.pid=create_thread(MouseThread.stack,MouseThread.l_stack,MouseThreadProgram);
	if(MouseThread.pid<=0) { ThreadDestroyStack(&MouseThread); return; }
	IdentifyThread(MouseThread.pid,"KSERMOUSE");
}

/* Obsolete dedicated serial-mouse IRQ handlers. The common serial UART driver
 * owns IRQ3/IRQ4 and feeds software FIFOs. */
void SerialMouse_irqhandler4(void) { }
void SerialMouse_irqhandler3(void) { }

void LimitToRectArea(int *x,int *y,int x1,int y1,int x2,int y2)
{
	if(*x<x1) *x=x1;
	if(*y<y1) *y=y1;
	if(*x>=x2) *x=x2;
	if(*y>=y2) *y=y2;
}

/* Compatibility entry point: process bytes for one already-claimed port. */
void HandleSerMouse(int nCom)
{
	int ch;
	if(nCom<0 || nCom>3 || !serial_mouse_active[nCom]) return;
	while((ch=serial_get_owned(nCom,SERIAL_OWNER_SERMOUSE))!=-1)
		SerialMouse_ProcessByte(nCom,ch);
}

int SerialMouse_SetDivisor(int nCom,int div)
{
	if(nCom<0 || nCom>3 || div<=0) return 1;
	mouse.serial[nCom].div=div;
	return 0;
}

/* Returns number of successfully enabled serial-mouse ports. */
int SerialMouse_setupirqs(void)
{
	int i,active,wanted;
	SERMOUSE *s;

	if(!serialInitialized)
	{
		printk("Serial mouse: UART driver is not initialized.\n");
		return 0;
	}

	for(i=0;i<4;i++)
	{
		serial_mouse_active[i]=0;
		s=&mouse.serial[i];
		s->bytenum=0;
		s->signal=0;
		s->x=s->y=s->dx=s->dy=0;
		SerialMouse_SetDivisor(i,1);
	}

	active=0;
	for(i=0;i<4;i++)
	{
		wanted=(i==0 && ENABLE_MOUSE_COM1) || (i==1 && ENABLE_MOUSE_COM2);
		if(!wanted) continue;

		/* Explicitly enabling a serial mouse gives it the whole UART. A debug
		 * console cannot share the same physical serial line. */
		if(serial_debug_line==i)
		{
			serial_console_redirect=0;
			serial_debug_line=-1;
			(void)serial_release_port(i,SERIAL_OWNER_DEBUG);
			printk("Serial mouse: disabled debug UART on COM%d.\n",i+1);
		}

		if(serial_claim_port(i,SERIAL_OWNER_SERMOUSE))
		{
			printk("Serial mouse: COM%d is owned by %s; not attaching mouse.\n",
				i+1,serial_owner_name(serial_get_owner(i)));
			continue;
		}

		if(SetSerialPortSpeedOwned(i,1200,SERIAL_OWNER_SERMOUSE))
		{
			printk("Serial mouse: failed to configure COM%d at 1200 bps.\n",i+1);
			serial_release_port(i,SERIAL_OWNER_SERMOUSE);
			continue;
		}

		serial_mouse_active[i]=1;
		active++;
		printk("Serial mouse: COM%d exclusive, %x IRQ%d, 1200 bps.\n",
			i+1,serialport[i].ad,serialport[i].irq);
	}

	if(active) init_MouseThread();
	return active;
}
