//------------------------------------------------------------
// ega.c - EGA VIDEO DRIVER
// (C) 2000-2007 by Jari Tuominen(jari@vunet.org).
//-----------------------------------------------------------
#include "ega.h"
#include "sysglvar.h"
#include "kernel32.h"
#include "macrodef.h"
#include "cpu.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
#include "printf.h"
#include "string.h"
//
#include "driver_sys.h" // driver_register_new_device, ...
#include "driver_api.h"
#include "terminal.h"
#include "ega_ansi.h" // ansi code support
#include "term.h"
#include "vesa.h"

//
#define IF_VISIBLE	if( thread_terminal[GetCurrentThread()]==visible_terminal )

// Safe mode EGA init so that kernel panics work at the start up
// even without the dynamic memory allocation system(malloc).
// (obsolete)
void EGASafeMode(void)
{
	//
	dump_all_to_com1=FALSE;
	terminalLockPID=0;
	puts_busy=0;
	visible_terminal=0;
	saved_terminal=-1;

	//
	initscreenstructure(&screens[0]);
}

/* 80x25 text screen = 4000 bytes. The historical JTMOS terminal layout
 * reserves a 4 KiB hardware page per VT at B8000, B9000, ... BF000.
 * VGA CRTC start-address registers count WORD addresses, so one 4 KiB page
 * advances the start by 0x800, not by 8. */
#define EGA_TEXT_PAGE_WORDS     0x0800
#define EGA_TEXT_VISIBLE_BYTES  (80*25*2)

// For 80x25 EGA/VGA text mode.
void EgaSelectWindow(int which)
{
	SCREEN *s;

	if(which < ID_VIRTUAL_TERMINAL_1 ||
	   which > ID_VIRTUAL_TERMINAL_9)
		return;

	/* VT9 cannot have its own hardware page: the color text aperture ends at
	 * BFFFF. Borrow page 0 while VT9 is visible. The RAM backing buffers
	 * remain authoritative, so restoring VT1 afterward is lossless. */
	if(which == ID_VIRTUAL_TERMINAL_9)
	{
		s = &screens[ID_VIRTUAL_TERMINAL_9];
		SetHWCopy(&screens[ID_VIRTUAL_TERMINAL_1], FALSE);
		SetHWCopy(s, FALSE);
		s->copy = JTM_DWORD_TO_PTR(char,0xB8000);
		memcpy((void *)0xB8000, s->buf, EGA_TEXT_VISIBLE_BYTES);
		SetHWCopy(s, TRUE);
		EgaSetViewStart(0);
		visible_terminal=which;
		locatetxtcursor(s);
		return;
	}

	/* If page 0 was borrowed by VT9, restore VT1 from its RAM buffer before
	 * returning to the normal eight-page hardware layout. */
	if(visible_terminal == ID_VIRTUAL_TERMINAL_9)
	{
		SetHWCopy(&screens[ID_VIRTUAL_TERMINAL_9], FALSE);
		screens[ID_VIRTUAL_TERMINAL_9].copy = (DWORD)0;
		screens[ID_VIRTUAL_TERMINAL_1].copy = JTM_DWORD_TO_PTR(char,0xB8000);
		memcpy((void *)0xB8000, screens[ID_VIRTUAL_TERMINAL_1].buf,
		       EGA_TEXT_VISIBLE_BYTES);
		SetHWCopy(&screens[ID_VIRTUAL_TERMINAL_1], TRUE);
	}

	EgaSetViewStart((WORD)(which * EGA_TEXT_PAGE_WORDS));
	visible_terminal=which;
	locatetxtcursor(&screens[visible_terminal]);
}

/* Select the EGA terminal associated with Left-Alt+F1..F7.  Keep the
 * keyboard mapping in one place: F1 -> VT0, ... F7 -> VT6.  The caller is
 * responsible for ensuring that the machine is currently in EGA/VGA text
 * mode; EgaSelectWindow() remains the actual hardware page selector. */
int EgaSelectFunctionWindow(int function_key)
{
	int which;

	if(function_key < 1 || function_key > 7)
		return 1;

	which=function_key-1;
	EgaSelectWindow(which);
	return 0;
}

// Set VGA/EGA CRTC start address (word address).
void EgaSetViewStart(WORD ad)
{
	/* CRTC 0Ch = start-address high, 0Dh = start-address low. The old
	 * implementation accidentally wrote both bytes to register 0Ch. */
	outportw(0x3D4, (WORD)(0x0C | (((ad >> 8) & 0xFF) << 8)));
	outportw(0x3D4, (WORD)(0x0D | ((ad & 0xFF) << 8)));
}

// Note: to see what does 'DEVICE_CALL_PARS' mean,
// check driver_api.h.
//
int ega_device_call(DEVICE_CALL_PARS)
{
	//
	switch(n_call)
	{
		//
		case DEVICE_CMD_INIT:
		break;
		//
		case DEVICE_CMD_SHUTDOWN:
		break;
		//
		case DEVICE_CMD_READBLOCK:
		break;
		//
		case DEVICE_CMD_WRITEBLOCK:
		break;
		//
		case DEVICE_CMD_GETSIZE:
		break;
		//
		case DEVICE_CMD_GETBLOCKSIZE:
		break;
		//
		case DEVICE_CMD_SEEK:
		break;
		//
		case DEVICE_CMD_GETCH:
		break;
		//
		case DEVICE_CMD_PUTCH:
		break;
		//
		case DEVICE_CMD_TELL:
		break;
		//
		default:
		break;
	}
 
	//
	return 0;
}

// Registers device 'ega'
int ega_register_device(void)
{
	// Check that the device isn't already registered
	if( driver_getdevicebyname("ega") )
	{
		dprintk("cannot register device ega: device already registered\n");
		return 1;
	}

	// Register the device
	driver_register_new_device("ega", ega_device_call, DEVICE_TYPE_CHAR);
 
	//
	return 0;
}

//
int ega_init(void)
{
	//
	ega_register_device();
	return 0;
}

// New: Now adds current visible screen offset
// to the cursor location.
//
static void ega_hw_cursor_visible(int visible)
{
	BYTE v;
	outportb(0x3D4,0x0A);
	v=(BYTE)inportb(0x3D5);
	if(visible) v=(BYTE)(v & (BYTE)~0x20);
	else v=(BYTE)(v | 0x20);
	outportb(0x3D5,v);
}

void ega_locatetxtcursor(SCREEN *s)
{
	int ad,ad2;
	int focused;
	if(s==NULL) return;
	focused=(s->updcur && s==&screens[visible_terminal] && s->id==GetInputTerminal());
	if(!focused)
	{
		ega_hw_cursor_visible(FALSE);
		return;
	}
	ega_hw_cursor_visible(TRUE);
	ad2=(int)s->copy-0xb8000;
	ad=(s->width*s->cury+s->curx)+(ad2>>1);
	outvgareg(0x0e,ad>>8);
	outvgareg(0x0f,ad&0xff);
}

// EGA/terminal system initialization
void EgaConsoleInit(void)
{
	// Define that we want now to see the output at EGA HW as well
	if(!vesa_enabled)
		VisibleTerminals_SetHWCopy(1);
}

//
