/*
 * JTMOS minimal OHCI USB 1.1 host driver.
 *
 * V67.8.57.10.18.16.16 target: NVIDIA MCP61 OHCI (10de:03f1), as used by
 * eMachines EL1352.  This is deliberately a small HID-only transport rather
 * than a general USB stack:
 *   - one OHCI controller
 *   - root-hub ports only (no external hubs yet)
 *   - standard device/configuration control requests
 *   - HID boot-subclass keyboard + mouse interfaces
 *   - periodic interrupt-IN reports, polling completion from process context
 *
 * The transport feeds usb_hid_boot_keyboard_report()/mouse_report(), so GraOS
 * and the existing keyboard/mouse policy do not know about OHCI details.
 */
#include "kernel32.h"
#include "driver_sys.h"
#include "driver_api.h"
#include "pci.h"
#include "paging.h"
#include "userhw.h"
#include "delay.h"
#include "pit.h"
#include "input_policy.h"
#include "usb_input.h"
#include "ohci.h"

#define NVIDIA_VENDOR_ID          0x10de
#define NVIDIA_MCP61_OHCI_ID      0x03f1
#define NVIDIA_MCP61_EHCI_ID      0x03f2

#define OHCI_CLASS_SERIAL         0x0c
#define OHCI_SUBCLASS_USB         0x03
#define OHCI_PROGIF               0x10

#define OHCI_REG_REVISION         0x00
#define OHCI_REG_CONTROL          0x04
#define OHCI_REG_COMMAND_STATUS   0x08
#define OHCI_REG_INTR_STATUS      0x0c
#define OHCI_REG_INTR_ENABLE      0x10
#define OHCI_REG_INTR_DISABLE     0x14
#define OHCI_REG_HCCA             0x18
#define OHCI_REG_PERIOD_CURRENT   0x1c
#define OHCI_REG_CONTROL_HEAD     0x20
#define OHCI_REG_CONTROL_CURRENT  0x24
#define OHCI_REG_BULK_HEAD        0x28
#define OHCI_REG_BULK_CURRENT     0x2c
#define OHCI_REG_DONE_HEAD        0x30
#define OHCI_REG_FM_INTERVAL      0x34
#define OHCI_REG_FM_REMAINING     0x38
#define OHCI_REG_FM_NUMBER        0x3c
#define OHCI_REG_PERIODIC_START   0x40
#define OHCI_REG_LS_THRESHOLD     0x44
#define OHCI_REG_RH_DESC_A        0x48
#define OHCI_REG_RH_DESC_B        0x4c
#define OHCI_REG_RH_STATUS        0x50
#define OHCI_REG_RH_PORT_BASE     0x54

#define OHCI_CTL_PLE              (1UL<<2)
#define OHCI_CTL_CLE              (1UL<<4)
#define OHCI_CTL_BLE              (1UL<<5)
#define OHCI_CTL_HCFS_MASK        (3UL<<6)
#define OHCI_CTL_OPERATIONAL      (2UL<<6)
#define OHCI_CTL_IR               (1UL<<8)

#define OHCI_CMD_HCR              (1UL<<0)
#define OHCI_CMD_CLF              (1UL<<1)
#define OHCI_CMD_BLF              (1UL<<2)
#define OHCI_CMD_OCR              (1UL<<3)

#define OHCI_INTR_WDH             (1UL<<1)
#define OHCI_INTR_RHSC            (1UL<<6)
#define OHCI_INTR_MIE             (1UL<<31)

#define OHCI_RHDA_NDP_MASK        0x000000ffUL
#define OHCI_RHDA_PSM             (1UL<<8)
#define OHCI_RHDA_NPS             (1UL<<9)
#define OHCI_RHDA_POTPGT_SHIFT    24

#define OHCI_RHS_LPSC             (1UL<<16)

#define OHCI_PORT_CCS             (1UL<<0)
#define OHCI_PORT_PES             (1UL<<1)
#define OHCI_PORT_PRS             (1UL<<4)
#define OHCI_PORT_PPS             (1UL<<8)
#define OHCI_PORT_LSDA            (1UL<<9)
#define OHCI_PORT_CSC             (1UL<<16)
#define OHCI_PORT_PESC            (1UL<<17)
#define OHCI_PORT_PSSC            (1UL<<18)
#define OHCI_PORT_OCIC            (1UL<<19)
#define OHCI_PORT_PRSC            (1UL<<20)
#define OHCI_PORT_CHANGE_MASK     (OHCI_PORT_CSC|OHCI_PORT_PESC|OHCI_PORT_PSSC|OHCI_PORT_OCIC|OHCI_PORT_PRSC)

#define OHCI_ED_D_FROM_TD         (0UL<<11)
#define OHCI_ED_D_OUT             (1UL<<11)
#define OHCI_ED_D_IN              (2UL<<11)
#define OHCI_ED_SPEED_LOW         (1UL<<13)
#define OHCI_ED_SKIP              (1UL<<14)
#define OHCI_ED_MPS_SHIFT         16
#define OHCI_ED_HEAD_HALT         1UL
#define OHCI_ED_HEAD_CARRY        2UL

#define OHCI_TD_R                 (1UL<<18)
#define OHCI_TD_DP_SETUP          (0UL<<19)
#define OHCI_TD_DP_OUT            (1UL<<19)
#define OHCI_TD_DP_IN             (2UL<<19)
#define OHCI_TD_DI_NONE           (7UL<<21)
#define OHCI_TD_T_DATA0           (2UL<<24)
#define OHCI_TD_T_DATA1           (3UL<<24)
#define OHCI_TD_CC_SHIFT          28
#define OHCI_TD_CC_NOT_ACCESSED   (15UL<<OHCI_TD_CC_SHIFT)
#define OHCI_TD_CC_MASK           (15UL<<OHCI_TD_CC_SHIFT)
#define OHCI_TD_CC_NOERROR        0
#define OHCI_TD_CC_DATAUNDERRUN   9

#define USB_DESC_DEVICE           1
#define USB_DESC_CONFIG           2
#define USB_DESC_INTERFACE        4
#define USB_DESC_ENDPOINT         5
#define USB_CLASS_HID             3
#define USB_HID_SUBCLASS_BOOT     1
#define USB_HID_PROTO_KEYBOARD    1
#define USB_HID_PROTO_MOUSE       2
#define USB_EP_XFER_INTERRUPT     3

#define USB_REQ_GET_DESCRIPTOR    6
#define USB_REQ_SET_ADDRESS       5
#define USB_REQ_SET_CONFIG        9
#define USB_HID_SET_PROTOCOL      0x0b
#define USB_HID_GET_REPORT        0x01
#define USB_HID_REPORT_INPUT      0x01

/* QEMU's usb-kbd/usb-mouse IDs.  The V69.22 control-report rescue is kept
 * deliberately narrow: real hardware continues to use the normal periodic
 * interrupt-IN endpoint, while QEMU can recover a maintenance console even if
 * its OHCI periodic queue has not retired a TD yet. */
#define QEMU_USB_HID_VENDOR        0x0627
#define QEMU_USB_HID_PRODUCT       0x0001
#define OHCI_BOOT_KBD_REPORT_LEN   8
#define OHCI_QEMU_RESCUE_USEC      20000UL
#define OHCI_QEMU_RETRY_USEC       250000UL

#define OHCI_DMA_BYTES            16384UL
#define OHCI_CTRL_BUFFER_BYTES    1024
#define OHCI_MAX_HID              8
#define OHCI_MAX_PORTS            15
#define OHCI_HID_SLOT_BYTES       0x100
#define OHCI_HID_BASE             0x800
#define OHCI_CTRL_TIMEOUT_MS      300
#define OHCI_CTRL_RESCUE_TIMEOUT_MS 50
#define OHCI_CTRL_QUIESCE_MS      20
#define OHCI_PERIODIC_QUIESCE_MS  20
#define OHCI_TOPOLOGY_POLL_USEC   250000UL
#define OHCI_FRAME_STALL_USEC     100000UL
#define OHCI_RECOVERY_BACKOFF_USEC 500000UL

#pragma pack(push,1)
typedef struct
{
    DWORD intr[32];
    WORD frame_no;
    WORD pad1;
    DWORD done_head;
    BYTE reserved[120];
} OHCI_HCCA;

typedef struct
{
    volatile DWORD flags;
    volatile DWORD tail;
    volatile DWORD head;
    volatile DWORD next;
} OHCI_ED;

typedef struct
{
    volatile DWORD flags;
    volatile DWORD cbp;
    volatile DWORD next;
    volatile DWORD be;
} OHCI_TD;

typedef struct
{
    BYTE bmRequestType;
    BYTE bRequest;
    WORD wValue;
    WORD wIndex;
    WORD wLength;
} USB_SETUP;
#pragma pack(pop)

typedef struct
{
    int used;
    int port;
    int address;
    int low_speed;
    WORD vendor;
    WORD product;
    BYTE interface_no;
    BYTE protocol;
    BYTE endpoint;
    BYTE ep0_max_packet;
    WORD max_packet;
    BYTE interval;
    int report_len;
    int td_active;
    int td_tail;
    DWORD reports;
    DWORD errors;
    DWORD control_reports;
    DWORD control_errors;
    DWORD control_error_streak;
    DWORD last_control_poll_us;
    OHCI_ED *ed;
    OHCI_TD *td[2];
    BYTE *report;
    DWORD ed_phys;
    DWORD td_phys[2];
    DWORD report_phys;
} OHCI_HID;

typedef struct
{
    int initialized;
    int ready;
    int controller_dnr;
    BYTE bus,dev,fun;
    volatile BYTE *mmio;
    DWORD mmio_phys;
    DWORD dma_phys;
    BYTE *dma;
    OHCI_HCCA *hcca;
    OHCI_ED *ctrl_ed;
    OHCI_TD *ctrl_td[4];
    USB_SETUP *setup;
    BYTE *ctrl_buf;
    int ports;
    int connected_ports;
    int enumerated_devices;
    int hid_count;
    int keyboards;
    int mice;
    int polls;
    DWORD poll_contentions;
    int transfer_errors;
    DWORD control_timeouts;
    DWORD control_quiesce_failures;
    DWORD periodic_quiesce_failures;
    DWORD topology_changes;
    DWORD schedule_republishes;
    DWORD frame_stalls;
    DWORD connected_bitmap;
    DWORD last_topology_poll_us;
    DWORD last_frame_progress_us;
    DWORD last_schedule_republish_us;
    WORD last_frame_no;
    OHCI_HID hid[OHCI_MAX_HID];
} OHCI_STATE;

static OHCI_STATE ohci;

static DWORD ohci_r32(int off)
{
    return mmio_read32(ohci.mmio+off);
}

static void ohci_w32(int off,DWORD v)
{
    mmio_write32(ohci.mmio+off,v);
}

static DWORD ohci_port_read(int p)
{
    return ohci_r32(OHCI_REG_RH_PORT_BASE+(p-1)*4);
}

static void ohci_port_write(int p,DWORD v)
{
    ohci_w32(OHCI_REG_RH_PORT_BASE+(p-1)*4,v);
}

static DWORD ohci_phys_at(DWORD off)
{
    return ohci.dma_phys+off;
}

static void *ohci_virt_at(DWORD off)
{
    return (void *)(ohci.dma+off);
}

static WORD usb_le16(const BYTE *p)
{
    return (WORD)((WORD)p[0] | ((WORD)p[1]<<8));
}

static int ohci_wait_clear(int reg,DWORD bit,int timeout_ms)
{
    int i;
    for(i=0;i<timeout_ms;i++)
    {
        if(!(ohci_r32(reg)&bit)) return 0;
        delay(1);
    }
    return 1;
}

static int ohci_controller_device_call(DEVICE_CALL_PARS)
{
    (void)n_call; (void)p1; (void)p2; (void)p3; (void)p4;
    (void)po1; (void)po2;
    return 0;
}

static int ohci_td_cc(OHCI_TD *td)
{
    return (int)((td->flags & OHCI_TD_CC_MASK)>>OHCI_TD_CC_SHIFT);
}

/* PLE/CLE changes take effect after the next SOF.  Observing that boundary is
 * the portable indication that HC has stopped starting work from the disabled
 * list; HcPeriodCurrentED is read-only to HCD and is not a drain handshake. */
static int ohci_wait_next_frame(int timeout_ms)
{
    WORD start,now;
    int i;

    start=(WORD)(ohci_r32(OHCI_REG_FM_NUMBER)&0xffffUL);
    for(i=0;i<timeout_ms;i++)
    {
        delay(1);
        now=(WORD)(ohci_r32(OHCI_REG_FM_NUMBER)&0xffffUL);
        if(now!=start) return 0;
    }
    return 1;
}

/* Stop endpoint zero before software recycles its fixed ED/TD storage.  The
 * OHCI specification permits HCD to replace ControlCurrentED only while CLE
 * is clear, and permits list edits after the following SOF.  If SOF never
 * arrives, retain the old descriptors and let the caller defer the request. */
static int ohci_control_quiesce(DWORD control)
{
    if(ohci.ctrl_ed) ohci.ctrl_ed->flags|=OHCI_ED_SKIP;
    __asm__ volatile("" ::: "memory");
    ohci_w32(OHCI_REG_CONTROL,control&~OHCI_CTL_CLE);
    if((ohci_r32(OHCI_REG_CONTROL)&OHCI_CTL_CLE) ||
       ohci_wait_next_frame(OHCI_CTRL_QUIESCE_MS))
    {
        ohci.control_quiesce_failures++;
        dprintk("OHCI: control-list quiesce deferred; no safe SOF boundary.\n");
        return 1;
    }
    ohci_w32(OHCI_REG_CONTROL_CURRENT,0);
    return 0;
}

/* One synchronous endpoint-zero transaction.  The four fixed TDs are safe
 * because enumeration and class requests are serialized during init. */
static int ohci_control_xfer(int address,int low_speed,int max_packet,
                             BYTE bmRequestType,BYTE bRequest,WORD wValue,
                             WORD wIndex,void *buffer,int length,int timeout_ms)
{
    OHCI_ED *ed;
    OHCI_TD *t0,*t1,*t2,*dummy;
    USB_SETUP *s;
    DWORD edphys,t0phys,t1phys,t2phys,dummyphys;
    DWORD bufphys;
    DWORD head;
    int dir_in;
    int i,cc0,cc1,cc2;

    DWORD ctl;
    if(!ohci.ready && !ohci.mmio) return 1;
    if(length<0 || length>OHCI_CTRL_BUFFER_BYTES) return 2;
    if(max_packet<=0) max_packet=8;
    if(max_packet>64) max_packet=64;
    if(timeout_ms<=0 || timeout_ms>OHCI_CTRL_TIMEOUT_MS)
        timeout_ms=OHCI_CTRL_TIMEOUT_MS;

    ed=ohci.ctrl_ed;
    t0=ohci.ctrl_td[0]; t1=ohci.ctrl_td[1];
    t2=ohci.ctrl_td[2]; dummy=ohci.ctrl_td[3];
    edphys=ohci_phys_at(0x100);
    t0phys=ohci_phys_at(0x110);
    t1phys=ohci_phys_at(0x120);
    t2phys=ohci_phys_at(0x130);
    dummyphys=ohci_phys_at(0x140);
    bufphys=ohci_phys_at(0x220);
    s=ohci.setup;
    dir_in=(bmRequestType&0x80) ? 1 : 0;

    /* Stop the control scheduler while rebuilding its fixed ED/TD chain. */
    ctl=ohci_r32(OHCI_REG_CONTROL);
    if(ohci_control_quiesce(ctl))
    {
        ohci.transfer_errors++;
        return 5;
    }
    memset((void *)ed,0,sizeof(*ed));
    memset((void *)t0,0,sizeof(*t0));
    memset((void *)t1,0,sizeof(*t1));
    memset((void *)t2,0,sizeof(*t2));
    memset((void *)dummy,0,sizeof(*dummy));
    memset(ohci.ctrl_buf,0,OHCI_CTRL_BUFFER_BYTES);

    s->bmRequestType=bmRequestType;
    s->bRequest=bRequest;
    s->wValue=wValue;
    s->wIndex=wIndex;
    s->wLength=(WORD)length;
    if(length && !dir_in && buffer)
        memcpy(ohci.ctrl_buf,buffer,(size_t)length);

    ed->flags=(DWORD)(address&0x7f) |
              (low_speed ? OHCI_ED_SPEED_LOW : 0) |
              ((DWORD)(max_packet&0x7ff)<<OHCI_ED_MPS_SHIFT) |
              OHCI_ED_D_FROM_TD;
    ed->tail=dummyphys;
    ed->head=t0phys;
    ed->next=0;

    t0->flags=OHCI_TD_CC_NOT_ACCESSED|OHCI_TD_DI_NONE|
              OHCI_TD_DP_SETUP|OHCI_TD_T_DATA0;
    t0->cbp=ohci_phys_at(0x200);
    t0->be=t0->cbp+7;
    t0->next=length ? t1phys : t2phys;

    if(length)
    {
        t1->flags=OHCI_TD_CC_NOT_ACCESSED|OHCI_TD_DI_NONE|
                  (dir_in ? OHCI_TD_R : 0) |
                  (dir_in ? OHCI_TD_DP_IN : OHCI_TD_DP_OUT) |
                  OHCI_TD_T_DATA1;
        t1->cbp=bufphys;
        t1->be=bufphys+(DWORD)length-1;
        t1->next=t2phys;
    }

    t2->flags=OHCI_TD_CC_NOT_ACCESSED|OHCI_TD_DI_NONE|
              (dir_in ? OHCI_TD_DP_OUT : OHCI_TD_DP_IN) |
              OHCI_TD_T_DATA1;
    t2->cbp=0;
    t2->be=0;
    t2->next=dummyphys;

    ohci_w32(OHCI_REG_CONTROL_HEAD,edphys);
    ohci_w32(OHCI_REG_CONTROL_CURRENT,0);
    ohci_w32(OHCI_REG_CONTROL,
             (((ctl|OHCI_CTL_CLE)&~OHCI_CTL_HCFS_MASK)|OHCI_CTL_OPERATIONAL));
    ohci_w32(OHCI_REG_COMMAND_STATUS,OHCI_CMD_CLF);

    for(i=0;i<timeout_ms;i++)
    {
        head=ed->head;
        if((head&~0x0fUL)==dummyphys) break;
        if(head&OHCI_ED_HEAD_HALT) break;
        delay(1);
    }
    head=ed->head;
    if((head&~0x0fUL)!=dummyphys)
    {
        (void)ohci_control_quiesce(ohci_r32(OHCI_REG_CONTROL));
        ohci.control_timeouts++;
        ohci.transfer_errors++;
        return 3;
    }

    cc0=ohci_td_cc(t0);
    cc1=length ? ohci_td_cc(t1) : OHCI_TD_CC_NOERROR;
    cc2=ohci_td_cc(t2);
    if(cc0!=OHCI_TD_CC_NOERROR || cc2!=OHCI_TD_CC_NOERROR ||
       (cc1!=OHCI_TD_CC_NOERROR && cc1!=OHCI_TD_CC_DATAUNDERRUN))
    {
        (void)ohci_control_quiesce(ohci_r32(OHCI_REG_CONTROL));
        ohci.transfer_errors++;
        return 4;
    }

    if(length && dir_in && buffer)
        memcpy(buffer,ohci.ctrl_buf,(size_t)length);
    return 0;
}

static int ohci_reset_port(int port,int *low_speed)
{
    DWORD st;
    int i;
    st=ohci_port_read(port);
    if(!(st&OHCI_PORT_CCS)) return 1;

    /* Clear stale change indications, then assert port reset. */
    ohci_port_write(port,st&OHCI_PORT_CHANGE_MASK);
    ohci_port_write(port,OHCI_PORT_PRS);
    for(i=0;i<100;i++)
    {
        delay(1);
        st=ohci_port_read(port);
        if(st&OHCI_PORT_PRSC) break;
    }
    st=ohci_port_read(port);
    if(!(st&OHCI_PORT_CCS)) return 2;
    if(st&OHCI_PORT_PRSC) ohci_port_write(port,OHCI_PORT_PRSC);
    delay(10);
    st=ohci_port_read(port);
    if(!(st&OHCI_PORT_PES)) return 3;
    if(low_speed) *low_speed=(st&OHCI_PORT_LSDA) ? 1 : 0;
    return 0;
}

static int ohci_add_hid_interface(int port,int address,int low_speed,
                                  WORD vendor,WORD product,BYTE ifno,
                                  BYTE protocol,BYTE endpoint,WORD mps,
                                  BYTE interval)
{
    OHCI_HID *h;
    int slot,i;
    DWORD off;
    if(ohci.hid_count>=OHCI_MAX_HID) return 1;
    if(protocol!=USB_HID_PROTO_KEYBOARD && protocol!=USB_HID_PROTO_MOUSE) return 2;

    /* usb_input.c keeps one aggregate boot-report state per input class.
     * Feeding two keyboards into it would let an idle report from one release
     * keys held on the other.  Until per-device aggregation exists, bind the
     * first usable keyboard and mouse and ignore duplicate interfaces. */
    for(i=0;i<ohci.hid_count;i++)
        if(ohci.hid[i].used && ohci.hid[i].protocol==protocol)
            return 3;

    if(endpoint==0 || mps==0 || mps>64 || (low_speed && mps>8)) return 4;
    slot=ohci.hid_count++;
    h=&ohci.hid[slot];
    memset(h,0,sizeof(*h));
    h->used=1;
    h->port=port; h->address=address; h->low_speed=low_speed;
    h->vendor=vendor; h->product=product; h->interface_no=ifno;
    h->protocol=protocol; h->endpoint=endpoint; h->max_packet=mps;
    h->ep0_max_packet=8;
    h->interval=interval ? interval : 1;
    h->report_len=(protocol==USB_HID_PROTO_KEYBOARD) ? 8 : (int)mps;
    if(h->report_len<3) h->report_len=3;
    if(h->report_len>8) h->report_len=8;

    off=OHCI_HID_BASE+(DWORD)slot*OHCI_HID_SLOT_BYTES;
    h->ed=(OHCI_ED *)ohci_virt_at(off+0x00);
    h->td[0]=(OHCI_TD *)ohci_virt_at(off+0x10);
    h->td[1]=(OHCI_TD *)ohci_virt_at(off+0x20);
    h->report=(BYTE *)ohci_virt_at(off+0x40);
    h->ed_phys=ohci_phys_at(off+0x00);
    h->td_phys[0]=ohci_phys_at(off+0x10);
    h->td_phys[1]=ohci_phys_at(off+0x20);
    h->report_phys=ohci_phys_at(off+0x40);
    h->td_active=0; h->td_tail=1;

    if(protocol==USB_HID_PROTO_KEYBOARD) ohci.keyboards++;
    else ohci.mice++;
    return 0;
}

static void ohci_rollback_hids(int base_hid)
{
    int i;

    if(base_hid<0) base_hid=0;
    if(base_hid>ohci.hid_count) base_hid=ohci.hid_count;
    for(i=base_hid;i<ohci.hid_count;i++)
    {
        if(ohci.hid[i].protocol==USB_HID_PROTO_KEYBOARD && ohci.keyboards>0)
            ohci.keyboards--;
        else if(ohci.hid[i].protocol==USB_HID_PROTO_MOUSE && ohci.mice>0)
            ohci.mice--;
        memset(&ohci.hid[i],0,sizeof(ohci.hid[i]));
    }
    ohci.hid_count=base_hid;
}

static int ohci_parse_configuration(int port,int address,int low_speed,
                                    WORD vendor,WORD product,const BYTE *buf,
                                    int length,BYTE *config_value)
{
    int pos;
    BYTE cur_if=0,cur_class=0,cur_sub=0,cur_proto=0,cur_alt=0;
    BYTE blen,btype,epaddr,attr,interval;
    WORD mps;
    if(length<9 || buf[1]!=USB_DESC_CONFIG) return 1;
    *config_value=buf[5];
    pos=0;
    while(pos+2<=length)
    {
        blen=buf[pos]; btype=buf[pos+1];
        if(blen<2 || pos+(int)blen>length) break;
        if(btype==USB_DESC_INTERFACE && blen>=9)
        {
            cur_if=buf[pos+2]; cur_alt=buf[pos+3];
            cur_class=buf[pos+5]; cur_sub=buf[pos+6]; cur_proto=buf[pos+7];
        }
        else if(btype==USB_DESC_ENDPOINT && blen>=7 && cur_alt==0 &&
                cur_class==USB_CLASS_HID && cur_sub==USB_HID_SUBCLASS_BOOT &&
                (cur_proto==USB_HID_PROTO_KEYBOARD || cur_proto==USB_HID_PROTO_MOUSE))
        {
            epaddr=buf[pos+2]; attr=buf[pos+3];
            mps=usb_le16(buf+pos+4)&0x07ffU;
            interval=buf[pos+6];
            if((epaddr&0x80) && (epaddr&0x0f) &&
               ((attr&3)==USB_EP_XFER_INTERRUPT) && mps>0 && mps<=64 &&
               (!low_speed || mps<=8))
            {
                if(ohci_add_hid_interface(port,address,low_speed,vendor,product,
                                           cur_if,cur_proto,(BYTE)(epaddr&0x0f),
                                           mps,interval)==0)
                {
                    dprintk("OHCI: HID %s port=%d addr=%d if=%d ep=%x mps=%d VID:PID=%04x:%04x.\n",
                           cur_proto==USB_HID_PROTO_KEYBOARD?"keyboard":"mouse",
                           port,address,cur_if,epaddr,mps,vendor,product);
                }
            }
        }
        pos+=(int)blen;
    }
    return 0;
}

static int ohci_enumerate_port(int port,int address)
{
    BYTE first8[8];
    BYTE devdesc[18];
    BYTE cfghead[9];
    BYTE cfg[OHCI_CTRL_BUFFER_BYTES];
    BYTE config_value;
    WORD total,vid,pid;
    int low_speed,mps,rv,base_hid,i;

    low_speed=0;
    rv=ohci_reset_port(port,&low_speed);
    if(rv)
    {
        printk("OHCI: port %d reset failed (%d), status=%x.\n",port,rv,ohci_port_read(port));
        return 1;
    }

    memset(first8,0,sizeof(first8));
    rv=ohci_control_xfer(0,low_speed,8,0x80,USB_REQ_GET_DESCRIPTOR,
                         (WORD)(USB_DESC_DEVICE<<8),0,first8,8,
                         OHCI_CTRL_TIMEOUT_MS);
    if(rv || first8[1]!=USB_DESC_DEVICE)
    {
        printk("OHCI: port %d GET_DESCRIPTOR(8) failed (%d).\n",port,rv);
        return 2;
    }
    mps=first8[7];
    if(mps!=8 && mps!=16 && mps!=32 && mps!=64) mps=8;

    rv=ohci_control_xfer(0,low_speed,mps,0x00,USB_REQ_SET_ADDRESS,
                         (WORD)address,0,NULL,0,OHCI_CTRL_TIMEOUT_MS);
    if(rv)
    {
        printk("OHCI: port %d SET_ADDRESS %d failed (%d).\n",port,address,rv);
        return 3;
    }
    delay(5);

    memset(devdesc,0,sizeof(devdesc));
    rv=ohci_control_xfer(address,low_speed,mps,0x80,USB_REQ_GET_DESCRIPTOR,
                         (WORD)(USB_DESC_DEVICE<<8),0,devdesc,18,
                         OHCI_CTRL_TIMEOUT_MS);
    if(rv)
    {
        printk("OHCI: addr %d device descriptor failed (%d).\n",address,rv);
        return 4;
    }
    vid=usb_le16(devdesc+8); pid=usb_le16(devdesc+10);

    memset(cfghead,0,sizeof(cfghead));
    rv=ohci_control_xfer(address,low_speed,mps,0x80,USB_REQ_GET_DESCRIPTOR,
                         (WORD)(USB_DESC_CONFIG<<8),0,cfghead,9,
                         OHCI_CTRL_TIMEOUT_MS);
    if(rv || cfghead[1]!=USB_DESC_CONFIG)
    {
        printk("OHCI: addr %d config header failed (%d).\n",address,rv);
        return 5;
    }
    total=usb_le16(cfghead+2);
    if(total<9) return 6;
    if(total>OHCI_CTRL_BUFFER_BYTES) total=OHCI_CTRL_BUFFER_BYTES;
    memset(cfg,0,sizeof(cfg));
    rv=ohci_control_xfer(address,low_speed,mps,0x80,USB_REQ_GET_DESCRIPTOR,
                         (WORD)(USB_DESC_CONFIG<<8),0,cfg,(int)total,
                         OHCI_CTRL_TIMEOUT_MS);
    if(rv)
    {
        printk("OHCI: addr %d config descriptor failed (%d).\n",address,rv);
        return 7;
    }

    base_hid=ohci.hid_count;
    config_value=0;
    ohci_parse_configuration(port,address,low_speed,vid,pid,cfg,(int)total,
                             &config_value);
    if(ohci.hid_count==base_hid)
    {
        printk("OHCI: USB device port=%d addr=%d VID:PID=%04x:%04x has no boot HID interface.\n",
               port,address,vid,pid);
        return 8;
    }

    if(config_value==0)
    {
        printk("OHCI: addr %d invalid zero configuration value.\n",address);
        ohci_rollback_hids(base_hid);
        return 9;
    }

    rv=ohci_control_xfer(address,low_speed,mps,0x00,USB_REQ_SET_CONFIG,
                         config_value,0,NULL,0,OHCI_CTRL_TIMEOUT_MS);
    if(rv)
    {
        printk("OHCI: addr %d SET_CONFIGURATION %d failed (%d).\n",address,config_value,rv);
        ohci_rollback_hids(base_hid);
        return 10;
    }
    delay(5);

    for(i=base_hid;i<ohci.hid_count;i++)
    {
        ohci.hid[i].ep0_max_packet=(BYTE)mps;
        /* Boot-subclass devices default to report protocol on some hardware;
         * explicitly select the fixed boot report format before polling. */
        rv=ohci_control_xfer(address,low_speed,mps,0x21,USB_HID_SET_PROTOCOL,
                             0,ohci.hid[i].interface_no,NULL,0,
                             OHCI_CTRL_TIMEOUT_MS);
        if(rv)
            printk("OHCI: addr %d if=%d SET_PROTOCOL(boot) warning=%d.\n",
                   address,ohci.hid[i].interface_no,rv);
    }

    ohci.enumerated_devices++;
    return 0;
}

static void ohci_arm_hid(OHCI_HID *h,int publish)
{
    OHCI_TD *td,*dummy;
    DWORD carry;
    int active,tail;
    active=h->td_active; tail=h->td_tail;
    td=h->td[active]; dummy=h->td[tail];
    memset((void *)td,0,sizeof(*td));
    memset((void *)dummy,0,sizeof(*dummy));
    memset(h->report,0,(size_t)h->report_len);

    h->ed->flags=(DWORD)(h->address&0x7f) |
                 ((DWORD)(h->endpoint&0x0f)<<7) |
                 OHCI_ED_D_IN |
                 (h->low_speed ? OHCI_ED_SPEED_LOW : 0) |
                 ((DWORD)(h->max_packet&0x7ff)<<OHCI_ED_MPS_SHIFT) |
                 OHCI_ED_SKIP;
    carry=h->ed->head&OHCI_ED_HEAD_CARRY;
    h->ed->tail=h->td_phys[tail];
    h->ed->head=h->td_phys[active]|carry;

    td->flags=OHCI_TD_CC_NOT_ACCESSED|OHCI_TD_DI_NONE|OHCI_TD_R|
              OHCI_TD_DP_IN; /* toggle comes from ED carry */
    td->cbp=h->report_phys;
    td->be=h->report_phys+(DWORD)h->report_len-1;
    td->next=h->td_phys[tail];
    __asm__ volatile("" ::: "memory");
    if(publish) h->ed->flags&=~OHCI_ED_SKIP;
}

static void ohci_build_periodic_list(void)
{
    int i,j;
    DWORD head=0;
    OHCI_HID *h;

    for(i=ohci.hid_count-1;i>=0;i--)
    {
        h=&ohci.hid[i];
        h->ed->next=head;
        ohci_arm_hid(h,1);
        h->ed->next=head;
        head=h->ed_phys;
    }
    for(j=0;j<32;j++) ohci.hcca->intr[j]=head;

    if(head)
    {
        ohci_w32(OHCI_REG_CONTROL,
                 (ohci_r32(OHCI_REG_CONTROL)&~OHCI_CTL_HCFS_MASK) |
                 OHCI_CTL_OPERATIONAL|OHCI_CTL_CLE|OHCI_CTL_PLE);
    }
}

static void ohci_register_detected_devices(void)
{
    int i,dnr;
    int have_kbd=0,have_mouse=0;
    for(i=0;i<ohci.hid_count;i++)
    {
        if(ohci.hid[i].protocol==USB_HID_PROTO_KEYBOARD) have_kbd=1;
        if(ohci.hid[i].protocol==USB_HID_PROTO_MOUSE) have_mouse=1;
    }

    if(have_kbd)
    {
        dnr=driver_getdevicenrbyname("usbkbd");
        if(dnr<0) dnr=driver_register_new_device("usbkbd",ohci_controller_device_call,DEVICE_TYPE_CHAR);
        usb_input.keyboard_dnr=dnr;
        /* Detection is not ownership.  Keep PS/2/BIOS keyboard fallback live
         * until usb_hid_boot_keyboard_report() receives a real report. */
    }
    if(have_mouse)
    {
        /* Do not remove ps2mouse: or publish usbmouse: at enumeration time.
         * usb_hid_boot_mouse_report() performs that handoff after the first
         * genuine report.  A detected-but-silent USB endpoint must never
         * disable the working BIOS/PS2 fallback. */
        usb_input.mouse_dnr=-1;
    }
}

static int ohci_controller_start(const PCIDEVICE *d)
{
    PCIBAR bar;
    DWORD pagebase,offset,map;
    DWORD control,fmi,fi,fsmps,rhda;
    int pages,i,power_delay;

    if(pci_get_bar(d,0,&bar)!=0 || !bar.valid || bar.io || bar.is64 || !bar.base_low)
    {
        printk("OHCI: unusable BAR0.\n");
        return 1;
    }
    if(pci_enable_device(d,PCI_ENABLE_MEMORY|PCI_ENABLE_MASTER)!=0)
    {
        printk("OHCI: cannot enable PCI memory/bus mastering.\n");
        return 2;
    }

    pagebase=bar.base_low&~(PAGESIZE-1UL);
    offset=bar.base_low-pagebase;
    pages=(int)((offset+0x1000UL+PAGESIZE-1UL)/PAGESIZE);
    map=pg_mapio((int)(pagebase/PAGESIZE),pages);
    if(!map) return 3;
    ohci.mmio=(volatile BYTE *)(map+offset);
    ohci.mmio_phys=bar.base_low;
    ohci.bus=d->bus; ohci.dev=d->device; ohci.fun=d->function;

    dprintk("OHCI: PCI %d:%d.%d %04x:%04x BAR0=0x%x rev=%x.\n",
           d->bus,d->device,d->function,d->vendor_id,d->device_id,
           bar.base_low,(unsigned)(ohci_r32(OHCI_REG_REVISION)&0xff));

    ohci.dma=(BYTE *)userhw_dma_alloc_kernel32(OHCI_DMA_BYTES,&ohci.dma_phys);
    if(!ohci.dma)
    {
        printk("OHCI: 32-bit bus-master DMA allocation failed (%lu bytes).\n",(DWORD)OHCI_DMA_BYTES);
        return 4;
    }
    dprintk("OHCI: DMA phys=0x%x map=0x%x size=%lu.\n",ohci.dma_phys,(DWORD)ohci.dma,(DWORD)OHCI_DMA_BYTES);
    ohci.hcca=(OHCI_HCCA *)ohci_virt_at(0x000);
    ohci.ctrl_ed=(OHCI_ED *)ohci_virt_at(0x100);
    ohci.ctrl_td[0]=(OHCI_TD *)ohci_virt_at(0x110);
    ohci.ctrl_td[1]=(OHCI_TD *)ohci_virt_at(0x120);
    ohci.ctrl_td[2]=(OHCI_TD *)ohci_virt_at(0x130);
    ohci.ctrl_td[3]=(OHCI_TD *)ohci_virt_at(0x140);
    ohci.setup=(USB_SETUP *)ohci_virt_at(0x200);
    ohci.ctrl_buf=(BYTE *)ohci_virt_at(0x220);

    /* If SMM owns the controller, request native ownership before reset. */
    control=ohci_r32(OHCI_REG_CONTROL);
    dprintk("OHCI: stage 1/5 controller control=0x%x (IR=%d).\n",
           control,(control&OHCI_CTL_IR)?1:0);
    if(control&OHCI_CTL_IR)
    {
        dprintk("OHCI: firmware owns controller; requesting ownership.\n");
        ohci_w32(OHCI_REG_COMMAND_STATUS,OHCI_CMD_OCR);
        for(i=0;i<500;i++)
        {
            if(!(ohci_r32(OHCI_REG_CONTROL)&OHCI_CTL_IR)) break;
            delay(1);
        }
        if(ohci_r32(OHCI_REG_CONTROL)&OHCI_CTL_IR)
        {
            printk("OHCI: firmware ownership handoff timed out.\n");
            return 5;
        }
    }

    fmi=ohci_r32(OHCI_REG_FM_INTERVAL);
    dprintk("OHCI: stage 2/5 host reset begin, FmInterval=0x%x.\n",fmi);
    ohci_w32(OHCI_REG_INTR_DISABLE,0xffffffffUL);
    ohci_w32(OHCI_REG_INTR_STATUS,0xffffffffUL);
    ohci_w32(OHCI_REG_COMMAND_STATUS,OHCI_CMD_HCR);
    if(ohci_wait_clear(OHCI_REG_COMMAND_STATUS,OHCI_CMD_HCR,100))
    {
        printk("OHCI: host controller reset timed out.\n");
        return 6;
    }

    dprintk("OHCI: stage 2/5 host reset complete, CommandStatus=0x%x.\n",
           ohci_r32(OHCI_REG_COMMAND_STATUS));
    dprintk("OHCI: stage 3/5 clearing/programming HCCA DMA.\n");
    memset(ohci.dma,0,OHCI_DMA_BYTES);
    ohci_w32(OHCI_REG_HCCA,ohci.dma_phys);
    ohci_w32(OHCI_REG_CONTROL_HEAD,ohci_phys_at(0x100));
    ohci_w32(OHCI_REG_BULK_HEAD,0);

    fi=fmi&0x3fffUL;
    if(fi<10000 || fi>13000) fi=0x2edfUL;
    fsmps=((fi-210UL)*6UL)/7UL;
    ohci_w32(OHCI_REG_FM_INTERVAL,(fsmps<<16)|fi);
    ohci_w32(OHCI_REG_PERIODIC_START,(fi*9UL)/10UL);
    ohci_w32(OHCI_REG_LS_THRESHOLD,0x628UL);
    ohci_w32(OHCI_REG_CONTROL,OHCI_CTL_OPERATIONAL|OHCI_CTL_CLE);
    dprintk("OHCI: stage 4/5 operational requested, HCCA=0x%x control=0x%x.\n",
           ohci_r32(OHCI_REG_HCCA),ohci_r32(OHCI_REG_CONTROL));
    delay(10);

    rhda=ohci_r32(OHCI_REG_RH_DESC_A);
    dprintk("OHCI: stage 5/5 root hub descriptor A=0x%x.\n",rhda);
    ohci.ports=(int)(rhda&OHCI_RHDA_NDP_MASK);
    if(ohci.ports<1) ohci.ports=1;
    if(ohci.ports>OHCI_MAX_PORTS) ohci.ports=OHCI_MAX_PORTS;

    if(!(rhda&OHCI_RHDA_NPS))
    {
        if(rhda&OHCI_RHDA_PSM)
        {
            for(i=1;i<=ohci.ports;i++) ohci_port_write(i,OHCI_PORT_PPS);
        }
        else
            ohci_w32(OHCI_REG_RH_STATUS,OHCI_RHS_LPSC);
        power_delay=(int)(((rhda>>OHCI_RHDA_POTPGT_SHIFT)&0xffUL)*2UL)+20;
        if(power_delay>520) power_delay=520;
        delay((DWORD)power_delay);
    }
    else delay(20);

    dprintk("OHCI: root hub power settle complete; ports=%d.\n",ohci.ports);
    ohci_w32(OHCI_REG_INTR_DISABLE,0xffffffffUL);
    ohci_w32(OHCI_REG_INTR_STATUS,0xffffffffUL);
    return 0;
}


/* MCP61 exposes the same physical USB ports through an EHCI 2.0 function and
 * an OHCI 1.1 companion.  Firmware may leave PORT_OWNER with EHCI; in that
 * case an OHCI-only HID driver sees no root-hub connection at all.  When the
 * OHCI root hub is empty, hand current ports to the companion without starting
 * an EHCI schedule.  High-speed devices then fall back to USB 1.1, which is
 * sufficient for boot keyboards and mice. */
static int ohci_mcp61_ehci_companion_handoff(void)
{
    const PCIDEVICE *d;
    PCIBAR bar;
    DWORD pagebase,offset,map,hcs,st;
    volatile BYTE *cap;
    volatile BYTE *op;
    int pages,nports,ppc,i,changed=0;
    BYTE caplen;

    d=pci_find_device(NVIDIA_VENDOR_ID,NVIDIA_MCP61_EHCI_ID,0);
    if(!d) return 1;
    if(pci_get_bar(d,0,&bar)!=0 || !bar.valid || bar.io || bar.is64 || !bar.base_low)
        return 2;
    if(pci_enable_device(d,PCI_ENABLE_MEMORY)!=0) return 3;
    pagebase=bar.base_low&~(PAGESIZE-1UL);
    offset=bar.base_low-pagebase;
    pages=(int)((offset+0x1000UL+PAGESIZE-1UL)/PAGESIZE);
    map=pg_mapio((int)(pagebase/PAGESIZE),pages);
    if(!map) return 4;
    cap=(volatile BYTE *)(map+offset);
    caplen=cap[0];
    if(caplen<0x10 || caplen>0x80) return 5;
    hcs=*(volatile DWORD *)(cap+4);
    nports=(int)(hcs&0x0fUL);
    ppc=(hcs&(1UL<<4)) ? 1 : 0;
    if(nports<1 || nports>15) return 6;
    op=cap+caplen;

    dprintk("OHCI: MCP61 EHCI companion handoff, EHCI ports=%d BAR0=0x%x.\n",nports,bar.base_low);
    for(i=0;i<nports;i++)
    {
        volatile DWORD *port=(volatile DWORD *)(op+0x44+i*4);
        st=*port;
        /* Preserve status/control bits, but never echo RW1C change bits. */
        st&=~((1UL<<1)|(1UL<<3)|(1UL<<5));
        if(ppc) st|=(1UL<<12);
        if(!(st&(1UL<<13)))
        {
            st|=(1UL<<13); /* PORT_OWNER -> companion OHCI */
            *port=st;
            changed++;
        }
    }
    if(changed) delay(50);
    dprintk("OHCI: EHCI companion handoff changed %d port(s).\n",changed);
    return 0;
}

static DWORD ohci_connected_bitmap(void)
{
    int i;
    DWORD bitmap=0;

    for(i=1;i<=ohci.ports;i++)
        if(ohci_port_read(i)&OHCI_PORT_CCS)
            bitmap|=(1UL<<(i-1));
    return bitmap;
}

static int ohci_connected_count(void)
{
    DWORD bitmap=ohci_connected_bitmap();
    int n=0;

    while(bitmap)
    {
        n+=(int)(bitmap&1UL);
        bitmap>>=1;
    }
    return n;
}

static void ohci_clear_root_changes(void)
{
    int i;
    DWORD st;

    for(i=1;i<=ohci.ports;i++)
    {
        st=ohci_port_read(i)&OHCI_PORT_CHANGE_MASK;
        if(st) ohci_port_write(i,st);
    }
    ohci_w32(OHCI_REG_INTR_STATUS,OHCI_INTR_RHSC);
}

/* Publish the already-built ED chain without resetting or recycling any TD.
 * This is safe for watchdog recovery: even if HC resumes between MMIO reads,
 * every pointer and buffer it can observe remains live and unchanged. */
static void ohci_republish_periodic_schedule(void)
{
    DWORD head=0,control;
    int i,j;

    for(i=0;i<ohci.hid_count;i++)
        if(ohci.hid[i].used && ohci.hid[i].ed)
        {
            head=ohci.hid[i].ed_phys;
            break;
        }
    for(j=0;j<32;j++) ohci.hcca->intr[j]=head;
    __asm__ volatile("" ::: "memory");
    ohci_w32(OHCI_REG_HCCA,ohci.dma_phys);
    for(i=0;i<ohci.hid_count;i++)
        if(ohci.hid[i].used && ohci.hid[i].ed)
            ohci.hid[i].ed->flags&=~OHCI_ED_SKIP;
    __asm__ volatile("" ::: "memory");

    control=ohci_r32(OHCI_REG_CONTROL);
    control=(control&~OHCI_CTL_HCFS_MASK)|OHCI_CTL_OPERATIONAL|OHCI_CTL_CLE;
    if(head) control|=OHCI_CTL_PLE;
    else control&=~OHCI_CTL_PLE;
    ohci_w32(OHCI_REG_CONTROL,control);
}

static int ohci_stop_periodic(void)
{
    DWORD control;
    int i,j;

    for(i=0;i<ohci.hid_count;i++)
        if(ohci.hid[i].used && ohci.hid[i].ed)
            ohci.hid[i].ed->flags|=OHCI_ED_SKIP;
    __asm__ volatile("" ::: "memory");
    control=ohci_r32(OHCI_REG_CONTROL);
    ohci_w32(OHCI_REG_CONTROL,control&~OHCI_CTL_PLE);
    if((ohci_r32(OHCI_REG_CONTROL)&OHCI_CTL_PLE) ||
       ohci_wait_next_frame(OHCI_PERIODIC_QUIESCE_MS))
    {
        ohci.periodic_quiesce_failures++;
        dprintk("OHCI: periodic-list quiesce deferred; no safe SOF boundary.\n");
        return 1;
    }
    for(j=0;j<32;j++) ohci.hcca->intr[j]=0;
    __asm__ volatile("" ::: "memory");
    return 0;
}

/* Rebuild all root-port devices as one transaction.  This deliberately keeps
 * the controller/DMA allocation alive, but removes every old periodic ED from
 * HCCA before reusing slots.  Re-enumerating the small root hub avoids stale
 * addresses and makes unplug/replug deterministic without a general hub layer. */
static int ohci_reenumerate_root_hub(DWORD new_bitmap)
{
    DWORD st;
    int i,addr=1;

    printk("OHCI: root-hub topology change old=0x%x new=0x%x; rebuilding HID schedule.\n",
           ohci.connected_bitmap,new_bitmap);
    if(ohci_stop_periodic())
    {
        dprintk("OHCI: root-hub rebuild deferred until periodic DMA quiesces.\n");
        ohci_republish_periodic_schedule();
        return 0;
    }
    usb_input_disconnect_all();

    memset(ohci.hid,0,sizeof(ohci.hid));
    ohci.hid_count=0;
    ohci.keyboards=0;
    ohci.mice=0;
    ohci.connected_ports=0;
    ohci.enumerated_devices=0;

    for(i=1;i<=ohci.ports && addr<127;i++)
    {
        st=ohci_port_read(i);
        if(st&OHCI_PORT_CCS)
        {
            ohci.connected_ports++;
            (void)ohci_enumerate_port(i,addr);
            /* SET_ADDRESS may have succeeded even when descriptor parsing or
             * class binding later failed.  Never reuse that address on a
             * second root port during this enumeration pass. */
            addr++;
        }
    }

    if(ohci.hid_count>0)
    {
        ohci_build_periodic_list();
        ohci_register_detected_devices();
    }
    ohci.connected_bitmap=ohci_connected_bitmap();
    ohci.topology_changes++;
    ohci.last_frame_no=(WORD)(ohci_r32(OHCI_REG_FM_NUMBER)&0xffffUL);
    ohci.last_frame_progress_us=PitGetUsec();
    ohci_clear_root_changes();
    return 1;
}

static int ohci_service_root_hub(void)
{
    DWORD now=PitGetUsec();
    DWORD intr=ohci_r32(OHCI_REG_INTR_STATUS);
    DWORD bitmap;
    int i,connection_change=0;

    if(!(intr&OHCI_INTR_RHSC) && ohci.last_topology_poll_us &&
       (DWORD)(now-ohci.last_topology_poll_us)<OHCI_TOPOLOGY_POLL_USEC)
        return 0;

    ohci.last_topology_poll_us=now;
    bitmap=ohci_connected_bitmap();
    if(intr&OHCI_INTR_RHSC)
        for(i=1;i<=ohci.ports;i++)
            if(ohci_port_read(i)&OHCI_PORT_CSC)
                connection_change=1;

    /* CSC matters even if a rapid unplug/replug happened between polls and
     * the final connected bitmap is unchanged: the old USB address and data
     * toggle state still belong to the removed device instance. */
    if(bitmap!=ohci.connected_bitmap || connection_change)
    {
        return ohci_reenumerate_root_hub(bitmap);
    }

    if(intr&OHCI_INTR_RHSC) ohci_clear_root_changes();
    return 0;
}

/* The frame counter must advance while an operational OHCI controller owns a
 * periodic list.  Recover a stopped schedule in process context rather than
 * letting KUSB-HID spin forever on TDs that hardware can no longer reach. */
static void ohci_periodic_watchdog(void)
{
    DWORD now;
    WORD frame;

    if(ohci.hid_count<=0) return;
    now=PitGetUsec();
    frame=(WORD)(ohci_r32(OHCI_REG_FM_NUMBER)&0xffffUL);
    if(!ohci.last_frame_progress_us || frame!=ohci.last_frame_no)
    {
        ohci.last_frame_no=frame;
        ohci.last_frame_progress_us=now;
        return;
    }
    if((DWORD)(now-ohci.last_frame_progress_us)<OHCI_FRAME_STALL_USEC)
        return;

    ohci.frame_stalls++;
    if(ohci.last_schedule_republish_us &&
       (DWORD)(now-ohci.last_schedule_republish_us)<OHCI_RECOVERY_BACKOFF_USEC)
        return;

    dprintk("OHCI: frame counter stalled at %u; republishing live periodic schedule.\n",
           (unsigned)frame);
    ohci_republish_periodic_schedule();
    ohci_w32(OHCI_REG_INTR_STATUS,OHCI_INTR_WDH);
    ohci.schedule_republishes++;
    ohci.last_schedule_republish_us=now;
    ohci.last_frame_progress_us=now;
}

int usb_ohci_init(void)
{
    const PCIDEVICE *d,*cand;
    int i,addr,rv;
    DWORD st;

    if(ohci.initialized) return ohci.ready ? 0 : 1;
    memset(&ohci,0,sizeof(ohci));
    ohci.controller_dnr=-1;
    ohci.initialized=1;

    pci_init();
    d=pci_find_device(NVIDIA_VENDOR_ID,NVIDIA_MCP61_OHCI_ID,0);
    if(!d)
    {
        d=NULL;
        for(i=0;i<pci_get_device_count();i++)
        {
            cand=pci_get_device(i);
            if(cand && cand->class_code==OHCI_CLASS_SERIAL &&
               cand->subclass==OHCI_SUBCLASS_USB && cand->prog_if==OHCI_PROGIF)
            { d=cand; break; }
        }
    }
    if(!d)
    {
        printk("OHCI: no PCI OHCI controller found.\n");
        return 1;
    }

    rv=ohci_controller_start(d);
    if(rv) return rv;
    ohci.ready=1; /* endpoint-zero transfers are now legal */
    usb_input_set_transport_ready(1);
    ohci.controller_dnr=driver_getdevicenrbyname("ohci0");
    if(ohci.controller_dnr<0)
        ohci.controller_dnr=driver_register_new_device("ohci0",ohci_controller_device_call,DEVICE_TYPE_CHAR);

    /* If firmware left the shared MCP61 ports owned by EHCI, explicitly route
     * them to the OHCI companion and give the root hub time to observe them. */
    if(ohci_connected_count()==0 && d->vendor_id==NVIDIA_VENDOR_ID &&
       d->device_id==NVIDIA_MCP61_OHCI_ID)
    {
        (void)ohci_mcp61_ehci_companion_handoff();
        delay(20);
    }

    addr=1;
    for(i=1;i<=ohci.ports && addr<127;i++)
    {
        st=ohci_port_read(i);
        dprintk("OHCI: root port %d status=%x%s.\n",i,st,(st&OHCI_PORT_CCS)?" connected":"");
        if(st&OHCI_PORT_CCS)
        {
            ohci.connected_ports++;
            (void)ohci_enumerate_port(i,addr);
            /* Reserve one address per connected root port even if class
             * binding fails after SET_ADDRESS.  Reusing such an address would
             * make two physical devices answer the next control request. */
            addr++;
        }
    }

    ohci.connected_bitmap=ohci_connected_bitmap();
    ohci_clear_root_changes();
    if(ohci.hid_count>0)
    {
        ohci_build_periodic_list();
        ohci_register_detected_devices();
        ohci.last_frame_no=(WORD)(ohci_r32(OHCI_REG_FM_NUMBER)&0xffffUL);
        ohci.last_frame_progress_us=PitGetUsec();
        delay(20);
        (void)usb_ohci_poll();
    }

    printk("OHCI: ready, ports=%d connected=%d devices=%d HID=%d (kbd=%d mouse=%d).\n",
           ohci.ports,ohci.connected_ports,ohci.enumerated_devices,
           ohci.hid_count,ohci.keyboards,ohci.mice);
    return 0;
}

static int ohci_hid_completed(OHCI_HID *h)
{
    DWORD head,tailphys;
    head=h->ed->head;
    tailphys=h->td_phys[h->td_tail];
    if(head&OHCI_ED_HEAD_HALT) return -1;
    return ((head&~0x0fUL)==tailphys) ? 1 : 0;
}

/* QEMU usb-kbd replaces its PS/2 keyboard.  If the periodic OHCI TD path is
 * silent, there is otherwise no second producer from which SMSH can recover.
 * QEMU's USB HID implementation supports HID GET_REPORT and feeds it from the
 * same keyboard state as endpoint 1, so retain a throttled control request as
 * a maintenance-console safety path.  usb_input.c de-duplicates unchanged
 * reports, which lets periodic interrupt-IN and this fallback coexist.
 *
 * Keep this QEMU-specific.  Physical keyboards use interrupt-IN normally and
 * are not subjected to repeated class control traffic. */
static int ohci_qemu_keyboard_control_rescue(OHCI_HID *h)
{
    BYTE report[OHCI_BOOT_KBD_REPORT_LEN];
    DWORD now,interval,before_events;
    int rv;

    if(!h || h->protocol!=USB_HID_PROTO_KEYBOARD) return 0;
    if(h->vendor!=QEMU_USB_HID_VENDOR || h->product!=QEMU_USB_HID_PRODUCT) return 0;

    now=PitGetUsec();
    interval=h->control_error_streak ? OHCI_QEMU_RETRY_USEC
                                     : OHCI_QEMU_RESCUE_USEC;
    if(h->last_control_poll_us &&
       (DWORD)(now-h->last_control_poll_us)<interval)
        return 0;
    h->last_control_poll_us=now;

    memset(report,0,sizeof(report));
    rv=ohci_control_xfer(h->address,h->low_speed,
                         h->ep0_max_packet ? h->ep0_max_packet : 8,
                         0xA1,USB_HID_GET_REPORT,
                         (WORD)(USB_HID_REPORT_INPUT<<8),
                         h->interface_no,report,sizeof(report),
                         OHCI_CTRL_RESCUE_TIMEOUT_MS);
    if(rv)
    {
        h->control_errors++;
        h->control_error_streak++;
        return 0;
    }

    h->control_error_streak=0;
    h->control_reports++;
    before_events=usb_input.keyboard_events;
    if(usb_hid_boot_keyboard_report(report,sizeof(report))!=0) return 0;
    return usb_input.keyboard_events!=before_events ? 1 : 0;
}

static void ohci_hid_rearm(OHCI_HID *h)
{
    int old_active,old_tail;
    DWORD carry,next;
    old_active=h->td_active;
    old_tail=h->td_tail;
    next=h->ed->next;

    /* OHCI may cache the current periodic ED.  Publish Skip and wait through
     * one frame before recycling its completed TD as the new dummy TD.  The
     * V69.22 immediate rewrite could lose the queue after its first idle
     * report, exactly when its QEMU control rescue also disabled itself. */
    h->ed->flags|=OHCI_ED_SKIP;
    __asm__ volatile("" ::: "memory");
    delay(1);
    carry=h->ed->head&OHCI_ED_HEAD_CARRY;
    h->td_active=old_tail;
    h->td_tail=old_active;
    ohci_arm_hid(h,0);
    h->ed->next=next;
    h->ed->head=(h->ed->head&~OHCI_ED_HEAD_CARRY)|carry;
    __asm__ volatile("" ::: "memory");
    h->ed->flags&=~OHCI_ED_SKIP;
}

int usb_ohci_poll(void)
{
    int i,done,cc,len,events=0;
    OHCI_HID *h;
    OHCI_TD *td;
    DWORD cbp;
    DWORD irqflags;
    static volatile int poll_busy=0;
    if(!ohci.ready) return 0;

    /* Keyboard getch and GraOS mouse service can poll from different tasks.
     * Serialize the shared control ED and periodic TD recycling without
     * sleeping with CPU interrupts disabled. */
    irqflags=get_eflags();
    disable();
    if(poll_busy)
    {
        ohci.poll_contentions++;
        set_eflags(irqflags);
        return 0;
    }
    poll_busy=1;
    set_eflags(irqflags);
    ohci.polls++;

    if(ohci_service_root_hub()) goto out;
    ohci_periodic_watchdog();

    for(i=0;i<ohci.hid_count;i++)
    {
        h=&ohci.hid[i];
        if(!h->used) continue;
        done=ohci_hid_completed(h);
        if(done==0) continue;
        if(done<0)
        {
            h->errors++; ohci.transfer_errors++;
            ohci_hid_rearm(h);
            continue;
        }
        td=h->td[h->td_active];
        cc=ohci_td_cc(td);
        if(cc==OHCI_TD_CC_NOERROR || cc==OHCI_TD_CC_DATAUNDERRUN)
        {
            cbp=td->cbp;
            if(cbp==0) len=h->report_len;
            else if(cbp>=h->report_phys && cbp<=h->report_phys+(DWORD)h->report_len)
                len=(int)(cbp-h->report_phys);
            else len=h->report_len;

            if(h->protocol==USB_HID_PROTO_KEYBOARD)
            {
                if(len>=8) (void)usb_hid_boot_keyboard_report(h->report,len);
            }
            else if(h->protocol==USB_HID_PROTO_MOUSE)
            {
                if(len>=3) (void)usb_hid_boot_mouse_report(h->report,len);
            }
            h->reports++; events++;
        }
        else
        {
            h->errors++; ohci.transfer_errors++;
        }
        ohci_hid_rearm(h);
    }

    /* V69.23 maintenance-console safety net for QEMU usb-kbd. */
    for(i=0;i<ohci.hid_count;i++)
        events+=ohci_qemu_keyboard_control_rescue(&ohci.hid[i]);

out:
    irqflags=get_eflags();
    disable();
    poll_busy=0;
    set_eflags(irqflags);
    return events;
}

int usb_ohci_is_ready(void)
{
    return ohci.ready;
}

void usb_ohci_dump(void)
{
    int i;
    OHCI_HID *h;
    if(!ohci.initialized)
    {
        printk("OHCI: not initialized.\n");
        return;
    }
    printk("OHCI: ready=%d PCI=%d:%d.%d MMIO=0x%x ports=%d connected=%d bitmap=0x%x devices=%d HID=%d polls=%d errors=%d\n",
           ohci.ready,ohci.bus,ohci.dev,ohci.fun,ohci.mmio_phys,
           ohci.ports,ohci.connected_ports,ohci.connected_bitmap,
           ohci.enumerated_devices,
           ohci.hid_count,ohci.polls,ohci.transfer_errors);
    printk("OHCI: contention=%lu control-timeouts=%lu quiesce-fail=%lu/%lu topology=%lu frame-stalls=%lu schedule-republishes=%lu frame=%u\n",
           (unsigned long)ohci.poll_contentions,
           (unsigned long)ohci.control_timeouts,
           (unsigned long)ohci.control_quiesce_failures,
           (unsigned long)ohci.periodic_quiesce_failures,
           (unsigned long)ohci.topology_changes,
           (unsigned long)ohci.frame_stalls,
           (unsigned long)ohci.schedule_republishes,
           (unsigned)(ohci_r32(OHCI_REG_FM_NUMBER)&0xffffUL));
    for(i=0;i<ohci.hid_count;i++)
    {
        h=&ohci.hid[i];
        printk("  USB %s port=%d addr=%d VID:PID=%04x:%04x if=%d ep=%d mps=%d %s reports=%lu errors=%lu ctrl-rescue=%lu/%lu streak=%lu\n",
               h->protocol==USB_HID_PROTO_KEYBOARD?"keyboard":"mouse",
               h->port,h->address,h->vendor,h->product,h->interface_no,
               h->endpoint,h->max_packet,h->low_speed?"low-speed":"full-speed",
               (unsigned long)h->reports,(unsigned long)h->errors,
               (unsigned long)h->control_reports,(unsigned long)h->control_errors,
               (unsigned long)h->control_error_streak);
    }
}
