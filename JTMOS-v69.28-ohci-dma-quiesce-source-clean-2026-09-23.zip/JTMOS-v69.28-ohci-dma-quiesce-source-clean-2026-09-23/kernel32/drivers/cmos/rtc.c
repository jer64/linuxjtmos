/**************************************************************
 * RTC - JTMOS Real Time Clock Functions - Part of CMOS driver.
 * (C) 2002-2003 by Jari Tuominen(jari@vunet.org)
 */

//
#include "kernel32.h"
#include "rtc.h"

//
RTCSTR rtcstr;
static int last_known_seconds=0,tm=0,tm2=0;

// Wrapper which is easier to remember
int GetSeconds(void)
{
	//
	return rtc_getseconds();
}

//

/*
 * Read a stable wall-clock second-of-day directly from MC146818-compatible
 * CMOS.  This helper is intentionally allocation/lock/scheduler free and is
 * safe to call from the NMI watchdog.  cmos_read() masks NMI only across each
 * individual selector/data transaction, so an NMI cannot corrupt another
 * CMOS access while still allowing this routine itself to run from vector 2.
 */
int rtc_getseconds_of_day_atomic(DWORD *seconds)
{
    int tries;

    if(seconds==NULL) return -1;
    for(tries=0;tries<4;tries++)
    {
        int sec1,sec2,min,hour,status_b;
        int pm=0;

        if(cmos_read(0x0A)&0x80) continue;
        sec1=cmos_read(0x00);
        min=cmos_read(0x02);
        hour=cmos_read(0x04);
        status_b=cmos_read(0x0B);
        sec2=cmos_read(0x00);
        if((cmos_read(0x0A)&0x80) || sec1!=sec2) continue;

        /* Status-B bit 2: 1=binary, 0=BCD. Bit 1: 1=24h, 0=12h. */
        if(!(status_b&0x04))
        {
            int h=hour&0x7f;
            BCD_TO_BIN(sec1);
            BCD_TO_BIN(min);
            BCD_TO_BIN(h);
            pm=hour&0x80;
            hour=h;
        }
        else
        {
            pm=hour&0x80;
            hour&=0x7f;
        }
        if(!(status_b&0x02))
        {
            if(hour==12) hour=0;
            if(pm) hour+=12;
        }
        if(sec1<0 || sec1>59 || min<0 || min>59 || hour<0 || hour>23)
            continue;
        *seconds=(DWORD)(hour*3600+min*60+sec1);
        return 0;
    }
    return -1;
}

int rtc_getseconds(void)
{
	static int flags,tick;
	static DATE d;

	// Decrease infinite loop preventer timer
	tm2--;
	//
	if( tm==0 || (GetTickCount()-tm)>=500 || tm2<=0 )
	{
		// Set values
		tm = GetTickCount();
		// Time-out to prevent infinite loops
		tm2 = 10000;

		// Receive new seconds count without leaking the caller IF state.
		flags=get_eflags();
		disable();
		rtc_getdate(&d);
		tick = d.hour*60*60 + d.minute*60 + d.second;
		set_eflags(flags);
		last_known_seconds = tick;
		return tick;
	}
	else
	{
		// Not enough time has passed, we return the old seconds.
		return last_known_seconds;
	}
}

//
int rtc_readreg(int which)
{
    return cmos_read(which);
}

//
void rtc_writereg(int which, int what)
{
    cmos_write(which,what);
}

//
int rtc_getsecond(void)
{
	//
	return rtc_readreg(0);
}

static int rtc_deadline_read_stable_second(int *second)
{
	int a,b;

	if(second==NULL) return FALSE;
	/* Do not count a value sampled while the RTC is updating its calendar. */
	if(rtc_readreg(0x0A)&0x80) return FALSE;
	a=rtc_getsecond();
	if(rtc_readreg(0x0A)&0x80) return FALSE;
	b=rtc_getsecond();
	if(a!=b) return FALSE;
	*second=b;
	return TRUE;
}

/*
 * Start/poll a deadline using the raw CMOS seconds byte.  Keeping the value
 * raw (normally packed BCD) is deliberate: for a deadline we only need to
 * know that the hardware seconds register changed.  0x59 -> 0x00 therefore
 * counts as exactly one transition, as desired.
 *
 * cmos_read() makes each 70h/71h selector/data transaction interrupt-atomic,
 * so callers may poll this from lock wait loops without relying on PIT ticks.
 */
void rtc_second_deadline_start(RTC_SECOND_DEADLINE *deadline)
{
	int second;

	if(deadline==NULL) return;
	if(!rtc_deadline_read_stable_second(&second))
		second=rtc_getsecond();
	deadline->last_raw_second=second;
	deadline->transitions=0;
}

int rtc_second_deadline_poll(RTC_SECOND_DEADLINE *deadline,
				     unsigned int transition_limit)
{
	int second;

	if(deadline==NULL || transition_limit==0) return TRUE;
	if(!rtc_deadline_read_stable_second(&second)) return FALSE;
	if(second!=deadline->last_raw_second)
	{
		deadline->last_raw_second=second;
		if(deadline->transitions<0xffffffffU)
			deadline->transitions++;
	}
	return deadline->transitions>=transition_limit ? TRUE : FALSE;
}

void rtc_io_deadline_start(RTC_IO_DEADLINE *deadline, DWORD timeout_ms,
                           unsigned int rtc_timeout_seconds,
                           unsigned long poll_limit)
{
	if(deadline==NULL) return;
	deadline->pit_start=GetTickCount();
	deadline->pit_timeout_ms=timeout_ms;
	deadline->rtc_timeout_seconds=rtc_timeout_seconds;
	deadline->polls=0;
	deadline->poll_limit=poll_limit ? poll_limit : 1UL;
	rtc_second_deadline_start(&deadline->rtc);
}

int rtc_io_deadline_expired(RTC_IO_DEADLINE *deadline)
{
	DWORD now;

	if(deadline==NULL) return TRUE;
	if(deadline->polls < 0xffffffffUL) deadline->polls++;

	/* Normal fast path: PIT based milliseconds. */
	now=GetTickCount();
	if(deadline->pit_timeout_ms &&
	   (DWORD)(now-deadline->pit_start)>=deadline->pit_timeout_ms)
		return TRUE;

	/* Independent hard wall: direct CMOS second transitions.  Sampling CMOS on
	 * every tight port-poll iteration is unnecessarily expensive; every 256th
	 * poll is still vastly faster than the one-second hardware granularity. */
	if(deadline->rtc_timeout_seconds &&
	   (deadline->polls==1UL || (deadline->polls&0xffUL)==0UL) &&
	   rtc_second_deadline_poll(&deadline->rtc,deadline->rtc_timeout_seconds))
		return TRUE;

	/* Last resort for dead PIT + dead/non-PC RTC. */
	if(deadline->polls>=deadline->poll_limit) return TRUE;
	return FALSE;
}

//
int rtc_getminute(void)
{
	//
	return rtc_readreg(2);
}

//
int rtc_gethour(void)
{
	//
	return rtc_readreg(4);
}

//
int rtc_getday(void)
{
	//
	return rtc_readreg(7);
}

//
int rtc_getmonth(void)
{
	//
	return rtc_readreg(6);
}

//
int rtc_getyear(void)
{
	//
	return rtc_readreg(9);
}

//
void rtc_busyWait(void)
{
	unsigned long loops;
	int flags;

	/* RTC update-in-progress normally clears in < 2 ms.  Keep this bounded so
	 * a broken/emulated CMOS cannot wedge the kernel forever. */
	flags = get_eflags();
	for(loops=0; loops<10000UL; loops++)
	{
		if(!(rtc_readreg(0xA)&0x80))
			return;

		if(Multitasking && !PitStorageSafeActive() && (flags & 0x200) &&
		   ((loops & 0x3FFUL)==0))
			SwitchToThread();
	}

	dprintk("rtc_busyWait: CMOS update-in-progress timeout.\n");
}

//
void rtc_getdate(DATE *d)
{
	static int flags;

	// Wait until time is available
	rtc_busyWait();

	//
	flags = get_eflags(); disable();

	// Receive
	d->second =	rtc_getsecond();
	d->minute =	rtc_getminute();
	d->hour =	rtc_gethour();
	d->day = 	rtc_getday();
	d->month =	rtc_getmonth();
	d->year =	rtc_getyear();
	// Convert
	BCD_TO_BIN(d->second);
	BCD_TO_BIN(d->minute);
	BCD_TO_BIN(d->hour);
	BCD_TO_BIN(d->day);
	BCD_TO_BIN(d->month);
	BCD_TO_BIN(d->year);
	//
	set_eflags(flags);
}


