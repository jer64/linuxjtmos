// ===========================================================
// RS232 - SERIAL PORT DRIVER FOR COM1, COM2, COM3, COM4, ETC.
//
// (C) 2002-2008 by Jari Tuominen(jari@vunet.org)
//        SEE HELPPC FOR EXCELLENT UART DOCUMENTATION!
// Added interrupt functionallity and FIFO buffer.
//
// SERIAL MOUSE DRIVER MUST BE DISABLED BEFORE USING
// THE SERIAL PORT FOR OTHER PURPOSES.
// ===========================================================
/*
	Valid legacy PC I/O addresses for serial ports are(in std. order):
	COM1=0x3F8, COM2=0x2F8, COM3=0x3E8, COM4=0x2E8

	(Add to base I/O, base can be e.g. 0x3F8)
	+0	W	Transmitter Holding Buffer
		R	Receiver Buffer
		RW	Divisor latch low byte
	+1	RW	Interrupt Enable Register
		RW	Divisor Latch High Byte
	+2	R	Interrupt Identification Register
		W	FIFO Control Register
	+3	RW	Line Control Register
	+4	RW	Modem Control register
	+5	R	Line Status Register
	+6	R	Modem Status Register
	+7	RW	Scratch Register
 */
//
#include "basdef.h"
#include "sysmem.h"
#include "kernel32.h"
//
#include "driver_sys.h" // driver_register_new_device, ...
#include "driver_api.h" // readblock,writeblock,getsize,getblocksize, ...
#include "zero.h"
#include "buffer.h" // FBUF
//
#include "serial.h"
#include "serial_dev.h"
#include "scheduler.h"

// Serial driver is initialized ?
int serialInitialized=FALSE;
int primitiveSerial=FALSE;

//----------------------------------------------------------------
// Buffers for COM1 and COM2
FBUF comportR[4]; // incoming data buffer(read)
FBUF comportW[4]; // outcoming data buffer(write)
// Serial flusher thread(serial thread)
THREAD SerialThread;
// Serial port I/O configuration
SERIALPORT serialport[8];
int serial_owner[4] = { SERIAL_OWNER_NONE, SERIAL_OWNER_NONE, SERIAL_OWNER_NONE, SERIAL_OWNER_NONE };
DWORD serial_rx_dropped[4] = { 0,0,0,0 };
DWORD serial_hw_overrun[4] = { 0,0,0,0 };
DWORD serial_hw_framing[4] = { 0,0,0,0 };
DWORD serial_hw_parity[4] = { 0,0,0,0 };
DWORD serial_hw_break[4] = { 0,0,0,0 };

static int serial_valid_port(int portnr)
{
	return portnr>=0 && portnr<4;
}

/* A missing legacy I/O port normally reads as 0xff.  Do not put such a
 * phantom UART on a shared IRQ service list: interpreting 0xff as LSR would
 * make every status bit look asserted and can keep the IRQ handler spinning.
 * The scratch-register test identifies 16450/16550-class UARTs; a BIOS-listed
 * older UART is still accepted when its LSR responds with something other
 * than 0xff. */
static int serial_probe_uart(int base, int bios_listed)
{
	int lsr,old,v1,v2;
	if(!base) return 0;
	lsr=inportb(base+SERIAL_LINE_STATUS);
	if(lsr==0xFF) return 0;

	old=inportb(base+SERIAL_SCRATCH_REGISTER);
	outportb(base+SERIAL_SCRATCH_REGISTER,0x55);
	v1=inportb(base+SERIAL_SCRATCH_REGISTER);
	outportb(base+SERIAL_SCRATCH_REGISTER,0xAA);
	v2=inportb(base+SERIAL_SCRATCH_REGISTER);
	outportb(base+SERIAL_SCRATCH_REGISTER,old);
	if(v1==0x55 && v2==0xAA) return 1;
	return bios_listed ? 1 : 0;
}

const char *serial_owner_name(int owner)
{
	switch(owner)
	{
		case SERIAL_OWNER_DEBUG: return "debug";
		case SERIAL_OWNER_SLIP: return "SLIP";
		case SERIAL_OWNER_SERMOUSE: return "serial mouse";
		case SERIAL_OWNER_KERNEL: return "kernel";
		case SERIAL_OWNER_USER: return "user";
	}
	return "free";
}

int serial_get_owner(int portnr)
{
	if(!serial_valid_port(portnr)) return -1;
	return serial_owner[portnr];
}

int serial_claim_port(int portnr, int owner)
{
	int flags,rv;
	if(!serial_valid_port(portnr) || owner==SERIAL_OWNER_NONE) return 1;
	if(serialInitialized && !serialport[portnr].isWorking) return 2;
	flags=get_eflags(); disable();
	if(serial_owner[portnr]==SERIAL_OWNER_NONE || serial_owner[portnr]==owner)
	{
		serial_owner[portnr]=owner;
		rv=0;
	}
	else rv=1;
	set_eflags(flags);
	return rv;
}

int serial_release_port(int portnr, int owner)
{
	int flags,rv;
	if(!serial_valid_port(portnr)) return 1;
	flags=get_eflags(); disable();
	if(serial_owner[portnr]==owner)
	{
		serial_owner[portnr]=SERIAL_OWNER_NONE;
		rv=0;
	}
	else rv=1;
	set_eflags(flags);
	return rv;
}
/*
	COM1	0x3F8
	COM2	0x2F8
	COM3	0x3E8
	COM4	0x2E8

// Interrupt Enable Register            =====> I don't understand sense of
RCV,XMT,LS,MS, these terms do not appear in the documentation of my chips
specification in the "Interrupt Enable Register" Options
#define IER_RCV 0x01
#define IER_XMT 0x02
#define IER_LS  0x04
#define IER_MS  0x08
*/

//
int bios_serial_ports=0;
int sline_speed[10]={0};

// Creates serial thread.
void init_SerialThread(void)
{
        //
        if(ThreadCreateStack(&SerialThread,JTMOS_MIN_DYNAMIC_STACK)!=0)
        { printk("KSERIALIO: stack allocation failed.\n"); return; }
        SerialThread.pid=create_thread(SerialThread.stack,SerialThread.l_stack,SerialThreadProgram);
        if(SerialThread.pid<=0)
        { ThreadDestroyStack(&SerialThread); printk("KSERIALIO: thread creation failed.\n"); return; }
        IdentifyThread(SerialThread.pid,"KSERIALIO");
}

// Serial port write flusher(serial thread).
void SerialThreadProgram(void)
{
	int i,d1,work;

	/* V68.175: KSERIALIO used to remain runnable forever and perform one
	 * voluntary yield per empty scan.  That prevents CPU_IDLE/HLT from owning
	 * truly idle periods.  Sleep 10 ms when all TX queues are empty; only
	 * cooperate after actual bytes were flushed. */
	while(1)
	{
		work=0;
		for(i=0; i<4; i++)
		{
			if(!serialport[i].isWorking) continue;
			while((d1=GetBuffer(&comportW[i]))!=-1)
			{
				serial_put1(serialport[i].ad,d1);
				work++;
			}
		}
		if(work) SchedulerCooperate();
		else SchedulerWaitPause(10000UL);
	}
}

//----------------------------------------------------------------------------------------------
/* Drain one UART receiver. After serial_init() this is the only place that
 * reads the UART receiver register. This prevents polling consumers from
 * stealing bytes from SLIP or a serial mouse. */
static void serial_drain_rx(int whichport)
{
	int base,guard,lsr,d1;
	if(!serial_valid_port(whichport)) return;
	if(!serialport[whichport].isWorking) return;
	base=serialport[whichport].ad;
	if(!base) return;

	for(guard=0; guard<256; guard++)
	{
		lsr=inportb(base+SERIAL_LINE_STATUS);
		if(lsr==0xFF) break; /* absent/floating UART must not look data-ready */
		/* Do not printk from IRQ context. Count UART errors so a lost-byte
		 * diagnosis can distinguish hardware FIFO overruns from software FIFO
		 * overflow. */
		if(lsr&0x02) serial_hw_overrun[whichport]++;
		if(lsr&0x04) serial_hw_parity[whichport]++;
		if(lsr&0x08) serial_hw_framing[whichport]++;
		if(lsr&0x10) serial_hw_break[whichport]++;
		if(!(lsr&1)) break;
		d1=inportb(base+SERIAL_RECBUF);
		if(PutBuffer(&comportR[whichport], d1)!=0)
			serial_rx_dropped[whichport]++;
	}
}

// IRQ4 is shared by COM1 and COM3.
void serial_irqhandler4(void)
{
	serial_drain_rx(0);
	serial_drain_rx(2);
	pic_send_eoi(4);
}

// IRQ3 is shared by COM2 and COM4.
void serial_irqhandler3(void)
{
	serial_drain_rx(1);
	serial_drain_rx(3);
	pic_send_eoi(3);
}

void serial_handlerirq(int whichport)
{
	serial_drain_rx(whichport);
}

// TODO
void serial_biosdetect(void)
{
	int *p JTM_UNUSED;
	int i,i2 JTM_UNUSED,i3 JTM_UNUSED,i4 JTM_UNUSED;

	//
	p=(int *)0x00000400UL;

	//
	for(i=0; i<4; i++)
	{
		//
	}
}

// Get specified serial line current speed
// (in bps)
int GetSerialLineSpeed(int nCom)
{
	return sline_speed[nCom];
}

// Set specified serial line speed (in bps) for an exclusive owner.
int SetSerialPortSpeedOwned(int nCom, int bps, int owner)
{
	int flags;
	if(!serial_valid_port(nCom) || bps<=0) return 1;
	if(serialInitialized && !serialport[nCom].isWorking) return 3;
	if(serial_owner[nCom]!=SERIAL_OWNER_NONE && serial_owner[nCom]!=owner) return 2;

	/* V68.166: callers may now enter with IF=1.  DLAB changes the meaning of
	 * UART registers 0/1, so the divisor + LCR/FIFO/MCR transaction itself must
	 * remain atomic against the managed serial IRQ handler. */
	flags=get_eflags();
	disable();
	sline_speed[nCom]=bps;
	/* DTR + RTS + OUT2. OUT2 gates the UART IRQ to the PC PIC. */
	init_serial_portEx(serialport[nCom].ad, bps, 0x03, DEF_SERFIFO, 0x0B);
	set_eflags(flags);
	return 0;
}

void SetSerialPortSpeed(int nCom, int bps)
{
	(void)SetSerialPortSpeedOwned(nCom,bps,SERIAL_OWNER_NONE);
}

// init_serial_portEx(ad, 0x01, 0x03, DEF_SERFIFO, 0x0b);
void init_serial_portEx(DWORD ad, int baudRate, 
			int transferType, int fifoSettings, int misc1)
{
	//------------------------------------------------------
	// SET DLAB ON (change higher registers)
	outportb(ad+3, 0x80);
	// Set Baud rate - Divisor Latch Low Byte
	//outportb(ad+0, SERIAL_9600BPS);
	outportb(ad+0, 1843200 / (baudRate * 16));
	// Set Baud rate - Divisor Latch High Byte
 	outportb(ad+1, 0x00);
 	// We get DLAB back here, and set transfer type:
	outportb(ad+3, transferType); 
 	//   Port 3FA - 16550 FIFO Control Register - FCR  (write only)
	// 
	// .7.6.5.4.3.2.1.0.  2FA, 3FA  FIFO Control Register
	//  . . . . . . . ..... 1 = enable clear XMIT and RCVR FIFO queues
	//  . . . . . . ...... 1 = clear RCVR FIFO
	//  . . . . . ....... 1 = clear XMIT FIFO
	//  . . . . ........ 1 = change RXRDY & TXRDY pins from mode 0 to mode 1
	//  . . ........... reserved (zero)
	//  .............. trigger level for RCVR FIFO interrupt
	// 
	// Bits      RCVR FIFO
	//  76     Trigger Level
	//  00        1 byte
	//  01        4 bytes
	//  10        8 bytes
	//  11       14 bytes
	// FIFO Control Register
	outportb(ad+2, fifoSettings);
	//  Turn on DTR, RTS, and OUT2
	// |7|6|5|4|3|2|1|0|  2FC, 3FC  Modem Control Register
	//  | | | | | | | `---- 1 = activate DTR
	//  | | | | | | `----- 1 = activate RTS
	//  | | | | | `------ OUT1
	//  | | | | `------- OUT2
	//  | | | `-------- 0 = normal, 1 = loop back test
	//  `------------- reserved (zero)
	outportb(ad+4, misc1);
	// Turn ON/OFF interrupts
	// .7.6.5.4.3.2.1.0.  2F9, 3F9: Interrupt Enable Register
	//  . . . . . . . ..... 1 = enable data available int (and 16550 Timeout)
	//  . . . . . . ...... 1 = enable THRE interrupt
	//  . . . . . ....... 1 = enable lines status interrupt
	//  . . . . ........ 1 = enable modem-status-change interrupt
	//  ............... reserved (zero)
	// 
	// - 16550 will interrupt if data exists in the FIFO and isn't read
	//   within the time it takes to receive four bytes or if no data is
	//   received within the time it takes to receive four bytes.
	outportb(ad+1, 1); // 1 = Enable data available int
}

// [PORT ADDRESS] [WHICH COM PORT]
void init_serial_port(DWORD ad, int which)
{
	if(!ad)
	{
		serialport[which].isWorking=FALSE;
		return;
	}
	// Port address, Baud rate.
	// [8 Bits, No Parity, 1 Stop Bit], FIFO, [DTR, RTS, OUT2]
	init_serial_portEx(ad, SERIAL_LINESPEED_BPS, 0x03, DEF_SERFIFO, 0x0B);

	// Init buffer, 16K space.
	CreateBuffer(&comportR[which], 1024*64); // incoming: ~5.5 s at 115200 bps
	CreateBuffer(&comportW[which], 1024*16); // outcoming
	serialport[which].isWorking = (comportR[which].buf!=NULL && comportW[which].buf!=NULL);
}

// Setup IRQ handler
void serialSetupIRQ(void)
{
	// Setup handler for IRQ4 (COM1/COM3)
	setint(M_VEC+4,
		serial_asmirqhandler4,
		GIMMIE_CS(),
		D_PRESENT + D_INT);
	enable_irq(4);

	// Setup handler for IRQ3 (COM2/COM4)
	setint(M_VEC+3,
		serial_asmirqhandler3,
		GIMMIE_CS(),
		D_PRESENT + D_INT);
	enable_irq(3);
}

// Define serial port addresses
// (using defaults, may not be these always!!)
void serial_init1(void)
{
	/* Use each BIOS Data Area COM entry independently.  Some BIOSes expose
	 * COM1 while leaving COM2..COM4 zero, so testing COM1 alone is not
	 * sufficient.  Fall back to the conventional IBM-PC layout. */
	{
		int cand[4];
		int listed[4];
		int i;
		listed[0]=(bios_data.com1_addr!=0);
		listed[1]=(bios_data.com2_addr!=0);
		listed[2]=(bios_data.com3_addr!=0);
		listed[3]=(bios_data.com4_addr!=0);
		cand[0]=listed[0] ? bios_data.com1_addr : 0x03F8;
		cand[1]=listed[1] ? bios_data.com2_addr : 0x02F8;
		cand[2]=listed[2] ? bios_data.com3_addr : 0x03E8;
		cand[3]=listed[3] ? bios_data.com4_addr : 0x02E8;

		for(i=0;i<4;i++)
			serialport[i].ad=serial_probe_uart(cand[i],listed[i]) ? cand[i] : 0;
	}
	serialport[0].irq = 4;
	serialport[1].irq = 3;
	serialport[2].irq = 4;
	serialport[3].irq = 3;

	// Declare primitive serial functions functional
	primitiveSerial = TRUE;
}

// Init port settings, buffers, install IRQ handler, etc.
void serial_init(void)
{
	//--------------------------------------------------------------------------------------
	/* serial_init() is called from both InitSystem() and historical hwdet().
	 * Reprogramming an active 16550 writes the FCR clear bits and recreating
	 * FBUF queues discards queued bytes.  Initialization must therefore be
	 * strictly idempotent. */
	if(serialInitialized)
	{
		return;
	}

	//--------------------------------------------------------------------------------------
	//
	printk("serial.c - Serial Port UART Management Driver\n");
	serial_init1();
	if(Multitasking)
		serial_register_device();
	serial_biosdetect();

	//
	init_serial_port( serialport[0].ad, 0 );
	init_serial_port( serialport[1].ad, 1 );
	init_serial_port( serialport[2].ad, 2 );
	init_serial_port( serialport[3].ad, 3 );

	/* All per-port FIFOs now exist. Mark the managed driver live before IRQs
	 * can expose it to clients. */
	serialInitialized = TRUE;

	/* Reserve the configured debug UART once the managed serial driver exists.
	 * Explicit consumers (SLIP/serial mouse) must resolve this conflict before
	 * taking the line. */
	if(serial_debug_line>=0 && serial_debug_line<4)
		(void)serial_claim_port(serial_debug_line,SERIAL_OWNER_DEBUG);

	// Setup IRQ-handler
	if(Multitasking)
		serialSetupIRQ();

	//	
	printk("Serial I/O configuration: COM1=%x, COM2=%x, COM3=%x, COM4=%x\n",
		serialport[0].ad, serialport[1].ad,
		serialport[2].ad, serialport[3].ad);

	// Start serial port flusher thread
	// (recommended to be done as last thing on the init)
	if(Multitasking)
		init_SerialThread();
}

// Zero:	Success
// Non-zero:	Failure(TIMEOUT)
int serial_wait_ctsend(int base)
{
	//
	int i JTM_UNUSED,i2;

	//
	for(i2=0; ; i2++)
	{
		// Check "Clear to Send" from modem status
		if( (inportb(base+SERIAL_MODEM_STATUS)&16) )return 0;

		// CPU usage moderator
		if(i2>SERIAL_CPUMODER){ SwitchToThread(); i2=0; }
	}
	return 1;
}

//
void serial_print_out_status_on_error(int base)
{
/*
Overrun Error

An "overrun error" occurs when the UART cannot process the character that just came in before the next one arrives. Various UART devices have 
differing amounts of buffer space to hold received characters. The CPU must service the UART in order to remove characters from the buffer. If the CPU 
does not service the UART quickly enough and the buffer becomes full, an Overrun Error will occur.

Framing Error

A "framing error" occurs when the designated "start" and "stop" bits are not valid. As the "start" bit is used to identify the beginning of an 
incoming character, it acts as a reference for the remaining bits. If the data line is not in the expected idle state when the "stop" bit is expected, 
a 'a'Framing Error will occur.

Parity Error

A "parity error" occurs when the number of "active" bits does not agree with the specified parity configuration of the UART, producing a Parity Error. 
Because the "parity" bit is optional, this error will not occur if parity has been disabled. Parity error is set when the parity of an incoming data 
character does not match the expected value.

Break Condition

A "break condition" occurs when the receiver input is in at the "space" level for longer than some duration of time, typically, for more than a 
character time. This is not necessarily an error, but appears to the receiver as a character of all zero bits with a framing error.

Some equipment will deliberately transmit the "break" level for longer than a character as an out-of-band signal. When signalling rates are 
mismatched, no meaningful characters can be sent, but a long "break" signal can be a useful way to get the attention of a mismatched receiver to do 
something (such as resetting itself. UNIX systems and UNIX-like systems such as Linux can use the long "break" level as a request to change the 
signalling rate.

	|7|6|5|4|3|2|1|0|  2FD, 3FD Line Status Register
1	 | | | | | | | `---- 1 = data ready
2	 | | | | | | `----- 1 = overrun error (OE)
4	 | | | | | `------ 1 = parity error (PE)
8	 | | | | `------- 1 = framing error (FE)
16	 | | | `-------- 1 = break interrupt  (BI)
32	 | | `--------- 1 = transmitter holding register empty (THRE)
64	 | `---------- 1 = transmitter shift register empty (TSRE)
128	 `----------- 1 = 16550 PE/FE/Break in FIFO queue, 0 for 8250 & 16450
*/

	//
	if( (inportb(base+SERIAL_LINE_STATUS)&8) )
	{
		printk("%s: framing error\n", __FILE__);
	}

	//
	if( (inportb(base+SERIAL_LINE_STATUS)&4) )
	{
		printk("%s: parity error\n", __FILE__);
	}

	//
	if( (inportb(base+SERIAL_LINE_STATUS)&2) )
	{
		printk("%s: overrun error\n", __FILE__);
	}

	//
}

//
int serial_wait_transmitter(int base)
{
	int i2;
	RTC_IO_DEADLINE deadline;

	rtc_io_deadline_start(&deadline,1000UL,2U,50000000UL);
	for(i2=0; !rtc_io_deadline_expired(&deadline); i2++)
	{
		// Wait until "Empty Transmitter Holding Register" is non-zero.
		if( (inportb(base+SERIAL_LINE_STATUS)&32) )return 0;

		//
		serial_print_out_status_on_error(base);

		// CPU usage moderator
		if(i2>SERIAL_CPUMODER){SwitchToThread(); i2=0;}
	}
	return 1;
}

//
int serial_directget(int i)
{
	if(!serial_valid_port(i)) return -1;
	/* Once IRQ buffering is active, never bypass it by reading RBR directly. */
	if(serialInitialized && Multitasking) return serial_get(i);
	return serial_get1(serialport[i].ad);
}

int serial_directput(int i, int d1)
{
	if(!serial_valid_port(i)) return 1;
	if(serialInitialized && Multitasking) return serial_put(i,d1);
	return serial_put1(serialport[i].ad, d1);
}

// TEMP FUNC
int serial_put1(int base, int c)
{
	int x;
	RTC_IO_DEADLINE deadline;
	static int write_counter JTM_UNUSED = 0;

	//
	if(!primitiveSerial)
		return 0;

	// Loop until ready, but never let a dead UART wedge boot/debug output.
	rtc_io_deadline_start(&deadline,1000UL,2U,50000000UL);
	for(x=0; (inportb(base+5)&0x20)==0; x++)
	{
		if(rtc_io_deadline_expired(&deadline)) return 1;
		//
		if(x>100000)
		{
			//
			x=0;
			
			//SwitchToThread();
		}
	}
	outportb(base, c);

	//
	return 0;
}

// Zero		OK
// Non-zero	Failure
int serial_put2(int base, int c)
{
	int tries,rv;

	for(tries=0,rv=0; tries<2; tries++)
	{
		// Wait until ready, if ok => Send.
		if( !serial_wait_ctsend(base) )
		{
			if( !serial_wait_transmitter(base) )
			{
				outportb(base, c);
				return 0;
			}
			else rv=1;
		}
		else
			rv=1;
	}
	return rv;
}

// Returns -1 if no data available.
int serial_get1(int base)
{
	DWORD x JTM_UNUSED;

	/* Legacy polling helper is early-boot only.  Once the managed UART driver
	 * is live, the IRQ handler exclusively owns RBR reads. */
	if(serialInitialized) return -1;

	// Do we have data available?
	if( (inportb(base+5)&1) )
		// Yes data
		return inportb(base);
	else
		// No data
		return -1;
}

// Owner-aware FIFO access. Hardware RX is serviced only by the IRQ handler.
int serial_put_owned(int portnr, int c, int owner)
{
	if(!serial_valid_port(portnr)) return 2;
	if(!serialport[portnr].isWorking) return 4;
	if(serial_owner[portnr]!=SERIAL_OWNER_NONE && serial_owner[portnr]!=owner) return 3;
	return PutBuffer(&comportW[portnr],c);
}

int serial_get_owned(int portnr, int owner)
{
	if(!serial_valid_port(portnr)) return -1;
	if(!serialport[portnr].isWorking) return -1;
	if(serial_owner[portnr]!=SERIAL_OWNER_NONE && serial_owner[portnr]!=owner) return -1;
	return GetBuffer(&comportR[portnr]);
}

int serial_put(int portnr, int c)
{
	/* Generic kernel/userspace serial I/O is only legal on an unclaimed line. */
	return serial_put_owned(portnr&3,c,SERIAL_OWNER_NONE);
}

int serial_get(int portnr)
{
	return serial_get_owned(portnr&3,SERIAL_OWNER_NONE);
}

//
void serial_puts(int portnr, const char *s)
{
	//
	int i,l;

	//
	l = strlen(s);
	for(i=0; i<l; i++)
	{
		serial_put(portnr, s[i]);
	}
}

// Returns zero on success, non-zero on timeout.
int WaitSerialStringTimeoutOwned(int portNr, const char *strLogin, DWORD timeout_ms, int owner)
{
	int matched,wanted,ch;
	RTC_IO_DEADLINE deadline;

	if(strLogin==NULL || strLogin[0]==0) return 0;
	if(!serial_valid_port(portNr)) return 1;
	wanted=strlen(strLogin);
	matched=0;
	rtc_io_deadline_start(&deadline,timeout_ms,
		(unsigned int)(timeout_ms/1000UL)+2U,100000000UL);

	while(!rtc_io_deadline_expired(&deadline))
	{
		ch=serial_get_owned(portNr,owner);
		if(ch==-1)
		{
			SwitchToThread();
			continue;
		}
		if(ch==(BYTE)strLogin[matched]) matched++;
		else matched=(ch==(BYTE)strLogin[0]) ? 1 : 0;
		if(matched>=wanted) return 0;
	}
	return 1;
}

int WaitSerialStringTimeout(int portNr, const char *strLogin, DWORD timeout_ms)
{
	return WaitSerialStringTimeoutOwned(portNr,strLogin,timeout_ms,SERIAL_OWNER_NONE);
}

int WaitSerialString(int portNr, const char *strLogin)
{
	return WaitSerialStringTimeout(portNr,strLogin,4000);
}

//

