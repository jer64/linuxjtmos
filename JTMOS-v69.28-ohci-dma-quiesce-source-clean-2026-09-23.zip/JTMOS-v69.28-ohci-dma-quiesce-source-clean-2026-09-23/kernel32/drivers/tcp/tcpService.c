//=====================================================================
// TCP Service Function
// (C) 2003 by Jari Tuominen
//=====================================================================
#include <stdio.h>
#include <jtmos/dcpacket.h>
#include "ts.h"
#include "tcp.h"
#include "tcpService.h"
#include "fs/api.h"

// Send response to the client
void tcpServiceRespondClient(int clientPID, DCPACKET *dc, int rval)
{
	int x;

	// Store return value
	globalcopy(
		GetCurrentThread(),JTM_PTR_TO_DWORD(&rval), // SRC
		clientPID,JTM_PTR_TO_DWORD(dc->rval),	  // DST
		4);

	// Flag as completed
	x = TRUE;
	globalcopy(GetCurrentThread(),JTM_PTR_TO_DWORD(&x),
		clientPID,JTM_PTR_TO_DWORD(dc->done),
		4);

	// Go back to client (quick switch)
	SwitchToThreadEx(clientPID);
}

// TCP device call probe
// (handles incoming device calls)
void tcpDeviceCallProbe(void)
{
	static MSG m;
	DCPACKET *dc;
	int x JTM_UNUSED,rval;

	//--------------------------------------------------
	// Get DCPACKET PTR
	dc = (DCPACKET *)m.buf;

	//--------------------------------------------------
	// Probe for packet
	//
	if( receiveMessage(&m) )
	{
		// Message received.
		rval = tcpDevCall(
			dc, m.sndPID,
			dc->n_function,
			dc->par1,dc->par2,dc->par3,dc->par4,
			dc->p1,dc->p2);

		//
		if(rval!=RVAL_WILL_WAIT)
		{
			//
			tcpServiceRespondClient(m.sndPID, dc, rval);
		}
		else
		{
			// Client is queued to wait
		}
	}
}

//


