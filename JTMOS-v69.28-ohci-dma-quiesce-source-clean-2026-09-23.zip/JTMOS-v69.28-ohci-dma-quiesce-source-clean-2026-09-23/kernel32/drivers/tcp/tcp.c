//===========================================================
// JTMOS TCP/IP stack
// tcp.c - Transport Control Protocol driver.
// See ts.c for the actual stack.
// (C) 2003-2005 by Jari Tuominen.
//===========================================================
#include <stdio.h>
#include "socket.h"
#include "ip.h"
#include "tcp.h"
#include "SendPacket.h"
#include "rawpacket.h"

// Convert from big-endian WORD to little-endian WORD.
int tcp_htons(int x)
{
        return (((x&255)<<8) | ((x>>8)&255));
}

//
void TCPPacketChecksumMeasurement(void *ptr)
{
	PACKET *p;

	//
	p = ptr;

	//
	p->tcp.chksum = tcpchksum(p)^0xFFFF;
}


// Construct TCP a packet.
// Returns length of constructed TCP header.
// (NOTE: DOES NOT CALCULATE CHECKSUM FOR IT)
int MakeTCPPacket(TCPHDR *t,
	WORD srcport, WORD dstport,
	int seqno, int ackno,
	BYTE flags)
{
	void *p JTM_UNUSED;

	//--------------------------------------------
	// Clear TCP structure
	memset(t, 0, sizeof(TCPHDR));

	//--------------------------------------------
	// Define ports
	t->srcport = tcp_htons(srcport) & 0xFFFF;
	t->dstport = tcp_htons(dstport) & 0xFFFF;

	// Define seq/ack numbers
	t->seqno = ntohl(seqno);
	t->ackno = ntohl(ackno);

	// Define flags
	//
	if( (flags&TCP_SYN) )
		t->syn |= 1;
	if( (flags&TCP_RST) )
		t->rst |= 1;
	if( (flags&TCP_ACK) )
		t->ack |= 1;
	if( (flags&TCP_FIN) )
		t->fin |= 1;

	// Otsikon pituus DWORDeina.
	t->doff = sizeof(TCPHDR)/4;

	// Window size
	t->window = tcp_htons(16384);

	// We send out the TCP Maximum Segment
	// Size option.
/*	t->optdata[0] = 2;
	t->optdata[1] = 4;
	t->optdata[2] = (TCP_MAX_SEGSIZE) / 256;
	t->optdata[3] = (TCP_MAX_SEGSIZE) & 255;*/

	//--------------------------------------------
	// Calculate TCP header checksum
	//
	t->chksum = 0;
//	t->chksum = ip_chksum16(t, 6*2);

	// Return length of the TCP header in bytes
	return t->doff*4;
}





