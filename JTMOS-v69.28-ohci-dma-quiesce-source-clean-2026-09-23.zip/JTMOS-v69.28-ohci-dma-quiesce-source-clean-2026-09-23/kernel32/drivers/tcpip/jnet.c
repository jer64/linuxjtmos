/* JNetPOSIX: compact POSIX-shaped IPv4 API, DHCP, ARP, DNS and ICMP control.
 *
 * V16.51 rules:
 *  - UipProcess remains the only normal Ethernet RX owner.
 *  - DHCP/ping/DNS synchronous control transactions execute in that owner.
 *  - JNET UDP sockets receive through jnet_input_ethernet(), never by stealing
 *    frames directly from the NIC.
 *  - packet scratch is automatic (network-thread stack), while leases, socket
 *    queues, ARP cache and request state are persistent subsystem state.
 */
#include "kernel32.h"
#include <keyb.h>
#include "ethdev.h"
#include "nforce.h"
#include <int.h>
#include "jnet.h"
#include "jnet_dhcp.h"
#include "uip.h"
#include "uipMain.h"
#include "networkControl.h"

#define JNET_FRAME_MAX 1600
#define JNET_ARP_CACHE_SIZE 8
#define JNET_ARP_CACHE_MS 60000UL
#define JNET_ARP_TRIES 3
#define JNET_ARP_TRY_MS 350UL
#define JNET_DHCP_INITIAL_TRIES 3
#define JNET_DHCP_RENEW_WAIT_MS 1200UL
#define JNET_DHCP_FALLBACK_PROBE_MS 60000UL
#define JNET_SEND_WAIT_MS 5000UL
#define JNET_UDP_PAYLOAD_MAX 1472
#define JNET_SOCKET_COUNT 8

static JNET_CONFIG cfg;
static JNET_STATS stats;
static volatile int static_override;
static int jnet_initialized;
static DWORD dhcp_last_attempt_tick;
static int dhcp_last_link=-1;

typedef struct {
    int valid;
    BYTE ip[4];
    BYTE mac[6];
    DWORD learned_tick;
} JARP;
static JARP arp_cache[JNET_ARP_CACHE_SIZE];

typedef struct {
    int used,type,connected;
    WORD lport,rport;
    BYTE rip[4];
    int rxlen;
    int rx_pending;
    BYTE rxbuf[JNET_UDP_PAYLOAD_MAX];
} JSOCK;
static JSOCK socks[JNET_SOCKET_COUNT];
static WORD next_port=49152;

/* Ethernet ownership and one bounded outbound UDP request slot.  The request
 * buffer is intentionally persistent: it crosses thread boundaries and must
 * remain valid after the calling Ring3/kernel thread yields. */
static volatile int jnet_owner_pid=-1;
static volatile DWORD jnet_owner_magic=0;
static volatile int send_pending,send_running,send_done;
static BYTE send_rip[4];
static WORD send_lport,send_rport;
static unsigned int send_len;
static BYTE send_buf[JNET_UDP_PAYLOAD_MAX];
static int send_result;

static volatile int ping_pending,ping_running,ping_done,ping_cancel;
static BYTE ping_ip[4];
static DWORD ping_timeout,ping_rtt;
static WORD ping_sequence;
static BYTE ping_ttl;
static int ping_result;

static int udp_send_now(const BYTE rip[4],WORD lp,WORD rp,const void *buf,unsigned len);
static void set_uip_config(const JNET_CONFIG *c);

#define JNET_POLL_IDLE_US   5000UL
#define JNET_POLL_ACTIVE_US 1000UL
#define JNET_REQUEST_WAIT_US 5000UL
#define JNET_SEND_HARD_WAIT_MS 5000UL
#define JNET_SEND_HARD_WAIT_LIMIT 8192UL

static DWORD jnet_thread_magic(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS || !valid_pid(pid)) return 0;
    return thread_magic[pid];
}

static int jnet_owner_alive(int pid,DWORD magic)
{
    if(pid<0 || pid>=N_MAX_THREADS || !valid_pid(pid)) return 0;
    if(!thread_states[pid]) return 0;
    if(pid==0) return magic==thread_magic[0];
    return magic!=0 && thread_magic[pid]==magic;
}

static int jnet_eth_error(int rv)
{
    if(rv==ETHDEV_ERR_NO_DEVICE||rv==ETHDEV_ERR_LINK_DOWN)return JNET_ENETDOWN;
    if(rv==ETHDEV_ERR_INVALID)return JNET_EINVAL;
    if(rv==ETHDEV_ERR_BUSY)return JNET_EBUSY;
    return JNET_EIO;
}

/* V68.170: polling must sleep, not merely yield.  SwitchToThread() is not a
 * delay: when the network task is the only runnable peer, the scheduler may
 * choose it again immediately and a packet wait becomes a full-CPU busy poll.
 * A 5 ms empty-poll delay caps idle JNET polling at about 200 probes/s; after
 * receiving unrelated traffic use a shorter 1 ms pause to preserve throughput. */
static void jnet_poll_pause(int had_frame)
{
    DWORD usec=had_frame?JNET_POLL_ACTIVE_US:JNET_POLL_IDLE_US;
    JtNetworkRuntimeInterrupts();
    if(Multitasking && !PitStorageSafeActive())
    {
        if(UsecSleep(usec)!=0) SwitchToThread();
    }
    else
        SwitchToThread();
}

/* Request submitters wait for the single uIP/JNET owner.  They also sleep so
 * several simultaneous clients do not form a herd of yield-only pollers. */
static void jnet_request_pause(void)
{
    JtNetworkRuntimeInterrupts();
    if(Multitasking && !PitStorageSafeActive())
    {
        if(UsecSleep(JNET_REQUEST_WAIT_US)!=0) SwitchToThread();
    }
    else
        SwitchToThread();
}

/* V68.171: low-volume keyboard/PIC/NIC snapshot around ICMP activity.
 * This is deliberately observational: do not issue an i8042 command-byte read
 * at runtime because that command can race real scan/AUX bytes on port 0x60.
 * keyb_controller_byte is the last successfully programmed command byte. */
static unsigned int jnet_irq_diag_budget=16U;
static BYTE jnet_irq_diag_last_pic=0xff;
static DWORD jnet_irq_diag_last_keyirq=0xffffffffUL;

static void jnet_irq_snapshot(const char *tag)
{
    DWORD nfstat=0,nfmask=0,eflags;
    WORD pcicmd=0xffff;
    BYTE picmask,status;
    int have_nf;
    if(jnet_irq_diag_budget==0U) return;
    eflags=get_eflags();
    picmask=inportb(M_PIC+1);
    status=inportb(0x64);
    have_nf=(ethdev_backend()==ETHDEV_NFORCE &&
             nforce_get_irq_debug(&nfstat,&nfmask,&pcicmd)==0);
    if(jnet_irq_diag_last_pic!=picmask || jnet_irq_diag_last_keyirq!=keyb_irq_count ||
       jnet_irq_diag_budget>12U)
    {
        dprintk("NET/IRQ: %s pid=%d IF=%d PIC1=%02x irq1=%s i8042-status=%02x cbyte=%02x keyirq=%lu keypoll=%lu",
               tag?tag:"?",GetCurrentThread(),(eflags&0x200UL)?1:0,
               picmask,(picmask&0x02)?"masked":"enabled",status,keyb_controller_byte,
               (unsigned long)keyb_irq_count,(unsigned long)keyb_poll_count);
        if(have_nf)
            dprintk(" nforce-stat=%x mask=%x pci-cmd=%04x intx=%s\n",
                   nfstat,nfmask,pcicmd,(pcicmd&PCI_COMMAND_INTX_DISABLE)?"off":"ON");
        else
            dprintk(" backend=%s\n",ethdev_name());
        jnet_irq_diag_budget--;
    }
    jnet_irq_diag_last_pic=picmask;
    jnet_irq_diag_last_keyirq=keyb_irq_count;
}

static volatile int host_pending,host_running,host_done,host_cancel;
static char host_name[256];
static DWORD host_timeout;
static JNET_HOST_RESULT host_answers;
static int host_result;

static void w16(BYTE *p,unsigned v){p[0]=(BYTE)(v>>8);p[1]=(BYTE)v;}
static unsigned r16(const BYTE *p){return ((unsigned)p[0]<<8)|p[1];}
static WORD csum(const BYTE *p,int n){DWORD s=0;while(n>1){s+=r16(p);p+=2;n-=2;}if(n)s+=((WORD)*p)<<8;while(s>>16)s=(s&0xffff)+(s>>16);return (WORD)~s;}
static DWORD csum_add(DWORD s,const BYTE *p,int n){while(n>1){s+=r16(p);p+=2;n-=2;}if(n)s+=((DWORD)*p)<<8;return s;}
static int udp_checksum_valid(const BYTE *ip,const BYTE *udp,int ulen)
{
    DWORD s=0;
    if(r16(udp+6)==0)return 1; /* IPv4 permits a zero UDP checksum. */
    s=csum_add(s,ip+12,8);s+=17U;s+=(DWORD)ulen;s=csum_add(s,udp,ulen);
    while(s>>16)s=(s&0xffffU)+(s>>16);
    return (WORD)s==0xffffU;
}
static int same4(const BYTE *a,const BYTE *b){return a[0]==b[0]&&a[1]==b[1]&&a[2]==b[2]&&a[3]==b[3];}
static int zero4(const BYTE *a){return a[0]==0&&a[1]==0&&a[2]==0&&a[3]==0;}
static int same_subnet(const BYTE *a,const BYTE *b,const BYTE *m){int i;for(i=0;i<4;i++)if((a[i]&m[i])!=(b[i]&m[i]))return 0;return 1;}
static int valid_netmask(const BYTE *m){int i,b,zero=0,ones=0;if(!m)return 0;for(i=0;i<4;i++)for(b=7;b>=0;b--){if(m[i]&(1<<b)){if(zero)return 0;ones++;}else zero=1;}return ones>0;}
static void eth(BYTE *p,const BYTE *dst,WORD type){int i;const BYTE*m=ethdev_mac();for(i=0;i<6;i++){p[i]=dst[i];p[6+i]=m[i];}w16(p+12,type);}

/* Control transactions temporarily own NIC polling, but must not monopolize
 * protocol delivery.  Preserve JNet UDP demultiplexing and uIP TCP/ARP/ICMP
 * progress for every unrelated frame received while waiting for a reply. */
static void owner_forward_frame(const BYTE *frame,int len)
{
    if(!frame || len<=0)return;
    if(jnet_input_ethernet(frame,len))return;
    if(JtUipServiceEthernetFrame(frame,len))stats.owner_forwarded++;
}

static void arp_cache_clear(void)
{
    memset(arp_cache,0,sizeof(arp_cache));
}

static void jnet_init_state_once(void)
{
    if(jnet_initialized) return;
    memset(&cfg,0,sizeof(cfg));
    memset(&stats,0,sizeof(stats));
    memset(socks,0,sizeof(socks));
    send_pending=send_running=send_done=0;
    ping_pending=ping_running=ping_done=ping_cancel=0;
    host_pending=host_running=host_done=host_cancel=0;
    arp_cache_clear();
    cfg.dhcp_state=JNET_DHCP_OFF;
    dhcp_last_link=-1;
    jnet_initialized=1;
}

int jnet_init_ne2k(void){jnet_init_state_once();return ethdev_init();}
int jnet_init_ethernet(void){jnet_init_state_once();return ethdev_init();}
const JNET_CONFIG *jnet_config(void){jnet_init_state_once();return &cfg;}
void jnet_get_config(JNET_CONFIG *out)
{
    int f;
    if(!out)return;
    jnet_init_state_once();
    f=get_eflags();disable();memcpy(out,&cfg,sizeof(*out));set_eflags(f);
}

void jnet_owner_attach(void)
{
    int f=get_eflags();
    jnet_init_state_once();disable();
    jnet_owner_pid=GetCurrentThread();
    jnet_owner_magic=jnet_thread_magic(jnet_owner_pid);
    set_eflags(f);
}

void jnet_owner_detach(void)
{
    int f=get_eflags();
    disable();
    if(jnet_owner_pid==GetCurrentThread() &&
       jnet_owner_magic==jnet_thread_magic(GetCurrentThread())) {
        jnet_owner_pid=-1;
        jnet_owner_magic=0;
    }
    if(send_pending||send_running){send_pending=0;send_running=0;send_result=JNET_ENETDOWN;send_done=1;}
    if(ping_pending||ping_running){ping_pending=0;ping_running=0;ping_result=JNET_ENETDOWN;ping_done=1;}
    if(host_pending||host_running){host_pending=0;host_running=0;host_result=JNET_ENETDOWN;host_done=1;}
    set_eflags(f);
}

void jnet_reset_runtime(void)
{
    int f;
    JNET_CONFIG empty;

    jnet_init_state_once();
    memset(&empty,0,sizeof(empty));
    empty.dhcp_state=JNET_DHCP_OFF;

    f=get_eflags();
    disable();
    cfg=empty;
    memset(&stats,0,sizeof(stats));
    memset(socks,0,sizeof(socks));
    next_port=49152;
    static_override=0;
    dhcp_last_attempt_tick=0;
    dhcp_last_link=-1;
    jnet_owner_pid=-1;
    jnet_owner_magic=0;
    send_pending=send_running=send_done=0;
    send_result=JNET_ENETDOWN;
    ping_pending=ping_running=ping_done=ping_cancel=0;
    ping_result=JNET_ENETDOWN;
    host_pending=host_running=host_done=host_cancel=0;
    host_result=JNET_ENETDOWN;
    arp_cache_clear();
    set_eflags(f);

    /* UipProcess is stopped before this routine is called, so clearing the
     * address cannot race its packet processing. */
    set_uip_config(NULL);
}

void jnet_get_stats(JNET_STATS *out)
{
    int f;
    if(!out)return;
    f=get_eflags();disable();memcpy(out,&stats,sizeof(*out));set_eflags(f);
}

void jnet_reset_stats(void)
{
    int f;
    jnet_init_state_once();
    f=get_eflags();disable();memset(&stats,0,sizeof(stats));set_eflags(f);
}

const char *jnet_dhcp_state_name(int state)
{
    switch(state)
    {
        case JNET_DHCP_SELECTING:return "selecting";
        case JNET_DHCP_REQUESTING:return "requesting";
        case JNET_DHCP_BOUND:return "bound";
        case JNET_DHCP_RENEWING:return "renewing";
        case JNET_DHCP_REBINDING:return "rebinding";
        case JNET_DHCP_EXPIRED:return "expired";
        case JNET_DHCP_FAILED:return "failed";
        default:return "off";
    }
}

static unsigned long lease_elapsed_seconds(const JNET_CONFIG *c)
{
    if(!c || !c->configured || c->config_method!=JNET_CFG_DHCP)return 0;
    return (DWORD)(GetTickCount()-c->lease_acquired_tick)/1000UL;
}

unsigned long jnet_lease_remaining_seconds(void)
{
    unsigned long e;
    if(!cfg.configured || cfg.config_method!=JNET_CFG_DHCP || !cfg.lease_seconds)return 0;
    e=lease_elapsed_seconds(&cfg);
    return e>=cfg.lease_seconds?0:cfg.lease_seconds-e;
}

static void set_uip_config(const JNET_CONFIG *c)
{
    static const BYTE zero[4]={0,0,0,0};
    if(c && c->configured)
    {
        uip_sethostaddr((BYTE*)c->ip);
        uip_setnetmask((BYTE*)c->mask);
        uip_setdraddr((BYTE*)c->gateway);
    }
    else
    {
        uip_sethostaddr((BYTE*)zero);
        uip_setnetmask((BYTE*)zero);
        uip_setdraddr((BYTE*)zero);
    }
}

static void commit_config(const JNET_CONFIG *n)
{
    int f=get_eflags();
    disable();cfg=*n;set_eflags(f);
    arp_cache_clear();
    set_uip_config(&cfg);
}

static void set_dhcp_state(int state,int error)
{
    int f=get_eflags();
    disable();cfg.dhcp_state=state;cfg.dhcp_last_error=error;set_eflags(f);
}

static void clear_dhcp_address(int state,int error)
{
    JNET_CONFIG n;
    memset(&n,0,sizeof(n));
    n.config_method=JNET_CFG_DHCP;
    n.dhcp_state=state;
    n.dhcp_last_error=error;
    commit_config(&n);
}

static void classful_mask(const BYTE ip[4],BYTE mask[4])
{
    if(ip[0]<128){mask[0]=255;mask[1]=0;mask[2]=0;mask[3]=0;}
    else if(ip[0]<192){mask[0]=255;mask[1]=255;mask[2]=0;mask[3]=0;}
    else {mask[0]=255;mask[1]=255;mask[2]=255;mask[3]=0;}
}

static int route_hop(const BYTE target[4],BYTE hop[4])
{
    if(!cfg.configured)return JNET_ENETDOWN;
    if(same_subnet(target,cfg.ip,cfg.mask)){memcpy(hop,target,4);return 0;}
    if(zero4(cfg.gateway))return JNET_ENETUNREACH;
    memcpy(hop,cfg.gateway,4);return 0;
}

static int arp_cache_get(const BYTE ip[4],BYTE mac[6])
{
    DWORD now=GetTickCount();int i;
    for(i=0;i<JNET_ARP_CACHE_SIZE;i++)
        if(arp_cache[i].valid && same4(arp_cache[i].ip,ip) &&
           (DWORD)(now-arp_cache[i].learned_tick)<JNET_ARP_CACHE_MS)
        {memcpy(mac,arp_cache[i].mac,6);stats.arp_hits++;return 0;}
    return -1;
}

static void arp_cache_put(const BYTE ip[4],const BYTE mac[6])
{
    DWORD now=GetTickCount(),age,bestage=0;int i,best=0;
    for(i=0;i<JNET_ARP_CACHE_SIZE;i++)
    {
        if(arp_cache[i].valid && same4(arp_cache[i].ip,ip)){best=i;goto store;}
        if(!arp_cache[i].valid){best=i;goto store;}
        age=(DWORD)(now-arp_cache[i].learned_tick);if(age>=bestage){bestage=age;best=i;}
    }
store:
    arp_cache[best].valid=1;memcpy(arp_cache[best].ip,ip,4);memcpy(arp_cache[best].mac,mac,6);arp_cache[best].learned_tick=now;
}

static int jnet_foreground_interrupt_pending(void)
{
    int pid=GetCurrentThread();
    int terminal=GetCurrentTerminal();

    /* V68.167: a blocking network request may only observe Ctrl+C from the
     * terminal owned by the calling process.  GetInputTerminal() is global
     * keyboard focus and can intentionally point at a different VT; consuming
     * that VT's interrupt here would let a background ping steal user input. */
    if(terminal>=0 && GetTerminalForegroundProcess(terminal)==pid &&
       PeekTerminalInterrupt(terminal)) return 1;
    return 0;
}

static int jnet_control_cancelled(void)
{
    if(JtInternetStopRequested()) return 1;
    return (ping_running && ping_cancel) || (host_running && host_cancel);
}

static int arp_resolve(const BYTE target[4],BYTE mac[6])
{
    JtNetworkRuntimeInterrupts();
    static const BYTE bc[6]={255,255,255,255,255,255};
    BYTE frame[JNET_FRAME_MAX],*a;
    DWORD started;
    int attempt,n;
    if(!target||!mac||zero4(target))return JNET_EHOSTUNREACH;
    if(arp_cache_get(target,mac)==0)return 0;

    for(attempt=0;attempt<JNET_ARP_TRIES;attempt++)
    {
        memset(frame,0,sizeof(frame));a=frame+14;eth(frame,bc,0x0806);
        w16(a,1);w16(a+2,0x0800);a[4]=6;a[5]=4;w16(a+6,1);
        memcpy(a+8,ethdev_mac(),6);memcpy(a+14,cfg.ip,4);memcpy(a+24,target,4);
        stats.arp_requests++;
        {int er=ethdev_send(frame,42);if(er<0)return jnet_eth_error(er);}
        started=GetTickCount();
        while((DWORD)(GetTickCount()-started)<JNET_ARP_TRY_MS)
        {
            if(jnet_control_cancelled()) return JNET_EINTR;
            n=ethdev_receive(frame,sizeof(frame));
            if(n<0)return jnet_eth_error(n);
            if(n>=42 && r16(frame+12)==0x0806)
            {
                a=frame+14;
                if(r16(a)==1 && r16(a+2)==0x0800 && a[4]==6 && a[5]==4 &&
                   r16(a+6)==2 && same4(a+14,target) && same4(a+24,cfg.ip) &&
                   !memcmp(a+18,ethdev_mac(),6))
                {memcpy(mac,a+8,6);arp_cache_put(target,mac);return 0;}
            }
            if(n>0)owner_forward_frame(frame,n);
            jnet_poll_pause(n>0);
        }
    }
    memset(mac,0,6);stats.arp_timeouts++;return JNET_EHOSTUNREACH;
}

static unsigned int dhcp_xid(int salt)
{
    const BYTE *m=ethdev_mac();
    unsigned int x=(unsigned int)GetTickCount()^0x4a544d4fU^(unsigned int)(salt*0x9e37);
    if(m)x^=((unsigned int)m[0]<<24)|((unsigned int)m[2]<<16)|((unsigned int)m[4]<<8)|m[5];
    return x?x:0x4a544d4fU;
}

static int dhcp_send(const JNET_DHCP_BUILD *b)
{
    BYTE frame[JNET_DHCP_FRAME_MAX];int n;
    n=jnet_dhcp_build_frame(frame,sizeof(frame),b);if(n<0)return JNET_EINVAL;
    n=ethdev_send(frame,n);return n<0?jnet_eth_error(n):0;
}

static int dhcp_wait(unsigned int xid,int wanted,DWORD timeout,JNET_DHCP_REPLY *reply)
{
    JtNetworkRuntimeInterrupts();
    BYTE frame[JNET_DHCP_FRAME_MAX];DWORD start=GetTickCount();int n,mt;
    while((DWORD)(GetTickCount()-start)<timeout)
    {
        if(JtInternetStopRequested())return JNET_EINTR;
        if(static_override)return -9;
        if(!ethdev_link_up())return JNET_ENETDOWN;
        n=ethdev_receive(frame,sizeof(frame));
        if(n<0)return jnet_eth_error(n);
        if(n==0){jnet_poll_pause(0);continue;}
        mt=jnet_dhcp_parse_reply(frame,n,xid,ethdev_mac(),reply);
        if(mt==JNET_DHCP_NAK){stats.dhcp_naks++;return JNET_DHCP_NAK;}
        if(mt==wanted)return mt;
        owner_forward_frame(frame,n);
        jnet_poll_pause(1);
    }
    stats.dhcp_timeouts++;return JNET_ETIMEDOUT;
}

static void dhcp_merge_reply(JNET_DHCP_REPLY *ack,const JNET_DHCP_REPLY *base)
{
    if(!ack->have_server && base->have_server){memcpy(ack->server,base->server,4);ack->have_server=1;}
    if(!ack->have_mask && base->have_mask){memcpy(ack->mask,base->mask,4);ack->have_mask=1;}
    if(!ack->have_gateway && base->have_gateway){memcpy(ack->gateway,base->gateway,4);ack->have_gateway=1;}
    if(!ack->have_dns && base->have_dns){memcpy(ack->dns,base->dns,4);ack->have_dns=1;}
    if(!ack->have_lease && base->have_lease){ack->lease_seconds=base->lease_seconds;ack->have_lease=1;}
    if(!ack->have_t1 && base->have_t1){ack->t1_seconds=base->t1_seconds;ack->have_t1=1;}
    if(!ack->have_t2 && base->have_t2){ack->t2_seconds=base->t2_seconds;ack->have_t2=1;}
    if(zero4(ack->yiaddr) && !zero4(base->yiaddr))memcpy(ack->yiaddr,base->yiaddr,4);
}

static void reply_from_config(JNET_DHCP_REPLY *r,const JNET_CONFIG *c)
{
    memset(r,0,sizeof(*r));
    memcpy(r->yiaddr,c->ip,4);memcpy(r->server,c->server,4);memcpy(r->mask,c->mask,4);
    memcpy(r->gateway,c->gateway,4);memcpy(r->dns,c->dns,4);
    r->lease_seconds=(unsigned int)c->lease_seconds;r->t1_seconds=(unsigned int)c->t1_seconds;r->t2_seconds=(unsigned int)c->t2_seconds;
    r->have_server=!zero4(r->server);r->have_mask=!zero4(r->mask);r->have_gateway=!zero4(r->gateway);r->have_dns=!zero4(r->dns);
    r->have_lease=c->lease_seconds!=0;r->have_t1=c->t1_seconds!=0;r->have_t2=c->t2_seconds!=0;
}

static int dhcp_commit_reply(JNET_DHCP_REPLY *r,int renewal)
{
    JNET_CONFIG n;unsigned long lease,t1,t2;
    if(zero4(r->yiaddr))return -30;
    memset(&n,0,sizeof(n));memcpy(n.ip,r->yiaddr,4);
    if(r->have_mask && valid_netmask(r->mask))memcpy(n.mask,r->mask,4);else classful_mask(n.ip,n.mask);
    if(r->have_gateway)memcpy(n.gateway,r->gateway,4);
    if(r->have_dns)memcpy(n.dns,r->dns,4);
    if(r->have_server)memcpy(n.server,r->server,4);
    lease=(r->have_lease && r->lease_seconds)?r->lease_seconds:3600UL;
    /* Never extend a server-supplied short lease.  For tiny test/emergency
     * leases there may be no useful renewal window; expiry wins first. */
    if(lease<4UL){t1=lease;t2=lease;}
    else
    {
        t1=r->have_t1?r->t1_seconds:lease/2;
        t2=r->have_t2?r->t2_seconds:(lease*7UL)/8UL;
        if(t1==0 || t1>=lease)t1=lease/2;
        if(t2<=t1 || t2>=lease)t2=(lease*7UL)/8UL;
        if(t2<=t1)t2=t1+1;
        if(t2>=lease)t2=lease-1;
    }
    n.lease_seconds=lease;n.t1_seconds=t1;n.t2_seconds=t2;n.lease_acquired_tick=GetTickCount();
    n.configured=1;n.config_method=JNET_CFG_DHCP;n.dhcp_state=JNET_DHCP_BOUND;n.dhcp_last_error=0;
    commit_config(&n);static_override=0;dhcp_last_attempt_tick=n.lease_acquired_tick;
    printk("DHCP: %d.%d.%d.%d mask %d.%d.%d.%d gateway %d.%d.%d.%d DNS %d.%d.%d.%d lease %lu s T1=%lu T2=%lu%s\n",
        n.ip[0],n.ip[1],n.ip[2],n.ip[3],n.mask[0],n.mask[1],n.mask[2],n.mask[3],
        n.gateway[0],n.gateway[1],n.gateway[2],n.gateway[3],n.dns[0],n.dns[1],n.dns[2],n.dns[3],
        n.lease_seconds,n.t1_seconds,n.t2_seconds,renewal?" (renewed)":"");
    return 0;
}

static int dhcp_acquire(int tries,int preserve)
{
    static const BYTE bc[6]={255,255,255,255,255,255};
    static const BYTE bip[4]={255,255,255,255};
    JNET_DHCP_BUILD b;JNET_DHCP_REPLY offer,ack;JNET_CONFIG old;
    DWORD begin=GetTickCount(),wait;unsigned int xid;int attempt,rv,last=JNET_ETIMEDOUT;
    old=cfg;
    if(static_override&&cfg.configured)return 0;
    if(!ethdev_present())
    {
        dhcp_last_attempt_tick=GetTickCount();
        if(!preserve)clear_dhcp_address(JNET_DHCP_FAILED,JNET_ENETDOWN);
        return JNET_ENETDOWN;
    }
    if(!ethdev_link_up())
    {
        dhcp_last_attempt_tick=GetTickCount();
        if(!preserve)clear_dhcp_address(JNET_DHCP_FAILED,JNET_ENETDOWN);
        return JNET_ENETDOWN;
    }
    for(attempt=0;attempt<tries;attempt++)
    {
        if(JtInternetStopRequested()) return JNET_EINTR;
        xid=dhcp_xid(attempt);wait=1200UL+(DWORD)attempt*1200UL;
        set_dhcp_state(JNET_DHCP_SELECTING,0);memset(&b,0,sizeof(b));
        b.message_type=JNET_DHCP_DISCOVER;b.xid=xid;b.secs=(WORD)((GetTickCount()-begin)/1000UL);b.broadcast=1;
        memcpy(b.client_mac,ethdev_mac(),6);memcpy(b.ethernet_dest,bc,6);memcpy(b.destination_ip,bip,4);
        stats.dhcp_discovers++;dhcp_last_attempt_tick=GetTickCount();
        rv=dhcp_send(&b);if(rv<0){last=rv;continue;}
        memset(&offer,0,sizeof(offer));rv=dhcp_wait(xid,JNET_DHCP_OFFER,wait,&offer);
        if(rv==JNET_EINTR) return rv;
        if(rv!=JNET_DHCP_OFFER){last=rv;continue;}stats.dhcp_offers++;
        if(zero4(offer.yiaddr) || !offer.have_server){last=-31;continue;}

        set_dhcp_state(JNET_DHCP_REQUESTING,0);memset(&b,0,sizeof(b));
        b.message_type=JNET_DHCP_REQUEST;b.xid=xid;b.secs=(WORD)((GetTickCount()-begin)/1000UL);b.broadcast=1;
        memcpy(b.client_mac,ethdev_mac(),6);memcpy(b.ethernet_dest,bc,6);memcpy(b.destination_ip,bip,4);
        memcpy(b.requested_ip,offer.yiaddr,4);b.include_requested_ip=1;
        memcpy(b.server_id,offer.server,4);b.include_server_id=1;
        stats.dhcp_requests++;
        rv=dhcp_send(&b);if(rv<0){last=rv;continue;}
        memset(&ack,0,sizeof(ack));rv=dhcp_wait(xid,JNET_DHCP_ACK,wait,&ack);
        if(rv==JNET_EINTR) return rv;
        if(rv==JNET_DHCP_NAK){last=-32;continue;}
        if(rv!=JNET_DHCP_ACK){last=rv;continue;}stats.dhcp_acks++;
        dhcp_merge_reply(&ack,&offer);
        rv=dhcp_commit_reply(&ack,0);if(rv==0)return 0;last=rv;
    }
    if(preserve && old.configured){commit_config(&old);set_dhcp_state(old.dhcp_state,last);}
    else clear_dhcp_address(JNET_DHCP_FAILED,last);
    return last;
}

int jnet_dhcp(void)
{
    jnet_init_state_once();
    return dhcp_acquire(JNET_DHCP_INITIAL_TRIES,0);
}

static int dhcp_renew_once(int rebind)
{
    static const BYTE bc[6]={255,255,255,255,255,255};
    static const BYTE bip[4]={255,255,255,255};
    JNET_CONFIG old=cfg;JNET_DHCP_BUILD b;JNET_DHCP_REPLY ack,base;
    BYTE hop[4],mac[6];unsigned int xid;int rv;
    if(!old.configured||old.config_method!=JNET_CFG_DHCP)return JNET_ENETDOWN;
    xid=dhcp_xid(rebind?0x77:0x55);memset(&b,0,sizeof(b));b.message_type=JNET_DHCP_REQUEST;b.xid=xid;
    memcpy(b.client_mac,ethdev_mac(),6);memcpy(b.source_ip,old.ip,4);memcpy(b.ciaddr,old.ip,4);
    if(rebind || zero4(old.server))
    {
        b.broadcast=1;memcpy(b.ethernet_dest,bc,6);memcpy(b.destination_ip,bip,4);
        set_dhcp_state(JNET_DHCP_REBINDING,0);stats.dhcp_rebinds++;
    }
    else
    {
        set_dhcp_state(JNET_DHCP_RENEWING,0);
        rv=route_hop(old.server,hop);if(rv<0)return rv;
        rv=arp_resolve(hop,mac);if(rv<0)return rv;
        memcpy(b.ethernet_dest,mac,6);memcpy(b.destination_ip,old.server,4);
    }
    stats.dhcp_requests++;dhcp_last_attempt_tick=GetTickCount();
    rv=dhcp_send(&b);if(rv<0){set_dhcp_state(rebind?JNET_DHCP_REBINDING:JNET_DHCP_RENEWING,rv);return rv;}
    memset(&ack,0,sizeof(ack));rv=dhcp_wait(xid,JNET_DHCP_ACK,JNET_DHCP_RENEW_WAIT_MS,&ack);
    if(rv==JNET_DHCP_NAK)
    {
        clear_dhcp_address(JNET_DHCP_EXPIRED,-32);return -32;
    }
    if(rv!=JNET_DHCP_ACK)
    {
        set_dhcp_state(rebind?JNET_DHCP_REBINDING:JNET_DHCP_RENEWING,rv);return rv;
    }
    stats.dhcp_acks++;reply_from_config(&base,&old);dhcp_merge_reply(&ack,&base);
    if(zero4(ack.yiaddr))memcpy(ack.yiaddr,old.ip,4);
    rv=dhcp_commit_reply(&ack,1);if(rv==0)stats.dhcp_renewals++;return rv;
}

void jnet_maintenance(void)
{
    DWORD now=GetTickCount(),retry_ms;unsigned long elapsed;int link,recovered=0;
    if(!ethdev_present())return;
    link=ethdev_link_up()?1:0;
    if(dhcp_last_link<0)dhcp_last_link=link;
    else if(link!=dhcp_last_link)
    {
        if(link){stats.dhcp_link_recoveries++;recovered=1;}
        else stats.dhcp_link_losses++;
        dhcp_last_link=link;
    }
    if(!link)return;
    if(static_override)return;

    /* A DHCP lease belongs to the network on which it was acquired.  After a
     * carrier loss/recovery, discard a DHCP address and perform a fresh DORA
     * instead of assuming the cable still reaches the same subnet. */
    if(recovered && cfg.configured && cfg.config_method==JNET_CFG_DHCP)
    {
        printk("DHCP: Ethernet carrier recovered; validating network with fresh discovery.\n");
        clear_dhcp_address(JNET_DHCP_SELECTING,0);
        dhcp_last_attempt_tick=now-30000UL;
    }

    if(cfg.config_method==JNET_CFG_QEMU_USER_STATIC || cfg.config_method==JNET_CFG_NFORCE_DIRECT)
    {
        /* Automatic fallbacks are not permanent policy.  Keep them working,
         * but periodically probe DHCP and atomically replace them only after
         * a complete OFFER/REQUEST/ACK succeeds. */
        if(recovered || (DWORD)(now-dhcp_last_attempt_tick)>=JNET_DHCP_FALLBACK_PROBE_MS)
        {
            stats.dhcp_fallback_probes++;
            (void)dhcp_acquire(1,1);
        }
        return;
    }
    if(cfg.config_method!=JNET_CFG_DHCP)return;
    if(!cfg.configured)
    {
        if(recovered || (DWORD)(now-dhcp_last_attempt_tick)>=30000UL)(void)dhcp_acquire(1,0);
        return;
    }
    if(!cfg.lease_seconds)return;
    elapsed=lease_elapsed_seconds(&cfg);
    retry_ms=cfg.lease_seconds<120?5000UL:30000UL;
    if(elapsed>=cfg.lease_seconds)
    {
        printk("DHCP: lease expired; dropping IPv4 address and restarting discovery.\n");
        clear_dhcp_address(JNET_DHCP_EXPIRED,JNET_ETIMEDOUT);dhcp_last_attempt_tick=now;
        (void)dhcp_acquire(1,0);return;
    }
    if((DWORD)(now-dhcp_last_attempt_tick)<retry_ms)return;
    if(elapsed>=cfg.t2_seconds){(void)dhcp_renew_once(1);return;}
    if(elapsed>=cfg.t1_seconds){(void)dhcp_renew_once(0);return;}
}

static int apply_static(const BYTE ip[4],const BYTE mask[4],const BYTE gateway[4],const BYTE dns[4],int method,int override)
{
    static const BYTE zero[4]={0,0,0,0};JNET_CONFIG n;
    if(!ethdev_present()||!ip||!mask)return -1;
    memset(&n,0,sizeof(n));memcpy(n.ip,ip,4);memcpy(n.mask,mask,4);
    memcpy(n.gateway,gateway?gateway:zero,4);memcpy(n.dns,dns?dns:zero,4);
    n.configured=1;n.config_method=method;n.dhcp_state=JNET_DHCP_OFF;
    static_override=override;commit_config(&n);
    printk("IPv4: static %d.%d.%d.%d mask %d.%d.%d.%d gateway %d.%d.%d.%d.\n",
        n.ip[0],n.ip[1],n.ip[2],n.ip[3],n.mask[0],n.mask[1],n.mask[2],n.mask[3],
        n.gateway[0],n.gateway[1],n.gateway[2],n.gateway[3]);
    return 0;
}

int jnet_configure_qemu_user_fallback(void)
{
    static const BYTE qemu_mac[6]={0x52,0x54,0x00,0x12,0x34,0x56};
    static const BYTE ip[4]={10,0,2,15},mask[4]={255,255,255,0},gateway[4]={10,0,2,2},dns[4]={10,0,2,3};
    const BYTE *mac=ethdev_mac();int rv;
    if(ethdev_backend()!=ETHDEV_NE2K||!mac||memcmp(mac,qemu_mac,6))return -1;
    rv=apply_static(ip,mask,gateway,dns,JNET_CFG_QEMU_USER_STATIC,0);
    if(rv==0)printk("IPv4: QEMU user-network fallback 10.0.2.15/24 gateway 10.0.2.2 DNS 10.0.2.3.\n");
    return rv;
}

int jnet_configure_static(const BYTE ip[4],const BYTE mask[4],const BYTE gateway[4],const BYTE dns[4])
{return apply_static(ip,mask,gateway,dns,JNET_CFG_STATIC,1);}

int jnet_configure_nforce_direct_fallback(void)
{
    static const BYTE ip[4]={192,168,50,2},mask[4]={255,255,255,0},zero[4]={0,0,0,0};int rv;
    if(ethdev_backend()!=ETHDEV_NFORCE)return -1;
    rv=apply_static(ip,mask,zero,zero,JNET_CFG_NFORCE_DIRECT,0);
    if(rv==0)printk("IPv4: nForce direct-link fallback 192.168.50.2/24 (peer suggestion 192.168.50.1).\n");
    return rv;
}

static int ipv4_frame_view(const BYTE *frame,int n,const BYTE **ipp,int *ihlp,int *totalp)
{
    const BYTE *ip;int ihl,total;
    if(!frame||n<14+20||r16(frame+12)!=0x0800)return -1;
    ip=frame+14;
    if((ip[0]>>4)!=4)return -1;
    ihl=(ip[0]&15)*4;total=r16(ip+2);
    if(ihl<20||ihl>60||total<ihl||14+total>n)return -1;
    if(r16(ip+6)&0x3fff)return -1;
    if(csum(ip,ihl)!=0)return -1;
    if(ipp) *ipp=ip;
    if(ihlp) *ihlp=ihl;
    if(totalp) *totalp=total;
    return 0;
}

static int ping_icmp_error(const BYTE *outer,int outer_len,const BYTE target[4],WORD sequence)
{
    const BYTE *inner,*echo;int ihl;
    if(outer_len<8+20+8 || (outer[0]!=3 && outer[0]!=11))return 0;
    if(csum(outer,outer_len)!=0)return 0;
    inner=outer+8;
    if((inner[0]>>4)!=4)return 0;
    ihl=(inner[0]&15)*4;
    if(ihl<20||ihl>60||8+ihl+8>outer_len||inner[9]!=1)return 0;
    if(!same4(inner+12,cfg.ip)||!same4(inner+16,target))return 0;
    echo=inner+ihl;
    if(echo[0]!=8||r16(echo+4)!=0x4a54||r16(echo+6)!=sequence)return 0;
    return outer[0]==11?JNET_ETIMEDOUT:JNET_EHOSTUNREACH;
}

static int ping_now(const BYTE target[4],DWORD timeout,WORD sequence,DWORD *rtt,BYTE *ttl)
{
    JtNetworkRuntimeInterrupts();
    BYTE frame[JNET_FRAME_MAX],mac[6],hop[4],*ip,*ic;const BYTE *rip;DWORD start,last_diag;unsigned long poll_count=0;int n,ihl,total,iclen,rv,error;
    if(!cfg.configured) return JNET_ENETDOWN;
    if(!target||zero4(target)) return JNET_EINVAL;
    if(same4(target,cfg.ip)){if(rtt)*rtt=0;if(ttl)*ttl=64;return 0;}
    jnet_irq_snapshot("ping-enter");
    rv=route_hop(target,hop);if(rv<0)return rv;rv=arp_resolve(hop,mac);if(rv<0)return rv;
    jnet_irq_snapshot("ping-pre-tx");
    memset(frame,0,98);eth(frame,mac,0x0800);ip=frame+14;ic=ip+20;ip[0]=0x45;w16(ip+2,84);w16(ip+4,sequence);w16(ip+6,0x4000);ip[8]=64;ip[9]=1;
    memcpy(ip+12,cfg.ip,4);memcpy(ip+16,target,4);ic[0]=8;w16(ic+4,0x4a54);w16(ic+6,sequence);
    for(n=8;n<64;n++) ic[n]=(BYTE)n;
    w16(ic+2,csum(ic,64));
    w16(ip+10,csum(ip,20));
    stats.ping_requests++;start=GetTickCount();last_diag=start;
    n=ethdev_send(frame,98);
    if(!(get_eflags()&0x200UL) && Multitasking && !PitStorageSafeActive())
    { dprintk("PING/JNET: IF dropped by ethdev_send; recovering\n"); JtNetworkRuntimeInterrupts(); }
    if(n<0) return jnet_eth_error(n);
    jnet_irq_snapshot("ping-post-tx");
    while((DWORD)(GetTickCount()-start)<timeout)
    {
        if(jnet_control_cancelled()) return JNET_EINTR;
        n=ethdev_receive(frame,sizeof(frame));
        poll_count++;
        if(!(get_eflags()&0x200UL) && Multitasking && !PitStorageSafeActive())
        {
            dprintk("PING/JNET: IF dropped by ethdev_receive poll=%lu; recovering\n",poll_count);
            JtNetworkRuntimeInterrupts();
        }
        if((DWORD)(GetTickCount()-last_diag)>=250UL)
        {
            dprintk("PING/JNET: wait elapsed=%lu ms polls=%lu last-rx=%d IF=%d keyirq=%lu keypoll=%lu\n",
                    (unsigned long)(GetTickCount()-start),poll_count,n,
                    (get_eflags()&0x200UL)?1:0,(unsigned long)keyb_irq_count,
                    (unsigned long)keyb_poll_count);
            jnet_irq_snapshot("ping-wait");
            last_diag=GetTickCount();
        }
        if(n<0)return jnet_eth_error(n);
        if(n>0 && ipv4_frame_view(frame,n,&rip,&ihl,&total)==0 &&
           rip[9]==1 && same4(rip+16,cfg.ip))
        {
            ic=(BYTE *)rip+ihl;iclen=total-ihl;
            if(iclen>=8 && ic[0]==0 && ic[1]==0 && same4(rip+12,target) &&
               r16(ic+4)==0x4a54 && r16(ic+6)==sequence && csum(ic,iclen)==0)
            {
                if(rtt) *rtt=GetTickCount()-start;
                if(ttl) *ttl=rip[8];
                stats.ping_replies++;jnet_irq_snapshot("ping-rx");return 0;
            }
            error=ping_icmp_error(ic,iclen,target,sequence);
            if(error)return error;
        }
        if(n>0)owner_forward_frame(frame,n);
        jnet_poll_pause(n>0);
    }
    return JNET_ETIMEDOUT;
}

static int dns_skip(const BYTE *d,int n,int off)
{
    int steps=0,l;
    while(off<n&&steps++<128){l=d[off];if((l&0xc0)==0xc0)return off+2<=n?off+2:-1;if(l==0)return off+1;if(l>63||off+1+l>n)return -1;off+=1+l;}return -1;
}

static int dns_now(const char *name,DWORD timeout,JNET_HOST_RESULT *res)
{
    JtNetworkRuntimeInterrupts();
    BYTE frame[JNET_FRAME_MAX],mac[6],hop[4],*ip,*udp,*dns,*q;const BYTE *vip;DWORD start;WORD id,ul,sport;int n,i,label,off,qd,an,ihl,total,rv;
    const char *np=name;
    if(!cfg.configured||!name||!res) return JNET_ENETDOWN;
    if(zero4(cfg.dns)) return JNET_ENETUNREACH;
    memset(res,0,sizeof(*res));rv=route_hop(cfg.dns,hop);if(rv<0)return rv;rv=arp_resolve(hop,mac);if(rv<0)return rv;
    memset(frame,0,sizeof(frame));eth(frame,mac,0x0800);ip=frame+14;udp=ip+20;dns=udp+8;
    ip[0]=0x45;ip[8]=64;ip[9]=17;memcpy(ip+12,cfg.ip,4);memcpy(ip+16,cfg.dns,4);
    sport=(WORD)(49152U+((unsigned)GetTickCount()%12000U));w16(udp,sport);w16(udp+2,53);
    id=(WORD)(0x4a54^GetTickCount());w16(dns,id);w16(dns+2,0x0100);w16(dns+4,1);q=dns+12;
    while(*np)
    {
        BYTE *lp=q++;label=0;
        while(*np&&*np!='.'){if(label>=63||q>=frame+1500)return JNET_EINVAL;*q++=(BYTE)*np++;label++;}
        if(label==0){if(*np=='.'&&np[1]=='\0'){np++;break;}return JNET_EINVAL;}
        *lp=(BYTE)label;if(*np=='.')np++;
    }
    *q++=0;w16(q,1);q+=2;w16(q,1);q+=2;n=(int)(q-dns);w16(udp+4,n+8);w16(ip+2,n+28);w16(ip+10,csum(ip,20));
    stats.dns_requests++;rv=ethdev_send(frame,n+42);if(rv<0)return jnet_eth_error(rv);start=GetTickCount();
    while((DWORD)(GetTickCount()-start)<timeout)
    {
        if(jnet_control_cancelled()) return JNET_EINTR;
        n=ethdev_receive(frame,sizeof(frame));
        if(n<0)return jnet_eth_error(n);
        if(n<14+20+8+12 || ipv4_frame_view(frame,n,&vip,&ihl,&total)<0)
        {if(n>0)owner_forward_frame(frame,n);jnet_poll_pause(n>0);continue;}
        if(total<ihl+8+12 || vip[9]!=17 || !same4(vip+12,cfg.dns) || !same4(vip+16,cfg.ip))
        {owner_forward_frame(frame,n);jnet_poll_pause(1);continue;}
        ip=(BYTE *)vip;udp=ip+ihl;
        if(r16(udp)!=53||r16(udp+2)!=sport)
        {owner_forward_frame(frame,n);jnet_poll_pause(1);continue;}
        ul=(WORD)r16(udp+4);if(ul<20||ul>(WORD)(total-ihl)){jnet_poll_pause(1);continue;}
        dns=udp+8;n=(int)ul-8;if(r16(dns)!=id||!(r16(dns+2)&0x8000)){jnet_poll_pause(1);continue;}if((r16(dns+2)&0x000f)!=0)return -4;
        qd=r16(dns+4);an=r16(dns+6);off=12;
        for(i=0;i<qd;i++){off=dns_skip(dns,n,off);if(off<0||off+4>n)return -5;off+=4;}
        for(i=0;i<an&&res->count<8;i++)
        {
            int type,klass,rdlen;off=dns_skip(dns,n,off);if(off<0||off+10>n)return -5;
            type=r16(dns+off);klass=r16(dns+off+2);rdlen=r16(dns+off+8);if(off+10+rdlen>n)return -5;
            if(type==1&&klass==1&&rdlen==4){memcpy(res->addr[res->count],dns+off+10,4);res->count++;}
            off+=10+rdlen;
        }
        if(res->count){stats.dns_replies++;return 0;}return -6;
    }
    return JNET_ETIMEDOUT;
}

int jnet_ping_request_ex(const BYTE ip[4],DWORD timeout,WORD sequence,DWORD *rtt,BYTE *ttl)
{
    JtNetworkRuntimeInterrupts();
    DWORD start;int f,rv,interrupted=0;
    if(!ip||timeout==0)return JNET_EINVAL;
    f=get_eflags();disable();if(ping_pending||ping_running){set_eflags(f);return JNET_EBUSY;}
    memcpy(ping_ip,ip,4);ping_timeout=timeout;ping_sequence=sequence;ping_ttl=0;ping_done=0;ping_cancel=0;ping_pending=1;set_eflags(f);
    start=GetTickCount();
    while(!ping_done&&(DWORD)(GetTickCount()-start)<timeout+1500UL)
    {
        KeyboardPollInputOnce();
        if(!interrupted && jnet_foreground_interrupt_pending())
        {
            interrupted=1;
            f=get_eflags();disable();
            ping_cancel=1;
            if(ping_pending && !ping_running){ping_pending=0;ping_result=JNET_EINTR;ping_done=1;}
            set_eflags(f);
        }
        jnet_request_pause();
    }
    if(!ping_done)
    {
        f=get_eflags();disable();if(ping_pending)ping_pending=0;ping_cancel=1;set_eflags(f);
        return interrupted?JNET_EINTR:JNET_ETIMEDOUT;
    }
    rv=interrupted?JNET_EINTR:ping_result;
    if(rtt) *rtt=ping_rtt;
    if(ttl) *ttl=ping_ttl;
    return rv;
}

int jnet_ping_request(const BYTE ip[4],DWORD timeout,DWORD *rtt){return jnet_ping_request_ex(ip,timeout,1,rtt,NULL);}

int jnet_host_request(const char *name,DWORD timeout,JNET_HOST_RESULT *result)
{
    JtNetworkRuntimeInterrupts();
    DWORD start;int l,f,rv,interrupted=0;
    if(!name||!result||timeout==0) return JNET_EINVAL;
    l=strlen(name);
    if(l<1||l>253) return JNET_EINVAL;
    f=get_eflags();disable();if(host_pending||host_running){set_eflags(f);return JNET_EBUSY;}
    strcpy(host_name,name);host_timeout=timeout;host_done=0;host_cancel=0;host_pending=1;set_eflags(f);
    start=GetTickCount();
    while(!host_done&&(DWORD)(GetTickCount()-start)<timeout+1500UL)
    {
        KeyboardPollInputOnce();
        if(!interrupted && jnet_foreground_interrupt_pending())
        {
            interrupted=1;
            f=get_eflags();disable();
            host_cancel=1;
            if(host_pending && !host_running){host_pending=0;host_result=JNET_EINTR;host_done=1;}
            set_eflags(f);
        }
        jnet_request_pause();
    }
    if(!host_done){f=get_eflags();disable();if(host_pending)host_pending=0;host_cancel=1;set_eflags(f);return interrupted?JNET_EINTR:JNET_ETIMEDOUT;}
    if(interrupted)return JNET_EINTR;
    memcpy(result,&host_answers,sizeof(*result));rv=host_result;return rv;
}

void jnet_service_requests(void)
{
    BYTE ip[4],srip[4],sbuf[JNET_UDP_PAYLOAD_MAX];char name[256];DWORD timeout;WORD seq,slp,srp;unsigned slen=0;int f,do_send=0,do_ping=0,do_host=0;
    f=get_eflags();disable();
    if(send_pending&&!send_running){memcpy(srip,send_rip,4);slp=send_lport;srp=send_rport;slen=send_len;if(slen)memcpy(sbuf,send_buf,slen);send_pending=0;send_running=1;do_send=1;}
    else if(ping_pending&&!ping_running){memcpy(ip,ping_ip,4);timeout=ping_timeout;seq=ping_sequence;ping_pending=0;ping_running=1;do_ping=1;}
    else if(host_pending&&!host_running){strcpy(name,host_name);timeout=host_timeout;host_pending=0;host_running=1;do_host=1;}
    set_eflags(f);
    if(do_send)
    {
        int result=udp_send_now(srip,slp,srp,sbuf,slen);
        f=get_eflags();disable();send_result=result;send_running=0;send_done=1;set_eflags(f);
    }
    if(do_ping)
    {
        DWORD rr=0;BYTE tt=0;int result=ping_now(ip,timeout,seq,&rr,&tt);
        f=get_eflags();disable();ping_result=result;ping_rtt=rr;ping_ttl=tt;ping_running=0;ping_cancel=0;ping_done=1;set_eflags(f);
    }
    if(do_host)
    {
        JNET_HOST_RESULT answers;int result=dns_now(name,timeout,&answers);
        f=get_eflags();disable();host_result=result;memcpy(&host_answers,&answers,sizeof(answers));host_running=0;host_cancel=0;host_done=1;set_eflags(f);
    }
}

int jnet_inet_pton(int af,const char *s,void *d)
{
    BYTE *p=(BYTE*)d;int i,v,digits;
    if(af!=JNET_AF_INET||!s||!d)return -1;
    for(i=0;i<4;i++)
    {
        v=0;digits=0;if(*s<'0'||*s>'9')return 0;
        while(*s>='0'&&*s<='9'){v=v*10+(*s-'0');if(v>255)return 0;s++;digits++;if(digits>3)return 0;}
        p[i]=(BYTE)v;if(i<3){if(*s!='.')return 0;s++;}else if(*s!='\0')return 0;
    }
    return 1;
}

const char *jnet_inet_ntop(int af,const void *s,char *d,jnet_socklen_t z)
{const BYTE*p=(const BYTE*)s;if(af!=JNET_AF_INET||!s||!d||z<16)return NULL;sprintf(d,"%d.%d.%d.%d",p[0],p[1],p[2],p[3]);return d;}

static WORD allocate_local_port(void)
{
    int tries,i,used;WORD p;
    for(tries=0;tries<16384;tries++)
    {
        p=next_port++;if(next_port<49152)next_port=49152;used=0;
        for(i=0;i<JNET_SOCKET_COUNT;i++)if(socks[i].used&&socks[i].lport==p){used=1;break;}
        if(!used)return p;
    }
    return 0;
}

int jnet_socket(int d,int t,int p)
{
    int i,f;WORD lp;
    if(d!=JNET_AF_INET||t!=JNET_SOCK_DGRAM||(p!=0&&p!=17))return t==JNET_SOCK_STREAM?-95:JNET_EINVAL;
    f=get_eflags();disable();lp=allocate_local_port();if(!lp){set_eflags(f);return -24;}
    for(i=0;i<JNET_SOCKET_COUNT;i++)if(!socks[i].used){memset(&socks[i],0,sizeof(socks[i]));socks[i].used=1;socks[i].type=t;socks[i].lport=lp;set_eflags(f);return i+3;}
    set_eflags(f);return -24;
}

int jnet_close(int fd)
{
    int i=fd-3,f;if(i<0||i>=JNET_SOCKET_COUNT)return -9;f=get_eflags();disable();if(!socks[i].used){set_eflags(f);return -9;}memset(&socks[i],0,sizeof(socks[i]));set_eflags(f);return 0;
}

int jnet_connect(int fd,const struct jnet_sockaddr *a,jnet_socklen_t l)
{
    int i=fd-3,f;const struct jnet_sockaddr_in *in=(const struct jnet_sockaddr_in*)a;
    if(i<0||i>=JNET_SOCKET_COUNT||!a||l<sizeof(*in)||in->sin_family!=JNET_AF_INET)return JNET_EINVAL;
    f=get_eflags();disable();if(!socks[i].used){set_eflags(f);return -9;}memcpy(socks[i].rip,&in->sin_addr.s_addr,4);socks[i].rport=ntohs(in->sin_port);socks[i].connected=1;socks[i].rxlen=0;socks[i].rx_pending=0;set_eflags(f);return 0;
}

static int udp_send_now(const BYTE rip[4],WORD lp,WORD rp,const void *buf,unsigned len)
{
    JtNetworkRuntimeInterrupts();
    int n,rv;BYTE frame[JNET_FRAME_MAX],mac[6],hop[4];BYTE *ip,*udp;
    if(!cfg.configured)return JNET_ENETDOWN;
    rv=route_hop(rip,hop);if(rv<0)return rv;rv=arp_resolve(hop,mac);if(rv<0)return rv;
    memset(frame,0,len+42);eth(frame,mac,0x0800);ip=frame+14;udp=ip+20;ip[0]=0x45;ip[8]=64;ip[9]=17;
    memcpy(ip+12,cfg.ip,4);memcpy(ip+16,rip,4);w16(ip+2,len+28);w16(udp,lp);w16(udp+2,rp);w16(udp+4,len+8);if(len)memcpy(udp+8,buf,len);w16(ip+10,csum(ip,20));
    n=ethdev_send(frame,len+42);return n<0?jnet_eth_error(n):(int)len;
}

int jnet_send(int fd,const void *buf,unsigned len,int flags)
{
    JtNetworkRuntimeInterrupts();
    int i=fd-3,f,rv,owner;DWORD start,owner_magic,current_magic;BYTE rip[4];WORD lp,rp;
    (void)flags;if(i<0||i>=JNET_SOCKET_COUNT||(!buf&&len))return -9;if(len>JNET_UDP_PAYLOAD_MAX)return -90;if(!cfg.configured)return JNET_ENETDOWN;
    f=get_eflags();disable();
    if(!socks[i].used||!socks[i].connected){set_eflags(f);return -9;}
    memcpy(rip,socks[i].rip,4);lp=socks[i].lport;rp=socks[i].rport;owner=jnet_owner_pid;owner_magic=jnet_owner_magic;
    current_magic=jnet_thread_magic(GetCurrentThread());
    if(owner==GetCurrentThread() && owner_magic==current_magic){set_eflags(f);return udp_send_now(rip,lp,rp,buf,len);}
    if(!jnet_owner_alive(owner,owner_magic)){
        if(owner>=0){jnet_owner_pid=-1;jnet_owner_magic=0;}
        set_eflags(f);return JNET_ENETDOWN;
    }
    if(send_pending||send_running){set_eflags(f);return JNET_EBUSY;}
    memcpy(send_rip,rip,4);send_lport=lp;send_rport=rp;send_len=len;if(len)memcpy(send_buf,buf,len);
    send_done=0;send_pending=1;set_eflags(f);
    start=GetTickCount();
    while(!send_done&&(DWORD)(GetTickCount()-start)<JNET_SEND_WAIT_MS)
        jnet_request_pause();
    if(!send_done)
    {
        DWORD hard_start;
        unsigned long hard_waits=0;
        f=get_eflags();disable();
        if(send_pending)
        {
            send_pending=0;
            set_eflags(f);
            return JNET_ETIMEDOUT;
        }
        set_eflags(f);

        /* The owner has already started ARP/TX.  Wait for a definitive result,
         * but never forever: owner death or a broken protocol state must not
         * pin a client process indefinitely. */
        hard_start=GetTickCount();
        while(!send_done)
        {
            owner=jnet_owner_pid;
            owner_magic=jnet_owner_magic;
            if(!jnet_owner_alive(owner,owner_magic) ||
               (DWORD)(GetTickCount()-hard_start)>=JNET_SEND_HARD_WAIT_MS ||
               ++hard_waits>=JNET_SEND_HARD_WAIT_LIMIT)
                return JNET_ETIMEDOUT;
            jnet_request_pause();
        }
    }
    f=get_eflags();disable();rv=send_result;send_done=0;set_eflags(f);return rv;
}

int jnet_recv(int fd,void *buf,unsigned len,int flags)
{
    int i=fd-3,n,f;(void)flags;if(i<0||i>=JNET_SOCKET_COUNT||(!buf&&len))return -9;
    f=get_eflags();disable();if(!socks[i].used){set_eflags(f);return -9;}if(!socks[i].rx_pending){set_eflags(f);return JNET_EAGAIN;}
    n=socks[i].rxlen;if((unsigned)n>len)n=(int)len;if(n>0)memcpy(buf,socks[i].rxbuf,n);socks[i].rxlen=0;socks[i].rx_pending=0;set_eflags(f);return n;
}

int jnet_input_ethernet(const BYTE *frame,int len)
{
    const BYTE *ip,*udp,*payload;int ihl,total,ulen,bytes,i,f;WORD sport,dport;
    if(!frame||len<14+20+8||r16(frame+12)!=0x0800) return 0;
    ip=frame+14;
    if((ip[0]>>4)!=4||ip[9]!=17) return 0;
    ihl=(ip[0]&15)*4;total=r16(ip+2);
    if(ihl<20||ihl>60||total<ihl+8||14+total>len)return 0;
    if((r16(ip+6)&0x3fffU)!=0 || csum(ip,ihl)!=0)return 0;
    if(!cfg.configured||!same4(ip+16,cfg.ip))return 0;
    udp=ip+ihl;sport=(WORD)r16(udp);dport=(WORD)r16(udp+2);ulen=r16(udp+4);if(ulen<8||ulen!=total-ihl)return 0;if(!udp_checksum_valid(ip,udp,ulen))return 0;bytes=ulen-8;payload=udp+8;
    f=get_eflags();disable();
    for(i=0;i<JNET_SOCKET_COUNT;i++)
    {
        if(!socks[i].used||socks[i].lport!=dport)continue;
        if(socks[i].connected && (socks[i].rport!=sport||!same4(socks[i].rip,ip+12)))continue;
        if(socks[i].rx_pending){stats.udp_rx_dropped++;set_eflags(f);return 1;}
        if(bytes>JNET_UDP_PAYLOAD_MAX) bytes=JNET_UDP_PAYLOAD_MAX;
        if(bytes>0) memcpy(socks[i].rxbuf,payload,bytes);
        socks[i].rxlen=bytes; socks[i].rx_pending=1; stats.udp_rx_queued++;
        set_eflags(f); return 1;
    }
    set_eflags(f);return 0;
}
