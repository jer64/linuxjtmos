#ifndef JTMOS_ETHDEV_H
#define JTMOS_ETHDEV_H

enum { ETHDEV_NONE=0, ETHDEV_NFORCE=1, ETHDEV_NE2K=2 };

/* Generic backend errors. Backends have private return codes; ethdev maps
 * them into this small stable interface so DHCP/JNET can distinguish a lost
 * carrier from a controller/DMA failure. */
#define ETHDEV_ERR_NO_DEVICE (-1)
#define ETHDEV_ERR_LINK_DOWN (-2)
#define ETHDEV_ERR_IO        (-3)
#define ETHDEV_ERR_INVALID   (-4)
#define ETHDEV_ERR_BUSY      (-5)

typedef struct {
    unsigned long rx_packets;
    unsigned long rx_bytes;
    unsigned long rx_errors;
    unsigned long tx_packets;
    unsigned long tx_bytes;
    unsigned long tx_errors;
    unsigned long link_changes;
    int link_up;
    int last_error;
} ETHDEV_STATS;

int ethdev_init(void);
int ethdev_restart(void);
int ethdev_present(void);
int ethdev_backend(void);
int ethdev_temporarily_quiesced(void);
int ethdev_receive(void *buf,int maxlen);
int ethdev_send(const void *buf,int len);
const unsigned char *ethdev_mac(void);
const char *ethdev_name(void);
int ethdev_link_up(void);
void ethdev_get_stats(ETHDEV_STATS *out);
void ethdev_reset_stats(void);

#endif
