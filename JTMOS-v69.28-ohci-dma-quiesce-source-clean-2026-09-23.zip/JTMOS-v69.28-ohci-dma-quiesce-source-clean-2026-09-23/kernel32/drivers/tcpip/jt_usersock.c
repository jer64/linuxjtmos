/*
 * JTMOS generic userspace TCP streams over uIP.
 * V68.8.57.10.18.16.95 - first consumer: ircII 4.4 JTMOS port.
 *
 * Design rule: uIP remains single-owner.  Ring3 syscall threads never invoke
 * uip_connect/uip_send/uip_close.  They only manipulate bounded queues under
 * the interrupt lock; UipProcess performs all TCP state-machine operations.
 */
#include "kernel32.h"
#include "uip.h"
#include "networkControl.h"
#include "jt_usersock.h"
#include "scheduler.h"

#define JT_USOCK_COUNT       4
#define JT_USOCK_RX_SIZE     4096
#define JT_USOCK_TX_SIZE     4096
#define JT_USOCK_SEG_SIZE    1460

#define JT_USOCK_FREE        0
#define JT_USOCK_PENDING     1
#define JT_USOCK_CONNECTING  2
#define JT_USOCK_OPEN        3
#define JT_USOCK_CLOSING     4
#define JT_USOCK_CLOSED      5

#define JT_USOCK_EBADF       (-9)
#define JT_USOCK_EAGAIN      (-11)
#define JT_USOCK_EBUSY       (-16)
#define JT_USOCK_EINVAL      (-22)
#define JT_USOCK_EPIPE       (-32)
#define JT_USOCK_ENETDOWN    (-100)
#define JT_USOCK_ETIMEDOUT   (-110)
#define JT_USOCK_ECONN       (-111)
#define JT_USOCK_EOF         (-2)

typedef struct {
    int state;
    int owner_pid;
    DWORD owner_magic;
    int port;
    unsigned char ip[4];
    struct uip_conn *conn;
    int close_requested;
    int error;
    unsigned char rx[JT_USOCK_RX_SIZE];
    unsigned int rx_head,rx_tail,rx_count;
    unsigned char tx[JT_USOCK_TX_SIZE];
    unsigned int tx_head,tx_tail,tx_count;
    unsigned char segment[JT_USOCK_SEG_SIZE];
    unsigned int segment_len;
} JT_USER_SOCKET;

static JT_USER_SOCKET usock[JT_USOCK_COUNT];

static void usock_zero(JT_USER_SOCKET *s)
{
    if(s) memset(s,0,sizeof(*s));
}

static DWORD usock_thread_magic(int pid)
{
    if(pid<=0 || pid>=N_MAX_THREADS || !valid_pid(pid)) return 0;
    return thread_magic[pid];
}

static int usock_owner_alive(const JT_USER_SOCKET *s)
{
    if(!s || s->owner_pid<=0 || s->owner_pid>=N_MAX_THREADS ||
       !valid_pid(s->owner_pid) || !thread_states[s->owner_pid]) return 0;
    return s->owner_magic!=0 && thread_magic[s->owner_pid]==s->owner_magic;
}

static int usock_valid_locked(int h,int owner_pid)
{
    if(h<0 || h>=JT_USOCK_COUNT) return 0;
    if(usock[h].state==JT_USOCK_FREE) return 0;
    if(owner_pid>0 && (usock[h].owner_pid!=owner_pid ||
       usock[h].owner_magic!=usock_thread_magic(owner_pid))) return 0;
    if(!usock_owner_alive(&usock[h])) return 0;
    return 1;
}

int JtUserSocketOpen(unsigned long ipaddr,int port,int owner_pid)
{
    int i,f;
    if(port<=0 || port>65535 || owner_pid<=0 || ipaddr==0) return JT_USOCK_EINVAL;
    if(JtInternetState()!=JTMOS_INET_ONLINE) return JT_USOCK_ENETDOWN;
    f=get_eflags();disable();
    for(i=0;i<JT_USOCK_COUNT;i++) if(usock[i].state==JT_USOCK_FREE) {
        usock_zero(&usock[i]);
        usock[i].state=JT_USOCK_PENDING;
        usock[i].owner_pid=owner_pid;
        usock[i].owner_magic=usock_thread_magic(owner_pid);
        if(usock[i].owner_magic==0) { usock_zero(&usock[i]); set_eflags(f); return JT_USOCK_EBADF; }
        usock[i].port=port;
        usock[i].ip[0]=(unsigned char)(ipaddr&255UL);
        usock[i].ip[1]=(unsigned char)((ipaddr>>8)&255UL);
        usock[i].ip[2]=(unsigned char)((ipaddr>>16)&255UL);
        usock[i].ip[3]=(unsigned char)((ipaddr>>24)&255UL);
        set_eflags(f);
        return i;
    }
    set_eflags(f);
    return JT_USOCK_EBUSY;
}

int JtUserSocketClose(int handle,int owner_pid)
{
    int f=get_eflags();
    disable();
    if(!usock_valid_locked(handle,owner_pid)) { set_eflags(f); return JT_USOCK_EBADF; }
    if(usock[handle].state==JT_USOCK_PENDING) {
        usock_zero(&usock[handle]);
        set_eflags(f);
        return 0;
    }
    if(usock[handle].state==JT_USOCK_CLOSED) {
        usock_zero(&usock[handle]);
        set_eflags(f);
        return 0;
    }
    usock[handle].close_requested=1;
    set_eflags(f);
    return 0;
}

int JtUserSocketRead(int handle,void *buffer,int maxlen,int owner_pid)
{
    JT_USER_SOCKET *s;
    unsigned char *out=(unsigned char *)buffer;
    int f,n,i,rv=0;
    if(!buffer || maxlen<=0) return JT_USOCK_EINVAL;
    f=get_eflags();disable();
    if(!usock_valid_locked(handle,owner_pid)) { set_eflags(f); return JT_USOCK_EBADF; }
    s=&usock[handle];
    n=(int)s->rx_count;if(n>maxlen)n=maxlen;
    for(i=0;i<n;i++) {
        out[i]=s->rx[s->rx_tail++];
        if(s->rx_tail>=JT_USOCK_RX_SIZE)s->rx_tail=0;
    }
    s->rx_count-=(unsigned int)n;
    if(n>0) rv=n;
    else if(s->state==JT_USOCK_CLOSED) rv=s->error?s->error:JT_USOCK_EOF;
    set_eflags(f);
    return rv;
}

int JtUserSocketWrite(int handle,const void *buffer,int len,int owner_pid)
{
    JT_USER_SOCKET *s;
    const unsigned char *in=(const unsigned char *)buffer;
    unsigned int free_bytes,n,i;
    int f;
    if(!buffer || len<=0) return JT_USOCK_EINVAL;
    f=get_eflags();disable();
    if(!usock_valid_locked(handle,owner_pid)) { set_eflags(f); return JT_USOCK_EBADF; }
    s=&usock[handle];
    if(s->state==JT_USOCK_CLOSED || s->state==JT_USOCK_CLOSING || s->close_requested) {
        int e=s->error?s->error:JT_USOCK_EPIPE;set_eflags(f);return e;
    }
    free_bytes=JT_USOCK_TX_SIZE-s->tx_count;
    if(free_bytes==0) { set_eflags(f); return JT_USOCK_EAGAIN; }
    n=(unsigned int)len;if(n>free_bytes)n=free_bytes;
    for(i=0;i<n;i++) {
        s->tx[s->tx_head++]=in[i];
        if(s->tx_head>=JT_USOCK_TX_SIZE)s->tx_head=0;
    }
    s->tx_count+=n;
    set_eflags(f);
    return (int)n;
}

static void usock_mark_closed(JT_USER_SOCKET *s,int error)
{
    int f=get_eflags();disable();
    s->state=JT_USOCK_CLOSED;s->error=error;s->conn=NULL;s->segment_len=0;
    set_eflags(f);
}

static int usock_rx_push(JT_USER_SOCKET *s,const unsigned char *p,unsigned int n)
{
    unsigned int i;
    int f=get_eflags();disable();
    if(n>JT_USOCK_RX_SIZE-s->rx_count) { set_eflags(f); return -1; }
    for(i=0;i<n;i++) {
        s->rx[s->rx_head++]=p[i];
        if(s->rx_head>=JT_USOCK_RX_SIZE)s->rx_head=0;
    }
    s->rx_count+=n;
    set_eflags(f);return 0;
}

static void usock_tx_ack(JT_USER_SOCKET *s)
{
    unsigned int n=s->segment_len;
    int f=get_eflags();disable();
    if(n>s->tx_count)n=s->tx_count;
    s->tx_tail=(s->tx_tail+n)%JT_USOCK_TX_SIZE;
    s->tx_count-=n;s->segment_len=0;
    set_eflags(f);
}

static void usock_send_next(JT_USER_SOCKET *s,int retransmit)
{
    unsigned int n,i,pos;
    if(retransmit && s->segment_len) { uip_send(s->segment,(int)s->segment_len); return; }
    if(s->segment_len || !s->tx_count) return;
    n=s->tx_count;if(n>(unsigned int)uip_mss())n=(unsigned int)uip_mss();if(n>JT_USOCK_SEG_SIZE)n=JT_USOCK_SEG_SIZE;
    pos=s->tx_tail;for(i=0;i<n;i++){s->segment[i]=s->tx[pos++];if(pos>=JT_USOCK_TX_SIZE)pos=0;}
    s->segment_len=n;uip_send(s->segment,(int)n);
}

void JtUserSocketService(void)
{
    int i,f;
    u16_t addr[2];
    for(i=0;i<JT_USOCK_COUNT;i++) {
        JT_USER_SOCKET *s=&usock[i];
        if(s->state==JT_USOCK_FREE) continue;
        if(!usock_owner_alive(s) || GetThreadType(s->owner_pid)==0) {
            f=get_eflags();disable();s->close_requested=1;set_eflags(f);
            if(s->state==JT_USOCK_PENDING || s->state==JT_USOCK_CLOSED) { f=get_eflags();disable();usock_zero(s);set_eflags(f); }
            continue;
        }
        if(s->state!=JT_USOCK_PENDING) continue;
        if(s->close_requested) { f=get_eflags();disable();usock_zero(s);set_eflags(f);continue; }
        if(JtInternetState()!=JTMOS_INET_ONLINE) { usock_mark_closed(s,JT_USOCK_ENETDOWN);continue; }
        uip_ipaddr(addr,s->ip[0],s->ip[1],s->ip[2],s->ip[3]);
        s->conn=uip_connect(addr,(u16_t)s->port);
        if(!s->conn) { usock_mark_closed(s,JT_USOCK_ECONN);continue; }
        f=get_eflags();disable();s->state=JT_USOCK_CONNECTING;set_eflags(f);
    }
}

int JtUserSocketAppCall(void)
{
    JT_USER_SOCKET *s=NULL;
    int i;
    unsigned int n;
    if(!uip_conn)return 0;
    for(i=0;i<JT_USOCK_COUNT;i++) if(usock[i].state!=JT_USOCK_FREE && usock[i].conn==uip_conn) { s=&usock[i];break; }
    if(!s)return 0;
    if(!usock_owner_alive(s)) {
        usock_mark_closed(s,JT_USOCK_EBADF);
        uip_abort();
        return 1;
    }

    if(uip_newdata() && uip_datalen()>0) {
        n=(unsigned int)uip_datalen();
        if(usock_rx_push(s,(const unsigned char *)uip_appdata,n)<0) {
            usock_mark_closed(s,-75);uip_abort();return 1;
        }
        /* Reward only genuine inbound bytes, never empty socket polling. */
        SchedulerNoteActivity(s->owner_pid,SCHED_ACTIVITY_NETWORK,
                              (int)((n+511U)/512U));
        uip_len=0;
    }
    if(uip_aborted()) { usock_mark_closed(s,JT_USOCK_ECONN);return 1; }
    if(uip_timedout()) { usock_mark_closed(s,JT_USOCK_ETIMEDOUT);return 1; }
    if(uip_closed()) { usock_mark_closed(s,0);return 1; }

    if(uip_connected()) s->state=JT_USOCK_OPEN;
    if(uip_acked() && s->segment_len) usock_tx_ack(s);

    if(s->close_requested && s->segment_len==0 && s->tx_count==0) {
        s->state=JT_USOCK_CLOSING;uip_close();return 1;
    }
    if(uip_rexmit() && s->segment_len) { usock_send_next(s,1);return 1; }
    if((uip_connected() || uip_acked() || uip_poll()) && s->segment_len==0 && s->tx_count)
        usock_send_next(s,0);
    return 1;
}

void JtUserSocketNetworkReset(void)
{
    int i,f=get_eflags();disable();
    for(i=0;i<JT_USOCK_COUNT;i++) usock_zero(&usock[i]);
    set_eflags(f);
}
