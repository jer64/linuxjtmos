#ifndef JTMOS_NFORCE_H
#define JTMOS_NFORCE_H

#include "basdef.h"

int nforce_init(void);
int nforce_restart(void);
int nforce_present(void);
int nforce_receive(void *buf,int maxlen);
int nforce_send(const void *buf,int len);
const unsigned char *nforce_mac(void);
int nforce_link_up(void);
const char *nforce_pci_name(void);
int nforce_phy_addr(void);
unsigned int nforce_phy_oui(void);
int nforce_phy_model(void);
int nforce_phy_rev(void);
int nforce_link_speed(void);
int nforce_full_duplex(void);
int nforce_get_irq_debug(DWORD *irqstat,DWORD *irqmask,WORD *pci_command);

#endif
