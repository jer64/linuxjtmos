/*
 * networkControl.c - runtime SLIP/IP lifecycle for JTMOS SMSH.
 *
 * V68.200 starts the native Ethernet/uIP owner only after the SMSH storage/
 * install bootstrap has completed (with SLIP fallback), or explicitly through
 * `internet start`.  The workers are kernel threads, so DHCP maintenance and
 * servers remain alive independently once started.
 */
#include "kernel32.h"
#include "scheduler.h"
#include "keropt.h"
#include "slip.h"
#include "slipKernelMain.h"
#include "slipStack.h"
#include "uipMain.h"
#include "networkControl.h"
#include "jt_httpd.h"
#include "jt_telnetd.h"
#include "jt_http_client.h"
#include "ethdev.h"
#include "jnet.h"

static THREAD inet_slip_thread;
static THREAD inet_stack_thread;
static int inet_stacks_allocated = 0;
static volatile int inet_state = JTMOS_INET_OFFLINE;
static volatile int inet_stop_requested = 0;
static int inet_slip_pid = 0;
static int inet_stack_pid = 0;
static int inet_com_port = 1; /* COM2 */
static int inet_bps = 115200;


/* Long-running network work is process context, not an IRQ critical section.
 * The native Ethernet backends are polling based, but keyboard/PIT/serial IRQs
 * must remain live while DHCP, ARP, DNS, ICMP or TCP waits are in progress.
 * Early boot/storage-safe callers deliberately retain their current IF state. */
void JtNetworkRuntimeInterrupts(void)
{
    static unsigned int recovered_if0;
    DWORD flags;

    if(!Multitasking || PitStorageSafeActive())
        return;

    flags=get_eflags();
    if(!(flags & 0x200UL))
    {
        /* If this ever fires during ping/DHCP/DNS, a process-context network
         * path really did inherit IF=0.  Keep the first few events visible on
         * serial without turning a hot loop into a printk flood. */
        recovered_if0++;
        if(recovered_if0<=8U)
            printk("NET/IRQ: recovered IF=0 pid=%d count=%u.\n",
                   GetCurrentThread(),recovered_if0);
        enable();
    }
}

static int thread_is_alive(int pid)
{
    if(pid <= 0)
        return 0;
    return GetThreadPriority((DWORD)pid) != 0;
}

int JtInternetStart(int com_port, int bps)
{
    DWORD flags;

    if(inet_state == JTMOS_INET_ONLINE || inet_state == JTMOS_INET_STARTING)
        return 1;

    if(com_port < 0 || com_port > 3)
        return -1;
    if(bps < 1200 || bps > 115200)
        return -2;

    if(thread_is_alive(inet_slip_pid) || thread_is_alive(inet_stack_pid))
        return -3;

    inet_com_port = com_port;
    inet_bps = bps;
    SLIP_COM_PORT_N = com_port;
    DefaultSlipBPS = bps;

    /* uIP is the maintained RFC1055 consumer in this release and also owns
     * the SMSH-managed HTTP service.  The older drivers/tcp stack remains in
     * the source tree but must never consume the same SLIP queue in parallel. */
    USE_LEGACY_UIP = 1;

    slipOnline = 0;
    slipStackReady = 0;
    inet_stop_requested = 0;
    inet_state = JTMOS_INET_STARTING;
    JtHttpdNetworkReset();
    JtTelnetdNetworkReset();
    JtHttpClientNetworkReset();

    /* Prefer native PCI Ethernet, then NE2000; retain SLIP as fallback. */
    if(!ethdev_present()) jnet_init_ethernet();

    if(!inet_stacks_allocated)
    {
        memset(&inet_slip_thread, 0, sizeof(inet_slip_thread));
        memset(&inet_stack_thread, 0, sizeof(inet_stack_thread));
        if(ThreadCreateStack(&inet_slip_thread,JTMOS_MIN_DYNAMIC_STACK)!=0)
        {
            inet_state=JTMOS_INET_OFFLINE;
            return -4;
        }
        if(ThreadCreateStack(&inet_stack_thread,JTMOS_MIN_DYNAMIC_STACK)!=0)
        {
            ThreadDestroyStack(&inet_slip_thread);
            memset(&inet_slip_thread,0,sizeof(inet_slip_thread));
            inet_state=JTMOS_INET_OFFLINE;
            return -4;
        }
        inet_stacks_allocated = 1;
    }

    /* create_thread()/IdentifyThread() allocate, inherit process metadata and may
     * take scheduler-visible locks.  Do not wrap those operations in CLI.
     * Only publish the pair of worker PIDs atomically after creation. */
    JtNetworkRuntimeInterrupts();
    if(ethdev_present()) inet_slip_thread.pid=0;
    else inet_slip_thread.pid = create_thread(inet_slip_thread.stack,
        inet_slip_thread.l_stack, SlipProcess);
    inet_stack_thread.pid = create_thread(inet_stack_thread.stack,
        inet_stack_thread.l_stack, UipProcess);
    if(inet_slip_thread.pid > 0)
        IdentifyThread(inet_slip_thread.pid, "slipd");
    if(inet_stack_thread.pid > 0)
        IdentifyThread(inet_stack_thread.pid, "uip");

    flags = get_eflags();
    disable();
    inet_slip_pid = inet_slip_thread.pid;
    inet_stack_pid = inet_stack_thread.pid;
    set_eflags(flags);

    if((!ethdev_present() && inet_slip_pid <= 0) || inet_stack_pid <= 0)
    {
        inet_stop_requested = 1;
        inet_state = JTMOS_INET_STOPPING;
        return -5;
    }

    return 0;
}

int JtInternetStop(void)
{
    if(inet_state == JTMOS_INET_OFFLINE)
        return 1;

    inet_stop_requested = 1;
    inet_state = JTMOS_INET_STOPPING;
    JtHttpdNetworkStop();
    JtTelnetdNetworkStop();
    return 0;
}

int JtInternetRestart(void)
{
    DWORD started;
    int rv;
    int had_ethernet=ethdev_present();
    int com=inet_com_port;
    int bps=inet_bps;

    if(inet_state != JTMOS_INET_OFFLINE)
    {
        rv=JtInternetStop();
        if(rv<0) return rv;
        JtNetworkRuntimeInterrupts();
        started=GetTickCount();
        while(JtInternetState()!=JTMOS_INET_OFFLINE &&
              (DWORD)(GetTickCount()-started)<3000UL)
        {
            JtNetworkRuntimeInterrupts();
            SchedulerWaitPause(5000UL);
        }
        if(JtInternetState()!=JTMOS_INET_OFFLINE)
        {
            printk("Internet: restart timed out waiting for uIP workers to exit.\n");
            return -6;
        }
    }

    /* No network owner is alive now.  Drop all stale DHCP/ARP/socket/request
     * state before touching the NIC, then perform a real controller restart. */
    jnet_reset_runtime();
    rv=ethdev_restart();
    if(rv<0 && had_ethernet)
    {
        printk("Internet: Ethernet restart failed (%d).\n",rv);
        return -7;
    }

    rv=JtInternetStart(com,bps);
    if(rv==1) return 0;
    return rv;
}

int JtInternetStopRequested(void)
{
    return inet_stop_requested;
}

void JtInternetThreadExited(int which)
{
    if(which == 0)
    {
        inet_slip_pid = 0;

        /* If the serial side dies while the link is still starting, wake the
         * uIP worker as well.  Otherwise UipProcess() could wait forever for
         * slipOnline on a failed COM-port start. */
        if(inet_state == JTMOS_INET_STARTING && !slipOnline)
        {
            inet_stop_requested = 1;
            inet_state = JTMOS_INET_STOPPING;
        }
    }
    else
        inet_stack_pid = 0;

    if(!thread_is_alive(inet_slip_pid) && !thread_is_alive(inet_stack_pid))
    {
        inet_slip_pid = 0;
        inet_stack_pid = 0;
        inet_stop_requested = 0;
        inet_state = JTMOS_INET_OFFLINE;
    }
}

int JtInternetState(void)
{
    if(inet_state != JTMOS_INET_STOPPING && ethdev_present())
    {
        const JNET_CONFIG *nc=jnet_config();
        int ready=nc && nc->configured && ethdev_link_up();
        if(ready && inet_state==JTMOS_INET_STARTING)inet_state=JTMOS_INET_ONLINE;
        else if(!ready && inet_state==JTMOS_INET_ONLINE)inet_state=JTMOS_INET_STARTING;
    }
    else if(inet_state == JTMOS_INET_STARTING && slipOnline && slipStackReady)
        inet_state = JTMOS_INET_ONLINE;

    if(inet_state != JTMOS_INET_OFFLINE &&
       !thread_is_alive(inet_slip_pid) && !thread_is_alive(inet_stack_pid))
    {
        inet_slip_pid = 0;
        inet_stack_pid = 0;
        inet_stop_requested = 0;
        inet_state = JTMOS_INET_OFFLINE;
    }

    return inet_state;
}

int JtInternetSlipPID(void) { return inet_slip_pid; }
int JtInternetStackPID(void) { return inet_stack_pid; }
int JtInternetComPort(void) { return inet_com_port; }
int JtInternetBPS(void) { return inet_bps; }
const char *JtInternetStackName(void) { return ethdev_present()?ethdev_name():"uIP/RFC1055"; }
