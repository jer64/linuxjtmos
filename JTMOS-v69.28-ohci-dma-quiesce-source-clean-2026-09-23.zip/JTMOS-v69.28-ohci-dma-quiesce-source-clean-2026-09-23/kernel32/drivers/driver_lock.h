#ifndef __INCLUDED_DRIVER_LOCK_H__
#define __INCLUDED_DRIVER_LOCK_H__

#include "lock.h"

void driver_lockOffAt(int lockNr,const char *function,const char *file,int line);
void driver_lockOnAt(int lockNr,const char *function,const char *file,int line);
int driver_getLock(int lockNr);
void driver_forceSetLock(int lockNr, int what);
void driver_directAccessLockOnAt(const char *function,const char *file,int line);
void driver_directAccessLockOffAt(const char *function,const char *file,int line);
int driver_lock_snapshot(JTMOS_LOCK_MONITOR_ENTRY *out,int capacity);

#ifndef JTMOS_DRIVER_LOCK_IMPLEMENTATION
#define driver_lockOn(lockNr) \
    driver_lockOnAt((lockNr),__FUNCTION__,__FILE__,__LINE__)
#define driver_lockOff(lockNr) \
    driver_lockOffAt((lockNr),__FUNCTION__,__FILE__,__LINE__)
#define driver_directAccessLockOn() \
    driver_directAccessLockOnAt(__FUNCTION__,__FILE__,__LINE__)
#define driver_directAccessLockOff() \
    driver_directAccessLockOffAt(__FUNCTION__,__FILE__,__LINE__)
#endif

#endif
