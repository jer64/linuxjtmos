// slipConfig.c
#include <stdio.h>
#include "slip.h"
#include "slipLogin.h"
#include "slipConfig.h"
#include "slipStack.h"
#include "keropt.h"

//
int slip_debug = TRUE;
char user[100]="slip";
char passwd[100]="slip";

// Read & parse slip configuration
void slipReadConfiguration(void)
{
	FILE *f JTM_UNUSED;
	int i JTM_UNUSED,value JTM_UNUSED,line JTM_UNUSED;
	static char str[256] JTM_UNUSED,par[256] JTM_UNUSED;

	/* Kernel policy owns the physical line.  Port numbers are zero based:
	 * 0=COM1, 1=COM2, ... */
	slip.bps = DefaultSlipBPS;
	slip.port = SLIP_COM_PORT_N;
	if(slip.port < 0 || slip.port > 3)
		slip.port = 1;
	if(slip.bps <= 0)
		slip.bps = 115200;

	//
}



