// ================================================================================
// driver_flush.c (obsolete stuff mostly)
// (C) 2002-2004 by Jari Tuominen.
// ================================================================================
#include "basdef.h"
#include "sysmem.h"
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
#include "driver_api.h"
#include "driver_sys.h"
#include "driver_lock.h"
#include "driver_rw.h" // readblock...
#include "driver_flush.h"
#include "kyber.h"
//#include "FatFlush.h" // FlushFat
#include "driver_diskchange.h"

//-------------------------------------------------------------
//
void driver_TriggerCacheFlush1(void)
{
	DEBLINE
	(void)sync();
	_FlushCache();
}

// Trigger FAT cache flush
void driver_TriggerCacheFlush(void)
{
	//
	DEBLINE

	(void)sync();
	_FlushCache();

/*	//
	while(FlushFat) { SwitchToThread(); }
	FlushFat = TRUE;
	while(FlushFat) { SwitchToThread(); }*/
}

//-------------------------------------------------------------
// FOR APPLICATIONS
//
void FlushAll(void)
{
	/* Historical API, now functional: flush device-level write caches. */
	_FlushCache();
}

// ==========================================================
// FlushCache --- THE MAIN CACHE FLUSH FUNCTION -------------
//
// __FOR CACHEFLUSHER PROCESS ONLY__:
//
// This function is ONLY used by
// CacheFlusher kernel process.
//
// Flushes all known system caches,
// so far we only have one in driver API.
// ==========================================================
void _FlushCache(void)
{
	int i,i2 JTM_UNUSED,i3 JTM_UNUSED,i4 JTM_UNUSED;
	char str[50];

	//
	DEBLINE

	//
	if(jtmos_debug) { printk("PASS 1\n"); }

	//
	if(jtmos_debug) { printk("PASS 2\n"); }

	// ---- DEVICE DRIVERS CACHE FLUSH ------------------------
	// L1: Flush device drivers own internal caches
	//
	printk("driver/FlushCache: Flushing L1 cache: ");
	//
	for(i=0; i<devdb->n_devices; i++)
	{
		//if( !driver_getAlias(i) )
		driver_getdevicename(i, str);
		printk("%s: ", str);
		driver_FlushDrive(i);
	}
	//
	printk("\ndriver/FlushCache: Flush completed OK\n");
	// -------------------------------------------------------



	//
	if(jtmos_debug) { printk("PASS 3\n"); }

	//
	return;
}

//
int driver_FlushDrive(int dnr)
{
	DEVICE_ENTRY *de;
	int err=0,rv;
	static DWORD flush_seq=0;
	DWORD seq;
	DEBLINE
	if(!isValidDevice(dnr)) return 1;
	de = driver_getdevice(dnr);
	if(de == NULL || !(de->type & DEVICE_TYPE_BLOCK)) return 1;
	seq=++flush_seq;
	if(seq<=8 || (seq&0xffUL)==0)
		dprintk("DRIVER/flush #%u begin dnr=%d dev=%s readcache=%d writeback=%d.\n",
		        (unsigned)seq,dnr,de->device_name,de->DAPIReadCache,de->DAPIWriteBackCache);
	kyber_barrier_begin(dnr);
	/* L2 generic write-back cache must drain before the driver's own L1 cache. */
	if(driver_block_cache_flush(dnr)!=0)
	{
		printk("driver/FlushCache: DAPI write-back flush failed for device %d.\n",dnr);
		err=1;
	}
	rv=device_call(dnr, DEVICE_CMD_FLUSH, 0,0,0,0, NULL, NULL);
	if(rv!=0)
	{
		printk("driver/FlushCache: device flush failed for device %d (error %d).\n",dnr,rv);
		err=1;
	}
	kyber_barrier_end(dnr);
	if(err || seq<=8 || (seq&0xffUL)==0)
		dprintk("DRIVER/flush #%u end dnr=%d device-rv=%d result=%d.\n",
		        (unsigned)seq,dnr,rv,err?1:0);
	return err ? 1 : 0;
}

