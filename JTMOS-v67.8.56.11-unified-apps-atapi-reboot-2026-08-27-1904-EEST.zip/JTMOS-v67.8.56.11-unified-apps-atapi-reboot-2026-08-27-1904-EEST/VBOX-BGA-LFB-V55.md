JTMOS V55 - VirtualBox/Bochs BGA Linear Framebuffer driver
==========================================================
Date: 2026-08-21

What changed
------------

* Added kernel32/drivers/vga/vboxbga.c and vboxbga.h.
* The driver uses the BGA/VBE-DISPI ports 0x01CE/0x01CF directly from
  protected mode; BIOS INT 10h is not required for this path.
* It detects B0C0..B0C4 and VirtualBox BE00..BE02 adapter IDs.
* It sets the GraOS mode to 640x480x8 with a linear framebuffer.
* VirtualBox LFB discovery first uses DISPI index 0x0B (FB_BASE_HI), then
  falls back to PCI BAR0 discovery for VirtualBox 80EE:BEEF and
  Bochs/QEMU 1234:1111 devices.  ISA Bochs has a final 0xE0000000 fallback.
* The driver feeds the existing vesa_frame_buf/vesa_pitch/vesa_* contract.
  JTMOS paging therefore maps the framebuffer before VesaActivate() clears
  or draws it, and GraOS can continue using VesaDrawFrame().
* InitSystem now tries VBox/BGA first when START_GRAOS=1, then falls back to
  the existing boot32 VESA ModeInfoBlock path.

How to use with VirtualBox
--------------------------

Use the legacy VBoxVGA graphics controller for this driver.  Give the VM
at least a few MiB of video RAM.  For the existing JTMOS GraOS startup path,
set START_GRAOS=1 in kernel32/init/keropt.c and build with GRAOS_BOOT=1
(e.g. the existing modules.graos-vesa.conf already retains the required
GraOS/application pieces; despite its historical name it can also be used
with this BGA-first kernel path).

The BGA driver itself does not require PCI=1 in modules.conf: it performs a
small local PCI configuration-space read only as an LFB-address fallback,
before the normal PCI subsystem starts.

Boot sequence
-------------

  protected mode
      -> VBoxBgaSetupGraOS()
          -> probe 0x01CE/0x01CF
          -> find LFB address
          -> set 640x480x8 + LFB
          -> populate shared vesa_* framebuffer descriptor
      -> if unavailable: VesaProbe() bootloader fallback
      -> mmInit()/pg_init()
          -> identity-map exact framebuffer pages
      -> VesaActivate()
          -> program RGB332 palette
          -> clear framebuffer
          -> enable JTMOS LFB drawing
      -> GraOS

Validation
----------

The new source is compiled with the same GCC i386/freestanding flags as the
V54 kernel.  Full VirtualBox runtime testing is not possible in this build
container because VirtualBox is not installed here.  See
V55-VBOX-BGA-TEST-RESULTS.txt for the exact build/static checks performed.
