//--------------------------------------------------------------------------------------------
// threadSwitch.c - thread switching logic.
//--------------------------------------------------------------------------------------------
#include "kernel32.h"
#include "threads.h"
#include "threadSwitch.h"
#include "scheduler.h"

// Aka ASCPI sleep.
int vmware_sleep_enabled = TRUE;
//
static int SleepTime=2;
//
static int goback=0;

//
void vmware_sleep(void)
{
	//
	if(vmware_sleep_enabled && vmware)
	{
		vmsleep();
	}
}

//--------------------------------------------------------------------------------------------
// Used by ScheduleNextThread and timerhandler.mac.
//
void forceSwitch(void)
{
    int idle;
    int old_pid;
    int candidate;
    int attempts;
    int return_thread;
    TSSEG *t;
    char str2[256];

    idle=IdleThread.pid;
    old_pid=nr_curthread;

    /* Ordered one-shot transfer used by SwitchToThreadEx(). */
    if(force_switch_thread_nr && !goback) {
        candidate=force_switch_thread_nr;
        force_switch_thread_nr=0;
        if(candidate>=0 && candidate<nr_threads && thread_states[candidate]) {
            goback=nr_curthread;
            nr_curthread=candidate;
            thread_idling[nr_curthread]=0;
            return;
        }
    }

    /* Preserve the historical return-to-caller behaviour after a forced
     * transfer, but never resurrect a dead PID. */
    if(goback) {
        return_thread=goback;
        goback=0;
        if(return_thread>=0 && return_thread<nr_threads && thread_states[return_thread]) {
            nr_curthread=return_thread;
            return;
        }
    }

    /* RRS chooses the best runnable task.  Invalid TSS entries are quarantined
     * and selection is retried, preserving the old scheduler's safety rule. */
    candidate=old_pid;
    for(attempts=0;attempts<nr_threads;attempts++) {
        candidate=SchedulerPickNext(candidate);
        if(candidate==idle) {
            nr_curthread=candidate;
            thread_idling[candidate]=0;
            return;
        }
        if(candidate<0 || candidate>=nr_threads || !thread_states[candidate]) continue;
        t=GetThreadTSS(candidate);
        if(t==NULL || !t->cs || !t->ds || !t->es || !t->fs) {
            GetThreadName(candidate,str2);
            dprintk("%s: quarantining process %d(%s): invalid TSS selectors.\n",
                    __FUNCTION__,candidate,str2);
            if(candidate==0) KERNEL_FATAL("scheduler: PID0 has an invalid TSS");
            thread_states[candidate]=0;
            SchedulerPriorityChanged(candidate,0);
            continue;
        }
        nr_curthread=candidate;
        return;
    }

    if(idle>=0 && idle<nr_threads && thread_states[idle]) nr_curthread=idle;
    else nr_curthread=0;
}

