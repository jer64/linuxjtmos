/*
 * unipid.h - obsolete JTMOS source compatibility shim
 *
 * V65 uses plain process IDs (PID == thread table index).  New kernel code
 * must use valid_pid(pid) and pass pid values directly.  These identity
 * macros exist only so archived/out-of-tree source can still be inspected or
 * compiled during the transition; the active kernel does not include this
 * header.
 */
#ifndef __INCLUDED_UNIPID_H__
#define __INCLUDED_UNIPID_H__
#define RPID(x) (x)
#define UNIF(x) if(valid_pid((x)))
#endif
