//
#include "kernel32.h"
#include "lock.h"

static volatile int lock[1000];

void Lock(int lockID)
{
    int flags;
    unsigned long spins;

    if(!Multitasking)
        return;
    if(lockID < 0 || lockID >= 1000)
        return;

    flags = get_eflags();
    spins = 0;
    disable();

    while(lock[lockID])
    {
        set_eflags(flags);

        if(Multitasking && !PitStorageSafeActive() && (flags & 0x200))
            SwitchToThread();
        else
        {
            volatile unsigned long i;
            for(i=0; i<128; i++) { }
        }

        disable();
        if(++spins >= JTMOS_LOCK_SPIN_LIMIT)
        {
            set_eflags(flags);
            printk("Lock(%d): contention timeout, retrying.\n", lockID);
            spins = 0;
            disable();
        }
    }

    lock[lockID] = 1;
    set_eflags(flags);
}

void Unlock(int lockID)
{
    int flags;

    if(!Multitasking)
        return;
    if(lockID < 0 || lockID >= 1000)
        return;

    flags = get_eflags();
    disable();
    lock[lockID] = 0;
    set_eflags(flags);
}
