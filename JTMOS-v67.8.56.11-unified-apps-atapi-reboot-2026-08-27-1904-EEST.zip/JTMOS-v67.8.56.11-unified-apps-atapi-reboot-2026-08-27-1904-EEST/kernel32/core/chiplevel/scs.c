// ======================================================================
// scs.c - JTMOS system call services.
// (C) 2002-2021 by Jari Tuominen
// (jari.t.tuominen@gmail.com).
//
// Note: all system calls implement it's callers stack,
// therefore all pointer references to the local variables,
// that are stored in the present stack are either invalid
// or must be specifically converted from USER memory space
// addressing to the KERNEL memory space addressing.
//
// This is a major bug that have been raging the system
// for a very long time.
// ======================================================================
#include "kernel32.h"
#include "systemcalls.h" // aka scs.h
#include "scconf.h" // contains only defines, works with nasm
#include "ega.h" // N_VIRTUAL_TERMINALS
#include "threads.h" // SwitchToThreadEx
#include "scs.h"
#include "scs2.h"
#include "scs_devices.h" // sys_readblock, etc.
#include "mouse.h"
#include "ps2mouse.h"
#include "msgbox.h"
#include "driver_diskchange.h"
#include "serial.h"
#include "scheduler.h"
#include "audio.h"
#include "userhw.h"
#include "sysgfx.h"
#include "vga.h"
#include "int.h"

//
void *scall_functions[N_MAX_SCALLS]={
	// 0
	// dummy entry, never ought to be called
	scall_dummy,
	// 1 SYS_IDLE
	idle_moment,
	// 2 SYS_remove
	scall_remove,
	// 3 SYS_mkfs
	scall_mkfs,
	// 4 SYS_rename
	scall_rename,
	// 5
	scall_dummy,
	// 6 SYS_PUTS
	scall_puts,
	// 7 SYS_PUTCH
	scall_putchar,
	// 8 SYS_EXIT
	scall_exit,
	// 9 SYS_CLRSCR
	scall_clrscr,
	// 10 SYS_GETCH
	scall_getch,
	// 11 postcmd
	scall_postcmd,
	// 12 SYS_GETCURDEV
	scall_getcurdev,
	// 13 SYS_GOTOXY
	scall_gotoxy,
	// 14 SYS_GETTICKCOUNT
	scall_gettickcount,
	// 15 SYS_GETAMEMSIZE
	scall_getamemsize,
	// 16 SYS_GETCURRENTTHREAD
	scall_getcurrentthread,
	// 17 SYS_GETARGC
	scall_getargc,
	// 18 SYS_GETARGV
	scall_getargv,
	// 19 SYS_open
	scall_open,
	// 20 SYS_close
	scall_close,
	// 21 SYS_read
	scall_read,
	// 22 SYS_write
	scall_write,
	// 23 SYS_lseek
	scall_lseek,
	// 24 SYS_cexec
	scall_cexec,
	// 25 SYS_getdevnrbyname
	scall_getdevnrbyname,
	// 26 SYS_readblock
	scall_readblock,
	// 27 SYS_writeblock
	scall_writeblock,
	// 28 SYS_waitprocterm
	scall_waitprocterm,
	// 29 SYS_findfirst
	scall_findfirst,
	// 30 SYS_findnext
	scall_findnext,
	// 31 SYS_textcolor
	scall_textcolor,
	// 32 SYS_textbackground
	scall_textbackground,
	// 33 SYS_inputmouse
	scall_inputmouse,
	// 34 SYS_setmouserect
	scall_setmouserect,
	// 35 SYS_vgadrawframe
	scall_vgadrawframe,
	// 36 SYS_GETCURDB
	scall_getcurdb,
	// 37 SYS_vgawaitretrace
	scall_vgawaitretrace,
	// 38 SYS_chdir
	scall_chdir,
	// 39 SYS_getdevicename
	scall_getdevicename,
	// 40 SYS_getdate
	scall_getdate,
	// 41 SYS_WHEREX
	scall_wherex,
	// 42 SYS_WHEREY
	scall_wherey,
	// 43 SYS_vgaselectplane
	scall_vgaselectplane,
	// 44 getdevicenrbyname
	scall_getdevicenrbyname,
	// 45 
	scall_getthreadpriority,
	// 46
	scall_getthreadspending,
	// 47
	scall_getthreadname,
	// 48
	scall_getthreadmemoryusage,
	// 49
	scall_getthreadcount,
	// 50
	scall_getctrl,
	// 51
	scall_getalt,
	// 52 Activate thread's MSGBOX
	scall_activatemsgbox,
	// 53 Send message to a PID
	scall_sendmessage,
	// 54 Receive message
	scall_receivemessage,
	// 55 getthreadpid
	scall_getthreadpid,
	// 56 identifythread
	scall_identifythread,
	// 57 getseconds
	scall_getseconds,
	// 58 globalcopy
	scall_globalcopy,
	// 59 getthreadterminal
	scall_getthreadterminal,
	// 60 setthreadterminal
	scall_setthreadterminal,
	// 61 NewTerminal
	scall_newterminal,
	// 62 outputterminalkeyboardbuffer
	scall_outputterminalkeyboardbuffer,
	// 63 inputterminalkeyboardbuffer
	scall_inputterminalkeyboardbuffer,
	// 64 copyterminal
	scall_copyterminal,
	// 65 killthread
	scall_killthread,
	// 66 getcursorlocation
	scall_getcursorlocation,
	// 67 setint
	scall_setint,
	// 68 enableirq
	scall_enableirq,
	// 69 diskchange
	scall_diskchange,
	// 70 legacy PID identity (former getthreaduniquepid)
	scall_getthreaduniquepid,
	// 71 registernewdevice
	scall_registernewdevice,
	// 72 switchtothreadex
	scall_switchtothreadex,
	// 73 createterminal
	scall_createterminal,
	// 74 setterminalowner
	scall_setterminalowner,
	// 75 getterminalowner
	scall_getterminalowner,
	// 76 serialget
	scall_serialget,
	// 77 serialput
	scall_serialput,
	// 78 setserialportspeed
	scall_setserialportspeed,
	// 79 receiverawpacket
	scall_receiverawpacket,
	// 80 transmitrawpacket
	scall_transmitrawpacket,
	// 81 devicecall
	scall_devicecall,
	// 82 milsleep
	scall_milsleep,
	// 83 opensocket
	scall_opensocket,
	// 84 closesocket
	scall_closesocket,
	// 85 readsocket
	scall_readsocket,
	// 86 writesocket
	scall_writesocket,
	// 87 switchtothread
	scall_switchtothread,
	// 88 getcwd
	scall_getcwd,
	// 89 stat
	scall_stat,
	// 90 fstat
	scall_fstat,
	// 91 SYS_wgetch
	scall_wgetch,
	// 92 SYS_mkdir
	scall_mkdir,
	// 93 kmalloc
	scall_kmalloc,
	// 94 kfree
	scall_kfree,
	// 95 SYS_fexist
	scall_fexist1,
	// 96 SYS_getfiledatablock
	scall_getfiledatablock,
	// 97 SYS_isdriveready
	scall_isdriveready,
	// 98 SYS_diskchange_compat (legacy duplicate of syscall 69)
	scall_diskchange,
	// 99 SYS_getfilesize
	scall_getfilesize,
	// 100 SYS_read1
	scall_read1,
	// 101 SYS_write1
	scall_write1,
	// 102 SYS_creat1
	scall_creat1,
	// 103 SYS_unlink1
	scall_unlink1,
	// 104 SYS_setsize1
	scall_setsize,
	// 105 SYS_getcpustats
	scall_getcpustats,
	// 106 SYS_usleep
	scall_usleep,
	// 107 SYS_audioinit
	scall_audioinit,
	// 108 SYS_audiowrite
	scall_audiowrite,
	// 109 SYS_audioposition
	scall_audioposition,
	// 110 SYS_audiostop
	scall_audiostop,
	// 111 SYS_audioinfo
	scall_audioinfo,
	// 112 SYS_audioselect
	scall_audioselect,
	// 113 SYS_window (Turbo C 1-based inclusive coordinates)
	scall_window,
	// 114 SYS_copyfromthread (kernel-assisted GUI framebuffer copy)
	scall_copyfromthread,
	// 115 SYS_irqsubscribe
	scall_irqsubscribe,
	// 116 SYS_irqunsubscribe
	scall_irqunsubscribe,
	// 117 SYS_irqwait
	scall_irqwait,
	// 118 SYS_dmaalloc
	scall_dmaalloc,
	// 119 SYS_dmafree
	scall_dmafree,
	// 120 SYS_dmaprogram
	scall_dmaprogram,
	// 121 SYS_dmastop
	scall_dmastop,
	// 122 SYS_vgasetpalette
	scall_vgasetpalette,
	// 123 SYS_getcpufeatures
	scall_getcpufeatures,
	// 124 SYS_graosgraphics
	scall_graosgraphics,
	// 125 SYS_readblocks
	scall_readblocks,
	// 126 SYS_writeblocks
	scall_writeblocks,
	// 127 SYS_fork
	scall_fork
};

// Number of system calls registered
DWORD nr_scall_func = 128;


//--------------------------------------------------------------------------
//
// A2K.
// Application to Kernel memory space address conversion function.
//
DWORD A2K(DWORD appoffs)
{
	return _A2KRange(appoffs,1,GetCurrentThread());
}

// PID specific.
DWORD _A2K(DWORD appoffs, int pid)
{
    return _A2KRange(appoffs,1,pid);
}

DWORD A2KRange(DWORD appoffs, DWORD length)
{
    return _A2KRange(appoffs,length,GetCurrentThread());
}

DWORD _A2KRange(DWORD appoffs, DWORD length, int pid)
{
	DWORD tb;
	DWORD dma_address;
	DWORD user_bytes;
	int type;

	if(length == 0)
		return 0;
	type = GetThreadType(pid);
	if(!(type & (THREAD_TYPE_APPLICATION|THREAD_TYPE_KERNEL)))
		return 0;

	/* V65 DMA mappings live outside the historical contiguous application
	 * backing image. Resolve those first so normal read/write/device syscalls
	 * can safely accept a DMA buffer pointer too. */
	dma_address = userhw_dma_translate_range(pid, appoffs, length);
	if(dma_address)
		return dma_address;

	/* ELF applications run in the V67 flat Ring3 address window.  Legacy
	 * segmented applications use their historical trusted-pointer ABI and
	 * must not be interpreted as MM_USER_BASE offsets. */
	if((type & THREAD_TYPE_APPLICATION) && thread_selector[pid] == USER_CS)
	{
		if(appoffs < MM_USER_BASE || !(tb=GetThreadBase(pid)))
			return 0;
		user_bytes=(DWORD)thread_memkb[pid]*1024UL;
		if(user_bytes>MM_USER_SIZE)
			user_bytes=MM_USER_SIZE;
		if(appoffs-MM_USER_BASE>=user_bytes ||
		   length>user_bytes-(appoffs-MM_USER_BASE))
			return 0;
		return (appoffs-MM_USER_BASE)+tb;
	}
	if(type & THREAD_TYPE_APPLICATION)
		return appoffs;

	/* Only native kernel threads use native kernel addresses. */
	return appoffs;
}

/* Copy a NUL-terminated userspace string without ever reading beyond the
 * caller's validated mapping.  A missing terminator is an error. */
static int scall_copyin_string(DWORD address, char *out, DWORD capacity)
{
	DWORD i;
	char *p;

	if(!address || !out || capacity < 2)
		return -1;
	for(i=0; i<capacity; ++i)
	{
		p=(char *)A2KRange(address+i,1);
		if(!p)
			return -1;
		out[i]=*p;
		if(out[i]==0)
			return (int)i;
	}
	out[capacity-1]=0;
	return -1;
}

//--------------------------------------------------------------------------
//
static void LogThisSystemCall(SYSCALLPAR)
{
	char str[256];

	//
	if(scall_eax!=SYS_PUTCH && scall_eax!=SYS_IDLE)
	{
		sprintf(str, "SYSCALL%d: ebx=%x, ecx=%x, edx=%x, esi=%x, edi=%x, ebp=%x\n",
			scall_eax,
			scall_ebx, scall_ecx, scall_edx,
			scall_esi, scall_edi, scall_ebp);
		WriteSystemLog(str);
	}
}

// Called by scall_handler before jumping to
// the service function.
void scallActive(SYSCALLPAR)
{
	int pid=GetCurrentThread();

	/* The gate may be installed before init_threads() has created a valid
	 * task slot. Never index per-thread arrays with an unvalidated PID. */
	if(!valid_pid(pid))
		return;

	if(GetThreadType(pid)&THREAD_TYPE_SYSCALL_TRACE)
		LogThisSystemCall(MYSYSCALLPAR);

	if(thread_scall_active[pid] != 0xFF)
		thread_scall_active[pid]++;
}

//--------------------------------------------------------------------------
// This function is called by scall_handler
// after the system call has been served.
void scallDeactive(void)
{
	int pid=GetCurrentThread();

	if(!valid_pid(pid))
		return;
	if(thread_scall_active[pid])
		thread_scall_active[pid]--;
}

//--------------------------------------------------------------------------
//
// Nothing doer.
//
DWORD scall_nothing(SYSCALLPAR)
{
	//
	return 0;
}

//--------------------------------------------------------------------------
//
// scall_puts(scall #6).
//
// Note: base address is needed because
// we need to translate the application's
// own virtual memory address space to
// memory space that is visible to kernel.
// f.e.:
// - Kernel can see everything.
// (supervising)
//
// - Application can see only itself.
// (restricted)
//
//
DWORD scall_puts(SYSCALLPAR)
{
	char text[1024];
	int i,l;

	l=scall_copyin_string(scall_ebx,text,sizeof(text));
	if(l<0)
		return -1;
	for(i=0; i<l; i++)
		putch(text[i]);
	return 0;
}

//--------------------------------------------------------------------------
// Wait until key is hit and return the key code.
int scall_wgetch(SYSCALLPAR)
{
	//
	return getch();
}

//--------------------------------------------------------------------------
// Input key from current terminal's keyboard buffer
DWORD scall_getch(SYSCALLPAR)
{
	//
	return getch1();
}

//--------------------------------------------------------------------------
//
// scall_putchar(scall #7).
// BL = character to print on screen.
//
// New: Modified for visible_terminal.
//
DWORD scall_putchar(SYSCALLPAR)
{
	int i;
	char *scr;
	char str[10];

	// Print char
	sputch(&screens[thread_terminal[GetCurrentThread()]], scall_ebx&255);

	//
	return 0;
}

//--------------------------------------------------------------------------
// This system call is used to exit a thread.
// F.e. an application can be ended with this
// function very well.
//
DWORD scall_exit(SYSCALLPAR)
{
	// Terminate the current thread.
	KillThread( GetCurrentThread() );

	// Wait until being looped out.
	while(1) { SwitchToThread(); }

	//
	return 0;
}

//--------------------------------------------------------------------------
//
// Clears screen.
//
DWORD scall_clrscr(SYSCALLPAR)
{
	//
	_clrscr();
	return 0;
}

//--------------------------------------------------------------------------
// scall_getcurdev - get current device
//
// Returns the caller process current device number (DNR).
//
DWORD scall_getcurdev(SYSCALLPAR)
{
	int devnr;

	//
	devnr = GetCurrentDNR();
	return devnr;
}

//--------------------------------------------------------------------------
DWORD scall_getcurdb(SYSCALLPAR)
{
	int db;

	//
	db = GetCurrentDB();
	return db;
}

//--------------------------------------------------------------------------
//
void scall_relaxthread(SYSCALLPAR)
{
	//
	SwitchToThread();
}

//--------------------------------------------------------------------------
//
int scall_gotoxy(SYSCALLPAR)
{
	gotoxy(scall_ebx,scall_ecx);
	return 0;
}

//--------------------------------------------------------------------------
//
DWORD scall_gettickcount(SYSCALLPAR)
{
	return GetTickCount();
}

//--------------------------------------------------------------------------
// scall_getamemsize
//
// This function returns the size of the memory
// allocated for the process use.
// This is only for application processes,
// does not apply to kernel processes.
DWORD scall_getamemsize(SYSCALLPAR)
{
	return thread_memkb[GetCurrentThread()]*1024;
}

//--------------------------------------------------------------------------
//
DWORD scall_getcurrentthread(SYSCALLPAR)
{
	return GetCurrentThread();
}

//--------------------------------------------------------------------------
//
DWORD scall_getargc(SYSCALLPAR)
{
	int i;
	char *s;

	s=thread_cmdline[GetCurrentThread()];
	if( !s )return 0;
	if( !isValidString(s) )return 0;

	//
	return CountWords(s);
}

//--------------------------------------------------------------------------
// scall_ebx = which argument
// scall_ecx = pointer to string where to store the answer
int scall_getargv(SYSCALLPAR)
{
    char *s;
    int which;
    DWORD argc;

    which = (int)scall_ebx;
    s = (char *)A2KRange(scall_ecx,256);
    if(s == NULL)
        return -1;

    argc = scall_getargc(MYSYSCALLPAR);
    if(which < 0 || (DWORD)which >= argc)
    {
        strcpy(s, "");
        return -1;
    }

    strcpy(s, "");
    strcpyarg(s, thread_cmdline[GetCurrentThread()], which);
    return 0;
}

//--------------------------------------------------------------------------
// Order init -process to create new task.
DWORD scall_cexec(SYSCALLPAR)
{
	char *s,*s2;
	DWORD pid;
	char fname[256],cmdline[256],workdir[256];
	int i,*spid;

	//	scall_ebx	(char *)	file name + arguments 
	//	scall_ecx	int		wait until process exits [TRUE/FALSE]
	//	scall_edx	(char *)	work directory
	//	scall_esi	(int *)		pointer to address where to store PID
	//		(if equals to NULL, then ignored)
	//	scall_edi	(int)		terminal ID

	//
	pid = 0;
	if(scall_copyin_string(scall_ebx,cmdline,sizeof(cmdline))<0)
		return -2;
	if(scall_copyin_string(scall_edx,workdir,sizeof(workdir))<0)
		return -2;
	s = cmdline; // string: exe fname&args
	//	scall_ecx = 0 background (return after creation), 1 foreground (wait for exit)
	s2 = workdir; // work dir
	spid =	scall_esi ? (int *)A2KRange(scall_esi,sizeof(int)) : NULL;
	if(scall_esi && !spid)
		return -2;
	if(spid)
		*spid = 0;

	//
	if(isValidString(s) && strlen(s))
	{
		// Cut file name.
		strcpy(fname, s);
		for(i=0; i<strlen(fname); i++)
			if(fname[i]==' ')fname[i]=0;

		// #1 argument =	file name(ends at the first space)
		// #2 argument = 	whole command line
		// s2 =			running path(where the program will run at)
#if JTMOS_MOD_APP_LOADER
		pid = centralprocess_exec(fname, s,  GetCurrentDNR(), GetCurrentDB(),
					s2,
					scall_edi); // terID

		// Store PID
		if(spid)
			*spid = pid;
#else
		printk("cexec: application loader module is disabled.\n");
		if(spid)
			*spid = 0;
		return -1;
#endif
	}
	else
		// Invalid parameter string(s) detected
		return -2;

	// Creation/load(not found) failed if pid equals zero
	// Return value -1 means error
	if(!pid)
		// No process created
		return -1;

	/* Historical ABI: ECX=0 means background; ECX=1 means foreground.
	 * Do not invert this in libc -- GraOS depends on bgexec() returning as
	 * soon as the child has been created. */
	if(!scall_ecx)
		return 0;

	WaitProcessTerminationInterruptible(pid);
	// Return value 0 means that
	// program terminated like it used to
	return 0;
}

//--------------------------------------------------------------------------
// scall_ebx = PID
DWORD scall_waitprocterm(SYSCALLPAR)
{
	enable();
	WaitProcessTerminationInterruptible(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
// scall_ebx = fname.
// scall_ecx = FFBLK typedef structure.
DWORD scall_findfirst(SYSCALLPAR)
{
    const char *path;
    void *ffblk;

    /* SYS_findfirst is an application-facing syscall.  Both arguments are
     * userspace pointers and must be translated before calling the kernel
     * JTMFS directory-search API.  The historical stub returned 0 for every
     * call, which made userspace shells (SQSH/GraOS) report that every
     * directory was unreadable. */
    path = (const char *)A2K(scall_ebx);
    ffblk = (void *)A2K(scall_ecx);
    if(path == NULL || ffblk == NULL)
        return (DWORD)-1;

    return (DWORD)findfirst(path, ffblk);
}

//--------------------------------------------------------------------------
// scall_ebx = fd.
// scall_ecx = FFBLK typedef structure.
DWORD scall_findnext(SYSCALLPAR)
{
    void *ffblk;

    ffblk = (void *)A2K(scall_ecx);
    if(ffblk == NULL)
        return (DWORD)-1;

    return (DWORD)findnext((int)scall_ebx, ffblk);
}

//--------------------------------------------------------------------------
int scall_textcolor(SYSCALLPAR)
{
	textcolor(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
int scall_textbackground(SYSCALLPAR)
{
	textbackground(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
DWORD scall_inputmouse(SYSCALLPAR)
{
	/* Keep the IRQ-driven path, but opportunistically drain queued PS/2 AUX
	 * bytes as a non-blocking fallback.  This is especially useful under
	 * QEMU/VirtualBox while the slave PIC is transitioning between masks. */
	mouse_poll();

	switch(scall_ebx)
	{
		//
		case 0:
		return mouse.x;
		case 1:
		return mouse.y;
		case 2:
		return mouse.buttons;
		case 3:
		return ps2mouse_irq_count;
		case 4:
		return ps2mouse_byte_count;
		case 5:
		return ps2mouse_packet_count;
		case 6:
		return (DWORD)ps2mouse_stream_status;

		//
		default:
		return 0;
	}
}

//--------------------------------------------------------------------------
int scall_setmouserect(SYSCALLPAR)
{
	long x1=scall_ebx,y1=scall_ecx,x2=scall_edx,y2=scall_esi;

	/* SetMouseRect() describes the coordinate range; it must not leave a
	 * newly-started GUI cursor clipped into the top-left corner.  The old
	 * syscall always teleported the pointer to (x1,y1).  Start at the centre
	 * of the requested rectangle instead; subsequent PS/2 packets update it. */
	mouse_setframe(x1,y1,x2,y2);
	mouse_setposition(x1+(x2-x1)/2,y1+(y2-y1)/2);
	return 0;
}

//--------------------------------------------------------------------------
DWORD scall_vgadrawframe(SYSCALLPAR)
{
    const void *src;

    /* Present one complete packed 1024x768x32 RGBA frame.  V67.8.13 normally
     * activates graphics explicitly from graos.bin, but keep lazy activation
     * here as compatibility for an older GraOS binary on a newer kernel. */
    if(scall_ecx != 0 || scall_edx != GRAOS_VESA_FRAME_BYTES)
        return 0;
    if(!VesaGraOSReady() && !VesaStartGraOSGraphics())
        return 0;

    src = (const void *)A2K(scall_ebx);
    if(src == NULL)
        return 0;

    /* Keep hardware IRQ latency reasonable during the ~3 MiB copy.  A2K()
     * returns the application's kernel-visible backing address, so the source
     * remains valid while interrupts are enabled. */
    enable();
    return VesaDrawFrame(src, GRAOS_VESA_FRAME_BYTES) ? 1 : 0;
}

//--------------------------------------------------------------------------
DWORD scall_vgawaitretrace(SYSCALLPAR)
{
	//
	vga_waitretrace();
	return 0;
}

//--------------------------------------------------------------------------
// chdir [path]
// EAX   EBX
DWORD scall_chdir(SYSCALLPAR)
{
    char *path;
    int rv;

    path = (char *)A2K(scall_ebx);
    if(path == NULL)
        return (DWORD)-1;

    rv = _chdir(path);
    return rv == 0 ? 0 : (DWORD)-rv;
}

//--------------------------------------------------------------------------
// SYS_mkfs [path]
DWORD scall_mkfs(SYSCALLPAR)
{
    /* libc historically passed either a device number or a device/path string. */
    if((int)scall_ebx >= 0 && (int)scall_ebx < 256 && isValidDevice((int)scall_ebx))
        return (DWORD)formatdrive((int)scall_ebx);
    {
        const char *path = (const char *)A2K(scall_ebx);
        if(path == NULL || !isValidString(path) || !strlen(path))
            return (DWORD)-1;
        return (DWORD)mkfs(path);
    }
}

//--------------------------------------------------------------------------
// Rename a file in the caller's current JTMFS device/database context.
// scall_rename: old file name, new file name
DWORD scall_rename(SYSCALLPAR)
{
    const char *oldname = (const char *)A2K(scall_ebx);
    const char *newname = (const char *)A2K(scall_ecx);
    if(oldname == NULL || newname == NULL ||
       !isValidString(oldname) || !isValidString(newname) ||
       !strlen(oldname) || !strlen(newname))
        return (DWORD)-1;
    return (DWORD)jtmfs_RenameFile(GetCurrentDNR(), oldname, newname, GetCurrentDB());
}



//--------------------------------------------------------------------------
// scall_mkdir: directory name, type
DWORD scall_mkdir(SYSCALLPAR)
{
    char *path = (char *)A2K(scall_ebx);
    if(path == NULL || !isValidString(path) || !strlen(path))
        return (DWORD)-1;
    return mkdir(path, scall_ecx);
}

//--------------------------------------------------------------------------
// SYS_remove
// remove [path]
// EAX    EBX
DWORD scall_remove(SYSCALLPAR)
{
    const char *path = (const char *)A2K(scall_ebx);
    if(path == NULL || !isValidString(path) || !strlen(path))
        return (DWORD)-1;
    return (DWORD)unlink(path);
}


//--------------------------------------------------------------------------
// dnr, strbuf*
int scall_getdevicenrbyname(SYSCALLPAR)
{
	char *p;
	p=A2K(scall_ebx);

	//
	if(p && isValidString(p))
	{
		return driver_getdevicenrbyname(p);
	}
	else
	{
		printk("%s: Malformed request to system call\n", __FUNCTION__);
		return 0;
	}
}

//--------------------------------------------------------------------------
// dnr, strbuf*
DWORD scall_getdevicename(SYSCALLPAR)
{
	char *p;

	//
	p=A2K(scall_ecx);

	//
	if(p && isValidString(p))
	{
		driver_getdevicename(scall_ebx, p);
	}
	else
	{
		printk("%s: Malformed request to system call\n", __FUNCTION__);
		return 1;
	}

	//
	return 0;
}

//--------------------------------------------------------------------------
//
DWORD scall_getdate(SYSCALLPAR)
{
	char *p;

	//
	p=A2K(scall_ebx);
	if(p == NULL) return -1;
	rtc_getdate(p);
	return 0;
}

//--------------------------------------------------------------------------
DWORD scall_wherex(SYSCALLPAR)
{
	//
	return wherex();
}

//--------------------------------------------------------------------------
DWORD scall_wherey(SYSCALLPAR)
{
	//
	return wherey();
}

//--------------------------------------------------------------------------
// VGA select plane where to draw and write.
DWORD scall_vgaselectplane(SYSCALLPAR)
{
	// Select VGA plane.
	setwplane(scall_ebx & 3);
	setrplane(scall_ebx & 3);
	return 0;
}

//--------------------------------------------------------------------------
// Get thread priority: pid.
int scall_getthreadpriority(SYSCALLPAR)
{
	//
	return GetThreadPriority(scall_ebx);
}

//--------------------------------------------------------------------------
// Get thread spending: pid.
int scall_getthreadspending(SYSCALLPAR)
{
	//
	return GetThreadSpending(scall_ebx);
}

//--------------------------------------------------------------------------
// Get thread name: pid, name.
int scall_getthreadname(SYSCALLPAR)
{
	char *p;

	//
	p = A2KRange(scall_ecx,39);
	if(!p) return -1;
	return GetThreadName(scall_ebx, p);
}

//--------------------------------------------------------------------------
// Get thread memory usage: pid
int scall_getthreadmemoryusage(SYSCALLPAR)
{
	//
	return GetThreadMemoryUsage(scall_ebx);
}

//--------------------------------------------------------------------------
// Get number of threads
int scall_getthreadcount(SYSCALLPAR)
{
	//
	return GetThreadCount();
}

//--------------------------------------------------------------------------
// Get scheduler CPU/load statistics. EBX=user struct pointer, ECX=struct size.
int scall_getcpustats(SYSCALLPAR)
{
	JTMOS_CPU_STATS *p;

	if(scall_ecx < sizeof(JTMOS_CPU_STATS)) return -1;
	p = (JTMOS_CPU_STATS *)A2KRange(scall_ebx,sizeof(JTMOS_CPU_STATS));
	if(!p) return -1;
	return SchedulerGetCpuStats(p, scall_ecx);
}

//--------------------------------------------------------------------------
int scall_getctrl(SYSCALLPAR)
{
	// Only when available to us
	if( thread_terminal[GetCurrentThread()]==GetInputTerminal() )
		return GetCTRL();
	else
		return 0;
}

//--------------------------------------------------------------------------
int scall_getalt(SYSCALLPAR)
{
	// Only when available to us
	if( thread_terminal[GetCurrentThread()]==GetInputTerminal() )
		return GetALT();
	else
		return 0;
}

//--------------------------------------------------------------------------
// Enables the caller thread to
// receive messages from other processes.
// (automatically activated nowadays, but still can be manually used...)
int scall_activatemsgbox(SYSCALLPAR)
{
	//
	return ActivateThreadMessageBox(GetCurrentThread());
}

//--------------------------------------------------------------------------
// Send message to a process.
int scall_sendmessage(SYSCALLPAR)
{
	void *p;

	// Get PTR
	p=A2KRange(scall_ebx,sizeof(MSG));
	if(!p) return 1;

	// Send message
	return sendMessage(p, scall_ecx);
}

//--------------------------------------------------------------------------
// Receive message.
int scall_receivemessage(SYSCALLPAR)
{
	void *p;

	// Get PTR
	p=A2KRange(scall_ebx,sizeof(MSG));
	if(!p) return 0;

	// Receive message
	return receiveMessage(p);
}

//--------------------------------------------------------------------------
// Resolve thread name to a PID.
int scall_getthreadpid(SYSCALLPAR)
{
	char name[39];

	// Get PTR
	if(scall_copyin_string(scall_ebx,name,sizeof(name))<0) return -1;
	return GetThreadPID(name);
}

//--------------------------------------------------------------------------
// Give thread a name
// (ONLY allows to identify itself,
//  future modifications will be made,
//  to allow system processes to do
//  identifying itself.)
int scall_identifythread(SYSCALLPAR)
{
	char name[39];

	// Get PTR
	if(scall_copyin_string(scall_ecx,name,sizeof(name))<0) return 1;

	// Only allow to modify itself
	if(scall_ebx==GetCurrentThread())
	{
		// Identify
		IdentifyThread(scall_ebx, name);
	}
	else
	{
		//
		printk("%s: Sorry PID%d, I cannot allow you to identify PID%d..\n",
			__FUNCTION__, GetCurrentThread(), scall_ebx);
		// Error
		return 1;
	}

	// Return OK
	return 0;
}

//--------------------------------------------------------------------------
// Return second count
int scall_getseconds(SYSCALLPAR)
{
	//
	return GetSeconds();
}

//--------------------------------------------------------------------------
// Copy a global memory region.
//
//	globalcopy(srcPID,srcPTR, dstPID,dstPTR, length);
//
//	scall_ebx	source PID
//	scall_ecx	source offset
//	scall_edx	destination PID
//	scall_esi	destination offset
//	scall_edi	copy length in bytes
//
int scall_globalcopy(SYSCALLPAR)
{
	BYTE *src,*dst;
	int srcPID,dstPID,len,caller,type;

	// Get PIDs
	srcPID = scall_ebx;
	dstPID = scall_edx;

	// Get copy length
	len = scall_edi;
	if(len < 0 || len > (16*1024*1024)) return -1;
	if(len == 0) return 0;
	caller=GetCurrentThread();
	type=GetThreadType(caller);
	if(!(type&THREAD_TYPE_KERNEL) && !(type&THREAD_TYPE_SERVICE) &&
	   (srcPID!=caller || dstPID!=caller))
		return -1;

	// Get PTRs
	src = (BYTE *)_A2KRange(scall_ecx,(DWORD)len,srcPID);
	dst = (BYTE *)_A2KRange(scall_esi,(DWORD)len,dstPID);

	//
	if(dst == NULL || src == NULL || illegal(dst) || illegal(src))
	{
		dprintk("Illegal globalcopy(%x,%x,%d).\n", dst,src,len);
		return -1;
	}

	// Perform copy
	memcpy(dst, src, len);

	//
	return 0;
}

//--------------------------------------------------------------------------
//
int scall_getthreadterminal(SYSCALLPAR)
{
	//
	return GetThreadTerminal(scall_ebx);
}

//--------------------------------------------------------------------------
//
int scall_setthreadterminal(SYSCALLPAR)
{
	//
	SetThreadTerminal(scall_ebx, scall_ecx);
	return 0;
}

//--------------------------------------------------------------------------
// Create a new terminal.
int scall_newterminal(SYSCALLPAR)
{
	// Returns terminal ID
	return NewTerminal();
}

//--------------------------------------------------------------------------
// Send a byte to terminal's keyboard buffer.
int scall_outputterminalkeyboardbuffer(SYSCALLPAR)
{
	if(scall_ebx<0 || scall_ebx>=N_MAX_SCREENS) return -1;
	return OutputTerminalKeyboardBuffer(&screens[scall_ebx], scall_ecx);
}

//--------------------------------------------------------------------------
// Send a byte to terminal's keyboard buffer
int scall_inputterminalkeyboardbuffer(SYSCALLPAR)
{
	if(scall_ebx<0 || scall_ebx>=N_MAX_SCREENS) return -1;
	return InputTerminalKeyboardBuffer(&screens[scall_ebx]);
}

//--------------------------------------------------------------------------
// Copy specified terminal to a buffer.
int scall_copyterminal(SYSCALLPAR)
{
	BYTE *p;
	int ter;

	// Get parameters
	ter = scall_ebx;
	if(ter<0 || ter>=N_MAX_SCREENS || scall_ecx==0) return -1;
	if(screens[ter].isFree || screens[ter].buf==NULL) return -1;
	p = A2K(scall_ecx);
	if(p==NULL) return -1;

	// Copy
	memcpy(p, screens[ter].buf,
		screens[ter].width*screens[ter].height*2);

	//
	return 0;
}

//--------------------------------------------------------------------------
// Terminate a process
int scall_killthread(SYSCALLPAR)
{
	//
	KillThread(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
// Get cursor location in specified terminal.
int scall_getcursorlocation(SYSCALLPAR)
{
	if(scall_ebx<0 || scall_ebx>=N_MAX_SCREENS) return -1;
	return GetCursorLocation(scall_ebx);
}

//--------------------------------------------------------------------------
// Set interrupt handler.
int scall_setint(SYSCALLPAR)
{
	return addInterruptHandler(scall_ebx,
		(void*)scall_ecx, scall_edx, scall_esi);
}

//--------------------------------------------------------------------------
// Enable IRQ #.
int scall_enableirq(SYSCALLPAR)
{
	/* The legacy ABI is retained, but garbage IRQ values must not reach the PIC. */
	if(scall_ebx < 0 || scall_ebx > 15) return -1;
	enable_irq((unsigned short)scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
//
int scall_diskchange(SYSCALLPAR)
{
	//
	diskchangednr(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
// Legacy syscall number 70. UNIPID is retired; return the PID unchanged so
// older applications remain ABI-compatible without generation-bit semantics.
int scall_getthreaduniquepid(SYSCALLPAR)
{
    return scall_ebx;
}

//--------------------------------------------------------------------------
// Register a new device.
int scall_registernewdevice(SYSCALLPAR)
{
	//
	return driver_register_new_deviceEx(A2K(scall_ebx),
			scall_ecx, scall_edx,
			scall_esi,
			scall_edi,
			scall_ebp);
	// int driver_register_new_deviceEx(const char *device_name,
	//                                void *device_call, int CS,
	//                                int pid,
	//                                WORD type,
	//                                int Alias)
}

//--------------------------------------------------------------------------
// Switch to specified thread.
int scall_switchtothreadex(SYSCALLPAR)
{
	//
	SwitchToThreadEx(scall_ebx);

	//
	return 0;
}

//--------------------------------------------------------------------------
// Create a new terminal.
int scall_createterminal(SYSCALLPAR)
{
	int terID;

	terID = NewTerminal();
	if(terID < 0)
		return -1;
	if(SetTerminalOwner(terID, GetCurrentThread()) < 0)
	{
		FreeTerminal(terID);
		return -1;
	}
	return terID;
}

//--------------------------------------------------------------------------
// Set terminal owner.
int scall_setterminalowner(SYSCALLPAR)
{
	//
	return SetTerminalOwner(scall_ebx, scall_ecx);
}

//--------------------------------------------------------------------------
// Createa a new terminal.
int scall_getterminalowner(SYSCALLPAR)
{
	//
	return GetTerminalOwner(scall_ebx);
}

//--------------------------------------------------------------------------
//
int scall_serialget(SYSCALLPAR)
{
	//
	return serial_get(scall_ebx);
}

//--------------------------------------------------------------------------
//
int scall_serialput(SYSCALLPAR)
{
	//
	return serial_put(scall_ebx, scall_ecx);
}

//--------------------------------------------------------------------------
//
int scall_setserialportspeed(SYSCALLPAR)
{
	//
	return SetSerialPortSpeedOwned(scall_ebx, scall_ecx, SERIAL_OWNER_NONE);
}

//
/*int device_call(long device_nr,
                long n_function,
                long v1,long v2,long v3,long v4,
                void *p1,void *p2)
*/

//--------------------------------------------------------------------------
// Receive raw packet.
int scall_receiverawpacket(SYSCALLPAR)
{
	// scall_ebx	device number
	// scall_ecx	PTR to packet buffer

	//
	return device_call(scall_ebx, // device number
		DEVICE_CMD_RECEIVERAWPACKET, // receive raw packet
		0,0,0,0,
		A2K(scall_ecx),NULL); // PTR to packet buffer.
}

//--------------------------------------------------------------------------
// Transmit raw packet
int scall_transmitrawpacket(SYSCALLPAR)
{
	// scall_ebx	device number
	// scall_ecx	PTR to packet buffer
	// scall_edx	packet length in bytes

	//
	return device_call(scall_ebx, // device number
		DEVICE_CMD_TRANSMITRAWPACKET, // receive raw packet
		scall_edx,0,0,0, // packet length
		A2K(scall_ecx),NULL); // PTR to packet buffer
		
		
}

//--------------------------------------------------------------------------
// Generic device call compatibility syscall.
int scall_devicecall(SYSCALLPAR)
{
    DCPACKET *userp;
    DCPACKET p;
    int dnr;

    dnr = (int)scall_ebx;
    userp = (DCPACKET *)A2K(scall_ecx);
    if(userp == NULL || illegal(userp))
        return -1;
    if(!isValidDevice(dnr))
        return -1;

    /* Copy the packet first, then translate its nested application pointers.
     * Passing raw p1/p2 values to a kernel driver was unsafe for ring-3 apps. */
    memcpy(&p, userp, sizeof(p));
    if(p.n_function <= 0)
        return -1;
    if(p.p1) p.p1 = (void *)A2K((DWORD)p.p1);
    if(p.p2) p.p2 = (void *)A2K((DWORD)p.p2);
    if(p.done) p.done = (int *)A2K((DWORD)p.done);
    if(p.rval) p.rval = (int *)A2K((DWORD)p.rval);

    return device_call(dnr, p.n_function,
                       p.par1,p.par2,p.par3,p.par4,
                       p.p1,p.p2);
}

//--------------------------------------------------------------------------
// Sleep specified amount of 1/100 seconds
int scall_milsleep(SYSCALLPAR)
{
	//
	MilSleep(scall_ebx);

	//
	return 0;
}

//--------------------------------------------------------------------------
// POSIX-style microsecond sleep.  EBX = useconds_t duration.
int scall_usleep(SYSCALLPAR)
{
	return UsecSleep(scall_ebx);
}

//--------------------------------------------------------------------------
// Generic audio syscall API.  User buffers are translated to kernel space;
// hardware I/O and DMA addresses never leave the kernel.
#if JTMOS_MOD_AUDIO_DRIVERS
int scall_audioinit(SYSCALLPAR)
{
    audio_init();
    return audio_ensure_backend((int)scall_ebx);
}

int scall_audiowrite(SYSCALLPAR)
{
    BYTE *buf;
    if(scall_ebx == 0 || scall_ecx == 0) return 0;
    if(scall_ecx > (1024UL * 1024UL)) return -1;
    buf = (BYTE *)A2KRange(scall_ebx,scall_ecx);
    if(!buf) return -1;
    return audio_write(buf, (int)scall_ecx, (int)scall_edx, (int)scall_esi);
}

int scall_audioposition(SYSCALLPAR)
{
    return (int)audio_pending_bytes();
}

int scall_audiostop(SYSCALLPAR)
{
    return audio_stop();
}

int scall_audioinfo(SYSCALLPAR)
{
    JTMOS_AUDIO_INFO *info;
    if(scall_ebx == 0 || scall_ecx < sizeof(JTMOS_AUDIO_INFO)) return -1;
    info = (JTMOS_AUDIO_INFO *)A2KRange(scall_ebx,sizeof(JTMOS_AUDIO_INFO));
    if(!info) return -1;
    return audio_get_info(info);
}

int scall_audioselect(SYSCALLPAR)
{
    return audio_select_backend((int)scall_ebx);
}

#else
int scall_audioinit(SYSCALLPAR) { return -1; }
int scall_audiowrite(SYSCALLPAR) { return -1; }
int scall_audioposition(SYSCALLPAR) { return 0; }
int scall_audiostop(SYSCALLPAR) { return -1; }
int scall_audioinfo(SYSCALLPAR) { return -1; }
int scall_audioselect(SYSCALLPAR) { return -1; }
#endif

//--------------------------------------------------------------------------
//
int GetTCPIPStackDNR(void)
{
	int dnr;

	//
	dnr = driver_getdevicenrbyname("network");
	return dnr;
}

//--------------------------------------------------------------------------
// Open socket.
int scall_opensocket(SYSCALLPAR)
{
	int rv;

	// scall_ebx	32-bit IP address
	// scall_ecx	port address

	//
	rv = device_call(GetTCPIPStackDNR(), // device number
		DEVICE_CMD_OPENSOCKET,
		scall_ebx,scall_ecx,0,0,
		NULL,NULL);

	//
	return rv;
}

//--------------------------------------------------------------------------
// Close socket.
int scall_closesocket(SYSCALLPAR)
{
	int rv;

	// scall_ebx	socket handle (int)

	//
	rv = device_call(GetTCPIPStackDNR(), // device number
		DEVICE_CMD_CLOSESOCKET,
		scall_ebx,0,0,0,
		NULL,NULL);

	//
	return rv;
}

//--------------------------------------------------------------------------
// Read socket.
int scall_readsocket(SYSCALLPAR)
{
	int rv;

	// scall_ebx	socket handle
	// scall_ecx	PTR to buffer

	//
	rv = device_call(GetTCPIPStackDNR(), // device number
		DEVICE_CMD_READSOCKET,
		scall_ebx,A2K(scall_ecx),0,0,
		NULL,NULL);

	//
	return rv;
}

//--------------------------------------------------------------------------
// Write socket.
int scall_writesocket(SYSCALLPAR)
{
	int rv;

	// scall_ebx	socket handle
	// scall_ecx	PTR to buffer
	// scall_edx	number of bytes

	//
	if(scall_edx && !A2KRange(scall_ecx,scall_edx)) return -1;
	rv = device_call(GetTCPIPStackDNR(), // device number
		DEVICE_CMD_WRITESOCKET,
		scall_ebx,scall_edx,0,0,
		A2KRange(scall_ecx,scall_edx),NULL);

	//
	return rv;
}

//--------------------------------------------------------------------------
// Schedule.
int scall_switchtothread(SYSCALLPAR)
{
	SwitchToThread();
	return 0;
}

//--------------------------------------------------------------------------
// Get current work directory path.
// Arguments: [getcwd] [string]
int scall_getcwd(SYSCALLPAR)
{
    char *buf;
    int max_len;
    int rv;

    max_len = (int)scall_ecx;
    if(max_len <= 0 || max_len > 4096)
        return -1;
    buf = (char *)A2KRange(scall_ebx,(DWORD)max_len);
    if(buf == NULL)
        return -1;

    rv = getcwd(buf, max_len);
    return rv == 0 ? 0 : -rv;
}

//--------------------------------------------------------------------------
void *scall_kmalloc(SYSCALLPAR)
{
	if(scall_ebx==0 || scall_ebx>(16UL*1024UL*1024UL))
		return NULL;
	return malloc(scall_ebx);
}

//--------------------------------------------------------------------------
int scall_kfree(SYSCALLPAR)
{
	if(scall_ebx) {
		if(GetChunkOwner((void *)scall_ebx)!=GetCurrentThread())
			return -1;
		free((void *)scall_ebx);
	}
	return 0;
}


//--------------------------------------------------------------------------
// scall_postcmd
//
// New: Modified to transfer execution immediatly
// to postman process so no CPU time is spent
// elsewhere, which might lead into a markable
// inefficiency.
//
int scall_postcmd(SYSCALLPAR)
{
    POSTMANCMD *userp;
    POSTMANCMD p;
    int *ackp = NULL;
    int *rvp = NULL;
    int rv = -1;

    userp = (POSTMANCMD *)A2K(scall_ebx);
    if(userp == NULL || illegal(userp))
        return -1;

    /* Work on a kernel copy: never dereference nested application pointers
     * before translating them from the caller's virtual address space. */
    memcpy(&p, userp, sizeof(p));
    if(p.par1) p.par1 = (char *)A2K((DWORD)p.par1);
    if(p.par2) p.par2 = (char *)A2K((DWORD)p.par2);
    if(p.par3) p.par3 = (char *)A2K((DWORD)p.par3);
    if(p.par4) p.par4 = (char *)A2K((DWORD)p.par4);
    if(p.par5) p.par5 = (char *)A2K((DWORD)p.par5);
    if(p.par6) p.par6 = (char *)A2K((DWORD)p.par6);
    if(p.par7) p.par7 = (char *)A2K((DWORD)p.par7);
    if(p.par8) p.par8 = (char *)A2K((DWORD)p.par8);
    if(p.acknowledged) ackp = (int *)A2K((DWORD)p.acknowledged);
    if(p.rv) rvp = (int *)A2K((DWORD)p.rv);

    /* The old Postman filled these from the sender before dispatching. */
    p.magic = POSTMAN_MAGIC;
    p.pid = GetCurrentThread();
    p.dnr = GetCurrentDNR();
    p.db = GetCurrentDB();

    switch(p.id)
    {
        case PCMD_CREATE_FILE:
            rv = createfile(p.par1);
            break;
        case PCMD_DELETE_FILE:
            rv = unlink(p.par1);
            break;
        case PCMD_WRITE_FILE:
            rv = writefile(p.par1, p.par2, p.v2, p.v1);
            break;
        case PCMD_READ_FILE:
            rv = readfile(p.par1, p.par2, p.v2, p.v1);
            break;
        case PCMD_GET_FILE_SIZE:
            rv = getfilesize(p.par1);
            break;
        case PCMD_ADD_BLOCKS:
            rv = addfileblocks(p.par1, p.v1);
            break;
        case PCMD_EXIST:
            rv = exist(p.par1);
            break;
        case PCMD_READBLOCK:
            rv = readblock(p.v1, p.v2, p.par1);
            break;
        case PCMD_WRITEBLOCK:
            rv = writeblock(p.v1, p.v2, p.par1);
            break;
        case PCMD_FINDFIRST:
            rv = findfirst(p.par1, p.par2);
            break;
        case PCMD_FINDNEXT:
            rv = findnext(p.v1, p.par1);
            break;
        case PCMD_RENAME_FILE:
            if(!p.par1 || !p.par2) rv = -1;
            else rv = jtmfs_RenameFile(GetCurrentDNR(), p.par1, p.par2, GetCurrentDB());
            break;
        case PCMD_SETSIZE:
            rv = setsize(p.par1, p.v1);
            break;
        case PCMD_GETFILEDATABLOCK:
            if(!p.par1) rv = -1;
            else rv = jtmfs_GetFileDataBlock(GetCurrentDNR(), GetCurrentDB(), p.par1);
            break;
        case PCMD_CREATEDIRECTORY:
            rv = mkdir(p.par1, 0);
            break;
        case PCMD_FORMATDRIVE:
            rv = formatdrive(p.v1);
            break;
        case PCMD_CLOSE:
            rv = close(p.v1);
            break;
        case PCMD_CHDIR:
            rv = chdir(p.par1);
            break;
        case PCMD_IS_DRIVE_READY:
            rv = isValidDevice(p.v1) && jtmfs_isDriveReady(p.v1) ? 1 : 0;
            break;
        case PCMD_GETCWD:
            rv = getcwd(p.par1, p.v1);
            break;

        /* Legacy multimedia Postman ABI now forwards to the same kernel
         * backends as the modern dedicated syscalls. */
        case PCMD_SETMODE:
            setvmode(p.v1);
            rv = 0;
            break;
        case PCMD_DRAWFRAME:
            if(!p.par1 || p.v2 <= 0) {
                rv = -1;
            } else if(p.v1 == 0 && p.v2 == GRAOS_VESA_FRAME_BYTES) {
                rv = VesaDrawFrame(p.par1, GRAOS_VESA_FRAME_BYTES) ? 0 : -1;
            } else if(p.v1 >= 0 && p.v2 > 0 && p.v1 + p.v2 <= 0x10000) {
                memcpy((BYTE *)0xA0000 + p.v1, p.par1, p.v2);
                rv = 0;
            } else {
                rv = -1;
            }
            break;
        case PCMD_SETPALETTE:
            if(p.v1 < 0 || p.v1 > 255 || p.v2 < 0 || p.v2 > 63 ||
               p.v3 < 0 || p.v3 > 63 || p.v4 < 0 || p.v4 > 63) {
                rv = -1;
            } else {
                setpaletteEx(p.v1, p.v2, p.v3, p.v4);
                rv = 0;
            }
            break;
        case PCMD_SETPALETTEMAP:
            if(!p.par1 || p.v1 < 0 || p.v1 > 255 || p.v2 <= 0 ||
               p.v2 > 256 || p.v1 + p.v2 > 256) {
                rv = -1;
            } else {
                setpalettemap(p.v1, p.v2, (BYTE *)p.par1);
                rv = 0;
            }
            break;
#if JTMOS_MOD_AUDIO_DRIVERS
        case PCMD_INITAUDIO:
            audio_init();
            rv = audio_ensure_backend(0);
            break;
        case PCMD_SENDAUDIO:
            if(!p.par1 || p.v1 <= 0 || p.v3 <= 0) rv = -1;
            else rv = audio_write((BYTE *)p.par1, p.v1, p.v3, p.v2);
            break;
        case PCMD_GETAUDIOPOSITION:
            rv = (int)audio_pending_bytes();
            break;
#endif
        default:
            rv = -1;
            break;
    }

    /* Preserve the synchronous Postman ABI for old callers that supplied
     * acknowledgement / return-value cells, while also returning rv in EAX. */
    if(rvp && !illegal(rvp)) *rvp = rv;
    if(ackp && !illegal(ackp)) *ackp = (rv < 0) ? 2 : 1;
    userp->magic = POSTMAN_MAGIC;
    userp->pid = p.pid;
    userp->dnr = p.dnr;
    userp->db = p.db;
    userp->id = 0;
    return rv;
}

//--------------------------------------------------------------------------
// scall_open
//
int scall_open(SYSCALLPAR)
{
    char *pathname;

    /* Userspace passes a virtual pointer in EBX.  Never let the filesystem
     * retain/use the raw application address: translate it to the stable
     * kernel-visible backing address first. */
    pathname = (char *)A2K(scall_ebx);
    if(pathname == NULL)
        return -1;
    return open(pathname, scall_ecx);
}

//--------------------------------------------------------------------------
// Turbo C compatible text window: all public coordinates are 1-based.
int scall_window(SYSCALLPAR)
{
    return window((long)scall_ebx, (long)scall_ecx,
                  (long)scall_edx, (long)scall_esi);
}

//--------------------------------------------------------------------------
// Copy bytes from another thread's user virtual address into the caller.
// Used by the GraOS server to make a private copy of client framebuffers.
int scall_copyfromthread(SYSCALLPAR)
{
    BYTE *src;
    BYTE *dst;
    DWORD len = scall_edx;
    int srcpid = (int)scall_ebx;
    int caller = GetCurrentThread();
    int type = GetThreadType(caller);

    if(srcpid <= 0 || scall_ecx == 0 || scall_esi == 0 || len == 0)
        return -1;
    if(len > (4UL * 1024UL * 1024UL))
        return -1;
	if(srcpid!=caller && !(type&THREAD_TYPE_KERNEL) &&
	   !(type&THREAD_TYPE_SERVICE))
		return -1;

    src = (BYTE *)_A2KRange(scall_ecx,len,srcpid);
    dst = (BYTE *)A2KRange(scall_esi,len);
    if(!src || !dst)
        return -1;
    memcpy(dst, src, len);
    return (int)len;
}

//--------------------------------------------------------------------------
// scall_close
//
int scall_close(SYSCALLPAR)
{
    /* Standard descriptors are permanent ABI objects. */
    if((int)scall_ebx >= 0 && (int)scall_ebx <= 2)
        return 0;
    return close(scall_ebx);
}

//
int scall_read(SYSCALLPAR)
{
    BYTE *buf;
    int i, count, c;

    count = (int)scall_edx;
    if(count < 0) return -1;
    if(count == 0) return 0;
    buf = (BYTE *)A2KRange(scall_ecx,(DWORD)count);
    if(buf == NULL) return -1;

    /* fd 0 is the current process terminal.  Read at least one character
     * and stop on newline so stdio/getchar works without a fake JTMFS file. */
    if((int)scall_ebx == 0)
    {
        for(i=0; i<count; ++i)
        {
            c = getch();
            if(c < 0) break;
            buf[i] = (BYTE)c;
            if(c == '\r' || c == '\n') { ++i; break; }
        }
        return i;
    }

    if((int)scall_ebx == 1 || (int)scall_ebx == 2)
        return -1;

    return read(scall_ebx, buf, count);
}

//--------------------------------------------------------------------------
// scall_write
//
int scall_write(SYSCALLPAR)
{
    BYTE *buf;
    int i, count;

    count = (int)scall_edx;
    if(count < 0) return -1;
    if(count == 0) return 0;
    buf = (BYTE *)A2KRange(scall_ecx,(DWORD)count);
    if(buf == NULL) return -1;

    /* fd 1/2 are the terminal console, not entries in the JTMFS file table. */
    if((int)scall_ebx == 1 || (int)scall_ebx == 2)
    {
        for(i=0; i<count; ++i)
            putch(buf[i]);
        return count;
    }
    if((int)scall_ebx == 0)
        return -1;

    return write(scall_ebx, buf, count);
}

//--------------------------------------------------------------------------
// scall_fnctl
//
int scall_fnctl(SYSCALLPAR)
{
	// file descriptor
	//return fnctl(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
// scall_fnctl
//
int scall_lseek(SYSCALLPAR)
{
	// fd, offset, whence
	return lseek(scall_ebx,scall_ecx,scall_edx);
}

//--------------------------------------------------------------------------
// scall_stat
//       int stat(const char *pathname, struct stat *buf);
//       int fstat(int fd, struct stat *buf);
//       int lstat(const char *pathname, struct stat *buf);
//
int scall_stat(SYSCALLPAR)
{
    char *pathname = (char *)A2K(scall_ebx);
    void *buf = (void *)A2K(scall_ecx);
    if(pathname == NULL || buf == NULL) return -1;
    return stat(pathname, buf);
}

//--------------------------------------------------------------------------
// scall_fstat
//       int stat(const char *pathname, struct stat *buf);
//       int fstat(int fd, struct stat *buf);
//       int lstat(const char *pathname, struct stat *buf);
//
int scall_fstat(SYSCALLPAR)
{
    void *buf = (void *)A2K(scall_ecx);
    if(buf == NULL) return -1;
    return fstat(scall_ebx, buf);
}

//--------------------------------------------------------------------------
// scall_lstat
//       int stat(const char *pathname, struct stat *buf);
//       int fstat(int fd, struct stat *buf);
//       int lstat(const char *pathname, struct stat *buf);
//
int scall_lstat(SYSCALLPAR)
{
    char *pathname = (char *)A2K(scall_ebx);
    void *buf = (void *)A2K(scall_ecx);
    if(pathname == NULL || buf == NULL) return -1;
    return lstat(pathname, buf);
}


//--------------------------------------------------------------------------
// V65 safe userspace IRQ / ISA DMA mediation.
int scall_irqsubscribe(SYSCALLPAR)
{
    return userhw_irq_subscribe(GetCurrentThread(), (int)scall_ebx, scall_ecx);
}

int scall_irqunsubscribe(SYSCALLPAR)
{
    return userhw_irq_unsubscribe(GetCurrentThread(), scall_ebx);
}

int scall_irqwait(SYSCALLPAR)
{
    return userhw_irq_wait(GetCurrentThread(), scall_ebx, scall_ecx);
}

int scall_dmaalloc(SYSCALLPAR)
{
    JTMOS_DMA_BUFFER_K *out;
    out = (JTMOS_DMA_BUFFER_K *)A2KRange(scall_edx,sizeof(*out));
    if(out == NULL)
        return -14;
    return userhw_dma_alloc(GetCurrentThread(), scall_ebx, scall_ecx, out);
}

int scall_dmafree(SYSCALLPAR)
{
    return userhw_dma_free(GetCurrentThread(), scall_ebx);
}

int scall_dmaprogram(SYSCALLPAR)
{
    return userhw_dma_program(GetCurrentThread(), scall_ebx,
        (int)scall_ecx, scall_edx, (int)scall_esi);
}

int scall_dmastop(SYSCALLPAR)
{
    return userhw_dma_stop(GetCurrentThread(), scall_ebx, (int)scall_ecx);
}


// V67.6: controlled VGA/VESA 8-bit DAC palette update for Ring3 GraOS clients.
int scall_vgasetpalette(SYSCALLPAR)
{
    int index=(int)scall_ebx;
    int r=(int)scall_ecx,g=(int)scall_edx,b=(int)scall_esi;

    /* index -1 is a backwards-compatible control operation: restore the
     * complete system MCGA/VGA palette without consuming another syscall
     * number.  Normal 0..255 entry updates retain the V67.6 ABI. */
    if(index==-1)
    {
        setpalette256();
        return 0;
    }
    if(index<0 || index>255 || r<0 || r>63 || g<0 || g>63 || b<0 || b>63)
        return -1;
    setpaletteEx(index,r,g,b);
    return 0;
}


// V67.8.12: return kernel-validated CPU/OS feature mask.
int scall_getcpufeatures(SYSCALLPAR)
{
    return (int)cpuFeatureMask();
}


// V67.8.13: GraOS owns the transition from VGA text mode to 1024x768x32 RGBA.
int scall_graosgraphics(SYSCALLPAR)
{
    (void)scall_ebx; (void)scall_ecx; (void)scall_edx;
    (void)scall_esi; (void)scall_edi; (void)scall_ebp;
    return VesaStartGraOSGraphics() ? 1 : 0;
}
