#ifndef __INCLUDED_LOCK_H__
#define __INCLUDED_LOCK_H__

/*
 * Cooperative kernel lock.
 *
 * Rules:
 *  - never leak a changed EFLAGS.IF state to the caller;
 *  - never call SwitchToThread() while IRQs are forced off;
 *  - never yield while the storage-safe PIT mode has disabled the TSS scheduler;
 *  - keep the ownership test/set atomic.
 */
#define JTMOS_LOCK_SPIN_LIMIT 1000000UL

#define LOCK \
    static volatile int granted_pid = -1; \
    static volatile unsigned long granted_depth = 0; \
    int __jtmos_lock_eflags = 0; \
    unsigned long __jtmos_lock_spins = 0; \
    int __jtmos_lock_pid = 0; \
    if(Multitasking) { \
        __jtmos_lock_pid = GetCurrentThread(); \
        __jtmos_lock_eflags = get_eflags(); \
        disable(); \
        while(granted_pid != -1 && granted_pid != __jtmos_lock_pid) { \
            set_eflags(__jtmos_lock_eflags); \
            if(Multitasking && !PitStorageSafeActive() && (__jtmos_lock_eflags & 0x200)) \
                SwitchToThread(); \
            else { \
                volatile unsigned long __i; \
                for(__i=0; __i<128; __i++) { } \
            } \
            disable(); \
            if(++__jtmos_lock_spins >= JTMOS_LOCK_SPIN_LIMIT) { \
                set_eflags(__jtmos_lock_eflags); \
                printk("LOCK timeout in %s; owner=%d caller=%d depth=%u IF=%d\n", \
                       __FUNCTION__, granted_pid, __jtmos_lock_pid, \
                       (unsigned)granted_depth, \
                       (__jtmos_lock_eflags & 0x200) ? 1 : 0); \
                __jtmos_lock_spins = 0; \
                disable(); \
            } \
        } \
        if(granted_pid == __jtmos_lock_pid) \
            granted_depth++; \
        else { \
            granted_pid = __jtmos_lock_pid; \
            granted_depth = 1; \
        } \
        set_eflags(__jtmos_lock_eflags); \
    }

#define UNLOCK \
    if(Multitasking) { \
        int __jtmos_unlock_flags = get_eflags(); \
        int __jtmos_unlock_pid = GetCurrentThread(); \
        disable(); \
        if(granted_pid == __jtmos_unlock_pid && granted_depth != 0) { \
            granted_depth--; \
            if(granted_depth == 0) \
                granted_pid = -1; \
        } \
        set_eflags(__jtmos_unlock_flags); \
    }

#endif
