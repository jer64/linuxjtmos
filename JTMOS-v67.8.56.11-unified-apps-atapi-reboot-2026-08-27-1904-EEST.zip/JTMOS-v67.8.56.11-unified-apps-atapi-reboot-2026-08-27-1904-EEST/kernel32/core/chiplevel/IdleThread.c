//=====================================================
// JTMOS THREADS - IdleThread.
// (C) 2001-2005 by Jari Tuominen.
//=====================================================
#include "cpu.h"
#include "kernel32.h"
#include "threads.h"
#include "IdleThread.h"

//
DWORD IdleThreadCounter=0;
//
THREAD IdleThread;

// Creates an idle thread
void init_IdleThread(void)
{
	//
	ThreadCreateStack(&IdleThread, JTMOS_MIN_DYNAMIC_STACK);
	IdleThread.pid = 
		create_thread(IdleThread.stack,
			IdleThread.l_stack, IdleThreadProgram);

	// max. 31 characters.
	IdentifyThread(IdleThread.pid, "CPU_IDLE");

	// Idle thread should be immortal.
	Immortal(IdleThread.pid);
}

//
void IdleThreadProgram(void)
{
	/*
	 * True CPU idle loop.  The PIT IRQ wakes HLT, enters TaskPitHandler(),
	 * and the scheduler immediately gives the CPU to a runnable thread.
	 * If nothing else is runnable we return here and halt again.
	 */
	IdleThreadCounter=0;
	for(;;)
	{
		IdleThreadCounter++;
		asm volatile("sti; hlt" ::: "memory");
	}
}

//

