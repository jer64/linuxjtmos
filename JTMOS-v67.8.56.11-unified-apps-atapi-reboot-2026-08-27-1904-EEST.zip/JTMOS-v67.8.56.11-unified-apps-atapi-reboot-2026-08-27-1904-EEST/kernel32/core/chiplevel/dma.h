#ifndef __INCLUDED_DMA_H__
#define __INCLUDED_DMA_H__

//
void dma_xfer(BYTE channel, DWORD address, unsigned int length, BYTE read);
void dma_mask_channel(BYTE channel);

#endif
