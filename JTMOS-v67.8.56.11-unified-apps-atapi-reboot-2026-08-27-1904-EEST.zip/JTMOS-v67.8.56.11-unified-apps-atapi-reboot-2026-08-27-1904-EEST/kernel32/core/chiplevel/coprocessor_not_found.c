/* JTMOS lazy x87/SSE context management. */
#include <stdio.h>
#include "coprocessor_not_found.h"
#include "cpu.h"
#include "threads.h"

static int fpu_last_user_pid=-1;
int mathHandling=0;

static void fpu_state_save(FPUREGS *r)
{
    if(!r)return;
    if(cpuHasFeature(JTMOS_CPUF_FXSR|JTMOS_CPUF_SSE_OS))
        __asm__ __volatile__("fxsave (%0)" : : "r"(r->state) : "memory");
    else
        __asm__ __volatile__("fnsave (%0); fwait" : : "r"(r->state) : "memory");
}

static void fpu_state_restore(FPUREGS *r)
{
    if(!r)return;
    if(cpuHasFeature(JTMOS_CPUF_FXSR|JTMOS_CPUF_SSE_OS))
        __asm__ __volatile__("fxrstor (%0)" : : "r"(r->state) : "memory");
    else
        __asm__ __volatile__("frstor (%0)" : : "r"(r->state) : "memory");
}

void FpuForgetThread(int pid)
{
    if(pid < 0 || pid >= N_MAX_THREADS)
        return;

    /* The process reaper owns/free()s the allocation itself.  This helper is
     * about PID reuse: remove a stale pointer and, crucially, invalidate the
     * cached hardware-owner PID so a recycled numeric PID cannot bypass #NM
     * initialization and accidentally observe the previous task's FPU state. */
    thread_fpuregs[pid] = NULL;
    if(fpu_last_user_pid == pid)
        fpu_last_user_pid = -1;
}

static int fpu_state_new(int pid)
{
    FPUREGS *r;
    unsigned long mxcsr=0x1f80UL;
    int i;

    r=(FPUREGS *)malloc(sizeof(FPUREGS));
    if(!r)return -1;
    /* Do not call optimized memset while constructing an FPU save image. */
    for(i=0;i<(int)sizeof(FPUREGS);i++) ((BYTE *)r)[i]=0;
    thread_fpuregs[pid]=r;

    __asm__ __volatile__("fninit" : : : "memory");
    if(cpuHasFeature(JTMOS_CPUF_FXSR|JTMOS_CPUF_SSE_OS))
    {
        __asm__ __volatile__("ldmxcsr %0" : : "m"(mxcsr) : "memory");
        __asm__ __volatile__("fxsave (%0)" : : "r"(r->state) : "memory");
    }
    else
        __asm__ __volatile__("fnsave (%0); fwait" : : "r"(r->state) : "memory");
    return 0;
}

void coprocessor_not_found(void)
{
    int current=GetCurrentThread();
    mathHandling++;

    if(current<0 || current>=N_MAX_THREADS)
        return;
    if(fpu_last_user_pid==current)
        return;

    /* Hardware task switches set CR0.TS. ASMexception_7 executes CLTS before
     * reaching here, so the previous owner's live x87/XMM state is still in
     * the processor and can now be saved safely. */
    if(fpu_last_user_pid>=0 && fpu_last_user_pid<N_MAX_THREADS &&
       thread_fpuregs[fpu_last_user_pid]!=NULL)
        fpu_state_save(thread_fpuregs[fpu_last_user_pid]);

    if(thread_fpuregs[current]==NULL && fpu_state_new(current)!=0)
    {
        dprintk("FPU: unable to allocate state for PID %d; resetting arithmetic state.\n",current);
        __asm__ __volatile__("fninit" : : : "memory");
        fpu_last_user_pid=-1;
        return;
    }

    fpu_state_restore(thread_fpuregs[current]);
    fpu_last_user_pid=current;
}
