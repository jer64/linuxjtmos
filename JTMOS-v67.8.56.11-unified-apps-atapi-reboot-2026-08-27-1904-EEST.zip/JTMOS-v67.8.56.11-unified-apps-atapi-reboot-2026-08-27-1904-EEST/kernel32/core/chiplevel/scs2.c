// ======================================================================
// scs2.c - legacy JTMOS filesystem syscall compatibility services.
//
// V67.8.2: these ABI slots are no longer stubs.  They are kept because old
// applications still use syscall numbers 95..104.  All userspace pointers
// are translated with A2K() before entering the kernel filesystem API.
// ======================================================================
#include "kernel32.h"
#include "systemcalls.h"
#include "scconf.h"
#include "ega.h"
#include "threads.h"
#include "scs.h"
#include "scs2.h"
#include "scs_devices.h"
#include "mouse.h"
#include "msgbox.h"
#include "driver_diskchange.h"
#include "serial.h"

// SYS_setsize1 (104): EBX=path, ECX=new size in bytes.
int scall_setsize(SYSCALLPAR)
{
    const char *path = (const char *)A2K(scall_ebx);
    if(path == NULL || !isValidString(path) || !strlen(path) || (int)scall_ecx < 0)
        return -1;
    return setsize(path, (int)scall_ecx);
}

// SYS_fexist (95): EBX=path.  Returns 0 not found, 1 file, 2 directory.
int scall_fexist1(SYSCALLPAR)
{
    const char *path = (const char *)A2K(scall_ebx);
    if(path == NULL || !isValidString(path) || !strlen(path))
        return 0;
    return exist(path);
}

// SYS_getfilesize (99): EBX=path, returns byte size or negative on error.
int scall_getfilesize(SYSCALLPAR)
{
    const char *path = (const char *)A2K(scall_ebx);
    if(path == NULL || !isValidString(path) || !strlen(path))
        return -1;
    return getfilesize(path);
}

// SYS_isdriveready (97): EBX=device number.
int scall_isdriveready(SYSCALLPAR)
{
    int dnr = (int)scall_ebx;
    if(!isValidDevice(dnr))
        return 0;
    return jtmfs_isDriveReady(dnr) ? 1 : 0;
}

// SYS_creat1 (102): EBX=path, ECX=flags (0 means O_CREAT compatibility).
int scall_creat1(SYSCALLPAR)
{
    const char *path = (const char *)A2K(scall_ebx);
    int flags = (int)scall_ecx;
    if(path == NULL || !isValidString(path) || !strlen(path))
        return -1;
    if(flags == 0) flags = O_CREAT;
    return creat(path, flags);
}

// SYS_unlink1 (103): EBX=path.
int scall_unlink1(SYSCALLPAR)
{
    const char *path = (const char *)A2K(scall_ebx);
    if(path == NULL || !isValidString(path) || !strlen(path))
        return -1;
    return unlink(path);
}

// SYS_read1 (100): EBX=fd, ECX=buffer, EDX=count.
int scall_read1(SYSCALLPAR)
{
    void *buf;
    if((int)scall_edx < 0) return -1;
    if(scall_edx == 0) return 0;
    buf = (void *)A2K(scall_ecx);
    if(buf == NULL) return -1;
    return read((int)scall_ebx, buf, (int)scall_edx);
}

// SYS_write1 (101): EBX=fd, ECX=buffer, EDX=count.
int scall_write1(SYSCALLPAR)
{
    const void *buf;
    if((int)scall_edx < 0) return -1;
    if(scall_edx == 0) return 0;
    buf = (const void *)A2K(scall_ecx);
    if(buf == NULL) return -1;
    return write((int)scall_ebx, buf, (int)scall_edx);
}

// SYS_getfiledatablock (96): EBX=path.
int scall_getfiledatablock(SYSCALLPAR)
{
    const char *path = (const char *)A2K(scall_ebx);
    if(path == NULL || !isValidString(path) || !strlen(path))
        return -1;
    return jtmfs_GetFileDataBlock(GetCurrentDNR(), GetCurrentDB(), path);
}
