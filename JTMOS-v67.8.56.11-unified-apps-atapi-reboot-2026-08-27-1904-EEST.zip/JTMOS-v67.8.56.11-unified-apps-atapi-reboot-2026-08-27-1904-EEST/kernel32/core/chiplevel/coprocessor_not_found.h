#ifndef JTMOS_COPROCESSOR_NOT_FOUND_H
#define JTMOS_COPROCESSOR_NOT_FOUND_H
void coprocessor_not_found(void);
void FpuForgetThread(int pid);
extern int mathHandling;
/* Legacy assembly entry points remain linked for compatibility. */
extern void fpu_restore(void *ptr);
extern void fpu_save(void *ptr);
#endif
