//------------------------------------------------------
// Interrupt database
//
// This database implementation makes possible for
// interrupts to have multiple handlers.
//------------------------------------------------------
#include "kernel32.h"
#include "int.h"
#include "intdb.h"

// Interrupt database
INTDB intdb;

// Init interrupt database system
int initInterruptDB(void)
{
	memset(&intdb, 0, sizeof(INTDB));
	return 0;
}

// Create new interrupt handler entry
int newHandlerEntryID(INTHAN *e)
{
	int i,found=-1;
	int capacity;
	IHANDLER *ih;

	if(e==NULL) return -1;
	capacity = (int)(sizeof(e->handler)/sizeof(e->handler[0]));
	if(e->nr_handlers < 0 || e->nr_handlers > capacity) return -1;

	for(i=0; i<e->nr_handlers; i++)
	{
		ih = &e->handler[i];
		if(ih->isFree) { found=i; break; }
	}

	if(found==-1)
	{
		if(e->nr_handlers >= capacity) return -1;
		found = e->nr_handlers++;
	}
	return found;
}

// Add a new handler to specified interrupt
int addInterruptHandler(int nr, void *ptr, int selector, int type)
{
	int id;
	IHANDLER *e;

	/* SYS_setint is reachable from Ring3. Never let it index outside intdb or
	 * overflow the fixed ten-handler array. */
	if(nr < 0 || nr >= 256 || ptr==NULL) return -1;

	id = newHandlerEntryID(&intdb.i[nr]);
	if(id < 0) return -1;

	e = &intdb.i[nr].handler[id];
	e->isFree = FALSE;
	e->eip = (int)ptr;
	e->cs = selector;
	e->type = type;
	return 0;
}
