// ============================================================
// dfunc.c
// Debugging Functions Collection
// (C) 2002-2004 by Jari Tuominen.
// ============================================================
// Required includes
#include "kernel32.h" // preferences for kernel32(init)
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
#include "sb.h"
#include "syssh.h"
#include "driver_sys.h"
#include "zero.h"
#include "null.h"
#include "printf.h"
#include "stdarg.h"
#include "dfunc.h"

// Debug sleep
int dsleep(int sec)
{
	//
	dprintk("%s: duration in seconds=%d\n",
		__FUNCTION__,
		sec);
	if(jtmos_debug)sleep(sec);
}

// Debug printk
int dprintk(const char *fmt, ...)
{
    va_list arg;
    char tmp[1024];

    if(!jtmos_debug || !DebugSerialRuntimeEnabled())
        return 0;

    va_start(arg, fmt);
    svprintf(tmp, fmt, arg);
    va_end(arg);

    /* V67.8.41: debug level 1 is a serial-only diagnostic channel.
     * Do not feed dprintk() back through printk()/terminal output and do not
     * copy it into the normal system log.  This keeps verbose filesystem,
     * driver and scheduler diagnostics out of SMSH/GraOS while preserving
     * the complete trace in the QEMU serial log. */
    if(serial_debug_line >= 0)
        DebugSerialWrite(tmp);

    return 0;
}

