/*
 * pit.c - programmable interrupt timer
 *
 * (C) 2001-2005 by Jari Tuominen.
 *
 * Programmable Interrupt Chip handler library.
 * Basically we need a PIC to do anything nice
 * with the OS, so here's one of the most
 * needed part of the entire OS ;-)
 */

//
// Update: finally got rid of the AT&T standard
// assembly code, quickly translated it into NASM,
// now it seems to compile, and it'll be possible
// to start coding task switching code with NASM
// standard ASM by now, great.
//

#include "kernel32.h"
#include "pit.h"
#include "io.h"
#include "sysglvar.h"
#include "basdef.h"
#include "int.h"
#include "delay.h"
#include "floppy.h" // fd_int1c
#include "tss.h"
#include "scheduler.h"

//
PIT *pit;
//
static int lala=0;

/*
 * Boot/storage timing mode.  During early floppy/IDE I/O we need IRQ0 for
 * millisecond counters and driver timeouts, but we do NOT want a hardware
 * TSS task switch on every PIT tick.  The old task-gate scheduler can perform
 * thousands of task switches during a single floppy seek and eventually
 * corrupt the init task context.
 */
static volatile int pit_storage_safe_active=0;
static int pit_storage_saved_multitasking=0;
#define PIT_INPUT_HZ 1193180UL
static DWORD pit_input_ticks_per_second=1;
static DWORD pit_programmed_divisor=1;
static DWORD pit_ms_phase=0;

/* High-resolution monotonic duration clock.  CMOS/RTC is the wall-clock
 * source, but PC/AT CMOS has only one-second calendar resolution.  Sub-second
 * sleeps are therefore derived from the PIT crystal (1,193,180 Hz), which is
 * the correct hardware time base for usleep().  The whole/remainder pair
 * keeps the average exact without floating point or 64-bit division. */
static volatile DWORD pit_monotonic_usec=0;
static DWORD pit_usec_tick_whole=0;
static DWORD pit_usec_tick_remainder=0;
static volatile DWORD pit_usec_phase=0;

static void pit_prepare_usec_increment(DWORD divisor)
{
	DWORD i;
	DWORD whole=0;
	DWORD rem=0;

	/* Compute (divisor * 1,000,000) / PIT_INPUT_HZ without overflowing
	 * 32-bit arithmetic.  Since 1,000,000 < PIT_INPUT_HZ, each iteration
	 * needs at most one carry.  This runs only when the PIT is programmed. */
	for(i=0; i<divisor; i++)
	{
		rem += 1000000UL;
		if(rem >= PIT_INPUT_HZ)
		{
			rem -= PIT_INPUT_HZ;
			whole++;
		}
	}

	pit_usec_tick_whole = whole;
	pit_usec_tick_remainder = rem;
	pit_usec_phase = 0;
	pit_monotonic_usec = 0;
}

void pit_handler(void);

/* Normal interrupt-gate IRQ0 handler used only during boot/storage I/O.
 * It advances JTMOS timers and acknowledges the PIC, but never invokes the
 * TSS scheduler.  IRET restores the interrupted EFLAGS/segments/registers. */
__attribute__((naked)) void pit_tick_only_ISR(void)
{
	__asm__ __volatile__(
		"cld\n\t"
		"pushal\n\t"
		"push %ds\n\t"
		"push %es\n\t"
		"push %fs\n\t"
		"push %gs\n\t"
		"mov $0x10, %ax\n\t"
		"mov %ax, %ds\n\t"
		"mov %ax, %es\n\t"
		"mov %ax, %fs\n\t"
		"mov %ax, %gs\n\t"
		"call pit_handler\n\t"
		"mov $0x20, %dx\n\t"
		"mov $0x20, %al\n\t"
		"out %al, %dx\n\t"
		"pop %gs\n\t"
		"pop %fs\n\t"
		"pop %es\n\t"
		"pop %ds\n\t"
		"popal\n\t"
		"iret\n\t"
	);
}

int PitStorageSafeActive(void)
{
	return pit_storage_safe_active;
}

void PitStorageSafeBegin(void)
{
	DWORD flags;

	flags = get_eflags();
	disable();

	if(!pit_storage_safe_active)
	{
		pit_storage_saved_multitasking = Multitasking;
		Multitasking = FALSE;
		setint(M_VEC, pit_tick_only_ISR, SEG_CODE32,
			D_INT + D_PRESENT);
		pit_storage_safe_active = TRUE;
	}

	enable_irq(0);
	set_eflags(flags);
	dprintk("PIT: storage-safe tick-only IRQ0 enabled; TSS scheduler paused.\n");
}

void PitStorageSafeEnd(void)
{
	DWORD flags;

	flags = get_eflags();
	disable();

	if(pit_storage_safe_active)
	{
		InstallPitTaskGate();
		Multitasking = pit_storage_saved_multitasking;
		pit_storage_safe_active = FALSE;
	}

	set_eflags(flags);
	dprintk("PIT: normal TSS scheduler IRQ0 restored.\n");
}

//
extern void pit_ISR(void);

//
void Sleep(int _count)
{
	MilSleep(_count);
}

//
void runPitHandlers(void)
{
	//
#ifndef IMPLEMENT_MULTIPLE_PIT_HANDLERS
	return;
#endif

	//
	int i;

	// Call other handlers
	for(i=0; i<pit->n_handlers; i++)
	{
		//
		if(pit->handler[i]!=NULL)
			(*(void (*)(void)) pit->handler[i])();
	}
}

//---------------------------------------------------------------------------------
// Init programmable interrupt timer
//
void InitTimer(void)
{
        // Let's enable timer:

	//
	disable();
        // 1) Setup a safe timer frequency at the first place
        init_pit(SAFE_TIMER_FREQUENCY, 0);
        // 2) Setup handler for the PIT timer interrupt
        setint(M_VEC,
                pit_low, GIMMIE_CS(),
                D_INT + D_PRESENT);
        // 3) Enable PIT timer
//        enable_irq(0);
}

/*
The timer output frequency is obtained by dividing the 8253 master clock
frequency of 1,193,180 Hz by a 16 bit divisor.  (A zero divisor is treated as
65,536.  This is the value programmed by the BIOS, to give a system timer of
18.2065 Hz.)  The timer is programmed by sending a control byte to port 43h,
followed by a divisor word (low byte, high byte) to port 4Xh where X is the
timer being programmed.

If the system timer (counter 0) is modified, an Int 8 handler must be written to
call the original Int 8 handler 18.2 times per second, otherwise some system
functions (eg time of day) may be upset.  When it does call the original Int 8
handler it must NOT send and EOI to the 8259 for the timer interrupt, since the
original Int 8 handler will send the EOI also.

Mitch

default 0x1000(16x BIOS default)
*/
void init_pit(long h, unsigned char channel)
{
	//
	DWORD temp=0;
	DWORD saved_flags;
	int i;

	// Initialize PIT structure
	pit = malloc(sizeof(PIT));
	memset(pit, 0, sizeof(PIT));
	
	//
	temp = h;
	
	// -----------------------------------------------------------------
	/*
	 * Do not use the historical PUSHFLAGS/POPFLAGS macros here.  They were
	 * separate inline-asm pushf/popf statements with an invisible ESP side
	 * effect.  GCC -O2 is therefore free to move stack-argument cleanup
	 * across PUSHFLAGS; in V67.8.50 that consumed the saved EFLAGS word and
	 * POPFLAGS later loaded unrelated stack data, occasionally setting TF
	 * and causing an early #DB (single-step) exception.
	 */
	saved_flags = get_eflags();
	disable();

	//
	outportb(TMR_CTRL, (channel*0x40) + TMR_BOTH + TMR_MD3);
	outportb((0x40+channel), (unsigned char) temp);
	outportb((0x40+channel), (unsigned char) (temp>>8));

	// Init all tick counters
	init_counters();
	pit_ms_phase = 0;
	/* PIT input clock is 1,193,180 Hz. A programmed divisor of zero means
	 * 65536 on the 8253/8254. */
	{
		DWORD divisor = ((DWORD)h & 0xFFFF);
		if(divisor == 0) divisor = 65536;
		pit_programmed_divisor = divisor;
		/* Rounded raw IRQ frequency is used by scheduler statistics only.
		 * Milliseconds and microseconds below use the exact divisor ratio. */
		pit_input_ticks_per_second = (PIT_INPUT_HZ + divisor/2) / divisor;
		if(!pit_input_ticks_per_second) pit_input_ticks_per_second = 1;
		pit_prepare_usec_increment(divisor);
	}

	// Determine raw tick rate deterministically; IRQ0 is not enabled yet.
	initPitMeasure();

	//
	set_eflags(saved_flags);
	// -----------------------------------------------------------------
}

// Makes up precalculations,
// e.g. how many ticks is one second
// at the current tick rate.
// To delay a millisecond, the amount
// of ticks needed to delay a single second
// is divided by 100, then this amount
// of ticks is waited and
// a millisecond has passed.
void initPitMeasure(void)
{
	/* IRQ0 is still masked while InitTimer() runs, so the historical
	 * sleep()/GetTickCount2() calibration always measured zero.  Derive the
	 * rate directly from the 8253/8254 input clock instead. */
	pit->secondInTicks = pit_input_ticks_per_second;
	pit->millisecondInTicks = pit->secondInTicks / 1000;
	if(!pit->secondInTicks) pit->secondInTicks = 1;
	if(!pit->millisecondInTicks) pit->millisecondInTicks = 1;
	printk("%s: PIT divisor=%u, IRQ rate=%u Hz, exact clock ~= %u us/IRQ.\n",
		__FUNCTION__, pit_programmed_divisor, pit->secondInTicks, pit_usec_tick_whole);
	if(pit->secondInTicks < 250)
		printk("PIT WARNING: IRQ rate below 250 Hz; scheduler/wakeup granularity is coarse.\n");
}

/* Return the PIT-derived monotonic clock in microseconds.  The counter wraps
 * naturally at 2^32 usec (~71.6 minutes); unsigned subtraction makes normal
 * sleep intervals wrap-safe.  Resolution is one PIT interrupt (~215 usec at
 * the default divisor 0x100), while long-term rate follows the exact PIT
 * divisor rather than an integer-Hz approximation. */
DWORD PitGetUsec(void)
{
	DWORD flags;
	DWORD now;

	flags = get_eflags();
	disable();
	now = pit_monotonic_usec;
	set_eflags(flags);
	return now;
}

/* Scheduler-friendly microsecond sleep.  This is a minimum-duration sleep,
 * as POSIX-style usleep() must be: scheduler load may make the actual delay
 * longer.  With normal multitasking it explicitly yields via SwitchToThread;
 * during storage-safe/early boot it executes HLT and wakes on PIT/IRQ6 rather
 * than burning CPU in a polling loop. */
int UsecSleep(DWORD usec)
{
	DWORD start;
	DWORD flags;

	if(usec == 0)
	{
		if(Multitasking && !PitStorageSafeActive())
			SwitchToThread();
		return 0;
	}

	flags = get_eflags();
	if(!Multitasking && !(flags & 0x200))
	{
		/* With no scheduler and IF clear, neither IRQ0 nor another runnable
		 * task can advance the software clock.  A normal userspace syscall
		 * enters through an interrupt gate with IF clear, but Multitasking is
		 * active there: SwitchToThread() lets other tasks/PIT advance time. */
		return -1;
	}

	if(Multitasking && !PitStorageSafeActive())
		return SchedulerSleepCurrentUsec(usec);

	/* Early boot/storage-safe mode has no runnable-task scheduler. */
	start = PitGetUsec();
	while((DWORD)(PitGetUsec() - start) < usec)
		__asm__ __volatile__("hlt" ::: "memory");

	return 0;
}

// Sleep a specified amount of milliseconds (1/1000 seconds).
void MilSleep(int periodMilliseconds)
{
	DWORD chunk;

	if(periodMilliseconds <= 0) return;

	/* Avoid overflow in msec*1000 while retaining the historical void API. */
	while(periodMilliseconds > 0)
	{
		chunk = (periodMilliseconds > 1000000) ? 1000000UL :
			(DWORD)periodMilliseconds;
		if(UsecSleep(chunk * 1000UL) != 0)
			return;
		periodMilliseconds -= (int)chunk;
	}
}

//
unsigned int pit_getchannel(unsigned char channel)
{
	//
	unsigned int x=0;
	
	//
	outportb(TMR_CTRL, (channel*0x40) + TMR_LATCH);
	x = inportb(0x40+channel);
	x += (inportb(0x40+channel) << 8);
	return x;
}

//----------------------------------------------------------------
// PIT interrupt handler (timer interrupt handler)
//
void pit_handler(void)
{
	int i,kert;
	char *p;

	// test...
/*	p = 0xB8000;
	for(i=0; i<50; i++)
	{
		p[i]++;
	}*/

	//
	ThreadTimeOut();
	SchedulerCpuTick();

	/* Increase generic raw-tick timers, but NOT timer[10].  timer[10] is
	 * the public millisecond clock returned by GetTickCount().  The old loop
	 * incremented timer[10] on every raw PIT IRQ and then incremented it again
	 * in the millisecond divider, making time run several times too fast. */
	for(i=0; i<50; i++)
	{
		if(i != 10) glvar.timer[i]++;
	}

	runPitHandlers();

	/* Exact PIT-ratio millisecond divider.  Do not round the PIT to an integer
	 * Hz first: the programmed divisor is not generally an integer-Hz rate. */
	pit_ms_phase += pit_programmed_divisor * 1000UL;
	while(pit_ms_phase >= PIT_INPUT_HZ)
	{
		pit_ms_phase -= PIT_INPUT_HZ;
		glvar.timer[10]++;
		fd_int1c();
	}

	/* Exact-average microsecond duration clock, same PIT source. */
	pit_monotonic_usec += pit_usec_tick_whole;
	pit_usec_phase += pit_usec_tick_remainder;
	if(pit_usec_phase >= PIT_INPUT_HZ)
	{
		pit_usec_phase -= PIT_INPUT_HZ;
		pit_monotonic_usec++;
	}

	// This is done in ASM handler timerhandler.mac:
//	outportb(0x20, 0x20);
}

//
void init_counters(void)
{
	//
	int i;

	//
	for(i=0; i<50; i++) { glvar.timer[i]=0; glvar.dbtimer[i]=0; }
}

// Add new PIT handler
void addPitHandler(void *ptr)
{
	int i;

	if(ptr==NULL)
	{
		dprintk("addPitHandler: NULL handler rejected.\n");
		return;
	}

	//
	if(pit->n_handlers==0)
		pit->n_handlers++;

	//--------------------------------------------------
	// Look for empty entry, if not found,
	// add one more entry.
	for(; ; pit->n_handlers++)
	{
		//
		if(pit->n_handlers>=N_MAX_PIT_HANDLERS)
		{
			dprintk("addPitHandler: handler table full (%d).\n",N_MAX_PIT_HANDLERS);
			return;
		}

		//--------------------------------------------------
		for(i=0; i<pit->n_handlers; i++)
		{
			//
			if(pit->handler[i]==NULL)
			{
				//
				pit->handler[i]=ptr;
				return;
			}
		}
	}
}

// Remove a PIT handler
void removePitHandler(void *ptr)
{
	int i;

	//
	for(i=0; i<pit->n_handlers; i++)
	{
		//
		if(pit->handler[i]==ptr)
		{
			//
			pit->handler[i]=NULL;
			return;
		}
	}
}

//


