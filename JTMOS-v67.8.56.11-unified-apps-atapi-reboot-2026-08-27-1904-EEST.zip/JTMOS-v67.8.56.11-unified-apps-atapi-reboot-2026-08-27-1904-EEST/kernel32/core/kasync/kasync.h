#ifndef JTMOS_KASYNC_H
#define JTMOS_KASYNC_H
#define KASYNC_MAX_JOBS 64
#define KASYNC_ARG_MAX 256
#define KASYNC_WORKERS 2
#define KASYNC_DETACHED 1
#define KASYNC_FREE 0
#define KASYNC_QUEUED 1
#define KASYNC_RUNNING 2
#define KASYNC_DONE 3
#define KASYNC_CANCELLED 4
#define KASYNC_TIMEDOUT 5
typedef int (*KASYNC_FUNCTION)(int job_id,void *argument,unsigned int argument_size);
typedef struct {int id,state,result;unsigned long submitted_at,started_at,finished_at,deadline;} KASYNC_STATUS;
int kasync_init(void);
int kasync_submit(KASYNC_FUNCTION function,const void *argument,unsigned int argument_size,unsigned long timeout_ms,int flags);
int kasync_poll(int job_id,KASYNC_STATUS *status);
int kasync_wait(int job_id,unsigned long timeout_ms,KASYNC_STATUS *status);
int kasync_cancel(int job_id);
int kasync_cancelled(int job_id);
int kasync_release(int job_id);
void kasync_counts(int *queued,int *running,int *finished);
DWORD kasync_memory_bytes(void);
#endif
