// =====================================================
// int 0x7E - JTMOS system call & FD database init.
// (C) 2001-2003 by Jari Tuominen
// =====================================================
#include "kernel32.h"
#include "system_call.h"
#include "int.h"
#include "systemcalls.h"
#include "filedes.h" // init_filedes - inits filedes database system

// System calls status.
int scallsIsWorking=FALSE;

// Install system call handler.
// (enables system calls)
void scall_init(void)
{
	int gate_entry;

	scallsIsWorking = FALSE;

	//
/*	gate_entry = gdt_NewEntry();
	SetCallGate(gate_entry, scall_handler,SEG_CODE32,
		128+ 64+32+ 8+4, // access: present(128), DPL3(64+32), 8+4(type=call gate)
		0);
	setint(SCALL_INT_NR, 0, gate_entry, 0xEE00);
*/

	//
	setint(SCALL_INT_NR, scall_handler, SEG_CODE32, 0xEE00); /* P=1,DPL=3,32-bit interrupt gate */

	// Init only
	// see scconf.h
//	setint(SCALL_INT_NR, scall_handler, SEG_CODE32, 0xEE00); /* P=1,DPL=3,32-bit interrupt gate */

	//
	setint(0x7E, NULL, SEG_CODE32, 0xEE00);

	// Do not advertise syscall readiness until init_filedes() has completed.

	// Init file descriptor database system
	init_filedes();
	scallsIsWorking = TRUE;

	// Report
	if(scallsIsWorking)
		printk("System calls are enabled.\n");
	else
		printk("System calls are disabled.\n");
}

//

