//--------------------------------------------------------------------------------------------
// threadSwitch.c - thread switching logic.
//--------------------------------------------------------------------------------------------
#include "kernel32.h"
#include "threads.h"
#include "threadSwitch.h"

// Aka ASCPI sleep.
int vmware_sleep_enabled = TRUE;
//
static int SleepTime=2;
//
static int goback=0;

//
void vmware_sleep(void)
{
	//
	if(vmware_sleep_enabled && vmware)
	{
		vmsleep();
	}
}

//--------------------------------------------------------------------------------------------
// Used by ScheduleNextThread and timerhandler.mac.
//
void forceSwitch(void)
{
    int scanned;
    int idle;
    int return_thread;
    TSSEG *t;
    char str[256],str2[256];

    idle = RPID(IdleThread.pid);

    /* SwitchToThread() is a pure voluntary yield.  Do not put preempted or
     * yielding threads to sleep here: PIT preemption must leave normal runnable
     * work runnable, otherwise CPU_IDLE steals real CPU time. */

    //---------------------------------------------------------------------
    // Do we have an ordered switch to a specified thread ?
    if(force_switch_thread_nr && !goback)
    {
        goback = nr_curthread;
        nr_curthread = force_switch_thread_nr;
        thread_idling[nr_curthread] = 0;
        force_switch_thread_nr = 0;
        return;
    }

    // Return back from a forced transfer before continuing round-robin.
    if(goback)
    {
        return_thread = goback;
        goback = 0;
        nr_curthread = return_thread;
    }

    //---------------------------------------------------------------------
    // Search one complete round for a genuinely runnable non-idle thread.
    // CPU_IDLE is a fallback only; it is never part of the normal rotation.
    for(scanned=0; scanned<nr_threads; scanned++)
    {
        nr_curthread++;
        if(nr_curthread >= nr_threads)
            nr_curthread = 0;

        if(nr_curthread == idle)
            continue;
        if(!thread_states[nr_curthread])
            continue;

        // Voluntary sleeps/yields decrement only when the scheduler sees them.
        if(thread_idling[nr_curthread])
        {
            thread_idling[nr_curthread]--;
            continue;
        }

        // Honor the historical JTMOS priority divisor.  Priority 1 runs on
        // every visit, 2 every second visit, 4 every fourth, and so on.
        thread_tick[nr_curthread]++;
        if(thread_tick[nr_curthread] < thread_states[nr_curthread])
            continue;
        thread_tick[nr_curthread] = 0;

        t = GetThreadTSS(nr_curthread);
        if(t==NULL || !t->cs || !t->ds || !t->es || !t->fs)
        {
            GetThreadName(nr_curthread, str2);
            dprintk("%s: quarantining process %d(%s): invalid TSS selectors.\n",
                __FUNCTION__, nr_curthread, str2);
            if(nr_curthread==0)
                KERNEL_FATAL("scheduler: PID0 has an invalid TSS");
            thread_states[nr_curthread]=0;
            continue;
        }

        return;
    }

    /* Nothing else is runnable right now.  CPU_IDLE is immortal and is the
     * only task allowed to execute HLT. */
    if(idle >= 0 && idle < nr_threads && thread_states[idle])
    {
        nr_curthread = idle;
        thread_idling[idle] = 0;
        return;
    }

    /* Early-boot safety fallback: idle should already exist once multitasking
     * is enabled, but never index outside the thread table if it does not. */
    nr_curthread = 0;
}

