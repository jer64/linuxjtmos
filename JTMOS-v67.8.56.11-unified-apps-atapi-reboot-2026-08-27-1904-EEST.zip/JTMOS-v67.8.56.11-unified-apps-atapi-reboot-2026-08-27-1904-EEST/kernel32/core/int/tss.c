//-----------------------------------------------------------
// Hardware task switching support (TSS).
// (C) 2003-2005 by Jari Tuominen.
//-----------------------------------------------------------
#include "kernel32.h"
#include "int.h"
#include "threads.h"
#include "tss.h"
#include "scheduler.h"

//
static TSSEG backup_kertss[10];
static CDSEG backup_kertssdes[10];

// Current TSS entry being active
int n_curtss=0;

///////////////////////////////////////////////////////////////////////////////
//
// Initialize TSS system.
//
void InitTSS(void)
{
	int i;

	//
	printk("  - tasks = malloc(...)\n");
	tasks = malloc(sizeof(TASKS));
	if(tasks==NULL)
		KERNEL_FATAL("InitTSS: cannot allocate task database");
	printk("  - memset(tasks, 0, ....)\n");
	memset(tasks, 0, sizeof(*tasks));

	///////////////////////////////////////////////////////////////////////
	// Set TSS descriptors on GDT table (0xNN, ... ->)
	//
	printk("  - Setting TSS descriptors on GDT table ...\n");
	for(i=0; i<256; i++)
	{
		SetSD(&gdt_table->tssdes[i], &tasks->tss[i], sizeof(TSSEG)-1); //
	}

	///////////////////////////////////////////////////////////////////////
	//
	printk("  - Setting up TSS exception handler ...\n");
	SetupTSSExceptionHandler();

	///////////////////////////////////////////////////////////////////////
	//

	//
}

//--------------------------------------------
// -- TSS functions for PIT based task switcher: --
//

///////////////////////////////////////////////////////////////////////////////
//
void SetTSSDESBusyBit(CDSEG *s, char val)
{
	//
	if(val)
		// Set the BUSY flag.
		s->flags |= 2;
	else
		// Unset the BUSY flag.
		s->flags &= ~2;
}

// Set current TSS as unbusy
void unbusyTSS(void)
{
	/* #GP/#PF now run through normal interrupt gates, not exception TSS
	 * task gates.  The old exception-only LOADTR(0x48) is therefore stale
	 * and can corrupt the recovery switch.  SchedulerJumpSelected() performs
	 * the single required dump-TSS LOADTR after this function for every switch. */
	if(EXCEPTION_HANDLER_ACTIVE)
		EXCEPTION_HANDLER_ACTIVE = FALSE;

	// 1) Fix for exception handler.
	SetTSSDESBusyBit(&gdt_table->kertssdes[0], 0);
	// 2) Fix for scall handler.
	SetTSSDESBusyBit(&gdt_table->kertssdes[1], 0);
	// Rest....
	SetTSSDESBusyBit(&gdt_table->kertssdes[2], 0);
	SetTSSDESBusyBit(&gdt_table->kertssdes[3], 0);
	SetTSSDESBusyBit(&gdt_table->kertssdes[4], 0);
	SetTSSDESBusyBit(&gdt_table->kertssdes[5], 0);
	SetTSSDESBusyBit(&gdt_table->kertssdes[6], 0);
	SetTSSDESBusyBit(&gdt_table->kertssdes[7], 0);
	SetTSSDESBusyBit(&gdt_table->kertssdes[8], 0);
	SetTSSDESBusyBit(&gdt_table->kertssdes[9], 0);
	SetTSSDESBusyBit(&gdt_table->kertssdes[10], 0);

	// 3) Fix for threads.
	SetTSSDESBusyBit(&gdt_table->tssdes[nr_curthread], 0);

	//
	TaskSwitched();
}

///////////////////////////////////////////////////////////////////////////////
//
void tssNextThread(void)
{
	// Do what ever needed here:
	//
}

///////////////////////////////////////////////////////////////////////////////
//
void SetTaskGateDPL(TSS_GATE *t, WORD selector, unsigned dpl)
{
	if(t==NULL || dpl>3) return;
	memset(t, 0, sizeof(TSS_GATE));
	t->selector = selector;
	/* 386 task gate: P=1, DPL=dpl, type=5. */
	t->type = (BYTE)(0x85U | ((dpl & 3U) << 5));
}

void SetTaskGate(TSS_GATE *t, WORD selector)
{
	/* Safe default for hardware/task exception gates. */
	SetTaskGateDPL(t, selector, 0);
}

void InstallPitTaskGate(void)
{
	WORD *p;

	p = GetIDTPTR();
	p += 3;
	SetTaskGate((TSS_GATE *)(p + M_VEC*4), 0x60);
}

//--------------------------------------------
// -- TSS system: --
//


///////////////////////////////////////////////////////////////////////////////
//
void Bingo1(void)
{
	static int i,i2,i3,i4,l;
	BYTE *p;

	//
	p = 0xB8000;

	//
	l = 80*25*2;
	for(i=0; i<l; i++)
	{
		p[i] = i+i2;
	}
	i2++;
}

// Do something colorful.
void Bingo(void)
{
	int i,i2,i3,i4,l;
	BYTE *p;

	//
	for(i2=0; ; i2++)
	{
		//
		Bingo1();
		/* Never poll the shared i8042 data register here. */
		if(kbstr.ktab && kbstr.ktab[SCODE_ESCAPE])
			break;
	}
}

///////////////////////////////////////////////////////////////////////////////
//
void TSSJump(TSSEG *t,
	WORD seg, DWORD eip)
{
	// Setup code segment
	t->cs   = seg; 
	// And the address where to start execution ...
	t->eip  = eip;
}

///////////////////////////////////////////////////////////////////////////////
// Creates selectors 0x40 and 0x48 on the GDT table.
//
void SetupTSSExceptionHandler(void)
{
	WORD *p;

	//
	disable();

	printk("  - GPF handler\n");
	// GPF HANDLER TASK SELECTOR 0x40
	// 13: Setup new GPF handler, that supports TSS multitasking (selector 0x40).
	NewTSS(&tasks->kertss[0], ASMexception_13, 0x100, -1); // 0x100 is just a mandatory link (ignore it)
	tasks->kertss[0].eflags &= ~(1<<9); // disable interrupts
	SetSD(&gdt_table->kertssdes[0], &tasks->kertss[0], sizeof(TSSEG)-1);

	printk("  - page fault handler\n");
	// PAGE FAULT HANDLER 0x50
	// 14: Setup new GPF handler, that supports TSS multitasking (selector 0x40).
	NewTSS(&tasks->kertss[2], ASMexception_14, 0x100, -1);
	tasks->kertss[2].eflags &= ~(1<<9); // disable interrupts
	SetSD(&gdt_table->kertssdes[2], &tasks->kertss[2], sizeof(TSSEG)-1);

	// SCHEDULER: IMMEDIATE TASK SWITCH 0x58
	printk("  - immediate task switch (scheduler)\n");
	NewTSS(&tasks->kertss[3], LLSchedule, 0x40, -1);
	tasks->kertss[3].eflags &= ~(1<<9); // disable interrupts
	SetSD(&gdt_table->kertssdes[3], &tasks->kertss[3], sizeof(TSSEG)-1);

	// SCHEDULER: PIT TASK SWITCH 0x60
	printk("  - PIT task switch\n");
	NewTSS(&tasks->kertss[4], TaskPitHandler, 0x40, -1);
	tasks->kertss[4].eflags &= ~(1<<9); // disable interrupts
	SetSD(&gdt_table->kertssdes[4], &tasks->kertss[4], sizeof(TSSEG)-1);

	// DOUBLE FAULT HANDLER 0x68 -- private TSS and private stack.
	// #DF must not depend on the stack that caused the original exception.
	printk("  - double fault emergency task\n");
	NewTSS(&tasks->kertss[5], ASMdoublefault_task, 0x100, -1);
	tasks->kertss[5].eflags &= ~(1<<9);
	SetSD(&gdt_table->kertssdes[5], &tasks->kertss[5], sizeof(TSSEG)-1);

	// TEMPORARY SELECTOR 0x48
	// Create TSS entry for temporary use (selector 0x48).
	printk("  - temporary selector\n");
	NewTSS(&tasks->kertss[1], ASMexception_13, 0x78, -1);
	tasks->kertss[1].eflags &= ~(1<<9); // disable interrupts
	SetSD(&gdt_table->kertssdes[1], &tasks->kertss[1], sizeof(TSSEG)-1);

	//
	printk("  - setting up task gates\n");
	// Get IDT table PTR.
	p = GetIDTPTR();
	p += 3;
	/* #DF is special: use an independent TSS/task gate so a corrupted or
	 * exhausted current stack cannot prevent the double-fault handler from running. */
	SetTaskGate((TSS_GATE *)(p+8*4), 0x68);

	/* Keep #GP and #PF on the normal interrupt-gate handlers installed by
	 * init_idt().  Making the exception handlers themselves TSS task gates
	 * means that any TSS/task-switch problem while handling the first fault
	 * immediately escalates into #DF and hides the original exception. */

	// TSS based PIT handler.
	InstallPitTaskGate();
	// INT 0x7E = immediate task switch.
	SetTaskGateDPL((TSS_GATE *)(p+0x7E*4), 0x58, 3);
	// INT 0x7F = system call.
	// Not setupped here, see heart/scs.

/*	//
	printk("  - enabling PIT timer interrupt (interrupts still disabled)\n");
        // Enable PIT timer.
        enable_irq(0);
	printk("  OK.\n");
	printk("Test ...\n");
	sleep(10);	*/
}

///////////////////////////////////////////////////////////////////////////////
// Set [segment] descriptor.
//
void SetSD(CDSEG *s, DWORD base, WORD limit)
{
	// First clear the structure.
	memset(s, 0, sizeof(CDSEG));

	// Define limit & base first.
	s->seg0_15 = limit & 0xFFFF;
	s->base0_15 = base & 0xFFFF;
	s->base16_23 = (base>>16) & 0xFF;
	s->base24_31 = (base>>24) & 0xFF;

	/* Present, DPL0.  TSS descriptors are kernel-only: ring-3 yields through
	 * the DPL3 INT 0x7E task gate and cannot far-JMP directly into a TSS. */
	s->flags = 0x80;
	//	TYPE	DESCRIPTION
	//	9	386 TSS (available, JMP)
	//	11	386 TSS (busy, IRET)
	s->flags |= 9;

	// Access contains AVL, GRA, LIMIT 19:16.
	s->access = (1<<4);
}

///////////////////////////////////////////////////////////////////////////////
//
void NewTSS(TSSEG *_t, DWORD sysad, WORD link, int pid)
{
	TSSEG *t = _t;

	//
	NewTSSEx(t,sysad,link,pid,0);
}

// Create a new task segment with data.
void NewTSSEx(TSSEG *t, DWORD sysad, WORD link, int pid,
		DWORD options)
{
	DWORD stacksize;
	BYTE *stack1,*stack2,*stack3,*stack4;

	// First clear the structure
	memset(t, 0, sizeof(TSSEG));

	// Link to next process(segment selector)
	t->link = link;
 
	// Define size of the stack.
	// (those stacks should not be used for any big things...)
	stacksize = 1024*4;
 
	// Allocate stacks
	stack1=malloc(stacksize);
	stack2=malloc(stacksize);
	stack3=malloc(stacksize);
	stack4=malloc(stacksize);
	if(!stack1 || !stack2 || !stack3 || !stack4)
	{
		if(stack1) free(stack1);
		if(stack2) free(stack2);
		if(stack3) free(stack3);
		if(stack4) free(stack4);
		memset(t,0,sizeof(*t));
		if(pid==-1)
			KERNEL_FATAL("NewTSS: cannot allocate kernel task stack");
		dprintk("NewTSS: cannot allocate stacks for PID %d.\n",pid);
		return;
	}
	if(pid!=-1)
	{
		ChangeChunkOwner(stack1, pid);
		ChangeChunkOwner(stack2, pid);
		ChangeChunkOwner(stack3, pid);
		ChangeChunkOwner(stack4, pid);
	}

	// Define stack pointers
	// (end of the buffer is the beginning)
	t->ss0  = SEG_DATA32;
	t->esp0 = stack1+(stacksize-1);
	t->ss1  = SEG_DATA32;
	t->esp1 = stack2+(stacksize-1);
	t->ss2  = SEG_DATA32;
	t->esp2 = stack3+(stacksize-1);
	// Actually used one:
	t->ss   = SEG_DATA32;
	t->esp  = stack4+(stacksize-1);
 

	// Setup data segment(s)
	t->ds   = SEG_DATA32;
	t->es   = SEG_DATA32;
	t->fs   = SEG_DATA32;
	t->gs   = SEG_DATA32;

	// Setup code segment
	t->cs   = SEG_CODE32; 
	// And the address where to start execution ...
	t->eip  = sysad;
 
	// Local Descriptor Table Register(selector)
	// (we don't need one)
	t->ldtr  = 0;
 
	/* Ring-3 tasks must not inherit accidental raw I/O permissions.
	 * The I/O-map base is one byte beyond the 104-byte 386 TSS limit,
	 * which means no bitmap is present and CPL3 port I/O is denied.
	 * Drivers use JTMOS kernel-mediated IRQ/DMA/PIO APIs instead. */
	t->iopb  = sizeof(TSSEG);

	// No CR3 needed.
	t->cr3 = GetCR3();
 
	/* A freshly created task must not inherit transient kernel EFLAGS such
	 * as NT or DF.  0x202 is the canonical IA-32 task start state here:
	 * reserved bit 1 + IF, with NT/DF/TF/IOPL clear.
	 *
	 * The old code also set EFLAGS bit 3 as an alleged FPU task-switched
	 * flag.  TS is CR0.bit3, not EFLAGS.bit3; EFLAGS bit3 is reserved. */
	t->eflags = 0x00000202;
}

///////////////////////////////////////////////////////////////////////////////
//
void DumpTSS(TSSEG *t)
{
	//
	printk("TSS DUMP\n");
	printk("CS:EIP = %x:%x\n",
		t->cs, t->eip);
}

///////////////////////////////////////////////////////////////////////////////


