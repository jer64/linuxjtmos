// ======================================================================
// scs.c - JTMOS system call services.
// (C) 2002-2021 by Jari Tuominen
// (jari.t.tuominen@gmail.com).
//
// Note: all system calls implement it's callers stack,
// therefore all pointer references to the local variables,
// that are stored in the present stack are either invalid
// or must be specifically converted from USER memory space
// addressing to the KERNEL memory space addressing.
//
// This is a major bug that have been raging the system
// for a very long time.
// ======================================================================
#include "kernel32.h"
#include "systemcalls.h" // aka scs.h
#include "scconf.h" // contains only defines, works with nasm
#include "ega.h" // N_VIRTUAL_TERMINALS
#include "threads.h" // SwitchToThreadEx
#include "scs.h"
#include "scs2.h"
#include "scs_devices.h" // sys_readblock, etc.
#include "mouse.h"
#include "ps2mouse.h"
#include "msgbox.h"
#include "driver_diskchange.h"
#include "serial.h"
#include "scheduler.h"

//
void *scall_functions[N_MAX_SCALLS]={
	// 0
	// dummy entry, never ought to be called
	scall_dummy,
	// 1 SYS_IDLE
	idle_moment,
	// 2 SYS_remove
	scall_remove,
	// 3 SYS_mkfs
	scall_mkfs,
	// 4 SYS_rename
	scall_rename,
	// 5
	scall_dummy,
	// 6 SYS_PUTS
	scall_puts,
	// 7 SYS_PUTCH
	scall_putchar,
	// 8 SYS_EXIT
	scall_exit,
	// 9 SYS_CLRSCR
	scall_clrscr,
	// 10 SYS_GETCH
	scall_getch,
	// 11 postcmd
	scall_postcmd,
	// 12 SYS_GETCURDEV
	scall_getcurdev,
	// 13 SYS_GOTOXY
	scall_gotoxy,
	// 14 SYS_GETTICKCOUNT
	scall_gettickcount,
	// 15 SYS_GETAMEMSIZE
	scall_getamemsize,
	// 16 SYS_GETCURRENTTHREAD
	scall_getcurrentthread,
	// 17 SYS_GETARGC
	scall_getargc,
	// 18 SYS_GETARGV
	scall_getargv,
	// 19 SYS_open
	scall_open,
	// 20 SYS_close
	scall_close,
	// 21 SYS_read
	scall_read,
	// 22 SYS_write
	scall_write,
	// 23 SYS_lseek
	scall_lseek,
	// 24 SYS_cexec
	scall_cexec,
	// 25 SYS_getdevnrbyname
	scall_getdevnrbyname,
	// 26 SYS_readblock
	scall_readblock,
	// 27 SYS_writeblock
	scall_writeblock,
	// 28 SYS_waitprocterm
	scall_waitprocterm,
	// 29 SYS_findfirst
	scall_findfirst,
	// 30 SYS_findnext
	scall_findnext,
	// 31 SYS_textcolor
	scall_textcolor,
	// 32 SYS_textbackground
	scall_textbackground,
	// 33 SYS_inputmouse
	scall_inputmouse,
	// 34 SYS_setmouserect
	scall_setmouserect,
	// 35 SYS_vgadrawframe
	scall_vgadrawframe,
	// 36 SYS_GETCURDB
	scall_getcurdb,
	// 37 SYS_vgawaitretrace
	scall_vgawaitretrace,
	// 38 SYS_chdir
	scall_chdir,
	// 39 SYS_getdevicename
	scall_getdevicename,
	// 40 SYS_getdate
	scall_getdate,
	// 41 SYS_WHEREX
	scall_wherex,
	// 42 SYS_WHEREY
	scall_wherey,
	// 43 SYS_vgaselectplane
	scall_vgaselectplane,
	// 44 getdevicenrbyname
	scall_getdevicenrbyname,
	// 45 
	scall_getthreadpriority,
	// 46
	scall_getthreadspending,
	// 47
	scall_getthreadname,
	// 48
	scall_getthreadmemoryusage,
	// 49
	scall_getthreadcount,
	// 50
	scall_getctrl,
	// 51
	scall_getalt,
	// 52 Activate thread's MSGBOX
	scall_activatemsgbox,
	// 53 Send message to a PID
	scall_sendmessage,
	// 54 Receive message
	scall_receivemessage,
	// 55 getthreadpid
	scall_getthreadpid,
	// 56 identifythread
	scall_identifythread,
	// 57 getseconds
	scall_getseconds,
	// 58 globalcopy
	scall_globalcopy,
	// 59 getthreadterminal
	scall_getthreadterminal,
	// 60 setthreadterminal
	scall_setthreadterminal,
	// 61 NewTerminal
	scall_newterminal,
	// 62 outputterminalkeyboardbuffer
	scall_outputterminalkeyboardbuffer,
	// 63 inputterminalkeyboardbuffer
	scall_inputterminalkeyboardbuffer,
	// 64 copyterminal
	scall_copyterminal,
	// 65 killthread
	scall_killthread,
	// 66 getcursorlocation
	scall_getcursorlocation,
	// 67 setint
	scall_setint,
	// 68 enableirq
	scall_enableirq,
	// 69 diskchange
	scall_diskchange,
	// 70 getthreaduniquepid
	scall_getthreaduniquepid,
	// 71 registernewdevice
	scall_registernewdevice,
	// 72 switchtothreadex
	scall_switchtothreadex,
	// 73 createterminal
	scall_createterminal,
	// 74 setterminalowner
	scall_setterminalowner,
	// 75 getterminalowner
	scall_getterminalowner,
	// 76 serialget
	scall_serialget,
	// 77 serialput
	scall_serialput,
	// 78 setserialportspeed
	scall_setserialportspeed,
	// 79 receiverawpacket
	scall_receiverawpacket,
	// 80 transmitrawpacket
	scall_transmitrawpacket,
	// 81 devicecall
	scall_devicecall,
	// 82 milsleep
	scall_milsleep,
	// 83 opensocket
	scall_opensocket,
	// 84 closesocket
	scall_closesocket,
	// 85 readsocket
	scall_readsocket,
	// 86 writesocket
	scall_writesocket,
	// 87 switchtothread
	scall_switchtothread,
	// 88 getcwd
	scall_getcwd,
	// 89 stat
	scall_stat,
	// 90 fstat
	scall_fstat,
	// 91 SYS_wgetch
	scall_wgetch,
	// 92 SYS_mkdir
	scall_mkdir,
	// 93 kmalloc
	scall_kmalloc,
	// 94 kfree
	scall_kfree,
	// 95 SYS_fexist
	scall_fexist1,
	// 96 SYS_getfiledatablock
	scall_getfiledatablock,
	// 97 SYS_isdriveready
	scall_isdriveready,
	// 98 SYS_diskchange_compat (legacy duplicate of syscall 69)
	scall_diskchange,
	// 99 SYS_getfilesize
	scall_getfilesize,
	// 100 SYS_read1
	scall_read1,
	// 101 SYS_write1
	scall_write1,
	// 102 SYS_creat1
	scall_creat1,
	// 103 SYS_unlink1
	scall_unlink1,
	// 104 SYS_setsize1
	scall_setsize,
	// 105 SYS_getcpustats
	scall_getcpustats,
	// 106 SYS_usleep
	scall_usleep
};

// Number of system calls registered
DWORD nr_scall_func = 120;


//--------------------------------------------------------------------------
//
// A2K.
// Application to Kernel memory space address conversion function.
//
DWORD A2K(DWORD appoffs)
{
	return _A2K(appoffs, GetCurrentThread());
}

// PID specific.
DWORD _A2K(DWORD appoffs, int pid)
{
	DWORD tb;

	//
	if(	appoffs >= 0x80000000 && 
		appoffs <= 0x8FFFF000 )
	{
		//
		if( !(tb=GetThreadBase(pid)) )
		{
			dprintk("Unknown 0x8NNN NNNN address.\n");
			goto past;
		}

		// Seems to be an application address.
		return (appoffs-0x80000000)+tb;
	}

past:
	// Not an application address..
	return appoffs;
}

//--------------------------------------------------------------------------
//
static void LogThisSystemCall(SYSCALLPAR)
{
	char str[256];

	//
	if(scall_eax!=SYS_PUTCH && scall_eax!=SYS_IDLE)
	{
		sprintf(str, "SYSCALL%d: ebx=%x, ecx=%x, edx=%x, esi=%x, edi=%x, ebp=%x\n",
			scall_eax,
			scall_ebx, scall_ecx, scall_edx,
			scall_esi, scall_edi, scall_ebp);
		WriteSystemLog(str);
	}
}

// Called by scall_handler before jumping to
// the service function.
void scallActive(SYSCALLPAR)
{
	int pid=GetCurrentThread();

	/* The gate may be installed before init_threads() has created a valid
	 * task slot. Never index per-thread arrays with an unvalidated PID. */
	if(!valid_pid(pid))
		return;

	if(GetThreadType(pid)&THREAD_TYPE_SYSCALL_TRACE)
		LogThisSystemCall(MYSYSCALLPAR);

	if(thread_scall_active[pid] != 0xFF)
		thread_scall_active[pid]++;
}

//--------------------------------------------------------------------------
// This function is called by scall_handler
// after the system call has been served.
void scallDeactive(void)
{
	int pid=GetCurrentThread();

	if(!valid_pid(pid))
		return;
	if(thread_scall_active[pid])
		thread_scall_active[pid]--;
}

//--------------------------------------------------------------------------
//
// Nothing doer.
//
DWORD scall_nothing(SYSCALLPAR)
{
	//
	return 0;
}

//--------------------------------------------------------------------------
//
// scall_puts(scall #6).
//
// Note: base address is needed because
// we need to translate the application's
// own virtual memory address space to
// memory space that is visible to kernel.
// f.e.:
// - Kernel can see everything.
// (supervising)
//
// - Application can see only itself.
// (restricted)
//
//
DWORD scall_puts(SYSCALLPAR)
{
	DWORD ad;
	char *p;
	int i,l;

	//
	ad = A2K(scall_ebx);
	p = ad;
	l = strlen(p);
	for(i=0; i<l; i++)
		putch(p[i]);
	return 0;
}

//--------------------------------------------------------------------------
// Wait until key is hit and return the key code.
int scall_wgetch(SYSCALLPAR)
{
	//
	return getch();
}

//--------------------------------------------------------------------------
// Input key from current terminal's keyboard buffer
DWORD scall_getch(SYSCALLPAR)
{
	//
	return getch1();
}

//--------------------------------------------------------------------------
//
// scall_putchar(scall #7).
// BL = character to print on screen.
//
// New: Modified for visible_terminal.
//
DWORD scall_putchar(SYSCALLPAR)
{
	int i;
	char *scr;
	char str[10];

	// Print char
	sputch(&screens[thread_terminal[RPID(GetCurrentThread())]], scall_ebx&255);

	//
	return 0;
}

//--------------------------------------------------------------------------
// This system call is used to exit a thread.
// F.e. an application can be ended with this
// function very well.
//
DWORD scall_exit(SYSCALLPAR)
{
	// Terminate the current thread.
	KillThread( GetCurrentThread() );

	// Wait until being looped out.
	while(1) { SwitchToThread(); }

	//
	return 0;
}

//--------------------------------------------------------------------------
//
// Clears screen.
//
DWORD scall_clrscr(SYSCALLPAR)
{
	//
	_clrscr();
	return 0;
}

//--------------------------------------------------------------------------
// scall_getcurdev - get current device
//
// Returns the caller process current device number (DNR).
//
DWORD scall_getcurdev(SYSCALLPAR)
{
	int devnr;

	//
	devnr = GetCurrentDNR();
	return devnr;
}

//--------------------------------------------------------------------------
DWORD scall_getcurdb(SYSCALLPAR)
{
	int db;

	//
	db = GetCurrentDB();
	return db;
}

//--------------------------------------------------------------------------
//
void scall_relaxthread(SYSCALLPAR)
{
	//
	SwitchToThread();
}

//--------------------------------------------------------------------------
//
int scall_gotoxy(SYSCALLPAR)
{
	gotoxy(scall_ebx,scall_ecx);
	return 0;
}

//--------------------------------------------------------------------------
//
DWORD scall_gettickcount(SYSCALLPAR)
{
	return GetTickCount();
}

//--------------------------------------------------------------------------
// scall_getamemsize
//
// This function returns the size of the memory
// allocated for the process use.
// This is only for application processes,
// does not apply to kernel processes.
DWORD scall_getamemsize(SYSCALLPAR)
{
	return thread_memkb[RPID(GetCurrentThread())]*1024;
}

//--------------------------------------------------------------------------
//
DWORD scall_getcurrentthread(SYSCALLPAR)
{
	return GetCurrentThread();
}

//--------------------------------------------------------------------------
//
DWORD scall_getargc(SYSCALLPAR)
{
	int i;
	char *s;

	s=thread_cmdline[RPID(GetCurrentThread())];
	if( !s )return 0;
	if( !isValidString(s) )return 0;

	//
	return CountWords(s);
}

//--------------------------------------------------------------------------
// scall_ebx = which argument
// scall_ecx = pointer to string where to store the answer
void scall_getargv(SYSCALLPAR)
{
	char *s,which;

	//
	which=scall_ebx;
	s = A2K(scall_ecx);

	//
	if( which>scall_getargc(MYSYSCALLPAR) || !scall_getargc(MYSYSCALLPAR) )
	{
		strcpy(s,"");
		return;
	}

	//
	strcpy(s,"");
	strcpyarg(s, thread_cmdline[RPID(GetCurrentThread())], which);
}

//--------------------------------------------------------------------------
// Order init -process to create new task.
DWORD scall_cexec(SYSCALLPAR)
{
	char *s,*s2,*s3,*s4;
	DWORD pid;
	char fname[256];
	int i,*spid;

	//	scall_ebx	(char *)	file name + arguments 
	//	scall_ecx	int		wait until process exits [TRUE/FALSE]
	//	scall_edx	(char *)	work directory
	//	scall_esi	(int *)		pointer to address where to store PID
	//		(if equals to NULL, then ignored)
	//	scall_edi	(int)		terminal ID

	//
	pid = 0;
	s =	A2K(scall_ebx); // string: exe fname&args
	//	scall_ecx = 0 background (return after creation), 1 foreground (wait for exit)
	s2 =	A2K(scall_edx); // work dir
	spid =	scall_esi ? (int *)A2K(scall_esi) : NULL;
	*spid = 0;

	//
	if(isValidString(s) && strlen(s))
	{
		// Cut file name.
		strcpy(fname, s);
		for(i=0; i<strlen(fname); i++)
			if(fname[i]==' ')fname[i]=0;

		// #1 argument =	file name(ends at the first space)
		// #2 argument = 	whole command line
		// s2 =			running path(where the program will run at)
#if JTMOS_MOD_APP_LOADER
		pid = centralprocess_exec(fname, s,  GetCurrentDNR(), GetCurrentDB(),
					s2,
					scall_edi); // terID

		// Store PID
		*spid = pid;
#else
		printk("cexec: application loader module is disabled.\n");
		*spid = 0;
		return -1;
#endif
	}
	else
		// Invalid parameter string(s) detected
		return -2;

	// Creation/load(not found) failed if pid equals zero
	// Return value -1 means error
	if(!pid)
		// No process created
		return -1;

	/* Historical ABI: ECX=0 means background; ECX=1 means foreground.
	 * Do not invert this in libc -- GraOS depends on bgexec() returning as
	 * soon as the child has been created. */
	if(!scall_ecx)
		return 0;

	WaitProcessTerminationInterruptible(pid);
	// Return value 0 means that
	// program terminated like it used to
	return 0;
}

//--------------------------------------------------------------------------
// scall_ebx = PID
DWORD scall_waitprocterm(SYSCALLPAR)
{
	enable();
	WaitProcessTerminationInterruptible(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
// scall_ebx = fname.
// scall_ecx = FFBLK typedef structure.
DWORD scall_findfirst(SYSCALLPAR)
{
    const char *path;
    void *ffblk;

    /* SYS_findfirst is an application-facing syscall.  Both arguments are
     * userspace pointers and must be translated before calling the kernel
     * JTMFS directory-search API.  The historical stub returned 0 for every
     * call, which made userspace shells (SQSH/GraOS) report that every
     * directory was unreadable. */
    path = (const char *)A2K(scall_ebx);
    ffblk = (void *)A2K(scall_ecx);
    if(path == NULL || ffblk == NULL)
        return (DWORD)-1;

    return (DWORD)findfirst(path, ffblk);
}

//--------------------------------------------------------------------------
// scall_ebx = fd.
// scall_ecx = FFBLK typedef structure.
DWORD scall_findnext(SYSCALLPAR)
{
    void *ffblk;

    ffblk = (void *)A2K(scall_ecx);
    if(ffblk == NULL)
        return (DWORD)-1;

    return (DWORD)findnext((int)scall_ebx, ffblk);
}

//--------------------------------------------------------------------------
int scall_textcolor(SYSCALLPAR)
{
	textcolor(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
int scall_textbackground(SYSCALLPAR)
{
	textbackground(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
DWORD scall_inputmouse(SYSCALLPAR)
{
	/* Keep the IRQ-driven path, but opportunistically drain queued PS/2 AUX
	 * bytes as a non-blocking fallback.  This is especially useful under
	 * QEMU/VirtualBox while the slave PIC is transitioning between masks. */
	mouse_poll();

	switch(scall_ebx)
	{
		//
		case 0:
		return mouse.x;
		case 1:
		return mouse.y;
		case 2:
		return mouse.buttons;
		case 3:
		return ps2mouse_irq_count;
		case 4:
		return ps2mouse_byte_count;
		case 5:
		return ps2mouse_packet_count;
		case 6:
		return (DWORD)ps2mouse_stream_status;

		//
		default:
		return 0;
	}
}

//--------------------------------------------------------------------------
int scall_setmouserect(SYSCALLPAR)
{
	long x1=scall_ebx,y1=scall_ecx,x2=scall_edx,y2=scall_esi;

	/* SetMouseRect() describes the coordinate range; it must not leave a
	 * newly-started GUI cursor clipped into the top-left corner.  The old
	 * syscall always teleported the pointer to (x1,y1).  Start at the centre
	 * of the requested rectangle instead; subsequent PS/2 packets update it. */
	mouse_setframe(x1,y1,x2,y2);
	mouse_setposition(x1+(x2-x1)/2,y1+(y2-y1)/2);
	return 0;
}

//--------------------------------------------------------------------------
DWORD scall_vgadrawframe(SYSCALLPAR)
{
    const void *src;

    /* GraOS V23 has one graphics primitive only: present a complete packed
     * 1024x768x32 RGBA frame to the boot32-selected VESA linear framebuffer.
     * Partial VGA aperture/plane writes are deliberately no longer supported. */
    if(scall_ecx != 0 || scall_edx != GRAOS_VESA_FRAME_BYTES)
        return 0;

    src = (const void *)A2K(scall_ebx);
    if(src == NULL)
        return 0;

    /* Keep hardware IRQ latency reasonable during the ~3 MiB copy.  A2K()
     * returns the application's kernel-visible backing address, so the source
     * remains valid while interrupts are enabled. */
    enable();
    return VesaDrawFrame(src, GRAOS_VESA_FRAME_BYTES) ? 1 : 0;
}

//--------------------------------------------------------------------------
DWORD scall_vgawaitretrace(SYSCALLPAR)
{
	//
	vga_waitretrace();
	return 0;
}

//--------------------------------------------------------------------------
// chdir [path]
// EAX   EBX
DWORD scall_chdir(SYSCALLPAR)
{
    char *path;
    int rv;

    path = (char *)A2K(scall_ebx);
    if(path == NULL)
        return (DWORD)-1;

    rv = _chdir(path);
    return rv == 0 ? 0 : (DWORD)-rv;
}

//--------------------------------------------------------------------------
// SYS_mkfs [path]
DWORD scall_mkfs(SYSCALLPAR)
{
    if((int)scall_ebx >= 0 && (int)scall_ebx < 256 && isValidDevice((int)scall_ebx))
        return (DWORD)formatdrive((int)scall_ebx);
    {
        const char *path = (const char *)A2K(scall_ebx);
        if(path == NULL || !isValidString(path) || !strlen(path))
            return (DWORD)-1;
        return (DWORD)mkfs(path);
    }
}

//--------------------------------------------------------------------------
// Rename a file in the caller's current JTMFS device/database context.
// scall_rename: old file name, new file name
DWORD scall_rename(SYSCALLPAR)
{
    const char *oldname = (const char *)A2K(scall_ebx);
    const char *newname = (const char *)A2K(scall_ecx);
    if(oldname == NULL || newname == NULL ||
       !isValidString(oldname) || !isValidString(newname) ||
       !strlen(oldname) || !strlen(newname))
        return (DWORD)-1;
    return (DWORD)jtmfs_RenameFile(GetCurrentDNR(), oldname, newname, GetCurrentDB());
}



//--------------------------------------------------------------------------
// scall_mkdir: directory name, type
DWORD scall_mkdir(SYSCALLPAR)
{
	//
	return mkdir(scall_ebx, scall_ecx);
}

//--------------------------------------------------------------------------
// SYS_remove
// remove [path]
// EAX    EBX
DWORD scall_remove(SYSCALLPAR)
{
    const char *path = (const char *)A2K(scall_ebx);
    if(path == NULL || !isValidString(path) || !strlen(path))
        return (DWORD)-1;
    return (DWORD)unlink(path);
}


//--------------------------------------------------------------------------
// dnr, strbuf*
int scall_getdevicenrbyname(SYSCALLPAR)
{
	char *p;
	p=A2K(scall_ebx);

	//
	if(p && isValidString(p))
	{
		return driver_getdevicenrbyname(p);
	}
	else
	{
		printk("%s: Malformed request to system call\n", __FUNCTION__);
		return 0;
	}
}

//--------------------------------------------------------------------------
// dnr, strbuf*
DWORD scall_getdevicename(SYSCALLPAR)
{
	char *p;

	//
	p=A2K(scall_ecx);

	//
	if(p && isValidString(p))
	{
		driver_getdevicename(scall_ebx, p);
	}
	else
	{
		printk("%s: Malformed request to system call\n", __FUNCTION__);
		return 1;
	}

	//
	return 0;
}

//--------------------------------------------------------------------------
//
DWORD scall_getdate(SYSCALLPAR)
{
	char *p;

	//
	p=A2K(scall_ebx);
	if(p == NULL) return -1;
	rtc_getdate(p);
	return 0;
}

//--------------------------------------------------------------------------
DWORD scall_wherex(SYSCALLPAR)
{
	//
	return wherex();
}

//--------------------------------------------------------------------------
DWORD scall_wherey(SYSCALLPAR)
{
	//
	return wherey();
}

//--------------------------------------------------------------------------
// VGA select plane where to draw and write.
DWORD scall_vgaselectplane(SYSCALLPAR)
{
	// Select VGA plane.
	setwplane(scall_ebx & 3);
	setrplane(scall_ebx & 3);
	return 0;
}

//--------------------------------------------------------------------------
// Get thread priority: pid.
int scall_getthreadpriority(SYSCALLPAR)
{
	//
	return GetThreadPriority(scall_ebx);
}

//--------------------------------------------------------------------------
// Get thread spending: pid.
int scall_getthreadspending(SYSCALLPAR)
{
	//
	return GetThreadSpending(scall_ebx);
}

//--------------------------------------------------------------------------
// Get thread name: pid, name.
int scall_getthreadname(SYSCALLPAR)
{
	char *p;

	//
	p = A2K(scall_ecx);
	return GetThreadName(scall_ebx, p);
}

//--------------------------------------------------------------------------
// Get thread memory usage: pid
int scall_getthreadmemoryusage(SYSCALLPAR)
{
	//
	return GetThreadMemoryUsage(scall_ebx);
}

//--------------------------------------------------------------------------
// Get number of threads
int scall_getthreadcount(SYSCALLPAR)
{
	//
	return GetThreadCount();
}

//--------------------------------------------------------------------------
// Get scheduler CPU/load statistics. EBX=user struct pointer, ECX=struct size.
int scall_getcpustats(SYSCALLPAR)
{
	JTMOS_CPU_STATS *p;

	p = (JTMOS_CPU_STATS *)A2K(scall_ebx);
	return SchedulerGetCpuStats(p, scall_ecx);
}

//--------------------------------------------------------------------------
int scall_getctrl(SYSCALLPAR)
{
	// Only when available to us
	if( thread_terminal[RPID(GetCurrentThread())]==visible_terminal )
		return GetCTRL();
	else
		return 0;
}

//--------------------------------------------------------------------------
int scall_getalt(SYSCALLPAR)
{
	// Only when available to us
	if( thread_terminal[RPID(GetCurrentThread())]==visible_terminal )
		return GetALT();
	else
		return 0;
}

//--------------------------------------------------------------------------
// Enables the caller thread to
// receive messages from other processes.
// (automatically activated nowadays, but still can be manually used...)
int scall_activatemsgbox(SYSCALLPAR)
{
	//
	return ActivateThreadMessageBox(GetCurrentThread());
}

//--------------------------------------------------------------------------
// Send message to a process.
int scall_sendmessage(SYSCALLPAR)
{
	void *p;

	// Get PTR
	p=A2K(scall_ebx);

	// Send message
	return sendMessage(p, scall_ecx);
}

//--------------------------------------------------------------------------
// Receive message.
int scall_receivemessage(SYSCALLPAR)
{
	void *p;

	// Get PTR
	p=A2K(scall_ebx);

	// Receive message
	return receiveMessage(p);
}

//--------------------------------------------------------------------------
// Resolve thread name to a PID.
int scall_getthreadpid(SYSCALLPAR)
{
	void *p;

	// Get PTR
	p=A2K(scall_ebx);

	//
	return GetThreadPID(p);
}

//--------------------------------------------------------------------------
// Give thread a name
// (ONLY allows to identify itself,
//  future modifications will be made,
//  to allow system processes to do
//  identifying itself.)
int scall_identifythread(SYSCALLPAR)
{
	void *p;

	// Get PTR
	p=A2K(scall_ecx);

	// Only allow to modify itself
	if(scall_ebx==GetCurrentThread())
	{
		// Identify
		IdentifyThread(scall_ebx, p);
	}
	else
	{
		//
		printk("%s: Sorry PID%d, I cannot allow you to identify PID%d..\n",
			__FUNCTION__, GetCurrentThread(), scall_ebx);
		// Error
		return 1;
	}

	// Return OK
	return 0;
}

//--------------------------------------------------------------------------
// Return second count
int scall_getseconds(SYSCALLPAR)
{
	//
	return GetSeconds();
}

//--------------------------------------------------------------------------
// Copy a global memory region.
//
//	globalcopy(srcPID,srcPTR, dstPID,dstPTR, length);
//
//	scall_ebx	source PID
//	scall_ecx	source offset
//	scall_edx	destination PID
//	scall_esi	destination offset
//	scall_edi	copy length in bytes
//
int scall_globalcopy(SYSCALLPAR)
{
	BYTE *src,*dst;
	int srcPID,dstPID,len;

	// Get PIDs
	srcPID = scall_ebx;
	dstPID = scall_edx;

	// Get copy length
	len = scall_edi;
	if(len < 0 || len > (16*1024*1024)) return -1;
	if(len == 0) return 0;

	// Get PTRs
	src = _A2K(scall_ecx, srcPID);
	dst = _A2K(scall_esi, dstPID);

	//
	if(dst == NULL || src == NULL || illegal(dst) || illegal(src))
	{
		dprintk("Illegal globalcopy(%x,%x,%d).\n", dst,src,len);
		return -1;
	}

	// Perform copy
	memcpy(dst, src, len);

	//
	return 0;
}

//--------------------------------------------------------------------------
//
int scall_getthreadterminal(SYSCALLPAR)
{
	//
	return GetThreadTerminal(scall_ebx);
}

//--------------------------------------------------------------------------
//
int scall_setthreadterminal(SYSCALLPAR)
{
	//
	SetThreadTerminal(scall_ebx, scall_ecx);
	return 0;
}

//--------------------------------------------------------------------------
// Create a new terminal.
int scall_newterminal(SYSCALLPAR)
{
	// Returns terminal ID
	return NewTerminal();
}

//--------------------------------------------------------------------------
// Send a byte to terminal's keyboard buffer.
int scall_outputterminalkeyboardbuffer(SYSCALLPAR)
{
	if(scall_ebx<0 || scall_ebx>=N_MAX_SCREENS) return -1;
	return OutputTerminalKeyboardBuffer(&screens[scall_ebx], scall_ecx);
}

//--------------------------------------------------------------------------
// Send a byte to terminal's keyboard buffer
int scall_inputterminalkeyboardbuffer(SYSCALLPAR)
{
	if(scall_ebx<0 || scall_ebx>=N_MAX_SCREENS) return -1;
	return InputTerminalKeyboardBuffer(&screens[scall_ebx]);
}

//--------------------------------------------------------------------------
// Copy specified terminal to a buffer.
int scall_copyterminal(SYSCALLPAR)
{
	BYTE *p;
	int ter;

	// Get parameters
	ter = scall_ebx;
	if(ter<0 || ter>=N_MAX_SCREENS || scall_ecx==0) return -1;
	if(screens[ter].isFree || screens[ter].buf==NULL) return -1;
	p = A2K(scall_ecx);
	if(p==NULL) return -1;

	// Copy
	memcpy(p, screens[ter].buf,
		screens[ter].width*screens[ter].height*2);

	//
	return 0;
}

//--------------------------------------------------------------------------
// Terminate a process
int scall_killthread(SYSCALLPAR)
{
	//
	KillThread(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
// Get cursor location in specified terminal.
int scall_getcursorlocation(SYSCALLPAR)
{
	if(scall_ebx<0 || scall_ebx>=N_MAX_SCREENS) return -1;
	return GetCursorLocation(scall_ebx);
}

//--------------------------------------------------------------------------
// Set interrupt handler.
int scall_setint(SYSCALLPAR)
{
	return addInterruptHandler(scall_ebx,
		(void*)scall_ecx, scall_edx, scall_esi);
}

//--------------------------------------------------------------------------
// Enable IRQ #.
int scall_enableirq(SYSCALLPAR)
{
	/* The legacy ABI is retained, but garbage IRQ values must not reach the PIC. */
	if(scall_ebx < 0 || scall_ebx > 15) return -1;
	enable_irq((unsigned short)scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
//
int scall_diskchange(SYSCALLPAR)
{
	//
	diskchangednr(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
// Converts real PID ID (linear PID) to unique PID.
// Unique PIDs(UNIPIDs) are used to fix many issues.
// These UNIPIDs prevent same process IDs getting
// used too often, in fact quite rarely.
int scall_getthreaduniquepid(SYSCALLPAR)
{
	//
	return GetThreadUniquePID(scall_ebx);
}

//--------------------------------------------------------------------------
// Register a new device.
int scall_registernewdevice(SYSCALLPAR)
{
	//
	return driver_register_new_deviceEx(A2K(scall_ebx),
			scall_ecx, scall_edx,
			scall_esi,
			scall_edi,
			scall_ebp);
	// int driver_register_new_deviceEx(const char *device_name,
	//                                void *device_call, int CS,
	//                                int pid,
	//                                WORD type,
	//                                int Alias)
}

//--------------------------------------------------------------------------
// Switch to specified thread.
int scall_switchtothreadex(SYSCALLPAR)
{
	//
	SwitchToThreadEx(scall_ebx);

	//
	return 0;
}

//--------------------------------------------------------------------------
// Create a new terminal.
int scall_createterminal(SYSCALLPAR)
{
	int terID;

	terID = NewTerminal();
	if(terID < 0)
		return -1;
	if(SetTerminalOwner(terID, GetCurrentThread()) < 0)
	{
		FreeTerminal(terID);
		return -1;
	}
	return terID;
}

//--------------------------------------------------------------------------
// Set terminal owner.
int scall_setterminalowner(SYSCALLPAR)
{
	//
	return SetTerminalOwner(scall_ebx, scall_ecx);
}

//--------------------------------------------------------------------------
// Createa a new terminal.
int scall_getterminalowner(SYSCALLPAR)
{
	//
	return GetTerminalOwner(scall_ebx);
}

//--------------------------------------------------------------------------
//
int scall_serialget(SYSCALLPAR)
{
	//
	return serial_get(scall_ebx);
}

//--------------------------------------------------------------------------
//
int scall_serialput(SYSCALLPAR)
{
	//
	return serial_put(scall_ebx, scall_ecx);
}

//--------------------------------------------------------------------------
//
int scall_setserialportspeed(SYSCALLPAR)
{
	//
	return SetSerialPortSpeedOwned(scall_ebx, scall_ecx, SERIAL_OWNER_NONE);
}

//
/*int device_call(long device_nr,
                long n_function,
                long v1,long v2,long v3,long v4,
                void *p1,void *p2)
*/

//--------------------------------------------------------------------------
// Receive raw packet.
int scall_receiverawpacket(SYSCALLPAR)
{
	// scall_ebx	device number
	// scall_ecx	PTR to packet buffer

	//
	return device_call(scall_ebx, // device number
		DEVICE_CMD_RECEIVERAWPACKET, // receive raw packet
		0,0,0,0,
		A2K(scall_ecx),NULL); // PTR to packet buffer.
}

//--------------------------------------------------------------------------
// Transmit raw packet
int scall_transmitrawpacket(SYSCALLPAR)
{
	// scall_ebx	device number
	// scall_ecx	PTR to packet buffer
	// scall_edx	packet length in bytes

	//
	return device_call(scall_ebx, // device number
		DEVICE_CMD_TRANSMITRAWPACKET, // receive raw packet
		scall_edx,0,0,0, // packet length
		A2K(scall_ecx),NULL); // PTR to packet buffer
		
		
}

//--------------------------------------------------------------------------
// Generic device call compatibility syscall.
int scall_devicecall(SYSCALLPAR)
{
    DCPACKET *userp;
    DCPACKET p;
    int dnr;

    dnr = (int)scall_ebx;
    userp = (DCPACKET *)A2K(scall_ecx);
    if(userp == NULL || illegal(userp))
        return -1;
    if(!isValidDevice(dnr))
        return -1;

    /* Copy the packet first, then translate its nested application pointers.
     * Passing raw p1/p2 values to a kernel driver was unsafe for ring-3 apps. */
    memcpy(&p, userp, sizeof(p));
    if(p.n_function <= 0)
        return -1;
    if(p.p1) p.p1 = (void *)A2K((DWORD)p.p1);
    if(p.p2) p.p2 = (void *)A2K((DWORD)p.p2);
    if(p.done) p.done = (int *)A2K((DWORD)p.done);
    if(p.rval) p.rval = (int *)A2K((DWORD)p.rval);

    return device_call(dnr, p.n_function,
                       p.par1,p.par2,p.par3,p.par4,
                       p.p1,p.p2);
}

//--------------------------------------------------------------------------
// Sleep specified amount of 1/100 seconds
int scall_milsleep(SYSCALLPAR)
{
	//
	MilSleep(scall_ebx);

	//
	return 0;
}

//--------------------------------------------------------------------------
// POSIX-style microsecond sleep.  EBX = useconds_t duration.
int scall_usleep(SYSCALLPAR)
{
	return UsecSleep(scall_ebx);
}

//--------------------------------------------------------------------------
//
int GetTCPIPStackDNR(void)
{
	int dnr;

	//
	dnr = driver_getdevicenrbyname("network");
	return dnr;
}

//--------------------------------------------------------------------------
// Open socket.
int scall_opensocket(SYSCALLPAR)
{
	int rv;

	// scall_ebx	32-bit IP address
	// scall_ecx	port address

	//
	rv = device_call(GetTCPIPStackDNR(), // device number
		DEVICE_CMD_OPENSOCKET,
		scall_ebx,scall_ecx,0,0,
		NULL,NULL);

	//
	return rv;
}

//--------------------------------------------------------------------------
// Close socket.
int scall_closesocket(SYSCALLPAR)
{
	int rv;

	// scall_ebx	socket handle (int)

	//
	rv = device_call(GetTCPIPStackDNR(), // device number
		DEVICE_CMD_CLOSESOCKET,
		scall_ebx,0,0,0,
		NULL,NULL);

	//
	return rv;
}

//--------------------------------------------------------------------------
// Read socket.
int scall_readsocket(SYSCALLPAR)
{
	int rv;

	// scall_ebx	socket handle
	// scall_ecx	PTR to buffer

	//
	rv = device_call(GetTCPIPStackDNR(), // device number
		DEVICE_CMD_READSOCKET,
		scall_ebx,A2K(scall_ecx),0,0,
		NULL,NULL);

	//
	return rv;
}

//--------------------------------------------------------------------------
// Write socket.
int scall_writesocket(SYSCALLPAR)
{
	int rv;

	// scall_ebx	socket handle
	// scall_ecx	PTR to buffer
	// scall_edx	number of bytes

	//
	rv = device_call(GetTCPIPStackDNR(), // device number
		DEVICE_CMD_WRITESOCKET,
		scall_ebx,scall_edx,0,0,
		A2K(scall_ecx),NULL);

	//
	return rv;
}

//--------------------------------------------------------------------------
// Schedule.
int scall_switchtothread(SYSCALLPAR)
{
	SwitchToThread();
	return 0;
}

//--------------------------------------------------------------------------
// Get current work directory path.
// Arguments: [getcwd] [string]
int scall_getcwd(SYSCALLPAR)
{
    char *buf;
    int max_len;
    int rv;

    buf = (char *)A2K(scall_ebx);
    max_len = (int)scall_ecx;
    if(buf == NULL || max_len <= 0)
        return -1;

    rv = getcwd(buf, max_len);
    return rv == 0 ? 0 : -rv;
}

//--------------------------------------------------------------------------
void *scall_kmalloc(SYSCALLPAR)
{
	return malloc(scall_ebx);
}

//--------------------------------------------------------------------------
int scall_kfree(SYSCALLPAR)
{
	if(scall_ebx)
		free((void *)scall_ebx);
	return 0;
}


//--------------------------------------------------------------------------
// scall_postcmd
//
// New: Modified to transfer execution immediatly
// to postman process so no CPU time is spent
// elsewhere, which might lead into a markable
// inefficiency.
//
int scall_postcmd(SYSCALLPAR)
{
	return 0;
}

//--------------------------------------------------------------------------
// scall_open
//
int scall_open(SYSCALLPAR)
{
	// pathname, flags
	return open(scall_ebx, scall_ecx);
}

//--------------------------------------------------------------------------
// scall_close
//
int scall_close(SYSCALLPAR)
{
	// file descriptor
	return close(scall_ebx);
}

//
int scall_read(SYSCALLPAR)
{
	// pathname, flags
	return read(scall_ebx, scall_ecx, scall_edx);
}

//--------------------------------------------------------------------------
// scall_close
//
int scall_write(SYSCALLPAR)
{
	// file descriptor
	return write(scall_ebx, scall_ecx, scall_edx);
}

//--------------------------------------------------------------------------
// scall_fnctl
//
int scall_fnctl(SYSCALLPAR)
{
	// file descriptor
	//return fnctl(scall_ebx);
	return 0;
}

//--------------------------------------------------------------------------
// scall_fnctl
//
int scall_lseek(SYSCALLPAR)
{
	// fd, offset, whence
	return lseek(scall_ebx,scall_ecx,scall_edx);
}

//--------------------------------------------------------------------------
// scall_stat
//       int stat(const char *pathname, struct stat *buf);
//       int fstat(int fd, struct stat *buf);
//       int lstat(const char *pathname, struct stat *buf);
//
int scall_stat(SYSCALLPAR)
{
	// pathname, buf
	return stat(scall_ebx, scall_ecx);
}

//--------------------------------------------------------------------------
// scall_fstat
//       int stat(const char *pathname, struct stat *buf);
//       int fstat(int fd, struct stat *buf);
//       int lstat(const char *pathname, struct stat *buf);
//
int scall_fstat(SYSCALLPAR)
{
	// fd, buf
	return fstat(scall_ebx, scall_ecx);
}

//--------------------------------------------------------------------------
// scall_lstat
//       int stat(const char *pathname, struct stat *buf);
//       int fstat(int fd, struct stat *buf);
//       int lstat(const char *pathname, struct stat *buf);
//
int scall_lstat(SYSCALLPAR)
{
	// pathname, buf
	return lstat(scall_ebx, scall_ecx);
}
