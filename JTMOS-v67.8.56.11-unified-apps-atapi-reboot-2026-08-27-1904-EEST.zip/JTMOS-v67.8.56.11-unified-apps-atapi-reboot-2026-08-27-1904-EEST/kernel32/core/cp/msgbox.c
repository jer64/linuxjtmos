//========================================================
// IPC: Inter Process Communication: Message Box Communication System
// (Process to Process Communication System, PPCS).
// (C) 2003-2005,2013-2014 by Jari Tuominen.
//========================================================
#include "kernel32.h"
#include "msgbox.h"

//
#define X(x) (((x)&255) | ((x)&255<<8) | ((x)&255<<16) | ((x)&255<<24))

//
static DWORD unique_number=0;

//
static DWORD un(void)
{
	return unique_number++;
}

/* IEEE CRC32 over the complete fixed-size packet.  The checksum slot itself
 * is treated as zero, so every header field and all payload bytes are covered
 * without changing the public MSG ABI. */
DWORD MessageChecksum(const MSG *msg)
{
	DWORD crc=0xFFFFFFFFUL ^ MSGBOX_CHECKSUM_SEED;
	DWORD i,j;
	const BYTE *p=(const BYTE *)msg;
	DWORD checksum_offset=(DWORD)&((MSG *)0)->magic2;

	if(msg==NULL)
		return 0;
	for(i=0; i<sizeof(MSG); ++i)
	{
		BYTE value=(i>=checksum_offset && i<checksum_offset+sizeof(DWORD)) ? 0 : p[i];
		crc^=value;
		for(j=0; j<8; ++j)
			crc=(crc>>1) ^ (0xEDB88320UL & (0UL-(crc&1UL)));
	}
	return crc ^ 0xFFFFFFFFUL;
}

//-------------------------------------------------------------------------------------
// Activate a thread's message box
//
int ActivateThreadMessageBox(int pid)
{
        // Check that the process really exists
        if(!valid_pid(pid)) return 1;

	// Does the thread already have an existing message box?
	if(thread_msgbox[pid]==NULL)
	{
		// Create a new message box:
		thread_msgbox[pid] = createMessageBox();
		if(thread_msgbox[pid]==NULL)
			return 1;
	}
	return 0;
}

//-------------------------------------------------------------------------------------
//
int VerifyMessage(MSG *msg)
{
	if(msg==NULL || msg->magic1!=MSGBOX_MAGIC1)
		return 0;
	if(msg->isFree!=MSG_RESERVED)
		return 0;
	if(msg->amount<0 || msg->amount>N_MAX_BYTES_PER_MSG)
		return 0;
	if(msg->protocol!=MB_PROTOCOL_DC &&
	   msg->protocol!=MB_PROTOCOL_POSTMAN &&
	   msg->protocol!=MB_PROTOCOL_GRAOS)
		return 0;
	return msg->magic2==MessageChecksum(msg);
}

//-------------------------------------------------------------------------------------
// Return value:
// 0 = Message delivered
// 1 = Message couldn't have been delivered
//
int sendMessage(MSG *deliver_this, int pid)
{
	int i,i2;
	MSGBOX *mb;
	MSG *me;
	MSG packet;
	DWORD ad;
	DCPACKET *dc;
	static char str[256];

	//
	printf("%s/%s/line %d: deliver_this=%x, pid=%d\n",
		__FILE__, __FUNCTION__, __LINE__, pid);
	if(!pid) {
		printf("%s/%s/line %d: pid is zero (%d), can't deliver\n",
			__FILE__, __FUNCTION__, __LINE__, pid);
		return 1;
	}

	//-----------------------------------------------------------
        // Check that the process really exists.
        if(!valid_pid(pid)) {
		printf("%s/%s/line %d: process (%d) does not exist, can't deliver\n",
			__FILE__, __FUNCTION__, __LINE__, pid);
		return 1;
	}

	// Check for NULL pointer
	if( illegal(deliver_this) )
	{
		//
		printf("%s/%s: deliver_this = ILLEGAL POINTER\n",
			__FILE__, __FUNCTION__);
		// Hey it's an illegal ptr!
		return 1;
	}

	/* Snapshot once before inspecting nested fields.  A Ring3 sender cannot
	 * change protocol/payload between validation and mailbox insertion. */
	memcpy(&packet,deliver_this,sizeof(packet));
	if(packet.amount<0 || packet.amount>N_MAX_BYTES_PER_MSG)
		return 14;

	//-----------------------------------------------------------
repeat:
	// Thread must have an active message box
	if( (mb=thread_msgbox[pid])==NULL )
	{
		//
		printf("%s/%s: thread_msgbox[%d] is NULL\n",
			__FILE__, __FUNCTION__, pid);
		// Thread has no message box!
		// Let's create one for it.
		if(ActivateThreadMessageBox(pid))
			return 1;
		goto repeat;
	}

	//--------------------------------------------------------------------
	// Make sure all required pointers in the MSG structure are valid.
	//

	// Verify a DC packet.
	switch(packet.protocol)
	{
		//
		case MB_PROTOCOL_DC:
		if(packet.amount<(int)sizeof(DCPACKET))
			return 15;
		dc = (DCPACKET *)&packet.buf;
		ad = dc->rval; ad += GetCurrentThread();

		//
		if(illegal(ad))
		{
			dprintk("%s: rejecting illegal DC packet from PID%d.\n",
				__FUNCTION__,GetCurrentThread());
			return 11;
		}
		break;

		//
		case MB_PROTOCOL_POSTMAN:
		break;
		case MB_PROTOCOL_GRAOS:
		break;

		//
		default:
	/**	sprintf(str, "%s/%s: Packet with unknown protocol (%d).",
			__FILE__, __FUNCTION__,
			deliver_this->protocol); **/
		printk("\n");
		p32(packet.protocol); printk("\n");
		printk("%s/%s line %d: msgbox unknown protocol value in deliver_this->protocol\n",
			__FUNCTION__,__FILE__,__LINE__);
		return 10;
	}

	//-----------------------------------------------------------
	// Set "to be sent" -message as reserved.
	packet.isFree = MSG_RESERVED;

	// Define sender's and receiver's PID
	packet.sndPID = GetCurrentThread();
	packet.rcvPID = pid;

	// Set magic numbers.
	packet.magic1 = MSGBOX_MAGIC1;

	// Define unique number
	packet.un = un();
	packet.magic2 = 0;
	packet.magic2 = MessageChecksum(&packet);

	//
	if(!VerifyMessage(&packet))
	{
		dprintk("%s: outgoing message validation failed.\n",__FUNCTION__);
		return 12;
	}

	//------------------------------------------------------------------------
repeatSearch:
	// Search for EMPTY LOCKER to drop it at.
	//
	for(i=0,me=NULL; i<mb->n_q; i++)
	{
retry:
		//
		me = &mb->q[i];

		// Found a free message entry?
		if( me->isFree==MSG_FREE )
		{
			// We got a free entry:

			// Deliver message
			memcpy(me, &packet, sizeof(MSG));

			//
			if(!VerifyMessage(me))
			{
				dprintk("%s: copied message validation failed; dropping entry.\n",__FUNCTION__);
				memset(me,0,sizeof(MSG));
				me->isFree=MSG_FREE;
				return 13;
			}

			// Message posted successfully.
			return 0;
		}
	}

	//------------------------------------------------------------------------
	return 1;
}

// A thread can receive own messages
// through this function.
//
// Return value:
// Non-zero	message was received successfully
// Zero		no new messages available
//
int receiveMessage(MSG *user_packet_buffer)
{
	DWORD age;
	int i,i2,ind;
	MSGBOX *mailbox;
	MSG *message,*got;
	
	// Check pointer
	if(user_packet_buffer==NULL)
		return 0;

repeat:
	// Get box PTR.
	mailbox = thread_msgbox[GetCurrentThread()];
	if(mailbox==NULL)
	{
		// We have no message box!
		// So, let's create one.
		if(ActivateThreadMessageBox(GetCurrentThread()))
			return 0;
		goto repeat;
	}

	// Search for [oldest] arrived message in the message box.
	for(i=0,age=0xFFFFFFFF,got=NULL; i<mailbox->n_q; i++)
	{
		//
		message = &mailbox->q[i];

		// Got [older] message?
		if(message->isFree==MSG_RESERVED && message->un<=age)
		{
			if(VerifyMessage(message) &&
			   message->rcvPID==GetCurrentThread())
			{
				//
				got = message;
				age = message->un; // un = packet number
				ind = i;
			}
			else
			{
				// Wrong magic number(s)!
				// Free the packet, it's spoiled.
				printk("%s: Flushing corrupted packet #%d (magic=%x checksum=%x expected=%x).\n",
					__FUNCTION__, i,
					message->magic1, message->magic2,
					MessageChecksum(message));
				message->isFree = MSG_FREE;
			}
		}
	}

	// If we eventually found a message ...
	if(got!=NULL)
	{
		// Got a message:
		// --------------

	//	printk("%s: ind=%d, packet number=%d\n", 
	//		__FUNCTION__, ind, age);

		// Copy message
		memcpy(user_packet_buffer, got, sizeof(MSG));

		// Flag it as received
		got->isFree = MSG_FREE;

		// Got message, return:
		return 1;
	}

	// No new message found
	return 0;
}

// Initialize a message box
void initMessageBox(MSGBOX *queue)
{
	int i;

	//
	memset(queue, 0x66, sizeof(MSGBOX));

	//
	queue->n_q = N_MAX_QUEUED_MSGS;

	//
	for(i=0; i<queue->n_q; i++)
		queue->q[i].isFree = MSG_FREE;
}

// Create a new message box
MSGBOX *createMessageBox(void)
{
	MSGBOX *box;

	// Allocate a message box
	box = malloc(sizeof(MSGBOX));
	if(box==NULL)
		return NULL;

	// Initialize message box
	initMessageBox(box);

	// Return PTR to the new message box
	return box;
}

//
