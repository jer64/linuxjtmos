/****************************************
 * reboot.c - System Reboot Functions
 * (C) 1999-2026 by Jari Tuominen
 ****************************************/
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "driver_sys.h"
#include "driver_flush.h"
#include "threads.h"
#include "pit.h"
#include "statusline.h"
#include "panic.h"
#include "reboot.h"

volatile int rebootCommenced=0;

/* Immediate, non-returning reset.  TripleFault() is implemented in aslib.asm
 * by loading a zero-length IDT and deliberately raising an exception.  No
 * attempt is made to leave protected mode, touch paging, or re-enable IRQs. */
__attribute__((noreturn)) void system_reset1(void)
{
    disable();
    TripleFault();

    /* TripleFault must not return.  Keep a hard stop here for unusual emulators
     * or broken CPUs rather than continuing with a destroyed IDT. */
    for(;;)
        __asm__ __volatile__("cli; hlt");
}

__attribute__((noreturn)) void SystemReboot(void)
{
    system_reset();
}

/* Graceful reboot: stop new activity, flush filesystem/device caches, ask
 * drivers to shut down, and only then execute the guaranteed triple fault. */
__attribute__((noreturn)) void system_reset(void)
{
    if(rebootCommenced)
        system_reset1();

    rebootCommenced=TRUE;

#if JTMOS_MOD_STATUSLINE
    statusline_terminate=1;
#endif

    /* Keep IRQs available while filesystem and driver flush paths may need
     * hardware completion interrupts. */
    enable();

    printk("\nJTMOS: preparing safe reboot.\n");
    printk("JTMOS: synchronizing filesystem caches ... ");
    if(sync()!=0)
        printk("warning\n");
    else
        printk("OK\n");

    /* The first sync is allowed to sleep/yield.  Once it completes, atomically
     * switch IRQ0 to the tick-only storage handler and stop TSS scheduling.
     * A second sync inside driver_TriggerCacheFlush() then runs with no other
     * process able to dirty filesystem state underneath the reboot path. */
    disable();
    PitStorageSafeBegin();
    enable();

    printk("JTMOS: scheduler quiesced; flushing block-device caches ...\n");
    driver_TriggerCacheFlush();

    printk("JTMOS: shutting down devices ... ");
    if(driver_ShutdownAllDevices()!=0)
        printk("warning\n");
    else
        printk("OK\n");

    DebugSerialWrite("[RESET] caches flushed, devices stopped; forcing triple fault.\n");
    disable();
    system_reset1();
}
