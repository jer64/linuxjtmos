//--------------------------------------------------------------------------------
// scheduler.c - Main scheduler.
// (C) 2004-2005 by Jari Tuominen(jari@vunet.org).
//
// A TSS based task switching system.
// See threadSwitch.c for the switching logic.
//--------------------------------------------------------------------------------
#include "kernel32.h"
#include "system_call.h" // scallsIsWorking
#include "scheduler.h"

/*
 * Fixed-point scheduler accounting.
 *
 * Load averages are sampled once per second and use the same exponential
 * time constants as the familiar Unix/Linux 1/5/15 minute load averages.
 * The internal representation is Q16.  A 64-bit intermediate is used only for
 * the multiply; i386 GCC emits ordinary integer instructions for this path and
 * no floating-point state is touched by the scheduler.
 */
#define LOAD_A_BETA_Q16 1083U   /* 1 - exp(-1/60)  */
#define LOAD_B_BETA_Q16  218U   /* 1 - exp(-1/300) */
#define LOAD_C_BETA_Q16   73U   /* 1 - exp(-1/900) */

static volatile DWORD cpu_sample_ticks=0;
static volatile DWORD cpu_sample_idle_ticks=0;
static volatile DWORD cpu_idle_per_mille=0;
static volatile DWORD cpu_busy_per_mille=0;
static volatile DWORD load_a_q16=0;
static volatile DWORD load_b_q16=0;
static volatile DWORD load_c_q16=0;
static volatile DWORD cpu_last_sample_ticks=0;
static volatile DWORD cpu_last_sample_idle_ticks=0;

/* Deadline sleeps are scheduler state, not polling loops. */
static volatile DWORD scheduler_sleep_start[N_MAX_THREADS];
static volatile DWORD scheduler_sleep_duration[N_MAX_THREADS];
static int scheduler_thread_sleeping(int pid);

static int scheduler_idle_slot(void)
{
    int idle;

    /* IdleThread is a zero-initialized global before init_IdleThread().
     * Do not accidentally treat bootstrap PID 0 as idle during early PIT
     * ticks just because PID 0 is also zero. */
    if(!IdleThread.pid || nr_threads <= 0)
        return -1;

    idle = IdleThread.pid;
    if(idle < 0 || idle >= nr_threads || !thread_states[idle])
        return -1;
    return idle;
}

static DWORD scheduler_count_threads(int runnable_only)
{
    int i;
    int idle;
    DWORD n=0;

    idle = scheduler_idle_slot();
    for(i=0; i<nr_threads; i++)
    {
        if(!thread_states[i])
            continue;
        if(i == idle)
            continue;
        if(runnable_only && (thread_idling[i] || scheduler_thread_sleeping(i)))
            continue;
        n++;
    }
    return n;
}

static DWORD scheduler_load_step(DWORD old_q16, DWORD active, DWORD beta_q16)
{
    long target;
    long delta;
    long step;
    long long product;

    if(active > N_MAX_THREADS)
        active = N_MAX_THREADS;

    target = (long)(active << 16);
    delta = target - (long)old_q16;
    product = (long long)delta * (long long)beta_q16;
    step = (long)(product >> 16);

    if((long)old_q16 + step < 0)
        return 0;
    return (DWORD)((long)old_q16 + step);
}

void SchedulerCpuTick(void)
{
    DWORD hz;
    DWORD runnable;
    int idle;

    cpu_sample_ticks++;
    idle = scheduler_idle_slot();
    if(idle >= 0 && nr_curthread == idle)
        cpu_sample_idle_ticks++;

    if(!pit || !pit->secondInTicks)
        return;

    hz = pit->secondInTicks;
    if(cpu_sample_ticks < hz)
        return;

    cpu_last_sample_ticks = cpu_sample_ticks;
    cpu_last_sample_idle_ticks = cpu_sample_idle_ticks;

    if(cpu_sample_ticks)
    {
        cpu_idle_per_mille = (cpu_sample_idle_ticks * 1000U) / cpu_sample_ticks;
        if(cpu_idle_per_mille > 1000U)
            cpu_idle_per_mille = 1000U;
        cpu_busy_per_mille = 1000U - cpu_idle_per_mille;
    }

    runnable = scheduler_count_threads(TRUE);
    load_a_q16 = scheduler_load_step(load_a_q16, runnable, LOAD_A_BETA_Q16);
    load_b_q16 = scheduler_load_step(load_b_q16, runnable, LOAD_B_BETA_Q16);
    load_c_q16 = scheduler_load_step(load_c_q16, runnable, LOAD_C_BETA_Q16);

    cpu_sample_ticks = 0;
    cpu_sample_idle_ticks = 0;
}

int SchedulerGetCpuStats(JTMOS_CPU_STATS *out, DWORD out_size)
{
    JTMOS_CPU_STATS s;
    DWORD copy_size;

    if(!out || out_size == 0)
        return -1;

    memset(&s, 0, sizeof(s));
    s.version = JTMOS_CPU_STATS_VERSION;
    s.size = sizeof(s);
    s.hz = (pit && pit->secondInTicks) ? pit->secondInTicks : 0;
    s.total_threads = scheduler_count_threads(FALSE);
    if(scheduler_idle_slot() >= 0)
        s.total_threads++; /* report CPU_IDLE too, like the process table does */
    s.runnable_threads = scheduler_count_threads(TRUE);
    s.idle_pid = (scheduler_idle_slot() >= 0) ? IdleThread.pid : 0;
    s.cpu_idle_per_mille = cpu_idle_per_mille;
    s.cpu_busy_per_mille = cpu_busy_per_mille;
    s.load_a_x1000 = (load_a_q16 >> 16) * 1000U + (((load_a_q16 & 0xffffU) * 1000U) >> 16);
    s.load_b_x1000 = (load_b_q16 >> 16) * 1000U + (((load_b_q16 & 0xffffU) * 1000U) >> 16);
    s.load_c_x1000 = (load_c_q16 >> 16) * 1000U + (((load_c_q16 & 0xffffU) * 1000U) >> 16);
    s.sample_ticks = cpu_last_sample_ticks;
    s.sample_idle_ticks = cpu_last_sample_idle_ticks;
    s.uptime_ms = GetTickCount();

    copy_size = out_size;
    if(copy_size > sizeof(s))
        copy_size = sizeof(s);
    memcpy(out, &s, copy_size);
    return 0;
}

/* -------------------------------------------------------------------------
 * V67.8.54 responsive reward scheduler (RRS)
 *
 * The old JTMOS scheduler switched tasks on every PIT interrupt.  At the old
 * 0x100 divisor that meant about 4661 hardware task-switch opportunities per
 * second: only ~214 us of useful execution between IRQ0 entries.  RRS keeps
 * PIT as a time source but gives each task a real multi-tick quantum.
 *
 * Policy:
 *   level 0  interactive       short latency, short quantum
 *   level 1  normal            default
 *   level 2  background        lower dispatch preference, longer quantum
 *   level 3  batch             lowest preference, longest quantum
 *
 * A task that voluntarily yields early or completes block I/O is promoted
 * (bounded by its explicit base priority).  A task that consumes a complete
 * quantum is demoted.  Runnable waiters accrue aging credit, so even a batch
 * task cannot starve behind permanently interactive work.
 */
#define SCHED_LEVELS                 4
#define SCHED_LEVEL_INTERACTIVE      0
#define SCHED_LEVEL_NORMAL           1
#define SCHED_LEVEL_BACKGROUND       2
#define SCHED_LEVEL_BATCH            3
#define SCHED_AGE_WINDOWS_MAX        3

static const BYTE scheduler_quantum_ticks[SCHED_LEVELS] = { 3, 4, 6, 10 };
static BYTE scheduler_initialized[N_MAX_THREADS];
static BYTE scheduler_level[N_MAX_THREADS];
static BYTE scheduler_quantum_left[N_MAX_THREADS];
static BYTE scheduler_run_ticks[N_MAX_THREADS];
static BYTE scheduler_empty_yield_streak[N_MAX_THREADS];
static WORD scheduler_wait_ticks[N_MAX_THREADS];
static volatile DWORD scheduler_context_switches=0;
static volatile DWORD scheduler_preemptions=0;
static volatile DWORD scheduler_voluntary_yields=0;
static volatile DWORD scheduler_promotions=0;
static volatile DWORD scheduler_demotions=0;
static volatile DWORD scheduler_io_rewards=0;
static volatile DWORD scheduler_empty_yields=0;

static BYTE scheduler_priority_floor(BYTE prio)
{
    if(prio<=THREAD_PRIORITY_NORMAL) return SCHED_LEVEL_INTERACTIVE;
    if(prio<=THREAD_PRIORITY_BELOW_NORMAL) return SCHED_LEVEL_NORMAL;
    if(prio<=THREAD_PRIORITY_IDLE) return SCHED_LEVEL_BACKGROUND;
    return SCHED_LEVEL_BATCH;
}

static BYTE scheduler_initial_level(BYTE prio)
{
    BYTE floor=scheduler_priority_floor(prio);
    if(floor<SCHED_LEVEL_BATCH) return (BYTE)(floor+1);
    return SCHED_LEVEL_BATCH;
}

static DWORD scheduler_age_window_ticks(void)
{
    DWORD hz=(pit && pit->secondInTicks) ? pit->secondInTicks : 1000U;
    DWORD ticks=hz/25U; /* about 40 ms */
    if(ticks<1U) ticks=1U;
    if(ticks>0xffffU) ticks=0xffffU;
    return ticks;
}

static int scheduler_thread_sleeping(int pid)
{
    DWORD duration;
    DWORD elapsed;

    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    duration=scheduler_sleep_duration[pid];
    if(!duration) return 0;
    elapsed=(DWORD)(PitGetUsec()-scheduler_sleep_start[pid]);
    if(elapsed>=duration) {
        scheduler_sleep_duration[pid]=0;
        scheduler_sleep_start[pid]=0;
        return 0;
    }
    return 1;
}

static void scheduler_ensure_thread(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return;
    if(scheduler_initialized[pid]) return;
    scheduler_initialized[pid]=1;
    scheduler_level[pid]=scheduler_initial_level(thread_states[pid]);
    scheduler_quantum_left[pid]=0;
    scheduler_run_ticks[pid]=0;
    scheduler_empty_yield_streak[pid]=0;
    scheduler_wait_ticks[pid]=0;
}

static BYTE scheduler_effective_level(int pid)
{
    DWORD win;
    DWORD boost;
    BYTE level;

    scheduler_ensure_thread(pid);
    level=scheduler_level[pid];
    win=scheduler_age_window_ticks();
    boost=(win ? ((DWORD)scheduler_wait_ticks[pid]/win) : 0U);
    if(boost>SCHED_AGE_WINDOWS_MAX) boost=SCHED_AGE_WINDOWS_MAX;
    if(boost>level) boost=level;
    return (BYTE)(level-boost);
}

static int scheduler_runnable_nonidle_exists(void)
{
    int i,idle=scheduler_idle_slot();
    for(i=0;i<nr_threads;i++) {
        if(i==idle) continue;
        if(thread_states[i] && !thread_idling[i] && !scheduler_thread_sleeping(i)) return 1;
    }
    return 0;
}

static int scheduler_more_urgent_waiter(int current)
{
    int i,idle=scheduler_idle_slot();
    BYTE clevel=scheduler_effective_level(current);
    for(i=0;i<nr_threads;i++) {
        if(i==current || i==idle || !thread_states[i] || thread_idling[i] ||
           scheduler_thread_sleeping(i)) continue;
        if(scheduler_wait_ticks[i]<3) continue;
        if(scheduler_effective_level(i)+1U < clevel) return 1;
    }
    return 0;
}

void SchedulerThreadInit(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return;
    scheduler_initialized[pid]=0;
    scheduler_level[pid]=SCHED_LEVEL_NORMAL;
    scheduler_quantum_left[pid]=0;
    scheduler_run_ticks[pid]=0;
    scheduler_empty_yield_streak[pid]=0;
    scheduler_wait_ticks[pid]=0;
    scheduler_sleep_start[pid]=0;
    scheduler_sleep_duration[pid]=0;
    scheduler_ensure_thread(pid);
}

void SchedulerPriorityChanged(int pid, BYTE prio)
{
    BYTE floor;
    if(pid<0 || pid>=N_MAX_THREADS) return;
    if(prio==0) {
        scheduler_initialized[pid]=0;
        scheduler_quantum_left[pid]=0;
        scheduler_run_ticks[pid]=0;
        scheduler_empty_yield_streak[pid]=0;
        scheduler_wait_ticks[pid]=0;
        scheduler_sleep_start[pid]=0;
        scheduler_sleep_duration[pid]=0;
        return;
    }
    scheduler_ensure_thread(pid);
    floor=scheduler_priority_floor(prio);
    scheduler_level[pid]=scheduler_initial_level(prio);
    if(scheduler_level[pid]<floor) scheduler_level[pid]=floor;
    scheduler_quantum_left[pid]=0;
    scheduler_run_ticks[pid]=0;
    scheduler_empty_yield_streak[pid]=0;
}

void SchedulerOnVoluntaryYield(int pid)
{
    BYTE q,left,used,floor;
    int idle=scheduler_idle_slot();
    if(pid<0 || pid>=nr_threads || pid==idle || !thread_states[pid]) return;
    scheduler_ensure_thread(pid);
    scheduler_voluntary_yields++;
    if(scheduler_sleep_duration[pid]) {
        scheduler_quantum_left[pid]=0;
        scheduler_run_ticks[pid]=0;
        return;
    }
    q=scheduler_quantum_ticks[scheduler_level[pid]];
    left=scheduler_quantum_left[pid];
    if(left==0 || left>q) left=q;
    used=(BYTE)(q-left);
    floor=scheduler_priority_floor(thread_states[pid]);

    /* A zero-tick yield loop is not useful interactive work.  Do not let a
     * process game the reward policy by repeatedly calling SwitchToThread()
     * without doing anything between calls.  Four consecutive empty yields
     * move it one latency class toward batch operation. */
    if(used==0) {
        scheduler_empty_yields++;
        if(scheduler_empty_yield_streak[pid]<255)
            scheduler_empty_yield_streak[pid]++;
        if(scheduler_empty_yield_streak[pid]>=4) {
            scheduler_empty_yield_streak[pid]=0;
            if(scheduler_level[pid]<SCHED_LEVEL_BATCH) {
                scheduler_level[pid]++;
                scheduler_demotions++;
            }
        }
    } else {
        scheduler_empty_yield_streak[pid]=0;
        if(used<=(BYTE)(q/2) && scheduler_level[pid]>floor) {
            scheduler_level[pid]--;
            scheduler_promotions++;
        }
    }
    /* A voluntary hand-off ends the current burst.  Start a fresh quantum
     * when this task is dispatched again. */
    scheduler_quantum_left[pid]=0;
    scheduler_run_ticks[pid]=0;
}

void SchedulerRewardIO(int pid, int work_units)
{
    BYTE floor;
    int idle=scheduler_idle_slot();
    if(work_units<=0 || pid<0 || pid>=nr_threads || pid==idle || !thread_states[pid]) return;
    scheduler_ensure_thread(pid);
    scheduler_io_rewards++;
    scheduler_empty_yield_streak[pid]=0;
    floor=scheduler_priority_floor(thread_states[pid]);
    if(scheduler_level[pid]>floor) {
        scheduler_level[pid]--;
        scheduler_promotions++;
    }
}

int SchedulerSleepCurrentUsec(DWORD usec)
{
    int pid;
    BYTE floor;

    if(usec==0) { SwitchToThread(); return 0; }
    if(!Multitasking) return -1;
    pid=nr_curthread;
    if(pid<0 || pid>=nr_threads || !thread_states[pid]) return -1;
    scheduler_ensure_thread(pid);
    scheduler_sleep_start[pid]=PitGetUsec();
    scheduler_sleep_duration[pid]=usec;
    scheduler_empty_yield_streak[pid]=0;

    /* Blocking before the end of a quantum is useful cooperative behaviour. */
    floor=scheduler_priority_floor(thread_states[pid]);
    if(scheduler_level[pid]>floor) {
        scheduler_level[pid]--;
        scheduler_promotions++;
    }
    scheduler_quantum_left[pid]=0;
    scheduler_run_ticks[pid]=0;

    /* The scheduler will not select this PID again until the deadline expires
     * or an explicit SchedulerWakeThread()/SwitchToThreadEx() occurs. */
    while(scheduler_thread_sleeping(pid)) SwitchToThread();
    return 0;
}

void SchedulerWakeThread(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return;
    scheduler_sleep_duration[pid]=0;
    scheduler_sleep_start[pid]=0;
    scheduler_wait_ticks[pid]=0;
}

int SchedulerTimerShouldPreempt(void)
{
    int i,current,idle;
    DWORD agewin,agemax;
    BYTE q;

    if(!Multitasking) return 0;
    current=nr_curthread;
    idle=scheduler_idle_slot();

    agewin=scheduler_age_window_ticks();
    agemax=agewin*SCHED_AGE_WINDOWS_MAX;
    if(agemax>0xffffU) agemax=0xffffU;
    for(i=0;i<nr_threads;i++) {
        if(i==current || i==idle || !thread_states[i] || thread_idling[i] ||
           scheduler_thread_sleeping(i)) continue;
        if((DWORD)scheduler_wait_ticks[i]<agemax) scheduler_wait_ticks[i]++;
    }

    if(current==idle) return scheduler_runnable_nonidle_exists();
    if(current<0 || current>=nr_threads || !thread_states[current]) return 1;
    if(scheduler_thread_sleeping(current)) return 1;

    scheduler_ensure_thread(current);
    q=scheduler_quantum_ticks[scheduler_level[current]];
    if(!scheduler_quantum_left[current]) scheduler_quantum_left[current]=q;
    if(scheduler_quantum_left[current]) scheduler_quantum_left[current]--;
    if(scheduler_run_ticks[current]<255) scheduler_run_ticks[current]++;

    if(!scheduler_quantum_left[current]) {
        if(scheduler_level[current]<SCHED_LEVEL_BATCH) {
            scheduler_level[current]++;
            scheduler_demotions++;
        }
        scheduler_run_ticks[current]=0;
        scheduler_empty_yield_streak[current]=0;
        scheduler_preemptions++;
        return 1;
    }

    /* Do not make a latency-sensitive waiter sit behind a long batch slice.
     * Still allow at least two PIT ticks of useful work before early preempt. */
    if(scheduler_run_ticks[current]>=2 && scheduler_more_urgent_waiter(current)) {
        scheduler_preemptions++;
        return 1;
    }
    return 0;
}

int SchedulerPickNext(int current)
{
    int offset,pid,best=-1,idle;
    BYTE eff,best_eff=0xff;

    idle=scheduler_idle_slot();
    if(nr_threads<=0) return 0;
    for(offset=1;offset<nr_threads;offset++) {
        pid=current+offset;
        while(pid>=nr_threads) pid-=nr_threads;
        if(pid==idle || !thread_states[pid] || scheduler_thread_sleeping(pid)) continue;
        if(thread_idling[pid]) {
            thread_idling[pid]--;
            continue;
        }
        eff=scheduler_effective_level(pid);
        if(best<0 || eff<best_eff) {
            best=pid;
            best_eff=eff;
            if(best_eff==SCHED_LEVEL_INTERACTIVE) {
                /* Keep scanning only for round-robin fairness among equal
                 * level-zero tasks; the first encountered wins ties. */
            }
        }
    }

    if(best<0) {
        if(current>=0 && current<nr_threads && current!=idle &&
           thread_states[current] && !thread_idling[current] &&
           !scheduler_thread_sleeping(current)) best=current;
        else if(idle>=0 && idle<nr_threads && thread_states[idle]) best=idle;
        else if(current>=0 && current<nr_threads && thread_states[current]) best=current;
        else best=0;
    }

    if(best>=0 && best<nr_threads) {
        scheduler_ensure_thread(best);
        scheduler_wait_ticks[best]=0;
        if(best!=idle && !scheduler_quantum_left[best])
            scheduler_quantum_left[best]=scheduler_quantum_ticks[scheduler_level[best]];
    }
    return best;
}

void SchedulerOnSwitch(int old_pid, int new_pid)
{
    if(old_pid!=new_pid) scheduler_context_switches++;
    if(new_pid>=0 && new_pid<nr_threads) scheduler_wait_ticks[new_pid]=0;
}

void SchedulerDump(void)
{
    int i,idle=scheduler_idle_slot();
    printk("RRS scheduler: PIT=%u Hz switches=%u preempt=%u yields=%u empty=%u promote=%u demote=%u io-reward=%u\n",
           (pit&&pit->secondInTicks)?pit->secondInTicks:0,
           (unsigned)scheduler_context_switches,(unsigned)scheduler_preemptions,
           (unsigned)scheduler_voluntary_yields,(unsigned)scheduler_empty_yields,
           (unsigned)scheduler_promotions,(unsigned)scheduler_demotions,
           (unsigned)scheduler_io_rewards);
    printk(" PID base level eff qleft wait cpu name\n");
    for(i=0;i<nr_threads;i++) {
        char name[128];
        if(!thread_states[i]) continue;
        GetThreadName(i,name);
        printk(" %3d %4u %5u %3u %5u %4u %u %s%s%s\n", i,
               (unsigned)thread_states[i],(unsigned)scheduler_level[i],
               (unsigned)scheduler_effective_level(i),
               (unsigned)scheduler_quantum_left[i],(unsigned)scheduler_wait_ticks[i],
               (unsigned)thread_CPUspending[i],name,(i==idle)?" [idle]":"",
               scheduler_thread_sleeping(i)?" [sleep]":"");
    }
}

//--------------------------------------------------------------------------------
// Calls int 0x7E.
//
void _idle_moment(void)
{
	//
	if(scallsIsWorking && Multitasking)
		asm("int $0x7E");
}

//--------------------------------------------------------------------------------
//
// 0x8000 0000 = will have the application memory space, if any.
//
void MapApplicationMemory(void)
{
	DWORD *pd;
	void *process_page_tables;
	int i,i2,i3,i4;
	DWORD ad;

	//
	pd = GetKernelPageDirPTR();
	//
	process_page_tables = (void *)PG_USER_PAGE_TABLES_PHYS;
	process_page_tables += nr_curthread*1024*16; // each process has 16 KB page tables (4x4 = 16)

	//
	for(i=0; i<4; i++,process_page_tables += 1024*4)
	{
		ad = process_page_tables;
	 	pd[512+i] = ad|7; /* present + writable + ring-3 user */
	}
}

//--------------------------------------------------------------------------------
//
static void SchedulerJumpSelected(int old_pid)
{
    TSSEG *ts;
    int sel;

    if(old_pid!=nr_curthread) taskSwitchNr++;
    SchedulerOnSwitch(old_pid,nr_curthread);
    unbusyTSS();
    if(old_pid!=nr_curthread) MapApplicationMemory();
    LOADTR(0x48);
    sel=nr_curthread*8+TSSSEL_OFFS;
    ts=&tasks->tss[nr_curthread];
    (void)ts;
    tss_goto(sel);
}

void LLSchedule(void)
{
    int old_pid=nr_curthread;

    /* INT 0x7E is a voluntary yield.  Reward a short burst, then choose a
     * peer immediately instead of waiting for the hardware quantum. */
    SchedulerOnVoluntaryYield(old_pid);
    forceSwitch();
    SchedulerJumpSelected(old_pid);
}

static void LLScheduleFromTimer(void)
{
    int old_pid=nr_curthread;

    /* A PIT tick is a clock event, not automatically a process switch. */
    if(SchedulerTimerShouldPreempt()) forceSwitch();
    SchedulerJumpSelected(old_pid);
}

//--------------------------------------------------------------------------------
//
void TaskPitHandler(void)
{
    pit_handler();
    outportb(0x20,0x20);
    LLScheduleFromTimer();
}

//--------------------------------------------------------------------------------

