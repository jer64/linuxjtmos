// ============================================================================
// fork.c - JTMOS V67.8.56 process image clone / POSIX fork() syscall.
//
// First-generation fork semantics for native ELF32 Ring3 applications:
//   * private copy of the entire primary ELF/heap/stack backing window
//   * same userspace PTE presence/protection layout (guard page stays unmapped)
//   * same CWD/device, terminal, command line and process name
//   * parent receives child PID; child receives 0
//
// IRQ subscriptions, DMA allocations, message boxes and other privileged
// kernel-owned resources are intentionally NOT inherited.  The first ABI also
// gives the child a fresh lazy-FPU state and does not promise POSIX descriptor
// inheritance until the descriptor table has shared-reference semantics.
// ============================================================================
#include "kernel32.h"
#include "systemcalls.h"
#include "threads.h"
#include "scheduler.h"
#include "mm.h"
#include "int.h"
#include "coprocessor_not_found.h"

typedef struct
{
    DWORD eip;
    DWORD esp;
    DWORD ebp;
    DWORD ebx;
    DWORD esi;
    DWORD edi;
    DWORD eflags;
} JTMOS_FORK_CONTEXT;

static int fork_context_valid(int parent, const JTMOS_FORK_CONTEXT *ctx)
{
    DWORD bytes;
    DWORD top;

    if(ctx == NULL || parent <= 0)
        return 0;

    bytes = (DWORD)thread_memkb[parent] * 1024UL;
    if(bytes == 0 || bytes > MM_USER_SIZE)
        return 0;
    top = MM_USER_BASE + bytes;

    if(ctx->eip < MM_USER_BASE || ctx->eip >= top)
        return 0;
    if(ctx->esp < MM_USER_BASE || ctx->esp > top)
        return 0;

    /* EBP/EBX/ESI/EDI are ordinary callee-saved values.  With frame-pointer
     * omission enabled they are not necessarily pointers at all. */
    return 1;
}

static void fork_set_child_context(int child, const JTMOS_FORK_CONTEXT *ctx)
{
    TSSEG *t = GetThreadTSS(child);

    if(t == NULL)
        return;

    t->cs = USER_CS;
    t->ds = USER_DS;
    t->es = USER_DS;
    t->fs = USER_DS;
    t->gs = USER_DS;
    t->ss = USER_DS;

    t->eip = ctx->eip;
    t->esp = ctx->esp;
    t->ebp = ctx->ebp;
    t->ebx = ctx->ebx;
    t->esi = ctx->esi;
    t->edi = ctx->edi;

    /* C ABI: fork() returns 0 in the child.  ECX/EDX are caller-saved. */
    t->eax = 0;
    t->ecx = 0;
    t->edx = 0;

    /* Preserve ordinary arithmetic/control flags, but never allow a child to
     * inherit NT/TF/IOPL or an accidentally cleared reserved bit. */
    t->eflags = (ctx->eflags & 0x000008d5UL) | 0x00000202UL;
    t->eflags &= ~((1UL << 14) | (3UL << 12) | (1UL << 8));
}

int scall_fork(SYSCALLPAR)
{
    JTMOS_FORK_CONTEXT ctx;
    JTMOS_FORK_CONTEXT *user_ctx;
    BYTE *parent_base;
    BYTE *child_base;
    DWORD bytes;
    DWORD banks;
    int parent;
    int child;
    int flags;
    int parent_type;
    char name[64];

    (void)scall_eax; (void)scall_ecx; (void)scall_edx;
    (void)scall_esi; (void)scall_edi; (void)scall_ebp;

    parent = GetCurrentThread();
    if(!valid_pid(parent) || parent <= 0)
        return -1;

    parent_type = GetThreadType(parent);
    if(!(parent_type & THREAD_TYPE_APPLICATION) ||
       (parent_type & THREAD_TYPE_KERNEL) ||
       thread_selector[parent] != USER_CS)
        return -1;

    user_ctx = (JTMOS_FORK_CONTEXT *)A2KRange(scall_ebx, sizeof(ctx));
    if(user_ctx == NULL)
        return -1;
    memcpy(&ctx, user_ctx, sizeof(ctx));
    if(!fork_context_valid(parent, &ctx))
        return -1;

    bytes = (DWORD)thread_memkb[parent] * 1024UL;
    parent_base = (BYTE *)thread_base[parent];
    if(parent_base == NULL || bytes == 0)
        return -1;

    /* Allocate and copy before publishing a runnable child.  The parent is
     * stopped inside this syscall, so its userspace image cannot mutate while
     * we make the snapshot. */
    child_base = (BYTE *)mm_sparse_alloc(bytes, parent, "fork child backing");
    if(child_base == NULL)
        return -1;
    memcpy(child_base, parent_base, bytes);

    flags = get_eflags();
    disable();

    child = (int)_createAppThread(USER_CS, USER_DS,
                                  (int)child_base, (int)ctx.eip, (int)ctx.esp);
    if(child <= 0)
    {
        set_eflags(flags);
        mm_sparse_free(child_base, bytes);
        return -1;
    }

    /* Child must not become runnable until every page and accounting field is
     * valid.  Interrupts remain disabled throughout this publication window. */
    if(mm_clone_process_space(parent, child, child_base, bytes) != 0)
        goto fail_child;

    if(mm_sparse_change_owner(child_base, bytes, parent, child) != 0)
        goto fail_child;

    SetThreadDNR(child, GetThreadDNR(parent));
    SetThreadDB(child, GetThreadDB(parent));
    SetThreadTerminal(child, GetThreadTerminal(parent));

    thread_base[child] = (DWORD)child_base;
    thread_ss[child] = USER_DS;
    thread_ds[child] = USER_DS;
    thread_es[child] = USER_DS;
    thread_fs[child] = USER_DS;
    thread_gs[child] = USER_DS;
    thread_selector[child] = USER_CS;
    banks = (bytes + (64UL * 1024UL - 1)) / (64UL * 1024UL);
    thread_banks[child] = (WORD)banks;
    thread_memkb[child] = (WORD)(bytes / 1024UL);
    thread_CPUspending[child] = 0;
    thread_scall_active[child] = 0;
    thread_idling[child] = 0;
    thread_ml[child] = 0;

    /* new_thread() may recycle a numeric PID whose old per-process pointers
     * were freed by the zombie/reaper path.  Never let the fork child inherit
     * those stale kernel pointers.  These facilities are reacquired lazily or
     * explicitly instead of being shared with the parent. */
    FpuForgetThread(child);
    thread_envdb[child] = NULL;
    thread_msgbox[child] = NULL;
    thread_shell_pointer[child] = 0;

    SetThreadType(child,
                  (parent_type & ~(THREAD_TYPE_KERNEL | THREAD_TYPE_IMMORTAL)) |
                  THREAD_TYPE_APPLICATION);

    if(thread_cmdline[parent] != NULL)
        (void)SetThreadCmdLine(child, thread_cmdline[parent]);
    GetThreadName(parent, name);
    IdentifyThread(child, name);

    fork_set_child_context(child, &ctx);
    SchedulerThreadInit(child);
    SetThreadPriority(child, GetThreadPriority(parent));

    ReportMessage("fork: parent PID%d cloned to child PID%d (%u KiB).\n",
                  parent, child, bytes / 1024UL);
    set_eflags(flags);
    return child;

fail_child:
    mm_clear_process_space(child);
    KillThreadEx(child, KT_NO_THREAD_SWITCH);
    set_eflags(flags);
    mm_sparse_free(child_base, bytes);
    return -1;
}
