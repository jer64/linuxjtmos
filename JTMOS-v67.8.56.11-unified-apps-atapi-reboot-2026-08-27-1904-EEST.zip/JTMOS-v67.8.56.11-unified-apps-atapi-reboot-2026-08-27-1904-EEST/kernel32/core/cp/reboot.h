#ifndef __INCLUDED_REBOOT_H__
#define __INCLUDED_REBOOT_H__

extern volatile int rebootCommenced;
__attribute__((noreturn)) void system_reset1(void);
__attribute__((noreturn)) void system_reset(void);
__attribute__((noreturn)) void SystemReboot(void);

#endif
