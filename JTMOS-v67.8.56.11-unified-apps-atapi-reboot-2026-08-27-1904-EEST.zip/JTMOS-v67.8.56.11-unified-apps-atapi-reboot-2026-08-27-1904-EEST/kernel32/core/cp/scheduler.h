#ifndef __INCLUDED_SCHEDULER_H__
#define __INCLUDED_SCHEDULER_H__

#include "basdef.h"

/*
 * JTMOS scheduler CPU/load statistics.
 *
 * load_a/load_b/load_c are fixed-point load averages multiplied by 1000:
 *   A = 1 minute, B = 5 minutes, C = 15 minutes.
 * cpu_idle/cpu_busy are per-mille values (0..1000) from the last 1 s sample.
 */
typedef struct
{
    DWORD version;
    DWORD size;
    DWORD hz;
    DWORD total_threads;
    DWORD runnable_threads;
    DWORD idle_pid;
    DWORD cpu_idle_per_mille;
    DWORD cpu_busy_per_mille;
    DWORD load_a_x1000;
    DWORD load_b_x1000;
    DWORD load_c_x1000;
    DWORD sample_ticks;
    DWORD sample_idle_ticks;
    DWORD uptime_ms;
} JTMOS_CPU_STATS;

#define JTMOS_CPU_STATS_VERSION 1

void _idle_moment(void);
void MapApplicationMemory(void);
void LLSchedule(void);
void TaskPitHandler(void);
void SchedulerCpuTick(void);
int SchedulerGetCpuStats(JTMOS_CPU_STATS *out, DWORD out_size);

/* V67.8.54 responsive reward scheduler. */
void SchedulerThreadInit(int pid);
void SchedulerPriorityChanged(int pid, BYTE prio);
void SchedulerOnVoluntaryYield(int pid);
void SchedulerRewardIO(int pid, int work_units);
int SchedulerSleepCurrentUsec(DWORD usec);
void SchedulerWakeThread(int pid);
int SchedulerTimerShouldPreempt(void);
int SchedulerPickNext(int current);
void SchedulerOnSwitch(int old_pid, int new_pid);
void SchedulerDump(void);

#endif
