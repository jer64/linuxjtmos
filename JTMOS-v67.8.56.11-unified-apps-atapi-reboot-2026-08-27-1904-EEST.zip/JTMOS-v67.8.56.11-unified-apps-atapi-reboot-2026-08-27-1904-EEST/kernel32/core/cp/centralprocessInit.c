// ===========================================================================
// centralprocessInit.c - Initializes the permanent kernel Central Process.
// (C) 2002-2003 by Jari Tuominen. Microkernel integration update 2026.
// ===========================================================================
#include "kernel32.h"
#include "centralprocess.h"
#include "centralprocessInit.h"

THREAD centralprocessThread;
int centralprocessStarted=0;
int centralprocessPID=0;

void centralprocessInit(void)
{
    if(centralprocessStarted)
        return;

    ThreadCreateStack(&centralprocessThread, JTMOS_MIN_DYNAMIC_STACK);
    centralprocessThread.pid = create_thread(centralprocessThread.stack,
        centralprocessThread.l_stack, centralprocess_run);

    if(!centralprocessThread.pid)
    {
        printk("CP: failed to create central process kernel thread.\n");
        return;
    }

    centralprocessPID = centralprocessThread.pid;
    IdentifyThread(centralprocessThread.pid, "CP");
    centralprocessStarted=1;
    printk("CP: kernel service created after driver initialization, PID=%d.\n",
        centralprocessPID);
}
