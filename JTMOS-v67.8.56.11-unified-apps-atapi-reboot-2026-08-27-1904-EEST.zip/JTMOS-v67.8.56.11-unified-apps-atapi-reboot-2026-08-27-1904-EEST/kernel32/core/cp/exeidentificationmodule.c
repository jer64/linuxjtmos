//=======================================================================
// JTMOS executable file identification.
// (C) 2003-2005 by Jari Tuominen.
// ELF32 compatibility / bounds fixes 2026.
//=======================================================================
#include "kernel32.h"
#include "exeidentificationmodule.h"

// Can run anything?
int exeIdentAnythingGoes = FALSE;

static int exe_is_elf32(const BYTE *buf, int len)
{
    if(buf == NULL || len < 5)
        return FALSE;
    return buf[0] == 0x7f && buf[1] == 'E' && buf[2] == 'L' &&
           buf[3] == 'F' && buf[4] == 1;
}

/* Return the byte offset of needle, or -1.  Unlike the historical matcher,
 * this is bounded by the actual file length and handles overlapping prefixes. */
static int exe_find_string(const BYTE *buf, int len,
                           const char *needle, int search_len)
{
    int i, j, n;

    if(buf == NULL || needle == NULL || len <= 0)
        return -1;

    n = strlen(needle);
    if(n <= 0 || n > len)
        return -1;

    if(search_len <= 0 || search_len > len)
        search_len = len;
    if(n > search_len)
        return -1;

    for(i = 0; i <= search_len - n; i++)
    {
        for(j = 0; j < n; j++)
            if(buf[i+j] != (BYTE)needle[j])
                break;
        if(j == n)
            return i;
    }
    return -1;
}

// Returns 0 if no MemReq string was found.
int getExeMemReq(BYTE *buf, int len)
{
    static const char ids[] = "SQUIRREL VERIFY APPLICATION MEMORY CONFIGURATION=";
    int off, p, value, digit, have_digit;

    off = exe_find_string(buf, len, ids, len);
    if(off < 0)
        return 0;

    p = off + strlen(ids);
    value = 0;
    have_digit = FALSE;

    while(p < len)
    {
        digit = buf[p] - '0';
        if(digit < 0 || digit > 9)
            break;
        have_digit = TRUE;
        if(value > (0x7fffffff - digit) / 10)
            return 0;
        value = value * 10 + digit;
        p++;
    }

    if(!have_digit)
        return 0;

    printk("%s: application memory configuration = %dK\n",
           __FUNCTION__, value);
    return value;
}

// Determine whether the binary in buffer is a JTMOS executable.
int isExeBinary(BYTE *buf, int len)
{
    static const char det[] = "[JTMOS LIBC (C) 2002 Jari Tuominen]";
    static const char tail[] = "[VALID JTMOS EXECUTABLE BINARY FILE FCE2E37BE38BA000]";
    int first_search;

    if(exeIdentAnythingGoes)
        return TRUE;
    if(buf == NULL || len <= 0)
        return FALSE;

    /* Legacy flat binaries kept the first marker in their first 200 bytes.
     * ELF has a file/program-header area before the first PT_LOAD payload, so
     * its marker naturally begins around file offset 0x1000.  Require the same
     * marker, but scan the complete ELF file rather than weakening validation. */
    first_search = exe_is_elf32(buf, len) ? len : ((len < 200) ? len : 200);

    if(exe_find_string(buf, len, det, first_search) < 0)
    {
        printk("%s: First EXE identification string not found.\n",
               __FUNCTION__);
        return FALSE;
    }

    if(exe_find_string(buf, len, tail, len) < 0)
    {
        printk("%s: Second EXE identification string not found.\n",
               __FUNCTION__);
        return FALSE;
    }

    return TRUE;
}
