#ifndef __INCLUDED_CENTRALPROCESSINIT_H__
#define __INCLUDED_CENTRALPROCESSINIT_H__

extern THREAD centralprocessThread;
extern int centralprocessStarted;
extern int centralprocessPID;

void centralprocessInit(void);

#endif
