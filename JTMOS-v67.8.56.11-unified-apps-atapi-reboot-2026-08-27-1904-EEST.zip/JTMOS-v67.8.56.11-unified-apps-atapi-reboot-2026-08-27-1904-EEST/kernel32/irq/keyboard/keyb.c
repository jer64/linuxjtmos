/**************************************************
 * keyb.c - Keyboard driver version 1.3           *
 * (C) 2002-2005 by Jari Tuominen.                *
 **************************************************/
//
////#define __KEYDEBUG__
//#define __KBIRQDEBUG__
//
#include <kernel32.h>
#include <cpu.h>
#include <io.h>
#include <keyb.h>
#include <sysglvar.h>
#include <ega.h>
#include <int.h>
#include <vga.h>
#include <scanasc.h>
#include <dispadmin.h>
//
#include <driver_sys.h> // driver_register_new_device, ...
#include <driver_api.h>
//
#include <ps2mouse.h>

//
int syskey_terminate=0;

/* One Ctrl+C latch per terminal.  IRQ1 only sets a byte; process context
 * performs the destructive action.  This avoids killing a task from inside
 * the keyboard interrupt handler and prevents Ctrl+C on one VT from
 * terminating a foreground job on another VT. */
static volatile BYTE terminal_interrupt_pending[N_MAX_SCREENS];

void SignalTerminalInterrupt(int terminal)
{
    if(terminal<0 || terminal>=N_MAX_SCREENS)
        terminal=0;
    terminal_interrupt_pending[terminal]=1;
    syskey_terminate=1; /* compatibility with historical callapp monitor */
}

int PeekTerminalInterrupt(int terminal)
{
    if(terminal<0 || terminal>=N_MAX_SCREENS)
        return 0;
    return terminal_interrupt_pending[terminal] ? 1 : 0;
}

int ConsumeTerminalInterrupt(int terminal)
{
    DWORD flags;
    int i,hit=0,any=0;

    if(terminal<0 || terminal>=N_MAX_SCREENS)
        return 0;
    flags=get_eflags();
    disable();
    if(terminal_interrupt_pending[terminal])
    {
        terminal_interrupt_pending[terminal]=0;
        hit=1;
    }
    for(i=0;i<N_MAX_SCREENS;i++)
        if(terminal_interrupt_pending[i]) { any=1; break; }
    if(!any) syskey_terminate=0;
    set_eflags(flags);
    return hit;
}


// Key status.
KEYS keys;

//
KBSTR kbstr;

/* Lock keys are logical toggle state, not ordinary held modifiers.  LED
 * programming is deferred out of IRQ1 so keyboard ACK bytes never have to be
 * synchronously consumed from interrupt context. */
static volatile int keyb_led_update_pending=0;
static volatile int keyb_led_update_busy=0;
static volatile int keyb_command_response=0;

static int keyb_handle_lock_make(BYTE scancode)
{
    BYTE mask=0;

    if(scancode==SCODE_CAPSLOCK) mask=LED_CAPS_LOCK;
    else if(scancode==SCODE_NUMLOCK) mask=LED_NUM_LOCK;
    else if(scancode==SCODE_SCROLLLOCK) mask=LED_SCROLL_LOCK;
    else return 0;

    kbstr.led_status ^= mask;
    keyb_led_update_pending=1;
    return 1;
}

/* EGA/VGA text-console hotkey: left ALT + top-row 1..9 selects virtual
 * terminal 1..9. Handle this from the raw MAKE path, before scan_to_asc(),
 * because the Finnish legacy keymap also uses ALT with number keys for
 * printable symbols. In graphics modes those old mappings remain intact.
 *
 * Return non-zero when the key belongs to the terminal hotkey, including
 * typematic repeated MAKEs. This prevents a terminal number from leaking
 * into the selected terminal's keyboard input buffer. */
static int keyb_handle_terminal_hotkey(BYTE scancode, int was_down)
{
    int terminal;

    if(dispadmin_getcurrentmode()!=3)
        return 0;
    if(!kbstr.ktab[SCODE_LEFTALT])
        return 0;
    if(scancode < 0x02 || scancode > 0x0A)
        return 0;

    terminal = (int)scancode - 0x02;      /* 1 -> VT0, ... 9 -> VT8 */

    /* Switch only on the up->down edge. Repeated MAKE codes while the
     * number key is held are consumed but do not retrigger the switch. */
    if(!was_down)
        SwitchUserTerminal(terminal);

    return 1;
}

// Get CTRL key status.
int GetCTRL(void)
{
	return keys.ctrl;
}

// Get ALT key status.
int GetALT(void)
{
	return keys.alt;
}

// Get CTRL/ALT.
void HandleStickKeys(void)
{
	// Get status
	keys.ctrl =	kbstr.ktab[29];
	keys.alt =	kbstr.ktab[56];
}

//
// void set_vector(void *handler,
//            unsigned char interrupt, unsigned short control_major)
//
int InitKeyboard()
{
	//
	int retval,i;

	//
	printk("Keyboard driver 0.2.0 by Jari Tuominen, Gareth Owen.\n");

	/* Drain only pending KEYBOARD bytes.  Port 0x60 is shared with the
	 * i8042 AUX/PS2 mouse channel; blindly reading it here used to steal
	 * mouse bytes before IRQ12 could consume them. */
	printk("kbinit 1");
	for(i=0; i<1000; i++)
	{
		int status=inportb(0x64);
		if(!(status & KBD_STAT_OBF))
			break;
		if(status & KBD_STAT_MOUSE_OBF)
			break;
		(void)inportb(0x60);
	}

	// Reset whole structure, fill with zeroes
	printk("2");
	memset(&kbstr,0,sizeof(KBSTR));
	kbstr.led_status = 0;
	keyb_led_update_pending = 1;

	// Some space for the macro
	printk("3");
	kbstr.macro = malloc(256);
	// 64K for keyboard defs
	kbstr.ktab = malloc(1024*64);
	// allocate data for the keyboard buffer
	printk("4");
	kbstr.buf = malloc(KEYBOARD_BUFFER_LENGTH*2+100);
	// allocate data for the ascii keyboard buffer
	kbstr.abuf = malloc(KEYBOARD_BUFFER_LENGTH*2+100); 
	printk("5");
	// set position to 0
	kbstr.i=0;
	// set ascii buffer's position to 0
	kbstr.ai=0;
	kbstr.i_macro=0;
	kbstr.counter=0;
	kbstr.place=0;
	//
	strcpy(kbstr.macro, "");

	//
	printk("6");
	setint(M_VEC+1, // M_VEC+1 orig.
		keyb_ISR,
		GIMMIE_CS(), 
		D_PRESENT + D_INT);

	//
	printk("7");
	enable_irq(1);

	//
	printk("8");
	kb_hwinit();

	//
//	kbstr.led_status = 0;
//	setleds();
	
	// Finally register keyboard as a valid device.
	printk("9");
	keyb_register_device();

	//
	printk("\n");
	return retval;
}

//
void kb_outbuf(int akey)
{
	// Zero code?
	if(!akey)return 0;

	// Store if space left at the buffer.
	if(kbstr.ai<KEYBOARD_BUFFER_LENGTH)
	{
		kbstr.abuf[kbstr.ai]=akey;
		kbstr.ai++;
		kbstr.abuf[kbstr.ai]=0;
		//if(kbstr.ExtraKey)goto morekeys;
	}
}

// Converts scancodes to more practically useful ASCII codes.
// F.e. getch returns only ASCII codes.
//
int kb_output_asc_buffer(int key)
{
	int akey;

	//
	if(key==-1 || key==0)return 0;

	//
	if(kbstr.abuf[0]==0){kbstr.ai=0;}

	//
	if(kbstr.ai>=KEYBOARD_BUFFER_LENGTH)
	{
		kbstr.ai=0;
	}

	// CONVERT SCANCODE TO ASCII
	// Also gives a character from possible macro string, etc.
morekeys:
	akey=scan_to_asc(key);

	if(kbstr.ExtraKey==0xFF || kbstr.ExtraKeyCode)
	{
		akey=kbstr.ExtraKeyCode;
		kbstr.ExtraKey=0;
		kbstr.counter=0;
		kbstr.ExtraKeyCode=0;
	}

	if(akey)		kb_outbuf(akey);
	if(kbstr.ExtraKey)	goto morekeys;

	//
	return 0;
}

//
void incmark(void)
{
	char *buf;

	//
	buf=0xb8000;

	//
	buf[0]++;
}

//
char getmark(int offs)
{
	char *buf;
	buf=0xb8000;
	return buf[offs];
}

//
void storemark(int which,int offs)
{
	char *buf;
	buf=0xb8000+offs;
	buf[0]=which;
}

// Terminal getch1
int getch1(void)
{
	int key;

	keyb_service();
	SCREEN *s;

	// Get terminal
	s = &screens[GetThreadTerminal(GetCurrentThread())];

	// Input keyboard
	key = PopBufferW(&s->key);

	// Filter input data
	if(key==-1)
		return 0;
	else
		return key;
}

// Redirection of keyboard stream
// to appropriate terminal.
void RedirectKeyboardStream(void)
{
	int t,key;
	SCREEN *s;

	/* Physical keyboard input follows the explicit focus terminal, not the
	 * terminal whose text page happens to be visible. */
	t = GetInputTerminal();
	s = &screens[t];

	// Output all keys to the terminal's
	// keyboard buffer.
	while( (key=directgetch())>=1 )
	{
		//
		PushBufferW(&s->key, key);
	}
}

//
// Keyboard Interrupt Handler
//
static void keyb_process_scancode(BYTE key)
{
    /* Keyboard command responses are not key scancodes.  Normally these are
     * consumed by keyb_service(), but ignoring them here makes the IRQ path
     * robust if an ACK happens to arrive asynchronously. */
    if(key==0xFA || key==0xFE)
        return;

    if(key==0xFC || key==0xFD)
    {
        printk("\nkeyb.c: keyboard error 0xfc/0xfd\n");
        return;
    }
    if(key==0xAA)
    {
        kbstr.diagnosticsOK=1;
        return;
    }

    if((key&0x80)==0x80)
    {
        kbstr.ktab[key&127]=0;
        kbstr.rkey=key&127;
    }
    else
    {
        BYTE sc=key&127;
        int was_down = kbstr.ktab[sc] ? 1 : 0;
        kbstr.ktab[sc]=1;

        /* Toggle only on the up->down edge.  A typematic repeated MAKE must
         * never toggle Caps/Num/Scroll Lock a second time while held. */
        if(!was_down && keyb_handle_lock_make(sc))
            goto done;
        if(was_down && (sc==SCODE_CAPSLOCK || sc==SCODE_NUMLOCK ||
                        sc==SCODE_SCROLLLOCK))
            goto done;

        /* ALT+1..9 is a console-control chord in mode 03h. Consume it
         * before ASCII translation so e.g. ALT+2 cannot become '@'. */
        if(keyb_handle_terminal_hotkey(sc, was_down))
            goto done;

        /* Ctrl+C is terminal job control, not printable input.  Latch it on
         * the up->down edge and consume the C make code so no stray 'c' is
         * left in the terminal FIFO.  Process termination is deliberately
         * deferred out of IRQ1. */
        if(!was_down && sc==46 && kbstr.ktab[SCODE_CTRL])
        {
            SignalTerminalInterrupt(GetInputTerminal());
            goto done;
        }

        translate_keyboard_situation();
        if(kbstr.i<KEYBOARD_BUFFER_LENGTH)
        {
            kbstr.key_pressed=1;
            kb_output_asc_buffer(key);
        }
    }

done:
    HandleStickKeys();
    RedirectKeyboardStream();
}

// Keyboard Interrupt Handler
void keyb_handler(void)
{
    BYTE key,status;

    status=inportb(0x64);

    /* The 8042 output register is shared by keyboard and AUX/PS2 mouse.
     * IRQ1 must never consume a byte tagged as AUX data (status bit 5). */
    if(!(status&KBD_STAT_OBF))
        goto eoi;
    if(status&KBD_STAT_MOUSE_OBF)
        goto eoi;

    key=inportb(0x60);

#ifdef __KBIRQDEBUG__
    incmark();
#endif

    if(keyb_led_update_busy && (key==0xFA || key==0xFE))
        keyb_command_response=key;
    else
        keyb_process_scancode(key);

eoi:
    outportb(0x20,0x20);
}

// Output string to current terminal's keyboard buffer
int WriteKeyboard(const char *s)
{
	int l,i=0;

	//
	l = strlen(s);
	for(i=0; i<l; i++)
	{
		//
		OutputKeyboard(s[i]);
	}
	return 0;
}

// Output terminal's keyboard buffer
int OutputKeyboard(int ch)
{
	SCREEN *s;

	// Get terminal
	s = &screens[GetThreadTerminal(GetCurrentThread())];

	// Output keyboard
	PushBufferW(&s->key, ch);
	return 0;
}

//
int translate_keyboard_situation(void)
{
	// See removed.txt.
	return 0;
}

//
int keyb_device_call(DEVICE_CALL_PARS)
{
	switch(n_call)
	{
		//
		case DEVICE_CMD_INIT:
		break;
		//
		case DEVICE_CMD_SHUTDOWN:
		break;
		//
		case DEVICE_CMD_READBLOCK:
		break;
		//
		case DEVICE_CMD_WRITEBLOCK:
		break;
		//
		case DEVICE_CMD_GETSIZE:
		break;
		//
		case DEVICE_CMD_GETBLOCKSIZE:
		break;
		//
		case DEVICE_CMD_SEEK:
		break;
		//
		case DEVICE_CMD_GETCH:
		break;
		//
		case DEVICE_CMD_PUTCH:
		break;
		//
		case DEVICE_CMD_TELL:
		break;
		//
		default:
		break;
	}

	//
	return 0;
}

//
int keyb_register_device(void)
{
	//
	if( driver_getdevicebyname("keyb") )	return 1;

	//
	driver_register_new_device( "keyb", keyb_device_call, DEVICE_TYPE_CHAR );

	//
	return 0;
}

//
int kbwaitstatus(DWORD value,DWORD mask)
{
	//
	DWORD i,i2;

	//
	for(i=0; i<PS2MOUSE_TIMEOUT; i++)
	{
		if( (inportb(0x64)&mask)==value )return 0;
		inportb(0x80);
		for(i2=0; i2<10; i2++)nop();
	}

	//
	return 1;
}

//
int kbread(void)
{
	int i,status,d2;

	/* Never consume an AUX byte through the keyboard helper.  This helper is
	 * kept for legacy callers, but the physical 0x60 read is permitted only
	 * when the i8042 status explicitly identifies keyboard output. */
	for(i=0; i<PS2MOUSE_TIMEOUT; i++)
	{
		status=inportb(0x64);
		if(status & KBD_STAT_OBF)
		{
			if(status & KBD_STAT_MOUSE_OBF)
				return -1;
			d2=inportb(0x60);
			return d2;
		}
		inportb(0x80);
	}
	return -1;
}

// non-zero return value is an error
int kbwrite(int value)
{
	//
	static long i,i2,i3,i4,d;
 
	// When using PS/2 mouse we should wait here
	// for kbwaitmousebufferfull, so
	// it should be manually called before using
	// this function when commanding PS/2 mouse.

	//
	kbwait();

	// write the data
	outportb(0x60,value); for(i4=0; i4<10; i4++)inportb(0x80);
 
	//
	kbwait();

	//
	return 0;
}

// non-zero will be an error
int kbcmd(int cmd)
{
	//
	long i;
 
	//
	kbwait();
 
	// cmd_send
	outportb(0x64,cmd);
	for(i=0; i<20; i++)nop();
 
	//
	kbwait();

	//
	return 0;
}

//
void kbwait(void)
{
	long i;

	for( i=glvar.timer[0]; (inportb(0x64) & 2); )
	{
		if( (glvar.timer[0]-i)>200 )
		{
			print("syskeyb.c/kbwait: error, timeout occured\n");
			break;
		}
	}
}

// Waits until readable data is available
void kbwaitdata(void)
{
	//
	long i,i2;

	//
	for( i=glvar.timer[0],i2=0; !(inportb(0x64) & 1); i2++)
	{
		//
		inportb(0x80);
		//
		if(i2>10000)break;
		//
		if( (glvar.timer[0]-i)>200 )
		{
			printk("keyb.c/kbwaitdata: error, timeout occured\n");
			break;
		}
	}
 // 
}

/* Poll one keyboard (not AUX) byte.  The status/read pair is protected so
 * IRQ1 cannot race this thread between the 0x64 and 0x60 accesses. */
static int keyb_poll_byte(int *value)
{
    int flags,status;

    flags=get_eflags();
    disable();
    status=inportb(0x64);
    if(!(status & KBD_STAT_OBF) || (status & KBD_STAT_MOUSE_OBF))
    {
        set_eflags(flags);
        return 0;
    }
    *value=inportb(0x60);
    set_eflags(flags);
    return 1;
}

static int keyb_wait_input_empty(DWORD timeout_ms)
{
    DWORD start=GetTickCount();
    while(inportb(0x64) & KBD_STAT_IBF)
    {
        if((DWORD)(GetTickCount()-start)>=timeout_ms)
            return 1;
        SwitchToThread();
    }
    return 0;
}

/* Return 0=ACK, 2=RESEND, 1=timeout/error.  Any real scancode encountered
 * while waiting is fed back through the normal decoder rather than lost. */
static int keyb_wait_ack(DWORD timeout_ms)
{
    DWORD start=GetTickCount();
    int b;

    while((DWORD)(GetTickCount()-start)<timeout_ms)
    {
        if(keyb_command_response)
        {
            b=keyb_command_response;
            keyb_command_response=0;
            if(b==0xFA) return 0;
            if(b==0xFE) return 2;
        }
        if(keyb_poll_byte(&b))
        {
            if(b==0xFA) return 0;
            if(b==0xFE) return 2;
            keyb_process_scancode((BYTE)b);
        }
        else
            SwitchToThread();
    }
    return 1;
}

static int keyb_send_ack_byte(BYTE value)
{
    int attempt,r;
    for(attempt=0; attempt<3; attempt++)
    {
        if(keyb_wait_input_empty(100)) return 1;
        keyb_command_response=0;
        outportb(0x60,value);
        r=keyb_wait_ack(150);
        if(r==0) return 0;
        if(r!=2) return 1;
    }
    return 1;
}

// Attempt to set keyboard LEDs from thread context.
void setleds(void)
{
    BYTE wanted=kbstr.led_status &
        (LED_SCROLL_LOCK|LED_NUM_LOCK|LED_CAPS_LOCK);

    if(keyb_led_update_busy)
        return;
    keyb_led_update_busy=1;

    if(!keyb_send_ack_byte(0xED) && !keyb_send_ack_byte(wanted))
        keyb_led_update_pending=0;

    keyb_led_update_busy=0;
}

void keyb_service(void)
{
    if(keyb_led_update_pending && !keyb_led_update_busy)
        setleds();
}

// returns non-zero on error
int kb_hwinit(void)
{
	//
	int d;

	// clear keyboard test variable
	kbstr.kb_test_ok=0;

	// Reset *keyboard* CPU, do power-on self-test,
	// return self-test result byte.
	if(kbwrite(0xFF))return 1;
	// Clears output *buffer*, enables *keyboard*.
	if(kbwrite(0xF4))return 2;

	//
	return 0;
}

// getch
//
// I don't know if keyb.c is the best place to store
// this getch() function, but let's think it's a
// inside kernel thing, applications will be not
// accessing it directly, instead via the interface.
//
int getch()
{
	int key;

	//
	while( !(key=getch1()) )
	{
		// Save some CPU time
		SwitchToThread();
	}
	return key;
}

// Direct input a char from keyboard
int directgetch()
{
	//
	int key;
	int i;
	
	// Buffer already empty?
	if( !kbstr.ai )return 0;

/*	// Check that the data is for us
	if( thread_terminal[GetCurrentThread()]!=visible_terminal )
	{
		return 0;
	}*/

	//
	key=kbstr.abuf[0];
	kbstr.ai--;
	kbstr.i--;
	
	//
	for(i=0; i<KEYBOARD_BUFFER_LENGTH; i++)
	{
		kbstr.buf[i]=kbstr.buf[i+1];
		kbstr.abuf[i]=kbstr.abuf[i+1];
	}

	//
	return key;
}

//
int kbhit()
{
	keyb_service();
	//
	if( !kbstr.ai ) return 0;

	//
	return 1;
}











