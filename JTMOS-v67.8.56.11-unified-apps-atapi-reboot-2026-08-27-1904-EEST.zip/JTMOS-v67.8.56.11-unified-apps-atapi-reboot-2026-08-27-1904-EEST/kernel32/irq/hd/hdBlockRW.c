// ==============================================================
// hdBlockRW.c
// (C) 2003-2004 by Jari Tuominen.
// ==============================================================
#include <stdio.h>
#include "hd.h"
#include "hdBlockRW.h"
#include "hdCache.h"

// dhd_blockrw function
//
// returns zero on success
int hdBlockRW(HD *h, BYTE *buf,int l_buf,
		DWORD blocknr,
		int drivenr,
		int rw)
{
	static int sectornr,headnr,cylindernr,retval,i,i2,try,try1,try2;

	//
	retval = 0;

	//
	if(h==NULL || buf==NULL || l_buf<h->blocksize || blocknr>=h->n_blocks)
		return 1;
	if(rw!=READ && rw!=WRITE)
	{
		dprintk("hdBlockRW: invalid rw=%d.\n",rw);
		return 1;
	}

	//
	if(h->lbaMode)
	{
                // ------------------------------------------------------------
                // int hdSectorRW_LBA(HD *h,
                //                BYTE *buf,int l_buf,
                //                DWORD lba,
                //                int driveNr, // 0=master, 1=slave
                //                int rw, // 0=read, 1=write
                //                int sectorCount)
                // ------------------------------------------------------------
		retval = hdSectorRW_LBA(h,	// HD*
			buf,l_buf,	// buf, l_buf
			blocknr,	// LBA
			h->slave,	// master or slave
			rw,		// read or write
			1);		// amount
	}
	else
	{
		// ---------------------------------------------------------------------
		// CONVERT LINEAR TO CHS
		LinearToCHS(h, blocknr, &cylindernr,&headnr,&sectornr);
	
		/* Direct CHS PIO: legacy write-back cache is disabled for correctness. */
		retval = hdSectorRW(h,buf,l_buf,cylindernr,headnr,sectornr,h->slave,rw,1);
	}

	// --------------------------------------------------------
	return retval;
}



