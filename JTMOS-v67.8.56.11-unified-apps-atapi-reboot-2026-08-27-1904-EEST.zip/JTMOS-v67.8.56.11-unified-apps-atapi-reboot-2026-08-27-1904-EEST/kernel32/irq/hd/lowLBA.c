// ===================================================================
// lowLBA.c - ATA PIO LBA28 access
// ===================================================================
#include <stdio.h>
#include "hd.h"
#include "lowLBA.h"

void HD_SetLBAMode(char sw)
{
    if(chd) chd->lbaBit = sw ? 0x40 : 0;
}

void hdNewOrders_LBA(HD *h,DWORD lba,int rw,int sectorCount)
{
    outportb(0x1F6,0xA0|((h->slave&1)<<4)|0x40|((lba>>24)&0x0F));
    hd400ns();
    outportb(0x1F2,sectorCount&0xFF);
    outportb(0x1F3,lba&0xFF);
    outportb(0x1F4,(lba>>8)&0xFF);
    outportb(0x1F5,(lba>>16)&0xFF);
    outportb(0x1F7,rw==READ ? 0x20 : 0x30);
}

int hdSectorRW_LBA(HD *h,BYTE *buf,int l_buf,DWORD lba,int driveNr,int rw,int sectorCount)
{
    int i,offs,r; BYTE status=0;
    if(!h || (rw!=READ && rw!=WRITE)) return 1;
    if(sectorCount<=0 || sectorCount>255) return 1;
    if(lba>=HD_LBA28_MAX_SECTORS || lba+(DWORD)sectorCount>HD_LBA28_MAX_SECTORS) return 1;
    if(lba+(DWORD)sectorCount>(DWORD)h->n_blocks) return 1;
    if(buf && l_buf<sectorCount*h->blocksize) return 1;
    if(hdWait(h)) return 10;
    hdNewOrders_LBA(h,lba,rw,sectorCount);
    for(i=0,offs=0;i<sectorCount;i++,offs+=h->blocksize)
    {
        r=hdWaitDRQ(HD_POLL_TIMEOUT_MS,&status);
        if(r)
        {
            printk("IDE LBA: DRQ timeout/error lba=%u status=0x%x err=0x%x\n",lba+(DWORD)i,status,hdReadError());
            return 20+r;
        }
        if(hdRW(h,buf ? buf+offs : NULL,rw)) return 30;
    }
    if(hdWaitNotBusy(HD_POLL_TIMEOUT_MS,&status)) return 40;
    if(status & (HD_STATUS_ERROR|HD_STATUS_WRITE_ERROR)) return hdErrorCheck(h,rw,driveNr,0,0,0) ? 50 : 0;
    return 0;
}
