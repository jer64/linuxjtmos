// ===================================================================
// lowCHS.c - ATA PIO CHS access
// ===================================================================
#include <stdio.h>
#include "hd.h"
#include "lowCHS.h"

void hdNewOrders(HD *h,int cylinder,int head,int sector,int rw,int sectorCount)
{
    outportb(0x1F6,0xA0|(head&0x0F)|((h->slave&1)<<4));
    hd400ns();
    outportb(0x1F2,sectorCount&0xFF);
    outportb(0x1F3,sector);
    outportb(0x1F4,cylinder&0xFF);
    outportb(0x1F5,(cylinder>>8)&0xFF);
    outportb(0x1F7,rw==READ ? 0x20 : 0x30);
}

int hdSectorRW(HD *h,BYTE *buf,int l_buf,int C,int H,int S,int driveNr,int rw,int sectorCount)
{
    int i,offs,r; BYTE status=0;
    if(!h || h->lbaMode || (rw!=READ && rw!=WRITE)) return 1;
    if(sectorCount<=0 || sectorCount>255 || !isValidCHS(h,C,H,S)) return 1;
    if(buf && l_buf<sectorCount*h->blocksize) return 1;
    if(hdWait(h)) return 10;
    hdNewOrders(h,C,H,S,rw,sectorCount);
    for(i=0,offs=0;i<sectorCount;i++,offs+=h->blocksize)
    {
        r=hdWaitDRQ(HD_POLL_TIMEOUT_MS,&status);
        if(r) return 20+r;
        if(hdRW(h,buf ? buf+offs : NULL,rw)) return 30;
    }
    if(hdWaitNotBusy(HD_POLL_TIMEOUT_MS,&status)) return 40;
    return hdErrorCheck(h,rw,driveNr,H,S,C);
}
