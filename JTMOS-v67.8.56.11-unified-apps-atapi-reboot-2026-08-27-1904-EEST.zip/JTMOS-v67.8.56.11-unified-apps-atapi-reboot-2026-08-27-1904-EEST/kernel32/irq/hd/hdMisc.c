//====================================================================
// hdMisc.c - ATA polling helpers
//====================================================================
#include <stdio.h>
#include "hd.h"
#include "hdMisc.h"

int hdChooseDrive(int which)
{
    outportb(0x1F6, (inportb(0x1F6)&0xEF) | ((which&1)<<4));
    hd400ns();
    return 0;
}

int hdGetStatus(void) { return inportb(0x01F7); }

void hd400ns(void)
{
    inportb(0x3F6); inportb(0x3F6); inportb(0x3F6); inportb(0x3F6);
}

void hdDelay(void)
{
    int i;
    for(i=0; i<100; i++) { inportb(0x80); nop(); nop(); }
}

BYTE hdReadError(void) { return inportb(0x01F1); }
inline int hdReadStatus(void) { return hdGetStatus(); }

int hdWaitIDEIRQ(int idenr)
{
    DWORD start;
    if(idenr<0 || idenr>=10) return 1;
    start=GetTickCount();
    while(!ideirqtick[idenr])
    {
        if((DWORD)(GetTickCount()-start)>=HD_POLL_TIMEOUT_MS) return 1;
        idle_moment();
    }
    ideirqtick[idenr]=0;
    return 0;
}

int hdWaitNotBusy(DWORD timeout_ms, BYTE *last_status)
{
    DWORD start=GetTickCount();
    BYTE s;
    for(;;)
    {
        s=(BYTE)hdGetStatus();
        if(last_status) *last_status=s;
        if(s==0x00 || s==0xFF) return 2;
        if(!(s & HD_STATUS_BUSY)) return 0;
        if((DWORD)(GetTickCount()-start)>=timeout_ms) return 1;
        hd400ns();
    }
}

int hdWaitDRQ(DWORD timeout_ms, BYTE *last_status)
{
    DWORD start=GetTickCount();
    BYTE s;
    for(;;)
    {
        s=(BYTE)hdGetStatus();
        if(last_status) *last_status=s;
        if(s==0x00 || s==0xFF) return 2;
        if(!(s & HD_STATUS_BUSY))
        {
            if(s & (HD_STATUS_ERROR|HD_STATUS_WRITE_ERROR)) return 3;
            if(s & HD_STATUS_DRQ) return 0;
        }
        if((DWORD)(GetTickCount()-start)>=timeout_ms) return 1;
        hd400ns();
    }
}

int hdIsDriveBusy(void)
{
    int v=hdGetStatus();
    if(v==0 || v==0xFF) return 1;
    return (v & HD_STATUS_BUSY) || !(v & HD_STATUS_READY);
}

int hdIsError(void) { return (hdGetStatus() & HD_STATUS_ERROR) != 0; }

int hdWait(HD *h)
{
    DWORD start;
    BYTE s;
    if(h==NULL) return 1;
    hdChooseDrive(h->slave);
    start=GetTickCount();
    for(;;)
    {
        s=(BYTE)hdGetStatus();
        if(s==0 || s==0xFF) return 2;
        if(!(s & HD_STATUS_BUSY) && (s & HD_STATUS_READY)) return 0;
        if((DWORD)(GetTickCount()-start)>=HD_POLL_TIMEOUT_MS)
        {
            printk("hdWait: timeout status=0x%x\n",s);
            return 1;
        }
        hd400ns();
    }
}

int hdErrorCheck(HD *h,int rw,int drivenr,int headnr,int sectornr,int cylinder)
{
    BYTE s=(BYTE)hdGetStatus();
    if(s & HD_STATUS_ERROR)
    {
        printk("IDE: ATA error status=0x%x error=0x%x\n",s,hdReadError());
        return 2;
    }
    if(rw==WRITE && (s & HD_STATUS_WRITE_ERROR))
    {
        printk("IDE: write fault at CHS %d/%d/%d status=0x%x\n",cylinder,headnr,sectornr,s);
        return 1;
    }
    return 0;
}

void hdCommand(HD *h,int which) { outportb(0x1F7,which); }

int hdFlushDeviceCache(HD *h)
{
    BYTE s;
    if(!h || hdWait(h)) return 1;
    outportb(0x1F7,0xE7);
    if(hdWaitNotBusy(HD_POLL_TIMEOUT_MS,&s)) return 1;
    return (s & HD_STATUS_ERROR) ? 1 : 0;
}

void hdRecalibrate(HD *h)
{
    if(!h) return;
    hdChooseDrive(h->slave);
    hdReset(h);
    if(hdWait(h)) return;
    hdCommand(h,0x10);
    hdWait(h);
}
