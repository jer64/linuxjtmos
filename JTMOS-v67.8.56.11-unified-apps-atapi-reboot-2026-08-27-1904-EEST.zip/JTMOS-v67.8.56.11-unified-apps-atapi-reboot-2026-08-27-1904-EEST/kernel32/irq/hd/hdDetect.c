// ------------------------------------------------------
// hdDetect.c
// Drive detection code.
// (C) 2003-2004 by Jari Tuominen.
// V67.8.50.2: robust legacy-first ATA IDENTIFY fallback.
// ------------------------------------------------------
#include <stdio.h>
#include "hd.h"
#include "hdDetect.h"

static const char *hd_drive_name(int drive)
{
    return drive ? "slave" : "master";
}

/*
 * Read the command-block status.  The historical JTMOS driver used 0x1F7
 * for detection and QEMU's legacy IDE implementation responds reliably to
 * it.  Alternate status is still included in diagnostics.
 */
static BYTE hd_probe_status(void)
{
    return (BYTE)inportb(0x1F7);
}

static void hd_probe_dump(int drive, const char *stage)
{
    BYTE st=hd_probe_status();
    BYTE ast=(BYTE)inportb(0x3F6);
    BYTE er=(BYTE)inportb(0x1F1);
    BYTE sc=(BYTE)inportb(0x1F2);
    BYTE lo=(BYTE)inportb(0x1F3);
    BYTE mi=(BYTE)inportb(0x1F4);
    BYTE hi=(BYTE)inportb(0x1F5);

    printk("IDE probe %s: %s status=0x%x alt=0x%x err=0x%x sc=0x%x lba=%x:%x:%x\n",
           hd_drive_name(drive), stage, st, ast, er, sc, hi, mi, lo);
}

/*
 * Early storage probing can run while IRQ0 delivery is deliberately limited.
 * Do not make ATA timeouts depend solely on GetTickCount(): always keep a
 * bounded port-I/O spin count as a second clock.
 */
static int hd_probe_timeout(DWORD start, DWORD spins)
{
    if((DWORD)(GetTickCount()-start) >= HD_IDENTIFY_TIMEOUT_MS) return 1;
    if(spins >= HD_IDENTIFY_SPIN_LIMIT) return 1;
    return 0;
}

static void hd_discard_identify_data(void)
{
    int i;
    BYTE st=hd_probe_status();
    if(!(st & HD_STATUS_BUSY) && (st & HD_STATUS_DRQ))
        for(i=0;i<256;i++) (void)inportw(0x1F0);
}

/*
 * Execute one ATA IDENTIFY DEVICE transfer.
 *
 * clean_taskfile != 0 follows the modern ATA probe sequence and clears the
 * count/LBA registers before ECh.  clean_taskfile == 0 intentionally mirrors
 * the original JTMOS sequence: drive/head select followed directly by ECh.
 * Some legacy emulators/controllers have historically worked only with the
 * latter, so GetHDParam() always has it as a compatibility fallback.
 */
static int hd_identify_once(HD *h, int drive, WORD *hdp, int clean_taskfile)
{
    int i;
    BYTE status;
    DWORD start,spins;
    HDPARAM *hh;

    if(h==NULL) return 1;

    outportb(0x1F6, drive ? 0xB0 : 0xA0);
    hd400ns();

    if(clean_taskfile)
    {
        outportb(0x1F2,0);
        outportb(0x1F3,0);
        outportb(0x1F4,0);
        outportb(0x1F5,0);
    }

    outportb(0x1F7,0xEC);
    hd400ns();

    status=hd_probe_status();
    if(status==0x00 || status==0xFF) return 1;

    start=GetTickCount();
    spins=0;
    while((status=hd_probe_status()) & HD_STATUS_BUSY)
    {
        if(hd_probe_timeout(start,spins++)) return 1;
        hd400ns();
    }

    if(status==0x00 || status==0xFF) return 1;

    /*
     * Do not reject a legacy ATA probe from stale LBA1/LBA2 values.
     * The original JTMOS probe never required these registers to be zero,
     * and BIOS/controller state may legitimately leave old values there.
     * ATAPI answering IDENTIFY DEVICE is distinguished by ERR/no DRQ below.
     */
    if(status & HD_STATUS_ERROR) return 1;

    start=GetTickCount();
    spins=0;
    for(;;)
    {
        status=hd_probe_status();
        if(status==0x00 || status==0xFF) return 1;
        if(!(status & HD_STATUS_BUSY))
        {
            if(status & HD_STATUS_ERROR) return 1;
            if(status & HD_STATUS_DRQ) break;
        }
        if(hd_probe_timeout(start,spins++)) return 1;
        hd400ns();
    }

    for(i=0;i<256;i++)
    {
        WORD w=inportw(0x1F0);
        if(hdp) hdp[i]=w;
    }

    if(hdp)
    {
        hh=(HDPARAM *)hdp;
        StrFix(hh->ModelNumber,40);
        StrFix(hh->FirmwareRev,8);
        StrFix(hh->SerialNumber,20);
    }

    return 0;
}

/* Detect drive(master or slave) on primary IDE channel. */
int hdDetect(HD *h)
{
    int i,registered=0;

    /*
     * First probe the controller in the state left by BIOS/boot loader.  This
     * preserves the behaviour of old JTMOS versions that successfully found
     * QEMU hda.  A software reset is recovery, not a prerequisite.
     */
    printk("IDE: probing primary ATA channel (BIOS state).\n");
    for(i=0;i<2;i++)
        if((registered=hdTryDevice(h,i))) break;

    if(!registered)
    {
        printk("IDE: initial IDENTIFY failed; resetting primary channel and retrying.\n");
        hdReset1();
        for(i=0;i<2;i++)
            if((registered=hdTryDevice(h,i))) break;
    }

    if(registered && hdPrimaryDetect(h)) registered=0;
    return registered;
}

void RecalculateTotalBlocks(HD *h)
{
#ifdef FORCE_BLOCKS
    h->n_blocks = FORCE_BLOCKS;
#else
    h->n_blocks = h->cylinders*h->heads*h->sectors;
#endif
}

/* Receive ATA IDENTIFY data. Returns zero on success. */
int GetHDParam(HD *h, int drive, WORD *hdp)
{
    if(h==NULL || (hdp!=NULL && sizeof(HDPARAM)!=512))
    {
        if(h==NULL) dprintk("GetHDParam: NULL drive structure.\n");
        else printk("IDE: internal HDPARAM size error: %d (expected 512).\n",
                    (int)sizeof(HDPARAM));
        return 1;
    }

    /*
     * Historical JTMOS/QEMU path first: select drive and issue ECh directly.
     * This is deliberately the first attempt because older JTMOS releases
     * detected the same hda configuration with precisely this sequence.
     */
    if(!hd_identify_once(h,drive,hdp,0))
    {
        printk("IDE probe %s: ATA IDENTIFY succeeded (legacy JTMOS sequence).\n",
               hd_drive_name(drive));
        return 0;
    }

    /* Clear any pending data phase before the standards-oriented retry. */
    hd_discard_identify_data();

    printk("IDE probe %s: legacy IDENTIFY failed; trying clean task-file sequence.\n",
           hd_drive_name(drive));
    if(!hd_identify_once(h,drive,hdp,1))
    {
        printk("IDE probe %s: ATA IDENTIFY succeeded (clean task-file).\n",
               hd_drive_name(drive));
        return 0;
    }

    hd_probe_dump(drive,"IDENTIFY failed in legacy and clean modes");
    return 1;
}

int hdTryDevice(HD *h, int selection)
{
    int tries;
    h->slave=selection;

    for(tries=0;tries<2;tries++)
    {
        if(!GetHDParam(h,h->slave,NULL)) return 1;
        /* Completely re-select the target before the second try. */
        outportb(0x1F6,h->slave ? 0xB0 : 0xA0);
        hd400ns();
    }
    return 0;
}

int StrFix(BYTE *s, int l)
{
    int i;
    DWORD v1,v2;
    for(i=0;i<(l-1);i+=2)
    {
        v1=s[i+0]; v2=s[i+1];
        s[i+0]=v2; s[i+1]=v1;
    }
    return 0;
}

int hdPrimaryDetect(HD *h)
{
    int i;

    h->blocksize=512;
    memset(&h->hp,0,sizeof(HDPARAM));
    if(GetHDParam(h,h->slave,(WORD *)&h->hp))
    {
        printk("IDE: parameter IDENTIFY failed for selected %s drive.\n",
               hd_drive_name(h->slave));
        return 1;
    }

    h->lbaMode = h->hp.mod.n_lba ? TRUE : FALSE;
    HD_SetLBAMode(h->lbaMode);
    h->n_lba=h->hp.mod.n_lba;

    if(h->lbaMode)
    {
        h->cylinders=1;
        h->heads=1;
        h->sectors=1;
        h->n_blocks=h->n_lba;
        if((DWORD)h->n_blocks>HD_LBA28_MAX_SECTORS)
            h->n_blocks=(int)HD_LBA28_MAX_SECTORS;
        h->units=1;
    }
    else
    {
        h->cylinders=h->hp.cylinders;
        h->heads=h->hp.heads;
        h->sectors=h->hp.sectors;
        RecalculateTotalBlocks(h);
        hdDetermineUnits(h);
    }

    if(h->n_lba || h->hp.cylinders)
    {
        for(i=0;i<40;i++) h->ModelNumber[i]=h->hp.ModelNumber[i];
        h->ModelNumber[i]=0;
        for(i=0;i<8;i++) h->FirmwareRev[i]=h->hp.FirmwareRev[i];
        h->FirmwareRev[i]=0;
        for(i=0;i<20;i++) h->SerialNumber[i]=h->hp.SerialNumber[i];
        h->SerialNumber[i]=0;

        printk("HD parameters: ");
        if(h->lbaMode)
            printk("[LBA MODE] %u LBA sectors (%uM)\n",
                   (DWORD)h->n_lba,((DWORD)h->n_lba*512UL)/(1024UL*1024UL));
        else
            printk("[CHS MODE] Cylinders=%d, Heads=%d, Sectors=%d\n",
                   h->cylinders,h->heads,h->sectors);
        printk("HD MODEL   : %s\n",h->ModelNumber);
        printk("HD SERIAL  : %s  ",h->SerialNumber);
        printk("HD FIRMREV : %s\n",h->FirmwareRev);
    }
    else
    {
        printk("Warning: IDENTIFY returned no usable LBA/CHS geometry.\n");
        return 1;
    }
    return 0;
}

void hdDetermineUnits(HD *h)
{
    if(h->n_blocks > (2*1024*768)) h->units=16;
    else if(h->n_blocks > (2*1024*256)) h->units=8;
    else if(h->n_blocks > (2*1024*80)) h->units=4;
    else if(h->n_blocks > (2*1024*20)) h->units=2;
    else h->units=1;
    printk("%s: 512 bytes units per block = %d\n",__FUNCTION__,h->units);
}
