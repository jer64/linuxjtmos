// ======================================================
// Internal Hard Disk Software Cache/Buffering System
// CHS ONLY CACHE - A SEPERATE CACHE WILL EXIST
// FOR NON-CHS DRIVES IN FUTURE, E.G. LBA32 ACCESS.
// (C) 2003-2004 by Jari Tuominen
// ======================================================
#include <stdio.h>
#include "hd.h"
#include "hdCache.h"
#include "hdCacheFlush.h"

//
static BYTE *tmp=NULL;
static int l_tmp=0;

// Flush everything to disk
void hdFlushWriteBack(void)
{
	int i,x,l,attempt,rv,verify_ok;
	HCE *h;

	if(!hdCacheActive || hdb==NULL || chd==NULL || chd->lbaMode)
		return;
	if(tmp==NULL)
	{
		l_tmp=chd->sectors*512+8192;
		tmp=malloc(l_tmp);
		if(tmp==NULL)
		{
			dprintk("hdFlushWriteBack: verification buffer allocation failed.\n");
			return; /* leave dirty entries dirty */
		}
	}

	for(i=0;i<hdb->n_e;i++)
	{
		h=hdb->e[i];
		if(h==NULL || h->isfree || !h->writeback)
			continue;
		if(!isValidCHS(chd,h->c,h->h,1) || h->buf==NULL || h->l_buf<chd->sectors*512)
		{
			dprintk("hdFlushWriteBack: corrupt cache entry %d discarded (C=%d H=%d).\n",i,h->c,h->h);
			h->writeback=FALSE; h->isfree=TRUE;
			continue;
		}

		verify_ok=FALSE;
		for(attempt=0;attempt<3 && !verify_ok;attempt++)
		{
			rv=hdSectorRW(chd,h->buf,h->l_buf,h->c,h->h,1,chd->slave,WRITE,chd->sectors);
			if(rv) { dprintk("IDE: cache write failed entry=%d attempt=%d rv=%d.\n",i,attempt+1,rv); continue; }
			memset(tmp,0x55,l_tmp);
			rv=hdSectorRW(chd,tmp,l_tmp,h->c,h->h,1,chd->slave,READ,chd->sectors);
			if(rv) { dprintk("IDE: verify read failed entry=%d attempt=%d rv=%d.\n",i,attempt+1,rv); continue; }
			verify_ok=TRUE;
			for(x=0;x<(chd->sectors*512);x++)
				if(h->buf[x]!=tmp[x]) { verify_ok=FALSE; break; }
		}
		if(!verify_ok)
		{
			/* Preserve the dirty entry so a later flush can retry; never loop forever. */
			dprintk("IDE: write verification failed after 3 attempts; cache remains dirty.\n");
			chd->fault++;
			continue;
		}
		h->writeback=FALSE;
		h->isfree=TRUE;
		h->c=h->h=h->s=-1;
	}
}



