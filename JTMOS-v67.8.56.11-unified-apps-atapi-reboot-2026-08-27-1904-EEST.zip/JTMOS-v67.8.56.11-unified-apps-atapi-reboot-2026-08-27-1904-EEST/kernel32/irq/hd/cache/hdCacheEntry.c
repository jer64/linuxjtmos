// ======================================================
// Internal Hard Disk Software Cache/Buffering System
// CHS ONLY CACHE - A SEPERATE CACHE WILL EXIST
// FOR NON-CHS DRIVES IN FUTURE, E.G. LBA32 ACCESS.
// (C) 2003 by Jari Tuominen
//
// hdArrangeFreeEntry might behave strangely (BUG !!).
// ======================================================
#include <stdio.h>
#include "hd.h"
#include "hdCache.h"
#include "hdCacheEntry.h"

//
void hdWipeCache(HCDB *h)
{
	int i,i2,l,c;
	static HCE *sort[1000];
	HCE *e1,*e2;

	//--------------------------------------------------
	// Get amount
	l = h->n_e;

	//--------------------------------------------------
	for(i=0; i<l; i++)
	{
		h->e[i]->isfree = TRUE;
	}
}

// Get more entries free on cache, use prioritizing
// (otherwise all of entries would be freed)
void hdArrangeMoreFreeEntries(HCDB *h)
{
	int i,i2,l,c;
	static HCE *sort[1000];
	HCE *e1,*e2;

	//
//	panic(__FUNCTION__);

	//--------------------------------------------------
	// We need to flush writeback cache first
	hdFlushWriteBack();
	hdWipeCache(h);
	return;
}

// Arrange a new free entry by using various methods
int hdArrangeFreeEntry(void)
{
	int i,i2;
	HCE *h;

        // Check for corruption
        CORCHECK

	//
	while(1)
	{
		// Find for already free entry
		for(i=0; i<hdb->n_e; i++)
		{
			h = hdb->e[i];
			if(h->isfree==TRUE)	return i;
		}

		// Arrange more free entries
		hdArrangeMoreFreeEntries(hdb);
	}
}

// Search for existance of specified track in the cache
HCE *hdFindTrackFromCache(int C, int H)
{
	int i,i2;
	HCE *h;

        // Check for corruption
        CORCHECK

	//
	for(i=0; i<hdb->n_e; i++)
	{
		// Get entry
		h = hdb->e[i];

		//
		if(h->isfree==FALSE)
		{
			if(	h->c==C &&
				h->h==H		)
			{
				return h;
			}
		}
	}
	return NULL;
}



