////////////////////////////////////////////////////////////////////////////////////////////
// hdService.c
// IDE hard disk driver service.
// (C) 2004 Jari Tuominen.
////////////////////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <jtmos/dcpacket.h>
#include "hd.h"
#include "hdService.h"

////////////////////////////////////////////////////////////////////////////////////////////
//
static char hdReady=FALSE;

//
// int hdDeviceCall(int n_call,
//        int p1,int p2,int p3,int p4,
//        void *po1,void *po2)

//
#ifdef JTMOSKERNEL
////////////////////////////////////////////////////////////////////////////////////////////
//
int hd_init(void)
{
	//
	hdReady = FALSE;
	
       // HW INIT
       // Detect HD
       if( hw_hd_init() )
       {
		if(hd_register_device()==0)
		{
			printk("IDE: hda registered (%s, %d blocks of %d bytes).\n",
			       chd->lbaMode ? "LBA28" : "CHS",
			       chd->n_blocks/chd->units, chd->blocksize*chd->units);
		}
		else
			printk("IDE: ATA disk identified, but hda device registration failed.\n");
	}
	else printk("IDE: no primary ATA hard disk detected after legacy+clean IDENTIFY retries.\n");
	
	//
	hdReady = TRUE;
	
	//
	return 0;
}
#endif

