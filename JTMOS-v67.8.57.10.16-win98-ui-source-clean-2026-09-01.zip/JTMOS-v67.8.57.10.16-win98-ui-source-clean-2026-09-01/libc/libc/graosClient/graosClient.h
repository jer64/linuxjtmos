#ifndef __INCLUDED_GRAOSCLIENT_H__
#define __INCLUDED_GRAOSCLIENT_H__

//
#define GRAOS_SERVER_PID_NAME	"guiserver"

//
void graosCheck(void);
int getGraosPID(void);
int waitGraosAnswer(void);
int createWindow(int x,int y,
                int width,int height,
                const char *caption,
		int type);
int closeWindow(int wid);
int refreshWindow(int wid);
int addFrameBuffer(int wid,
        BYTE *buf, int x, int y,
        int width, int height, int bpp,
	int type, int terID);
int createButton(int wid,
        int x1,int y1,int x2,int y2,
        int type,
        const char *caption);
int createButtonStyled(int wid,
        int x1,int y1,int x2,int y2,
        int id,int style,
        const char *caption);

/* Non-interactive text label widget. Coordinates are window-relative. */
int createLabel(int wid,int x,int y,int width,int height,int id,
        int fg,int bg,int align,const char *text);
int setLabelText(int wid,int id,const char *text);
int setLabelStyle(int wid,int id,int fg,int bg,int align);
int removeLabel(int wid,int id);
int createTextBox(int wid,int x,int y,int width,int height,int id,int maxlen,const char *text);
int setTextBoxText(int wid,int id,const char *text);
int getTextBoxText(int wid,int id,char *text,int cap);
int removeTextBox(int wid,int id);

#endif


