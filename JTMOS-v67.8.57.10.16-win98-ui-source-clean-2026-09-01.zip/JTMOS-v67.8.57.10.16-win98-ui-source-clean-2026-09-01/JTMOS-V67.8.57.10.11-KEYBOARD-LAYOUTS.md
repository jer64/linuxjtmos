# JTMOS V67.8.57.10.11 — English and Finnish keyboard layouts

## Default

JTMOS now boots with **English (US)** keyboard layout by default.

At the SMSH prompt:

    keymap
    keymap english
    keymap finnish

`kbd` is an alias for `keymap`. Short names `en`, `us` and `fi` are also
accepted by the kernel API.

## Layout implementation

The old Finnish-specific condition chain in `scanasc.c` has been replaced by
explicit scan-code-set-1 tables in `drivers/keyboard/keymap.c`:

- English (US): standard US number/punctuation rows, QWERTY letters.
- Finnish: QWERTY + å/ä/ö, Finnish punctuation and common AltGr symbols.
- Finnish national characters use ISO-8859-1 bytes to match the current JTMOS
  byte-oriented terminal/font path.
- Caps Lock affects alphabetic keys only. Shift+Caps uses XOR semantics.
- Finnish dead-key positions currently emit spacing characters (`´`, `¨`, `^`)
  because compose/dead-key state is not yet implemented.

## AltGr / extended keyboard fix

The keyboard IRQ path now decodes 0xE0-prefixed scan-code-set-1 sequences.
This is required so Right Alt is `SCODE_RIGHTALT` (AltGr), not Left Alt.
The same decoder distinguishes the dedicated cursor/navigation block and
Right Control. Pause/Break's E1 sequence is consumed as a unit.

## Regression test

Run:

    ./tools/check_keyboard_layouts.sh

It verifies English default selection, Shift/Caps behavior, Finnish å/ä/ö,
Finnish punctuation, AltGr programming symbols, runtime layout switching and
invalid-layout rejection.
