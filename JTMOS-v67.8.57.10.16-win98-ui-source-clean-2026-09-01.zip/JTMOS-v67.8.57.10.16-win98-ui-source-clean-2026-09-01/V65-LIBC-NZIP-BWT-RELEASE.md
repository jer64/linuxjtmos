# JTMOS V65 LIBC / NZIP / SQA modernization release

Date: 2026-08-22

This V65 source release consolidates the clean-build, dual-floppy/FDC, plain-PID,
external-application ABI, userspace LIBC, NZIP and SQA/SQARC work.

## Build

From the release root:

    make clean
    make

A normal `make` is intended to build the kernel, userspace applications,
`install.img.nz`, `jtm32.img` and the 1.44 MiB `utils1440.img` extended utilities
floppy.  NASM, GCC multilib/-m32 support, GNU binutils, Perl and make are needed.
The obsolete `kernel32 imp` stage is not used.

## Userspace LIBC

* static ELF32/i386 application ABI retained (default entry 0x80004000)
* userspace heap is process-local instead of using the kernel kmalloc heap
* ELF process layout separates image, heap, guard page and stack
* fd 0/1/2 are stdin/stdout/stderr; normal files start at fd 3
* userspace pointers are translated/validated at syscall boundaries
* buffered stdio and improved printf/scanf/string/memory/stdlib/environment paths
* errno/error propagation improvements
* compiler runtime support for freestanding 64-bit integer arithmetic
* plain PID process model is used in the active V65 path
* DJGPP-compatible IRQ/DMA bridge from the earlier V65 work is retained

## NZIP modernization

The historical format remains readable:

* 0xFCE3 char packer / RLE
* 0xFCE4 sequence/back-reference compressor
* 0xFCEE end marker
* 0xFCEF escaped marker-looking literal pair

V65 adds codec 0xFCE5:

    BWT -> Move-to-Front -> zero-run coding -> CRC32

BWT is block based (16 KiB).  Default `nzip file` / `nzip --auto file` compares
the legacy representation and BWT for every block.  BWT is selected first when
it is smaller; otherwise the legacy codec wins.  A single .nz stream may mix
all codecs.

Modes:

    nzip --auto file
    nzip --legacy file
    nzip --bwt file
    nzip -d file.nz

The decoder also recognizes the short-lived development end marker 0xFEEE for
recovery, but new files always emit the historical 0xFCEE marker.

## SQA / SQARC modernization

* SQARC520 wire format retained
* fixed 44-byte little-endian directory entries are encoded field-by-field
* no raw C-structure serialization assumptions
* stronger bounds, truncation, checksum and write-error checks
* portable host sqarc recursively walks input itself (no find/cat shell pipeline)
* deterministic filename ordering for reproducible archives
* streaming file copying and safer pathname handling
* SMSH `sqa` builtin remains present

## Validation performed in this release workspace

* LIBC `make check`: PASS for application and kernel profiles
* header smoke tests: PASS with -Werror
* static application link smoke: PASS
* kernel LIBC relocatable link smoke: PASS
* nzip.bin, unz.bin and sqa.bin: static ELF32/i386 builds PASS
* selected kernel objects (LaunchApp + nzip/sqa/sqarc): compile PASS
* NZIP BWT/legacy AUTO round-trip on 1,567,361-byte install image: byte-identical
* AUTO result: 444,252 bytes, 23 BWT blocks + 73 legacy blocks
* deterministic host SQARC test: two builds byte-identical
* release-layout check: PASS

The build environment used for final packaging does not contain NASM or QEMU,
so a complete fresh kernel/boot image and runtime boot were not re-run here.
The source tree is prepared so the intended final validation on the JTMOS
Ubuntu development machine is simply `make clean && make` followed by QEMU.
