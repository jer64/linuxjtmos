# JTMOS V67.8.57.10.15 — CBMVM 0.7 SYS / MOS 6502/6510

This release fixes real C64/C128 PRGs whose BASIC bootstrap uses token `$9E` (`SYS`).

## Added

- BASIC `SYS address` execution.
- Cooperative NMOS 6502/6510 machine-code mode.
- Documented 6502 instruction set plus common C64 undocumented opcodes.
- 6510 `$0000/$0001` RAM/ROM/I/O banking behavior needed by self-unpacking PRGs.
- Separate 1 KiB C64 color RAM under `$D800-$DBFF`.
- VIC-II raster timing/IRQ basis and PAL/NTSC frame progression.
- CIA1/CIA2 timer and interrupt-mask basics plus keyboard matrix.
- ROM-free KERNAL service traps for a small set of common calls.
- VIC-II standard/multicolor text, hires/multicolor bitmap and sprite frame rendering.
- Same machine-code graphics path on Linux/SDL2 and native JTMOS/GraOS.

## Dictator regression

The supplied Dictator hexdump begins with `10 SYS 2061`; machine code starts at `$080D`. The previous CBMVM stopped immediately on unsupported BASIC token `$9E`. CBMVM 0.7 enters the 6510 core instead. The restored user PRG was smoke-tested for tens of millions of emulated CPU cycles without a BASIC-token or illegal-opcode failure.

The compatibility core is not cycle-exact and does not bundle copyrighted Commodore ROM images. Exact VIC bad-line/raster effects, complete CIA TOD/serial behavior and SID synthesis remain future accuracy work.
