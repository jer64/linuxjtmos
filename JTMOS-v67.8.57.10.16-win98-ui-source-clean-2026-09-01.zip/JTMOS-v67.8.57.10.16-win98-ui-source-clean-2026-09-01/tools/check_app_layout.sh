#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
CANON=$(readlink -f libc/apps)
for p in apps graos-host/apps tools/apps kernel32/apps graos-host/filer/JTMOS_GraOS_Filer_Explorer_2026/apps; do
    [ -L "$p" ] || { echo "app layout: $p must be a symlink" >&2; exit 1; }
    [ "$(readlink -f "$p")" = "$CANON" ] || { echo "app layout: $p does not resolve to libc/apps" >&2; exit 1; }
done
[ -f libc/apps/gui/terminal.c ]
[ -f libc/apps/gui/controlpanel.c ]
[ -f libc/apps/gui/launcher.c ]
[ -f libc/apps/filer.c ]
echo "canonical libc/apps layout: PASS"
