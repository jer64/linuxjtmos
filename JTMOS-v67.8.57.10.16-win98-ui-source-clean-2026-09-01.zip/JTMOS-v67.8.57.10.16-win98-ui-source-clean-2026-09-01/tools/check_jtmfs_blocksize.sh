#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
cd "$ROOT"
! grep -RIn --include='*.c' --include='*.h' 'System area length in 512 bytes blocks' kernel32/fs/jtmfs
! grep -RIn --include='*.c' 'FAT_INFO_BLOCK_OFFS/getblocksize' kernel32/fs/jtmfs
grep -q 'FAT_INFO_BYTE_OFFS' kernel32/fs/jtmfs/jtmfat.h
grep -q 'inf->block_size=(DWORD)blocksize' kernel32/fs/jtmfs/createfat.c
grep -q 'jtmfat_info_location' kernel32/fs/jtmfs/jtmfat.c
grep -q 'fsgeom' kernel32/sh/sh.c
echo 'JTMFS block-size/layout static checks: PASS'
