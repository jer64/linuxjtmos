#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

# V67.8.5: there must be exactly one kernel source tree.
[ -L tools/kernel32 ] || { echo "check: tools/kernel32 must be a symlink" >&2; exit 1; }
[ "$(readlink tools/kernel32)" = "../kernel32" ] || { echo "check: tools/kernel32 must point to ../kernel32" >&2; exit 1; }
[ "$(readlink -f tools/kernel32)" = "$(readlink -f kernel32)" ] || { echo "check: tools/kernel32 does not resolve to canonical kernel32" >&2; exit 1; }
! grep -Eq '^([[:space:]]*)\$\(MAKE\)[[:space:]]+-C[[:space:]]+kernel32[[:space:]]+imp([[:space:]]|$)' Makefile || {
    echo "check: obsolete kernel32 imp target call still present" >&2; exit 1;
}
grep -q '^image:' Makefile

grep -q '^default: image rootimage utilscdrom' Makefile
grep -q '^linkit: image' Makefile
grep -q 'RD_DEFAULT_SIZE=[[:space:]]*65536' kernel32/init/keropt.c
grep -q 'rd_default_blocks_for_ram' kernel32/drivers/ramdisk/ramdisk.c
grep -q '\{"sqa", sqa_main\}' kernel32/sh/sh.c
grep -q 'install.img.nz' tools/build_install_image.sh
grep -q 'cp "$APPS/unz.bin" "$BOOTSTRAP/unz.bin"' tools/build_install_image.sh
grep -q 'cp tools/utilities.sqa utilities.iso' Makefile
grep -q '^utilscdrom: packages host-tools' Makefile
grep -q 'ROOT_CDROM=' run_jtmos_qemu.sh
grep -q 'ROOT_FLOPPY=' run_jtmos_qemu.sh
grep -q 'tools/utilities.sqa' jtm32-util.cfg
grep -q 'make image' Makefile || true
# V66 Kyber scheduler integration invariants.
[ -f kernel32/drivers/kyber.c ]
[ -f kernel32/drivers/kyber.h ]
[ -f kernel32/sh/kyberapp.c ]
grep -q '\{"kyber", kyber_app\}' kernel32/sh/sh.c
grep -q 'kyber_should_schedule' kernel32/drivers/driver_rw.c
grep -q 'kyber_barrier_begin' kernel32/drivers/driver_flush.c
grep -q 'kyber_barrier_begin' kernel32/drivers/driver_api.c
grep -q 'KYBER_READ_TARGET_US[[:space:]]*2000' kernel32/drivers/kyber.c
grep -q 'KYBER_WRITE_TARGET_US[[:space:]]*10000' kernel32/drivers/kyber.c
# V67 ELF32 ring-3 / multiprocess invariants.
grep -q '#define USER_CS.*SEG_APPCODE32.*3' kernel32/core/chiplevel/int.h
grep -q '#define USER_DS.*SEG_APPDATA32.*3' kernel32/core/chiplevel/int.h
grep -q 'appcode32, 0xFFFF,0,0,0xFA,0xCF,0' kernel32/core/chiplevel/int.c
grep -q 'appdata32, 0xFFFF,0,0,0xF2,0xCF,0' kernel32/core/chiplevel/int.c
grep -q 'pd\[512+i\] = ad|7' kernel32/core/cp/scheduler.c
grep -q 'flags = 1 | 4' kernel32/mm/mmap.c
grep -q 'APP_MIN_HEAP_SIZE' kernel32/core/cp/LaunchApp.h
grep -q '_createAppThread(USER_CS, USER_DS' kernel32/core/cp/LaunchApp.c
grep -q 'KillThreadEx(pid, KT_NO_THREAD_SWITCH)' kernel32/core/cp/LaunchApp.c
grep -q 'mm_clear_process_space(pid)' kernel32/core/chiplevel/threads.c
grep -q 'sizeof(TSSEG)-1' kernel32/core/chiplevel/tss.c
grep -q 't->iopb  = sizeof(TSSEG)' kernel32/core/chiplevel/tss.c
grep -q 's->flags = 0x80' kernel32/core/chiplevel/tss.c
grep -q 'launch_detail' kernel32/core/cp/centralprocess.h
grep -q 'sparse backing' kernel32/core/cp/LaunchApp.c
grep -q 'while(bytes >= required_bytes)' kernel32/core/cp/LaunchApp.c
grep -q 'mm_sparse_alloc' kernel32/mm/mmap.c
grep -q 'mm_sparse_change_owner' kernel32/mm/mmap.c
grep -q 'HEAP_BIN_COUNT' libc/libc/modern/alloc.c
grep -q 'void \*sbrk' libc/libc/modern/sbrk.c

# V67.4 sparse-memory/libc/GraOS build + utilities packaging invariants.
grep -q 'LC_ALL=C readelf' libc/apps/app-common.mk
grep -q 'LC_ALL=C readelf' libc/apps/Makefile
grep -q 'LC_ALL=C readelf' libc/apps/gui/Makefile
grep -q 'LC_ALL=C readelf' libc/libc/Makefile
grep -q 'GRAOS_VERSION "V37"' libc/apps/gui/graos.h
grep -q 'APPRAM_12288K' libc/apps/gui/graos.c
grep -q 'guiResource.o' libc/apps/gui/graos.mak
grep -q 'guiBmp.o' libc/apps/gui/graos.mak
grep -q 'guiChrome.o' libc/apps/gui/graos.mak
grep -q 'guiWelcome.o' libc/apps/gui/graos.mak
grep -q 'guiStartup.o' libc/apps/gui/graos.mak
[ -f libc/apps/gui/title_close98.raw ]
[ -f libc/apps/gui/title_minimize98.raw ]
[ -f libc/apps/gui/jtmos_poster.raw ]
[ "$(wc -c < libc/apps/gui/title_close98.raw)" -eq 784 ]
[ "$(wc -c < libc/apps/gui/title_minimize98.raw)" -eq 784 ]
[ "$(wc -c < libc/apps/gui/jtmos_poster.raw)" -eq 40960 ]
grep -q "libc/apps/\\*.bin" tools/build_install_image.sh
grep -q "source/build artifact leaked" tools/build_install_image.sh
grep -q 'CD_ONLY_FILES=' tools/build_install_image.sh
grep -q 'system_payload system-install.img' tools/build_install_image.sh
grep -q 'extended_bootstrap utilities.sqa' tools/build_install_image.sh
grep -q 'system_bootstrap utilsdisk.img' tools/build_install_image.sh
grep -q '1440 \* 1024' tools/build_install_image.sh
[ ! -f tools/utilsdisk.img ] || [ "$(wc -c < tools/utilsdisk.img)" -le $((1440 * 1024)) ]
[ ! -f tools/utilities.sqa ] || [ "$(wc -c < tools/utilities.sqa)" -gt 0 ]

# V67.4 dynamic physical-memory detection invariants.
! grep -q 'GRAOS_BOOT_TEST_RAM_MB' kernel32/settings.txt
grep -q 'call detect_e820' boot32/boot.asm
grep -q 'E820_HANDOFF_SIGNATURE' boot32/e820.inc
grep -q 'E820_HANDOFF_ADDR' kernel32/mm/scanmem.c
grep -q 'mm_database_size_for_region' kernel32/mm/mm.c
grep -q 'ALLOCATION_DATABASE_MIN_SIZE' kernel32/mm/mm.h

# V67.4 plain-PID / CP completion invariants. PID 0 is init only, never a
# successful thread allocation or userspace process result.
grep -q 'for(i=1; i<nr_threads; i++)' kernel32/core/chiplevel/threads.c
grep -q 'if(pid <= 0)' kernel32/core/chiplevel/threads.c
grep -q 'resultPending' kernel32/core/cp/centralprocess.h
grep -q 'centralprocess.isBusy || centralprocess.resultPending' kernel32/core/cp/centralprocess.c
grep -q 'process created, PID=%d.*created_pid' kernel32/core/cp/centralprocessMain.c

# V67.5 process-launch semantics.  SYS_cexec ECX=0 is background and ECX=1
# waits for child termination.  GraOS TERMINAL uses bgexecEx(), so reversing
# these flags freezes the GUI event loop until sqsh.bin exits.
grep -q '#define JTMOS_EXEC_BACKGROUND 0' libc/libc/include/jtmos/process.h
grep -q '#define JTMOS_EXEC_WAIT[[:space:]]*1' libc/libc/include/jtmos/process.h
grep -q 'jtmos_exec_ex(f,w,t,JTMOS_EXEC_WAIT)' libc/libc/modern/process_console.c
grep -q 'jtmos_exec_ex(f,w,t,JTMOS_EXEC_BACKGROUND)' libc/libc/modern/process_console.c
grep -q 'if(!scall_ecx)' kernel32/core/chiplevel/scs.c
grep -q 'WaitProcessTerminationInterruptible(pid)' kernel32/core/chiplevel/scs.c

# SMSH SQA support must remain present in both command front-end and extractor.
[ -f kernel32/sh/sqaMain.c ]
[ -f kernel32/sh/sqa.c ]
[ ! -f jtm32.img ] || [ "$(wc -c < jtm32.img)" -eq 1474560 ]
[ ! -f utilities.iso ] || [ $(( $(wc -c < utilities.iso) % 2048 )) -eq 0 ]

# V67.8 window-manager + shared widget invariants.
grep -q 'GRAOS_GSID_GETSTATS 10' libc/include/jtmos/graosprotocol.h
grep -q 'GRAOS_GSID_BUTTON 14' libc/include/jtmos/graosprotocol.h
grep -q 'guiCreateButtonEx' libc/apps/gui/windowFunc.c
grep -q 'type!=GRAOS_SURFACE_TERMINAL && !buf' libc/libc/modern/graos_compat.c
grep -q 'JtmosGraOSSetDesktopColor' libc/libc/modern/graos_compat.c
grep -q 'SYS_vgasetpalette.*122' libc/libc/include/jtmos/syscallcodes.h
grep -q 'scall_vgasetpalette' kernel32/core/chiplevel/scs.c
grep -q 'graos_shell_try_command' kernel32/sh/graos_shell.c
! grep -q 'snprintf' kernel32/sh/graos_shell.c
[ -f libc/apps/gui/terminal.c ]
[ -f libc/apps/gui/controlpanel.c ]
[ -f libc/apps/gui/launcher.c ]
[ -f libc/apps/gui/graosctl.c ]
[ -f libc/apps/gui/taskbar.c ]
[ -f libc/apps/gui/labeldemo.c ]
! grep -q 'kernel32/apps/gui' tools/build_install_image.sh
# Ring3 external applications must never leak into the native kernel object list.
TMP_AUTOGEN=${TMPDIR:-/tmp}/jtmos-autogen-app-isolation-$$.mak
trap 'rm -f "$TMP_AUTOGEN" kernel32/modules.generated.h' EXIT HUP INT TERM
( cd kernel32 && ./autogen.pl ) > "$TMP_AUTOGEN"
if grep -q 'apps/gui/' "$TMP_AUTOGEN"; then
    echo "release layout: libc/apps/gui leaked into kernel generated.mak" >&2
    exit 1
fi
rm -f "$TMP_AUTOGEN" kernel32/modules.generated.h
trap - EXIT HUP INT TERM

grep -q 'GRAOS_GSID_CREATELABEL 16' libc/include/jtmos/graosprotocol.h
grep -q 'GRAOS_GSID_SETLABELTEXT 17' libc/include/jtmos/graosprotocol.h
grep -q 'GRAOS_MAX_LABELS 32' libc/apps/gui/window.h
grep -q 'guiCreateLabel' libc/apps/gui/guiLabel.c
grep -q 'guiDrawLabel' libc/apps/gui/windowDraw.c
grep -q 'int createLabel' libc/libc/modern/graos_compat.c
grep -q 'createLabel' libc/apps/gui/controlpanel.c
grep -q 'createLabel' libc/apps/gui/launcher.c
grep -q 'createLabel' libc/apps/gui/terminal.c
grep -q 'createLabel' libc/apps/gui/taskbar.c

grep -q 'GRAOS_GSID_CREATEBITMAP 21' libc/include/jtmos/graosprotocol.h
grep -q 'GRAOS_GSID_POLLEVENT 24' libc/include/jtmos/graosprotocol.h
grep -q 'GRAOS_MAX_BITMAPS 8' libc/apps/gui/window.h
grep -q 'guiCreateBitmap' libc/apps/gui/guiBitmap.c
grep -q 'guiQueueWindowEvent' libc/apps/gui/windowFunc.c
grep -q 'JtmosGraOSPollEvent' libc/libc/modern/graos_compat.c
grep -q 'int createBitmap' libc/libc/modern/graos_compat.c
[ -f libc/apps/gui/bitmapdemo.c ]
[ -f libc/apps/gui/squirrel16.raw ]
[ "$(wc -c < libc/apps/gui/squirrel16.raw)" -eq 36864 ]

# V67.8 shared component base + window manager invariants.
grep -q 'typedef struct GRAOS_WIDGET' libc/include/jtmos/graosprotocol.h
grep -q 'GRAOS_WIDGET widget;' libc/apps/gui/window.h
grep -q 'GRAOS_WIDGET root;' libc/apps/gui/window.h
grep -q 'GRAOS_WINDOW_MINIMIZE_BUTTON 32' libc/include/jtmos/graosprotocol.h
grep -q 'GRAOS_GSID_WINDOW_MINIMIZED 27' libc/include/jtmos/graosprotocol.h
grep -q 'GRAOS_GSID_RESTOREWINDOW 30' libc/include/jtmos/graosprotocol.h
grep -q 'guiMinimizeWindow' libc/apps/gui/windowFunc.c
grep -q 'guiRestoreWindow' libc/apps/gui/windowFunc.c
grep -q 'draw_taskbar_windows' libc/apps/gui/guiDesktopDraw.c
grep -q 'taskbar_hit' libc/apps/gui/guiDesktopDraw.c
grep -q 'guiWidgetInit' libc/apps/gui/guiWidget.c
grep -q 'guiWidget.o' libc/apps/gui/graos.mak

echo "release layout checks: PASS"


# V67.8 TextBox widget invariants.
grep -q 'GRAOS_WIDGET_TEXTBOX' "$ROOT/libc/include/jtmos/graosprotocol.h" || { echo "check_release_layout: TextBox widget type missing" >&2; exit 1; }
grep -q 'GRAOS_GSID_CREATETEXTBOX' "$ROOT/libc/include/jtmos/graosprotocol.h" || { echo "check_release_layout: TextBox IPC missing" >&2; exit 1; }
grep -q 'guiTextBox.o' "$ROOT/libc/apps/gui/graos.mak" || { echo "check_release_layout: guiTextBox not linked into GraOS" >&2; exit 1; }
grep -q 'createTextBox' "$ROOT/libc/libc/modern/graos_compat.c" || { echo "check_release_layout: TextBox libc API missing" >&2; exit 1; }
grep -q 'textboxdemo' "$ROOT/libc/apps/gui/Makefile" || { echo "check_release_layout: textboxdemo not in external apps" >&2; exit 1; }

# V67.8.13 delayed GraOS graphics invariants.
grep -q '^%define BOOT_VESA_GRAPHICS 0' "$ROOT/boot32/boot.asm" || { echo "check_release_layout: boot32 graphics must default off" >&2; exit 1; }
grep -q '^%define BOOT_VESA_GRAPHICS 0' "$ROOT/boot32/dosboot.asm" || { echo "check_release_layout: dosboot graphics must default off" >&2; exit 1; }
grep -q '#define SYS_graosgraphics[[:space:]]*124' "$ROOT/kernel32/core/chiplevel/syscallcodes.h" || { echo "check_release_layout: SYS_graosgraphics ABI missing" >&2; exit 1; }
grep -q 'scall_graosgraphics' "$ROOT/kernel32/core/chiplevel/scs.c" || { echo "check_release_layout: GraOS graphics syscall handler missing" >&2; exit 1; }
grep -q 'VBoxBgaPrepareGraOS' "$ROOT/kernel32/init/initsystem.c" || { echo "check_release_layout: delayed BGA prepare path missing" >&2; exit 1; }
grep -q 'VesaEarlyTextActivate' "$ROOT/kernel32/init/initsystem.c" || { echo "check_release_layout: boot-VESA text mirror missing" >&2; exit 1; }
grep -q 'VesaStartGraOSGraphics' "$ROOT/kernel32/init/vesa.c" || { echo "check_release_layout: delayed graphics activation missing" >&2; exit 1; }
grep -q 'SYS_graosgraphics' "$ROOT/libc/apps/gui/guiStart.c" || { echo "check_release_layout: GraOS does not own graphics transition" >&2; exit 1; }
grep -q 'if(!vesa_enabled)' "$ROOT/kernel32/init/initsystem.c" || { echo "check_release_layout: inactive prepared LFB suppresses VGA text maintenance" >&2; exit 1; }
[ "$(grep -R -l 'VBoxBgaSetupGraOS(' "$ROOT/kernel32" --include='*.c' | wc -l)" -eq 1 ] || { echo "check_release_layout: VBoxBgaSetupGraOS unexpectedly called from kernel boot" >&2; exit 1; }

echo "release layout checks including V67.8.13 delayed graphics: PASS"

# V67.8.34 canonical low-memory layout invariants.
[ -f kernel32/include/memory_layout.h ]
[ -f kernel32/include/memory_layout.inc ]
[ -f kernel32/include/memory_layout.ld ]

layout_c_value() {
    awk -v key="$1" '$1=="#define" && $2==key { print toupper($3); exit }' kernel32/include/memory_layout.h
}
layout_asm_value() {
    awk -v key="$1" '$1=="%define" && $2==key { print toupper($3); exit }' kernel32/include/memory_layout.inc
}
layout_ld_value() {
    awk -v key="$1" '$1==key && $2=="=" { gsub(/;/,"",$3); print toupper($3); exit }' kernel32/include/memory_layout.ld
}
for key in \
    JTMOS_KERNEL_LOAD_PHYS \
    JTMOS_KERNEL_BSS_BASE \
    JTMOS_KERNEL_EARLY_STACK_BOTTOM \
    JTMOS_KERNEL_EARLY_STACK_TOP \
    JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP \
    JTMOS_KERNEL_IDT_BASE \
    JTMOS_KERNEL_IDT_END \
    JTMOS_KERNEL_PAGE_DIRECTORY_PHYS \
    JTMOS_KERNEL_PAGE_TABLE_PHYS \
    JTMOS_KERNEL_PAGE_TABLE_BYTES \
    JTMOS_KERNEL_USER_PTES_PHYS \
    JTMOS_KERNEL_USER_PTES_BYTES \
    JTMOS_KERNEL_DYNAMIC_PHYS_START \
    JTMOS_KERNEL_MAP_START \
    JTMOS_KERNEL_MAP_END
do
    cv=$(layout_c_value "$key")
    av=$(layout_asm_value "$key")
    lv=$(layout_ld_value "$key")
    [ -n "$cv" ] && [ "$cv" = "$av" ] && [ "$cv" = "$lv" ] || {
        echo "check: memory layout constant mismatch for $key: C=$cv ASM=$av LD=$lv" >&2
        exit 1
    }
done

[ "$(layout_c_value JTMOS_KERNEL_EARLY_STACK_BOTTOM)" = "0X002E0000" ]
[ "$(layout_c_value JTMOS_KERNEL_EARLY_STACK_TOP)" = "0X002F0000" ]
[ "$(layout_c_value JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP)" = "0X002EFFF0" ]
[ "$(layout_c_value JTMOS_KERNEL_LOAD_PHYS)" = "0X00100000" ]
[ "$(layout_c_value JTMOS_KERNEL_BSS_BASE)" = "0X00200000" ]
[ "$(layout_c_value JTMOS_KERNEL_DYNAMIC_PHYS_START)" = "0X00B00000" ]

grep -q '%include "../kernel32/include/memory_layout.inc"' boot32/boot.asm
grep -q 'mov esp,JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP' boot32/boot.asm
grep -q 'JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP_ASM' kernel32/init/start.c
grep -q '#include "memory_layout.h"' kernel32/mm/paging.h
grep -q 'JTMOS_KERNEL_DYNAMIC_PHYS_START' kernel32/init/initsystem.c
grep -q '^INCLUDE include/memory_layout.ld' kernel32/kernel32.src
grep -q 'JTMOS_KERNEL_EARLY_STACK_BOTTOM' kernel32/kernel32.src
grep -q 'include/memory_layout.h' kernel32/autogen.pl
grep -q 'include/memory_layout.inc' kernel32/autogen.pl

# The canonical constants, not stale literals, must drive executable source.
! grep -Eq 'mov[[:space:]]+esp,0x001EFFF0' boot32/boot.asm boot32/dosboot.asm boot32/nwrkboot.asx \
    kernel32/core/int/exc.mac kernel32/core/int/llexc.asm \
    kernel32/core/lowlevel/exc.mac kernel32/core/lowlevel/llexc.asm \
    kernel32/core/chiplevel/exc.mac kernel32/core/chiplevel/llexc.asm \
    kernel32/core/iodma/exc.mac kernel32/core/iodma/llexc.asm
! grep -Eq 'return[[:space:]]+0x1F0000' kernel32/core/int/int.c kernel32/core/lowlevel/int.c \
    kernel32/core/chiplevel/int.c kernel32/core/iodma/int.c
! grep -q 'if(ad != 0x00A00000)' kernel32/init/initsystem.c
! grep -q 'ASSERT(_ebss <= 0x1E0000' kernel32/kernel32.src kernel32/dosker32.src

echo "release layout checks including V67.8.34 canonical memory layout: PASS"

# V67.8.35 early-syscall/checksum handoff invariants.
grep -q 'boot_kernel_checksum_expected_early' kernel32/init/start.c
grep -q 'boot_kernel_checksum_measured_early' kernel32/init/start.c
grep -q 'boot_drive_early' kernel32/init/start.c
grep -q 'System Call initialization returned safely' kernel32/init/initsystem.c
grep -q 'thread_type\[0\]=THREAD_TYPE_KERNEL' kernel32/core/chiplevel/threads.c
grep -q 'if(!valid_pid(pid))' kernel32/core/chiplevel/scs.c
grep -q 'kernel32.bound.sha256' boot32pm/Makefile
grep -q 'boot32pm is stale' buildimage
# Kernel print() must not recurse through the syscall gate.
print_body=$(awk '
    /void print\(const char \*s\)/ { inside=1 }
    inside { print }
    inside && /^}/ { exit }
' kernel32/drivers/term/term.c)
printf '%s\n' "$print_body" | grep -q 'writetext'
! printf '%s\n' "$print_body" | grep -q 'scall(' || { echo "check_release_layout: kernel print recursively enters syscall gate" >&2; exit 1; }

echo "release layout checks including V67.8.35 early syscall/checksum hardening: PASS"

# V67.8.40 QEMU CPU default invariant.  Do not force a Core Duo model under
# TCG: the pc machine's default CPU is substantially faster for day-to-day
# JTMOS testing, while runtime CPUID dispatch still selects available features.
grep -q 'set -- qemu-system-i386 -machine pc -m 512 -vga std' "$ROOT/run_jtmos_qemu.sh" || { echo "check_release_layout: QEMU pc default launcher missing" >&2; exit 1; }
! grep -q -- '-cpu ' "$ROOT/run_jtmos_qemu.sh" || { echo "check_release_layout: run_jtmos_qemu.sh must not force a CPU model" >&2; exit 1; }

echo "release layout checks including V67.8.40 QEMU pc/default-CPU launcher: PASS"

# V67.8.37 default boot32pm nzip-kernel invariants.
grep -q '^%define BOOT32PM_NZIP_KERNEL 1' boot32pm/boot.asm
grep -q '^kernel-nz: host-tools kernel' Makefile
grep -q './tools/build_kernel_nz.sh' Makefile
grep -q '"$NZIP" --legacy "$RAW"' tools/build_kernel_nz.sh
grep -q '^boot: kernel-nz' Makefile
grep -q '^boot-legacy: kernel' Makefile
grep -q 'boot32pm/boot.bin' jtm32.cfg
grep -q 'kernel32/kernel32.bin.nz' jtm32.cfg
grep -q 'boot32/boot.bin' jtm32-legacy.cfg
grep -q 'kernel32/kernel32.bin[[:space:]]' jtm32-legacy.cfg
grep -q 'BOOT32PM_NZIP_KERNEL' boot32/bootmod.inc
grep -q '%include "kernelmeta.inc"' boot32/bootmod.inc
grep -q 'STREAM_SECTORS_PER_CHUNK[[:space:]]*equ 128' boot32/bootmod.inc
grep -q 'JTMOS_BOOT_NZIP_STAGING_PHYS' boot32/boot.asm
grep -q '^nzip_decompress_kernel32:' boot32/boot.asm
grep -q 'kernel_raw_bytes' boot32/boot.asm
grep -q 'kernel_nz_bytes' boot32/boot.asm
grep -q 'kernel text/data exceeds relocated 1 MiB image window' kernel32/kernel32.src
grep -q '1048576' boot32pm/Makefile
grep -q '1048576' boot32pm/Makefile
grep -q '^%define BOOT32PM_STREAM_KERNEL 1' boot32pm/boot.asm
grep -q 'sha256sum kernel32/kernel32.bin kernel32/kernel32.bin.nz' boot32pm/Makefile
grep -q 'sha256sum -c boot32pm/kernel32.bound.sha256' buildimage
grep -q 'BOOT32_RAW_RELOCATE_KERNEL_1M=1' boot32/Makefile
! grep -q -- '-Ttext 0x10000' kernel32/settings.txt || { echo "check: relocated kernel still forced to old -Ttext 0x10000" >&2; exit 1; }
grep -q 'JTMOS_KERNEL_BSS_BASE + 0x00000500UL' kernel32/init/start.c
grep -q 'JTMOS_KERNEL_BSS_BASE + 0x00100500UL' kernel32/init/start.c
echo "release layout checks including V67.8.37 boot32pm nzip kernel loader: PASS"

# V67.8.57.9 MS-DOS 64 KiB protected-mode nzip stream invariants.
grep -q '^%define DOS_READ_HALF_CHUNK 0x8000' boot32/dosboot.asm
grep -q '^%define DOS_CHUNK_BYTES[[:space:]]*0x10000' boot32/dosboot.asm
grep -q '^pmode_stream_copy32:' boot32/dosboot.asm
grep -q '^nzip_decompress_kernel32:' boot32/dosboot.asm
grep -q 'mov edi,JTMOS_KERNEL_LOAD_PHYS' boot32/dosboot.asm
grep -q 'JTMOS_BOOT_NZIP_STAGING_PHYS' boot32/dosboot.asm
grep -q 'test eax,0x00020000' boot32/dosboot.asm
grep -q '^dosboot: kernel-nz' Makefile
grep -q '^kernel32.nz: ../kernel32/kernel32.bin.nz' boot32/Makefile
echo "release layout checks including V67.8.57.9 DOS 64K nzip loader: PASS"

# V67.8.41 serial-only debug/report invariants.
for profile in int lowlevel chiplevel iodma; do
    grep -q 'debug level 1 is a serial-only diagnostic channel' "kernel32/core/$profile/dfunc.c"
    grep -Eq 'debug level 2/report output is serial-only|Report output is intentionally routed only to the serial debug line' "kernel32/core/$profile/debug.c"
    dbody=$(awk '/int dprintk\(const char \*fmt, \.\.\.\)/ { inside=1 } inside { print } inside && /^}/ { exit }' "kernel32/core/$profile/dfunc.c")
    rbody=$(awk '/int ReportMessage\(const char \*fmt, \.\.\.\)/ { inside=1 } inside { print } inside && /^}/ { exit }' "kernel32/core/$profile/debug.c")
    printf '%s\n' "$dbody" | grep -q 'DebugSerialWrite(tmp)'
    printf '%s\n' "$rbody" | grep -q 'DebugSerialWrite(tmp)'
    ! printf '%s\n' "$dbody" | grep -Eq '^[[:space:]]*printk[[:space:]]*\(' || { echo "check_release_layout: dprintk still writes console in $profile" >&2; exit 1; }
    ! printf '%s\n' "$dbody" | grep -Eq '^[[:space:]]*WriteSystemLog[[:space:]]*\(' || { echo "check_release_layout: dprintk still writes system log in $profile" >&2; exit 1; }
    ! printf '%s\n' "$rbody" | grep -Eq '^[[:space:]]*printk[[:space:]]*\(' || { echo "check_release_layout: ReportMessage still writes console in $profile" >&2; exit 1; }
    ! printf '%s\n' "$rbody" | grep -Eq '^[[:space:]]*WriteSystemLog[[:space:]]*\(' || { echo "check_release_layout: ReportMessage still writes system log in $profile" >&2; exit 1; }
done

echo "release layout checks including V67.8.41 serial-only debug/report: PASS"

# V67.8.42 iview baseline-JPEG/GraOS framebuffer invariants.
[ -f libc/apps/iview/iview.c ]
[ -f libc/apps/iview/jpegdec.c ]
[ -f libc/apps/iview/jpegdec.h ]
[ -f libc/apps/iview/mcga_palette.h ]
[ -f libc/apps/iview/README.txt ]
grep -q 'SPECIAL_APPS := .*iview' libc/apps/Makefile
grep -q 'GRAOS_SURFACE_BITMAP' libc/apps/iview/iview.c
grep -q 'jpgDecode' libc/apps/iview/iview.c
grep -q 'GRAOS_RGB' libc/apps/iview/iview.c
grep -q 'GRAOS_BPP' libc/apps/iview/iview.c
grep -q 'iview.bin' tools/build_release_apps.sh
grep -A28 '^CD_ONLY_FILES=' tools/build_install_image.sh | grep -q '^iview.bin$'
# Small native widget demos are part of the normal B: root payload now; they
# must be launchable from the Welcome/Applications UI without utilities.iso.
for f in labeldemo.bin bitmapdemo.bin textboxdemo.bin; do
    ! grep -A28 '^CD_ONLY_FILES=' tools/build_install_image.sh | grep -q "^${f}$" || { echo "check_release_layout: $f unexpectedly CD-only" >&2; exit 1; }
done
! grep -q 'JtmosGraOSSetPalette' libc/apps/iview/iview.c || { echo "check_release_layout: iview must not change global GraOS palette" >&2; exit 1; }

echo "release layout checks including V67.8.42 GraOS JPEG iview: PASS"


# V67.8.56 ELF32 fork() ABI invariants.
[ -f kernel32/core/cp/fork.c ]
[ -f libc/apps/fork.c ]
[ -f libc/apps/fork.mak ]
grep -q '#define SYS_fork[[:space:]]*127' kernel32/core/chiplevel/syscallcodes.h
grep -q '#define SYS_fork[[:space:]]*127' libc/libc/include/jtmos/syscallcodes.h
grep -q 'scall_fork' kernel32/core/chiplevel/scs.c
awk '/DWORD nr_scall_func =/ { v=$4; gsub(/;/,"",v); if ((v+0) >= 128) ok=1 } END { exit ok?0:1 }' kernel32/core/chiplevel/scs.c
grep -q 'mm_clone_process_space' kernel32/mm/mmap.c
grep -q 'FpuForgetThread' kernel32/core/chiplevel/coprocessor_not_found.c
grep -q 'FpuForgetThread(child)' kernel32/core/cp/fork.c
grep -q 'pid_t fork(void);' libc/libc/include/unistd.h
grep -q '^\.global fork' libc/libc/modern/syscall_app.S
grep -q 'filetest fork hello' libc/apps/Makefile

echo "release layout checks including V67.8.56 fork ABI: PASS"

# V67.8.56.1 Filer startup memory invariant.
grep -q 'SYSMEMREQ(APPRAM_4096K)' libc/apps/filer.c
grep -q 'out of memory allocating.*framebuffer' libc/apps/filer.c
grep -q 'GraOS createWindow failed' libc/apps/filer.c
grep -q 'GraOS addFrameBuffer failed' libc/apps/filer.c
echo "release layout checks including V67.8.56.1 Filer startup memory fix: PASS"
# V67.8.56.2 runtime GraOS geometry/taskbar invariant.
grep -q 'GRAOS_GSID_GETSCREENINFO 39' libc/include/jtmos/graosprotocol.h
grep -q 'JtmosGraOSGetScreenInfo' libc/include/jtmos/graos.h
grep -q 'case GRAOS_GSID_GETSCREENINFO' libc/apps/gui/guiServer.c
grep -q 'GRAOS_WINDOW_TASKBAR 128' libc/include/jtmos/graosprotocol.h
grep -q 'bottom=(GRAOS_IS_TASKBAR_WINDOW(type))?v->height' libc/apps/gui/wdb.c
grep -q 'JtmosGraOSGetScreenInfo' libc/apps/taskbar.c
! grep -q 'createWindow(0,480-30' libc/apps/taskbar.c
echo "release layout checks including V67.8.56.2 runtime taskbar geometry: PASS"
# V67.8.56.3 Filer event-loop/lifecycle invariant.
grep -q 'JtmosGraOSPollEvent(window_id,&ev)' libc/apps/filer.c
! grep -q 'while(receiveMessage(&m))' libc/apps/filer.c
! grep -q 'static int decode_event' libc/apps/filer.c
grep -q 'ev.wid>=0 && ev.wid!=window_id' libc/apps/filer.c
grep -q 'Paint once before polling' libc/apps/filer.c
echo "release layout checks including V67.8.56.3 Filer event-loop fix: PASS"

# V67.8.56.4 external LIBC namespace invariant.
grep -q 'GRAOS_GSID_EXIT 4' libc/include/jtmos/graosprotocol.h
grep -q 'GRAOS_WINDOW_STANDARD' libc/include/jtmos/graosprotocol.h
grep -q 'GRAOS_SURFACE_BITMAP 2' libc/include/jtmos/graosprotocol.h
grep -q 'GRAOS_CMD_MAGIC 0xFCE2E37BUL' libc/include/jtmos/graosprotocol.h
grep -q 'JTMOS_MB_PROTOCOL_GRAOS' libc/include/jtmos/msgbox.h
if grep -RInE '\b(FILER_GSID_|GSID_[A-Z0-9_]+|STANDARD_WINDOW|STANDARD_BUTTON|TASKBAR_WINDOW|TYPE_(TERMINAL_EMULATION|BITMAP_SCREEN)|WINDOW_(CLOSE_BUTTON|HAS_CAPTION|HAS_BORDER|AUTOCLEAR|MINIMIZE_BUTTON|TASKBAR|WELCOME_STYLE)|MB_PROTOCOL_GRAOS)\b' libc/apps libc/libc/modern libc/libc/graosClient --include='*.c' >/dev/null; then
  echo "check_release_layout: legacy unnamespaced GraOS/JTMOS ID remains in external LIBC C source" >&2
  exit 1
fi
echo "release layout checks including V67.8.56.4 external LIBC namespaces: PASS"

# V67.8.56.5 QEMU user-network IPv4 readiness invariant.
grep -q 'JNET_CFG_QEMU_USER_STATIC' kernel32/drivers/tcpip/jnet.h
grep -q 'JNET_ENETDOWN (-100)' kernel32/drivers/tcpip/jnet.h
grep -q 'jnet_configure_qemu_user_fallback' kernel32/drivers/tcpip/jnet.c
grep -q '0x52,0x54,0x00,0x12,0x34,0x56' kernel32/drivers/tcpip/jnet.c
grep -q '10,0,2,15' kernel32/drivers/tcpip/jnet.c
grep -q '10,0,2,2' kernel32/drivers/tcpip/jnet.c
grep -q '10,0,2,3' kernel32/drivers/tcpip/jnet.c
grep -q 'nc && nc->configured' kernel32/drivers/tcpip/networkControl.c
grep -q 'DHCP: failed (%d)' kernel32/drivers/tcpip/uipMain.c
grep -q 'Destination Host Unreachable (ARP)' kernel32/sh/networkapp.c
! grep -q 'DHCP: no lease, using static 10.0.0.5/24' kernel32/drivers/tcpip/uipMain.c
echo "release layout checks including V67.8.56.5 QEMU user-network IPv4 readiness: PASS"

# V67.8.56.6 NE2000 packet-RAM/TX invariant.
grep -q '^#define TX_PAGE 0x40$' kernel32/drivers/tcpip/ne2k.c
grep -q '^#define TX_PAGES 6$' kernel32/drivers/tcpip/ne2k.c
grep -q '^#define RX_START (TX_PAGE + TX_PAGES)$' kernel32/drivers/tcpip/ne2k.c
! grep -q '^#define TX_PAGE 0x20$' kernel32/drivers/tcpip/ne2k.c
grep -q 'regw(ISR,0x0a)' kernel32/drivers/tcpip/ne2k.c
grep -q 'if(isr&0x02)' kernel32/drivers/tcpip/ne2k.c
echo "release layout checks including V67.8.56.6 NE2000 TX/ring fix: PASS"

# V67.8.56.10: normal GraOS boot must hydrate /bin from the canonical sys:
# utilities payload; otherwise Welcome/Start buttons launch files that do not
# exist in the RAM root.
grep -q 'sqa_main(5,outer_argv)' kernel32/init/graos_boot.c
grep -q 'nzip_uncompress("/bin/install.img.nz","/bin/install.img")' kernel32/init/graos_boot.c
for f in graos.bin sqsh.bin filer.bin controlpanel.bin launcher.bin; do
    grep -q "\"/bin/$f\"" kernel32/init/graos_boot.c
done
# HDA close/sync durability must flush DIRDB -> FAT -> DAPI -> ATA.
grep -q 'dirdbFlushDNR(dnr)' kernel32/fs/jtmfs/publicapi/directfileaccess.c
grep -q 'driver_FlushDrive(dnr)' kernel32/fs/jtmfs/publicapi/directfileaccess.c
grep -q 'flags & (O_CREAT|O_TRUNC)' kernel32/fs/jtmfs/publicapi/directfileaccess.c
grep -q '{"sync", sync_app}' kernel32/sh/sh.c

# V67.8.56.10: durable sync must observe the block/device flush result.
grep -q 'int driver_FlushDrive(int dnr)' kernel32/drivers/driver_flush.c || { echo 'check: driver_FlushDrive must return status' >&2; exit 1; }
grep -q 'driver_FlushDrive(dnr)!=0' kernel32/fs/jtmfs/publicapi/directfileaccess.c || { echo 'check: syncdev must propagate device flush failures' >&2; exit 1; }

# Reboot durability: one held Ctrl+Alt+Del must not bypass system_reset().
grep -q 'reset_chord_latched' kernel32/drivers/keyboard/scanasc.c || fail "reboot chord must be edge-triggered"
grep -q 'reboot_now = TRUE' kernel32/drivers/keyboard/scanasc.c || fail "first reboot chord must request graceful reboot"
echo "release layout checks including V67.8.56.10 GraOS startup/HDA persistence: PASS"
