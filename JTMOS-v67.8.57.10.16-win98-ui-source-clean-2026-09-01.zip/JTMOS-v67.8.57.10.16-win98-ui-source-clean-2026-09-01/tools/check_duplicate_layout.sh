#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

fail() { echo "duplicate layout: $*" >&2; exit 1; }
check_link() {
    path=$1
    target=$2
    [ -L "$path" ] || fail "$path must be a symlink"
    [ "$(readlink "$path")" = "$target" ] || fail "$path -> $(readlink "$path"), expected $target"
    [ -e "$path" ] || fail "$path is a broken symlink"
}

# One canonical native kernel tree.
check_link tools/kernel32 ../kernel32

# One canonical Ring3 application tree.
check_link apps libc/apps
check_link tools/apps ../libc/apps
check_link kernel32/apps ../libc/apps
check_link graos-host/apps ../libc/apps
check_link graos-host/filer/JTMOS_GraOS_Filer_Explorer_2026/apps ../../../libc/apps

# kernel32/irq is a compatibility namespace.  Active drivers live in drivers/.
for d in floppy hd keyboard sb; do
    check_link "kernel32/irq/$d" "../drivers/$d"
done

# These three old names contained the same low-level tree and are excluded by
# autogen.pl.  Keep the include/compatibility paths but use chiplevel as source.
for d in int iodma lowlevel; do
    check_link "kernel32/core/$d" chiplevel
done

# Legacy external-driver history/cache snapshots are shared with the newer
# libc/drv copy.  Keep drv/* compatibility paths without another file copy.
check_link drv/hd/old ../../libc/drv/hd/old
check_link drv/hd/cache ../../libc/drv/hd/cache
check_link drv/tcp/old ../../libc/drv/tcp/old
check_link drv/slip/old ../../libc/drv/slip/old

# Host packaging carried a byte-identical copy of the native GraOS/Postman
# adapter overlay.  Keep graos-native-overlay as the one physical copy.
check_link graos-host/kernel32/sh/graos ../../../graos-native-overlay/graos
check_link graos-host/kernel32/sh/postman ../../../graos-native-overlay/postman

# Historical spelling retained for old developer commands.
check_link tools/gr gui

# Resolve every alias to its canonical location as a second-level guard.
canon_apps=$(readlink -f libc/apps)
for p in apps tools/apps kernel32/apps graos-host/apps graos-host/filer/JTMOS_GraOS_Filer_Explorer_2026/apps; do
    [ "$(readlink -f "$p")" = "$canon_apps" ] || fail "$p does not resolve to libc/apps"
done
[ "$(readlink -f tools/kernel32)" = "$(readlink -f kernel32)" ] || fail "tools/kernel32 does not resolve to kernel32"
for d in floppy hd keyboard sb; do
    [ "$(readlink -f "kernel32/irq/$d")" = "$(readlink -f "kernel32/drivers/$d")" ] || fail "irq/$d does not resolve to drivers/$d"
done
for d in int iodma lowlevel; do
    [ "$(readlink -f "kernel32/core/$d")" = "$(readlink -f kernel32/core/chiplevel)" ] || fail "core/$d does not resolve to core/chiplevel"
done
for p in graos postman; do
    [ "$(readlink -f "graos-host/kernel32/sh/$p")" = "$(readlink -f "graos-native-overlay/$p")" ] || fail "graos-host kernel32/sh/$p does not resolve to graos-native-overlay/$p"
done
for p in hd/old hd/cache tcp/old slip/old; do
    [ "$(readlink -f "drv/$p")" = "$(readlink -f "libc/drv/$p")" ] || fail "drv/$p does not resolve to libc/drv/$p"
done
[ "$(readlink -f tools/gr)" = "$(readlink -f tools/gui)" ] || fail "tools/gr does not resolve to tools/gui"

echo "canonical duplicate-directory layout: PASS"
