#!/bin/sh
set -eu
TOOLS=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$TOOLS/.." && pwd)
APPS="$ROOT/libc/apps"
GUI="$APPS/gui"
PAYLOAD="$TOOLS/install_payload"
BOOTSTRAP="$TOOLS/extended_bootstrap"
SYSTEM_PAYLOAD="$TOOLS/system_payload"
SYSTEM_BOOTSTRAP="$TOOLS/system_bootstrap"
MANIFEST="$PAYLOAD/UTILS-MANIFEST.txt"

[ -x "$TOOLS/sqarc" ] || { echo "build_install_image: tools/sqarc missing" >&2; exit 1; }
[ -x "$TOOLS/nzip" ] || { echo "build_install_image: tools/nzip missing" >&2; exit 1; }
[ -s "$APPS/unz.bin" ] || { echo "build_install_image: unz.bin missing" >&2; exit 1; }
[ -s "$APPS/sqa.bin" ] || { echo "build_install_image: sqa.bin missing" >&2; exit 1; }

rm -rf "$PAYLOAD" "$BOOTSTRAP" "$SYSTEM_PAYLOAD" "$SYSTEM_BOOTSTRAP"
mkdir -p "$PAYLOAD" "$BOOTSTRAP" "$SYSTEM_PAYLOAD" "$SYSTEM_BOOTSTRAP"
rm -f "$TOOLS/install.img" "$TOOLS/install.img.nz" \
      "$TOOLS/system-install.img" "$TOOLS/system-install.img.nz" \
      "$TOOLS/utilsdisk.img" "$TOOLS/utilities.sqa"

# Every built root userspace program belongs to the extended utilities payload.
APP_COUNT=0
for f in "$APPS"/*.bin; do
    [ -f "$f" ] || continue
    cp "$f" "$PAYLOAD/$(basename "$f")"
    APP_COUNT=$((APP_COUNT + 1))
done
[ "$APP_COUNT" -gt 0 ] || { echo "build_install_image: no libc/apps/*.bin programs found" >&2; exit 1; }

# GraOS runtime distribution.  Do NOT put source/build artifacts on the 1.44M
# utilities archive.  The whitelist deliberately includes only executable and
# runtime resource/config/help formats.  New GraOS runtime dependencies with a
# supported extension are picked up automatically.
GUI_COUNT=0
for f in "$GUI"/*; do
    [ -f "$f" ] || continue
    case "$f" in
        *.bin|*.raw|*.dat|*.cfg|*.hlp|*.txt|*.ini|*.fnt|*.font|*.pal|*.res|*.bmp|*.pcx)
            base=$(basename "$f")
            [ ! -e "$PAYLOAD/$base" ] || {
                echo "build_install_image: duplicate runtime basename: $base" >&2
                exit 1
            }
            cp "$f" "$PAYLOAD/$base"
            GUI_COUNT=$((GUI_COUNT + 1))
            ;;
        *.c|*.h|*.o|*.a|*.map|*.mak|*/Makefile|*/README)
            ;;
        *)
            # Unknown files are not silently shipped as runtime dependencies.
            ;;
    esac
done
[ -s "$PAYLOAD/graos.bin" ] || { echo "build_install_image: gui/graos.bin missing" >&2; exit 1; }

# Native GraOS clients are built and packaged from the canonical libc/apps/gui tree.
EXTGUI_COUNT=0
EXTGUI_RES_COUNT=0

# Runtime resources belonging to CLI-directory GraOS applications.
# sqfam.raw is installed with picture.bin so the windowed picture demo works from the normal root payload.
[ ! -f "$APPS/sqfam.raw" ] || cp "$APPS/sqfam.raw" "$PAYLOAD/sqfam.raw"

# Useful help/config scripts from the CLI app directory.
for f in "$APPS"/*.hlp "$APPS"/boot.sh "$APPS"/help.sh "$APPS"/setup.sh; do
    [ -f "$f" ] || continue
    cp "$f" "$PAYLOAD/$(basename "$f")"
done

# Runtime external-driver material currently shipped by the tree.  These are
# data/config artifacts only; kernel-owned boot-critical drivers remain kernel
# drivers until their userspace ABI ports are complete.
find "$ROOT/libc/drv" -type f \( -name '*.sys' -o -name '*.cfg' \) -print | while IFS= read -r f; do
    cp "$f" "$PAYLOAD/$(basename "$f")"
done

cat > "$PAYLOAD/DRIVERS.txt" <<'TXT'
JTMOS V67.8 driver notes
========================
FDC, Sound Blaster, Gravis UltraSound, IDE, serial and other boot-critical
hardware remain kernel drivers unless explicitly ported through the userspace
IRQ/DMA ABI.  irqdma.bin demonstrates the userspace IRQ/DMA interface.
TXT

# Record exactly what the compressed utilities payload carries.
{
    echo "JTMOS V67.8 extended utilities payload"
    echo "======================================="
    echo "libc/apps/*.bin programs: $APP_COUNT"
    echo "GraOS runtime files:      $GUI_COUNT"
    echo "External GraOS apps:      $EXTGUI_COUNT"
    echo "External GraOS resources: $EXTGUI_RES_COUNT"
    echo
    echo "Files:"
    (cd "$PAYLOAD" && find . -maxdepth 1 -type f -printf '%f\n' | LC_ALL=C sort)
} > "$MANIFEST"

# Hard release invariant requested for the utilities archive: no C/header/object
# or static-library/map/make fragments may leak into the runtime payload.
if find "$PAYLOAD" -maxdepth 1 -type f \( \
       -name '*.c' -o -name '*.h' -o -name '*.o' -o -name '*.a' -o \
       -name '*.map' -o -name '*.mak' -o -name 'Makefile' \) | grep -q .; then
    echo "build_install_image: source/build artifact leaked into runtime payload" >&2
    exit 1
fi

cat > "$PAYLOAD/DEMO-README.txt" <<'TXT'
JTMOS V67.8 extended applications + GraOS payload
=================================================
This payload contains every release-built libc/apps/*.bin program plus GraOS
runtime files (graos.bin and its data/resources; no .c/.h/.o build files).
It is transported inside install.img.nz on the utilities CD-ROM; the compact
core subset (including windowed GraOS demos) is also emitted on the B: root image.

Typical SMSH RAM-disk use:
  sqa cdrom       # ATAPI/QEMU -cdrom test path
  unz.bin


unz performs both stages:
  install.img.nz -> install.img -> SQA files
and removes the temporary install.img after successful extraction.
TXT

# ---------------------------------------------------------------------------
# System + CD-ROM utilities packaging
# ---------------------------------------------------------------------------
# install_payload is the complete distribution and is always placed on the
# ATAPI utilities/demo CD-ROM.  The boot floppy A: is boot-only.  The compact system archive is emitted for
# the separate 1.44 MiB B: root medium, so it is no longer constrained by the
# historical 800 KiB tail of the boot floppy.  Large demos/media/tests remain
# CD-ROM-only so the B: root image stays comfortably below 1.44 MiB.
#
# Keep this list conservative: anything removed here remains present in the
# complete CD-ROM payload below.
CD_ONLY_FILES="
iview.bin
mpeg1.bin
bgidemo.bin
stuntcar.bin
vgarawplay.bin
printtest.bin
keytest.bin
filetest.bin
malloctest.bin
performance.bin
hello.bin
talk.bin
writing.bin
"

# Create the reduced system payload from the already validated complete one.
cp -a "$PAYLOAD/." "$SYSTEM_PAYLOAD/"
MOVED_COUNT=0
for base in $CD_ONLY_FILES; do
    if [ -f "$SYSTEM_PAYLOAD/$base" ]; then
        rm -f "$SYSTEM_PAYLOAD/$base"
        MOVED_COUNT=$((MOVED_COUNT + 1))
    fi
done

# Replace the copied full manifest with an accurate system-payload manifest.
{
    echo "JTMOS V67.8 system utilities payload"
    echo "======================================"
    echo "CD-ROM-only files omitted from sys: $MOVED_COUNT"
    echo
    echo "Files present in the B: root/system payload:"
    (cd "$SYSTEM_PAYLOAD" && find . -maxdepth 1 -type f ! -name 'UTILS-MANIFEST.txt' -printf '%f\n' | LC_ALL=C sort)
    echo
    echo "Available on utilities.iso only:"
    for base in $CD_ONLY_FILES; do
        [ -f "$PAYLOAD/$base" ] && echo "$base"
    done
} > "$SYSTEM_PAYLOAD/UTILS-MANIFEST.txt"

# Also document the split on the full utilities disk.
cat > "$PAYLOAD/EXTENDED-ONLY.txt" <<'TXT'
JTMOS V67.8 extended utilities
================================
The A: boot floppy carries no sys: payload.  The normal core system lives on
the separate 1.44 MiB B: root image.  Windowed GraOS demos (Snake, Plasma,
Plasma II, VGA Plasma, Picture/Squirrel Family, Label/Bitmap/TextBox demos)
are core applications and are installed in /bin.  Only larger media and
self-test programs remain utilities.iso-only:

iview.bin
mpeg1.bin
bgidemo.bin
stuntcar.bin
vgarawplay.bin
printtest.bin
keytest.bin
filetest.bin
malloctest.bin
performance.bin
hello.bin
talk.bin
writing.bin

The normal system disk keeps GraOS 32-bpp RGBA cursor, chrome and startup assets; the desktop background is rendered procedurally.
Core Terminal, Launcher, Control Panel, Filer, Editor, Task Manager, SQSH and
recovery/install utilities also remain in sys:.
TXT

cd "$TOOLS"

# Full CD-ROM payload -> install.img.nz -> utilities.sqa.
JTMOSDIR="$ROOT" ./sqarc install_payload install.img
INSTALL_BYTES=$(wc -c < install.img)
./nzip --auto install.img
[ -s install.img.nz ] || { echo "build_install_image: nzip did not create install.img.nz" >&2; exit 1; }

cp "$APPS/unz.bin" "$BOOTSTRAP/unz.bin"
cp "$APPS/sqa.bin" "$BOOTSTRAP/sqa.bin"
cp install.img.nz "$BOOTSTRAP/install.img.nz"
cat > "$BOOTSTRAP/README.txt" <<'TXT'
JTMOS V67.8 extended utilities media
=====================================
Run from SMSH with the ATAPI CD-ROM:
  sqa cdrom
  unz.bin

install.img.nz contains the complete release application set, all GraOS runtime
files, demos, media and tests.  Source/build files are deliberately excluded.
TXT
JTMOSDIR="$ROOT" ./sqarc extended_bootstrap utilities.sqa

# Reduced system payload -> system-install.img.nz -> utilsdisk.img.  The inner
# compressed archive is still named install.img.nz inside the SQA bootstrap so
# the existing unz command needs no special case.
JTMOSDIR="$ROOT" ./sqarc system_payload system-install.img
SYSTEM_INSTALL_BYTES=$(wc -c < system-install.img)
./nzip --auto system-install.img
[ -s system-install.img.nz ] || { echo "build_install_image: nzip did not create system-install.img.nz" >&2; exit 1; }

cp "$APPS/unz.bin" "$SYSTEM_BOOTSTRAP/unz.bin"
cp "$APPS/sqa.bin" "$SYSTEM_BOOTSTRAP/sqa.bin"
cp system-install.img.nz "$SYSTEM_BOOTSTRAP/install.img.nz"
cat > "$SYSTEM_BOOTSTRAP/README.txt" <<'TXT'
JTMOS V67.8 system utilities (sys:)
===================================
This compact package is the payload for the separate 1.44 MiB B: root floppy.
It contains boot/recovery/install tools, the core CLI set and the functional
GraOS desktop/application set.  A: is boot-only; large demos/media/tests live
on utilities.iso.
TXT
JTMOSDIR="$ROOT" ./sqarc system_bootstrap utilsdisk.img

SYS_UTIL_BYTES=$(wc -c < utilsdisk.img)
EXT_UTIL_BYTES=$(wc -c < utilities.sqa)
NZ_BYTES=$(wc -c < install.img.nz)
SYSTEM_NZ_BYTES=$(wc -c < system-install.img.nz)

if [ "$SYS_UTIL_BYTES" -gt $((1440 * 1024)) ]; then
    echo "build_install_image: system utilsdisk.img exceeds 1.44 MiB B: root medium ($SYS_UTIL_BYTES bytes)" >&2
    exit 1
fi

# Root copies are the complete installer payload, not the reduced sys: subset.
cp install.img.nz "$ROOT/install.img.nz"
cp "$APPS/unz.bin" "$ROOT/unz.bin"

printf 'application binaries:      %s\n' "$APP_COUNT"
printf 'GraOS runtime files:        %s\n' "$GUI_COUNT"
printf 'External GraOS apps:        %s\n' "$EXTGUI_COUNT"
printf 'External GraOS resources:   %s\n' "$EXTGUI_RES_COUNT"
printf 'extended-only moved files:  %s\n' "$MOVED_COUNT"
printf 'full install SQA expanded:  %s bytes\n' "$INSTALL_BYTES"
printf 'full install.img.nz:        %s bytes\n' "$NZ_BYTES"
printf 'system install SQA expanded:%s bytes\n' "$SYSTEM_INSTALL_BYTES"
printf 'system install.img.nz:      %s bytes\n' "$SYSTEM_NZ_BYTES"
printf 'tools/utilsdisk.img:        %s bytes (1.44 MiB B: root limit)\n' "$SYS_UTIL_BYTES"
printf 'tools/utilities.sqa:        %s bytes (CD-ROM payload; no floppy-size limit)\n' "$EXT_UTIL_BYTES"
