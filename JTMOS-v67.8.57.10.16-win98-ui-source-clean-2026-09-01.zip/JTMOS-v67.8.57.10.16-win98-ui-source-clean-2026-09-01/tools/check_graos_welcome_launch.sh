#!/bin/sh
set -eu
fail(){ echo "check_graos_welcome_launch: FAIL: $*" >&2; exit 1; }

[ -f libc/apps/gui/guiLaunchCompat.h ] || fail "compat launcher helper missing"
grep -q 'ram:%s' libc/apps/gui/guiLaunchCompat.h || fail "ram:/ fallback missing"
grep -q 'graos_bgexec_ex_command(program,cwd,ter)' libc/apps/gui/guiStart.c || fail "internal terminal launcher bypasses compat helper"
grep -q 'graos_bgexec_ex_command(program,cwd,GetCurrentTerminal())' libc/apps/gui/guiStart.c || fail "background launcher bypasses compat helper"
grep -q 'graos_file_available(program)' libc/apps/gui/guiStart.c || fail "terminal existence probe does not understand ram:/"
grep -q 'SYSTEM TOOLS.*guiOpenControlPanel(v)' libc/apps/gui/windowFunc.c || fail "Welcome System Tools still depends on external controlpanel exec"
grep -q 'case GRAOS_MENU_CONTROL:' libc/apps/gui/guiStart.c || fail "control menu action missing"
grep -A1 'case GRAOS_MENU_CONTROL:' libc/apps/gui/guiStart.c | grep -q 'guiOpenControlPanel(v)' || fail "Start menu control panel still external"
grep -q 'graos_bgexec_command(s,"/")' libc/apps/gui/launcher.c || fail "launcher entries bypass compat helper"
grep -q 'graos_bgexec_command(cmd,"/")' libc/apps/gui/controlpanel.c || fail "external control panel bypasses compat helper"
grep -q 'graos_bgexec_ex_command(child,cwd,ter)' libc/apps/gui/terminal.c || fail "external terminal child bypasses compat helper"
grep -q 'graos_bgexec_command("/bin/launcher.bin","/")' libc/apps/taskbar.c || fail "legacy taskbar bypasses compat helper"
grep -q 'graos_bgexec_command(cmd,filer->cwd)' libc/apps/filer.c || fail "Filer editor launch bypasses compat helper"
grep -q 'graos_bgexec_command(name,filer->cwd)' libc/apps/filer.c || fail "Filer executable launch bypasses compat helper"

echo "check_graos_welcome_launch: PASS"
