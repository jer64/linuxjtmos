#!/usr/bin/env python3
"""Report byte-identical physical directory trees in a JTMOS checkout.

Symlink directories are deliberately not followed: a symlink is the desired
representation for compatibility aliases and therefore is not a duplicate.
"""
from __future__ import annotations
import hashlib
import os
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKIP_NAMES = {'.git', '.metadata', 'build', '__pycache__'}
MAX_FILES = 5000
MIN_FILES = 2


def file_digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        while True:
            b = f.read(1024 * 1024)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def tree_signature(base: Path):
    entries = []
    for dp, dirs, files in os.walk(base, followlinks=False):
        dpath = Path(dp)
        dirs[:] = [d for d in dirs
                   if d not in SKIP_NAMES and not (dpath / d).is_symlink()]
        for name in files:
            p = dpath / name
            if p.is_symlink() or not p.is_file():
                continue
            rel = p.relative_to(base).as_posix()
            entries.append((rel, file_digest(p)))
            if len(entries) > MAX_FILES:
                return None
    if len(entries) < MIN_FILES:
        return None
    h = hashlib.sha256()
    total = 0
    for rel, digest in sorted(entries):
        h.update(rel.encode('utf-8', 'surrogateescape'))
        h.update(b'\0')
        h.update(digest.encode('ascii'))
        h.update(b'\n')
        total += (base / rel).stat().st_size
    return h.hexdigest(), len(entries), total


def main() -> int:
    groups = defaultdict(list)
    for dp, dirs, _files in os.walk(ROOT, followlinks=False):
        dpath = Path(dp)
        dirs[:] = [d for d in dirs
                   if d not in SKIP_NAMES and not (dpath / d).is_symlink()]
        if dpath == ROOT:
            continue
        sig = tree_signature(dpath)
        if sig:
            groups[sig[0]].append((dpath.relative_to(ROOT).as_posix(), sig[1], sig[2]))

    duplicate_groups = [v for v in groups.values() if len(v) > 1]
    duplicate_groups.sort(key=lambda g: (g[0][1], g[0][2]), reverse=True)
    if not duplicate_groups:
        print('No byte-identical physical directory trees found.')
        return 0
    for group in duplicate_groups:
        print(f"identical: {group[0][1]} files, {group[0][2]} bytes")
        for rel, _n, _size in group:
            print(f"  {rel}")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
