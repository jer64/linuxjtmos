#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
F="$ROOT/kernel32/fs/jtmfs/diskcache/flexFat.c"
RW="$ROOT/kernel32/drivers/driver_rw.c"
HD="$ROOT/kernel32/drivers/hd/hdDev.c"
FL="$ROOT/kernel32/drivers/driver_flush.c"
MISC="$ROOT/kernel32/drivers/hd/hdMisc.c"
LBA="$ROOT/kernel32/drivers/hd/lowLBA.c"
HDEV="$ROOT/kernel32/drivers/hd/hdDev.c"
DFA="$ROOT/kernel32/fs/jtmfs/publicapi/directfileaccess.c"

fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }

# 1. HDA cache must actually be enabled.
grep -q 'driver_enableDAPIReadCache(dnr);' "$HD" || fail "HDA read cache is not enabled"
grep -q 'driver_enableDAPIWriteBackCache(dnr);' "$HD" || fail "HDA write-back cache is not enabled"
! grep -q 'hda DAPI policy = fully uncached' "$HD" || fail "old uncached HDA policy remains"
pass "HDA DAPI read/write-back cache restored"

# 2. FlexFAT must retain dirty pages long enough to combine them.
python3 - "$F" <<'PY'
import re,sys
s=open(sys.argv[1],encoding='utf-8').read()
for name in ('_FastSetBlock','FastSetBlocks'):
    m=re.search(r'\b(?:int|void)\s+'+re.escape(name)+r'\b.*?\n\}',s,re.S)
    if not m: raise SystemExit('missing '+name)
    if 'flexFlushSlot(f,slot)' in m.group(0):
        raise SystemExit(name+' still forces per-entry HDA write-through')
PY
pass "FlexFAT no longer destroys batching with per-entry HDA flushes"

# 3. Checked FAT commit must perform write -> device flush -> direct readback.
grep -q 'writeblocks(dnr,disk_block,io,run)' "$F" || fail "FlexFAT has no run writeblocks path"
grep -q 'driver_FlushDrive(dnr)' "$F" || fail "FlexFAT has no checked device flush"
grep -q 'readblocks1(dnr,disk_block,verify,run)' "$F" || fail "FlexFAT has no direct physical readback"
grep -q 'for(i=0;i<n;i++) f->writemap\[order\[i\]\]=0' "$F" || fail "dirty clear is not gated by checked commit"
pass "FlexFAT commit is write + flush + uncached readback before clean"

# 4. DAPI writeback must sort/gather contiguous blocks and use one direct run.
grep -q 'next=first+run' "$RW" || fail "no contiguous run discovery"
grep -q 'writeblocks1(owner,first,dapi_io_buffer,run)' "$RW" || fail "cache does not issue multi-block physical runs"
grep -q 'dapi_cache_max_flush_run' "$RW" || fail "run instrumentation missing"
pass "DAPI cache physically emits contiguous writeblocks1 runs"

# 5. Multi-block DEVAPI must stay multi-sector all the way to ATA PIO.
grep -q 'DEVICE_CMD_WRITEBLOCKS' "$HDEV" || fail "HDA multi-block command missing"
grep -q 'hdSectorRW_LBA(chd,p,(int)(chunk\*512U),sector,chd->slave,rw,(int)chunk)' "$HDEV" || fail "HDA does not pass run length to LBA PIO"
grep -q 'outportb(0x1F2,sectorCount&0xFF)' "$LBA" || fail "ATA sector-count register is not programmed"
grep -q 'outportb(0x1F7,rw==READ ? 0x20 : 0x30)' "$LBA" || fail "ATA READ/WRITE SECTORS command missing"
pass "contiguous DAPI run remains one ATA command with sectorCount"

# 6. A driver flush must drain DAPI before ATA cache, and ATA must issue E7.
python3 - "$FL" <<'PY'
import sys
s=open(sys.argv[1],encoding='utf-8').read()
a=s.find('driver_block_cache_flush(dnr)')
b=s.find('DEVICE_CMD_FLUSH',a)
if a<0 or b<0 or b<a: raise SystemExit('flush ordering missing')
PY
grep -q 'outportb(0x1F7,0xE7)' "$MISC" || fail "ATA FLUSH CACHE E7 missing"
pass "driver flush orders DAPI drain before ATA FLUSH CACHE (E7)"

# 7. close() must also persist hda1..hda4 JTMFS, not exact hda only.
grep -q "devname\[0\]=='h'.*devname\[1\]=='d'.*devname\[2\]=='a'" "$DFA" || fail "close() HDA-family detection missing"
grep -q 'flush_rv=syncdev(dnr)' "$DFA" || fail "close() does not sync owning HDA device"
pass "close() syncs hda and hdaN devices"

# 8. wildcard cache flush must not overwrite the wildcard selector.
grep -q 'owner=dnr' "$RW" || fail "wildcard owner separation missing"
! grep -q 'first=e->block_nr; bs=e->block_size; dnr=e->dnr' "$RW" || fail "old wildcard flush bug remains"
pass "driver_block_cache_flush(-1) keeps flushing all dirty devices"

echo "PASS: FlexFAT/HDA triple-check complete"
