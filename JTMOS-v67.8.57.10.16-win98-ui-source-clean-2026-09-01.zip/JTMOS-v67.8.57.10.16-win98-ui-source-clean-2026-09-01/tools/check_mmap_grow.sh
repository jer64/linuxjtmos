#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_mmap_grow: FAIL: $*" >&2; exit 1; }
grep -q '#define SYS_mmap[[:space:]]*147' libc/libc/include/jtmos/syscallcodes.h || fail "SYS_mmap ABI"
grep -q '#define SYS_munmap[[:space:]]*148' libc/libc/include/jtmos/syscallcodes.h || fail "SYS_munmap ABI"
grep -q '#define SYS_mem_grow[[:space:]]*149' libc/libc/include/jtmos/syscallcodes.h || fail "SYS_mem_grow ABI"
grep -q 'scall_mem_grow' kernel32/core/iodma/scs.c || fail "kernel grow syscall"
grep -q 'mm_process_mmap_anon' kernel32/mm/mmap.c || fail "process mmap backend"
grep -q 'mm_translate_process_mapping' kernel32/core/iodma/scs.c || fail "A2K mmap translation"
grep -q 'mm_release_process_mappings' kernel32/core/iodma/threads.c || fail "exit mmap cleanup"
grep -q 'mm_clone_process_mappings' kernel32/core/cp/fork.c || fail "fork mmap clone"
grep -q 'jtmos_mem_grow(request)' libc/libc/modern/alloc.c || fail "malloc grow fallback"
! grep -q 'p=malloc(length)' libc/libc/modern/mmap.c || fail "userspace mmap still malloc-emulated"
echo 'check_mmap_grow: PASS (SYSMEMREQ initial heap + process mmap growth)'
