#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail() { echo "check_jtmfs_kernel1m: FAIL: $*" >&2; exit 1; }
H=kernel32/fs/jtmfs/jtmfat.h
C=kernel32/fs/jtmfs/createfat.c
F=libc/libc/modern/jtmos_extra.c
M=libc/apps/mkfs.c

[ -f "$H" ] || fail "$H missing"
grep -q '^#define JTMFS_KERNEL_RESERVE_K[[:space:]]*1024' "$H" || fail "1 MiB KiB constant missing"
grep -q '^#define JTMFS_KERNEL_RESERVE_BYTES[[:space:]]*(1024UL\*1024UL)' "$H" || fail "1 MiB byte constant missing"
grep -q 'inf->res3=JTMFS_BOOT_LAYOUT_TAG' "$C" || fail "JTMFS layout tag is not written"
grep -q 'inf->res4=JTMFS_KERNEL_RESERVE_BYTES' "$C" || fail "JTMFS kernel capacity is not written"
grep -q 'JtmfsKernelRegionIsCurrent' "$C" || fail "JTMFS kernel geometry validator missing"
grep -q 'const int chunk_bytes=64\*1024' "$C" || fail "64 KiB rootinstall buffer missing"
grep -q 'malloc(chunk_bytes)' "$C" || fail "chunked rootinstall allocation missing"
! grep -q 'malloc(KERNEL_LEN_K\*1024)' "$C" || fail "legacy contiguous 1 MiB allocation remains"
grep -q 'SYS_mkfs,(uintptr_t)n' "$F" || fail "userspace formatDrive still bypasses pathname mkfs policy"
grep -q '1 MiB kernel reservation' "$M" || fail "mkfs help does not expose 1 MiB boot layout"
grep -q '^rootdisk: packages' Makefile || fail "rootdisk build target missing"
grep -q 'JTMFS_KERNEL_RESERVE_K' buildroot || fail "rootdisk builder does not validate JTMFS 1 MiB contract"
echo 'check_jtmfs_kernel1m: PASS (JTMFS/rootdisk/mkfs 1 MiB kernel contract)'
