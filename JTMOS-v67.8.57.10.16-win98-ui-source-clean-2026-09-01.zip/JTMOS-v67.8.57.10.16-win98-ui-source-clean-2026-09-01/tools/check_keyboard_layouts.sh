#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=${TMPDIR:-/tmp}/jtmos-keymap-test-$$
trap 'rm -f "$TMP"' EXIT HUP INT TERM
cc -std=gnu11 -Wall -Wextra -Werror \
  -I"$ROOT/kernel32/drivers/keyboard" \
  "$ROOT/kernel32/drivers/keyboard/keymap.c" \
  "$ROOT/tests/test_keyboard_keymap.c" -o "$TMP"
"$TMP"
