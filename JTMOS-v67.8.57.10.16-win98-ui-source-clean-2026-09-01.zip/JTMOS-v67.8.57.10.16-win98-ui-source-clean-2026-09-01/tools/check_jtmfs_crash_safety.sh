#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fail() { echo "check_jtmfs_crash_safety: FAIL: $*" >&2; exit 1; }

FSADD="$ROOT/kernel32/fs/jtmfs/fsadd.c"
ACCESS="$ROOT/kernel32/fs/jtmfs/jtmfsAccess.c"
FIND="$ROOT/kernel32/fs/jtmfs/diskcache/dirdbFind.c"
WALK="$ROOT/kernel32/fs/jtmfs/diskcache/dirdbWalk.c"
FAT="$ROOT/kernel32/fs/jtmfs/jtmfat.c"
FLEX="$ROOT/kernel32/fs/jtmfs/diskcache/flexFat.c"
CORE="$ROOT/kernel32/fs/jtmfs/jtmfs.c"

# The old fsadd bug wrote fe->magicNumber before checking fe==NULL.
null_line=$(grep -n 'if(fe==NULL)' "$FSADD" | head -1 | cut -d: -f1)
magic_line=$(grep -n 'fe->magicNumber[[:space:]]*=' "$FSADD" | head -1 | cut -d: -f1)
[ -n "$null_line" ] && [ -n "$magic_line" ] && [ "$null_line" -lt "$magic_line" ] || \
  fail 'fsadd NULL guard must precede first fe dereference'

# No unbounded "walk until name[0]==0" scan may remain in the lookup file.
! grep -Eq 'for[[:space:]]*\([^;]*;[[:space:]]*\*p[[:space:]]*;' "$FIND" || \
  fail 'unbounded DIRDB lookup scan returned'
grep -q 'p+sizeof(JTMFS_FILE_ENTRY)<=end' "$FIND" || \
  fail 'DIRDB lookups are not bounded by cache end'
grep -q 'magicNumber!=0xFCE2E37B' "$FIND" || \
  fail 'DIRDB lookup no longer validates entry magic'

# Invalid DIRWALK must never be dereferenced on the diagnostic path.
grep -q 'dw ? dw->d : NULL' "$WALK" || fail 'DIRWALK NULL-safe diagnostic missing'

# ReadFile used to divide by getblocksize(dnr) before device validation.
read_body=$(sed -n '/int _jtmfs_ReadFile(/,/^}/p' "$ACCESS")
! printf '%s\n' "$read_body" | grep -q 'preciseLength/getblocksize' || \
  fail '_jtmfs_ReadFile pre-validation divide returned'
printf '%s\n' "$read_body" | grep -q 'buf==NULL || preciseLength<0 || offset<0' || \
  fail '_jtmfs_ReadFile argument guard missing'

# Mount/root paths and cache activation need null/range guards.
grep -q 'if(!jtmfat_ready || fatsys==NULL || !jtmfat_valid_slot(dnr))' "$FAT" || \
  fail 'jtmfat_getinfoblock slot guard missing'
grep -q 'if(inf==NULL || !fatsys->isJTMFS\[dnr\]' "$FAT" || \
  fail 'root/info NULL guard missing'
grep -q '!flexActive || fle==NULL' "$FLEX" || fail 'FlexFAT allocation-failure guard missing'

# FAT diagnostic traversal must be bounded to catch multi-node cycles.
grep -q 'for(amount=1; amount<=limit; amount++)' "$CORE" || \
  fail 'FAT chain traversal is not bounded'

echo 'check_jtmfs_crash_safety: PASS (NULL/range/corruption/divide/cycle guards)'
