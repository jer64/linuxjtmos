#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail() { echo "check_top_linux: FAIL: $*" >&2; exit 1; }
TOP=libc/apps/top.c
PC=libc/libc/modern/process_console.c

[ -f "$TOP" ] || fail "$TOP missing"
[ -f "$PC" ] || fail "$PC missing"

grep -q "ch==27 || ch=='q' || ch=='Q'" "$TOP" || fail "top does not quit explicitly on q/ESC"
! grep -q 'if(ch >= 0) break' "$TOP" || fail "historical getch1()==0 auto-exit remains"
grep -q 'TOP_POLL_MS' "$TOP" || fail "nonblocking refresh polling missing"
grep -q '#include <sys/sysinfo.h>' "$TOP" || fail "Linux sysinfo memory source missing"
grep -q 'MiB Mem :' "$TOP" || fail "Linux-style memory summary missing"
grep -q 'Tasks:' "$TOP" || fail "Linux-style task summary missing"
grep -q '%Cpu(s):' "$TOP" || fail "Linux-style CPU summary missing"
grep -q 'P CPU sort' "$TOP" || fail "interactive CPU sort missing"
grep -q 'M memory sort' "$TOP" || fail "interactive memory sort missing"
[ "$(grep -c 'clrscr();' "$TOP")" -eq 1 ] || fail "top should clear screen only once"
grep -q 'printf("%-79.79s"' "$TOP" || fail "fixed-width redraw missing"
grep -q "for(;i<n;i++)putchar(' ');" "$PC" || fail "Ring3 StretchPrint still does not pad fields"

CP=kernel32/core/cp/centralprocessMain.c
[ -f "$CP" ] || fail "$CP missing"
! grep -Eq '^[[:space:]]*printk\("CP: process created' "$CP" || fail "normal process-start printk can overwrite fullscreen apps"
grep -q 'dprintk("CP: process created' "$CP" || fail "process-start diagnostic is not serial-debug routed"

echo "check_top_linux: PASS (persistent top + padded columns + Linux-style view)"
