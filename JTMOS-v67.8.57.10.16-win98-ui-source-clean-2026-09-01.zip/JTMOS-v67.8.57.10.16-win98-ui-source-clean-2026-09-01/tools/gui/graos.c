/*
 * GraOS VESA framebuffer bring-up program.
 *
 * V23 deliberately contains no window manager, VGA planar emulation,
 * Postman graphics, taskbar or GUI asset loader.  Its only graphics primitive
 * is drawframe(): one complete packed 640x480x32 RGBA frame is presented through
 * SYS_vgadrawframe to the boot32-selected VESA linear framebuffer.
 */
#include <stdio.h>
#include <stdlib.h>
#include <jtmos/scall.h>
#include <jtmos/process.h>

#define GRAOS_WIDTH       640
#define GRAOS_HEIGHT      480
#define GRAOS_FRAME_BYTES (GRAOS_WIDTH * GRAOS_HEIGHT)

SYSMEMREQ(APPRAM_2048K)

static unsigned char *framebuffer;

/* The entire active GraOS graphics ABI.  Keeping this local avoids pulling
 * the historical video.c/Postman/VGA compatibility object into graos.bin. */
static int draw_frame(const void *frame)
{
    return (int)scall(SYS_vgadrawframe, (DWORD)frame, 0,
                      GRAOS_FRAME_BYTES, 0, 0, 0);
}

static void render_diagnostic_plasma(unsigned int phase)
{
    int x, y;
    unsigned int p;
    unsigned int a, b, c;

    p = 0;
    for(y=0; y<GRAOS_HEIGHT; y++)
    {
        for(x=0; x<GRAOS_WIDTH; x++,p++)
        {
            /* Fast integer-only pattern.  With the kernel RGB332 palette this
             * produces obvious motion and exercises every framebuffer byte. */
            a = (unsigned int)(x + (int)phase) & 255U;
            b = (unsigned int)((y << 1) - (int)phase) & 255U;
            c = (unsigned int)(((x ^ y) + (int)(phase << 1))) & 255U;
            framebuffer[p] = (unsigned char)((a + b + c +
                                (unsigned int)((x * y) >> 5)) & 255U);
        }
    }

    /* Fixed reference markers: white border, black inner border and a color
     * ramp at the top make geometry/pitch problems immediately visible. */
    for(x=0; x<GRAOS_WIDTH; x++)
    {
        framebuffer[x] = (unsigned char)x;
        framebuffer[(GRAOS_HEIGHT-1)*GRAOS_WIDTH+x] = 255;
    }
    for(y=0; y<GRAOS_HEIGHT; y++)
    {
        framebuffer[y*GRAOS_WIDTH] = 255;
        framebuffer[y*GRAOS_WIDTH + GRAOS_WIDTH-1] = 255;
    }
}

int main(int argc, const char **argv)
{
    unsigned int phase;

    (void)argc;
    (void)argv;

    printf("GraOS V23 VESA framebuffer diagnostic: 640x480x32 RGBA.\n");

    framebuffer = (unsigned char *)malloc(GRAOS_FRAME_BYTES);
    if(framebuffer == NULL)
    {
        printf("GraOS: unable to allocate 307200-byte framebuffer.\n");
        return 1;
    }

    phase = 0;
    render_diagnostic_plasma(phase);
    if(!draw_frame(framebuffer))
    {
        printf("GraOS: VESA LFB drawframe rejected; GUI requires boot32 VESA 640x480x32 RGBA.\n");
        free(framebuffer);
        return 2;
    }

    for(;;)
    {
        phase++;
        render_diagnostic_plasma(phase);
        if(!draw_frame(framebuffer))
        {
            printf("GraOS: VESA framebuffer became unavailable.\n");
            break;
        }
        SwitchToThread();
    }

    free(framebuffer);
    return 3;
}
