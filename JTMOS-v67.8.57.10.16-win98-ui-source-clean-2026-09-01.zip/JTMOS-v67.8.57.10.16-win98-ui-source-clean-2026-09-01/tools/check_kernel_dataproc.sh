#!/bin/sh
# JTMOS V67.8.57.10.8 dataproc regression check.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
K="$ROOT/kernel32"
TMP=${TMPDIR:-/tmp}/jtmos-dataproc-check-$$
trap 'rm -f "$TMP" "$TMP.link"' EXIT HUP INT TERM

cd "$K"
./autogen.pl > generated.mak

OBJS=$(find core/dataproc -maxdepth 1 -name '*.c' -print | sed 's/\.c$/.o/' | tr '\n' ' ')
rm -f core/dataproc/*.o
STRICT='-std=gnu89 -c -Wall -Wextra -Werror=implicit-function-declaration -Werror=int-conversion -Werror=return-type -Werror=array-bounds -Werror=shift-count-overflow -Werror=uninitialized -Werror=maybe-uninitialized -Werror=implicit-fallthrough -Wno-unused-parameter -Wno-sign-compare -Wno-pointer-sign -Wno-unused-function -Wno-unused-variable -Wno-missing-field-initializers -nostdlib -nostdinc -fno-builtin -fno-stack-protector -fcommon -O2 -march=i486 -m32 $(JTMDEF)'
# Deliberately use two jobs: this is also the normal JTMOS build policy.
if ! make -j 2 -f generated.mak CFLAGS="$STRICT" $OBJS >"$TMP" 2>&1; then
    cat "$TMP" >&2
    exit 1
fi

for sym in memmove memset strcmp strlen str2int hex2int sscanf svscanf strtok_r strspn strcspn; do
    if ! nm core/dataproc/*.o | grep -Eq "[[:space:]]T[[:space:]]+$sym$"; then
        echo "check_kernel_dataproc: FAIL: missing symbol $sym" >&2
        exit 1
    fi
done

# Compile two real consumers after the header/API cleanup.
rm -f sh/sqarc.o fs/filebuf.o
if ! make -j 2 -f generated.mak sh/sqarc.o fs/filebuf.o >"$TMP" 2>&1; then
    cat "$TMP" >&2
    exit 1
fi
ld -m elf_i386 -r fs/filebuf.o core/dataproc/memcpy.o -o "$TMP.link"
if nm -u "$TMP.link" | grep -Eq '[[:space:]]memmove$'; then
    echo "check_kernel_dataproc: FAIL: filebuf still has unresolved memmove" >&2
    exit 1
fi

# Guard collisions used to hide sscanf and strtok_r prototypes depending on
# include order.  The guards must stay distinct.
SPRINTF_GUARD=$(awk '/^#define __.*SPRINTF.*H__/ {print $2; exit}' core/dataproc/sprintf.h)
SSCANF_GUARD=$(awk '/^#define __.*SSCANF.*H__/ {print $2; exit}' core/dataproc/sscanf.h)
STRTOK_GUARD=$(awk '/^#define __.*STRTOK_H__/ {print $2; exit}' core/dataproc/strtok.h)
STRTOKR_GUARD=$(awk '/^#define __.*STRTOK_R_H__/ {print $2; exit}' core/dataproc/strtok_r.h)
[ -n "$SPRINTF_GUARD" ] && [ -n "$SSCANF_GUARD" ] && [ "$SPRINTF_GUARD" != "$SSCANF_GUARD" ] || {
    echo "check_kernel_dataproc: FAIL: sprintf/sscanf include guard collision" >&2; exit 1; }
[ -n "$STRTOK_GUARD" ] && [ -n "$STRTOKR_GUARD" ] && [ "$STRTOK_GUARD" != "$STRTOKR_GUARD" ] || {
    echo "check_kernel_dataproc: FAIL: strtok/strtok_r include guard collision" >&2; exit 1; }

# Lock in the high-impact source invariants found by the audit.
! grep -Eq '9999|d\[10\]' core/dataproc/string.c || {
    echo "check_kernel_dataproc: FAIL: legacy string length/OOB sentinel returned" >&2; exit 1; }
grep -q 'return assigned;' core/dataproc/sscanf.c || {
    echo "check_kernel_dataproc: FAIL: sscanf assignment count missing" >&2; exit 1; }
grep -q 'i2<length' core/dataproc/hexdump.c || {
    echo "check_kernel_dataproc: FAIL: hexdump final-line bound check missing" >&2; exit 1; }

echo "check_kernel_dataproc: PASS"
