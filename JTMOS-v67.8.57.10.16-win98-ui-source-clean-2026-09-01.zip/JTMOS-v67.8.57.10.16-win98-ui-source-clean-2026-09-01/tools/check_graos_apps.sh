#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_graos_apps: FAIL: $*" >&2; exit 1; }

grep -q 'pop_event_for_window' libc/libc/modern/graos_compat.c || fail "window-filtered client event queue missing"
grep -q 'graos_pid=GetThreadPID' libc/libc/modern/graos_compat.c || fail "GraOS PID is not revalidated"
grep -q 'GetThreadMemoryUsage(pid)==0' libc/apps/gui/terminal.c || fail "terminal wrapper does not reap an exited child"
! grep -q 'SetTerminalOwner(ter,pid)' libc/apps/gui/terminal.c || fail "external terminal still transfers terminal lifetime to child"
grep -q 'guiReapExitedTerminalPrograms' libc/apps/gui/guiLoop.c || fail "internal dead-terminal reaper not in event loop"
grep -q 'program not installed' libc/apps/gui/guiStart.c || fail "internal terminal launch lacks install preflight"
grep -q 'graos_demo.h' libc/apps/picture.c || fail "picture is not using windowed GraOS framebuffer/event helper"
grep -q '/bin/sqfam.raw' libc/apps/picture.c || fail "picture cannot locate installed resource"
grep -q '/bin/squirrel16.raw' libc/apps/gui/bitmapdemo.c || fail "bitmap demo cannot locate installed resource"
grep -q 'command_available' libc/apps/gui/launcher.c || fail "launcher does not preflight application commands"
grep -q '/bin/terminal.bin' kernel32/init/graos_boot.c || fail "GraOS boot core does not require terminal client"
grep -q 'getch();' libc/apps/bgidemo.c || fail "BGI demo no longer exercises conio input"
grep -q 'jtmos_graph_active.*jtmos_graph_getch' libc/libc/modern/process_console.c || fail "conio getch no longer routes active BGI input to the GraOS graph window"
grep -q 'terminal.bin %s %s' libc/apps/filer.c || fail "Filer editor is not launched in a visible terminal"
grep -q '#define EDIT_CMD_PATH "/bin/edit.bin"' libc/apps/filer.c || fail "Filer editor path is tied to hda instead of mounted root"
grep -q '#define FILER_HLP_PATH "/bin/filer.hlp"' libc/apps/filer.c || fail "Filer help path is tied to hda instead of mounted root"
grep -q 'graos_bgexec_command(name,filer->cwd)' libc/apps/filer.c || fail "Filer executable launch is not asynchronous/namespace-safe"
grep -q 'sqfam.raw' tools/build_install_image.sh || fail "picture resource not packaged"
grep -q 'JtmosGraOSPollEvent(wid,&ev)' libc/apps/winshell.c || fail "release winshell still uses raw GraOS receive loop"
grep -q 'GetThreadMemoryUsage(\*child_pid)==0' libc/apps/winshell.c || fail "winshell does not close after child exit"
grep -q 'graos_bgexec_command("/bin/launcher.bin","/")' libc/apps/taskbar.c || fail "legacy taskbar bypasses namespace-safe launcher"
grep -q 'Sleep(40)' libc/apps/taskbar.c || fail "legacy taskbar still sleeps seconds between frames"
grep -q '^%.bin: FORCE' libc/apps/Makefile || fail "app dispatcher does not re-enter per-app makefiles"
grep -q '^%.bin: FORCE' libc/apps/gui/Makefile || fail "GUI dispatcher does not re-enter per-app makefiles"

[ ! -e libc/apps/terminal.c ] || fail "duplicate root terminal client still exists"
[ ! -e libc/apps/controlpanel.c ] || fail "duplicate root control panel still exists"

echo 'check_graos_apps: PASS (event routing, terminal lifecycle, launcher/Filer/resources)'
