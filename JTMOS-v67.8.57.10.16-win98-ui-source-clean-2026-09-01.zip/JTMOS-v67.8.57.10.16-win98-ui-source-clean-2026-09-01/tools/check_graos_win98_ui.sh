#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

fail(){ echo "check_graos_win98_ui: FAIL: $*" >&2; exit 1; }

# Window chrome: classic 20 px caption with a native 8 px font at y+6 gives
# roughly 3 px of breathing room above and below inside the blue title field.
grep -q 'GRAOS_VERSION "V37"' libc/apps/gui/graos.h || fail "GraOS V37 missing"
grep -q '#define GRAOS_PANEL_HEIGHT 30' libc/apps/gui/graos.h || fail "30 px taskbar missing"
grep -q 'DrawText(v,w->caption,title_x,w->y+6,15,-1)' libc/apps/gui/guiChrome.c || fail "crisp caption baseline missing"
grep -q 'GRAOS_RGB(0,0,128)' libc/apps/gui/guiChrome.c || fail "classic dark-blue active caption missing"
! grep -q 'DrawText(v,w->caption,title_x+1' libc/apps/gui/guiChrome.c || fail "title shadow returned"

# Styled taskbar/start-menu API must survive through the IPC protocol.
grep -q 'GRAOS_BUTTON_MENU' libc/include/jtmos/graosprotocol.h || fail "menu button style missing"
grep -q 'GRAOS_BUTTON_ICON_VIEW' libc/include/jtmos/graosprotocol.h || fail "icon-view style missing"
grep -q 'GRAOS_BUTTON_START' libc/include/jtmos/graosprotocol.h || fail "Start button style missing"
grep -q 'c->v\[6\]' libc/apps/gui/guiServer.c || fail "button style not routed by server"
grep -q 'createButtonStyled' libc/libc/modern/graos_compat.c || fail "styled client button API missing"

# taskbar.bin: 30 px panel, raised Start button, blue branding gutter and roomy rows.
grep -q '#define TASKBAR_H 30' libc/apps/taskbar.c || fail "taskbar height is not 30"
grep -q 'GRAOS_BUTTON_START,"Start"' libc/apps/taskbar.c || fail "styled Start button missing"
grep -q '#define MENU_ROW_H 32' libc/apps/taskbar.c || fail "Start menu rows are not roomy"
grep -q 'menu_brand_buf' libc/apps/taskbar.c || fail "Start menu blue branding strip missing"
grep -q '"Programs"' libc/apps/taskbar.c || fail "Programs menu entry missing"
grep -q '"Settings"' libc/apps/taskbar.c || fail "Settings menu entry missing"

# Both in-process and external Control Panels use the left info pane + right icon grid.
grep -q '740,430,"JTMOS Control Panel"' libc/apps/gui/guiStart.c || fail "internal Control Panel geometry missing"
grep -q 'GRAOS_WINDOW_CONTROL_PANEL_STYLE' libc/apps/gui/guiStart.c || fail "internal Control Panel two-pane style missing"
grep -q 'GRAOS_BUTTON_ICON_VIEW' libc/apps/gui/guiStart.c || fail "internal Control Panel icon grid missing"
grep -q '740,430,"JTMOS Control Panel"' libc/apps/gui/controlpanel.c || fail "external Control Panel geometry missing"
grep -q 'createButtonStyled' libc/apps/gui/controlpanel.c || fail "external Control Panel icon grid missing"
grep -q '"Use these settings to"' libc/apps/gui/controlpanel.c || fail "Control Panel description pane missing"

echo "check_graos_win98_ui: PASS (caption spacing, taskbar/start menu, two-pane Control Panel)"
