#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
K="$ROOT/kernel32"
TMP=${TMPDIR:-/tmp}/jtmos-kernel-memmove-$$.o
trap 'rm -f "$TMP"' EXIT HUP INT TERM

cd "$K"
./autogen.pl > generated.mak
make -j2 -f generated.mak core/dataproc/memcpy.o fs/filebuf.o >/dev/null

nm core/dataproc/memcpy.o | grep -Eq '[[:space:]]T[[:space:]]+memmove$' || {
    echo "check_kernel_memmove: FAIL: native kernel memmove symbol missing" >&2
    exit 1
}

# filebuf.c needs overlap-safe compaction after a partial write.  Verify the
# exact two objects can be relocatably linked without leaving memmove unresolved.
ld -m elf_i386 -r fs/filebuf.o core/dataproc/memcpy.o -o "$TMP"
if nm -u "$TMP" | grep -Eq '[[:space:]]memmove$'; then
    echo "check_kernel_memmove: FAIL: fs/filebuf.o still has unresolved memmove" >&2
    exit 1
fi

echo "check_kernel_memmove: PASS (native overlap-safe memmove resolves kernel filebuf)"
