#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail() { echo "check_hda_persistence: FAIL: $*" >&2; exit 1; }

grep -q 'driver_block_cache_flush(dnr)' kernel32/drivers/driver_api.c || fail "mount path does not flush DAPI cache"
grep -q 'refusing to drop dirty cache' kernel32/drivers/driver_api.c || fail "mount flush failure is not protected"
grep -q 'r=driver_mountDNR(dnr)' kernel32/fs/jtmfs/mount.c || fail "JTMFS mount does not observe driver mount result"
grep -q 'preserving filesystem caches' kernel32/fs/jtmfs/mount.c || fail "failed mount may still discard filesystem cache"
grep -q 'jtmfs_isDriveReady(dnr) && syncdev(dnr)!=0' kernel32/fs/jtmfs/mount.c || fail "unmount does not sync JTMFS before invalidation"
grep -q 'keeping it mounted' kernel32/drivers/driver_api.c || fail "driver unmount does not preserve state on failed flush"
grep -q 'driver_enableDAPIReadCache(dnr)' kernel32/drivers/hd/hdDev.c || fail "HDA DAPI read cache is not enabled"
grep -q 'driver_enableDAPIWriteBackCache(dnr)' kernel32/drivers/hd/hdDev.c || fail "HDA DAPI write-combining cache is not enabled"
grep -q 'writeblocks1(owner,first,dapi_io_buffer,run)' kernel32/drivers/driver_rw.c || fail "DAPI cache does not flush contiguous physical runs"
grep -q 'writeblocks(dnr,disk_block,io,run)' kernel32/fs/jtmfs/diskcache/flexFat.c || fail "FlexFAT does not submit contiguous FAT runs"
grep -q 'readblocks1(dnr,disk_block,verify,run)' kernel32/fs/jtmfs/diskcache/flexFat.c || fail "FlexFAT physical readback verify missing"
grep -q 'driver_FlushDrive(d->dnr)' kernel32/fs/jtmfs/diskcache/dirdb_writeDir.c || fail "DIRDB durable media verify does not flush through the device"
grep -q 'driver_block_cache_invalidate(d->dnr)' kernel32/fs/jtmfs/diskcache/dirdb_writeDir.c || fail "DIRDB media verify does not invalidate cached readback"
grep -q 'driver_FlushDrive(dnr)!=0' kernel32/fs/jtmfs/publicapi/directfileaccess.c || fail "syncdev does not propagate block/device flush failure"
grep -q 'case DEVICE_CMD_FLUSH:' kernel32/drivers/hd/hdDev.c || fail "HDA has no DEVAPI flush command"
grep -q 'outportb(0x1F7,0xE7)' kernel32/drivers/hd/hdMisc.c || fail "ATA FLUSH CACHE (E7) missing"
grep -q '{"hdatest", hdatest_app}' kernel32/sh/sh.c || fail "SMSH hdatest command missing"
grep -q 'JTMOS-HDA-PERSISTENCE-V67.8.56.12' kernel32/sh/fsadmin.c || fail "reboot persistence marker missing"
grep -Fq 'media=disk,cache=writethrough' run_jtmos_qemu.sh || fail "QEMU HDA is not writethrough"

echo "check_hda_persistence: PASS"
echo "runtime test: hdatest write ; reboot ; hdatest check"
