#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail() { echo "check_boot32_hd_nzip: FAIL: $*" >&2; exit 1; }

B=boot32/bootmod.inc
A=boot32/boot.asm
C=kernel32/fs/jtmfs/createfat.c
N=tools/build_kernel_nz.sh
P=boot32pm/Makefile

[ -f "$B" ] || fail "$B missing"
grep -q '^prepare_kernel_handoff:' "$B" || fail "shared checksum handoff missing"
awk '/^hd_load_kernel_image:/{f=1;n=0} f&&n++<16{print} /^floppy_load_kernel_image:/{f=0}' "$B" | grep -q 'call prepare_kernel_handoff' || fail "HD handoff missing"
awk '/^floppy_load_kernel_image:/{f=1;n=0} f&&n++<16{print}' "$B" | grep -q 'call prepare_kernel_handoff' || fail "floppy handoff missing"
grep -q 'STREAM_SECTORS_PER_CHUNK[[:space:]]*equ 128' "$B" || fail "64 KiB / 128-sector chunk contract missing"
grep -q '^stream_flush_chunk:' "$B" || fail "stream flush missing"
grep -q '^pmode_stream_copy:' "$A" || fail "PMODE stream copy missing"
grep -q 'JTMOS_BOOT_NZIP_STAGING_PHYS' "$A" || fail "high staging destination missing"
grep -q '^%define JTMOS_BOOT_NZIP_STAGING_PHYS[[:space:]]*0x01000000' kernel32/include/memory_layout.inc || fail "16 MiB staging address missing"
grep -q '^#define JTMFS_KERNEL_RESERVE_K[[:space:]]*1024' kernel32/fs/jtmfs/jtmfat.h || fail "JTMFS HDD boot reservation is not 1 MiB"
grep -q '^#define JTMFS_KERNEL_RESERVE_BYTES[[:space:]]*(1024UL\*1024UL)' kernel32/fs/jtmfs/jtmfat.h || fail "JTMFS byte reservation contract missing"
grep -q 'HD_KERNEL_SECTORS > 2048' "$B" || fail "2048-sector compile-time guard missing"
grep -q 'compressed kernel exceeds 1 MiB PMODE streaming window' "$N" || fail "kernel-nz 1 MiB guard missing"
grep -q 'kernel32.bin.nz exceeds 1 MiB streamed staging window' "$P" || fail "boot32pm 1 MiB guard missing"
grep -q '18+offset/JTMFS_BOOT_RECORD_BYTES' "$C" || fail "CopyKernel no longer streams boot payload from sector 18"
grep -q 'malloc(chunk_bytes)' "$C" || fail "CopyKernel is not using the bounded 64 KiB buffer"
! grep -q 'malloc(KERNEL_LEN_K\*1024)' "$C" || fail "CopyKernel still allocates a contiguous 1 MiB buffer"
grep -q 'SetKernelChecksum(dnr, source_raw_checksum)' "$C" || fail "raw checksum handoff missing"

# HDD boot must continue automatically after the image load.  Historically
# loaded_fine waited on INT 16h for every boot drive except A:, which made
# `boot: c` stop exactly at the Ready line.
loaded_block=$(awk '/^loaded_fine:/{f=1} /^ignore_error:/{if(f){print; exit}} f{print}' "$B")
printf '%s\n' "$loaded_block" | grep -q 'puts str_loaded' || fail "loaded_fine message missing"
! printf '%s\n' "$loaded_block" | grep -q 'int[[:space:]]*0x16' || fail "loaded_fine still waits for a key on HDD boot"
! grep -q 'Ready: Kernel loaded, checksum OK' boot32/text.inc || fail "nzip pre-PMODE message still falsely claims checksum OK"
grep -q 'Ready: Kernel image loaded. Starting kernel' boot32/text.inc || fail "automatic kernel handoff status text missing"

# Split-media invariants: A: must remain boot-only; B:/ATAPI carry SQARC root.
grep -q 'boot32pm/boot.bin' jtm32.cfg || fail "A: boot image lacks boot32pm"
grep -q 'kernel32/kernel32.bin.nz' jtm32.cfg || fail "A: boot image lacks compressed kernel"
! grep -q 'utilsdisk\|utilities' jtm32.cfg || fail "A: boot image still embeds system payload"
[ -x buildroot ] || fail "B: root image builder missing"
grep -q '1440 \* 1024' tools/build_install_image.sh || fail "B: payload is not allowed the full 1.44 MiB"
grep -q 'sysdev_probe_sqarc' kernel32/drivers/sysdev/sysdev.c || fail "root-media SQARC probe missing"
grep -q 'driver_getdevicenrbyname("floppy2")' kernel32/drivers/sysdev/sysdev.c || fail "B: root backend missing"
grep -q 'driver_getdevicenrbyname("cdrom")' kernel32/drivers/sysdev/sysdev.c || fail "ATAPI root fallback missing"
grep -q '^default: image rootimage utilscdrom' Makefile || fail "default build does not emit split media"

# The failure size from V67.8.57.0 must now fit comfortably and require
# multiple PMODE round trips rather than conventional-memory staging.
probe=593277
[ "$probe" -le 1048576 ] || fail "regression stream does not fit new 1 MiB contract"
sectors=$(( (probe + 511) / 512 ))
chunks=$(( (sectors + 127) / 128 ))
[ "$chunks" -gt 1 ] || fail "regression stream is not exercising multi-chunk loading"
[ "$chunks" -le 16 ] || fail "1 MiB stream should require at most 16 64 KiB chunks"

echo "check_boot32_hd_nzip: PASS (64 KiB BIOS/PMODE streaming, 1 MiB payload)"
