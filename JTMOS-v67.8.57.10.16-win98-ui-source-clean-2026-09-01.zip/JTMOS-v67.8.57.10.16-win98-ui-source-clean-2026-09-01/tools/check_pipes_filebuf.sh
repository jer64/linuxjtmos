#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail() { echo "check_pipes_filebuf: FAIL: $*" >&2; exit 1; }

KSC=kernel32/core/chiplevel/syscallcodes.h
LSC=libc/libc/include/jtmos/syscallcodes.h
KFB=kernel32/fs/filebuf.c
KFH=kernel32/fs/filebuf.h
LFB=libc/libc/modern/filebuf.c
STDIO=libc/libc/modern/stdio.c
LINUX=kernel32/core/cp/linuxabi.c
SCS=kernel32/core/chiplevel/scs.c
SQSH=libc/apps/sqsh.c
SMSH=kernel32/sh/sh.c
CAT=libc/apps/cat.c

for f in "$KSC" "$LSC" "$KFB" "$KFH" "$LFB" "$STDIO" "$LINUX" "$SCS" "$SQSH" "$SMSH" "$CAT"; do
    [ -f "$f" ] || fail "$f missing"
done

# Keep the established pipe ABI and append the kernel file-buffer/stdio ABI.
grep -Eq '^#define[[:space:]]+SYS_pipe[[:space:]]+132' "$KSC" || fail 'kernel SYS_pipe ABI changed'
grep -Eq '^#define[[:space:]]+SYS_pipe[[:space:]]+132' "$LSC" || fail 'libc SYS_pipe ABI mismatch'
for pair in \
 'SYS_filebuf_read 139' 'SYS_filebuf_write 140' 'SYS_filebuf_flush 141' \
 'SYS_filebuf_set 142' 'SYS_filebuf_seek 143' 'SYS_filebuf_tell 144' \
 'SYS_dup2 145' 'SYS_cexec_stdio 146'; do
    name=${pair% *}; nr=${pair#* }
    grep -Eq "^#define[[:space:]]+$name[[:space:]]+$nr" "$KSC" || fail "$KSC: $name=$nr missing"
    grep -Eq "^#define[[:space:]]+$name[[:space:]]+$nr" "$LSC" || fail "$LSC: $name=$nr mismatch"
done
grep -q 'nr_scall_func = 151' "$SCS" || fail 'syscall dispatcher size is not 151'

# Pipe transport and ownership live in the kernel.
grep -q 'int LinuxPipeCreate' "$LINUX" || fail 'kernel pipe creator missing'
grep -q 'LINUX_PIPE_CAPACITY' "$LINUX" || fail 'kernel pipe ring buffer missing'
grep -q 'LinuxFdOwnerAdded' "$LINUX" || fail 'pipe reader/writer ownership accounting missing'
grep -q 'LinuxFdOwnerReleased' "$LINUX" || fail 'pipe endpoint release accounting missing'
grep -q 'int LinuxDup2' "$LINUX" || fail 'kernel dup2 stdio routing missing'

# Persistent stdio/file buffering lives in kernel32/fs/filebuf.c.
for fn in KernelFileBufRead KernelFileBufWrite KernelFileBufFlush KernelFileBufSet KernelFileBufSeek KernelFileBufTell KernelFileBufFdClosing; do
    grep -q "$fn" "$KFB" || fail "$fn missing from kernel filebuf"
    grep -q "$fn" "$KFH" || fail "$fn missing from kernel filebuf header"
done
grep -q 'JTMOS_KERNEL_FILEBUF' "$KFB" || fail 'kernel file-buffer state missing'
grep -q 'LinuxFdIsPipe(fd) ? JTMOS_FILEBUF_NONE' "$KFB" || fail 'pipe stream must not receive a second userspace-style data buffer'

# Ring3 libc is only the syscall facade. It must not own BUFSIZ data buffers.
for fn in __jtmos_filebuf_read __jtmos_filebuf_write __jtmos_filebuf_flush __jtmos_filebuf_set __jtmos_filebuf_seek __jtmos_filebuf_tell; do
    grep -q "$fn" "$LFB" || fail "$fn syscall wrapper missing"
    grep -q "$fn" "$STDIO" || fail "stdio does not use $fn"
done
! grep -q 'ensure_buffer' "$STDIO" || fail 'legacy userspace stdio buffering remains'
! grep -Eq 'malloc[[:space:]]*\([[:space:]]*BUFSIZ' "$STDIO" || fail 'userspace BUFSIZ allocation remains'

# Both shells must build real concurrent pipelines, not copy through a shell buffer.
grep -q 'sqsh_run_pipeline' "$SQSH" || fail 'SQSH pipeline parser/runner missing'
grep -q 'pipe(pfds\[i\])' "$SQSH" || fail 'SQSH does not call SYS_pipe through libc pipe()'
grep -q 'bgexecStdio' "$SQSH" || fail 'SQSH stages lack redirected stdio process launch'
grep -q -- '--pipe-stage' "$SQSH" || fail 'SQSH no-banner pipeline worker missing'
grep -q 'sh_run_pipeline' "$SMSH" || fail 'SMSH pipeline parser/runner missing'
grep -q 'LinuxPipeCreate' "$SMSH" || fail 'SMSH does not allocate kernel pipes'
grep -q 'centralprocess_exec_stdio' "$SMSH" || fail 'SMSH stages lack stdio routing'

# cat with no operand is the minimal stream consumer used by smoke tests.
grep -q 'argc==1' "$CAT" || grep -q 'argc <= 1' "$CAT" || fail 'cat does not expose stdin mode'

echo 'check_pipes_filebuf: PASS (kernel pipes + kernel filebuf syscalls + SQSH/SMSH pipelines)'
