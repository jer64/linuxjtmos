#!/bin/sh
# Static regression checks for the V67.8.56.8 utilities reliability pass.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
APPS="$ROOT/libc/apps"

fail() { echo "check_utilities: FAIL: $*" >&2; exit 1; }

# Plain PID is the V67 userspace contract.  Utilities must not revive UNIPID.
! grep -q 'GetThreadUniquePID' "$APPS/ps.c" || fail "ps still uses legacy UniquePID"
! grep -q 'GetThreadUniquePID' "$APPS/top.c" || fail "top still uses legacy UniquePID"

# The old utilities contained several argc+1 loops which accessed argv[argc].
for f in cp.c rm.c val.c mkfs.c; do
    ! grep -Eq 'argc[[:space:]]*\+[[:space:]]*1|\(argc\+1\)' "$APPS/$f" || \
        fail "$f contains an argc+1 argument loop"
done

# val must understand the current Ring3 ELF32 ABI, not only the 2000s flat ABI.
grep -q '0x7f' "$APPS/val.c" || fail "val lacks ELF magic validation"
grep -q '0x80004000' "$APPS/val.c" || fail "val lacks JTMOS Ring3 entry validation"

# mv must implement rename plus a copy/remove cross-device fallback.
grep -q 'rename(' "$APPS/mv.c" || fail "mv lacks rename path"
grep -Fq 'remove(argv[1])' "$APPS/mv.c" || fail "mv lacks copy/remove fallback"

# Historical scripts must never regenerate the canonical .mak files.
! grep -q './bm.sh' "$APPS/buildutils.sh" || fail "buildutils still runs legacy bm.sh"
! grep -q './makgen.pl' "$APPS/bm.sh" || fail "bm.sh can still overwrite ELF32 makefiles"

echo "JTMOS V67.8.56.9 utilities static regression checks: PASS"
