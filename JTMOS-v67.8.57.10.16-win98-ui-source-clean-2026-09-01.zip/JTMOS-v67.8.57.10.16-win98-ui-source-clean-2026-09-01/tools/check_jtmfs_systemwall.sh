#!/bin/sh
set -eu
fail(){ echo "check_jtmfs_systemwall: FAIL: $*" >&2; exit 1; }
H=kernel32/fs/jtmfs/jtmfat.h
J=kernel32/fs/jtmfs/jtmfat.c
W=kernel32/fs/jtmfs/WriteChain.c
R=kernel32/fs/jtmfs/ReadChain.c
F=kernel32/fs/jtmfs/diskcache/flexFat.c
C=kernel32/fs/jtmfs/createfat.c
FMT=kernel32/fs/jtmfs/format.c

grep -q 'jtmfat_firstallocatableblock' "$H" || fail 'allocation-boundary API missing'
grep -q 'first=(int)jtmfat_firstallocatableblock' "$J" || fail 'free-block search does not start at system wall'
grep -q 'i=first' "$J" || fail 'free-block wrap does not return to system wall'
grep -q 'jtmfat_isallocatableblock' "$W" || fail 'write-chain does not validate allocated blocks'
grep -q 'jtmfat_isdatablock' "$W" || fail 'write-chain does not reject protected chain blocks'
grep -q 'jtmfat_isdatablock' "$R" || fail 'read-chain does not reject protected chain blocks'
grep -q 'SYSTEM-WALL refused FAT mutation' "$F" || fail 'central FAT system-area mutation guard missing'
grep -q 'writeblocks1(dnr,0,tmp,blocks)' "$C" || fail 'bootloader write is still cacheable'
grep -q 'readblock1(dnr, 0, tmp)' "$C" || fail 'physical boot-sector readback missing'
grep -q 'pre-format device flush failed' "$FMT" || fail 'pre-format DAPI flush/invalidate barrier missing'

# Current 512-byte HDD geometry: 16 KiB boot + 1 MiB kernel means FAT cannot
# begin before sector 2080.  Keep this arithmetic visible in the regression.
boot_sectors=$((16*1024/512))
kernel_sectors=$((1024*1024/512))
first_fat=$((boot_sectors+kernel_sectors))
[ "$boot_sectors" -eq 32 ] || fail '16 KiB boot geometry changed unexpectedly'
[ "$kernel_sectors" -eq 2048 ] || fail '1 MiB kernel geometry changed unexpectedly'
[ "$first_fat" -eq 2080 ] || fail 'expected FAT floor is sector 2080'

echo "check_jtmfs_systemwall: PASS (HDD sectors 0..2079 protected; normal allocation begins after JTMFS system area)"
