#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail() { echo "check_dosboot_nzip: FAIL: $*" >&2; exit 1; }
D=boot32/dosboot.asm
M=boot32/Makefile
T=Makefile

[ -f "$D" ] || fail "$D missing"
[ -f "$M" ] || fail "$M missing"

grep -q '^%define BOOT_VESA_GRAPHICS 0' "$D" || fail "DOS boot must leave graphics disabled"
grep -q '^%define DOS_READ_HALF_CHUNK 0x8000' "$D" || fail "32 KiB DOS sub-read size missing"
grep -q '^%define DOS_CHUNK_BYTES[[:space:]]*0x10000' "$D" || fail "64 KiB completed chunk size missing"
grep -q 'mov ah,0x3F' "$D" || fail "DOS AH=3F file read missing"
grep -q 'test eax,0x00020000' "$D" || fail "V86 host guard missing"
grep -q 'mov dx,DOS_READ_HALF_CHUNK' "$D" || fail "upper 32 KiB half read missing"
grep -q '^pmode_stream_copy:' "$D" || fail "real->PM chunk copy entry missing"
grep -q '^pmode_stream_copy32:' "$D" || fail "32-bit chunk copier missing"
grep -q 'mov edi,dword \[fs:stream_high_dest\]' "$D" || fail "PM copy does not use high destination"
grep -q 'JTMOS_BOOT_NZIP_STAGING_PHYS' "$D" || fail "shared 16 MiB nzip staging constant missing"
grep -q '^nzip_decompress_kernel32:' "$D" || fail "protected-mode nzip decoder missing"
grep -q 'mov edi,JTMOS_KERNEL_LOAD_PHYS' "$D" || fail "nzip output is not the canonical 1 MiB kernel address"
grep -q 'jmp dword code32_idx:JTMOS_KERNEL_LOAD_PHYS' "$D" || fail "flat final kernel jump missing"
grep -q 'mov word \[es:0x1000\],kchecksum' "$D" || fail "expected raw checksum handoff missing"
grep -q 'mov word \[es:0x1004\],ax' "$D" || fail "DOS boot-drive handoff missing"
grep -q 'mov word \[es:0x7DFE\],0xAA55' "$D" || fail "legacy loader signature handoff missing"
grep -q '^dos_stack:' "$D" || fail "dedicated COM loader stack missing"
grep -q 'cmp dx,\[cs:0x0002\]' "$D" || fail "PSP conventional-memory bound check missing"
grep -q 'mov dword \[stream_remaining\],kernel_nz_bytes' "$D" || fail "exact compressed byte count is not used"

# DOS package uses legal 8.3 names and the exact boot32pm legacy nzip stream.
grep -q '^dosboot.com:' "$M" || fail "DOSBOOT.COM build target missing"
grep -q '^kernel32.nz: ../kernel32/kernel32.bin.nz' "$M" || fail "KERNEL32.NZ is not sourced from canonical kernel32.bin.nz"
grep -q 'cp dosboot.com dosboot/DOSBOOT.COM' "$M" || fail "DOSBOOT.COM package copy missing"
grep -q 'cp kernel32.nz dosboot/KERNEL32.NZ' "$M" || fail "KERNEL32.NZ package copy missing"
grep -q '^dosboot: kernel-nz' "$T" || fail "top-level dosboot target missing"

# Ensure the DOS path did not regress to the old raw 0x10000 staging model.
! grep -Eq 'kernel_raw_loadlimit|mov[[:space:]]+esi,0x00010000' "$D" || \
    fail "legacy whole-raw low-memory staging remains in DOS boot"

echo 'check_dosboot_nzip: PASS (DOS 64 KiB bounce -> PM high staging -> nzip @ 1 MiB)'
