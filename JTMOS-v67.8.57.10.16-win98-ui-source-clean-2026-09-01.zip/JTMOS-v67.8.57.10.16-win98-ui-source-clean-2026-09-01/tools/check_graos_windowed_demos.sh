#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_graos_windowed_demos: FAIL: $*" >&2; exit 1; }
for f in picture plasma plasma2 snake vgaplasma; do
    [ -f "libc/apps/$f.c" ] || fail "$f.c missing"
    grep -q 'graos_demo.h' "libc/apps/$f.c" || fail "$f is not on common GraOS framebuffer path"
    ! grep -Eq 'setv?mode[[:space:]]*\(|drawframe[[:space:]]*\(|waitretrace[[:space:]]*\(' "libc/apps/$f.c" || fail "$f still switches/draws global VGA"
done
grep -q 'addFrameBuffer' libc/apps/graos_demo.h || fail 'window framebuffer attach missing'
grep -q 'refreshWindow' libc/apps/graos_demo.h || fail 'window framebuffer refresh missing'
grep -q 'GRAOS_GSID_KEYPRESSED' libc/apps/graos_demo.h || fail 'GraOS key events missing'
grep -q '/bin/sqsh.bin' libc/apps/gui/terminal.c || fail 'terminal default SQSH path is not absolute'
grep -q 'cmdstore' libc/apps/sqsh.c || fail 'SQSH contiguous command arena missing'
grep -q 'Squirrel Shell' libc/apps/gui/launcher.c || fail 'launcher SQSH entry missing'
for f in snake.bin plasma.bin plasma2.bin vgaplasma.bin picture.bin sqfam.raw labeldemo.bin bitmapdemo.bin textboxdemo.bin; do
    if sed -n '/^CD_ONLY_FILES="/,/^"$/p' tools/build_install_image.sh | grep -qx "$f"; then
        fail "$f is still CD-only"
    fi
done
echo 'check_graos_windowed_demos: PASS (windowed framebuffer demos + SQSH/intro launch path)'
