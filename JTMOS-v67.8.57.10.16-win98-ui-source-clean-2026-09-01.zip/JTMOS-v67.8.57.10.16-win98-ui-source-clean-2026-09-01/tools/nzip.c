/*
 * nzip.c - JTMOS Peanut/Nut Zip adaptive codec, V65 modernization.
 *
 * Compatible decoder for the historical JTMOS stream:
 *   0xFCE3 char packer (RLE)
 *   0xFCE4 absolute back-reference (sequence compressor)
 *   0xFCEE end marker
 *   0xFCEF escaped marker-looking literal pair
 *
 * V65 adds:
 *   0xFCE5 BWT block = BWT -> MTF -> zero-run coding, protected by CRC32.
 *
 * The default encoder works block-by-block.  It encodes the same raw block
 * with the legacy RLE/back-reference path and with BWT.  When BWT is smaller,
 * BWT wins; otherwise the legacy candidate is emitted.  The resulting .nz
 * stream can therefore mix all three compression methods.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "nzip.h"

#if defined(JTMOS_APPLICATION)
#include <jtmos/process.h>
SYSMEMREQ(APPRAM_12288K)
#endif

typedef struct nzip_buffer {
    BYTE *data;
    size_t size;
    size_t capacity;
} NZIP_BUFFER;

typedef struct nzip_stats {
    unsigned long raw_bytes;
    unsigned long legacy_bytes;
    unsigned long bwt_bytes;
    unsigned legacy_blocks;
    unsigned bwt_blocks;
} NZIP_STATS;


#define NZIP_PROGRESS_WIDTH 22

typedef struct nzip_progress_state {
    FILE *input;
    unsigned long total;
    unsigned long done;
    unsigned long step_bytes;
    unsigned long next_report;
    unsigned long start_ms;
    unsigned long last_ms;
    unsigned last_percent;
    int active;
    char label[19];
} NZIP_PROGRESS;

static NZIP_PROGRESS nzip_progress_state;

static unsigned long nzip_progress_now(void)
{
#if defined(JTMOSKERNEL) || defined(JTMOS_APPLICATION)
    return (unsigned long)GetTickCount();
#else
    return 0UL;
#endif
}

static unsigned nzip_progress_percent(unsigned long done,unsigned long total)
{
    if(total==0UL || done>=total) return 100U;
    while(total>0x02000000UL) { total>>=1; done>>=1; }
    return (unsigned)((done*100UL)/total);
}

static void nzip_progress_label(char out[19],const char *name)
{
    unsigned i;
    for(i=0U;i<18U;i++) out[i]=' ';
    out[18]='\0';
    if(name==NULL) return;
    for(i=0U;i<18U && name[i];i++) out[i]=name[i];
}

static void nzip_progress_render(NZIP_PROGRESS *p,int final)
{
    char bar[NZIP_PROGRESS_WIDTH+1];
    unsigned percent,filled,i,eta_s=0U,eta_m=0U,eta_ss=0U;
    unsigned long now,elapsed,remaining,rate,elapsed_s,eta_ms;
    int eta_known=0;
    if(p==NULL || !p->active) return;
    percent=nzip_progress_percent(p->done,p->total);
    now=nzip_progress_now();
    if(!final && percent==p->last_percent) return;
    if(!final && p->last_percent<=100U && now!=0UL && (unsigned long)(now-p->last_ms)<100UL) return;

    filled=(percent*NZIP_PROGRESS_WIDTH)/100U;
    for(i=0U;i<NZIP_PROGRESS_WIDTH;i++) bar[i]=(i<filled)?'#':'-';
    bar[NZIP_PROGRESS_WIDTH]='\0';

    elapsed=(unsigned long)(now-p->start_ms);
    remaining=p->total-p->done;
    if(p->done>0UL && elapsed>=250UL && remaining>0UL) {
        if(p->done>=elapsed) {
            rate=p->done/elapsed;
            if(rate>0UL) {
                eta_ms=(remaining+rate-1UL)/rate;
                eta_s=(unsigned)((eta_ms+999UL)/1000UL);
                eta_known=1;
            }
        } else {
            elapsed_s=(elapsed+999UL)/1000UL;
            rate=elapsed_s ? p->done/elapsed_s : 0UL;
            if(rate>0UL) {
                eta_s=(unsigned)((remaining+rate-1UL)/rate);
                eta_known=1;
            }
        }
    }
    if(final && p->done>=p->total) { eta_s=0U; eta_known=1; }
    eta_m=eta_s/60U;
    eta_ss=eta_s%60U;

    if(final) {
        unsigned elapsed_total_s=(unsigned)((elapsed+999UL)/1000UL);
        printf("\r%s [%s] %3u%% time %02u:%02u",p->label,bar,percent,
               elapsed_total_s/60U,elapsed_total_s%60U);
    } else if(eta_known)
        printf("\r%s [%s] %3u%% ETA %02u:%02u",p->label,bar,percent,eta_m,eta_ss);
    else
        printf("\r%s [%s] %3u%% ETA --:--",p->label,bar,percent);
    if(final) printf("\n");
#if !defined(JTMOSKERNEL)
    fflush(stdout);
#endif
    p->last_percent=percent;
    p->last_ms=now;
}

static void nzip_progress_begin(FILE *input,const char *name,unsigned long total)
{
    NZIP_PROGRESS *p=&nzip_progress_state;
    memset(p,0,sizeof(*p));
    p->input=input;
    p->total=total;
    p->step_bytes=total/100UL;
    if(p->step_bytes==0UL) p->step_bytes=1UL;
    p->next_report=p->step_bytes;
    p->start_ms=nzip_progress_now();
    p->last_ms=p->start_ms;
    p->last_percent=101U;
    p->active=1;
    nzip_progress_label(p->label,name);
    nzip_progress_render(p,0);
}

static void nzip_progress_note(FILE *input,unsigned long count)
{
    NZIP_PROGRESS *p=&nzip_progress_state;
    if(!p->active || p->input!=input || count==0UL) return;
    if(count>p->total-p->done) p->done=p->total;
    else p->done+=count;
    if(p->done<p->next_report && p->done<p->total) return;
    while(p->next_report<=p->done && p->next_report<p->total) {
        if(p->next_report>p->total-p->step_bytes) { p->next_report=p->total; break; }
        p->next_report+=p->step_bytes;
    }
    nzip_progress_render(p,0);
}

static void nzip_progress_end(int success)
{
    NZIP_PROGRESS *p=&nzip_progress_state;
    if(!p->active) return;
    if(success) p->done=p->total;
    nzip_progress_render(p,1);
    p->active=0;
    p->input=NULL;
}

static unsigned long nzip_stream_size(FILE *f)
{
    long cur,end;
    if(f==NULL) return 0UL;
    cur=ftell(f);
    if(cur<0L) return 0UL;
    if(fseek(f,0L,SEEK_END)!=0) return 0UL;
    end=ftell(f);
    if(fseek(f,cur,SEEK_SET)!=0) return 0UL;
    return end>0L ? (unsigned long)end : 0UL;
}

static unsigned nzip_hash3(const BYTE *p)
{
    unsigned v;
    v = (unsigned)p[0] * 251U;
    v ^= (unsigned)p[1] * 31U;
    v ^= (unsigned)p[2] * 257U;
    return v & (NZIP_HASH_SIZE - 1U);
}

static NZIP_UINT32 nzip_crc32(const BYTE *data, size_t length)
{
    NZIP_UINT32 crc;
    size_t i;
    unsigned bit;
    crc = (NZIP_UINT32)0xffffffffUL;
    for(i=0U;i<length;++i) {
        crc ^= (NZIP_UINT32)data[i];
        for(bit=0U;bit<8U;++bit) {
            NZIP_UINT32 mask = (NZIP_UINT32)(0UL - (crc & 1UL));
            crc = (crc >> 1U) ^ ((NZIP_UINT32)0xedb88320UL & mask);
        }
    }
    return crc ^ (NZIP_UINT32)0xffffffffUL;
}

static int put_byte(FILE *f, unsigned value)
{
    return fputc((int)(value & 0xffU),f) == EOF ? -1 : 0;
}

static int put_le16(FILE *f, unsigned value)
{
    if(put_byte(f,value) != 0 || put_byte(f,value >> 8U) != 0) return -1;
    return 0;
}

static int put_le32(FILE *f, NZIP_UINT32 value)
{
    if(put_byte(f,(unsigned)value) != 0
       || put_byte(f,(unsigned)(value >> 8U)) != 0
       || put_byte(f,(unsigned)(value >> 16U)) != 0
       || put_byte(f,(unsigned)(value >> 24U)) != 0) return -1;
    return 0;
}

static int read_byte(FILE *f, unsigned *value)
{
    int c;
    c = fgetc(f);
    if(c == EOF) return 0;
    nzip_progress_note(f,1UL);
    *value = (unsigned)(BYTE)c;
    return 1;
}

static int read_le16(FILE *f, unsigned *value)
{
    unsigned a,b;
    if(read_byte(f,&a) != 1 || read_byte(f,&b) != 1) return -1;
    *value = a | (b << 8U);
    return 0;
}

static int read_le32(FILE *f, NZIP_UINT32 *value)
{
    unsigned a,b,c,d;
    if(read_byte(f,&a) != 1 || read_byte(f,&b) != 1
       || read_byte(f,&c) != 1 || read_byte(f,&d) != 1) return -1;
    *value = (NZIP_UINT32)a | ((NZIP_UINT32)b << 8U)
           | ((NZIP_UINT32)c << 16U) | ((NZIP_UINT32)d << 24U);
    return 0;
}

static int buffer_reserve_limit(NZIP_BUFFER *b, size_t extra, size_t limit)
{
    size_t need,capacity,next;
    BYTE *grown;
    if(extra > (size_t)-1 - b->size) return -1;
    need = b->size + extra;
    if(need > limit) return -1;
    if(need <= b->capacity) return 0;
    capacity = b->capacity ? b->capacity : 4096U;
    while(capacity < need) {
        next = capacity * 2U;
        if(next < capacity || next > limit) next = limit;
        capacity = next;
        if(capacity < need && capacity == limit) return -1;
    }
    grown = (BYTE *)realloc(b->data,capacity);
    if(grown == NULL) return -1;
    b->data = grown;
    b->capacity = capacity;
    return 0;
}

static int enc_reserve(NZIP_BUFFER *b, size_t extra)
{
    return buffer_reserve_limit(b,extra,(size_t)NZIP_MAX_OUTPUT);
}

static void enc_reset(NZIP_BUFFER *b)
{
    b->size = 0U;
}

static int enc_byte(NZIP_BUFFER *b, unsigned value)
{
    if(enc_reserve(b,1U) != 0) return -1;
    b->data[b->size++] = (BYTE)(value & 0xffU);
    return 0;
}

static int enc_le16(NZIP_BUFFER *b, unsigned value)
{
    if(enc_byte(b,value) != 0 || enc_byte(b,value >> 8U) != 0) return -1;
    return 0;
}

static int buffer_byte(NZIP_BUFFER *b, BYTE value)
{
    if(buffer_reserve_limit(b,1U,(size_t)NZIP_MAX_OUTPUT) != 0) return -1;
    b->data[b->size++] = value;
    return 0;
}

static int buffer_append(NZIP_BUFFER *b, const BYTE *data, size_t count)
{
    if(count == 0U) return 0;
    if(data == NULL || buffer_reserve_limit(b,count,(size_t)NZIP_MAX_OUTPUT) != 0) return -1;
    memcpy(b->data+b->size,data,count);
    b->size += count;
    return 0;
}

static int buffer_repeat(NZIP_BUFFER *b, BYTE value, size_t count)
{
    if(buffer_reserve_limit(b,count,(size_t)NZIP_MAX_OUTPUT) != 0) return -1;
    memset(b->data+b->size,value,count);
    b->size += count;
    return 0;
}

static int buffer_backref(NZIP_BUFFER *b, size_t offset, size_t count)
{
    size_t i,known;
    known = b->size;
    /* Historical nzip deliberately forbids overlapping copies. */
    if(offset >= known || count > known-offset) return -1;
    if(buffer_reserve_limit(b,count,(size_t)NZIP_MAX_OUTPUT) != 0) return -1;
    for(i=0U;i<count;++i) b->data[b->size++] = b->data[offset+i];
    return 0;
}

static int write_buffer(FILE *f, const BYTE *data, size_t length)
{
    size_t done,chunk;
    done = 0U;
    while(done < length) {
        chunk = length-done;
        if(chunk > NZIP_IO_CHUNK) chunk = NZIP_IO_CHUNK;
        if(fwrite(data+done,1U,chunk,f) != chunk) return -1;
        done += chunk;
    }
    return 0;
}

static int write_buffer_file(const char *name, const BYTE *data, size_t length)
{
    FILE *f;
    int rc;
    f = fopen(name,"wb");
    if(f == NULL) return -1;
    rc = write_buffer(f,data,length);
    if(fclose(f) != 0) rc = -1;
    return rc;
}

static int read_whole_file(const char *name, BYTE **out, size_t *length)
{
    FILE *f;
    long n;
    BYTE *data;
    size_t got;
    *out = NULL;
    *length = 0U;
    f = fopen(name,"rb");
    if(f == NULL) return -1;
    if(fseek(f,0L,SEEK_END) != 0) { (void)fclose(f); return -1; }
    n = ftell(f);
    if(n < 0L) { (void)fclose(f); return -1; }
    if(fseek(f,0L,SEEK_SET) != 0) { (void)fclose(f); return -1; }
    if((unsigned long)n > (unsigned long)((size_t)-1)) { (void)fclose(f); return -1; }
    data = (BYTE *)malloc(n ? (size_t)n : 1U);
    if(data == NULL) { (void)fclose(f); return -1; }
    got = n ? fread(data,1U,(size_t)n,f) : 0U;
    if(got != (size_t)n || fclose(f) != 0) { free(data); return -1; }
    *out = data;
    *length = (size_t)n;
    return 0;
}

static size_t find_run(const BYTE *data, size_t end, size_t pos)
{
    size_t n;
    n = 1U;
    while(pos+n < end && data[pos+n] == data[pos] && n < NZIP_MAX_MATCH) ++n;
    return n;
}

static size_t find_backref(const BYTE *data, size_t end, size_t pos,
                           NZIP_INT32 *last, size_t *source)
{
    unsigned h;
    NZIP_INT32 candidate;
    size_t limit,n;
    if(pos+2U >= end) return 0U;
    h = nzip_hash3(data+pos);
    candidate = last[h];
    last[h] = (NZIP_INT32)pos;
    if(candidate < 0 || (size_t)candidate >= pos) return 0U;
    if(pos-(size_t)candidate > NZIP_MAX_LOOKBACK) return 0U;
    limit = end-pos;
    if(limit > NZIP_MAX_MATCH) limit = NZIP_MAX_MATCH;
    /* Legacy decoder forbids overlap, so cap to already-known source bytes. */
    if(limit > pos-(size_t)candidate) limit = pos-(size_t)candidate;
    n = 0U;
    while(n < limit && data[(size_t)candidate+n] == data[pos+n]) ++n;
    if(n < NZIP_MIN_BACKREF) return 0U;
    *source = (size_t)candidate;
    return n;
}

static void update_hashes(const BYTE *data, size_t length, size_t start, size_t count,
                          NZIP_INT32 *last)
{
    size_t i,end;
    end = start+count;
    if(end > length) end = length;
    for(i=start;i<end;++i) {
        if(i+2U < length) last[nzip_hash3(data+i)] = (NZIP_INT32)i;
    }
}

static int legacy_encode_block(const BYTE *data, size_t length, size_t start,
                               size_t count, const NZIP_INT32 *history,
                               NZIP_INT32 *work, NZIP_BUFFER *encoded)
{
    size_t pos,end,run,match,from;
    memcpy(work,history,NZIP_HASH_SIZE*sizeof(*work));
    enc_reset(encoded);
    pos = start;
    end = start+count;
    while(pos < end) {
        run = find_run(data,end,pos);
        if(run >= NZIP_MIN_RLE) {
            if(enc_le16(encoded,CODE_CHARPACK) != 0 || enc_le16(encoded,(unsigned)run) != 0
               || enc_byte(encoded,data[pos]) != 0) return -1;
            update_hashes(data,length,pos,run,work);
            pos += run;
            continue;
        }
        match = find_backref(data,end,pos,work,&from);
        if(match >= NZIP_MIN_BACKREF) {
            if(enc_le16(encoded,CODE_ADVPAK) != 0 || enc_le16(encoded,(unsigned)match) != 0
               || enc_byte(encoded,(unsigned)from) != 0
               || enc_byte(encoded,(unsigned)(from >> 8U)) != 0
               || enc_byte(encoded,(unsigned)(from >> 16U)) != 0
               || enc_byte(encoded,(unsigned)(from >> 24U)) != 0) return -1;
            if(match > 1U) update_hashes(data,length,pos+1U,match-1U,work);
            pos += match;
            continue;
        }
        /* All 0xFCxx control words are escaped when their little-endian byte
         * pair occurs literally.  This includes the new E5/FC BWT marker. */
        if(pos+1U < end && data[pos] >= 0xE3U && data[pos] <= 0xFEU
           && data[pos+1U] == 0xFCU) {
            if(enc_le16(encoded,CODE_FIX) != 0 || enc_byte(encoded,data[pos]) != 0
               || enc_byte(encoded,data[pos+1U]) != 0) return -1;
            update_hashes(data,length,pos,2U,work);
            pos += 2U;
        } else {
            if(enc_byte(encoded,data[pos]) != 0) return -1;
            update_hashes(data,length,pos,1U,work);
            ++pos;
        }
    }
    return 0;
}

/* Sort cyclic rotations using the O(n log n) prefix-doubling algorithm. */
static int bwt_transform(const BYTE *src, size_t n, BYTE *mtf, unsigned *primary)
{
    int *p,*c,*pn,*cn,*cnt,*swap;
    size_t i;
    unsigned classes,shift,b,idx;
    BYTE symbols[256];
    size_t count_cap;
    int rc;

    if(src == NULL || mtf == NULL || primary == NULL || n == 0U || n > NZIP_BWT_BLOCK) return -1;
    p = (int *)malloc(n*sizeof(int));
    c = (int *)malloc(n*sizeof(int));
    pn = (int *)malloc(n*sizeof(int));
    cn = (int *)malloc(n*sizeof(int));
    count_cap = n > 256U ? n : 256U;
    cnt = (int *)malloc(count_cap*sizeof(int));
    if(p == NULL || c == NULL || pn == NULL || cn == NULL || cnt == NULL) {
        free(p); free(c); free(pn); free(cn); free(cnt);
        return -1;
    }

    memset(cnt,0,256U*sizeof(int));
    for(i=0U;i<n;++i) ++cnt[src[i]];
    for(i=1U;i<256U;++i) cnt[i] += cnt[i-1U];
    i = n;
    while(i != 0U) {
        --i;
        p[--cnt[src[i]]] = (int)i;
    }
    classes = 1U;
    c[p[0]] = 0;
    for(i=1U;i<n;++i) {
        if(src[p[i]] != src[p[i-1U]]) ++classes;
        c[p[i]] = (int)(classes-1U);
    }

    shift = 1U;
    while((size_t)shift < n) {
        for(i=0U;i<n;++i) {
            int q = p[i]-(int)shift;
            if(q < 0) q += (int)n;
            pn[i] = q;
        }
        memset(cnt,0,(size_t)classes*sizeof(int));
        for(i=0U;i<n;++i) ++cnt[c[pn[i]]];
        for(i=1U;i<(size_t)classes;++i) cnt[i] += cnt[i-1U];
        i = n;
        while(i != 0U) {
            int q;
            --i;
            q = pn[i];
            p[--cnt[c[q]]] = q;
        }
        classes = 1U;
        cn[p[0]] = 0;
        for(i=1U;i<n;++i) {
            int cur1,cur2,prev1,prev2;
            cur1 = c[p[i]];
            cur2 = c[(p[i]+(int)shift)%(int)n];
            prev1 = c[p[i-1U]];
            prev2 = c[(p[i-1U]+(int)shift)%(int)n];
            if(cur1 != prev1 || cur2 != prev2) ++classes;
            cn[p[i]] = (int)(classes-1U);
        }
        swap = c; c = cn; cn = swap;
        if(shift > 0x3fffU) break;
        shift <<= 1U;
    }

    for(i=0U;i<256U;++i) symbols[i] = (BYTE)i;
    *primary = 0U;
    for(i=0U;i<n;++i) {
        BYTE value;
        if(p[i] == 0) *primary = (unsigned)i;
        value = src[(p[i]+(int)n-1)%(int)n];
        idx = 0U;
        while(idx < 256U && symbols[idx] != value) ++idx;
        if(idx >= 256U) { rc = -1; goto done; }
        mtf[i] = (BYTE)idx;
        b = idx;
        while(b > 0U) { symbols[b] = symbols[b-1U]; --b; }
        symbols[0] = value;
    }
    rc = 0;
done:
    free(p); free(c); free(pn); free(cn); free(cnt);
    return rc;
}

static int bwt_pack(const BYTE *src, size_t n, NZIP_BUFFER *payload, unsigned *primary)
{
    BYTE *mtf;
    size_t i,run;
    int rc;
    enc_reset(payload);
    mtf = (BYTE *)malloc(n ? n : 1U);
    if(mtf == NULL) return -1;
    if(bwt_transform(src,n,mtf,primary) != 0) { free(mtf); return -1; }
    i = 0U;
    rc = 0;
    while(i < n) {
        if(mtf[i] == 0U) {
            run = 1U;
            while(i+run < n && mtf[i+run] == 0U && run < 65535U) ++run;
            if(enc_byte(payload,0U) != 0 || enc_le16(payload,(unsigned)run) != 0) { rc=-1; break; }
            i += run;
        } else {
            if(enc_byte(payload,mtf[i]) != 0) { rc=-1; break; }
            ++i;
        }
    }
    free(mtf);
    if(payload->size > 65535U) return -1;
    return rc;
}

static int bwt_unpack(const BYTE *packed, size_t packed_len, size_t raw_len,
                      unsigned primary, BYTE *raw)
{
    BYTE *mtf,*lastcol;
    int *next;
    size_t inpos,outpos,i,run;
    unsigned value,j;
    unsigned counts[256],cursor[256],sum;
    int rc;

    if(raw == NULL || packed == NULL || raw_len == 0U || raw_len > NZIP_BWT_BLOCK
       || primary >= raw_len) return -1;
    mtf = (BYTE *)malloc(raw_len);
    lastcol = (BYTE *)malloc(raw_len);
    next = (int *)malloc(raw_len*sizeof(int));
    if(mtf == NULL || lastcol == NULL || next == NULL) {
        free(mtf); free(lastcol); free(next); return -1;
    }

    inpos = 0U;
    outpos = 0U;
    while(inpos < packed_len && outpos < raw_len) {
        value = packed[inpos++];
        if(value == 0U) {
            if(inpos+2U > packed_len) { rc=-1; goto done; }
            run = (size_t)packed[inpos] | ((size_t)packed[inpos+1U] << 8U);
            inpos += 2U;
            if(run == 0U || run > raw_len-outpos) { rc=-1; goto done; }
            memset(mtf+outpos,0,run);
            outpos += run;
        } else {
            mtf[outpos++] = (BYTE)value;
        }
    }
    if(outpos != raw_len || inpos != packed_len) { rc=-1; goto done; }

    {
        BYTE list[256];
        for(i=0U;i<256U;++i) list[i] = (BYTE)i;
        for(i=0U;i<raw_len;++i) {
            BYTE byte;
            value = (unsigned)mtf[i];
            if(value >= 256U) { rc=-1; goto done; }
            byte = list[value];
            lastcol[i] = byte;
            j = value;
            while(j > 0U) { list[j] = list[j-1U]; --j; }
            list[0] = byte;
        }
    }

    memset(counts,0,sizeof(counts));
    for(i=0U;i<raw_len;++i) ++counts[lastcol[i]];
    sum = 0U;
    for(i=0U;i<256U;++i) {
        cursor[i] = sum;
        sum += counts[i];
    }
    for(i=0U;i<raw_len;++i) {
        value = lastcol[i];
        next[cursor[value]++] = (int)i;
    }
    j = primary;
    for(i=0U;i<raw_len;++i) {
        j = (unsigned)next[j];
        if(j >= raw_len) { rc=-1; goto done; }
        raw[i] = lastcol[j];
    }
    rc = 0;
done:
    free(mtf); free(lastcol); free(next);
    return rc;
}

int nzip_output_name(char *output, size_t capacity, const char *source)
{
    size_t n;
    if(output == NULL || source == NULL || capacity == 0U) return -1;
    n = strlen(source);
    if(n < 3U || source[n-3U] != '.' || source[n-2U] != 'n' || source[n-1U] != 'z') return -1;
    if(n-2U > capacity) return -1;
    memcpy(output,source,n-3U);
    output[n-3U] = '\0';
    return 0;
}

void unNutFname(char *output, const char *source)
{
    size_t n;
    if(output == NULL) return;
    output[0] = '\0';
    if(source == NULL) return;
    n = strlen(source);
    if(n < 3U || source[n-3U] != '.' || source[n-2U] != 'n' || source[n-1U] != 'z') return;
    memcpy(output,source,n-3U);
    output[n-3U] = '\0';
}

int nzip_compress_mode(const char *source, const char *destination, int mode)
{
    BYTE *data;
    size_t length,pos,block_len;
    NZIP_INT32 *history,*work;
    NZIP_BUFFER legacy,bwt;
    FILE *out;
    int rc,use_bwt,bwt_ok;
    unsigned i,primary;
    size_t bwt_record_size;
    NZIP_STATS stats;

    data = NULL;
    history = NULL;
    work = NULL;
    out = NULL;
    memset(&legacy,0,sizeof(legacy));
    memset(&bwt,0,sizeof(bwt));
    memset(&stats,0,sizeof(stats));
    rc = 1;
    if(source == NULL || destination == NULL) return 1;
    if(mode != NZIP_MODE_AUTO && mode != NZIP_MODE_LEGACY && mode != NZIP_MODE_BWT) return 1;
    if(read_whole_file(source,&data,&length) != 0) {
        fprintf(stderr,"nzip: unable to read %s\n",source);
        goto done;
    }
    if(length > 0x7fffffffUL) {
        fprintf(stderr,"nzip: source too large for 32-bit back-reference offsets\n");
        goto done;
    }
    history = (NZIP_INT32 *)malloc(NZIP_HASH_SIZE*sizeof(*history));
    work = (NZIP_INT32 *)malloc(NZIP_HASH_SIZE*sizeof(*work));
    if(history == NULL || work == NULL) { fprintf(stderr,"nzip: out of memory\n"); goto done; }
    for(i=0U;i<NZIP_HASH_SIZE;++i) history[i] = (NZIP_INT32)-1;
    out = fopen(destination,"wb");
    if(out == NULL) { fprintf(stderr,"nzip: unable to create %s\n",destination); goto done; }

    pos = 0U;
    while(pos < length) {
        block_len = length-pos;
        if(block_len > NZIP_BWT_BLOCK) block_len = NZIP_BWT_BLOCK;
        if(legacy_encode_block(data,length,pos,block_len,history,work,&legacy) != 0) {
            fprintf(stderr,"nzip: legacy encoder ran out of memory\n"); goto done;
        }

        bwt_ok = 0;
        primary = 0U;
        bwt_record_size = (size_t)-1;
        if(mode != NZIP_MODE_LEGACY && block_len >= NZIP_BWT_MIN_BLOCK) {
            if(bwt_pack(data+pos,block_len,&bwt,&primary) == 0) {
                bwt_record_size = NZIP_BWT_HEADER_SIZE+bwt.size;
                bwt_ok = 1;
            }
        }
        use_bwt = 0;
        if(bwt_ok) {
            if(mode == NZIP_MODE_BWT || bwt_record_size < legacy.size) use_bwt = 1;
        }

        if(use_bwt) {
            NZIP_UINT32 crc;
            crc = nzip_crc32(data+pos,block_len);
            if(put_le16(out,CODE_BWT) != 0
               || put_le16(out,(unsigned)block_len) != 0
               || put_le16(out,primary) != 0
               || put_le16(out,(unsigned)bwt.size) != 0
               || put_le32(out,crc) != 0
               || write_buffer(out,bwt.data,bwt.size) != 0) goto done;
            stats.bwt_bytes += (unsigned long)bwt_record_size;
            ++stats.bwt_blocks;
        } else {
            if(write_buffer(out,legacy.data,legacy.size) != 0) goto done;
            stats.legacy_bytes += (unsigned long)legacy.size;
            ++stats.legacy_blocks;
        }
        stats.raw_bytes += (unsigned long)block_len;
        update_hashes(data,length,pos,block_len,history);
        pos += block_len;
    }
    if(put_le16(out,CODE_END) != 0 || fflush(out) != 0) goto done;
    rc = 0;

done:
    if(out != NULL && fclose(out) != 0) rc = 1;
    free(history); free(work); free(legacy.data); free(bwt.data); free(data);
    if(rc == 0) {
        printf("nzip: %s -> %s complete\n",source,destination);
        printf("nzip: raw=%lu bytes, BWT blocks=%u (%lu bytes), legacy blocks=%u (%lu bytes)\n",
               stats.raw_bytes,stats.bwt_blocks,stats.bwt_bytes,
               stats.legacy_blocks,stats.legacy_bytes);
    } else {
        (void)remove(destination);
    }
    return rc;
}

int nzip_compress(const char *source, const char *destination)
{
    return nzip_compress_mode(source,destination,NZIP_MODE_AUTO);
}

int nzip_uncompress(const char *source, const char *destination)
{
    FILE *in;
    NZIP_BUFFER out;
    int pending,ended,rc;
    unsigned b0,b1,code,length,value,primary,packed_len;
    NZIP_UINT32 offset,stored_crc,actual_crc;
    unsigned long input_size;
    int progress_started;

    in = NULL;
    memset(&out,0,sizeof(out));
    pending = -1;
    ended = 0;
    rc = 1;
    input_size = 0UL;
    progress_started = 0;
    if(source == NULL || destination == NULL) return 1;
    in = fopen(source,"rb");
    if(in == NULL) { fprintf(stderr,"nzip: unable to open %s\n",source); goto done; }
    input_size=nzip_stream_size(in);
    if(input_size>0UL) {
        nzip_progress_begin(in,source,input_size);
        progress_started=1;
    }

    while(!ended) {
        int r;
        if(pending >= 0) { b0 = (unsigned)pending; pending = -1; r = 1; }
        else r = read_byte(in,&b0);
        if(r == 0) { fprintf(stderr,"nzip: truncated stream (missing end marker)\n"); goto done; }

        if(b0 == 0xE3U || b0 == 0xE4U || b0 == 0xE5U
           || b0 == 0xEEU || b0 == 0xEFU) {
            if(read_byte(in,&b1) != 1) { fprintf(stderr,"nzip: truncated marker\n"); goto done; }
            code = b0 | (b1 << 8U);
            if(code == CODE_END) {
                ended = 1;
                break;
            }
            if(code == CODE_END_V65_BROKEN) {
                /* The accidental EE/FE marker is ambiguous with ordinary
                 * literal data.  Accept it only when it is physically the
                 * final word in the file; otherwise preserve both bytes. */
                if(read_byte(in,&value) == 0) {
                    ended = 1;
                    break;
                }
                if(buffer_byte(&out,(BYTE)b0) != 0
                   || buffer_byte(&out,(BYTE)b1) != 0) goto oom_or_bad;
                pending = (int)value;
                continue;
            }
            if(code == CODE_FIX) {
                if(read_byte(in,&b0) != 1 || read_byte(in,&b1) != 1
                   || buffer_byte(&out,(BYTE)b0) != 0 || buffer_byte(&out,(BYTE)b1) != 0) goto oom_or_bad;
                continue;
            }
            if(code == CODE_CHARPACK) {
                if(read_le16(in,&length) != 0 || read_byte(in,&value) != 1 || length == 0U) {
                    fprintf(stderr,"nzip: invalid/truncated char-pack record\n"); goto done;
                }
                if(buffer_repeat(&out,(BYTE)value,(size_t)length) != 0) goto oom_or_bad;
                continue;
            }
            if(code == CODE_ADVPAK) {
                if(read_le16(in,&length) != 0 || read_le32(in,&offset) != 0 || length == 0U) {
                    fprintf(stderr,"nzip: invalid/truncated back-reference\n"); goto done;
                }
                if(buffer_backref(&out,(size_t)offset,(size_t)length) != 0) {
                    fprintf(stderr,"nzip: invalid back-reference offset/length\n"); goto done;
                }
                continue;
            }
            if(code == CODE_BWT) {
                BYTE *packed,*raw;
                size_t got;
                if(read_le16(in,&length) != 0 || read_le16(in,&primary) != 0
                   || read_le16(in,&packed_len) != 0 || read_le32(in,&stored_crc) != 0
                   || length == 0U || length > NZIP_BWT_BLOCK || primary >= length
                   || packed_len == 0U || packed_len > (2U*NZIP_BWT_BLOCK+16U)) {
                    fprintf(stderr,"nzip: invalid/truncated BWT block header\n"); goto done;
                }
                packed = (BYTE *)malloc((size_t)packed_len);
                raw = (BYTE *)malloc((size_t)length);
                if(packed == NULL || raw == NULL) { free(packed); free(raw); goto oom_or_bad; }
                got = fread(packed,1U,(size_t)packed_len,in);
                if(got != 0U) nzip_progress_note(in,(unsigned long)got);
                if(got != (size_t)packed_len || bwt_unpack(packed,(size_t)packed_len,
                   (size_t)length,primary,raw) != 0) {
                    free(packed); free(raw);
                    fprintf(stderr,"nzip: corrupt BWT payload\n"); goto done;
                }
                actual_crc = nzip_crc32(raw,(size_t)length);
                if(actual_crc != stored_crc) {
                    free(packed); free(raw);
                    fprintf(stderr,"nzip: BWT CRC32 mismatch\n"); goto done;
                }
                if(buffer_append(&out,raw,(size_t)length) != 0) {
                    free(packed); free(raw); goto oom_or_bad;
                }
                free(packed); free(raw);
                continue;
            }
            /* Not a recognized control code: first byte is literal and the
             * second one belongs to the following token. */
            if(buffer_byte(&out,(BYTE)b0) != 0) goto oom_or_bad;
            pending = (int)b1;
        } else {
            if(buffer_byte(&out,(BYTE)b0) != 0) goto oom_or_bad;
        }
    }

    if(!ended) goto done;
    if(write_buffer_file(destination,out.data,out.size) != 0) {
        fprintf(stderr,"nzip: unable to write %s\n",destination);
        goto done;
    }
    rc = 0;
    if(progress_started) { nzip_progress_end(1); progress_started=0; }
    printf("nzip: %s -> %s, %lu bytes\n",source,destination,(unsigned long)out.size);
    goto done;

oom_or_bad:
    fprintf(stderr,"nzip: output exceeds memory/format limit (%lu bytes max)\n",
            (unsigned long)NZIP_MAX_OUTPUT);
done:
    if(progress_started) nzip_progress_end(rc==0);
    if(in != NULL) (void)fclose(in);
    free(out.data);
    if(rc != 0) (void)remove(destination);
    return rc;
}

static int compress_mode_name(const char *fname, int mode)
{
    char *output;
    size_t n;
    int rc;
    if(fname == NULL) return 1;
    n = strlen(fname);
    if(n > (size_t)-1-4U) return 1;
    output = (char *)malloc(n+4U);
    if(output == NULL) return 1;
    memcpy(output,fname,n);
    memcpy(output+n,".nz",4U);
    rc = nzip_compress_mode(fname,output,mode);
    free(output);
    return rc;
}

int compress(const char *fname)
{
    return compress_mode_name(fname,NZIP_MODE_AUTO);
}

int uncompress(const char *fname)
{
    char *output;
    size_t n;
    int rc;
    if(fname == NULL) return 1;
    n = strlen(fname);
    output = (char *)malloc(n+1U);
    if(output == NULL) return 1;
    if(nzip_output_name(output,n+1U,fname) != 0) {
        fprintf(stderr,"nzip: '%s' does not end in .nz\n",fname);
        free(output);
        return 1;
    }
    rc = nzip_uncompress(fname,output);
    free(output);
    return rc;
}

/* CLI helper used by nzipMain.c. */
int nzip_compress_named_mode(const char *fname, int mode)
{
    return compress_mode_name(fname,mode);
}
