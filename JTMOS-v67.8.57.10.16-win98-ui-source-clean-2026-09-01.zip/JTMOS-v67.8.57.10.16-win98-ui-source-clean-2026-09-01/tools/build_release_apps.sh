#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
APPS="$ROOT/libc/apps"

# One canonical Ring3 userspace tree. libc/apps/gui contains GraOS itself and
# the native Terminal/Control Panel/Launcher clients.
make -C "$APPS" clean
make -C "$APPS" check

for f in unz.bin sqa.bin nzip.bin ls.bin cp.bin edit.bin filer.bin iview.bin top.bin sound.bin irqdma.bin; do
    [ -s "$APPS/$f" ] || { echo "build_release_apps: $f was not built" >&2; exit 1; }
done
for f in graos.bin terminal.bin controlpanel.bin graosctl.bin launcher.bin labeldemo.bin bitmapdemo.bin graostaskbar.bin textboxdemo.bin; do
    [ -s "$APPS/gui/$f" ] || { echo "build_release_apps: gui/$f was not built" >&2; exit 1; }
done
