#!/usr/bin/env python3
"""Convert headerless 8-bpp MCGA indexed RAW pixels to RGBA32.

Palette is parsed from kernel32/drivers/vga/vgapal.h.  The output byte order is
R,G,B,A.  Use --transparent-index N for legacy colour-key assets such as the
GraOS mouse cursor; the RGB channels still retain the exact MCGA palette value.

Usage:
  convert_raw_mcga_to_rgba.py INPUT.raw OUTPUT.raw [--transparent-index N]
"""
from pathlib import Path
import re,sys
if len(sys.argv) not in (3,5):
    raise SystemExit("usage: convert_raw_mcga_to_rgba.py INPUT.raw OUTPUT.raw [--transparent-index N]")
transparent=None
if len(sys.argv)==5:
    if sys.argv[3] != "--transparent-index":
        raise SystemExit("expected --transparent-index N")
    transparent=int(sys.argv[4],0)&255
root=Path(__file__).resolve().parents[1]
t=(root/"kernel32/drivers/vga/vgapal.h").read_text()
n=[int(x) for x in re.findall(r"(?<![A-Za-z0-9_])-?\d+",t.split("{",1)[1].split("}",1)[0])]
if len(n)!=768: raise SystemExit("invalid vgapal.h")
def e(v): v&=63; return (v<<2)|(v>>4)
pal=[(e(n[i*3]),e(n[i*3+1]),e(n[i*3+2])) for i in range(256)]
src=Path(sys.argv[1]).read_bytes(); out=bytearray(len(src)*4)
for i,c in enumerate(src):
    r,g,b=pal[c]; a=0 if transparent is not None and c==transparent else 255
    out[i*4:i*4+4]=bytes((r,g,b,a))
Path(sys.argv[2]).write_bytes(out)
