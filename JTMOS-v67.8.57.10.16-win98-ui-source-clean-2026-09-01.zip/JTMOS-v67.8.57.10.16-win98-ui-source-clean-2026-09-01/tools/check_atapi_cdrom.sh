#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
IMG="$ROOT/utilities.iso"
SQA="$ROOT/tools/utilities.sqa"
RUN="$ROOT/run_jtmos_qemu.sh"
TESTRUN="$ROOT/run_atapi_test_qemu.sh"

grep -Fq -- '-cdrom "$ROOT_CDROM"' "$RUN" || { echo "ATAPI check: QEMU launcher lacks root-media -cdrom" >&2; exit 1; }
grep -Fq -- '-cdrom "$UTILS_CDROM"' "$TESTRUN" || { echo "ATAPI check: focused launcher lacks -cdrom" >&2; exit 1; }
grep -Fq -- 'if=floppy,index=1' "$RUN" || { echo "ATAPI check: split-root launcher lacks B: attachment" >&2; exit 1; }

if [ ! -f "$SQA" ] || [ ! -f "$IMG" ]; then
    echo "ATAPI utilities CD-ROM static validation: PASS (media not built)"
    exit 0
fi
bytes=$(wc -c < "$IMG")
[ $((bytes % 2048)) -eq 0 ] || { echo "ATAPI check: CD image size $bytes is not 2048-byte aligned" >&2; exit 1; }
magic=$(dd if="$IMG" bs=1 skip=2048 count=8 2>/dev/null)
[ "$magic" = "SQARC520" ] || { echo "ATAPI check: SQARC520 missing at byte 2048" >&2; exit 1; }
printf 'ATAPI utilities CD-ROM validation: PASS (%s bytes, %s sectors)\n' "$bytes" "$((bytes / 2048))"
