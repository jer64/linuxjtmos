#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
RAW="$ROOT/kernel32/kernel32.bin"
NZ="$RAW.nz"
NZIP="$ROOT/tools/nzip"

[ -f "$RAW" ] || { echo "build_kernel_nz: $RAW missing; link kernel32 first" >&2; exit 1; }
[ -x "$NZIP" ] || { echo "build_kernel_nz: host tools/nzip missing; run make host-tools" >&2; exit 1; }

rm -f "$NZ"
"$NZIP" --legacy "$RAW"
[ -f "$NZ" ] || { echo "build_kernel_nz: nzip did not create $NZ" >&2; exit 1; }

RAW_BYTES=$(wc -c < "$RAW")
NZ_BYTES=$(wc -c < "$NZ")
SECTORS=$(( (NZ_BYTES + 511) / 512 ))
PADDED=$(( SECTORS * 512 ))
CHUNKS=$(( (SECTORS + 127) / 128 ))

[ "$RAW_BYTES" -le $((1024 * 1024)) ] || {
    echo "build_kernel_nz: raw kernel exceeds 1 MiB linked image window ($RAW_BYTES bytes)" >&2
    rm -f "$NZ"
    exit 1
}
[ "$NZ_BYTES" -le $((1024 * 1024)) ] || {
    echo "build_kernel_nz: compressed kernel exceeds 1 MiB PMODE streaming window ($NZ_BYTES bytes)" >&2
    rm -f "$NZ"
    exit 1
}
[ "$SECTORS" -le 2048 ] || {
    echo "build_kernel_nz: compressed kernel exceeds 2048-sector boot payload ($SECTORS sectors)" >&2
    rm -f "$NZ"
    exit 1
}

printf 'kernel32 nzip: raw=%s bytes nz=%s bytes disk=%s bytes/%s sectors pmode_chunks=%s mode=legacy-stream64k\n' \
    "$RAW_BYTES" "$NZ_BYTES" "$PADDED" "$SECTORS" "$CHUNKS"
