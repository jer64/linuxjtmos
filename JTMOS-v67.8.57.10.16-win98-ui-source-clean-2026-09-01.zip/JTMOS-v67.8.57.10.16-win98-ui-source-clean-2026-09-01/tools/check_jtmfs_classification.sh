#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail() { echo "check_jtmfs_classification: FAIL: $*" >&2; exit 1; }

H=kernel32/fs/jtmfs/dirtype.h
[ -f "$H" ] || fail "$H missing"

grep -q '^#define JTMFS_ATTR_MASK[[:space:]]*0x3FU' "$H" || fail "attribute mask is not 0x3f"
grep -q '^#define JTMFS_CLASS_MASK[[:space:]]*0xC0U' "$H" || fail "class mask is not 0xc0"
grep -q '^#define JTMFS_CLASS_DIRNAME[[:space:]]*0x40U' "$H" || fail "DIRNAME ABI changed"
grep -q '^#define JTMFS_CLASS_DIRECTORY[[:space:]]*0x80U' "$H" || fail "DIRECTORY ABI changed"
grep -q '^#define JTMFS_ID_WRITEONLY[[:space:]]*JTMFS_ATTR_READONLY' "$H" || fail "legacy WRITEONLY alias missing"
grep -q '^#define JTMFS_TYPE_IS_VALID(t)' "$H" || fail "classification validator missing"

# Public libc copies must be byte-identical to the kernel definition so old
# applications and new kernel code can never silently disagree about the disk ABI.
for P in \
    libc/include/jtmos/dirtype.h \
    libc/libc/include/jtmos/dirtype.h \
    libc/libc/include2026/jtmos/dirtype.h
do
    cmp -s "$H" "$P" || fail "$P diverges from canonical $H"
done

TMP=${TMPDIR:-/tmp}/jtmos-jtmfs-classify-$$
trap 'rm -f "$TMP.c" "$TMP"' EXIT HUP INT TERM
cat > "$TMP.c" <<'EOF'
#include "kernel32/fs/jtmfs/dirtype.h"
int main(void)
{
    unsigned int hidden_dir=JTMFS_TYPE_BUILD(JTMFS_CLASS_DIRECTORY,JTMFS_ATTR_HIDDEN);
    unsigned int system_dn=JTMFS_TYPE_BUILD(JTMFS_CLASS_DIRNAME,JTMFS_ATTR_SYSTEM);
    unsigned int exec_file=JTMFS_TYPE_BUILD(JTMFS_CLASS_FILE,JTMFS_ATTR_ARCHIVE|JTMFS_ATTR_EXECUTABLE);
    if(hidden_dir != (JTMFS_ID_DIRECTORY|JTMFS_ID_HIDDEN)) return 1;
    if(!JTMFS_TYPE_IS_DIRECTORY(hidden_dir) || JTMFS_TYPE_IS_FILE(hidden_dir)) return 2;
    if(!JTMFS_TYPE_IS_DIRNAME(system_dn)) return 3;
    if(!JTMFS_TYPE_IS_FILE(exec_file)) return 4;
    if(!JTMFS_TYPE_HAS_ATTR(exec_file,JTMFS_ID_ARCHIVE)) return 5;
    if(!JTMFS_TYPE_IS_VALID(hidden_dir)) return 6;
    if(JTMFS_TYPE_IS_VALID(JTMFS_CLASS_RESERVED)) return 7;
    if(JTMFS_TYPE_IS_VALID(0x100U)) return 8;
    return 0;
}
EOF
cc -std=gnu89 -Wall -Wextra -I. "$TMP.c" -o "$TMP" || fail "classification smoke compile failed"
"$TMP" || fail "classification smoke runtime failed ($?)"

# New live code must classify on the class mask, not compare a combined entry
# directly against a bare DIRECTORY/DIRNAME value.  Historical snapshots are
# intentionally excluded from this source-policy check.
if grep -RIn \
    --include='*.c' --include='*.h' \
    --exclude='*.v52-before-fix' \
    -E '(==|!=)[[:space:]]*JTMFS_ID_(DIRECTORY|DIRNAME)|JTMFS_ID_(DIRECTORY|DIRNAME)[[:space:]]*(==|!=)' \
    kernel32 libc/apps graos-host/apps graos-host/kernel32/sh \
    >/tmp/jtmos-jtmfs-classify-grep-$$ 2>/dev/null
then
    cat /tmp/jtmos-jtmfs-classify-grep-$$ >&2
    rm -f /tmp/jtmos-jtmfs-classify-grep-$$
    fail "exact DIRECTORY/DIRNAME comparison remains"
fi
rm -f /tmp/jtmos-jtmfs-classify-grep-$$

grep -q 'DIRDB_KIND_DIRECTORY' kernel32/fs/jtmfs/diskcache/dirdb.h || fail "DirDB kind namespace missing"
grep -q 'DIRDB_KIND_IS_VALID' kernel32/fs/jtmfs/diskcache/dirdbCorruption.c || fail "DirDB kind validation missing"
grep -q 'JTMFS_TYPE_IS_VALID(fe->type)' kernel32/fs/jtmfs/jtmfsIntegrity.c || fail "fsck entry classification validation missing"

echo "check_jtmfs_classification: PASS (class mask + attributes + DirDB separation)"
