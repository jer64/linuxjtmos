#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail(){ echo "check_edit_cursor: FAIL: $*" >&2; exit 1; }
E=libc/apps/edit.c
U=libc/apps/editEditor.c
H=libc/apps/edit.h
K=kernel32/drivers/ega/ega.c
T=kernel32/drivers/term/term.c
S=kernel32/core/chiplevel/syscallcodes.h
SC=kernel32/core/chiplevel/scs.c
PC=libc/libc/modern/process_console.c
C=libc/include/conio.h
for f in "$E" "$U" "$H" "$K" "$T" "$S" "$SC" "$PC" "$C"; do [ -f "$f" ] || fail "$f missing"; done
grep -q '^#define MAX_PER_LINE[[:space:]]*81' "$H" || fail '80 chars + NUL line capacity missing'
grep -q 'dirty_line' "$H" || fail 'dirty-line redraw state missing'
grep -q 'MarkLineDirty' "$E" || fail 'incremental line redraw missing'
grep -q "if(ch=='\\\\t')" "$E" || fail 'tab expansion on file load missing'
grep -q 'InsertTab' "$E" || fail 'interactive Tab support missing'
grep -q 'SplitLine' "$E" || fail 'Enter line split missing'
grep -q 'DeleteAtCursor' "$E" || fail 'Delete editing missing'
grep -q '_setcursortype(_NOCURSOR)' "$U" || fail 'cursor is not suppressed during repaint'
grep -q '_setcursortype(_NORMALCURSOR)' "$U" || fail 'cursor is not restored at final edit position'
grep -q 'F1 Help.*F2 Save.*F3 Ins/Ovr' "$U" || fail 'DOS-style command bar missing'
grep -q '^#define SYS_setcursortype[[:space:]]*150' "$S" || fail 'cursor syscall ABI missing'
grep -q 'scall_setcursortype' "$SC" || fail 'cursor syscall handler missing'
grep -q 'ter!=GetInputTerminal()) return -1' "$SC" || fail 'GraOS/userspace cursor is not focus-gated'
grep -q 'SYS_setcursortype' "$PC" || fail 'libc cursor syscall wrapper missing'
grep -q '#define _NOCURSOR 0' "$C" || fail 'public cursor constants missing'
grep -q 's->id==GetInputTerminal()' "$K" || fail 'EGA cursor is not focus-gated'
grep -q 'locatetxtcursor(s)' "$T" || fail 'CursorState does not refresh hardware/software cursor'
! grep -q '#define _setcursortype(x)' "$C" || fail 'legacy no-op cursor macro remains'
echo 'check_edit_cursor: PASS (dirty redraw + focused kernel cursor + editor functions)'
