JTMOS V19 COM2 / SLIP networking repair (2026-08-19)

Default link:
  COM2, conventional PC base 0x2F8, IRQ3, 115200 bps, 8N1
  JTMOS local IPv4 remains 10.0.0.5/24 in drivers/tcp/tcpConfig.c.

Server modes:
  1. Legacy login/SLiRP: detects login:, sends configured slip/slip credentials,
     accepts the old address/banner sequence when present.
  2. Direct SLIP server: if no login prompt appears, sends RFC1055 END framing
     synchronization and brings the link online without requiring a text banner.

Important V18 bugs fixed:
  * SLIP config hard-coded COM1 despite keropt saying COM2.
  * fallback COM2/COM3 I/O bases were swapped.
  * SetSerialPortSpeed disabled UART OUT2, preventing IRQ3 receive interrupts.
  * WaitSerialString could loop forever because its retry goto bypassed timeout.
  * slip_gets used an uninitialized index.
  * slipStack allocated malloc(sp.len) while sp.len was initially zero.
  * SLIP TX could silently lose bytes when the serial software FIFO was full.
  * partial/oversize RFC1055 frames could leave receive handling stuck/corrupt.

Legacy uIP restoration:
  The uIP sources were restored from Jari Tuominen's jtm32-150206.tar.bz2
  source archive and updated to build with the 2026 GCC/JTMOS tree. uIP is the
  default SLIP network consumer (USE_LEGACY_UIP=1). The newer drivers/tcp stack
  remains selectable with USE_LEGACY_UIP=0.
