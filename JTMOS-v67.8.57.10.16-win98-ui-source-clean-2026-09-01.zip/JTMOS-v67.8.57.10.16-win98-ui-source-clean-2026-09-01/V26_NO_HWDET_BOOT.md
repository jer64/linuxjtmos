# JTMOS V26: HWDET skipped during boot

The boot-time `hwdet()` call has been removed from both the normal KernelInit path
and the legacy XML init pass. The detector implementation remains in the source
and kernel, so it can be reintroduced later as an explicit/manual service without
blocking normal JTMOS/GraOS startup.

After partition/storage initialization the kernel now logs:

    HWDET: boot-time hardware detection skipped.

and proceeds directly to the GraOS boot readiness/install path.
