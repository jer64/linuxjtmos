# JTMOS V67 - ELF32 ring-3 multiprocess release

V67 fixes LaunchApp error #2 for small ELF32 executables and completes the first real ring-3 userspace path.

## Architecture
- Plain PID process identity; no UNIPID in the V67 application path.
- One hardware TSS per PID at selector `0x100 + PID*8`.
- Shared flat `USER_CS=0x33` and `USER_DS=0x3b` for all ELF32 processes.
- Four private page tables per PID cover `0x80000000..0x80ffffff` (16 MiB).
- Process PDE/PTE entries carry the IA-32 U/S bit.
- Every TSS owns a private ring-0 `ss0/esp0` stack for privilege transitions.
- TSS descriptors are DPL0; ring-3 cannot jump directly to another hardware task.
- The TSS I/O-map base lies beyond the TSS limit, so raw CPL3 port I/O is denied by default.
- `INT 0x7f` is a DPL3 interrupt gate to the ring-0 syscall handler.

## ELF memory layout
`PT_LOAD image -> >=64 KiB private heap -> 4 KiB unmapped guard -> 256 KiB user stack`.

V66 could reserve only image+guard+stack for a small executable and reject the exact boundary with generic error #2. V67 always reserves a real heap and uses a valid boundary check.

## Multiple simultaneous ELF32 instances
Every launch receives a new PID, TSS, backing allocation, process page tables, heap, stack and FD state. Central Process serializes only the executable staging/creation transaction so two callers cannot overwrite its shared staging buffer; once committed, the created processes are independent and execute concurrently. Therefore the same executable can be launched repeatedly and multiple ELF32 programs may all use entry address `0x80004000` simultaneously. The scheduler switches the selected PID's page tables on every task switch. Process teardown clears those PTEs before PID reuse.

## Runtime test
After boot, start the same simple external program twice and another external program once. Verify three distinct PIDs and that all continue to make `INT 0x7f` syscalls while the scheduler switches among them.

## Launch rollback and PID reuse
If ELF mapping fails after PID/TSS creation, V67 now destroys that not-yet-runnable task while interrupts remain disabled and frees its backing allocation. Normal process exit clears the PID's user PTEs before the PID can be reused. A failed launch can therefore no longer leave a phantom runnable task or stale address-space mapping behind.
