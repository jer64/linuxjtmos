#ifndef _JTMOS_FSUSAGE_H
#define _JTMOS_FSUSAGE_H
#include "basdef.h"

typedef struct {
    DWORD total_units;
    DWORD free_units;
    DWORD unit_size;
    DWORD flags;
} JTMOS_FSUSAGE;

#define JTMOS_FSUSAGE_JTMFS 0x00000001UL
#endif
