/*** slip.c - SLIP DEVICE DRIVER ***
 * SERIAL LINE PROTOCOL DRIVER
 * (C) 2002-2005 by
 *	Jari Tuominen(jari@vunet.org).
 * Programmed according to RFC1055.
 * Feel free to spread and use this code.
 *
 * This device driver is dependent on two functions:
 *	- send_char
 *	- recv_char
 *
 * I programmed these functions to be simple wrappers
 * to the serial port driver's functions.
 * You can easily select the serial port number,
 * that is being used for slip connection by
 * changing the #define entry in slip.h.
 */

//
#include <stdio.h>
#include "slip.h"
#include "serial.h"
#include "slipLogin.h"
#include "slipStack.h"

// SLIP has been dialed online yet?
// Default is 0(=offline).
char slipOnline = 0;

//
void slip_send_char(int c)
{
	/* The serial TX FIFO is software buffered.  Do not silently lose SLIP
	 * octets when that buffer is temporarily full. */
	while(serial_put_owned(slip.port, c, SERIAL_OWNER_SLIP)!=0)
		SwitchToThread();
}

//
void slip_gets(char *buf, int l_buf)
{
	DWORD idle_start;
	int i,ch;

	if(buf==NULL || l_buf<=0)
		return;

	i = 0;
	buf[0] = 0;
	idle_start = GetTickCount();
	while(i < l_buf-1)
	{
		ch = slip_recv_char();
		if(ch==-1)
		{
			if((DWORD)(GetTickCount()-idle_start) >= 2000)
				break;
			continue;
		}
		idle_start = GetTickCount();
		if(!i && (ch=='\n' || ch=='\r'))
			continue;
		if(i && (ch=='\n' || ch=='\r'))
			break;
		buf[i++] = ch;
	}
	buf[i] = 0;
}

//
int slip_recv_char(void)
{
	int d1,i;

	//
	for(i=0; i<10; i++)
	{
		//
		d1=serial_get_owned(slip.port,SERIAL_OWNER_SLIP);
		if(d1!=-1)
			return d1;
		SwitchToThread();
	}
	return -1;
}

//
void slip_send_packet(char *p, int len)
{
	BYTE *buf;
	int i,i2,i3,i4;

	// If not online, return...
	if(!slipOnline)return;

	// Send an initial END character to flush
	// out any data that may have accumulated
	// in the receiver due to line noise.
	slip_send_char(END);

	// For each byte in the packet, send
	// appropriate character sequence.
	for(buf=p,i=0; i<len; i++)
	{
		switch(buf[i])
		{
			// if it's the same code as an END character,
			// we send a special two character code so as
			// not to make the receiver think we sent an END.
			case END:
				slip_send_char(ESC);
				slip_send_char(ESC_END);
				break;
			// If it's the same code as an ESC character,
			// we send a special two character code so as not
			// to make the receiver think we sent an ESC.
			case ESC:
				slip_send_char(ESC);
				slip_send_char(ESC_ESC);
				break;
			// Otherwise, we just send the character.
			default:
				slip_send_char(buf[i]);
				break;
		}
	}

	// Tell the receiver that we're done sending
	// the packet.
	slip_send_char(END);
}

//
int slip_recv_packet(char *p, int len)
{
	DWORD last_byte;
	int c, received, escaped, overflow;

	if(!slipOnline || p==NULL || len<=0)
		return 0;

	received = 0;
	escaped = 0;
	overflow = 0;
	last_byte = GetTickCount();

	for(;;)
	{
		c = slip_recv_char();
		if(c==-1)
		{
			/* No packet in progress: return quickly so the network/service
			 * task can run.  An incomplete frame is discarded after 1 s. */
			if(received==0 && !escaped)
				return 0;
			if((DWORD)(GetTickCount()-last_byte) >= 1000)
				return 0;
			continue;
		}

		last_byte = GetTickCount();

		if(escaped)
		{
			escaped = 0;
			if(c==ESC_END) c=END;
			else if(c==ESC_ESC) c=ESC;
		}
		else if(c==END)
		{
			if(received==0)
				continue;
			return overflow ? 0 : received;
		}
		else if(c==ESC)
		{
			escaped = 1;
			continue;
		}

		if(received < len)
			p[received++] = (BYTE)c;
		else
			overflow = 1;
	}
}
