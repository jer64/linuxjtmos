//----------------------------------------
// Generic Audio Driver 2.0
// (C) 2003-2026 by Jari Tuominen
//----------------------------------------
#include "kernel32.h"
#include "buffer.h"
#include "audio.h"
#include "sb.h"
#include "gus.h"
#include "driver_sys.h"
#include "../hda/hda.h"

FBUF aud;
AUDIO audio;

static int audio_driver_registered = 0;
static int audio_preferred_backend = AUDIO_BACKEND_AUTO;

const char *audio_backend_name(int backend)
{
    if(backend == AUDIO_BACKEND_HDA) return "hda";
    if(backend == AUDIO_BACKEND_SB) return "sb";
    if(backend == AUDIO_BACKEND_GUS) return "gus";
    return "none";
}

static int audio_fifo_write(const BYTE *src, int len)
{
    int flags;
    int n = 0;

    if(src == NULL || len <= 0 || aud.buf == NULL || aud.magic != FIFOBUF_MAGIC)
        return 0;

    flags = get_eflags();
    disable();
    while(n < len && aud.count < aud.l_buf)
    {
        aud.head++;
        if(aud.head >= aud.l_buf)
            aud.head = 0;
        aud.buf[aud.head] = src[n++];
        aud.count++;
        aud.total++;
    }
    set_eflags(flags);
    return n;
}

int audio_fifo_read(BYTE *dst, int maxlen)
{
    int flags;
    int n = 0;

    if(dst == NULL || maxlen <= 0 || aud.buf == NULL || aud.magic != FIFOBUF_MAGIC)
        return 0;

    flags = get_eflags();
    disable();
    while(n < maxlen && aud.count > 0)
    {
        aud.tail++;
        if(aud.tail >= aud.l_buf)
            aud.tail = 0;
        dst[n++] = aud.buf[aud.tail];
        aud.count--;
        aud.total++;
    }
    set_eflags(flags);
    return n;
}

int audio_fifo_count(void)
{
    int flags;
    int count;

    flags = get_eflags();
    disable();
    count = aud.count;
    set_eflags(flags);
    return count;
}

void audio_notify_played(int bytes)
{
    if(bytes > 0)
        audio.bytes_played += (DWORD)bytes;
}

void audio_notify_underrun(void)
{
    audio.underruns++;
}

static int audio_backend_active_bytes(void)
{
    if(audio.backend == AUDIO_BACKEND_SB)
        return sb_active_bytes();
    if(audio.backend == AUDIO_BACKEND_GUS)
        return gus_active_bytes();
#if JTMOS_MOD_PCI
    if(audio.backend == AUDIO_BACKEND_HDA)
        return hda_active_bytes();
#endif
    return 0;
}

void audio_kick(void)
{
    if(audio.backend == AUDIO_BACKEND_SB)
        sb_kick();
    else if(audio.backend == AUDIO_BACKEND_GUS)
        gus_kick();
#if JTMOS_MOD_PCI
    else if(audio.backend == AUDIO_BACKEND_HDA)
        hda_kick();
#endif
}

int audio_select_backend(int backend)
{
    if(backend != AUDIO_BACKEND_AUTO && backend != AUDIO_BACKEND_SB &&
       backend != AUDIO_BACKEND_GUS && backend != AUDIO_BACKEND_HDA)
        return -1;

    if(audio.backend != 0 && audio.backend != backend && backend != AUDIO_BACKEND_AUTO)
    {
        audio_stop();
        audio.backend = 0;
    }

    audio_preferred_backend = backend;
    if(backend == AUDIO_BACKEND_AUTO)
        return 0;

    return audio_ensure_backend(backend);
}

int audio_ensure_backend(int preferred)
{
    int want = preferred;

    if(!audio.initialized)
        audio_init();

    if((preferred == AUDIO_BACKEND_AUTO || preferred == AUDIO_BACKEND_SB) &&
       audio.backend == AUDIO_BACKEND_SB && sb_is_ready())
        return AUDIO_BACKEND_SB;
    if((preferred == AUDIO_BACKEND_AUTO || preferred == AUDIO_BACKEND_GUS) &&
       audio.backend == AUDIO_BACKEND_GUS && gus_is_ready())
        return AUDIO_BACKEND_GUS;
#if JTMOS_MOD_PCI
    if((preferred == AUDIO_BACKEND_AUTO || preferred == AUDIO_BACKEND_HDA) &&
       audio.backend == AUDIO_BACKEND_HDA && hda_is_ready())
        return AUDIO_BACKEND_HDA;
#endif

    if(want == AUDIO_BACKEND_AUTO)
        want = audio_preferred_backend;

    if(want == AUDIO_BACKEND_SB)
    {
        if(sb_init(0) == 0)
        {
            audio.backend = AUDIO_BACKEND_SB;
            return audio.backend;
        }
        return -1;
    }

    if(want == AUDIO_BACKEND_GUS)
    {
        if(gus_init())
        {
            audio.backend = AUDIO_BACKEND_GUS;
            return audio.backend;
        }
        return -1;
    }

    if(want == AUDIO_BACKEND_HDA)
    {
#if JTMOS_MOD_PCI
        if(hda_init() == 0 && hda_is_ready())
        {
            audio.backend = AUDIO_BACKEND_HDA;
            return audio.backend;
        }
#endif
        return -1;
    }

    /* AUTO: prefer PCI HDA on physical machines, then retain the historical
     * SB/GUS emulator/ISA fallbacks. */
#if JTMOS_MOD_PCI
    if(hda_init() == 0 && hda_is_ready())
    {
        audio.backend = AUDIO_BACKEND_HDA;
        return audio.backend;
    }
#endif
    if(sb_init(0) == 0)
    {
        audio.backend = AUDIO_BACKEND_SB;
        return audio.backend;
    }
    if(gus_init())
    {
        audio.backend = AUDIO_BACKEND_GUS;
        return audio.backend;
    }

    return -1;
}

int audio_write(BYTE *buf, int len, int format, int freq)
{
    int done;

    if(buf == NULL || len <= 0)
        return 0;
    if(format != AUDIO_FORMAT_U8_MONO)
        return -2;
    if(freq < 4000 || freq > 44100)
        return -3;
    if(audio_ensure_backend(AUDIO_BACKEND_AUTO) < 0)
        return -4;

    /* Changing the clock while a DMA/voice is live produces a pitch jump.
     * Require a drained stream before accepting a new sample rate. */
    if(audio.frequency != 0 && audio.frequency != freq && audio_pending_bytes() != 0)
        return -5;

    audio.frequency = freq;
    audio.format = format;
    done = audio_fifo_write(buf, len);
    if(done > 0)
    {
        audio.bytes_queued += (DWORD)done;
        audio_kick();
    }
    return done;
}

int audio_stop(void)
{
    int flags;

    if(audio.backend == AUDIO_BACKEND_SB)
        sb_stop();
    else if(audio.backend == AUDIO_BACKEND_GUS)
        gus_stop();
#if JTMOS_MOD_PCI
    else if(audio.backend == AUDIO_BACKEND_HDA)
        hda_stop();
#endif

    flags = get_eflags();
    disable();
    if(aud.magic == FIFOBUF_MAGIC)
    {
        aud.head = 0;
        aud.tail = 0;
        aud.count = 0;
    }
    audio.playing = 0;
    set_eflags(flags);
    return 0;
}

DWORD audio_pending_bytes(void)
{
    DWORD n = (DWORD)audio_fifo_count();
    int active = audio_backend_active_bytes();
    if(active > 0)
        n += (DWORD)active;
    return n;
}

int audio_get_info(JTMOS_AUDIO_INFO *info)
{
    if(info == NULL)
        return -1;
    xmemset((char *)info, 0, sizeof(*info));
    info->size = sizeof(*info);
    info->backend = (DWORD)audio.backend;
    info->initialized = (DWORD)audio.initialized;
    info->playing = (DWORD)(audio_backend_active_bytes() != 0);
    info->sample_rate = (DWORD)audio.frequency;
    info->format = (DWORD)audio.format;
    info->queued_bytes = (DWORD)audio_fifo_count();
    info->active_bytes = (DWORD)audio_backend_active_bytes();
    info->played_bytes = audio.bytes_played;
    info->underruns = audio.underruns;
    return 0;
}

void SendAudio(BYTE *buf, int len, int freq)
{
    int offset = 0;
    int n;

    while(offset < len)
    {
        n = audio_write(buf + offset, len - offset, AUDIO_FORMAT_U8_MONO, freq);
        if(n < 0)
            return;
        if(n == 0)
        {
            SwitchToThread();
            continue;
        }
        offset += n;
    }
}

int audio_dev_call(DEVICE_CALL_PARS)
{
    DWORD *v=(DWORD *)po1;
    (void)p1; (void)p2; (void)p3; (void)p4; (void)po2;
    switch(n_call)
    {
        case DEVICE_CMD_INIT:
            return audio_ensure_backend(AUDIO_BACKEND_AUTO)<0 ? -1 : 0;
        case DEVICE_CMD_SHUTDOWN:
            return audio_stop();
        case DEVICE_CMD_GETSIZE:
            if(v) *v=audio_pending_bytes();
            return 0;
        case DEVICE_CMD_GETBLOCKSIZE:
            if(v) *v=1;
            return 0;
        case DEVICE_CMD_TELL:
            if(v) *v=audio.bytes_played;
            return 0;
        case DEVICE_CMD_FLUSH:
            audio_kick();
            return (int)audio_pending_bytes();
        default:
            return 0;
    }
}

void audio_init(void)
{
    int dnr;
    if(audio.initialized) return;

    xmemset((char *)&audio, 0, sizeof(audio));

    /* The generic logical device exists independently of the hardware
       backend.  Applications target `audio`; HDA/SB/GUS are implementation
       details selected lazily when playback begins. */
    if(!audio_driver_registered)
    {
        dnr=device("audio");
        if(dnr<=0) dnr=driver_register_new_device("audio",audio_dev_call,DEVICE_TYPE_CHAR);
        if(dnr>=0) audio_driver_registered=1;
    }

    printk("Generic audio device: audio (backend policy HDA -> SB -> GUS).\n");
    CreateBuffer(&aud, AUDIO_FIFO_SIZE);
    if(aud.buf == NULL)
    {
        printk("audio: cannot allocate %d-byte FIFO.\n", AUDIO_FIFO_SIZE);
        return;
    }

    audio.initialized=1;
    audio.format=AUDIO_FORMAT_U8_MONO;
}
