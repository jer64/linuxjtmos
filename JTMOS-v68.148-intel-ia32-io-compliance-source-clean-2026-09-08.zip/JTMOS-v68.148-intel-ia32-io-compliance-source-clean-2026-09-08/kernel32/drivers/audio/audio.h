#ifndef __INCLUDED_AUDIO_H__
#define __INCLUDED_AUDIO_H__

#include "kernel32.h"
#include "buffer.h"

#define AUDIO_FORMAT_U8_MONO 0

#define AUDIO_BACKEND_AUTO 0
#define AUDIO_BACKEND_SB   1
#define AUDIO_BACKEND_GUS  2
#define AUDIO_BACKEND_HDA  3

#define AUDIO_FIFO_SIZE (128*1024)

typedef struct
{
    int length;
    int frequency;
    int format;
    int backend;
    int initialized;
    int playing;
    DWORD bytes_queued;
    DWORD bytes_played;
    DWORD underruns;
} AUDIO;

typedef struct
{
    DWORD size;
    DWORD backend;
    DWORD initialized;
    DWORD playing;
    DWORD sample_rate;
    DWORD format;
    DWORD queued_bytes;
    DWORD active_bytes;
    DWORD played_bytes;
    DWORD underruns;
} JTMOS_AUDIO_INFO;

extern AUDIO audio;
extern FBUF aud;

void audio_init(void);
const char *audio_backend_name(int backend);
int audio_ensure_backend(int preferred);
int audio_select_backend(int backend);
int audio_write(BYTE *buf, int len, int format, int freq);
int audio_stop(void);
DWORD audio_pending_bytes(void);
int audio_get_info(JTMOS_AUDIO_INFO *info);

/* Backward-compatible kernel API. */
void SendAudio(BYTE *buf, int len, int freq);

/* Driver-side FIFO/service hooks. */
int audio_fifo_read(BYTE *dst, int maxlen);
int audio_fifo_count(void);
void audio_notify_played(int bytes);
void audio_notify_underrun(void);
void audio_kick(void);

#endif
