/*
 * sb.c - Sound Blaster 8-bit PCM support for JTMOS.
 * (C) 2001-2003, 2026 by Jari Tuominen.
 *
 * V58 replaces the old predictive/auto-init polling loop with IRQ-driven
 * single-cycle DMA blocks.  The ISR only acknowledges completion; the normal
 * KSB worker starts the next FIFO block outside interrupt context.
 */
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "dma.h"
#include "pit.h"
#include "threads.h"
#include "sb.h"
#include "sb_dev.h"
#include "audio.h"

THREAD sbThread;
SB sb;

static int sb_ready = 0;
static int sb_thread_started = 0;
static volatile int sb_completed_bytes = 0;
static int sb_seen_irq = 0;

static int sb_irq_vector(int irq)
{
    if(irq < 8)
        return M_VEC + irq;
    return S_VEC + (irq - 8);
}

static void sb_pic_eoi(int irq)
{
    pic_send_eoi((unsigned short)irq);
}

static int sb_wait_write_ready(DWORD timeout_us)
{
    DWORD start = PitGetUsec();
    while(inportb(sb.base + DSP_STATUS) & 0x80)
    {
        if((DWORD)(PitGetUsec() - start) >= timeout_us)
            return 0;
        if(Multitasking)
            SwitchToThread();
    }
    return 1;
}

static int sb_wait_read_ready(DWORD timeout_us)
{
    DWORD start = PitGetUsec();
    while(!(inportb(sb.base + DSP_DATA_AVAIL) & 0x80))
    {
        if((DWORD)(PitGetUsec() - start) >= timeout_us)
            return 0;
        if(Multitasking)
            SwitchToThread();
    }
    return 1;
}

int sb_write_dsp(BYTE value)
{
    if(!sb_wait_write_ready(100000UL))
        return 1;
    outportb(sb.base + DSP_WRITE, value);
    return 0;
}

int sb_read_dsp(void)
{
    if(!sb_wait_read_ready(100000UL))
        return -1;
    return inportb(sb.base + DSP_READ);
}

int sb_reset(void)
{
    int value;
    DWORD flags = get_eflags();

    outportb(sb.base + DSP_RESET, 1);
    UsecSleep(4);
    outportb(sb.base + DSP_RESET, 0);
    if(!sb_wait_read_ready(100000UL))
    {
        set_eflags(flags);
        return 1;
    }
    value = inportb(sb.base + DSP_READ);
    set_eflags(flags);
    return value == 0xAA ? 0 : 1;
}

int sb_get_version(void)
{
    int major, minor;
    if(sb_write_dsp(0xE1))
        return -1;
    major = sb_read_dsp();
    minor = sb_read_dsp();
    if(major < 0 || minor < 0)
        return -1;
    return ((major & 0xff) << 8) | (minor & 0xff);
}

void sb_configure(int base,int irq,int dma)
{
    sb.base = (WORD)base;
    sb.irq = (WORD)irq;
    sb.dma = (WORD)dma;
}

void sb_set_mixer_reg(int which,int value)
{
    outportb(sb.base + MIXER_ADDR, which & 0xff);
    outportb(sb.base + MIXER_DATA, value & 0xff);
}

int sb_get_mixer_reg(int which)
{
    outportb(sb.base + MIXER_ADDR, which & 0xff);
    return inportb(sb.base + MIXER_DATA);
}

int sb_get_irq_nr(void)
{
    int value = sb_get_mixer_reg(IRQ_NR);
    if(value & 0x02) return 5;
    if(value & 0x04) return 7;
    if(value & 0x08) return 10;
    if(value & 0x01) return 2;
    return -1;
}

int sb_get_dma_nr(void)
{
    int value = sb_get_mixer_reg(DMA_NR);
    if(value & 0x02) return 1;
    if(value & 0x08) return 3;
    if(value & 0x01) return 0;
    return -1;
}

static int sb_detect_mixer(void)
{
    int old, test;
    old = sb_get_mixer_reg(MASTER_VOL);
    sb_set_mixer_reg(MASTER_VOL, 0xAA);
    test = sb_get_mixer_reg(MASTER_VOL);
    sb_set_mixer_reg(MASTER_VOL, old);
    return test == 0xAA;
}

static int sb_decode_resources(void)
{
    int irq, dma;

    if(sb.version < 0x0400 || !sb.mixer)
        return 0;

    irq = sb_get_irq_nr();
    dma = sb_get_dma_nr();
    if(irq >= 2 && irq <= 15)
        sb.irq = (WORD)irq;
    if(dma == 0 || dma == 1 || dma == 3)
        sb.dma = (WORD)dma;
    return 0;
}

int sb_init1(int base, int irq, int dma, int quiet)
{
    int version;

    xmemset((char *)&sb, 0, sizeof(sb));
    sb_configure(base, irq, dma);
    if(sb_reset())
        return 1;

    version = sb_get_version();
    if(version < 0x0200 || version == 0xffff)
        return 1;
    sb.version = version;
    sb.mixer = (sb.version >= 0x0300) ? sb_detect_mixer() : 0;
    sb_decode_resources();

    if(!quiet)
        printk("SB: DSP %d.%02d at 0x%x IRQ%d DMA%d%s.\n",
               (sb.version >> 8) & 0xff, sb.version & 0xff,
               sb.base, sb.irq, sb.dma, sb.mixer ? " mixer" : "");
    return 0;
}

int sb_init_(int hardscan)
{
    static const WORD normal_bases[] = { 0x220, 0x240, 0x260, 0x280 };
    int i;

    for(i = 0; i < (int)(sizeof(normal_bases)/sizeof(normal_bases[0])); ++i)
        if(sb_init1(normal_bases[i], 5, 1, 1) == 0)
            return 0;

    if(hardscan)
    {
        for(i = 0x210; i <= 0x280; i += 0x10)
        {
            if(i == 0x220 || i == 0x240 || i == 0x260 || i == 0x280)
                continue;
            if(sb_init1(i, 5, 1, 1) == 0)
                return 0;
        }
    }
    return 1;
}

void sb_turn_speaker_on(void)  { (void)sb_write_dsp(DSP_CMD_SPEAKERON); }
void sb_turn_speaker_off(void) { (void)sb_write_dsp(DSP_CMD_SPEAKEROFF); }

int sb_set_frequency(WORD freq)
{
    int tc;

    if(freq < 4000 || freq > 44100)
        return 1;

    if(sb.version >= 0x0400)
    {
        if(sb_write_dsp(0x41)) return 1;
        if(sb_write_dsp((BYTE)(freq >> 8))) return 1;
        if(sb_write_dsp((BYTE)(freq & 0xff))) return 1;
        return 0;
    }

    tc = 256 - (1000000UL / (DWORD)freq);
    if(tc < 0) tc = 0;
    if(tc > 255) tc = 255;
    if(sb_write_dsp(0x40)) return 1;
    return sb_write_dsp((BYTE)tc);
}

int sb_set_playback(WORD fmt, WORD size)
{
    WORD count;
    if(size == 0)
        return 1;
    count = size - 1;
    if(sb_write_dsp((BYTE)fmt)) return 1;
    if(sb_write_dsp((BYTE)(count & 0xff))) return 1;
    if(sb_write_dsp((BYTE)(count >> 8))) return 1;
    return 0;
}

int sb_set_dma_blocklength(WORD length)
{
    WORD count;
    if(length == 0) return 1;
    count = length - 1;
    if(sb_write_dsp(0x48)) return 1;
    if(sb_write_dsp((BYTE)(count & 0xff))) return 1;
    return sb_write_dsp((BYTE)(count >> 8));
}

static int sb_start_block(int bytes, int freq)
{
    WORD count;

    if(bytes <= 0 || bytes > SB_DMA_BUFFER_SIZE)
        return 1;

    dma_xfer((BYTE)sb.dma, (DWORD)SB_DMA_BUFFER_OFFSET, (unsigned int)bytes, TRUE);
    if(sb_set_frequency((WORD)freq))
        return 1;

    count = (WORD)(bytes - 1);
    if(sb.version >= 0x0400)
    {
        /* SB16: 8-bit single-cycle output, unsigned mono. */
        if(sb_write_dsp(0xC0)) return 1;
        if(sb_write_dsp(0x00)) return 1;
        if(sb_write_dsp((BYTE)(count & 0xff))) return 1;
        if(sb_write_dsp((BYTE)(count >> 8))) return 1;
    }
    else
    {
        /* SB 2.0 / Pro compatible single-cycle 8-bit DMA. */
        if(sb_write_dsp(0x14)) return 1;
        if(sb_write_dsp((BYTE)(count & 0xff))) return 1;
        if(sb_write_dsp((BYTE)(count >> 8))) return 1;
    }

    sb.activeBytes = bytes;
    sb.length = bytes;
    sb.frequency = freq;
    sb.isPlaying = 1;
    audio.playing = 1;
    return 0;
}

void sb_kick(void)
{
    int flags, bytes;
    BYTE *dma_buf = (BYTE *)SB_DMA_BUFFER_OFFSET;

    if(!sb_ready)
        return;

    flags = get_eflags();
    disable();
    if(sb.isPlaying)
    {
        set_eflags(flags);
        return;
    }
    sb.isPlaying = 2; /* reserve backend while IF is restored */
    set_eflags(flags);

    bytes = audio_fifo_read(dma_buf, SB_DMA_BUFFER_SIZE);
    if(bytes <= 0)
    {
        sb.isPlaying = 0;
        return;
    }
    if(sb_start_block(bytes, audio.frequency ? audio.frequency : 11025))
    {
        sb.activeBytes = 0;
        sb.isPlaying = 0;
        audio_notify_underrun();
    }
}

int sb_play_sample(WORD size, WORD freq)
{
    return sb_start_block((int)size, (int)freq);
}

void sb_start_playing(void)
{
    sb_kick();
}

void sb_stop(void)
{
    if(!sb_ready)
        return;
    (void)sb_write_dsp(DSP_CMD_DMAPAUSE);
    sb_turn_speaker_off();
    sb.isPlaying = 0;
    sb.activeBytes = 0;
    audio.playing = 0;
}

int sb_is_ready(void) { return sb_ready; }
int sb_active_bytes(void) { return sb.isPlaying == 1 ? sb.activeBytes : 0; }

void sb_irqhandler(void)
{
    int finished = sb.activeBytes;

    /* Read DSP status/data-available to acknowledge the 8-bit IRQ. */
    (void)inportb(sb.base + DSP_DATA_AVAIL);
    sb.activeBytes = 0;
    sb.isPlaying = 0;
    sb_completed_bytes += finished;
    sb.irqTick++;
    sb_pic_eoi(sb.irq);
}

void sbProcess(void)
{
    int seen = sb_seen_irq;
    for(;;)
    {
        if(seen != sb.irqTick)
        {
            int done;
            int flags = get_eflags();
            disable();
            done = sb_completed_bytes;
            sb_completed_bytes = 0;
            seen = sb.irqTick;
            set_eflags(flags);
            if(done > 0)
            {
                sb.totalBytes += (DWORD)done;
                audio_notify_played(done);
            }
            sb_kick();
        }
        else if(!sb.isPlaying && audio_fifo_count() > 0)
            sb_kick();
        SwitchToThread();
    }
}

void init_sbThread(void)
{
    if(sb_thread_started || !Multitasking)
        return;
    ThreadCreateStack(&sbThread, JTMOS_MIN_DYNAMIC_STACK);
    sbThread.pid = create_thread(sbThread.stack, sbThread.l_stack, sbProcess);
    SetThreadTerminal(sbThread.pid, 6);
    IdentifyThread(sbThread.pid, "KSB-AUDIO");
    sb_thread_started = 1;
}

int sb_init(int hardscan)
{
    if(sb_ready)
        return 0;

    printk("Sound Blaster PCM driver 2.0: probing DSP.\n");
    xmemset((char *)SB_DMA_BUFFER_OFFSET, (char)0x80, SB_DMA_BUFFER_SIZE);
    if(sb_init_(hardscan))
    {
        printk("SB: no supported DSP detected.\n");
        return 1;
    }

    printk("SB: DSP %d.%02d at 0x%x, IRQ%d, DMA%d.\n",
           (sb.version >> 8) & 0xff, sb.version & 0xff,
           sb.base, sb.irq, sb.dma);

    setint(sb_irq_vector(sb.irq), sb_ISR, GIMMIE_CS(),
           D_PRESENT + D_INT);
    enable_irq(sb.irq);
    sb_turn_speaker_on();
    (void)sb_register_device();
    sb_ready = 1;
    init_sbThread();
    return 0;
}

WORD sb_getplayposition(BYTE dmanumber)
{
    BYTE count_port;
    WORD count;
    int flags;

    if(dmanumber > 3)
        return 0;
    count_port = (BYTE)(dmanumber * 2 + 1);
    flags = get_eflags();
    disable();
    outportb(0x0C, 0);
    count = inportb(count_port);
    count |= ((WORD)inportb(count_port)) << 8;
    set_eflags(flags);
    return count;
}

void sb_direct_output(int amount)
{
    if(!sb_ready) return;
    if(!sb_write_dsp(0x10))
        (void)sb_write_dsp((BYTE)amount);
}

static void sb_set_volume_reg(int reg, int amount)
{
    if(sb.mixer)
        sb_set_mixer_reg(reg, amount & 0xff);
}
void sb_set_master_volume(int amount) { sb_set_volume_reg(MASTER_VOL, amount); }
void sb_set_dsp_volume(int amount)    { sb_set_volume_reg(VOC_VOL, amount); }
void sb_set_fm_volume(int amount)     { sb_set_volume_reg(FM_VOL, amount); }
void sb_set_cd_volume(int amount)     { sb_set_volume_reg(CD_VOL, amount); }
void sb_set_line_volume(int amount)   { sb_set_volume_reg(LINE_VOL, amount); }
void sb_set_speaker_volume(int amount){ sb_set_volume_reg(SPEAKER_VOL, amount); }

int sb_set_treble(int power)
{
    if(power < 0) power = 0; if(power > 15) power = 15;
    sb_set_volume_reg(TREBLE_L, power << 4);
    sb_set_volume_reg(TREBLE_R, power << 4);
    return 0;
}

int sb_set_bass(int power)
{
    if(power < 0) power = 0; if(power > 15) power = 15;
    sb_set_volume_reg(BASS_L, power << 4);
    sb_set_volume_reg(BASS_R, power << 4);
    return 0;
}
