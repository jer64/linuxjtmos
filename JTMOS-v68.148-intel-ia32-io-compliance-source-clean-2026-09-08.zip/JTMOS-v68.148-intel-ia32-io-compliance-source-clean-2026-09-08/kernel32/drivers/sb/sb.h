#ifndef __INCLUDED_SB_H__
#define __INCLUDED_SB_H__

#include "kernel32.h"

#define SB_FIFO_BUFFER_SIZE (128*1024)
#define SB_DMA_BUFFER_SIZE 4096
#define SB_DMA_BUFFER_OFFSET (0xA0000-SB_DMA_BUFFER_SIZE)

#define VOC_VOL         0x04
#define MIC_VOL         0x0A
#define RECORD_SRC      0x0C
#define OUT_FILTER      0x0E
#define MASTER_VOL      0x22
#define FM_VOL          0x26
#define CD_VOL          0x28
#define LINE_VOL        0x2E
#define SPEAKER_VOL     0x3B
#define TREBLE_L        0x44
#define TREBLE_R        0x45
#define BASS_L          0x46
#define BASS_R          0x47
#define IRQ_NR          0x80
#define DMA_NR          0x81
#define IRQ_STAT        0x82

#define DSP_RESET       0x06
#define DSP_READ        0x0A
#define DSP_WRITE       0x0C
#define DSP_STATUS      0x0C
#define DSP_DATA_AVAIL  0x0E
#define DSP_DATA_AVL16  0x0F
#define MIXER_ADDR      0x04
#define MIXER_DATA      0x05

#define DSP_CMD_SPEAKERON   0xD1
#define DSP_CMD_SPEAKEROFF  0xD3
#define DSP_CMD_DMAPAUSE    0xD0
#define DSP_CMD_DMARESUME   0xD4

typedef struct
{
    WORD base,irq,dma;
    int version;
    char mixer;
    int length,frequency;
    volatile int isPlaying;
    volatile int irqTick;
    volatile int activeBytes;
    DWORD totalBytes;
} SB;

extern SB sb;

int sb_write_dsp(BYTE value);
int sb_read_dsp(void);
int sb_get_version(void);
void sb_configure(int base,int irq,int dma);
int sb_init(int hardscan);
int sb_init_(int hardscan);
int sb_init1(int base,int irq,int dma,int quiet);
int sb_reset(void);
void sb_set_mixer_reg(int which,int value);
int sb_get_mixer_reg(int which);
int sb_get_irq_nr(void);
int sb_get_dma_nr(void);
int sb_set_treble(int power);
int sb_set_bass(int power);
int sb_set_frequency(WORD freq);
int sb_set_playback(WORD fmt, WORD size);
int sb_set_dma_blocklength(WORD length);
int sb_play_sample(WORD size,WORD freq);
void sb_turn_speaker_on(void);
void sb_turn_speaker_off(void);
void sb_direct_output(int amount);
void sb_set_master_volume(int amount);
void sb_set_dsp_volume(int amount);
void sb_set_fm_volume(int amount);
void sb_set_cd_volume(int amount);
void sb_set_line_volume(int amount);
void sb_set_speaker_volume(int amount);
WORD sb_getplayposition(unsigned char dmanumber);
extern void sb_ISR(void);
void sb_irqhandler(void);
void sb_start_playing(void);
void sbProcess(void);
void init_sbThread(void);

/* Generic-audio backend API. */
int sb_is_ready(void);
int sb_active_bytes(void);
void sb_kick(void);
void sb_stop(void);

#endif
