/************************************************************************
 *                                                                	*
 * JTMOS - Device/File System/Block Device -Driver Fusion Solution	*                                                          *
 * APPLICATION INTERFACE FOR DEVICE DRIVER CALLS			*
 * (C) 2001-2021 by Jari Tuominen(jari.t.tuominen@gmail.com).		*
 *                                                                 	*
 ************************************************************************/

// NOTES
// Whole FAT read/write functions are now implementing
// _readblock _writeblock instead of direct reads.
// This prevents cacheflusher process from jamming.

//
//#include "basdef.h"
//#include "sysmem.h"
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
#include "driver_api.h"
#include "kyber.h"
#include "driver_sys.h"
#include "driver_lock.h"
#include "driver_rw.h" // readblock...
#include "driver_devcall.h"
#include "driver_init.h"

//
char *devCmdNames[]={
    "nothing",
    "init","shutdown","readblock","writeblock",
    "obsolete",
    "getsize","getblocksize","seek","getch",
    "putch","tell","flush","mount","unmount",
    "receivepacket","transmitpacket",
    "opensocket","closesocket","readsocket","writesocket",
    "ping","open","creat","close","read","write","lseek",
    "readdir","mkdir","unlink","chdir","getcwd","mkfs","rmdir",
    "readblocks","writeblocks","*"
        };

// Used by driver_FindCacheEntry
int dtravel=0;
//
// Busy indicator variable
char device_call_busy=0;
// Lock variable
int driver_lock[100]={0};
// Debug variable, indicates the function # which
// is currently running, when DEVAPI is locked
// (Read: Is in use by some specific process).
int driver_db=0;
// Name of the function(string)
char driver_dbFuncStr[100]={ 0 };

// Note: special functions are seperated with stars.
//
/********* DEBUG VARIABLE HANDLING *******************/
char *driver_getDebugVar(void)
{
	return driver_dbFuncStr;
}

//-------------------------------------------------------------------------------------
void DumpDC(DCPACKET *dc, const char *func)
{
	// Report
	printf("%s: received message %s (%d), %d,%d,%d,%d, %x,%x\n",
		func,
		devCmdNames[dc->n_function],
		dc->n_function,
		dc->par1,dc->par2,dc->par3,dc->par4,
		dc->p1,dc->p2);
}

//-------------------------------------------------------------------------------------
void IllegalPacket(DCPACKET *dc)
{
	// Report
	printf("%s: %d, %d,%d,%d,%d, %x,%x\n",
		__FUNCTION__,
		dc->n_function,
		dc->par1,dc->par2,dc->par3,dc->par4,
		dc->p1,dc->p2);
}

// Returns the size of the device, which is counted in blocks
int getsize(int device_nr)
{
	int actual_size;

	//
	if( !isValidDevice(device_nr) )return 0;
	actual_size=0;

	//
	device_call(device_nr,
			DEVICE_CMD_GETSIZE,
			0,0,0,0,
			&actual_size,NULL);

	//
	return actual_size;
}

// Returns the blocksize in the specified device
int getblocksize(int device_nr)
{
	int actual_size;

	actual_size=0;

	if( !isValidDevice(device_nr) )return 0;

	device_call(device_nr,
			DEVICE_CMD_GETBLOCKSIZE,
			0,0,0,0,
			&actual_size,NULL);

	// NOTE: size 1 means error, of course and functions should handle this :)
	if(!actual_size)
	{
		actual_size=1;
	}

	return actual_size;
}

// Change device
// Returns isJTMFS true or not
int chdev(int device_nr)
{
	if( !isValidDevice(device_nr) )return FALSE;
	return TRUE;
}

//
int driver_unmountDNR(int dnr)
{
    int rv;

    if(!isValidDevice(dnr)) return 1;

    /* V67.8.56.12 durability rule: never close a block device after a failed
     * cache flush.  Leaving it mounted is recoverable; invalidating dirty RAM
     * state is not. */
    kyber_barrier_begin(dnr);
    if(driver_block_cache_flush(dnr)!=0)
    {
        printk("driver_unmountDNR: DAPI flush failed for device %d; keeping it mounted.\n",dnr);
        kyber_barrier_end(dnr);
        return 2;
    }
    rv=device_call(dnr, DEVICE_CMD_FLUSH, 0,0,0,0, 0,NULL);
    if(rv!=0)
    {
        printk("driver_unmountDNR: device flush failed for device %d (%d); keeping it mounted.\n",dnr,rv);
        kyber_barrier_end(dnr);
        return 3;
    }
    rv=device_call(dnr, DEVICE_CMD_UNMOUNT, 0,0,0,0, 0,NULL);
    if(rv==0)
        driver_block_cache_invalidate(dnr);
    kyber_barrier_end(dnr);
    return rv;
}

//
int driver_mountDNR(int dnr)
{
    int rv;

    if(!isValidDevice(dnr)) return 1;

    /* V67.8.56.12 durability fix:
     * Never invalidate a block-device cache before dirty entries have reached
     * the device.  The previous mount path dropped DAPI write-back blocks
     * unconditionally, which could make recently written hda: contents exist
     * only in RAM and disappear after a remount/reboot. */
    kyber_barrier_begin(dnr);
    if(driver_block_cache_flush(dnr)!=0)
    {
        printk("driver_mountDNR: refusing to drop dirty cache for device %d.\n",dnr);
        kyber_barrier_end(dnr);
        return 1;
    }
    driver_block_cache_invalidate(dnr);
    rv=device_call(dnr,
                   DEVICE_CMD_MOUNT,
                   0,0,0,0,
                   0,NULL);
    kyber_barrier_end(dnr);
    return rv;
}



// Checks whether if a drive is ready and
// has a healthy file system.
int isDriveReady(int dnr)
{
	int r,rv;

	//
	return 0;
}

// Commit a disk change
// All device buffers and caches are deallocated,
// and prepared for a re-read.
int diskChange(int dnr)
{
	if(!isValidDevice(dnr)) return 1;
	/* Removable media must never inherit cached blocks from the old medium. */
	driver_block_cache_invalidate(dnr);
	return 0;
}




