/* ========================================================================
 * JTMOS SATA/AHCI block driver - hda:
 *
 * First native SATA backend for JTMOS.  The design intentionally keeps the
 * existing DEVAPI/DAPI/FlexFAT contract unchanged and replaces only the
 * physical disk backend when a PCI class 01/06/01 AHCI controller is found.
 *
 * V1 policy:
 *   - shared JTMOS PCI scanner/database (no private PCI scan)
 *   - first AHCI SATA ATA port becomes hda:
 *   - polling completion, command slot 0 (safe early-boot implementation)
 *   - READ DMA EXT / WRITE DMA EXT (LBA48)
 *   - IDENTIFY DEVICE and FLUSH CACHE/FLUSH CACHE EXT
 *   - one physically contiguous 64 KiB bounce buffer, so arbitrary JTMOS
 *     virtual buffers need not be physically contiguous for bus-master DMA
 *   - existing DAPI read/write-back cache and FlexFAT durability verification
 *     remain above this driver
 *
 * Later versions can add IRQ completion, NCQ and multiple SATA disks without
 * changing the block-device API exposed here.
 * ======================================================================== */
#include "kernel32.h"
#include "sysmem.h"
#include "driver_api.h"
#include "driver_sys.h"
#include "userhw.h"
#include "paging.h"
#include "pit.h"
#include "pci.h"
#include "ahci.h"

#define AHCI_PCI_CLASS_STORAGE   0x01
#define AHCI_PCI_SUBCLASS_SATA   0x06
#define AHCI_PCI_PROGIF_AHCI     0x01

#define AHCI_GHC_HR              0x00000001UL
#define AHCI_GHC_IE              0x00000002UL
#define AHCI_GHC_AE              0x80000000UL
#define AHCI_CAP2_BOH            0x00000001UL
#define AHCI_BOHC_BOS            0x00000001UL
#define AHCI_BOHC_OOS            0x00000002UL

#define AHCI_PXCMD_ST            0x00000001UL
#define AHCI_PXCMD_FRE           0x00000010UL
#define AHCI_PXCMD_FR            0x00004000UL
#define AHCI_PXCMD_CR            0x00008000UL
#define AHCI_PXIS_TFES           0x40000000UL
#define AHCI_TFD_BSY             0x00000080UL
#define AHCI_TFD_DRQ             0x00000008UL

#define AHCI_SIG_ATA             0x00000101UL
#define AHCI_SIG_ATAPI           0xeb140101UL

#define ATA_CMD_READ_DMA         0xc8
#define ATA_CMD_WRITE_DMA        0xca
#define ATA_CMD_READ_DMA_EXT     0x25
#define ATA_CMD_WRITE_DMA_EXT    0x35
#define ATA_CMD_IDENTIFY         0xec
#define ATA_CMD_FLUSH_CACHE      0xe7
#define ATA_CMD_FLUSH_CACHE_EXT  0xea

#define FIS_TYPE_REG_H2D         0x27

#define AHCI_CMD_LIST_OFF        0x000
#define AHCI_RFIS_OFF            0x400
#define AHCI_CMD_TABLE_OFF       0x500
#define AHCI_DMA_META_BYTES      4096UL
/* Bigfoot sector demo V1.
 *
 * JTMOS keeps the public logical sector at 512 bytes.  The SATA backend is
 * free to combine adjacent logical sectors into a much larger DMA footprint.
 * A single 128 KiB physically-contiguous bounce area is enough for the first
 * demo and still fits in one AHCI PRDT entry (22-bit byte count field).
 *
 * The maximum footprint is selected after IDENTIFY from disk capacity:
 *    <=  8 GiB :   4 KiB   (  8 sectors)
 *    <= 32 GiB :  16 KiB   ( 32 sectors)
 *    <=128 GiB :  32 KiB   ( 64 sectors)
 *    <=256 GiB :  64 KiB   (128 sectors)
 *    > 256 GiB : 128 KiB   (256 sectors)
 *
 * Individual requests can of course be smaller.  Thus filesystem metadata
 * stays cheap while long sequential runs grow into Bigfoot transfers.
 */
#define AHCI_BOUNCE_BYTES        131072UL
#define AHCI_BOUNCE_SECTORS      (AHCI_BOUNCE_BYTES/512UL)
#define BIGFOOT_4K_SECTORS       8UL
#define BIGFOOT_16K_SECTORS      32UL
#define BIGFOOT_32K_SECTORS      64UL
#define BIGFOOT_64K_SECTORS      128UL
#define BIGFOOT_128K_SECTORS     256UL
#define AHCI_MMIO_BYTES          0x1100UL
#define AHCI_TIMEOUT_MS          5000UL
#define AHCI_HANDOFF_TIMEOUT_MS  2000UL

/* AHCI 1.x host register block. */
typedef volatile struct {
    DWORD cap;
    DWORD ghc;
    DWORD is;
    DWORD pi;
    DWORD vs;
    DWORD ccc_ctl;
    DWORD ccc_pts;
    DWORD em_loc;
    DWORD em_ctl;
    DWORD cap2;
    DWORD bohc;
    BYTE  reserved[0x100-0x2c];
} AHCI_HBA;

typedef volatile struct {
    DWORD clb;
    DWORD clbu;
    DWORD fb;
    DWORD fbu;
    DWORD is;
    DWORD ie;
    DWORD cmd;
    DWORD reserved0;
    DWORD tfd;
    DWORD sig;
    DWORD ssts;
    DWORD sctl;
    DWORD serr;
    DWORD sact;
    DWORD ci;
    DWORD sntf;
    DWORD fbs;
    DWORD devslp;
    BYTE  reserved1[0x70-0x48];
    DWORD vendor[4];
} AHCI_PORT;

typedef struct {
    WORD flags;
    WORD prdtl;
    DWORD prdbc;
    DWORD ctba;
    DWORD ctbau;
    DWORD reserved[4];
} AHCI_CMD_HEADER;

typedef struct {
    DWORD dba;
    DWORD dbau;
    DWORD reserved;
    DWORD dbc_i;
} AHCI_PRDT;

typedef struct {
    BYTE cfis[64];
    BYTE acmd[16];
    BYTE reserved[48];
    AHCI_PRDT prdt[1];
} AHCI_CMD_TABLE;

/* Compile-time ABI guards. AHCI register/DMA structures are hardware ABIs;
 * a compiler/layout change must fail the build instead of corrupting memory. */
typedef char ahci_hba_size_check[(sizeof(AHCI_HBA)==0x100) ? 1 : -1];
typedef char ahci_port_size_check[(sizeof(AHCI_PORT)==0x80) ? 1 : -1];
typedef char ahci_cmd_header_size_check[(sizeof(AHCI_CMD_HEADER)==32) ? 1 : -1];
typedef char ahci_prdt_size_check[(sizeof(AHCI_PRDT)==16) ? 1 : -1];
typedef char ahci_cmd_table_size_check[(sizeof(AHCI_CMD_TABLE)==144) ? 1 : -1];
typedef char ahci_cmd_list_alignment_check[((AHCI_CMD_LIST_OFF & 0x3ffUL)==0) ? 1 : -1];
typedef char ahci_rfis_alignment_check[((AHCI_RFIS_OFF & 0xffUL)==0) ? 1 : -1];
typedef char ahci_cmd_table_alignment_check[((AHCI_CMD_TABLE_OFF & 0x7fUL)==0) ? 1 : -1];
typedef char ahci_meta_layout_bounds_check[((AHCI_CMD_TABLE_OFF + sizeof(AHCI_CMD_TABLE)) <= AHCI_DMA_META_BYTES) ? 1 : -1];

typedef struct {
    int present;
    int mounted;
    BYTE bus,dev,fun;
    DWORD abar_phys;
    DWORD abar_map;
    DWORD abar_pages;
    AHCI_HBA *hba;
    AHCI_PORT *port;
    int portno;
    DWORD sectors;
    int lba48;
    DWORD bigfoot_max_sectors;
    DWORD bigfoot_commands;
    DWORD bigfoot_max_seen;
    char model[41];

    BYTE *meta;
    DWORD meta_phys;
    AHCI_CMD_HEADER *cmdlist;
    AHCI_CMD_TABLE *cmdtable;
    BYTE *bounce;
    DWORD bounce_phys;
} AHCI_DISK;

static AHCI_DISK ahd;
static DWORD ahci_debug_issue_seq=0;
static DWORD ahci_debug_flush_seq=0;

static DWORD ahci_bigfoot_profile(DWORD sectors);
static void ahci_bigfoot_report(void);

static void ahci_memory_barrier(void)
{
    /* DMA descriptors/bounce data live in normal WB RAM while PxCI is UC
     * MMIO.  Use the i486-compatible full barrier rather than a compiler-only
     * barrier so descriptor publication is globally visible before the HBA is
     * allowed to fetch it. */
    io_memory_barrier();
}

static int ahci_find_controller(BYTE *rb,BYTE *rd,BYTE *rf,DWORD *rabar)
{
    const PCIDEVICE *pdev;
    PCIBAR bar;

    /* Reuse the JTMOS PCI scanner/database.  pci_init() is idempotent, so the
     * storage path is also safe when AHCI is probed before optional HWDET. */
    pci_init();
    pdev=pci_find_class(AHCI_PCI_CLASS_STORAGE,AHCI_PCI_SUBCLASS_SATA,
                        AHCI_PCI_PROGIF_AHCI,0);
    if(pdev==NULL) return 0;

    if(pci_get_bar(pdev,5,&bar)!=0 || !bar.valid || bar.io || bar.is64 ||
       bar.base_low==0) {
        printk("SATA: AHCI controller %d:%d.%d has unusable BAR5.\n",
               pdev->bus,pdev->device,pdev->function);
        return -1;
    }

    if(pci_enable_device(pdev,PCI_ENABLE_MEMORY|PCI_ENABLE_MASTER)!=0) {
        printk("SATA: cannot enable PCI memory/bus-master for %d:%d.%d.\n",
               pdev->bus,pdev->device,pdev->function);
        return -1;
    }

    *rb=pdev->bus; *rd=pdev->device; *rf=pdev->function;
    *rabar=bar.base_low;
    return 1;
}

static int ahci_wait_clear(volatile DWORD *reg,DWORD mask,DWORD timeout)
{
    DWORD start,loops;
    start=GetTickCount();
    loops=0;
    while((*reg)&mask) {
        if((DWORD)(GetTickCount()-start)>=timeout) return 1;
        /* Backstop for a broken/non-advancing early timer. */
        if(++loops>100000000UL) return 1;
    }
    return 0;
}

static int ahci_bios_handoff(void)
{
    DWORD start;
    if(!(ahd.hba->cap2&AHCI_CAP2_BOH)) return 0;
    if(!(ahd.hba->bohc&AHCI_BOHC_BOS)) return 0;

    printk("SATA: requesting AHCI BIOS/OS ownership handoff.\n");
    ahd.hba->bohc|=AHCI_BOHC_OOS;
    start=GetTickCount();
    while(ahd.hba->bohc&AHCI_BOHC_BOS) {
        if((DWORD)(GetTickCount()-start)>=AHCI_HANDOFF_TIMEOUT_MS) {
            printk("SATA: BIOS ownership did not clear; AHCI takeover aborted.\n");
            return 1;
        }
    }
    return 0;
}

static int ahci_port_is_sata(AHCI_PORT *p)
{
    DWORD ssts,det,ipm;
    ssts=p->ssts;
    det=ssts&0x0fU;
    ipm=(ssts>>8)&0x0fU;
    if(det!=3 || ipm!=1) return 0;
    if(p->sig==AHCI_SIG_ATAPI) return 0;
    return p->sig==AHCI_SIG_ATA;
}

static int ahci_stop_port(AHCI_PORT *p)
{
    p->cmd&=~AHCI_PXCMD_ST;
    if(ahci_wait_clear(&p->cmd,AHCI_PXCMD_CR,AHCI_TIMEOUT_MS)) return 1;
    p->cmd&=~AHCI_PXCMD_FRE;
    if(ahci_wait_clear(&p->cmd,AHCI_PXCMD_FR,AHCI_TIMEOUT_MS)) return 1;
    return 0;
}

static int ahci_start_port(AHCI_PORT *p)
{
    if(ahci_wait_clear(&p->cmd,AHCI_PXCMD_CR,AHCI_TIMEOUT_MS)) return 1;
    p->cmd|=AHCI_PXCMD_FRE;
    p->cmd|=AHCI_PXCMD_ST;
    return 0;
}

static int ahci_rebase(void)
{
    AHCI_PORT *p;
    p=ahd.port;
    if(ahci_stop_port(p)) {
        printk("SATA: port %d command engine would not stop.\n",ahd.portno);
        return 1;
    }

    ahd.meta=(BYTE *)userhw_dma_alloc_kernel32(AHCI_DMA_META_BYTES,&ahd.meta_phys);
    if(ahd.meta==NULL) {
        printk("SATA: unable to allocate AHCI command DMA page.\n");
        return 1;
    }
    ahd.bounce=(BYTE *)userhw_dma_alloc_kernel32(AHCI_BOUNCE_BYTES,&ahd.bounce_phys);
    if(ahd.bounce==NULL) {
        printk("SATA: unable to allocate 128 KiB Bigfoot AHCI bounce buffer.\n");
        return 1;
    }

    if(userhw_dma_verify_kernel32((DWORD)ahd.meta,ahd.meta_phys,AHCI_DMA_META_BYTES)!=0 ||
       userhw_dma_verify_kernel32((DWORD)ahd.bounce,ahd.bounce_phys,AHCI_BOUNCE_BYTES)!=0)
    {
        printk("SATA: AHCI DMA physical continuity verification failed.\n");
        return 1;
    }
    dprintk("AHCI/DMA: meta virt=0x%x phys=0x%x end=0x%x; bounce virt=0x%x phys=0x%x end=0x%x.\n",
        ahd.meta,ahd.meta_phys,ahd.meta_phys+AHCI_DMA_META_BYTES-1,
        ahd.bounce,ahd.bounce_phys,ahd.bounce_phys+AHCI_BOUNCE_BYTES-1);

    memset(ahd.meta,0,AHCI_DMA_META_BYTES);
    memset(ahd.bounce,0,AHCI_BOUNCE_BYTES);
    ahd.cmdlist=(AHCI_CMD_HEADER *)(ahd.meta+AHCI_CMD_LIST_OFF);
    ahd.cmdtable=(AHCI_CMD_TABLE *)(ahd.meta+AHCI_CMD_TABLE_OFF);

    p->clb=ahd.meta_phys+AHCI_CMD_LIST_OFF;
    p->clbu=0;
    p->fb=ahd.meta_phys+AHCI_RFIS_OFF;
    p->fbu=0;
    p->is=0xffffffffUL;
    p->serr=0xffffffffUL;
    p->ie=0; /* V1 completion is polling. */

    ahd.cmdlist[0].ctba=ahd.meta_phys+AHCI_CMD_TABLE_OFF;
    ahd.cmdlist[0].ctbau=0;

    if(p->clb != ahd.meta_phys+AHCI_CMD_LIST_OFF || p->clbu != 0 ||
       p->fb != ahd.meta_phys+AHCI_RFIS_OFF || p->fbu != 0 ||
       ahd.cmdlist[0].ctba != ahd.meta_phys+AHCI_CMD_TABLE_OFF ||
       ahd.cmdlist[0].ctbau != 0)
    {
        printk("SATA: AHCI DMA region address readback mismatch.\n");
        return 1;
    }
    dprintk("AHCI/DMA layout: CLB=0x%x FB=0x%x CTBA=0x%x align=1024/256/128 verified.\n",
        p->clb,p->fb,ahd.cmdlist[0].ctba);

    return ahci_start_port(p);
}

static void ahci_build_fis(BYTE command,unsigned long long lba,WORD count)
{
    BYTE *f;
    f=ahd.cmdtable->cfis;
    memset(f,0,64);
    f[0]=FIS_TYPE_REG_H2D;
    f[1]=0x80;                 /* command FIS */
    f[2]=command;
    f[4]=(BYTE)(lba&0xffULL);
    f[5]=(BYTE)((lba>>8)&0xffULL);
    f[6]=(BYTE)((lba>>16)&0xffULL);
    if(command==ATA_CMD_READ_DMA_EXT || command==ATA_CMD_WRITE_DMA_EXT) {
        f[7]=0x40;             /* LBA48 mode */
        f[8]=(BYTE)((lba>>24)&0xffULL);
        f[9]=(BYTE)((lba>>32)&0xffULL);
        f[10]=(BYTE)((lba>>40)&0xffULL);
        f[12]=(BYTE)(count&0xffU);
        f[13]=(BYTE)((count>>8)&0xffU);
    } else if(command==ATA_CMD_READ_DMA || command==ATA_CMD_WRITE_DMA) {
        /* LBA28 DMA fallback for early/small SATA disks without word 83
         * LBA48 support.  The caller limits these commands to <=255 sectors. */
        f[7]=(BYTE)(0x40 | ((lba>>24)&0x0fULL));
        f[12]=(BYTE)(count&0xffU);
    }
}

static int ahci_issue(BYTE command,unsigned long long lba,WORD count,
                      int write,DWORD bytes)
{
    AHCI_CMD_HEADER *h;
    DWORD start,loops;
    AHCI_PORT *p;

    p=ahd.port;
    h=&ahd.cmdlist[0];
    memset((void *)h,0,sizeof(*h));
    memset((void *)ahd.cmdtable,0,sizeof(*ahd.cmdtable));

    h->flags=(WORD)(5 | (write ? 0x40 : 0)); /* 20-byte FIS, W bit */
    h->ctba=ahd.meta_phys+AHCI_CMD_TABLE_OFF;
    h->ctbau=0;
    if(bytes) {
        h->prdtl=1;
        ahd.cmdtable->prdt[0].dba=ahd.bounce_phys;
        ahd.cmdtable->prdt[0].dbau=0;
        ahd.cmdtable->prdt[0].reserved=0;
        ahd.cmdtable->prdt[0].dbc_i=(bytes-1)&0x003fffffUL;
    }
    ahci_build_fis(command,lba,count);

    start=GetTickCount();
    loops=0;
    while(p->tfd&(AHCI_TFD_BSY|AHCI_TFD_DRQ)) {
        if((DWORD)(GetTickCount()-start)>=AHCI_TIMEOUT_MS || ++loops>100000000UL) {
            printk("SATA: port %d remained busy before command 0x%x.\n",
                   ahd.portno,command);
            return 1;
        }
    }

    p->is=0xffffffffUL;
    p->serr=0xffffffffUL;
    /* Publish the command list/table and bounce-buffer stores before ringing
     * PxCI.  x86 DMA is coherent, but the compiler barrier prevents source
     * reordering across the MMIO submission point. */
    {
        DWORD seq=++ahci_debug_issue_seq;
        if(command==ATA_CMD_FLUSH_CACHE || command==ATA_CMD_FLUSH_CACHE_EXT ||
           seq<=16 || lba<32ULL || (seq&0x3ffUL)==0)
        {
            dprintk("AHCI/issue #%u cmd=0x%x %s LBA=%08x:%08x count=%u bytes=%u bounce=0x%x tfd=0x%x.\n",
                    (unsigned)seq,(unsigned)command,write?"WRITE":"READ",
                    (unsigned)(DWORD)(lba>>32),(unsigned)(DWORD)lba,
                    (unsigned)count,(unsigned)bytes,
                    (unsigned)ahd.bounce_phys,(unsigned)p->tfd);
        }
    }
    ahci_memory_barrier();
    p->ci=1;
    /* Read back the doorbell register.  This also drains any posted bridge
     * write before we begin polling completion state. */
    (void)p->ci;

    start=GetTickCount();
    loops=0;
    while(p->ci&1U) {
        if(p->is&AHCI_PXIS_TFES) {
            printk("SATA: task-file error cmd=0x%x LBA=%08x:%08x count=%u tfd=0x%x is=0x%x serr=0x%x.\n",
                   command,(DWORD)(lba>>32),(DWORD)lba,(unsigned)count,p->tfd,p->is,p->serr);
            return 1;
        }
        if((DWORD)(GetTickCount()-start)>=AHCI_TIMEOUT_MS || ++loops>100000000UL) {
            printk("SATA: command timeout cmd=0x%x LBA=%08x:%08x count=%u ci=0x%x tfd=0x%x is=0x%x serr=0x%x.\n",
                   command,(DWORD)(lba>>32),(DWORD)lba,(unsigned)count,
                   p->ci,p->tfd,p->is,p->serr);
            return 1;
        }
    }
    if(p->is&AHCI_PXIS_TFES) return 1;
    /* Do not let the compiler hoist bounce-buffer reads before completion. */
    ahci_memory_barrier();
    return 0;
}

static int ahci_identify(void)
{
    WORD *id;
    DWORD lba28;
    unsigned long long lba48;
    int i,j,end;

    memset(ahd.bounce,0,512);
    if(ahci_issue(ATA_CMD_IDENTIFY,0,0,0,512)) return 1;
    id=(WORD *)ahd.bounce;

    ahd.lba48=(id[83]&(1U<<10)) ? 1 : 0;
    lba28=((DWORD)id[61]<<16) | (DWORD)id[60];
    lba48=((unsigned long long)id[100]) |
          ((unsigned long long)id[101]<<16) |
          ((unsigned long long)id[102]<<32) |
          ((unsigned long long)id[103]<<48);
    if(ahd.lba48 && lba48) {
        if(lba48>0xffffffffULL) ahd.sectors=0xffffffffUL;
        else ahd.sectors=(DWORD)lba48;
    } else ahd.sectors=lba28;
    if(ahd.sectors==0) return 1;
    ahd.bigfoot_max_sectors=ahci_bigfoot_profile(ahd.sectors);
    dprintk("AHCI/identify: LBA28=%u LBA48=%08x:%08x supported=%d exported-sectors=%u Bigfoot=%u sectors.\n",
            (unsigned)lba28,(unsigned)(DWORD)(lba48>>32),(unsigned)(DWORD)lba48,
            ahd.lba48,(unsigned)ahd.sectors,(unsigned)ahd.bigfoot_max_sectors);

    j=0;
    for(i=27;i<=46 && j<40;i++) {
        ahd.model[j++]=(char)((id[i]>>8)&0xff);
        ahd.model[j++]=(char)(id[i]&0xff);
    }
    ahd.model[40]=0;
    end=39;
    while(end>=0 && (ahd.model[end]==' ' || ahd.model[end]==0))
        ahd.model[end--]=0;
    return 0;
}

static DWORD ahci_bigfoot_profile(DWORD sectors)
{
    /* Thresholds are expressed in 512-byte sectors to avoid byte-size
     * overflow in 32-bit arithmetic. */
    if(sectors<=16777216UL)  return BIGFOOT_4K_SECTORS;   /* 8 GiB */
    if(sectors<=67108864UL)  return BIGFOOT_16K_SECTORS;  /* 32 GiB */
    if(sectors<=268435456UL) return BIGFOOT_32K_SECTORS;  /* 128 GiB */
    if(sectors<=536870912UL) return BIGFOOT_64K_SECTORS;  /* 256 GiB */
    return BIGFOOT_128K_SECTORS;                          /* >256 GiB */
}

static void ahci_bigfoot_report(void)
{
    DWORD kib=(ahd.bigfoot_max_sectors*512UL)/1024UL;
    printk("SATA Bigfoot V1: logical sector=512 B, adaptive DMA footprint <= %u KiB (%u sectors).\n",
           (unsigned)kib,(unsigned)ahd.bigfoot_max_sectors);
}

static int ahci_rw(int first,int count,BYTE *buffer,int write)
{
    DWORD lba,left,chunk,bytes,off,maxchunk;
    if(buffer==NULL || first<0 || count<=0) {
        dprintk("AHCI/rw: reject %s first=%d count=%d buffer=0x%x.\n",
                write?"WRITE":"READ",first,count,(unsigned)buffer);
        return 1;
    }
    if((DWORD)first>=ahd.sectors || (DWORD)count>ahd.sectors-(DWORD)first) {
        dprintk("AHCI/rw: range reject %s first=%u count=%u sectors=%u.\n",
                write?"WRITE":"READ",(unsigned)(DWORD)first,(unsigned)(DWORD)count,
                (unsigned)ahd.sectors);
        return 1;
    }

    lba=(DWORD)first;
    left=(DWORD)count;
    off=0;
    maxchunk=ahd.bigfoot_max_sectors;
    if(maxchunk==0 || maxchunk>AHCI_BOUNCE_SECTORS) maxchunk=AHCI_BOUNCE_SECTORS;
    while(left) {
        chunk=left>maxchunk ? maxchunk : left;
        bytes=chunk*512UL;
        if(write) {
            memcpy(ahd.bounce,buffer+off,bytes);
            if(lba<32UL)
                dprintk("AHCI/rw-data WRITE LBA=%u count=%u first=%02x %02x %02x %02x %02x %02x %02x %02x.\n",
                        (unsigned)lba,(unsigned)chunk,
                        (unsigned char)ahd.bounce[0],(unsigned char)ahd.bounce[1],
                        (unsigned char)ahd.bounce[2],(unsigned char)ahd.bounce[3],
                        (unsigned char)ahd.bounce[4],(unsigned char)ahd.bounce[5],
                        (unsigned char)ahd.bounce[6],(unsigned char)ahd.bounce[7]);
        }
        if(ahci_issue(write ? (ahd.lba48 ? ATA_CMD_WRITE_DMA_EXT : ATA_CMD_WRITE_DMA)
                            : (ahd.lba48 ? ATA_CMD_READ_DMA_EXT : ATA_CMD_READ_DMA),
                      (unsigned long long)lba,(WORD)chunk,write,bytes))
            return 1;
        if(!write) {
            if(lba<32UL)
                dprintk("AHCI/rw-data READ LBA=%u count=%u first=%02x %02x %02x %02x %02x %02x %02x %02x.\n",
                        (unsigned)lba,(unsigned)chunk,
                        (unsigned char)ahd.bounce[0],(unsigned char)ahd.bounce[1],
                        (unsigned char)ahd.bounce[2],(unsigned char)ahd.bounce[3],
                        (unsigned char)ahd.bounce[4],(unsigned char)ahd.bounce[5],
                        (unsigned char)ahd.bounce[6],(unsigned char)ahd.bounce[7]);
            memcpy(buffer+off,ahd.bounce,bytes);
        }
        ahd.bigfoot_commands++;
        if(chunk>ahd.bigfoot_max_seen) ahd.bigfoot_max_seen=chunk;
        lba+=chunk;
        left-=chunk;
        off+=bytes;
    }
    return 0;
}

static int ahci_flush(void)
{
    int r;
    DWORD seq=++ahci_debug_flush_seq;
    dprintk("AHCI/flush #%u begin mode=%s issued=%u max-seen=%u sectors.\n",
            (unsigned)seq,ahd.lba48?"LBA48":"LBA28",
            (unsigned)ahd.bigfoot_commands,(unsigned)ahd.bigfoot_max_seen);
    r=ahci_issue(ahd.lba48 ? ATA_CMD_FLUSH_CACHE_EXT : ATA_CMD_FLUSH_CACHE,
                 0,0,0,0);
    dprintk("AHCI/flush #%u end rv=%d tfd=0x%x is=0x%x serr=0x%x.\n",
            (unsigned)seq,r,(unsigned)ahd.port->tfd,
            (unsigned)ahd.port->is,(unsigned)ahd.port->serr);
    return r;
}

static int ahci_device_call(DEVICE_CALL_PARS)
{
    DWORD *size;
    (void)p3; (void)p4; (void)po2;
    if(n_call!=DEVICE_CMD_MOUNT && !ahd.mounted) return 1;
    switch(n_call) {
        case DEVICE_CMD_MOUNT: ahd.mounted=1; return 0;
        case DEVICE_CMD_UNMOUNT: ahd.mounted=0; return 0;
        case DEVICE_CMD_INIT: return 0;
        case DEVICE_CMD_SHUTDOWN: return ahci_flush();
        case DEVICE_CMD_READBLOCK: return ahci_rw(p1,1,(BYTE *)po1,0);
        case DEVICE_CMD_WRITEBLOCK: return ahci_rw(p1,1,(BYTE *)po1,1);
        case DEVICE_CMD_READBLOCKS: return ahci_rw(p1,p2,(BYTE *)po1,0);
        case DEVICE_CMD_WRITEBLOCKS: return ahci_rw(p1,p2,(BYTE *)po1,1);
        case DEVICE_CMD_GETSIZE:
            if(po1==NULL) return 1;
            size=(DWORD *)po1; *size=ahd.sectors; return 0;
        case DEVICE_CMD_GETBLOCKSIZE:
            if(po1==NULL) return 1;
            size=(DWORD *)po1; *size=512; return 0;
        case DEVICE_CMD_FLUSH: return ahci_flush();
        default: return 0;
    }
}

static int ahci_register_hda(void)
{
    int dnr;
    if(driver_getdevicebyname("hda")) return 1;
    dnr=driver_register_new_device("hda",ahci_device_call,
                                   DEVICE_TYPE_BLOCK|DEVICE_TYPE_MULTIBLOCK);
    if(dnr<0) return 1;
    driver_enableDAPIReadCache(dnr);
    driver_enableDAPIWriteBackCache(dnr);
    printk("SATA: hda DAPI cache enabled (read cache + write-combining write-back).\n");
    return 0;
}

int ahci_hda_active(void)
{
    return ahd.present;
}

int ahci_init_hda(void)
{
    int found,i,pages;
    BYTE bus,dev,fun;
    DWORD abar,pagebase,offset,map;
    AHCI_PORT *ports;

    memset(&ahd,0,sizeof(ahd));
    found=ahci_find_controller(&bus,&dev,&fun,&abar);
    if(found<=0) return found;

    ahd.bus=bus; ahd.dev=dev; ahd.fun=fun; ahd.abar_phys=abar;
    pagebase=abar&~(PAGESIZE-1UL);
    offset=abar-pagebase;
    pages=(int)((offset+AHCI_MMIO_BYTES+PAGESIZE-1UL)/PAGESIZE);
    map=pg_mapio((int)(pagebase/PAGESIZE),pages);
    if(!map) {
        printk("SATA: cannot map AHCI ABAR 0x%x (%d pages).\n",abar,pages);
        return -1;
    }
    ahd.abar_map=map;
    ahd.abar_pages=(DWORD)pages;
    ahd.hba=(AHCI_HBA *)(map+offset);

    printk("SATA: AHCI controller at PCI %d:%d.%d ABAR=0x%x version=0x%x.\n",
           bus,dev,fun,abar,ahd.hba->vs);

    if(ahci_bios_handoff()) return -1;
    ahd.hba->ghc|=AHCI_GHC_AE;
    ahd.hba->ghc&=~AHCI_GHC_IE; /* polling first version */

    ports=(AHCI_PORT *)((BYTE *)ahd.hba+0x100);
    for(i=0;i<32;i++) {
        if(!(ahd.hba->pi&(1UL<<i))) continue;
        if(!ahci_port_is_sata(&ports[i])) continue;
        ahd.port=&ports[i];
        ahd.portno=i;
        break;
    }
    if(ahd.port==NULL) {
        printk("SATA: AHCI controller found, but no active SATA ATA disk port.\n");
        return 0;
    }

    printk("SATA: port %d link up, signature=0x%x.\n",ahd.portno,ahd.port->sig);
    if(ahci_rebase()) return -1;
    if(ahci_identify()) {
        printk("SATA: IDENTIFY DEVICE failed on port %d.\n",ahd.portno);
        return -1;
    }

    ahd.mounted=1;
    if(ahci_register_hda()) {
        printk("SATA: disk identified, but hda registration failed.\n");
        return -1;
    }
    ahd.present=1;
    printk("SATA: hda registered AHCI/%s model '%s', %u sectors of 512 bytes.\n",
           ahd.lba48 ? "LBA48" : "LBA28",ahd.model,(unsigned)ahd.sectors);
    ahci_bigfoot_report();
    return 1;
}
