/* ========================================================================
 * JTMOS NVIDIA MCP61 SATA rescue backend
 *
 * Acer/eMachines EL1352-class systems commonly expose the MCP61 SATA ports as
 * PCI IDE/native-mode functions (10de:03f6, class 01/01, prog-if 85) rather
 * than as AHCI.  A hard-coded 0x1f0 legacy probe can therefore miss the disk
 * even though BIOS calls this an "IDE" mode.
 *
 * This driver is deliberately conservative:
 *   - it is used only after the historical JTMOS IDE path + sector sanity test
 *     has failed;
 *   - it only claims known MCP61 SATA PCI IDs;
 *   - task-file I/O addresses come from PCI BAR0..BAR3, never guessed;
 *   - PIO is used first (no chipset-specific bus-master programming needed);
 *   - IDENTIFY + two identical sector-0 reads must succeed before hda exists.
 *
 * Once this proves stable on the EL1352, bus-master DMA can be added behind
 * the same block-device API without changing FlexFAT/DAPI.
 * ======================================================================== */
#include "kernel32.h"
#include "driver_api.h"
#include "driver_sys.h"
#include "pci.h"
#include "pit.h"
#include "mcp61.h"

#define NVIDIA_VENDOR_ID       0x10de
#define MCP61_SATA_03E7        0x03e7
#define MCP61_SATA_03F6        0x03f6
#define MCP61_SATA_03F7        0x03f7

#define ATA_SR_ERR             0x01
#define ATA_SR_DRQ             0x08
#define ATA_SR_DF              0x20
#define ATA_SR_DRDY            0x40
#define ATA_SR_BSY             0x80

#define ATA_CMD_READ_PIO       0x20
#define ATA_CMD_READ_PIO_EXT   0x24
#define ATA_CMD_WRITE_PIO      0x30
#define ATA_CMD_WRITE_PIO_EXT  0x34
#define ATA_CMD_CACHE_FLUSH    0xe7
#define ATA_CMD_CACHE_FLUSH_EXT 0xea
#define ATA_CMD_IDENTIFY       0xec

#define MCP61_TIMEOUT_MS       3000UL
#define MCP61_SPIN_LIMIT       80000000UL

typedef struct {
    int present;
    int mounted;
    BYTE bus,dev,fun;
    WORD cmd;
    WORD ctrl;
    int slave;
    int lba48;
    DWORD sectors;
    char model[41];
} MCP61_DISK;

static MCP61_DISK mcpd;
static DWORD mcp61_debug_rw_seq=0;
static DWORD mcp61_debug_flush_seq=0;

static int mcp61_known_id(WORD id)
{
    return id==MCP61_SATA_03E7 || id==MCP61_SATA_03F6 || id==MCP61_SATA_03F7;
}

static BYTE ata_status(void)
{
    return (BYTE)inportb((WORD)(mcpd.cmd+7));
}

static void ata_400ns(void)
{
    /* Native-mode IDE control BAR points at the control block base; alternate
     * status/device-control live at +2. Four reads provide the ATA delay. */
    (void)inportb(mcpd.ctrl); (void)inportb(mcpd.ctrl);
    (void)inportb(mcpd.ctrl); (void)inportb(mcpd.ctrl);
}

static int ata_timeout(DWORD start,DWORD *spins)
{
    if((DWORD)(GetTickCount()-start)>=MCP61_TIMEOUT_MS) return 1;
    if(++(*spins)>=MCP61_SPIN_LIMIT) return 1;
    return 0;
}

static int ata_wait_not_busy(void)
{
    DWORD start=GetTickCount(),spins=0;
    BYTE st;
    do {
        st=ata_status();
        if(st==0x00 || st==0xff) return 1;
        if(!(st&ATA_SR_BSY)) return 0;
        ata_400ns();
    } while(!ata_timeout(start,&spins));
    return 1;
}

static int ata_wait_drq(void)
{
    DWORD start=GetTickCount(),spins=0;
    BYTE st;
    for(;;) {
        st=ata_status();
        if(st==0x00 || st==0xff) return 1;
        if(!(st&ATA_SR_BSY)) {
            if(st&(ATA_SR_ERR|ATA_SR_DF)) return 1;
            if(st&ATA_SR_DRQ) return 0;
        }
        ata_400ns();
        if(ata_timeout(start,&spins)) return 1;
    }
}

static void ata_select(int slave)
{
    outportb((WORD)(mcpd.cmd+6),(BYTE)(slave ? 0xb0 : 0xa0));
    ata_400ns();
}

static int ata_identify(int slave)
{
    WORD id[256];
    unsigned long long n48;
    DWORD n28;
    int i,j,end;

    ata_select(slave);
    outportb((WORD)(mcpd.cmd+1),0);
    outportb((WORD)(mcpd.cmd+2),0);
    outportb((WORD)(mcpd.cmd+3),0);
    outportb((WORD)(mcpd.cmd+4),0);
    outportb((WORD)(mcpd.cmd+5),0);
    outportb((WORD)(mcpd.cmd+7),ATA_CMD_IDENTIFY);
    ata_400ns();
    if(ata_wait_not_busy()) return 1;
    if(ata_wait_drq()) return 1;

    for(i=0;i<256;i++) id[i]=inportw(mcpd.cmd);

    if(!(id[49]&(1U<<9))) return 1; /* SATA media must support LBA */
    mcpd.lba48=(id[83]&(1U<<10)) ? 1 : 0;
    n28=((DWORD)id[61]<<16)|(DWORD)id[60];
    n48=((unsigned long long)id[100])|
        ((unsigned long long)id[101]<<16)|
        ((unsigned long long)id[102]<<32)|
        ((unsigned long long)id[103]<<48);
    if(mcpd.lba48 && n48) mcpd.sectors=n48>0xffffffffULL ? 0xffffffffUL : (DWORD)n48;
    else mcpd.sectors=n28;
    if(!mcpd.sectors) return 1;
    dprintk("MCP61/identify: %s LBA28=%u LBA48=%08x:%08x supported=%d exported=%u sectors (%u MiB).\n",
            slave?"slave":"master",(unsigned)n28,
            (unsigned)(DWORD)(n48>>32),(unsigned)(DWORD)n48,mcpd.lba48,
            (unsigned)mcpd.sectors,(unsigned)((unsigned long long)mcpd.sectors/2048ULL));

    j=0;
    for(i=27;i<=46 && j<40;i++) {
        mcpd.model[j++]=(char)((id[i]>>8)&0xff);
        mcpd.model[j++]=(char)(id[i]&0xff);
    }
    mcpd.model[40]=0;
    end=39;
    while(end>=0 && (mcpd.model[end]==' ' || mcpd.model[end]==0)) mcpd.model[end--]=0;
    mcpd.slave=slave;
    return 0;
}

static int ata_flush(void);

static void ata_program_lba(unsigned long long lba,WORD count,int ext)
{
    BYTE drive=(BYTE)(0xe0 | (mcpd.slave ? 0x10 : 0));
    if(ext) {
        outportb((WORD)(mcpd.cmd+6),drive);
        ata_400ns();
        outportb((WORD)(mcpd.cmd+2),(BYTE)((count>>8)&0xff));
        outportb((WORD)(mcpd.cmd+3),(BYTE)((lba>>24)&0xff));
        outportb((WORD)(mcpd.cmd+4),(BYTE)((lba>>32)&0xff));
        outportb((WORD)(mcpd.cmd+5),(BYTE)((lba>>40)&0xff));
        outportb((WORD)(mcpd.cmd+2),(BYTE)(count&0xff));
        outportb((WORD)(mcpd.cmd+3),(BYTE)(lba&0xff));
        outportb((WORD)(mcpd.cmd+4),(BYTE)((lba>>8)&0xff));
        outportb((WORD)(mcpd.cmd+5),(BYTE)((lba>>16)&0xff));
    } else {
        drive|=(BYTE)((lba>>24)&0x0f);
        outportb((WORD)(mcpd.cmd+6),drive);
        ata_400ns();
        outportb((WORD)(mcpd.cmd+2),(BYTE)(count&0xff));
        outportb((WORD)(mcpd.cmd+3),(BYTE)(lba&0xff));
        outportb((WORD)(mcpd.cmd+4),(BYTE)((lba>>8)&0xff));
        outportb((WORD)(mcpd.cmd+5),(BYTE)((lba>>16)&0xff));
    }
}

static int ata_rw(DWORD first,int count,BYTE *buf,int write)
{
    DWORD lba,left,chunk,off,seq;
    int ext,i,s;
    BYTE cmd;
    if(buf==NULL || count<=0 || first>=mcpd.sectors ||
       (DWORD)count>mcpd.sectors-first) {
        dprintk("MCP61/rw: reject %s LBA=%u count=%d sectors=%u buffer=0x%x.\n",
                write?"WRITE":"READ",(unsigned)first,count,
                (unsigned)mcpd.sectors,(unsigned)buf);
        return 1;
    }

    seq=++mcp61_debug_rw_seq;
    if(count>=8 && (seq<=8 || (seq&0x3ffUL)==0))
        dprintk("MCP61/rw #%u: %s LBA=%u count=%d bytes=%u mode=%s max-PIO=255 sectors.\n",
                (unsigned)seq,write?"WRITE":"READ",(unsigned)first,count,
                (unsigned)((DWORD)count*512UL),mcpd.lba48?"LBA48":"LBA28");

    lba=first; left=(DWORD)count; off=0;
    while(left) {
        /* V16.97 EL1352/MCP61 safe-write policy:
         *
         * Reads may still use the controller's normal bounded multi-sector PIO
         * path.  Writes are deliberately one ATA command per 512-byte sector.
         * The rescue backend is selected only after the legacy IDE sanity probe
         * failed, so correctness is more important than throughput here.  In
         * particular, do not depend on MCP61 multi-sector PIO DRQ timing while
         * JTMFS is publishing metadata. */
        if(write) chunk=1UL;
        else chunk=left>255UL ? 255UL : left;
        ext=mcpd.lba48 && ((unsigned long long)lba+chunk>0x0fffffffULL);
        if(!mcpd.lba48 && ((unsigned long long)lba+chunk>0x10000000ULL)) return 1;
        if(mcpd.lba48) ext=1; /* use EXT consistently once the disk supports it */
        if(ata_wait_not_busy()) {
            dprintk("MCP61/rw #%u: pre-command BSY timeout LBA=%u left=%u status=0x%x.\n",
                    (unsigned)seq,(unsigned)lba,(unsigned)left,(unsigned)ata_status());
            return 1;
        }
        ata_program_lba((unsigned long long)lba,(WORD)chunk,ext);
        cmd=write ? (ext ? ATA_CMD_WRITE_PIO_EXT : ATA_CMD_WRITE_PIO)
                  : (ext ? ATA_CMD_READ_PIO_EXT  : ATA_CMD_READ_PIO);
        outportb((WORD)(mcpd.cmd+7),cmd);
        ata_400ns();

        for(s=0;s<(int)chunk;s++) {
            if(ata_wait_drq()) {
                printk("SATA rescue: PIO %s failed lba=%u sector=%d status=0x%x.\n",
                       write?"write":"read",(unsigned)lba,s,ata_status());
                return 1;
            }
            if(write) {
                for(i=0;i<256;i++) {
                    WORD w=(WORD)buf[off+i*2] | ((WORD)buf[off+i*2+1]<<8);
                    outportw(mcpd.cmd,w);
                }
            } else {
                for(i=0;i<256;i++) {
                    WORD w=inportw(mcpd.cmd);
                    buf[off+i*2]=(BYTE)(w&0xff);
                    buf[off+i*2+1]=(BYTE)(w>>8);
                }
            }
            off+=512;
            if(write) ata_400ns();
        }
        if(ata_wait_not_busy()) {
            dprintk("MCP61/rw #%u: post-command BSY timeout LBA=%u chunk=%u status=0x%x.\n",
                    (unsigned)seq,(unsigned)lba,(unsigned)chunk,(unsigned)ata_status());
            return 1;
        }
        lba+=chunk; left-=chunk;
    }
    /* Write-through policy for the MCP61 rescue backend.  DAPI write-back is
     * disabled as well, so a successful block write means the ATA device has
     * accepted the sectors and completed FLUSH CACHE before we return. */
    if(write && ata_flush()) return 1;
    return 0;
}

static int ata_flush(void)
{
    DWORD seq=++mcp61_debug_flush_seq;
    BYTE st;
    if(seq<=8 || (seq&0xffUL)==0)
        dprintk("MCP61/flush #%u begin command=%s.\n",
                (unsigned)seq,mcpd.lba48?"FLUSH CACHE EXT":"FLUSH CACHE");
    ata_select(mcpd.slave);
    outportb((WORD)(mcpd.cmd+7),mcpd.lba48 ? ATA_CMD_CACHE_FLUSH_EXT : ATA_CMD_CACHE_FLUSH);
    ata_400ns();
    if(ata_wait_not_busy()) {
        dprintk("MCP61/flush #%u timeout status=0x%x.\n",(unsigned)seq,(unsigned)ata_status());
        return 1;
    }
    st=ata_status();
    if((st&(ATA_SR_ERR|ATA_SR_DF)) || seq<=8 || (seq&0xffUL)==0)
        dprintk("MCP61/flush #%u end status=0x%x result=%d.\n",
                (unsigned)seq,(unsigned)st,(st&(ATA_SR_ERR|ATA_SR_DF))?1:0);
    return (st&(ATA_SR_ERR|ATA_SR_DF)) ? 1 : 0;
}

static int ata_sector_sanity(void)
{
    BYTE a[512],b[512];
    int i;
    if(ata_rw(0,1,a,0) || ata_rw(0,1,b,0)) return 1;
    for(i=0;i<512;i++) if(a[i]!=b[i]) return 1;
    return 0;
}

static int mcp61_device_call(DEVICE_CALL_PARS)
{
    DWORD *size;
    (void)p3; (void)p4; (void)po2;
    if(n_call!=DEVICE_CMD_MOUNT && !mcpd.mounted) return 1;
    switch(n_call) {
        case DEVICE_CMD_MOUNT: mcpd.mounted=1; return 0;
        case DEVICE_CMD_UNMOUNT: mcpd.mounted=0; return 0;
        case DEVICE_CMD_INIT: return 0;
        case DEVICE_CMD_SHUTDOWN: return ata_flush();
        case DEVICE_CMD_READBLOCK: return ata_rw((DWORD)p1,1,(BYTE *)po1,0);
        case DEVICE_CMD_WRITEBLOCK: return ata_rw((DWORD)p1,1,(BYTE *)po1,1);
        case DEVICE_CMD_READBLOCKS: return ata_rw((DWORD)p1,p2,(BYTE *)po1,0);
        case DEVICE_CMD_WRITEBLOCKS: return ata_rw((DWORD)p1,p2,(BYTE *)po1,1);
        case DEVICE_CMD_GETSIZE:
            if(!po1) return 1; size=(DWORD *)po1; *size=mcpd.sectors; return 0;
        case DEVICE_CMD_GETBLOCKSIZE:
            if(!po1) return 1; size=(DWORD *)po1; *size=512; return 0;
        case DEVICE_CMD_FLUSH: return ata_flush();
        default: return 0;
    }
}

static int mcp61_register_hda(void)
{
    int dnr;
    if(driver_getdevicebyname("hda")) return 1;
    dnr=driver_register_new_device("hda",mcp61_device_call,
                                   DEVICE_TYPE_BLOCK|DEVICE_TYPE_MULTIBLOCK);
    if(dnr<0) return 1;
    driver_enableDAPIReadCache(dnr);
    /* MCP61 is a rescue PIO backend, not a mature high-throughput path.  Keep
     * reads cached but make writes synchronous.  driver_register_new_device()
     * enables block write-back by default, so explicitly turn it back off. */
    driver_disableDAPIWriteBackCache(dnr);
    printk("SATA rescue: hda DAPI policy = read-cache + synchronous write-through.\n");
    return 0;
}

static int mcp61_try_channel(const PCIDEVICE *d,int channel)
{
    PCIBAR cmdbar,ctlbar;
    int bcmd=channel ? 2 : 0;
    int bctl=channel ? 3 : 1;
    int slave;

    if(pci_get_bar(d,bcmd,&cmdbar)!=0 || !cmdbar.valid || !cmdbar.io || !cmdbar.base_low)
        return 0;
    if(pci_get_bar(d,bctl,&ctlbar)!=0 || !ctlbar.valid || !ctlbar.io || !ctlbar.base_low)
        return 0;
    if(cmdbar.base_low>0xffffUL || ctlbar.base_low>0xffffUL) return 0;

    mcpd.cmd=(WORD)cmdbar.base_low;
    mcpd.ctrl=(WORD)(ctlbar.base_low+2);
    printk("SATA rescue: MCP61 PCI %d:%d.%d ch%d taskfile=0x%x ctrl=0x%x.\n",
           d->bus,d->device,d->function,channel,mcpd.cmd,mcpd.ctrl);

    /* Disable channel IRQ at device-control while the rescue backend uses
     * polling. This does not change transfer mode or reset the controller. */
    outportb(mcpd.ctrl,0x02);
    ata_400ns();
    for(slave=0;slave<2;slave++) {
        if(ata_identify(slave)==0) {
            printk("SATA rescue: IDENTIFY succeeded on ch%d %s, model '%s'.\n",
                   channel,slave?"slave":"master",mcpd.model);
            if(ata_sector_sanity()==0) return 1;
            printk("SATA rescue: sector-0 repeat-read sanity failed; rejecting this port.\n");
        }
    }
    return 0;
}

int mcp61_sata_hda_active(void)
{
    return mcpd.present;
}

int mcp61_sata_init_hda(void)
{
    int i,channel;
    const PCIDEVICE *d;
    memset(&mcpd,0,sizeof(mcpd));
    pci_init();

    for(i=0;i<pci_get_device_count();i++) {
        d=pci_get_device(i);
        if(!d || d->vendor_id!=NVIDIA_VENDOR_ID || !mcp61_known_id(d->device_id)) continue;
        if(d->class_code!=0x01 || d->subclass!=0x01) continue;
        if(pci_enable_device(d,PCI_ENABLE_IO)!=0) continue;
        printk("SATA rescue: found NVIDIA MCP61 SATA %04x at PCI %d:%d.%d prog-if=0x%x.\n",
               d->device_id,d->bus,d->device,d->function,d->prog_if);
        mcpd.bus=d->bus; mcpd.dev=d->device; mcpd.fun=d->function;
        for(channel=0;channel<2;channel++) {
            if(mcp61_try_channel(d,channel)) {
                mcpd.mounted=1;
                if(mcp61_register_hda()) return -1;
                mcpd.present=1;
                printk("SATA rescue: hda registered MCP61 PIO/%s, %u sectors.\n",
                       mcpd.lba48?"LBA48":"LBA28",(unsigned)mcpd.sectors);
                printk("SATA rescue safe-write: reads <=255-sector PIO; writes = one 512-byte ATA command + flush, DAPI write-back disabled.\n");
                return 1;
            }
        }
    }
    return 0;
}
