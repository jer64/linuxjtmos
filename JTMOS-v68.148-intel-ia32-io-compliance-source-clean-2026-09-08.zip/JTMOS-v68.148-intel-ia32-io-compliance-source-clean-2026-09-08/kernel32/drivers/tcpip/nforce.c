/*
 * JTMOS polling driver for NVIDIA nForce/MCP61 Ethernet.
 *
 * Minimal forcedeth-compatible transport for the eMachines EL1352 family.
 * It intentionally avoids interrupts/MSI and checksum/VLAN offload: uIP only
 * needs a reliable Ethernet send/receive primitive.  MCP61 uses descriptor
 * format 3; all DMA allocations are kept below 4 GiB by JTMOS.
 */
#include "kernel32.h"
#include "nforce.h"
#include "drivers/pci/pci.h"
#include "core/int/userhw.h"
#include "mm/paging.h"
#include "drivers/driver_sys.h"

#define NV_VENDOR 0x10de
/* Linux forcedeth refuses ring configurations smaller than 128 RX / 64 TX.
 * The original JTMOS MCP61 driver used only 16/8 descriptors.  That is enough
 * for a synthetic smoke test but leaves almost no tolerance for real-hardware
 * DMA latency/bursts.  Keep the hardware-tested forcedeth minimums here. */
#define RX_RING 128
#define TX_RING 64
#define BUF_SIZE 2048
#define DMA_BYTES (512*1024)

/* forcedeth register subset */
#define R_IRQSTAT       0x000
#define R_IRQMASK       0x004
#define R_UNK6          0x008
#define R_POLL          0x00c
#define R_MACRESET      0x034
#define R_MISC1         0x080
#define R_TXCTL         0x084
#define R_TXSTAT        0x088
#define R_PFF           0x08c
#define R_OFFLOAD       0x090
#define R_RXCTL         0x094
#define R_RXSTAT        0x098
#define R_SLOTTIME      0x09c
#define R_TXDEF         0x0a0
#define R_RXDEF         0x0a4
#define R_MACA          0x0a8
#define R_MACB          0x0ac
#define R_MCASTA        0x0b0
#define R_MCASTB        0x0b4
#define R_MCASTMA       0x0b8
#define R_MCASTMB       0x0bc
#define R_PHYIF         0x0c0
#define R_BACKOFF       0x0c4
#define R_TXRING        0x100
#define R_RXRING        0x104
#define R_RINGSZ        0x108
#define R_TXPOLL        0x10c
#define R_LINKSPEED     0x110
#define R_UNK5          0x130
#define UNK5_READY      (1UL<<31)
#define R_TXWM          0x13c
#define R_TXRXCTL       0x144
#define R_TXRINGHI      0x148
#define R_RXRINGHI      0x14c
#define R_TXPAUSE       0x170
#define R_MIISTAT       0x180
#define R_MIIMASK       0x184
#define R_ADAPTER       0x188
#define R_MIISPEED      0x18c
#define R_MIICTL        0x190
#define R_MIIDATA       0x194
#define R_POWER         0x26c
#define R_POWER2        0x600

#define PFF_ALWAYS      0x007f0000UL
#define PFF_MYADDR      0x20
#define MISC1_FORCE     0x003b0f3cUL
#define MISC1_HD        0x02
#define TXCTL_START     0x01
/* MCP61 forcedeth management-unit arbitration lives in TX control.  Do not
 * clobber these fields while stopping/starting DMA: firmware and the host
 * driver share PHY access through this semaphore. */
#define TXCTL_MGMT_ST       0x40000000UL
#define TXCTL_SYNC_PHY_INIT  0x00040000UL
#define TXCTL_MGMT_SEMA_MASK 0x00000f00UL
#define TXCTL_MGMT_SEMA_FREE 0x00000000UL
#define TXCTL_HOST_SEMA_MASK 0x0000f000UL
#define TXCTL_HOST_SEMA_ACQ  0x0000f000UL
#define TXSTAT_BUSY     0x01
#define RXCTL_START     0x01
#define RXSTAT_BUSY     0x01
#define TXRX_KICK       0x0001
#define TXRX_BIT1       0x0002
#define TXRX_BIT2       0x0004
#define TXRX_RESET      0x0010
#define TXRX_DESC3      0x00c02200UL
#define TXWM_DESC23     0x01e08000UL
#define TXWM_DESC23_1000 0x0fe08000UL
#define SLOTTIME        0x80007f00UL
#define SLOTTIME_1000   0x8003ff00UL
#define SLOTTIME_SPEED_MASK 0x0003ff00UL
#define TXDEF_DEFAULT   0x0015050fUL
#define TXDEF_RGMII_10_100 0x0016070fUL
#define TXDEF_RGMII_1000   0x0014050fUL
#define RXDEF_DEFAULT   0x16
#define BACKOFF_DEFAULT 0x70000000UL
#define TXPAUSE_DISABLE 0x0fff0080UL
#define LINK_FORCE      0x10000
#define LINK_10         1000
#define LINK_100        100
#define LINK_1000       50
#define ADAPT_PHYVALID  0x00040000UL
#define ADAPT_RUNNING   0x00100000UL
#define ADAPT_PHYSHIFT  24
#define MIISPEED_BIT8   0x100
#define MIIDELAY        5
#define MIICTL_INUSE    0x08000
#define MIICTL_WRITE    0x00400
#define MIICTL_ADDRSHIFT 5
#define MIISTAT_ERROR   0x01
#define MIISTAT_MASKRW  0x07

#define TX_LAST         (1UL<<29)
#define TX_ERROR        (1UL<<30)
#define TX_VALID        (1UL<<31)
#define RX_DESCVALID    (1UL<<29)
#define RX_ERROR        (1UL<<30)
#define RX_AVAIL        (1UL<<31)
#define RX_ERROR_MASK   (0x7fUL<<18)
#define LEN_MASK        0x3fff

/* standard MII */
#define MII_BMCR        0
#define MII_BMSR        1
#define MII_PHYSID1     2
#define MII_PHYSID2     3
#define MII_ADVERTISE   4
#define MII_LPA         5
#define MII_CTRL1000    9
#define MII_STAT1000    10
#define MII_RESV1       0x17
#define PHY_RGMII       0x10000000UL
#define PHY_100         0x00000001UL
#define PHY_1000        0x00000002UL
#define PHY_HALF        0x00000100UL
#define PHY_GIGABIT     0x0100
#define PHY_OUI_REALTEK 0x0732
#define PHY_OUI_REALTEK2 0x0020
#define PHYID1_OUI_MASK 0x03ff
#define PHYID1_OUI_SHFT 6
#define PHYID2_OUI_MASK 0xfc00
#define PHYID2_OUI_SHFT 10
#define PHYID2_MODEL_MASK 0x03f0
#define PHY_MODEL_REALTEK_8211 0x0110
#define PHY_REV_MASK 0x0001
#define PHY_REV_REALTEK_8211C 0x0001
#define PHY_REALTEK_INIT_REG1 0x1f
#define PHY_REALTEK_INIT_REG6 0x11
#define PHY_REALTEK_INIT_REG7 0x01
#define PHY_REALTEK_INIT1 0x0000
#define PHY_REALTEK_INIT9 0x0008
#define PHY_REALTEK_INIT10 0x0005
#define PHY_REALTEK_INIT11 0x0200
#define POWER2_PHY_RESET 0x0004
#define BMCR_ANENABLE   0x1000
#define BMCR_ANRESTART  0x0200
#define BMCR_ISOLATE    0x0400
#define BMCR_PDOWN      0x0800
#define BMSR_LSTATUS    0x0004
#define BMSR_ANEGCOMPLETE 0x0020
#define ADVERTISE_ALL   0x01e0
#define ADVERTISE_CSMA  0x0001
#define ADV_10HALF      0x0020
#define ADV_10FULL      0x0040
#define ADV_100HALF     0x0080
#define ADV_100FULL     0x0100
#define ADV_1000HALF    0x0100
#define ADV_1000FULL    0x0200
#define LPA_1000HALF    0x0400
#define LPA_1000FULL    0x0800
#define MII_READ        (-1)
#define MII_RETRIES     3

typedef struct {
    volatile DWORD bufhigh;
    volatile DWORD buflow;
    volatile DWORD txvlan;
    volatile DWORD flaglen;
} NFORCE_DESC;

typedef struct {
    int found;
    const PCIDEVICE *pci;
    volatile BYTE *mmio;
    DWORD mmio_phys;
    BYTE mac[6];
    int phy;
    int phy_id1;
    int phy_id2;
    unsigned int phy_oui;
    int phy_model;
    int phy_rev;
    int mgmt_sema;
    int link;
    int link_speed;
    int duplex;
    int mode_valid;
    BYTE *dma;
    DWORD dma_phys;
    NFORCE_DESC *rx;
    NFORCE_DESC *tx;
    DWORD rx_phys;
    DWORD tx_phys;
    BYTE *rxbuf[RX_RING];
    BYTE *txbuf[TX_RING];
    DWORD rxbuf_phys[RX_RING];
    DWORD txbuf_phys[TX_RING];
    int rx_get;
    int tx_put;
    int dnr;
    unsigned long tx_packets,rx_packets,tx_errors,rx_errors;
} NFORCE_STATE;

static NFORCE_STATE nf;

static DWORD rr(int o){return mmio_read32(nf.mmio+o);}
static void wr(int o,DWORD v){mmio_write32(nf.mmio+o,v);(void)rr(0);}
static void mb(void){__asm__ __volatile__("":::"memory");}
static int supported(WORD id){return id==0x03e5||id==0x03e6||id==0x03ee||id==0x03ef;}
static int valid_mac(const BYTE *m){int i,all0=1,allf=1;for(i=0;i<6;i++){if(m[i])all0=0;if(m[i]!=0xff)allf=0;}return !all0&&!allf&&!(m[0]&1);}

static int nforce_dev_call(DEVICE_CALL_PARS)
{
    (void)p1;(void)p2;(void)p3;(void)p4;(void)po1;(void)po2;
    if(n_call==DEVICE_CMD_INIT) return 0;
    if(n_call==DEVICE_CMD_SHUTDOWN){wr(R_IRQMASK,0);wr(R_RXCTL,rr(R_RXCTL)&~RXCTL_START);wr(R_TXCTL,rr(R_TXCTL)&~TXCTL_START);return 0;}
    return -1;
}

static int wait_clear(int reg,DWORD bit,DWORD timeout_ms)
{
    DWORD s=GetTickCount();
    unsigned long guard=0;
    int flags;

    /* Never make NIC progress depend solely on PIT ticks.  On real hardware a
     * wedged MMIO/MII state must degrade to an I/O error, not turn into an
     * infinite kernel loop if the caller happened to enter with IF clear or
     * the scheduler clock is otherwise unable to advance. */
    while(rr(reg)&bit)
    {
        if((DWORD)(GetTickCount()-s)>=timeout_ms || ++guard>=500000UL)
            return -1;
        if((guard&1023UL)==0)
        {
            flags=get_eflags();
            if(Multitasking && !PitStorageSafeActive() && (flags&0x200))
                SwitchToThread();
        }
    }
    return 0;
}

static int wait_set_bounded(int reg,DWORD bit,unsigned long guard_max)
{
    unsigned long guard=0;
    int flags;
    while(!(rr(reg)&bit))
    {
        if(++guard>=guard_max) return -1;
        if((guard&1023UL)==0)
        {
            flags=get_eflags();
            if(Multitasking && !PitStorageSafeActive() && (flags&0x200))
                SwitchToThread();
        }
    }
    return 0;
}

static void mac_reset(void)
{
    DWORD a=rr(R_MACA),b=rr(R_MACB),poll=rr(R_TXPOLL);
    wr(R_TXRXCTL,TXRX_BIT2|TXRX_RESET|TXRX_DESC3);
    wr(R_MACRESET,0x0f3); UsecSleep(64);
    wr(R_MACRESET,0); UsecSleep(64);
    wr(R_MACA,a); wr(R_MACB,b); wr(R_TXPOLL,poll);
    wr(R_TXRXCTL,TXRX_BIT2|TXRX_DESC3);
}

static void power_up(void)
{
    DWORD p=rr(R_POWER2);
    p &= ~0x0f15UL; /* ungate MAC/PHY clocks; MCP61 has DEV_HAS_POWER_CNTRL */
    wr(R_POWER2,p);
    p=rr(R_POWER);
    if(!(p&0x8000)) wr(R_POWER,p|0x8000);
    UsecSleep(10);
    wr(R_POWER,rr(R_POWER)|0x0100);
}

/* Linux forcedeth marks every MCP61 PCI ID supported here with
 * DEV_HAS_MGMT_UNIT.  The management firmware and host driver arbitrate PHY
 * accesses through semaphore fields in NvRegTransmitterControl (0x084).
 * Keeping this bounded is important on JTMOS: a broken management unit must
 * produce a warning/error, never a multi-second hard lock. */
static int mgmt_acquire(void)
{
    DWORD start=GetTickCount(),tx;
    unsigned long guard=0;
    int i;
    nf.mgmt_sema=0;
    while((rr(R_TXCTL)&TXCTL_MGMT_SEMA_MASK)!=TXCTL_MGMT_SEMA_FREE)
    {
        /* Tick progress is not guaranteed while early hardware init is
         * running.  Keep the forcedeth-style wait bounded independently too. */
        if((DWORD)(GetTickCount()-start)>=500UL || guard++>=500UL) return 0;
        UsecSleep(1000);
        if(Multitasking && !PitStorageSafeActive() && (guard&7UL)==0) SwitchToThread();
    }
    for(i=0;i<2;i++)
    {
        tx=rr(R_TXCTL)|TXCTL_HOST_SEMA_ACQ;
        wr(R_TXCTL,tx);
        tx=rr(R_TXCTL);
        if((tx&TXCTL_HOST_SEMA_MASK)==TXCTL_HOST_SEMA_ACQ &&
           (tx&TXCTL_MGMT_SEMA_MASK)==TXCTL_MGMT_SEMA_FREE)
        {
            nf.mgmt_sema=1;
            return 1;
        }
        UsecSleep(50);
    }
    return 0;
}

static void mgmt_release(void)
{
    DWORD tx;
    if(!nf.mgmt_sema) return;
    tx=rr(R_TXCTL);
    tx&=~TXCTL_HOST_SEMA_ACQ;
    wr(R_TXCTL,tx);
    nf.mgmt_sema=0;
}

static int mii_rw(int phy,int reg,int value)
{
    DWORD ctl;int rv;
    if(phy<0 || phy>31 || reg<0 || reg>31)return -1;
    wr(R_MIISTAT,MIISTAT_MASKRW);
    ctl=rr(R_MIICTL);
    if(ctl&MIICTL_INUSE){wr(R_MIICTL,MIICTL_INUSE);UsecSleep(100);}
    ctl=((DWORD)phy<<MIICTL_ADDRSHIFT)|(DWORD)reg;
    if(value!=MII_READ){wr(R_MIIDATA,(DWORD)value);ctl|=MIICTL_WRITE;}
    wr(R_MIICTL,ctl);
    if(wait_clear(R_MIICTL,MIICTL_INUSE,20)<0)return -1;
    if(value!=MII_READ)return 0;
    if(rr(R_MIISTAT)&MIISTAT_ERROR)return -1;
    rv=(int)(rr(R_MIIDATA)&0xffff);
    return rv;
}

static int mii_read_retry(int phy,int reg)
{
    int i,rv=-1;
    for(i=0;i<MII_RETRIES;i++)
    {
        rv=mii_rw(phy,reg,MII_READ);
        if(rv>=0)return rv;
        UsecSleep(50);
    }
    return -1;
}

static int mii_write_retry(int phy,int reg,int value)
{
    int i;
    for(i=0;i<MII_RETRIES;i++)
    {
        if(mii_rw(phy,reg,value)==0)return 0;
        UsecSleep(50);
    }
    return -1;
}

/* forcedeth halts AdapterControl while it owns the MDIO bus.  Leaving the
 * firmware's RUNNING bit set made PHY discovery depend on warm-boot state and
 * could race the MCP61 link state machine on the EL1352. */
static void phy_adapter_quiesce(void)
{
    DWORD adapter=rr(R_ADAPTER);
    wr(R_MIIMASK,0);
    if(adapter&ADAPT_RUNNING)
    {
        wr(R_ADAPTER,adapter&~ADAPT_RUNNING);
        UsecSleep(10);
    }
    wr(R_MIISTAT,0x0f);
}

static void remember_phy(int p,int id1,int id2)
{
    int rev=-1;
    unsigned int oui;
    nf.phy=p;nf.phy_id1=id1;nf.phy_id2=id2;
    nf.phy_model=id2&PHYID2_MODEL_MASK;
    oui=((unsigned int)(id1&PHYID1_OUI_MASK)<<PHYID1_OUI_SHFT)|
        ((unsigned int)(id2&PHYID2_OUI_MASK)>>PHYID2_OUI_SHFT);
    if(oui==PHY_OUI_REALTEK2) oui=PHY_OUI_REALTEK;
    nf.phy_oui=oui;
    nf.phy_rev=-1;
    if(oui==PHY_OUI_REALTEK && nf.phy_model==PHY_MODEL_REALTEK_8211)
    {
        rev=mii_read_retry(p,MII_RESV1);
        if(rev>=0) nf.phy_rev=rev&PHY_REV_MASK;
    }
    printk("NFORCE: PHY addr=%d id=%04x:%04x OUI=0x%x model=0x%x rev=%d.\n",
           p,id1&0xffff,id2&0xffff,oui,nf.phy_model,nf.phy_rev);
}

static int find_phy(void)
{
    int pass,p,a,b;
    for(pass=0;pass<2;pass++)
    {
        for(p=1;p<32;p++){
            a=mii_read_retry(p,MII_PHYSID1); b=mii_read_retry(p,MII_PHYSID2);
            /* Realtek hardcodes PHYSID1 to 0 on some RTL8211 parts.  Linux
             * forcedeth explicitly accepts this; requiring a>0 made JTMOS reject
             * the EL1352's valid RTL8211CL PHY even though the MCP61 MAC was found. */
            if(a>=0 && a!=0xffff && b>0 && b!=0xffff){remember_phy(p,a,b);return p;}
        }
        /* forcedeth scans address zero last (its 1..32 loop wraps 32 to zero). */
        a=mii_read_retry(0,MII_PHYSID1);b=mii_read_retry(0,MII_PHYSID2);
        if(a>=0&&a!=0xffff&&b>0&&b!=0xffff){remember_phy(0,a,b);return 0;}
        if(pass==0)UsecSleep(10000);
    }
    return -1;
}

static int realtek_8211c_init(void)
{
    DWORD power;
    int reg,rv=-1;
    if(nf.phy<0) return -1;
    power=rr(R_POWER2);
    wr(R_POWER2,power|POWER2_PHY_RESET);UsecSleep(25000);
    wr(R_POWER2,power&~POWER2_PHY_RESET);UsecSleep(25000);
    /* A failed previous attempt may have left a vendor page selected. */
    if(mii_write_retry(nf.phy,PHY_REALTEK_INIT_REG1,PHY_REALTEK_INIT1)<0)goto out;
    reg=mii_read_retry(nf.phy,PHY_REALTEK_INIT_REG6);
    if(reg<0 || mii_write_retry(nf.phy,PHY_REALTEK_INIT_REG6,reg|PHY_REALTEK_INIT9)<0)goto out;
    if(mii_write_retry(nf.phy,PHY_REALTEK_INIT_REG1,PHY_REALTEK_INIT10)<0)goto out;
    reg=mii_read_retry(nf.phy,PHY_REALTEK_INIT_REG7);
    if(reg<0)goto out;
    if(!(reg&PHY_REALTEK_INIT11) &&
       mii_write_retry(nf.phy,PHY_REALTEK_INIT_REG7,reg|PHY_REALTEK_INIT11)<0)goto out;
    rv=0;
out:
    /* Generic MII registers are on page zero.  Always restore it, including
     * failure paths, before phy_setup() attempts its generic fallback. */
    if(mii_write_retry(nf.phy,PHY_REALTEK_INIT_REG1,PHY_REALTEK_INIT1)<0)rv=-1;
    if(rv==0)printk("NFORCE: Realtek RTL8211C/CL forcedeth PHY init applied.\n");
    return rv;
}

static int phy_setup(void)
{
    int adv,bmcr,bmsr,gctl;
    if(nf.phy<0)return -1;
    if(nf.phy_oui==PHY_OUI_REALTEK &&
       nf.phy_model==PHY_MODEL_REALTEK_8211 &&
       nf.phy_rev==PHY_REV_REALTEK_8211C)
    {
        if(realtek_8211c_init()<0)
            printk("NFORCE: warning: RTL8211C/CL vendor init failed; trying generic autoneg.\n");
    }
    adv=mii_read_retry(nf.phy,MII_ADVERTISE);
    if(adv<0 || mii_write_retry(nf.phy,MII_ADVERTISE,
       adv|ADVERTISE_ALL|ADVERTISE_CSMA|0x0c00)<0)return -1;
    bmsr=mii_read_retry(nf.phy,MII_BMSR);
    if(bmsr>=0 && (bmsr&PHY_GIGABIT))
    {
        gctl=mii_read_retry(nf.phy,MII_CTRL1000);
        if(gctl>=0)
        {
            gctl&=~ADV_1000HALF;
            if(rr(R_PHYIF)&PHY_RGMII) gctl|=ADV_1000FULL;
            else gctl&=~ADV_1000FULL;
            if(mii_write_retry(nf.phy,MII_CTRL1000,gctl)<0)return -1;
        }
    }
    bmcr=mii_read_retry(nf.phy,MII_BMCR);
    if(bmcr<0)return -1;
    bmcr&=~(BMCR_PDOWN|BMCR_ISOLATE);
    if(mii_write_retry(nf.phy,MII_BMCR,bmcr|BMCR_ANENABLE|BMCR_ANRESTART)<0)return -1;
    return 0;
}

static void program_link_mode(int speed,int duplex)
{
    DWORD phyif,slot,txdef;
    int tx_running,rx_running;

    if(nf.mode_valid && nf.link_speed==speed && nf.duplex==duplex)return;

    tx_running=(rr(R_TXCTL)&TXCTL_START)?1:0;
    rx_running=(rr(R_RXCTL)&RXCTL_START)?1:0;
    /* forcedeth stops both engines before changing MAC/PHY interface timing. */
    if(tx_running)
    {
        wr(R_TXCTL,rr(R_TXCTL)&~TXCTL_START);
        if(wait_clear(R_TXSTAT,TXSTAT_BUSY,500)<0)
            printk("NFORCE: TX engine busy during link-mode change.\n");
    }
    if(rx_running)
    {
        wr(R_RXCTL,rr(R_RXCTL)&~RXCTL_START);
        if(wait_clear(R_RXSTAT,RXSTAT_BUSY,500)<0)
            printk("NFORCE: RX engine busy during link-mode change.\n");
    }

    phyif=rr(R_PHYIF);
    phyif&=~(PHY_HALF|PHY_100|PHY_1000);
    if(!duplex)phyif|=PHY_HALF;
    if(speed==100)phyif|=PHY_100;
    else if(speed==1000)phyif|=PHY_1000;
    wr(R_PHYIF,phyif);

    if(phyif&PHY_RGMII)
        txdef=(speed==1000)?TXDEF_RGMII_1000:TXDEF_RGMII_10_100;
    else txdef=TXDEF_DEFAULT;
    wr(R_TXDEF,txdef);

    slot=rr(R_SLOTTIME)&~SLOTTIME_SPEED_MASK;
    slot|=(speed==1000)?SLOTTIME_1000:SLOTTIME;
    wr(R_SLOTTIME,slot);
    wr(R_TXWM,speed==1000?TXWM_DESC23_1000:TXWM_DESC23);
    wr(R_MISC1,MISC1_FORCE|(duplex?0:MISC1_HD));
    wr(R_LINKSPEED,LINK_FORCE|(speed==1000?LINK_1000:(speed==100?LINK_100:LINK_10)));

    if(tx_running)wr(R_TXCTL,rr(R_TXCTL)|TXCTL_START);
    if(rx_running)wr(R_RXCTL,rr(R_RXCTL)|RXCTL_START);

    nf.link_speed=speed;
    nf.duplex=duplex;
    nf.mode_valid=1;
    printk("NFORCE: MAC mode %d Mbps %s-duplex, PHYIF=0x%x TXDEF=0x%x.\n",
           speed,duplex?"full":"half",phyif,txdef);
}

static int update_link_mode(void)
{
    int bmsr,adv,lpa,gctl,gstat,common,speed=10,duplex=0;
    if(nf.phy<0)return 0;
    (void)mii_read_retry(nf.phy,MII_BMSR);
    bmsr=mii_read_retry(nf.phy,MII_BMSR);
    if(bmsr<0 || !(bmsr&BMSR_LSTATUS) || !(bmsr&BMSR_ANEGCOMPLETE))
    { nf.link=0; return 0; }
    adv=mii_read_retry(nf.phy,MII_ADVERTISE);
    lpa=mii_read_retry(nf.phy,MII_LPA);
    if(adv<0 || lpa<0){nf.link=0;return 0;}
    gctl=mii_read_retry(nf.phy,MII_CTRL1000);
    gstat=mii_read_retry(nf.phy,MII_STAT1000);
    if(gctl>=0 && gstat>=0 && (((gctl&ADV_1000FULL)&&(gstat&LPA_1000FULL)) || ((gctl&ADV_1000HALF)&&(gstat&LPA_1000HALF)))) {
        speed=1000; duplex=((gctl&ADV_1000FULL)&&(gstat&LPA_1000FULL))?1:0;
    } else {
        common=(adv>=0&&lpa>=0)?(adv&lpa):0;
        if(common&ADV_100FULL){speed=100;duplex=1;}
        else if(common&ADV_100HALF){speed=100;duplex=0;}
        else if(common&ADV_10FULL){speed=10;duplex=1;}
        else if(common&ADV_10HALF){speed=10;duplex=0;}
        else {nf.link=0;return 0;}
    }
    program_link_mode(speed,duplex);
    nf.link=1;
    return 1;
}

static void read_mac(void)
{
    DWORD a=rr(R_MACA),b=rr(R_MACB);
    nf.mac[0]=(BYTE)a; nf.mac[1]=(BYTE)(a>>8); nf.mac[2]=(BYTE)(a>>16); nf.mac[3]=(BYTE)(a>>24);
    nf.mac[4]=(BYTE)b; nf.mac[5]=(BYTE)(b>>8);
}

static int setup_dma(void)
{
    DWORD off=0,phys;int i;
    nf.dma=(BYTE *)userhw_dma_alloc_kernel32(DMA_BYTES,&nf.dma_phys);
    if(!nf.dma)return -1;
    memset(nf.dma,0,DMA_BYTES);
    off=(off+255)&~255UL;
    nf.rx=(NFORCE_DESC *)(nf.dma+off);nf.rx_phys=nf.dma_phys+off;off+=RX_RING*sizeof(NFORCE_DESC);
    off=(off+255)&~255UL;
    nf.tx=(NFORCE_DESC *)(nf.dma+off);nf.tx_phys=nf.dma_phys+off;off+=TX_RING*sizeof(NFORCE_DESC);
    off=(off+2047)&~2047UL;
    for(i=0;i<RX_RING;i++){nf.rxbuf[i]=nf.dma+off;phys=nf.dma_phys+off;nf.rxbuf_phys[i]=phys;off+=BUF_SIZE;}
    for(i=0;i<TX_RING;i++){nf.txbuf[i]=nf.dma+off;phys=nf.dma_phys+off;nf.txbuf_phys[i]=phys;off+=BUF_SIZE;}
    if(off>DMA_BYTES)return -2;
    for(i=0;i<RX_RING;i++){
        nf.rx[i].bufhigh=0;nf.rx[i].buflow=nf.rxbuf_phys[i];nf.rx[i].txvlan=0;nf.rx[i].flaglen=BUF_SIZE|RX_AVAIL;
    }
    for(i=0;i<TX_RING;i++){
        nf.tx[i].bufhigh=0;nf.tx[i].buflow=nf.txbuf_phys[i];nf.tx[i].txvlan=0;nf.tx[i].flaglen=0;
    }
    mb();
    printk("NFORCE: DMA phys=0x%x rxring=0x%x txring=0x%x (%d RX/%d TX, %d-byte buffers).\n",nf.dma_phys,nf.rx_phys,nf.tx_phys,RX_RING,TX_RING,BUF_SIZE);
    return 0;
}

static void reset_dma_rings(void)
{
    int i;
    if(!nf.dma || !nf.rx || !nf.tx) return;
    nf.rx_get=0;
    nf.tx_put=0;
    for(i=0;i<RX_RING;i++)
    {
        nf.rx[i].bufhigh=0;
        nf.rx[i].buflow=nf.rxbuf_phys[i];
        nf.rx[i].txvlan=0;
        nf.rx[i].flaglen=BUF_SIZE|RX_AVAIL;
    }
    for(i=0;i<TX_RING;i++)
    {
        nf.tx[i].bufhigh=0;
        nf.tx[i].buflow=nf.txbuf_phys[i];
        nf.tx[i].txvlan=0;
        nf.tx[i].flaglen=0;
    }
    nf.tx_packets=0;
    nf.rx_packets=0;
    nf.tx_errors=0;
    nf.rx_errors=0;
    mb();
}

static void program_controller(void)
{
    DWORD txpoll;
    wr(R_IRQMASK,0);wr(R_MIIMASK,0);wr(R_IRQSTAT,0xffffffffUL);wr(R_MIISTAT,0x0f);
    wr(R_TXCTL,rr(R_TXCTL)&~TXCTL_START);wr(R_RXCTL,0);
    /* Clear stale completion/busy status left by firmware or a warm reboot. */
    wr(R_TXSTAT,rr(R_TXSTAT));wr(R_RXSTAT,rr(R_RXSTAT));
    wr(R_ADAPTER,0);
    wr(R_MCASTA,1);wr(R_MCASTB,0);wr(R_MCASTMA,0xffffffffUL);wr(R_MCASTMB,0xffff);
    wr(R_PFF,0);
    /* MCP61 supports forcedeth pause-frame v1.  Do not inherit a firmware or
     * previous-OS TX-pause state: Linux forcedeth explicitly disables it
     * because some nForce NICs can freeze with TX pause enabled while down. */
    wr(R_TXPAUSE,TXPAUSE_DISABLE);
    txpoll=rr(R_TXPOLL)&0x8000;wr(R_TXPOLL,txpoll);
    wr(R_TXRXCTL,TXRX_BIT2|TXRX_RESET|TXRX_DESC3);UsecSleep(10);wr(R_TXRXCTL,TXRX_BIT2|TXRX_DESC3);
    wr(R_UNK6,0);
    wr(R_RXRING,nf.rx_phys);wr(R_RXRINGHI,0);wr(R_TXRING,nf.tx_phys);wr(R_TXRINGHI,0);
    wr(R_RINGSZ,((RX_RING-1)<<16)|(TX_RING-1));
    /* Autonegotiation is not complete yet.  forcedeth uses 10/Half as the
     * conservative MAC mode until a common PHY mode has been resolved. */
    wr(R_LINKSPEED,LINK_FORCE|LINK_10);
    wr(R_TXWM,TXWM_DESC23);wr(R_MISC1,MISC1_FORCE|MISC1_HD);
    wr(R_PFF,PFF_ALWAYS|PFF_MYADDR);wr(R_OFFLOAD,BUF_SIZE);
    wr(R_SLOTTIME,SLOTTIME);wr(R_TXDEF,TXDEF_DEFAULT);wr(R_RXDEF,RXDEF_DEFAULT);wr(R_BACKOFF,BACKOFF_DEFAULT);
    wr(R_POLL,13);wr(R_UNK6,3);
    if(nf.phy>=0)wr(R_ADAPTER,((DWORD)nf.phy<<ADAPT_PHYSHIFT)|ADAPT_PHYVALID|ADAPT_RUNNING);
    wr(R_MIISPEED,MIISPEED_BIT8|MIIDELAY);
    wr(R_IRQMASK,0);wr(R_MIIMASK,0); /* polling only */
    /* forcedeth setup sequence: descriptor format, BIT1 handoff, then wait
     * for UnknownSetupReg5 bit31 before starting DMA.  Older JTMOS skipped the
     * readiness handshake entirely, which can race a real MCP61 controller. */
    wr(R_TXRXCTL,TXRX_DESC3);
    wr(R_TXRXCTL,TXRX_BIT1|TXRX_DESC3);
    if(wait_set_bounded(R_UNK5,UNK5_READY,500000UL)<0)
        printk("NFORCE: warning: SetupReg5 ready bit did not assert; continuing in polling-safe mode.\n");
    nf.mode_valid=0;
    program_link_mode(10,0);
    wr(R_RXCTL,rr(R_RXCTL)|RXCTL_START);
    wr(R_TXCTL,rr(R_TXCTL)|TXCTL_START);
    wr(R_TXRXCTL,TXRX_KICK|TXRX_DESC3);
    wr(R_PFF,PFF_ALWAYS|PFF_MYADDR);
    printk("NFORCE: rings programmed RX=0x%x TX=0x%x sizes=%x ctl=%x.\n",
           rr(R_RXRING),rr(R_TXRING),rr(R_RINGSZ),rr(R_TXRXCTL));
}

static const PCIDEVICE *probe_pci(void)
{
    int i;const PCIDEVICE *d;
    pci_init();
    for(i=0;i<pci_get_device_count();i++){
        d=pci_get_device(i);if(d&&d->vendor_id==NV_VENDOR&&supported(d->device_id))return d;
    }
    return NULL;
}

/* pci_enable_device() in Linux also brings a function back to PCI D0.  The
 * compact JTMOS PCI helper only sets COMMAND bits, so do the PM-capability
 * transition here before touching an MCP61 left in D3 by a previous OS. */
static int pci_enter_d0(const PCIDEVICE *d)
{
    int cap;
    WORD pmcsr;
    if(!d)return -1;
    cap=pci_find_capability(d,PCI_CAP_ID_PM);
    if(!cap)return 0;
    pmcsr=pci_config_read16(d->bus,d->device,d->function,(BYTE)(cap+4));
    if(pmcsr==0xffff || !(pmcsr&3))return 0;
    printk("NFORCE: PCI power state D%d -> D0.\n",pmcsr&3);
    pci_config_write16(d->bus,d->device,d->function,(BYTE)(cap+4),(WORD)(pmcsr&~3U));
    UsecSleep(10000);
    pmcsr=pci_config_read16(d->bus,d->device,d->function,(BYTE)(cap+4));
    return (pmcsr&3)?-1:0;
}

int nforce_init(void)
{
    const PCIDEVICE *d;PCIBAR bar;DWORD pagebase,map,off,start;int pages,link_tries;
    if(nf.found)return 0;
    memset(&nf,0,sizeof(nf));nf.phy=-1;nf.dnr=-1;
    d=probe_pci();if(!d)return -1;nf.pci=d;
    printk("NFORCE: MCP61 Ethernet PCI %d:%d.%d %x:%x rev=%x irq=%d.\n",d->bus,d->device,d->function,d->vendor_id,d->device_id,d->revision,d->irq_line);
    if(pci_get_bar(d,0,&bar)!=0||!bar.valid||bar.io||bar.is64||!bar.base_low){printk("NFORCE: BAR0 MMIO unavailable.\n");return -2;}
    if(pci_enter_d0(d)<0){printk("NFORCE: PCI function did not enter D0.\n");return -3;}
    if(pci_enable_device(d,PCI_ENABLE_MEMORY|PCI_ENABLE_MASTER)!=0)return -3;
    pagebase=bar.base_low&~(PAGESIZE-1);off=bar.base_low-pagebase;pages=(int)((off+0x604+PAGESIZE-1)/PAGESIZE);
    map=pg_mapio((int)(pagebase/PAGESIZE),pages);if(!map)return -4;
    nf.mmio=(volatile BYTE *)(map+off);nf.mmio_phys=bar.base_low;
    read_mac();
    if(!valid_mac(nf.mac)){printk("NFORCE: invalid MAC %x:%x:%x:%x:%x:%x.\n",nf.mac[0],nf.mac[1],nf.mac[2],nf.mac[3],nf.mac[4],nf.mac[5]);return -5;}
    printk("NFORCE: MAC %02x:%02x:%02x:%02x:%02x:%02x MMIO=0x%x.\n",nf.mac[0],nf.mac[1],nf.mac[2],nf.mac[3],nf.mac[4],nf.mac[5],nf.mmio_phys);
    power_up();
    mac_reset();
    /* MCP61 management firmware shares the PHY.  Acquire the forcedeth host
     * semaphore before PHY discovery/init and preserve TX-control mgmt bits. */
    wr(R_MIISPEED,MIISPEED_BIT8|MIIDELAY);phy_adapter_quiesce();
    if((rr(R_TXCTL)&(TXCTL_MGMT_ST|TXCTL_SYNC_PHY_INIT))==(TXCTL_MGMT_ST|TXCTL_SYNC_PHY_INIT))
    {
        if(!mgmt_acquire())
            printk("NFORCE: warning: MCP61 management PHY semaphore not acquired.\n");
    }
    nf.phy=find_phy();
    if(nf.phy<0)printk("NFORCE: PHY not identified; link/DHCP will remain unavailable.\n");
    else if(phy_setup()<0)printk("NFORCE: PHY setup failed; link remains down until restart succeeds.\n");
    mgmt_release();
    if(setup_dma()<0)return -6;
    program_controller();
    start=GetTickCount();
    for(link_tries=0;link_tries<50 && (DWORD)(GetTickCount()-start)<2500UL;link_tries++)
    {
        if(update_link_mode())break;
        UsecSleep(50000);
    }
    nf.found=1;
    nf.dnr=driver_getdevicenrbyname("nforce0");
    if(nf.dnr<0)nf.dnr=driver_register_new_device("nforce0",nforce_dev_call,DEVICE_TYPE_CHAR);
    if(nf.link) printk("NFORCE: native MCP61 polling Ethernet ready, link=up %d Mbps %s-duplex, descriptor=v3.\n",nf.link_speed,nf.duplex?"full":"half");
    else printk("NFORCE: native MCP61 polling Ethernet ready, link=negotiating/down, descriptor=v3.\n");
    return 0;
}

int nforce_restart(void)
{
    DWORD start;
    int link_tries;

    if(!nf.found || !nf.mmio || !nf.dma) return -1;

    /* Stop DMA before rebuilding descriptors.  Keep the existing MMIO mapping
     * and DMA allocation: repeatedly allocating them from `net restart` would
     * leak low physical memory and eventually destabilize the kernel. */
    wr(R_IRQMASK,0);
    wr(R_MIIMASK,0);
    wr(R_RXCTL,rr(R_RXCTL)&~RXCTL_START);
    if(wait_clear(R_RXSTAT,RXSTAT_BUSY,500)<0)
        printk("NFORCE: RX engine did not become idle before restart.\n");
    wr(R_TXCTL,rr(R_TXCTL)&~TXCTL_START);
    if(wait_clear(R_TXSTAT,TXSTAT_BUSY,500)<0)
        printk("NFORCE: TX engine did not become idle before restart.\n");
    UsecSleep(100);

    power_up();
    mac_reset();
    wr(R_MIISPEED,MIISPEED_BIT8|MIIDELAY);
    phy_adapter_quiesce();
    if((rr(R_TXCTL)&(TXCTL_MGMT_ST|TXCTL_SYNC_PHY_INIT))==(TXCTL_MGMT_ST|TXCTL_SYNC_PHY_INIT))
    {
        if(!mgmt_acquire())
            printk("NFORCE: warning: management PHY semaphore unavailable during restart.\n");
    }
    /* Re-read the PHY identity after the hardware reset.  This also recovers
     * from a transiently missing MDIO device during the first boot scan. */
    nf.phy=find_phy();
    if(nf.phy>=0 && phy_setup()<0)
        printk("NFORCE: PHY setup failed during restart.\n");
    mgmt_release();

    nf.link=0;
    nf.link_speed=0;
    nf.duplex=0;
    nf.mode_valid=0;
    reset_dma_rings();
    program_controller();

    /* A restart must not fail just because the cable is currently unplugged.
     * Give autonegotiation a short opportunity, then leave carrier tracking to
     * ethdev_link_up()/JNET maintenance. */
    start=GetTickCount();
    for(link_tries=0;link_tries<10 && (DWORD)(GetTickCount()-start)<500UL;link_tries++)
    {
        if(update_link_mode()) break;
        UsecSleep(50000);
    }
    printk("NFORCE: Ethernet controller restarted, link=%s.\n",nf.link?"up":"down/negotiating");
    return 0;
}

int nforce_present(void){return nf.found;}
const unsigned char *nforce_mac(void){return nf.mac;}
const char *nforce_pci_name(void){static char n[]="NVIDIA MCP61";return n;}
int nforce_phy_addr(void){return nf.phy;}
unsigned int nforce_phy_oui(void){return nf.phy_oui;}
int nforce_phy_model(void){return nf.phy_model;}
int nforce_phy_rev(void){return nf.phy_rev;}
int nforce_link_speed(void){return nf.link?nf.link_speed:0;}
int nforce_full_duplex(void){return nf.link?nf.duplex:0;}
int nforce_link_up(void){if(!nf.found)return 0;return update_link_mode();}

int nforce_send(const void *buf,int len)
{
    NFORCE_DESC *d;
    DWORD f;
    int i,scan,n=len;

    if(!nf.found||!buf||len<=0||len>1518)return -1;
    if(!nf.link) update_link_mode();

    /* DMA transmit is asynchronous.  Never wait for TX_VALID to clear here:
     * the former synchronous 100/200 ms loops ran inside the single Ethernet
     * owner and could freeze the whole machine when a physical MCP61 stopped
     * completing a descriptor.  Find a descriptor the NIC has returned; if
     * the ring is genuinely full, fail this packet quickly and let TCP/uIP
     * retransmission or the next ping attempt recover. */
    i=nf.tx_put;
    d=NULL;
    for(scan=0;scan<TX_RING;scan++)
    {
        NFORCE_DESC *candidate=&nf.tx[i];
        f=candidate->flaglen;
        if(!(f&TX_VALID))
        {
            d=candidate;
            if(f&TX_ERROR) nf.tx_errors++;
            break;
        }
        i=(i+1)%TX_RING;
    }
    if(!d)
    {
        nf.tx_errors++;
        /* A kick is harmless and can recover a controller that merely missed
         * a poll edge.  Crucially there is no busy/yield loop here. */
        wr(R_TXRXCTL,TXRX_KICK|TXRX_DESC3);
        return -2;
    }

    if(n<60)n=60;
    memcpy(nf.txbuf[i],buf,len);
    if(n>len)memset(nf.txbuf[i]+len,0,n-len);
    d->bufhigh=0;
    d->buflow=nf.txbuf_phys[i];
    d->txvlan=0;
    mb();
    d->flaglen=((DWORD)n-1)|TX_LAST|TX_VALID;
    mb();
    /* BIT2 belongs to the reset sequence.  Normal forcedeth ownership kicks
     * contain only KICK plus the descriptor-format bits. */
    wr(R_TXRXCTL,TXRX_KICK|TXRX_DESC3);

    nf.tx_put=(i+1)%TX_RING;
    nf.tx_packets++;
    return n;
}

int nforce_receive(void *buf,int maxlen)
{
    NFORCE_DESC *d;DWORD f;int i,len;
    if(!nf.found||!buf||maxlen<14)return 0;
    i=nf.rx_get;d=&nf.rx[i];f=d->flaglen;
    if(f&RX_AVAIL)return 0;
    len=(int)(f&LEN_MASK);
    /* Descriptor v2/v3 reports the received frame length.  Some revisions
     * include FCS; trim only an obvious Ethernet FCS-sized overshoot. */
    if(len>1518&&len<=1522)len-=4;
    if(!(f&RX_DESCVALID)||(f&(RX_ERROR|RX_ERROR_MASK))||len<14||len>1518||len>maxlen){
        nf.rx_errors++;if((nf.rx_errors<8)||!(nf.rx_errors&63))printk("NFORCE/RX: drop slot=%d flags=0x%x len=%d.\n",i,f,len);
        len=-1;
    } else {
        memcpy(buf,nf.rxbuf[i],len);nf.rx_packets++;
        if(nf.rx_packets<=8) printk("NFORCE/RX #%lu len=%d type=%02x%02x.\n",nf.rx_packets,len,((BYTE*)buf)[12],((BYTE*)buf)[13]);
    }
    d->bufhigh=0;d->buflow=nf.rxbuf_phys[i];d->txvlan=0;mb();d->flaglen=BUF_SIZE|RX_AVAIL;mb();
    nf.rx_get=(i+1)%RX_RING;
    return len;
}
