/*
 * ramdisk.c
 * RAM DISK BLOCK DEVICE DRIVER.
 * (C) 2002-2008 by Jari Tuominen.
 *
 * Changed ram disk device name to "ram:", much simplier now.
 *
 * 1/2003: Added ram disk service
 * ------: Service adding frozen for now, will fix some other stuff first
 */

//
#include "basdef.h"
#include "sysmem.h"
#include "kernel32.h"
#include "ramdisk.h"
//
#include "driver_sys.h" // driver_register_new_device, ...
#include "driver_api.h" // readblock,writeblock,getsize,getblocksize, ...

// Default ram disk which will be
// created upon initialization of the ram disk device.
RAMDISK_IMAGE default_ramdisk;
int ram_dev_mounted=1;

/* Default RAM-disk policy.
 *
 * The normal JTMOS ram: target is exactly RD_DEFAULT_SIZE blocks, currently
 * 40960 x 512 bytes = 20 MiB.  Do not use the old one-quarter-of-RAM rule:
 * it made a machine reported as 64 MiB receive only a 16 MiB ramdisk even
 * though a 20 MiB disk is useful for the utilities/install working set.
 *
 * Keep at least 16 MiB outside ram: for the kernel, application banks and
 * decompression/network buffers.  On systems below 36 MiB this therefore
 * scales down gracefully, with the historical 4 MiB minimum retained for a
 * machine meeting the 16 MiB kernel minimum.  The block count is rounded to
 * an IA-32 4 KiB page boundary. */
static DWORD rd_default_blocks_for_ram(void)
{
	DWORD total, wanted, reserve, minimum, bytes, blocks;

	total = (DWORD)GetRamAmount();
	wanted = (DWORD)RD_DEFAULT_SIZE * (DWORD)RD_DEFAULT_BLOCK_SIZE;
	reserve = 16UL * 1024UL * 1024UL;
	minimum = 4UL * 1024UL * 1024UL;

	if(total > reserve)
		bytes = total - reserve;
	else
		bytes = minimum;

	if(bytes < minimum)
		bytes = minimum;
	if(bytes > wanted)
		bytes = wanted;

	blocks = bytes / (DWORD)RD_DEFAULT_BLOCK_SIZE;
	blocks &= ~7UL; /* 8 x 512 bytes = one IA-32 4 KiB page. */
	if(blocks == 0)
		blocks = 8;
	return blocks;
}

//
void rd_createdefaultramdisk(void)
{
	RAMDISK_IMAGE *i;
	DWORD blocks;


	//
	i=&default_ramdisk;

	/* This routine is also called by the legacy RAM-disk service.  Recreating
	 * the image after KernelInit() has formatted it would free/replace the
	 * filesystem backing store and make the boot-time JTMFS disappear before
	 * SMSH starts.  Treat an already valid image as initialized. */
	if(i->buf!=NULL && i->blocks>0 && i->blocksize>0)
	{
		dprintk("ramdisk: default image already exists (%d blocks x %d); preserving contents.\n",
			(int)i->blocks, (int)i->blocksize);
		return;
	}

	// Create the device only on machines that satisfy the kernel minimum.
	if( GetRamAmount() >= (1024*1024*16) )
	{
		blocks = rd_default_blocks_for_ram();
		printk("Initializing ram disk device(%dK, %d blocks x %d)\n",
			(int)(blocks * (DWORD)RD_DEFAULT_BLOCK_SIZE / 1024UL),
			(int)blocks, RD_DEFAULT_BLOCK_SIZE);
		if(blocks != (DWORD)RD_DEFAULT_SIZE)
			printk("ramdisk: size scaled down from %dK to preserve 16 MiB system RAM.\n",
				RD_DEFAULT_SIZE * RD_DEFAULT_BLOCK_SIZE / 1024);
		rd_createimage(i, blocks, RD_DEFAULT_BLOCK_SIZE);
		if(i->buf!=NULL)
			printk("Ramdisk block device has been initialized.\n");
		else
			printk("ramdisk: image allocation failed; ram: remains unavailable.\n");
	}
	else
	{
		printk("This computer has a very low amount of total RAM available.\n");
		printk("Not enough memory for ram disk.\n");
	}
}


// Old stylish device call wrapper, direct access!
int rdDevCall(DCP)
{
	SREQ ss;

	/* The device layer already serializes one DEVICE_ENTRY.  Keep the request
	 * packet on this call's stack so RAM I/O no longer needs a global static
	 * packet protected by a long IRQ-off critical section. */
	// Convert to SREQ structure
	ss.n_call = n_call;
	ss.p1 = p1;
	ss.p2 = p2;
	ss.p3 = p3;
	ss.p4 = p4;
	ss.po1 = po1;
	ss.po2 = po2;
	// Give out to handler
	return rdHandler(&ss);
}

// Note: To see what does 'DEVICE_CALL_PARS'(DCP) mean,
// check driver_api.h.
//
int rdHandler(SREQ *s)
{
	DWORD *size;
	int rc=0;

	// If unmounted, we won't answer anything until mounted again.
	if(s->n_call!=DEVICE_CMD_MOUNT && !ram_dev_mounted)
		return 0;

	/* Do not CLI around RAM copies.  device_call() owns the per-device busy
	 * serialization, and rdDevCall() now uses a local SREQ.  Keeping IF enabled
	 * here is important during multi-block bootstrap writes: IRQ1, Ctrl-Alt-Del
	 * and Alt+Fn must remain live while ram: is busy. */
	switch(s->n_call)
	{
                case DEVICE_CMD_MOUNT:
                ram_dev_mounted=1;
                break;
                case DEVICE_CMD_UNMOUNT:
                ram_dev_mounted=0;
                break;

		//
		case DEVICE_CMD_INIT:
		break;
		//
		case DEVICE_CMD_SHUTDOWN:
		break;
		//
		case DEVICE_CMD_READBLOCK:
		rc = rd_readblocks(&default_ramdisk,s->p1,1,s->po1)==1 ? 0 : 1;
		break;
		case DEVICE_CMD_WRITEBLOCK:
		rc = rd_writeblocks(&default_ramdisk,s->p1,1,s->po1)==1 ? 0 : 1;
		break;
		case DEVICE_CMD_READBLOCKS:
		rc = rd_readblocks(&default_ramdisk,s->p1,s->p2,s->po1)==s->p2 ? 0 : 1;
		break;
		case DEVICE_CMD_WRITEBLOCKS:
		rc = rd_writeblocks(&default_ramdisk,s->p1,s->p2,s->po1)==s->p2 ? 0 : 1;
		break;
		//
		case DEVICE_CMD_GETSIZE:
		size = s->po1;
		*size = rd_getsize(&default_ramdisk);
		break;
		//
		case DEVICE_CMD_GETBLOCKSIZE:
		size = s->po1;
		*size = default_ramdisk.blocksize;
		break;
		//
		case DEVICE_CMD_SEEK:
		break;
		//
		case DEVICE_CMD_GETCH:
		break;
		//
		case DEVICE_CMD_PUTCH:
		break;
		//
		case DEVICE_CMD_TELL:
		break;
		//
		default:
		if(s->extension_wrapper_function!=NULL)
			((int(*)(void *))s->extension_wrapper_function)(s);
		break;
	}

	return rc;
}

// Registers device 'ramdisk'
int rd_register_device(void)
{
	// Check that the device isn't already registered
	if(driver_getdevicebyname("ram"))
	{
		dprintk("rd_register_device: ram: already registered; keeping existing device.\n");
		return 0;
	}

	// Register the device
	driver_register_new_device("ram", rdDevCall, DEVICE_TYPE_BLOCK|DEVICE_TYPE_MULTIBLOCK);
	driver_disableDAPIReadCache(driver_getdevicenrbyname("ram"));
	driver_disableDAPIWriteBackCache(driver_getdevicenrbyname("ram"));
	// Create alias ramdisk:
	driver_register_new_deviceEx( "ramdisk", rdDevCall,0,0,
		DEVICE_TYPE_BLOCK,
		driver_getdevicenrbyname("ram") );
 
	return 0;
}

//
int rd_init(void)
{
	return ramdisk_init();
}

//
int ramdisk_init(void)
{
	/* Idempotent initialization: do not register a second ram: device and do
	 * not recreate an existing image. */
	if(driver_getdevicebyname("ram")==NULL)
		rd_register_device();
	rd_createdefaultramdisk();
	return TRUE;
}

// rd_createimage
// imageptr, blocks, blocksize
void rd_createimage(RAMDISK_IMAGE *jim,
	DWORD blocks,DWORD blocksize)
{
	DWORD bytes;

	if(jim==NULL || blocks==0 || blocksize==0 ||
	   blocks > (0xFFFFFFFFUL/blocksize))
	{
		dprintk("rd_createimage: invalid geometry blocks=%u blocksize=%u.\n",
			(unsigned)blocks,(unsigned)blocksize);
		return;
	}
	bytes=blocks*blocksize;
	memset(jim,0,sizeof(RAMDISK_IMAGE));
	jim->blocks=blocks;
	jim->blocksize=blocksize;
	printk("ramdisk image creation: blocks=%d, blocksize=%d\n",(int)blocks,(int)blocksize);
	jim->buf=malloc(bytes);
	if(jim->buf==NULL || illegal(jim->buf))
	{
		dprintk("rd_createimage: allocation of %u bytes failed.\n",(unsigned)bytes);
		jim->buf=NULL;
		jim->blocks=0;
		jim->blocksize=0;
		return;
	}
	memset(jim->buf,0,bytes);
}

//
void rd_destroyimage(RAMDISK_IMAGE *jim)
{
	//
	if(jim->buf)
	{
		free( jim->buf );
	}
	else print("rd_destroyimage: null pointer reference detected");
}

// Multi-block RAM transfer: one memcpy for the complete extent.
int rd_readblocks(RAMDISK_IMAGE *im,int which,int count,unsigned char *buf)
{
    DWORD offs,bytes;
    if(im==NULL || buf==NULL || im->buf==NULL || which<0 || count<=0 ||
       im->blocksize==0 || (DWORD)which>=im->blocks ||
       (DWORD)count>im->blocks-(DWORD)which ||
       (DWORD)count>0xffffffffUL/im->blocksize)
        return 0;
    offs=(DWORD)which*im->blocksize;
    bytes=(DWORD)count*im->blocksize;
    memcpy(buf,im->buf+offs,bytes);
    return count;
}

int rd_writeblocks(RAMDISK_IMAGE *im,int which,int count,unsigned char *buf)
{
    DWORD offs,bytes;
    if(im==NULL || buf==NULL || im->buf==NULL || which<0 || count<=0 ||
       im->blocksize==0 || (DWORD)which>=im->blocks ||
       (DWORD)count>im->blocks-(DWORD)which ||
       (DWORD)count>0xffffffffUL/im->blocksize)
        return 0;
    offs=(DWORD)which*im->blocksize;
    bytes=(DWORD)count*im->blocksize;
    memcpy(im->buf+offs,buf,bytes);
    return count;
}

int rd_readblock(RAMDISK_IMAGE *im,int which,unsigned char *buf)
{
    return rd_readblocks(im,which,1,buf);
}

int rd_writeblock(RAMDISK_IMAGE *im,int which,unsigned char *buf)
{
    return rd_writeblocks(im,which,1,buf);
}

// Returns size of the ramdisk in blocks
int rd_getsize(RAMDISK_IMAGE *im)
{
	if(im==NULL || im->buf==NULL) return 0;
	return (int)im->blocks;
}

// Returns size of a single block unit(in bytes)
int rd_getblocksize(RAMDISK_IMAGE *im)
{
	//
	return im->blocksize;
}

