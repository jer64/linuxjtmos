// ================================================================
// REMOVABLE DEVICE SUPPORT
// DiskChange is called by various functions/programs.
// It ejects all cache, buffers on the specified drive.
// (C) 2002-2004,2017 by Jari Tuominen (jari.t.tuominen@gmail.com.
// ===============================================================
#include "basdef.h"
#include "sysmem.h"
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
#include "driver_api.h"
#include "driver_sys.h"
#include "driver_lock.h"
#include "driver_rw.h" // readblock...
#include "driver_diskchange.h"
#include "jtmfat.h" // jtmfat_chdev...

// Wrapper
void diskchange(int dnr)
{
	//
	diskchangednr(dnr);
}

// Wrapper
void DiskChange(int dnr)
{
	//
	diskchangednr(dnr);
}

// Called when the specified device had a disk change.
//
// PROCESS CONTEXT ONLY.
// jtmfat_chdev() flushes/reloads filesystem state and may perform block I/O;
// it is not IRQ-safe and must never be called from a hardware ISR.  Hardware
// drivers should only mark/invalidate their own low-level state in the ISR and
// use this function later from an explicit process-context refresh path.
void diskchangednr(int WHICH_DNR)
{
	jtmfat_chdev(WHICH_DNR);
}

