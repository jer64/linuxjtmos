/**************************************************************
 * RTC - JTMOS Real Time Clock Functions - Part of CMOS driver.
 * (C) 2002-2003 by Jari Tuominen(jari@vunet.org)
 */

//
#include "kernel32.h"
#include "rtc.h"

//
RTCSTR rtcstr;
static int last_known_seconds=0,tm=0,tm2=0;

// Wrapper which is easier to remember
int GetSeconds(void)
{
	//
	return rtc_getseconds();
}

//
int rtc_getseconds(void)
{
	static int flags,tick;
	static DATE d;

	// Decrease infinite loop preventer timer
	tm2--;
	//
	if( tm==0 || (GetTickCount()-tm)>=500 || tm2<=0 )
	{
		// Set values
		tm = GetTickCount();
		// Time-out to prevent infinite loops
		tm2 = 10000;

		// Receive new seconds count without leaking the caller IF state.
		flags=get_eflags();
		disable();
		rtc_getdate(&d);
		tick = d.hour*60*60 + d.minute*60 + d.second;
		set_eflags(flags);
		last_known_seconds = tick;
		return tick;
	}
	else
	{
		// Not enough time has passed, we return the old seconds.
		return last_known_seconds;
	}
}

//
int rtc_readreg(int which)
{
    return cmos_read(which);
}

//
void rtc_writereg(int which, int what)
{
    cmos_write(which,what);
}

//
int rtc_getsecond(void)
{
	//
	return rtc_readreg(0);
}

static int rtc_deadline_read_stable_second(int *second)
{
	int a,b;

	if(second==NULL) return FALSE;
	/* Do not count a value sampled while the RTC is updating its calendar. */
	if(rtc_readreg(0x0A)&0x80) return FALSE;
	a=rtc_getsecond();
	if(rtc_readreg(0x0A)&0x80) return FALSE;
	b=rtc_getsecond();
	if(a!=b) return FALSE;
	*second=b;
	return TRUE;
}

/*
 * Start/poll a deadline using the raw CMOS seconds byte.  Keeping the value
 * raw (normally packed BCD) is deliberate: for a deadline we only need to
 * know that the hardware seconds register changed.  0x59 -> 0x00 therefore
 * counts as exactly one transition, as desired.
 *
 * cmos_read() makes each 70h/71h selector/data transaction interrupt-atomic,
 * so callers may poll this from lock wait loops without relying on PIT ticks.
 */
void rtc_second_deadline_start(RTC_SECOND_DEADLINE *deadline)
{
	int second;

	if(deadline==NULL) return;
	if(!rtc_deadline_read_stable_second(&second))
		second=rtc_getsecond();
	deadline->last_raw_second=second;
	deadline->transitions=0;
}

int rtc_second_deadline_poll(RTC_SECOND_DEADLINE *deadline,
				     unsigned int transition_limit)
{
	int second;

	if(deadline==NULL || transition_limit==0) return TRUE;
	if(!rtc_deadline_read_stable_second(&second)) return FALSE;
	if(second!=deadline->last_raw_second)
	{
		deadline->last_raw_second=second;
		if(deadline->transitions<0xffffffffU)
			deadline->transitions++;
	}
	return deadline->transitions>=transition_limit ? TRUE : FALSE;
}

//
int rtc_getminute(void)
{
	//
	return rtc_readreg(2);
}

//
int rtc_gethour(void)
{
	//
	return rtc_readreg(4);
}

//
int rtc_getday(void)
{
	//
	return rtc_readreg(7);
}

//
int rtc_getmonth(void)
{
	//
	return rtc_readreg(6);
}

//
int rtc_getyear(void)
{
	//
	return rtc_readreg(9);
}

//
void rtc_busyWait(void)
{
	unsigned long loops;
	int flags;

	/* RTC update-in-progress normally clears in < 2 ms.  Keep this bounded so
	 * a broken/emulated CMOS cannot wedge the kernel forever. */
	flags = get_eflags();
	for(loops=0; loops<10000UL; loops++)
	{
		if(!(rtc_readreg(0xA)&0x80))
			return;

		if(Multitasking && !PitStorageSafeActive() && (flags & 0x200) &&
		   ((loops & 0x3FFUL)==0))
			SwitchToThread();
	}

	dprintk("rtc_busyWait: CMOS update-in-progress timeout.\n");
}

//
void rtc_getdate(DATE *d)
{
	static int flags;

	// Wait until time is available
	rtc_busyWait();

	//
	flags = get_eflags(); disable();

	// Receive
	d->second =	rtc_getsecond();
	d->minute =	rtc_getminute();
	d->hour =	rtc_gethour();
	d->day = 	rtc_getday();
	d->month =	rtc_getmonth();
	d->year =	rtc_getyear();
	// Convert
	BCD_TO_BIN(d->second);
	BCD_TO_BIN(d->minute);
	BCD_TO_BIN(d->hour);
	BCD_TO_BIN(d->day);
	BCD_TO_BIN(d->month);
	BCD_TO_BIN(d->year);
	//
	set_eflags(flags);
}


