#ifndef __INCLUDED_RTC_H__
#define __INCLUDED_RTC_H__

//
#include "kernel32.h"
#include "cmos.h" // TIME -structure

// Date/Time structure
typedef struct
{
        int second,minute,hour,
                day,month,year;
        int res[10];
}DATE;

// ??
typedef struct
{
	int offs;
	int a1,a2,a3,a4;
}RTCSTR;

/*
 * Coarse hardware deadline based directly on the PC/AT CMOS seconds
 * register.  This intentionally counts *second transitions* instead of
 * converting the RTC to milliseconds: storage lock recovery must keep
 * working while the normal scheduler/tick based timing path is suspect.
 *
 * rtc_second_deadline_poll() performs a fresh CMOS port probe on every call.
 */
typedef struct
{
	int last_raw_second;
	unsigned int transitions;
} RTC_SECOND_DEADLINE;

// Function prototypes
int rtc_init(void);
void rtc_getdate(DATE *d);
void rtc_busyWait(void);
int rtc_getseconds(void);
int GetSeconds(void);
void rtc_second_deadline_start(RTC_SECOND_DEADLINE *deadline);
int rtc_second_deadline_poll(RTC_SECOND_DEADLINE *deadline,
                             unsigned int transition_limit);

//
extern RTCSTR rtcstr;

// From Linux 1.0:
#ifndef BCD_TO_BIN
#define BCD_TO_BIN(val) ((val)=((val)&15) + ((val)>>4)*10)
#endif

#ifndef BIN_TO_BCD
#define BIN_TO_BCD(val) ((val)=(((val)/10)<<4) + (val)%10)
#endif

#endif
