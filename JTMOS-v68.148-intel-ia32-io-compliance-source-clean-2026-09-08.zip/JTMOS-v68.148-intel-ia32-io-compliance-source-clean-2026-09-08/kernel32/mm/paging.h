#ifndef __INCLUDED_PAGING_H__
#define __INCLUDED_PAGING_H__

#include "memory_layout.h"

// Physical locations occupied by JTMOS paging structures.
// These pages must never be returned by kmalloc().
/* V67.8.36 experimental kernel-at-1MiB layout.  The canonical memory-layout
 * constants themselves are relocated, so do not add a second offset here. */
#define PG_STRUCTURES_RELOCATION     0x00000000UL
#define PG_PAGE_DIRECTORY_PHYS       (JTMOS_KERNEL_PAGE_DIRECTORY_PHYS + PG_STRUCTURES_RELOCATION)
#define PG_PAGE_TABLE_PHYS           (JTMOS_KERNEL_PAGE_TABLE_PHYS + PG_STRUCTURES_RELOCATION)
#define PG_PAGE_TABLE_BYTES          JTMOS_KERNEL_PAGE_TABLE_BYTES
#define PG_USER_PAGE_TABLES_PHYS     (JTMOS_KERNEL_USER_PTES_PHYS + PG_STRUCTURES_RELOCATION)
#define PG_USER_PAGE_TABLES_BYTES    JTMOS_KERNEL_USER_PTES_BYTES
#define PG_STRUCTURES_PHYS_START     PG_PAGE_DIRECTORY_PHYS
#define PG_STRUCTURES_PHYS_END       (PG_USER_PAGE_TABLES_PHYS + PG_USER_PAGE_TABLES_BYTES)

/* The whole fixed paging area must remain directly addressable after CR0.PG
 * is enabled because JTMOS accesses page tables through their physical/linear
 * identity addresses.  With 250 thread slots, 4 MiB of per-process page-table
 * storage is required: 250 * 4096 PTEs * 4 bytes = 4,096,000 bytes. */
#define PG_IDENTITY_MAP_BYTES        PG_STRUCTURES_PHYS_END

/* Kernel kmalloc virtual mapping window.  Keep these as compile-time constants
 * rather than BSS state; FindEmptyArea() validates/reseeds only its cursor. */
#define PG_KERNEL_MAP_START          JTMOS_KERNEL_MAP_START
#define PG_KERNEL_MAP_END            JTMOS_KERNEL_MAP_END
#define PG_KERNEL_MAP_START_PAGE     (PG_KERNEL_MAP_START/PAGESIZE)
#define PG_KERNEL_MAP_END_PAGE       (PG_KERNEL_MAP_END/PAGESIZE)

void pg_init(void);
void SetPage1(DWORD *p, DWORD which, DWORD where);
void SetPage(DWORD which, DWORD where);
DWORD GenLinTable(DWORD *p, DWORD ad);
void Demonstrate(void);
void *GetKernelPageDirPTR(void);
void *GetKernelPageTablePTR(void);
void pg_enable(void);
DWORD GetPage1(DWORD *p, DWORD which);
DWORD GetPage(DWORD which);
void *_pg_alloc(int amount);
void *_pg_allocEx(int amount, DWORD mapad);
extern char paging_enabled;
void pg_unmapmemory(DWORD addy, int pages);
int pg_protectmemory(DWORD addy, int pages, int prot);
DWORD pg_mapmemory(int realpage, int pages);
DWORD pg_mapio(int realpage, int pages);
DWORD pg_mapmemory_at(int realpage, int pages, DWORD mapad);
void PageDump(DWORD spad, DWORD count);
void PageDumpNear(DWORD ad);
void *pg_QuickMap(DWORD phst, int length, DWORD mapad);
DWORD FindEmptyArea(int amount);
void pg_reserve_internal_pages(void);

extern DWORD lin_walk;
extern DWORD search_walk;

#endif
