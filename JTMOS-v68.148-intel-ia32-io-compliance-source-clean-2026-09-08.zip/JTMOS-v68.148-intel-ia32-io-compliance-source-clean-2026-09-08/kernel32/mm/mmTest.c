// mmTest.c
#include <stdio.h>
#include "mm.h"
#include "mmAlloc.h"
#include "mmTest.h"

// Enable or disable debug print messages.
//#define TPRINT printf
#define TPRINT(...) do { } while(0)

static void mmTestCheckPagingOverlap(void *ptr)
{
    MD *m;
    DWORD ps,pe;

    if(ptr == NULL)
        return;

    m = mmGiveMD(ptr);
    if(m == NULL)
        KERNEL_FATAL("mmTest: allocation has no descriptor");

    ps = (DWORD)m->p;
    pe = ps + (DWORD)m->pages * PAGESIZE;

    if(ps < PG_STRUCTURES_PHYS_END && pe > PG_STRUCTURES_PHYS_START)
        KERNEL_FATAL("mmTest: allocator returned a live paging-structure page");
}

void mmTest(void)
{
    int i,times,big_count;
    BYTE *tmp,*tmp2,*tmp3,*big[1000];

    printf("Testing MM 0.4.1\n");

    for(times=1; times<5; times++)
    {
        printf(".");
        memset(big, 0, sizeof(big));
        big_count = 0;

        TPRINT("---------------------------------------------\n");
        TPRINT("mm.n_allocated = %d\n", p_mm->n_allocated);
        TPRINT("Allocating big thing:\n");

        for(i=0; i<1000; i++)
        {
            big[i] = malloc(583);
            if(big[i] == NULL)
                break;
            mmTestCheckPagingOverlap(big[i]);
            big_count++;
        }

        tmp = malloc(1024*64);
        tmp3 = malloc(10);
        tmp2 = malloc(1024*64);
        mmTestCheckPagingOverlap(tmp);
        mmTestCheckPagingOverlap(tmp2);
        mmTestCheckPagingOverlap(tmp3);
        TPRINT("(1) tmp=0x%x, tmp2=0x%x\n", tmp, tmp2);
        free(tmp);
        free(tmp2);

        tmp = malloc(1024*128);
        tmp2 = malloc(1024*128);
        mmTestCheckPagingOverlap(tmp);
        mmTestCheckPagingOverlap(tmp2);
        TPRINT("(2) tmp=0x%x, tmp2=0x%x\n", tmp, tmp2);
        free(tmp);
        free(tmp2);

        tmp = malloc(1024*256);
        tmp2 = malloc(1024*256);
        mmTestCheckPagingOverlap(tmp);
        mmTestCheckPagingOverlap(tmp2);
        TPRINT("(3) tmp=0x%x, tmp2=0x%x\n", tmp, tmp2);
        free(tmp);
        free(tmp2);
        free(tmp3);

        TPRINT("Freeing big thing:\n");
        for(i=0; i<big_count; i++)
            free(big[i]);
    }

    printf(" MM test passed.\n");
}
