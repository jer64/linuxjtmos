/////////////////////////////////////////////////////////////////////////////////////////////////
//
// paging.c
// (C) 2004-2006 by Jari Tuominen.
// Fixed 2026: bounded virtual search, TLB invalidation, protected paging
//             structures, safe exact mappings and graceful address-space OOM.
//
/////////////////////////////////////////////////////////////////////////////////////////////////
#include "kernel32.h"
#include "mm.h"
#include "mmAlloc.h"
#include "paging.h"
#include "sys/mman.h"

static DWORD *page_directory;
static DWORD *physical_page_directory;
static DWORD *page_table;
static DWORD *user_page_tables;

char paging_enabled = FALSE;
DWORD lin_walk;
DWORD search_walk;


/*
 * Clear boot paging memory in bounded chunks.  Besides avoiding one opaque
 * multi-megabyte libc call, this makes the serial log show the exact physical
 * boundary reached if a machine has a real addressability problem.
 */
static void pg_boot_clear(const char *name, DWORD base, DWORD bytes)
{
    DWORD off;
    DWORD chunk;

    if((base & (PAGESIZE-1)) != 0)
        KERNEL_FATAL("pg_boot_clear: base is not page aligned");
    if((bytes & 3) != 0)
        KERNEL_FATAL("pg_boot_clear: byte count is not dword aligned");

    for(off=0; off<bytes; off+=chunk)
    {
        chunk = bytes-off;
        if(chunk > 0x00040000UL)
            chunk = 0x00040000UL;       /* 256 KiB */

        memset((void *)(base+off), 0, chunk);

        /* One line per MiB keeps COM1 useful without flooding it. */
        if((((off+chunk) & 0x000fffffUL) == 0) || off+chunk == bytes)
            printk("  %s: cleared through 0x%x\n", name, base+off+chunk);
    }
}

static DWORD pg_pages_for_bytes(DWORD bytes)
{
    if(bytes == 0)
        return 0;
    return (bytes / PAGESIZE) + ((bytes % PAGESIZE) ? 1 : 0);
}

static void pg_invalidate_page(DWORD which)
{
#if defined(__i386__) && !defined(LIBCVERSION)
    void *linear;

    if(!paging_enabled)
        return;

    linear = (void *)(which * (DWORD)PAGESIZE);
    asm volatile("invlpg (%0)" : : "r" (linear) : "memory");
#else
    (void)which;
#endif
}

static int pg_virtual_range_is_free(DWORD first_page, DWORD pages)
{
    DWORD i;

    if(pages == 0)
        return 0;
    if(first_page >= MM_BITMAP_PAGES)
        return 0;
    if(pages > MM_BITMAP_PAGES - first_page)
        return 0;

    for(i=0; i<pages; i++)
    {
        if(GetPage(first_page+i) & 1)
            return 0;
    }
    return 1;
}

DWORD pg_mapmemory_at(int realpage, int pages, DWORD mapad)
{
    DWORD dpa,rad;
    int i;

    if(realpage <= 0 || pages <= 0 || mapad == 0)
        return 0;
    if(mapad & (PAGESIZE-1))
        return 0;
    if((DWORD)realpage >= MM_BITMAP_PAGES)
        return 0;
    if((DWORD)pages > MM_BITMAP_PAGES - (DWORD)realpage)
        return 0;

    dpa = mapad / PAGESIZE;
    if(!pg_virtual_range_is_free(dpa, (DWORD)pages))
        return 0;

    rad = (DWORD)realpage * PAGESIZE;
    for(i=0; i<pages; i++,rad+=PAGESIZE)
    {
        DWORD expected = rad | 3;
        SetPage(dpa+(DWORD)i, expected);
        if(GetPage(dpa+(DWORD)i) != expected)
        {
            /* A PTE write that does not stick means the paging structures are
             * not where the kernel thinks they are.  Roll back the entries
             * already installed instead of returning a poisoned mapping. */
            int j;
            for(j=0; j<=i; j++)
                SetPage(dpa+(DWORD)j, 2);
            return 0;
        }
    }

    return mapad;
}

/* Map PCI/MMIO physical pages into the kernel with page-level cache
 * disable/write-through attributes.  Normal RAM mappings deliberately keep
 * using pg_mapmemory(); device register windows must not be cached. */
DWORD pg_mapio(int realpage, int pages)
{
    /* IA-32 legacy PTE memory-type encoding with the reset/default PAT:
     * PCD=1,PWT=1 selects UC.  Device register windows must never use the
     * normal WB pg_mapmemory() path. */
    const DWORD io_pte_flags = 0x1bUL; /* P | RW | PWT | PCD */
    DWORD mapad=0,dpa=0,rad,flags;
    int i;

    if(realpage <= 0 || pages <= 0)
        return 0;
    if((DWORD)realpage >= MM_BITMAP_PAGES)
        return 0;
    if((DWORD)pages > MM_BITMAP_PAGES - (DWORD)realpage)
        return 0;

    /* Keep virtual-range discovery and PTE publication one MM transaction.
     * Otherwise a concurrent kmalloc/MMIO mapper could choose the same kernel
     * virtual window between FindEmptyArea() and SetPage(). */
    flags=mmCriticalEnter();
    mapad = FindEmptyArea(pages);
    if(!mapad)
        goto out;
    dpa = mapad / PAGESIZE;
    if(!pg_virtual_range_is_free(dpa,(DWORD)pages)) {
        mapad=0;
        goto out;
    }

    rad = (DWORD)realpage * PAGESIZE;
    for(i=0; i<pages; i++,rad+=PAGESIZE)
    {
        DWORD expected = rad | io_pte_flags;
        SetPage(dpa+(DWORD)i, expected);
        if(GetPage(dpa+(DWORD)i) != expected)
        {
            int j;
            for(j=0; j<=i; j++)
                SetPage(dpa+(DWORD)j, 2);
            mapad=0;
            goto out;
        }
    }
out:
    mmCriticalLeave(flags);
    return mapad;
}

DWORD pg_mapmemory(int realpage, int pages)
{
    DWORD mapad;

    if(realpage <= 0 || pages <= 0)
        return 0;

    mapad = FindEmptyArea(pages);
    if(!mapad)
        return 0;

    // FindEmptyArea() found this range free; pg_mapmemory_at() performs
    // the final bounds check and installs the PTEs.
    return pg_mapmemory_at(realpage, pages, mapad);
}

void pg_unmapmemory(DWORD addy, int pages)
{
    int i;
    DWORD dpa;

    if(addy == 0 || pages <= 0)
        return;
    if(addy & (PAGESIZE-1))
        return;

    dpa = addy / PAGESIZE;
    if(dpa >= MM_BITMAP_PAGES)
        return;
    if((DWORD)pages > MM_BITMAP_PAGES - dpa)
        pages = (int)(MM_BITMAP_PAGES - dpa);

    for(i=0; i<pages; i++)
        SetPage(dpa+(DWORD)i, 2); // RW, non-present
}


int pg_protectmemory(DWORD addy, int pages, int prot)
{
    DWORD dpa;
    DWORD pte;
    DWORD flags;
    int i;

    if(addy == 0 || pages <= 0 || (addy & (PAGESIZE-1)))
        return -1;
    if(prot & ~(PROT_READ | PROT_WRITE | PROT_EXEC))
        return -1;

    dpa = addy / PAGESIZE;
    if(dpa >= MM_BITMAP_PAGES || (DWORD)pages > MM_BITMAP_PAGES - dpa)
        return -1;

    flags = 0;
    if(prot != PROT_NONE)
    {
        flags |= 1;             // present
        if(prot & PROT_WRITE)
            flags |= 2;         // writable
    }

    for(i=0; i<pages; i++)
    {
        pte = GetPage(dpa+(DWORD)i);
        if((pte & 0xfffff000UL) == 0)
            return -1;

        // Preserve physical address and IA-32 metadata bits except P/RW.
        pte = (pte & ~3UL) | flags;
        SetPage(dpa+(DWORD)i, pte);
    }

    return 0;
}

DWORD FindEmptyArea(int amount)
{
    DWORD ad,cnt,scanned,span,cursor;

    if(amount <= 0 || page_table == NULL)
        return 0;

    span = PG_KERNEL_MAP_END_PAGE - PG_KERNEL_MAP_START_PAGE;
    if(span == 0 || (DWORD)amount > span)
        return 0;

    /* search_walk is deliberately only a hint.  A stale/zero BSS value must
     * never make the whole heap appear exhausted. */
    if(search_walk < PG_KERNEL_MAP_START_PAGE ||
       search_walk >= PG_KERNEL_MAP_END_PAGE)
        search_walk = PG_KERNEL_MAP_START_PAGE;

    cursor = search_walk;
    cnt = 0;
    ad = 0;
    for(scanned=0; scanned<span; scanned++)
    {
        if(cursor >= PG_KERNEL_MAP_END_PAGE)
        {
            cursor = PG_KERNEL_MAP_START_PAGE;
            cnt = 0;
            ad = 0;
        }

        if(!(GetPage(cursor) & 1))
        {
            if(!cnt)
                ad = cursor * PAGESIZE;
            cnt++;
            if(cnt >= (DWORD)amount)
            {
                cursor++;
                if(cursor >= PG_KERNEL_MAP_END_PAGE)
                    cursor = PG_KERNEL_MAP_START_PAGE;
                search_walk = cursor;
                return ad;
            }
        }
        else
        {
            ad = 0;
            cnt = 0;
        }
        cursor++;
    }

    /* Preserve a valid cursor even after genuine address-space exhaustion. */
    search_walk = cursor >= PG_KERNEL_MAP_END_PAGE ?
        PG_KERNEL_MAP_START_PAGE : cursor;
    return 0;
}

void *_pg_alloc(int amount)
{
    if(amount <= 0)
        return NULL;

    // procmalloc() already allocates physical pages and maps them into the
    // allocator's virtual window. PID 0 keeps the historical kernel/permanent
    // ownership policy used by the old pg allocator.
    return procmalloc((DWORD)amount, 0, __FUNCTION__);
}

void *_pg_allocEx(int amount, DWORD mapad)
{
    if(amount <= 0 || mapad == 0 || (mapad & (PAGESIZE-1)))
        return NULL;

    // Allocate physical pages directly at the requested virtual address.
    // This avoids the old temporary-map/copy/unmap sequence, which could
    // accidentally choose the requested target as its temporary mapping.
    return _kmalloc_at(amount, 0, __FUNCTION__, mapad);
}

void *GetKernelPageDirPTR(void)
{
    return page_directory;
}

void *GetKernelPageTablePTR(void)
{
    return page_table;
}

void Demonstrate(void)
{
    int i,l,x;
    BYTE *p;

    for(x=0,p = (BYTE *)0xB8000; ; x++)
    {
        l = 80*25*2;
        for(i=0; i<l; i++)
            p[i] += i+x;
    }
}

DWORD GenLinTable(DWORD *p, DWORD ad)
{
    int i;

    for(i=0; i<1024; i++,ad+=PAGESIZE)
        p[i] = ad | 3;
    return ad;
}

DWORD GetPage(DWORD which)
{
    return GetPage1(page_table, which);
}

DWORD GetPage1(DWORD *p, DWORD which)
{
    if(p==NULL || which>=MM_BITMAP_PAGES)
    {
        dprintk("GetPage1: invalid page index %u rejected.\n",(unsigned)which);
        return 0;
    }
    return p[which];
}

void SetPage(DWORD which, DWORD where)
{
    SetPage1(page_table, which, where);
}

void SetPage1(DWORD *p, DWORD which, DWORD where)
{
    if(p==NULL || which>=MM_BITMAP_PAGES)
    {
        dprintk("SetPage1: invalid page index %u rejected.\n",(unsigned)which);
        return;
    }

    p[which]=where;

    // PTE changes made after paging is enabled must invalidate stale TLB
    // translations. Without this, kfree()+kmalloc() can keep using an old
    // physical page even though the page table has already changed.
    if(p == page_table)
        pg_invalidate_page(which);
}

void pg_enable(void)
{
    SETCR0(GETCR0() | 0x80000000);
}

void *pg_QuickMap(DWORD phst, int length, DWORD mapad)
{
    DWORD ad,i,i2,l,first;

    if(length <= 0 || mapad == 0)
        return NULL;
    if((phst & (PAGESIZE-1)) || (mapad & (PAGESIZE-1)))
        return NULL;

    l = pg_pages_for_bytes((DWORD)length);
    if(l == 0)
        return NULL;

    first = mapad / PAGESIZE;
    if(first >= MM_BITMAP_PAGES || l > MM_BITMAP_PAGES-first)
        return NULL;
    if((phst / PAGESIZE) >= MM_BITMAP_PAGES ||
       l > MM_BITMAP_PAGES-(phst/PAGESIZE))
        return NULL;

    for(i=first,i2=0,ad=phst; i2<l; i2++,ad+=PAGESIZE)
        SetPage(i+i2, ad|3);

    return (void *)mapad;
}

// Reserve the physical pages occupied by the live paging structures.
// mmInit() calls this after it marks the general RAM region free.
void pg_reserve_internal_pages(void)
{
    mmReserveRegionAD((char *)PG_STRUCTURES_PHYS_START,
        (char *)PG_STRUCTURES_PHYS_END);
}

void pg_init(void)
{
    DWORD i,i2,l;
    DWORD *p,ad,ad2;
    DWORD fb_start,fb_bytes,fb_offset;

    printk("Paging initializing:\n");
    printk("- CR0 before paging = 0x%x\n", GETCR0());

    /* Intel 32-bit paging requires CR3/page-directory and each page table to
     * start on a 4 KiB boundary.  Fail before touching memory if the fixed
     * JTMOS layout is accidentally changed. */
    if((PG_PAGE_DIRECTORY_PHYS & (PAGESIZE-1)) ||
       (PG_PAGE_TABLE_PHYS & (PAGESIZE-1)) ||
       (PG_USER_PAGE_TABLES_PHYS & (PAGESIZE-1)))
        KERNEL_FATAL("paging: paging structures are not 4K aligned");
    if(GETCR0() & 0x80000000UL)
        KERNEL_FATAL("paging: CR0.PG was already set before pg_init");

    paging_enabled = FALSE;
    search_walk = PG_KERNEL_MAP_START_PAGE;

    page_directory = (DWORD *)PG_PAGE_DIRECTORY_PHYS;
    page_table = (DWORD *)PG_PAGE_TABLE_PHYS;
    user_page_tables = (DWORD *)PG_USER_PAGE_TABLES_PHYS;
    physical_page_directory = NULL;

    printk("- Page tables: flat PTE array 0x%x..0x%x\n",
        PG_PAGE_TABLE_PHYS, PG_PAGE_TABLE_PHYS+PG_PAGE_TABLE_BYTES);
    pg_boot_clear("kernel PTE", PG_PAGE_TABLE_PHYS, PG_PAGE_TABLE_BYTES);

    printk("- User page-table reserve 0x%x..0x%x\n",
        PG_USER_PAGE_TABLES_PHYS,
        PG_USER_PAGE_TABLES_PHYS+PG_USER_PAGE_TABLES_BYTES);
    pg_boot_clear("user PT", PG_USER_PAGE_TABLES_PHYS,
        PG_USER_PAGE_TABLES_BYTES);

    /* The flat PTE array is already zero.  Map only what must survive the
     * CR0.PG transition. */
    printk("- identity mapping fixed low memory through 0x%x ... ",
        PG_IDENTITY_MAP_BYTES);
    l = PG_IDENTITY_MAP_BYTES/PAGESIZE;
    for(i=0,ad=0; i<l; i++,ad+=PAGESIZE)
        page_table[i] = ad | 3;
    printk("OK\n");

    /* VBE PhysBasePtr is a physical address.  The loader filled the mode
     * information block while BIOS services were still available; VesaProbe()
     * records it before pg_init().  Identity-map exactly the scanline-backed
     * framebuffer range before paging is switched on. */
    if(vesa_frame_buf!=NULL && vesa_frame_buf_bytes!=0)
    {
        ad2 = (DWORD)vesa_frame_buf;
        fb_start = ad2 & ~(PAGESIZE-1);
        fb_offset = ad2-fb_start;
        if(vesa_frame_buf_bytes > 0xffffffffUL-fb_offset)
        {
            printk("paging: invalid VESA framebuffer length; disabling LFB.\n");
            vesa_frame_buf=NULL;
            vesa_frame_buf_bytes=0;
        }
        else
        {
            fb_bytes=vesa_frame_buf_bytes+fb_offset;
            l=pg_pages_for_bytes(fb_bytes);
            if((fb_start/PAGESIZE)>=MM_BITMAP_PAGES ||
               l>MM_BITMAP_PAGES-(fb_start/PAGESIZE))
            {
                printk("paging: VESA framebuffer outside IA-32 map; disabling LFB.\n");
                vesa_frame_buf=NULL;
                vesa_frame_buf_bytes=0;
            }
            else
            {
                printk("- identity mapping VESA LFB 0x%x, %d pages ... ",fb_start,l);
                for(i=fb_start/PAGESIZE,ad=fb_start,i2=0;i2<l;i++,i2++,ad+=PAGESIZE)
                    page_table[i]=ad|3;
                printk("OK\n");
            }
        }
    }

    /* Null pointer protection. */
    page_table[0] = 2;

    printk("- Page directory @0x%x ... ", PG_PAGE_DIRECTORY_PHYS);
    p = page_directory;
    for(i=0,ad=(DWORD)page_table; i<1024; i++,ad+=PAGESIZE)
        p[i] = ad | 3;
    printk("OK\n");

    /* Keep the first 8 MiB accessible through the historical 0x10000000
     * alias used by JTMOS. */
    l = 1024*1024*8/PAGESIZE;
    i2 = 0x10000000/PAGESIZE;
    for(i=0,ad=0; i<l; i++,ad+=PAGESIZE)
        page_table[i+i2] = ad | 3;

    physical_page_directory = page_directory;

    printk("- Loading CR3=0x%x ... ", physical_page_directory);
    SETCR3(JTM_PTR_TO_DWORD(physical_page_directory));
    printk("OK\n");
    printk("- Setting CR0.PG ... ");
    pg_enable();
    paging_enabled = TRUE;
    printk("OK\n");

    printk("Done (CR0 = 0x%x).\n", GETCR0());
    printk("page_directory = 0x%x\n", page_directory);
    printk("page_table =     0x%x\n", page_table);
    printk("kernel map window = 0x%x..0x%x, first PTE=0x%x\n",
        PG_KERNEL_MAP_START, PG_KERNEL_MAP_END,
        GetPage(PG_KERNEL_MAP_START_PAGE));

    ad = (DWORD)p_mm;
    printk("p_mm =      0x%x\n", ad);
    printk("p_mm page = 0x%x\n", GetPage(ad/PAGESIZE));
}

void PageDump(DWORD spad, DWORD count)
{
    DWORD i,pad;

    printk("PDD@%x: ", spad);
    for(i=0,pad=spad; i<count; i++,pad++)
        printk("%x, ", GetPage(pad));
    printk("\n");
}

void PageDumpNear(DWORD ad)
{
    DWORD pad;

    pad = ad/PAGESIZE;
    PageDump(pad,20);
}
