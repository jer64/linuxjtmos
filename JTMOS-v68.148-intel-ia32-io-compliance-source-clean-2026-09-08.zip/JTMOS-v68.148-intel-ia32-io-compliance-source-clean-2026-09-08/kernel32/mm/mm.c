// ================================================================
// Enhanced memory management system 0.4.1.
// for JTMOS Operating System.
//
// (C) 2002-2006 by Jari Tuominen.
// Reliability fixes 2026.
// ================================================================
#include <stdio.h>
#include "mm.h"
#include "mmAlloc.h"
#include "mmTest.h"

void *aldb;
char *MSTART,*phMSTART;
char *MEND,*phMEND;
char *REND,*phREND;
MM mm;
MM *p_mm = NULL;
int mallocOK = FALSE;
int mm_debug = FALSE;
static DWORD mm_total_allocatable_bytes;

DWORD malloc_getmemorytotal(void)
{
    return mm_total_allocatable_bytes;
}

void mm_get_memory_stats(MM_MEMORY_STATS *stats)
{
    DWORD flags,free_bytes;
    int i,active;

    if(stats == NULL)
        return;

    flags = mmCriticalEnter();
    free_bytes = malloc_getmemoryfree();
    active = 0;
    if(p_mm != NULL && p_mm->allocated != NULL)
        for(i=0; i<p_mm->n_allocated; i++)
            if(p_mm->allocated[i] != NULL && !p_mm->allocated[i]->isFree)
                active++;

    stats->total_bytes = mm_total_allocatable_bytes;
    stats->free_bytes = free_bytes;
    stats->allocated_bytes = stats->total_bytes >= free_bytes ?
        stats->total_bytes - free_bytes : 0;
    stats->descriptors_active = active;
    stats->descriptors_highwater = p_mm != NULL ? p_mm->n_allocated : 0;
    stats->descriptors_capacity = p_mm != NULL ? p_mm->max_allocated : 0;
    mmCriticalLeave(flags);
}

DWORD mmCriticalEnter(void)
{
    DWORD flags;

    flags = (DWORD)get_eflags();
    disable();
    return flags;
}

void mmCriticalLeave(DWORD flags)
{
    set_eflags((int)flags);
}

static DWORD mm_align_up(DWORD v, DWORD a)
{
    if(a == 0)
        return v;
    return (v + a - 1) & ~(a - 1);
}

static DWORD mm_align_down(DWORD v, DWORD a)
{
    if(a == 0)
        return v;
    return v & ~(a - 1);
}

static DWORD mm_database_size_for_region(DWORD usable_start, DWORD usable_end)
{
    DWORD pages,per_slot,need;

    if(usable_end<=usable_start)
        return 0;

    pages=(usable_end-usable_start)/PAGESIZE;
    per_slot=(DWORD)sizeof(MD *)+(DWORD)sizeof(MD);
    if(per_slot==0 || pages>(0xffffffffUL-MM_BITMAP_BYTES-PAGESIZE)/per_slot)
        return 0;

    /* Reserve enough pointer+descriptor slots for the pathological case where
     * every managed physical page is represented by its own allocation.  Add
     * one page of layout/alignment slack, then round to a page boundary. */
    need=MM_BITMAP_BYTES+pages*per_slot+PAGESIZE;
    need=mm_align_up(need,PAGESIZE);
    if(need<ALLOCATION_DATABASE_MIN_SIZE)
        need=ALLOCATION_DATABASE_MIN_SIZE;
    return need;
}

static DWORD mm_overlap_pages(DWORD a0, DWORD a1, DWORD b0, DWORD b1)
{
    DWORD s,e;

    s = a0 > b0 ? a0 : b0;
    e = a1 < b1 ? a1 : b1;
    if(e <= s)
        return 0;

    /* All MM layout boundaries reaching this helper are page aligned. */
    return (e - s) / PAGESIZE;
}

void MMPANIC(const char *msg)
{
    printf("\n");
    printf("last function which called 'malloc' = '%s'\n", malloc_caller);
    printf("last function which called 'free' =   '%s'\n", free_caller);
    printf("%s: '%s'\n", __FUNCTION__, msg ? msg : "(null)");
    printf("%s: %u bytes free\n",
        __FUNCTION__, (unsigned int)malloc_getmemoryfree());
    printf("%s: descriptor high-water = %d\n",
        __FUNCTION__, mm.n_allocated);
    printf("%s: descriptor maximum = %d\n",
        __FUNCTION__, mm.max_allocated);
    KERNEL_FATAL("MMPANIC (description printed above)");
}

void mm_Diagnostics(void)
{
    printf("%s: phMSTART=0x%x, phMEND=0x%x, phREND=0x%x\n",
        __FUNCTION__, phMSTART, phMEND, phREND);
    printf("%s: DB map MSTART=0x%x, MEND=0x%x, REND=0x%x\n",
        __FUNCTION__, MSTART, MEND, REND);
    printf("%s: mm.allocated=0x%x(max=%d), mm.bitmap=0x%x(len=%d)\n",
        __FUNCTION__, mm.allocated, mm.max_allocated,
        mm.bitmap, mm.l_bitmap);
    printf("%s: paging physical reserve=0x%x..0x%x\n",
        __FUNCTION__, PG_STRUCTURES_PHYS_START, PG_STRUCTURES_PHYS_END);
}

void ShowPageMap(void)
{
    DWORD i,ad,mask=0;

    printk("%s\n", __FUNCTION__);
    for(i=0,ad=0; i<1024; i++,ad+=PAGESIZE)
    {
        if((i&255)==0)
            mask=0;
        mask |= GetPage(i);
        if((i&255)==255)
            printk("%x: mask=%x\n", ad/(1024*1024), mask);
    }
}

// Initialize the JTMOS physical-page allocator and allocation database.
// 'region' and 'length' describe the physical RAM range offered to MM.
void mmInit(void *region, int length)
{
    DWORD i;
    DWORD raw_start,raw_end,usable_start,usable_end,db_phys,db_bytes;
    DWORD db_start,db_end,bitmap_start,descriptor_start;
    DWORD db_without_bitmap,max_guess,max_by_ptr,max_by_desc;
    DWORD ptr_bytes,align;
    DWORD expected_free_pages,actual_free_pages,reserved_overlap_pages;
    char *p;

    mallocOK = FALSE;
    mm_debug = FALSE;
    mm_total_allocatable_bytes = 0;

    if(region == NULL || length <= 0)
        KERNEL_FATAL("mmInit: invalid RAM region");

    raw_start = (DWORD)region;
    if((DWORD)length > 0xffffffffU - raw_start)
        KERNEL_FATAL("mmInit: RAM region wraps address space");
    raw_end = raw_start + (DWORD)length;

    usable_start = mm_align_up(raw_start, PAGESIZE);
    usable_end = mm_align_down(raw_end, PAGESIZE);

    if(usable_end <= usable_start)
        KERNEL_FATAL("mmInit: empty page-aligned RAM region");
    if(usable_end < PG_STRUCTURES_PHYS_END)
        KERNEL_FATAL("mmInit: RAM does not cover fixed paging structures");

    db_bytes=mm_database_size_for_region(usable_start,usable_end);
    if(db_bytes==0 || (db_bytes & (PAGESIZE-1)) != 0)
        KERNEL_FATAL("mmInit: invalid dynamic allocation database size");
    if(db_bytes>0xffffffffUL-MAPAD_MM_DB)
        KERNEL_FATAL("mmInit: allocation database exceeds virtual mapping window");
    if((usable_end-usable_start)<=db_bytes+PAGESIZE)
        KERNEL_FATAL("mmInit: RAM region too small for MM database");

    db_phys=usable_end-db_bytes;
    if(db_phys <= usable_start)
        KERNEL_FATAL("mmInit: MM database overlaps allocatable RAM start");
    if(db_phys < PG_STRUCTURES_PHYS_END &&
       usable_end > PG_STRUCTURES_PHYS_START)
        KERNEL_FATAL("mmInit: MM database overlaps paging structures");

    phMSTART = (char *)usable_start;
    phMEND = (char *)db_phys;
    phREND = (char *)usable_end;

    memset(&mm, 0, sizeof(MM));
    p_mm = &mm;

    // Paging structures have fixed physical locations and must exist before
    // the high virtual MM database mapping is installed.
    printk("MM physical layout: dynamic=0x%x..0x%x, DB=0x%x..0x%x (%dK)\n",
        usable_start, db_phys, db_phys, usable_end, (int)(db_bytes/1024UL));
    printk("MM fixed paging reserve: 0x%x..0x%x\n",
        PG_STRUCTURES_PHYS_START, PG_STRUCTURES_PHYS_END);
    printk("p_mm=0x%x\nESP = 0x%x\n", p_mm, GETESP());
    pg_init();

    /* V67.8.31: keep the MM database at an identity-mapped linear address.
     *
     * The old code mapped the physical database near the top of RAM through
     * a second alias at 0xF2000000.  That alias was the only memory path that
     * could explain a successful descriptor-table setup followed by bitmap
     * writes which read back as 0xFF.  Nothing outside mm/ depends on the
     * legacy alias, so remove that extra translation from the allocator's
     * bootstrap path.  The database remains outside the allocatable arena. */
    MSTART = phMEND;
    printk("MM DB identity map: phys=%x, length=%x, linear=%x\n",
        phMEND, db_bytes, MSTART);
    if(pg_QuickMap((DWORD)phMEND, (int)db_bytes,
        (DWORD)MSTART) == NULL)
        KERNEL_FATAL("mmInit: cannot identity-map allocation database");

    /* Verify both ends of the mapping before trusting any descriptor or
     * bitmap state.  In particular the last word lives in the physical page
     * which will contain the tail of the bitmap. */
    {
        DWORD first_db_page,last_db_page;
        volatile DWORD *db_first,*db_last;

        first_db_page = (DWORD)MSTART / PAGESIZE;
        last_db_page = ((DWORD)MSTART + db_bytes - 1) / PAGESIZE;
        if((GetPage(first_db_page) & ~(PAGESIZE-1UL)) != (DWORD)phMEND)
            KERNEL_FATAL("mmInit: first MM DB PTE does not match physical backing");
        if((GetPage(last_db_page) & ~(PAGESIZE-1UL)) !=
           ((DWORD)phMEND + (last_db_page-first_db_page)*PAGESIZE))
            KERNEL_FATAL("mmInit: last MM DB PTE does not match physical backing");

        db_first = (volatile DWORD *)MSTART;
        db_last = (volatile DWORD *)((DWORD)MSTART + db_bytes - sizeof(DWORD));
        db_first[0] = 0x4A544442UL; /* 'JTDB' */
        db_last[0] = 0x4244544AUL;  /* 'BDTJ' */
        if(db_first[0] != 0x4A544442UL || db_last[0] != 0x4244544AUL)
            KERNEL_FATAL("mmInit: MM DB physical backing is not writable");
        printk("MM DB mapping verified: firstPTE=0x%x lastPTE=0x%x.\n",
            GetPage(first_db_page), GetPage(last_db_page));
    }

    // Legacy names: the MM database begins at MEND/MSTART and ends at REND.
    MEND = MSTART;
    REND = MSTART + db_bytes;
    aldb = MEND;

    memset(MEND, 0, db_bytes);

    // Robust database layout:
    //   [ MD* pointer table ][ aligned MD descriptors ][ free-page bitmap ]
    // The bitmap has a fixed size (128 KB for the full 4 GB / 4 KB map).
    db_start = (DWORD)MEND;
    db_end = (DWORD)REND;
    bitmap_start = db_end - MM_BITMAP_BYTES;
    db_without_bitmap = bitmap_start - db_start;

    align = sizeof(DWORD);
    max_guess = db_without_bitmap / (sizeof(MD *) + sizeof(MD));
    if(max_guess == 0)
        KERNEL_FATAL("mmInit: allocation database cannot hold descriptors");

    // Reduce until pointer and descriptor areas fit after alignment.
    for(;;)
    {
        ptr_bytes = max_guess * sizeof(MD *);
        descriptor_start = mm_align_up(db_start + ptr_bytes, align);

        if(descriptor_start <= bitmap_start)
        {
            max_by_ptr = (descriptor_start - db_start) / sizeof(MD *);
            max_by_desc = (bitmap_start - descriptor_start) / sizeof(MD);
            if(max_guess <= max_by_ptr && max_guess <= max_by_desc)
                break;
        }

        if(max_guess == 0)
            KERNEL_FATAL("mmInit: allocation DB layout failed");
        max_guess--;
    }

    mm.max_allocated = (int)max_guess;
    mm.n_allocated = 0;
    mm.allocated = (MD **)MEND;
    mm.bitmap = (BYTE *)bitmap_start;
    mm.l_bitmap = MM_BITMAP_BYTES;

    for(i=0,p=(char *)descriptor_start; i<(DWORD)mm.max_allocated;
        i++,p+=sizeof(MD))
    {
        mm.allocated[i] = (MD *)p;
        memset(mm.allocated[i], 0, sizeof(MD));
        mm.allocated[i]->isFree = 1;
        mm.allocated[i]->PID = -1;
    }

    /* V67.8.33: construct the initial physical bitmap directly and keep one
     * authoritative MM state. Earlier releases initialized it to 0xFF and
     * then called mmBitRemove() once for every free page. On the failing boot
     * the accounting counter advanced
     * but the bitmap bytes remained 0xFF.  Bootstrap is now an independent,
     * volatile byte-level operation; normal mmBit* mutations are used only
     * after this invariant has been proven. */
    mmBitResetAccounting();
    mmBitConfigurePhysicalRange(usable_start / PAGESIZE, db_phys / PAGESIZE);
    if(p_mm != &mm)
        KERNEL_FATAL("mmInit: p_mm no longer points to authoritative MM state");
    if(p_mm->bitmap != mm.bitmap || p_mm->l_bitmap != mm.l_bitmap)
        KERNEL_FATAL("mmInit: MM bitmap metadata has diverged");
    if(mmBitmapBootstrapRange(usable_start / PAGESIZE, db_phys / PAGESIZE) != 0)
        KERNEL_FATAL("mmInit: cannot construct physical allocation bitmap");

    /* The current arena begins exactly at PG_STRUCTURES_PHYS_END, so the
     * paging reserve is normally outside it.  Retain the generic overlap
     * reservation for layouts where those ranges do intersect. */
    if(mm_overlap_pages(usable_start, db_phys,
        PG_STRUCTURES_PHYS_START, PG_STRUCTURES_PHYS_END) != 0)
        pg_reserve_internal_pages();

    /* Cross-check the bitmap against the physical layout before the first
     * allocation is allowed.  This catches exactly the class of bugs where
     * a paging/DB page accidentally becomes allocatable. */
    expected_free_pages = (db_phys - usable_start) / PAGESIZE;
    reserved_overlap_pages = mm_overlap_pages(usable_start, db_phys,
        PG_STRUCTURES_PHYS_START, PG_STRUCTURES_PHYS_END);
    if(reserved_overlap_pages > expected_free_pages)
        KERNEL_FATAL("mmInit: paging overlap exceeds allocatable region");
    expected_free_pages -= reserved_overlap_pages;
    mm_total_allocatable_bytes = expected_free_pages * (DWORD)PAGESIZE;
    /* Recount from the bitmap bytes themselves.  Do not trust mutation
     * accounting at boot: the searcher and the free counter must prove they
     * see exactly the same bitmap state. */
    actual_free_pages = mmBitRecountFreePages();
    printk("MM bitmap bootstrap: ptr=0x%x firstByte=0x%x midByte=0x%x lastByte=0x%x firstPage=%u endPage=%u recount=%u.\n",
        mm.bitmap,
        (unsigned int)mm.bitmap[(usable_start/PAGESIZE) >> 3],
        (unsigned int)mm.bitmap[(((usable_start/PAGESIZE)+(db_phys/PAGESIZE))/2) >> 3],
        (unsigned int)mm.bitmap[((db_phys/PAGESIZE)-1) >> 3],
        usable_start/PAGESIZE, db_phys/PAGESIZE, actual_free_pages);
    if(actual_free_pages != expected_free_pages)
    {
        printk("mmInit: bitmap mismatch expected=%u pages actual=%u pages\n",
            expected_free_pages, actual_free_pages);
        KERNEL_FATAL("mmInit: physical allocation bitmap does not match layout");
    }
    printk("MM bitmap verified: %u allocatable pages (%u bytes), first=%u last=%u.\n",
        actual_free_pages, actual_free_pages * (DWORD)PAGESIZE,
        usable_start / PAGESIZE, (db_phys / PAGESIZE) - 1);

    if(mmBitGet(usable_start / PAGESIZE) != 0)
        KERNEL_FATAL("mmInit: first managed physical page is not free in bitmap");

    /* Validate the descriptor database before the allocator is enabled. */
    if(mm.max_allocated <= 0 || mm.allocated == NULL || mm.bitmap == NULL)
        KERNEL_FATAL("mmInit: allocation database metadata invalid");
    if(mm.allocated[0] == NULL || mm.allocated[mm.max_allocated-1] == NULL)
        KERNEL_FATAL("mmInit: allocation descriptor pointer table invalid");
    printk("MM descriptor DB verified: slots=%d first=0x%x last=0x%x.\n",
        mm.max_allocated, mm.allocated[0], mm.allocated[mm.max_allocated-1]);

    /* Prove the page-table machinery independently of kmalloc descriptors.
     * Use one currently-free physical page, map it at the first kernel-map
     * address, verify both PTE and memory access, then undo only the PTE. */
    {
        int raw_page;
        volatile DWORD *raw_probe;

        raw_page = mmFindFreePages(1);
        if(raw_page <= 0)
            KERNEL_FATAL("mmInit: bitmap reports free memory but no page can be found");
        raw_probe = (volatile DWORD *)pg_mapmemory_at(raw_page, 1,
            PG_KERNEL_MAP_START);
        if(raw_probe == NULL)
            KERNEL_FATAL("mmInit: direct kernel PTE mapping failed");
        if(GetPage(PG_KERNEL_MAP_START_PAGE) !=
           (((DWORD)raw_page * PAGESIZE) | 3))
            KERNEL_FATAL("mmInit: direct kernel PTE verification failed");
        raw_probe[0] = 0x4A545054UL; /* 'JTPT' */
        if(raw_probe[0] != 0x4A545054UL)
            KERNEL_FATAL("mmInit: direct mapped-page access failed");
        pg_unmapmemory(PG_KERNEL_MAP_START, 1);
        printk("MM direct PTE probe passed: phys=0x%x virt=0x%x.\n",
            (DWORD)raw_page * PAGESIZE, PG_KERNEL_MAP_START);
    }

    mallocOK = TRUE;

    /* V67.8.29 boot invariant: physical bitmap and direct PTE success are not
     * enough; prove that one real kmalloc can acquire descriptor+mapping and
     * can be touched and released. PID -1 makes the probe reclaimable because
     * PID 0 allocations are permanent. */
    {
        DWORD before_free;
        volatile DWORD *probe;

        before_free = malloc_getmemoryfree();
        probe = (volatile DWORD *)_kmalloc(PAGESIZE, -1, "mmInit-map-probe");
        if(probe == NULL)
        {
            printk("MM map probe failed: stage=%d free=%u first-kmap-PTE=0x%x cursor=0x%x ndesc=%d/%d firstdesc=0x%x\n",
                mm_alloc_last_failure,
                (unsigned)before_free,
                GetPage(PG_KERNEL_MAP_START_PAGE),
                (unsigned)search_walk,
                mm.n_allocated, mm.max_allocated,
                mm.allocated ? mm.allocated[0] : NULL);
            KERNEL_FATAL("mmInit: kernel virtual allocation mapping failed");
        }
        if((DWORD)probe < PG_KERNEL_MAP_START || (DWORD)probe >= PG_KERNEL_MAP_END)
            KERNEL_FATAL("mmInit: allocator returned address outside kernel map window");

        probe[0] = 0x4A544D4DUL; /* 'JTMM' */
        probe[(PAGESIZE/sizeof(DWORD))-1] = 0x4D4D544AUL;
        if(probe[0] != 0x4A544D4DUL ||
           probe[(PAGESIZE/sizeof(DWORD))-1] != 0x4D4D544AUL)
            KERNEL_FATAL("mmInit: mapped allocation read/write verification failed");

        _kfree((void *)probe);
        if(malloc_getmemoryfree() != before_free)
            KERNEL_FATAL("mmInit: allocation probe did not restore free-page count");
        printk("MM kernel-map allocation probe passed.\n");
    }

    ShowPageMap();
    mm_Diagnostics();
    printf("%s: %u bytes free\n",
        __FUNCTION__, (unsigned int)malloc_getmemoryfree());
    printk("MM initialization passed.\n");
}

#ifdef LIBCVERSION
void disable(void)
{
}
void enable(void)
{
}
int get_eflags(void)
{
    return 0;
}
void set_eflags(int flags)
{
    (void)flags;
}

void malloc_init(char *p, int l)
{
    mmInit(p, l);
}
#endif
