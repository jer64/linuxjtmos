// ============================================================================
// mmap.c - POSIX-call-compatible mmap()/munmap() and ELF32 process mappings.
//
// The public mmap API is intentionally separate from kmalloc(). kmalloc keeps
// its historical one-argument kernel allocation role: kmalloc(size).
//
// Current JTMOS limitations:
//   * anonymous mappings are implemented;
//   * file-backed mappings are not implemented yet;
//   * MAP_FIXED requires a free exact range (it does not destroy an old map);
//   * munmap currently releases one complete mmap allocation, not a subrange;
//   * IA-32 non-PAE paging cannot enforce PROT_EXEC/NX separately.
// ============================================================================

#include <stddef.h>
#include "mm.h"
#include "mmAlloc.h"
#include "paging.h"
#include "sys/mman.h"

#if defined(N_MAX_THREADS) && (N_MAX_THREADS > MM_PROCESS_PAGE_TABLE_CAPACITY)
#error "JTMOS MM: PG_USER_PAGE_TABLES_BYTES is too small for N_MAX_THREADS"
#endif


static DWORD mmap_align_up(DWORD value)
{
    if(value > (0xffffffffUL - MM_PAGE_MASK))
        return 0;
    return (value + MM_PAGE_MASK) & ~MM_PAGE_MASK;
}

static int mmap_valid_prot(int prot)
{
    return (prot & ~(PROT_READ | PROT_WRITE | PROT_EXEC)) == 0;
}

void *mmap(void *addr, size_t length, int prot, int flags,
           int fd, off_t offset)
{
    DWORD bytes;
    void *p;
    int sharing;
    int pages;

    if(length == 0 || length > (size_t)0x7fffffffU)
        return MAP_FAILED;
    if(!mmap_valid_prot(prot))
        return MAP_FAILED;

    sharing = flags & (MAP_PRIVATE | MAP_SHARED);
    if(sharing != MAP_PRIVATE && sharing != MAP_SHARED)
        return MAP_FAILED;

    /* The first JTMOS implementation is anonymous-memory only. */
    if((flags & MAP_ANONYMOUS) == 0)
        return MAP_FAILED;
    if(fd != -1 || offset != 0)
        return MAP_FAILED;

    bytes = mmap_align_up((DWORD)length);
    if(bytes == 0 || bytes > 0x7fffffffUL)
        return MAP_FAILED;
    pages = (int)(bytes / PAGESIZE);

    if((flags & (MAP_FIXED | MAP_FIXED_NOREPLACE)) != 0)
    {
        if(addr == NULL || (((DWORD)addr) & MM_PAGE_MASK) != 0)
            return MAP_FAILED;

        /* Safe JTMOS interpretation: exact address, but never silently
           destroy an existing allocation. */
        p = _kmalloc_at((int)bytes, GetCurrentThread(), "mmap", (DWORD)addr);
    }
    else
    {
        /* addr is a POSIX hint here. The current JTMOS virtual allocator has
           no nearest-to-hint search, so an available mapping is selected. */
        p = kmalloc((int)bytes);
    }

    if(p == NULL)
        return MAP_FAILED;

    /* Anonymous mmap pages must initially read as zero. Do this while the
       mapping is writable, then apply the requested protection bits. */
    memset(p, 0, bytes);

    if(pg_protectmemory((DWORD)p, pages, prot) != 0)
    {
        kfree(p);
        return MAP_FAILED;
    }

    return p;
}

int munmap(void *addr, size_t length)
{
    DWORD bytes;
    int allocation_bytes;

    if(addr == NULL || addr == MAP_FAILED || length == 0)
        return -1;
    if(((DWORD)addr & MM_PAGE_MASK) != 0)
        return -1;
    if(length > (size_t)0x7fffffffU)
        return -1;

    bytes = mmap_align_up((DWORD)length);
    if(bytes == 0)
        return -1;

    allocation_bytes = malloc_getsize(addr);
    if(allocation_bytes <= 0)
        return -1;

    /* The MM descriptor currently represents one contiguous allocation.
       Reject partial unmaps rather than freeing more memory than requested. */
    if((DWORD)allocation_bytes != bytes)
        return -1;

    kfree(addr);
    return 0;
}

DWORD mm_page_align_down(DWORD value)
{
    return value & ~MM_PAGE_MASK;
}

DWORD mm_page_align_up(DWORD value)
{
    return mmap_align_up(value);
}

/*
 * V67.4 sparse process backing.
 *
 * Find one contiguous free kernel *virtual* window, then populate it one page
 * at a time with _kmalloc_at().  Every call therefore needs only one free
 * physical 4 KiB page; physical adjacency is not required.  The resulting
 * kernel virtual range remains contiguous, which intentionally keeps A2K(),
 * ELF relocation/copy logic and legacy thread_base[] semantics unchanged.
 */
void *mm_sparse_alloc(DWORD length, int owner_pid, const char *name)
{
    DWORD bytes;
    DWORD base;
    DWORD i;
    DWORD pages;

    if(length == 0 || owner_pid < 0)
        return NULL;

    bytes = mm_page_align_up(length);
    if(bytes == 0 || bytes > 0x7fffffffUL)
        return NULL;

    pages = bytes / PAGESIZE;
    base = FindEmptyArea((int)pages);
    if(base == 0)
        return NULL;

    for(i = 0; i < pages; ++i)
    {
        if(_kmalloc_at(PAGESIZE, owner_pid,
                       name ? name : "sparse",
                       base + i * PAGESIZE) == NULL)
        {
            while(i > 0)
            {
                --i;
                kfree((void *)(base + i * PAGESIZE));
            }
            return NULL;
        }
    }

    memset((void *)base, 0, bytes);
    return (void *)base;
}

int mm_sparse_free(void *base, DWORD length)
{
    DWORD bytes;
    DWORD pages;
    DWORD i;

    if(base == NULL || (((DWORD)base) & MM_PAGE_MASK) != 0 || length == 0)
        return -1;

    bytes = mm_page_align_up(length);
    if(bytes == 0)
        return -1;
    pages = bytes / PAGESIZE;

    for(i = 0; i < pages; ++i)
        kfree((void *)((DWORD)base + i * PAGESIZE));

    return 0;
}

int mm_sparse_change_owner(void *base, DWORD length, int old_pid, int new_pid)
{
    DWORD bytes;
    DWORD pages;
    DWORD i;

    if(base == NULL || (((DWORD)base) & MM_PAGE_MASK) != 0 ||
       length == 0 || old_pid < 0 || new_pid < 0)
        return -1;

    bytes = mm_page_align_up(length);
    if(bytes == 0)
        return -1;
    pages = bytes / PAGESIZE;

    for(i = 0; i < pages; ++i)
    {
        void *page = (void *)((DWORD)base + i * PAGESIZE);
        if(ChangeChunkOwner(page, new_pid) != new_pid)
        {
            /* Restore the ownership already changed so callers have one
             * deterministic cleanup path. */
            while(i > 0)
            {
                --i;
                page = (void *)((DWORD)base + i * PAGESIZE);
                (void)ChangeChunkOwner(page, old_pid);
            }
            return -1;
        }
    }

    return 0;
}

static DWORD *mm_process_page_table(int pid)
{
    DWORD bytes_per_process;
    DWORD maximum_processes;

    if(pid < 0)
        return NULL;

    bytes_per_process = MM_PROCESS_PAGE_TABLE_BYTES;
    maximum_processes = MM_PROCESS_PAGE_TABLE_CAPACITY;
    if((DWORD)pid >= maximum_processes)
        return NULL;

    return (DWORD *)(PG_USER_PAGE_TABLES_PHYS +
                     ((DWORD)pid * bytes_per_process));
}

static DWORD mm_pte_flags_from_prot(int prot)
{
    DWORD flags;

    if(prot == PROT_NONE)
        return 0;

    /* Process mappings are ring-3 pages.  The parent PDE is also marked
       U/S by scheduler.c when the PID is selected. */
    flags = 1 | 4;              /* present + user */
    if(prot & PROT_WRITE)
        flags |= 2;             /* writable */

    /* IA-32 non-PAE has no NX bit, so PROT_EXEC cannot be independently
       enforced. PROT_READ/PROT_EXEC both mean a present, read-only PTE when
       PROT_WRITE is absent. */
    return flags;
}

void mm_clear_process_space(int pid)
{
    DWORD *table;
    DWORD i;
    DWORD mmflags;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return;

    mmflags=mmCriticalEnter();
    for(i = 0; i < MM_USER_PAGES; ++i)
        table[i] = 0;
    mmCriticalLeave(mmflags);
}

/* Clone the primary ELF32 userspace mappings onto a freshly allocated
 * child backing window.  The backing pages are private copies; only the
 * parent's PTE protection bits/presence are inherited.  This deliberately
 * excludes kernel-mediated DMA/IRQ resources, which have their own lifetime. */
int mm_clone_process_space(int parent_pid, int child_pid, void *child_backing, DWORD length)
{
    DWORD *parent_table;
    DWORD *child_table;
    DWORD bytes;
    DWORD pages;
    DWORD child_kernel_page;
    DWORD child_source_pte;
    DWORD physical;
    DWORD flags;
    DWORD i;

    if(child_backing == NULL || (((DWORD)child_backing) & MM_PAGE_MASK) != 0 || length == 0)
        return -1;

    bytes = mm_page_align_up(length);
    if(bytes == 0 || bytes > MM_USER_SIZE)
        return -1;

    parent_table = mm_process_page_table(parent_pid);
    child_table = mm_process_page_table(child_pid);
    if(parent_table == NULL || child_table == NULL)
        return -1;

    pages = bytes / PAGESIZE;
    if(pages > MM_USER_PAGES)
        pages = MM_USER_PAGES;

    mm_clear_process_space(child_pid);
    child_kernel_page = ((DWORD)child_backing) / PAGESIZE;

    for(i = 0; i < pages; ++i)
    {
        if((parent_table[i] & 1U) == 0)
            continue;

        child_source_pte = GetPage(child_kernel_page + i);
        physical = child_source_pte & 0xfffff000UL;
        if((child_source_pte & 1U) == 0 || physical < PG_STRUCTURES_PHYS_END)
        {
            mm_clear_process_space(child_pid);
            return -1;
        }

        /* Preserve IA-32 low PTE attributes (P/RW/US/cache/access bits), but
         * always use the child's newly allocated physical page. */
        flags = parent_table[i] & 0x00000fffUL;
        flags |= 1U | 4U;
        child_table[i] = physical | flags;
    }

    return 0;
}


DWORD mm_get_process_pte(int pid, DWORD virtual_address)
{
    DWORD *table;
    DWORD index;
    DWORD pte;
    DWORD mmflags;

    if(virtual_address < MM_USER_BASE || virtual_address >= MM_USER_TOP)
        return 0;
    table = mm_process_page_table(pid);
    if(table == NULL)
        return 0;
    index = (virtual_address - MM_USER_BASE) / PAGESIZE;
    if(index >= MM_USER_PAGES)
        return 0;

    mmflags=mmCriticalEnter();
    pte=table[index];
    mmCriticalLeave(mmflags);
    return pte;
}

int mm_map_process_range(int pid, DWORD virtual_address,
                         void *kernel_address, DWORD length, int prot)
{
    DWORD *table;
    DWORD virtual_end;
    DWORD first_index;
    DWORD page_count;
    DWORD source_page;
    DWORD source_pte;
    DWORD physical;
    DWORD pte_flags;
    DWORD mmflags;
    DWORD i;
    DWORD j;

    if(kernel_address == NULL || length == 0 || !mmap_valid_prot(prot))
        return -1;
    if((virtual_address & MM_PAGE_MASK) != 0 ||
       ((DWORD)kernel_address & MM_PAGE_MASK) != 0)
        return -1;

    length = mm_page_align_up(length);
    if(length == 0 || virtual_address < MM_USER_BASE)
        return -1;
    if(virtual_address > 0xffffffffUL - length)
        return -1;

    virtual_end = virtual_address + length;
    if(virtual_end > MM_USER_TOP)
        return -1;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return -1;

    first_index = (virtual_address - MM_USER_BASE) / PAGESIZE;
    page_count = length / PAGESIZE;
    source_page = ((DWORD)kernel_address) / PAGESIZE;
    pte_flags = mm_pte_flags_from_prot(prot);

    mmflags=mmCriticalEnter();
    for(i = 0; i < page_count; ++i)
    {
        source_pte = GetPage(source_page + i);
        physical = source_pte & 0xfffff000UL;

        if((source_pte & 1) == 0 || physical < PG_STRUCTURES_PHYS_END)
        {
            /* Transactional failure: never expose a partially installed
             * process mapping when one backing PTE is invalid. */
            for(j=0;j<i;++j)
                table[first_index+j]=0;
            mmCriticalLeave(mmflags);
            return -1;
        }

        table[first_index + i] = physical | pte_flags;
    }
    mmCriticalLeave(mmflags);
    return 0;
}

int mm_protect_process_range(int pid, DWORD virtual_address,
                             DWORD length, int prot)
{
    DWORD *table;
    DWORD virtual_end;
    DWORD first_index;
    DWORD page_count;
    DWORD pte;
    DWORD pte_flags;
    DWORD mmflags;
    DWORD i;

    if(length == 0 || !mmap_valid_prot(prot) ||
       (virtual_address & MM_PAGE_MASK) != 0)
        return -1;

    length = mm_page_align_up(length);
    if(length == 0 || virtual_address < MM_USER_BASE)
        return -1;
    if(virtual_address > 0xffffffffUL - length)
        return -1;

    virtual_end = virtual_address + length;
    if(virtual_end > MM_USER_TOP)
        return -1;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return -1;

    first_index = (virtual_address - MM_USER_BASE) / PAGESIZE;
    page_count = length / PAGESIZE;
    pte_flags = mm_pte_flags_from_prot(prot);

    mmflags=mmCriticalEnter();
    /* Validate the complete range first so protection changes are atomic. */
    for(i=0;i<page_count;++i)
    {
        pte=table[first_index+i];
        if((pte&0xfffff000UL)==0)
        {
            mmCriticalLeave(mmflags);
            return -1;
        }
    }
    for(i=0;i<page_count;++i)
    {
        pte=table[first_index+i];
        table[first_index+i]=(pte&0xfffff000UL)|pte_flags;
    }
    mmCriticalLeave(mmflags);
    return 0;
}

int mm_unmap_process_range(int pid, DWORD virtual_address, DWORD length)
{
    DWORD *table;
    DWORD virtual_end;
    DWORD first_index;
    DWORD page_count;
    DWORD mmflags;
    DWORD i;

    if(length == 0 || (virtual_address & MM_PAGE_MASK) != 0)
        return -1;

    length = mm_page_align_up(length);
    if(length == 0 || virtual_address < MM_USER_BASE)
        return -1;
    if(virtual_address > 0xffffffffUL - length)
        return -1;

    virtual_end = virtual_address + length;
    if(virtual_end > MM_USER_TOP)
        return -1;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return -1;

    first_index = (virtual_address - MM_USER_BASE) / PAGESIZE;
    page_count = length / PAGESIZE;
    mmflags=mmCriticalEnter();
    for(i = 0; i < page_count; ++i)
        table[first_index + i] = 0;
    mmCriticalLeave(mmflags);
    return 0;
}

DWORD mm_find_process_free_range(int pid, DWORD length, DWORD low, DWORD high)
{
    DWORD *table;
    DWORD pages;
    DWORD low_index;
    DWORD high_index;
    DWORD start;
    DWORD i;
    int free_range;

    length = mm_page_align_up(length);
    if(length == 0)
        return 0;
    if(low < MM_USER_BASE)
        low = MM_USER_BASE;
    if(high > MM_USER_TOP)
        high = MM_USER_TOP;
    low = mm_page_align_up(low);
    high = mm_page_align_down(high);
    if(high <= low || length > high-low)
        return 0;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return 0;
    pages = length / PAGESIZE;
    low_index = (low-MM_USER_BASE)/PAGESIZE;
    high_index = (high-MM_USER_BASE)/PAGESIZE;
    if(high_index < pages)
        return 0;

    start = high_index-pages;
    for(;;)
    {
        if(start < low_index)
            break;
        free_range = 1;
        for(i=0; i<pages; ++i)
        {
            /* A PROT_NONE mapping keeps its physical PTE address while
             * clearing Present. Treat any physical PTE as occupied. */
            if(table[start+i] & 0xfffff000UL)
            {
                free_range = 0;
                break;
            }
        }
        if(free_range)
            return MM_USER_BASE + start*PAGESIZE;
        if(start == 0)
            break;
        --start;
    }
    return 0;
}


/* -------------------------------------------------------------------------
 * V67.8.57.8 process mmap manager.
 *
 * The original mmap() above is a kernel-linear allocator.  ELF32 processes,
 * however, execute in their own 0x80000000..0x80ffffff page-table window.
 * These helpers allocate sparse kernel backing pages, map them into that
 * process window and retain the kernel alias needed by syscall copyin/copyout.
 * ------------------------------------------------------------------------- */
#define MM_PROCESS_MMAP_SLOTS 64

/* Process mmap metadata is published in two phases.  RESERVED claims both the
 * metadata slot and user virtual range before any slow backing allocation is
 * started.  ACTIVE is visible to A2K/translation.  REMOVING prevents a second
 * munmap/teardown from claiming the same mapping while its PTEs are removed.
 *
 * The registry is protected by mmCriticalEnter()/Leave().  On current JTMOS
 * this is an IRQ-safe single-CPU critical section; the reservation_id prevents
 * an old in-flight mmap from committing into a slot that teardown cancelled
 * and a later mapping reused (ABA protection). */
#define MM_PROCESS_MAP_FREE       0
#define MM_PROCESS_MAP_RESERVED   1
#define MM_PROCESS_MAP_ACTIVE     2
#define MM_PROCESS_MAP_REMOVING   3

typedef struct {
    BYTE state;
    DWORD reservation_id;
    DWORD user_address;
    DWORD kernel_address;
    DWORD length;
    int prot;
    int flags;
} MM_PROCESS_MAPPING;

static MM_PROCESS_MAPPING process_mmaps[MM_PROCESS_PAGE_TABLE_CAPACITY][MM_PROCESS_MMAP_SLOTS];
static DWORD process_mmap_next_reservation=1;

static int mm_process_pid_ok(int pid)
{
    return pid >= 0 && (DWORD)pid < MM_PROCESS_PAGE_TABLE_CAPACITY;
}

static DWORD mm_process_next_reservation_nolock(void)
{
    DWORD id;

    id=process_mmap_next_reservation++;
    if(id==0)
    {
        id=process_mmap_next_reservation++;
        if(id==0)
        {
            process_mmap_next_reservation=2;
            id=1;
        }
    }
    return id;
}

static int mm_process_pte_range_free_nolock(int pid, DWORD address, DWORD length)
{
    DWORD *table;
    DWORD first_index;
    DWORD pages;
    DWORD i;

    if(!mm_process_pid_ok(pid) || length==0 || (address&MM_PAGE_MASK))
        return 0;
    length=mm_page_align_up(length);
    if(length==0 || address<MM_USER_BASE || address>MM_USER_TOP-length)
        return 0;

    table=mm_process_page_table(pid);
    if(table==NULL)
        return 0;
    first_index=(address-MM_USER_BASE)/PAGESIZE;
    pages=length/PAGESIZE;
    for(i=0;i<pages;++i)
        if(table[first_index+i]&0xfffff000UL)
            return 0;
    return 1;
}

static int mm_process_registry_range_free_nolock(int pid, DWORD address, DWORD length)
{
    DWORD end;
    DWORD mend;
    int i;
    MM_PROCESS_MAPPING *m;

    if(!mm_process_pid_ok(pid) || length==0 || address>0xffffffffUL-length)
        return 0;
    end=address+length;
    for(i=0;i<MM_PROCESS_MMAP_SLOTS;++i)
    {
        m=&process_mmaps[pid][i];
        if(m->state==MM_PROCESS_MAP_FREE || m->length==0)
            continue;
        if(m->user_address>0xffffffffUL-m->length)
            return 0;
        mend=m->user_address+m->length;
        if(address<mend && m->user_address<end)
            return 0;
    }
    return 1;
}

static int mm_process_range_available_nolock(int pid, DWORD address, DWORD length)
{
    return mm_process_pte_range_free_nolock(pid,address,length) &&
           mm_process_registry_range_free_nolock(pid,address,length);
}

static DWORD mm_process_find_free_range_nolock(int pid, DWORD length,
                                                DWORD low, DWORD high)
{
    DWORD candidate;

    length=mm_page_align_up(length);
    if(length==0)
        return 0;
    if(low<MM_USER_BASE)
        low=MM_USER_BASE;
    if(high>MM_USER_TOP)
        high=MM_USER_TOP;
    low=mm_page_align_up(low);
    high=mm_page_align_down(high);
    if(high<=low || length>high-low)
        return 0;

    candidate=high-length;
    for(;;)
    {
        if(candidate<low)
            break;
        if(mm_process_range_available_nolock(pid,candidate,length))
            return candidate;
        if(candidate<low+PAGESIZE)
            break;
        candidate-=PAGESIZE;
    }
    return 0;
}

static MM_PROCESS_MAPPING *mm_process_free_slot_nolock(int pid)
{
    int i;
    if(!mm_process_pid_ok(pid))
        return NULL;
    for(i=0;i<MM_PROCESS_MMAP_SLOTS;++i)
        if(process_mmaps[pid][i].state==MM_PROCESS_MAP_FREE)
            return &process_mmaps[pid][i];
    return NULL;
}

static MM_PROCESS_MAPPING *mm_process_find_active_nolock(int pid, DWORD address)
{
    int i;
    MM_PROCESS_MAPPING *m;

    if(!mm_process_pid_ok(pid))
        return NULL;
    for(i=0;i<MM_PROCESS_MMAP_SLOTS;++i)
    {
        m=&process_mmaps[pid][i];
        if(m->state==MM_PROCESS_MAP_ACTIVE && m->user_address==address)
            return m;
    }
    return NULL;
}

static void mm_process_cancel_reservation(MM_PROCESS_MAPPING *slot, DWORD reservation_id)
{
    DWORD mmflags;

    if(slot==NULL || reservation_id==0)
        return;
    mmflags=mmCriticalEnter();
    if(slot->state==MM_PROCESS_MAP_RESERVED &&
       slot->reservation_id==reservation_id)
        memset(slot,0,sizeof(*slot));
    mmCriticalLeave(mmflags);
}

static void mm_process_invalidate(int pid, DWORD address, DWORD length)
{
#if defined(__i386__) && !defined(LIBCVERSION)
    DWORD end;
    if(pid != GetCurrentThread())
        return;
    end=address+length;
    while(address<end)
    {
        asm volatile("invlpg (%0)" : : "r" ((void *)address) : "memory");
        address+=PAGESIZE;
    }
#else
    (void)pid; (void)address; (void)length;
#endif
}

void *mm_process_mmap_anon(int pid, DWORD requested_address, DWORD length,
                           int prot, int flags, DWORD low)
{
    DWORD bytes;
    DWORD user_address;
    DWORD reservation_id;
    DWORD mmflags;
    void *backing;
    MM_PROCESS_MAPPING *slot;
    int fixed;
    int map_rv;

    if(!mm_process_pid_ok(pid) || length==0 || !mmap_valid_prot(prot))
        return NULL;
    if((flags&MAP_ANONYMOUS)==0 || (flags&MAP_PRIVATE)==0 || (flags&MAP_SHARED))
        return NULL;

    bytes=mm_page_align_up(length);
    if(bytes==0 || bytes>MM_USER_SIZE)
        return NULL;
    if(low<MM_USER_BASE) low=MM_USER_BASE;
    low=mm_page_align_up(low);
    if(low>=MM_USER_TOP || bytes>MM_USER_TOP-low)
        return NULL;

    /* Atomically claim a registry slot and the user VA range.  No PTE is
     * installed yet; RESERVED metadata makes the range unavailable to another
     * mmap while the potentially slow sparse backing allocation runs. */
    mmflags=mmCriticalEnter();
    slot=mm_process_free_slot_nolock(pid);
    if(slot==NULL)
    {
        mmCriticalLeave(mmflags);
        return NULL;
    }

    fixed=(flags&(MAP_FIXED|MAP_FIXED_NOREPLACE))!=0;
    user_address=0;
    if(requested_address)
    {
        if((requested_address&MM_PAGE_MASK)==0 && requested_address>=low &&
           requested_address<=MM_USER_TOP-bytes &&
           mm_process_range_available_nolock(pid,requested_address,bytes))
            user_address=requested_address;
        else if(fixed)
        {
            mmCriticalLeave(mmflags);
            return NULL;
        }
    }
    if(user_address==0)
        user_address=mm_process_find_free_range_nolock(pid,bytes,low,MM_USER_TOP);
    if(user_address==0)
    {
        mmCriticalLeave(mmflags);
        return NULL;
    }

    reservation_id=mm_process_next_reservation_nolock();
    memset(slot,0,sizeof(*slot));
    slot->state=MM_PROCESS_MAP_RESERVED;
    slot->reservation_id=reservation_id;
    slot->user_address=user_address;
    slot->length=bytes;
    slot->prot=prot;
    slot->flags=flags;
    mmCriticalLeave(mmflags);

    backing=mm_sparse_alloc(bytes,pid,"process mmap");
    if(backing==NULL)
    {
        mm_process_cancel_reservation(slot,reservation_id);
        return NULL;
    }

    /* Commit PTEs and metadata under the same MM critical section.  Teardown
     * may have cancelled this reservation while backing was allocated; token
     * validation prevents that stale operation from publishing into a reused
     * slot. */
    mmflags=mmCriticalEnter();
    if(slot->state!=MM_PROCESS_MAP_RESERVED ||
       slot->reservation_id!=reservation_id ||
       slot->user_address!=user_address || slot->length!=bytes)
    {
        mmCriticalLeave(mmflags);
        mm_sparse_free(backing,bytes);
        return NULL;
    }

    map_rv=mm_map_process_range(pid,user_address,backing,bytes,prot);
    if(map_rv!=0)
    {
        memset(slot,0,sizeof(*slot));
        mmCriticalLeave(mmflags);
        mm_sparse_free(backing,bytes);
        return NULL;
    }

    slot->kernel_address=(DWORD)backing;
    slot->state=MM_PROCESS_MAP_ACTIVE;
    mmCriticalLeave(mmflags);

    mm_process_invalidate(pid,user_address,bytes);
    return (void *)user_address;
}

int mm_process_munmap(int pid, DWORD user_address, DWORD length)
{
    MM_PROCESS_MAPPING *m;
    DWORD bytes;
    DWORD backing;
    DWORD mapped_address;
    DWORD mapped_length;
    DWORD mmflags;

    if(!mm_process_pid_ok(pid) || user_address==0 ||
       (user_address&MM_PAGE_MASK) || length==0)
        return -1;
    bytes=mm_page_align_up(length);
    if(bytes==0)
        return -1;

    mmflags=mmCriticalEnter();
    m=mm_process_find_active_nolock(pid,user_address);
    if(m==NULL || m->length!=bytes)
    {
        mmCriticalLeave(mmflags);
        return -1;
    }

    /* REMOVING makes a second munmap/translate fail before the PTEs/backing
     * can be touched twice. */
    m->state=MM_PROCESS_MAP_REMOVING;
    backing=m->kernel_address;
    mapped_address=m->user_address;
    mapped_length=m->length;
    if(mm_unmap_process_range(pid,mapped_address,mapped_length)!=0)
    {
        m->state=MM_PROCESS_MAP_ACTIVE;
        mmCriticalLeave(mmflags);
        return -1;
    }
    memset(m,0,sizeof(*m));
    mmCriticalLeave(mmflags);

    mm_process_invalidate(pid,mapped_address,mapped_length);
    return mm_sparse_free((void *)backing,bytes);
}

DWORD mm_translate_process_mapping(int pid, DWORD user_address, DWORD length)
{
    int i;
    MM_PROCESS_MAPPING *m;
    DWORD offset;
    DWORD result=0;
    DWORD mmflags;

    if(!mm_process_pid_ok(pid) || length==0)
        return 0;

    mmflags=mmCriticalEnter();
    for(i=0;i<MM_PROCESS_MMAP_SLOTS;++i)
    {
        m=&process_mmaps[pid][i];
        if(m->state!=MM_PROCESS_MAP_ACTIVE || user_address<m->user_address)
            continue;
        offset=user_address-m->user_address;
        if(offset<m->length && length<=m->length-offset)
        {
            result=m->kernel_address+offset;
            break;
        }
    }
    mmCriticalLeave(mmflags);
    return result;
}

void mm_release_process_mappings(int pid)
{
    int i;
    MM_PROCESS_MAPPING *m;
    DWORD backing;
    DWORD bytes;
    DWORD address;
    DWORD mmflags;
    int have_backing;

    if(!mm_process_pid_ok(pid))
        return;

    for(i=0;i<MM_PROCESS_MMAP_SLOTS;++i)
    {
        backing=0;
        bytes=0;
        address=0;
        have_backing=0;

        mmflags=mmCriticalEnter();
        m=&process_mmaps[pid][i];
        if(m->state==MM_PROCESS_MAP_FREE)
        {
            mmCriticalLeave(mmflags);
            continue;
        }

        if(m->state==MM_PROCESS_MAP_RESERVED)
        {
            /* Cancel an mmap that is still allocating backing.  Its token
             * check will notice cancellation and free any backing it obtains. */
            memset(m,0,sizeof(*m));
            mmCriticalLeave(mmflags);
            continue;
        }

        if(m->state==MM_PROCESS_MAP_ACTIVE)
        {
            m->state=MM_PROCESS_MAP_REMOVING;
            backing=m->kernel_address;
            bytes=m->length;
            address=m->user_address;
            have_backing=backing!=0 && bytes!=0;
            (void)mm_unmap_process_range(pid,address,bytes);
            memset(m,0,sizeof(*m));
        }
        else
        {
            /* REMOVING is normally transient entirely inside a critical
             * section.  Do not ever free its backing twice. */
            memset(m,0,sizeof(*m));
        }
        mmCriticalLeave(mmflags);

        if(have_backing)
        {
            mm_process_invalidate(pid,address,bytes);
            (void)mm_sparse_free((void *)backing,bytes);
        }
    }
}

int mm_clone_process_mappings(int parent_pid, int child_pid)
{
    int i;
    MM_PROCESS_MAPPING *src;
    MM_PROCESS_MAPPING *dst;
    DWORD src_user;
    DWORD src_kernel;
    DWORD src_length;
    DWORD reservation_id;
    DWORD mmflags;
    int src_prot;
    int src_flags;
    void *backing;
    int map_rv;

    if(!mm_process_pid_ok(parent_pid) || !mm_process_pid_ok(child_pid))
        return -1;

    for(i=0;i<MM_PROCESS_MMAP_SLOTS;++i)
    {
        /* Snapshot one ACTIVE parent mapping and reserve the identical child
         * VA/slot atomically.  RESERVED prevents another child mmap from
         * selecting the same address while backing is copied. */
        mmflags=mmCriticalEnter();
        src=&process_mmaps[parent_pid][i];
        if(src->state!=MM_PROCESS_MAP_ACTIVE)
        {
            mmCriticalLeave(mmflags);
            continue;
        }

        src_user=src->user_address;
        src_kernel=src->kernel_address;
        src_length=src->length;
        src_prot=src->prot;
        src_flags=src->flags;

        dst=mm_process_free_slot_nolock(child_pid);
        if(dst==NULL ||
           !mm_process_range_available_nolock(child_pid,src_user,src_length))
        {
            mmCriticalLeave(mmflags);
            goto fail;
        }

        reservation_id=mm_process_next_reservation_nolock();
        memset(dst,0,sizeof(*dst));
        dst->state=MM_PROCESS_MAP_RESERVED;
        dst->reservation_id=reservation_id;
        dst->user_address=src_user;
        dst->length=src_length;
        dst->prot=src_prot;
        dst->flags=src_flags;
        mmCriticalLeave(mmflags);

        backing=mm_sparse_alloc(src_length,child_pid,"fork mmap");
        if(backing==NULL)
        {
            mm_process_cancel_reservation(dst,reservation_id);
            goto fail;
        }
        memcpy(backing,(void *)src_kernel,src_length);

        mmflags=mmCriticalEnter();
        if(dst->state!=MM_PROCESS_MAP_RESERVED ||
           dst->reservation_id!=reservation_id ||
           dst->user_address!=src_user || dst->length!=src_length)
        {
            mmCriticalLeave(mmflags);
            mm_sparse_free(backing,src_length);
            goto fail;
        }

        map_rv=mm_map_process_range(child_pid,src_user,backing,
                                    src_length,src_prot);
        if(map_rv!=0)
        {
            memset(dst,0,sizeof(*dst));
            mmCriticalLeave(mmflags);
            mm_sparse_free(backing,src_length);
            goto fail;
        }

        dst->kernel_address=(DWORD)backing;
        dst->state=MM_PROCESS_MAP_ACTIVE;
        mmCriticalLeave(mmflags);
        mm_process_invalidate(child_pid,src_user,src_length);
    }
    return 0;

fail:
    mm_release_process_mappings(child_pid);
    return -1;
}
