// ============================================================================
// Memory management system - Free memory bitmap operations.
// (C) 2002-2005 by Jari Tuominen.
// Fixed 2026: bounds-safe bit access, exact page search and conservative
//             address rounding for free/reserve operations.
// ============================================================================
#include <stdio.h>
#include "mm.h"
#include "mmBit.h"

BYTE mmOrBits[8]={1,2,4,8, 16,32,64,128};
BYTE mmAndBits[8]={255-1, 255-2, 255-4, 255-8,
        255-16, 255-32, 255-64, 255-128};
static DWORD mm_free_pages;

static BYTE mm_bit_mask(DWORD which)
{
    return (BYTE)(1U << (which & 7));
}

/* V67.8.33: the bitmap has one authoritative owner: the global MM state.
 * p_mm remains a compatibility pointer for the rest of the kernel, but the
 * physical allocator must not depend on a second pointer to discover its own
 * bitmap.  The V67.8.32 boot proved mm.bitmap itself contained the correct
 * edge bytes while the scan path still reported zero free pages. */
static DWORD mm_bitmap_pages(void)
{
    if(mm.bitmap != NULL && mm.l_bitmap > 0)
        return (DWORD)mm.l_bitmap * 8;
    return 0;
}

static volatile BYTE *mm_bitmap_ptr(void)
{
    if(mm.bitmap == NULL || mm.l_bitmap <= 0)
        return NULL;
    return (volatile BYTE *)mm.bitmap;
}

/* Never keep a second hidden copy of the physical allocation bounds.
 * phMSTART..phMEND are the canonical arena selected by mmInit(). */
static DWORD mm_managed_first_page(void)
{
    DWORD first,pages;

    pages = mm_bitmap_pages();
    if(pages == 0 || phMSTART == NULL)
        return 0;
    first = (DWORD)phMSTART / PAGESIZE;
    if(first == 0)
        first = 1;
    if(first >= pages)
        return 0;
    return first;
}

static DWORD mm_managed_end_page(void)
{
    DWORD end,pages;

    pages = mm_bitmap_pages();
    if(pages == 0 || phMEND == NULL)
        return 0;
    end = (DWORD)phMEND / PAGESIZE;
    if(end > pages)
        end = pages;
    return end;
}

/* Bootstrap the physical arena without depending on the normal per-bit
 * allocator path.  The MM bitmap lives in freshly mapped bootstrap memory;
 * use volatile byte stores so every write is committed exactly once before
 * the first allocation is attempted.  [firstPage,endPage) becomes free and
 * every page outside that interval stays reserved. */
int mmBitmapBootstrapRange(DWORD firstPage, DWORD endPage)
{
    volatile BYTE *bitmap;
    DWORD represented,i,startByte,endByte,startBit,endBit;
    BYTE keep;

    bitmap = mm_bitmap_ptr();
    represented = mm_bitmap_pages();
    if(bitmap == NULL || represented == 0 ||
       firstPage >= endPage || endPage > represented)
        return -1;

    for(i=0; i<(DWORD)mm.l_bitmap; i++)
        bitmap[i] = 0xFF;

    startByte = firstPage >> 3;
    endByte = endPage >> 3;
    startBit = firstPage & 7;
    endBit = endPage & 7;

    if(startByte == endByte)
    {
        BYTE freeMask;
        freeMask = (BYTE)(((1U << endBit) - 1U) &
                          ~((1U << startBit) - 1U));
        bitmap[startByte] = (BYTE)(bitmap[startByte] & (BYTE)~freeMask);
    }
    else
    {
        /* First partial byte: preserve only pages below firstPage. */
        keep = startBit ? (BYTE)((1U << startBit) - 1U) : 0;
        bitmap[startByte] = keep;

        /* Complete interior bytes are entirely allocatable. */
        for(i=startByte+1; i<endByte; i++)
            bitmap[i] = 0x00;

        /* Last partial byte: free bits below endBit and keep the rest
         * reserved.  If endPage is byte aligned, endByte is outside the
         * free interval and must stay 0xFF. */
        if(endBit)
            bitmap[endByte] = (BYTE)~((1U << endBit) - 1U);
    }

    mm_free_pages = endPage - firstPage;

    /* Read back both edges immediately. */
    if((bitmap[firstPage >> 3] & mm_bit_mask(firstPage)) != 0 ||
       (bitmap[(endPage-1) >> 3] & mm_bit_mask(endPage-1)) != 0)
        return -2;

    return 0;
}

int mmBitGet(DWORD which)
{
    DWORD pages;

    pages = mm_bitmap_pages();
    // Outside the represented bitmap is never allocatable.
    if(pages == 0 || which >= pages)
        return 1;

    {
        volatile BYTE *bitmap = mm_bitmap_ptr();
        return (bitmap[which >> 3] & mm_bit_mask(which)) ? 1 : 0;
    }
}

int mmBitSet(DWORD which)
{
    DWORD pages;
    BYTE mask;

    pages = mm_bitmap_pages();
    if(pages == 0 || which >= pages)
        return -1;

    mask = mm_bit_mask(which);
    {
        volatile BYTE *bitmap = mm_bitmap_ptr();
        if(!(bitmap[which >> 3] & mask))
        {
            bitmap[which >> 3] = (BYTE)(bitmap[which >> 3] | mask);
            if(mm_free_pages)
                mm_free_pages--;
        }
    }
    return 0;
}

int mmBitRemove(DWORD which)
{
    DWORD pages;
    BYTE mask;

    pages = mm_bitmap_pages();
    if(pages == 0 || which >= pages)
        return -1;

    mask = mm_bit_mask(which);
    {
        volatile BYTE *bitmap = mm_bitmap_ptr();
        if(bitmap[which >> 3] & mask)
        {
            bitmap[which >> 3] = (BYTE)(bitmap[which >> 3] & (BYTE)~mask);
            mm_free_pages++;
        }
    }
    return 0;
}

int mmBitWrite(DWORD which, int state)
{
    if(state)
        return mmBitSet(which);
    return mmBitRemove(which);
}

int malloc_getamountfree(void)
{
    DWORD free_bytes;

    free_bytes = malloc_getmemoryfree();
    // Preserve the historical signed-int API without returning a negative
    // value on machines with more than 2 GB free.
    if(free_bytes > 0x7fffffffU)
        return 0x7fffffff;
    return (int)free_bytes;
}

void mmBitResetAccounting(void)
{
    mm_free_pages = 0;
}

void mmBitConfigurePhysicalRange(DWORD firstPage, DWORD endPage)
{
    /* Compatibility hook retained for older callers.  V67.8.33 deliberately
     * does not cache these values: the live arena is always derived from
     * phMSTART..phMEND so bootstrap, recount and allocation cannot diverge. */
    (void)firstPage;
    (void)endPage;
}

DWORD mmBitRecountFreePages(void)
{
    DWORD i,first,end,count;
    volatile BYTE *bitmap;

    bitmap = mm_bitmap_ptr();
    first = mm_managed_first_page();
    end = mm_managed_end_page();
    if(bitmap == NULL || first == 0 || end <= first)
    {
        mm_free_pages = 0;
        return 0;
    }

    count = 0;
    for(i=first; i<end; i++)
    {
        BYTE value,mask;
        value = bitmap[i >> 3];
        mask = mm_bit_mask(i);
        if((value & mask) == 0)
            count++;
    }

    mm_free_pages = count;
    return count;
}

DWORD malloc_getfreepages(void)
{
    return mm_free_pages;
}

// O(1) free-memory query. Bitmap mutations maintain the page counter.
DWORD malloc_getmemoryfree(void)
{
    return mm_free_pages * (DWORD)PAGESIZE;
}

// Returns the start page number containing at least 'pages' contiguous free pages.
int mmFindFreePages(int pages)
{
    DWORD i,first,end,run,start;
    volatile BYTE *bitmap;

    if(pages <= 0)
        return 0;

    bitmap = mm_bitmap_ptr();
    first = mm_managed_first_page();
    end = mm_managed_end_page();
    if(bitmap == NULL || first == 0 || end <= first ||
       (DWORD)pages > end-first)
        return 0;

    run = 0;
    start = 0;
    for(i=first; i<end; i++)
    {
        BYTE value,mask;
        value = bitmap[i >> 3];
        mask = mm_bit_mask(i);
        if((value & mask) == 0)
        {
            if(run == 0)
                start = i;
            run++;
            if(run >= (DWORD)pages)
                return (int)start;
        }
        else
        {
            run = 0;
            start = 0;
        }
    }

    return 0;
}

// Mark an address range free. Only complete pages fully contained in
// [p_s,p_e) are freed; this avoids exposing bytes belonging to a neighbour.
int mmFreeRegionAD(char *p_s, char *p_e)
{
    DWORD s,e;

    s = (DWORD)p_s;
    e = (DWORD)p_e;
    if(e <= s)
        return 0;

    s = (s / PAGESIZE) + ((s % PAGESIZE) ? 1 : 0); // ceil(start)
    e = e / PAGESIZE;                                  // floor(end)
    if(e <= s)
        return 0;

    return mmFreeRegion(s,e);
}

// Mark an address range reserved. Every page touched by [p_s,p_e) is reserved.
int mmReserveRegionAD(char *p_s, char *p_e)
{
    DWORD s,e;

    s = (DWORD)p_s;
    e = (DWORD)p_e;
    if(e <= s)
        return 0;

    s = s / PAGESIZE;                                      // floor(start)
    e = (e / PAGESIZE) + ((e % PAGESIZE) ? 1 : 0);       // ceil(end)
    return mmReserveRegion(s,e);
}

int mmFreeRegion(DWORD s, DWORD e)
{
    return mmSetRegion(s,e,0);
}

int mmReserveRegion(DWORD s, DWORD e)
{
    return mmSetRegion(s,e,1);
}

// Fill [startPage,endPage) in the bitmap to a defined state (0 or 1).
int mmSetRegion(DWORD startPage, DWORD endPage, int STATE)
{
    DWORD i,l,flags;
    int result;

    flags = mmCriticalEnter();
    l = mm_bitmap_pages();
    result = 0;

    if(l == 0 || startPage > endPage || startPage >= l)
        result = -1;
    else if(startPage != endPage)
    {
        if(endPage > l)
            endPage = l;
        for(i=startPage; i<endPage; i++)
            mmBitWrite(i, STATE ? 1 : 0);
    }

    mmCriticalLeave(flags);
    return result;
}
