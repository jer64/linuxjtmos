///////////////////////////////////////////////////////////////////////////////////
// scanmem.c
// (C) 2004-2005 Jari Tuominen.
// 2026: BIOS E820 handoff from boot32; no compile-time RAM-size assumption.
///////////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include "kernel32.h"
#include "paging.h"
#include "scanmem.h"

/* boot32/e820.inc stores a versioned BIOS memory map here before protected
 * mode is entered. */
#define E820_HANDOFF_ADDR          0x00004200UL
#define E820_HANDOFF_SIGNATURE     0x30323845UL /* bytes: "E820" */
#define E820_HANDOFF_VERSION       1UL
#define E820_HANDOFF_ENTRY_OFF     0x40UL
#define E820_HANDOFF_ENTRY_SIZE    24UL
#define E820_HANDOFF_MAX_ENTRIES   64UL
#define E820_TYPE_USABLE           1UL
#define E820_FLAG_TRUNCATED        0x00000001UL
#define E820_FLAG_E801             0x00000002UL
#define E820_FLAG_AH88             0x00000004UL

/* mmInit() still has a signed int length argument. Keep the managed physical
 * top below 2 GiB until that interface and dependent arithmetic are widened.
 * This is a safety ceiling, not a configured/detected RAM size. */
#define SCANMEM_MANAGED_MAX        0x7FF00000UL

//////////////////////////////////////////////////////////////////////////////////////////
MEMORY_INFORMATION ms;

static DWORD scanmem_align_down(DWORD v)
{
    return v & ~(PAGESIZE-1UL);
}

/* Return the end of the contiguous BIOS-usable range which contains the fixed
 * JTMOS paging structures. JTMOS's physical allocator currently manages one
 * contiguous range beginning at PG_STRUCTURES_PHYS_END, so this must not cross
 * E820 reserved/ACPI/MMIO holes. */
static DWORD scanmem_e820_managed_end(DWORD *usable_bytes_out,
                                      DWORD *entry_count_out,
                                      DWORD *flags_out)
{
    volatile DWORD *h;
    volatile DWORD *e;
    DWORD count,stride,flags,i;
    DWORD base_lo,base_hi,len_lo,len_hi,type;
    DWORD end,managed_end,usable_total;

    h=(volatile DWORD *)E820_HANDOFF_ADDR;
    if(h[0]!=E820_HANDOFF_SIGNATURE || h[1]!=E820_HANDOFF_VERSION)
        return 0;

    count=h[2];
    stride=h[3];
    flags=h[4];
    if(count==0 || count>E820_HANDOFF_MAX_ENTRIES)
        return 0;
    if(stride<E820_HANDOFF_ENTRY_SIZE || stride>64UL)
        return 0;

    managed_end=0;
    usable_total=0;

    for(i=0;i<count;i++)
    {
        e=(volatile DWORD *)(E820_HANDOFF_ADDR+E820_HANDOFF_ENTRY_OFF+i*stride);
        base_lo=e[0];
        base_hi=e[1];
        len_lo=e[2];
        len_hi=e[3];
        type=e[4];

        if(type!=E820_TYPE_USABLE || (len_lo==0 && len_hi==0))
            continue;

        /* JTMOS is currently a 32-bit physical-memory kernel. */
        if(base_hi!=0)
            continue;

        /* Saturating 32-bit end calculation. */
        if(len_hi!=0 || len_lo>0xFFFFFFFFUL-base_lo)
            end=0xFFFFFFFFUL;
        else
            end=base_lo+len_lo;

        /* Account usable bytes below 4 GiB for diagnostics. */
        if(end>base_lo)
        {
            DWORD span=end-base_lo;
            if(usable_total>0xFFFFFFFFUL-span)
                usable_total=0xFFFFFFFFUL;
            else
                usable_total+=span;
        }

        if(base_lo<=PG_STRUCTURES_PHYS_END && end>PG_STRUCTURES_PHYS_END)
        {
            if(end>SCANMEM_MANAGED_MAX)
                end=SCANMEM_MANAGED_MAX;
            end=scanmem_align_down(end);
            if(end>managed_end)
                managed_end=end;
        }
    }

    if(usable_bytes_out) *usable_bytes_out=usable_total;
    if(entry_count_out) *entry_count_out=count;
    if(flags_out) *flags_out=flags;
    return managed_end;
}

//////////////////////////////////////////////////////////////////////////////////////////
// Returns the safe physical top address used by the current contiguous JTMOS MM.
//
int scanmem1(void)
{
    DWORD managed_end,usable_bytes,entries,flags;

    managed_end=scanmem_e820_managed_end(&usable_bytes,&entries,&flags);
    if(managed_end==0)
    {
        /* Never fall back to the old write-pattern probe here: kernel BSS/live
         * low memory already occupies addresses that probe used to overwrite. */
        KERNEL_FATAL("scanmem: boot loader supplied no usable BIOS memory map");
        return 0;
    }

    if(managed_end<=PG_STRUCTURES_PHYS_END)
        KERNEL_FATAL("scanmem: BIOS RAM ends inside fixed paging structures");

    printk("scanmem: BIOS memory map: %d entries", (int)entries);
    if(flags&E820_FLAG_E801)
        printk(" (E801 fallback)");
    else if(flags&E820_FLAG_AH88)
        printk(" (AH=88 fallback)");
    else if(flags&E820_FLAG_TRUNCATED)
        printk(" (E820 truncated)");
    printk(".\n");

    printk("scanmem: usable below 4G=%dK, managed physical top=%dK.\n",
           (int)(usable_bytes/1024UL), (int)(managed_end/1024UL));
    if(managed_end==SCANMEM_MANAGED_MAX)
        printk("scanmem: managed RAM capped below 2G by current mmInit ABI.\n");

    if(usable_bytes>SCANMEM_MANAGED_MAX)
        usable_bytes=SCANMEM_MANAGED_MAX;
    ms.usable=(int)usable_bytes;
    ms.unusable=0;
    return (int)managed_end;
}

//////////////////////////////////////////////////////////////////////////////////////////
int scanmem(void)
{
    int i;

    DebugSerialWrite("[scanmem] wrapper enter\n");
    i=scanmem1();
    DebugSerialWrite("[scanmem] scanmem1 returned\n");
    ms.amount=i;

    printk("Detected/managed RAM top: ");
    pd32(i/(1024*1024));
    print("M\n");
    DebugSerialWrite("[scanmem] wrapper leave\n");
    return i;
}

//////////////////////////////////////////////////////////////////////////////////////////
int GetRamAmount(void)
{
    return ms.amount;
}

//
