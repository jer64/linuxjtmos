// =================================================================================
// mmAlloc.c - kmalloc and kfree functions.
// (C) 2002-2005 by Jari Tuominen.
// Fixed 2026: lock handling, safe accounting, bounded names, exact-map allocator,
//             rollback on mapping failure and robust free paths.
// =================================================================================
#include <stdio.h>
#include "mm.h"
#include "mmAlloc.h"

char free_caller[100]={0,};
char malloc_caller[100]={0,};
volatile int mm_alloc_last_failure = MM_ALLOC_FAIL_NONE;

// ----------- Internal helpers ------------------------------------

static int mm_round_pages(int bytes)
{
    if(bytes <= 0)
        return 0;
    return (bytes / PAGESIZE) + ((bytes % PAGESIZE) ? 1 : 0);
}

static int mm_round_bytes(int bytes)
{
    int pages;

    if(bytes <= 0)
        return 0;
    if(bytes < PAGESIZE)
        return PAGESIZE;

    // Avoid signed int overflow when rounding up.
    if(bytes > 0x7fffffff - (PAGESIZE-1))
        return 0;

    pages = mm_round_pages(bytes);
    if(pages <= 0)
        return 0;
    return pages * PAGESIZE;
}

static void mm_copy_debug_name(char *dst, int dst_bytes, const char *src)
{
    if(dst == NULL || dst_bytes <= 0)
        return;
    if(src == NULL)
        src = "?";

    strncpy(dst, src, dst_bytes-1);
    dst[dst_bytes-1] = 0;
}

static void AffectProcessML_NoLock(int pid, int affection)
{
    int ml;

    if(!mallocOK)
        return;
    if(pid <= 0)
        return;

    ml = GetThreadML(pid);
    if((affection >= 0 && ml <= 0x7fffffff-affection) ||
       (affection < 0 && ml >= -affection))
        SetThreadML(pid, ml + affection);
}

// Allocate physical pages and map either automatically or at an exact address.
static void *mm_kmalloc_internal(int requested_bytes, int pid,
    const char *_property_name, DWORD exact_mapad, int use_exact_map)
{
    int startPage,endPage,pages,bytes;
    DWORD mapped,mapad;
    void *physical;
    MD *m;
    int flags;

    mm_alloc_last_failure = MM_ALLOC_FAIL_NONE;

    if(!mallocOK)
    {
        mm_alloc_last_failure = MM_ALLOC_FAIL_DISABLED;
        return NULL;
    }
    if(requested_bytes <= 0)
    {
        mm_alloc_last_failure = MM_ALLOC_FAIL_ARGUMENT;
        return NULL;
    }
    if(_property_name == NULL)
        _property_name = "kmalloc";
    if(use_exact_map && (exact_mapad == 0 || (exact_mapad & (PAGESIZE-1))))
    {
        mm_alloc_last_failure = MM_ALLOC_FAIL_ARGUMENT;
        return NULL;
    }

    bytes = mm_round_bytes(requested_bytes);
    if(bytes <= 0)
    {
        mm_alloc_last_failure = MM_ALLOC_FAIL_ARGUMENT;
        return NULL;
    }
    pages = bytes / PAGESIZE;

    flags = (int)mmCriticalEnter();
    mapped = 0;
    m = NULL;

    startPage = mmFindFreePages(pages);
    if(!startPage)
    {
        mm_alloc_last_failure = MM_ALLOC_FAIL_PHYSICAL;
        goto out;
    }

    endPage = startPage + pages;
    physical = (void *)((DWORD)startPage * PAGESIZE);

    /* Pick the virtual address before mutating the physical bitmap.  This
     * keeps every failure path transactional and makes virtual-space failure
     * distinguishable from descriptor exhaustion. */
    if(use_exact_map)
        mapad = exact_mapad;
    else
        mapad = FindEmptyArea(pages);
    if(!mapad)
    {
        mm_alloc_last_failure = MM_ALLOC_FAIL_VIRTUAL;
        goto out;
    }

    if(mmReserveRegion((DWORD)startPage, (DWORD)endPage) != 0)
    {
        mm_alloc_last_failure = MM_ALLOC_FAIL_RESERVE;
        goto out;
    }

    m = (MD *)mmAddEntry(startPage, pages, bytes);
    if(m == NULL)
    {
        mmFreeRegion((DWORD)startPage, (DWORD)endPage);
        mm_alloc_last_failure = MM_ALLOC_FAIL_DESCRIPTOR;
        goto out;
    }

    m->PID = pid;
    m->isFree = 0;
    m->pages = pages;
    m->page = startPage;
    m->bytes = bytes;
    m->p = physical;
    mm_copy_debug_name(m->name, sizeof(m->name), _property_name);

    /* FindEmptyArea() already selected and advanced the cursor, so use the
     * exact mapper for both paths.  This avoids a second virtual search and
     * makes allocation state changes strictly one-pass. */
    mapped = pg_mapmemory_at(startPage, pages, mapad);
    if(!mapped)
    {
        mmRemoveEntry(m); /* also releases physical bitmap region */
        mm_alloc_last_failure = MM_ALLOC_FAIL_MAP;
        goto out;
    }

    m->mapad = mapped;
    AffectProcessML_NoLock(m->PID, pages);
    mm_alloc_last_failure = MM_ALLOC_FAIL_NONE;

out:
    mmCriticalLeave((DWORD)flags);
    return mapped ? (void *)mapped : NULL;
}

// ----------- Wrappers I -------------------------------------

void malloc_optimize(void) { }
void malloc_dumpchunkinfoEx(void) { }
void malloc_restfree(void) { }

void AffectProcessML(int pid, int affection)
{
    DWORD flags;

    if(!mallocOK)
        return;
    flags = mmCriticalEnter();
    AffectProcessML_NoLock(pid, affection);
    mmCriticalLeave(flags);
}

void *malloc1(int count, const char *_property_name)
{
    void *ptr;

    if(!mallocOK)
        return NULL;
    if(_property_name == NULL)
        _property_name = "malloc";

    if(jtmos_debug)
        mm_copy_debug_name(malloc_caller, sizeof(malloc_caller), _property_name);
    if(mm_debug)
    {
        printk("%s called malloc with request count of %d bytes\n",
            _property_name, count);
    }

    ptr = _kmalloc(count, GetCurrentThread(), _property_name);
    return ptr;
}

void free1(void *ptr, const char *_property_name)
{
    if(!mallocOK || ptr == NULL)
        return;
    if(_property_name == NULL)
        _property_name = "free";

    if(jtmos_debug)
        mm_copy_debug_name(free_caller, sizeof(free_caller), _property_name);
    if(mm_debug)
        printk("%s called free with request to free PTR 0x%x\n",
            _property_name, ptr);
    kfree(ptr);
}


/* ------------------------------------------------------------------
 * Standard heap API.
 *
 * JTMOS keeps the page-based allocator underneath these functions.  The
 * public signatures are compatible with <stdlib.h>; the old malloc1/free1
 * entry points remain for code that wants to pass an explicit debug owner.
 * ------------------------------------------------------------------ */
void *malloc(size_t size)
{
    if(size == 0 || size > (size_t)0x7fffffffU)
        return NULL;
    return malloc1((int)size, "malloc");
}

void free(void *ptr)
{
    free1(ptr, "free");
}

void *calloc(size_t nmemb, size_t size)
{
    size_t total;
    void *ptr;

    if(nmemb != 0 && size > ((size_t)-1) / nmemb)
        return NULL;

    total = nmemb * size;
    if(total == 0)
        return malloc(0);

    ptr = malloc(total);
    if(ptr != NULL)
        memset(ptr, 0, total);
    return ptr;
}

void *realloc(void *ptr, size_t size)
{
    int old_size;
    size_t copy_size;
    void *new_ptr;

    if(ptr == NULL)
        return malloc(size);

    if(size == 0)
    {
        free(ptr);
        return NULL;
    }

    if(size > (size_t)0x7fffffffU)
        return NULL;

    old_size = malloc_getsize(ptr);
    if(old_size <= 0)
        return NULL;

    if(size <= (size_t)old_size &&
       size > (size_t)(old_size - PAGESIZE))
        return ptr;

    new_ptr = malloc(size);
    if(new_ptr == NULL)
        return NULL;

    copy_size = size < (size_t)old_size ? size : (size_t)old_size;
    memcpy(new_ptr, ptr, copy_size);
    free(ptr);
    return new_ptr;
}

void *reallocarray(void *ptr, size_t nmemb, size_t size)
{
    if(nmemb != 0 && size > ((size_t)-1) / nmemb)
        return NULL;
    return realloc(ptr, nmemb * size);
}

void mmPause(void)
{
    ESCLOCK();
}

// ----------- Wrappers II ------------------------------------

void SetMemoryName(void *ptr, const char *name)
{
    MD *m;
    DWORD flags;

    if(!mallocOK || ptr == NULL || name == NULL)
        return;

    flags = mmCriticalEnter();
    m = mmGiveMD(ptr);
    if(m != NULL)
        mm_copy_debug_name(m->name, sizeof(m->name), name);
    mmCriticalLeave(flags);
}

void *kmalloc(int l)
{
    if(!mallocOK || l <= 0)
        return NULL;
    return _kmalloc(l, GetCurrentThread(), "kmalloc");
}

void kfree(void *ptr)
{
    if(!mallocOK || ptr == NULL)
        return;
    _kfree(ptr);
}

// ----------- Functions -------------------------------------

void malloc_freeprocmem(int pid)
{
    int i,flags;
    MD *m;

    if(!mallocOK)
        return;

    if(!valid_pid(pid)) return;

    flags = (int)mmCriticalEnter();

    for(i=0; i<p_mm->n_allocated; i++)
    {
        m = p_mm->allocated[i];
        if(m == NULL || m->isFree)
            continue;

        if(m->PID == pid && m->p)
        {
            if(m->mapad)
                pg_unmapmemory(m->mapad, m->pages);

            AffectProcessML_NoLock(m->PID, -m->pages);
            mmRemoveEntry(m);
        }
    }

    mmCriticalLeave((DWORD)flags);
}

int malloc_getsize(void *PTR)
{
    MD *m;
    int bytes = 0;
    DWORD flags;

    if(!mallocOK || PTR == NULL)
        return 0;

    flags = mmCriticalEnter();
    m = mmGiveMD(PTR);
    if(m != NULL)
        bytes = m->bytes;
    mmCriticalLeave(flags);

    return bytes;
}

int ChangeChunkOwner(void *PTR, int pid)
{
    MD *m;
    int oldpid;
    int result;
    DWORD flags;

    if(!mallocOK || PTR == NULL)
        return 0;

    flags = mmCriticalEnter();
    m = mmGiveMD(PTR);
    if(m == NULL)
    {
        mmCriticalLeave(flags);
        return 0;
    }

    oldpid = m->PID;
    if(oldpid != pid)
    {
        AffectProcessML_NoLock(oldpid, -m->pages);
        m->PID = pid;
        AffectProcessML_NoLock(m->PID, m->pages);
    }
    result = m->PID;

    mmCriticalLeave(flags);
    return result;
}

void *procmalloc(DWORD l, int pid, const char *_property_name)
{
    if(!mallocOK || l == 0 || l > 0x7fffffffU)
        return NULL;
    return _kmalloc((int)l, pid, _property_name);
}

void *_kmalloc(int _bytes, int pid, const char *_property_name)
{
    return mm_kmalloc_internal(_bytes, pid, _property_name, 0, FALSE);
}

void *_kmalloc_at(int _bytes, int pid, const char *_property_name, DWORD mapad)
{
    return mm_kmalloc_internal(_bytes, pid, _property_name, mapad, TRUE);
}

void _kfree(void *ptr)
{
    int flags;
    MD *m;

    if(!mallocOK || ptr == NULL)
        return;

    flags = (int)mmCriticalEnter();

    m = mmGiveMD(ptr);
    if(m == NULL || m->isFree)
        goto out;

    // Historical policy: PID 0 allocations are permanent kernel mappings.
    if(m->PID == 0)
        goto out;

    if(m->mapad)
        pg_unmapmemory(m->mapad, m->pages);

    AffectProcessML_NoLock(m->PID, -m->pages);
    mmRemoveEntry(m);

out:
    mmCriticalLeave((DWORD)flags);
}
