#ifndef __INCLUDED_MMALLOC_H__
#define __INCLUDED_MMALLOC_H__

#include <stddef.h>

extern char free_caller[];
extern char malloc_caller[];

/* Standard C/POSIX-style heap interface. */
void *malloc(size_t size);
void free(void *ptr);
void *calloc(size_t nmemb, size_t size);
void *realloc(void *ptr, size_t size);
void *reallocarray(void *ptr, size_t nmemb, size_t size);

/* Historical debug-aware entry points remain available to old JTMOS code. */
void *malloc1(int count, const char *_property_name);
void free1(void *ptr, const char *_property_name);

/* Kernel allocator: deliberately remains kmalloc(X), not mmap-like. */
void *kmalloc(int l);
void kfree(void *ptr);

void *procmalloc(DWORD l, int PID, const char *_property_name);
void *_kmalloc(int bytes, int PID, const char *_property_name);
void *_kmalloc_at(int bytes, int PID, const char *_property_name, DWORD mapad);

/* Early-boot allocator diagnostics.  A failed allocation records the first
 * stage that rejected it so mmInit can distinguish physical, descriptor and
 * virtual-map failures without dereferencing unsafe pointers. */
#define MM_ALLOC_FAIL_NONE        0
#define MM_ALLOC_FAIL_DISABLED    1
#define MM_ALLOC_FAIL_ARGUMENT    2
#define MM_ALLOC_FAIL_PHYSICAL    3
#define MM_ALLOC_FAIL_RESERVE     4
#define MM_ALLOC_FAIL_DESCRIPTOR  5
#define MM_ALLOC_FAIL_VIRTUAL     6
#define MM_ALLOC_FAIL_MAP         7
extern volatile int mm_alloc_last_failure;
void _kfree(void *ptr);
int ChangeChunkOwner(void *PTR, int PID);
int malloc_getsize(void *PTR);
void AffectProcessML(int pid, int affection);
void malloc_freeprocmem(int pid);
void SetMemoryName(void *ptr, const char *name);
void mmPause(void);

#endif
