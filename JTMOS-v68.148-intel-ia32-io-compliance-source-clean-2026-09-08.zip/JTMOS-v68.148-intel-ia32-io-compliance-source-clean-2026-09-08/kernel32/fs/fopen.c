//=====================================================================================
// JTMOS kernel stdio fopen/freopen backend.
// V67.8.57.10.18.8: use descriptor flags directly; do not emulate stream position
// with a second buffer/offset state machine.
//=====================================================================================
#include <stdio.h>
#include "fcntlbits.h"

static int stdio_mode_flags(const char *mode, int *readable, int *writable,
                            int *append)
{
    int flags, plus=0, excl=0;
    int seen_b=0, seen_t=0, seen_plus=0, seen_x=0;
    int i;

    if(!mode || !mode[0]) { errno=EINVAL; return -1; }
    if(mode[0]!='r' && mode[0]!='w' && mode[0]!='a')
    { errno=EINVAL; return -1; }

    for(i=1; mode[i]; ++i)
    {
        switch(mode[i])
        {
            case 'b': if(seen_b++) { errno=EINVAL; return -1; } break;
            case 't': if(seen_t++) { errno=EINVAL; return -1; } break; /* legacy JTMOS extension */
            case '+': if(seen_plus++) { errno=EINVAL; return -1; } plus=1; break;
            case 'x': if(seen_x++) { errno=EINVAL; return -1; } excl=1; break;
            default: errno=EINVAL; return -1;
        }
    }
    if(excl && mode[0]!='w') { errno=EINVAL; return -1; }

    if(mode[0]=='r')
        flags=plus ? O_RDWR : O_RDONLY;
    else if(mode[0]=='w')
        flags=(plus ? O_RDWR : O_WRONLY) | O_CREAT | O_TRUNC;
    else
        flags=(plus ? O_RDWR : O_WRONLY) | O_CREAT | O_APPEND;
    if(excl) flags|=O_EXCL;

    if(readable) *readable=(mode[0]=='r' || plus) ? TRUE : FALSE;
    if(writable) *writable=(mode[0]!='r' || plus) ? TRUE : FALSE;
    if(append) *append=(mode[0]=='a') ? TRUE : FALSE;
    return flags;
}

FILE *fopen(const char *path, const char *mode)
{
    return _fopen(path,mode,NULL);
}

FILE *_fopen(const char *path, const char *mode, FILE *initialPTR)
{
    FILE *ns=initialPTR;
    int flags,fd,endpos,readable,writable,append;

    if(!path || !mode || !isValidString(path) || !isValidString(mode) || !path[0])
    { errno=EINVAL; return NULL; }
    if(strlen(path)>=sizeof(((FILE *)0)->tmpfname) ||
       strlen(mode)>=sizeof(((FILE *)0)->strmode))
    { errno=EINVAL; return NULL; }

    flags=stdio_mode_flags(mode,&readable,&writable,&append);
    if(flags<0) return NULL;

    /* freopen() closes the old association before attempting the new open. */
    if(ns)
    {
        if(ns->fd>=0) (void)close(ns->fd);
        if(ns->buf) { free(ns->buf); ns->buf=NULL; }
        memset(ns,0,sizeof(*ns));
        ns->fd=-1;
    }
    else
    {
        ns=(FILE *)malloc(sizeof(*ns));
        if(!ns) { errno=ENOMEM; return NULL; }
        memset(ns,0,sizeof(*ns));
        ns->fd=-1;
    }

    fd=open(path,flags);
    if(fd<0)
    {
        if(initialPTR==NULL) free(ns);
        return NULL;
    }

    ns->fd=fd;
    ns->readable=(char)readable;
    ns->writable=(char)writable;
    ns->append=(char)append;
    ns->readonly=(char)(readable && !writable);
    ns->eof=FALSE;
    ns->error=FALSE;
    ns->hasRead=FALSE;
    ns->writeback=FALSE;
    ns->mode=_IONBF;              /* kernel FILE now uses descriptor I/O directly */
    ns->offs=0;
    ns->baseOffs=0;
    ns->buf=NULL;
    ns->bufsiz=0;
    strcpy(ns->tmpfname,path);
    strcpy(ns->strmode,mode);

    endpos=lseek(fd,0,SEEK_END);
    if(endpos<0)
    {
        (void)close(fd); ns->fd=-1;
        if(initialPTR==NULL) free(ns);
        return NULL;
    }
    ns->fsize=endpos;
    if(append)
    {
        if(lseek(fd,0,SEEK_END)<0)
        {
            (void)close(fd); ns->fd=-1;
            if(initialPTR==NULL) free(ns);
            return NULL;
        }
    }
    else if(lseek(fd,0,SEEK_SET)<0)
    {
        (void)close(fd); ns->fd=-1;
        if(initialPTR==NULL) free(ns);
        return NULL;
    }
    return ns;
}
