#include <stdio.h>
#include "file.h"

/* Allocated/assigned by legacy kernel startup users when needed. */
FILE *stdout,*stdin,*stderr;

FILE *__fnewstream(void)
{
    FILE *s=(FILE *)malloc(sizeof(FILE));
    if(!s) { errno=ENOMEM; return NULL; }
    memset(s,0,sizeof(FILE));
    s->fd=-1;
    return s;
}

char *fgets(char *s, int maxv, FILE *stream)
{
    int i=0,c=EOF;
    if(!s || !stream || maxv<=0) { errno=EINVAL; return NULL; }
    if(maxv==1) { s[0]=0; return s; }

    while(i<maxv-1)
    {
        c=fgetc(stream);
        if(c==EOF) break;
        s[i++]=(char)c;
        if(c=='\n') break;
    }
    if(i==0 && c==EOF) return NULL;
    s[i]=0;
    return s;
}

int fputs(const char *s, FILE *stream)
{
    size_t n;
    if(!s || !stream) { errno=EINVAL; return EOF; }
    n=strlen(s);
    return fwrite(s,1,n,stream)==n ? 0 : EOF;
}

size_t fread(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
    BYTE *out=(BYTE *)ptr;
    size_t total,done=0;
    int rv;

    if(!stream || (!ptr && size && nmemb)) { errno=EINVAL; return 0; }
    if(size==0 || nmemb==0) return 0;
    if(nmemb>((size_t)-1)/size) { errno=EFBIG; stream->error=TRUE; return 0; }
    if(!stream->readable) { errno=EBADF; stream->error=TRUE; return 0; }

    total=size*nmemb;
    while(done<total)
    {
        int want=(total-done)>0x10000UL ? 0x10000 : (int)(total-done);
        rv=read(stream->fd,out+done,want);
        if(rv<0) { stream->error=TRUE; break; }
        if(rv==0) { stream->eof=TRUE; break; }
        stream->eof=FALSE;
        done+=(size_t)rv;
    }
    return done/size;
}

size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream)
{
    const BYTE *in=(const BYTE *)ptr;
    size_t total,done=0;
    int rv;

    if(!stream || (!ptr && size && nmemb)) { errno=EINVAL; return 0; }
    if(size==0 || nmemb==0) return 0;
    if(nmemb>((size_t)-1)/size) { errno=EFBIG; stream->error=TRUE; return 0; }
    if(!stream->writable) { errno=EBADF; stream->error=TRUE; return 0; }

    total=size*nmemb;
    stream->eof=FALSE;
    while(done<total)
    {
        int want=(total-done)>0x10000UL ? 0x10000 : (int)(total-done);
        rv=write(stream->fd,(void *)(in+done),want);
        if(rv<0) { stream->error=TRUE; break; }
        if(rv==0) { errno=EIO; stream->error=TRUE; break; }
        done+=(size_t)rv;
    }
    if((int)ftell(stream)>stream->fsize) stream->fsize=(int)ftell(stream);
    return done/size;
}

int putc(int c, FILE *stream) { return fputc(c,stream); }

void clearerr(FILE *stream)
{
    if(stream) { stream->eof=FALSE; stream->error=FALSE; }
}

int ferror(FILE *stream) { return stream ? stream->error : TRUE; }
int fileno(FILE *stream) { if(!stream) { errno=EINVAL; return -1; } return stream->fd; }
void rewind(FILE *stream) { if(stream) { (void)fseek(stream,0,SEEK_SET); clearerr(stream); } }
