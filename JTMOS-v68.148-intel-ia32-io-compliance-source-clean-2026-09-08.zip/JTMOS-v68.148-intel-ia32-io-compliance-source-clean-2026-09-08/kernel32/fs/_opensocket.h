//
#ifndef __INCLUDED_OPENSOCKET_H__
#define __INCLUDED_OPENSOCKET_H__

//
#define ISNUMBER(x) (x>='0' && x<='9')

int GetIPADDRPORT(const char *s, DWORD *ipaddr, DWORD *storeport);

#endif



