#ifndef __INCLUDED_FILEDIR_H__
#define __INCLUDED_FILEDIR_H__

/*
 * Directory namespace generation.
 *
 * DNR/DB is the authoritative per-thread cwd identity.  A printable cwd path
 * is only a cache and must be rebuilt after directory namespace changes.
 */
DWORD FileDirPathGeneration(void);
void FileDirNamespaceChanged(void);

#endif
