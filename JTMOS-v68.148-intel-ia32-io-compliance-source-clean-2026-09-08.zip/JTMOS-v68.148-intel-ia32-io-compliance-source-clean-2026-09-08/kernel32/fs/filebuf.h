#ifndef __INCLUDED_FILEBUF_H__
#define __INCLUDED_FILEBUF_H__

//
#include "fsdos.h"
#include "filedef.h"

// Buffer setting
// big = fast for large files   (e.g. 64K)
// small = fast for small files (e.g. 8K)
#define PRE_BUF_AMOUNT_K        24

// Obsolete (just ignore this value)
#define BUFFER_MORE_K           64

//
void setbuf(FILE *stream, char *buf);
void setbuffer(FILE *stream, char *buf, size_t size);
void setlinebuf(FILE *stream);
int setvbuf(FILE *stream, char *buf, int mode , size_t size);
int fputc(int c, FILE *stream);
int fgetc(FILE *stream);
int __fenlargebuf(FILE *stream, int newsz);
//int frefresh_write(FILE *stream);
//int frefresh(FILE *stream);
int rbuf(FILE *stream);
int wbuf(FILE *stream);

/* V67.8.57.7 kernel-owned descriptor buffering.  These mode values are the
 * Ring3 stdio ABI and intentionally match libc's _IOFBF/_IOLBF/_IONBF. */
#define JTMOS_FILEBUF_FULL 0
#define JTMOS_FILEBUF_LINE 1
#define JTMOS_FILEBUF_NONE 2
#define JTMOS_FILEBUF_DEFAULT_SIZE 4096
#define JTMOS_FILEBUF_MAX_SIZE (64*1024)

int KernelNativeStdinRead(int pid, void *buf, int count);
int KernelFileBufRead(int pid, int fd, void *buf, int count);
int KernelFileBufWrite(int pid, int fd, const void *buf, int count);
int KernelFileBufFlush(int pid, int fd);
int KernelFileBufSet(int pid, int fd, int mode, int size);
int KernelFileBufSeek(int pid, int fd, int offset, int whence);
int KernelFileBufTell(int pid, int fd);
void KernelFileBufFdClosing(int fd);

#endif

