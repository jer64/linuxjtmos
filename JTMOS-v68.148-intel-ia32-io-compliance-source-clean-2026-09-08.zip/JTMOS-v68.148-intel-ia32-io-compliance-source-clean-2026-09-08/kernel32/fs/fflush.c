#include <stdio.h>

/* Kernel FILE output is descriptor-direct as of V67.8.57.10.18.8.
 * There is therefore no FILE-local dirty buffer to drain.  Device/filesystem
 * durability remains the responsibility of write()/close()/syncdev(). */
int fflush(FILE *stream)
{
    if(stream==NULL) return 0; /* equivalent to flushing all: nothing pending */
    if(stream->fd<0) { errno=EBADF; stream->error=TRUE; return EOF; }
    return 0;
}
