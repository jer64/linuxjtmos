#include <stdio.h>

FILE *freopen(const char *path, const char *mode, FILE *stream)
{
    int oldfd;
    if(stream==NULL || path==NULL || mode==NULL) return NULL;
    (void)fflush(stream);
    oldfd=stream->fd;
    if(oldfd>=0) {
        (void)close(oldfd);
        stream->fd=-1;
    }
    return _fopen(path,mode,stream);
}
