// ===========================================================
// api.c - Kernel wrappers for LIBC fread, fwrite, etc.
// (C) 2002-2005 by Jari Tuominen.
// ===========================================================
#include "kernel32.h"
#include "api.h"

// Current path search order.
char *SysSearchPath=JTMOS_PATH;
// Current work directory (OBSOLETE).
char SysCWD[100]="/ram";
// Convert alter to multi-thread (TODO!).
FILE *stderr;
FILE *stdout;
FILE *stdin;


// Register a new device.
int registerNewDevice(const char *name,
        void *call,int cs,
        int pid,int type,
        int alias)
{
        //
        return scall(SYS_registernewdevice,
                JTM_PTR_TO_DWORD(name),JTM_PTR_TO_DWORD(call),cs, pid,type,alias);
}

//
void startMessageBox(void)
{
        //
        scall(SYS_activatemsgbox, 0,0,0, 0,0,0);
}

// Basic postman command poster function.
int Posti(int id,
	void *par1,void *par2,void *par3,void *par4,
	int v1,int v2)
{
/*	int rv;
	POSTMANCMD *p;

	//
	p = malloc(sizeof(POSTMANCMD));
	p->par1 = A2K(par1);
	p->par2 = A2K(par2);
	p->par3 = A2K(par3);
	p->par4 = A2K(par4);
	p->v1 = v1;
	p->v2 = v2;
	p->id = id;
	rv = PostmanPost(p);
	free(p);
	return rv;*/
	(void)id; (void)par1; (void)par2; (void)par3; (void)par4; (void)v1; (void)v2;
	return -1;
}

// Search through specified paths for a file.
static int path_component_separator(const char *path,int start,int pos)
{
    int i;
    if(path[pos]==';') return 1;
    if(path[pos]!=':') return 0;
    /* JTMOS device-qualified paths use a colon too (ram:/bin, hda:/bin).
     * A colon directly after a simple device name and before '/' belongs to
     * that component; later colons are POSIX PATH separators. */
    if(path[pos+1]=='/' && pos>start) {
        for(i=start;i<pos;i++)
            if(path[i]=='/' || path[i]=='\\' || path[i]==':') return 1;
        return 0;
    }
    return 1;
}

int SearchThroughPath(char *path, char *name, char *found)
{
    char str[256],str2[512];
    int start,pos,n,fd,sz,l;
    if(found==NULL) return 0;
    found[0]=0;
    if(path==NULL || name==NULL || !name[0]) return 0;
    l=(int)strlen(path);
    start=0;
    while(start<=l) {
        while(start<l && (path[start]==';' || path[start]==':')) start++;
        if(start>=l) break;
        pos=start;
        while(pos<l && !path_component_separator(path,start,pos)) pos++;
        n=pos-start;
        if(n>0 && n<(int)sizeof(str)) {
            memcpy(str,path+start,(unsigned int)n); str[n]=0;
            if((int)(strlen(str)+strlen(name)+2U)<(int)sizeof(str2)) {
                if(str[n-1]=='/' || str[n-1]=='\\') sprintf(str2,"%s%s",str,name);
                else sprintf(str2,"%s/%s",str,name);
                fd=open(str2,O_RDONLY);
                if(fd>=0) {
                    sz=lseek(fd,0,SEEK_END); close(fd);
                    if(sz>=0) { strcpy(found,str2); return 1; }
                }
            }
        }
        if(pos>=l) break;
        start=pos+1;
    }
    return 0;
}

// Copy memory chunk from process to process.
int globalcopy(int srcPID, DWORD srcOffs,
	int dstPID, DWORD dstOffs,
	int amount)
{
	//
	return scall(SYS_globalcopy, srcPID, srcOffs,
		dstPID, dstOffs,
		amount,0);
}

// Copy terminal's contents to a buffer.
int CopyTerminal(int terID, BYTE *buf)
{
        //
        return scall(SYS_copyterminal,
                terID,JTM_PTR_TO_DWORD(buf),0, 0,0,0);
}

// Run a command & wait until it exits
int cexec(const char *fname, const char *workDir)
{
	int pid;

        //
        if(!fname)return 1;
        if(!isValidString(fname))return 2;
        if(!workDir)workDir="";

        // Empty workDir means exact current DNR/DB inheritance.
        scall(SYS_cexec, JTM_PTR_TO_DWORD(fname),1,JTM_PTR_TO_DWORD(workDir),JTM_PTR_TO_DWORD(&pid),GetCurrentTerminal(),0);

	//
	return pid;
}

// Run a process in background
int bgexec(const char *fname, const char *workDir)
{
	int pid;

        //
        if(!fname)return 1;
        if(!isValidString(fname))return 2;
        if(!workDir)workDir="";

        // Empty workDir means exact current DNR/DB inheritance.
        scall(SYS_cexec, JTM_PTR_TO_DWORD(fname),0,JTM_PTR_TO_DWORD(workDir),JTM_PTR_TO_DWORD(&pid),GetCurrentTerminal(),0);

	//
	return pid;
}

// Execute a program through the single kernel exec resolver.
// Central Process reads PATH from the submitting process and performs the
// SearchThroughPath() lookup, including JTMOS device-qualified components such
// as hda1:/bin.  Keeping PATH resolution in one place prevents SMSH system()
// from accidentally using the obsolete compile-time SysSearchPath instead.
// Note: cexec() requests synchronous execution.
int system(const char *_cmd)
{
        int pid;

        if(_cmd==NULL || !_cmd[0]) return 1;
        /* Empty workDir preserves the caller's exact DNR/DB snapshot. */
        pid=cexec(_cmd,"");
        return pid>0 ? 0 : 1;
}

//
int _system(const char *cmd, const char *path)
{
        int pid;

        if(cmd==NULL || !cmd[0]) return 1;
        if(path==NULL) path="";

        /* Never implement exec cwd by getcwd()->chdir()->cexec()->chdir().
         * cexec snapshots the caller DNR/DB and resolves this workDir against
         * that immutable identity.  The caller's own cwd is never modified. */
        pid=cexec(cmd,path);
        if(pid<=0) return 1;
        WaitProcessTermination(pid);
        return 0;
}



int remove(const char *path)
{
	return unlink(path);
}
