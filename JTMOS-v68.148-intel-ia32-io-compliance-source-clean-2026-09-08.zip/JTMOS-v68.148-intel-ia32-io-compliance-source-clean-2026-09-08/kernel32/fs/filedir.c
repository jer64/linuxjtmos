// filedir.c - Directory namespace coordination
//
// The old file contained commented-out mkdir()/rmdir() libc stubs.  The real
// kernel directory API lives in fs/jtmfs/publicapi/directfileaccess.c.  Keep
// this unit for kernel-wide directory namespace state instead of shadowing
// those public functions with conflicting prototypes.
#include "kernel32.h"
#include "filedir.h"

static volatile DWORD filedir_path_generation = 1;

DWORD FileDirPathGeneration(void)
{
    return filedir_path_generation;
}

void FileDirNamespaceChanged(void)
{
    DWORD flags;

    flags=get_eflags();
    disable();
    ++filedir_path_generation;
    if(filedir_path_generation==0)
        filedir_path_generation=1;
    set_eflags(flags);
}
