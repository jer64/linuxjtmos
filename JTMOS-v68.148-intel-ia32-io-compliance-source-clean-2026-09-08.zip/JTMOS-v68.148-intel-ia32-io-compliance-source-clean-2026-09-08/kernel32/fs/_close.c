// close.c - Close file descriptor / file.
#include "basdef.h"
#include "kernel32.h"
#include "threads.h"
#include "scs.h"
#include "filedescriptor.h"
#include "msdosio.h"

//
// Free the descriptor.
// This will also cause automatic
// flushing of all the buffers, etc.
// Deallocation of the allocate data
// on buffers, if any, and so on.
//
int msdos_close(SYSCALLPAR)
{
	POSTMANCMD *post;
	FILEDES *f;
	int fd;

	//-------------------------------------------------------
	fd = scall_ebx;

	// Check file descriptor validity
	if(!isValidFD(fd))
		return -1;

	//-------------------------------------------------------
	f = get_filedesptr(fd);
	if(f==NULL)
	{
		dprintk("scall_close: Invalid fd=%d.\n",
			fd);
		return -1;
	}

	// Close socket.
	if(f->socketHandle)
	{
		// Close socket
		scall(SYS_closesocket, f->socketHandle,0,0, 0,0,0);
	}

	//
	dprintk("scall_close: Closing fd %d.\n",
		fd);

	// Got a new larger file size? Set new file size.
	if( f->max_offset_peek > msdos_getfilesize_path(f->dnr, f->name, f->db) )
	{
		// Set new size.
		msdos_setsize(f->dnr, f->name, (DWORD)f->max_offset_peek);
	}

	//
        _msdos_close(f);

	// Free file descriptor
	FreeFD(fd);

	//
	return 0;
}

//
int _msdos_setsize(const char *pathname, int offsetti)
{
	return msdos_setsize(GetCurrentDNR(), pathname, (DWORD)offsetti);
}

//

