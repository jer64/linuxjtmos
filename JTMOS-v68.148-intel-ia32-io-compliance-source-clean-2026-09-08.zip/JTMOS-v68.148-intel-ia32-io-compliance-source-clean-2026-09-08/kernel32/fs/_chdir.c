//
#include "kernel32.h"
#include "jtmfsAccess.h"

/* POSIX/Turbo-C compatibility entry point used by SYS_chdir. */
int _chdir(const char *path)
{
    return jtmfs_chdir(path);
}

int _fchdir(int fd)
{
    (void)fd;
    return -1;
}
