// =======================================================================
// File buffering functions.
//
// (C) 2002-2005 by Jari Tuominen(jari.tuominen@kanetti.fi).
//
// Some of these buffering functions(3 of these),
// simply implement setvbuffer -function.
// =======================================================================
#include <stdio.h>
#include <fsdos.h>
#include "linuxabi.h"
#include "filedescriptor.h"
#include "errno.h"
#include "term.h"
// Enable or disable file traceback
//#define TRACE printf
#ifdef TRACE
#undef TRACE
#endif
#define TRACE //

/** ENABLE OR DISABLE FILEBUF DEBUG MESSAGES **/
// #define FILEBUF_DEBUG
/**********************************************/

#define filebuf_debug //
////#define filebuf_debug printf

// This function is called on buffer refresh need.
// (for read "r" mode only)
int rbuf(FILE *stream)
{
	/* Pipes are streams: seeking them is invalid (ESPIPE). */
	if(LinuxFdIsPipe(stream->fd))
		return read(stream->fd,stream->buf,stream->bufsiz);
	lseek(stream->fd, stream->baseOffs, SEEK_SET);
	return read(stream->fd, stream->buf, stream->bufsiz);
}

// This function is called on buffer refresh need.
// (for write mode only)
int wbuf(FILE *stream)
{
	stream->writeback = FALSE;
	if(LinuxFdIsPipe(stream->fd))
		return write(stream->fd,stream->buf,stream->offs);
	lseek(stream->fd, stream->baseOffs, SEEK_SET);
	return write(stream->fd, stream->buf, stream->offs);
}

// Enlarge buffer
int __fenlargebuf(FILE *stream, int newsz)
{
	char *tmp;

	//
	if(  newsz >= stream->bufsiz  )
	{
		// Expand buffer when needed.
		filebuf_debug("%s: malloc\n", __FUNCTION__);
		TRACE("<MA %d>", newsz); //
		tmp = malloc(newsz);
		TRACE("</MA>"); //
		if(tmp==NULL)
		{
			filebuf_debug("%s: allocation of %d bytes failed\n",__FUNCTION__,newsz);
			return 1;
		}
		filebuf_debug("%s: memcpy\n", __FUNCTION__);
		TRACE("<CPY>"); //
		memcpy(tmp, stream->buf, stream->bufsiz);
		TRACE("</CPY>"); //

		//
		TRACE("<FR>"); //
		free(stream->buf);
		TRACE("</FR>"); //
		stream->buf=tmp;
		stream->bufsiz=newsz;
		filebuf_debug("%s: done\n", __FUNCTION__);
	}
	return 0;
}

// Read next character from a kernel FILE stream.
int fgetc(FILE *stream)
{
    BYTE c;
    int rv;
    if(!stream) { errno=EINVAL; return EOF; }
    if(!stream->readable) { errno=EBADF; stream->error=TRUE; return EOF; }
    rv=read(stream->fd,&c,1);
    if(rv<0) { stream->error=TRUE; return EOF; }
    if(rv==0) { stream->eof=TRUE; return EOF; }
    stream->eof=FALSE;
    return (int)c;
}

int fputc(int c, FILE *stream)
{
    BYTE ch=(BYTE)c;
    int rv;
    if(!stream) { errno=EINVAL; return EOF; }
    if(!stream->writable) { errno=EBADF; stream->error=TRUE; return EOF; }
    rv=write(stream->fd,&ch,1);
    if(rv!=1)
    {
        if(rv==0 && errno==0) errno=EIO;
        stream->error=TRUE;
        return EOF;
    }
    stream->eof=FALSE;
    return (int)ch;
}

/*
       The setvbuf function may be used at any time on any open stream to change its buffer.  The mode  parameter
       must be one of the following three macros:
              _IONBF unbuffered
              _IOLBF line buffered
              _IOFBF fully buffered
*/

//
void setbuf(FILE *stream, char *buf)
{
	//
	setvbuf(stream, buf, buf ? _IOFBF : _IONBF, BUFSIZ);
}

//
void setbuffer(FILE *stream, char *buf, size_t size)
{
	//
	setvbuf(stream, buf, buf != NULL ? _IOFBF : _IONBF, size);
}

//
void setlinebuf(FILE *stream)
{
	//
	(void)setvbuf(stream, NULL, _IOLBF, 0);
	return;
}

//
int setvbuf(FILE *stream, char *buf, int mode, size_t size)
{
	if(!stream || (mode!=_IOFBF && mode!=_IOLBF && mode!=_IONBF))
	{ errno=EINVAL; return EOF; }
	stream->mode=mode;
	stream->buf=buf;
	stream->bufsiz=(int)size;
	stream->offs=0;
	return 0;
}

//



/* =======================================================================
 * V67.8.57.7: kernel-owned fd/stdio buffering for Ring3.
 *
 * The modern libc used to keep fread/fwrite buffers in application memory.
 * That duplicated stream state outside the kernel and made pipes especially
 * fragile.  The kernel now owns the buffering state on the underlying open
 * descriptor.  Pipes remain unbuffered by default because their own ring
 * buffer is already the transport buffer.
 * ======================================================================= */
typedef struct
{
    BYTE *data;
    int capacity;
    int mode;
    int read_pos;
    int read_len;
    int write_len;
    int last_op;            /* 0 none, 1 read, 2 write */
    int eof;
    int error;
} JTMOS_KERNEL_FILEBUF;

static int kfilebuf_resolve_fd(int pid, int fd)
{
    if(fd>=0 && fd<=2) return LinuxResolveStdioFd(pid,fd);
    return fd;
}

static JTMOS_KERNEL_FILEBUF *kfilebuf_state(int fd, int create)
{
    FILEDES *f;
    JTMOS_KERNEL_FILEBUF *b;
    if(fd<3 || !isValidFD(fd)) return NULL;
    f=get_filedesptr(fd);
    if(!f) return NULL;
    b=(JTMOS_KERNEL_FILEBUF *)f->p4;
    if(b || !create) return b;
    b=(JTMOS_KERNEL_FILEBUF *)malloc(sizeof(*b));
    if(!b) return NULL;
    memset(b,0,sizeof(*b));
    ChangeChunkOwner(b,0);
    b->mode=LinuxFdIsPipe(fd) ? JTMOS_FILEBUF_NONE : JTMOS_FILEBUF_FULL;
    b->capacity=JTMOS_FILEBUF_DEFAULT_SIZE;
    if(b->mode!=JTMOS_FILEBUF_NONE)
    {
        b->data=(BYTE *)malloc(b->capacity);
        if(!b->data) { free(b); return NULL; }
        ChangeChunkOwner(b->data,0);
    }
    f->p4=(char *)b;
    return b;
}

/* Native terminal stdin is a canonical TTY stream, not raw conio input.
 *
 * Modern libc implements fgets()/scanf()/getchar() through fd 0.  The old
 * filebuf path called getch() once per requested byte and returned it
 * immediately.  That had two serious user-visible effects: typed characters
 * were never echoed, and Backspace could not edit bytes that fgetc() had
 * already consumed.  Programs such as net.bin therefore looked completely
 * frozen even though the USB/PS2 FIFO was receiving keys.
 *
 * Keep getch()/SYS_GETCH raw for conio applications, but make fd 0 behave like
 * a conventional canonical terminal: collect and echo one edited line, then
 * satisfy subsequent reads from that completed line.  State is terminal-local
 * because the terminal is the JTMOS controlling-TTY object. */
#define JTMOS_TTY_LINE_MAX 1024

typedef struct
{
    BYTE data[JTMOS_TTY_LINE_MAX];
    int length;
    int pos;
    int ready;
    int owner_pid;
} JTMOS_TTY_LINE;

static JTMOS_TTY_LINE *native_tty_line[N_MAX_SCREENS];

static JTMOS_TTY_LINE *kfilebuf_tty_state(int pid)
{
    int ter;
    JTMOS_TTY_LINE *st;

    ter=GetThreadTerminal(pid);
    if(ter<0 || ter>=N_MAX_SCREENS) return NULL;
    st=native_tty_line[ter];
    if(st) return st;

    st=(JTMOS_TTY_LINE *)malloc(sizeof(*st));
    if(!st) return NULL;
    memset(st,0,sizeof(*st));
    st->owner_pid=-1;
    ChangeChunkOwner(st,0);
    native_tty_line[ter]=st;
    return st;
}

int KernelNativeStdinRead(int pid, void *buf, int count)
{
    BYTE *out=(BYTE *)buf;
    JTMOS_TTY_LINE *st;
    int c,n;

    if(count<0 || (count>0 && !buf)) return -EINVAL;
    if(count==0) return 0;

    st=kfilebuf_tty_state(pid);
    if(!st) return -ENOMEM;

    /* A terminal can be handed from a shell to a foreground child and back.
     * Never leak an unfinished or completed line from the previous reader. */
    if(st->owner_pid!=pid)
    {
        st->length=0;
        st->pos=0;
        st->ready=0;
        st->owner_pid=pid;
    }

    /* Canonical mode does not expose a partial line.  Echo/edit while the
     * caller sleeps in this syscall, then publish the completed line. */
    while(!st->ready)
    {
        c=getch();

        if(c=='\r' || c=='\n')
        {
            if(st->length<JTMOS_TTY_LINE_MAX)
                st->data[st->length++]='\n';
            putch('\n');
            st->pos=0;
            st->ready=1;
            break;
        }

        if(c=='\b' || c==127)
        {
            if(st->length>0)
            {
                st->length--;
                /* putch('\b') in the terminal driver moves left and blanks
                 * the old cell, which is exactly canonical erase semantics. */
                putch('\b');
            }
            continue;
        }

        /* Ignore other C0 controls in canonical stdin.  Raw applications use
         * getch(), which intentionally keeps the full key stream. */
        if(c!='\t' && (c<32 || c>255))
            continue;

        if(st->length < JTMOS_TTY_LINE_MAX-1)
        {
            st->data[st->length++]=(BYTE)c;
            putch((BYTE)c);
        }
    }

    n=st->length-st->pos;
    if(n>count) n=count;
    if(n>0) memcpy(out,st->data+st->pos,n);
    st->pos+=n;

    if(st->pos>=st->length)
    {
        st->length=0;
        st->pos=0;
        st->ready=0;
    }
    return n;
}

static int kfilebuf_native_read(int pid, int fd, void *buf, int count)
{
    if(fd!=0) return -EBADF;
    return KernelNativeStdinRead(pid,buf,count);
}

static int kfilebuf_native_write(int fd, const void *buf, int count)
{
    const BYTE *p=(const BYTE *)buf;
    int i;
    if(fd!=1 && fd!=2) return -EBADF;
    for(i=0;i<count;i++) putch(p[i]);
    return count;
}

static int kfilebuf_flush_state(int fd, JTMOS_KERNEL_FILEBUF *b)
{
    int done=0,rv;
    if(!b || b->last_op!=2 || b->write_len<=0) return 0;
    while(done<b->write_len)
    {
        rv=write(fd,b->data+done,b->write_len-done);
        if(rv<=0)
        {
            b->error=1;
            if(done>0)
            {
                memmove(b->data,b->data+done,b->write_len-done);
                b->write_len-=done;
            }
            return -(errno ? errno : EIO);
        }
        done+=rv;
    }
    b->write_len=0;
    return 0;
}

static int kfilebuf_rewind_unread(int fd, JTMOS_KERNEL_FILEBUF *b)
{
    int unread,rv;
    if(!b || b->last_op!=1) return 0;
    unread=b->read_len-b->read_pos;
    if(unread<=0) { b->read_pos=b->read_len=0; return 0; }
    rv=lseek(fd,-unread,SEEK_CUR);
    if(rv<0) return -(errno ? errno : ESPIPE);
    b->read_pos=b->read_len=0;
    return 0;
}

int KernelFileBufRead(int pid, int fd, void *buf, int count)
{
    int realfd,done=0,rv,avail,chunk;
    BYTE *out=(BYTE *)buf;
    JTMOS_KERNEL_FILEBUF *b;
    if(count<0 || (count>0 && !buf)) return -EINVAL;
    if(count==0) return 0;
    realfd=kfilebuf_resolve_fd(pid,fd);
    if(realfd>=0 && realfd<=2) return kfilebuf_native_read(pid,realfd,buf,count);
    if(realfd<3 || !isValidFD(realfd) || !fd_has_owner(realfd,pid)) return -EBADF;
    b=kfilebuf_state(realfd,1);
    if(!b) return -ENOMEM;
    if(b->last_op==2)
    {
        rv=kfilebuf_flush_state(realfd,b);
        if(rv<0) return rv;
        b->last_op=0;
    }
    b->last_op=1;
    b->eof=0;
    if(b->mode==JTMOS_FILEBUF_NONE || !b->data || b->capacity<=0)
    {
        rv=read(realfd,buf,count);
        if(rv==0) b->eof=1;
        if(rv<0) { b->error=1; return -(errno ? errno : EIO); }
        return rv;
    }
    while(done<count)
    {
        if(b->read_pos<b->read_len)
        {
            avail=b->read_len-b->read_pos;
            chunk=count-done<avail ? count-done : avail;
            memcpy(out+done,b->data+b->read_pos,chunk);
            b->read_pos+=chunk;
            done+=chunk;
            continue;
        }
        b->read_pos=b->read_len=0;
        if(count-done>=b->capacity)
        {
            rv=read(realfd,out+done,count-done);
            if(rv<0) { b->error=1; return done ? done : -(errno ? errno : EIO); }
            if(rv==0) { b->eof=1; break; }
            done+=rv;
            continue;
        }
        rv=read(realfd,b->data,b->capacity);
        if(rv<0) { b->error=1; return done ? done : -(errno ? errno : EIO); }
        if(rv==0) { b->eof=1; break; }
        b->read_len=rv;
    }
    return done;
}

int KernelFileBufWrite(int pid, int fd, const void *buf, int count)
{
    int realfd,done=0,rv,room,chunk,i,flush_line;
    const BYTE *in=(const BYTE *)buf;
    JTMOS_KERNEL_FILEBUF *b;
    if(count<0 || (count>0 && !buf)) return -EINVAL;
    if(count==0) return 0;
    realfd=kfilebuf_resolve_fd(pid,fd);
    if(realfd>=0 && realfd<=2) return kfilebuf_native_write(realfd,buf,count);
    if(realfd<3 || !isValidFD(realfd) || !fd_has_owner(realfd,pid)) return -EBADF;
    b=kfilebuf_state(realfd,1);
    if(!b) return -ENOMEM;
    if(b->last_op==1)
    {
        rv=kfilebuf_rewind_unread(realfd,b);
        if(rv<0) return rv;
        b->last_op=0;
    }
    b->last_op=2;
    if(b->mode==JTMOS_FILEBUF_NONE || !b->data || b->capacity<=0)
    {
        rv=write(realfd,(void *)buf,count);
        if(rv<0) { b->error=1; return -(errno ? errno : EIO); }
        return rv;
    }
    while(done<count)
    {
        if(b->mode==JTMOS_FILEBUF_FULL && b->write_len==0 && count-done>=b->capacity)
        {
            rv=write(realfd,(void *)(in+done),count-done);
            if(rv<0) { b->error=1; return done ? done : -(errno ? errno : EIO); }
            if(rv==0) break;
            done+=rv;
            continue;
        }
        room=b->capacity-b->write_len;
        if(room<=0)
        {
            rv=kfilebuf_flush_state(realfd,b);
            if(rv<0) return done ? done : rv;
            room=b->capacity;
        }
        chunk=count-done<room ? count-done : room;
        memcpy(b->data+b->write_len,in+done,chunk);
        flush_line=0;
        if(b->mode==JTMOS_FILEBUF_LINE)
            for(i=0;i<chunk;i++) if(in[done+i]=='\n') { flush_line=1; break; }
        b->write_len+=chunk;
        done+=chunk;
        if(b->write_len>=b->capacity || flush_line)
        {
            rv=kfilebuf_flush_state(realfd,b);
            if(rv<0) return done ? done : rv;
            b->last_op=2;
        }
    }
    return done;
}

int KernelFileBufFlush(int pid, int fd)
{
    int realfd;
    JTMOS_KERNEL_FILEBUF *b;
    realfd=kfilebuf_resolve_fd(pid,fd);
    if(realfd>=0 && realfd<=2) return 0;
    if(realfd<3 || !isValidFD(realfd) || !fd_has_owner(realfd,pid)) return -EBADF;
    b=kfilebuf_state(realfd,0);
    if(!b) return 0;
    return kfilebuf_flush_state(realfd,b);
}

int KernelFileBufSet(int pid, int fd, int mode, int size)
{
    int realfd,rv;
    BYTE *newdata=NULL;
    JTMOS_KERNEL_FILEBUF *b;
    if(mode<JTMOS_FILEBUF_FULL || mode>JTMOS_FILEBUF_NONE) return -EINVAL;
    if(size<=0) size=JTMOS_FILEBUF_DEFAULT_SIZE;
    if(size>JTMOS_FILEBUF_MAX_SIZE) return -EINVAL;
    realfd=kfilebuf_resolve_fd(pid,fd);
    if(realfd>=0 && realfd<=2) return 0;
    if(realfd<3 || !isValidFD(realfd) || !fd_has_owner(realfd,pid)) return -EBADF;
    b=kfilebuf_state(realfd,1);
    if(!b) return -ENOMEM;
    rv=kfilebuf_flush_state(realfd,b);
    if(rv<0) return rv;
    rv=kfilebuf_rewind_unread(realfd,b);
    if(rv<0 && b->read_len>b->read_pos) return rv;
    if(mode!=JTMOS_FILEBUF_NONE)
    {
        newdata=(BYTE *)malloc(size);
        if(!newdata) return -ENOMEM;
        ChangeChunkOwner(newdata,0);
    }
    if(b->data) free(b->data);
    b->data=newdata;
    b->capacity=size;
    b->mode=mode;
    b->read_pos=b->read_len=b->write_len=0;
    b->last_op=0; b->eof=0; b->error=0;
    return 0;
}

int KernelFileBufSeek(int pid, int fd, int offset, int whence)
{
    int realfd,rv,unread;
    JTMOS_KERNEL_FILEBUF *b;
    realfd=kfilebuf_resolve_fd(pid,fd);
    if(realfd<3 || !isValidFD(realfd) || !fd_has_owner(realfd,pid)) return -ESPIPE;
    b=kfilebuf_state(realfd,0);
    if(b && b->last_op==2)
    {
        rv=kfilebuf_flush_state(realfd,b);
        if(rv<0) return rv;
    }
    if(b && b->last_op==1 && whence==SEEK_CUR)
    {
        unread=b->read_len-b->read_pos;
        offset-=unread;
    }
    rv=lseek(realfd,offset,whence);
    if(rv<0) return -(errno ? errno : ESPIPE);
    if(b)
    {
        b->read_pos=b->read_len=b->write_len=0;
        b->last_op=0; b->eof=0;
    }
    return rv;
}

int KernelFileBufTell(int pid, int fd)
{
    int realfd,rv,unread;
    JTMOS_KERNEL_FILEBUF *b;
    realfd=kfilebuf_resolve_fd(pid,fd);
    if(realfd<3 || !isValidFD(realfd) || !fd_has_owner(realfd,pid)) return -ESPIPE;
    rv=lseek(realfd,0,SEEK_CUR);
    if(rv<0) return -(errno ? errno : ESPIPE);
    b=kfilebuf_state(realfd,0);
    if(!b) return rv;
    if(b->last_op==1)
    {
        unread=b->read_len-b->read_pos;
        rv-=unread;
    }
    else if(b->last_op==2) rv+=b->write_len;
    return rv;
}

void KernelFileBufFdClosing(int fd)
{
    FILEDES *f;
    JTMOS_KERNEL_FILEBUF *b;
    if(fd<3 || !isValidFD(fd)) return;
    f=get_filedesptr(fd);
    if(!f) return;
    b=(JTMOS_KERNEL_FILEBUF *)f->p4;
    if(!b) return;
    (void)kfilebuf_flush_state(fd,b);
    if(b->data) free(b->data);
    free(b);
    f->p4=NULL;
}
