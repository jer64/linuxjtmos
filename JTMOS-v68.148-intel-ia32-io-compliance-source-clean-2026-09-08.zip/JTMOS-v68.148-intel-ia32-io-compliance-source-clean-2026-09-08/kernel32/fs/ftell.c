#ifdef JTMOSKERNEL
#include "kernel32.h"
#include "filebuf.h"
#include "filedef.h"
#else
#include <stdio.h>
#endif

long ftell(FILE *stream)
{
    int pos;
    if(!stream) { errno=EINVAL; return -1L; }
    pos=lseek(stream->fd,0,SEEK_CUR);
    if(pos<0) { stream->error=TRUE; return -1L; }
    return (long)pos;
}
