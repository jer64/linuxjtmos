#ifndef __INCLUDED_MSDOSIO_H__
#define __INCLUDED_MSDOSIO_H__

#include "kernel32.h"
#include "filedes.h"

/* FAT directory attributes. */
#define FAT12_ATTR_READONLY   0x01
#define FAT12_ATTR_HIDDEN     0x02
#define FAT12_ATTR_SYSTEM     0x04
#define FAT12_ATTR_VOLUME     0x08
#define FAT12_ATTR_DIRECTORY  0x10
#define FAT12_ATTR_ARCHIVE    0x20
#define FAT12_ATTR_LFN        0x0F

#define FAT12_CLUSTER_FREE    0x000
#define FAT12_CLUSTER_BAD     0xFF7
#define FAT12_CLUSTER_EOC_MIN 0xFF8
#define FAT12_CLUSTER_EOC     0xFFF

/*
 * Standard 32-byte MS-DOS directory entry.  FAT12/16 store the starting
 * cluster in the low 16-bit cluster field at offset 26.
 */
typedef struct __attribute__((packed))
{
    BYTE filename[11];
    BYTE attribute;
    BYTE nt_reserved;
    BYTE creation_tenths;
    WORD creation_time;
    WORD creation_date;
    WORD access_date;
    WORD cluster_high;
    WORD write_time;
    WORD write_date;
    WORD starting_cluster;
    DWORD filesize;
} FAT12_FILE_ENTRY;

int msdos_mount_drive(int fd);
int msdos_mount_filedes(FILEDES *f);
int msdos_unmount_drive(FILEDES *f);
int msdos_flush_device(int dnr);
int msdos_is_fat12_device(int dnr);

int _msdos_open(FILEDES *f, const char *name, int flags);
int _msdos_close(FILEDES *f);
int _msdos_read(int fd, const char *fname, char *buf, int count, int offset);
int _msdos_write(int fd, const char *fname, char *buf, int count, int offset);
int _msdos_readdir(int fd, char *buf, int count);

int msdos_getfilesize_path(int dnr, const char *pathname, int db);
int msdos_setsize(int dnr, const char *pathname, DWORD new_size);
int msdos_unlink_path(int dnr, const char *pathname);
int msdos_mkdir_path(int dnr, const char *pathname);
int msdos_file_exists(int dnr, const char *pathname);

/* Compatibility helper retained for old callers. */
int msdos_scanrootblock(FILEDES *f);

#endif
