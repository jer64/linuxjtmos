/*
 * kernel32/fs/fat12/msdosio.c
 *
 * MS-DOS FAT12 filesystem support for JTMOS.
 *
 * The original implementation was an unfinished 1.44 MB floppy prototype
 * which buffered the complete disk image and used hard-coded FAT/root
 * offsets.  This implementation derives the layout from the BPB, keeps only
 * the FAT in memory and performs data/directory I/O on demand.
 *
 * Supported:
 *   - FAT12 BPB validation and mount
 *   - 8.3 short file names (LFN entries are ignored)
 *   - root directory and subdirectories
 *   - file read/write/create/truncate/append
 *   - cluster allocation/freeing and both FAT copies
 *   - directory enumeration
 *   - mkdir/unlink/set-size helpers
 *
 * On-disk format is standard FAT12.  A device block must currently equal the
 * BPB bytes-per-sector value; normal DOS FAT12 media uses 512-byte sectors.
 */
#include "kernel32.h"
#include "msdosio.h"
#include "msdosmetadata.h"
#include "filedes.h"

static MSDOSIO *msdosio[FAT12_MAX_DEVICES];

typedef struct
{
    int d_ino;
    int d_off;
    unsigned short d_reclen;
    unsigned char d_type;
    char d_name[256];
} FAT12_DIRENT;


/* ------------------------------------------------------------------------- */
/* Little-endian helpers.                                                    */
/* ------------------------------------------------------------------------- */
static WORD fat12_get16(const BYTE *p)
{
    return (WORD)((WORD)p[0] | ((WORD)p[1] << 8));
}

static DWORD fat12_get32(const BYTE *p)
{
    return (DWORD)p[0] |
           ((DWORD)p[1] << 8) |
           ((DWORD)p[2] << 16) |
           ((DWORD)p[3] << 24);
}

static void fat12_put16(BYTE *p, WORD v)
{
    p[0] = (BYTE)(v & 0xff);
    p[1] = (BYTE)((v >> 8) & 0xff);
}

static void fat12_put32(BYTE *p, DWORD v)
{
    p[0] = (BYTE)(v & 0xff);
    p[1] = (BYTE)((v >> 8) & 0xff);
    p[2] = (BYTE)((v >> 16) & 0xff);
    p[3] = (BYTE)((v >> 24) & 0xff);
}

static int fat12_valid_dnr(int dnr)
{
    return dnr >= 0 && dnr < FAT12_MAX_DEVICES;
}

static MSDOSIO *fat12_state(int dnr)
{
    if(!fat12_valid_dnr(dnr))
        return NULL;
    return msdosio[dnr];
}

static int fat12_alloc_state(int dnr)
{
    MSDOSIO *m;

    if(!fat12_valid_dnr(dnr))
        return -1;
    if(msdosio[dnr] != NULL)
        return 0;

    m = (MSDOSIO *)malloc(sizeof(MSDOSIO));
    if(m == NULL)
        return -1;
    memset(m, 0, sizeof(MSDOSIO));
    m->dnr = dnr;
    msdosio[dnr] = m;
    return 0;
}

static void fat12_release_state(int dnr)
{
    MSDOSIO *m;

    if(!fat12_valid_dnr(dnr))
        return;
    m = msdosio[dnr];
    if(m == NULL)
        return;
    if(m->fat != NULL)
        free(m->fat);
    free(m);
    msdosio[dnr] = NULL;
}

/* ------------------------------------------------------------------------- */
/* Device/BPB handling.                                                      */
/* ------------------------------------------------------------------------- */
static int fat12_read_sector(MSDOSIO *m, DWORD sector, BYTE *buf)
{
    if(m == NULL || buf == NULL || sector >= m->total_sectors)
        return -1;
    return readblock(m->dnr, (int)sector, buf);
}

static int fat12_write_sector(MSDOSIO *m, DWORD sector, const BYTE *buf)
{
    if(m == NULL || buf == NULL || sector >= m->total_sectors)
        return -1;
    return writeblock(m->dnr, (int)sector, (void *)buf);
}

static int fat12_parse_bpb(MSDOSIO *m)
{
    BYTE *b;
    DWORD total;
    DWORD root_secs;
    DWORD data_secs;
    DWORD clusters;
    int block_size;

    if(m == NULL)
        return -1;
    b = m->bootsector;

    if(b[510] != 0x55 || b[511] != 0xaa)
        return -1;

    m->bytes_per_sector    = fat12_get16(b + 11);
    m->sectors_per_cluster = b[13];
    m->reserved_sectors    = fat12_get16(b + 14);
    m->fat_count           = b[16];
    m->root_entries        = fat12_get16(b + 17);
    total                  = fat12_get16(b + 19);
    m->media_descriptor    = b[21];
    m->sectors_per_fat     = fat12_get16(b + 22);
    if(total == 0)
        total = fat12_get32(b + 32);
    m->total_sectors = total;

    /* FAT12 sanity checks. */
    if(m->bytes_per_sector < 128 ||
       (m->bytes_per_sector & (m->bytes_per_sector - 1)) != 0 ||
       m->sectors_per_cluster == 0 ||
       (m->sectors_per_cluster & (m->sectors_per_cluster - 1)) != 0 ||
       m->reserved_sectors == 0 ||
       m->fat_count == 0 ||
       m->root_entries == 0 ||
       m->sectors_per_fat == 0 ||
       m->total_sectors == 0)
        return -1;

    block_size = getblocksize(m->dnr);
    if(block_size <= 0 || (WORD)block_size != m->bytes_per_sector)
    {
        dprintk("FAT12: device %d block size %d != BPB sector size %u.\n",
                m->dnr, block_size, (unsigned)m->bytes_per_sector);
        return -1;
    }
    m->device_block_size = block_size;

    root_secs = ((DWORD)m->root_entries * 32UL +
                 (DWORD)m->bytes_per_sector - 1UL) /
                (DWORD)m->bytes_per_sector;
    m->root_dir_sectors = root_secs;
    m->first_fat_sector = m->reserved_sectors;
    m->first_root_sector = m->first_fat_sector +
                           (DWORD)m->fat_count * m->sectors_per_fat;
    m->first_data_sector = m->first_root_sector + root_secs;

    if(m->first_data_sector >= m->total_sectors)
        return -1;

    data_secs = m->total_sectors - m->first_data_sector;
    clusters = data_secs / m->sectors_per_cluster;
    m->data_sectors = data_secs;
    m->cluster_count = clusters;

    /* Microsoft FAT type determination: FAT12 has < 4085 data clusters. */
    if(clusters == 0 || clusters >= 4085)
        return -1;

    m->max_cluster = (WORD)(clusters + 1); /* clusters are numbered 2..N+1 */
    m->fat_size_bytes = (DWORD)m->sectors_per_fat * m->bytes_per_sector;

    /* FAT must be large enough for every data-cluster entry plus 0 and 1. */
    if((((DWORD)m->max_cluster + 1UL) * 3UL + 1UL) / 2UL > m->fat_size_bytes)
        return -1;

    /* First FAT byte should agree with BPB media byte on formatted media. */
    return 0;
}

static int fat12_load_fat(MSDOSIO *m)
{
    DWORD i;
    BYTE *p;

    if(m == NULL)
        return -1;
    if(m->fat != NULL)
    {
        free(m->fat);
        m->fat = NULL;
    }

    m->fat = (BYTE *)malloc(m->fat_size_bytes);
    if(m->fat == NULL)
        return -1;

    p = m->fat;
    for(i = 0; i < m->sectors_per_fat; i++)
    {
        if(fat12_read_sector(m, m->first_fat_sector + i,
                             p + i * m->bytes_per_sector) != 0)
        {
            free(m->fat);
            m->fat = NULL;
            return -1;
        }
    }

    if(m->fat_size_bytes >= 3 && m->fat[0] != m->media_descriptor)
    {
        dprintk("FAT12: media byte mismatch on device %d (BPB=%x FAT=%x).\n",
                m->dnr, m->media_descriptor, m->fat[0]);
        /* Do not reject old/odd DOS images solely for this diagnostic. */
    }
    m->fat_dirty = 0;
    return 0;
}

static int fat12_mount_dnr(int dnr)
{
    MSDOSIO *m;
    BYTE sector0[512];
    int bs;

    if(!fat12_valid_dnr(dnr))
        return -1;
    if(fat12_alloc_state(dnr) != 0)
        return -1;
    m = msdosio[dnr];
    if(m->mounted)
        return 0;

    bs = getblocksize(dnr);
    if(bs != 512)
    {
        /* We need the BPB before supporting a non-512 physical block. */
        fat12_release_state(dnr);
        return -1;
    }
    if(readblock(dnr, 0, sector0) != 0)
    {
        fat12_release_state(dnr);
        return -1;
    }
    memcpy(m->bootsector, sector0, 512);

    if(fat12_parse_bpb(m) != 0 || fat12_load_fat(m) != 0)
    {
        fat12_release_state(dnr);
        return -1;
    }

    m->mounted = 1;
    dprintk("FAT12: mounted device %d: %lu sectors, %lu clusters, FAT=%u sectors.\n",
            dnr, (unsigned long)m->total_sectors,
            (unsigned long)m->cluster_count, (unsigned)m->sectors_per_fat);
    return 0;
}

int msdos_is_fat12_device(int dnr)
{
    if(fat12_mount_dnr(dnr) != 0)
        return 0;
    return 1;
}

int msdos_mount_filedes(FILEDES *f)
{
    if(f == NULL)
        return -1;
    if(fat12_mount_dnr(f->dnr) != 0)
        return -1;
    /* FAT12 root is represented as directory cluster 0. */
    if(f->db <= 0)
        f->db = FAT12_ROOT_CLUSTER;
    return 0;
}

int msdos_mount_drive(int fd)
{
    FILEDES *f;
    f = get_filedesptr(fd);
    if(f == NULL)
        return -1;
    return msdos_mount_filedes(f);
}

/* Compatibility helper.  A FAT12 root directory is not a cluster. */
int msdos_scanrootblock(FILEDES *f)
{
    if(f == NULL)
        return -1;
    if(msdos_mount_filedes(f) != 0)
        return -1;
    f->db = FAT12_ROOT_CLUSTER;
    return 0;
}

static WORD fat12_get_entry(MSDOSIO *m, WORD cluster)
{
    DWORD o;
    WORD v;

    if(m == NULL || m->fat == NULL || cluster > m->max_cluster)
        return FAT12_CLUSTER_EOC;
    o = (DWORD)cluster + ((DWORD)cluster >> 1);
    if(o + 1 >= m->fat_size_bytes)
        return FAT12_CLUSTER_EOC;

    v = (WORD)m->fat[o] | ((WORD)m->fat[o + 1] << 8);
    if(cluster & 1)
        v = (WORD)(v >> 4);
    else
        v = (WORD)(v & 0x0fff);
    return (WORD)(v & 0x0fff);
}

static int fat12_set_entry(MSDOSIO *m, WORD cluster, WORD value)
{
    DWORD o;
    WORD pair;

    if(m == NULL || m->fat == NULL || cluster > m->max_cluster)
        return -1;
    value &= 0x0fff;
    o = (DWORD)cluster + ((DWORD)cluster >> 1);
    if(o + 1 >= m->fat_size_bytes)
        return -1;

    pair = (WORD)m->fat[o] | ((WORD)m->fat[o + 1] << 8);
    if(cluster & 1)
        pair = (WORD)((pair & 0x000f) | (value << 4));
    else
        pair = (WORD)((pair & 0xf000) | value);
    m->fat[o] = (BYTE)(pair & 0xff);
    m->fat[o + 1] = (BYTE)((pair >> 8) & 0xff);
    m->fat_dirty = 1;
    return 0;
}

int msdos_flush_device(int dnr)
{
    MSDOSIO *m;
    DWORD copy, s;

    m = fat12_state(dnr);
    if(m == NULL || !m->mounted)
        return -1;
    if(!m->fat_dirty)
        return 0;

    for(copy = 0; copy < m->fat_count; copy++)
    {
        DWORD base;
        base = m->first_fat_sector + copy * m->sectors_per_fat;
        for(s = 0; s < m->sectors_per_fat; s++)
        {
            if(fat12_write_sector(m, base + s,
                    m->fat + s * m->bytes_per_sector) != 0)
                return -1;
        }
    }
    m->fat_dirty = 0;
    return 0;
}

int msdos_unmount_drive(FILEDES *f)
{
    int dnr;
    if(f == NULL)
        return -1;
    dnr = f->dnr;
    if(fat12_state(dnr) == NULL)
        return 0;
    if(msdos_flush_device(dnr) != 0)
        return -1;
    fat12_release_state(dnr);
    return 0;
}

/* ------------------------------------------------------------------------- */
/* FAT cluster helpers.                                                      */
/* ------------------------------------------------------------------------- */
static int fat12_valid_data_cluster(MSDOSIO *m, WORD c)
{
    return m != NULL && c >= 2 && c <= m->max_cluster;
}

static int fat12_is_eoc(WORD c)
{
    return (c & 0x0fff) >= FAT12_CLUSTER_EOC_MIN;
}

static DWORD fat12_cluster_first_sector(MSDOSIO *m, WORD cluster)
{
    return m->first_data_sector +
           ((DWORD)cluster - 2UL) * m->sectors_per_cluster;
}

static int fat12_zero_cluster(MSDOSIO *m, WORD cluster)
{
    BYTE *z;
    DWORD i;
    int rv;

    if(!fat12_valid_data_cluster(m, cluster))
        return -1;
    z = (BYTE *)malloc(m->bytes_per_sector);
    if(z == NULL)
        return -1;
    memset(z, 0, m->bytes_per_sector);
    rv = 0;
    for(i = 0; i < m->sectors_per_cluster; i++)
    {
        if(fat12_write_sector(m, fat12_cluster_first_sector(m, cluster) + i, z) != 0)
        {
            rv = -1;
            break;
        }
    }
    free(z);
    return rv;
}

static int fat12_alloc_cluster(MSDOSIO *m, WORD *out)
{
    WORD c;

    if(m == NULL || out == NULL)
        return -1;
    for(c = 2; c <= m->max_cluster; c++)
    {
        if(fat12_get_entry(m, c) == FAT12_CLUSTER_FREE)
        {
            if(fat12_set_entry(m, c, FAT12_CLUSTER_EOC) != 0)
                return -1;
            if(fat12_zero_cluster(m, c) != 0)
            {
                fat12_set_entry(m, c, FAT12_CLUSTER_FREE);
                return -1;
            }
            *out = c;
            return 0;
        }
    }
    return -1;
}

static int fat12_free_chain(MSDOSIO *m, WORD start)
{
    WORD c, next;
    DWORD guard;

    c = start;
    guard = 0;
    while(fat12_valid_data_cluster(m, c) && guard++ <= m->cluster_count)
    {
        next = fat12_get_entry(m, c);
        if(fat12_set_entry(m, c, FAT12_CLUSTER_FREE) != 0)
            return -1;
        if(fat12_is_eoc(next) || !fat12_valid_data_cluster(m, next))
            break;
        c = next;
    }
    return 0;
}

static int fat12_nth_cluster(MSDOSIO *m, WORD start, DWORD index, WORD *out)
{
    WORD c, next;
    DWORD i;

    if(m == NULL || out == NULL || !fat12_valid_data_cluster(m, start))
        return -1;
    c = start;
    for(i = 0; i < index; i++)
    {
        next = fat12_get_entry(m, c);
        if(fat12_is_eoc(next) || !fat12_valid_data_cluster(m, next))
            return -1;
        c = next;
    }
    *out = c;
    return 0;
}

static int fat12_chain_length(MSDOSIO *m, WORD start, DWORD *length, WORD *last)
{
    WORD c, next;
    DWORD n;

    if(length != NULL) *length = 0;
    if(last != NULL) *last = 0;
    if(start == 0)
        return 0;
    if(!fat12_valid_data_cluster(m, start))
        return -1;

    c = start;
    n = 0;
    while(fat12_valid_data_cluster(m, c) && n <= m->cluster_count)
    {
        n++;
        if(last != NULL) *last = c;
        next = fat12_get_entry(m, c);
        if(fat12_is_eoc(next))
            break;
        if(!fat12_valid_data_cluster(m, next))
            return -1;
        c = next;
    }
    if(n > m->cluster_count)
        return -1;
    if(length != NULL) *length = n;
    return 0;
}

static int fat12_ensure_chain(MSDOSIO *m, WORD *start, DWORD clusters_needed)
{
    DWORD have;
    WORD last, n;

    if(m == NULL || start == NULL)
        return -1;
    if(clusters_needed == 0)
    {
        if(*start != 0)
        {
            if(fat12_free_chain(m, *start) != 0)
                return -1;
            *start = 0;
        }
        return 0;
    }

    have = 0;
    last = 0;
    if(*start != 0 && fat12_chain_length(m, *start, &have, &last) != 0)
        return -1;

    if(have == 0)
    {
        if(fat12_alloc_cluster(m, &n) != 0)
            return -1;
        *start = n;
        last = n;
        have = 1;
    }

    while(have < clusters_needed)
    {
        if(fat12_alloc_cluster(m, &n) != 0)
            return -1;
        if(fat12_set_entry(m, last, n) != 0)
            return -1;
        if(fat12_set_entry(m, n, FAT12_CLUSTER_EOC) != 0)
            return -1;
        last = n;
        have++;
    }

    if(have > clusters_needed)
    {
        WORD keep, next;
        if(fat12_nth_cluster(m, *start, clusters_needed - 1, &keep) != 0)
            return -1;
        next = fat12_get_entry(m, keep);
        if(fat12_set_entry(m, keep, FAT12_CLUSTER_EOC) != 0)
            return -1;
        if(fat12_valid_data_cluster(m, next))
            return fat12_free_chain(m, next);
    }
    return 0;
}

/* ------------------------------------------------------------------------- */
/* DOS 8.3 names.                                                            */
/* ------------------------------------------------------------------------- */
static int fat12_is_name_char(int c)
{
    if(c >= 'A' && c <= 'Z') return 1;
    if(c >= 'a' && c <= 'z') return 1;
    if(c >= '0' && c <= '9') return 1;
    switch(c)
    {
        case '$': case '%': case '\'': case '-': case '_': case '@':
        case '~': case '`': case '!': case '(': case ')': case '{':
        case '}': case '^': case '#': case '&':
            return 1;
    }
    return 0;
}

static BYTE fat12_upper(BYTE c)
{
    if(c >= 'a' && c <= 'z')
        return (BYTE)(c - 'a' + 'A');
    return c;
}

static int fat12_make_short_name(const char *name, BYTE out[11])
{
    int i, n, e, dot;
    const char *p;

    if(name == NULL || out == NULL || name[0] == 0)
        return -1;
    memset(out, ' ', 11);

    if(!strcmp(name, "."))
    {
        out[0] = '.';
        return 0;
    }
    if(!strcmp(name, ".."))
    {
        out[0] = '.'; out[1] = '.';
        return 0;
    }

    dot = -1;
    for(i = 0; name[i]; i++)
    {
        if(name[i] == '.')
        {
            if(dot >= 0) return -1;
            dot = i;
        }
        else if(!fat12_is_name_char((unsigned char)name[i]))
            return -1;
    }

    n = dot >= 0 ? dot : i;
    e = dot >= 0 ? i - dot - 1 : 0;
    if(n < 1 || n > 8 || e > 3)
        return -1;
    if(dot >= 0 && e == 0)
        return -1;

    p = name;
    for(i = 0; i < n; i++)
        out[i] = fat12_upper((BYTE)p[i]);
    if(dot >= 0)
    {
        p = name + dot + 1;
        for(i = 0; i < e; i++)
            out[8 + i] = fat12_upper((BYTE)p[i]);
    }
    return 0;
}

static void fat12_short_to_text(const BYTE in[11], char *out, int outsz)
{
    int i, p, last;

    if(out == NULL || outsz <= 0)
        return;
    p = 0;
    last = 7;
    while(last >= 0 && in[last] == ' ') last--;
    for(i = 0; i <= last && p + 1 < outsz; i++)
        out[p++] = (char)in[i];
    last = 10;
    while(last >= 8 && in[last] == ' ') last--;
    if(last >= 8 && p + 1 < outsz)
    {
        out[p++] = '.';
        for(i = 8; i <= last && p + 1 < outsz; i++)
            out[p++] = (char)in[i];
    }
    out[p] = 0;
}

static int fat12_name_equal(const BYTE a[11], const BYTE b[11])
{
    int i;
    for(i = 0; i < 11; i++)
        if(fat12_upper(a[i]) != fat12_upper(b[i]))
            return 0;
    return 1;
}

/* ------------------------------------------------------------------------- */
/* Directory access.                                                         */
/* ------------------------------------------------------------------------- */
typedef struct
{
    DWORD sector;
    WORD offset;
    DWORD ordinal;
} FAT12_DIRENT_LOC;

static int fat12_dir_entry_location(MSDOSIO *m, WORD dir_cluster,
                                    DWORD ordinal, FAT12_DIRENT_LOC *loc)
{
    DWORD entries_per_sector;
    DWORD entries_per_cluster;
    DWORD sector_index;
    WORD cluster;

    if(m == NULL || loc == NULL)
        return -1;
    entries_per_sector = m->bytes_per_sector / 32;
    if(entries_per_sector == 0)
        return -1;

    if(dir_cluster == FAT12_ROOT_CLUSTER)
    {
        if(ordinal >= m->root_entries)
            return -1;
        sector_index = ordinal / entries_per_sector;
        loc->sector = m->first_root_sector + sector_index;
        loc->offset = (WORD)((ordinal % entries_per_sector) * 32);
        loc->ordinal = ordinal;
        return 0;
    }

    entries_per_cluster = entries_per_sector * m->sectors_per_cluster;
    if(entries_per_cluster == 0)
        return -1;
    if(fat12_nth_cluster(m, dir_cluster, ordinal / entries_per_cluster,
                         &cluster) != 0)
        return -1;
    sector_index = (ordinal % entries_per_cluster) / entries_per_sector;
    loc->sector = fat12_cluster_first_sector(m, cluster) + sector_index;
    loc->offset = (WORD)((ordinal % entries_per_sector) * 32);
    loc->ordinal = ordinal;
    return 0;
}

static int fat12_read_dir_entry(MSDOSIO *m, WORD dir_cluster, DWORD ordinal,
                                FAT12_FILE_ENTRY *e, FAT12_DIRENT_LOC *loc)
{
    FAT12_DIRENT_LOC l;
    BYTE *sec;
    int rv;

    if(e == NULL)
        return -1;
    if(fat12_dir_entry_location(m, dir_cluster, ordinal, &l) != 0)
        return -1;
    sec = (BYTE *)malloc(m->bytes_per_sector);
    if(sec == NULL)
        return -1;
    rv = fat12_read_sector(m, l.sector, sec);
    if(rv == 0)
        memcpy(e, sec + l.offset, sizeof(FAT12_FILE_ENTRY));
    free(sec);
    if(rv != 0)
        return -1;
    if(loc != NULL)
        *loc = l;
    return 0;
}

static int fat12_write_dir_entry(MSDOSIO *m, const FAT12_DIRENT_LOC *loc,
                                 const FAT12_FILE_ENTRY *e)
{
    BYTE *sec;
    int rv;

    if(m == NULL || loc == NULL || e == NULL)
        return -1;
    sec = (BYTE *)malloc(m->bytes_per_sector);
    if(sec == NULL)
        return -1;
    if(fat12_read_sector(m, loc->sector, sec) != 0)
    {
        free(sec);
        return -1;
    }
    memcpy(sec + loc->offset, e, sizeof(FAT12_FILE_ENTRY));
    rv = fat12_write_sector(m, loc->sector, sec);
    free(sec);
    return rv;
}

static int fat12_find_in_dir(MSDOSIO *m, WORD dir_cluster, const BYTE name[11],
                             FAT12_FILE_ENTRY *out, FAT12_DIRENT_LOC *outloc)
{
    FAT12_FILE_ENTRY e;
    FAT12_DIRENT_LOC loc;
    DWORD ord;
    DWORD limit;

    if(m == NULL || name == NULL)
        return 0;
    limit = dir_cluster == FAT12_ROOT_CLUSTER ? m->root_entries :
            (m->cluster_count * m->sectors_per_cluster *
             (m->bytes_per_sector / 32));

    for(ord = 0; ord < limit; ord++)
    {
        if(fat12_read_dir_entry(m, dir_cluster, ord, &e, &loc) != 0)
            break;
        if(e.filename[0] == 0x00)
            break;
        if(e.filename[0] == 0xe5)
            continue;
        if(e.attribute == FAT12_ATTR_LFN)
            continue;
        if(e.attribute & FAT12_ATTR_VOLUME)
            continue;
        if(fat12_name_equal(e.filename, name))
        {
            if(out != NULL) *out = e;
            if(outloc != NULL) *outloc = loc;
            return 1;
        }
    }
    return 0;
}

static int fat12_find_free_dir_entry(MSDOSIO *m, WORD dir_cluster,
                                     FAT12_DIRENT_LOC *outloc)
{
    FAT12_FILE_ENTRY e;
    FAT12_DIRENT_LOC loc;
    DWORD ord;
    DWORD entries_per_cluster;
    DWORD chain_len;
    WORD last, newc;

    if(m == NULL || outloc == NULL)
        return -1;

    if(dir_cluster == FAT12_ROOT_CLUSTER)
    {
        for(ord = 0; ord < m->root_entries; ord++)
        {
            if(fat12_read_dir_entry(m, dir_cluster, ord, &e, &loc) != 0)
                return -1;
            if(e.filename[0] == 0x00 || e.filename[0] == 0xe5)
            {
                *outloc = loc;
                return 0;
            }
        }
        return -1; /* FAT12 root cannot grow. */
    }

    if(fat12_chain_length(m, dir_cluster, &chain_len, &last) != 0)
        return -1;
    entries_per_cluster = (DWORD)m->sectors_per_cluster *
                          (m->bytes_per_sector / 32);
    for(ord = 0; ord < chain_len * entries_per_cluster; ord++)
    {
        if(fat12_read_dir_entry(m, dir_cluster, ord, &e, &loc) != 0)
            return -1;
        if(e.filename[0] == 0x00 || e.filename[0] == 0xe5)
        {
            *outloc = loc;
            return 0;
        }
    }

    /* Subdirectories may grow by one cluster. */
    if(fat12_alloc_cluster(m, &newc) != 0)
        return -1;
    if(fat12_set_entry(m, last, newc) != 0)
        return -1;
    if(fat12_set_entry(m, newc, FAT12_CLUSTER_EOC) != 0)
        return -1;
    ord = chain_len * entries_per_cluster;
    return fat12_dir_entry_location(m, dir_cluster, ord, outloc);
}

/* Resolve a slash/backslash separated path.  Returns the entry and its
 * parent directory.  Empty path resolves to root when allow_root != 0. */
static int fat12_strip_device_prefix(const char *path, const char **rest)
{
    const char *p, *slash;

    if(path == NULL || rest == NULL)
        return -1;
    p = strchr(path, ':');
    slash = strchr(path, '/');
    if(p != NULL && (slash == NULL || p < slash))
        path = p + 1;
    while(*path == '/' || *path == '\\') path++;
    *rest = path;
    return 0;
}

static int fat12_next_component(const char **pp, char *component, int max)
{
    const char *p;
    int n;

    p = *pp;
    while(*p == '/' || *p == '\\') p++;
    if(*p == 0)
    {
        *pp = p;
        return 0;
    }
    n = 0;
    while(*p && *p != '/' && *p != '\\')
    {
        if(n + 1 >= max)
            return -1;
        component[n++] = *p++;
    }
    component[n] = 0;
    while(*p == '/' || *p == '\\') p++;
    *pp = p;
    return 1;
}

static int fat12_resolve_parent(MSDOSIO *m, const char *path,
                                WORD *parent, BYTE leaf[11])
{
    const char *p;
    char comp[32], next[32];
    BYTE shortn[11];
    FAT12_FILE_ENTRY e;
    WORD dir;
    int rc, has_next;

    if(m == NULL || path == NULL || parent == NULL || leaf == NULL)
        return -1;
    if(fat12_strip_device_prefix(path, &p) != 0)
        return -1;
    dir = FAT12_ROOT_CLUSTER;
    rc = fat12_next_component(&p, comp, sizeof(comp));
    if(rc <= 0)
        return -1;

    for(;;)
    {
        const char *save;
        save = p;
        has_next = fat12_next_component(&save, next, sizeof(next));
        if(has_next < 0)
            return -1;
        if(has_next == 0)
        {
            if(fat12_make_short_name(comp, leaf) != 0)
                return -1;
            *parent = dir;
            return 0;
        }

        if(!strcmp(comp, "."))
        {
            /* stay */
        }
        else if(!strcmp(comp, ".."))
        {
            if(dir != FAT12_ROOT_CLUSTER)
            {
                BYTE dotdot[11];
                if(fat12_make_short_name("..", dotdot) != 0 ||
                   !fat12_find_in_dir(m, dir, dotdot, &e, NULL))
                    return -1;
                dir = e.starting_cluster;
            }
        }
        else
        {
            if(fat12_make_short_name(comp, shortn) != 0)
                return -1;
            if(!fat12_find_in_dir(m, dir, shortn, &e, NULL))
                return -1;
            if(!(e.attribute & FAT12_ATTR_DIRECTORY))
                return -1;
            dir = e.starting_cluster;
        }

        strcpy(comp, next);
        p = save;
    }
}

static int fat12_resolve_entry(MSDOSIO *m, const char *path,
                               FAT12_FILE_ENTRY *e, FAT12_DIRENT_LOC *loc,
                               WORD *parent)
{
    BYTE leaf[11];
    WORD dir;

    if(fat12_resolve_parent(m, path, &dir, leaf) != 0)
        return 0;
    if(!fat12_find_in_dir(m, dir, leaf, e, loc))
        return 0;
    if(parent != NULL) *parent = dir;
    return 1;
}

static int fat12_create_entry(MSDOSIO *m, const char *path, BYTE attr,
                              FAT12_FILE_ENTRY *out, FAT12_DIRENT_LOC *outloc)
{
    FAT12_FILE_ENTRY e;
    FAT12_DIRENT_LOC loc;
    BYTE leaf[11];
    WORD parent;

    if(fat12_resolve_parent(m, path, &parent, leaf) != 0)
        return -1;
    if(fat12_find_in_dir(m, parent, leaf, NULL, NULL))
        return -1;
    if(fat12_find_free_dir_entry(m, parent, &loc) != 0)
        return -1;

    memset(&e, 0, sizeof(e));
    memcpy(e.filename, leaf, 11);
    e.attribute = attr;
    e.starting_cluster = 0;
    e.filesize = 0;
    if(fat12_write_dir_entry(m, &loc, &e) != 0)
        return -1;
    if(out != NULL) *out = e;
    if(outloc != NULL) *outloc = loc;
    return 0;
}

/* ------------------------------------------------------------------------- */
/* File data I/O.                                                            */
/* ------------------------------------------------------------------------- */
static int fat12_read_data(MSDOSIO *m, WORD start, DWORD file_size,
                           BYTE *buf, DWORD count, DWORD offset)
{
    DWORD cluster_size, cluster_index, in_cluster, done, want;
    WORD c;
    BYTE *sec;

    if(m == NULL || buf == NULL)
        return -1;
    if(offset >= file_size || count == 0)
        return 0;
    if(count > file_size - offset)
        count = file_size - offset;
    if(start == 0)
        return 0;

    cluster_size = (DWORD)m->bytes_per_sector * m->sectors_per_cluster;
    cluster_index = offset / cluster_size;
    in_cluster = offset % cluster_size;
    if(fat12_nth_cluster(m, start, cluster_index, &c) != 0)
        return -1;

    sec = (BYTE *)malloc(m->bytes_per_sector);
    if(sec == NULL)
        return -1;
    done = 0;
    while(done < count)
    {
        DWORD sindex, soff;
        WORD next;
        sindex = in_cluster / m->bytes_per_sector;
        soff = in_cluster % m->bytes_per_sector;
        while(sindex < m->sectors_per_cluster && done < count)
        {
            if(fat12_read_sector(m, fat12_cluster_first_sector(m, c) + sindex, sec) != 0)
            {
                free(sec);
                return -1;
            }
            want = m->bytes_per_sector - soff;
            if(want > count - done) want = count - done;
            memcpy(buf + done, sec + soff, want);
            done += want;
            sindex++;
            soff = 0;
        }
        in_cluster = 0;
        if(done >= count) break;
        next = fat12_get_entry(m, c);
        if(fat12_is_eoc(next) || !fat12_valid_data_cluster(m, next))
            break;
        c = next;
    }
    free(sec);
    return (int)done;
}

static int fat12_write_data(MSDOSIO *m, FAT12_FILE_ENTRY *e,
                            const FAT12_DIRENT_LOC *loc,
                            const BYTE *buf, DWORD count, DWORD offset)
{
    DWORD cluster_size, end, clusters_needed;
    DWORD cluster_index, in_cluster, done, want;
    WORD start, c;
    BYTE *sec;

    if(m == NULL || e == NULL || loc == NULL || (buf == NULL && count != 0))
        return -1;
    if(count == 0)
        return 0;
    if(offset > 0xffffffffUL - count)
        return -1;
    end = offset + count;
    cluster_size = (DWORD)m->bytes_per_sector * m->sectors_per_cluster;
    clusters_needed = (end + cluster_size - 1) / cluster_size;
    start = e->starting_cluster;
    if(fat12_ensure_chain(m, &start, clusters_needed) != 0)
        return -1;
    e->starting_cluster = start;

    cluster_index = offset / cluster_size;
    in_cluster = offset % cluster_size;
    if(fat12_nth_cluster(m, start, cluster_index, &c) != 0)
        return -1;

    sec = (BYTE *)malloc(m->bytes_per_sector);
    if(sec == NULL)
        return -1;
    done = 0;
    while(done < count)
    {
        DWORD sindex, soff;
        WORD next;
        sindex = in_cluster / m->bytes_per_sector;
        soff = in_cluster % m->bytes_per_sector;
        while(sindex < m->sectors_per_cluster && done < count)
        {
            DWORD sector;
            sector = fat12_cluster_first_sector(m, c) + sindex;
            want = m->bytes_per_sector - soff;
            if(want > count - done) want = count - done;
            if(soff != 0 || want != m->bytes_per_sector)
            {
                if(fat12_read_sector(m, sector, sec) != 0)
                {
                    free(sec);
                    return -1;
                }
            }
            else
                memset(sec, 0, m->bytes_per_sector);
            memcpy(sec + soff, buf + done, want);
            if(fat12_write_sector(m, sector, sec) != 0)
            {
                free(sec);
                return -1;
            }
            done += want;
            sindex++;
            soff = 0;
        }
        in_cluster = 0;
        if(done >= count) break;
        next = fat12_get_entry(m, c);
        if(fat12_is_eoc(next) || !fat12_valid_data_cluster(m, next))
        {
            free(sec);
            return -1;
        }
        c = next;
    }
    free(sec);

    if(end > e->filesize)
        e->filesize = end;
    if(fat12_write_dir_entry(m, loc, e) != 0)
        return -1;
    if(msdos_flush_device(m->dnr) != 0)
        return -1;
    return (int)done;
}

/* ------------------------------------------------------------------------- */
/* Public file API used by the legacy kernel wrappers.                       */
/* ------------------------------------------------------------------------- */
int _msdos_open(FILEDES *f, const char *name, int flags)
{
    MSDOSIO *m;
    FAT12_FILE_ENTRY e;
    FAT12_DIRENT_LOC loc;
    int exists;

    if(f == NULL || name == NULL)
        return -1;
    if(msdos_mount_filedes(f) != 0)
        return -1;
    m = fat12_state(f->dnr);
    if(m == NULL)
        return -1;

    {
        const char *rootp;
        fat12_strip_device_prefix(name, &rootp);
        if(*rootp == 0 && (flags & O_DIRECTORY))
        {
            f->db = FAT12_ROOT_CLUSTER;
            f->datablock = 0;
            f->v1 = f->v2 = f->v3 = 0;
            f->v4 = FAT12_ATTR_DIRECTORY;
            f->offset = 0;
            return 0;
        }
    }

    exists = fat12_resolve_entry(m, name, &e, &loc, NULL);
    if(!exists && (flags & O_CREAT))
    {
        if(fat12_create_entry(m, name, FAT12_ATTR_ARCHIVE, &e, &loc) != 0)
            return -1;
        exists = 1;
    }
    if(!exists)
        return -1;

    if((flags & O_DIRECTORY) && !(e.attribute & FAT12_ATTR_DIRECTORY))
        return -1;
    if(!(flags & O_DIRECTORY) && (e.attribute & FAT12_ATTR_DIRECTORY))
        return -1;

    if((flags & O_TRUNC) && !(e.attribute & FAT12_ATTR_DIRECTORY))
    {
        if(e.starting_cluster != 0)
            fat12_free_chain(m, e.starting_cluster);
        e.starting_cluster = 0;
        e.filesize = 0;
        if(fat12_write_dir_entry(m, &loc, &e) != 0 || msdos_flush_device(f->dnr) != 0)
            return -1;
    }

    f->datablock = e.starting_cluster;
    f->v1 = (int)loc.sector;
    f->v2 = (int)loc.offset;
    f->v3 = (int)e.filesize;
    f->v4 = e.attribute;
    if(flags & O_DIRECTORY)
    {
        f->db = e.starting_cluster;
        f->offset = 0;
    }
    else if(flags & O_APPEND)
        f->offset = (int)e.filesize;
    return 0;
}

int _msdos_close(FILEDES *f)
{
    if(f == NULL)
        return -1;
    return msdos_flush_device(f->dnr);
}

int _msdos_read(int fd, const char *fname, char *buf, int count, int offset)
{
    FILEDES *f;
    MSDOSIO *m;
    FAT12_FILE_ENTRY e;
    FAT12_DIRENT_LOC loc;
    int rv;

    if(count < 0 || offset < 0 || buf == NULL)
        return -1;
    f = get_filedesptr(fd);
    if(f == NULL || msdos_mount_filedes(f) != 0)
        return -1;
    m = fat12_state(f->dnr);
    if(!fat12_resolve_entry(m, fname, &e, &loc, NULL))
        return -1;
    if(e.attribute & FAT12_ATTR_DIRECTORY)
        return -1;
    rv = fat12_read_data(m, e.starting_cluster, e.filesize,
                         (BYTE *)buf, (DWORD)count, (DWORD)offset);
    return rv;
}

int _msdos_write(int fd, const char *fname, char *buf, int count, int offset)
{
    FILEDES *f;
    MSDOSIO *m;
    FAT12_FILE_ENTRY e;
    FAT12_DIRENT_LOC loc;

    if(count < 0 || offset < 0 || (buf == NULL && count != 0))
        return -1;
    f = get_filedesptr(fd);
    if(f == NULL || msdos_mount_filedes(f) != 0)
        return -1;
    m = fat12_state(f->dnr);
    if(!fat12_resolve_entry(m, fname, &e, &loc, NULL))
    {
        if(!(f->flags & O_CREAT))
            return -1;
        if(fat12_create_entry(m, fname, FAT12_ATTR_ARCHIVE, &e, &loc) != 0)
            return -1;
    }
    if(e.attribute & (FAT12_ATTR_DIRECTORY | FAT12_ATTR_READONLY))
        return -1;
    return fat12_write_data(m, &e, &loc, (BYTE *)buf,
                            (DWORD)count, (DWORD)offset);
}

int _msdos_readdir(int fd, char *buf, int count)
{
    FILEDES *f;
    MSDOSIO *m;
    FAT12_FILE_ENTRY e;
    DWORD ord, limit;
    char name[16];
    FAT12_DIRENT *de;

    f = get_filedesptr(fd);
    if(f == NULL || buf == NULL || count < (int)sizeof(FAT12_DIRENT))
        return -1;
    if(msdos_mount_filedes(f) != 0)
        return -1;
    m = fat12_state(f->dnr);
    ord = (DWORD)f->offset;
    limit = f->db == FAT12_ROOT_CLUSTER ? m->root_entries :
            m->cluster_count * m->sectors_per_cluster *
            (m->bytes_per_sector / 32);

    while(ord < limit)
    {
        if(fat12_read_dir_entry(m, (WORD)f->db, ord, &e, NULL) != 0)
            return 0;
        ord++;
        f->offset = (int)ord;
        if(e.filename[0] == 0x00)
            return 0;
        if(e.filename[0] == 0xe5 || e.attribute == FAT12_ATTR_LFN ||
           (e.attribute & FAT12_ATTR_VOLUME))
            continue;
        fat12_short_to_text(e.filename, name, sizeof(name));
        de = (FAT12_DIRENT *)buf;
        memset(de, 0, sizeof(FAT12_DIRENT));
        de->d_ino = e.starting_cluster;
        de->d_off = (int)ord;
        de->d_reclen = sizeof(FAT12_DIRENT);
        de->d_type = (e.attribute & FAT12_ATTR_DIRECTORY) ? 4 : 8;
        strcpy(de->d_name, name);
        return sizeof(FAT12_DIRENT);
    }
    return 0;
}

int msdos_getfilesize_path(int dnr, const char *pathname, int db)
{
    MSDOSIO *m;
    FAT12_FILE_ENTRY e;
    (void)db;

    if(pathname == NULL || fat12_mount_dnr(dnr) != 0)
        return -1;
    m = fat12_state(dnr);
    if(!fat12_resolve_entry(m, pathname, &e, NULL, NULL))
        return -1;
    return (int)e.filesize;
}

int msdos_file_exists(int dnr, const char *pathname)
{
    MSDOSIO *m;
    if(pathname == NULL || fat12_mount_dnr(dnr) != 0)
        return 0;
    m = fat12_state(dnr);
    return fat12_resolve_entry(m, pathname, NULL, NULL, NULL);
}

int msdos_setsize(int dnr, const char *pathname, DWORD new_size)
{
    MSDOSIO *m;
    FAT12_FILE_ENTRY e;
    FAT12_DIRENT_LOC loc;
    DWORD cluster_size, need;
    WORD start;

    if(pathname == NULL || fat12_mount_dnr(dnr) != 0)
        return -1;
    m = fat12_state(dnr);
    if(!fat12_resolve_entry(m, pathname, &e, &loc, NULL))
        return -1;
    if(e.attribute & FAT12_ATTR_DIRECTORY)
        return -1;

    cluster_size = (DWORD)m->bytes_per_sector * m->sectors_per_cluster;
    need = new_size == 0 ? 0 : (new_size + cluster_size - 1) / cluster_size;
    start = e.starting_cluster;
    if(fat12_ensure_chain(m, &start, need) != 0)
        return -1;
    e.starting_cluster = start;
    e.filesize = new_size;
    if(fat12_write_dir_entry(m, &loc, &e) != 0)
        return -1;
    return msdos_flush_device(dnr);
}

int msdos_unlink_path(int dnr, const char *pathname)
{
    MSDOSIO *m;
    FAT12_FILE_ENTRY e;
    FAT12_DIRENT_LOC loc;

    if(pathname == NULL || fat12_mount_dnr(dnr) != 0)
        return -1;
    m = fat12_state(dnr);
    if(!fat12_resolve_entry(m, pathname, &e, &loc, NULL))
        return -1;
    if(e.attribute & FAT12_ATTR_DIRECTORY)
        return -1;
    if(e.starting_cluster != 0 && fat12_free_chain(m, e.starting_cluster) != 0)
        return -1;
    e.filename[0] = 0xe5;
    if(fat12_write_dir_entry(m, &loc, &e) != 0)
        return -1;
    return msdos_flush_device(dnr);
}

int msdos_mkdir_path(int dnr, const char *pathname)
{
    MSDOSIO *m;
    FAT12_FILE_ENTRY e, dot, dotdot;
    FAT12_DIRENT_LOC loc, dloc;
    WORD parent, cluster;
    BYTE leaf[11];

    if(pathname == NULL || fat12_mount_dnr(dnr) != 0)
        return -1;
    m = fat12_state(dnr);
    if(fat12_resolve_parent(m, pathname, &parent, leaf) != 0)
        return -1;
    if(fat12_find_in_dir(m, parent, leaf, NULL, NULL))
        return -1;
    if(fat12_find_free_dir_entry(m, parent, &loc) != 0)
        return -1;
    if(fat12_alloc_cluster(m, &cluster) != 0)
        return -1;

    memset(&e, 0, sizeof(e));
    memcpy(e.filename, leaf, 11);
    e.attribute = FAT12_ATTR_DIRECTORY;
    e.starting_cluster = cluster;
    if(fat12_write_dir_entry(m, &loc, &e) != 0)
        goto fail;

    memset(&dot, 0, sizeof(dot));
    fat12_make_short_name(".", dot.filename);
    dot.attribute = FAT12_ATTR_DIRECTORY;
    dot.starting_cluster = cluster;
    if(fat12_dir_entry_location(m, cluster, 0, &dloc) != 0 ||
       fat12_write_dir_entry(m, &dloc, &dot) != 0)
        goto fail_parent;

    memset(&dotdot, 0, sizeof(dotdot));
    fat12_make_short_name("..", dotdot.filename);
    dotdot.attribute = FAT12_ATTR_DIRECTORY;
    dotdot.starting_cluster = parent;
    if(fat12_dir_entry_location(m, cluster, 1, &dloc) != 0 ||
       fat12_write_dir_entry(m, &dloc, &dotdot) != 0)
        goto fail_parent;

    return msdos_flush_device(dnr);

fail_parent:
    e.filename[0] = 0xe5;
    fat12_write_dir_entry(m, &loc, &e);
fail:
    fat12_free_chain(m, cluster);
    msdos_flush_device(dnr);
    return -1;
}

