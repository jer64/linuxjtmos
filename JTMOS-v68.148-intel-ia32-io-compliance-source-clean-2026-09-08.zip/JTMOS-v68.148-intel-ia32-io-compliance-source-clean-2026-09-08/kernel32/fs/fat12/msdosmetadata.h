#ifndef __INCLUDED_MSDOSMETADATA_H__
#define __INCLUDED_MSDOSMETADATA_H__

#include "kernel32.h"

#define FAT12_MAX_DEVICES 200
#define FAT12_ROOT_CLUSTER 0

typedef struct
{
    int mounted;
    int dnr;
    int device_block_size;

    WORD bytes_per_sector;
    BYTE sectors_per_cluster;
    WORD reserved_sectors;
    BYTE fat_count;
    WORD root_entries;
    DWORD total_sectors;
    BYTE media_descriptor;
    WORD sectors_per_fat;

    DWORD root_dir_sectors;
    DWORD first_fat_sector;
    DWORD first_root_sector;
    DWORD first_data_sector;
    DWORD data_sectors;
    DWORD cluster_count;
    WORD max_cluster;

    DWORD fat_size_bytes;
    BYTE *fat;
    int fat_dirty;

    BYTE bootsector[512];
} MSDOSIO;

/* Generic metadata object retained for source compatibility. */
typedef struct
{
    int realized;
    char *buf;
    int l_buf;
    struct {
        int dnr,db;
    } focus;
} METADATA;

#endif
