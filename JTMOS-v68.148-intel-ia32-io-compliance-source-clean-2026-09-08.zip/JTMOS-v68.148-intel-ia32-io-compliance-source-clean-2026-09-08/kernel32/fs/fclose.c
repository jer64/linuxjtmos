#ifdef JTMOSKERNEL
#include "kernel32.h"
#include "filebuf.h"
#include "filedef.h"
#else
#include <stdio.h>
#endif

int fclose(FILE *stream)
{
    int rv=0;
    if(!stream) { errno=EINVAL; return EOF; }

    if(fflush(stream)==EOF) rv=EOF;
    if(stream->fd>=0)
    {
        if(close(stream->fd)<0) rv=EOF;
        stream->fd=-1;
    }
    if(stream->buf) { free(stream->buf); stream->buf=NULL; }
    free(stream);
    return rv;
}
