// ===================================================================
// filedes.c - FILE DESCRIPTOR DATABASE
// (C) 2002-2008 by Jari Tuominen
// ===================================================================
#include "basdef.h"
#include "kernel32.h"
#include "filedes.h"

//
FDDB fddb;

/* Linux/POSIX-style descriptor lifetime bookkeeping.
 * JTMOS keeps descriptor numbers in one kernel-wide table, but a descriptor
 * may be referenced by more than one process after fork().  The owner bitmap
 * keeps the historical table while adding shared-open-file lifetime semantics. */
static BYTE fd_owner_refs[N_MAX_FD][N_MAX_THREADS];
static WORD fd_refcounts[N_MAX_FD];

#if defined(__GNUC__)
extern void LinuxFdOwnerAdded(int fd, int pid) __attribute__((weak));
extern void LinuxFdOwnerReleased(int fd, int pid) __attribute__((weak));
extern void KernelFileBufFdClosing(int fd) __attribute__((weak));
#endif

static void fd_reset_refs(int fd)
{
    if(fd < 0 || fd >= N_MAX_FD) return;
    memset(fd_owner_refs[fd], 0, N_MAX_THREADS);
    fd_refcounts[fd] = 0;
}

int fd_add_owner(int fd, int pid)
{
    if(fd < 0 || fd >= N_MAX_FD || pid < 0 || pid >= N_MAX_THREADS) return -1;
    if(fd_owner_refs[fd][pid]) return 0;
    fd_owner_refs[fd][pid] = 1;
    if(fd_refcounts[fd] < 0xffffU) fd_refcounts[fd]++;
#if defined(__GNUC__)
    if(LinuxFdOwnerAdded) LinuxFdOwnerAdded(fd,pid);
#endif
    return 0;
}

int fd_has_owner(int fd, int pid)
{
    if(fd < 0 || fd >= N_MAX_FD || pid < 0 || pid >= N_MAX_THREADS) return 0;
    return fd_owner_refs[fd][pid] != 0;
}

int fd_get_refcount(int fd)
{
    if(fd < 0 || fd >= N_MAX_FD) return 0;
    return (int)fd_refcounts[fd];
}

int fd_inherit_process(int parent_pid, int child_pid)
{
    int fd, n = 0;
    if(parent_pid < 0 || parent_pid >= N_MAX_THREADS ||
       child_pid < 0 || child_pid >= N_MAX_THREADS) return -1;
    for(fd = 3; fd < N_MAX_FD; ++fd)
        if(!fddb.fd[fd]->isFree && fd_owner_refs[fd][parent_pid])
        {
            if(fd_add_owner(fd, child_pid) == 0) n++;
        }
    return n;
}

// New FILEDES, returns PTR to a FILEDES structure.
FILEDES *NewFD(void)
{
	int fd;

	//
	fd = new_filedes();
	return get_filedesptr(fd);
}

// Free a file descriptor
int FreeFD(int fd)
{
    FILEDES *f;
    int pid;

    /* 0/1/2 are permanent process ABI descriptors. */
    if(fd <= 2 || fd >= N_MAX_FD) return 1;
    f = fddb.fd[fd];
    if(f == NULL || f->isFree) return 1;

    pid = GetCurrentThread();
    if(pid >= 0 && pid < N_MAX_THREADS && fd_owner_refs[fd][pid])
    {
        #if defined(__GNUC__)
        if(LinuxFdOwnerReleased) LinuxFdOwnerReleased(fd,pid);
#endif
        fd_owner_refs[fd][pid] = 0;
        if(fd_refcounts[fd]) fd_refcounts[fd]--;
    }
    else if(fd_refcounts[fd] == 0)
    {
        /* Legacy/kernel-created descriptor without registered ownership. */
    }
    else
        return 1;

    if(fd_refcounts[fd] != 0)
        return 0;

#if defined(__GNUC__)
    if(KernelFileBufFdClosing) KernelFileBufFdClosing(fd);
#endif
    memset(f, 0, sizeof(*f));
    f->fd = fd;
    f->isFree = TRUE;
    fd_reset_refs(fd);
    return 0;
}

void changeFDOwner(int fd, int pid)
{
    int i;
    if(!isValidFD(fd) || pid < 0 || pid >= N_MAX_THREADS) return;
    fd_reset_refs(fd);
    for(i=0;i<N_MAX_THREADS;i++) fd_owner_refs[fd][i]=0;
    fd_add_owner(fd,pid);
    fddb.fd[fd]->op = pid;
}

//
FILEDES *get_filedesptr(int fd)
{
	//
	if( isValidFD(fd) )
	{
		//
		return fddb.fd[fd];
	}
	else	return NULL;
}

// Check that file descriptor is valid.
// 0=invalid, 1=valid
int isValidFD(int fd)
{
	int i,i2,i3,i4;

	// Out of range?
	if(fd>=N_MAX_FD || fd<0)return 0;

        // Freed one?
	if(fddb.fd[fd]->isFree)return 0;

        // Valid.
        return 1;
}

//
void filedesInformation(void)
{
	int i,r,f;

	//
	printk("--: FILEDES information\n");
	printk("Total %d entries reserved:\n", fddb.amount);
	for(i=0,r=0,f=0; i<fddb.amount; i++)
	{
		if(fddb.fd[i]->isFree)
			f++;
			else
			r++;
	}
	printk("%d entries are free\n",		f);
	printk("%d entries are allocated\n", 	r);
}

//
void init_filedes(void)
{
	int i,i2,i3,i4,nullfd;

	//
	fddb.amount =	0;
	fddb.fd =	malloc(8*N_MAX_FD);

	//
	for(i=0; i<N_MAX_FD; i++)
	{
		//
		fddb.fd[i] =		malloc(sizeof(FILEDES));
		memset(fddb.fd[i], 0, sizeof(FILEDES));
		fddb.fd[i]->isFree =	1;
		fddb.fd[i]->fd =	i;
		fd_reset_refs(i);
	}

	/* Reserve the POSIX/JTMOS standard descriptor numbers permanently.
	 * The syscall layer handles their console semantics directly.  Keeping
	 * them occupied also guarantees that the first real file is fd 3, so
	 * libc stdout/stderr can never alias an opened JTMFS file. */
	nullfd = new_filedes(); /* fd 0: stdin  */
	(void)new_filedes();    /* fd 1: stdout */
	(void)new_filedes();    /* fd 2: stderr */
	fddb.fd[0]->op = -1;
	fddb.fd[1]->op = -1;
	fddb.fd[2]->op = -1;
}

// deallocate_proc_filedes(pid)
// Deallocates all filedescriptors that
// belong to the specified pid.
// Return value:
// Amount of entries deallocated totally.
int deallocate_proc_filedes(int pid)
{
    return fd_release_process(pid);
}

int fd_release_process(int pid)
{
    int fd, n=0;
    if(pid < 0 || pid >= N_MAX_THREADS) return 0;
    for(fd=3; fd<N_MAX_FD; ++fd)
    {
        FILEDES *f=fddb.fd[fd];
        if(f==NULL || f->isFree || !fd_owner_refs[fd][pid]) continue;
#if defined(__GNUC__)
        if(LinuxFdOwnerReleased) LinuxFdOwnerReleased(fd,pid);
#endif
        fd_owner_refs[fd][pid]=0;
        if(fd_refcounts[fd]) fd_refcounts[fd]--;
        if(fd_refcounts[fd]==0)
        {
#if defined(__GNUC__)
            if(KernelFileBufFdClosing) KernelFileBufFdClosing(fd);
#endif
            memset(f,0,sizeof(*f));
            f->fd=fd;
            f->isFree=TRUE;
            fd_reset_refs(fd);
        }
        n++;
    }
    return n;
}


//
int new_filedes(void)
{
	int i,i2,i3,i4,entry;

	// Search for free entry.
	for(i=0,entry=-1; i<fddb.amount; i++)
	{
		// Got free entry?
		if( fddb.fd[i]->isFree )
		{
			// Reset structure
			memset(fddb.fd[i], 0, sizeof(FILEDES));
			// Set FD code
			fddb.fd[i]->fd = i;
			// Set entry as occupied
			fddb.fd[i]->isFree = FALSE;
			// Set owner PID
			fddb.fd[i]->op = GetCurrentThread();
			fd_reset_refs(i);
			(void)fd_add_owner(i, GetCurrentThread());
			return i;
		}
	}

	// Already ran out of entries?
	if( (fddb.amount+1)>=N_MAX_FD )
		return -1;

	// Allocate new entry.
	entry=fddb.amount;
	fddb.amount++;
	fddb.fd[entry]->isFree = FALSE;
	fddb.fd[entry]->op = GetCurrentThread();
	fddb.fd[entry]->fd = entry;
	fd_reset_refs(entry);
	(void)fd_add_owner(entry, GetCurrentThread());
	return entry;
}

// Returns 0 if no free entry was found.
// Otherwise returns the entry number.
int NEW_FILE_DESCRIPTOR(void *path, void *p1,void *p2, int v1,int v2)
{
	static int i,i2,i3,i4;

	//
	disable();
	i = new_filedes();
	enable();

	//
	if(!i) return 0;

	//
	return i;
}


