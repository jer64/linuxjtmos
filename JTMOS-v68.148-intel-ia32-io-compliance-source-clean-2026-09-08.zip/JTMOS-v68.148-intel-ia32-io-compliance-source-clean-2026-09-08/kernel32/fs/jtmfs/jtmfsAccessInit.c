// jtmfsAccessInit.c
#include "kernel32.h"
#include "jtmfat.h" // getfreeblock
#include "jtmfs.h" // comes with fileapi as well
#include "ramdisk.h" // default_ramdisk
#include "fsdos.h"
#include "fname_translation.h" // tell_fname
#include "root.h"
#include "jtmfsAccessInit.h"

// Initializes kernel fileapi
//
void jtmfsAccessInit(void)
{
	// Init structure
	memset(&jtmfsAccess, 0, sizeof(JTMFSACCESS));

	// Path
	jtmfsAccess.path = malloc(1024*4);
	if(jtmfsAccess.path!=NULL)
		jtmfsAccess.path[0]=0;
	else
		printk("jtmfsAccessInit: unable to allocate current-path buffer.\n");

	// Temporary buffers for block access.
	jtmfsAccess.rwtmp = malloc(1024*64);
	jtmfsAccess.rwtmp2 = malloc(1024*64);
	if(jtmfsAccess.rwtmp==NULL || jtmfsAccess.rwtmp2==NULL)
		printk("jtmfsAccessInit: unable to allocate filesystem I/O scratch buffers; file I/O will fail safely.\n");

	//
	jtmfsAccess.dnr = driver_getdevicenrbyname("ram");
}


