// ======================================================================================
// jtmfsAccess.c - JTMOS File System functions for Postman.
//
// (C) 2002-2005 Jari Tuominen(jari@vunet.org).
//
// jtmfs_ functions now do file name translation,
// which includes device detection.
//
// int jtmfs_CreateFile(const char *devname,const char *fname,int blocks);
// jtmfs_DeleteFile dnr, name, db
// jtmfs_ReadFile dnr, name, db
// jtmfs_WriteFile dnr, name, db
// jtmfs_RenameFile dnr,
//		OldName, NewName,
//		db
// jtmfs_AddBlocks dnr, fname, db, amount
// ======================================================================================
#include "kernel32.h"
#include "jtmfat.h" // getfreeblock
#include "jtmfs.h" // comes with jtmfsAccess as well
#include "ramdisk.h" // default_ramdisk
#include "fsdos.h"
#include "fname_translation.h" // tell_fname
#include "root.h"
#include "jtmfsAccess.h"
#include "jtmfsPath.h"
#include "ReadChain.h"
#include "WriteChain.h"
#include "fsaddblocks.h"
#include "diskspace.h"
#include "filedir.h"

//
JTMFSACCESS jtmfsAccess;

// Get a thread's current work directory.
// DNR/DB is authoritative; the printable path is cached by namespace generation.
int jtmfs_GetThreadCWD(int pid, char *path, int max_len)
{
    int rv,dnr,db;
    DWORD generation;

    if(path==NULL || max_len<=0)
        return JTMFS_PATH_EINVAL;

    generation=FileDirPathGeneration();
    if(GetThreadCWDCache(pid,generation,path,max_len)==0)
        return JTMFS_PATH_OK;

    dnr=GetThreadDNR(pid);
    db=GetThreadDB(pid);
    rv=jtmfsBuildPath(dnr,db,path,max_len);
    if(rv)
    {
        path[0]=0;
        dprintk("%s: unable to build path for PID%d DNR/DB=%d/%d (rv=%d).\n",
                __FUNCTION__,pid,dnr,db,rv);
        return rv;
    }

    (void)SetThreadCWDCache(pid,path,generation);
    return JTMFS_PATH_OK;
}

int jtmfs_GetCWD(char *path, int max_len)
{
    return jtmfs_GetThreadCWD(GetCurrentThread(),path,max_len);
}

// TRUE =	Drive is formatted and works properly.
// FALSE =	Drive is not formatted.
int jtmfs_isDriveReady(int dnr)
{
	//
	if(!isValidDevice(dnr))
		return FALSE;
	return jtmfat_isJTMFS(dnr);
}

// jtmfs_GetDirName dnr db name
// Converts DNR/DB to directory name.
// Stores directory name in string pointed by name.
// Zero = success.
// Non-zero = error.
int jtmfs_GetDirName(int dnr,int db, char *name)
{
	static DIRWALK dw;

	// int dirdb_GetDirName(int dnr,int db, char *dest_name)
	if( dirdb_GetDirName(dnr,db, name) )
	{
		return 0;
	}
	else
	{
		// Dir name could not been resolved.
		strcpy(name, "");
		return 1;
	}
}

//
int jtmfs_GetFileDataBlock(int dnr, int db, const char *name)
{
	DIRWALK dw;
	RESOLVE r;

	//
	DEBUGLINE

	//
	if( !isValidString(name) )	return 0;

	//
	if(resolveFileNamePath(name, &dnr, &db, &r)) return 0;
	memset(&dw, 0, sizeof(dw));
	if(!jtmfs_ffindfile(dnr, r.name, db, &dw) || dw.fe==NULL) return 0;
	return dw.fe->FirstDataBlock;
}

//
int jtmfs_DeleteFile(int dnr, const char *name, int db)
{
	RESOLVE r;

	//
	DEBUGLINE

	//
	if( !isValidString(name) )	return 1;

	//
	if(resolveFileNamePath(name, &dnr, &db, &r)) return 1;
	// Not valid device?
	if( !isOK(dnr)  ) return 1;

	//
	{
        int rv=jtmfs_deletefile(dnr, r.name, db);
        /* Deletion may remove a directory entry through legacy callers.
         * Invalidate printable cwd caches conservatively even for files. */
        if(rv==0) FileDirNamespaceChanged();
        return rv;
    }
}

// jtmfs_CreateFile [dnr] [file name] [number of blocks to allocate]
//
// Non-zero = error
// Zero = no error
//
// Possible return values
// 1: Creation of file structure failed or file name not legal
// ....
//
// New: If file already exists by the name, it'll be deleted.
//
// "devname" can be acquired by f.e. driver_getdevicenrbyname(syssh.str_device).
// When "blocks" -parameter equals zero, no blocks will be added.
// Function is not multitasking capable.
//
int jtmfs_CreateFile(int dnr,int db,
		const char *name,int blocks)
{
	JTMFS_FILE_ENTRY fe;
	int i,i2,i3,i4,rv;
	RESOLVE r;

	//
	DEBUGLINE

	//
	if( !isValidString(name) )	return 10;

	//
	if(name==NULL)return 11;

	//
	if(resolveFileNamePath(name, &dnr, &db, &r)) return 1;

	//
	dprintk("%s: Device validity check.\n", __FUNCTION__);
	// Not valid device?
	if( !isOK(dnr) )
		return 1986;

	//
	dprintk("%s: Entry creation.\n", __FUNCTION__);
	//
	if( jtmfs_fentry(&fe,
	       r.name,0,0,
	       0,0,
	       0,0,0,
	       0,0) )
	{
		return 12;
	}

	//
	for(i=0; i<2; i++)
	{
		//
		dprintk("%s: Adding entry                \r", __FUNCTION__);
		//
		if( (rv=jtmfs_adddirentry(dnr, db, &fe))==10 )
		{
			//
			dprintk("%s: File '%s' already exists, replacing.\n",
				__FUNCTION__, fe.name);
			// Aha, file already exists? => Delete.
			if( jtmfs_DeleteFile(dnr, r.name, db) )return 1;
			continue;
		}
		if(rv)
			// Creation failed.
			return 100;
		break;
	}

	// Assign some blocks for it(grow up it's chain=file size).
	// But don't add any blocks if blocks equals zero.
	if(blocks)
	{
		dprintk("%s: jtmfs_add_blocks_for_entry       \r", __FUNCTION__);
		rv=jtmfs_add_blocks_for_entry(dnr,r.name,db,blocks);
		if(rv)
		{
			dprintk("%s: block allocation failed for '%s' (rv=%d).\n",
			         __FUNCTION__,r.name,rv);
			/* Keep the historical public ABI: CreateFile uses 10 for ENOSPC. */
			if(rv==JTMFS_RESERVE_NOSPC) return 10;
			return 13;
		}
	}

	//
	dprintk("\n%s: Work done here.\n", __FUNCTION__);

	//
	return 0;
}

//
int jtmfs_LastBlock(DWORD block)
{
	//
	if(block>=0xFFFFFFF0)return 1;
	return 0;
}

// Return value:
// 0 =		Success
// Non-zero =	Error
// -1 =		File not found.
//
// Returns size of the specified file in bytes.
int jtmfs_GetFileSize(int dnr, const char *fname, int db)
{
	RESOLVE r;
	int d1;

	//
	DEBUGLINE

	//
	if( !isValidString(fname) )	return 1;

	//--------------------------------------------------------
	// Is it a device?
	if( (d1=driver_getdevicenrbyname(fname))!=-1 )
	{
		// Get device size in bytes and set it as return value
		return	getblocksize(d1)*getsize(d1);
	}

	//
	if(resolveFileNamePath(fname, &dnr, &db, &r)) return 0;

	// Not valid device?
	if( !isOK(dnr) )
	{
		dprintk("%s: Invalid device %d\n",
			__FUNCTION__, dnr);
		return 0;
	}

	return jtmfs_getfilesize(dnr,r.name,db);
}

// Write data to file (length, offset)
static int jtmfs_WriteFileUnlocked(int dnr,
            const char *name,int db,
            BYTE *buf, char showMeter,
            int preciseLength,
            int offset)
{
    DWORD d,endpos;
    int rv,bs,required_blocks;
    DIRWALK dw;
    RESOLVE r;

    DEBUGLINE

    if(name==NULL || !isValidString(name)) return 1;
    if(buf==NULL || preciseLength<0 || offset<0) return 1;
    if(preciseLength==0) return 0;

    if(resolveFileNamePath(name, &dnr, &db, &r)) return 1;
    if(!isOK(dnr)) return 10;

    bs=(int)jtmfat_unitsize(dnr);
    if(bs<=0) return 10;
    endpos=(DWORD)(unsigned)offset + (DWORD)(unsigned)preciseLength;
    if(endpos<(DWORD)(unsigned)offset || endpos>0x7fffffffUL) return 1;
    required_blocks=(int)((endpos+(DWORD)bs-1U)/(DWORD)bs);
    if(required_blocks<=0) return 1;

    /* Reserve the complete destination span before data I/O.  Capacity is
     * hidden behind the old exact byte length, so no stale bytes become
     * visible and WriteFileChainEx can batch already-existing contiguous
     * clusters instead of allocating/zeroing one cluster at a time. */
    rv=jtmfs_reserve_blocks_for_write(dnr,r.name,db,required_blocks);
    if(rv) {
        ReportMessage("%s: reserve-for-write failed (%s, blocks=%d, rv=%d)\n",
                      __FUNCTION__,r.name,required_blocks,rv);
        if(rv==JTMFS_RESERVE_NOSPC) {
            DiskSpaceNoteENOSPC(dnr,"file write reservation",(DWORD)preciseLength);
            return 2;
        }
        return 3;
    }

    InitDW(&dw);
    if(!jtmfs_ffindfile(dnr,r.name,db,&dw) || dw.fe==NULL) {
        EndDirWalk(&dw);
        return 1;
    }
    d=dw.fe->FirstDataBlock;
    EndDirWalk(&dw);
    if(d==0 || !jtmfat_isdatablock(dnr,d)) return 3;

    ReportMessage(" -- jtmfs_WriteFileChain:\n");
    return jtmfs_WriteFileChain(buf,dnr,(int)d,preciseLength,offset);
}

/* Public writer serialized with resize on the resolved device.  The unlocked
 * implementation may recurse through block-allocation helpers safely. */
int jtmfs_WriteFile(int dnr, const char *name, int db, BYTE *buf, char showMeter,
                    int preciseLength, int offset)
{
    int rd=dnr,rdb=db,rv;
    RESOLVE rr;
    if(name==NULL || !isValidString(name)) return 1;
    if(resolveFileNamePath(name,&rd,&rdb,&rr)) return 1;
    if(!isOK(rd)) return 10;
    jtmfs_mutation_lock(rd);
    rv=jtmfs_WriteFileUnlocked(dnr,name,db,buf,showMeter,preciseLength,offset);
    jtmfs_mutation_unlock(rd);
    return rv;
}

// Reads specified amount of blocks from the specified file
int _jtmfs_ReadFile(const char *caller,
			int dnr, const char *name,
			int db,
                        BYTE *buf, char showMeter,
			int preciseLength,
			int offset)
{
	int i,i2,i3,i4,d,newd,ii,ii2,ii3,ii4,offs;
	DIRWALK dw;
	char *tmp;
	RESOLVE r;

	//
	dprintk("%s was called by %s\n",
		__FUNCTION__, caller);

	//
	FFCHECK

	/* Do not touch device geometry before validating/resolving the request.
	 * The old unused estimate divided by getblocksize(dnr) here and could
	 * raise #DE for an invalid/uninitialized DNR. */
	if(name==NULL || !isValidString(name)) return 1;
	if(buf==NULL || preciseLength<0 || offset<0) return 1;
	if(preciseLength==0) return 0;

	//
	FFCHECK

	//
	tmp = jtmfsAccess.rwtmp;
	if(tmp==NULL) return 1;

	//
	FFCHECK

	//
	DEBUGLINE

	//
	FFCHECK

	// name was validated before touching device geometry.
	FFCHECK

	//
	if(resolveFileNamePath(name, &dnr, &db, &r)) return 1;

	//
	FFCHECK

	// Not valid device?
	if( !isOK(dnr) ) return 10;

	//
	FFCHECK

	//
	if( !jtmfs_ffindfile(dnr, r.name, db, &dw) )
	{
		// Not found => We don't create one here, return 1.
		return 1;
	}

	//
	FFCHECK

	// Get data block
	if(dw.fe==NULL) return 1;
	d = dw.fe->FirstDataBlock;

	//
	return jtmfs_ReadFileChain(buf, dnr, d,
		preciseLength,
		offset);
}

// Return value:
// 0 = OK
// 1 = Error
int jtmfs_AddBlocks(int dnr, const char *name, int db, int amount)
{
	RESOLVE r;

	//
	DEBUGLINE

	//
	if( !isValidString(name) )	return 1;

	//
	if(resolveFileNamePath(name, &dnr, &db, &r)) return 1;
	if( !isOK(dnr) )	return 1;

	// Propagate allocation/metadata errors instead of always reporting success.
	return jtmfs_add_blocks_for_entry(dnr,r.name,db,amount);
}

// File existance checker.
int jtmfs_Fexist(int dnr, const char *name, int db)
{
	RESOLVE r;

	//
	DEBUGLINE

	//
/*	printk("%s: loc=%d/%d, name=%s.\n",
		__FUNCTION__, dnr,db, name);*/

	//
	if( !isValidString(name) )
	{
		printk("%s: Name is invaldi string.\n",
			__FUNCTION__);
		return 0;
	}

	//
	if(resolveFileNamePath(name, &dnr, &db, &r)) return 0;
	if( !isOK(dnr) )
	{
		printk("%s: File system is invalid for loc %d/%d.\n",
			__FUNCTION__, dnr,db);
		return 0;
	}

	//
/*	printk("%s: Calling jtmfs_fexist with jtmfs_exist(%d, %s, %d);\n",
		__FUNCTION__, dnr, r.name, db);*/

	//
	return jtmfs_fexist(dnr, r.name, db);
}

// Set file fixed size (in bytes).
int jtmfs_SetSize(int dnr,
		const char *name, int newSize,
		int db)
{
	RESOLVE r;

	//
	DEBUGLINE

	//
	if( !isValidString(name) )	return 1;

	//
	if(resolveFileNamePath(name, &dnr, &db, &r)) return 1;
	if( !isOK(dnr) )	return 1;

	/* Shared with writers so truncate/grow cannot race a concurrent write. */
	jtmfs_mutation_lock(dnr);
	{
		int resize_rv=jtmfs_setsize(dnr, r.name, newSize, db);
		jtmfs_mutation_unlock(dnr);
		return resize_rv;
	}
}

/* Commit the exact visible EOF after data has already been written.
 * Unlike truncate growth this must not zero the newly written range. */
int jtmfs_SetSizeAfterWrite(int dnr,
        const char *name, int newSize,
        int db)
{
    RESOLVE r;
    int rv;

    if(!isValidString(name) || newSize<0) return 1;
    if(resolveFileNamePath(name,&dnr,&db,&r)) return 1;
    if(!isOK(dnr)) return 1;

    jtmfs_mutation_lock(dnr);
    rv=jtmfs_setsize_after_write(dnr,r.name,newSize,db);
    jtmfs_mutation_unlock(dnr);
    return rv;
}

//
int jtmfs_RenameFile(int dnr,
        const char *OldName, const char *NewName,
        int db)
{
    RESOLVE rOLD;
    RESOLVE rNEW;
    int old_dnr, old_db, new_dnr, new_db;

    DEBUGLINE

    if(!isValidString(OldName) || !isValidString(NewName))
        return 1;

    old_dnr=dnr;
    old_db=db;
    new_dnr=dnr;
    new_db=db;

    if(resolveFileNamePath(OldName, &old_dnr, &old_db, &rOLD))
        return 1;
    if(resolveFileNamePath(NewName, &new_dnr, &new_db, &rNEW))
        return 1;

    if(!isOK(old_dnr) || old_dnr!=new_dnr || old_db!=new_db)
        return 1; /* rename does not move files between directories */

    {
        int rv=jtmfs_renamefile(old_dnr, rOLD.name, rNEW.name, old_db);
        if(rv==0) FileDirNamespaceChanged();
        return rv;
    }
}

//
DWORD GetCurrentDrive(void)
{
	DEBUGLINE
	return scall(SYS_GETCURDEV, 0,0,0, 0,0,0);
}

// chdir wrapper
int IntelligentCHDIR(const char *path)
{
	DEBUGLINE
	return jtmfs_chdir(path);
}

// Used by the system call "chdir"
// Return value:
// Zero = success.
// Non-zero = error.
int jtmfs_chdir(const char *pathi)
{
    int dnr, db, rv;

    if(pathi==NULL) return 3;
    if(!strlen(pathi)) return 4;
    if(!isValidString(pathi)) return 5;

    rv=jtmfsResolvePathAt(GetCurrentDNR(), GetCurrentDB(),
                          pathi, &dnr, &db);
    if(rv)
    {
        dprintk("%s: unable to resolve '%s' (rv=%d).\n",
                __FUNCTION__, pathi, rv);
        return 1;
    }

    /* Commit DNR/DB as one cwd identity.  Then prime the printable cache once;
     * getcwd() will not need a reverse walk until the namespace generation
     * changes (for example after rename). */
    SetThreadCWDContext(GetCurrentThread(), dnr, db);
    {
        char canonical[JTMFS_PATH_MAX];
        if(jtmfsBuildPath(dnr,db,canonical,sizeof(canonical))==JTMFS_PATH_OK)
            (void)SetThreadCWDCache(GetCurrentThread(),canonical,FileDirPathGeneration());
    }
    return 0;
}

/* Compatibility entry point.  It now has the same atomic semantics. */
int _jtmfs_chdir(const char *pathi)
{
    return jtmfs_chdir(pathi);
}

// [parent_db]
//     |
//     \____[target_db]
//
int jtmfs_CreateDirectory(int dnr,int db, const char *dirname)
{
    JTMFS_FILE_ENTRY e;
    int newBlock, rv;
    RESOLVE r;

    DEBUGLINE

    if(!isValidString(dirname)) return 5;
    if(resolveFileNamePath(dirname, &dnr, &db, &r)) return 5;
    if(!isOK(dnr)) return 1;

    /* Reject only a real on-disk/DIRDB duplicate before reserving a FAT
     * block.  Do not use jtmfs_fexist() here: historical versions treated
     * any registered device name (hda, cdrom, sys, ...) as an implicit
     * directory even when no directory entry existed. */
    {
        DIRWALK existing;
        InitDW(&existing);
        if(jtmfs_ffindfile(dnr, r.name, db, &existing))
        {
            EndDirWalk(&existing);
            return 7;
        }
        EndDirWalk(&existing);
    }

    newBlock=jtmfat_reserveblock(dnr);
    if(newBlock==-1) return 10; /* ENOSPC */
    if(newBlock<=0 || (DWORD)newBlock>=jtmfat_unitcount(dnr)) return 2;

    /* The child owns a private standalone EOC reservation before any data is
     * written.  It is not reachable from the parent until adddirentry(). */
    if((DWORD)jtmfat_getblock(dnr,newBlock)<0xFFFFFFF8UL)
    {
        printk("jtmfs_CreateDirectory: reservation was lost for block %d.\n",newBlock);
        (void)jtmfat_setblock(dnr,newBlock,0);
        return 3;
    }

    /* Materialise the child directory before publishing it in the parent. */
    rv=jtmfs_createdirectory(dnr, newBlock, db, r.name);
    if(rv)
    {
        /* jtmfs_createdirectory() normally leaves FAT free on a pre-EOC
         * failure.  Be defensive in case a later failure happens after FAT
         * publication. */
        if((DWORD)jtmfat_getblock(dnr,newBlock)>=0xFFFFFFF8UL)
            (void)jtmfat_setblock(dnr,newBlock,0);
        return 6;
    }

    jtmfs_cedir(&e, r.name, newBlock, 0);
    rv=jtmfs_adddirentry(dnr, db, &e);
    if(rv)
    {
        /* The child is not reachable yet, so rollback its private FAT node. */
        (void)jtmfat_setblock(dnr, newBlock, 0);
        dirdb_clearCacheForDB(dnr,newBlock);
        return 4;
    }

    FileDirNamespaceChanged();
    return 0;
}

// Reads FAT tables at the start up
void jtmfs_PreloadFATS(void)
{
	int dnr;

	//
	DEBUGLINE

	//
	dnr = driver_getdevicenrbyname("hda");
	//if(dnr!=-1)	driver_TriggerCacheActivation(dnr);
	dnr = driver_getdevicenrbyname("ram");
	//if(dnr!=-1)	driver_TriggerCacheActivation(dnr);
}

//

