/* ========================================================================
 * jtmfat.c - JTMOS FAT is part of the JTMOS File System(JTMFS) package
 * This file contains only parts of JTMFAT, see flexFat.* for more.
 * (C) 2001-2021 by Jari Tuominen(jari.t.tuominen@gmail.com).
 * ========================================================================
 */
 
/*
 * [FAT]       (FILE ALLOCATION TABLE)
 * |
 * V
 * [DATA AREA] (FILESYSTEM/OTHER DATA)
 *
 *
 *
 * FAT TABLE(32-bit)
 *
 * 00000000		empty place
 * FFFFFFF1-FFFFFFF6	bad track marking
 * FFFFFFF7		system reserved area(BOOTSECTOR & FAT ..)
 * FFFFFFF8		used to mark end of a file chain
 * FFFFFFFF		standard marker for end of a file chain
 * (!) Last cluster of a file always
 * contains a value of FFFFFFF8-FFFFFFFF.
 *
 * Ramdisks have got a standard sector
 * size of 1KB, 3.5" 1.44M floppys 512(�KB) bytes.
 */

//
#include "kernel32.h"
#include "rtc.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
//
#include "jtmfs.h"
// ---- #include "fileapi.h"
#include "ramdisk.h"
#include "jtmfat.h"
#include "dirdbAccess.h"
#include "diskspace.h"
#include "createfat.h"

//
int findfreeblock_last_block_nr=-1,
	EntranceGetrootdir=0;

/* V68.117: allocation is a per-device transaction.  The old single cursor and
 * locator-then-publish sequence allowed two preempted tasks to claim the same
 * FAT entry.  Keep one cursor and one re-entrant cooperative lock per DNR. */
static int findfreeblock_last_by_dnr[N_CFAT_STRUCTURES];
static volatile int jtmfat_alloc_owner[N_CFAT_STRUCTURES];
static volatile unsigned long jtmfat_alloc_depth[N_CFAT_STRUCTURES];
//
char *TMPSPACE1=NULL, *BOOT_TMP_BUF=NULL;
//
JTMFATSYS *fatsys;
// Set to TRUE after jtmfat is ready to be used
int jtmfat_ready=FALSE;
//
USE_DEBUGTRAP

/* JTMFATSYS and FlexFAT both have fixed 100-device tables.  DEVAPI device
 * numbers must be range-checked before indexing either table. */
static int jtmfat_valid_slot(int dnr)
{
	return dnr>=0 && dnr<N_CFAT_STRUCTURES && isValidDevice(dnr);
}

int jtmfat_info_location(int dnr, int *block_nr, int *byte_offs)
{
	int bs,b,o;
	if(!jtmfat_valid_slot(dnr) || block_nr==NULL || byte_offs==NULL) return 1;
	bs=getblocksize(dnr);
	if(bs<=0) return 2;
	b=FAT_INFO_BYTE_OFFS/bs;
	o=FAT_INFO_BYTE_OFFS%bs;
	if(o+(int)sizeof(JTMFAT_INFOBLOCK)>bs)
	{
		printk("JTMFS: info record crosses device block DNR=%d bs=%d off=%d info=%d.\n",
		       dnr,bs,o,(int)sizeof(JTMFAT_INFOBLOCK));
		return 3;
	}
	if(b<0 || b>=getsize(dnr)) return 4;
	*block_nr=b; *byte_offs=o;
	return 0;
}


/* V16.24 allocation-unit helpers.  New clustered volumes use FAT/file chain
 * IDs as cluster ordinals while DEVAPI remains 512/1K/etc physical blocks.
 * Legacy volumes keep identity mapping.
 *
 * V16.53: clustering is filesystem geometry and is deliberately independent
 * of JTMFS_BOOT_LAYOUT_TAG.  hda1/hda2 are valid clustered filesystems even
 * when they contain no BIOS boot payload. */
int jtmfat_infoblock_uses_clusters(const JTMFAT_INFOBLOCK *inf)
{
    return inf!=NULL &&
           inf->res5>=JTMFS_CLUSTER_LAYOUT_VERSION &&
           inf->res6>1;
}

/* V68.143: new mkfs volumes may leave the untouched tail of the FAT physically
 * stale.  The persisted materialized-prefix count makes that safe across
 * reboot: any FAT sector at or beyond the prefix is defined as logical zero. */
int jtmfat_infoblock_uses_lazyfat(const JTMFAT_INFOBLOCK *inf)
{
    if(inf==NULL) return 0;
    if(inf->res5<JTMFS_LAZY_FAT_LAYOUT_VERSION) return 0;
    if((inf->fatChecksum32 & JTMFS_LAZY_FAT_FLAG)==0) return 0;
    if((inf->fatChecksum32 & JTMFS_LAZY_FAT_PAGE_MASK)>inf->fat_length) return 0;
    return 1;
}

DWORD jtmfat_lazyfat_materialized_pages(const JTMFAT_INFOBLOCK *inf)
{
    if(!jtmfat_infoblock_uses_lazyfat(inf)) return 0;
    return inf->fatChecksum32 & JTMFS_LAZY_FAT_PAGE_MASK;
}

/* Persist an extended lazy-FAT prefix only after those FAT pages have already
 * reached the physical medium.  If metadata commit fails, restore the old
 * in-memory state: after reboot the newly written pages are intentionally
 * ignored and therefore cannot resurrect stale allocations. */
int jtmfat_lazyfat_set_materialized_pages(int dnr, DWORD pages)
{
    JTMFAT_INFOBLOCK *inf;
    DWORD old;
    int rv;

    if(!jtmfat_valid_slot(dnr) || fatsys==NULL || fatsys->bb[dnr]==NULL) return 1;
    inf=fatsys->bb[dnr];
    if(!jtmfat_infoblock_uses_lazyfat(inf)) return 0;
    if(pages>inf->fat_length || pages>JTMFS_LAZY_FAT_PAGE_MASK) return 2;
    if(pages<=jtmfat_lazyfat_materialized_pages(inf)) return 0;

    old=inf->fatChecksum32;
    inf->fatChecksum32=JTMFS_LAZY_FAT_FLAG|pages;
    rv=WriteInformationBlock(dnr,inf);
    if(rv)
    {
        inf->fatChecksum32=old;
        dprintk("JTMFS/lazy-FAT: DNR=%d failed to persist materialized prefix=%u pages rv=%d.\n",
                dnr,(unsigned)pages,rv);
        return rv;
    }
    dprintk("JTMFS/lazy-FAT: DNR=%d materialized prefix advanced to %u/%u FAT pages.\n",
            dnr,(unsigned)pages,(unsigned)inf->fat_length);
    return 0;
}

int jtmfat_isclustered(int dnr)
{
    JTMFAT_INFOBLOCK *inf;
    if(!jtmfat_valid_slot(dnr) || fatsys==NULL || fatsys->bb[dnr]==NULL) return 0;
    inf=fatsys->bb[dnr];
    return jtmfat_infoblock_uses_clusters(inf) &&
           inf->res7>0 && inf->max_val>2;
}

DWORD jtmfat_clustersectors(int dnr)
{
    JTMFAT_INFOBLOCK *inf;
    if(!jtmfat_valid_slot(dnr) || fatsys==NULL || fatsys->bb[dnr]==NULL) return 1;
    inf=fatsys->bb[dnr];
    if(jtmfat_infoblock_uses_clusters(inf) &&
       inf->res6<=JTMFS_CLUSTER_MAX_SECTORS)
        return inf->res6;
    return 1;
}

DWORD jtmfat_unitcount(int dnr)
{
    JTMFAT_INFOBLOCK *inf;
    if(!jtmfat_valid_slot(dnr)) return 0;
    if(fatsys!=NULL && fatsys->bb[dnr]!=NULL)
    {
        inf=fatsys->bb[dnr];
        if(jtmfat_infoblock_uses_clusters(inf) && inf->max_val>2)
            return (DWORD)inf->max_val;
    }
    return (DWORD)getsize(dnr);
}

DWORD jtmfat_unitsize(int dnr)
{
    DWORD cs;
    int bs;
    if(!jtmfat_valid_slot(dnr)) return 0;
    bs=getblocksize(dnr); if(bs<=0) return 0;
    cs=jtmfat_clustersectors(dnr);
    if(cs>0xffffffffUL/(DWORD)bs) return 0;
    return cs*(DWORD)bs;
}

DWORD jtmfat_unit_to_lba(int dnr, DWORD unit)
{
    JTMFAT_INFOBLOCK *inf;
    DWORD cs,off;
    if(!jtmfat_valid_slot(dnr)) return 0xffffffffUL;
    if(!jtmfat_isclustered(dnr)) return unit;
    inf=fatsys->bb[dnr]; cs=inf->res6;
    if(unit==0 || unit>=(DWORD)inf->max_val) return 0xffffffffUL;
    off=(unit-1UL)*cs;
    if(unit>1UL && off/cs!=unit-1UL) return 0xffffffffUL;
    if(inf->res7>0xffffffffUL-off) return 0xffffffffUL;
    return inf->res7+off;
}

int jtmfat_validateinfoblock(int dnr, const JTMFAT_INFOBLOCK *inf)
{
	int bs,n;
	if(!jtmfat_valid_slot(dnr) || inf==NULL) return 1;
	if(strncmp(inf->detstr,"JTMFS",5))
	{
		printk("JTMFS: DNR=%d information block has no JTMFS signature "
		       "(detstr=%02x %02x %02x %02x %02x %02x).\n",
		       dnr,(unsigned char)inf->detstr[0],(unsigned char)inf->detstr[1],
		       (unsigned char)inf->detstr[2],(unsigned char)inf->detstr[3],
		       (unsigned char)inf->detstr[4],(unsigned char)inf->detstr[5]);
		return 2;
	}
	bs=getblocksize(dnr); n=getsize(dnr);
	if(bs<=0 || n<=0)
	{
		printk("JTMFS: DNR=%d invalid DEVAPI geometry blocks=%d blocksize=%d.\n",dnr,n,bs);
		return 3;
	}
	/* Legacy images stored zero in these fields; accept zero but validate new media. */
	if(inf->block_size && inf->block_size!=(DWORD)bs)
	{
		printk("JTMFS: DNR=%d block-size mismatch media=%u current=%d.\n",dnr,inf->block_size,bs);
		return 4;
	}
	if(inf->n_blocks && inf->n_blocks!=(DWORD)n)
	{
		printk("JTMFS: DNR=%d block-count mismatch media=%u current=%d.\n",dnr,inf->n_blocks,n);
		return 5;
	}
	if(!inf->fat_offs || !inf->fat_length || !inf->data_offs || !inf->sysarea_length)
	{
		printk("JTMFS: DNR=%d incomplete filesystem geometry fat=%u+%u root=%u sys=%u.\n",
		       dnr,inf->fat_offs,inf->fat_length,inf->data_offs,inf->sysarea_length);
		return 6;
	}
	if(inf->fat_offs>=(DWORD)n || inf->fat_length>(DWORD)n ||
	   inf->fat_length>(DWORD)n-inf->fat_offs)
	{
		printk("JTMFS: DNR=%d physical FAT geometry outside device: blocks=%d fat=%u+%u.\n",
		       dnr,n,inf->fat_offs,inf->fat_length);
		return 7;
	}
	if(jtmfat_infoblock_uses_clusters(inf))
	{
		DWORD cs=inf->res6,units=(DWORD)inf->max_val,last_lba;
		if(cs>JTMFS_CLUSTER_MAX_SECTORS || (cs&(cs-1U))!=0 || inf->res7==0 ||
		   units<3 || inf->data_offs!=1U || inf->sysarea_length!=2U ||
		   inf->bootblock_size>inf->fat_offs || inf->fat_offs+inf->fat_length>inf->res7)
		{
			printk("JTMFS: DNR=%d invalid clustered geometry cs=%u dataLBA=%u units=%u fat=%u+%u.\n",
			       dnr,cs,inf->res7,units,inf->fat_offs,inf->fat_length);
			return 8;
		}
		last_lba=inf->res7+(units-2U)*cs;
		if(last_lba>=inf->n_blocks || cs>inf->n_blocks-last_lba)
		{
			printk("JTMFS: DNR=%d clustered data extent outside media lastLBA=%u cs=%u n=%u.\n",
			       dnr,last_lba,cs,inf->n_blocks);
			return 9;
		}
	}
	else
	{
		if(inf->data_offs>=(DWORD)n || inf->sysarea_length>(DWORD)n ||
		   inf->data_offs+1U!=inf->sysarea_length ||
		   inf->bootblock_size>inf->fat_offs || inf->fat_offs+inf->fat_length>inf->data_offs)
		{
			printk("JTMFS: DNR=%d invalid legacy geometry root=%u sys=%u fat=%u+%u.\n",
			       dnr,inf->data_offs,inf->sysarea_length,inf->fat_offs,inf->fat_length);
			return 9;
		}
	}
	/* Current bootable JTMFS volumes publish an explicit 1 MiB kernel contract.
	 * Validate it at every mount/reload, not only while mkfs is constructing it. */
	if(inf->res3==JTMFS_BOOT_LAYOUT_TAG)
	{
		DWORD kernel_start,kernel_blocks,kernel_end;
		if(inf->res5<JTMFS_BOOT_LAYOUT_VERSION ||
		   inf->res4<JTMFS_KERNEL_RESERVE_BYTES ||
		   (FAT_BOOT_SECTION_LEN_K*1024UL)%(DWORD)bs ||
		   inf->res4%(DWORD)bs)
		{
			printk("JTMFS: DNR=%d invalid 1 MiB boot-layout metadata tag=%x bytes=%u version=%u.\n",
			       dnr,inf->res3,inf->res4,inf->res5);
			return 10;
		}
		kernel_start=(DWORD)(FAT_BOOT_SECTION_LEN_K*1024UL)/(DWORD)bs;
		kernel_blocks=inf->res4/(DWORD)bs;
		kernel_end=kernel_start+kernel_blocks;
		if(inf->kernel_offs!=kernel_start ||
		   inf->bootblock_size<kernel_end || inf->fat_offs<kernel_end)
		{
			printk("JTMFS: DNR=%d kernel/system overlap kernel=%u..%u boot=%u fat=%u.\n",
			       dnr,kernel_start,kernel_end,inf->bootblock_size,inf->fat_offs);
			return 11;
		}
	}
	return 0;
}

void jtmfat_dumpgeometry(int dnr)
{
	JTMFAT_INFOBLOCK *inf;
	char name[32];
	int bs,n,ib,io,r;
	if(!isValidDevice(dnr)) { printk("fsgeom: invalid DNR=%d.\n",dnr); return; }
	name[0]=0; driver_getdevicename(dnr,name);
	bs=getblocksize(dnr); n=getsize(dnr);
	r=jtmfat_info_location(dnr,&ib,&io);
	printk("fsgeom %s: DNR=%d blocks=%d blocksize=%d capacity=%u MiB.\n",
	       name,dnr,n,bs,
	       (unsigned)(((unsigned long long)(DWORD)n*(unsigned long long)(DWORD)bs)/(1024ULL*1024ULL)));
	if(r) { printk("fsgeom %s: info-location error=%d.\n",name,r); return; }
	printk("fsgeom %s: info byte=%d => block=%d +%d.\n",name,FAT_INFO_BYTE_OFFS,ib,io);
	inf=jtmfat_getinfoblock(dnr);
	if(inf==NULL) { printk("fsgeom %s: no JTMFS info loaded.\n",name); return; }
	printk("fsgeom %s: media blocks=%u blocksize=%u fat=%u+%u root=%u sys=%u kernel=%u boot=%u.\n",
	       name,inf->n_blocks,inf->block_size,inf->fat_offs,inf->fat_length,
	       inf->data_offs,inf->sysarea_length,inf->kernel_offs,inf->bootblock_size);
	if(jtmfat_isclustered(dnr))
	{
		DWORD root_lba=jtmfat_unit_to_lba(dnr,inf->data_offs);
		printk("fsgeom %s: CLUSTERED v%u cluster=%u sectors/%u bytes units=%u dataLBA=%u rootLBA=%u.\n",
		       name,(unsigned)inf->res5,(unsigned)jtmfat_clustersectors(dnr),
		       (unsigned)jtmfat_unitsize(dnr),(unsigned)jtmfat_unitcount(dnr),
		       (unsigned)inf->res7,(unsigned)root_lba);
		printk("fsgeom %s: FAT=%u KiB validation=%d; unit 0 reserved, root unit=%u, first allocatable unit=%u.\n",
		       name,(unsigned)((inf->fat_length*(DWORD)bs)/1024UL),
		       jtmfat_validateinfoblock(dnr,inf),inf->data_offs,inf->sysarea_length);
	}
	else
	{
		printk("fsgeom %s: LEGACY sector allocation FAT=%u KiB root-LBA=%u validation=%d.\n",
		       name,(unsigned)((inf->fat_length*(DWORD)bs)/1024UL),
		       inf->data_offs,jtmfat_validateinfoblock(dnr,inf));
		printk("fsgeom %s: SYSTEM-WALL protected blocks 0..%u, root=%u, normal allocation starts=%u.\n",
		       name,inf->sysarea_length ? inf->sysarea_length-1U : 0U,
		       inf->data_offs,inf->sysarea_length);
	}
}

//
void DebugTrap(int dnr, const char *funcStr)
{
	char *str,*str2;
	int i,i2;
	BYTE *p;

	//
	DEBUGFUNC
}

// Calculate 32-bit checksum out of the whole FAT table
DWORD GetFATChecksum32(CFAT *f)
{
	int i,i2,l;
	BYTE *p;
	DWORD sum;

	DEBUGFUNC
	//
	p = (BYTE *)f->buf;  l = f->l_buf;
	for(i=0,sum=0; i<l; i++) { sum+=(p[i]+1); }
	return sum;
}

// 0 =			OK
// 1 =			ERROR
// OTHER NUMBERS =	MISC. ERROR
int read_fat(int dnr)
{
	//
	DEBUGFUNC
	DEBUGLINE
	return 0;
}

// Called by kernel cache flusher process only!:
int write_fat(int dnr)
{
	//
	DEBUGFUNC
	return 0;
}

int allocate_fat(int dnr)
{
	//
	DEBUGFUNC
	return 0;
}

// Touch on FAT it becomes alive...
int touch_fat(int dnr)
{
	//
	DEBUGFUNC
	return 0;
}

// HAS TO BE CALLED FIRST BEFORE USING JTMFAT
int jtmfat_init(void)
{
	int i,n;

	DEBUGFUNC
	jtmfat_ready=FALSE;
	for(i=0;i<N_CFAT_STRUCTURES;i++)
	{
		findfreeblock_last_by_dnr[i]=-1;
		jtmfat_alloc_owner[i]=-1;
		jtmfat_alloc_depth[i]=0;
	}
	findfreeblock_last_block_nr=-1;

	if(TMPSPACE1==NULL)
		TMPSPACE1=malloc(1024*64);
	if(TMPSPACE1==NULL)
	{
		printk("jtmfat_init: unable to allocate 64 KiB info/FAT scratch buffer.\n");
		return 1;
	}

	fatsys=malloc(sizeof(JTMFATSYS));
	if(fatsys==NULL)
	{
		printk("jtmfat_init: unable to allocate JTMFATSYS.\n");
		return 2;
	}
	memset((void*)fatsys,0,sizeof(JTMFATSYS));
	fatsys->virgin=1;
	SetMemoryName(fatsys,"fatsys:structure");

	dprintk("%s: Allocating sector buffers for block devices:\n",__FUNCTION__);
	n=driver_nr();
	if(n>N_CFAT_STRUCTURES)
	{
		printk("jtmfat_init: DEVAPI exposes %d devices, JTMFAT supports %d; extra devices are ignored.\n",
		       n,N_CFAT_STRUCTURES);
		n=N_CFAT_STRUCTURES;
	}
	for(i=0;i<n;i++)
	{
		if(getsize(i)>=1)
		{
			fatsys->bb[i]=malloc(1024*32);
			if(fatsys->bb[i]==NULL)
				dprintk("jtmfat_init: no info cache buffer for DNR=%d; it will be allocated lazily.\n",i);
		}
	}

	fatsys->tbuf=malloc(1024*64);
	if(fatsys->tbuf!=NULL)
		SetMemoryName(fatsys->tbuf,"fatsys:tbuf");
	else
		dprintk("jtmfat_init: optional tbuf allocation failed.\n");

	/* Publish JTMFAT before FlexFAT activation.  FlexFAT failure is tolerated
	 * as a disabled filesystem rather than an immediate NULL dereference. */
	jtmfat_ready=TRUE;
	flexFatInit();
	if(!flexActive || fle==NULL)
	{
		printk("jtmfat_init: FlexFAT cache unavailable; JTMFS block access disabled safely.\n");
		return 3;
	}
	return 0;
}

// Updates info block for the drive
// (loads a new one from drive to the drive's info block buffer).
int jtmfat_LoadNewInfoBlock(int dnr)
{
	void *tmp,*p;
	int i,i2,i3;

	DEBUGFUNC
	if(!jtmfat_ready || fatsys==NULL || TMPSPACE1==NULL ||
	   !jtmfat_valid_slot(dnr))
		return 1;

	{
		int bs,ib,io;
		bs=getblocksize(dnr);
		if(bs<=0 || bs>1024*64 || jtmfat_info_location(dnr,&ib,&io))
		{
			fatsys->isJTMFS[dnr]=FALSE;
			return 1;
		}
		if(fatsys->bb[dnr]==NULL) fatsys->bb[dnr]=malloc(sizeof(JTMFAT_INFOBLOCK));
		if(fatsys->bb[dnr]==NULL) { fatsys->isJTMFS[dnr]=FALSE; return 1; }
		tmp=TMPSPACE1;
		ReportMessage("%s: physical info read DNR=%d block=%d +%d bs=%d.\n",
		              __FUNCTION__,dnr,ib,io,bs);
		if(readblock1(dnr,ib,tmp))
		{
			fatsys->isJTMFS[dnr]=FALSE;
			dprintk("%s: physical info-block read failed DNR=%d.\n",__FUNCTION__,dnr);
			return 1;
		}
		p=fatsys->bb[dnr]; i2=sizeof(JTMFAT_INFOBLOCK); i3=io;
		memcpy(p,tmp+i3,i2);
		dprintk("JTMFS/load-info: DNR=%d LBA=%d +%d raw detstr=%02x %02x %02x %02x %02x %02x fat=%u+%u data=%u sys=%u n=%u bs=%u.\n",
		        dnr,ib,io,
		        (unsigned char)fatsys->bb[dnr]->detstr[0],
		        (unsigned char)fatsys->bb[dnr]->detstr[1],
		        (unsigned char)fatsys->bb[dnr]->detstr[2],
		        (unsigned char)fatsys->bb[dnr]->detstr[3],
		        (unsigned char)fatsys->bb[dnr]->detstr[4],
		        (unsigned char)fatsys->bb[dnr]->detstr[5],
		        fatsys->bb[dnr]->fat_offs,fatsys->bb[dnr]->fat_length,
		        fatsys->bb[dnr]->data_offs,fatsys->bb[dnr]->sysarea_length,
		        fatsys->bb[dnr]->n_blocks,fatsys->bb[dnr]->block_size);
		i=jtmfat_validateinfoblock(dnr,fatsys->bb[dnr]);
		if(i==0)
		{
			fatsys->isJTMFS[dnr]=TRUE;
			dprintk("JTMFS DNR=%d: bs=%d blocks=%d fat=%u+%u root=%u sys=%u.\n",
			       dnr,bs,getsize(dnr),fatsys->bb[dnr]->fat_offs,
			       fatsys->bb[dnr]->fat_length,fatsys->bb[dnr]->data_offs,
			       fatsys->bb[dnr]->sysarea_length);
			if(jtmfat_isclustered(dnr))
				dprintk("JTMFS/cluster: DNR=%d sectors/cluster=%u cluster-bytes=%u units=%u dataLBA=%u root-unit=%u first-free-unit=%u.\n",
				       dnr,(unsigned)jtmfat_clustersectors(dnr),(unsigned)jtmfat_unitsize(dnr),
				       (unsigned)jtmfat_unitcount(dnr),(unsigned)fatsys->bb[dnr]->res7,
				       (unsigned)fatsys->bb[dnr]->data_offs,(unsigned)fatsys->bb[dnr]->sysarea_length);
		}
		else
		{
			fatsys->isJTMFS[dnr]=FALSE;
			printk("JTMFS: DNR=%d information block rejected (validation=%d).\n",dnr,i);
			return i;
		}
	}

	//
	return 0;
}

// Loads up data to fatsys->bb[dnr]
// Returns non-zero if the drive is not
// JTMFS formatted.
int _jtmfat_loadinfoblock(const char *caller, int dnr)
{
	BYTE *tmp,*p;
	int i,i2;

	DEBUGFUNC

	//
	dprintk("%s was called by %s\n",
		__FUNCTION__, caller);
	DEBUGLINE

	//------------------------------------------------------
	// FAT system must be active
	if(jtmfat_ready!=TRUE)return 1;

	//------------------------------------------------------
	// Check device
	if(!isValidDevice(dnr))
	{
		dprintk("%s: Invalid device %d.\n", 
			__FUNCTION__, dnr);
		return 2;
	}

	//------------------------------------------------------
	// Get temporary data buffer PTR
	tmp=TMPSPACE1;
	if(tmp==NULL)
	{
		dprintk("jtmfat_loadinfoblock: temporary buffer unavailable.\n");
		return FALSE;
	}

	/*
	 * This is the SLOW/refresh path.  The old code only loaded the info block
	 * when the cache pointer was NULL, despite the function comment saying it
	 * updates the info block.  After a format/media update that left stale
	 * detstr/fat_offs/data_offs values resident indefinitely.
	 */
	if(jtmfat_LoadNewInfoBlock(dnr))
	{
		dprintk("%s: info block read failed for drive %d.\n",
			__FUNCTION__, dnr);
		return FALSE;
	}

	dprintk("%s: Leaving this function.\n",
		__FUNCTION__);
	return fatsys->isJTMFS[dnr];
}

// Return value:
// Non-zero=Success, 0=Failure
//
int _jtmfat_chdev(const char *caller, long dnr)
{
	//
	DEBUGFUNC
	FFCHECK

	//-----------------------------------------------------------------------------------
	//
	if(jtmfat_ready!=TRUE || fatsys==NULL) return 0;

	//
	if(!jtmfat_valid_slot((int)dnr))
	{
		dprintk("jtmfat_chdev: Invalid device %d\n",
			dnr);
		return 2;
	}

	//-----------------------------------------------------------------------------------
	// Note: This function is called really often,
	// adding debug traces to this function
	//�will lead into a big flow of debug text.
	dprintk("%s was called by %s\n",
		__FUNCTION__, caller);

	/*
	 * Flush using the geometry that belongs to the currently cached FAT BEFORE
	 * refreshing the info block.  f->bb points directly at fatsys->bb[dnr];
	 * reloading fat_offs first could otherwise make dirty old cache pages get
	 * written through the new filesystem geometry.
	 */
	FFCHECK
	/* Refresh only after this device's own dirty metadata is safely drained.
	 * The historical global dirdbFlush() could write unrelated filesystems and
	 * both flush calls ignored failures before replacing cached geometry. */
	if(dirdbFlushDNR((int)dnr)!=0)
	{
		printk("jtmfat_chdev: DIRDB flush failed for DNR=%d; geometry refresh cancelled.\n",(int)dnr);
		return 0;
	}
	if(flexActive && flexFlushFATChecked((int)dnr)!=0)
	{
		printk("jtmfat_chdev: FAT flush failed for DNR=%d; geometry refresh cancelled.\n",(int)dnr);
		return 0;
	}

	/* Slow path: really refresh detstr/fat_offs/data_offs from media. */
	if(!jtmfat_loadinfoblock((int)dnr))
		return 0;
	FFCHECK

	dprintk("%s: leaving this function\n",
		__FUNCTION__);
	return fatsys->isJTMFS[dnr];
}

// jtmfat_getinfoblock =	Fast access to boot block of DNR(for FATGET/FATSET)
// jtmfat_chdev =		Slow access to boot block
// Get handle to the boot block of the specified DNR
JTMFAT_INFOBLOCK *jtmfat_getinfoblock(int dnr)
{
	DEBUGFUNC

	if(!jtmfat_ready || fatsys==NULL || !jtmfat_valid_slot(dnr))
		return NULL;

	if(fatsys->bb[dnr]==NULL)
	{
		if(jtmfat_LoadNewInfoBlock(dnr))
			return NULL;
	}
	return fatsys->bb[dnr];
}

// Same as getrootdir1, but this one
// tries to retrieve the rootdir twice
// with two other ways.
int _jtmfat_getrootdir(const char *caller, int dnr)
{
	int block;

	DEBUGFUNC

	//
	dprintk("%s was called by %s\n",
		__FUNCTION__, caller);

	//
	FFCHECK

	//
	EntranceGetrootdir=1;

	//
	DEBUGLINE

	//
	if(!isValidDevice(dnr))
	{
		//
		EntranceGetrootdir=0;
		dprintk("%s/%s/%d: Invalid device %d\n",
			__FUNCTION__, __FILE__, __LINE__,
			dnr);
		sleep(2);
		return 2;
	}

	//
	block = jtmfat_getrootdir1(dnr);
	if(!block)
	{
		// Try retrying twice by first trying to chdev
		dprintk("%s: Boot block = zero ??\n",
			__FUNCTION__);
	}

	//
	EntranceGetrootdir=0;

	//
	return block;
}

// Sets specified drive to "removable drive" -mode.
// Causes some minimal performance loss, but provides
// support for removable drives and first of all support
// for disk change.
void RemovableDevice(int dnr)
{
	DEBUGFUNC
	if(fatsys==NULL || !jtmfat_valid_slot(dnr)) return;
	fatsys->bootinf[dnr].isRemovable = TRUE;
}

// Returns the block # where the root directory resides.
int jtmfat_getrootdir1(int dnr)
{
	JTMFAT_INFOBLOCK *inf;
	int reload;

	DEBUGFUNC
	DEBUGLINE

	if(!jtmfat_ready || fatsys==NULL || !jtmfat_valid_slot(dnr))
		return -1988;

	reload=FALSE;
	if(fatsys->bootinf[dnr].isRemovable)
	{
		if(fatsys->bb[dnr]==NULL || !fatsys->isJTMFS[dnr] ||
		   (GetSeconds()-fatsys->bootinf[dnr].t)>=2)
		{
			fatsys->bootinf[dnr].t=GetSeconds();
			reload=TRUE;
		}
	}
	else if(fatsys->bb[dnr]==NULL || !fatsys->isJTMFS[dnr])
		reload=TRUE;

	if(reload && jtmfat_LoadNewInfoBlock(dnr))
	{
		dprintk("jtmfat_getrootdir1: unable to load JTMFS info for DNR=%d.\n",dnr);
		return -1986;
	}

	inf=fatsys->bb[dnr];
	if(inf==NULL || !fatsys->isJTMFS[dnr] || jtmfat_validateinfoblock(dnr,inf))
		return -1986;
	if(inf->data_offs==0 || inf->data_offs>=jtmfat_unitcount(dnr))
		return -1986;

	dprintk("%s: Root directory at block %d on drive %d.\n",
		__FUNCTION__,inf->data_offs,dnr);
	return (int)inf->data_offs;
}

/* Return the first block that normal file/directory allocation may use.
 * data_offs is the root directory itself and is reserved for that purpose;
 * ordinary allocations begin at sysarea_length (= data_offs + 1). */
DWORD jtmfat_firstallocatableblock(int dnr)
{
	JTMFAT_INFOBLOCK *inf;
	if(!isValidDevice(dnr) || !jtmfat_isJTMFS(dnr)) return 0;
	inf=jtmfat_getinfoblock(dnr);
	if(inf==NULL || jtmfat_validateinfoblock(dnr,inf)) return 0;
	if(inf->sysarea_length>=jtmfat_unitcount(dnr)) return 0;
	return inf->sysarea_length;
}

/* Valid physical block for an existing JTMFS chain.  The root directory is
 * the sole legal block immediately below the allocation boundary. */
int jtmfat_isdatablock(int dnr, DWORD block)
{
	JTMFAT_INFOBLOCK *inf;
	if(!isValidDevice(dnr) || block>=jtmfat_unitcount(dnr)) return 0;
	inf=jtmfat_getinfoblock(dnr);
	if(inf==NULL || jtmfat_validateinfoblock(dnr,inf)) return 0;
	return block==inf->data_offs || block>=inf->sysarea_length;
}

/* New chains may never allocate the root block either. */
int jtmfat_isallocatableblock(int dnr, DWORD block)
{
	DWORD first=jtmfat_firstallocatableblock(dnr);
	return first!=0 && block>=first && block<jtmfat_unitcount(dnr);
}

// Searches for a free block and returns it.
// IMPORTANT INVARIANT: this is a locator, not an allocator.  A successful
// return still has FAT value 0; the caller must initialise/publish the FAT
// entry only after the new block's contents are in a safe state.
// NEW: Optimized to remember location for last found
// free block, it'll continue search on the last position.
// It is much possible that it'll find another empty
// block after it, or it is atleast much more probable
// to find than when starting from the beginning at every
// try.
// When the function is called first time, it'll not
// use the findfreeblock_last_block_nr -variable,
// although it'll save the block number to it after
// it has ran through the operation.
//
// Fixed: Won't accept block #0 as a free one ever.
//
// Returns -1 on disk full.
//
int jtmfat_getfreeblock1(long dnr)
{
	int i,i2,amount,first;

	DEBUGFUNC
	DEBUGLINE

	if(jtmfat_ready!=TRUE)
		return -3;
	if(!isValidDevice(dnr))
	{
		dprintk("jtmfat_getfreeblock1: Invalid device %d\n",(int)dnr);
		return 0;
	}

	DEBUGTRAP
	amount=(int)jtmfat_unitcount((int)dnr);
	first=(int)jtmfat_firstallocatableblock((int)dnr);
	if(amount<10 || first<=0 || first>=amount)
		return -2;

	/* V67.8.57.4 SYSTEM-WALL: never scan boot/kernel/FAT/root blocks even if
	 * their FAT entry has accidentally become zero.  The allocator therefore
	 * cannot turn a metadata/cache error into boot-kernel destruction. */
	if((int)dnr>=0 && (int)dnr<N_CFAT_STRUCTURES &&
	   findfreeblock_last_by_dnr[(int)dnr]>=first &&
	   findfreeblock_last_by_dnr[(int)dnr]<amount)
		i=findfreeblock_last_by_dnr[(int)dnr];
	else
		i=first;

	for(i2=0; i2<amount-first; i2++,i++)
	{
		jtmfs_cooperative_yield((unsigned long)i2);
		if(i<first || i>=amount)
			i=first;
		if(!jtmfat_isallocatableblock((int)dnr,(DWORD)i))
		{
			printk("JTMFS: allocator SYSTEM-WALL rejected DNR=%d block=%d first=%d.\n",
			       (int)dnr,i,first);
			return -2;
		}
		if(!jtmfat_getblock(dnr,i))
		{
			if((int)dnr>=0 && (int)dnr<N_CFAT_STRUCTURES)
				findfreeblock_last_by_dnr[(int)dnr]=i;
			findfreeblock_last_block_nr=i; /* diagnostic compatibility */
			return i;
		}
	}

	if((int)dnr>=0 && (int)dnr<N_CFAT_STRUCTURES)
		findfreeblock_last_by_dnr[(int)dnr]=first;
	findfreeblock_last_block_nr=first;
	return -1;
}

//
static void jtmfat_allocator_lock(int dnr)
{
	int pid,flags;
	unsigned long spins=0;
	if(!Multitasking) return;
	pid=GetCurrentThread();
	for(;;)
	{
		flags=get_eflags();
		disable();
		if(jtmfat_alloc_owner[dnr]==-1 || jtmfat_alloc_owner[dnr]==pid)
		{
			if(jtmfat_alloc_owner[dnr]==pid) jtmfat_alloc_depth[dnr]++;
			else { jtmfat_alloc_owner[dnr]=pid; jtmfat_alloc_depth[dnr]=1; }
			set_eflags(flags);
			return;
		}
		set_eflags(flags);
		if(LockWaitCanYield(flags)) SwitchToThread();
		else { volatile unsigned long i; for(i=0;i<128;i++) { } }
		if(++spins==1000000UL)
		{
			printk("JTMFS: allocator lock wait DNR=%d owner=%d caller=%d.\n",
			       dnr,jtmfat_alloc_owner[dnr],pid);
			spins=0;
		}
	}
}

static void jtmfat_allocator_unlock(int dnr)
{
	int flags,pid;
	if(!Multitasking) return;
	pid=GetCurrentThread();
	flags=get_eflags();
	disable();
	if(jtmfat_alloc_owner[dnr]==pid && jtmfat_alloc_depth[dnr])
	{
		jtmfat_alloc_depth[dnr]--;
		if(!jtmfat_alloc_depth[dnr]) jtmfat_alloc_owner[dnr]=-1;
	}
	set_eflags(flags);
}

long jtmfat_getfreeblock(long dnr)
{
	int b;

	//
	DEBUGFUNC
	DEBUGLINE

	//
	if(!isValidDevice(dnr))
	{
		dprintk("jtmfat_getfreeblock: Invalid device %d\n",
			dnr);
		return 0;
	}

	// ------------------------------------
	DEBUGTRAP

	//
	b = jtmfat_getfreeblock1(dnr);
	return b;
}

/*
 * Atomically reserve a free FAT node.  The reservation is represented by a
 * normal standalone EOC (FFFFFFF8), so an interrupted caller may leak one
 * unreachable block but can never cross-link two files onto the same block.
 */
long jtmfat_reserveblock(long dnr)
{
	int b,was_full=0;
	DWORD v;
	if(!jtmfat_valid_slot((int)dnr) || !jtmfat_ready) return -3;
	jtmfat_allocator_lock((int)dnr);
	b=jtmfat_getfreeblock1(dnr);
	if(b==-1) was_full=1;
	if(b>0)
	{
		v=(DWORD)jtmfat_getblock((int)dnr,b);
		if(v!=0 || !jtmfat_isallocatableblock((int)dnr,(DWORD)b)) b=-2;
		else if(jtmfat_setblock((int)dnr,b,(int)0xFFFFFFF8UL) ||
		        (DWORD)jtmfat_getblock((int)dnr,b)<0xFFFFFFF8UL)
		{
			(void)jtmfat_setblock((int)dnr,b,0);
			b=-2;
		}
		else if((int)dnr<N_CFAT_STRUCTURES)
		{
			int first=(int)jtmfat_firstallocatableblock((int)dnr);
			int amount=(int)jtmfat_unitcount((int)dnr);
			int next=b+1;
			if(next<first || next>=amount) next=first;
			findfreeblock_last_by_dnr[(int)dnr]=next;
			findfreeblock_last_block_nr=next;
		}
	}
	jtmfat_allocator_unlock((int)dnr);
	/* Never run the troubleshooter while holding the allocator lock: normal
	 * writes acquire mutation->allocator, so reversing that order here would
	 * create an ENOSPC-only lock inversion. */
	if(was_full)
		DiskSpaceNoteENOSPC((int)dnr,"JTMFAT allocator",jtmfat_unitsize((int)dnr));
	return b;
}

//------------------------------------------------------------
//
long jtmfat_isJTMFS(int dnr)
{
	DEBUGFUNC

	//---------------------------------------
	// Couple checks
	if(jtmfat_ready!=TRUE || fatsys==NULL)
	{
		dprintk("[%s/%s/line %d]: jtmfat isn't ready yet!\n",
			__FUNCTION__, __FILE__, __LINE__);
		return FALSE;
	}

	//
	if(!jtmfat_valid_slot(dnr))
		return FALSE;

	/*
	 * Fast readiness query.  This function is on virtually every pathname and
	 * directory operation; forcing jtmfat_chdev() here re-read the info block
	 * and flushed caches for every lookup.  Non-removable devices use the
	 * cached info block.  Removable media still use the slow refresh path.
	 */
	if(fatsys->bootinf[dnr].isRemovable)
	{
		if(!jtmfat_chdev(dnr))
			return FALSE;
	}
	else if(fatsys->bb[dnr]==NULL)
	{
		if(jtmfat_LoadNewInfoBlock(dnr))
			return FALSE;
	}

	return fatsys->bb[dnr]!=NULL && fatsys->isJTMFS[dnr];
}

// jtmfat_getblocksfree
// --------------------
// Returns the amount of blocks free
// Return value: below zero on error, zero on success
long jtmfat_getblocksfree(long dnr)
{
	int i,i2,i3,i4,amount,n_free,n_allocated;
	JTMOS_DISKSPACE_STATS st;

	/* V68.133: the kernel owns an incrementally maintained free-space table.
	 * Reconcile lazily when needed instead of rescanning the entire FAT for
	 * every df/statistics request. */
	if(DiskSpaceGetStats((int)dnr,&st,1)==0 &&
	   (st.flags&DISKSPACE_FLAG_JTMFS))
		return (long)st.free_units;

	//
	DEBUGFUNC
	DEBUGLINE

	//
	if(!jtmfat_valid_slot((int)dnr) || fatsys==NULL || !jtmfat_isJTMFS((int)dnr))
	{
		dprintk("jtmfat_getblocksfree: Invalid/non-JTMFS device %d\n",
			dnr);
		return -1;
	}

	// ------------------------------------
	DEBUGTRAP

	// Get drive size
	amount=(int)jtmfat_unitcount((int)dnr);
	// Do sanity check
	if(amount<10)return 1;

	// Find free block
	for(i=0,n_allocated=0,n_free=0; i<amount; i++)
	{
		if( jtmfat_getblock(dnr,i) )
		{
			n_allocated++;
		}
		else
		{
			n_free++;
		}
	}

	//
	return n_free;
}

// jtmfat_getblocksallocated
// -------------------------
// Returns the amount of blocks free
// Return value: below zero on error, zero on success
long jtmfat_getblocksallocated(long dnr)
{
	int i,i2,i3,i4,
		amount,n_free,n_allocated;

	//
	DEBUGFUNC
	DEBUGLINE

	//
	if(!jtmfat_valid_slot((int)dnr) || fatsys==NULL)
	{
		dprintk("jtmfat_getblocksallocated: Invalid device %d\n",
			dnr);
		return -1;
	}

	//
	if(!jtmfat_chdev(dnr) || !fatsys->isJTMFS[dnr])
	{
		dprintk("jtmfat_getblocksallocated: Non-JTMFS FS\n");
		return -1;
	}

	// ------------------------------------
	DEBUGTRAP

	//
	amount=(int)jtmfat_unitcount((int)dnr);

	//
	for(i=0,n_allocated=0,n_free=0; i<amount; i++)
	{
		if( jtmfat_getblock(dnr,i) )
		{
			n_allocated++;
		}
		else
		{
			n_free++;
		}
	}

	//
	return n_allocated;
}

int jtmfat_deactivateFatDNR(int dnr)
{
	DEBUGFUNC
	if(!jtmfat_valid_slot(dnr) || fatsys==NULL ||
	   fatsys->fat==NULL || fatsys->fat[dnr]==NULL)
		return 1;

	DEBUGLINE
	fatsys->fat[dnr]->isActive=0;
	return 0;
}

//
void _jtmfatInformation(void)
{
	//
	DEBUGFUNC
}

//




