# JTMOS V68.139 disk-full / ENOSPC design

Goals:

1. A full JTMFS volume returns ENOSPC, not generic EIO.
2. File growth is all-or-nothing with respect to free-space allocation.
3. Failed data I/O or EOF metadata commit releases hidden blocks reserved for the failed write.
4. Allocation corruption/not-ready failures are not mislabeled as ENOSPC.
5. Diagnostics show both JTMFS free space and the underlying DEVAPI geometry.
6. A suspiciously tiny hd* geometry is called out as a possible ATA/AHCI IDENTIFY problem, not silently treated as a normal full physical disk.

Write transaction:

- Determine the final block span.
- Check the maintained free-unit snapshot as an early ENOSPC preflight.
- Reserve every required FAT unit before data I/O.
- On allocator exhaustion, roll back the private extension and return ENOSPC.
- Write data.
- Publish exact EOF only after data succeeds.
- If data or EOF commit fails, call SetSize(original_size) to detach any hidden extension.

The FAT allocator remains authoritative: the cached preflight is only an optimization and diagnostic aid.
