//-----------------------------------------------------------------------
// WriteChain.c - bounded/reentrant file-chain writer
// V68.8.57.10.18.16.55: sector-aligned partial-cluster writes update only
// the requested sectors instead of reading and rewriting the whole cluster.
//-----------------------------------------------------------------------
#include "kernel32.h"
#include "jtmfsAccess.h"
#include "jtmfat.h"

#define JTMFS_CHAIN_IO_MAX_BLOCKS 256

int jtmfs_WriteFileChain(BYTE *buf, int dnr, int _d,
                         int preciseLength, int offset)
{
    DEBUGLINE
    return jtmfs_WriteFileChainEx(buf,dnr,_d,preciseLength,offset,1);
}

/*
 * Grow a chain only when another data block is actually needed.  The old
 * implementation used (length/blocksize)+1 and then iterated amount+1, which
 * allocated trailing blocks on every write (visible in the boot log as a 1K
 * directory write growing through four additional blocks).
 * Return: 0 success, -1 I/O/argument/corruption error, -2 disk full.
 */
int jtmfs_WriteFileChainEx(BYTE *buf, int dnr, int _d,
                           int preciseLength, int offset, int useCache)
{
    DWORD d,newd,new_block,lastd,lba,cs,units;
    int bsz,pbs,skip,skipBytes,c,chunk,remaining,run,maxrun,sectors;
    int sector_off;
    BYTE *tmp,*zero;
    (void)useCache;

    DEBUGLINE
    if(!isOK(dnr) || buf==NULL || preciseLength<0 || offset<0) return -1;
    if(preciseLength==0) return 0;
    bsz=(int)jtmfat_unitsize(dnr);
    pbs=getblocksize(dnr);
    cs=jtmfat_clustersectors(dnr);
    units=jtmfat_unitcount(dnr);
    if(bsz<=0 || bsz>64*1024 || pbs<=0 || cs==0 || units<2 ||
       (DWORD)pbs*cs!=(DWORD)bsz || _d<=0 || (DWORD)_d>=units || jtmfs_LastBlock((DWORD)_d) ||
       !jtmfat_isdatablock(dnr,(DWORD)_d))
    {
        ReportMessage("%s: SYSTEM-WALL rejected initial chain block %d.\n",__FUNCTION__,_d);
        return -1;
    }

    tmp=jtmfsAccess.rwtmp;
    zero=jtmfsAccess.rwtmp2;
    if(tmp==NULL || zero==NULL) return -1;
    d=(DWORD)_d;
    skip=offset/bsz;
    skipBytes=offset%bsz;

    /* Walk/extend to the first block touched by offset. */
    while(skip>0)
    {
        newd=(DWORD)jtmfat_getblock(dnr,(int)d);
        if(jtmfs_LastBlock(newd))
        {
            new_block=(DWORD)jtmfat_reserveblock(dnr);
            if((int)new_block==-1) return -2;
            if(new_block==0 || new_block>=units || jtmfs_LastBlock(new_block) ||
               !jtmfat_isallocatableblock(dnr,new_block))
            {
                ReportMessage("%s: allocator returned protected block %u.\n",__FUNCTION__,new_block);
                return -1;
            }
            memset(zero,0,bsz);
            lba=jtmfat_unit_to_lba(dnr,new_block);
            if(lba==0xffffffffUL || writeblocks(dnr,(long)lba,zero,(int)cs)!=(int)cs)
            {
                (void)jtmfat_setblock(dnr,(int)new_block,0);
                return -1;
            }
            if(jtmfat_setblock(dnr,(int)d,(int)new_block))
            {
                jtmfat_setblock(dnr,(int)new_block,0);
                return -1;
            }
            newd=new_block;
        }
        else if(newd==0 || newd>=units || !jtmfat_isdatablock(dnr,newd))
        {
            ReportMessage("%s: corrupt/system-area chain link %u -> %u.\n",__FUNCTION__,d,newd);
            return -1;
        }
        d=newd;
        skip--;
    }

    c=0;
    while(c<preciseLength)
    {
        remaining=preciseLength-c;

        /* Existing contiguous full blocks can be submitted in one writeblocks
         * request.  If the chain ends, write the existing final block now and
         * let the normal allocation path extend it on the next iteration. */
        if(skipBytes==0 && remaining>=bsz)
        {
            maxrun=remaining/bsz;
            if(maxrun>JTMFS_CHAIN_IO_MAX_BLOCKS) maxrun=JTMFS_CHAIN_IO_MAX_BLOCKS;
            if(cs>0 && maxrun>(int)(256UL/cs)) maxrun=(int)(256UL/cs);
            if(maxrun<1) maxrun=1;
            run=1;
            lastd=d;
            while(run<maxrun)
            {
                newd=(DWORD)jtmfat_getblock(dnr,(int)lastd);
                if(jtmfs_LastBlock(newd)) break;
                if(newd==0 || newd>=units || !jtmfat_isdatablock(dnr,newd))
                {
                    ReportMessage("%s: corrupt/system-area chain link %u -> %u.\n",__FUNCTION__,lastd,newd);
                    return -1;
                }
                if(newd!=lastd+1U) break;
                lastd=newd;
                run++;
            }
            lba=jtmfat_unit_to_lba(dnr,d);
            if(lba==0xffffffffUL) return -1;
            sectors=run*(int)cs;
            if(writeblocks(dnr,(long)lba,buf+c,sectors)!=sectors) return -1;
            c+=run*bsz;
            if(c>=preciseLength) break;

            newd=(DWORD)jtmfat_getblock(dnr,(int)lastd);
            if(jtmfs_LastBlock(newd))
            {
                new_block=(DWORD)jtmfat_reserveblock(dnr);
                if((int)new_block==-1) return -2;
                if(new_block==0 || new_block>=units || jtmfs_LastBlock(new_block) ||
                   !jtmfat_isallocatableblock(dnr,new_block))
                {
                    ReportMessage("%s: allocator returned protected block %u.\n",__FUNCTION__,new_block);
                    return -1;
                }
                memset(zero,0,bsz);
                lba=jtmfat_unit_to_lba(dnr,new_block);
                if(lba==0xffffffffUL || writeblocks(dnr,(long)lba,zero,(int)cs)!=(int)cs)
                {
                    (void)jtmfat_setblock(dnr,(int)new_block,0);
                    return -1;
                }
                if(jtmfat_setblock(dnr,(int)lastd,(int)new_block))
                {
                    jtmfat_setblock(dnr,(int)new_block,0);
                    return -1;
                }
                newd=new_block;
            }
            else if(newd==0 || newd>=units || !jtmfat_isdatablock(dnr,newd))
            {
                ReportMessage("%s: corrupt/system-area chain link %u -> %u.\n",__FUNCTION__,lastd,newd);
                return -1;
            }
            d=newd;
            continue;
        }

        chunk=bsz-skipBytes;
        if(chunk>remaining) chunk=remaining;

        lba=jtmfat_unit_to_lba(dnr,d);
        if(lba==0xffffffffUL) return -1;

        /* Sector-aligned partial writes do not need a whole-cluster RMW.
         * This is the common stdio/copyall path and is especially important
         * for 32/64 KiB JTMFS clusters on legacy SATA/IDE controllers. */
        if((skipBytes%pbs)==0 && (chunk%pbs)==0) {
            sector_off=skipBytes/pbs;
            sectors=chunk/pbs;
            if(sectors<=0 ||
               writeblocks(dnr,(long)(lba+(DWORD)sector_off),buf+c,sectors)!=sectors) {
                printk("JTMFS/write: DNR=%d unit=%u LBA=%u +%d sectors=%d offset=%d failed.\n",
                       dnr,(unsigned)d,(unsigned)lba,sector_off,sectors,offset+c);
                return -1;
            }
        } else {
            /* Byte-unaligned compatibility path: preserve untouched bytes. */
            if(skipBytes!=0 || chunk!=bsz) {
                if(readblocks(dnr,(long)lba,tmp,(int)cs)!=(int)cs) return -1;
            } else
                memset(tmp,0,bsz);
            memcpy(tmp+skipBytes,buf+c,chunk);
            if(writeblocks(dnr,(long)lba,tmp,(int)cs)!=(int)cs) return -1;
        }
        c+=chunk;
        skipBytes=0;
        if(c>=preciseLength) break;

        newd=(DWORD)jtmfat_getblock(dnr,(int)d);
        if(jtmfs_LastBlock(newd))
        {
            new_block=(DWORD)jtmfat_reserveblock(dnr);
            if((int)new_block==-1) return -2;
            if(new_block==0 || new_block>=units || jtmfs_LastBlock(new_block) ||
               !jtmfat_isallocatableblock(dnr,new_block))
            {
                ReportMessage("%s: allocator returned protected block %u.\n",__FUNCTION__,new_block);
                return -1;
            }
            memset(zero,0,bsz);
            lba=jtmfat_unit_to_lba(dnr,new_block);
            if(lba==0xffffffffUL || writeblocks(dnr,(long)lba,zero,(int)cs)!=(int)cs)
            {
                (void)jtmfat_setblock(dnr,(int)new_block,0);
                return -1;
            }
            if(jtmfat_setblock(dnr,(int)d,(int)new_block))
            {
                jtmfat_setblock(dnr,(int)new_block,0);
                return -1;
            }
            newd=new_block;
        }
        else if(newd==0 || newd>=units || !jtmfat_isdatablock(dnr,newd))
        {
            ReportMessage("%s: corrupt/system-area chain link %u -> %u.\n",__FUNCTION__,d,newd);
            return -1;
        }
        d=newd;
    }

    ReportMessage("%s: wrote %d byte(s), offset=%d.\n",__FUNCTION__,c,offset);
    return 0;
}
