#ifndef __INCLUDED_MOUNT_H__
#define __INCLUDED_MOUNT_H__

int mountDNR(int dnr);
int unmountDNR(int dnr);
int jtmfs_device_busy(int dnr);

#endif
