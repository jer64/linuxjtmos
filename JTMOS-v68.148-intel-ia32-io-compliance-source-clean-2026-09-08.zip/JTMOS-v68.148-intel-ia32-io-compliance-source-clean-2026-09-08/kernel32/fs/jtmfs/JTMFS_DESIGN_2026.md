# JTMFS 2026 design notes

## Compatibility rule

The current on-disk JTMFS layout remains version-1 compatible.  This hardening
pass deliberately does **not** move the 512-byte legacy information record or
change the 32-bit linked FAT representation.  Reliability work is therefore
safe for an already working `hda:` image.

## Layering

```
POSIX/direct file API (open/read/write/close/syncfs)
        |
        v
JTMFS namespace + file metadata
        |
        +---- DIRDB directory cache
        |
        +---- file-chain I/O
        |
        v
FlexFAT demand-paged FAT cache
        |
        v
DEVAPI block I/O / Kyber
        |
        v
ATA/FDC/RAM/ATAPI driver
```

A successful durability boundary is:

```
DIRDB write -> FAT flush -> block/device flush -> hardware flush
```

For HDA, critical metadata paths may additionally invalidate caches and verify
media with the uncached DEVAPI backend.

## Invariants

1. Device geometry comes from `getblocksize(dnr)` and `getsize(dnr)`.
2. `JTMFAT_INFOBLOCK` offsets and lengths are DEVAPI logical block numbers.
3. The legacy information-record location is a byte offset and is converted to
   `(block, byte-offset)` by `jtmfat_info_location()`.
4. A directory is never published in FAT before its first block contains a
   valid `.`, `..`, dirname and terminator set.
5. A newly extended FAT node receives EOF before the old tail links to it.
6. A delete makes the namespace entry unreachable before freeing its blocks.
   A crash may therefore leak blocks, but must not leave a live file pointing
   at blocks that may be reused by another file.
7. Reads do not mark DIRDB entries dirty.
8. Dirty FAT pages are clean only after `flexFlushFATChecked()` succeeds.
9. Physical filesystem validation must not rely on DIRDB/FlexFAT cache state.

## `fsck`

`fsck [-v] <device>` is a read-only streaming checker.  SMSH first calls
`syncdev()` and then the checker reads the information record, FAT and directory
blocks through `readblock1()`.

It reports:

- malformed information-block geometry;
- invalid FAT values and links into the system area;
- chain loops and cross-links;
- directory entries with invalid magic/name termination;
- allocated but unreachable (orphan) data blocks;
- visible file size vs FAT-chain length mismatches;
- stale `LastDataBlock` hints;
- physical I/O errors.

It intentionally performs no automatic repair in this generation.

## Next generation roadmap

### 1. Repair-mode fsck

Add an explicitly requested offline repair mode.  Safe first repairs are orphan
reclamation and stale `LastDataBlock` reconstruction.  Never repair a mounted
writable filesystem automatically.

### 2. Metadata transaction record

Use currently reserved information-block fields for a backwards-compatible
transaction generation/clean-shutdown marker.  Mount can then distinguish a
clean filesystem from one requiring fsck after a reset or power loss.

### 3. Checksums

The existing `fatChecksum32` field is currently not a trustworthy live checksum.
Define an exact checksum algorithm and update protocol before enforcing it.
Directory-block checksums would require either a format extension or a side
metadata area.

### 4. Allocation API split

Separate "reserve blocks" from "publish file size".  The legacy
`jtmfs_add_blocks_for_entry()` still combines allocation and visible length for
compatibility.  New write paths should eventually reserve privately, write
content, then atomically publish size/first/last metadata.

### 5. Locking

Replace remaining historical global/static scratch state with per-operation
state and introduce per-volume metadata locks rather than relying on broad
filesystem/global locks.

## V68.143 lazy-zero FAT formatting

`mkfs` no longer writes or verifies the complete FAT. New volumes mark the
FAT as lazy-zero by setting layout version 3 and using the historical
`fatChecksum32` field as `bit31 | materialized_fat_sector_prefix`. FAT sectors
at or above that persisted prefix are logically zero and are not read from the
old physical medium. This prevents stale pre-format FAT bytes from becoming
allocations while allowing formatting to write only metadata that is actually
dirty.

Runtime FAT materialization advances sequentially. The prefix is persisted only
after the new FAT pages have been written, flushed, and (for HDA) physically
read back. A failed prefix metadata commit leaves those pages outside the
authoritative prefix, so a reboot still interprets them as FREE rather than
trusting a partial transaction.

The information block itself is committed with an exact one-block RMW and
one-block readback verification. This replaces the older eight-block metadata
window.
