#ifndef __JTMOS_DISKSPACE_H__
#define __JTMOS_DISKSPACE_H__

#include "basdef.h"

#define DISKSPACE_MAX_DEVICES 100
#define DISKSPACE_FLAG_BLOCK_DEVICE 0x00000001UL
#define DISKSPACE_FLAG_JTMFS        0x00000002UL
#define DISKSPACE_FLAG_LOW          0x00000004UL
#define DISKSPACE_FLAG_CRITICAL     0x00000008UL
#define DISKSPACE_FLAG_FULL         0x00000010UL

typedef struct {
    DWORD total_units;
    DWORD free_units;
    DWORD unit_size;
    DWORD first_allocatable;
    DWORD min_free_units;
    DWORD samples;
    DWORD enospc_events;
    DWORD last_sample_seconds;
    DWORD last_enospc_seconds;
    DWORD flags;
} JTMOS_DISKSPACE_STATS;

DWORD DiskSpacePercentUnits(DWORD free_units,DWORD total_units);
DWORD DiskSpaceUnitsToKiB(DWORD units,DWORD unit_size);
void DiskSpaceInit(void);
void DiskSpaceInvalidateDevice(int dnr);
int DiskSpaceRefreshDevice(int dnr);
int DiskSpaceGetStats(int dnr,JTMOS_DISKSPACE_STATS *out,int refresh_if_needed);
void DiskSpaceFatTransition(int dnr,DWORD block,DWORD old_value,DWORD new_value);
void DiskSpaceNoteENOSPC(int dnr,const char *context,DWORD requested_bytes);
void DiskSpacePeriodicSample(void);
int DiskSpaceWriteSnapshot(int fd);
int DiskSpaceTroubleshootDevice(int dnr,const char *reason,DWORD requested_bytes,int force);

#endif
