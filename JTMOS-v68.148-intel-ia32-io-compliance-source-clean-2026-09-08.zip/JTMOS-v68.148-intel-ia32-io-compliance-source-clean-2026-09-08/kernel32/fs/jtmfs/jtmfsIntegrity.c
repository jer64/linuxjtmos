/* ========================================================================
 * jtmfsIntegrity.c - streaming, read-only JTMFS media consistency checker
 * (C) 2026 Jari Tuominen / JTMOS
 *
 * Design goals:
 *  - inspect physical media, not the live DIRDB/FlexFAT view;
 *  - bounded memory (one FAT sector, one directory buffer, two bitmaps);
 *  - never repair automatically;
 *  - detect invalid links, loops/cross-links, orphan blocks and bad entries.
 * ======================================================================== */
#include "kernel32.h"
#include "jtmfs.h"
#include "jtmfat.h"
#include "diskcache/dirdb.h"
#include "jtmfsIntegrity.h"

#define JTMFS_FAT_BAD_MIN       0xFFFFFFF0UL
#define JTMFS_FAT_SYSTEM        0xFFFFFFF7UL
#define JTMFS_FAT_EOC_MIN       0xFFFFFFF8UL
#define JTMFS_ENTRY_MAGIC       0xFCE2E37BUL
#define JTMFS_CHECK_DIRQ_INIT   64

typedef struct
{
    int dnr;
    int bs;                 /* physical DEVAPI block size / FAT page size */
    int unit_bs;            /* allocation-unit size */
    int physical_blocks;
    DWORD cluster_sectors;
    int nblocks;            /* allocation-unit count */
    int fat_entries_per_block;
    int cached_fat_page;
    BYTE *fat_block;
    BYTE *data_block;
    BYTE *dirbuf;
    BYTE *reachable;
    BYTE *dirqueued;
    int bitmap_bytes;
    DWORD *dirq;
    int dirq_count;
    int dirq_pos;
    int dirq_capacity;
    int verbose;
    JTMFAT_INFOBLOCK info;
    JTMFS_CHECK_REPORT *r;
} JTMFS_CHECK_CTX;

static int bit_test(BYTE *map, int n)
{
    return (map[n>>3] & (BYTE)(1U<<(n&7))) != 0;
}

static void bit_set(BYTE *map, int n)
{
    map[n>>3] |= (BYTE)(1U<<(n&7));
}

static int check_read_info(JTMFS_CHECK_CTX *c)
{
    int block_nr,byte_offs;

    if(jtmfat_info_location(c->dnr,&block_nr,&byte_offs))
        return 1;
    if(readblock1(c->dnr,block_nr,c->data_block))
    {
        c->r->io_errors++;
        printk("JTMFS fsck: cannot read information block DNR=%d block=%d.\n",
               c->dnr,block_nr);
        return 1;
    }
    memcpy(&c->info,c->data_block+byte_offs,sizeof(c->info));
    if(jtmfat_validateinfoblock(c->dnr,&c->info))
        return 1;
    return 0;
}

static int check_fat_get(JTMFS_CHECK_CTX *c, int entry, DWORD *value)
{
    int page,index,disk_block;
    DWORD *p;

    if(entry<0 || entry>=c->nblocks || value==NULL)
        return 1;
    page=entry/c->fat_entries_per_block;
    index=entry%c->fat_entries_per_block;
    if(page<0 || page>=(int)c->info.fat_length)
        return 1;
    if(page!=c->cached_fat_page)
    {
        disk_block=(int)c->info.fat_offs+page;
        if(disk_block<0 || disk_block>=c->physical_blocks ||
           readblock1(c->dnr,disk_block,c->fat_block))
        {
            c->r->io_errors++;
            printk("JTMFS fsck: physical FAT read failed page=%d disk-block=%d.\n",
                   page,disk_block);
            c->cached_fat_page=-1;
            return 1;
        }
        c->cached_fat_page=page;
    }
    p=(DWORD*)c->fat_block;
    *value=p[index];
    return 0;
}

static int check_name_terminated(const char *name, int length)
{
    int i;
    for(i=0;i<length;i++)
        if(name[i]==0) return 1;
    return 0;
}

static int queue_directory(JTMFS_CHECK_CTX *c, DWORD block)
{
    DWORD *p;
    int newcap;

    if(block==0 || block>=(DWORD)c->nblocks)
        return 1;
    if(bit_test(c->dirqueued,(int)block))
    {
        c->r->crosslinks++;
        if(c->verbose)
            printk("JTMFS fsck: directory block %u is referenced more than once.\n",block);
        return 2;
    }
    bit_set(c->dirqueued,(int)block);
    if(c->dirq_count>=c->dirq_capacity)
    {
        newcap=c->dirq_capacity*2;
        if(newcap<c->dirq_capacity || newcap>c->nblocks)
            newcap=c->nblocks;
        if(newcap<=c->dirq_capacity)
            return 1;
        p=malloc(newcap*(int)sizeof(DWORD));
        if(p==NULL) return 1;
        memcpy(p,c->dirq,c->dirq_count*(int)sizeof(DWORD));
        free(c->dirq);
        c->dirq=p;
        c->dirq_capacity=newcap;
    }
    c->dirq[c->dirq_count++]=block;
    return 0;
}

/* Mark one file chain as reachable and validate every link physically. */
static int check_file_chain(JTMFS_CHECK_CTX *c, DWORD start,
                            int length, DWORD last_hint)
{
    DWORD block,next,last;
    int count,expected,bad;

    if(start==0)
    {
        if(length>0)
        {
            c->r->bad_chains++;
            if(c->verbose)
                printk("JTMFS fsck: non-empty file has no first data block.\n");
            return 1;
        }
        return 0;
    }
    if(start>=(DWORD)c->nblocks || start<(DWORD)c->info.sysarea_length)
    {
        c->r->bad_chains++;
        if(c->verbose)
            printk("JTMFS fsck: file chain starts at illegal block %u.\n",start);
        return 1;
    }

    block=start;
    last=0;
    count=0;
    bad=0;
    for(;;)
    {
        if(block==0 || block>=(DWORD)c->nblocks)
        {
            bad=1;
            break;
        }
        if(bit_test(c->reachable,(int)block))
        {
            c->r->crosslinks++;
            bad=1;
            if(c->verbose)
                printk("JTMFS fsck: FAT loop/cross-link at block %u.\n",block);
            break;
        }
        bit_set(c->reachable,(int)block);
        c->r->reachable_blocks++;
        last=block;
        count++;
        if(count>c->nblocks)
        {
            bad=1;
            break;
        }
        if(check_fat_get(c,(int)block,&next))
        {
            bad=1;
            break;
        }
        if(next>=JTMFS_FAT_EOC_MIN)
            break;
        if(next>=JTMFS_FAT_BAD_MIN || next==0 || next>=(DWORD)c->nblocks || next==block)
        {
            if(c->verbose)
                printk("JTMFS fsck: invalid file FAT link %u -> 0x%x.\n",block,next);
            bad=1;
            break;
        }
        if(next<(DWORD)c->info.sysarea_length)
        {
            if(c->verbose)
                printk("JTMFS fsck: file FAT link %u enters system block %u.\n",block,next);
            bad=1;
            break;
        }
        block=next;
    }

    if(length>=0)
    {
        expected=(length+c->bs-1)/c->bs;
        if(length==0 && start!=0) expected=0;
        if(count!=expected)
        {
            c->r->size_mismatches++;
            if(c->verbose)
                printk("JTMFS fsck: file chain has %d block(s), size requires %d.\n",
                       count,expected);
        }
    }
    if(last_hint && last_hint!=last)
    {
        c->r->size_mismatches++;
        if(c->verbose)
            printk("JTMFS fsck: LastDataBlock=%u but chain ends at %u.\n",last_hint,last);
    }
    if(bad) c->r->bad_chains++;
    return bad;
}

/* Read, mark and parse one directory chain. */
static int check_directory(JTMFS_CHECK_CTX *c, DWORD start)
{
    DWORD block,next;
    int used,blocks,limit,i,terminated,bad,copy;
    JTMFS_FILE_ENTRY *fe;

    if(start==0 || start>=(DWORD)c->nblocks)
    {
        c->r->bad_chains++;
        return 1;
    }
    block=start;
    used=0;
    blocks=0;
    bad=0;
    memset(c->dirbuf,0,MAX_BYTES_PER_DIR);

    for(;;)
    {
        if(block==0 || block>=(DWORD)c->nblocks)
        {
            bad=1;
            break;
        }
        if(bit_test(c->reachable,(int)block))
        {
            c->r->crosslinks++;
            bad=1;
            if(c->verbose)
                printk("JTMFS fsck: directory loop/cross-link at block %u.\n",block);
            break;
        }
        bit_set(c->reachable,(int)block);
        c->r->reachable_blocks++;
        {
            DWORD lba=jtmfat_unit_to_lba(c->dnr,block);
            if(lba==0xffffffffUL ||
               readblocks1(c->dnr,(long)lba,c->data_block,(int)c->cluster_sectors)!=(int)c->cluster_sectors)
            {
                c->r->io_errors++;
                bad=1;
                break;
            }
        }
        if(used>=MAX_BYTES_PER_DIR)
        {
            bad=1;
            break;
        }
        copy=c->unit_bs;
        if(copy>MAX_BYTES_PER_DIR-used) copy=MAX_BYTES_PER_DIR-used;
        memcpy(c->dirbuf+used,c->data_block,copy);
        used+=copy;
        blocks++;
        if(blocks>c->nblocks)
        {
            bad=1;
            break;
        }
        if(check_fat_get(c,(int)block,&next))
        {
            bad=1;
            break;
        }
        if(next>=JTMFS_FAT_EOC_MIN)
            break;
        if(next>=JTMFS_FAT_BAD_MIN || next==0 || next>=(DWORD)c->nblocks || next==block)
        {
            if(c->verbose)
                printk("JTMFS fsck: invalid directory FAT link %u -> 0x%x.\n",block,next);
            bad=1;
            break;
        }
        if(next<(DWORD)c->info.sysarea_length)
        {
            if(c->verbose)
                printk("JTMFS fsck: directory FAT link %u enters system block %u.\n",block,next);
            bad=1;
            break;
        }
        if(used>=MAX_BYTES_PER_DIR)
        {
            if(c->verbose)
                printk("JTMFS fsck: directory at %u exceeds %d-byte DIRDB limit.\n",
                       start,MAX_BYTES_PER_DIR);
            bad=1;
            break;
        }
        block=next;
    }

    c->r->directories++;
    limit=used/(int)sizeof(JTMFS_FILE_ENTRY);
    terminated=0;
    for(i=0;i<limit;i++)
    {
        fe=(JTMFS_FILE_ENTRY*)(c->dirbuf+i*sizeof(JTMFS_FILE_ENTRY));
        if(!fe->name[0])
        {
            terminated=1;
            break;
        }
        c->r->entries++;
        if(!check_name_terminated(fe->name,(int)sizeof(fe->name)) ||
           fe->magicNumber!=JTMFS_ENTRY_MAGIC)
        {
            c->r->bad_entries++;
            bad=1;
            if(c->verbose)
                printk("JTMFS fsck: bad directory entry #%d in directory block %u.\n",i,start);
            continue;
        }
        if(!JTMFS_TYPE_IS_VALID(fe->type))
        {
            c->r->bad_entries++;
            bad=1;
            if(c->verbose)
                printk("JTMFS fsck: invalid entry type 0x%x for '%s' in directory block %u.\n",
                       fe->type,fe->name,start);
            continue;
        }
        if(JTMFS_TYPE_IS_DIRNAME(fe->type))
            continue;
        if(fe->length==-1)
        {
            c->r->deleted_entries++;
            continue;
        }
        if(!strcmp(fe->name,".") || !strcmp(fe->name,".."))
        {
            if(!JTMFS_TYPE_IS_DIRECTORY(fe->type) || fe->FirstDataBlock==0 ||
               fe->FirstDataBlock>=(DWORD)c->nblocks)
            {
                c->r->bad_entries++;
                bad=1;
            }
            continue;
        }
        if(JTMFS_TYPE_IS_DIRECTORY(fe->type))
        {
            if(fe->FirstDataBlock==0 || fe->FirstDataBlock>=(DWORD)c->nblocks ||
               queue_directory(c,fe->FirstDataBlock))
            {
                c->r->bad_entries++;
                bad=1;
            }
        }
        else
        {
            c->r->files++;
            if(check_file_chain(c,fe->FirstDataBlock,fe->length,fe->LastDataBlock))
                bad=1;
        }
    }
    if(!terminated)
    {
        c->r->bad_entries++;
        bad=1;
        if(c->verbose)
            printk("JTMFS fsck: directory at %u has no terminating empty entry.\n",start);
    }
    if(bad) c->r->bad_chains++;
    return bad;
}

static int scan_fat_and_orphans(JTMFS_CHECK_CTX *c)
{
    DWORD value;
    int i,bad;

    bad=0;
    for(i=0;i<c->nblocks;i++)
    {
        if((i&0x3ff)==0) jtmfs_cooperative_yield((unsigned long)i);
        if(check_fat_get(c,i,&value))
        {
            bad=1;
            break;
        }
        if(value==0)
            c->r->fat_free++;
        else if(value==JTMFS_FAT_SYSTEM)
            c->r->fat_reserved++;
        else if(value>=JTMFS_FAT_EOC_MIN)
            c->r->fat_eoc++;
        else if(value>=JTMFS_FAT_BAD_MIN || value>=(DWORD)c->nblocks || value==(DWORD)i)
        {
            c->r->fat_invalid++;
            bad=1;
        }
        else
            c->r->fat_links++;

        if(i<(int)c->info.sysarea_length && i!=(int)c->info.data_offs)
        {
            if(value!=JTMFS_FAT_SYSTEM)
            {
                c->r->fat_invalid++;
                bad=1;
                if(c->verbose)
                    printk("JTMFS fsck: system FAT entry %d is 0x%x, expected reserved.\n",i,value);
            }
        }
        else if(i>=(int)c->info.sysarea_length && value==JTMFS_FAT_SYSTEM)
        {
            c->r->fat_invalid++;
            bad=1;
            if(c->verbose)
                printk("JTMFS fsck: data-area block %d is unexpectedly system-reserved.\n",i);
        }

        if(i>=(int)c->info.sysarea_length && value!=0 && value!=JTMFS_FAT_SYSTEM &&
           !bit_test(c->reachable,i))
            c->r->orphan_blocks++;
    }
    return bad;
}

int jtmfs_check_device(int dnr, int verbose, JTMFS_CHECK_REPORT *report)
{
    JTMFS_CHECK_CTX c;
    JTMFS_CHECK_REPORT local;
    int bad,initial_cap;
    DWORD root;

    if(report==NULL) report=&local;
    memset(report,0,sizeof(*report));
    memset(&c,0,sizeof(c));
    c.dnr=dnr;
    c.verbose=verbose;
    c.r=report;
    c.cached_fat_page=-1;

    if(!isValidDevice(dnr)) return 1;
    c.bs=getblocksize(dnr);
    c.unit_bs=(int)jtmfat_unitsize(dnr);
    c.cluster_sectors=jtmfat_clustersectors(dnr);
    c.physical_blocks=getsize(dnr);
    c.nblocks=(int)jtmfat_unitcount(dnr);
    if(c.bs<(int)sizeof(DWORD) || c.unit_bs<c.bs || c.unit_bs>64*1024 ||
       c.cluster_sectors==0 || c.physical_blocks<=0 || c.nblocks<=0 ||
       (c.bs%(int)sizeof(DWORD))!=0)
        return 2;
    c.fat_entries_per_block=c.bs/(int)sizeof(DWORD);
    c.bitmap_bytes=(c.nblocks+7)/8;
    report->blocks_total=(DWORD)c.nblocks;
    report->block_size=(DWORD)c.unit_bs;

    c.fat_block=malloc(c.bs);
    c.data_block=malloc(c.unit_bs);
    c.dirbuf=malloc(MAX_BYTES_PER_DIR);
    c.reachable=malloc(c.bitmap_bytes);
    c.dirqueued=malloc(c.bitmap_bytes);
    initial_cap=JTMFS_CHECK_DIRQ_INIT;
    if(initial_cap>c.nblocks) initial_cap=c.nblocks;
    if(initial_cap<1) initial_cap=1;
    c.dirq=malloc(initial_cap*(int)sizeof(DWORD));
    c.dirq_capacity=initial_cap;
    if(c.fat_block==NULL || c.data_block==NULL || c.dirbuf==NULL ||
       c.reachable==NULL || c.dirqueued==NULL || c.dirq==NULL)
    {
        if(c.fat_block) free(c.fat_block);
        if(c.data_block) free(c.data_block);
        if(c.dirbuf) free(c.dirbuf);
        if(c.reachable) free(c.reachable);
        if(c.dirqueued) free(c.dirqueued);
        if(c.dirq) free(c.dirq);
        return 3;
    }
    memset(c.reachable,0,c.bitmap_bytes);
    memset(c.dirqueued,0,c.bitmap_bytes);

    bad=0;
    if(check_read_info(&c))
        bad=1;
    else
    {
        root=c.info.data_offs;
        if(root==0 || root>=(DWORD)c.nblocks || queue_directory(&c,root))
            bad=1;
        while(!bad && c.dirq_pos<c.dirq_count)
        {
            if(check_directory(&c,c.dirq[c.dirq_pos++]))
                bad=1;
            /* Continue after structural errors when possible: a useful fsck
             * report is better than stopping at the first bad file. */
            if(bad && c.r->io_errors==0)
                bad=0;
        }
        if(scan_fat_and_orphans(&c)) bad=1;
        if(report->bad_entries || report->bad_chains || report->crosslinks ||
           report->fat_invalid || report->orphan_blocks ||
           report->size_mismatches || report->io_errors)
            bad=1;
    }

    free(c.fat_block);
    free(c.data_block);
    free(c.dirbuf);
    free(c.reachable);
    free(c.dirqueued);
    free(c.dirq);
    return bad ? 1 : 0;
}
