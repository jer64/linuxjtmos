//=====================================================================================
// createfat.c - FAT & info block creation.
//
// (C) 2003 by Jari Tuominen
//
// Note: The largest block size the FAT system can handle is 16K,
// Formatting drives with larger than 16K blocks will lead into
// corruption of the file system.
// New: Now also creates more detailed information block,
// which contains specific information about the file system,
// kernel and boot loader configuration.
// The present createfat also automatically detects standard
// BIOS drives, e.g. A:, B:, C:, D: drives and writes
// boot loader on the drive with appropriate configuration.
//=====================================================================================
#include <stdio.h>
#include "kernel32.h"
#include "jtmfs.h"
#include "jtmfat.h"
#include "flexFat.h"
#include "createfat.h"

/* V68.143: mkfs is dirty-metadata driven. Large media still use clustered
 * allocation, but formatting never sweeps the complete FAT. Only the FAT
 * sector prefix containing system/root entries is materialized initially; the
 * remaining FAT is persistent lazy-zero state. */

static DWORD JtmfsChooseClusterSectors(DWORD nblocks, int blocksize)
{
    DWORD blocks_per_mib,capacity_mib,cs;
    if(blocksize<=0) return 1;
    blocks_per_mib=(1024UL*1024UL)/(DWORD)blocksize;
    if(blocks_per_mib==0) return 1;
    capacity_mib=nblocks/blocks_per_mib;
    if(capacity_mib>=262144UL) cs=64UL;      /* >=256 GiB -> 32 KiB @512 */
    else if(capacity_mib>=65536UL) cs=32UL;  /* >=64 GiB  -> 16 KiB */
    else if(capacity_mib>=16384UL) cs=16UL;  /* >=16 GiB  -> 8 KiB */
    else if(capacity_mib>=4096UL) cs=8UL;    /* >=4 GiB   -> 4 KiB */
    else cs=1UL;                             /* legacy sector FAT */
    while(cs>1UL && cs*(DWORD)blocksize>32768UL) cs>>=1;
    return cs;
}

/* Build only the physically dirty FAT prefix needed by a new filesystem.
 *
 * Old mkfs wrote and read back inf->fat_length sectors. V68.143 writes only
 * enough FAT sectors to contain [0,sysarea_length), with every unused entry in
 * the last dirty sector explicitly zeroed. The untouched tail is protected by
 * the lazy-zero prefix stored in fatChecksum32 and is never trusted as disk
 * data until first materialization. */
static int JtmfsInitializeDirtyFat(int dnr, JTMFAT_INFOBLOCK *inf)
{
    BYTE *io,*verify;
    DWORD bs,entries_per_sector,dirty_pages,entries,system_entries;
    DWORD page,entry,base,disk_block;
    DWORD *dw;
    int i;

    if(inf==NULL || !isValidDevice(dnr)) return 1;
    bs=(DWORD)getblocksize(dnr);
    if(bs<4 || (bs&3UL)) return 2;
    entries=jtmfat_infoblock_uses_clusters(inf)?(DWORD)inf->max_val:inf->n_blocks;
    system_entries=inf->sysarea_length;
    if(system_entries==0 || system_entries>entries) return 3;
    entries_per_sector=bs/4UL;
    dirty_pages=system_entries/entries_per_sector;
    if(system_entries%entries_per_sector) dirty_pages++;
    if(dirty_pages==0) dirty_pages=1;
    if(dirty_pages>inf->fat_length || dirty_pages>JTMFS_LAZY_FAT_PAGE_MASK) return 4;

    io=(BYTE*)malloc((size_t)(dirty_pages*bs));
    verify=(BYTE*)malloc((size_t)(dirty_pages*bs));
    if(io==NULL || verify==NULL)
    {
        if(io) free(io);
        if(verify) free(verify);
        return 5;
    }
    memset(io,0,(size_t)(dirty_pages*bs));
    for(page=0;page<dirty_pages;page++)
    {
        dw=(DWORD*)(io+page*bs);
        base=page*entries_per_sector;
        for(entry=0;entry<entries_per_sector;entry++)
        {
            DWORD unit=base+entry;
            if(unit<system_entries) dw[entry]=0xFFFFFFF7UL;
            else dw[entry]=0;
        }
    }

    dprintk("MKFS/dirty-FAT: DNR=%d writing only %u dirty FAT page(s) of %u; system entries=%u.\n",
            dnr,(unsigned)dirty_pages,(unsigned)inf->fat_length,(unsigned)system_entries);
    if(driver_FlushDrive(dnr)!=0) { free(io); free(verify); return 6; }
    driver_block_cache_invalidate(dnr);
    disk_block=inf->fat_offs;
    if(writeblocks1(dnr,(long)disk_block,io,(int)dirty_pages)!=(int)dirty_pages)
    {
        free(io); free(verify); return 7;
    }
    if(driver_FlushDrive(dnr)!=0) { free(io); free(verify); return 8; }
    driver_block_cache_invalidate(dnr);

    /* Verify only what mkfs actually dirtied. */
    memset(verify,0,(size_t)(dirty_pages*bs));
    if(readblocks1(dnr,(long)disk_block,verify,(int)dirty_pages)!=(int)dirty_pages)
    {
        free(io); free(verify); return 9;
    }
    if(memcmp(io,verify,(size_t)(dirty_pages*bs))!=0)
    {
        for(i=0;i<(int)(dirty_pages*bs);i++) if(io[i]!=verify[i]) break;
        dprintk("MKFS/dirty-FAT: verify mismatch byte=%d disk-LBA=%u.\n",
                i,(unsigned)(disk_block+(DWORD)i/bs));
        free(io); free(verify); return 10;
    }
    free(io); free(verify);

    inf->fatChecksum32=JTMFS_LAZY_FAT_FLAG|dirty_pages;
    if(WriteInformationBlock(dnr,inf)) return 11;
    driver_block_cache_invalidate(dnr);
    flexDiskChange(dnr);
    dprintk("MKFS/dirty-FAT: committed %u/%u FAT pages; untouched tail is logical zero.\n",
            (unsigned)dirty_pages,(unsigned)inf->fat_length);
    return 0;
}


/* Return nonzero only when the on-disk JTMFS geometry leaves the full current
 * 1 MiB kernel payload area between the fixed 32 KiB boot section and FAT.
 * The geometry check is authoritative for pre-V67.8.57.2 filesystems too. */
static int JtmfsKernelRegionIsCurrent(int dnr, JTMFAT_INFOBLOCK *inf)
{
	int blocksize;
	DWORD startblock, kernelblocks, endblock;

	if(inf==NULL || !isValidDevice(dnr))
		return 0;
	blocksize=getblocksize(dnr);
	if(blocksize<=0 ||
	   (FAT_BOOT_SECTION_LEN_K*1024UL)%(DWORD)blocksize ||
	   JTMFS_KERNEL_RESERVE_BYTES%(DWORD)blocksize)
		return 0;
	startblock=(DWORD)(FAT_BOOT_SECTION_LEN_K*1024UL)/(DWORD)blocksize;
	kernelblocks=JTMFS_KERNEL_RESERVE_BYTES/(DWORD)blocksize;
	endblock=startblock+kernelblocks;
	if(inf->kernel_offs!=startblock || inf->bootblock_size<endblock ||
	   inf->fat_offs<endblock || inf->fat_offs>inf->n_blocks)
		return 0;
	/* New formatters publish the capacity explicitly.  A zero tag means an
	 * older filesystem; geometry still decides whether it is large enough. */
	if(inf->res3==JTMFS_BOOT_LAYOUT_TAG &&
	   (inf->res4<JTMFS_KERNEL_RESERVE_BYTES ||
	    inf->res5<JTMFS_BOOT_LAYOUT_VERSION))
		return 0;
	return 1;
}

// FAT CREATION
// ------------
//
// - Allocates & writes a boot loader on the drive if is bootable.
// - If drive is bootable, a 1 MiB kernel payload region is reserved on the drive.
// - Updates boot record.
// - Updates information block.
// - Creates a blank FAT table, JTMOS stylish.
//
// This function makes sure that most of it's writes and
// works get done properly.
//
int jtmfat_createfat(int dnr)
{
	int i,i2,i3,i4,l,data1,v1,v2,r,
		tick,tick2,trigger,trigger2;
	BYTE *tmp,*p;
	char *s,*s2;
	int bytes_per_entry=4,bdrv;
	BYTE *vali;
	char devname[50];
	JTMFAT_INFOBLOCK *inf;
	
	DEBUGFUNC

	//---------------------------------------------------------------------------------------------
	if(jtmfat_ready!=TRUE || fatsys==NULL)
		return 10;

	// Fixed JTMFAT/FlexFAT tables contain exactly N_CFAT_STRUCTURES slots.
	if(dnr<0 || dnr>=N_CFAT_STRUCTURES || !isValidDevice(dnr))
	{
		dprintk("jtmfat_createfat: Invalid device %d.\n",
			dnr);
		return 11;
	}

	//
	if( !getsize(dnr) )
	{
		dprintk("jtmfat_createfat: Size of device %d is zero blocks.\n", dnr);
		return 12;
	}

	//---------------------------------------------------------------------------------------------
	// Get device name
	driver_getdevicename(dnr, devname);

	//////// FORMAT CALLER HAS ALREADY DRAINED/INVALIDATED OLD CACHE ///////////
	/* Do NOT call jtmfat_chdev() here: it is a mount/media-refresh primitive
	 * which tries to read the OLD information block.  On a blank disk this is
	 * exactly where detstr=ff ff ff... came from during eMachines mkfs tests. */
	dprintk("MKFS: old filesystem caches already drained; no pre-format info-block reload for DNR=%d.\n",dnr);

	//////////////////////////////////////////////////////////////////////////////////////////

	// Convert to BIOS drive.
	bdrv = DetermineBootdrv(devname);

	// Which BIOS drive.
	switch(bdrv)
	{
		//
		case 0:
		case 1:
		dprintk("%s: is a floppy disk drive in BIOS standards.\n",
			devname);
		break;

		//
		case 0x80:
		case 0x81:
		case 0x82:
		case 0x83:
		dprintk("%s: is an IDE hard disk drive in BIOS standards.\n",
			devname);
		break;

		//
		default:
		break;
	}



	// -------------------------------------------------------
	// And now we need to store all this information on
	// the bootblock.
	// There is a slight problem, if the disk will be made
	// bootable, it still needs to be JTMOS complaint,
	// or it will not be accessible from JTMOS,
	// so probably whetever a bootdisk will be accessed
	// it'll always return invalid values because of
	// the incorrect bootblock.
	// However, the problem is not that big since,
	// many bootdisks often only contain just the kernel image
	// and perhaps a root ramdisk on it too, or on another disk.
	// Perhaps this problem will be fixed in the future.
	// For example slackware comes with two disks,
	// boot(kernel) disk and the ramdisk image disk.

	// Install boot loader.  When formatting a BIOS hard disk while JTMOS was
	// booted from a floppy, use the exact boot loader from that running boot
	// medium.  This keeps mkfs hda in sync with the kernel/loader combination
	// which actually started the machine.
	r = InstallBootLoader(dnr, bdrv);
	if(r)
	{
		dprintk("jtmfat_createfat: boot-loader installation failed, error %d.\n", r);
		return r;
	}

	// Build information block.  A failed/partial JTMFAT init may have no
	// per-device cache buffer; refuse mkfs instead of dereferencing NULL.
	if(fatsys->bb[dnr]==NULL)
	{
		fatsys->bb[dnr]=malloc(sizeof(JTMFAT_INFOBLOCK));
		if(fatsys->bb[dnr]==NULL) return 13;
	}
	inf = BuildInfoBlock(dnr, bdrv);
	if(inf==NULL)
	{
		dprintk("jtmfat_createfat: Could not build information block for drive %d.\n", dnr);
		return 13;
	}
	// Write on drive and propagate media/device errors.
	if(WriteInformationBlock(dnr, inf))
	{
		dprintk("jtmfat_createfat: Could not write information block on drive %d.\n", dnr);
		return 14;
	}

	// -------------------------------------------------------

	/*
	 * The on-disk information block now defines the FAT geometry.  The old
	 * DiskChange() wrapper only called jtmfat_chdev() and did not actually
	 * invalidate FlexFAT, so a FAT cache from the previous filesystem could
	 * survive the format.  At this point the old FAT has already been flushed
	 * before formatting started; discard it and reload the just-written info
	 * block explicitly before touching the new FAT.
	 */
	dprintk("Refreshing drive after new JTMFS information block ...\n");
	flexDiskChange(dnr);
	dirdb_DiskChange(dnr);
	fatsys->isJTMFS[dnr] = FALSE;
	if(jtmfat_LoadNewInfoBlock(dnr) || !fatsys->isJTMFS[dnr])
	{
		dprintk("jtmfat_createfat: Could not reload new JTMFS information block.\n");
		return 15;
	}

	dprintk("Detection string(detstr) = '%s'.\n",
		fatsys->bb[dnr]->detstr);

	// ------ INITIALIZE ONLY DIRTY FAT PAGES (V68.143)
	// The untouched FAT tail is lazy-zero and must never be physically swept by mkfs.
	dprintk("MKFS: initializing only dirty FAT pages; no whole-FAT write/readback pass.\n");
	r=JtmfsInitializeDirtyFat(dnr,fatsys->bb[dnr]);
	if(r)
	{
		dprintk("jtmfat_createfat: dirty FAT initialization failed, error %d.\n",r);
		return 1977+r;
	}

	/* Semantic probes touch only the materialized first page or the logical-zero
	 * tail; no complete FAT readback is performed. */
	if((DWORD)jtmfat_getblock(dnr,0)!=0xFFFFFFF7UL) return 1980;
	i=(int)fatsys->bb[dnr]->data_offs;
	if(i<=0 || (DWORD)i>=jtmfat_unitcount(dnr) ||
	   (DWORD)jtmfat_getblock(dnr,i)!=0xFFFFFFF7UL) return 1981;
	i=(int)fatsys->bb[dnr]->sysarea_length;
	if(i<=0 || (DWORD)i>=jtmfat_unitcount(dnr) || jtmfat_getblock(dnr,i)!=0) return 1981;
	dprintk("MKFS: dirty-FAT probes OK; untouched FAT tail is logical zero.\n");

	// RELEASE A BLOCK FOR ROOT DIR...
	// However, we will need to release the first block of the root directory
	// for use(createdirectory will expect this from us)
	dprintk("Releasing a block from FAT for rootdir on block #%d.\n", jtmfat_getrootdir(dnr));
	i = jtmfat_getrootdir(dnr);
	if(i<=0 || (DWORD)i>=jtmfat_unitcount(dnr) || jtmfat_setblock(dnr, i, 0))
		return 1979;
	/* Flush only the FAT page dirtied by releasing the root entry. */
	if(flexFlushFATChecked(dnr)!=0)
		return 1982;

	/* Verify only the root/system page, never the whole FAT. */
	flexDiskChange(dnr);
	if((DWORD)jtmfat_getblock(dnr, 0) != 0xFFFFFFF7UL)
	{
		dprintk("jtmfat_createfat: FAT readback failed at system entry 0.\n");
		return 1980;
	}
	i = jtmfat_getrootdir(dnr);
	if(i<=0 || (DWORD)i>=jtmfat_unitcount(dnr) || jtmfat_getblock(dnr, i)!=0)
	{
		dprintk("jtmfat_createfat: FAT readback failed at root entry %d.\n", i);
		return 1981;
	}

	return 0;
}

// Build information block for a specified drive
// on system boot block and return PTR to it.
JTMFAT_INFOBLOCK *BuildInfoBlock(int dnr, int bdrv)
{
	int i,i2,i3,i4,l,data1,v1,v2,
		tick,tick2,trigger,trigger2;
	int blocksize;
	BYTE *tmp,*p;
	char *s,*s2;
	int bytes_per_entry=4;
	BYTE *vali;
	JTMFAT_INFOBLOCK *inf;
	
	DEBUGFUNC
	if(fatsys==NULL || dnr<0 || dnr>=N_CFAT_STRUCTURES ||
	   !isValidDevice(dnr) || fatsys->bb[dnr]==NULL)
		return NULL;

	// BUILD INFO BLOCK, SPECIFY PARAMETERS
	// ------------------------------------

	//
	if(getsize(dnr)<10)
	{
		return NULL;
	}

	//
	inf = fatsys->bb[dnr];
	memset(inf, 0, sizeof(JTMFAT_INFOBLOCK));

	blocksize=getblocksize(dnr);
	if(blocksize<=0 || blocksize>16*1024) return NULL;
	inf->n_blocks=(DWORD)getsize(dnr);
	inf->block_size=(DWORD)blocksize;
	inf->bootblock_size=((FAT_BOOT_SECTION_LEN_K*1024UL)+(DWORD)blocksize-1)/(DWORD)blocksize;
	if( (bdrv&0xF0)==0x80 )
	{
		if((FAT_BOOT_SECTION_LEN_K*1024UL)%(DWORD)blocksize ||
		   JTMFS_KERNEL_RESERVE_BYTES%(DWORD)blocksize)
		{
			dprintk("BuildInfoBlock: blocksize %d cannot represent 1 MiB boot layout exactly.\n",blocksize);
			return NULL;
		}
		inf->kernel_offs=(DWORD)(FAT_BOOT_SECTION_LEN_K*1024UL)/(DWORD)blocksize;
		inf->bootblock_size+=JTMFS_KERNEL_RESERVE_BYTES/(DWORD)blocksize;
		inf->res3=JTMFS_BOOT_LAYOUT_TAG;
		inf->res4=JTMFS_KERNEL_RESERVE_BYTES;
		inf->res5=JTMFS_BOOT_LAYOUT_VERSION;
	}
	else inf->kernel_offs=0;

	/* FAT / allocation geometry.  The physical FAT itself is always addressed in
	 * DEVAPI blocks.  On large disks, however, each FAT entry describes one
	 * allocation cluster instead of one sector.  res6=sectors/cluster and
	 * res7=physical LBA of cluster #1 (root). */
	{
		DWORD nblocks,fatblocks,entries_per_block,cluster_sectors;
		DWORD data_lba,cluster_count,nentries,base,aligned,i;
		DWORD blocks_per_mib,capacity_mib;

		if((blocksize&3)!=0) return NULL;
		nblocks=(DWORD)getsize(dnr);
		entries_per_block=(DWORD)blocksize/4UL;
		if(entries_per_block==0) return NULL;
		cluster_sectors=JtmfsChooseClusterSectors(nblocks,blocksize);

		if(cluster_sectors<=1UL)
		{
			fatblocks=nblocks/entries_per_block;
			if(nblocks%entries_per_block) fatblocks++;
			if(fatblocks>0xffffffffUL-2UL) return NULL;
			fatblocks+=2UL;
			if(inf->bootblock_size>0xffffffffUL-fatblocks-10UL) return NULL;
			inf->fat_length=fatblocks;
			inf->max_val=(int)nblocks;
			inf->sysarea_length=inf->bootblock_size+fatblocks+10UL;
			inf->fat_offs=inf->bootblock_size;
			inf->data_offs=inf->sysarea_length-1UL;
			inf->res6=1;
			inf->res7=0;
		}
		else
		{
			/* Fixed-point iteration: FAT length changes data_lba, which changes
			 * the number of clusters.  Converges in a couple of rounds. */
			cluster_count=(nblocks-inf->bootblock_size)/cluster_sectors;
			if(cluster_count<2UL) return NULL;
			fatblocks=0; data_lba=0;
			for(i=0;i<8;i++)
			{
				nentries=cluster_count+1UL; /* entry 0 reserved, clusters 1..N */
				fatblocks=nentries/entries_per_block;
				if(nentries%entries_per_block) fatblocks++;
				fatblocks+=2UL;
				base=inf->bootblock_size+fatblocks+10UL;
				aligned=(base+cluster_sectors-1UL)&~(cluster_sectors-1UL);
				if(aligned>=nblocks) return NULL;
				nentries=(nblocks-aligned)/cluster_sectors;
				if(nentries==cluster_count) { data_lba=aligned; break; }
				cluster_count=nentries;
			}
			if(data_lba==0)
			{
				base=inf->bootblock_size+fatblocks+10UL;
				data_lba=(base+cluster_sectors-1UL)&~(cluster_sectors-1UL);
				cluster_count=(nblocks-data_lba)/cluster_sectors;
			}
			if(cluster_count<2UL || cluster_count>=0x7ffffffeUL) return NULL;
			inf->fat_offs=inf->bootblock_size;
			inf->fat_length=fatblocks;
			inf->data_offs=1UL;       /* root cluster ID */
			inf->sysarea_length=2UL;  /* first allocatable cluster ID */
			inf->max_val=(int)(cluster_count+1UL);
			inf->res6=cluster_sectors;
			inf->res7=data_lba;
			inf->res5=JTMFS_CLUSTER_LAYOUT_VERSION;
		}

		if(inf->fat_offs>=nblocks || inf->fat_length>nblocks-inf->fat_offs)
			return NULL;
		blocks_per_mib=(1024UL*1024UL)/(DWORD)blocksize;
		capacity_mib=blocks_per_mib ? nblocks/blocks_per_mib : 0;
		dprintk("MKFS geometry: DNR=%d blocks=%u bs=%d capacity=%u MiB boot=%u kernel=%u FAT=%u+%u cluster=%u sectors (%u KiB) units=%u root=%u first=%u dataLBA=%u.\n",
		        dnr,(unsigned)inf->n_blocks,blocksize,(unsigned)capacity_mib,
		        (unsigned)inf->bootblock_size,(unsigned)inf->kernel_offs,
		        (unsigned)inf->fat_offs,(unsigned)inf->fat_length,
		        (unsigned)inf->res6,(unsigned)((inf->res6*(DWORD)blocksize)/1024UL),
		        (unsigned)inf->max_val,(unsigned)inf->data_offs,
		        (unsigned)inf->sysarea_length,(unsigned)inf->res7);
	}

	/* V68.143: advertise lazy-zero FAT semantics before the first information
	 * block commit.  Prefix=0 means no FAT sector is authoritative yet. */
	if(inf->res5<JTMFS_LAZY_FAT_LAYOUT_VERSION)
		inf->res5=JTMFS_LAZY_FAT_LAYOUT_VERSION;
	inf->fatChecksum32=JTMFS_LAZY_FAT_FLAG;

	// Store identifier.
	strcpy(inf->detstr, "JTMFS");

	//////////////////////////////////////////////////////////////////////////////////////////
	// Display values
/*	ReportMessage("[:- FAT creation: fat_length=%d, sysarea_length=%d,
		fat_offs=%d, data_offs=%d]\n",
		inf->fat_length,
		inf->sysarea_length,
		inf->fat_offs,
		inf->data_offs);*/

	//
	s = inf->detstr;
	ReportMessage("Detection string(detstr) = '%s'.\n",
	               s);

	// Error check: use the same legacy/cluster-aware validator used at mount.
	if(jtmfat_validateinfoblock(dnr,inf) ||
	   (((bdrv&0xF0)==0x80) && !JtmfsKernelRegionIsCurrent(dnr, inf)))
	{
		dprintk("FATAL LOGIC FAILURE: FAT CREATION FAILED, INVALID PARAMETERS DETECTED!\n");
		return NULL;
	}

	//
	return inf;
}

// Set correct values on a boot record.
void BuildBootRecord(int dnr, BOOTRECORD *br, int bdrv)
{
	int i;

	DEBUGFUNC

	// Store offset to "kernel image on HD".
	// Used by HD boot loader to locate kernel
	// on the hard disk.
	i = FAT_BOOT_SECTION_LEN_K*1024;
	br->boot_len_k = i;
	// Define drive CHS parameters
	// (we should make a call to hard disk driver
	//  to figure out the correct parameters here!)
	br->cylinders =	895;
	br->heads =	5;
	br->sectors =	55;
	// Store boot drive variable.
	br->bootdrv = bdrv;
	// Store boot sector signature.
	br->signature = 0xAA55;
}

// Determine which BIOS drive the device name refers to.
int DetermineBootdrv(const char *devname)
{
	int bd;

	// Determine BIOS boot drive.
	if(!strcmp(devname,"hda"))
		bd = 0x80;
	else
	if(!strcmp(devname,"hdb"))
		bd = 0x81;
	else
	if(!strcmp(devname,"hdc"))
		bd = 0x82;
	else
	if(!strcmp(devname,"hdd"))
		bd = 0x83;
	else
	if(!strcmp(devname,"floppy"))
		bd = 0;
	else
	if(!strcmp(devname,"floppy2"))
		bd = 1;
	else
	{
		// Default to floppy A: if unknown
		// (boot sector loader will be not used on
		//  this media anyway, probably!)
		bd = 0xFF;
		dprintk("Note: This is a non-BIOS drive, therefore it does not support system boot up feature.\n");
	}

	//
	return bd;
}

// Update information block on drive.
/*
 * Bigfoot metadata transaction.
 *
 * The first JTMFS information record lives in logical block 1 on 512-byte
 * media.  During bring-up we found that the SATA/AHCI path reliably handled
 * the boot-loader as 4 KiB Bigfoot transfers while the one-sector metadata
 * transaction could fail its immediate physical readback.  Keep the on-disk
 * layout unchanged, but commit metadata as an aligned 8-block read/modify/
 * write window.  This also preserves the neighbouring boot-loader sectors.
 */
int WriteInformationBlock(int dnr, JTMFAT_INFOBLOCK *inf)
{
    BYTE *block,*verify;
    JTMFAT_INFOBLOCK image,readback_info;
    int bs,bn,bo,attempt,flushrv,i,firstdiff;

    DEBUGFUNC
    if(!isValidDevice(dnr) || inf==NULL) return 1;
    memcpy(&image,inf,sizeof(image));
    bs=getblocksize(dnr);
    if(bs<=0 || bs>1024*64 || jtmfat_info_location(dnr,&bn,&bo)) return 2;

    block=malloc(bs);
    verify=malloc(bs);
    if(block==NULL || verify==NULL)
    {
        if(block) free(block);
        if(verify) free(verify);
        return 3;
    }

    dprintk("MKFS/info: exact dirty-block commit DNR=%d LBA=%d offset=%d bs=%d.\n",
            dnr,bn,bo,bs);
    for(attempt=1;attempt<=3;attempt++)
    {
        if(driver_FlushDrive(dnr)!=0) continue;
        driver_block_cache_invalidate(dnr);
        if(readblock1(dnr,bn,block))
        {
            dprintk("MKFS/info: attempt %d pre-read failed LBA=%d.\n",attempt,bn);
            continue;
        }

        memcpy(block+bo,&image,sizeof(image));
        if(writeblock1(dnr,bn,block))
        {
            dprintk("MKFS/info: attempt %d exact-block write failed LBA=%d.\n",attempt,bn);
            continue;
        }
        flushrv=driver_FlushDrive(dnr);
        if(flushrv!=0)
        {
            dprintk("MKFS/info: attempt %d flush failed rv=%d.\n",attempt,flushrv);
            continue;
        }

        driver_block_cache_invalidate(dnr);
        memset(verify,0,bs);
        if(readblock1(dnr,bn,verify)) continue;
        memcpy(&readback_info,verify+bo,sizeof(readback_info));
        if(memcmp(block,verify,(size_t)bs)==0 &&
           !memcmp(readback_info.detstr,"JTMFS",5))
        {
            memcpy(inf,&image,sizeof(image));
            free(block); free(verify);
            dprintk("MKFS/info: exact dirty block LBA=%d physical verify OK attempt=%d.\n",
                    bn,attempt);
            return 0;
        }

        firstdiff=-1;
        for(i=0;i<bs;i++) if(block[i]!=verify[i]) { firstdiff=i; break; }
        dprintk("MKFS/info: attempt %d exact-block verify mismatch LBA=%d firstdiff=%d.\n",
                attempt,bn,firstdiff);
    }

    free(block); free(verify);
    printk("WriteInformationBlock: exact dirty-block commit failed after 3 attempts DNR=%d block=%d.\n",
           dnr,bn);
    return 7;
}


// Read information block from drive.
int ReadInformationBlock(int dnr, JTMFAT_INFOBLOCK *inf)
{
	BYTE *tmp;
	int bs,bn,bo;
	DEBUGFUNC
	if(!isValidDevice(dnr) || inf==NULL) return 1;
	bs=getblocksize(dnr);
	if(bs<=0 || bs>1024*64 || jtmfat_info_location(dnr,&bn,&bo)) return 2;
	tmp=malloc(bs); if(tmp==NULL) return 3;
	if(readblock1(dnr,bn,tmp)) { free(tmp); return 4; }
	memcpy(inf,tmp+bo,sizeof(JTMFAT_INFOBLOCK)); free(tmp);
	return jtmfat_validateinfoblock(dnr,inf);
}

// Set kernel checksum in partition-safe boot32 runtime metadata (LBA3).
int SetKernelChecksum(int dnr, WORD checksum)
{
	BYTE *tmp;
	int blocksize,bn,bo;
	DWORD off=JTMFS_BOOT_RUNTIME_CHECKSUM_OFFS;

	DEBUGFUNC
	if(!isValidDevice(dnr)) return 1;

	blocksize = getblocksize(dnr);
	if(blocksize < JTMFS_BOOT_RECORD_BYTES || blocksize>16384)
		return 1;
	bn=(int)(off/(DWORD)blocksize);
	bo=(int)(off%(DWORD)blocksize);
	if(bo+2>blocksize) return 1;

	tmp = malloc(blocksize);
	if(tmp==NULL)
		return 2;

	if(readblock1(dnr, bn, tmp))
	{
		free(tmp);
		return 3;
	}

	tmp[bo] = checksum & 255;
	tmp[bo+1] = (checksum >> 8) & 255;
	/* The checksum now lives at LBA3, outside the standard MBR partition table.
	 * Commit it synchronously so the loader and payload cannot become mismatched. */
	if(driver_FlushDrive(dnr)!=0)
	{
		free(tmp);
		return 4;
	}
	driver_block_cache_invalidate(dnr);
	if(writeblock1(dnr, bn, tmp) || driver_FlushDrive(dnr)!=0)
	{
		free(tmp);
		return 4;
	}
	driver_block_cache_invalidate(dnr);

	memset(tmp, 0, blocksize);
	if(readblock1(dnr, bn, tmp) ||
	   tmp[bo] != (BYTE)(checksum & 255) ||
	   tmp[bo+1] != (BYTE)((checksum >> 8) & 255))
	{
		free(tmp);
		return 5;
	}

	free(tmp);
	return 0;
}

/* Return the active JTMOS boot floppy device name.  The protected-mode
 * kernel remembers BIOS DL from boot32, so this works for both A: and B:.
 * A non-floppy boot returns 0 and lets the formatter use its embedded loader. */
static int CurrentBootFloppy(char *name, int capacity)
{
	int biosboot;

	if(name==NULL || capacity<8)
		return 0;

	biosboot=GetBiosBootDrive();
	if(biosboot==0)
		strcpy(name, "floppy");
	else if(biosboot==1)
		strcpy(name, "floppy2");
	else
		return 0;

	return isValidDevice(driver_getdevicenrbyname(name));
}

// Install boot loader.  For an HDD target, prefer the exact 36-sector / two-track loader
// track from the floppy which booted this JTMOS instance.  The target-specific
// HDD fields are patched below and BuildInfoBlock()/WriteInformationBlock()
// subsequently restore JTMFS metadata inside the reserved boot area.
static int InstallBootLoader(int dnr, int bdrv)
{
	BYTE *tmp,*p,*oldmbr;
	int i,i2,blocks,payload_len,sdnr,used_boot_floppy;
	int blocksize;
	char source[16];

	DEBUGFUNC
	if(!isValidDevice(dnr)) return 19;

	blocksize=getblocksize(dnr);
	if(blocksize<=0 || blocksize>16384)
		return 20;

	/* 64 KiB is intentionally larger than both the historical embedded loader
	 * and the 36-sector (18 KiB) floppy boot area. */
	tmp = malloc(1024*64);
	if(tmp==NULL)
		return 21;
	memset(tmp, 0, 1024*64);
	payload_len=0;
	used_boot_floppy=0;

	if((bdrv & 0xF0)==0x80 && blocksize==JTMFS_BOOT_RECORD_BYTES &&
	   CurrentBootFloppy(source, sizeof(source)))
	{
		sdnr=driver_getdevicenrbyname(source);
		if(!isValidDevice(sdnr) || getblocksize(sdnr)!=JTMFS_BOOT_RECORD_BYTES)
		{
			free(tmp);
			return 22;
		}

		ReportMessage("Copying current boot loader from %s to hard disk . . ", source);
		if(readblocks(sdnr,0,tmp,JTMFS_BOOT_TRACK_SECTORS)!=JTMFS_BOOT_TRACK_SECTORS)
		{
			ReportMessage("FAILED\n");
			free(tmp);
			return 23;
		}
		ReportMessage("OK\n");
		payload_len=JTMFS_BOOT_TRACK_SECTORS*JTMFS_BOOT_RECORD_BYTES;
		used_boot_floppy=1;
	}

	if(!used_boot_floppy)
	{
		if(boot_bin_length<=0 || boot_bin_length>(1024*64))
		{
			free(tmp);
			return 24;
		}
		memcpy(tmp, boot_bin, boot_bin_length);
		payload_len=boot_bin_length;
	}

	/* V16.71.2: bytes 446..509 are the standard MBR partition table and must
	 * never carry JTMOS loader metadata.  BIOS DL is captured at runtime and
	 * checksum/kernel-offset metadata lives at LBA3.  When installing on an HDD,
	 * preserve an existing partition table exactly. */
	if((bdrv & 0xF0)==0x80 && blocksize==JTMFS_BOOT_RECORD_BYTES)
	{
		oldmbr=malloc(JTMFS_BOOT_RECORD_BYTES);
		if(oldmbr==NULL) { free(tmp); return 27; }
		if(readblock1(dnr,0,oldmbr)==0 && oldmbr[510]==0x55 && oldmbr[511]==0xAA)
			memcpy(tmp+JTMFS_MBR_PARTITION_BYTE_OFFS,
			       oldmbr+JTMFS_MBR_PARTITION_BYTE_OFFS,
			       JTMFS_MBR_PARTITION_BYTES);
		free(oldmbr);
	}
	tmp[510]=0x55;
	tmp[511]=0xAA;

	blocks=(payload_len + blocksize - 1) / blocksize;
	/* Boot sectors are filesystem metadata, not normal write-back data.  Commit
	 * them physically now so a later DAPI cache flush cannot resurrect sectors
	 * from the pre-format filesystem over the new boot/JTMFS layout. */
	if(driver_FlushDrive(dnr)!=0)
	{
		free(tmp);
		return 25;
	}
	driver_block_cache_invalidate(dnr);
	if(writeblocks1(dnr,0,tmp,blocks)!=blocks || driver_FlushDrive(dnr)!=0)
	{
		free(tmp);
		return 25;
	}
	driver_block_cache_invalidate(dnr);

	/* Verify the BIOS-visible MBR signature.  Runtime drive/offset metadata no
	 * longer lives inside the partition table. */
	memset(tmp, 0, blocksize);
	if(readblock1(dnr, 0, tmp) || tmp[510]!=0x55 || tmp[511]!=0xAA)
	{
		free(tmp);
		return 26;
	}

	free(tmp);
	return 0;
}

// Writes kernel image on specified drive and reports media errors.
int WriteKernel(int dnr, const void *ker)
{
	int i,l,blocksize,startblock;
	const BYTE *p;

	DEBUGFUNC

	if(ker==NULL || !isValidDevice(dnr))
		return 1;
	blocksize=getblocksize(dnr);
	if(blocksize<=0 || JTMFS_KERNEL_RESERVE_BYTES%(DWORD)blocksize ||
	   (FAT_BOOT_SECTION_LEN_K*1024UL)%(DWORD)blocksize)
		return 2;

	l = (int)(JTMFS_KERNEL_RESERVE_BYTES/(DWORD)blocksize);
	startblock = (int)((FAT_BOOT_SECTION_LEN_K*1024UL)/(DWORD)blocksize);
	/* Never overwrite the FAT of an older/smaller JTMFS boot layout. */
	if(!JtmfsKernelRegionIsCurrent(dnr, jtmfat_getinfoblock(dnr)))
	{
		ReportMessage("FAILED (JTMFS boot payload reservation is below 1 MiB; reformat with current mkfs)\n");
		return 4;
	}
	ReportMessage("Writing %d KiB boot kernel payload on system drive . . ", KERNEL_LEN_K);
	if(writeblocks(dnr,startblock,(BYTE *)ker,l)!=l)
	{
		ReportMessage("FAILED\n");
		return 3;
	}
	ReportMessage("OK (%d blocks)\n", l);
	return 0;
}

// Determine 16-bit kernel checksum.
WORD DetermineKernelChecksum(BYTE *buf, int len)
{
	WORD sum;
	int i;

	DEBUGFUNC

	for(i=0,sum=0; i<len; i++)
		sum+=buf[i];
	return sum;
}

// Copy the exact 1 MiB boot-kernel PAYLOAD region from a JTMOS boot floppy
// to a bootable JTMFS HDD.  With the default boot32pm image, sector 36 starts
// kernel32.bin.nz; with the legacy image it starts raw kernel32.bin.  The
// loader copied to the HDD carries the matching exact nzip/raw size metadata.
//
// IMPORTANT: the boot-sector checksum is always the checksum of the RAW
// kernel32.bin.  Never derive it from this 1 MiB payload buffer: for nzip
// that buffer contains compressed bytes plus padding and has a different sum.
static int CopyKernelReadDevice(int sdnr, int byte_offset, BYTE *buf, int nbytes)
{
	int blocks;

	if(!isValidDevice(sdnr) || buf==NULL || nbytes<=0 ||
	   byte_offset<0 || (byte_offset%JTMFS_BOOT_RECORD_BYTES)!=0 ||
	   (nbytes%JTMFS_BOOT_RECORD_BYTES)!=0)
		return 0;
	blocks=nbytes/JTMFS_BOOT_RECORD_BYTES;
	return readblocks(sdnr,byte_offset/JTMFS_BOOT_RECORD_BYTES,buf,blocks)==blocks;
}

static int CopyKernelReadImage(FILE *image, int byte_offset, BYTE *buf, int nbytes)
{
	if(image==NULL || buf==NULL || byte_offset<0 || nbytes<=0)
		return 0;
	if(fseek(image,(long)byte_offset,SEEK_SET)!=0)
		return 0;
	return fread(buf,1,(size_t)nbytes,image)==(size_t)nbytes;
}


static DWORD CopyKernelGetLe32(const BYTE *p)
{
	return (DWORD)p[0] | ((DWORD)p[1]<<8) | ((DWORD)p[2]<<16) | ((DWORD)p[3]<<24);
}

/* Return 1 for a standard partitioned MBR target, 0 for the historical
 * whole-disk JTMFS layout and <0 for an unsafe/corrupt partition layout. */
static int CopyKernelPartitionedHddTarget(int dnr, BYTE *mbr, DWORD *first_lba)
{
	DWORD disk_sectors,min_lba=0,start,count,end;
	int i,found=0;
	BYTE *e;

	if(!isValidDevice(dnr) || !mbr || getblocksize(dnr)!=JTMFS_BOOT_RECORD_BYTES)
		return 0;
	if(readblock1(dnr,0,mbr)!=0 || mbr[510]!=0x55 || mbr[511]!=0xAA)
		return 0;
	disk_sectors=(DWORD)getsize(dnr);
	if(disk_sectors==0) return -1;
	for(i=0;i<4;i++)
	{
		e=mbr+JTMFS_MBR_PARTITION_BYTE_OFFS+i*16;
		start=CopyKernelGetLe32(e+8);
		count=CopyKernelGetLe32(e+12);
		if(e[4]==0 || count==0) continue;
		if(start==0 || start>=disk_sectors || count>disk_sectors-start)
			return -1;
		end=start+count;
		if(end<start) return -1;
		if(!found || start<min_lba) min_lba=start;
		found=1;
	}
	if(!found) return 0;

	/* Partitioned-HDD contract: LBA0..4095 is the JTMOS pre-partition boot/system
	 * reserve. The active loader lives at 0..35 and kernel at 64..2111; keeping
	 * the full 2 MiB reserve makes room for future boot/system growth too. */
	if(min_lba<JTMOS_HDD_FIRST_PARTITION_LBA) return -2;
	if(first_lba) *first_lba=min_lba;
	return 1;
}

static int CopyKernelReadSourceHeader(int sdnr, FILE *image, BYTE *buf,
                                      WORD *checksum, int *mbr_safe)
{
	DWORD magic;
	int i,safe=1;
	const int need=(int)(JTMFS_BOOT_RUNTIME_CHECKSUM_OFFS+2UL);
	if(!buf || !checksum || need>64*1024) return 0;
	if(!(image ? CopyKernelReadImage(image,0,buf,need)
	           : CopyKernelReadDevice(sdnr,0,buf,
	                 ((need+JTMFS_BOOT_RECORD_BYTES-1)/JTMFS_BOOT_RECORD_BYTES)*JTMFS_BOOT_RECORD_BYTES)))
		return 0;
	if(buf[510]!=0x55 || buf[511]!=0xAA) return 0;
	for(i=JTMFS_MBR_PARTITION_BYTE_OFFS;
	    i<JTMFS_MBR_PARTITION_BYTE_OFFS+JTMFS_MBR_PARTITION_BYTES;i++)
		if(buf[i]!=0) safe=0;
	magic=CopyKernelGetLe32(buf+JTMFS_BOOT_RUNTIME_BYTE_OFFS);
	if(magic==JTMFS_BOOT_RUNTIME_MAGIC)
		*checksum=(WORD)buf[JTMFS_BOOT_RUNTIME_CHECKSUM_OFFS] |
		          ((WORD)buf[JTMFS_BOOT_RUNTIME_CHECKSUM_OFFS+1]<<8);
	else
		*checksum=(WORD)buf[JTMFS_BOOT_RECORD_BYTES-11] |
		          ((WORD)buf[JTMFS_BOOT_RECORD_BYTES-10]<<8);
	if(mbr_safe) *mbr_safe=(magic==JTMFS_BOOT_RUNTIME_MAGIC && safe);
	return 1;
}

static int CopyKernelInstallPartitionedBootTrack(int sdnr, FILE *image,
                                                  int dnr, BYTE *buf,
                                                  const BYTE *target_mbr)
{
	BYTE *verify;
	int i;
	const int bytes=(int)(JTMOS_FLOPPY_LOADER_SECTORS*JTMOS_BOOT_SECTOR_BYTES);
	if(!buf || !target_mbr) return 1;
	if(!(image ? CopyKernelReadImage(image,0,buf,bytes)
	           : CopyKernelReadDevice(sdnr,0,buf,bytes)))
		return 2;
	if(buf[510]!=0x55 || buf[511]!=0xAA ||
	   CopyKernelGetLe32(buf+JTMFS_BOOT_RUNTIME_BYTE_OFFS)!=JTMFS_BOOT_RUNTIME_MAGIC)
		return 3;
	/* A current jtm32.img has a blank MBR table.  Reject an old floppy loader
	 * whose executable/metadata still occupies bytes 446..509: preserving the
	 * HDD partition table would truncate that loader again. */
	for(i=JTMFS_MBR_PARTITION_BYTE_OFFS;
	    i<JTMFS_MBR_PARTITION_BYTE_OFFS+JTMFS_MBR_PARTITION_BYTES;i++)
		if(buf[i]!=0) return 4;
	memcpy(buf+JTMFS_MBR_PARTITION_BYTE_OFFS,
	       target_mbr+JTMFS_MBR_PARTITION_BYTE_OFFS,
	       JTMFS_MBR_PARTITION_BYTES);
	buf[510]=0x55; buf[511]=0xAA;

	if(driver_FlushDrive(dnr)!=0) return 5;
	driver_block_cache_invalidate(dnr);
	if(writeblocks1(dnr,0,buf,(int)JTMOS_HDD_LOADER_SECTORS)!=(int)JTMOS_HDD_LOADER_SECTORS ||
	   driver_FlushDrive(dnr)!=0)
		return 5;
	driver_block_cache_invalidate(dnr);

	verify=malloc(bytes);
	if(!verify) return 6;
	if(readblocks1(dnr,0,verify,(int)JTMOS_HDD_LOADER_SECTORS)!=(int)JTMOS_HDD_LOADER_SECTORS)
	{ free(verify); return 7; }
	if(memcmp(verify,buf,bytes)!=0)
	{ free(verify); return 8; }
	free(verify);
	return 0;
}

/*
 * Shared implementation for a physical 512-byte boot device and a raw JTMOS
 * floppy image file. Both source forms use the same media layout: sector 0
 * carries the boot signature + RAW-kernel checksum and sector 36 begins the
 * reserved 1 MiB nzip/raw kernel payload.
 */
static int CopyKernelCommon(int sdnr, FILE *image, const char *dst)
{
	int dnr,r,blocksize,startblock,partitioned,mbr_safe;
	int dstblocks,nbytes,offset,i;
	BYTE *buf,*target_mbr;
	WORD payload_checksum,readback_sum,source_raw_checksum;
	DWORD first_partition_lba=0;
	long image_size;
	const int chunk_bytes=64*1024;
	const int source_bytes=(int)(JTMOS_FLOPPY_KERNEL_LBA*JTMOS_BOOT_SECTOR_BYTES)+
	                       (int)JTMFS_KERNEL_RESERVE_BYTES;

	DEBUGFUNC

	if(dst==NULL)
		return 1;
	dnr=driver_getdevicenrbyname(dst);
	if(!isValidDevice(dnr))
		return 2;

	if(image==NULL)
	{
		if(!isValidDevice(sdnr)) return 3;
		if(getblocksize(sdnr)!=JTMFS_BOOT_RECORD_BYTES) return 4;
		if(getsize(sdnr)<source_bytes/JTMFS_BOOT_RECORD_BYTES) return 6;
	}
	else
	{
		if(fseek(image,0,SEEK_END)!=0) return 6;
		image_size=ftell(image);
		if(image_size<(long)source_bytes) return 6;
		if(fseek(image,0,SEEK_SET)!=0) return 6;
	}

	blocksize=getblocksize(dnr);
	if(blocksize<JTMFS_BOOT_RECORD_BYTES ||
	   JTMFS_KERNEL_RESERVE_BYTES%(DWORD)blocksize ||
	   chunk_bytes%blocksize)
		return 5;

	target_mbr=malloc(JTMFS_BOOT_RECORD_BYTES);
	if(!target_mbr) return 7;
	partitioned=CopyKernelPartitionedHddTarget(dnr,target_mbr,&first_partition_lba);
	if(partitioned<0) { free(target_mbr); return partitioned==-2?18:19; }
	if(partitioned)
	{
		if(blocksize!=JTMOS_BOOT_SECTOR_BYTES ||
		   (JTMOS_HDD_KERNEL_LBA*JTMOS_BOOT_SECTOR_BYTES)%(DWORD)blocksize)
		{ free(target_mbr); return 5; }
	}
	else
	{
		if((FAT_BOOT_SECTION_LEN_K*1024UL)%(DWORD)blocksize ||
		   !JtmfsKernelRegionIsCurrent(dnr,jtmfat_getinfoblock(dnr)))
		{ free(target_mbr); return 14; }
	}

	buf=malloc(chunk_bytes);
	if(buf==NULL) { free(target_mbr); return 7; }
	if(!CopyKernelReadSourceHeader(sdnr,image,buf,&source_raw_checksum,&mbr_safe))
	{ free(buf); free(target_mbr); return 8; }

	if(partitioned)
	{
		if(blocksize!=JTMFS_BOOT_RECORD_BYTES || !mbr_safe)
		{ free(buf); free(target_mbr); return 17; }
		ReportMessage("Installing partition-safe HDD MBR + 36-sector/two-track boot32pm loader (hda1 LBA %u, kernel LBA %u) . . ",
		              (unsigned)first_partition_lba,(unsigned)JTMOS_HDD_KERNEL_LBA);
		r=CopyKernelInstallPartitionedBootTrack(sdnr,image,dnr,buf,target_mbr);
		if(r)
		{
			ReportMessage("FAILED (%d)\n",r);
			free(buf); free(target_mbr); return 30+r;
		}
		ReportMessage("OK\n");
	}
	free(target_mbr);

	payload_checksum=0;
	if(partitioned)
		startblock=(int)((JTMOS_HDD_KERNEL_LBA*JTMOS_BOOT_SECTOR_BYTES)/(DWORD)blocksize);
	else
		startblock=(int)((FAT_BOOT_SECTION_LEN_K*1024UL)/(DWORD)blocksize);
	ReportMessage("Copying %d KiB boot kernel payload in 64 KiB chunks . . ",KERNEL_LEN_K);
	for(offset=0;offset<(int)JTMFS_KERNEL_RESERVE_BYTES;offset+=chunk_bytes)
	{
		nbytes=chunk_bytes;
		if(offset+nbytes>(int)JTMFS_KERNEL_RESERVE_BYTES)
			nbytes=(int)JTMFS_KERNEL_RESERVE_BYTES-offset;
		if(!(image ? CopyKernelReadImage(image,JTMOS_FLOPPY_KERNEL_LBA*JTMOS_BOOT_SECTOR_BYTES+offset,buf,nbytes)
		           : CopyKernelReadDevice(sdnr,JTMOS_FLOPPY_KERNEL_LBA*JTMOS_BOOT_SECTOR_BYTES+offset,buf,nbytes)))
		{
			ReportMessage("FAILED (source read)\n");
			free(buf); return 9;
		}
		for(i=0;i<nbytes;i++) payload_checksum+=(WORD)buf[i];
		dstblocks=nbytes/blocksize;
		if(writeblocks(dnr,startblock+offset/blocksize,buf,dstblocks)!=dstblocks)
		{
			ReportMessage("FAILED (target write)\n");
			free(buf); return 13;
		}
	}
	ReportMessage("OK (raw checksum 0x%04x)\n",source_raw_checksum);

	readback_sum=0;
	for(offset=0;offset<(int)JTMFS_KERNEL_RESERVE_BYTES;offset+=chunk_bytes)
	{
		nbytes=chunk_bytes;
		if(offset+nbytes>(int)JTMFS_KERNEL_RESERVE_BYTES)
			nbytes=(int)JTMFS_KERNEL_RESERVE_BYTES-offset;
		dstblocks=nbytes/blocksize;
		if(readblocks(dnr,startblock+offset/blocksize,buf,dstblocks)!=dstblocks)
		{ free(buf); return 15; }
		for(i=0;i<nbytes;i++) readback_sum+=(WORD)buf[i];
	}
	if(readback_sum!=payload_checksum)
	{ free(buf); return 16; }

	/* On a partitioned HDD the matching checksum/runtime metadata arrived with
	 * the copied boot track at LBA3.  The historical whole-disk JTMFS layout
	 * keeps its loader in place, so patch only its relocated checksum field. */
	if(!partitioned)
	{
		r=SetKernelChecksum(dnr,source_raw_checksum);
		if(r) { free(buf); return 20+r; }
	}
	free(buf);
	return 0;
}

int CopyKernel(const char *src, const char *dst)
{
	int sdnr;

	if(src==NULL || dst==NULL)
		return 1;
	sdnr=driver_getdevicenrbyname(src);
	if(!isValidDevice(sdnr))
		return 3;
	return CopyKernelCommon(sdnr,NULL,dst);
}

/* Install from a raw JTMOS floppy image such as jtm32.img on JTMFS/RAM media. */
int CopyKernelImage(const char *srcimage, const char *dst)
{
	FILE *image;
	int r;

	if(srcimage==NULL || dst==NULL)
		return 1;
	image=fopen(srcimage,"rb");
	if(image==NULL)
		return 30;
	r=CopyKernelCommon(-1,image,dst);
	fclose(image);
	return r;
}
