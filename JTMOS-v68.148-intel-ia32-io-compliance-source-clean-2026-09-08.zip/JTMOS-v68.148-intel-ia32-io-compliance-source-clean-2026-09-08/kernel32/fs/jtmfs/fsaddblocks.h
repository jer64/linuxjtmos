#ifndef __INCLUDED_FSADDBLOCKS_H__
#define __INCLUDED_FSADDBLOCKS_H__

//
int jtmfs_add_blocks_for_entry(int device_nr,
char *fname,int dblock,int amount);

/* Reserve enough FAT capacity for a write without changing the visible
 * byte length.  This is the preferred writer path; truncate/grow semantics
 * remain in jtmfs_setsize(). */
#define JTMFS_RESERVE_NOSPC 28
int jtmfs_reserve_blocks_for_write(int device_nr,
char *fname,int dblock,int required_blocks);

#endif

