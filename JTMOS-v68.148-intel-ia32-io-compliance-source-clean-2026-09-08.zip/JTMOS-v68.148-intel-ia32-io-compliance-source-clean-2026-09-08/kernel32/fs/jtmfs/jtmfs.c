// ==================================================
// JTMOS FILE SYSTEM
// -----------------
//
// (C) 2001-2021 by Jari Tuominen
//		(jari.t.tuominen@gmail.com).
//
// JTMFS is dependent on JTMFAT.
// JTMFAT is dependent on a block device,
// which varies.
// The block device is accessible via
// the BLOCK/CHAR DEVICE API implementation,
// which uses a caching system.
//
// jtmfsAccess.c        FS plugins access layer(high)
// jtmfat.c             JTMOS file allocation system(low)
// jtmfs.c              JTMOS file system(low)
// fswalk.c		Dir walking functions(low)
// fsfind.c		File finding functions(low)
// fsadd.c		Directory entry adding functions(low)
// fsaddblocks.c	Allocate more blocks on for(low)
//			file or directory
// fsdev.c		Functions that figure out
//			which device is currently
//			assigned to each of the processes(low)
// ==================================================
#include "sysmem.h"
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
// ---- #include "fileapi.h"
#include "ramdisk.h"
#include "jtmfs.h"
#include "fswalk.h"
#include "fsadd.h"
#include "fsdos.h"
#include "fname_translation.h"
#include "jtmfsAccess.h"
#include "jtmfsAccessInit.h"
#include "dirdb_writeDir.h"
#include "dirdbAccess.h"
#include "dirdbFind.h"

//----------------------------------------------------------------------
//
DEBUGSTR debugstr;

//
struct
{
	int try;
}jtmfs_structure;

/* V68.117: one re-entrant cooperative metadata lock per device.  This closes
 * resize-vs-write and resize-vs-resize races without keeping IRQs disabled
 * during media I/O.  depth==0 means free, so static zero initialization is
 * sufficient even for bootstrap PID 0. */
static volatile int jtmfs_mut_owner[N_CFAT_STRUCTURES];
static volatile unsigned long jtmfs_mut_depth[N_CFAT_STRUCTURES];

void jtmfs_mutation_lock(int dnr)
{
    int pid,flags;
    unsigned long spins=0;
    if(!Multitasking || dnr<0 || dnr>=N_CFAT_STRUCTURES) return;
    pid=GetCurrentThread();
    for(;;)
    {
        flags=get_eflags();
        disable();
        if(jtmfs_mut_depth[dnr]==0 || jtmfs_mut_owner[dnr]==pid)
        {
            jtmfs_mut_owner[dnr]=pid;
            jtmfs_mut_depth[dnr]++;
            set_eflags(flags);
            return;
        }
        set_eflags(flags);
        if(LockWaitCanYield(flags)) SwitchToThread();
        else { volatile unsigned long i; for(i=0;i<128;i++) { } }
        if(++spins==1000000UL)
        {
            printk("JTMFS: mutation lock wait DNR=%d owner=%d caller=%d.\n",
                   dnr,jtmfs_mut_owner[dnr],pid);
            spins=0;
        }
    }
}

void jtmfs_mutation_unlock(int dnr)
{
    int pid,flags;
    if(!Multitasking || dnr<0 || dnr>=N_CFAT_STRUCTURES) return;
    pid=GetCurrentThread();
    flags=get_eflags();
    disable();
    if(jtmfs_mut_depth[dnr] && jtmfs_mut_owner[dnr]==pid)
    {
        jtmfs_mut_depth[dnr]--;
        if(!jtmfs_mut_depth[dnr]) jtmfs_mut_owner[dnr]=0;
    }
    set_eflags(flags);
}

//----------------------------------------------------------------------
// Called by DiskChange system function.
int jtmfs_DiskChange(int dnr)
{
	/* Media-change notifications can arrive during early/failed JTMFAT init. */
	if(fatsys==NULL || dnr<0 || dnr>=N_CFAT_STRUCTURES || !isValidDevice(dnr))
		return 1;
	fatsys->isJTMFS[dnr] = FALSE;
	return 0;
}

//
void InitDW(DIRWALK *dw)
{
	memset(dw, 0, sizeof(DIRWALK));
	dw->buf_length = 8192;
}

//
void EndDirWalk(DIRWALK *dw)
{
	if(dw!=NULL) dw->isWalking=0;
}

//
void jtmfs_inc_try(void)
{
	BYTE *dummy_buf,*dummy_buf2;

	//
	jtmfs_structure.try++;
 
	// print out the try number
	print("{"); pd32(jtmfs_structure.try); print("}");
 
	// make allocation system test(see if it works at all :))
	dummy_buf= malloc(jtmfs_structure.try);
	dummy_buf2=malloc(jtmfs_structure.try);
	if(dummy_buf) free(dummy_buf);
	if(dummy_buf2) free(dummy_buf2);
}

// -----------------------------------------------------------
//
void jtmfs_init(void)
{
	//
	jtmfs_init_try();
	jtmfsAccessInit();
}

// -----------------------------------------------------------
//
void jtmfs_init_try(void)
{
	jtmfs_structure.try=0;
}

/*
 * Cooperative wait point for long filesystem scans/copies.  Never task-switch
 * while the storage-safe PIT mode owns IRQ0, and never manufacture IF=1 for a
 * caller that entered with interrupts disabled.
 */
void jtmfs_cooperative_yield(unsigned long iteration)
{
	int flags;

	/*
	 * Do not yield on iteration zero.  V52 did that, which made the very
	 * first FAT free-block probe call SwitchToThread() while KernelInit was
	 * still constructing the RAM root.  The init task is deliberately still
	 * in bootstrap state at that point (systemStarted == 0).
	 *
	 * Cooperative filesystem yields are an optimisation, never a correctness
	 * requirement.  They are therefore enabled only after the kernel has
	 * published systemStarted.  The PIT/IF checks remain as the second line of
	 * defence for later filesystem operations.
	 */
	if(iteration == 0 || (iteration & 0x3FUL) != 0)
		return;
	if(!(systemStarted & 1))
		return;

	flags = get_eflags();
	if(Multitasking && !PitStorageSafeActive() && (flags & 0x200))
		SwitchToThread();
}

// -----------------------------------------------------------
// jtmfs_ffupdatefe
//
// Updates dw->fe to point at a correct location
// inside the active DirDB directory buffer (dw->d->buf).
// Updating the pointer structure makes the findfirst/next
// functions generally much easier to use and more efficient too.
//
void jtmfs_ffupdatefe(DIRWALK *dw)
{
	/*
	 * DIRWALK entries live inside the active DirDB cache buffer.
	 *
	 * The old code accidentally added current_offset to d->l_buf
	 * (an integer length) instead of d->buf (the actual pointer).
	 * That produced low bogus pointers such as 0x2c30, so CreateFile()
	 * copied the new directory entry outside the directory cache.
	 */
	if(dw == NULL || dw->d == NULL || dw->d->buf == NULL)
	{
		if(dw) dw->fe = NULL;
		return;
	}

	if(dw->current_offset < 0 ||
	   dw->current_offset + (int)sizeof(JTMFS_FILE_ENTRY) > dw->d->l_buf)
	{
		dprintk("%s: invalid directory offset %d (buffer length %d)\n",
			__FUNCTION__, dw->current_offset, dw->d->l_buf);
		dw->fe = NULL;
		return;
	}

	// Update entry pointer from the real cached directory buffer.
	dw->fe = (JTMFS_FILE_ENTRY *)(dw->d->buf + dw->current_offset);

	// For debugging :
#ifdef JTMFSDEBUG
	dprintk("%s: dw->fe=0x%x, dw->d->buf=0x%x, dw->buf=0x%x\n",
		__FUNCTION__,
		dw->fe,
		dw->d->buf,
		dw->buf);
#endif
}



/* typedef struct
 * {
 *  // sizeof, bytes :
 *  // 0x00
 *  char			name[31];
 *  unsigned short int 	type;
 *  unsigned int	length; (if -1 then entry is a ghost, deleted)
 *  unsigned int      protection;
 *  unsigned char		owner;
 *  unsigned int	creationdate;
 *  unsigned int	lastaccessdate;
 *  unsigned int	lastchangedate;
 *  unsigned int	track;
 *  unsigned int	block;
 *  // 0x40 .... bingo
 *  //
 * }JTMFS_FILE_ENTRY;
 */

// Use this function to create a single file/dir entry!
int jtmfs_fentry(	JTMFS_FILE_ENTRY *e,
			const char *name,
			unsigned short int 	type,
			unsigned int	length,
			unsigned char		protection,
			unsigned char		owner,
			unsigned int	creationdate,
			unsigned int	lastaccessdate,
			unsigned int	lastchangedate,
			unsigned int	FirstDataBlock,
			unsigned int	LastDataBlock)
{
	// If entry is NULL:
	if(e==NULL || name==NULL)
		return 1;

	// If filename error:
	if(!strlen(name) || strlen(name)>31)
		return 2;

	/* Refuse to create entries with unknown upper bits or the reserved 0xC0
	 * class.  Existing media can still be inspected by fsck without silently
	 * manufacturing more ambiguous entries. */
	if(!JTMFS_TYPE_IS_VALID(type))
		return 3;

	// First wipe
	memset(e, 0, sizeof(JTMFS_FILE_ENTRY));
	// Then copy
	strcpy(e->name,	name);
	e->type=		type;   // example: 0x80 = directory
	e->length=		length; // example: -1 = deleted / aka ghost
	e->FirstDataBlock=	FirstDataBlock;
	e->LastDataBlock=	LastDataBlock;
	e->magicNumber=		0xFCE2E37B;

	// Return success.
	return 0;
}			

//--------------------------------------------------------------------------------
//
// Creates a directory entry.
//
int jtmfs_cedir(JTMFS_FILE_ENTRY *e,const char *name,
	int FirstDataBlock,int LastDataBlock)
{
	// null reference checker
	if(!e || !name)
	{
		dprintk("jtmfs_cedir: NULL argument.\n");
		return 1;
	}
	if(strlen(name)>=sizeof(e->name))
	{
		dprintk("jtmfs_cedir: directory name too long.\n");
		return 2;
	}

	// clear structure
	memset(e,0,sizeof(JTMFS_FILE_ENTRY));

	// copy name
	strcpy(e->name, name);
	e->FirstDataBlock =	FirstDataBlock;
	e->LastDataBlock =	LastDataBlock;
	e->magicNumber =	0xFCE2E37B;

	// type = directory(0x80)
	e->type = JTMFS_ID_DIRECTORY;

	//
	return 0;
}

// Creates end of directory
void jtmfs_cedirend(JTMFS_FILE_ENTRY *e)
{
	// NULL?
	if(e==NULL)
	{
		dprintk("jtmfs_cedirend: NULL entry ignored.\n");
		return;
	}
 
	// Clear entry
	memset(e, 0, sizeof(JTMFS_FILE_ENTRY));
}

// jtmfs_createdirectory
//
// dblock = block where the directory are about to be stored at
//	This fuction writes an independent directory on the disk.
//	It is not a subdirectory, unless otherwise specified later on.
//
//  	Note!: the block where the directory will be made at,
//	MUST be free, if not so, no directory will be created.
//
int jtmfs_createdirectory(int device_nr, int dblock, int backdb,
        const char *name)
{
    BYTE *buf;
    JTMFS_FILE_ENTRY *fe;
    int i,end,start,bs;
    char dirname[JTMFS_NAME_MAX+1];
    DWORD fat_value;
    int pre_reserved;

    if(!isValidDevice(device_nr)) return 10;
    if(!jtmfat_isJTMFS(device_nr)) return 1;
    if(name==NULL || illegal(name) || !name[0]) return 1;
    if(dblock<=0 || dblock>=(int)jtmfat_unitcount(device_nr)) return 2;
    if(backdb<0 || backdb>=(int)jtmfat_unitcount(device_nr)) return 2;

    /* Keep the filesystem root marker, otherwise use the final path component. */
    if(!strcmp(name,"/"))
        strcpy(dirname,"/");
    else
    {
        end=(int)strlen(name);
        while(end>0 && name[end-1]=='/') --end;
        start=end;
        while(start>0 && name[start-1]!='/') --start;
        if(end-start<=0 || end-start>JTMFS_NAME_MAX) return 2;
        for(i=0;start+i<end;i++) dirname[i]=name[start+i];
        dirname[i]=0;
    }

    bs=(int)jtmfat_unitsize(device_nr);
    if(bs<=0 || bs<(int)(4*sizeof(JTMFS_FILE_ENTRY)))
    {
        printk("jtmfs_createdirectory: block size %d is too small for directory header.\n",bs);
        return 3;
    }

    /* A new directory must start on a genuinely free FAT block.  The previous
     * implementation silently overwrote an allocated block and only skipped
     * the FAT update, which could create cross-linked directories. */
    fat_value=(DWORD)jtmfat_getblock(device_nr,dblock);
    pre_reserved=(fat_value>=0xFFFFFFF8UL);
    if(fat_value!=0 && !pre_reserved)
    {
        printk("jtmfs_createdirectory: refusing allocated block %d (FAT=0x%x).\n",
               dblock,fat_value);
        return 4;
    }

    buf=malloc(bs);
    if(buf==NULL) return 5;
    memset(buf,0,bs);
    fe=(JTMFS_FILE_ENTRY*)buf;

    if(jtmfs_cedir(&fe[0],".",dblock,dblock) ||
       jtmfs_cedir(&fe[1],"..",backdb,backdb) ||
       jtmfs_cedir(&fe[2],dirname,0,0))
    {
        free(buf);
        return 6;
    }
    fe[2].type=JTMFS_ID_DIRNAME;
    fe[2].length=-1;
    jtmfs_cedirend(&fe[3]);

    /* Data first, FAT publication second.  A crash between these operations
     * leaves at most an unreachable block, never a FAT chain pointing at
     * uninitialized directory bytes. */
    {
        DWORD lba=jtmfat_unit_to_lba(device_nr,(DWORD)dblock);
        DWORD cs=jtmfat_clustersectors(device_nr);
        if(lba==0xffffffffUL || writeblocks(device_nr,(long)lba,buf,(int)cs)!=(int)cs)
        {
            printk("jtmfs_createdirectory: directory cluster write failed DNR=%d unit=%d LBA=%u.\n",
                   device_nr,dblock,(unsigned)lba);
            free(buf);
            return 7;
        }
    }
    if(!pre_reserved && jtmfat_setblock(device_nr,dblock,(int)0xFFFFFFF8UL))
    {
        printk("jtmfs_createdirectory: FAT publish failed DNR=%d block=%d.\n",
               device_nr,dblock);
        free(buf);
        return 8;
    }

    dirdb_clearCacheForDB(device_nr,dblock);
    free(buf);
    return 0;
}

//
int jtmfs_getrootdir(int device_nr)
{
	if(!isValidDevice(device_nr)) return 0;

	// We will just pass this request for the JTMFAT
	// (JTMFAT nowadays does this stuff).
	return jtmfat_getrootdir(device_nr);
}

// Create root directory(used by formatdrive)
int jtmfs_createrootdir(int dnr)
{
	int rdnr;
	char *str_root="/";

	// Device validity check
	if(!isValidDevice(dnr))
	{
		dprintk("%s: DNR %d is not a valid device!\n",
			__FUNCTION__, dnr);
		return 2;
	}
	// JTMFS required
	if(!jtmfat_isJTMFS(dnr))
	{
		dprintk("%s: DNR %d is not formatted! Cannot create directory. Invalid ID!\n",
			__FUNCTION__, dnr);
		return 1;
	}

	// Get root directory block #
	rdnr = jtmfs_getrootdir(dnr);
	// Root directory block validity check
	if(rdnr<=0 || rdnr>=(int)jtmfat_unitcount(dnr))
	{
		dprintk("%s: Illegal root dir block = %d!\n",
			__FUNCTION__, rdnr);
		return 3;
	}

	// Create root directory.
	dprintk("%s: Root dir block = %d\n", __FUNCTION__, rdnr);
	dprintk("%s: Creating directory on it:\n", __FUNCTION__);
	if(jtmfs_createdirectory(dnr, rdnr, 0, str_root))
	{
		dprintk("%s: Root directory creation failed.\n", __FUNCTION__);
		return 4;
	}
	dprintk("%s: Directory creation completed.\n", __FUNCTION__);
	return 0;
}

// Lists root directory's contents
int jtmfs_dirroot(int device_nr)
{
	if(!isValidDevice(device_nr)) return 1;

	// JTMFS required
	//
	jtmfs_dir( device_nr, jtmfs_getrootdir(device_nr) );

	//
	return 0;
}

// Checks if it is the last entry?
// Return value: non-zero if true, else zero
int jtmfs_ffIsLast(int device_nr,DIRWALK *dw)
{
	// JTMFS required
	if(!jtmfat_isJTMFS(device_nr))return 1;
	if(dw==NULL || dw->fe==NULL) return 1;

	//
	if( !strlen(dw->fe->name) ) return 1;
 
	//
	return 0;
}

int jtmfs_clearwbuf(int device_nr,DIRWALK *dw)
{
	//
	return 0;
}

// EXPAND FILE OR DIRECTORY CHAIN
// ------------------------------
//
// This function expands a file chain, so that it will contain
// one more block.
// Return value: new block's number
// Negative value means error.
//
int jtmfs_expandchain(int device_nr,int block)
{
    DWORD old_value;
    int new_block;

    if(!isValidDevice(device_nr) || !jtmfat_isJTMFS(device_nr)) return -1;
    if(block<=0 || block>=(int)jtmfat_unitcount(device_nr) ||
       !jtmfat_isdatablock(device_nr,(DWORD)block))
    {
        printk("jtmfs_expandchain: SYSTEM-WALL rejected tail block %d.\n",block);
        return -1;
    }

    old_value=(DWORD)jtmfat_getblock(device_nr,block);
    if(old_value<0xFFFFFFF8UL)
    {
        dprintk("jtmfs_expandchain: block %d is not an end-of-chain block (FAT=0x%x).\n",
                block,old_value);
        return -2;
    }

    new_block=(int)jtmfat_reserveblock(device_nr);
    /* Preserve a real allocator ENOSPC separately from allocator/FAT faults.
     * Callers can now roll back cleanly without misreporting corruption as
     * "disk full" (or vice versa). */
    if(new_block==-1)
        return -ENOSPC;
    if(new_block<=0 || new_block>=(int)jtmfat_unitcount(device_nr) || new_block==block ||
       !jtmfat_isallocatableblock(device_nr,(DWORD)new_block))
    {
        dprintk("jtmfs_expandchain: allocator fault block=%d dnr=%d.\n",
                new_block,device_nr);
        return -3;
    }

    /* jtmfat_reserveblock() already published the new node as a standalone
     * EOC under the allocator lock.  Only the tail link remains to commit. */
    if((DWORD)jtmfat_getblock(device_nr,new_block)<0xFFFFFFF8UL)
    {
        (void)jtmfat_setblock(device_nr,new_block,0);
        return -4;
    }
    if(jtmfat_setblock(device_nr,block,new_block))
    {
        (void)jtmfat_setblock(device_nr,new_block,0);
        return -6;
    }
    if(jtmfat_getblock(device_nr,block)!=new_block)
    {
        (void)jtmfat_setblock(device_nr,block,(int)old_value);
        (void)jtmfat_setblock(device_nr,new_block,0);
        return -6;
    }
    return new_block;
}

// Reads current block location at the buffer
// I tried to optimize it to load only when neccesary,
// but it didn't really work right :\
// TODO: WHY it is needed to load the block everytime?
int jtmfs_ffreadlocation(int device_nr,DIRWALK *dw)
{
	/* Reading metadata must never mark it dirty.  The historical code called
	 * dirdb_flushRequirement() here, so even a directory read could later be
	 * written back.  Combined with a failed/partial media read this could turn
	 * a read-side fault into destructive empty-directory writeback. */
	if(!jtmfat_isJTMFS(device_nr)) return 1;
	if(dw==NULL) return 2;
	return 0;
}

// Writes current buffer to the disk
int jtmfs_ffwritelocation(int device_nr, DIRWALK *dw)
{
	// JTMFS required
	if(!jtmfat_isJTMFS(device_nr))
	{
		dprintk("%s: DNR%d = non-JTMFS file system\n",
			__FUNCTION__, device_nr);
		return 1;
	}

	if(dw==NULL || dw->d==NULL)
	{
		dprintk("%s: ERROR Called with invalid DIRWALK\n",__FUNCTION__);
		return 2;
	}

	/* Historically this function only set flushRequired and then returned 0,
	 * despite its name/comment saying that it wrote to disk.  Keep deferred
	 * caching for RAM/removable media, but make HDA metadata writes durable at
	 * the point where callers are told that the write succeeded. */
	dirdb_flushRequirement(dw);
	{
		int hda=driver_getdevicenrbyname("hda");
		if(hda>=0 && device_nr==hda)
		{
			int er=dirdb_commitDir(dw->d);
			if(er)
			{
				printk("jtmfs_ffwritelocation: HDA durable DIRDB commit failed DNR=%d DB=%d err=%d.\n",
				       device_nr,dw->d->db,er);
				return er;
			}
		}
	}

	return 0;
}

/* typedef struct
 * {
 *  // sizeof, bytes :
 *  // 0x00
 * 00 char			name[31];
 * 20 unsigned short int 	type;
 * 22 unsigned int	length;
 * 26 unsigned int      protection;
 * 2a unsigned char		owner;
 * 2b unsigned int	creationdate;
 * 2f unsigned int	lastaccessdate;
 * 33 unsigned int	lastchangedate;
 * 37 unsigned int	track;
 * 3b unsigned int	block;
 * 3f unsigned char	unused;
 *  // 0x40 .... bingo
 *  //
 * }JTMFS_FILE_ENTRY;
 */

//
int jtmfs_entryIsDeleted(JTMFS_FILE_ENTRY *fe)
{
	if(fe==NULL) return 0;
	if(fe->length==-1)
			return 1;
			else
			return 0;
}

// jtmfs_deletefile dnr,fname,dirblock
// -----------------------------------
//
// Sets the direntry of the specified file as "free",
// and frees all blocks that are allocated by the file,
// if any.
//
// New: if dirblock equals to zero, it'll be treated as
// the rootdirectory(default).
//
int jtmfs_deletefile(int device_nr,const char *fname,int dirblock)
{
    DIRWALK dw;
    int delete_blocknr,dirblock1;

    if(!isValidDevice(device_nr) || fname==NULL) return 1;
    if(dirblock<0 || dirblock>=(int)jtmfat_unitcount(device_nr)) return 1;
    dirblock1=dirblock ? dirblock : jtmfs_getrootdir(device_nr);
    if(dirblock1<=0 || dirblock1>=(int)jtmfat_unitcount(device_nr)) return 1;

    InitDW(&dw);
    if(!jtmfs_ffindfile(device_nr,fname,dirblock1,&dw))
        return 1;

    delete_blocknr=(int)dw.fe->FirstDataBlock;

    /* Crash-safe deletion ordering:
     *   1. make the namespace entry unreachable and commit it;
     *   2. only then release the FAT chain.
     * A crash between the two steps leaks blocks (repairable by fsck) instead
     * of leaving a live directory entry pointing at blocks already reused by
     * another file. */
    dw.fe->length=-1;
    dw.fe->FirstDataBlock=0;
    dw.fe->LastDataBlock=0;
    if(jtmfs_ffwritelocation(device_nr,&dw))
    {
        EndDirWalk(&dw);
        return 3;
    }
    EndDirWalk(&dw);

    if(delete_blocknr>0)
    {
        if(jtmfs_deletechain(device_nr,delete_blocknr))
        {
            printk("jtmfs_deletefile: namespace entry removed but FAT chain %d could not be fully released; fsck will report orphan blocks.\n",
                   delete_blocknr);
            return 2;
        }
        if(flexFlushFATChecked(device_nr))
            return 4;
    }
    return 0;
}

// ------------------------------------------------------------------------------
// jtmfs_renamefile(dev, "floppy:lala", "lolo", rootdir);
//
// Renames a file or files.
// REN [drive:][path]filename1 filename2.
// Note that you cannot specify a new drive or path for your destination file.
//
int jtmfs_renamefile(int device_nr,
        const char *OldName, const char *NewName,
        int dirblock)
{
    DIRWALK dw,existing;
    int dirblock1;

    if(!isValidDevice(device_nr) || OldName==NULL || NewName==NULL) return 1;
    if(!OldName[0] || !NewName[0] || strlen(NewName)>JTMFS_NAME_MAX) return 2;
    if(strchr(NewName,'/') || strchr(NewName,':')) return 2;
    if(dirblock<0 || dirblock>=(int)jtmfat_unitcount(device_nr)) return 1;
    dirblock1=dirblock ? dirblock : jtmfs_getrootdir(device_nr);

    InitDW(&dw);
    if(!jtmfs_ffindfile(device_nr,OldName,dirblock1,&dw))
        return 1;
    if(!strcmp(OldName,NewName))
    {
        EndDirWalk(&dw);
        return 0;
    }

    InitDW(&existing);
    if(jtmfs_ffindfile(device_nr,NewName,dirblock1,&existing))
    {
        EndDirWalk(&existing);
        EndDirWalk(&dw);
        return 4;
    }

    strcpy(dw.fe->name,NewName);
    if(jtmfs_ffwritelocation(device_nr,&dw))
    {
        EndDirWalk(&dw);
        return 3;
    }
    EndDirWalk(&dw);
    return 0;
}

// ------------------------------------------------------------------------------
// jtmfs_setsize(dev, "floppy:lala", new_size, rootdir);
//
// Set file fixed size (in bytes).
//
// This function only sets the visible size, but does
// not affect the real allocated blocks amount.
//
static int jtmfs_zero_visible_range(int device_nr, DWORD first,
                                    int offset, int length)
{
    BYTE *z;
    int chunk,done,rv;
    if(length<=0) return 0;
    if(first==0 || !jtmfat_isdatablock(device_nr,first)) return 1;
    z=malloc(64*1024);
    if(z==NULL) return 1;
    memset(z,0,64*1024);
    done=0;
    while(done<length)
    {
        chunk=length-done;
        if(chunk>64*1024) chunk=64*1024;
        rv=jtmfs_WriteFileChain(z,device_nr,(int)first,chunk,offset+done);
        if(rv)
        {
            free(z);
            return 1;
        }
        done+=chunk;
    }
    free(z);
    return 0;
}

// ------------------------------------------------------------------------------
// jtmfs_setsize(dev, "floppy:lala", new_size, rootdir);
//
// V68.117: resize is now a real FAT transaction.  Shrinking detaches surplus
// blocks and keeps the exact byte length in the directory entry.  Growing
// allocates a private zero-filled chain first and publishes it only after the
// whole extension is ready.  On metadata failure the old chain is restored.
static int jtmfs_setsize_mode(int device_nr,
        const char *OldName, int newSize,
            int dirblock, int zero_growth)
{
    DIRWALK dw;
    DWORD first,old_dir_last,block,next,actual_last,keep_tail,detach_first;
    DWORD new_first,new_last,new_block,prev_new;
    long reserve_rv;
    int dirblock1,bs,oldSize,old_blocks,need_blocks,count,rv;
    int add,zero_len,zero_capacity;
    BYTE *zero_block;

    if(!isValidDevice(device_nr) || OldName==NULL || newSize<0) return 1;
    if(dirblock<0 || dirblock>=(int)jtmfat_unitcount(device_nr)) return 1;
    bs=(int)jtmfat_unitsize(device_nr);
    if(bs<=0) return 1;
    dirblock1=dirblock ? dirblock : jtmfs_getrootdir(device_nr);

    jtmfs_mutation_lock(device_nr);
    InitDW(&dw);
    if(!jtmfs_ffindfile(device_nr,OldName,dirblock1,&dw) || dw.fe==NULL)
    {
        jtmfs_mutation_unlock(device_nr);
        return 1;
    }

    oldSize=dw.fe->length;
    if(oldSize<0)
    {
        EndDirWalk(&dw);
        jtmfs_mutation_unlock(device_nr);
        return 1;
    }
    first=dw.fe->FirstDataBlock;
    old_dir_last=dw.fe->LastDataBlock;
    need_blocks=(newSize==0) ? 0 : ((newSize+bs-1)/bs);
    old_blocks=0;
    actual_last=0;
    keep_tail=0;
    detach_first=0;

    /* Validate/count the real chain instead of trusting length or the cached
     * LastDataBlock field.  This also repairs a stale LastDataBlock on commit. */
    if(first!=0)
    {
        block=first;
        for(count=0; count<(int)jtmfat_unitcount(device_nr); count++)
        {
            if(!jtmfat_isdatablock(device_nr,block)) { rv=4; goto out; }
            old_blocks++;
            if(old_blocks==need_blocks) keep_tail=block;
            next=(DWORD)jtmfat_getblock(device_nr,(int)block);
            if(next>=0xFFFFFFF8UL)
            {
                actual_last=block;
                break;
            }
            if(next==0 || next>=0xFFFFFFF0UL ||
               next>=jtmfat_unitcount(device_nr) || next==block ||
               !jtmfat_isdatablock(device_nr,next))
            {
                rv=4;
                goto out;
            }
            if(old_blocks==need_blocks) detach_first=next;
            block=next;
        }
        if(actual_last==0) { rv=4; goto out; }
    }

    /* A post-write size commit must never allocate or zero data: the writer
     * has already reserved the complete span and written the bytes. */
    if(!zero_growth && need_blocks>old_blocks) { rv=4; goto out; }

    /* No allocation change: preserve the chain, zero newly exposed bytes only
     * for truncate-style growth, and publish the exact requested byte length. */
    if(need_blocks==old_blocks)
    {
        if(zero_growth && newSize>oldSize && first!=0)
        {
            zero_len=newSize-oldSize;
            if(jtmfs_zero_visible_range(device_nr,first,oldSize,zero_len))
            { rv=5; goto out; }
        }
        dw.fe->length=newSize;
        if(old_blocks==0) { dw.fe->FirstDataBlock=0; dw.fe->LastDataBlock=0; }
        else { dw.fe->FirstDataBlock=first; dw.fe->LastDataBlock=actual_last; }
        if(jtmfs_ffwritelocation(device_nr,&dw))
        {
            dw.fe->length=oldSize;
            dw.fe->FirstDataBlock=first;
            dw.fe->LastDataBlock=old_dir_last;
            rv=3;
        }
        else rv=0;
        goto out;
    }

    /* Shrink to empty: first publish an empty namespace entry, then release
     * the now unreachable old chain.  A release failure leaks blocks but does
     * not leave a file pointing into free space. */
    if(need_blocks==0)
    {
        dw.fe->length=0;
        dw.fe->FirstDataBlock=0;
        dw.fe->LastDataBlock=0;
        if(jtmfs_ffwritelocation(device_nr,&dw))
        {
            dw.fe->length=oldSize;
            dw.fe->FirstDataBlock=first;
            dw.fe->LastDataBlock=old_dir_last;
            rv=3;
            goto out;
        }
        if(first!=0 && jtmfs_deletechain(device_nr,(int)first))
            printk("jtmfs_setsize: orphaned old chain %u after shrink-to-zero.\n",first);
        rv=0;
        goto out;
    }

    /* Shrink while keeping at least one block.  Detach first but do not free;
     * if the directory update fails, restore the exact old FAT link. */
    if(need_blocks<old_blocks)
    {
        if(keep_tail==0 || detach_first==0) { rv=4; goto out; }
        if(jtmfat_setblock(device_nr,(int)keep_tail,(int)0xFFFFFFF8UL))
        { rv=5; goto out; }
        dw.fe->length=newSize;
        dw.fe->FirstDataBlock=first;
        dw.fe->LastDataBlock=keep_tail;
        if(jtmfs_ffwritelocation(device_nr,&dw))
        {
            dw.fe->length=oldSize;
            dw.fe->FirstDataBlock=first;
            dw.fe->LastDataBlock=old_dir_last;
            (void)jtmfat_setblock(device_nr,(int)keep_tail,(int)detach_first);
            rv=3;
            goto out;
        }
        if(jtmfs_deletechain(device_nr,(int)detach_first))
            printk("jtmfs_setsize: detached chain %u could not be fully freed.\n",detach_first);
        rv=0;
        goto out;
    }

    /* Enlarge: build a private, zero-filled standalone chain.  Nothing links
     * it to the old file until every required block has been reserved. */
    add=need_blocks-old_blocks;
    new_first=0;
    new_last=0;
    prev_new=0;
    zero_block=malloc(bs);
    if(zero_block==NULL) { rv=6; goto out; }
    memset(zero_block,0,bs);
    while(add>0)
    {
        DWORD lba,cs;
        reserve_rv=jtmfat_reserveblock(device_nr);
        if(reserve_rv==-1)
        {
            /* Legacy jtmfs_setsize() ABI uses rv=2 for ENOSPC. */
            rv=2;
            goto grow_fail;
        }
        if(reserve_rv<=0 || (DWORD)reserve_rv>=jtmfat_unitcount(device_nr))
        {
            dprintk("jtmfs_setsize: allocator fault dnr=%d rv=%d while growing '%s'.\n",
                    device_nr,(int)reserve_rv,OldName);
            rv=5;
            goto grow_fail;
        }
        new_block=(DWORD)reserve_rv;
        lba=jtmfat_unit_to_lba(device_nr,new_block);
        cs=jtmfat_clustersectors(device_nr);
        if(lba==0xffffffffUL || cs==0 ||
           writeblocks(device_nr,(long)lba,zero_block,(int)cs)!=(int)cs)
        {
            (void)jtmfat_setblock(device_nr,(int)new_block,0);
            rv=5;
            goto grow_fail;
        }
        if(new_first==0) new_first=new_block;
        if(prev_new!=0 && jtmfat_setblock(device_nr,(int)prev_new,(int)new_block))
        {
            (void)jtmfat_setblock(device_nr,(int)new_block,0);
            rv=5;
            goto grow_fail;
        }
        prev_new=new_block;
        new_last=new_block;
        add--;
    }
    free(zero_block);
    zero_block=NULL;

    /* Existing allocated bytes past old EOF must read as zero after truncate
     * enlargement, including the tail of an already allocated last block. */
    if(old_blocks>0 && newSize>oldSize)
    {
        zero_capacity=old_blocks*bs-oldSize;
        if(zero_capacity<0) zero_capacity=0;
        zero_len=newSize-oldSize;
        if(zero_len>zero_capacity) zero_len=zero_capacity;
        if(zero_len>0 && jtmfs_zero_visible_range(device_nr,first,oldSize,zero_len))
        { rv=5; goto grow_fail_nozero; }
    }

    if(old_blocks==0)
    {
        dw.fe->FirstDataBlock=new_first;
        dw.fe->LastDataBlock=new_last;
    }
    else
    {
        if(jtmfat_setblock(device_nr,(int)actual_last,(int)new_first))
        { rv=5; goto grow_fail_nozero; }
        dw.fe->FirstDataBlock=first;
        dw.fe->LastDataBlock=new_last;
    }
    dw.fe->length=newSize;
    if(jtmfs_ffwritelocation(device_nr,&dw))
    {
        dw.fe->length=oldSize;
        dw.fe->FirstDataBlock=first;
        dw.fe->LastDataBlock=old_dir_last;
        if(old_blocks>0) (void)jtmfat_setblock(device_nr,(int)actual_last,(int)0xFFFFFFF8UL);
        rv=3;
        goto grow_fail_nozero;
    }
    rv=0;
    goto out;

grow_fail:
    if(zero_block) { free(zero_block); zero_block=NULL; }
grow_fail_nozero:
    if(new_first!=0) (void)jtmfs_deletechain(device_nr,(int)new_first);
out:
    EndDirWalk(&dw);
    jtmfs_mutation_unlock(device_nr);
    return rv;
}

int jtmfs_setsize(int device_nr,
        const char *OldName, int newSize,
            int dirblock)
{
    return jtmfs_setsize_mode(device_nr,OldName,newSize,dirblock,1);
}

int jtmfs_setsize_after_write(int device_nr,
        const char *OldName, int newSize,
            int dirblock)
{
    return jtmfs_setsize_mode(device_nr,OldName,newSize,dirblock,0);
}

// DELETECHAIN
// -----------
//
// Deletes a file/dir chain
// (frees all the blocks of the specified chain)
//
// Returns zero on success
// and non-zero on error
//
// NEW: now ignores chain that is allocated on block zero.
//
// ** TODO **
// Something wrong here, it does not delete the chain.
// Instead the data is left there, maybe
// dump of the fat table will tell what has
// been happended.
// But it definetly does not deallocate the chain.
//
int jtmfs_deletechain(int device_nr, int blocknr)
{
    DWORD block,next;
    int count;

    if(!isValidDevice(device_nr) || blocknr<=0 || blocknr>=(int)jtmfat_unitcount(device_nr))
        return 1;

    block=(DWORD)blocknr;
    for(count=0;count<(int)jtmfat_unitcount(device_nr);count++)
    {
        jtmfs_cooperative_yield((unsigned long)count);
        if(block==0 || block>=(DWORD)(int)jtmfat_unitcount(device_nr))
        {
            printk("jtmfs_deletechain: invalid chain block %u.\n",block);
            return 1;
        }

        next=(DWORD)jtmfat_getblock(device_nr,(int)block);
        if(next==0)
        {
            printk("jtmfs_deletechain: free FAT entry encountered inside chain at block %u.\n",block);
            return 1;
        }
        if(next==block)
        {
            printk("jtmfs_deletechain: self-loop at block %u.\n",block);
            return 1;
        }

        /* F8..FF are legitimate end-of-chain markers.  F0..F7 are reserved
         * or bad/system markers and must never terminate a normal file. */
        if(next>=0xFFFFFFF8UL)
        {
            if(jtmfat_setblock(device_nr,(int)block,0)) return 1;
            return 0;
        }
        if(next>=0xFFFFFFF0UL || next>=(DWORD)(int)jtmfat_unitcount(device_nr))
        {
            printk("jtmfs_deletechain: invalid FAT link %u -> 0x%x.\n",block,next);
            return 1;
        }

        if(jtmfat_setblock(device_nr,(int)block,0)) return 1;
        block=next;
    }

    printk("jtmfs_deletechain: FAT chain loop/overflow from block %d.\n",blocknr);
    return 1;
}

// The real getfilesize function.
// Returns size of the file in bytes.
//
int jtmfs_getfilesize(int dnr, const char *fname, int db)
{
	if(!isValidDevice(dnr) || fname==NULL || db<0 || db>=(int)jtmfat_unitcount(dnr)) return -1;

	/* Do not use a process-global static DIRWALK here.  DIRWALK is 16 KiB and
	 * the old static shortcut made file-size queries non-reentrant: a timer
	 * switch could let another task replace dw.fe before this task read the
	 * length.  DirDB now exposes a small atomic metadata lookup instead. */
	return dirdb_GetFileLength(dnr,fname,db);
}

// Returns size of the specified file.
//
// PERFORMANCE NOTIFICATION:
// This is a determistic diagnostics function and it is SLOW.
// It is easier to just read the file entry and use it's
// file size identifier variable to determine size of the file.
//
int jtmfs_getfileblocksize(int device_nr, const char *fname, int dblock)
{
	DWORD block,next;
	int amount,limit;
	static DIRWALK dw;

	if(!isValidDevice(device_nr) || fname==NULL ||
	   dblock<0 || dblock>=(int)jtmfat_unitcount(device_nr))
		return 0;
	InitDW(&dw);
	if(!jtmfs_ffindfile(device_nr,fname,dblock,&dw) || dw.fe==NULL)
		return 0;

	block=dw.fe->FirstDataBlock;
	if(block==0) { EndDirWalk(&dw); return 0; }
	limit=(int)jtmfat_unitcount(device_nr);
	if(limit<=0) { EndDirWalk(&dw); return 0; }

	/* Bound traversal by the number of media blocks.  This catches every FAT
	 * cycle, not only the historical A->A self-loop case. */
	for(amount=1; amount<=limit; amount++)
	{
		if(!jtmfat_isdatablock(device_nr,block))
		{
			EndDirWalk(&dw);
			return 2;
		}
		next=(DWORD)jtmfat_getblock(device_nr,block);
		if(next==0xFFFFFFF8UL) { EndDirWalk(&dw); return amount; }
		if(next>=0xFFFFFFF0UL || next==0 || next>=(DWORD)limit)
		{
			printk("jtmfs_getfileblocksize: corrupt FAT chain at %u -> 0x%x.\n",
			       block,next);
			EndDirWalk(&dw);
			return 2;
		}
		block=next;
	}
	printk("jtmfs_getfileblocksize: FAT cycle/overflow detected for '%s'.\n",fname);
	EndDirWalk(&dw);
	return 3;
}

// Return value:
// 0 = Entry not found.
// 1 = Entry found(FILE).
// 2 = Entry found(DIRECTORY).
int jtmfs_fexist(int dnr, char *fname, int dblock)
{
	static DIRWALK dw;
	int rv;

	if(!isValidDevice(dnr) || fname==NULL || dblock<0 || dblock>=(int)jtmfat_unitcount(dnr)) return 0;
	InitDW(&dw);

	/* V62 namespace rule: a bare name such as "hda" is an ordinary
	 * directory entry.  Physical device selection is explicit ("hda:" or
	 * "hda:/...") and is handled by the pathname resolver.  Older code
	 * pretended every registered device name already existed here; that made
	 * it impossible for rootfs to create the real /hda, /cdrom, /sys, ...
	 * mount-point placeholders. */

	//
	if( jtmfs_ffindfile(dnr, fname, dblock, &dw) )
	{
		// Determine return value from the class bits, preserving attributes.
		switch(JTMFS_TYPE_CLASS(dw.fe->type))
		{
			case JTMFS_CLASS_DIRECTORY:
				rv = 2;
				break;
			case JTMFS_CLASS_DIRNAME:
				rv = 3;
				break;
			case JTMFS_CLASS_FILE:
			default:
				rv = 1;
				break;
		}

		//
		EndDirWalk(&dw);
		return rv;
	}
	else return 0;
}

//

