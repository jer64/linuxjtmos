/*
 * diskspace.c - per-block-device free-space accounting and ENOSPC diagnostics.
 *
 * V68.133 goals:
 *  - keep a cheap in-kernel free-space snapshot for every block device;
 *  - take one exact JTMFS FAT snapshot, then maintain it incrementally;
 *  - update the cached count on every normal FAT free<->allocated transition;
 *  - provide a rate-limited automatic troubleshooter when allocation fails;
 *  - serialize compact snapshots for /var/log/diskspace.log.
 *
 * Raw devices are recorded with capacity but free space is only meaningful for
 * a filesystem.  At present JTMFS is the filesystem that exports exact free
 * allocation-unit accounting.
 */
#include "kernel32.h"
#include "driver_api.h"
#include "jtmfat.h"
#include "jtmfs.h"
#include "diskspace.h"
#include "logging.h"

#define DISKSPACE_WARN_PERCENT      10UL
#define DISKSPACE_CRIT_PERCENT       5UL
#define DISKSPACE_TROUBLE_RATE       5UL

static JTMOS_DISKSPACE_STATS ds[DISKSPACE_MAX_DEVICES];
static BYTE ds_valid[DISKSPACE_MAX_DEVICES];
static BYTE ds_warn_state[DISKSPACE_MAX_DEVICES];
static int ds_initialized=0;

static void ds_init_once(void)
{
    int i;
    if(ds_initialized) return;
    memset(ds,0,sizeof(ds));
    memset(ds_valid,0,sizeof(ds_valid));
    memset(ds_warn_state,0,sizeof(ds_warn_state));
    for(i=0;i<DISKSPACE_MAX_DEVICES;i++) ds[i].min_free_units=0xffffffffUL;
    ds_initialized=1;
}

void DiskSpaceInit(void)
{
    ds_init_once();
}

void DiskSpaceInvalidateDevice(int dnr)
{
    int flags;
    ds_init_once();
    if(dnr<0 || dnr>=DISKSPACE_MAX_DEVICES) return;
    flags=get_eflags();
    disable();
    ds_valid[dnr]=0;
    ds_warn_state[dnr]=0;
    memset(&ds[dnr],0,sizeof(ds[dnr]));
    ds[dnr].min_free_units=0xffffffffUL;
    set_eflags(flags);
}


/* Freestanding i486 kernel helper: avoid GCC's __udivdi3 dependency.
 * JTMOS links the kernel without libgcc.  The percentage routine uses exact
 * integer thresholds, and the KiB conversion rearranges the product so the
 * common 32-bit result does not require 64-bit division. */
DWORD DiskSpacePercentUnits(DWORD free_units,DWORD total_units)
{
    DWORD q,r,threshold;
    int pct;
    if(total_units==0) return 0;
    if(free_units>=total_units) return 100;
    q=total_units/100UL;
    r=total_units%100UL;
    for(pct=99;pct>0;pct--) {
        threshold=q*(DWORD)pct;
        threshold+=(r*(DWORD)pct+99UL)/100UL;
        if(free_units>=threshold) return (DWORD)pct;
    }
    return 0;
}

DWORD DiskSpaceUnitsToKiB(DWORD units,DWORD unit_size)
{
    DWORD hi,lo,a,b;
    if(units==0 || unit_size==0) return 0;
    hi=units/1024UL;
    lo=units%1024UL;
    if(hi!=0 && unit_size>0xffffffffUL/hi) return 0xffffffffUL;
    a=hi*unit_size;
    b=(lo*unit_size)/1024UL;
    if(b>0xffffffffUL-a) return 0xffffffffUL;
    return a+b;
}

static DWORD ds_state_flags(DWORD total,DWORD free_units,DWORD base_flags)
{
    DWORD pct;
    base_flags &= ~(DISKSPACE_FLAG_LOW|DISKSPACE_FLAG_CRITICAL|DISKSPACE_FLAG_FULL);
    if(total==0) return base_flags;
    if(free_units==0) return base_flags|DISKSPACE_FLAG_FULL|DISKSPACE_FLAG_CRITICAL|DISKSPACE_FLAG_LOW;
    pct=DiskSpacePercentUnits(free_units,total);
    if(pct<=DISKSPACE_CRIT_PERCENT) base_flags|=DISKSPACE_FLAG_CRITICAL|DISKSPACE_FLAG_LOW;
    else if(pct<=DISKSPACE_WARN_PERCENT) base_flags|=DISKSPACE_FLAG_LOW;
    return base_flags;
}

int DiskSpaceRefreshDevice(int dnr)
{
    JTMOS_DISKSPACE_STATS n;
    DWORD units,first,free_units,i;
    int bs,flags;

    ds_init_once();
    if(dnr<0 || dnr>=DISKSPACE_MAX_DEVICES || !isValidDevice(dnr)) return -1;
    bs=getblocksize(dnr);
    if(bs<=0 || getsize(dnr)<=0) return -1;

    memset(&n,0,sizeof(n));
    n.unit_size=(DWORD)bs;
    n.total_units=(DWORD)getsize(dnr);
    n.min_free_units=0xffffffffUL;
    n.flags=DISKSPACE_FLAG_BLOCK_DEVICE;

    /* Never probe raw/removable media just for statistics.  JTMFS devices
     * become known here after the normal mount/info-block path has populated
     * fatsys; this keeps the periodic monitor from waking empty floppy/CD
     * devices every few minutes. */
    if(fatsys!=NULL && dnr<N_CFAT_STRUCTURES &&
       fatsys->isJTMFS[dnr] && fatsys->bb[dnr]!=NULL)
    {
        /* Freeze namespace/FAT mutation while reconciling the exact count.
         * The lock is re-entrant for callers already inside a write/resize. */
        jtmfs_mutation_lock(dnr);
        units=jtmfat_unitcount(dnr);
        first=jtmfat_firstallocatableblock(dnr);
        if(units==0 || first==0 || first>=units)
        {
            jtmfs_mutation_unlock(dnr);
            return -1;
        }
        free_units=0;
        for(i=first;i<units;i++)
        {
            if((DWORD)jtmfat_getblock(dnr,(int)i)==0) free_units++;
            if((i&0xffUL)==0) jtmfs_cooperative_yield(i);
        }
        jtmfs_mutation_unlock(dnr);

        n.total_units=units;
        n.free_units=free_units;
        n.unit_size=jtmfat_unitsize(dnr);
        n.first_allocatable=first;
        n.flags|=DISKSPACE_FLAG_JTMFS;
    }

    flags=get_eflags();
    disable();
    n.samples=ds[dnr].samples+1U;
    n.enospc_events=ds[dnr].enospc_events;
    n.last_enospc_seconds=ds[dnr].last_enospc_seconds;
    n.last_sample_seconds=(DWORD)GetSeconds();
    if(ds_valid[dnr] && ds[dnr].min_free_units<n.min_free_units)
        n.min_free_units=ds[dnr].min_free_units;
    if((n.flags&DISKSPACE_FLAG_JTMFS) && n.free_units<n.min_free_units)
        n.min_free_units=n.free_units;
    n.flags=ds_state_flags(n.total_units,n.free_units,n.flags);
    ds[dnr]=n;
    ds_valid[dnr]=1;
    set_eflags(flags);
    return 0;
}

int DiskSpaceGetStats(int dnr,JTMOS_DISKSPACE_STATS *out,int refresh_if_needed)
{
    int flags,need;
    DWORD now;
    ds_init_once();
    if(out==NULL || dnr<0 || dnr>=DISKSPACE_MAX_DEVICES) return -1;
    now=(DWORD)GetSeconds();
    (void)now;
    flags=get_eflags();
    disable();
    /* A full FAT scan is intentionally one-shot/lazy.  After initialization
     * every normal FAT free<->allocated transition updates the counter, so
     * periodic logging remains O(number-of-devices) instead of O(FAT-size). */
    need=!ds_valid[dnr];
    set_eflags(flags);
    if(need && refresh_if_needed && DiskSpaceRefreshDevice(dnr)!=0) return -1;
    flags=get_eflags();
    disable();
    if(!ds_valid[dnr]) { set_eflags(flags); return -1; }
    *out=ds[dnr];
    set_eflags(flags);
    return 0;
}

void DiskSpaceFatTransition(int dnr,DWORD block,DWORD old_value,DWORD new_value)
{
    int flags,delta=0;
    DWORD first,total;
    ds_init_once();
    if(dnr<0 || dnr>=DISKSPACE_MAX_DEVICES || old_value==new_value) return;
    flags=get_eflags();
    disable();
    if(!ds_valid[dnr] || !(ds[dnr].flags&DISKSPACE_FLAG_JTMFS))
    { set_eflags(flags); return; }
    first=ds[dnr].first_allocatable;
    total=ds[dnr].total_units;
    if(block<first || block>=total) { set_eflags(flags); return; }
    if(old_value==0 && new_value!=0) delta=-1;
    else if(old_value!=0 && new_value==0) delta=1;
    if(delta<0 && ds[dnr].free_units>0) ds[dnr].free_units--;
    else if(delta>0 && ds[dnr].free_units<total-first) ds[dnr].free_units++;
    ds[dnr].samples++;
    ds[dnr].last_sample_seconds=(DWORD)GetSeconds();
    if(ds[dnr].free_units<ds[dnr].min_free_units) ds[dnr].min_free_units=ds[dnr].free_units;
    ds[dnr].flags=ds_state_flags(ds[dnr].total_units,ds[dnr].free_units,ds[dnr].flags);
    set_eflags(flags);
}

static void ds_device_name(int dnr,char *buf,int cap)
{
    if(buf==NULL || cap<=0) return;
    buf[0]=0;
    if(getdevicename(dnr,buf)==NULL || !buf[0]) snprintf(buf,(size_t)cap,"dnr%d",dnr);
}

int DiskSpaceTroubleshootDevice(int dnr,const char *reason,DWORD requested_bytes,int force)
{
    JTMOS_DISKSPACE_STATS s;
    char dev[64],msg[320];
    DWORD totalk,freek,rawk;
    DWORD now,pct;
    int raw_blocks,raw_bs,geometry_suspect;
    int flags,rate_limited=0;

    if(DiskSpaceGetStats(dnr,&s,1)!=0) return -1;
    now=(DWORD)GetSeconds();
    flags=get_eflags();
    disable();
    if(!force && ds[dnr].last_enospc_seconds!=0 &&
       now-ds[dnr].last_enospc_seconds<DISKSPACE_TROUBLE_RATE)
        rate_limited=1;
    else {
        ds[dnr].last_enospc_seconds=now;
        ds[dnr].enospc_events++;
        s.enospc_events=ds[dnr].enospc_events;
        s.last_enospc_seconds=now;
    }
    set_eflags(flags);
    if(rate_limited) return 0;

    ds_device_name(dnr,dev,sizeof(dev));
    totalk=DiskSpaceUnitsToKiB(s.total_units,s.unit_size);
    freek=DiskSpaceUnitsToKiB(s.free_units,s.unit_size);
    pct=DiskSpacePercentUnits(s.free_units,s.total_units);
    raw_blocks=getsize(dnr);
    raw_bs=getblocksize(dnr);
    rawk=(raw_blocks>0 && raw_bs>0) ?
         DiskSpaceUnitsToKiB((DWORD)raw_blocks,(DWORD)raw_bs) : 0;
    /* A hard-disk style name exposing <=64 MiB is suspicious enough to call
     * out explicitly, but it is NOT used to change ENOSPC semantics.  This
     * catches cases like a 500 GB disk accidentally exported as 32768 sectors. */
    geometry_suspect=((dev[0]=='h' && dev[1]=='d') && rawk>0 && rawk<=64UL*1024UL);

    printk("\n*** JTMOS DISK SPACE TROUBLESHOOTER ***\n");
    printk("device=%s: DNR=%d reason=%s requested=%u bytes\n",
           dev,dnr,reason?reason:"ENOSPC",(unsigned)requested_bytes);
    printk("JTMFS capacity=%u KiB free=%u KiB (%u%%), unit=%u bytes, free-units=%u\n",
           (unsigned)totalk,(unsigned)freek,(unsigned)pct,(unsigned)s.unit_size,(unsigned)s.free_units);
    printk("DEVAPI geometry=%d blocks x %d bytes = %u KiB\n",
           raw_blocks,raw_bs,(unsigned)rawk);
    if(geometry_suspect)
        printk("WARNING: hard-disk geometry is suspiciously small. If the physical disk is larger, investigate ATA/AHCI IDENTIFY/geometry before treating this as a normal full disk.\n");
    printk("diagnosis: no free JTMFS allocation units are available for this request.\n");
    printk("actions: run 'df -h'; remove/move files; or enlarge/repartition the target device.\n");
    printk("note: kernel free-space counters are persisted in /var/log/diskspace.log when root logging is writable.\n");
    printk("*** END DISK SPACE TROUBLESHOOTER ***\n\n");

    snprintf(msg,sizeof(msg),
             "DISKSPACE/ENOSPC device=%s dnr=%d reason=%s request=%u free_kib=%u total_kib=%u devapi_kib=%u geometry_suspect=%d events=%u",
             dev,dnr,reason?reason:"ENOSPC",(unsigned)requested_bytes,
             (unsigned)freek,(unsigned)totalk,(unsigned)rawk,geometry_suspect,
             (unsigned)s.enospc_events);
    WriteSystemLog(msg);
    return 0;
}

void DiskSpaceNoteENOSPC(int dnr,const char *context,DWORD requested_bytes)
{
    (void)DiskSpaceTroubleshootDevice(dnr,context,requested_bytes,0);
}

void DiskSpacePeriodicSample(void)
{
    JTMOS_DISKSPACE_STATS s;
    char dev[64],msg[256];
    DWORD now;
    int dnr,state,oldstate;

    ds_init_once();
    now=(DWORD)GetSeconds();
    for(dnr=0;dnr<DISKSPACE_MAX_DEVICES;dnr++)
    {
        if(!isValidDevice(dnr) || getsize(dnr)<=0 || getblocksize(dnr)<=0) continue;
        if(!ds_valid[dnr])
            (void)DiskSpaceRefreshDevice(dnr);
        if(DiskSpaceGetStats(dnr,&s,0)!=0 || !(s.flags&DISKSPACE_FLAG_JTMFS)) continue;
        state=(s.flags&DISKSPACE_FLAG_FULL)?3:
              ((s.flags&DISKSPACE_FLAG_CRITICAL)?2:((s.flags&DISKSPACE_FLAG_LOW)?1:0));
        oldstate=ds_warn_state[dnr];
        if(state!=oldstate)
        {
            ds_warn_state[dnr]=(BYTE)state;
            ds_device_name(dnr,dev,sizeof(dev));
            if(state>0)
            {
                DWORD freek=DiskSpaceUnitsToKiB(s.free_units,s.unit_size);
                snprintf(msg,sizeof(msg),"DISKSPACE/%s device=%s: free=%u KiB units=%u",
                         state==3?"FULL":(state==2?"CRITICAL":"LOW"),dev,
                         (unsigned)freek,(unsigned)s.free_units);
                WriteSystemLog(msg);
                if(state==3) (void)DiskSpaceTroubleshootDevice(dnr,"periodic full-space check",0,0);
            }
            else if(oldstate>0)
            {
                snprintf(msg,sizeof(msg),"DISKSPACE/RECOVERED device=%s: free-units=%u",
                         dev,(unsigned)s.free_units);
                WriteSystemLog(msg);
            }
        }
    }
}

static int ds_write_all(int fd,const char *p,int n)
{
    int off=0,rv;
    while(off<n) {
        rv=write(fd,(void *)(p+off),n-off);
        if(rv<=0) return -1;
        off+=rv;
    }
    return 0;
}

int DiskSpaceWriteSnapshot(int fd)
{
    JTMOS_DISKSPACE_STATS s;
    char dev[64],line[320];
    int dnr,n;
    DWORD totalk,freek;

    if(fd<0) return -1;
    n=snprintf(line,sizeof(line),"snapshot seconds=%u\n",(unsigned)GetSeconds());
    if(n>0 && ds_write_all(fd,line,n)!=0) return -1;
    for(dnr=0;dnr<DISKSPACE_MAX_DEVICES;dnr++)
    {
        if(!isValidDevice(dnr) || getsize(dnr)<=0 || getblocksize(dnr)<=0) continue;
        if(DiskSpaceGetStats(dnr,&s,1)!=0) continue;
        ds_device_name(dnr,dev,sizeof(dev));
        totalk=DiskSpaceUnitsToKiB(s.total_units,s.unit_size);
        freek=DiskSpaceUnitsToKiB(s.free_units,s.unit_size);
        if(s.flags&DISKSPACE_FLAG_JTMFS)
            n=snprintf(line,sizeof(line),
                       "dnr=%d dev=%s fs=JTMFS total_kib=%u free_kib=%u unit=%u free_units=%u min_free_units=%u enospc=%u flags=0x%x\n",
                       dnr,dev,(unsigned)totalk,(unsigned)freek,(unsigned)s.unit_size,(unsigned)s.free_units,
                       (unsigned)s.min_free_units,(unsigned)s.enospc_events,(unsigned)s.flags);
        else
            n=snprintf(line,sizeof(line),
                       "dnr=%d dev=%s fs=raw total_kib=%u free=n/a block=%u flags=0x%x\n",
                       dnr,dev,(unsigned)totalk,(unsigned)s.unit_size,(unsigned)s.flags);
        if(n>0 && ds_write_all(fd,line,n)!=0) return -1;
    }
    return 0;
}
