//==============================================================================
// Direct File Access Functions
// (C) 2020 by Jari Tuominen.
// Added locking mechanism to prevent thread violations.
//==============================================================================
#include "basdef.h"
#include "kernel32.h"
#include "scs.h"
#include "devsys.h"
#include "jtmfs.h"
#include "jtmfat.h"
#include "devapi.h"
#include "sysgfx.h" // SetVideoMode, setvmode
#include "filedes.h"
#include "lock.h"
#include "directfileaccess.h"
#include "mount.h"
#include "createfat.h"
#include "jtmfsPath.h"
#include "driver_flush.h"
#include "diskcache/dirdbAccess.h"
#include "diskcache/flexFat.h"
#include "linuxabi.h"
//#include "dispadmin.h" // dispadmin_getcurrentmode
//#include "verify_ptr.h"

//
#define ddprintk dprintk


/* Release any hidden FAT extension left by reserve-for-write after a failed
 * data/EOF commit.  Calling SetSize(original_size) is intentional even when
 * the visible length never changed: jtmfs_setsize_mode() counts the real FAT
 * chain and detaches surplus hidden blocks transactionally. */
static void jtmfs_rollback_failed_write_growth(int dnr,const char *name,int db,
                                                int original_size,const char *where)
{
    int rv;
    if(!isValidDevice(dnr) || name==NULL || original_size<0) return;
    rv=jtmfs_SetSize(dnr,name,original_size,db);
    if(rv==0)
        dprintk("JTMFS/write rollback: dnr=%d file='%s' restored_size=%d after=%s.\n",
                dnr,name,original_size,where?where:"write failure");
    else
        dprintk("JTMFS/write rollback FAILED: dnr=%d file='%s' size=%d rv=%d after=%s.\n",
                dnr,name,original_size,rv,where?where:"write failure");
}

/* Device read/write scratch space is allocated per operation.
 * Keeping it local avoids stale shared buffers and makes the byte-to-block
 * conversion explicit and bounds checked. */

//
int renamefile(const char *oldpath, const char *newpath)
{
	// ----------------------------------------------------
	int key1,pr,i,i2,i3,i4;
	LOCK

	//
	if( oldpath && isValidString(oldpath) && strlen(oldpath)
		&&
		newpath && isValidString(newpath) && strlen(newpath) )
	{
jtmfs_RenameFile(GetCurrentDNR(), oldpath,newpath, GetCurrentDB());
	}

	//
	UNLOCK
	return 0;
}

// Create file
int createfile(const char *path)
{
	// ----------------------------------------------------
	int key1,pr,i,i2,i3,i4,rv,devnr;
	
	LOCK

	//
	if( path && isValidString(path) && strlen(path) )
	{
		//
		ReportMessage("%s: Calling jtmfs_CreateFile, dnr=%d, db=%d, fname='%s'.\n",
			__FUNCTION__, GetCurrentDNR(), GetCurrentDB(), path);
rv = jtmfs_CreateFile(GetCurrentDNR(), GetCurrentDB(), path, 0);
	}
	else
	{
		//
		ddprintk("%s: Invalid call.\n");
		rv = 1984;
	}

	//
	UNLOCK
	return rv;
}

// Remove a file
int deletefile(const char *path)
{
	// ----------------------------------------------------
	int key1,pr,i,i2,i3,i4,devnr;
	
	LOCK

	// Check path
	if( path && isValidString(path) && strlen(path) )
	{
jtmfs_DeleteFile(GetCurrentDNR(), path, GetCurrentDB());
	}

	//
	UNLOCK
	return 0;
}

// Read data from specified part of a file.
// Usage: readfile path, buf, offset, count.
int readfile(char *path, char *buf, int offset, int count)
{
    int d1,bs,first_block,byte_offset,block_count,dev_blocks,rv;
    unsigned long span;
    size_t scratch_len;
    BYTE *scratch=NULL;

    LOCK

    if(count==0) { UNLOCK return 0; }
    if(count >= (1024*1024*1) || count < 0 || offset < 0 || buf == NULL)
    {
        errno=EINVAL;
        UNLOCK
        return EINVAL;
    }
    if(path==NULL || !isValidString(path) || !strlen(path))
    {
        errno=EINVAL;
        UNLOCK
        return EINVAL;
    }

    FFCHECK

    /* Raw block device byte stream.  Return 0 only after the complete request
     * really reached the caller's buffer.  Older code silently returned
     * success after a failed READ(10), which let SQA parse stale heap bytes. */
    if((d1=driver_getdevicenrbyname(path))!=-1)
    {
        bs=getblocksize(d1);
        dev_blocks=getsize(d1);
        if(bs<=0 || dev_blocks<=0)
        {
            ReportMessage("%s: device '%s' has invalid geometry.\n",__FUNCTION__,path);
            errno=EIO;
            UNLOCK
            return EIO;
        }

        first_block=offset/bs;
        byte_offset=offset%bs;
        span=(unsigned long)byte_offset+(unsigned long)count;
        block_count=(int)((span+(unsigned long)bs-1UL)/(unsigned long)bs);
        if(first_block<0 || block_count<=0 || first_block>=dev_blocks ||
           block_count>(dev_blocks-first_block))
        {
            ReportMessage("%s: device read outside '%s': block=%d count=%d size=%d.\n",
                          __FUNCTION__,path,first_block,block_count,dev_blocks);
            errno=ERANGE;
            UNLOCK
            return ERANGE;
        }

        if(byte_offset==0 && count==block_count*bs)
        {
            rv=readblocks(d1,first_block,(BYTE *)buf,block_count);
            if(rv!=block_count)
            {
                ReportMessage("%s: multi-block read failed: %s block %d count %d rv=%d.\n",
                              __FUNCTION__,path,first_block,block_count,rv);
                errno=EIO;
                UNLOCK
                return EIO;
            }
            UNLOCK
            return 0;
        }

        scratch_len=(size_t)block_count*(size_t)bs;
        scratch=(BYTE *)malloc(scratch_len);
        if(scratch==NULL)
        {
            ReportMessage("%s: unable to allocate %u byte device buffer.\n",
                          __FUNCTION__,(unsigned int)scratch_len);
            errno=ENOMEM;
            UNLOCK
            return ENOMEM;
        }

        rv=readblocks(d1,first_block,scratch,block_count);
        if(rv!=block_count)
        {
            ReportMessage("%s: multi-block read failed: %s block %d count %d rv=%d.\n",
                          __FUNCTION__,path,first_block,block_count,rv);
            free(scratch);
            errno=EIO;
            UNLOCK
            return EIO;
        }
        memcpy(buf,scratch+byte_offset,(size_t)count);
        free(scratch);
        UNLOCK
        return 0;
    }

    rv=jtmfs_ReadFile(GetCurrentDNR(),path,GetCurrentDB(),
                      (BYTE *)buf,0,count,offset);
    if(rv!=count)
    {
        ReportMessage("%s: JTMFS short/error read '%s' offset=%d want=%d rv=%d.\n",
                      __FUNCTION__,path,offset,count,rv);
        errno=EIO;
        UNLOCK
        return EIO;
    }

    UNLOCK
    return 0;
}

// Write specified part to a file
// par1 = fname
// par2 = data buffer
// v1 = amount to write in bytes
// v2 = write offset
int writefile(const char *path,char *buf,int offset,int count)
{
    int key1,pr,i,i2,i3,i4,devnr,d1;
    int bs, first_block, byte_offset, block_count, dev_blocks;
    int rv, old_size, original_size, exact_size, resize_rv;
    unsigned long span;
    size_t scratch_len;
    BYTE *scratch = NULL;

    LOCK

    if(count >= (1024*1024*1) || count <= 0 || offset < 0 || buf == NULL)
    {
        ReportMessage("%s: illegal offset/size offset=%d size=%d\n",
                      __FUNCTION__, offset, count);
        errno = EINVAL;
        UNLOCK
        return EINVAL;
    }

    if(!path || !isValidString(path) || !strlen(path))
    {
        errno = EINVAL;
        UNLOCK
        return EINVAL;
    }

    if( (d1=driver_getdevicenrbyname(path))!=-1 )
    {
        bs = getblocksize(d1);
        dev_blocks = getsize(d1);
        if(bs <= 0 || dev_blocks <= 0)
        {
            ReportMessage("%s: device '%s' has invalid geometry.\n",
                          __FUNCTION__, path);
            errno = EIO;
            UNLOCK
            return EIO;
        }

        first_block = offset / bs;
        byte_offset = offset % bs;
        span = (unsigned long)byte_offset + (unsigned long)count;
        block_count = (int)((span + (unsigned long)bs - 1UL) /
                            (unsigned long)bs);

        if(first_block < 0 || block_count <= 0 ||
           first_block >= dev_blocks ||
           block_count > (dev_blocks - first_block))
        {
            ReportMessage("%s: device write outside '%s': block=%d count=%d size=%d.\n",
                          __FUNCTION__, path, first_block, block_count, dev_blocks);
            errno = EFBIG;
            UNLOCK
            return EFBIG;
        }

        /* Fast path: aligned whole-block writes need neither a read/modify/write
         * buffer nor one command per block. */
        if(byte_offset==0 && count==block_count*bs)
        {
            if(writeblocks(d1,first_block,(BYTE *)buf,block_count)!=block_count)
            {
                ReportMessage("%s: multi-block write failed: %s block %d count %d.\n",
                              __FUNCTION__,path,first_block,block_count);
                errno=EIO;
                UNLOCK
                return EIO;
            }
            UNLOCK
            return 0;
        }

        scratch_len = (size_t)block_count * (size_t)bs;
        scratch = (BYTE *)malloc(scratch_len);
        if(scratch == NULL)
        {
            ReportMessage("%s: unable to allocate %u byte device buffer.\n",
                          __FUNCTION__, (unsigned int)scratch_len);
            errno = ENOMEM;
            UNLOCK
            return ENOMEM;
        }

        if(readblocks(d1,first_block,scratch,block_count)!=block_count)
        {
            ReportMessage("%s: multi-block pre-read failed: %s block %d count %d.\n",
                          __FUNCTION__,path,first_block,block_count);
            free(scratch);
            errno=EIO;
            UNLOCK
            return EIO;
        }

        memcpy(scratch+byte_offset, buf, (size_t)count);

        if(writeblocks(d1,first_block,scratch,block_count)!=block_count)
        {
            ReportMessage("%s: multi-block write failed: %s block %d count %d.\n",
                          __FUNCTION__,path,first_block,block_count);
            free(scratch);
            errno=EIO;
            UNLOCK
            return EIO;
        }

        free(scratch);
        UNLOCK
        return 0;
    }

    devnr = GetCurrentDNR();
    old_size = jtmfs_GetFileSize(devnr, path, GetCurrentDB());
    if(old_size < 0) old_size = 0;
    original_size = old_size;

    dprintk("%s: '%s', dnr=%d, db=%d, len=%d offset=%d\n",
            __FUNCTION__, path, devnr, GetCurrentDB(), count, offset);

    /* A true seek-created hole must read as zero.  Grow only to the write
     * offset before writing; the written range itself is committed below
     * without truncate-style zeroing. */
    if(offset > old_size) {
        resize_rv=jtmfs_SetSize(devnr,path,offset,GetCurrentDB());
        if(resize_rv != 0) {
            errno=(resize_rv==2)?ENOSPC:EIO;
            UNLOCK
            return errno;
        }
        old_size=offset;
    }

    rv = jtmfs_WriteFile(devnr, path, GetCurrentDB(), (BYTE *)buf,
                         0, count, offset);
    if(rv != 0)
    {
        ReportMessage("%s: JTMFS write failed for '%s' (rv=%d).\n",
                      __FUNCTION__, path, rv);
        jtmfs_rollback_failed_write_growth(devnr,path,GetCurrentDB(),
                                           original_size,"data write");
        errno = (rv == 2) ? ENOSPC : ((rv == 1) ? ENOENT : EIO);
        UNLOCK
        return errno;
    }

    exact_size = offset + count;
    if(old_size > exact_size) exact_size = old_size;
    if(exact_size > old_size &&
       jtmfs_SetSizeAfterWrite(devnr,path,exact_size,GetCurrentDB()) != 0)
    {
        ReportMessage("%s: data written but exact EOF commit failed for '%s'.\n",
                      __FUNCTION__, path);
        jtmfs_rollback_failed_write_growth(devnr,path,GetCurrentDB(),
                                           original_size,"EOF commit");
        errno = EIO;
        UNLOCK
        return EIO;
    }

    UNLOCK
    return 0;
}

//
int getfilesize(const char *path)
{
	// ----------------------------------------------------
	int key1,pr,i,i2,i3,i4,devnr,d1,sz;
	
	LOCK


	// Validate string
	if(!isValidString(path))
	{
		//
		UNLOCK
		// Invalid string
		return 0;
	}

	//--------------------------------------------------------
	// Is it a device?
	if( (d1=driver_getdevicenrbyname(path))!=-1 )
	{
		// Get device size in bytes and set it as return value
		sz = getblocksize(d1)*getsize(d1);
		UNLOCK
		return sz;
	}

	//--------------------------------------------------------
	// Check path
	if( path && isValidString(path) && strlen(path) )
	{
		// Get file size and set it as return value
		sz = 
			jtmfs_GetFileSize(
			GetCurrentDNR(), path,
				GetCurrentDB());
		UNLOCK
		return sz;
	}
	else
	{
		//
		dprintk("%s: Defective file name\n", __FUNCTION__);
		UNLOCK
		return 0;
	}

	//
	UNLOCK
	return 1;
}

//
int addfileblocks(const char *path, int count)
{
	//
	int key1,pr,i,i2,i3,i4;

	LOCK

	// Check path
	if( path && isValidString(path) && strlen(path) )
	{
		dprintk("jtmfs_AddBlocks(devnr=%d, '%s'(0x%x), 0, count=%d);\n",
			GetCurrentDNR(), path, path, count);
		jtmfs_AddBlocks(
		GetCurrentDNR(), path, GetCurrentDB(), count);
		UNLOCK
		return 1;
	}
	else
	{
		dprintk("%s: error par1==NULL\n", __FUNCTION__);
		UNLOCK
		return 0;
	}

	//
}

//
int setsize(const char *path, int newsize)
{
	int key1,pr,i,i2,i3,i4,dnr,db;

	LOCK

	// Check path
	if( path && isValidString(path) && strlen(path) )
	{
		dnr = GetCurrentDNR();
		db = GetCurrentDB();
		ReportMessage("jtmfs_SetSize(devnr=%d, '%s'(0x%x), 0, size=%d);\n",
			dnr, path,path, newsize);
		{
			int resize_rv=jtmfs_SetSize(dnr, path, newsize, db);
			UNLOCK
			return resize_rv;
		}
	}
	else
	{
		dprintk("%s: error par1==NULL\n", __FUNCTION__);
		UNLOCK
		return 1;
	}

	//
}

// Check file existance and return it's type.
// -1/0: Not found.
// 1: File.
// 2: Directory.
// Other values: Unknown.
int exist(const char *path)
{
	LOCK

	//
	if( path && isValidString(path) && strlen(path) )
	{
		// v4 will contain the return value.
		UNLOCK
		return
			jtmfs_Fexist(GetCurrentDNR(), path, GetCurrentDB());
	//	printk("%s: Returns %d on '%s'(len=%d)-\n",
	//	__FUNCTION__, p->v4, p->par1, strlen(p->par1));
	}
	else
	{
		printk("%s: Malformed request.\n", __FUNCTION__);
		UNLOCK
		return 0;
	}

	//
}

// Start a directory search
int findfirst(const char *path, void *ffblk)
{
	int fd;
	
	LOCK

	// const char *path,	FFBLK *
	// (par1)		(par2)
	dprintk("%s: path(par1)='%s', par2=%x\n",
			__FUNCTION__, path, ffblk);
	// Do findfirst
	fd = jtmfs_findfirst(GetCurrentDNR(), GetCurrentDB(), path, ffblk);
	/* Only a successful directory search owns a real descriptor. */
	if(fd > 2)
		changeFDOwner(fd, GetCurrentThread());
	
	UNLOCK
	//
	return fd;
}

// Continue directory search
int findnext(int fd, void *ffblk)
{
	int i;

	LOCK

	// int fd,	FFBLK *
	// (v1)		(par1)
	i =
		jtmfs_findnext(GetCurrentDNR(), GetCurrentDB(), fd, ffblk);
	UNLOCK
	return i;
}

// Get file data block number
int getfiledatablock(const char *path)
{
	int i;

	LOCK

	//
	i = 
		jtmfs_GetFileDataBlock(GetCurrentDNR(), GetCurrentDB(), path);
	UNLOCK
	return i;
}

// Create directory
int createdirectory(const char *path)
{
	int rv;

	if(path==NULL || !isValidString(path) || !strlen(path))
		return 5;

	LOCK
	rv=jtmfs_CreateDirectory(GetCurrentDNR(), GetCurrentDB(), path);
	UNLOCK

	/* JTMFS convention: zero means success, non-zero is an error.
	 * Preserve that convention so kernel callers can detect failures. */
	return rv;
}

// Format a drive(multitasking safe)
int formatdrive(int dnr)
{
	int r;

	if(!isValidDevice(dnr))
		return 10;

	LOCK
	r = jtmfs_formatdrive(dnr);
	UNLOCK
	return r;
}

// Change directory
int changedirectory(const char *path)
{
	// ----------------------------------------------------
	int key1,pr,i,i2,i3,i4,devnr,r;
	
	LOCK

	// Check path
	if( path!=NULL && isValidString(path) && strlen(path) )
	{
		// Change to specified directory
		r = jtmfs_chdir(path);
	}
	else
	{
		// Arguments were bad
		r=1;
	}
	
	//
	UNLOCK

	// Give out a return value.
	return r;
}

// Checks whether if specified drive is ready for writing/reading,
// in other words that the drive is healthy and properly formatted.
int isdriveready(int dnr)
{
	int rv;
	LOCK

	// Set return value
	rv=jtmfs_isDriveReady(dnr);
	
	//
	UNLOCK

	//
	return rv;
}

// Get current work directory.
int getcwd(char *path, int max_len)
{
	int i;
	
	LOCK

	// Set return value
	i = jtmfs_GetCWD(path, max_len);
	
	//
	UNLOCK
	return i;
}

// THE OPEN FUNCTION 
//
int open(const char *pathname, int flags)
{
    FILEDES *f;
    RESOLVE resolved;
    int dnr, db, kind, rv, access_mode, raw_dev, resolved_dnr, resolved_db;

    /* Validate before the pseudo-VFS path parser dereferences pathname. */
    if(pathname == NULL || !isValidString(pathname) || !strlen(pathname))
    {
        errno = EINVAL;
        return -1;
    }

    rv = LinuxVfsOpen(pathname, flags);
    if(rv != JTMOS_VFS_NOT_HANDLED)
    {
        if(rv < 0) { errno = -rv; return -1; }
        return rv;
    }

    LOCK

    if(pathname == NULL || !isValidString(pathname) || !strlen(pathname))
    {
        errno = EINVAL;
        UNLOCK
        return -1;
    }

    dnr = GetCurrentDNR();
    db = GetCurrentDB();
    access_mode = flags & O_ACCMODE;
    raw_dev = driver_getdevicenrbyname(pathname);
    resolved_dnr = dnr;
    resolved_db = db;
    memset(&resolved,0,sizeof(resolved));

    if(raw_dev == -1)
    {
        kind = jtmfs_Fexist(dnr, pathname, db);

        if((flags & O_CREAT) && (flags & O_EXCL) && kind > 0)
        {
            errno = EEXIST;
            UNLOCK
            return -1;
        }

        if(kind <= 0)
        {
            if(!(flags & O_CREAT))
            {
                errno = ENOENT;
                UNLOCK
                return -1;
            }

            rv = jtmfs_CreateFile(dnr, db, pathname, 0);
            if(rv != 0)
            {
                ReportMessage("open: unable to create '%s' (rv=%d).\n",
                              pathname, rv);
                errno = (rv == 10) ? ENOSPC : EIO;
                UNLOCK
                return -1;
            }
            kind = 1;
        }

        if(kind == 2 && access_mode != O_RDONLY)
        {
            errno = EISDIR;
            UNLOCK
            return -1;
        }

        if((flags & O_TRUNC) && access_mode != O_RDONLY && kind == 1)
        {
            rv = jtmfs_SetSize(dnr, pathname, 0, db);
            if(rv != 0)
            {
                errno = EIO;
                UNLOCK
                return -1;
            }
        }

        /* Persist the resolved parent location in the descriptor.  This is
         * important for device-qualified paths such as hda:/file: close() and
         * syncfs() must flush the device that actually owns the file, not the
         * process CWD device that happened to be active at open time. */
        if(resolveFileNamePath(pathname,&resolved_dnr,&resolved_db,&resolved)!=0)
        {
            errno = EIO;
            UNLOCK
            return -1;
        }
    }
    else
    {
        resolved_dnr = raw_dev;
        resolved_db = 0;
    }

    f = NewFD();
    if(f == NULL || f->fd <= 0)
    {
        errno = EMFILE;
        UNLOCK
        return -1;
    }

    memset(f->name, 0, sizeof(f->name));
    /* A descriptor is bound to its resolved parent (dnr/db).  Store only the
     * final component so later read/write/lseek never re-resolve a relative
     * pathname against a possibly different process CWD. */
    if(raw_dev==-1) strncpy(f->name, resolved.name, sizeof(f->name)-1);
    else strncpy(f->name, pathname, sizeof(f->name)-1);
    f->flags = flags;
    f->written = FALSE;
    f->max_offset_peek = 0;
    f->dnr = resolved_dnr;
    f->db = resolved_db;

    if(flags & O_APPEND)
    {
        if(driver_getdevicenrbyname(pathname) != -1)
            f->offset = getfilesize(pathname);
        else
        {
            rv = jtmfs_GetFileSize(resolved_dnr, resolved.name, resolved_db);
            f->offset = rv > 0 ? rv : 0;
        }
    }
    else
        f->offset = 0;

    UNLOCK
    return f->fd;
}

//
int creat(const char *pathname, int flags)
{
    (void)flags;
    return open(pathname, O_WRONLY | O_CREAT | O_TRUNC);
}

//
int close(int fd)
{
    FILEDES *f;
    int written,dnr,flags,flush_rv,vr,is_hda;
    char devname[32];

    vr=LinuxVfsClose(fd);
    if(vr != JTMOS_VFS_NOT_HANDLED)
    {
        if(vr < 0) { errno=-vr; return -1; }
        return vr;
    }

    written=0;
    dnr=-1;
    flags=0;
    flush_rv=0;

    /* Capture the owning device and retire the descriptor under one LOCK
     * declaration.  The JTMOS LOCK macro carries per-function state and must
     * not be expanded twice in the same function. */
    LOCK
    f=get_filedesptr(fd);
    if(f==NULL)
    {
        errno=EBADF;
        UNLOCK
        return -1;
    }
    written=f->written;
    dnr=f->dnr;
    flags=f->flags;
    if(FreeFD(fd)!=0)
    {
        UNLOCK
        errno=EBADF;
        return -1;
    }
    UNLOCK

    /* V67.8.56.10 durability rule: a completed write to hda: is stable when
     * the descriptor is closed.  This drains, in order, DIRDB metadata, FAT
     * pages, the generic DAPI write-back cache and finally ATA FLUSH CACHE. */
    is_hda=0;
    memset(devname,0,sizeof(devname));
    if(isValidDevice(dnr) && driver_getdevicename(dnr,devname)!=NULL &&
       devname[0]=='h' && devname[1]=='d' && devname[2]=='a')
        is_hda=1;
    if((written || (flags & (O_CREAT|O_TRUNC))) && is_hda &&
       !(flags & O_JTMOS_BATCH) &&
       isValidDevice(dnr) && jtmfs_isDriveReady(dnr))
        flush_rv=syncdev(dnr);

    return flush_rv;
}

//
int read(int fd, void *buf, int count)
{
    FILEDES *f;
    int size,want,rv,raw,vr;
    if(count<0 || (count>0 && buf==NULL)) { errno=EINVAL; return -1; }
    vr=LinuxVfsRead(fd,buf,count);
    if(vr != JTMOS_VFS_NOT_HANDLED)
    {
        if(vr < 0) { errno=-vr; return -1; }
        return vr;
    }
    LOCK
    if(count<0 || buf==NULL || !isValidFD(fd)) { errno=EBADF; UNLOCK return -1; }
    if(count==0) { UNLOCK return 0; }
    f=get_filedesptr(fd); if(f==NULL) { errno=EBADF; UNLOCK return -1; }
    if((f->flags&O_ACCMODE)==O_WRONLY) { errno=EBADF; UNLOCK return -1; }
    raw=driver_getdevicenrbyname(f->name);
    if(raw!=-1)
    {
        int bs=getblocksize(raw);
        int blocks=getsize(raw);
        unsigned long raw_bytes;
        if(bs<=0 || blocks<=0) { errno=EIO; UNLOCK return -1; }
        raw_bytes=(unsigned long)(unsigned)bs*(unsigned long)(unsigned)blocks;
        if((unsigned long)(unsigned)f->offset>=raw_bytes) { UNLOCK return 0; }
        want=count;
        if((unsigned long)(unsigned)want>raw_bytes-(unsigned long)(unsigned)f->offset)
            want=(int)(raw_bytes-(unsigned long)(unsigned)f->offset);
        rv=readfile(f->name,(char *)buf,f->offset,want);
        if(rv!=0) { if(errno==0) errno=EIO; UNLOCK return -1; }
        f->offset+=want;
        if(f->offset>f->max_offset_peek) f->max_offset_peek=f->offset;
        UNLOCK return want;
    }
    size=jtmfs_GetFileSize(f->dnr,f->name,f->db);
    if(size<0) { errno=EIO; UNLOCK return -1; }
    if(f->offset>=size) { UNLOCK return 0; }
    want=count; if(want>size-f->offset) want=size-f->offset;
    rv=jtmfs_ReadFile(f->dnr,f->name,f->db,(BYTE *)buf,0,want,f->offset);
    if(rv!=want) { errno=EIO; UNLOCK return -1; }
    f->offset+=rv;
    if(f->offset>f->max_offset_peek) f->max_offset_peek=f->offset;
    UNLOCK return rv;
}

//
int write(int fd, const void *buf, int count)
{
    FILEDES *f;
    int rv,access_mode,old_size,original_size,exact_size,raw,vr;
    if(count<0 || (count>0 && buf==NULL)) { errno=EINVAL; return -1; }
    vr=LinuxVfsWrite(fd,buf,count);
    if(vr != JTMOS_VFS_NOT_HANDLED)
    {
        if(vr < 0) { errno=-vr; return -1; }
        return vr;
    }
    LOCK
    if(count<0 || buf==NULL || !isValidFD(fd)) { errno=EBADF; UNLOCK return -1; }
    if(count==0) { UNLOCK return 0; }
    f=get_filedesptr(fd); if(f==NULL) { errno=EBADF; UNLOCK return -1; }
    access_mode=f->flags&O_ACCMODE;
    if(access_mode==O_RDONLY) { errno=EBADF; UNLOCK return -1; }
    raw=driver_getdevicenrbyname(f->name);
    if(raw!=-1)
    {
        rv=writefile(f->name,(char *)buf,f->offset,count);
        if(rv!=0) { if(errno==0) errno=EIO; UNLOCK return -1; }
    }
    else
    {
        if(f->flags&O_APPEND)
        {
            rv=jtmfs_GetFileSize(f->dnr,f->name,f->db);
            f->offset=rv>0 ? rv : 0;
        }
        old_size=jtmfs_GetFileSize(f->dnr,f->name,f->db);
        if(old_size<0) old_size=0;
        original_size=old_size;
        if(f->offset>old_size) {
            rv=jtmfs_SetSize(f->dnr,f->name,f->offset,f->db);
            if(rv!=0)
            { errno=(rv==2)?ENOSPC:EIO; UNLOCK return -1; }
            old_size=f->offset;
        }
        rv=jtmfs_WriteFile(f->dnr,f->name,f->db,(BYTE *)buf,0,count,f->offset);
        if(rv!=0) {
            jtmfs_rollback_failed_write_growth(f->dnr,f->name,f->db,
                                               original_size,"POSIX write");
            errno=(rv==2)?ENOSPC:EIO;
            UNLOCK return -1;
        }
        exact_size=f->offset+count; if(old_size>exact_size) exact_size=old_size;
        if(exact_size>old_size &&
           jtmfs_SetSizeAfterWrite(f->dnr,f->name,exact_size,f->db)!=0)
        {
            jtmfs_rollback_failed_write_growth(f->dnr,f->name,f->db,
                                               original_size,"POSIX EOF commit");
            errno=EIO;
            UNLOCK return -1;
        }
    }
    f->offset+=count; f->written=TRUE;
    if(f->offset>f->max_offset_peek) f->max_offset_peek=f->offset;
    UNLOCK return count;
}

//
int lseek(int fd, int offset, int whence)
{
	FILEDES *f;
	int new_offset,vr;

	vr=LinuxVfsLseek(fd,offset,whence);
	if(vr != JTMOS_VFS_NOT_HANDLED)
	{
		if(vr < 0) { errno=-vr; return -1; }
		return vr;
	}

	LOCK
	f = get_filedesptr(fd);
	if(!f) { UNLOCK return -1; }

	if(whence==SEEK_SET)
		new_offset = offset;
	else if(whence==SEEK_CUR)
		new_offset = f->offset + offset;
	else if(whence==SEEK_END)
	{
		int raw=driver_getdevicenrbyname(f->name);
		int endpos=(raw!=-1) ? getfilesize(f->name) : jtmfs_GetFileSize(f->dnr,f->name,f->db);
		new_offset=endpos+offset;
	}
	else
	{
		UNLOCK
		return -1;
	}

	if(new_offset < 0)
	{
		errno=EINVAL;
		UNLOCK
		return -1;
	}
	f->offset = new_offset;
	UNLOCK
	return new_offset;
}

//
int readdir(unsigned int fd, void *dirp,
          unsigned int count)
{
	LOCK
	// TODO!!
	UNLOCK
	return 0;
}

//
int mkdir(const char *pathname, int mode)
{
	int rv;

	(void)mode;
	rv=createdirectory(pathname);
	if(rv==0) return 0;
	errno=(rv==10)?ENOSPC:EIO;
	return -1;
}

//
int rmdir(const char *pathname)
{
	//
	LOCK
	//
	UNLOCK
	//
	return 0;
}

//
int unlink(const char *pathname)
{
	int i;
	
	LOCK

	//
	i = deletefile(pathname);

	//
	UNLOCK
	return i;
}

//
int chdir(const char *pathname)
{
	int i;

	LOCK
	i = jtmfs_chdir(pathname);
	UNLOCK
	return i;
}

//
int mkfs(const char *path)
{
	int dnr, len;
	char devname[32];

	if(path==NULL || !isValidString(path) || !strlen(path))
		return 10;

	len=(int)strlen(path);
	if(len<=0 || len>=(int)sizeof(devname))
		return 10;
	strcpy(devname, path);
	if(len>0 && devname[len-1]==':')
		devname[len-1]=0;

	dnr = driver_getdevicenrbyname(devname);
	if(!isValidDevice(dnr))
		return 10;

	/* Never destroy a filesystem that still has live namespace/process/file
	 * references.  This is the JTMOS equivalent of EBUSY. */
	if(jtmfs_device_busy(dnr))
		return 16;

	/* A prior SMSH umount closes the driver's I/O gate.  Re-open it for the
	 * formatter; formatting itself invalidates/rebuilds the filesystem caches.
	 * Never continue after a failed mount: doing so used to hide partition
	 * driver protocol bugs behind a later, misleading mkfs failure. */
	{
		int r;
		r=mountDNR(dnr);
		if(r)
			return 19;

		/* formatdrive() owns the filesystem lock.  Do not nest LOCK here. */
		r = formatdrive(dnr);
		if(r)
			return r;

		/* V63 install policy: mkfs hda is a complete boot-disk install when
		 * JTMOS itself was booted from A: or B:.  jtmfat_createfat() has
		 * already copied/patched the current floppy loader into the reserved
		 * HDD boot area; now copy and verify its matching 1 MiB boot payload.
		 * Default boot32pm stores kernel32.bin.nz here; legacy boot32 stores raw
		 * kernel32.bin.  CopyKernel preserves the RAW-kernel checksum contract.
		 * rootinstall remains available as an explicit repair/reinstall tool. */
		if(!strcmp(devname, "hda"))
		{
			const char *source;
			int biosboot;

			biosboot=GetBiosBootDrive();
			if(biosboot==0)
				source="floppy";
			else if(biosboot==1)
				source="floppy2";
			else
				return 17; /* filesystem exists, but no boot-floppy source */

			if(!isValidDevice(driver_getdevicenrbyname(source)))
				return 17;

			r=CopyKernel(source, devname);
			if(r)
				return 18; /* formatted, boot/kernel installation incomplete */
		}

		return 0;
	}
}


//
int syncdev(int dnr)
{
    int err=0;

    if(!isValidDevice(dnr) || !jtmfs_isDriveReady(dnr))
        return -1;

    LOCK
    /* Ordering is intentional: directory entries can point at newly allocated
     * chains, so metadata reaches the DAPI cache before FAT pages are drained. */
    if(dirdbFlushDNR(dnr)!=0)
        err=1;
    if(flexActive && flexFlushFATChecked(dnr)!=0)
        err=1;
    UNLOCK

    /* Filesystem writeback above feeds the generic block cache.  The device
     * flush then drains DAPI and issues the driver's hardware flush (ATA E7
     * for hda), so success means the metadata is no longer RAM-only. */
    if(driver_FlushDrive(dnr)!=0)
        err=1;
    return err ? -1 : 0;
}

int sync(void)
{
    int i,err=0;

    /* Flush each active JTMFS device all the way to its block driver. */
    for(i=0;i<N_MAX_FATS;i++)
    {
        if(!isValidDevice(i) || !jtmfs_isDriveReady(i))
            continue;
        if(syncdev(i)!=0)
            err=1;
    }
    return err ? -1 : 0;
}


//
int syncfs(int fd)
{
    FILEDES *f;
    int dnr;

    LOCK
    f=get_filedesptr(fd);
    if(f==NULL)
    {
        UNLOCK
        errno=EBADF;
        return -1;
    }
    dnr=f->dnr;
    UNLOCK
    return syncdev(dnr);
}

