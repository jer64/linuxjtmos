//======================================================
// EDCDS DATABASE WALKING FUNCTIONS
// (C) 2002-2005 by Jari Tuominen(jari@vunet.org).
//======================================================
#include "kernel32.h"
#include "dirdb.h"
#include "dirdbAccess.h"
#include "dirdbWalk.h"
#include "dirdbFind.h"

// Search for a regular file or directory.
int dirdb_ffindfile(int dnr,
                const char *fname, int db, DIRWALK *dw)
{
	DEBUGFUNC
	//
	return dirdb_ffindfileEx(dnr, fname, db, dw, 0);
}

/*
 * Read only the logical file length without using a shared DIRWALK.
 *
 * DIRWALK contains a 16 KiB scratch buffer, which historically encouraged
 * jtmfs_getfilesize() to keep one static instance.  That static object is
 * unsafe in a preemptive kernel: another task can overwrite dw.fe between
 * lookup and the length read, producing a size for an unrelated file.
 *
 * touchDir() may perform I/O, so do it before disabling interrupts.  Once the
 * cache entry exists, scan its in-memory fixed records atomically on the
 * current single-CPU kernel.  SMP will replace this short critical section
 * with the DirDB spinlock.
 */
int dirdb_GetFileLength(int dnr, const char *fname, int db)
{
    DIR *dir;
    BYTE *p,*end;
    JTMFS_FILE_ENTRY *fe;
    int flags;
    int length;

    if(fname==NULL || !isValidDevice(dnr)) return -1;
    /* Ensure the directory is resident before entering the short IRQ-off
     * section.  touchDir() may perform media I/O and must remain preemptible. */
    dir=touchDir(dnr,db,DIRDB_KIND_DIRECTORY);
    if(dir==NULL) return -1;

    length=-1;
    flags=get_eflags();
    disable();
    /* Re-acquire the cache pointer after preemption has been disabled.  The
     * first pointer could have been evicted between touchDir() and cli. */
    dir=dbGiveDir(dnr,db,DIRDB_KIND_DIRECTORY);
    if(dir==NULL || dir->buf==NULL ||
       dir->l_buf<(int)sizeof(JTMFS_FILE_ENTRY))
    {
        set_eflags(flags);
        return -1;
    }
    end=dir->buf+dir->l_buf;
    for(p=dir->buf; p+sizeof(JTMFS_FILE_ENTRY)<=end;
        p+=sizeof(JTMFS_FILE_ENTRY))
    {
        fe=(JTMFS_FILE_ENTRY*)p;
        if(fe->name[0]==0) break;
        if(fe->magicNumber!=0xFCE2E37B) break;
        if(JTMFS_TYPE_IS_DIRNAME(fe->type) || fe->length==-1) continue;
        if(strcmp(fe->name,fname)==0)
        {
            length=fe->length;
            break;
        }
    }
    set_eflags(flags);
    return length;
}

// Search for a deleted file entry.
int dirdb_ffindghostfile(int dnr,
                const char *fname, int db, DIRWALK *dw)
{
	//
	DEBUGFUNC	
	return dirdb_ffindfileEx(dnr, fname, db, dw, 1);
}

// Search for directory name definition,
// which indicates directory name.
// (parameter fname is ignored, use NULL) DIRWALK *dw
int dirdb_ffinddirname(int dnr, const char *name, int db, DIRWALK *dw)
{
	//
	DEBUGFUNC
	return dirdb_ffindfileEx(dnr, NULL, db, dw, 2);
}

// Search for a specified file or directory.
// ghost=0 means: Search for non-deleted files only.
// ghost=1 means: Search for deleted files only.
// ghost=2 means: Search for directory names only.
// Return value: zero if not found...
int dirdb_ffindfileEx(int dnr,
                const char *fname, int db, DIRWALK *dw,
		int ghost)
{
	BYTE *p,*end;
	DIR *dir;
	int index;
	JTMFS_FILE_ENTRY *fe;

	DEBUGFUNC

	if(ghost<0 || ghost>2)
		return 0;
	if(ghost!=2 && fname==NULL)
		return 0;

	dir = touchDir(dnr, db, DIRDB_KIND_DIRECTORY);
	if(dir==NULL || dir->buf==NULL ||
	   dir->l_buf<(int)sizeof(JTMFS_FILE_ENTRY))
		return 0;

	end=dir->buf+dir->l_buf;
	for(index=0,p=dir->buf;
	    p+sizeof(JTMFS_FILE_ENTRY)<=end;
	    index++,p+=sizeof(JTMFS_FILE_ENTRY))
	{
		fe=(JTMFS_FILE_ENTRY*)p;
		if(fe->name[0]==0)
			return 0;
		if(fe->magicNumber!=0xFCE2E37B)
		{
			printk("dirdb_ffindfileEx: corrupt directory DNR=%d DB=%d entry=%d.\n",
			       dnr,db,index);
			return 0;
		}

		if(ghost==2)
		{
			if(!JTMFS_TYPE_IS_DIRNAME(fe->type))
				continue;
		}
		else
		{
			if(strcmp(fe->name,fname))
				continue;
			if(JTMFS_TYPE_IS_DIRNAME(fe->type))
				continue;
			if(ghost==1)
			{
				if(fe->length!=-1) continue;
			}
			else if(fe->length==-1)
				continue;
		}

		if(dw!=NULL)
		{
			memset(dw,0,sizeof(DIRWALK));
			dw->d=dir;
			dw->fe=fe;
			dw->start_block=db;
			dw->current_block=db;
			dw->device_nr=dnr;
			dw->db=db;
			dw->current_offset=(int)(p-dir->buf);
			dw->entry=index;
			dw->isWalking=1;
			dw->buf_length=8192;
		}
		dprintk("<<%s!>>",fe->name);
		return 1;
	}

	/* No terminating empty entry inside the cache is corruption. */
	printk("dirdb_ffindfileEx: unterminated directory DNR=%d DB=%d; lookup refused.\n",
	       dnr,db);
	return 0;
}


// Figure out what is the name of the directory at specified location.
// Return value: FALSE if not found, TRUE if found.
int dirdb_GetDirName(int dnr,int db, char *dest_name)
{
	BYTE *p,*end;
	DIR *dir;
	JTMFS_FILE_ENTRY *fe;

	DEBUGFUNC
	if(dest_name==NULL) return FALSE;

	dir=touchDir(dnr,db,DIRDB_KIND_DIRECTORY);
	if(dir==NULL || dir->buf==NULL ||
	   dir->l_buf<(int)sizeof(JTMFS_FILE_ENTRY))
		return FALSE;

	end=dir->buf+dir->l_buf;
	for(p=dir->buf;
	    p+sizeof(JTMFS_FILE_ENTRY)<=end;
	    p+=sizeof(JTMFS_FILE_ENTRY))
	{
		fe=(JTMFS_FILE_ENTRY*)p;
		if(fe->name[0]==0)
			return FALSE;
		if(fe->magicNumber!=0xFCE2E37B)
		{
			printk("dirdb_GetDirName: corrupt directory DNR=%d DB=%d.\n",dnr,db);
			return FALSE;
		}
		if(JTMFS_TYPE_IS_DIRNAME(fe->type))
		{
			strcpy(dest_name,fe->name);
			return TRUE;
		}
	}
	printk("dirdb_GetDirName: unterminated directory DNR=%d DB=%d.\n",dnr,db);
	return FALSE;
}

