// ------------------------------------------------------------------
// flexFat.c - Flexible FAT system.
// (C) 2002-2005 by Jari Tuominen.
// V46: demand-paged FAT sector cache (2026).
// ------------------------------------------------------------------
#include "kernel32.h"
#include "jtmfs.h"
#include "jtmfat.h"
#include "flexFat.h"
#include "flexCorruption.h"
#include "diskspace.h"

char flextmp[256];
FLEFATSYS *fle;
int flexActive=FALSE;

/* ------------------------------------------------------------------
 * Internal paged-cache helpers
 * ------------------------------------------------------------------ */
static BYTE *flexSlotPtr(FLEFAT *f, int slot)
{
    return f->buf + (slot * f->bs);
}

static int flexCountDirty(FLEFAT *f)
{
    int i, n;

    for(i=0,n=0; i<f->cache_slots; i++)
        if(f->writemap[i]) n++;
    return n;
}

/* Sort resident dirty FAT pages by physical FAT-sector number.  The cache
 * slots themselves are LRU-ordered and therefore not normally contiguous in
 * memory.  A sorted slot list lets flush turn adjacent FAT pages back into
 * one multi-sector device request. */
static int flexCollectDirtySlots(FLEFAT *f, int *order, int maxslots)
{
    int i,j,n,slot;

    if(f==NULL || order==NULL || maxslots<=0) return 0;
    n=0;
    for(i=0;i<f->cache_slots && n<maxslots;i++)
        if(f->writemap[i] && f->cache_page[i]!=FLEXFAT_INVALID_PAGE)
            order[n++]=i;

    for(i=1;i<n;i++)
    {
        slot=order[i];
        j=i-1;
        while(j>=0 && f->cache_page[order[j]]>f->cache_page[slot])
        {
            order[j+1]=order[j];
            j--;
        }
        order[j+1]=slot;
    }
    return n;
}

static void flexResetCacheMetadata(FLEFAT *f)
{
    int i;

    if(f==NULL) return;

    if(f->buf && f->l_buf>0)
        memset(f->buf, 0, f->l_buf);
    if(f->writemap && f->l_writemap>0)
        memset(f->writemap, 0, f->l_writemap);

    if(f->cache_page)
        for(i=0; i<f->cache_slots; i++)
            f->cache_page[i] = FLEXFAT_INVALID_PAGE;
    if(f->cache_age)
        for(i=0; i<f->cache_slots; i++)
            f->cache_age[i] = 0;

    f->cache_clock = 1;
    f->writeBack = 0;
}

/* Return true for the physical ATA disk and its partition aliases. */
static int flexIsHdaDevice(int dnr)
{
    const char *name;
    name=driver_getdevicename(dnr,NULL);
    return name!=NULL && name[0]=='h' && name[1]=='d' && name[2]=='a';
}

/* Write one dirty cache slot back to its on-disk FAT sector.
 *
 * HDA commit rule: a cache hit is NOT a disk commit.  Even this single-page
 * eviction path therefore performs three independent durability checks:
 *   1) enqueue/write through DEVAPI,
 *   2) drain DAPI and issue the ATA FLUSH CACHE command,
 *   3) read the sector back through the direct uncached backend and compare.
 * writemap[] is cleared only after all three stages succeed. */
static int flexFlushSlot(FLEFAT *f, int slot)
{
    int disk_block,bs,i;
    BYTE *verify;

    if(f==NULL || slot<0 || slot>=f->cache_slots)
        return 1;
    if(f->cache_page[slot]==FLEXFAT_INVALID_PAGE)
        return 0;
    if(!f->writemap[slot])
        return 0;

    disk_block = f->bb->fat_offs + f->cache_page[slot];

    if(flexIsHdaDevice(f->dnr))
    {
        bs=getblocksize(f->dnr);
        if(bs<=0) return 1;
        verify=malloc(bs);
        if(verify==NULL) return 1;

        if(writeblock(f->dnr,disk_block,flexSlotPtr(f,slot)))
        {
            printk("FlexFAT: HDA enqueue/write failed FAT sector %d (device %d, block %d).\n",
                   f->cache_page[slot],f->dnr,disk_block);
            free(verify);
            return 1;
        }
        if(driver_FlushDrive(f->dnr)!=0)
        {
            printk("FlexFAT: HDA DAPI/ATA flush failed FAT sector %d (device %d, block %d).\n",
                   f->cache_page[slot],f->dnr,disk_block);
            free(verify);
            return 1;
        }
        if(readblock1(f->dnr,disk_block,verify))
        {
            printk("FlexFAT: HDA physical verify read failed FAT sector %d (device %d, block %d).\n",
                   f->cache_page[slot],f->dnr,disk_block);
            free(verify);
            return 1;
        }
        for(i=0;i<bs;i++)
            if(verify[i]!=flexSlotPtr(f,slot)[i])
            {
                printk("FlexFAT: HDA physical verify mismatch FAT sector %d block %d offset %d.\n",
                       f->cache_page[slot],disk_block,i);
                free(verify);
                return 1;
            }
        free(verify);
        dprintk("FlexFAT: HDA FAT sector %d -> block %d committed (write + ATA flush + readback).\n",
                f->cache_page[slot],disk_block);
    }
    else if(writeblock(f->dnr, disk_block, flexSlotPtr(f, slot)))
    {
        printk("FlexFAT: failed to write FAT sector %d (device %d, block %d).\n",
               f->cache_page[slot], f->dnr, disk_block);
        return 1;
    }

    if(f->bb && jtmfat_infoblock_uses_lazyfat(f->bb) &&
       (DWORD)f->cache_page[slot]==f->lazy_materialized_pages)
    {
        DWORD np=f->lazy_materialized_pages+1UL;
        if(jtmfat_lazyfat_set_materialized_pages(f->dnr,np)!=0) return 1;
        f->lazy_materialized_pages=np;
        if(f->lazy_staged_pages<np) f->lazy_staged_pages=np;
    }

    f->disk_writes++;
    f->writemap[slot] = 0;
    f->writeBack = flexCountDirty(f);
    return 0;
}

/* Find an already cached FAT sector. */
static int flexFindSlot(FLEFAT *f, int fat_sector)
{
    int i;

    for(i=0; i<f->cache_slots; i++)
        if(f->cache_page[i] == fat_sector)
            return i;
    return -1;
}

/* Pick a free slot, otherwise least-recently-used slot. */
static int flexPickSlot(FLEFAT *f)
{
    int i, oldest;
    DWORD age;

    for(i=0; i<f->cache_slots; i++)
        if(f->cache_page[i] == FLEXFAT_INVALID_PAGE)
            return i;

    oldest = 0;
    age = f->cache_age[0];
    for(i=1; i<f->cache_slots; i++)
    {
        if(f->cache_age[i] < age)
        {
            age = f->cache_age[i];
            oldest = i;
        }
    }
    return oldest;
}

/*
 * Return a cache slot containing one FAT sector.
 *
 * If overwrite_whole_sector is TRUE, the old disk contents are not read.
 * This matters a lot during mkfs/FastSetBlocks where complete FAT sectors are
 * initialized to FREE or SYSTEM-RESERVED values.
 */
static int flexGetPage(FLEFAT *f, int fat_sector,
                       int overwrite_whole_sector, int *slot_out)
{
    int slot, disk_block;
    BYTE *p;

    if(f==NULL || slot_out==NULL)
        return 1;
    if(fat_sector<0 || fat_sector>=f->fat_sectors)
        return 1;

    slot = flexFindSlot(f, fat_sector);
    if(slot>=0)
    {
        f->cache_hits++;
        f->cache_age[slot] = ++f->cache_clock;
        *slot_out = slot;
        return 0;
    }

    f->cache_misses++;
    slot = flexPickSlot(f);

    /* Dirty LRU victim must reach disk before reuse.  On HDA, if the cache is
     * full of several dirty FAT pages, drain the whole set at once so the DAPI
     * write-combiner can turn it into contiguous multi-sector transfers. */
    if(f->writemap[slot] && flexIsHdaDevice(f->dnr) && f->writeBack>1)
    {
        if(flexFlushFATChecked(f->dnr)) return 1;
    }
    else if(flexFlushSlot(f, slot))
        return 1;

    p = flexSlotPtr(f, slot);
    if(overwrite_whole_sector)
    {
        /* Also clears unused padding at the end of the final FAT sector. */
        memset(p, 0, f->bs);
    }
    else
    {
        /* V68.143 lazy-zero FAT: sectors beyond the persisted materialized
         * prefix are logically FREE even if an older filesystem left stale
         * bytes in those physical sectors.  Never read that stale tail. */
        if(f->bb && jtmfat_infoblock_uses_lazyfat(f->bb) &&
           (DWORD)fat_sector>=f->lazy_materialized_pages)
        {
            memset(p,0,f->bs);
        }
        else
        {
            disk_block = f->bb->fat_offs + fat_sector;
            if(readblock(f->dnr, disk_block, p))
            {
                printk("FlexFAT: failed to read FAT sector %d (device %d, block %d).\n",
                       fat_sector, f->dnr, disk_block);
                f->cache_page[slot] = FLEXFAT_INVALID_PAGE;
                return 1;
            }
            f->disk_reads++;
        }
    }

    f->cache_page[slot] = fat_sector;
    f->cache_age[slot] = ++f->cache_clock;
    f->writemap[slot] = 0;
    *slot_out = slot;
    return 0;
}

static int flexEntryLocation(FLEFAT *f, int entry,
                             int *fat_sector, int *sector_entry)
{
    if(f==NULL || fat_sector==NULL || sector_entry==NULL)
        return 1;
    if(entry<0 || entry>=f->amount)
        return 1;

    *fat_sector = entry / f->entries_per_sector;
    *sector_entry = entry % f->entries_per_sector;
    return 0;
}

static int flexValueIsValid(FLEFAT *f, DWORD what)
{
    if((what & 0xFFFFFFF0UL) == 0xFFFFFFF0UL)
        return TRUE;
    if(what < f->max_val)
        return TRUE;
    return FALSE;
}

/* ------------------------------------------------------------------ */
void flexHealthCheck(void)
{
    int dnr,i;
    char *walk[]={"hda","ram","*"};

    DEBUGFUNC
    if(!flexActive || fle==NULL) return;

    for(i=0; strcmp(walk[i], "*"); i++)
    {
        dnr = driver_getdevicenrbyname(walk[i]);
        if(dnr>=0 && dnr<N_MAX_FATS)
            AnalyzeFAT(&fle->FAT[dnr]);
    }
}

void flexFatInit(void)
{
    int i;
    FLEFAT *f;

    DEBUGFUNC

    fle=malloc(sizeof(FLEFATSYS));
    if(fle==NULL)
    {
        dprintk("flexFatInit: unable to allocate FAT cache system.\n");
        flexActive=FALSE;
        return;
    }

    memset(fle,0,sizeof(FLEFATSYS));
    for(i=0; i<N_MAX_FATS; i++)
    {
        f = &fle->FAT[i];
        f->isOK = FALSE;
        f->dnr = -1;
        f->bnr = -1;
        flexResetCacheMetadata(f);
    }
    flexActive = TRUE;
}

/* Flush only resident dirty FAT sectors and return a real status.
 *
 * Older callers had to inspect FLEFAT.writeBack after the void flush call.
 * That leaked cache internals into DIRDB and syncdev().  Keep the historical
 * void wrapper, but make new metadata code use the checked API. */
int flexFlushFATChecked(int dnr)
{
    FLEFAT *f;
    int i,j,n,pos,run,first_page,disk_block,bs,bytes,failed;
    int order[FLEXFAT_CACHE_SLOTS];
    BYTE *io,*verify;

    DEBUGFUNC

    if(!isValidDevice(dnr) || dnr<0 || dnr>=N_MAX_FATS ||
       !flexActive || fle==NULL)
        return 1;

    f = &fle->FAT[dnr];
    if(!f->isOK || !f->writeBack)
        return 0;

    n=flexCollectDirtySlots(f,order,FLEXFAT_CACHE_SLOTS);
    if(n<=0)
    {
        f->writeBack=0;
        return 0;
    }

    dprintk("%s: flushing %d dirty FAT cache page(s), DNR=%d\n",
            __FUNCTION__,n,dnr);

    /* HDA/hdaN: preserve write combining without weakening persistence.
     * All dirty FAT pages are first submitted in ascending contiguous runs to
     * the normal DAPI write-back cache. driver_FlushDrive() then drains that
     * cache using writeblocks1() runs and finally sends ATA FLUSH CACHE (E7).
     * Only after a direct uncached readback matches do we clear dirty bits. */
    if(flexIsHdaDevice(dnr))
    {
        bs=getblocksize(dnr);
        if(bs<=0) return 1;
        bytes=n*bs;
        io=malloc(bytes);
        verify=malloc(bytes);
        if(io==NULL || verify==NULL)
        {
            if(io) free(io);
            if(verify) free(verify);
            return 1;
        }

        failed=0;
        pos=0;
        while(pos<n)
        {
            first_page=f->cache_page[order[pos]];
            run=1;
            while(pos+run<n &&
                  f->cache_page[order[pos+run]]==first_page+run)
                run++;

            for(j=0;j<run;j++)
                memcpy(io+j*bs,flexSlotPtr(f,order[pos+j]),(size_t)bs);
            disk_block=f->bb->fat_offs+first_page;
            if(writeblocks(dnr,disk_block,io,run)!=run)
            {
                printk("FlexFAT: HDA FAT run enqueue/write failed pages %d..%d (blocks %d..%d).\n",
                       first_page,first_page+run-1,disk_block,disk_block+run-1);
                failed=1;
                break;
            }
            pos+=run;
        }

        /* Even if one enqueue failed, try to drain any earlier accepted writes
         * so no successfully submitted metadata is left hidden only in RAM. */
        if(driver_FlushDrive(dnr)!=0)
        {
            printk("FlexFAT: HDA DAPI/ATA FLUSH CACHE failed for DNR=%d.\n",dnr);
            failed=1;
        }

        if(!failed)
        {
            pos=0;
            while(pos<n)
            {
                first_page=f->cache_page[order[pos]];
                run=1;
                while(pos+run<n &&
                      f->cache_page[order[pos+run]]==first_page+run)
                    run++;
                disk_block=f->bb->fat_offs+first_page;
                if(readblocks1(dnr,disk_block,verify,run)!=run)
                {
                    printk("FlexFAT: HDA FAT direct verify read failed pages %d..%d.\n",
                           first_page,first_page+run-1);
                    failed=1;
                    break;
                }
                for(j=0;j<run && !failed;j++)
                    for(i=0;i<bs;i++)
                        if(verify[j*bs+i]!=flexSlotPtr(f,order[pos+j])[i])
                        {
                            printk("FlexFAT: HDA FAT verify mismatch page %d block %d offset %d.\n",
                                   first_page+j,disk_block+j,i);
                            failed=1;
                            break;
                        }
                pos+=run;
            }
        }

        if(!failed && f->bb && jtmfat_infoblock_uses_lazyfat(f->bb) &&
           f->lazy_staged_pages>f->lazy_materialized_pages)
        {
            /* All pages from the old prefix to staged_pages must be present in
             * this successful dirty set before the prefix can advance. */
            DWORD want=f->lazy_materialized_pages;
            int found;
            while(want<f->lazy_staged_pages)
            {
                found=0;
                for(i=0;i<n;i++)
                    if((DWORD)f->cache_page[order[i]]==want) { found=1; break; }
                if(!found) break;
                want++;
            }
            if(want>f->lazy_materialized_pages)
            {
                if(jtmfat_lazyfat_set_materialized_pages(dnr,want)!=0)
                    failed=1;
                else
                    f->lazy_materialized_pages=want;
            }
        }

        if(!failed)
        {
            for(i=0;i<n;i++) f->writemap[order[i]]=0;
            f->disk_writes+=(DWORD)n;
            dprintk("FlexFAT: HDA committed %d dirty FAT sector(s): DAPI write-combine + ATA flush + physical readback OK.\n",n);
        }
        free(io);
        free(verify);
        f->writeBack=flexCountDirty(f);
        return failed || f->writeBack ? 1 : 0;
    }

    failed = 0;
    for(i=0; i<f->cache_slots; i++)
        if(f->writemap[i] && flexFlushSlot(f, i))
            failed = 1;

    f->writeBack = flexCountDirty(f);
    if(f->writeBack) failed=1;
    if(failed)
        printk("FlexFAT: DNR=%d still has %d dirty FAT cache page(s) after flush.\n",
               dnr,f->writeBack);
    return failed;
}

void flexFlushFAT(int dnr)
{
    (void)flexFlushFATChecked(dnr);
}

/* Clear/invalidate the RAM cache; this does not modify the on-disk FAT. */
void clearFatContents(FLEFAT *f)
{
    DEBUGFUNC

    if(f==NULL)
        return;
    flexResetCacheMetadata(f);
}

/* Allocate the bounded page-cache buffers for one drive. */
int flexAllocateFat(FLEFAT *f)
{
    int amount, bs, entries_per_sector, fat_sectors, slots;
    int wanted_buf, wanted_wm;

    DEBUGFUNC

    if(f==NULL)
        return 1984;

    amount = (int)jtmfat_unitcount(f->dnr);
    bs = getblocksize(f->dnr);
    if(amount<=0 || bs<4 || (bs&3))
        return 1985;

    entries_per_sector = bs / 4;
    fat_sectors = (amount + entries_per_sector - 1) / entries_per_sector;
    if(fat_sectors<=0)
        return 1986;

    /* The formatted volume must reserve enough sectors for all FAT entries. */
    if(f->bb && f->bb->fat_length < fat_sectors)
    {
        printk("FlexFAT: FAT geometry invalid: reserved=%d, required=%d sectors.\n",
               f->bb->fat_length, fat_sectors);
        return 1987;
    }

    slots = fat_sectors;
    if(slots > FLEXFAT_CACHE_SLOTS)
        slots = FLEXFAT_CACHE_SLOTS;
    if(slots < 1)
        slots = 1;

    wanted_buf = slots * bs;
    wanted_wm = slots;

    if(f->cache_page && f->l_cache_page != slots*(int)sizeof(int))
    {
        free(f->cache_page);
        f->cache_page = NULL;
        f->l_cache_page = 0;
    }
    if(f->cache_age && f->l_cache_age != slots*(int)sizeof(DWORD))
    {
        free(f->cache_age);
        f->cache_age = NULL;
        f->l_cache_age = 0;
    }

    if(f->buf && f->l_buf != wanted_buf)
    {
        free(f->buf);
        f->buf = NULL;
        f->l_buf = 0;
    }
    if(f->writemap && f->l_writemap != wanted_wm)
    {
        free(f->writemap);
        f->writemap = NULL;
        f->l_writemap = 0;
    }

    if(f->buf==NULL)
    {
        f->buf = malloc(wanted_buf);
        if(f->buf==NULL || illegal(f->buf))
            return 1988;
        f->l_buf = wanted_buf;
    }

    if(f->writemap==NULL)
    {
        f->writemap = malloc(wanted_wm);
        if(f->writemap==NULL || illegal(f->writemap))
            return 1989;
        f->l_writemap = wanted_wm;
    }

    if(f->cache_page==NULL)
    {
        f->cache_page = malloc(slots * sizeof(int));
        if(f->cache_page==NULL || illegal(f->cache_page))
            return 1990;
        f->l_cache_page = slots * sizeof(int);
    }
    if(f->cache_age==NULL)
    {
        f->cache_age = malloc(slots * sizeof(DWORD));
        if(f->cache_age==NULL || illegal(f->cache_age))
            return 1991;
        f->l_cache_age = slots * sizeof(DWORD);
    }

    f->amount = amount;
    f->bs = bs;
    f->entries_per_sector = entries_per_sector;
    f->fat_sectors = fat_sectors;
    f->cache_slots = slots;

    clearFatContents(f);

    dprintk("%s: DNR=%d, FAT entries=%d, FAT sectors=%d, cache=%d sectors/%d bytes\n",
            __FUNCTION__, f->dnr, f->amount, f->fat_sectors,
            f->cache_slots, f->l_buf);
    return 0;
}

/*
 * Full-table integrity scanning used to depend on f->buf containing every FAT
 * entry.  V46 is intentionally demand-paged; the old AnalyzeFAT implementation
 * was already disabled by an unconditional return.  Keep it as a no-op until a
 * streaming checker is implemented.
 */
void AnalyzeFAT(FLEFAT *f)
{
    (void)f;
    return;
}

void AnalyzeFATs(void)
{
    int dnr;

    if(!flexActive || fle==NULL) return;
    dnr = driver_getdevicenrbyname("ram");
    if(dnr>=0 && dnr<N_MAX_FATS) AnalyzeFAT(&fle->FAT[dnr]);
    dnr = driver_getdevicenrbyname("hda");
    if(dnr>=0 && dnr<N_MAX_FATS) AnalyzeFAT(&fle->FAT[dnr]);
}

/*
 * Compatibility function:
 *  FLEXFAT_WRITE: flush resident dirty pages.
 *  FLEXFAT_READ : invalidate current resident pages; next access reloads lazily.
 */
void flexRWFAT(FLEFAT *f, int rw)
{
    int i;

    DEBUGFUNC

    if(f==NULL)
        return;

    if(rw==FLEXFAT_WRITE)
    {
        (void)flexFlushFATChecked(f->dnr);
        return;
    }

    /* Do not discard dirty data on an explicit refresh request.  Older code
     * unconditionally invalidated every slot even when a FAT write failed,
     * silently converting an I/O error into lost metadata. */
    if(flexFlushFATChecked(f->dnr)!=0)
    {
        printk("FlexFAT: refusing FLEXFAT_READ refresh/invalidate for DNR=%d because dirty metadata could not be flushed.\n",f->dnr);
        return;
    }
    for(i=0; i<f->cache_slots; i++)
    {
        f->cache_page[i] = FLEXFAT_INVALID_PAGE;
        f->cache_age[i] = 0;
        f->writemap[i] = 0;
    }
    f->writeBack = 0;
}

int flexActivateFat(int dnr)
{
    FLEFAT *f;
    int rv;

    DEBUGFUNC

    if(!isValidDevice(dnr) || dnr<0 || dnr>=N_MAX_FATS ||
       !flexActive || fle==NULL)
        return 1981;

    f = &fle->FAT[dnr];
    f->bb = jtmfat_getinfoblock(dnr);
    if(f->bb==NULL || strncmp(f->bb->detstr, "JTMFS", 5))
    {
        dprintk("%s: drive %d is not JTMFS formatted.\n", __FUNCTION__, dnr);
        return 1980;
    }

    f->status = INITIALIZED;
    f->dnr = dnr;
    f->guard = FLFGUARD;
    f->writeBack = 0;
    f->max_val = jtmfat_unitcount(dnr);
    f->amount = (int)jtmfat_unitcount(dnr);
    f->cache_hits = 0;
    f->cache_misses = 0;
    f->disk_reads = 0;
    f->disk_writes = 0;
    f->lazy_materialized_pages = jtmfat_lazyfat_materialized_pages(f->bb);
    f->lazy_staged_pages = f->lazy_materialized_pages;

    rv = flexAllocateFat(f);
    if(rv)
    {
        f->isOK = FALSE;
        return rv;
    }

    f->isOK = TRUE;
    return 0;
}

int flexGetFatSize(int dnr)
{
    if(!isValidDevice(dnr) || dnr<0 || dnr>=N_MAX_FATS ||
       !flexActive || fle==NULL)
        return 0;
    if(!fle->FAT[dnr].isOK)
        if(flexTouchFat(dnr, 0))
            return 0;
    return fle->FAT[dnr].amount;
}

/* Ensure FAT metadata/cache exists.  No whole-FAT read happens here. */
int flexTouchFat(int dnr, int FATbnr)
{
    FLEFAT *f;

    DEBUGFUNC

    if(!isValidDevice(dnr) || dnr<0 || dnr>=N_MAX_FATS ||
       !flexActive || fle==NULL)
        return 1;
    if(FATbnr<0 || (DWORD)FATbnr>=jtmfat_unitcount(dnr))
        return 1;

    f = &fle->FAT[dnr];
    if(!f->isOK)
        return flexActivateFat(dnr);

    return 0;
}

/* Kept for source compatibility. entry here means cache slot. */
void flexSetWM(FLEFAT *f, int entry, int what)
{
    if(f==NULL || entry<0 || entry>=f->cache_slots)
        return;
    f->writemap[entry] = what ? 1 : 0;
    f->writeBack = flexCountDirty(f);
}

/* Mark the cache slot containing FAT entry dirty. */
void flexAffectWM(FLEFAT *f, int entry)
{
    int fat_sector, sector_entry, slot;

    if(flexEntryLocation(f, entry, &fat_sector, &sector_entry))
        return;
    (void)sector_entry;
    slot = flexFindSlot(f, fat_sector);
    if(slot<0)
        return;
    f->writemap[slot] = 1;
    f->writeBack = flexCountDirty(f);
}

int _flexFatGetBlock(const char *caller, int dnr,int X)
{
    int rv;
    (void)caller;

    if(!isValidDevice(dnr) || dnr<0 || dnr>=N_MAX_FATS ||
       !flexActive || fle==NULL)
        return 0;
    if(X<0 || (DWORD)X>=jtmfat_unitcount(dnr))
        return 0;
    rv = flexTouchFat(dnr, X);
    if(rv)
        return 0;
    return FastGetBlock(dnr, X);
}

int _FastSetBlock(char *fun, int dnr, int which, DWORD what)
{
    FLEFAT *f;
    int fat_sector, sector_entry, slot;
    DWORD *entries;
    char str[256];

    if(flexTouchFat(dnr, which))
        return 1;

    f = &fle->FAT[dnr];
    if(!flexValueIsValid(f, what))
    {
        dprintk("Function %s attempted illegal FAT value %x (max=%x); write rejected.\n",
                fun,what,f->max_val);
        return 1;
    }

    if(flexEntryLocation(f, which, &fat_sector, &sector_entry))
        return 1;

    /* Lazy FAT pages are materialized in ascending order.  This keeps one
     * persistent scalar sufficient to distinguish valid new FAT data from
     * stale bytes left by the previous filesystem. */
    if(f->bb && jtmfat_infoblock_uses_lazyfat(f->bb) &&
       (DWORD)fat_sector>=f->lazy_materialized_pages)
    {
        if((DWORD)fat_sector>f->lazy_staged_pages)
        {
            printk("JTMFS: lazy-FAT refused non-sequential materialization DNR=%d page=%d staged=%u persisted=%u.\n",
                   dnr,fat_sector,(unsigned)f->lazy_staged_pages,
                   (unsigned)f->lazy_materialized_pages);
            return 1;
        }
        if(flexGetPage(f,fat_sector,TRUE,&slot)) return 1;
        if((DWORD)fat_sector==f->lazy_staged_pages)
            f->lazy_staged_pages=(DWORD)fat_sector+1UL;
    }
    else if(flexGetPage(f, fat_sector, FALSE, &slot))
        return 1;

    entries = (DWORD*)flexSlotPtr(f, slot);
    entries[sector_entry] = what;
    f->writemap[slot] = 1;
    f->writeBack = flexCountDirty(f);

    /* Keep HDA metadata dirty in FlexFAT until sync/eviction.  The checked
     * flush path writes adjacent FAT pages as one DAPI/ATA series and verifies
     * the physical media before clearing these bits. */
    return 0;
}

/*
 * Set [x1,x2) to one FAT value.  Complete FAT sectors are created in RAM
 * without first reading their obsolete contents from disk.
 */
int FastSetBlocks(int dnr, int x1, int x2, int what)
{
    FLEFAT *f;
    DWORD value;
    int pos, page, page_first, page_limit, seg_end;
    int slot, full_page, i;
    DWORD *entries;

    if(!isValidDevice(dnr) || dnr<0 || dnr>=N_MAX_FATS ||
       !flexActive || fle==NULL)
        return 1;
    if(x1<0 || x2<x1 || (DWORD)x2>jtmfat_unitcount(dnr))
        return 1;
    if(x1==x2)
        return 0;
    if(flexTouchFat(dnr, x1))
        return 1;

    f = &fle->FAT[dnr];
    value = (DWORD)what;
    if(!flexValueIsValid(f, value))
        return 1;

    pos = x1;
    while(pos < x2)
    {
        jtmfs_cooperative_yield((unsigned long)pos);
        page = pos / f->entries_per_sector;
        page_first = page * f->entries_per_sector;
        page_limit = page_first + f->entries_per_sector;
        if(page_limit > f->amount)
            page_limit = f->amount;

        seg_end = x2;
        if(seg_end > page_limit)
            seg_end = page_limit;

        full_page = (pos==page_first && seg_end==page_limit);
        if(f->bb && jtmfat_infoblock_uses_lazyfat(f->bb) &&
           (DWORD)page>=f->lazy_materialized_pages)
        {
            if((DWORD)page>f->lazy_staged_pages) return 1;
            if(flexGetPage(f,page,TRUE,&slot)) return 1;
            if((DWORD)page==f->lazy_staged_pages)
                f->lazy_staged_pages=(DWORD)page+1UL;
        }
        else if(flexGetPage(f, page, full_page, &slot))
            return 1;

        entries = (DWORD*)flexSlotPtr(f, slot);
        for(i=pos; i<seg_end; i++)
            entries[i-page_first] = value;

        f->writemap[slot] = 1;
        f->writeBack = flexCountDirty(f);
        pos = seg_end;
    }

    return 0;
}

int _FastGetBlock(const char *fun, int dnr, int which)
{
    FLEFAT *f;
    int fat_sector, sector_entry, slot;
    DWORD *entries;
    (void)fun;

    if(flexTouchFat(dnr, which))
        return 0;

    f = &fle->FAT[dnr];
    if(flexEntryLocation(f, which, &fat_sector, &sector_entry))
        return 0;
    if(flexGetPage(f, fat_sector, FALSE, &slot))
        return 0;

    entries = (DWORD*)flexSlotPtr(f, slot);
    return (int)entries[sector_entry];
}

int _flexFatSetBlock(const char *caller, int dnr,int X,int VALUE)
{
    JTMFAT_INFOBLOCK *inf;
    DWORD old_value;
    int rv;
    if(!isValidDevice(dnr) || dnr<0 || dnr>=N_MAX_FATS ||
       !flexActive || fle==NULL)
        return 1;
    if(X<0 || (DWORD)X>=jtmfat_unitcount(dnr))
        return 1;

    /* V67.8.57.4 SYSTEM-WALL: normal FAT mutation is forbidden for the
     * boot/kernel/FAT-reserved entries.  mkfs initializes that range with
     * FastSetBlocks() deliberately; the root entry at data_offs remains a
     * normal chain node. */
    inf=jtmfat_getinfoblock(dnr);
    if(inf!=NULL && fatsys!=NULL && fatsys->isJTMFS[dnr] && X<(int)inf->data_offs)
    {
        printk("JTMFS: SYSTEM-WALL refused FAT mutation by %s DNR=%d block=%d value=0x%x (root=%u).\n",
               caller ? caller : "?",dnr,X,(unsigned int)VALUE,inf->data_offs);
        return 1;
    }

    if(flexTouchFat(dnr, X))
        return 1;
    old_value=(DWORD)_FastGetBlock(caller,dnr,X);
    rv=_FastSetBlock((char*)caller, dnr, X, (DWORD)VALUE);
    if(rv==0)
        DiskSpaceFatTransition(dnr,(DWORD)X,old_value,(DWORD)VALUE);
    return rv;
}

/*
 * Real media change: discard resident pages.  Callers must flush before
 * announcing a media change if the old medium is still writable.
 */
void flexDiskChange(int dnr)
{
    FLEFAT *f;

    DEBUGFUNC

    if(!isValidDevice(dnr) || dnr<0 || dnr>=N_MAX_FATS || fle==NULL)
        return;

    f = &fle->FAT[dnr];
    if(f->status!=INITIALIZED)
        return;

    f->isOK = FALSE;
    clearFatContents(f);
    f->bb = NULL;
    DiskSpaceInvalidateDevice(dnr);
}
