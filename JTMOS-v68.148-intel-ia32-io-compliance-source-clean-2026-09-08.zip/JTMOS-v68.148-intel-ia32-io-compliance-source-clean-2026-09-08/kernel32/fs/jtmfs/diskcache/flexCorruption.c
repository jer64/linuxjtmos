// flexCorruption.c
#include "kernel32.h"
#include "jtmfs.h"
#include "jtmfat.h"
#include "flexFat.h"
#include "flexCorruption.h"

//----------------------------------------------------------------
// FlexFAT system report
//
void jtmfatInformation(void)
{
	int dnr;

	if(!flexActive || fle==NULL)
	{
		printk("FlexFAT: cache system is unavailable.\n");
		return;
	}

	// Check HDA
	dnr = driver_getdevicenrbyname("hda");
	if(dnr>=0 && dnr<N_MAX_FATS)
		jtmfatInformation1(&fle->FAT[dnr], "Hard Disk Drive");

	// Check RAM disk
	dnr = driver_getdevicenrbyname("ram");
	if(dnr>=0 && dnr<N_MAX_FATS)
		jtmfatInformation1(&fle->FAT[dnr], "RAM Disk Drive");
}

// Check FAT structure's status
// FALSE = corrupted
// TRUE = uncorrupted, or information unavailable
int checkFat(FLEFAT *e)
{
	if(e==NULL) return TRUE;
	// Skip inactive FATs
	if(e->isOK==FALSE)
		return TRUE;

	// Check guard DWORD
	if(e->guard!=FLFGUARD)
		return FALSE;

/*	// Check buffer #1
	if( fixalCheck(e->buf, e->l_buf)==FALSE )
		return FALSE;

	// Check buffer #2
	if( fixalCheck(e->writemap, e->l_writemap)==FALSE )
		return FALSE;*/

	// OK:
	return TRUE;
}

// FlexFAT general corruption check
int ffCheck(const char *fn, const char *func, int line)
{
	int dnr;
	static char str[256],name[256];
	FLEFAT *e;
	int i;
	static char *drives[]={"ram","hda","*"};
	static int dnrs[100]={-1,-1};

	//
	if(flexActive!=TRUE)
		return 1;

	//
	return 0;

	//
	for(i=0; strcmp(drives[i],"*"); i++)
	{
		// Check HDA
		if( (dnr=dnrs[i])==-1 )
			dnrs[i] = dnr = driver_getdevicenrbyname(drives[i]);
		if(dnr==-1)
			continue;
		e = &fle->FAT[dnr];
	
		// Check one
//		FLEXCHECK(e);

		// Check two
		if(checkFat(e)==FALSE)
		{
			//
			driver_getdevicename(dnr, name);
			sprintf(str, "error: file %s, function %s, line %d -- FAT failure on device %s",
				fn, func, line,
				name);
			dprintk("%s\n",str);
			e->isOK=FALSE;
			return 1;
		}
	}

	//
	return 0;
}

// Reporter function
void jtmfatInformation1(FLEFAT *e, const char *name)
{
	int i,i2,i3,i4;

	if(e==NULL) return;
	// Skip inactive FATs
	if(e->isOK==FALSE)
		return;

	// Print descriptions
	printk("-------------------------------------------------------------\n");
	printk("REPORT FOR: %s\n",		name);
	printk("Cache PTR  Cache bytes  Dirty map  Slots  DNR  GUARD  FAT entries/sectors\n");

	// Print values
	printk("%x  %d  %x  %d  %d  %x  %d/%d\n",
		e->buf, e->l_buf, e->writemap, e->cache_slots,
		e->dnr, e->guard, e->amount, e->fat_sectors);
	printk("Cache hits=%d misses=%d disk_reads=%d disk_writes=%d dirty=%d\n",
		e->cache_hits, e->cache_misses, e->disk_reads, e->disk_writes,
		e->writeBack);

	// Check guard DWORD
	if(e->guard!=FLFGUARD)
	{
		//
		printk("WARNING: entry guard variable is incorrect. This most probably indicates a corrupted FAT structure.\n");
		printk("%x != %x\n",
			e->guard, FLFGUARD);
	}

/*	// Check buffer #1
	if( fixalCheck(e->buf, e->l_buf)==FALSE )
	{
		//
		printk("e->buf guard is invalid, this indicates a buffer corruption.\n");
	}

	// Check buffer #2
	if( fixalCheck(e->writemap, e->l_writemap)==FALSE )
	{
		//
		printk("e->writemap guard is invalid, this indicates a buffer corruption.\n");
	}*/
}




