//
#ifndef __INCLUDED_FLEXCORRUPTION_H__
#define __INCLUDED_FLEXCORRUPTION_H__

//
#include "flexFat.h"

//
void jtmfatInformation(void);
void jtmfatInformation1(FLEFAT *e, const char *name);
int checkFat(FLEFAT *e);
int ffCheck(const char *fn, const char *func, int line);

//
#define FFCHECK ffCheck(__FILE__, __FUNCTION__, __LINE__);

//
#define FLEXCHECK(x) do { \
	FLEFAT *__flexcheck_f=(FLEFAT*)(x); \
	if(__flexcheck_f!=NULL && checkFat(__flexcheck_f)==FALSE) { \
		printk("FlexFAT corruption detected: function %s, file %s, line %d; cache disabled.\n", \
			__FUNCTION__,__FILE__,__LINE__); \
		__flexcheck_f->isOK=FALSE; \
	} \
} while(0);

#define jtmfatChecker(); FFCHECK

#endif




