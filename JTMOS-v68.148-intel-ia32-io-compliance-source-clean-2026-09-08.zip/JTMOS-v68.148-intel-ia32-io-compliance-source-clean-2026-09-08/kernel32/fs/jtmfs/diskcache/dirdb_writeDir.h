#ifndef __INCLUDED_WRITEDIR_H__
#define __INCLUDED_WRITEDIR_H__

int dirdb_writeDir(DIR *d);
int dirdb_commitDir(DIR *d);

#endif


