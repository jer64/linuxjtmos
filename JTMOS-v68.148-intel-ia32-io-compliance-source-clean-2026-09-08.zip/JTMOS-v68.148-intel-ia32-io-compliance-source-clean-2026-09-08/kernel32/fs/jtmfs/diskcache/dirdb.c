// ======================================================================
// Enhanced directory cache database system,
//		aka EDCDS system.
// (C) 2002-2021 by Jari Tuominen.
//
// This file contains only the init routine
// and some few functions.
// Other functions are located in seperate
// dirdb* files.
// ======================================================================
#include "kernel32.h"
#include "dirdb.h"		// DIRDB main header file
#include "dirdbAccess.h"	// DIRDB access functions
#include "dirdbWalk.h"		// DIRDB dir walking functions
#include "dirdb_writeDir.h"
//
DIRDB dirdb;

#define DIRDB_MIN_BUDGET (MAX_BYTES_PER_DIR * 4)
#define DIRDB_MAX_BUDGET (MAX_BYTES_PER_DIR * MAX_DIRS_CACHED)

void dirdb_releaseBuffer(DIR *d)
{
	if(!d || !d->buf) return;
	if(dirdb.bytes_allocated >= (DWORD)d->l_buf)
		dirdb.bytes_allocated -= (DWORD)d->l_buf;
	else
		dirdb.bytes_allocated = 0;
	free(d->buf);
	d->buf = NULL;
	d->l_buf = 0;
}

/* Drop least-recently-used clean entries until the requested allocation fits. */
void dirdb_trimCache(DWORD bytes_needed)
{
	DIR *victim;
	DWORD oldest;
	DWORD free_bytes;
	DWORD adaptive;
	int i;

	free_bytes = malloc_getmemoryfree();
	adaptive = free_bytes / 16; /* DIRDB may consume at most 1/16 of free RAM. */
	if(adaptive < DIRDB_MIN_BUDGET) adaptive = DIRDB_MIN_BUDGET;
	if(adaptive > DIRDB_MAX_BUDGET) adaptive = DIRDB_MAX_BUDGET;
	dirdb.byte_limit = adaptive;

	while(dirdb.bytes_allocated + bytes_needed > dirdb.byte_limit)
	{
		victim = NULL;
		oldest = 0xFFFFFFFFUL;
		for(i=0; i<dirdb.n_entries; i++)
		{
			DIR *d = &dirdb.dir[i];
			if(d->buf && !d->flushRequired && d->last_access <= oldest)
			{
				oldest = d->last_access;
				victim = d;
			}
		}
		if(!victim) break; /* Dirty buffers must never be discarded. */
		victim->isfree = 1;
		victim->dnr = -1;
		victim->db = -1;
		dirdb_releaseBuffer(victim);
	}
}

int dirdb_ensureBuffer(DIR *d, DWORD bytes)
{
	BYTE *newbuf;
	if(!d) return 1;
	if(d->buf && (DWORD)d->l_buf >= bytes) return 0;
	if(d->flushRequired) return 1;
	dirdb_trimCache(bytes);
	newbuf = malloc(bytes);
	if(!newbuf) return 1;
	dirdb_releaseBuffer(d);
	d->buf = newbuf;
	d->l_buf = (int)bytes;
	dirdb.bytes_allocated += bytes;
	return 0;
}

//
int dirdb_inited=0;

//
void pause(const char *s)
{
	printk(s);
	ESCLOCK();
}

// Initialise DIRDB
int dirdb_init(void)
{
	// --------------------------------------
	int i,i2,i3,i4;

	//
	if(dirdb_inited)return 1;
	dirdb_inited = 1;

	// --------------------------------------
	// Clear structure
	memset(&dirdb, 0, sizeof(DIRDB));

	// Set amount of directories in cache
	dirdb.total =		MAX_DIRS_CACHED;

	// Set entries amount to zero
	dirdb.n_entries =	0;

	// Set state to free(for concurrency handling)
	dirdb.state =		0;

	// Set all directory entries free
	        /*
	        We are changing contents of DIRDB based dirdb database:
	        
		// DIRECTORY (ACTUAL DIRECTORY/CACHE ENTRY) -STRUCTURE DEFINITION.
		...
	        // Structures for cached directories
       		DIR dir[(MAX_DIRS_CACHED+10)];
       		*/
	for(i=0; i<dirdb.total; i++)
	{
		// Set guard variable
		dirdb.dir[i].guard =	DIRDB_GUARD;
		// Set entry free
		dirdb.dir[i].isfree =	1;
		// Buffers are allocated lazily on the first cache miss.
		dirdb.dir[i].buf =	NULL;
		dirdb.dir[i].l_buf =	0;
		// Set type to directory
		dirdb.dir[i].type =	DIRDB_KIND_DIRECTORY;
	}

	// No cache flush request at the start up.
	dirdb.cacheFlushRec = 0;
	dirdb.access_clock = 0;
	dirdb.bytes_allocated = 0;
	dirdb.byte_limit = DIRDB_MIN_BUDGET;

	//
	return 0;
}


// Initialise DIRDB
int dirdb_flush(void)
{
	/* Historical spelling retained for old kernel callers.  The previous
	 * implementation returned immediately whenever DIRDB was initialized,
	 * which made it a silent no-op in the only state where flushing matters. */
	if(!dirdb_inited) return 1;
	return dirdbFlush();
}
