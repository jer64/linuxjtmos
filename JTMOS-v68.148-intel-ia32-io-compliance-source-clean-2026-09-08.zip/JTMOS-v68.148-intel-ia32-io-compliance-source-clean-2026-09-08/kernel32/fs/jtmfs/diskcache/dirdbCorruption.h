//
#ifndef __INCLUDED_DIRDBCORRUPTION_H__
#define __INCLUDED_DIRDBCORRUPTION_H__

//
int dirdb_validator(DIR *d);

//

#endif



