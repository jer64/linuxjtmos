//================================================================
// dirdb_writeDir.c - safe DirDB writeback
//================================================================
#include "kernel32.h"
#include "dirdb.h"
#include "dirdbAccess.h"
#include "dirdbWalk.h"

static int dirdb_safe_count_entries(DIR *d)
{
    int i,limit;
    JTMFS_FILE_ENTRY *fe;

    if(d==NULL || d->buf==NULL || d->l_buf<(int)sizeof(JTMFS_FILE_ENTRY)) return -1;
    limit=d->l_buf/(int)sizeof(JTMFS_FILE_ENTRY);
    for(i=0;i<limit;i++)
    {
        fe=(JTMFS_FILE_ENTRY*)(d->buf+i*sizeof(JTMFS_FILE_ENTRY));
        if(!fe->name[0]) return i;
        if(fe->magicNumber!=0xFCE2E37B) return -1;
    }
    /* A full cache without the required empty terminator is not safe to write. */
    return -1;
}

int dirdb_writeDir(DIR *d)
{
    int blocks,x,er,rd,bs,l_tmp,bytes;
    char str[256];
    BYTE *tmp;

    DIRDEBUG
    if(d==NULL || d->buf==NULL || !dirdb_validator(d)) return 1;
    bs=(int)jtmfat_unitsize(d->dnr);
    if(bs<=0) return 2;

    if(d->type==DIRDB_KIND_DIRECTORY)
    {
        d->n_entries=dirdb_safe_count_entries(d);
        if(d->n_entries<0)
        {
            printk("%s: corrupt/unterminated directory cache; refusing writeback.\n",__FUNCTION__);
            return 307;
        }
        /* Include the terminating empty entry, then round up exactly once. */
        bytes=(d->n_entries+1)*(int)sizeof(JTMFS_FILE_ENTRY);
        blocks=(bytes+bs-1)/bs;
        driver_getdevicename(d->dnr,str);
        ReportMessage("%s: Writing directory on drive %s (%d entries, %d blocks).\n",
                      __FUNCTION__,str,d->n_entries,blocks);
    }
    else if(d->type==DIRDB_KIND_FILE)
    {
        blocks=d->blocks;
        ReportMessage("%s: Writing file dnr=%d, db=%d, buf=0x%x.\n",
                      __FUNCTION__,d->dnr,d->db,d->buf);
    }
    else
        return 300;

    if(blocks<=0) blocks=1;
    l_tmp=blocks*bs;
    if(l_tmp<=0 || l_tmp>d->l_buf)
    {
        printk("%s: refusing writeback length %d (cache buffer %d).\n",
               __FUNCTION__,l_tmp,d->l_buf);
        return 302;
    }

    tmp=malloc(l_tmp);
    if(tmp==NULL) return 303;

    er=jtmfs_WriteFileChain(d->buf,d->dnr,d->db,l_tmp,0);
    if(er)
    {
        printk("%s: write failed, error %d; dirty cache retained.\n",__FUNCTION__,er);
        free(tmp);
        return er==-2 ? 10 : 304;
    }

    /* V67.8.56.13 durable DIRDB commit:
     * WriteFileChain may extend a directory chain and therefore dirty FlexFAT.
     * Flush the FAT BEFORE claiming that directory data is durable.  The old
     * verifier could follow the newly-created chain through FlexFAT RAM and
     * therefore prove only that RAM was self-consistent. */
    if(flexFlushFATChecked(d->dnr))
    {
        printk("%s: FAT flush failed; refusing durable success.\n",__FUNCTION__);
        free(tmp);
        return 309;
    }

    if(driver_FlushDrive(d->dnr)!=0)
    {
        printk("%s: block/device flush failed before durable media verify.\n",__FUNCTION__);
        free(tmp);
        return 308;
    }

    /* Throw away both generic block-cache data and clean FlexFAT pages.
     * The following ReadFileChain must reconstruct the chain from media. */
    driver_block_cache_invalidate(d->dnr);
    if(flexActive && fle!=NULL && d->dnr>=0 && d->dnr<N_MAX_FATS &&
       fle->FAT[d->dnr].isOK)
        flexRWFAT(&fle->FAT[d->dnr], FLEXFAT_READ);
    driver_block_cache_invalidate(d->dnr);

    rd=jtmfs_ReadFileChain(tmp,d->dnr,d->db,l_tmp,0);
    if(rd!=l_tmp)
    {
        printk("%s: verify read failed/short (%d/%d bytes).\n",__FUNCTION__,rd,l_tmp);
        free(tmp);
        return 305;
    }
    for(x=0;x<l_tmp;x++)
        if(d->buf[x]!=tmp[x])
        {
            printk("%s: verify mismatch at offset 0x%x; dirty cache retained.\n",__FUNCTION__,x);
            free(tmp);
            return 306;
        }

    free(tmp);
    return 0;
}


/* Commit one DIRDB entry synchronously.  Unlike dirdb_flushRequirement(),
 * success from this API means the directory was written, FAT metadata was
 * drained and a media-backed readback succeeded. */
int dirdb_commitDir(DIR *d)
{
    int er;
    if(d==NULL || d->isfree) return 1;
    d->flushRequired=1;
    er=dirdb_writeDir(d);
    if(er==0) d->flushRequired=0;
    return er;
}
