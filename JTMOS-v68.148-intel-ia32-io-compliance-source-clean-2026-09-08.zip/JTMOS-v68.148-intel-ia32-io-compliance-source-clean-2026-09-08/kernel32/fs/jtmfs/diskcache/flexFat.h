#ifndef __INCLUDED_FLEXFAT_H__
#define __INCLUDED_FLEXFAT_H__

#include "jtmfat.h"

/*
 * FlexFAT cache design (V46)
 * --------------------------
 *
 * The on-disk JTMFS FAT is still a 32-bit linked allocation table.  It cannot
 * be replaced by a simple allocation bitmap because each FAT entry can contain
 * the number of the next data block in a file chain.
 *
 * What *is* paged is the in-memory cache.  Older FlexFAT versions allocated
 * getsize(dnr) * 4 bytes and read the complete FAT on first access.  V46 keeps
 * only a small number of FAT sectors in RAM and loads them on demand.
 */
#define INITIALIZED             0x136FD2DA
#define N_MAX_FATS              100
#define FLFGUARD                0xFCE2E37B

#define FLEXFAT_READ            0
#define FLEXFAT_WRITE           1

/* Per active device.  64 * 512 = 32 KiB, 64 * 1024 = 64 KiB. */
#define FLEXFAT_CACHE_SLOTS     64
#define FLEXFAT_INVALID_PAGE    (-1)

/* FlexFat errors are important and remain visible. */
#define FLEXER(ERRNO, EXPLANATION) dprintk("Flex error(%s) #%d\n", __FUNCTION__, ERRNO); \
printk(EXPLANATION);

typedef struct
{
    int isOK;

    DWORD guard;

    /*
     * Cache pool, not a whole-FAT image anymore.  Slot N begins at
     * buf + N*bs.  writemap[N] is the dirty flag for that slot.
     */
    BYTE *buf;
    int l_buf;
    BYTE *writemap;
    int l_writemap;

    /* Number of 32-bit FAT entries on this device. */
    int amount;

    /* Device/cache geometry. */
    int dnr;
    int bnr;                    /* retained for old diagnostics */
    int bs;
    int entries_per_sector;
    int fat_sectors;
    int cache_slots;

    /* Slot metadata. Allocated only for active devices. */
    int *cache_page;            /* FAT-sector index, or -1 */
    DWORD *cache_age;           /* LRU timestamp per slot */
    int l_cache_page;
    int l_cache_age;
    DWORD cache_clock;

    /* Number/flag indicating that dirty cache data exists. */
    int writeBack;

    /* Lightweight statistics, useful while developing JTMFS. */
    DWORD cache_hits;
    DWORD cache_misses;
    DWORD disk_reads;
    DWORD disk_writes;

    /* Lazy-zero FAT state. materialized_pages is persisted in the information
     * block; staged_pages is the contiguous zero-initialized prefix currently
     * known in RAM and may run ahead until the next successful flush. */
    DWORD lazy_materialized_pages;
    DWORD lazy_staged_pages;

    DWORD status;
    DWORD max_val;
    JTMFAT_INFOBLOCK *bb;
} FLEFAT;

typedef struct
{
    FLEFAT FAT[N_MAX_FATS];
} FLEFATSYS;

int flexFlushFATChecked(int dnr);
void flexFlushFAT(int dnr);
void flexDiskChange(int dnr);
void clearFatContents(FLEFAT *f);
void jtmfatInformation1(FLEFAT *e, const char *name);
void jtmfatInformation(void);
int _flexFatGetBlock(const char *caller, int dnr, int X);
int _flexFatSetBlock(const char *caller, int dnr, int X, int VALUE);
int FastSetBlocks(int dnr, int x1, int x2, int what);
void AnalyzeFAT(FLEFAT *f);
int flexActivateFat(int dnr);
int flexTouchFat(int dnr, int FATbnr);
int flexGetFatSize(int dnr);
void flexFatInit(void);

#define FastGetBlock(dnr,which) _FastGetBlock(__FUNCTION__, dnr,which)
#define FastSetBlock(dnr,which,what) _FastSetBlock(__FUNCTION__, dnr,which,what)
int _FastGetBlock(const char *fun, int dnr, int which);
int _FastSetBlock(char *fun, int dnr, int which, DWORD what);
void flexHealthCheck(void);

/*
 * Compatibility entry point.  WRITE flushes dirty cache pages.  READ no
 * longer reads the complete FAT; it prepares/invalidates the lazy cache.
 */
void flexRWFAT(FLEFAT *f, int rw);

extern char flextmp[256];
extern int flexActive;
extern FLEFATSYS *fle;

#include "flexCorruption.h"
void AnalyzeFATs(void);

#endif
