// ==============================================================================
// dirdbAccess.c - EDCDS DATABASE ACCESS FUNCTIONS.
// (C) 2002-2021 by Jari Tuominen (jari.t.tuominen@gmail.com).
// ==============================================================================
#include "kernel32.h"
#include "dirdb.h"
#include "dirdbAccess.h"
#include "dirdbWalk.h"

//
#define ddprintk dprintk
//#define ddprintk printk

//
int roll=0;

// This function is called upon disk
// changes(removable storage devices).
void dirdb_DiskChange(int dnr)
{
	//
	dirdb_clearCacheForDNR(dnr);
}

// Clears DIRDB cache for a specified DNR
// This funtion is called by e.g. IRQ handlers,
// therefore it must be kept quick and simple.
void dirdb_clearCacheForDNR(int dnr)
{
	DIR *d;
	int i,i2,i3,i4;
	DWORD wanted,unit;
	int flags;

	//
	DEBUGFUNC
	DIRDEBUG

	// Find all DNR's entries and deallocate these
	for(i=0; i<dirdb.n_entries; i++)
	{
		jtmfs_cooperative_yield((unsigned long)i);
		// Get directory entry pointer from database structure tree (array).
		d = &dirdb.dir[i];
		
		// Check for corruption.
		if( !dirdb_validator(d) )
		{
			// Invalid structure:
			printk("[DATA CORRUPTION, error at %s/%s/line %d] dirdb.dir[%d] is an invalid (DIR*) directory cache entry!\n",
				__FUNCTION__, __FILE__, __LINE__, i);
			sleep(2);
		}

		//
		if( d->dnr==dnr )
		{
			if(d->flushRequired) continue;
			d->isfree = 1;
			d->dnr = -1;
			d->db = -1;
			dirdb_releaseBuffer(d);
		}
	}
}

//
void dirdb_clearCacheForDBEx(int dnr, int db)
{
	DIR *d;

	//
	DIRDEBUG

	// Check validity
	if(dnr<0 || db<0)return;

	// Type 0 means = Any
	if( (d=dbGiveDir(dnr, db, 0)) )
	{
		// Check for corruption.
		if( !dirdb_validator(d) )
		{
			// Invalid structure:
			printk("[DATA CORRUPTION, error at %s/%s/line %d]: An invalid (DIR*) directory cache entry!\n",
				__FUNCTION__, __FILE__, __LINE__);
			sleep(2);
		}

		if(d->flushRequired) return;
		d->isfree = 1;
		d->dnr = -1;
		d->db = -1;
		dirdb_releaseBuffer(d);
	}
}

//
void dirdb_clearCacheForDB(int dnr, int db)
{
	//
	DIRDEBUG

	// Check validity
	if(!isValidDevice(dnr) || db<0)
		return;

	//
	if(dbGiveDir(dnr,db,0)) // Type 0 = Any
	{
		FlushAll(); // ?????????? Is this allowed?
		dirdb_clearCacheForDBEx(dnr, db);
	}
}

//
int getAlreadyFreeDBEntry(void)
{
	int i,i2,i3,i4,id,req;
	DIR *d;

	//
	DIRDEBUG

	// Warning: a possible endless loop.
	i4=roll&3; roll++;
retry:
	//
	for(i=0; i<dirdb.n_entries; i++)
	{
		jtmfs_cooperative_yield((unsigned long)i);
		if(dirdb.dir[i].isfree)
			return i;
	}

	// Already too much allocated?
	if(dirdb.n_entries>=MAX_DIRS_CACHED/2)
	{
		// Determine a fair requirement, 1/3 of space must be free
		req = dirdb.n_entries/3; if(!req)req++;
		// Make some space, deallocate ~10 entries
		for(i=0,i2=0; i<dirdb.n_entries && i2<req; i++)
		{
			//
			d = &dirdb.dir[i];
			
			// Check for corruption.
	                if( !dirdb_validator(d) )
       		        {
                	        // Invalid structure:
                	        printk("[DATA CORRUPTION, error at %s/%s/line %d] dirdb.dir[%d] is an invalid (DIR*) directory cache entry!\n",
                       	         __FUNCTION__, __FILE__, __LINE__, i);
                       	         sleep(2);
			}

			if(!d->isfree && !d->flushRequired
				&& ((i+i4)&3)==0)
			{
				dirdb_releaseBuffer(d);
				d->isfree=1;
				i2++;
			}
		}

		//
		i4++;
		if(i4>=10)	goto alloc;
		goto retry;
	}

alloc:
	// In cases when we afford to suggest allocation, we do so:
	return -1;
}

//
int reserveNewDBEntry(void)
{
	int i;

	//
	DIRDEBUG

	//
	if(dirdb.n_entries>=dirdb.total)
	{
   		printk("[DATABASE ERROR, Out of (DIR*) cache entries in the directory disk cache tree: %s/%s/line %d] %d dirdb.n_entries allocated, max.cap is %d.\n",
  	              __FUNCTION__, __FILE__, __LINE__,
  	              dirdb.n_entries, dirdb.total);
  	        sleep(5);
		//panic("... SYSTEM FAILURE at reserveNewDBEntry.");
		return -1;
	}

	//
	i = dirdb.n_entries;
	dirdb.n_entries++;
	return i;
}

// New: now deallocates a few entries if none is found.
int getFreeDBEntry(void)
{
	int i,id;

	//
	DIRDEBUG

	//
	id = getAlreadyFreeDBEntry();
	if(id==-1)
	{
		// Reserve new entry
		id = reserveNewDBEntry();
	}
	return id;
}

// touchDir dnr, db
//
// This function "touches" a directory on the database,
// if it does not exist on the database then it'll get it,
// so it is there on the fly, this makes it look for
// the caller like the directory would've been 
// there all the time.
DIR *touchDir(int dnr, int db, int type)
{
	DIR *d;

	//
	DIRDEBUG

	//
	// dirdb_validator

	// If not valid device, just return NULL
	if(!isValidDevice(dnr))return NULL;

	// Check for corruption
	FFCHECK

	//
	if( (d=dbGiveDir(dnr, db, type))==NULL )
	{
		//
		ddprintk("%s: Caching directory %d/%d\n",
			__FUNCTION__,
			dnr,db);
		return copyDirToDB(dnr,db, type);
	}

	//
	return d;
}

// Returns NULL if dir is not in the database.
DIR *dbGiveDir(int dnr, int db, int type)
{
	int i;
	DIR *d;

	DEBUGFUNC

	// If not valid device, just return NULL
	if(!isValidDevice(dnr))		return NULL;

	//
	FFCHECK
	DIRDEBUG

	//
	ddprintk("%s: Searching through cache (%d entries) for %d/%d\n",
		__FUNCTION__,
		dirdb.n_entries,
		dnr,db);

	//
	for(i=0; i<dirdb.n_entries; i++)
	{
		d = &dirdb.dir[i];

                // Check for corruption.
                if( !dirdb_validator(d) )
                {
                        // Invalid structure:
                        printk("[DATA CORRUPTION, error at %s/%s/line %d] dirdb.dir[%d] is an invalid (DIR*) directory cache entry!\n",
                                __FUNCTION__, __FILE__, __LINE__, i);
                        sleep(2);
                }

		if(!d->isfree
			&&
		   d->dnr==dnr
			&&
		   d->db==db
			&&
		   (d->type==type || type==0)) // type 0 = Any type
		{
			ddprintk("%s: Found entry %d,%d\n",
				__FUNCTION__,
				d->dnr, d->db);
			d->last_access = ++dirdb.access_clock;
			return d;
		}
	}
	ddprintk("%s: Entry %d,%d not found\n",
		__FUNCTION__,
		dnr, db);
	return NULL;
}

// Copy [file or directory] to database
DIR *copyDirToDB(int dnr, int db, int type)
{
	DIR *d;
	int i,i2,i3,i4;
	DWORD wanted,unit;

	DIRDEBUG

	//
	if( !isValidDevice(dnr) )	return NULL;

	// Check if it is there already
	if( (d=dbGiveDir(dnr, db, type))!=NULL )
	{
                // Check for corruption.
                if( !dirdb_validator(d) )
                {
                        // Invalid structure:
                        printk("[DATA CORRUPTION, error at %s/%s/line %d]: An invalid (DIR*) directory cache entry!\n",
                                __FUNCTION__, __FILE__, __LINE__);
                        sleep(2);
                }

		return d;
	}

	// Find free entry in database
	i = getFreeDBEntry();
	if(i < 0) return NULL;

	// Get the structure PTR
	d = &dirdb.dir[i];

	// Set it as reserved
	d->isfree=0;
	// Specify location
	d->dnr =	dnr;
	d->db =		db;
	// Specify type
	d->type =	type;
	d->last_access = ++dirdb.access_clock;
	d->flushRequired = 0;
	wanted=(type==DIRDB_KIND_FILE) ? 1024UL*128UL : (DWORD)MAX_BYTES_PER_DIR;
	if(type==DIRDB_KIND_DIRECTORY)
	{
		unit=jtmfat_unitsize(dnr);
		if(unit==0) { d->isfree=1; return NULL; }
		wanted=((wanted+unit-1UL)/unit)*unit;
	}
	if(dirdb_ensureBuffer(d, wanted))
	{
		d->isfree = 1;
		return NULL;
	}

	// Clear the buffer first
	memset(d->buf, 0, d->l_buf);

	// Read directory/file contents.  Never turn an I/O error into a silently
	// empty cached directory: that makes a populated HDA look freshly blank.
	if(readDir(d)!=0)
	{
		printk("copyDirToDB: media read failed for DNR=%d DB=%d; cache entry rejected.\n",dnr,db);
		d->isfree=1;
		d->dnr=-1;
		d->db=-1;
		dirdb_releaseBuffer(d);
		return NULL;
	}

                // Check for corruption.
                if( !dirdb_validator(d) )
                {
                        // Invalid structure:
                        printk("[DATA CORRUPTION, error at %s/%s/line %d] dirdb.dir[%d]\n",
                                __FUNCTION__, __FILE__, __LINE__,  i);
                        sleep(2);
                }

	// Return directory PTR
	return d;
}

//
int db_ReadDirectory(int dnr,int db,
        BYTE *buf,int l_buf)
{
    int rv,unit_size;
    if(!isOK(dnr) || buf==NULL || l_buf<=0) return -1;
    if(db<=0 || (DWORD)db>=jtmfat_unitcount(dnr)) return -1;
    unit_size=(int)jtmfat_unitsize(dnr);
    if(unit_size<=0) return -1;
    rv=jtmfs_ReadFileChain(buf,dnr,db,l_buf,0);
    if(rv<0) return -1;
    return (rv+unit_size-1)/unit_size;
}


// Reads directory into a DIR* structure.
int readDir(DIR *d)
{
	int blocks_read;

	DEBUGFUNC
	DIRDEBUG

	//
	if(d==NULL)
		return 1;

                // Check for corruption.
                if( !dirdb_validator(d) )
                {
                        // Invalid structure:
                        printk("[DATA CORRUPTION, error at %s/%s/line %d]: This is an invalid (DIR*) directory cache entry!\n",
                                __FUNCTION__, __FILE__, __LINE__);
                        sleep(2);
                }

	//
	ddprintk("%s: Reading directory dnr=%d, db=%d, buf=0x%x\n",
		__FUNCTION__,
		d->dnr, d->db,
		d->buf);

	// For files, do some modifications:
	if(d->type==DIRDB_KIND_FILE)
	{
		// Make some space for a file
		if(d->l_buf < 1024*128)
		{
			if(dirdb_ensureBuffer(d, 1024*128)) return 1;
		}
	}

	// Read directory from chain
	memset(d->buf, 0, d->l_buf);
	blocks_read = db_ReadDirectory(d->dnr,d->db, d->buf,d->l_buf);
	if(blocks_read<0)
	{
		printk("readDir: unable to read DNR=%d DB=%d from media.\n",d->dnr,d->db);
		return 2;
	}

	// Define amount of blocks cached
	d->blocks = blocks_read;

	// Determine amount of entries directory has
	if(d->type==DIRDB_KIND_DIRECTORY)
	{
		d->n_entries = countEntries(d);
		ReportMessage("%s: %d entries detected for this directory.\n",
			__FUNCTION__,
			d->n_entries);
	}

                // Check for corruption.
                if( !dirdb_validator(d) )
                {
                        // Invalid structure:
                        printk("[DATA CORRUPTION, error at %s/%s/line %d]\n",
                                __FUNCTION__, __FILE__, __LINE__);
                        sleep(2);
                }

	//
	return 0;
}

static int dirdbFlushInternal(int only_dnr)
{
    int i,c=0,errors=0,wr;
    int flags;
    DIR *d;

    DIRDEBUG
    flags=get_eflags();
    disable();
    {
        unsigned long spins=0;
        while(dirdb.state==1)
        {
            set_eflags(flags);
            if(LockWaitCanYield(flags))
                SwitchToThread();
            else
            {
                volatile unsigned long k;
                for(k=0;k<128;k++) { }
            }
            disable();
            if(++spins>=1000000UL)
            {
                set_eflags(flags);
                printk("dirdbFlush: wait timeout; state=%d, retrying.\n",dirdb.state);
                spins=0;
                disable();
            }
        }
    }
    dirdb.l_state=dirdb.state;
    dirdb.state=2;
    set_eflags(flags);

    for(i=0;i<dirdb.n_entries;i++)
    {
        d=&dirdb.dir[i];
        if(!dirdb_validator(d))
        {
            printk("dirdbFlush: invalid cache entry %d; refusing writeback.\n",i);
            errors++;
            continue;
        }
        if(only_dnr>=0 && d->dnr!=only_dnr)
            continue;
        if(!d->isfree && d->flushRequired)
        {
            wr=dirdb_writeDir(d);
            if(wr==0)
            {
                d->flushRequired=0;
                c++;
            }
            else
            {
                /* Never clear the dirty flag after a failed disk write. */
                printk("dirdbFlush: writeback failed for DNR=%d DB=%d (error %d).\n",
                       d->dnr,d->db,wr);
                errors++;
            }
        }
    }

    ddprintk("%d dir(s) flushed, %d error(s), DNR filter=%d.\n",c,errors,only_dnr);
    disable();
    dirdb.state=dirdb.l_state;
    set_eflags(flags);
    return errors ? 1 : 0;
}

/* Flush all dirty directory metadata. */
int dirdbFlush(void)
{
    return dirdbFlushInternal(-1);
}

/* Flush only metadata belonging to one physical/logical block device. */
int dirdbFlushDNR(int dnr)
{
    if(!isValidDevice(dnr)) return 1;
    return dirdbFlushInternal(dnr);
}

// countEntries d
//
// This function determines how many
// directory entries there are
// and returns the amount as an integer.
int countEntries(DIR *d)
{
	int i;
	char *p,*e;
	JTMFS_FILE_ENTRY *fe;

	DIRDEBUG

	//
	if(d==NULL)	return 0;

                // Check for corruption.
                if( !dirdb_validator(d) )
                {
                        // Invalid structure:
                        printk("[DATA CORRUPTION, error at %s/%s/line %d]: An invalid (DIR*) directory cache entry!\n",
                                __FUNCTION__, __FILE__, __LINE__);
                        sleep(2);
                        return 0;
                }

	// Determine location of end of the buffer
	e = d->buf; e+=d->l_buf;
	// Count entries
	for(p=d->buf,i=0; ; p+=sizeof(JTMFS_FILE_ENTRY),i++)
	{
		// Get fe PTR
		fe = (JTMFS_FILE_ENTRY *)p;

		// Unexpected end?
		if(p>=e)break;

		// Last entry reached?
		if(!fe->name[0])
			return i;

		//
		if(JTMFS_TYPE_IS_DIRNAME(fe->type))
		{
			printk(">>>> \"%s\" <<<<\n", fe->name);
		//	sleep(10);
		}

		// If magicNumber is wrong, we assume this directory
		// is entirely broken, we will therefore report 0 files.
		// The caller of this function should understand
		// "Return Value 0" as an indication of the fact that
		// the directory is corrupted, and therfore should be
		// ignored and/or fixed.
		if(fe->magicNumber!=0xFCE2E37B)	
		{
			// Corrupted directory detected:
			return 0;
		}
	}
	return 0;
}

//
