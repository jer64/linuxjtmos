// 2021 (C) Jari Tapio Tuominen (jari.t.tuominen@gmail.com) - Project Manager, Tech. Lead.
#include "kernel32.h"
#include "dirdb.h"
#include "dirdbCorruption.h"

// Returns TRUE on valid entry, directory cache entry structure.
int dirdb_validator(DIR *d)
{
    if(d==NULL) return FALSE;
    if(d->guard != DIRDB_GUARD) return FALSE;
    /* Free slots may contain stale bookkeeping, but every live cache object
     * must have a RAM-only DirDB kind -- never a JTMFS on-disk type. */
    if(!d->isfree && !DIRDB_KIND_IS_VALID(d->type)) return FALSE;
    return TRUE;
}


