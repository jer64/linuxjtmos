//=============================================================
// Root device functions - root.c
// (C) 2003 by Jari Tuominen
// Root-device namespace cleanup 2026.
//=============================================================
#include "kernel32.h"
#include "jtmfat.h" // getfreeblock
#include "jtmfs.h"
#include "jtmfsAccess.h"
#include "ramdisk.h" // default_ramdisk
#include "fsdos.h"
#include "fname_translation.h" // tell_fname
#include "root.h"
#include "mount.h"

// Returns current root device number.
int getRootDNR(void)
{
    return jtmfsAccess.dnr;
}

// Returns the real directory block backing '/'.
int getRootDB(void)
{
    int dnr;

    dnr=getRootDNR();
    if(!isValidDevice(dnr) || !jtmfs_isDriveReady(dnr))
        return 0;
    return jtmfat_getrootdir(dnr);
}

// MOUNT ROOT
// ----------
// The JTMOS namespace root is backed by a real JTMFS device.  At present
// boot selects ram:, but the implementation intentionally does not hard-code
// that choice here.
//
// Return values:
// 0=success, other values=error.
int mount_root(int dnr)
{
    int db;

    if(!isValidDevice(dnr))
        return 1;
    if(!jtmfs_isDriveReady(dnr))
        return 2;

    db=jtmfat_getrootdir(dnr);
    if(db<=0 || db>=(int)jtmfat_unitcount(dnr))
        return 3;

    jtmfsAccess.dnr=dnr;
    jtmfsAccess.db=db;
    if(jtmfsAccess.path!=NULL)
        strcpy(jtmfsAccess.path, "/");
    return 0;
}

// UNMOUNT ROOT
// ------------
int umount_root(void)
{
    jtmfsAccess.dnr=-1;
    jtmfsAccess.db=0;
    if(jtmfsAccess.path!=NULL)
        strcpy(jtmfsAccess.path, "");
    return 0;
}

/*
 * Populate the physical root filesystem with one directory for every real
 * block-device name known to the driver manager.  These directories are
 * persistent namespace/mount-point entries on the root device itself.
 *
 * The pathname resolver treats a root-level directory whose name matches a
 * JTMFS-formatted block device as a mount point and switches DNR/DB to that
 * device's real root.  For a raw/unformatted block device the directory stays
 * a normal empty placeholder until a filesystem becomes available there.
 */
int jtmfs_sync_block_device_mountpoints(void)
{
    int root_dnr, root_db;
    int i, amount, created, errors, rv;
    DEVICE_ENTRY *e;
    DIRWALK dw;
    char name[32];

    root_dnr=getRootDNR();
    root_db=getRootDB();
    if(!isValidDevice(root_dnr) || root_db<=0)
        return 1;

    amount=driver_getdeviceamount();
    created=0;
    errors=0;

    for(i=1; i<amount; ++i)
    {
        e=driver_getdevice(i);
        if(e==NULL || e->isfree)
            continue;
        if((e->type & DEVICE_TYPE_BLOCK)==0)
            continue;
        /* Do not create a self-mount directory such as /hda when hda: is /. */
        if(i==root_dnr)
            continue;

        /* Some historical drivers used DEVICE_TYPE_BLOCK for non-storage
         * objects.  Require a usable block geometry before exposing them in
         * the filesystem namespace. */
        if(getsize(i)<=0 || getblocksize(i)<=0)
            continue;

        if(e->device_name[0]==0 || strlen(e->device_name)>31)
            continue;
        strcpy(name, e->device_name);

        InitDW(&dw);
        if(jtmfs_ffindfile(root_dnr, name, root_db, &dw) && dw.fe!=NULL)
        {
            if(!JTMFS_TYPE_IS_DIRECTORY(dw.fe->type) ||
               jtmfs_entryIsDeleted(dw.fe))
            {
                printk("rootfs: cannot create block-device mount point '%s': name already exists and is not a directory.\n",
                       name);
                ++errors;
            }
            EndDirWalk(&dw);
            continue;
        }
        EndDirWalk(&dw);

        rv=jtmfs_CreateDirectory(root_dnr, root_db, name);
        if(rv)
        {
            printk("rootfs: cannot create block-device mount point '/%s' (mkdir rv=%d).\n",
                   name, rv);
            ++errors;
            continue;
        }
        ++created;
    }

    /* Persist the directory entries and their FAT allocations before child
     * processes inherit the root filesystem. */
    if(!jtmfat_chdev(root_dnr))
        ++errors;

    dprintk("rootfs: synchronized block-device mount points: %d created, %d error(s).\n",
            created, errors);
    return errors ? 2 : 0;
}
