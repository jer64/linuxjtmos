//
#ifndef __INCLUDED_CREATEFAT_H__
#define __INCLUDED_CREATEFAT_H__

//
int jtmfat_createfat(int dnr);;
int WriteInformationBlock(int dnr, JTMFAT_INFOBLOCK *inf);
int ReadInformationBlock(int dnr, JTMFAT_INFOBLOCK *inf);
int SetKernelChecksum(int dnr, WORD checksum);
int WriteKernel(int dnr, const void *ker);
int CopyKernel(const char *src, const char *dst);
int CopyKernelImage(const char *srcimage, const char *dst);
int DetermineBootdrv(const char *devname);
WORD DetermineKernelChecksum(BYTE *buf, int len);
JTMFAT_INFOBLOCK *BuildInfoBlock(int dnr, int bootdrv);
static int InstallBootLoader(int dnr, int bdrv);
static void BuildBootRecord(int dnr, BOOTRECORD *br, int bdrv);

#endif




