//==========================================================================
// jtmfsPath.c - JTMFS path <-> DNR/DB conversion.
// (C) 2002-2005 by Jari Tuominen.
// Path resolver rewrite 2026; physical root-device namespace V50.
//
// DNR = Device number
// DB  = Directory block number
//==========================================================================
#include "kernel32.h"
#include "jtmfat.h"
#include "jtmfs.h"
#include "root.h"
#include "jtmfsAccess.h"
#include "jtmfsPath.h"

static int copy_component(char *dst, const char *src, int len)
{
    int i;

    if(dst==NULL || src==NULL || len<=0)
        return JTMFS_PATH_EINVAL;
    if(len>JTMFS_NAME_MAX)
        return JTMFS_PATH_ETOOLONG;

    for(i=0; i<len; ++i)
        dst[i]=src[i];
    dst[len]=0;
    return JTMFS_PATH_OK;
}

static int device_root_location(int dnr, int *db)
{
    int rdb;

    if(db==NULL || !isValidDevice(dnr) || !jtmfs_isDriveReady(dnr))
        return JTMFS_PATH_EDEVICE;

    rdb=jtmfat_getrootdir(dnr);
    if(rdb<=0 || rdb>=(int)jtmfat_unitcount(dnr))
        return JTMFS_PATH_ECORRUPT;

    *db=rdb;
    return JTMFS_PATH_OK;
}

/* Return the real JTMFS location backing '/'. */
static int namespace_root_location(int *dnr, int *db)
{
    int rd, rb;

    if(dnr==NULL || db==NULL)
        return JTMFS_PATH_EINVAL;

    rd=getRootDNR();
    if(!isValidDevice(rd) || !jtmfs_isDriveReady(rd))
        return JTMFS_PATH_EDEVICE;

    rb=jtmfat_getrootdir(rd);
    if(rb<=0 || (DWORD)rb>=jtmfat_unitcount(rd))
        return JTMFS_PATH_ECORRUPT;

    *dnr=rd;
    *db=rb;
    return JTMFS_PATH_OK;
}

static int is_namespace_root(int dnr, int db)
{
    int rd, rb;

    if(namespace_root_location(&rd, &rb))
        return 0;
    return dnr==rd && db==rb;
}

/* Resolve one ordinary directory component without invoking public chdir. */
static int follow_directory(int dnr, int db, const char *name, int *next_db)
{
    DIRWALK dw;
    int block;

    if(name==NULL || next_db==NULL)
        return JTMFS_PATH_EINVAL;

    memset(&dw, 0, sizeof(dw));
    if(!jtmfs_ffindfile(dnr, name, db, &dw) || dw.fe==NULL)
        return JTMFS_PATH_ENOENT;
    if(!JTMFS_TYPE_IS_DIRECTORY(dw.fe->type) || jtmfs_entryIsDeleted(dw.fe))
        return JTMFS_PATH_ENOTDIR;

    block=(int)dw.fe->FirstDataBlock;
    if(block<=0 || block>=(int)jtmfat_unitcount(dnr))
        return JTMFS_PATH_ECORRUPT;

    *next_db=block;
    return JTMFS_PATH_OK;
}

/* Follow '..' across physical root-device mount points. */
static int follow_parent(int *dnr, int *db)
{
    int dev_root, next_db, rv;
    int root_dnr, root_db;

    if(dnr==NULL || db==NULL)
        return JTMFS_PATH_EINVAL;

    rv=namespace_root_location(&root_dnr, &root_db);
    if(rv)
        return rv;

    if(*dnr==root_dnr && *db==root_db)
        return JTMFS_PATH_OK;                    /* /.. == / */

    rv=device_root_location(*dnr, &dev_root);
    if(rv)
        return rv;

    if(*db==dev_root)
    {
        /* V62: every device owns its own pathname root.  A relative '..' at
         * hda:/ or sys:/ therefore remains at that device root.  Switching
         * devices is explicit through a leading device prefix such as
         * ram:/, sys:/ or hda:/. */
        return JTMFS_PATH_OK;
    }

    rv=follow_directory(*dnr, *db, "..", &next_db);
    if(rv)
        return rv;
    *db=next_db;
    return JTMFS_PATH_OK;
}

static int strip_device_colon(char *dst, const char *component)
{
    int len;

    if(dst==NULL || component==NULL)
        return JTMFS_PATH_EINVAL;
    len=(int)strlen(component);
    if(len<=0 || len>=JTMFS_PATH_MAX)
        return JTMFS_PATH_EINVAL;
    strcpy(dst, component);
    if(dst[len-1]==':')
        dst[len-1]=0;
    return dst[0] ? JTMFS_PATH_OK : JTMFS_PATH_EDEVICE;
}

static int has_device_colon(const char *component)
{
    int len;
    if(component==NULL) return 0;
    len=(int)strlen(component);
    return len>0 && component[len-1]==':';
}

/* Return canonical device number for a device-name component, or -1. */
static int lookup_device_component(const char *component)
{
    char devname[JTMFS_PATH_MAX];

    if(strip_device_colon(devname, component))
        return -1;
    return driver_getdevicenrbyname(devname);
}

/*
 * Pure pathname resolver.  The namespace root is a real JTMFS root device
 * (normally ram:).  Root-level directories named after block devices are
 * mount points.  If the target device is not JTMFS-ready yet, its physical
 * placeholder directory on the root filesystem remains accessible.
 */
int jtmfsResolvePathAt(int start_dnr, int start_db,
                       const char *path, int *dnr, int *db)
{
    char component[JTMFS_PATH_MAX];
    int cur_dnr, cur_db;
    int i, begin, len, first_component, rv, next_db, dev;
    int root_dnr, root_db, at_root, explicit_device;
    int legacy_namespace_absolute;

    if(path==NULL || dnr==NULL || db==NULL || !isValidString(path))
        return JTMFS_PATH_EINVAL;
    if(strlen(path)>=(size_t)JTMFS_PATH_MAX)
        return JTMFS_PATH_ETOOLONG;

    rv=namespace_root_location(&root_dnr, &root_db);
    if(rv)
        return rv;

    legacy_namespace_absolute=(path[0]=='/');

    if(legacy_namespace_absolute)
    {
        /* Compatibility: old JTMOS paths such as /hda/bin are still
         * accepted.  New code should prefer hda:/bin. */
        cur_dnr=root_dnr;
        cur_db=root_db;
    }
    else if(isValidDevice(start_dnr) && start_db>0 &&
            jtmfs_isDriveReady(start_dnr))
    {
        cur_dnr=start_dnr;
        cur_db=start_db;
    }
    else
    {
        /* A newly created kernel/service thread without a CWD starts from /. */
        cur_dnr=root_dnr;
        cur_db=root_db;
    }

    i=0;
    first_component=1;
    while(path[i])
    {
        while(path[i]=='/') ++i;
        if(!path[i]) break;

        begin=i;
        while(path[i] && path[i]!='/') ++i;
        len=i-begin;
        rv=copy_component(component, path+begin, len);
        if(rv) return rv;

        if(!strcmp(component, "."))
        {
            first_component=0;
            continue;
        }
        if(!strcmp(component, ".."))
        {
            rv=follow_parent(&cur_dnr, &cur_db);
            if(rv) return rv;
            first_component=0;
            continue;
        }

        at_root=(cur_dnr==root_dnr && cur_db==root_db);
        explicit_device=has_device_colon(component);
        dev=-1;

        /* V62 pathname rule:
         *   hda:/dir   explicit device-absolute path
         *   sys:/      explicit device root
         *   dir/file   relative to the current device/CWD
         *
         * Keep /hda/... as a compatibility spelling only when the path itself
         * began with '/'.  A plain first component named "hda" is now an
         * ordinary relative directory name, as requested by the public API. */
        if(explicit_device || (legacy_namespace_absolute && at_root))
            dev=lookup_device_component(component);

        if(dev>=0 && isValidDevice(dev) && jtmfs_isDriveReady(dev))
        {
            rv=device_root_location(dev, &next_db);
            if(rv) return rv;
            cur_dnr=dev;
            cur_db=next_db;
        }
        else
        {
            if(explicit_device && dev>=0)
                return JTMFS_PATH_EDEVICE;

            /* If a raw/unformatted block device has a placeholder directory
             * under /, simply enter that directory on the root filesystem. */
            rv=follow_directory(cur_dnr, cur_db, component, &next_db);
            if(rv) return rv;
            cur_db=next_db;
        }

        first_component=0;
    }

    *dnr=cur_dnr;
    *db=cur_db;
    return JTMFS_PATH_OK;
}

int resolvePath(const char *path, int *dnr, int *db)
{
    return jtmfsResolvePathAt(GetCurrentDNR(), GetCurrentDB(),
                              path, dnr, db);
}

int resolveFileNamePath(const char *filepath,
                        int *dnr, int *db,
                        RESOLVE *r)
{
    int len, slash, colon, i, parent_len, name_start, rv;
    int start_dnr, start_db, out_dnr, out_db;
    int root_dnr, root_db;

    if(filepath==NULL || dnr==NULL || db==NULL || r==NULL ||
       !isValidString(filepath))
        return JTMFS_PATH_EINVAL;

    len=(int)strlen(filepath);
    if(len<=0)
        return JTMFS_PATH_EINVAL;
    if(len>=JTMFS_PATH_MAX)
        return JTMFS_PATH_ETOOLONG;

    memset(r, 0, sizeof(*r));
    start_dnr=*dnr;
    start_db=*db;
    if(!isValidDevice(start_dnr) || start_db<=0 ||
       !jtmfs_isDriveReady(start_dnr))
    {
        start_dnr=GetCurrentDNR();
        start_db=GetCurrentDB();
    }
    if(!isValidDevice(start_dnr) || start_db<=0 ||
       !jtmfs_isDriveReady(start_dnr))
    {
        rv=namespace_root_location(&root_dnr, &root_db);
        if(rv) return rv;
        start_dnr=root_dnr;
        start_db=root_db;
    }

    if(filepath[len-1]=='/')
        return JTMFS_PATH_EINVAL;

    slash=-1;
    colon=-1;
    for(i=0; i<len; ++i)
    {
        if(filepath[i]=='/') slash=i;
        if(filepath[i]==':' && colon<0) colon=i;
    }

    if(slash>=0)
    {
        name_start=slash+1;
        parent_len=slash;
        if(slash==0)
        {
            r->path[0]='/';
            r->path[1]=0;
        }
        else
        {
            if(parent_len>=JTMFS_PATH_MAX)
                return JTMFS_PATH_ETOOLONG;
            for(i=0; i<parent_len; ++i)
                r->path[i]=filepath[i];
            r->path[parent_len]=0;
        }
    }
    else if(colon>=0)
    {
        if(colon==0 || colon>=JTMFS_PATH_MAX-1)
            return JTMFS_PATH_EINVAL;
        for(i=0; i<=colon; ++i)
            r->path[i]=filepath[i];
        r->path[colon+1]=0;
        name_start=colon+1;
    }
    else
    {
        r->path[0]=0;
        name_start=0;
    }

    if(!filepath[name_start])
        return JTMFS_PATH_EINVAL;
    if((len-name_start)>JTMFS_NAME_MAX)
        return JTMFS_PATH_ETOOLONG;

    strcpy(r->name, filepath+name_start);
    if(!strcmp(r->name, ".") || !strcmp(r->name, ".."))
        return JTMFS_PATH_EINVAL;

    if(r->path[0])
    {
        rv=jtmfsResolvePathAt(start_dnr, start_db,
                              r->path, &out_dnr, &out_db);
        if(rv) return rv;
        *dnr=out_dnr;
        *db=out_db;
    }
    else
    {
        *dnr=start_dnr;
        *db=start_db;
    }

    return JTMFS_PATH_OK;
}

static int prepend_component(char *work, const char *name)
{
    char tmp[JTMFS_PATH_MAX];
    int need;

    if(work==NULL || name==NULL || !name[0])
        return JTMFS_PATH_EINVAL;

    need=(int)strlen(name)+(int)strlen(work)+2;
    if(need>JTMFS_PATH_MAX)
        return JTMFS_PATH_ETOOLONG;

    strcpy(tmp, "/");
    strcat(tmp, name);
    strcat(tmp, work);
    strcpy(work, tmp);
    return JTMFS_PATH_OK;
}

/* Convert a real DNR/DB directory location back to canonical JTMOS path. */
int jtmfsBuildPath(int dnr, int db, char *path, int max_len)
{
    char work[JTMFS_PATH_MAX];
    char name[JTMFS_PATH_MAX];
    char devname[JTMFS_PATH_MAX];
    char result[JTMFS_PATH_MAX];
    DIRWALK dw;
    int dev_root, cur_db, parent_db;
    int limit, rv, root_dnr, root_db;

    if(path==NULL || max_len<=0)
        return JTMFS_PATH_EINVAL;

    rv=namespace_root_location(&root_dnr, &root_db);
    if(rv)
        return rv;

    /* Treat a legacy/uninitialized 0/0 location as the current namespace
     * root, but still return the V62 canonical device-qualified spelling. */
    if(dnr==0 && db==0)
    {
        dnr=root_dnr;
        db=root_db;
    }

    if(!isValidDevice(dnr) || !jtmfs_isDriveReady(dnr) || db<=0)
        return JTMFS_PATH_EINVAL;

    rv=device_root_location(dnr, &dev_root);
    if(rv) return rv;

    work[0]=0;
    cur_db=db;
    for(limit=0; limit<128 && cur_db!=dev_root; ++limit)
    {
        if(jtmfs_GetDirName(dnr, cur_db, name) || !name[0] ||
           !strcmp(name, "/"))
            return JTMFS_PATH_ECORRUPT;
        rv=prepend_component(work, name);
        if(rv) return rv;

        memset(&dw, 0, sizeof(dw));
        if(!jtmfs_ffindfile(dnr, "..", cur_db, &dw) || dw.fe==NULL ||
           !JTMFS_TYPE_IS_DIRECTORY(dw.fe->type))
            return JTMFS_PATH_ECORRUPT;

        parent_db=(int)dw.fe->FirstDataBlock;
        if(parent_db<=0 || parent_db>=(int)jtmfat_unitcount(dnr) || parent_db==cur_db)
            return JTMFS_PATH_ECORRUPT;
        cur_db=parent_db;
    }

    if(cur_db!=dev_root)
        return JTMFS_PATH_ECORRUPT;

    /* V62 canonical CWD is always device-qualified, including the root
     * device: ram:/, sys:/, hda:/dir, ... .  This makes getcwd() unambiguous
     * and lets SMSH display exactly which block device owns the directory. */
    if(driver_getdevicename(dnr, devname)==NULL || !devname[0])
        return JTMFS_PATH_EDEVICE;
    if((int)strlen(devname)+(int)strlen(work)+3>=JTMFS_PATH_MAX)
        return JTMFS_PATH_ETOOLONG;

    strcpy(result, devname);
    strcat(result, ":");
    if(work[0]==0)
        strcat(result, "/");
    else
        strcat(result, work);

    if((int)strlen(result)>=max_len)
        return JTMFS_PATH_ETOOLONG;
    strcpy(path, result);
    return JTMFS_PATH_OK;
}
