#ifndef __INCLUDED_JTMFSPATH_H__
#define __INCLUDED_JTMFSPATH_H__

/*
 * JTMFS pathname resolver.
 *
 * A JTMOS directory location is identified by two values:
 *   DNR = block device number
 *   DB  = directory block number on that device
 *
 * Path resolution must not alter the calling thread's current DNR/DB.
 */
#define JTMFS_PATH_MAX 256
#define JTMFS_NAME_MAX 31

#define JTMFS_PATH_OK            0
#define JTMFS_PATH_EINVAL        1
#define JTMFS_PATH_ENOENT        2
#define JTMFS_PATH_ENOTDIR       3
#define JTMFS_PATH_ETOOLONG      4
#define JTMFS_PATH_EDEVICE       5
#define JTMFS_PATH_ECORRUPT      6

typedef struct
{
    char name[JTMFS_PATH_MAX];
    char path[JTMFS_PATH_MAX];
} RESOLVE;

/* Resolve a directory path starting from an explicit DNR/DB. */
int jtmfsResolvePathAt(int start_dnr, int start_db,
                       const char *path, int *dnr, int *db);

/* Resolve a directory path relative to the calling thread's CWD. */
int resolvePath(const char *path, int *dnr, int *db);

/*
 * Split filepath into parent path + final name and resolve the parent.
 * On success *dnr/*db identify the directory containing r->name.
 * Returns JTMFS_PATH_OK on success, non-zero on error.
 */
int resolveFileNamePath(const char *filepath,
                        int *dnr, int *db,
                        RESOLVE *r);

/* Convert an actual DNR/DB directory location back to a canonical path. */
int jtmfsBuildPath(int dnr, int db, char *path, int max_len);

#endif
