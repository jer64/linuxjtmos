/*
 * ===========================================================
 * JTMFS FILE SYSTEM - Add blocks for a dir entry
 * (C) 2002-2003 by Jari Tuominen
 * ===========================================================
 */
//
#include "sysmem.h"
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
// ---- #include "fileapi.h"
#include "ramdisk.h"
#include "jtmfs.h"
#include "fswalk.h"
#include "fsaddblocks.h"
#include "diskspace.h"

// jtmfs_add_blocks_for_entry
//
// new: now checks for available space,
// if it is insufficient, we'll just
// return an error, a non-zero value.
//
int jtmfs_add_blocks_for_entry(int device_nr,
        char *fname, int dblock, int amount)
{
    DIRWALK dw;
    DWORD old_first,old_last,new_first,work_last;
    int old_length,remaining,new_block,allocated,rv,bs;

    if(!isValidDevice(device_nr) || fname==NULL || amount<=0 ||
       (DWORD)amount>=jtmfat_unitcount(device_nr))
        return 10;
    bs=(int)jtmfat_unitsize(device_nr);
    if(bs<=0) return 10;

    InitDW(&dw);
    if(!jtmfs_ffindfile(device_nr,fname,dblock,&dw))
        return 1;

    old_first=dw.fe->FirstDataBlock;
    old_last=dw.fe->LastDataBlock;
    old_length=dw.fe->length;
    new_first=0;
    work_last=old_last;
    allocated=0;
    remaining=amount;

    if(old_first==0)
    {
        new_block=(int)jtmfat_reserveblock(device_nr);
        if(new_block==-1)
        {
            EndDirWalk(&dw);
            return JTMFS_RESERVE_NOSPC;
        }
        if(new_block<=0 || (DWORD)new_block>=jtmfat_unitcount(device_nr) ||
           !jtmfat_isallocatableblock(device_nr,(DWORD)new_block))
        {
            dprintk("jtmfs_add_blocks_for_entry: allocator fault dnr=%d rv=%d.\n",
                    device_nr,new_block);
            EndDirWalk(&dw);
            return 10;
        }
        new_first=(DWORD)new_block;
        work_last=(DWORD)new_block;
        allocated=1;
        remaining--;
    }
    else
    {
        if(old_first==0 || old_first>=jtmfat_unitcount(device_nr) ||
           !jtmfat_isdatablock(device_nr,old_first) ||
           old_last==0 || old_last>=jtmfat_unitcount(device_nr) ||
           !jtmfat_isdatablock(device_nr,old_last) ||
           (DWORD)jtmfat_getblock(device_nr,(int)old_last)<0xFFFFFFF8UL)
        {
            EndDirWalk(&dw);
            return 13;
        }
    }

    while(remaining>0)
    {
        new_block=jtmfs_expandchain(device_nr,(int)work_last);
        if(new_block<=0)
        {
            int err=(new_block==-ENOSPC) ? JTMFS_RESERVE_NOSPC : 10;
            /* Roll back extensions before publishing any new directory
             * metadata.  Existing files regain their original EOF tail; new
             * files simply release the private chain that was never visible. */
            if(old_first!=0 && new_first!=0)
            {
                (void)jtmfat_setblock(device_nr,(int)old_last,(int)0xFFFFFFF8UL);
                (void)jtmfs_deletechain(device_nr,(int)new_first);
            }
            else if(old_first==0 && new_first!=0)
                (void)jtmfs_deletechain(device_nr,(int)new_first);
            EndDirWalk(&dw);
            return err;
        }
        if(new_first==0) new_first=(DWORD)new_block;
        work_last=(DWORD)new_block;
        allocated++;
        remaining--;
    }

    /* FAT transaction is complete.  Publish all directory metadata once. */
    if(old_first==0) dw.fe->FirstDataBlock=new_first;
    dw.fe->LastDataBlock=work_last;
    dw.fe->length=old_length + allocated*bs;
    rv=jtmfs_ffwritelocation(device_nr,&dw);
    EndDirWalk(&dw);
    if(rv) return 11;
    return 0;
}



/*
 * Ensure that a file owns at least required_blocks FAT nodes without making
 * any additional bytes visible.  The old jtmfs_add_blocks_for_entry() also
 * grows dw.fe->length, which is useful for the historical allocation API but
 * wrong for streamed writes: it can expose unwritten/stale cluster bytes and
 * forces a later truncate-style SetSize() pass.
 *
 * Caller: jtmfs_WriteFile() holds the per-volume mutation lock.
 * Crash ordering: reserve/link the hidden FAT extension first, then publish
 * FirstDataBlock/LastDataBlock while preserving the exact old byte length.
 */
int jtmfs_reserve_blocks_for_write(int device_nr,
        char *fname, int dblock, int required_blocks)
{
    DIRWALK dw;
    DWORD old_first,old_dir_last,actual_last,block,next,new_first,work_last;
    JTMOS_DISKSPACE_STATS space;
    int have,count,remaining,new_block,rv,old_length;

    if(!isValidDevice(device_nr) || fname==NULL || required_blocks<=0 ||
       (DWORD)required_blocks>=jtmfat_unitcount(device_nr))
        return 10;

    InitDW(&dw);
    if(!jtmfs_ffindfile(device_nr,fname,dblock,&dw) || dw.fe==NULL)
        return 1;

    old_first=dw.fe->FirstDataBlock;
    old_dir_last=dw.fe->LastDataBlock;
    old_length=dw.fe->length;
    actual_last=0;
    have=0;

    if(old_first!=0)
    {
        block=old_first;
        for(count=0; count<(int)jtmfat_unitcount(device_nr); count++)
        {
            if(!jtmfat_isdatablock(device_nr,block)) {
                EndDirWalk(&dw);
                return 13;
            }
            have++;
            next=(DWORD)jtmfat_getblock(device_nr,(int)block);
            if(next>=0xFFFFFFF8UL) {
                actual_last=block;
                break;
            }
            if(next==0 || next>=0xFFFFFFF0UL ||
               next>=jtmfat_unitcount(device_nr) || next==block ||
               !jtmfat_isdatablock(device_nr,next)) {
                EndDirWalk(&dw);
                return 13;
            }
            block=next;
        }
        if(actual_last==0) {
            EndDirWalk(&dw);
            return 13;
        }
    }

    if(have>=required_blocks)
    {
        /* Repair only the cheap last-block hint; never alter visible length. */
        if(have>0 && old_dir_last!=actual_last) {
            dw.fe->LastDataBlock=actual_last;
            if(jtmfs_ffwritelocation(device_nr,&dw)) {
                dw.fe->LastDataBlock=old_dir_last;
                EndDirWalk(&dw);
                return 11;
            }
        }
        EndDirWalk(&dw);
        return 0;
    }

    remaining=required_blocks-have;
    new_first=0;
    work_last=actual_last;

    /* Cheap ENOSPC preflight.  Once initialized, DiskSpaceFatTransition()
     * keeps free_units synchronized with FAT allocation/free transitions.
     * We still keep the transactional allocator rollback below as the final
     * authority in case another path changes space unexpectedly. */
    if(DiskSpaceGetStats(device_nr,&space,0)==0 &&
       (space.flags&DISKSPACE_FLAG_JTMFS) &&
       space.free_units<(DWORD)remaining)
    {
        dprintk("JTMFS/ENOSPC preflight dnr=%d need_units=%d free_units=%u unit=%u.\n",
                device_nr,remaining,(unsigned)space.free_units,(unsigned)space.unit_size);
        EndDirWalk(&dw);
        return JTMFS_RESERVE_NOSPC;
    }

    while(remaining>0)
    {
        new_block=(int)jtmfat_reserveblock(device_nr);
        if(new_block==-1) { rv=JTMFS_RESERVE_NOSPC; goto rollback_code; }
        if(new_block<=0 || (DWORD)new_block>=jtmfat_unitcount(device_nr) ||
           !jtmfat_isallocatableblock(device_nr,(DWORD)new_block))
            goto rollback;

        if(new_first==0) new_first=(DWORD)new_block;
        if(work_last!=0 && jtmfat_setblock(device_nr,(int)work_last,new_block))
        {
            (void)jtmfat_setblock(device_nr,new_block,0);
            goto rollback;
        }
        work_last=(DWORD)new_block;
        remaining--;
    }

    if(old_first==0) dw.fe->FirstDataBlock=new_first;
    dw.fe->LastDataBlock=work_last;
    dw.fe->length=old_length;
    rv=jtmfs_ffwritelocation(device_nr,&dw);
    if(rv==0) {
        EndDirWalk(&dw);
        return 0;
    }

    dw.fe->FirstDataBlock=old_first;
    dw.fe->LastDataBlock=old_dir_last;
    dw.fe->length=old_length;

rollback:
    rv=10;
rollback_code:
    if(old_first!=0 && new_first!=0) {
        (void)jtmfat_setblock(device_nr,(int)actual_last,(int)0xFFFFFFF8UL);
        (void)jtmfs_deletechain(device_nr,(int)new_first);
    } else if(old_first==0 && new_first!=0) {
        (void)jtmfs_deletechain(device_nr,(int)new_first);
    }
    EndDirWalk(&dw);
    return rv;
}
