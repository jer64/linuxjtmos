
#ifndef __INCLUDED_JTMFAT_H__
#define __INCLUDED_JTMFAT_H__

/* Legacy JTMFS system-area BYTE layout.
 * FAT_INFO_BYTE_OFFS is deliberately a byte offset, not a DEVAPI block.
 * Convert it to block+offset with getblocksize(dnr) on every device. */
#include "../../../boot_storage_layout.h"

#define JTMFS_BOOT_RECORD_BYTES JTMOS_BOOT_SECTOR_BYTES
#define FAT_INFO_BYTE_OFFS      512
/* Source compatibility only; new code should use FAT_INFO_BYTE_OFFS. */
#define FAT_INFO_BLOCK_OFFS     FAT_INFO_BYTE_OFFS
#define FAT_BOOT_SECTION_LEN_K  32

/* V16.77 partitioned-HDD boot contract. Sector 0 is a standard MBR:
 * boot code 0..445, primary partition table 446..509, signature 510..511.
 * The boot32 runtime metadata therefore lives at LBA3 in the reserved area. */
#define JTMFS_MBR_BOOTCODE_BYTES          446
#define JTMFS_MBR_PARTITION_BYTE_OFFS     446
#define JTMFS_MBR_PARTITION_BYTES         64
#define JTMFS_BOOT_TRACK_SECTORS          JTMOS_FLOPPY_LOADER_SECTORS /* compatibility alias */
#define JTMFS_BOOT_RUNTIME_BYTE_OFFS      (3UL*512UL)
#define JTMFS_BOOT_RUNTIME_MAGIC          0x32424D4AUL /* "JMB2" little endian */
#define JTMFS_BOOT_RUNTIME_CHECKSUM_OFFS  (JTMFS_BOOT_RUNTIME_BYTE_OFFS+4UL)

/* Legacy whole-disk bootable-JTMFS contract. This is intentionally separate
 * from the partitioned-HDD pre-partition layout above. Whole-disk JTMFS keeps
 * its historical 32 KiB prefix + 1 MiB kernel reservation inside the volume. */
#define JTMFS_KERNEL_RESERVE_K      1024
#define JTMFS_KERNEL_RESERVE_BYTES  (1024UL*1024UL)
#define KERNEL_LEN_K                JTMFS_KERNEL_RESERVE_K

/* res3/res4 in JTMFAT_INFOBLOCK advertise the current boot-layout contract.
 * Geometry remains authoritative so old filesystems with zeroed reserved
 * fields are still readable; installers require >= 1 MiB capacity. */
#define JTMFS_BOOT_LAYOUT_TAG       0x4B314D4AUL /* "JM1K" little endian */
#define JTMFS_BOOT_LAYOUT_VERSION   2UL

/* V16.24 clustered allocation layout.  This is independent of the boot-layout
 * tag: a partition such as hda1 is normally not a BIOS boot device but still
 * needs clustered allocation on a large volume.  Legacy volumes have res6==0/1.
 * Clustered volumes advertise res5>=JTMFS_CLUSTER_LAYOUT_VERSION, store the
 * number of DEVAPI blocks per allocation unit in res6, and the first physical
 * data LBA in res7.  FAT links/file FirstDataBlock values are allocation-unit
 * IDs (root=1, first ordinary allocation=2). */
#define JTMFS_CLUSTER_LAYOUT_VERSION 2UL
#define JTMFS_CLUSTER_MAX_SECTORS    64UL /* 32 KiB on 512-byte media */

/* V68.143 lazy-zero FAT format.
 *
 * mkfs no longer writes and verifies the complete FAT.  On new volumes only
 * the physically materialized FAT-sector prefix is authoritative; sectors
 * beyond that prefix are logically all-zero/FREE until first allocation.
 * fatChecksum32 was historically unused/unreliable, so format version >=3
 * repurposes it as a lazy-FAT state word without changing the on-disk
 * JTMFAT_INFOBLOCK size or moving boot-loader bytes:
 *   bit31      = lazy-zero FAT enabled
 *   bits0..30  = number of physically materialized FAT sectors from fat_offs.
 */
#define JTMFS_LAZY_FAT_LAYOUT_VERSION 3UL
#define JTMFS_LAZY_FAT_FLAG           0x80000000UL
#define JTMFS_LAZY_FAT_PAGE_MASK      0x7FFFFFFFUL

// Enable new FLEXFAT system.
#define FLEXFAT

//
#define jtmfat_getrootdir(x) _jtmfat_getrootdir(__FUNCTION__, x)

// Remove remarks from the defination below
// if you want to enable strict perfection -option.
// This option will cause panics on some concurrent
// problems, rather than trying to fix these.
//// #define STRICT_PERFECTION

// When formatting a drive, this is a max. value of how many
// times the progress indicator status must be updated.
// 100 means 100 times, this means update on every % increase.
// (obsolete)
#define INDICATOR_RADIUS        100

// Safe guard line that is REQUIRED!
// Recommanded: 1024*8 (8K)
#define FAT_SAFEGUARD		1024*512
// Contains roadmap for the FAT table.
#define L_ROADMAP		getsize(dnr)
// Contains cache 32-bit FAT table(4 bytes per entry):
#define L_FATCACHE		getsize(dnr)*4
// Contains CFAT structures for max. X different devices(X=value below).
#define N_CFAT_STRUCTURES	100

//
//#define JTMFAT_ALLOWTEXTS
// Uncomment this out if you want warnings/etc messages to be shown too.
//#define __DJTMFAT__

//
#include "basdef.h"
#include "devapi.h"

//
typedef struct
{
	// 11 bytes: (512-11 = 501)

	// Kernel 16-bit checksum.
	WORD correct_kernel_checksum;
	// Boot section length(offset to kernel on drive).
	WORD boot_len_k;
	// CHS settings.
	WORD cylinders;
	BYTE heads;
	BYTE sectors;
	// BIOS boot drive.
	BYTE bootdrv;
	// Boot record signature.
	// (0x55AA)
	WORD signature;
}BOOTRECORD;

// 48 bytes bootblock,
// res1,res2 = will contain sufficient space for the ASM jump instruction
// which will jump past the description information, to the code
// beginning after res7.
//
// New rule:
// Offsets now mean block numbers,
// aka block offset.
// length = length in blocks
//
typedef struct
{
	// First eight bytes are reserved(res1,res2 DWORDs).
	DWORD res1,res2;
	// Boot drive (0=floppy A:, 1=floppy B:, 0x80=drive C:, 0x81=drive D:).
	BYTE bootdrv;
	// Detection string: "JTMFS",0
	char detstr[6];
	// Offset to FAT and data area.
	DWORD fat_offs;
	DWORD data_offs;
	DWORD kernel_offs;	// 0 if no kernel featured.
	/* Geometry offsets/lengths are DEVAPI logical blocks; one block is
	 * getblocksize(dnr) bytes for this filesystem. */
	DWORD sysarea_length;
	// System area before the data area,
	// system area is:
	// A) boot block B) info block C) FAT (in bytes)
	DWORD fat_length; // (blocks)
	// sysarea_length.
	DWORD bootblock_size; // (blocks)
	// DEVICE SPECIFIC.
	DWORD n_blocks,block_size;
	/* Historical FAT checksum field.  On layout version >=3 it stores the
	 * JTMFS_LAZY_FAT_FLAG + materialized FAT-sector prefix instead. */
	DWORD fatChecksum32;
	// Max. value allowed on FAT table.
	int max_val;
	/* Reserved-layout metadata:
	 *   res3/res4 = optional boot-layout tag + kernel reservation bytes.
	 *   res5      = on-disk layout version (>=2 means clustered when res6>1).
	 *   res6/res7 = cluster sectors + physical data-LBA for clustered volumes.
	 * Old volumes normally contain zero here. */
	DWORD res3,res4,res5,res6,res7;
}JTMFAT_INFOBLOCK;

//
typedef struct
{
	char isActive;

	//
	DWORD *buf;
	int l_buf;

	//
	BYTE *actual;
	int l_actual;

	//
	char *roadMap;	// Info about which block has changed
	int l_roadMap;

	//
	int requiresFlush;
}CFAT;

//
typedef struct
{
	// Is drive removable?
	char isRemovable;
	// Last time when boot block was reloaded.
	int t;
}BOOTINF;

//
typedef struct
{
	// This is a new device? We have to load information of it,
	// where fat is located, how big it is, how big the device is, etc..
	// (This variable is set to non-zero usually by jtmfat_chdev)
	int virgin;
	// device number
	int dnr;
	// the bootblock, which contains all information
	// jtmfat_chdev will reload new bootblock to this structure.
	JTMFAT_INFOBLOCK *bb[100]; // << 100 is max. devices now !!!! (2)
	// This device have been formatted to JTMFS? 0=Nope, 1=Yes
	int isJTMFS[100]; // << 100 is max. devices now !!!! (1)
	// Boot block information.
	BOOTINF bootinf[100];
	// Temporary buffer, used for various purposes,
	// f.e. for storing a piece of fat table.
	BYTE *tmpbuf,*tbuf;

	// FAT structures.
	CFAT **fat;

	//
	BYTE *all_cfat_structures;
 //
}JTMFATSYS;

//
int _jtmfat_chdev(const char *caller, long dnr);
//
#define jtmfat_chdev(x) _jtmfat_chdev(__FUNCTION__, x)

//
int jtmfat_getrootdir1(int dnr);
int _jtmfat_getrootdir(const char *caller, int dnr);
int _jtmfat_loadinfoblock(const char *caller, int dnr);
//
#define jtmfat_loadinfoblock(x) \
	_jtmfat_loadinfoblock(__FUNCTION__, x)

//
#define jtmfat_getblock(dnr, db) \
	_flexFatGetBlock(__FUNCTION__, dnr, db)
#define jtmfat_setblock(dnr, which, what) \
	_flexFatSetBlock(__FUNCTION__, dnr,which,what)

//
long jtmfat_isJTMFS(int dnr);
void jtmfat_flushfatcache(void);
long jtmfat_getblocksallocated(long dnr);
long jtmfat_getblocksfree(long dnr);
long jtmfat_getfreeblock(long dnr);
/* Atomically locate and reserve one free allocation unit as a standalone EOC.
 * Runtime writers must use this instead of locator-only jtmfat_getfreeblock(). */
long jtmfat_reserveblock(long dnr);
/* Hard filesystem/system-area boundary.  File and directory chains may use
 * the root block itself, or blocks at/after sysarea_length; they must never
 * enter boot loader, kernel payload or FAT storage. */
int jtmfat_isdatablock(int dnr, DWORD block);
int jtmfat_isallocatableblock(int dnr, DWORD block);
DWORD jtmfat_firstallocatableblock(int dnr);
/* Allocation-unit/cluster helpers.  Old volumes transparently return
 * sector-sized units and identity LBA mapping. */
int jtmfat_infoblock_uses_clusters(const JTMFAT_INFOBLOCK *inf);
int jtmfat_infoblock_uses_lazyfat(const JTMFAT_INFOBLOCK *inf);
DWORD jtmfat_lazyfat_materialized_pages(const JTMFAT_INFOBLOCK *inf);
int jtmfat_lazyfat_set_materialized_pages(int dnr, DWORD pages);
int jtmfat_isclustered(int dnr);
DWORD jtmfat_clustersectors(int dnr);
DWORD jtmfat_unitcount(int dnr);
DWORD jtmfat_unitsize(int dnr);
DWORD jtmfat_unit_to_lba(int dnr, DWORD unit);
int write_fat(int dnr);
int read_fat(int dnr);
int jtmfat_deactivateFatDNR(int dnr);

#define USE_DEBUGTRAP   char __str[255];
/*#define DEBUGTRAP       strcpy(__str, __FUNCTION__); \
DebugTrap(dnr, __str);*/

#define DEBUGTRAP	DebugTrap(dnr, __FUNCTION__);

//
JTMFAT_INFOBLOCK *jtmfat_getinfoblock(int dnr);
int jtmfat_info_location(int dnr, int *block_nr, int *byte_offs);
int jtmfat_validateinfoblock(int dnr, const JTMFAT_INFOBLOCK *inf);
void jtmfat_dumpgeometry(int dnr);
void jtmfat_DiskChange(int dnr);

//
extern int jtmfat_ready;
extern JTMFATSYS *fatsys;

//
#endif

