// mount.c - JTMFS block-device mount helpers
// (C) 2003-2026 Jari Tuominen
#include "kernel32.h"
#include "jtmfs.h"
#include "root.h"
#include "mount.h"
#include "filedes.h"

/*
 * JTMOS does not yet have a Unix VFS mount table.  A JTMFS-ready block device
 * becomes reachable by its device-name component in jtmfsPath.c.  Therefore
 * "busy" means that invalidating the filesystem would leave a live kernel
 * reference behind: namespace root, a process CWD, or an open descriptor.
 */
int jtmfs_device_busy(int dnr)
{
    int i;

    if(!isValidDevice(dnr))
        return 0;

    if(getRootDNR()==dnr && jtmfs_isDriveReady(dnr) && getRootDB()>0)
        return 1;

    for(i=0; i<N_MAX_THREADS; ++i)
    {
        if(thread_states[i] && (int)thread_dnr[i]==dnr)
            return 1;
    }

    if(fddb.fd!=NULL)
    {
        for(i=0; i<fddb.amount && i<N_MAX_FD; ++i)
        {
            FILEDES *f=fddb.fd[i];
            if(f!=NULL && !f->isFree && f->dnr==dnr)
                return 1;
        }
    }

    return 0;
}

int mountDNR(int dnr)
{
    int r;

    if(!isValidDevice(dnr))
        return 1;

    /* V67.8.56.12: driver_mountDNR() now flushes dirty block cache before
     * invalidating it.  Propagate that result: announcing DiskChange after a
     * failed flush would discard filesystem cache state and can turn a
     * recoverable writeback error into lost directory/FAT updates. */
    r=driver_mountDNR(dnr);
    if(r)
    {
        printk("mountDNR: device %d mount/flush failed (%d); preserving filesystem caches.\n",dnr,r);
        return r;
    }

    DiskChange(dnr);
    return 0;
}

int unmountDNR(int dnr)
{
    int r;

    if(!isValidDevice(dnr))
        return 1;
    if(jtmfs_device_busy(dnr))
        return 2;

    /* V67.8.56.12: the old order called DiskChange() first.  That can discard
     * FlexFAT pages before driver_unmountDNR() ever sees them.  Commit all
     * filesystem metadata first, then close the device, then discard only
     * clean cache state. */
    if(jtmfs_isDriveReady(dnr) && syncdev(dnr)!=0)
    {
        printk("unmountDNR: filesystem sync failed for device %d; keeping it mounted.\n",dnr);
        return 3;
    }

    r=driver_unmountDNR(dnr);
    if(r)
        return 4;

    DiskChange(dnr);
    return 0;
}
