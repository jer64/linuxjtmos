#ifndef __INCLUDED_JTMFS_INTEGRITY_H__
#define __INCLUDED_JTMFS_INTEGRITY_H__

#include "basdef.h"

typedef struct
{
    DWORD blocks_total;
    DWORD block_size;
    DWORD fat_free;
    DWORD fat_reserved;
    DWORD fat_links;
    DWORD fat_eoc;
    DWORD fat_invalid;
    DWORD reachable_blocks;
    DWORD orphan_blocks;
    DWORD directories;
    DWORD files;
    DWORD entries;
    DWORD deleted_entries;
    DWORD bad_entries;
    DWORD bad_chains;
    DWORD crosslinks;
    DWORD size_mismatches;
    DWORD io_errors;
} JTMFS_CHECK_REPORT;

/*
 * Read-only, media-backed JTMFS consistency check.
 *
 * The checker deliberately uses readblock1() for filesystem structures so a
 * successful result describes the medium itself rather than DIRDB/FlexFAT or
 * the generic block cache.  Call syncdev(dnr) first if dirty data is expected.
 *
 * Return 0 when no structural error was found, non-zero otherwise.
 */
int jtmfs_check_device(int dnr, int verbose, JTMFS_CHECK_REPORT *report);

#endif
