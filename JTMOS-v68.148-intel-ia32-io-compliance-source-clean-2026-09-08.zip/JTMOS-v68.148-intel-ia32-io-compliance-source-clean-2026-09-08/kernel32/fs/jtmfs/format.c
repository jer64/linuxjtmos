/////////////////////////////////////////////////////////////////////////////////////////
// format.c
/////////////////////////////////////////////////////////////////////////////////////////
#include "kernel32.h"
#include "jtmfs.h"
#include "jtmfat.h"
#include "flexFat.h"
#include "format.h"
#include "dirdbAccess.h"

//-----------------------------------------------------------------------------------------
// What it does do :
//	- Creates an empty FAT
//	- Reserves system area on FAT
//	- Creates a basic root directory
int jtmfs_formatdrive(int device_nr)
{
	int nr_blocks,blocksize,r;
	char str[100];

retry:
	//----------------------------------------------------
	if(!isValidDevice(device_nr))
	{
		dprintk("%s/%s/line %d: Invalid device #%d.\n",
			__FUNCTION__,
			__FILE__,
			__LINE__,
			device_nr);
		return 10;
	}

	//----------------------------------------------------
	/* Formatting is a media replacement operation, not a normal DiskChange().
	 * DiskChange() calls jtmfat_chdev(), which reloads/validates the OLD info
	 * block.  On a blank/non-JTMFS disk that means detstr=ff.. and, worse, can
	 * reactivate stale geometry while mkfs is about to replace it.
	 *
	 * Drain old metadata only when the current medium is known JTMFS, then
	 * invalidate every cache layer WITHOUT trying to reload the old filesystem. */
	if(fatsys!=NULL && device_nr>=0 && device_nr<N_CFAT_STRUCTURES &&
	   fatsys->isJTMFS[device_nr])
	{
		if(dirdbFlushDNR(device_nr)!=0)
		{
			dprintk("%s: pre-format DIRDB flush failed for DNR=%d.\n",__FUNCTION__,device_nr);
			return 4;
		}
		if(flexActive && flexFlushFATChecked(device_nr)!=0)
		{
			dprintk("%s: pre-format FAT flush failed for DNR=%d.\n",__FUNCTION__,device_nr);
			return 4;
		}
	}
	else
		dprintk("%s: target DNR=%d has no valid cached JTMFS; skipping old-info reload.\n",
		         __FUNCTION__,device_nr);

	if(driver_FlushDrive(device_nr)!=0)
	{
		dprintk("%s: pre-format device flush failed for DNR=%d.\n",__FUNCTION__,device_nr);
		return 4;
	}
	driver_block_cache_invalidate(device_nr);
	dirdb_DiskChange(device_nr);
	flexDiskChange(device_nr);
	if(fatsys!=NULL && device_nr>=0 && device_nr<N_CFAT_STRUCTURES)
		fatsys->isJTMFS[device_nr]=FALSE;

	//
	driver_getdevicename(device_nr, str);
	dprintk("[%s/%s/line %d]: Formatting drive %s: ...\n",
		__FILE__,
		__FUNCTION__,
		__LINE__,
		str);
	//
	nr_blocks = getsize(device_nr);
	blocksize = getblocksize(device_nr);
	//
	FFCHECK

	//
	dprintk("MKFS/start: DNR=%d dev=%s blocks=%d blocksize=%d capacity=%u MiB cached_jtmfs=%d.\n",
		device_nr,str,nr_blocks,blocksize,
		(unsigned)(((unsigned long long)(DWORD)nr_blocks*(unsigned long long)(DWORD)blocksize)/(1024ULL*1024ULL)),
		(fatsys!=NULL && device_nr>=0 && device_nr<N_CFAT_STRUCTURES) ? fatsys->isJTMFS[device_nr] : -1);
	printk("\rMKFS | [------------------------------]   0%% preparing          ");

	//
	if(!nr_blocks)
	{
		//
		dprintk("Device is not suitable for a file system.\n");
		return 1;
	}

	// Do the job. Never report success if FAT creation failed.
	dprintk("MKFS/stage: entering jtmfat_createfat DNR=%d.\n",device_nr);
	r = jtmfat_createfat(device_nr);
	if(r)
	{
		dprintk("[%s/%s/line %d]: FAT creation failed, error %d.\n",
			__FUNCTION__, __FILE__, __LINE__, r);
		return r;
	}
	dprintk("MKFS/stage: FAT+info complete; creating root directory DNR=%d.\n",device_nr);
	if( jtmfs_createrootdir(device_nr) )
	{
		// Root dir creation failed, retry. Over come a common bug!
		FlushAll();
		dprintk("[%s/%s/line %d]: Format failed.\n",
			__FUNCTION__, __FILE__, __LINE__);
		return 1;
	}

	/*
	 * Root-directory creation marks its block EOF in the FAT after writing the
	 * directory data.  Flush that last dirty FAT page before reporting format
	 * success.  FlushAll() is currently a compatibility no-op.
	 */
	dprintk("MKFS/stage: root directory created; flushing only dirty FAT metadata DNR=%d.\n",device_nr);
	if(flexFlushFATChecked(device_nr)!=0)
	{
		dprintk("[%s/%s/line %d]: final dirty FAT flush failed.\n",
			__FUNCTION__, __FILE__, __LINE__);
		return 2;
	}

	/* Final verification is deliberately limited to the root FAT page. */
	{
		int root_block;
		root_block=jtmfat_getrootdir(device_nr);
		flexDiskChange(device_nr);
		if(root_block<=0 || (DWORD)root_block>=jtmfat_unitcount(device_nr) ||
		   (DWORD)jtmfat_getblock(device_nr, root_block)!=0xFFFFFFF8UL)
		{
			dprintk("[%s/%s/line %d]: root FAT dirty-page verification failed (block %d).\n",
				__FUNCTION__, __FILE__, __LINE__, root_block);
			return 3;
		}
	}
	FlushAll();
	dprintk("MKFS/done: DNR=%d dev=%s dirty FAT + root verification OK; whole FAT was not scanned.\n",device_nr,str);
	printk("\rMKFS | [##############################] 100%% complete            \n");
	dprintk("Format Completed.\n");
	return 0;
}
