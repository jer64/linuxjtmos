#ifndef __INCLUDED_ROOT_H__
#define __INCLUDED_ROOT_H__

int mount_root(int dnr);
int umount_root(void);
int getRootDNR(void);
int getRootDB(void);

/* Create/synchronize physical root-directory mount points for registered
 * block devices. */
int jtmfs_sync_block_device_mountpoints(void);

#endif
