///////////////////////////////////////////////////////////////////////////////////////////
// ReadChain.c - bounded/reentrant file-chain reader
// V67.8.53: coalesce physically contiguous chain blocks into readblocks().
// V68.8.57.10.18.16.55: sector-aligned partial-cluster reads no longer
// read the complete cluster into the shared 64 KiB scratch buffer.
///////////////////////////////////////////////////////////////////////////////////////////
#include "kernel32.h"
#include "dir.h"
#include "flexCorruption.h"
#include "ReadChain.h"

#define JTMFS_CHAIN_IO_MAX_BLOCKS 256

/* Return bytes copied, 0 at EOF, negative on error. */
int jtmfs_ReadFileChain(BYTE *buf, int dnr, int _d,
                        int preciseLength, int offset)
{
    DWORD d,newd,lastd,lba,cs,units;
    int bsz,pbs,skip,skipBytes,c,chunk,remaining,run,maxrun,sectors;
    int sector_off;
    BYTE *tmp;

    DEBUGLINE
    FFCHECK

    if(!isOK(dnr) || buf==NULL || preciseLength<0 || offset<0) return -1;
    if(preciseLength==0) return 0;
    bsz=(int)jtmfat_unitsize(dnr);
    pbs=getblocksize(dnr);
    cs=jtmfat_clustersectors(dnr);
    units=jtmfat_unitcount(dnr);
    if(bsz<=0 || bsz>64*1024 || pbs<=0 || cs==0 || units<2 ||
       (DWORD)pbs*cs!=(DWORD)bsz || _d<=0 || (DWORD)_d>=units || jtmfs_LastBlock((DWORD)_d) ||
       !jtmfat_isdatablock(dnr,(DWORD)_d))
    {
        ReportMessage("%s: SYSTEM-WALL rejected initial chain block %d.\n",__FUNCTION__,_d);
        return -1;
    }

    d=(DWORD)_d;
    tmp=jtmfsAccess.rwtmp;
    if(tmp==NULL) return -1;

    skip=offset/bsz;
    skipBytes=offset%bsz;

    while(skip>0)
    {
        jtmfs_cooperative_yield((unsigned long)skip);
        newd=(DWORD)jtmfat_getblock(dnr,(int)d);
        if(jtmfs_LastBlock(newd)) return 0;
        if(newd==0 || newd>=units || !jtmfat_isdatablock(dnr,newd))
        {
            printk("JTMFS/read: invalid FAT chain at file offset=%d DNR=%d unit=%u -> 0x%x.\n",
                   offset,dnr,(unsigned)d,(unsigned)newd);
            ReportMessage("%s: corrupt/system-area chain link %u -> %u.\n",__FUNCTION__,d,newd);
            return -1;
        }
        d=newd;
        skip--;
    }

    c=0;
    while(c<preciseLength)
    {
        jtmfs_cooperative_yield((unsigned long)c);
        if(d==0 || d>=units || jtmfs_LastBlock(d) || !jtmfat_isdatablock(dnr,d))
        {
            ReportMessage("%s: SYSTEM-WALL rejected data block %u.\n",__FUNCTION__,d);
            return -1;
        }
        remaining=preciseLength-c;

        /* Full aligned blocks can go straight from the block layer to the
         * caller.  Walk enough FAT links to discover a contiguous physical
         * extent, then submit the whole extent as one readblocks request. */
        if(skipBytes==0 && remaining>=bsz)
        {
            maxrun=remaining/bsz;
            if(maxrun>JTMFS_CHAIN_IO_MAX_BLOCKS) maxrun=JTMFS_CHAIN_IO_MAX_BLOCKS;
            if(cs>0 && maxrun>(int)(256UL/cs)) maxrun=(int)(256UL/cs);
            if(maxrun<1) maxrun=1;
            run=1;
            lastd=d;
            while(run<maxrun)
            {
                newd=(DWORD)jtmfat_getblock(dnr,(int)lastd);
                if(jtmfs_LastBlock(newd)) break;
                if(newd==0 || newd>=units || !jtmfat_isdatablock(dnr,newd))
                {
                    ReportMessage("%s: corrupt/system-area chain link %u -> %u.\n",__FUNCTION__,lastd,newd);
                    return -1;
                }
                if(newd!=lastd+1U) break;
                lastd=newd;
                run++;
            }

            lba=jtmfat_unit_to_lba(dnr,d);
            if(lba==0xffffffffUL) return -1;
            sectors=run*(int)cs;
            if(readblocks(dnr,(long)lba,buf+c,sectors)!=sectors) return -1;
            c+=run*bsz;
            if(c>=preciseLength) break;

            newd=(DWORD)jtmfat_getblock(dnr,(int)lastd);
            if(jtmfs_LastBlock(newd)) break;
            if(newd==0 || newd>=units)
            {
                ReportMessage("%s: corrupt chain link %u -> %u.\n",__FUNCTION__,lastd,newd);
                return -1;
            }
            d=newd;
            continue;
        }

        /* Unaligned first/last block: preserve the historical scratch path. */
        lba=jtmfat_unit_to_lba(dnr,d);
        if(lba==0xffffffffUL) return -1;
        chunk=bsz-skipBytes;
        if(chunk>remaining) chunk=remaining;

        /* A normal file read is almost always physical-sector aligned.  On a
         * clustered volume do not turn a 16 KiB request into a 32/64 KiB
         * read-modify-copy cycle.  Reading only the requested sectors both
         * removes shared-scratch exposure and reduces old ATA/SATA command
         * pressure.  Truly byte-unaligned requests keep the compatibility
         * scratch path. */
        if((skipBytes%pbs)==0 && (chunk%pbs)==0) {
            sector_off=skipBytes/pbs;
            sectors=chunk/pbs;
            if(sectors<=0 ||
               readblocks(dnr,(long)(lba+(DWORD)sector_off),buf+c,sectors)!=sectors) {
                printk("JTMFS/read: DNR=%d unit=%u LBA=%u +%d sectors=%d offset=%d failed.\n",
                       dnr,(unsigned)d,(unsigned)lba,sector_off,sectors,offset+c);
                return -1;
            }
        } else {
            if(readblocks(dnr,(long)lba,tmp,(int)cs)!=(int)cs) {
                printk("JTMFS/read: DNR=%d full-cluster fallback unit=%u LBA=%u sectors=%u failed.\n",
                       dnr,(unsigned)d,(unsigned)lba,(unsigned)cs);
                return -1;
            }
            memcpy(buf+c,tmp+skipBytes,chunk);
        }
        c+=chunk;
        skipBytes=0;
        if(c>=preciseLength) break;

        newd=(DWORD)jtmfat_getblock(dnr,(int)d);
        if(jtmfs_LastBlock(newd)) break;
        if(newd==0 || newd>=units || !jtmfat_isdatablock(dnr,newd))
        {
            ReportMessage("%s: corrupt/system-area chain link %u -> %u.\n",__FUNCTION__,d,newd);
            return -1;
        }
        d=newd;
    }
    FFCHECK
    return c;
}
