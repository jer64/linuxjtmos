#ifndef __INCLUDED_FILE_H__
#define __INCLUDED_FILE_H__

#include <stdio.h>
#include "filedef.h"

int _fsetsize(const char *fname, int length);
int __fcreate(const char *path);

FILE *fopen(const char *path, const char *mode);
FILE *_fopen(const char *path, const char *mode, FILE *initialPTR);
FILE *freopen(const char *path, const char *mode, FILE *stream);
int fclose(FILE *stream);
int fflush(FILE *stream);

size_t fread(void *ptr, size_t size, size_t nmemb, FILE *stream);
size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream);
int fgetc(FILE *stream);
int fputc(int c, FILE *stream);
int putc(int c, FILE *stream);
char *fgets(char *s, int maxv, FILE *stream);
int fputs(const char *s, FILE *stream);
int fseek(FILE *stream, long offset, int whence);
long ftell(FILE *stream);
void rewind(FILE *stream);
int feof(FILE *stream);
int ferror(FILE *stream);
void clearerr(FILE *stream);
int fileno(FILE *stream);

FILE *__fnewstream(void);
extern FILE *stdout,*stdin,*stderr;

int fexist(const char *pathname);
int __fexist(const char *pathname);
int close(int fd);
int lseek(int fd, int offset, int whence);
int _fgetsize(const char *pathname);
int __faddblocks(const char *pathname,long amount);
int StringCheck(const char *s);
int rename(const char *OldName, const char *NewName);
int unlink(const char *pathname);
int remove(const char *pathname);
int fsizeof(const char *pathname);
int formatDrive(const char *name);
int _formatDrive(int dnr);

#endif
