#include <stdio.h>

int fseek(FILE *stream, long offset, int whence)
{
    int pos;
    if(!stream) { errno=EINVAL; return -1; }
    if(whence!=SEEK_SET && whence!=SEEK_CUR && whence!=SEEK_END)
    { errno=EINVAL; stream->error=TRUE; return -1; }

    /* Kernel FILE I/O is descriptor based, so there is no hidden FILE read
     * buffer to compensate for here. */
    pos=lseek(stream->fd,(int)offset,whence);
    if(pos<0) { stream->error=TRUE; return -1; }

    stream->eof=FALSE;
    stream->hasRead=FALSE;
    stream->writeback=FALSE;
    stream->baseOffs=pos; /* legacy introspection only */
    stream->offs=0;
    return 0;
}
