// (C) 2020-2026 JTT.
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sh.h"
#include "lsapp.h"
#include "formatapp.h"
#include "chdirapp.h"
#include "helpapp.h"
#include "exitapp.h"
#include "nzip.h"
#include "sqa.h"
#include "copyall.h"
#include "rmwildcard.h"
#include "debugmode.h"
#include "memdump.h"
#include "freeapp.h"
#include "fsadmin.h"
#include "kyberapp.h"
#include "aiapp.h"
#if JTMOS_MOD_NETWORK
#include "networkapp.h"
#endif

#ifdef JTMOS
#include "kernel32.h"
#include "jtmfsPath.h"
#include "centralprocess.h"
#include "scheduler.h"
#include "reboot.h"
#include "linuxabi.h"
#include "keymap.h"
#include "mouse.h"
#include "ps2mouse.h"
#include "bootutilsram.h"
#if JTMOS_MOD_GRAOS_BOOT
#include "graos_boot.h"
#endif
#include "fs/api.h"
#include "fs/filebuf.h"
#include "core/dataproc/kformat.h"
#if JTMOS_MOD_PCI
#include "pci.h"
#include "usb_input.h"
#endif
#endif

#define SH_MAX_LINE 65536U
#define SH_MAX_ARGS 100
#define SH_NOT_HANDLED (-32767)
#define SH_MAX_PIPE_STAGES 16

typedef int (*shell_command_fn)(int argc, char **argv);

typedef struct shell_command {
    const char *name;
    shell_command_fn function;
} SHELL_COMMAND;

/* When shell_graos.o is linked, this weak hook adds gui/graos/postman/pm
 * without making the standalone shell depend on SDL2 or Postman. */
#if defined(__GNUC__)
extern int graos_shell_try_command(const char *command, int argc, char **argv)
    __attribute__((weak));
extern int AudioDemoMain(int argc, char **argv) __attribute__((weak));
#endif

#ifdef JTMOS
/* Restricted SMSH builtins normally print through the kernel console.  When a
 * Ring3 SQSH pipeline invokes the builtin bridge, selected stream-safe builtins
 * use smsh_printf() instead: it writes to the calling process' fd 1, which may
 * be a real kernel pipe.  Direct SMSH still falls back to normal vprintf(). */
static volatile int smsh_bridge_owner=-1;
static volatile int smsh_bridge_depth=0;

typedef struct SMSH_PIPE_PRINTF_CONTEXT {
    int pid;
    int error;
    unsigned int used;
    char data[256];
} SMSH_PIPE_PRINTF_CONTEXT;

static void smsh_pipe_printf_flush(SMSH_PIPE_PRINTF_CONTEXT *ctx)
{
    int wrote;
    if(!ctx || ctx->error || ctx->used==0U) return;
    wrote=KernelFileBufWrite(ctx->pid,1,ctx->data,(int)ctx->used);
    if(wrote!=(int)ctx->used) ctx->error=1;
    ctx->used=0U;
}

static void smsh_pipe_printf_emit(void *opaque,char ch)
{
    SMSH_PIPE_PRINTF_CONTEXT *ctx=(SMSH_PIPE_PRINTF_CONTEXT *)opaque;
    if(!ctx || ctx->error) return;
    ctx->data[ctx->used++]=ch;
    if(ctx->used>=sizeof(ctx->data) || ch=='\n') smsh_pipe_printf_flush(ctx);
}

int smsh_printf(const char *fmt,...)
{
    va_list args;
    int result;
    SMSH_PIPE_PRINTF_CONTEXT ctx;
    if(fmt==NULL) return 0;
    if(smsh_bridge_owner!=GetCurrentThread()) {
        va_start(args,fmt);
        result=vprintf(fmt,args);
        va_end(args);
        return result;
    }
    memset(&ctx,0,sizeof(ctx));
    ctx.pid=GetCurrentThread();
    va_start(args,fmt);
    result=jt_vformat(smsh_pipe_printf_emit,&ctx,fmt,args);
    va_end(args);
    smsh_pipe_printf_flush(&ctx);
    return ctx.error ? -1 : result;
}

static void smsh_bridge_enter(void)
{
    int pid=GetCurrentThread();
    for(;;) {
        DWORD flags=get_eflags();
        disable();
        if(smsh_bridge_owner<0 || smsh_bridge_owner==pid) {
            smsh_bridge_owner=pid;
            smsh_bridge_depth++;
            set_eflags(flags);
            return;
        }
        set_eflags(flags);
        SwitchToThread();
    }
}

static void smsh_bridge_leave(void)
{
    DWORD flags=get_eflags();
    disable();
    if(smsh_bridge_owner==GetCurrentThread()) {
        if(smsh_bridge_depth>0) smsh_bridge_depth--;
        if(smsh_bridge_depth==0) smsh_bridge_owner=-1;
    }
    set_eflags(flags);
}
#endif

static int sound_builtin(int argc, char **argv)
{
#if defined(__GNUC__)
    if(AudioDemoMain != NULL)
        return AudioDemoMain(argc, argv);
#endif
    printf("sound: audio drivers are not included in this kernel build.\n");
    return 1;
}

#ifdef JTMOS
/* Kernel-controlled GraOS launch entry.  SQSH reaches this through the
 * restricted SMSH builtin syscall so GraOS receives both a private terminal
 * and THREAD_TYPE_SERVICE before any GUI client can attach a framebuffer. */
static const char *gfx_provider_name(int provider)
{
    if(provider==VESA_TEXT_GFX_NV6150) return "GeForce 6150SE/MCP61";
    if(provider==VESA_TEXT_GFX_VM_VGA) return "VM VGA/BGA";
    if(provider==VESA_TEXT_GFX_BOOT_VESA) return "boot VESA/LFB";
    if(provider==VESA_TEXT_GFX_AUTO) return "auto";
    return "none/text VGA";
}

static void gfx_usage(void)
{
    printf("Usage: gfx [auto|geforce|vmvga|640x480|1024x768|status|off]\n");
    printf("       gfx [auto|geforce|vmvga] [640x480|1024x768]\n");
    printf("       gfx vt <0-6>\n");
    printf("Default: auto provider, 640x480x32 framebuffer text console.\n");
}

static int gfx_parse_mode(const char *s, int *w, int *h)
{
    if(strcmp(s,"640x480")==0) { *w=640; *h=480; return 0; }
    if(strcmp(s,"1024x768")==0) { *w=1024; *h=768; return 0; }
    return 1;
}

static int gfx_builtin(int argc, char **argv)
{
    int provider=VESA_TEXT_GFX_AUTO;
    int width=VESA_TEXT_GFX_DEFAULT_WIDTH;
    int height=VESA_TEXT_GFX_DEFAULT_HEIGHT;
    int active;
    int explicit_mode=FALSE;
    const char *name;

    if(argc>=2 && strcmp(argv[1],"status")==0)
    {
        if(argc!=2) { gfx_usage(); return 2; }
        active=VesaTextGraphicsProvider();
        name=gfx_provider_name(active);
        printf("gfx: provider=%s graphics=%d vt-render=%d mode=%dx%dx%d pitch=%d LFB=0x%x\n",
               name,vesa_enabled?1:0,vesa_text_console_enabled?1:0,
               vesa_width,vesa_height,vesa_bpp,vesa_pitch,vesa_frame_buf);
        printf("gfx: prepared nv6150=%d vm-vga=%d visible-vt=%d input-vt=%d\n",
               Nv6150IsPrepared()?1:0,VBoxBgaIsPrepared()?1:0,
               GetVisibleTerminal(),GetInputTerminal());
        return 0;
    }

    if(argc>=2 && strcmp(argv[1],"off")==0)
    {
        if(argc!=2) { gfx_usage(); return 2; }
        /* Do not attempt a BIOS/VGA mode-3 transition from protected mode on
         * native MCP61 hardware. `off` only releases the framebuffer terminal
         * renderer; a later gfx command re-enables it idempotently. */
        VesaTextConsoleEnable(FALSE);
        printf("gfx: virtual-terminal framebuffer renderer disabled; hardware mode unchanged.\n");
        return 0;
    }

    if(argc>=2 && strcmp(argv[1],"vt")==0)
    {
        int vt;
        if(argc!=3 || argv[2][0]<'0' || argv[2][0]>'6' || argv[2][1]!=0)
        {
            printf("Usage: gfx vt <0-6>\n");
            return 2;
        }
        vt=argv[2][0]-'0';
        if(SwitchUserTerminal(vt)!=0)
        {
            printf("gfx: VT%d is not available.\n",vt);
            return 1;
        }
        if(vesa_enabled && !vesa_text_console_enabled)
            VesaTextConsoleEnable(TRUE);
        if(vesa_enabled)
            VesaTextConsoleRefresh();
        printf("gfx: switched display and keyboard focus to VT%d.\n",vt);
        return 0;
    }

    if(argc>3) { gfx_usage(); return 2; }

    if(argc>=2)
    {
        if(strcmp(argv[1],"auto")==0) provider=VESA_TEXT_GFX_AUTO;
        else if(strcmp(argv[1],"geforce")==0) provider=VESA_TEXT_GFX_NV6150;
        else if(strcmp(argv[1],"vmvga")==0) provider=VESA_TEXT_GFX_VM_VGA;
        else if(gfx_parse_mode(argv[1],&width,&height)==0) { provider=VESA_TEXT_GFX_AUTO; explicit_mode=TRUE; }
        else { gfx_usage(); return 2; }
    }

    if(argc==3)
    {
        if(!(strcmp(argv[1],"auto")==0 || strcmp(argv[1],"geforce")==0 ||
             strcmp(argv[1],"vmvga")==0) ||
           gfx_parse_mode(argv[2],&width,&height)!=0)
        {
            gfx_usage();
            return 2;
        }
        explicit_mode=TRUE;
    }

    if(provider==VESA_TEXT_GFX_AUTO && !explicit_mode)
        active=VesaStartTextGraphics();
    else
        active=VesaSetTextGraphics(provider,width,height);
    if(active==VESA_TEXT_GFX_NONE)
    {
        printf("gfx: graphics console activation failed.\n");
        return 1;
    }

    name=gfx_provider_name(active);
    printf("gfx: %s %dx%dx%d active; virtual-terminal renderer enabled.\n",
           name,vesa_width,vesa_height,vesa_bpp);
    return 0;
}

static int graos_builtin(int argc, char **argv)
{
#if defined(__GNUC__)
    if(graos_shell_try_command != NULL)
        return graos_shell_try_command("graos",argc,argv);
#endif
    (void)argc; (void)argv;
    printf("graos: GraOS launcher is not included in this kernel build.\n");
    return 1;
}
#endif

static int sh_debug = 0;

#ifdef JTMOS
static int sh_directory_exists(const char *path)
{
    int pid,dnr,db;
    if(path==NULL || !path[0]) return 0;
    pid=GetCurrentThread(); dnr=GetCurrentDNR(); db=GetCurrentDB();
    if(chdir(path)!=0) return 0;
    /* Restore by DNR/DB identity instead of reparsing a saved pathname.  This
     * keeps mkdir -p side-effect free even across device-qualified paths. */
    SetThreadDNR(pid,dnr); SetThreadDB(pid,db);
    return 1;
}

static int sh_mkdir_p(const char *path)
{
    char tmp[1024];
    int i,n;
    if(path==NULL || !path[0] || strlen(path)>=sizeof(tmp)) return -1;
    strcpy(tmp,path); n=(int)strlen(tmp);
    for(i=1;i<n;i++) {
        if(tmp[i]=='/' || tmp[i]=='\\') {
            char save=tmp[i];
            if(i>0 && tmp[i-1]==':') continue;
            tmp[i]=0;
            if(tmp[0] && !sh_directory_exists(tmp)) (void)mkdir(tmp,0);
            tmp[i]=save;
        }
    }
    if(!sh_directory_exists(tmp) && mkdir(tmp,0)!=0 && !sh_directory_exists(tmp)) return -1;
    return 0;
}

static int mkdir_builtin(int argc, char **argv)
{
    int i,start=1,pflag=0,rc=0;
    if(argc < 2) {
        printf("Usage: mkdir [-p] DIRECTORY [DIRECTORY ...]\n");
        return 2;
    }
    if(!strcmp(argv[1], "-h") || !strcmp(argv[1], "--help")) {
        printf("Usage: mkdir [-p] DIRECTORY [DIRECTORY ...]\n");
        printf("Create JTMFS directories; -p creates missing parent directories.\n");
        return 0;
    }
    if(!strcmp(argv[1],"-p")) { pflag=1; start=2; }
    if(start>=argc) return 2;
    for(i=start;i<argc;i++) {
        if((pflag ? sh_mkdir_p(argv[i]) : mkdir(argv[i],0))!=0) {
            if(!(pflag && sh_directory_exists(argv[i]))) {
                printf("mkdir: cannot create '%s'\n",argv[i]); rc=1;
            }
        }
    }
    return rc;
}

static int env_split_assignment(const char *arg,char *name,int cap,const char **value)
{
    const char *eq;
    int n;
    if(arg==NULL || name==NULL || cap<2 || value==NULL) return -1;
    eq=strchr(arg,'=');
    if(eq==NULL) return -1;
    n=(int)(eq-arg);
    if(n<=0 || n>=cap) return -1;
    memcpy(name,arg,(unsigned int)n); name[n]=0; *value=eq+1;
    return envdb_ValidName(name) ? 0 : -1;
}

static const char *smsh_env_canonical_name(const char *name)
{
    /* Match SQSH convenience semantics: only PATH is case-insensitive. */
    if(name!=NULL &&
       (name[0]=='p' || name[0]=='P') &&
       (name[1]=='a' || name[1]=='A') &&
       (name[2]=='t' || name[2]=='T') &&
       (name[3]=='h' || name[3]=='H') && name[4]==0)
        return "PATH";
    return name;
}

static int env_builtin_common(int argc,char **argv,int global)
{
    int i,count,rc;
    char name[256];
    const char *value,*entry;
    ENVDB *db;
    if(global) db=kenv; else db=ProcessEnvGetDB(GetCurrentThread(),1);
    if(db==NULL) { printf("%s: environment unavailable\n",global?"setglobal":"set"); return 1; }
    if(argc==1) {
        count=envdb_Count(db);
        for(i=0;i<count;i++) { entry=envdb_EntryAt(db,i); if(entry) printf("%s\n",entry); }
        return 0;
    }
    if(argc==3 && !strcmp(argv[1],"-u"))
        return global ? (kunsetglobalenv(smsh_env_canonical_name(argv[2]))<0) : (ProcessEnvUnset(GetCurrentThread(),smsh_env_canonical_name(argv[2]))<0);
    if(argc==2 && env_split_assignment(argv[1],name,sizeof(name),&value)==0) {
        rc=global ? ksetglobalenv(smsh_env_canonical_name(name),value,1) : ProcessEnvSet(GetCurrentThread(),smsh_env_canonical_name(name),value,1);
        return rc<0 ? 1 : 0;
    }
    if(argc==3 && envdb_ValidName(argv[1])) {
        rc=global ? ksetglobalenv(smsh_env_canonical_name(argv[1]),argv[2],1) : ProcessEnvSet(GetCurrentThread(),smsh_env_canonical_name(argv[1]),argv[2],1);
        return rc<0 ? 1 : 0;
    }
    printf("Usage: %s [NAME=VALUE | NAME VALUE | -u NAME]\n",global?"setglobal":"set");
    return 2;
}

static int set_builtin(int argc,char **argv) { return env_builtin_common(argc,argv,0); }
static int setglobal_builtin(int argc,char **argv) { return env_builtin_common(argc,argv,1); }

static int path_builtin(int argc,char **argv)
{
    char value[1024];
    if(argc==1) {
        if(ProcessEnvGet(GetCurrentThread(),"PATH",value,sizeof(value))<0) value[0]=0;
        printf("PATH=%s\n",value);
        return 0;
    }
    if(argc==2) return ProcessEnvSet(GetCurrentThread(),"PATH",argv[1],1)<0 ? 1 : 0;
    printf("Usage: path [VALUE]\n");
    return 2;
}

static int keymap_builtin(int argc, char **argv)
{
    if(argc==1)
    {
        printf("Keyboard layout: %s\n",KeyboardGetLayoutName());
        printf("PS/2 keyboard: init=%d controller=%x IRQ1=%lu bytes=%lu poll=%lu\n",
               keyb_hwinit_status,(unsigned int)keyb_controller_byte,
               (unsigned long)keyb_irq_count,(unsigned long)keyb_byte_count,
               (unsigned long)keyb_poll_count);
        printf("Usage: keymap english|finnish\n");
        return 0;
    }
    if(argc!=2 || KeyboardSetLayoutByName(argv[1])!=0)
    {
        printf("keymap: unknown layout '%s'\n",argc>1 ? argv[1] : "");
        printf("Available layouts: english (default), finnish\n");
        return 2;
    }
    printf("Keyboard layout: %s\n",KeyboardGetLayoutName());
    return 0;
}


static int usbinfo_builtin(int argc, char **argv)
{
    if(argc!=1)
    {
        printf("Usage: usbinfo\n");
        return 2;
    }
#if JTMOS_MOD_PCI
    usb_input_dump();
    return 0;
#else
    printf("usbinfo: PCI/USB input scaffold disabled in this build.\n");
    return 1;
#endif
}

static int mouseinfo_builtin(int argc, char **argv)
{
    int rv=0;

    if(argc>2) {
        printf("Usage: mouseinfo [reinit]\n");
        return 2;
    }
    if(argc==2) {
        if(strcmp(argv[1],"reinit")!=0) {
            printf("Usage: mouseinfo [reinit]\n");
            return 2;
        }
        if(!PS2MOUSE_ENABLED) {
            printf("mouseinfo: PS/2 mouse is disabled in keropt.\n");
            return 1;
        }
        if(!ps2mouse_enabled)
            ps2mouse_init();
        else
            rv=ps2mouse_hardwareinit();
    }

    (void)mouse_poll();
    printf("PS/2 mouse: enabled=%d stream=%d x=%d y=%d buttons=%x IRQ12=%lu bytes=%lu packets=%lu\n",
           ps2mouse_enabled,ps2mouse_stream_status,mouse.x,mouse.y,mouse_getbuttons(),
           (unsigned long)ps2mouse_irq_count,(unsigned long)ps2mouse_byte_count,
           (unsigned long)ps2mouse_packet_count);
    printf("i8042 status=%x PIC master mask=%x slave mask=%x%s\n",
           (unsigned int)inportb(0x64),(unsigned int)inportb(0x21),
           (unsigned int)inportb(0xA1),rv ? " reinit FAILED" : "");
    return rv ? 1 : 0;
}

static int reboot_builtin(int argc, char **argv)
{
    (void)argc; (void)argv;
    printf("Rebooting JTMOS...\n");
    system_reset();
    return 0;
}

#define RAMEXTRACT_BUILTIN_MAX_BYTES JTMOS_BOOT_UTILS_RAM_BYTES

static int ramextract_builtin(int argc, char **argv)
{
    const char *outname="utils.iso";
    const void *image;
    DWORD size;
    FILE *out;
    size_t wrote;

    if(argc>2) {
        printf("Usage: ramextract [OUTPUT]\n");
        return 2;
    }
    if(argc==2) {
        if(!strcmp(argv[1],"-h") || !strcmp(argv[1],"--help")) {
            printf("Usage: ramextract [OUTPUT]\n");
            printf("Extract DOSBOOT-staged UTILS.ISO (max 16 MiB); default OUTPUT is utils.iso.\n");
            return 0;
        }
        outname=argv[1];
    }

    size=BootUtilsRamSize();
    image=BootUtilsRamData();
    if(size==0 || size>RAMEXTRACT_BUILTIN_MAX_BYTES || image==NULL) {
        printf("ramextract: no valid DOSBOOT UTILS.ISO RAM bank\n");
        return 1;
    }

    out=fopen(outname,"wb");
    if(out==NULL) {
        printf("ramextract: cannot create '%s'\n",outname);
        return 1;
    }

    /* One JTMFS write is intentional.  ram: uses 512-byte allocation units on
     * the 20 MiB rescue disk, so the historical 32 KiB loop caused every
     * write to walk an ever-longer FAT chain: ~143 writes and O(n^2) FAT work
     * for a 4.6 MiB utils.iso.  The staged image is already kernel-mapped, so
     * reserve the final chain once and stream it through WriteFileChainEx in a
     * single write() transaction. */
    printf("ramextract: writing %lu bytes to %s (bulk RAM->JTMFS)\n",
           (unsigned long)size,outname);
    wrote=fwrite(image,1U,(size_t)size,out);
    if(wrote!=(size_t)size) {
        printf("ramextract: write failed after %lu/%lu bytes\n",
               (unsigned long)wrote,(unsigned long)size);
        fclose(out);
        return 1;
    }
    if(fclose(out)!=0) {
        printf("ramextract: close failed for '%s'\n",outname);
        return 1;
    }
    printf("ramextract: done (%lu bytes)\n",(unsigned long)size);
    return 0;
}
#endif

#ifdef JTMOS
static int scheduler_builtin(int argc, char **argv)
{
    (void)argc; (void)argv;
    SchedulerDump();
    return 0;
}
#endif

#if defined(JTMOS) && JTMOS_MOD_PCI
static int lspci_builtin(int argc, char **argv)
{
    int i,b,verbose;
    const PCIDEVICE *d;
    PCIBAR bar;
    verbose=0;
    if(argc>2 || (argc==2 && strcmp(argv[1],"-v"))) {
        printf("Usage: lspci [-v]\n");
        return 2;
    }
    if(argc==2) verbose=1;
    pci_init();
    if(!verbose) {
        pci_dump_devices();
        return 0;
    }
    printf("PCI: %d retained function(s)\n",pci_get_device_count());
    for(i=0; i<pci_get_device_count(); ++i) {
        d=pci_get_device(i);
        pci_print_device(d);
        for(b=0; b<PCI_MAX_BARS; ++b) {
            if(pci_get_bar(d,b,&bar)==0 && bar.valid) {
                if(bar.io)
                    printf("  BAR%d I/O  base=%x\n",b,bar.base_low);
                else if(bar.is64)
                    printf("  BAR%d MMIO64 base=%x:%x%s\n",b,bar.base_high,bar.base_low,
                           bar.prefetchable?" prefetch":"");
                else
                    printf("  BAR%d MMIO base=%x%s\n",b,bar.base_low,
                           bar.prefetchable?" prefetch":"");
                if(bar.is64) ++b;
            }
        }
        if(d->class_code==0x06 && d->subclass==0x04)
            printf("  bridge buses: primary=%d secondary=%d subordinate=%d\n",
                   d->primary_bus,d->secondary_bus,d->subordinate_bus);
        if(d->cap_ptr)
            printf("  caps: ptr=%x PM=%d MSI=%d MSI-X=%d PCIe=%d\n",
                   d->cap_ptr,d->has_pm,d->has_msi,d->has_msix,d->has_pcie);
    }
    return 0;
}
#endif

#ifdef JTMOS
static int unique_builtin(int argc, char **argv)
{
    char command[1024];
    char workdir[256];
    int used,i,pid;
    if(argc<2) {
        printf("Usage: unique FILE.uni [args ...]\n");
        printf("       uni FILE.uni [args ...]\n");
        return 2;
    }
    strcpy(command,"/bin/unique.bin"); used=(int)strlen(command);
    for(i=1;i<argc;i++) {
        size_t arglen=strlen(argv[i]);
        /* Kernel sh is linked without userspace formatted-stdio helpers. Append the
         * tokenized argv element directly and keep one byte for the NUL. */
        if((size_t)used + 1U + arglen >= sizeof(command)) {
            printf("unique: command line too long.\n"); return 2;
        }
        command[used++]=' ';
        memcpy(command+used,argv[i],arglen);
        used+=(int)arglen;
        command[used]=0;
    }
    workdir[0]=0; /* exact current DNR/DB inheritance */
    pid=centralprocess_exec("/bin/unique.bin",command,GetCurrentDNR(),GetCurrentDB(),workdir,GetCurrentTerminal());
    if(pid<=0) { printf("unique: cannot launch /bin/unique.bin\n"); return 1; }
    return WaitProcessTerminationInterruptible(pid)?130:0;
}
#endif

static const SHELL_COMMAND shell_commands[] = {
    {"cd", chdir_app},
    {"chdir", chdir_app},
    {"ls", ls_app},
    {"dir", ls_app},
    {"lsdev", lsdev_app},
#if defined(JTMOS) && JTMOS_MOD_PCI
    {"lspci", lspci_builtin},
#endif
    {"mkfs", format_app},
    {"format", format_app},
    {"mount", mount_app},
    {"umount", umount_app},
    {"unmount", umount_app},
    {"root", root_app},
    {"rootinstall", rootinstall_app},
    {"bootroot", bootroot_app},
    {"sync", sync_app},
    {"hdatest", hdatest_app},
    {"fsgeom", fsgeom_app},
    {"fsck", fsck_app},
    {"diskspace", diskspace_app},
    {"ai", ai_native_app},
#ifdef JTMOS
    {"gfx", gfx_builtin},
    {"graos", graos_builtin},
    {"gui", graos_builtin},
    {"mkdir", mkdir_builtin},
    {"unique", unique_builtin},
    {"uni", unique_builtin},
    {"set", set_builtin},
    {"setglobal", setglobal_builtin},
    {"path", path_builtin},
    {"keymap", keymap_builtin},
    {"kbd", keymap_builtin},
    {"usbinfo", usbinfo_builtin},
    {"mouseinfo", mouseinfo_builtin},
    {"mouse", mouseinfo_builtin},
    {"reboot", reboot_builtin},
    {"reset", reboot_builtin},
    {"ramextract", ramextract_builtin},
#endif
    {"help", help_app},
    {"exit", exit_app},
    {"quit", exit_app},
    {"sqa", sqa_main},
    {"sqarc", sqarc_main},
    {"nzip", nzip_main},
    {"kyber", kyber_app},
#ifdef JTMOS
    {"sched", scheduler_builtin},
#endif
    {"copyall", copyall_main},
    {"rm_wildcard", rm_wildcard_main},
    {"rmwild", rm_wildcard_main},
    {"rmw", rm_wildcard_main},
    {"debug", DebugModeSwitchMain},
    {"debug1", DebugModeSwitchMain},
    {"report", ReportModeSwitchMain},
    {"debug2", ReportModeSwitchMain},
    {"d0", DebugReportOffMain},
    {"m", kmed_main},
    {"kmed", kmed_main},
    {"fm", file_memory_dump_main},
    {"free", free_app},
    {"sound", sound_builtin},
#if JTMOS_MOD_NETWORK
    {"internet", internet_app},
    {"inet", internet_app},
    {"www", www_app},
    {"telnetd", telnetd_app},
    {"ping", ping_app},
    {"host", host_app},
    {"nutget", nutget_app},
    {"async", async_app},
#endif
    {NULL, NULL}
};

int sh_dprint(const char *fmt, ...)
{
    va_list args;

    if (!sh_debug || fmt == NULL) {
        return 0;
    }

    va_start(args, fmt);
    (void)vprintf(fmt, args);
    va_end(args);
    return 0;
}

char *splitter(char *split_what, char *with_what, int n_occurance)
{
    char *cursor;
    size_t separator_length;
    int found = 0;

    if (split_what == NULL || with_what == NULL || n_occurance <= 0) {
        return split_what;
    }

    separator_length = strlen(with_what);
    if (separator_length == 0U) {
        return split_what;
    }

    cursor = split_what;
    while (*cursor != '\0') {
        if (strncmp(cursor, with_what, separator_length) == 0) {
            ++found;
            cursor += separator_length;
            if (found == n_occurance) {
                return cursor;
            }
        } else {
            ++cursor;
        }
    }
    return cursor;
}

static int is_separator(char value, const char *separators)
{
    if (separators == NULL || separators[0] == '\0') {
        return value == ' ' || value == '\t';
    }
    return strchr(separators, value) != NULL;
}

static void free_argv(char **argv, int argc)
{
    int i;

    if (argv == NULL) {
        return;
    }
    for (i = 0; i < argc; ++i) {
        free(argv[i]);
    }
    free(argv);
}

/* Build a conventional argv array. Quoted strings and backslash escapes are
 * accepted, so e.g. postman exec "program name" remains one argument. */
char **argvbuilder(char *cmdstr, char *filterstring, int *pointer_to_argc)
{
    const char *cursor;
    char **argv;
    int argc = 0;

    if (pointer_to_argc != NULL) {
        *pointer_to_argc = 0;
    }
    if (cmdstr == NULL) {
        return NULL;
    }

    argv = (char **)calloc((size_t)SH_MAX_ARGS + 1U, sizeof(*argv));
    if (argv == NULL) {
        return NULL;
    }

    cursor = cmdstr;
    while (*cursor != '\0' && argc < SH_MAX_ARGS) {
        const char *start;
        char quote = '\0';
        char *argument;
        size_t capacity;
        size_t used = 0U;

        while (*cursor != '\0' && is_separator(*cursor, filterstring)) {
            ++cursor;
        }
        if (*cursor == '\0') {
            break;
        }

        start = cursor;
        capacity = strlen(start) + 1U;
        argument = (char *)malloc(capacity);
        if (argument == NULL) {
            free_argv(argv, argc);
            return NULL;
        }

        while (*cursor != '\0') {
            char value = *cursor;

            if (quote == '\0' && is_separator(value, filterstring)) {
                break;
            }
            if (value == '\\' && cursor[1] != '\0') {
                argument[used++] = cursor[1];
                cursor += 2;
                continue;
            }
            if (value == '\'' || value == '"') {
                if (quote == '\0') {
                    quote = value;
                    ++cursor;
                    continue;
                }
                if (quote == value) {
                    quote = '\0';
                    ++cursor;
                    continue;
                }
            }
            argument[used++] = value;
            ++cursor;
        }
        argument[used] = '\0';
        argv[argc++] = argument;

        while (*cursor != '\0' && is_separator(*cursor, filterstring)) {
            ++cursor;
        }
    }

    argv[argc] = NULL;
    if (pointer_to_argc != NULL) {
        *pointer_to_argc = argc;
    }
    return argv;
}

char **old_argvbuilder(char *cmdstr, char *filterstring, int *pointer_to_argc)
{
    return argvbuilder(cmdstr, filterstring, pointer_to_argc);
}

/* Legacy flat-buffer helper. The returned buffer is a copy of the command
 * line; pointer_to_argc receives the parsed argument count. */
char *b_argvbuilder(char *cmdstr, char *filterstring, char *pointer_to_argc)
{
    char **argv;
    char *copy;
    int argc = 0;

    if (cmdstr == NULL) {
        return NULL;
    }
    argv = argvbuilder(cmdstr, filterstring, &argc);
    if (argv == NULL) {
        return NULL;
    }
    copy = (char *)malloc(strlen(cmdstr) + 1U);
    if (copy != NULL) {
        strcpy(copy, cmdstr);
    }
    if (pointer_to_argc != NULL) {
        *pointer_to_argc = (char)((argc > 127) ? 127 : argc);
    }
    free_argv(argv, argc);
    return copy;
}

/* Legacy tokenizer for callers that supply an argv array. */
int getargumentlist(char *command_line, char **argv)
{
    static char storage[8192];
    char *token;
    int argc = 0;

    if (command_line == NULL || argv == NULL) {
        return 0;
    }
    strncpy(storage, command_line, sizeof(storage) - 1U);
    storage[sizeof(storage) - 1U] = '\0';

    token = strtok(storage, " \t");
    while (token != NULL && argc < SH_MAX_ARGS) {
        argv[argc++] = token;
        token = strtok(NULL, " \t");
    }
    argv[argc] = NULL;
    return argc;
}

static shell_command_fn find_builtin(const char *name)
{
    size_t i;

    if (name == NULL) {
        return NULL;
    }
    for (i = 0U; shell_commands[i].name != NULL; ++i) {
        if (strcmp(shell_commands[i].name, name) == 0) {
            return shell_commands[i].function;
        }
    }
    return NULL;
}


/* Native JTMOS has a terminal getch() primitive but no fgets()-based pipe
 * stream for interactive input. Keep fgets() only in the host test branch. */
static int sh_readline(char *line, size_t capacity)
{
#ifdef JTMOS
    size_t used = 0U;
    int overflow = 0;

    if(line == NULL || capacity < 2U) return -1;
    line[0] = '\0';

    for(;;) {
        int key = getch();

        /* With no foreground child, terminal Ctrl+C is delivered as ETX.
         * Cancel the editing line here; foreground jobs receive the same key
         * as a terminal-local interrupt instead. */
        if(key == 3) {
            printf("^C\n");
            line[0]='\0';
            return -3;
        }

        if(ConsumeTerminalInterrupt(GetCurrentTerminal())) {
            printf("^C\n");
            line[0]='\0';
            return -3;
        }
        if(key == '\r' || key == '\n') {
            putchar('\n');
            break;
        }
        if(key == 4 && used == 0U) return -1; /* Ctrl-D */
        if(key == '\b' || key == 127) {
            if(used > 0U) {
                --used;
                line[used] = '\0';
                putchar('\b'); putchar(' '); putchar('\b');
            }
            continue;
        }
        if(key == 27 || key < 32 || key > 255) continue;

        if(used + 1U < capacity) {
            line[used++] = (char)key;
            line[used] = '\0';
            putchar(key);
        } else {
            overflow = 1;
        }
    }

    if(overflow) {
        printf("sh: command line too long (maximum %u characters)\\n",
               (unsigned)(capacity - 1U));
        line[0] = '\0';
        return -2;
    }
    return (int)used;
#else
    size_t length;
    if(line == NULL || capacity < 2U) return -1;
    if(fgets(line, (int)capacity, stdin) == NULL) return -1;
    length = strlen(line);
    if(length > 0U && line[length-1U] != '\n' && !feof(stdin)) {
        int ch;
        while((ch = getchar()) != '\n' && ch != EOF) { }
        line[0] = '\0';
        return -2;
    }
    while(length > 0U && (line[length-1U] == '\n' || line[length-1U] == '\r'))
        line[--length] = '\0';
    return (int)length;
#endif
}

static int try_optional_dispatch(const char *command, int argc, char **argv)
{
#if defined(__GNUC__)
    if (graos_shell_try_command != NULL) {
        return graos_shell_try_command(command, argc, argv);
    }
#else
    (void)command;
    (void)argc;
    (void)argv;
#endif
    return SH_NOT_HANDLED;
}

#ifdef JTMOS
/*
 * Explicit external-program path for the native SMSH.
 *
 *   :install
 *   :ls /ram
 *   :/bin/test.bin arg1 arg2
 *
 * The leading ':' belongs to SMSH syntax only and is stripped before the
 * application loader sees the filename.  This is important because old
 * centralprocess_loadEXE() has historical pseudo-names such as
 * ":install.bin"; V27 deliberately bypasses those and loads the real file
 * from JTMFS/PATH.  centralprocess_exec() then reaches LaunchAppEx() after
 * the executable has been loaded from disk.
 */
static int smsh_launch_external(const char *line)
{
    char command[256];
    char executable[256];
    char workdir[256];
    const char *src;
    size_t len;
    size_t i;
    int pid;
    int background = 0;

    if(line == NULL || line[0] != ':')
        return -1;

    src = line + 1;
    while(*src == ' ' || *src == '\t')
        ++src;

    if(*src == '\0') {
        printf("SMSH: ':' requires an external program name.\n");
        return -1;
    }

    len = strlen(src);
    if(len >= sizeof(command)) {
        printf("SMSH: external command is too long (max %u bytes).\n",
               (unsigned)(sizeof(command) - 1U));
        return -1;
    }

    strcpy(command, src);

    /* A trailing ampersand is SMSH background syntax for explicit external
     * programs.  Remove it from argv before LaunchApp and, after a successful
     * launch, do not wait for process termination. */
    while(len>0U && (command[len-1U]==' ' || command[len-1U]=='\t'))
        command[--len]='\0';
    if(len>0U && command[len-1U]=='&')
    {
        background=1;
        command[--len]='\0';
        while(len>0U && (command[len-1U]==' ' || command[len-1U]=='\t'))
            command[--len]='\0';
    }
    if(len==0U)
    {
        printf("SMSH: background marker requires an external program.\n");
        return -1;
    }

    /* centralprocess_exec() wants argv[0]/filename separately from the full
     * command line.  Keep quoting/arguments intact in command[]. */
    for(i = 0U; i < sizeof(executable) - 1U && command[i] != '\0'; ++i) {
        if(command[i] == ' ' || command[i] == '\t')
            break;
        executable[i] = command[i];
    }
    executable[i] = '\0';

    if(executable[0] == '\0') {
        printf("SMSH: invalid external program name.\n");
        return -1;
    }

    /* Empty workDir means exact syscall/caller DNR/DB inheritance; do not
     * stringify cwd and resolve it back through another process. */
    workdir[0] = '\0';
    printf("SMSH LaunchApp: '%s' (cwd=DNR/DB %d/%d)\n",
           command,GetCurrentDNR(),GetCurrentDB());
    pid = centralprocess_exec(executable, command,
                              GetCurrentDNR(), GetCurrentDB(),
                              workdir, GetCurrentTerminal());
    if(pid <= 0) {
        printf("SMSH LaunchApp: unable to load/execute '%s'.\n", executable);
        return -1;
    }

    if(background)
    {
        printf("SMSH LaunchApp: PID %d started in background.\n", pid);
        return 0;
    }

    printf("SMSH LaunchApp: PID %d started; waiting for termination.\n", pid);
    if(WaitProcessTerminationInterruptible(pid))
        printf("SMSH LaunchApp: PID %d interrupted.\n", pid);
    else
        printf("SMSH LaunchApp: PID %d terminated.\n", pid);
    return 0;
}
#endif


#ifdef JTMOS
static char *sh_trim(char *s)
{
    char *e;
    while(*s==' ' || *s=='\t') s++;
    e=s+strlen(s);
    while(e>s && (e[-1]==' ' || e[-1]=='\t')) *--e='\0';
    return s;
}

/* Split only unquoted, unescaped pipe characters.  This deliberately leaves
 * argv quoting to argvbuilder/LaunchApp so arguments such as "a|b" survive. */
static int sh_split_pipeline(char *line, char **stage, int maxstage)
{
    char quote=0;
    int escape=0,n=1,i;
    char *p;
    if(!line || !stage || maxstage<1) return -1;
    stage[0]=line;
    for(p=line; *p; ++p)
    {
        if(escape) { escape=0; continue; }
        if(*p=='\\') { escape=1; continue; }
        if(quote) { if(*p==quote) quote=0; continue; }
        if(*p=='\'' || *p=='"') { quote=*p; continue; }
        if(*p=='|')
        {
            if(n>=maxstage) return -2;
            *p='\0';
            stage[n++]=p+1;
        }
    }
    if(n==1) return 0;
    for(i=0;i<n;i++)
    {
        stage[i]=sh_trim(stage[i]);
        if(!*stage[i]) return -1;
    }
    return n;
}

static int smsh_pipeline_builtin_bridgeable(const char *name)
{
    static const char *names[]={"internet","inet","www","telnetd","ping","host","nutget","async",
                                "ai","set","setglobal","path",NULL};
    int i;
    if(!name) return 0;
    for(i=0;names[i];i++) if(!strcmp(name,names[i])) return 1;
    return 0;
}

static int sh_resolve_pipeline_exe(const char *exe,char *envpath,char *found,int foundcap)
{
    char withbin[256];
    if(!exe || !found || foundcap<2) return 0;
    found[0]='\0';
    if(strchr(exe,'/') || strchr(exe,'\\') || strchr(exe,':')) {
        if(strlen(exe)>=(size_t)foundcap) return 0;
        strcpy(found,exe);
        return 1;
    }
    if(envpath && envpath[0] && SearchThroughPath(envpath,(char *)exe,found)) return 1;
    /* The normal JTMOS loader appends .bin automatically.  SMSH's historical
     * pipeline pre-resolver bypassed that step, so `cat | more` searched for a
     * literal file called `more`.  Mirror normal loader semantics here. */
    if(strchr(exe,'.')==NULL && strlen(exe)+4U<sizeof(withbin)) {
        strcpy(withbin,exe); strcat(withbin,".bin");
        if(envpath && envpath[0] && SearchThroughPath(envpath,withbin,found)) return 1;
    }
    return 0;
}

static int sh_make_sqsh_pipe_stage_cmd(char *out,int cap,const char *sqsh,const char *stage,int has_input)
{
    int used=0,i;
    const char *mid=has_input ? " --pipe-stage-in \"" : " --pipe-stage \"";
    if(!out || cap<16 || !sqsh || !stage) return -1;
    for(i=0;sqsh[i];i++) { if(used+1>=cap) return -1; out[used++]=sqsh[i]; }
    for(i=0;mid[i];i++) { if(used+1>=cap) return -1; out[used++]=mid[i]; }
    for(i=0;stage[i];i++) {
        if(stage[i]=='\\' || stage[i]=='\"') {
            if(used+2>=cap) return -1;
            out[used++]='\\';
        }
        if(used+1>=cap) return -1;
        out[used++]=stage[i];
    }
    if(used+2>=cap) return -1;
    out[used++]='\"'; out[used]='\0';
    return 0;
}

static int sh_pipeline_launch_one(const char *stage, int stdin_fd, int stdout_fd, int *pid_out)
{
    char command[1024],exe[256],savedcwd[JTMFS_PATH_MAX],envpath[512],found[512];
    char worker[1200],sqsh_found[512];
    const char *src;
    size_t i;
    int pid=0;

    if(!stage || !pid_out) return -1;
    src=stage;
    while(*src==' ' || *src=='\t') src++;
    if(*src==':') { src++; while(*src==' ' || *src=='\t') src++; }
    if(!*src || strlen(src)>=sizeof(command)) return -1;
    strcpy(command,src);

    for(i=0;i<sizeof(exe)-1 && command[i] && command[i]!=' ' && command[i]!='\t';i++)
        exe[i]=command[i];
    exe[i]='\0';
    if(!exe[0]) return -1;
    if(getcwd(savedcwd,sizeof(savedcwd)-1U)==NULL) strcpy(savedcwd,"ram:/");
    savedcwd[sizeof(savedcwd)-1U]='\0';
    if(ProcessEnvGet(GetCurrentThread(),"PATH",envpath,sizeof(envpath))<0)
        envpath[0]='\0';

    /* A kernel builtin cannot execute concurrently inside the SMSH parent
     * while that parent's stdout is redirected.  Run exported builtins through
     * SQSH's no-banner worker; SYS_smsh_builtin then routes network/status text
     * to the worker's fd 1, so e.g. `inet status | more` is a real pipeline. */
    if(find_builtin(exe)!=NULL && smsh_pipeline_builtin_bridgeable(exe)) {
        if(!sh_resolve_pipeline_exe("sqsh.bin",envpath,sqsh_found,sizeof(sqsh_found)))
            strcpy(sqsh_found,"/bin/sqsh.bin");
        if(sh_make_sqsh_pipe_stage_cmd(worker,sizeof(worker),sqsh_found,command,stdin_fd>=0)!=0) {
            *pid_out=0; return -1;
        }
        pid=centralprocess_exec_stdio(sqsh_found,worker,GetCurrentDNR(),GetCurrentDB(),
                "",GetCurrentTerminal(),stdin_fd,stdout_fd,-1);
        (void)chdir(savedcwd);
        *pid_out=pid;
        return pid>0 ? 0 : -1;
    }

    if(!sh_resolve_pipeline_exe(exe,envpath,found,sizeof(found))) {
        (void)chdir(savedcwd);
        *pid_out=0;
        return -1;
    }

    pid=centralprocess_exec_stdio(found,command,GetCurrentDNR(),GetCurrentDB(),
            "",GetCurrentTerminal(),stdin_fd,stdout_fd,-1);
    (void)chdir(savedcwd);
    *pid_out=pid;
    return pid>0 ? 0 : -1;
}

static int sh_run_pipeline(char *line)
{
    char *stage[SH_MAX_PIPE_STAGES];
    int pipes[SH_MAX_PIPE_STAGES-1][2];
    int pids[SH_MAX_PIPE_STAGES];
    int n,i,j,rc=0,created=0;

    n=sh_split_pipeline(line,stage,SH_MAX_PIPE_STAGES);
    if(n==0) return SH_NOT_HANDLED;
    if(n<0)
    {
        printf("sh: invalid pipeline (maximum %d stages)\n",SH_MAX_PIPE_STAGES);
        return 2;
    }
    memset(pipes,-1,sizeof(pipes));
    memset(pids,0,sizeof(pids));
    for(i=0;i<n-1;i++)
    {
        if(LinuxPipeCreate(pipes[i])!=0)
        {
            printf("sh: pipe: unable to allocate pipe %d\n",i+1);
            rc=1; goto cleanup;
        }
    }

    for(i=0;i<n;i++)
    {
        int in_fd=(i==0)?-1:pipes[i-1][0];
        int out_fd=(i==n-1)?-1:pipes[i][1];
        if(sh_pipeline_launch_one(stage[i],in_fd,out_fd,&pids[i])!=0)
        {
            printf("sh: pipeline: unable to launch stage %d: %s\n",i+1,stage[i]);
            rc=1; goto cleanup;
        }
        created++;
    }

cleanup:
    /* Parent must close every endpoint after children have inherited their
     * selected ends.  Otherwise readers would never observe EOF. */
    for(i=0;i<n-1;i++)
        for(j=0;j<2;j++) if(pipes[i][j]>=3) { (void)close(pipes[i][j]); pipes[i][j]=-1; }

    for(i=0;i<created;i++)
    {
        if(pids[i]>0 && WaitProcessTerminationInterruptible(pids[i]))
        {
            int k;
            rc=130;
            for(k=i+1;k<created;k++) if(pids[k]>0) KillThread(pids[k]);
            break;
        }
    }
    return rc;
}
#endif

#ifdef JTMOS
/* Execute one non-interactive SMSH command through the same builtin/GraOS/
 * external dispatch order as the interactive shell.  Autostart deliberately
 * does not invent private filesystem shortcuts: the bootstrap path therefore
 * exercises the exact same command implementations a user would type. */
/* Restricted userspace bridge for SQSH.  This intentionally exposes only
 * established SMSH builtins whose semantics are useful for system
 * administration.  It never falls through to system()/external execution. */
static int smsh_userspace_builtin_allowed(const char *name)
{
    static const char *allowed[]={
        "cd","chdir","mkdir",
        "mount","umount","unmount","root","rootinstall","bootroot","sync",
        "hdatest","fsgeom","fsck","diskspace","ai","keymap","kbd","usbinfo","mouseinfo","mouse",
        "reboot","reset","ramextract","sched","kyber","debug","debug1","report",
        "debug2","d0","sound","free","lspci","gfx","graos","gui","ping","internet",
        "inet","www","telnetd","host","nutget","copyall",
        "sqa","sqarc","nzip",NULL
    };
    int i;
    if(name==NULL || !name[0]) return 0;
    for(i=0; allowed[i]!=NULL; ++i)
        if(strcmp(name,allowed[i])==0) return 1;
    return 0;
}

int smsh_execute_builtin_text(const char *text)
{
    char line[1024];
    char **argv;
    int argc=0,rc;
    shell_command_fn command;

    if(text==NULL || text[0]=='\0' || strlen(text)>=sizeof(line)) return 2;
    strcpy(line,text);
    argv=argvbuilder(line," \t",&argc);
    if(argv==NULL || argc==0) {
        if(argv!=NULL) free_argv(argv,argc);
        return 2;
    }
    if(!smsh_userspace_builtin_allowed(argv[0])) {
        free_argv(argv,argc);
        return -3;
    }
    command=find_builtin(argv[0]);
    if(command==NULL) {
        free_argv(argv,argc);
        return -2;
    }

    /* Builtins own any command-specific foreground-job semantics.  In
     * particular ping_app() now marks/restores itself so SMSH and SQSH behave
     * identically. */
    smsh_bridge_enter();
    rc=command(argc,argv);
    smsh_bridge_leave();
    free_argv(argv,argc);
    return rc;
}

static int smsh_execute_command_text(const char *text)
{
    char line[1024];
    char **argv;
    int argc=0;
    int rc;
    shell_command_fn command;

    if(text==NULL || text[0]=='\0' || strlen(text)>=sizeof(line))
        return 2;
    strcpy(line,text);

    argv=argvbuilder(line," \t",&argc);
    if(argv==NULL || argc==0) {
        if(argv!=NULL) free_argv(argv,argc);
        return 2;
    }

    command=find_builtin(argv[0]);
    if(command!=NULL) {
        rc=command(argc,argv);
        free_argv(argv,argc);
        return rc;
    }

    rc=try_optional_dispatch(argv[0],argc,argv);
    if(rc!=SH_NOT_HANDLED) {
        free_argv(argv,argc);
        return rc;
    }

    free_argv(argv,argc);
    rc=system(text);
    return rc==0 ? 0 : 1;
}

static int smsh_autostart_after_root(void)
{
    static const char *steps[]={
        "cd ram:",
        "mkdir bin",
        "cd bin",
        "ramextract utils.iso",
        "sqa utils.iso",
        "unz",
        NULL
    };
    int i,rc;

    printf("SMSH autostart: headless utilities bootstrap enabled (GraOS is manual).\n");
    for(i=0;steps[i]!=NULL;i++) {
        printf("autostart> %s\n",steps[i]);
        rc=smsh_execute_command_text(steps[i]);

        /* mkdir is intentionally idempotent.  An existing ram:/bin is not an
         * autostart failure; the following cd bin is the authoritative test. */
        if(i==1 && rc!=0) {
            printf("SMSH autostart: mkdir bin returned %d; continuing in case it already exists.\n",rc);
            continue;
        }
        if(rc!=0) {
            printf("SMSH autostart: stopped at '%s' (status %d); maintenance prompt remains available.\n",
                   steps[i],rc);
            return rc;
        }
    }
    printf("SMSH autostart: headless bootstrap sequence completed; use graos manually if wanted.\n");
    return 0;
}
#endif

int run_shell(void)
{
    char *line;

    line = (char *)malloc(SH_MAX_LINE);
    if (line == NULL) {
        fprintf(stderr, "sh: unable to allocate command buffer\n");
        return 1;
    }

#ifdef JTMOS
    if(boot_ctrl_smsh_override)
        printf("SMSH safe boot: Ctrl held during boot; automatic commands and GraOS are disabled.\n");

    /* autostart command #1 must be d0.  Do it before root probing/banner
     * chatter so test boots are not dominated by debug/serial output.
     * The boot Ctrl latch is checked as a second line of defense in addition
     * to KernelInit forcing autostart=0. */
    if(autostart && !boot_ctrl_smsh_override) {
        printf("autostart> d0\n");
        (void)smsh_execute_command_text("d0");
    }

    if(smsh_boot_root_policy()!=0)
        printf("SMSH boot: root filesystem is not available; maintenance shell continues.\n");
#endif

    printf("Built-In System Maintenance Debug Shell 1.2 / 2020-2026\n");
#ifdef JTMOS
    /* This line is intentionally printed before interactive input.  If a
     * keyboard regression prevents typing, the screen still tells us whether
     * CPU IRQs and PIC IRQ1 were enabled when SMSH took control. */
    printf("SMSH keyboard bootdiag: IF=%d status64=%x PICmask=%x init=%d cb=%x IRQ1=%lu bytes=%lu poll=%lu\n",
           (get_eflags() & 0x200UL) ? 1 : 0,
           (unsigned int)inportb(0x64),(unsigned int)inportb(0x21),
           keyb_hwinit_status,(unsigned int)keyb_controller_byte,
           (unsigned long)keyb_irq_count,(unsigned long)keyb_byte_count,
           (unsigned long)keyb_poll_count);
    if(autostart && !boot_ctrl_smsh_override) {
#if JTMOS_MOD_GRAOS_BOOT
        if(START_GRAOS && GraOSBootStarted())
            printf("SMSH autostart: GraOS already started by kernel; legacy GUI bootstrap skipped.\n");
        else
#endif
            (void)smsh_autostart_after_root();
    }
#endif

    for (;;) {
        char **argv;
        int argc = 0;
        int dispatch_result;
        shell_command_fn command;

#ifdef JTMOS
        {
            char cwd[JTMFS_PATH_MAX];
            char prompt = (getringlevel() == 0) ? '#' : '$';
            if(getcwd(cwd, sizeof(cwd)) == 0 && cwd[0] != '\0')
                printf("%s%c ", cwd, prompt);
            else
                printf("?%c ", prompt);
        }
#else
        printf("# ");
        fflush(stdout);
#endif

        {
            int read_result = sh_readline(line, SH_MAX_LINE);
            if(read_result == -1) {
                putchar('\n');
                break;
            }
            if(read_result == -2) {
                printf("sh: input discarded\n");
                continue;
            }
            if(read_result == -3)
                continue;
        }
#ifdef JTMOS
        {
            int pipe_result=sh_run_pipeline(line);
            if(pipe_result!=SH_NOT_HANDLED)
                continue;
        }
#endif
        argv = argvbuilder(line, " \t", &argc);
        if (argv == NULL) {
            fprintf(stderr, "sh: unable to parse command line\n");
            continue;
        }
        if (argc == 0) {
            free_argv(argv, argc);
            continue;
        }

#ifdef JTMOS
        /* A leading ':' always means "load an external executable".
         * Do this before builtin lookup so :help can launch help.bin rather
         * than invoking the SMSH builtin help command. */
        if(line[0] == ':') {
            (void)smsh_launch_external(line);
            free_argv(argv, argc);
            continue;
        }
#endif

        command = find_builtin(argv[0]);
        if (command != NULL) {
            int command_result = command(argc, argv);
            free_argv(argv, argc);
            if(command_result == SHELL_EXIT_REQUEST)
                break;
            continue;
        }

        dispatch_result = try_optional_dispatch(argv[0], argc, argv);
        if (dispatch_result != SH_NOT_HANDLED) {
            free_argv(argv, argc);
            continue;
        }

        /* Preserve the original external-program path.  GRAOS/Postman gets
         * the first chance through the optional dispatcher above. */
        if (system(line) == -1) {
#ifndef JTMOS
            perror("system");
#else
            printf("Unable to launch: %s\n", argv[0]);
#endif
        }
        free_argv(argv, argc);
    }

    free(line);
    sh_dprint("Exiting Shell, Thank You For Visiting Us!\n");
    return 0;
}
