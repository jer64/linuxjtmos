/*
 * copyall.c - SMSH/SQSH copyall builtin.
 *
 * JTMOS semantics:
 *   copyall SOURCE_PATH
 *       Copy and verify regular files from SOURCE_PATH into the current
 *       JTMFS directory.
 *
 *   copyall -r SOURCE_PATH
 *       Recursively copy and verify regular files while preserving the
 *       source subdirectory tree below the current JTMFS directory.
 *
 * Reliability rules:
 *   - every source directory is snapshotted before target writes begin;
 *   - file payloads are copied in bounded heap buffers and read back;
 *   - target logical size is explicitly truncated/set/verified;
 *   - recursive mode refuses a destination inside the source tree;
 *   - recursion depth is bounded so a corrupt directory graph cannot
 *     consume the kernel stack indefinitely.
 *
 * SQSH intentionally reaches this same implementation through the restricted
 * SMSH builtin bridge.  There is only one JTMFS copy engine to keep the two
 * shells' behaviour identical.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "copyall.h"

#ifdef JTMOS
#include "kernel32.h"
#include "jtmfs.h"
#include "jtmfsAccess.h"

#define COPYALL_CHUNK       (16 * 1024)
#define COPYALL_MAX_DEPTH   64
#define COPYALL_REL_MAX     512

typedef struct copyall_entry {
    struct copyall_entry *next;
    int size;
    int child_db;
    int is_directory;
    char name[34];
} COPYALL_ENTRY;

typedef struct copyall_stats {
    int files_seen;
    int files_copied;
    int dirs_seen;
    int dirs_ready;
} COPYALL_STATS;

static void copyall_restore_location(int dnr, int db)
{
    SetThreadDNR(GetCurrentThread(), dnr);
    SetThreadDB(GetCurrentThread(), db);
}

/* Accept historical device spellings ("ram", "hda/path") in addition to
 * canonical ram:/ and hda:/path. */
static int copyall_chdir_source(const char *path)
{
    char canonical[256];
    char devname[64];
    const char *slash;
    int prefix_len;
    int dev;
    int i;

    if(path==NULL || path[0]=='\0')
        return 1;

    if(strchr(path, ':')!=NULL || path[0]=='/')
        return jtmfs_chdir(path);

    slash=strchr(path, '/');
    prefix_len=slash ? (int)(slash-path) : (int)strlen(path);
    if(prefix_len<=0 || prefix_len>=(int)sizeof(devname))
        return jtmfs_chdir(path);

    for(i=0; i<prefix_len; ++i)
        devname[i]=path[i];
    devname[prefix_len]='\0';
    dev=driver_getdevicenrbyname(devname);
    if(dev<0)
        return jtmfs_chdir(path);

    if(slash!=NULL)
    {
        if(strlen(path)+2U>=sizeof(canonical))
            return 1;
        memcpy(canonical,path,(size_t)prefix_len);
        canonical[prefix_len]=':';
        strcpy(canonical+prefix_len+1,slash);
    }
    else
    {
        if(strlen(path)+3U>=sizeof(canonical))
            return 1;
        strcpy(canonical,path);
        strcat(canonical,":/");
    }

    return jtmfs_chdir(canonical);
}

static void copyall_free_entries(COPYALL_ENTRY *head)
{
    COPYALL_ENTRY *next;

    while(head != NULL) {
        next = head->next;
        free(head);
        head = next;
    }
}

/* Local, re-entrant directory lookup.  Do not use jtmfs_Fexist() here: that
 * legacy helper still owns a static DIRWALK and recursive copyall deliberately
 * avoids shared directory walkers. */
static int copyall_lookup_entry(int dnr, int db, const char *name,
                                int *out_type, int *out_first)
{
    DIRWALK dw;
    int found;

    if(out_type) *out_type=0;
    if(out_first) *out_first=0;
    if(name==NULL || !name[0]) return 0;

    InitDW(&dw);
    found=jtmfs_ffindfile(dnr,name,db,&dw);
    if(found && dw.fe!=NULL && !jtmfs_entryIsDeleted(dw.fe))
    {
        if(out_type) *out_type=(int)dw.fe->type;
        if(out_first) *out_first=(int)dw.fe->FirstDataBlock;
        EndDirWalk(&dw);
        return 1;
    }
    EndDirWalk(&dw);
    return 0;
}

/* Is candidate_db the same directory as, or below, ancestor_db?  Return -1
 * if a damaged '..' chain prevents a safe answer. */
static int copyall_db_is_inside(int dnr, int candidate_db, int ancestor_db)
{
    int cur;
    int root;
    int type;
    int parent;
    int limit;

    cur=candidate_db;
    root=jtmfat_getrootdir(dnr);
    if(root<=0) return -1;

    for(limit=0; limit<128; ++limit)
    {
        if(cur==ancestor_db) return 1;
        if(cur==root) return 0;
        if(!copyall_lookup_entry(dnr,cur,"..",&type,&parent) ||
           !JTMFS_TYPE_IS_DIRECTORY(type) || parent<=0 || parent==cur)
            return -1;
        cur=parent;
    }
    return -1;
}

static int copyall_snapshot(int dnr, int db, int include_directories,
                            COPYALL_ENTRY **out_head,
                            int *out_file_count,
                            int *out_dir_count)
{
    DIRWALK *dw;
    COPYALL_ENTRY *head;
    COPYALL_ENTRY *tail;
    COPYALL_ENTRY *entry;
    JTMFS_FILE_ENTRY *fe;
    int files;
    int dirs;
    int done;
    int is_dir;

    if(out_head == NULL || out_file_count == NULL || out_dir_count == NULL)
        return 1;

    *out_head = NULL;
    *out_file_count = 0;
    *out_dir_count = 0;
    head = NULL;
    tail = NULL;
    files = 0;
    dirs = 0;

    dw = (DIRWALK *)malloc(sizeof(DIRWALK));
    if(dw == NULL) {
        printf("copyall: unable to allocate directory walker.\n");
        return 1;
    }
    memset(dw, 0, sizeof(DIRWALK));

    if(jtmfs_ffirst(dnr, db, dw) != 0) {
        printf("copyall: unable to read source directory DB=%d.\n",db);
        free(dw);
        return 1;
    }

    done = 0;
    while(!done) {
        fe = dw->fe;
        if(fe != NULL && fe->name[0] != '\0' &&
           !jtmfs_entryIsDeleted(fe) &&
           !JTMFS_TYPE_IS_DIRNAME(fe->type))
        {
            is_dir=JTMFS_TYPE_IS_DIRECTORY(fe->type) ? 1 : 0;

            /* '.' and '..' are structural links, not children to clone. */
            if(is_dir && (!strcmp(fe->name,".") || !strcmp(fe->name,"..")))
            {
                /* skip */
            }
            else if((is_dir && include_directories) ||
                    (!is_dir && JTMFS_TYPE_IS_FILE(fe->type) && fe->length>=0))
            {
                entry = (COPYALL_ENTRY *)malloc(sizeof(COPYALL_ENTRY));
                if(entry == NULL) {
                    printf("copyall: out of memory while collecting '%s'.\n",
                           fe->name);
                    jtmfs_fend(dw);
                    free(dw);
                    copyall_free_entries(head);
                    return 1;
                }
                memset(entry, 0, sizeof(COPYALL_ENTRY));
                strncpy(entry->name, fe->name, sizeof(entry->name) - 1U);
                entry->name[sizeof(entry->name) - 1U] = '\0';
                entry->is_directory=is_dir;
                if(is_dir)
                {
                    entry->child_db=(int)fe->FirstDataBlock;
                    entry->size=0;
                    ++dirs;
                }
                else
                {
                    entry->size=fe->length;
                    entry->child_db=0;
                    ++files;
                }
                entry->next = NULL;

                if(tail != NULL)
                    tail->next = entry;
                else
                    head = entry;
                tail = entry;
            }
        }

        if(jtmfs_fnext(dnr, dw) != 0)
            done = 1;
    }

    jtmfs_fend(dw);
    free(dw);
    *out_head = head;
    *out_file_count = files;
    *out_dir_count = dirs;
    return 0;
}

static int copyall_prepare_target_file(const char *name,
                                       int target_dnr, int target_db)
{
    int type;
    int first;

    if(copyall_lookup_entry(target_dnr,target_db,name,&type,&first))
    {
        if(!JTMFS_TYPE_IS_FILE(type)) {
            printf("copyall: target '%s' is not a regular file.\n", name);
            return 1;
        }
    }
    else
    {
        if(jtmfs_CreateFile(target_dnr, target_db, name, 0) != 0) {
            printf("copyall: unable to create '%s'.\n", name);
            return 1;
        }
    }

    if(jtmfs_SetSize(target_dnr, name, 0, target_db) != 0) {
        printf("copyall: unable to truncate '%s'.\n", name);
        return 1;
    }
    return 0;
}

static int copyall_prepare_target_dir(const char *name,
                                      int target_dnr, int target_db,
                                      int *out_db)
{
    int type;
    int child;

    if(out_db==NULL) return 1;
    *out_db=0;

    if(copyall_lookup_entry(target_dnr,target_db,name,&type,&child))
    {
        if(!JTMFS_TYPE_IS_DIRECTORY(type)) {
            printf("copyall: cannot create directory '%s': target is a file.\n",name);
            return 1;
        }
    }
    else
    {
        if(jtmfs_CreateDirectory(target_dnr,target_db,name)!=0) {
            printf("copyall: unable to create directory '%s'.\n",name);
            return 1;
        }
        if(!copyall_lookup_entry(target_dnr,target_db,name,&type,&child) ||
           !JTMFS_TYPE_IS_DIRECTORY(type)) {
            printf("copyall: directory '%s' was created but cannot be reopened.\n",name);
            return 1;
        }
    }

    if(child<=0 || child==target_db) {
        printf("copyall: invalid target directory block for '%s' (%d).\n",name,child);
        return 1;
    }
    *out_db=child;
    return 0;
}

static int copyall_join_relative(const char *base, const char *name,
                                 char *out, int out_size)
{
    size_t need;

    if(base==NULL || name==NULL || out==NULL || out_size<=0) return 1;
    need=strlen(base)+strlen(name)+2U;
    if(need>(size_t)out_size) return 1;
    if(base[0]) {
        strcpy(out,base);
        strcat(out,"/");
        strcat(out,name);
    } else {
        strcpy(out,name);
    }
    return 0;
}

static int copyall_one(const COPYALL_ENTRY *entry, const char *display_name,
                       int source_dnr, int source_db,
                       int target_dnr, int target_db,
                       BYTE *buffer, BYTE *verify)
{
    int offset;
    int amount;
    int i;
    int rv;
    int actual_size;
    int size_mismatch;

    if(copyall_prepare_target_file(entry->name,target_dnr,target_db) != 0)
        return 1;

    offset = 0;
    while(offset < entry->size) {
        amount = entry->size - offset;
        if(amount > COPYALL_CHUNK)
            amount = COPYALL_CHUNK;

        rv = jtmfs_ReadFile(source_dnr, entry->name, source_db,
                            buffer, 0, amount, offset);
        if(rv != amount) {
            printf("copyall: read failed: %s offset=%d size=%d rv=%d\n",
                   display_name, offset, amount, rv);
            return 1;
        }

        rv = jtmfs_WriteFile(target_dnr, entry->name, target_db,
                             buffer, 0, amount, offset);
        if(rv != 0) {
            if(rv==2)
                printf("copyall: no space left on device (ENOSPC): %s offset=%d size=%d\n",
                       display_name,offset,amount);
            else
                printf("copyall: write failed: %s offset=%d size=%d rv=%d\n",
                       display_name, offset, amount, rv);
            return 1;
        }
        offset += amount;
    }

    if(jtmfs_SetSizeAfterWrite(target_dnr, entry->name, entry->size, target_db) != 0) {
        printf("copyall: unable to commit final size for '%s'.\n", display_name);
        return 1;
    }

    actual_size=jtmfs_GetFileSize(target_dnr, entry->name, target_db);
    size_mismatch=(actual_size != entry->size);
    if(size_mismatch) {
        printf("copyall: target size mismatch for '%s': expected=%d actual=%d.\n",
               display_name, entry->size, actual_size);
    }

    offset = 0;
    while(offset < entry->size) {
        amount = entry->size - offset;
        if(amount > COPYALL_CHUNK)
            amount = COPYALL_CHUNK;

        rv = jtmfs_ReadFile(source_dnr, entry->name, source_db,
                            buffer, 0, amount, offset);
        if(rv != amount) {
            printf("copyall: verify source read failed: %s offset=%d size=%d rv=%d\n",
                   display_name, offset, amount, rv);
            return 1;
        }

        rv = jtmfs_ReadFile(target_dnr, entry->name, target_db,
                            verify, 0, amount, offset);
        if(rv != amount) {
            printf("copyall: verify target read failed: %s offset=%d size=%d rv=%d\n",
                   display_name, offset, amount, rv);
            return 1;
        }

        for(i = 0; i < amount; ++i) {
            if(buffer[i] != verify[i]) {
                printf("copyall: verify failed: %s offset=%d\n",
                       display_name, offset + i);
                return 1;
            }
        }
        offset += amount;
    }

    if(size_mismatch) {
        printf("copyall: '%s': CONTENT EXACT for %d bytes, but logical size is %d (not an exact file copy).\n",
               display_name, entry->size, actual_size);
        return 1;
    }

    return 0;
}

static int copyall_tree(int source_dnr, int source_db,
                        int target_dnr, int target_db,
                        int recursive, int depth, const char *relative,
                        BYTE *buffer, BYTE *verify, COPYALL_STATS *stats)
{
    COPYALL_ENTRY *entries;
    COPYALL_ENTRY *entry;
    int file_count;
    int dir_count;
    int child_target_db;
    char display[COPYALL_REL_MAX];

    if(depth>COPYALL_MAX_DEPTH) {
        printf("copyall: recursion limit (%d) exceeded; source tree may be corrupt.\n",
               COPYALL_MAX_DEPTH);
        return 1;
    }

    entries=NULL;
    file_count=0;
    dir_count=0;
    if(copyall_snapshot(source_dnr,source_db,recursive,
                        &entries,&file_count,&dir_count)!=0)
        return 1;

    stats->files_seen+=file_count;
    stats->dirs_seen+=dir_count;

    entry=entries;
    while(entry!=NULL)
    {
        if(copyall_join_relative(relative,entry->name,display,sizeof(display))) {
            printf("copyall: relative path too long below '%s'.\n",entry->name);
            copyall_free_entries(entries);
            return 1;
        }

        if(entry->is_directory)
        {
            if(entry->child_db<=0 || entry->child_db==source_db) {
                printf("copyall: invalid source directory block for '%s' (%d).\n",
                       display,entry->child_db);
                copyall_free_entries(entries);
                return 1;
            }
            printf("copyall: mkdir %s ... ",display);
            if(copyall_prepare_target_dir(entry->name,target_dnr,target_db,
                                          &child_target_db)!=0) {
                printf("FAILED\n");
                copyall_free_entries(entries);
                return 1;
            }
            printf("OK\n");
            ++stats->dirs_ready;
            if(copyall_tree(source_dnr,entry->child_db,
                            target_dnr,child_target_db,
                            1,depth+1,display,buffer,verify,stats)!=0) {
                copyall_free_entries(entries);
                return 1;
            }
        }
        else
        {
            printf("copyall: %s (%d bytes) ... ", display, entry->size);
            if(copyall_one(entry,display,source_dnr,source_db,
                           target_dnr,target_db,buffer,verify)!=0) {
                printf("FAILED\n");
                copyall_free_entries(entries);
                return 1;
            }
            printf("OK\n");
            ++stats->files_copied;
        }
        entry=entry->next;
    }

    copyall_free_entries(entries);
    return 0;
}

static void copyall_usage(void)
{
    printf("Usage: copyall [-r|--recursive] SOURCE_PATH\n");
    printf("Examples:\n");
    printf("  copyall ram:/bin\n");
    printf("  copyall -r ram:/etc\n");
    printf("  copyall --recursive hda:/www\n");
    printf("Without -r only regular files in SOURCE_PATH are copied.\n");
    printf("With -r subdirectories are created and copied recursively.\n");
    printf("Target is always the currently active JTMFS directory.\n");
    printf("Bare device compatibility is accepted, e.g. copyall ram\n");
}

int copyall_main(int argc, char **argv)
{
    int target_dnr;
    int target_db;
    int source_dnr;
    int source_db;
    int recursive;
    int source_index;
    int ancestry;
    int failed;
    BYTE *buffer;
    BYTE *verify;
    COPYALL_STATS stats;
    char target_path[256];
    char source_path[256];

    recursive=0;
    source_index=1;
    if(argc>=2 && argv!=NULL && argv[1]!=NULL &&
       (!strcmp(argv[1],"-r") || !strcmp(argv[1],"-R") ||
        !strcmp(argv[1],"--recursive")))
    {
        recursive=1;
        source_index=2;
    }

    if(argv==NULL || argc!=source_index+1 || argv[source_index]==NULL ||
       argv[source_index][0]=='\0') {
        copyall_usage();
        return 1;
    }

    target_dnr = GetCurrentDNR();
    target_db = GetCurrentDB();
    target_path[0]='\0';
    source_path[0]='\0';
    (void)getcwd(target_path,sizeof(target_path));
    if(target_dnr < 0 || target_db <= 0 || !jtmfat_isJTMFS(target_dnr)) {
        printf("copyall: current target is not a valid JTMFS directory.\n");
        return 1;
    }

    if(copyall_chdir_source(argv[source_index]) != 0) {
        copyall_restore_location(target_dnr, target_db);
        printf("copyall: source path not found: %s\n", argv[source_index]);
        return 1;
    }

    source_dnr = GetCurrentDNR();
    source_db = GetCurrentDB();
    (void)getcwd(source_path,sizeof(source_path));
    copyall_restore_location(target_dnr, target_db);
    if(source_dnr < 0 || source_db <= 0 || !jtmfat_isJTMFS(source_dnr)) {
        printf("copyall: invalid source: %s\n", argv[source_index]);
        return 1;
    }

    if(source_path[0] && target_path[0])
        printf("copyall%s: %s -> %s\n",recursive ? " -r" : "",source_path,target_path);

    if(source_dnr == target_dnr) {
        if(source_db==target_db) {
            printf("copyall: source and target are the same directory.\n");
            return 1;
        }
        if(recursive) {
            ancestry=copyall_db_is_inside(source_dnr,target_db,source_db);
            if(ancestry==1) {
                printf("copyall: recursive target is inside the source tree.\n");
                printf("copyall: refusing copy to prevent recursive self-copy.\n");
                return 1;
            }
            if(ancestry<0) {
                printf("copyall: unable to verify source/target ancestry safely.\n");
                return 1;
            }
        }
    }

    buffer = (BYTE *)malloc(COPYALL_CHUNK);
    verify = (BYTE *)malloc(COPYALL_CHUNK);
    if(buffer == NULL || verify == NULL) {
        printf("copyall: unable to allocate copy buffers.\n");
        if(buffer != NULL) free(buffer);
        if(verify != NULL) free(verify);
        return 1;
    }

    memset(&stats,0,sizeof(stats));
    failed=copyall_tree(source_dnr,source_db,target_dnr,target_db,
                        recursive,0,"",buffer,verify,&stats);

    copyall_restore_location(target_dnr, target_db);
    free(buffer);
    free(verify);

    printf("copyall: %d/%d file(s) copied and verified",
           stats.files_copied,stats.files_seen);
    if(recursive)
        printf(", %d/%d director%s prepared",
               stats.dirs_ready,stats.dirs_seen,
               stats.dirs_seen==1 ? "y" : "ies");
    printf(".\n");
    return failed ? 1 : 0;
}

#else /* !JTMOS */

#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>

static int host_copy_file(const char *src, const char *dst)
{
    FILE *in;
    FILE *out;
    unsigned char *buf;
    size_t got;
    int rv;

    in = fopen(src, "rb");
    if(in == NULL)
        return 1;
    out = fopen(dst, "wb");
    if(out == NULL) {
        fclose(in);
        return 1;
    }
    buf = (unsigned char *)malloc(16384U);
    if(buf == NULL) {
        fclose(in);
        fclose(out);
        return 1;
    }
    rv = 0;
    while((got = fread(buf, 1U, 16384U, in)) != 0U) {
        if(fwrite(buf, 1U, got, out) != got) {
            rv = 1;
            break;
        }
    }
    free(buf);
    fclose(in);
    if(fclose(out) != 0)
        rv = 1;
    return rv;
}

static char *host_join(const char *a,const char *b)
{
    char *p;
    size_t n;
    n=strlen(a)+strlen(b)+2U;
    p=(char*)malloc(n);
    if(p==NULL) return NULL;
    if(!strcmp(a,".")) snprintf(p,n,"%s",b);
    else snprintf(p,n,"%s/%s",a,b);
    return p;
}

static int host_copy_tree(const char *source,const char *target,int recursive,
                          int *files,int *dirs)
{
    DIR *dir;
    struct dirent *de;
    struct stat st;
    char *src;
    char *dst;
    int rv;

    dir=opendir(source);
    if(dir==NULL) return 1;
    rv=0;
    while((de=readdir(dir))!=NULL)
    {
        if(!strcmp(de->d_name,".") || !strcmp(de->d_name,"..")) continue;
        src=host_join(source,de->d_name);
        dst=host_join(target,de->d_name);
        if(src==NULL || dst==NULL) {
            if(src) free(src);
            if(dst) free(dst);
            rv=1;
            break;
        }
        if(stat(src,&st)!=0) rv=1;
        else if(S_ISREG(st.st_mode)) {
            if(host_copy_file(src,dst)!=0) rv=1;
            else ++*files;
        } else if(S_ISDIR(st.st_mode) && recursive) {
            if(mkdir(dst,0777)!=0 && errno!=EEXIST) rv=1;
            else {
                ++*dirs;
                rv=host_copy_tree(src,dst,1,files,dirs);
            }
        }
        free(src);
        free(dst);
        if(rv) break;
    }
    closedir(dir);
    return rv;
}

int copyall_main(int argc, char **argv)
{
    int recursive;
    int source_index;
    int files;
    int dirs;
    int rv;

    recursive=0;
    source_index=1;
    if(argc>=2 && argv && argv[1] &&
       (!strcmp(argv[1],"-r") || !strcmp(argv[1],"-R") ||
        !strcmp(argv[1],"--recursive"))) {
        recursive=1;
        source_index=2;
    }
    if(argv==NULL || argc!=source_index+1 || argv[source_index]==NULL) {
        printf("Usage: copyall [-r|--recursive] SOURCE_PATH\n");
        return 1;
    }
    files=0;
    dirs=0;
    rv=host_copy_tree(argv[source_index],".",recursive,&files,&dirs);
    printf("copyall: %d file(s) copied",files);
    if(recursive) printf(", %d director%s copied",dirs,dirs==1 ? "y" : "ies");
    printf(".\n");
    return rv;
}

#endif
