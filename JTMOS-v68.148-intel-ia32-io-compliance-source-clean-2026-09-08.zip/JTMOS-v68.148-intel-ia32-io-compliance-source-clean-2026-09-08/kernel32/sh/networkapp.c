/* SMSH runtime networking commands for JTMOS V68. */
#include "kernel32.h"
#include "networkapp.h"
#include "networkControl.h"
#include "jt_httpd.h"
#include "jt_telnetd.h"
#include "jt_http_client.h"
#include "slip.h"
#include "slipStack.h"
#include "uip.h"
#include "uipMain.h"
#include "jnet.h"
#include "ethdev.h"
#include "nforce.h"
#include "core/kasync/kasync.h"
#include "sh.h"

/* When invoked from SQSH through SYS_smsh_builtin, route status text through
 * the caller's fd 1 so real pipelines (inet status | more) work. */
#define printf smsh_printf

static const char *inet_state_name(int state)
{
    switch(state)
    {
        case JTMOS_INET_STARTING: return "starting";
        case JTMOS_INET_ONLINE: return "online";
        case JTMOS_INET_STOPPING: return "stopping";
        default: return "offline";
    }
}

static int parse_uint(const char *s, int *out)
{
    int value = 0;

    if(s == NULL || *s == '\0' || out == NULL)
        return -1;
    while(*s)
    {
        if(*s < '0' || *s > '9')
            return -1;
        if(value > 100000000)
            return -1;
        value = value * 10 + (*s - '0');
        ++s;
    }
    *out = value;
    return 0;
}

static int parse_com(const char *s)
{
    if(s==NULL || *s=='\0') return -1;
    if(!strcmp(s,"com1") || !strcmp(s,"COM1") || !strcmp(s,"1")) return 0;
    if(!strcmp(s,"com2") || !strcmp(s,"COM2") || !strcmp(s,"2")) return 1;
    if(!strcmp(s,"com3") || !strcmp(s,"COM3") || !strcmp(s,"3")) return 2;
    if(!strcmp(s,"com4") || !strcmp(s,"COM4") || !strcmp(s,"4")) return 3;
    return -1;
}

static unsigned long inet_count_after_reject(unsigned long received,unsigned long rejected)
{
    return received>rejected ? received-rejected : 0;
}

static void internet_reset_packet_stats(void)
{
    /* This is a counters-only reset: addresses, DHCP lease, ARP cache, TCP
     * connections and the HTTP listener remain untouched.  JtUipReset... also
     * resets the protocol-core uip_stat structure. */
    JtUipResetDriverStats();
    jnet_reset_stats();
    JtHttpClientResetStats();
    if(ethdev_present()) ethdev_reset_stats();
}

static void internet_print_packet_stats(void)
{
    JT_UIP_DRIVER_STATS ds;
    JT_HTTP_CLIENT_STATS hs;
    ETHDEV_STATS es;
    unsigned long age,unclassified=0;
    unsigned long ip_recv,ip_reject,ip_accept;
    unsigned long tcp_recv,tcp_reject,tcp_accept;
    unsigned long icmp_recv,icmp_reject,icmp_accept;

    JtUipGetDriverStats(&ds);
    JtHttpClientGetStats(&hs);
    memset(&es,0,sizeof(es));
    if(ethdev_present()) ethdev_get_stats(&es);

    age=(DWORD)(GetTickCount()-ds.reset_tick)/1000UL;
    ip_recv=(unsigned long)uip_stat.ip.recv;
    ip_reject=(unsigned long)uip_stat.ip.drop;
    ip_accept=inet_count_after_reject(ip_recv,ip_reject);
    tcp_recv=(unsigned long)uip_stat.tcp.recv;
    /* tcp.drop covers checksum/ACK rejects. rst counts segments rejected with
     * an outgoing reset (including SYNs for closed ports), and syndrop means
     * a valid listening SYN was rejected because no connection slot existed. */
    tcp_reject=(unsigned long)uip_stat.tcp.drop+
               (unsigned long)uip_stat.tcp.rst+
               (unsigned long)uip_stat.tcp.syndrop;
    tcp_accept=inet_count_after_reject(tcp_recv,tcp_reject);
    icmp_recv=(unsigned long)uip_stat.icmp.recv;
    icmp_reject=(unsigned long)uip_stat.icmp.drop;
    icmp_accept=inet_count_after_reject(icmp_recv,icmp_reject);

    if(ethdev_present() && es.rx_packets>ds.rx_frames_seen)
        unclassified=es.rx_packets-ds.rx_frames_seen;

    printf("INET packet statistics: since reset %lu s\n",age);
    if(ethdev_present())
        printf("  NIC RX=%lu accepted-by-dispatch=%lu rejected-by-dispatch=%lu control/unclassified=%lu\n",
            es.rx_packets,ds.rx_frames_accepted,ds.rx_frames_rejected,unclassified);
    else
        printf("  Link RX seen=%lu accepted-by-dispatch=%lu rejected-by-dispatch=%lu\n",
            ds.rx_frames_seen,ds.rx_frames_accepted,ds.rx_frames_rejected);
    printf("    accepted: ARP=%lu IPv4=%lu JNET/UDP=%lu\n",
        ds.rx_arp_accepted,ds.rx_ipv4_accepted,ds.rx_jnet_accepted);
    printf("    rejected: short=%lu oversize=%lu ethertype=%lu bad-ip-frame=%lu\n",
        ds.rx_reject_short,ds.rx_reject_oversize,
        ds.rx_reject_ethertype,ds.rx_reject_ipv4);
    printf("  IPv4: accepted=%lu rejected=%lu received=%lu checksum=%u fragment=%u proto=%u len=%u/%u vhl=%u\n",
        ip_accept,ip_reject,ip_recv,uip_stat.ip.chkerr,uip_stat.ip.fragerr,
        uip_stat.ip.protoerr,uip_stat.ip.hblenerr,uip_stat.ip.lblenerr,uip_stat.ip.vhlerr);
    printf("  TCP:  accepted=%lu rejected=%lu received=%lu checksum=%u ack=%u closed-port-SYN=%u no-slots=%u resets=%u rexmit=%u\n",
        tcp_accept,tcp_reject,tcp_recv,uip_stat.tcp.chkerr,uip_stat.tcp.ackerr,
        uip_stat.tcp.synrst,uip_stat.tcp.syndrop,uip_stat.tcp.rst,uip_stat.tcp.rexmit);
    printf("  ICMP: accepted=%lu rejected=%lu received=%lu bad-type=%u\n",
        icmp_accept,icmp_reject,icmp_recv,uip_stat.icmp.typeerr);
    printf("  TX:   accepted=%lu rejected=%lu bytes=%lu; NIC errors=%lu\n",
        ds.tx_packets,ds.tx_dropped,ds.tx_bytes,
        ethdev_present()?es.tx_errors:0UL);
    printf("    TCP app payload linearized=%lu packets/%lu bytes invalid=%lu\n",
        ds.tx_appdata_linearized,ds.tx_appdata_bytes,ds.tx_appdata_invalid);
    printf("    HTTP client RX queued=%lu consumed=%lu peak=%lu/%u flow-stop=%lu resume=%lu overflow=%lu\n",
        hs.rx_queued_bytes,hs.rx_consumed_bytes,hs.rx_peak_buffered,32768U,
        hs.flow_stops,hs.flow_restarts,hs.overflow_errors);
    printf("  uIP idle sleeps=%lu requested=%lu ms (1ms=%lu 2ms=%lu 5ms=%lu)\n",
        ds.idle_sleep_calls,ds.idle_sleep_ms,
        ds.idle_sleep_fast,ds.idle_sleep_medium,ds.idle_sleep_max);
    printf("  HTTP diagnostic: port=%d requested=%s listener-marker=%s uIP-listen=%s\n",
        JtHttpdPort(),JtHttpdRequested()?"yes":"no",
        JtHttpdIsListening()?"listening":"stopped",
        uip_is_listening((u16_t)JtHttpdPort())?"yes":"no");
    if(JtHttpdIsListening() && !uip_is_listening((u16_t)JtHttpdPort()))
        printf("  DIAG: HTTP marker is listening but the uIP listen table has no port %d.\n",JtHttpdPort());
    if(uip_stat.tcp.synrst)
        printf("  DIAG: %u TCP SYN packet(s) reached uIP for a closed/unmatched port.\n",uip_stat.tcp.synrst);
    if(uip_stat.tcp.chkerr)
        printf("  DIAG: %u TCP packet(s) failed checksum validation.\n",uip_stat.tcp.chkerr);
    if(uip_stat.ip.chkerr)
        printf("  DIAG: %u IPv4 packet(s) failed header checksum validation.\n",uip_stat.ip.chkerr);
    if(tcp_recv==0 && ds.rx_ipv4_accepted>0)
        printf("  DIAG: IPv4 reaches the dispatcher but no TCP segment has reached the uIP TCP core yet.\n");
}

static void internet_print_status(void)
{
    int state=JtInternetState();
    JT_UIP_DRIVER_STATS ds;
    JNET_STATS js;
    ETHDEV_STATS es;
    JtUipGetDriverStats(&ds);
    jnet_get_stats(&js);
    ethdev_get_stats(&es);
    printf("Internet: %s, stack=%s, COM%d, %d bps\n",
        inet_state_name(state), JtInternetStackName(),
        JtInternetComPort()+1, JtInternetBPS());
    const JNET_CONFIG *nc=jnet_config();
    if(ethdev_present())
    {
        if(nc->configured)
        {
            const char *method=(nc->config_method==JNET_CFG_DHCP)?"DHCP":
                               (nc->config_method==JNET_CFG_QEMU_USER_STATIC)?"QEMU-user fallback":
                               (nc->config_method==JNET_CFG_NFORCE_DIRECT)?"nForce direct-link":"static";
            printf("  IPv4 (%s): %d.%d.%d.%d gateway %d.%d.%d.%d DNS %d.%d.%d.%d",
                method,nc->ip[0],nc->ip[1],nc->ip[2],nc->ip[3],
                nc->gateway[0],nc->gateway[1],nc->gateway[2],nc->gateway[3],
                nc->dns[0],nc->dns[1],nc->dns[2],nc->dns[3]);
            if(nc->config_method==JNET_CFG_DHCP)
                printf(" lease=%lu s remaining=%lu s T1=%lu T2=%lu state=%s last=%d",
                    nc->lease_seconds,jnet_lease_remaining_seconds(),nc->t1_seconds,nc->t2_seconds,
                    jnet_dhcp_state_name(nc->dhcp_state),nc->dhcp_last_error);
            printf("\n");
        }
        else
            printf("  IPv4: not configured (DHCP pending/failed)\n");
    }
    else printf("  IPv4: 10.0.0.5  peer/gateway: 10.0.0.1\n");
    printf("  slipd PID=%d  stack PID=%d  slipOnline=%d  slipStackReady=%d\n",
        JtInternetSlipPID(), JtInternetStackPID(),
        (int)slipOnline, slipStackReady);
    printf("  uIP driver: RX=%lu/%luB TX=%lu/%luB invalid=%lu oversize=%lu timer-catchup=%lu\n",
        ds.rx_packets, ds.rx_bytes, ds.tx_packets, ds.tx_bytes,
        ds.rx_invalid, ds.rx_oversize, ds.timer_catchups);
    printf("              idle-sleep=%lu calls/%lu ms requested (1/2/5ms=%lu/%lu/%lu)\n",
        ds.idle_sleep_calls,ds.idle_sleep_ms,
        ds.idle_sleep_fast,ds.idle_sleep_medium,ds.idle_sleep_max);
    printf("  JNET: DHCP discover=%lu offer=%lu request=%lu ack=%lu nak=%lu timeout=%lu renew=%lu rebind=%lu\n",
        js.dhcp_discovers,js.dhcp_offers,js.dhcp_requests,js.dhcp_acks,js.dhcp_naks,js.dhcp_timeouts,js.dhcp_renewals,js.dhcp_rebinds);
    printf("        link loss/recovery=%lu/%lu fallback DHCP probes=%lu\n",
        js.dhcp_link_losses,js.dhcp_link_recoveries,js.dhcp_fallback_probes);
    printf("        ARP request=%lu hit=%lu timeout=%lu; ping req/reply=%lu/%lu; DNS req/reply=%lu/%lu; UDP queued=%lu dropped=%lu\n",
        js.arp_requests,js.arp_hits,js.arp_timeouts,js.ping_requests,js.ping_replies,js.dns_requests,js.dns_replies,js.udp_rx_queued,js.udp_rx_dropped);
    printf("        owner-wait frames forwarded to uIP=%lu\n",js.owner_forwarded);
    if(ethdev_present())
    {
        printf("  Ethernet: %s, link=%s RX=%lu/%luB err=%lu TX=%lu/%luB err=%lu linkchg=%lu last=%d\n",
            ethdev_name(),ethdev_link_up()?"up":"down/negotiating",
            es.rx_packets,es.rx_bytes,es.rx_errors,es.tx_packets,es.tx_bytes,es.tx_errors,es.link_changes,es.last_error);
        if(nforce_present())
        {
            int nfspeed=nforce_link_speed();
            printf("  MCP61 PHY: addr=%d OUI=0x%x model=0x%x rev=%d%s, MAC mode=",
                nforce_phy_addr(),nforce_phy_oui(),nforce_phy_model(),nforce_phy_rev(),
                (nforce_phy_oui()==0x0732 && nforce_phy_model()==0x0110)?" Realtek RTL8211":"");
            if(nfspeed>0)printf("%d Mbps %s-duplex\n",nfspeed,nforce_full_duplex()?"full":"half");
            else printf("down/negotiating\n");
        }
    }
    else
        printf("  Note: raw SLIP has no peer handshake; 'online' means the local RFC1055 link is ready.\n");
    printf("  HTTP: %s port=%d requested=%s IPv4-autostart=%s\n",
        JtHttpdIsListening()?"listening":"stopped",JtHttpdPort(),
        JtHttpdRequested()?"yes":"no",JtHttpdAutoEnabled()?"enabled":"disabled");
    internet_print_packet_stats();
}

int host_app(int argc,char **argv)
{
    JNET_HOST_RESULT hr;const JNET_CONFIG *nc=jnet_config();int i,rv;
    if(argc!=2){printf("Usage: host <hostname>\n");return 1;}
    if(JtInternetState()!=JTMOS_INET_ONLINE||!ethdev_present()||!nc->configured)
    {printf("host: Ethernet/DNS network is not online.\n");return 1;}
    printf("Using domain server:\nName: %d.%d.%d.%d\nAddress: %d.%d.%d.%d#53\n\n",nc->dns[0],nc->dns[1],nc->dns[2],nc->dns[3],nc->dns[0],nc->dns[1],nc->dns[2],nc->dns[3]);
    rv=jnet_host_request(argv[1],3000,&hr);
    if(rv<0){printf("Host %s not found: resolver error %d\n",argv[1],rv);return 1;}
    for(i=0;i<hr.count;i++)printf("%s has address %d.%d.%d.%d\n",argv[1],hr.addr[i][0],hr.addr[i][1],hr.addr[i][2],hr.addr[i][3]);
    return 0;
}

typedef struct {int operation;BYTE ip[4];char name[240];} ASYNC_NET_ARGUMENT;
static const char *async_state(int s){switch(s){case KASYNC_QUEUED:return "queued";case KASYNC_RUNNING:return "running";case KASYNC_DONE:return "done";case KASYNC_CANCELLED:return "cancelled";case KASYNC_TIMEDOUT:return "timedout";default:return "unknown";}}
static int async_network_job(int id,void *ptr,unsigned int size)
{
    ASYNC_NET_ARGUMENT *a=ptr;DWORD rtt;JNET_HOST_RESULT hr;int i,rv;
    if(size!=sizeof(*a)||kasync_cancelled(id))return -125;
    if(a->operation==1){rv=jnet_ping_request(a->ip,2000,&rtt);if(!rv)printf("[async %d] %d.%d.%d.%d: reply time=%lu ms\n",id,a->ip[0],a->ip[1],a->ip[2],a->ip[3],rtt);else printf("[async %d] ping failed: %d\n",id,rv);return rv;}
    rv=jnet_host_request(a->name,3000,&hr);if(rv<0){printf("[async %d] host %s failed: %d\n",id,a->name,rv);return rv;}for(i=0;i<hr.count;i++)printf("[async %d] %s has address %d.%d.%d.%d\n",id,a->name,hr.addr[i][0],hr.addr[i][1],hr.addr[i][2],hr.addr[i][3]);return 0;
}
int async_app(int argc,char **argv)
{
    ASYNC_NET_ARGUMENT a;KASYNC_STATUS st;int id,q,r,d,rv;
    if(argc<2||!strcmp(argv[1],"status")){kasync_counts(&q,&r,&d);printf("KAsync: queued=%d running=%d finished=%d workers=%d capacity=%d\n",q,r,d,KASYNC_WORKERS,KASYNC_MAX_JOBS);return 0;}
    if((!strcmp(argv[1],"wait")||!strcmp(argv[1],"poll")||!strcmp(argv[1],"cancel"))&&argc==3){if(parse_uint(argv[2],&id)<0)return 1;if(!strcmp(argv[1],"cancel")){rv=kasync_cancel(id);printf("async %d: cancel %s\n",id,rv<0?"failed":"requested");return rv<0;}if(!strcmp(argv[1],"wait"))rv=kasync_wait(id,10000,&st);else rv=kasync_poll(id,&st);if(rv<0){printf("async %d: unavailable (%d)\n",id,rv);return 1;}printf("async %d: %s result=%d\n",id,async_state(st.state),st.result);if(!strcmp(argv[1],"wait")&&(st.state==KASYNC_DONE||st.state==KASYNC_CANCELLED||st.state==KASYNC_TIMEDOUT))kasync_release(id);return 0;}
    memset(&a,0,sizeof(a));
    if(!strcmp(argv[1],"ping")&&argc==3){const JNET_CONFIG *nc=jnet_config();a.operation=1;if(!strcmp(argv[2],"gateway"))memcpy(a.ip,nc->gateway,4);else if(jnet_inet_pton(JNET_AF_INET,argv[2],a.ip)!=1)return 1;}
    else if(!strcmp(argv[1],"host")&&argc==3){if(strlen(argv[2])>=sizeof(a.name))return 1;a.operation=2;strcpy(a.name,argv[2]);}
    else {printf("Usage: async [status|poll ID|wait ID|cancel ID|ping IP|host NAME]\n");return 1;}
    id=kasync_submit(async_network_job,&a,sizeof(a),7000,0);if(id<0){printf("async: submit failed %d\n",id);return 1;}printf("async job %d queued\n",id);return 0;
}

static unsigned long ping_isqrt(unsigned long value)
{
    unsigned long bit=1UL<<30,result=0;
    while(bit>value) bit>>=2;
    while(bit)
    {
        if(value>=result+bit)
        {
            value-=result+bit;
            result=(result>>1)+bit;
        }
        else result>>=1;
        bit>>=2;
    }
    return result;
}

static int network_consume_foreground_interrupt(void)
{
    int terminal=GetCurrentTerminal();
    int input=GetInputTerminal();
    int pid=GetCurrentThread();
    int i;

    if(terminal>=0 && ConsumeTerminalInterrupt(terminal)) return 1;
    if(input>=0 && input!=terminal && ConsumeTerminalInterrupt(input)) return 1;
    /* Some SMSH/SQSH/VT bridge paths can temporarily disagree about the
     * current vs active-input terminal.  The keyboard still records SIGINT on
     * the terminal whose foreground PID is this builtin.  Find that terminal
     * instead of leaving ping unkillable. */
    for(i=0;i<N_MAX_SCREENS;i++)
        if(i!=terminal && i!=input &&
           GetTerminalForegroundProcess(i)==pid &&
           ConsumeTerminalInterrupt(i)) return 1;
    return 0;
}

static int ping_drain_terminal_keys(int terminal)
{
    int key,stop=0;
    if(terminal<0 || terminal>=N_MAX_SCREENS) return 0;
    for(;;)
    {
        key=InputTerminalKeyboardBuffer(&screens[terminal]);
        if(key<0) break;
        key&=0xff;
        if(key==3 || key==27 || key=='q' || key=='Q') stop=1;
        /* Every other byte belongs to ping while it is the foreground job.
         * Discard it instead of letting the terminal FIFO fill and making the
         * keyboard appear frozen after a long-running ping. */
    }
    return stop;
}

static int ping_interrupted(void)
{
    int terminal=GetCurrentTerminal();
    int input=GetInputTerminal();
    if(network_consume_foreground_interrupt()) return 1;
    if(ping_drain_terminal_keys(terminal)) return 1;
    if(input!=terminal && ping_drain_terminal_keys(input)) return 1;
    return 0;
}

static int ping_wait_interval(DWORD started,DWORD interval)
{
    while((DWORD)(GetTickCount()-started)<interval)
    {
        if(ping_interrupted()) return 1;
        SwitchToThread();
    }
    return 0;
}

int ping_app(int argc,char **argv)
{
    BYTE ip[4],ttl=0;
    DWORD rtt=0,start,attempt_start,elapsed;
    DWORD rtt_min=0xffffffffUL,rtt_max=0,rtt_sum=0,mean=0,m2=0;
    JNET_HOST_RESULT host_result;
    const JNET_CONFIG *nc=jnet_config();
    const char *target=NULL;
    int target_is_name=0;
    int count=0;                 /* zero = Linux-style run until Ctrl+C */
    int transmitted=0,received=0,seq=0,rv=0,i;
    int terminal=-1,input_terminal=-1;
    int saved_foreground=0,saved_input_foreground=0;
    int foreground_marked=0,input_foreground_marked=0,interrupted=0;

    if(!ethdev_present()) { printf("ping: Ethernet adapter is not available.\n"); return 1; }
    if(!nc->configured) { printf("ping: IPv4 is not configured yet (DHCP pending/failed).\n"); return 1; }
    if(JtInternetState()!=JTMOS_INET_ONLINE) { printf("ping: Ethernet/uIP network is not online.\n"); return 1; }

    for(i=1;i<argc;i++)
    {
        if(!strcmp(argv[i],"-c"))
        {
            if(++i>=argc || parse_uint(argv[i],&count)<0 || count<1 || count>65535)
            { printf("Usage: ping [-c count] <host|IPv4|gateway>\n"); return 1; }
        }
        else if(argv[i][0]=='-')
        { printf("ping: unsupported option '%s'\nUsage: ping [-c count] <host|IPv4|gateway>\n",argv[i]); return 1; }
        else if(target)
        { printf("Usage: ping [-c count] <host|IPv4|gateway>\n"); return 1; }
        else target=argv[i];
    }
    if(!target) target="gateway";

    /* The builtin itself owns foreground-job marking so Ctrl+C works from
     * both SMSH and the SQSH bridge (and from any future internal caller). */
    terminal=GetCurrentTerminal();
    input_terminal=GetInputTerminal();
    if(terminal>=0) {
        saved_foreground=GetTerminalForegroundProcess(terminal);
        foreground_marked=(SetTerminalForegroundProcess(terminal,GetCurrentThread())==0);
        (void)ConsumeTerminalInterrupt(terminal);
    }
    /* The keyboard routes Ctrl+C through the currently active input terminal.
     * A SQSH builtin can execute on a task terminal which differs from that
     * active VT, so mark both.  Otherwise ETX is left in the wrong FIFO and
     * ping never sees the terminal interrupt. */
    if(input_terminal>=0 && input_terminal!=terminal) {
        saved_input_foreground=GetTerminalForegroundProcess(input_terminal);
        input_foreground_marked=(SetTerminalForegroundProcess(input_terminal,GetCurrentThread())==0);
        (void)ConsumeTerminalInterrupt(input_terminal);
    }

    if(!strcmp(target,"gateway"))
    {
        if(nc->gateway[0]==0&&nc->gateway[1]==0&&nc->gateway[2]==0&&nc->gateway[3]==0)
        {printf("ping: DHCP configuration has no default gateway.\n");rv=1;goto ping_cleanup;}
        memcpy(ip,nc->gateway,4);
    }
    else if(jnet_inet_pton(JNET_AF_INET,target,ip)!=1)
    {
        rv=jnet_host_request(target,3000,&host_result);
        if(rv==JNET_EINTR) { (void)ping_interrupted(); interrupted=1; printf("^C\n"); rv=1; goto ping_cleanup; }
        if(rv<0 || host_result.count<1)
        {printf("ping: %s: DNS lookup failed (error %d)\n",target,rv);rv=1;goto ping_cleanup;}
        memcpy(ip,host_result.addr[0],4);target_is_name=1;
    }


    printf("ping: Ctrl+C, Esc or q stops.\n");
    if(target_is_name)
        printf("PING %s (%d.%d.%d.%d) 56(84) bytes of data.\n",
               target,ip[0],ip[1],ip[2],ip[3]);
    else
        printf("PING %d.%d.%d.%d (%d.%d.%d.%d) 56(84) bytes of data.\n",
               ip[0],ip[1],ip[2],ip[3],ip[0],ip[1],ip[2],ip[3]);
    start=GetTickCount();

    while(count==0 || transmitted<count)
    {
        long delta,delta2;
        unsigned long add;

        if(ping_interrupted()) { interrupted=1; printf("^C\n"); break; }
        seq++;
        attempt_start=GetTickCount();
        transmitted++;
        rv=jnet_ping_request_ex(ip,2000,(WORD)seq,&rtt,&ttl);
        if(rv==JNET_EINTR) { (void)ping_interrupted(); interrupted=1; printf("^C\n"); break; }
        if(rv==0)
        {
            received++;
            printf("64 bytes from %d.%d.%d.%d: icmp_seq=%d ttl=%u time=%lu ms\n",
                   ip[0],ip[1],ip[2],ip[3],seq,(unsigned)ttl,rtt);
            if(rtt<rtt_min) rtt_min=rtt;
            if(rtt>rtt_max) rtt_max=rtt;
            if(0xffffffffUL-rtt_sum>=rtt) rtt_sum+=rtt;
            delta=(long)rtt-(long)mean;
            mean=(DWORD)((long)mean + delta/received);
            delta2=(long)rtt-(long)mean;
            if(delta<0) delta=-delta;
            if(delta2<0) delta2=-delta2;
            if((unsigned long)delta!=0 && (unsigned long)delta2>0xffffffffUL/(unsigned long)delta)
                add=0xffffffffUL;
            else add=(unsigned long)delta*(unsigned long)delta2;
            if(0xffffffffUL-m2<add) m2=0xffffffffUL; else m2+=add;
        }
        else if(rv==JNET_EHOSTUNREACH)
            printf("From %d.%d.%d.%d icmp_seq=%d Destination Host Unreachable\n",ip[0],ip[1],ip[2],ip[3],seq);
        else if(rv==JNET_ETIMEDOUT)
            printf("Request timeout for icmp_seq %d\n",seq);
        else if(rv==JNET_ENETUNREACH)
        {
            printf("ping: no route to %d.%d.%d.%d (no default gateway).\n",ip[0],ip[1],ip[2],ip[3]);
            break; /* permanent configuration error, not a packet timeout */
        }
        else if(rv==JNET_ENETDOWN)
        {
            printf("ping: IPv4 configuration is unavailable.\n");
            break;
        }
        else if(rv==JNET_EBUSY)
            printf("ping: another network request is busy (error %d).\n",rv);
        else
            printf("ping: ICMP request failed for icmp_seq %d (error %d).\n",seq,rv);

        if(ping_interrupted()) { interrupted=1; printf("^C\n"); break; }
        if(count!=0 && transmitted>=count) break;
        if(ping_wait_interval(attempt_start,1000)) { interrupted=1; printf("^C\n"); break; }
    }

ping_summary:
    elapsed=(transmitted>0)?(GetTickCount()-start):0;
    printf("--- %d.%d.%d.%d ping statistics ---\n",ip[0],ip[1],ip[2],ip[3]);
    printf("%d packets transmitted, %d received, %d%% packet loss, time %lums\n",
           transmitted,received,transmitted?((transmitted-received)*100)/transmitted:0,elapsed);
    if(received)
    {
        DWORD avg=rtt_sum/(DWORD)received;
        DWORD variance=m2/(DWORD)received;
        printf("rtt min/avg/max/mdev = %lu/%lu/%lu/%lu ms\n",
               rtt_min,avg,rtt_max,ping_isqrt(variance));
    }
    rv=received?0:1;
ping_cleanup:
    if(input_foreground_marked)
        (void)SetTerminalForegroundProcess(input_terminal,saved_input_foreground>0?saved_input_foreground:0);
    if(foreground_marked)
        (void)SetTerminalForegroundProcess(terminal,saved_foreground>0?saved_foreground:0);
    return interrupted?130:rv;
}


#define NUTGET_HOST_MAX 253
#define NUTGET_PATH_MAX 768
#define NUTGET_URL_MAX  1024
#define NUTGET_HEADER_MAX 8192
#define NUTGET_IO_CHUNK 2048
#define NUTGET_MAX_REDIRECTS 5

typedef struct {
    char host[NUTGET_HOST_MAX+1];
    char path[NUTGET_PATH_MAX+1];
    int port;
} NUTGET_URL;

static int nutget_ascii_tolower(int c)
{
    if(c>='A' && c<='Z') return c-'A'+'a';
    return c;
}

static int nutget_ieq_n(const char *a,const char *b,int n)
{
    int i;
    for(i=0;i<n;i++)
        if(nutget_ascii_tolower((unsigned char)a[i])!=nutget_ascii_tolower((unsigned char)b[i])) return 0;
    return 1;
}

static int nutget_parse_port(const char *s,int n,int *port)
{
    int i,v=0;
    if(n<=0 || !port) return -1;
    for(i=0;i<n;i++)
    {
        if(s[i]<'0'||s[i]>'9') return -1;
        v=v*10+(s[i]-'0');
        if(v>65535) return -1;
    }
    if(v<=0) return -1;
    *port=v;
    return 0;
}

static int nutget_parse_url(const char *text,NUTGET_URL *u)
{
    const char *p,*hostbeg,*pathbeg,*colon=NULL;
    int hostlen,i;
    if(!text||!u||!text[0]) return -1;
    memset(u,0,sizeof(*u));
    u->port=80;

    if(!strncmp(text,"https://",8) || !strncmp(text,"HTTPS://",8)) return -2;
    if(!strncmp(text,"http://",7) || !strncmp(text,"HTTP://",7)) p=text+7;
    else if(strstr(text,"://")) return -3;
    else p=text; /* curl-like convenience: bare host/path means plain HTTP. */

    hostbeg=p;
    while(*p && *p!='/' && *p!='?' && *p!='#')
    {
        if(*p==':') colon=p;
        p++;
    }
    hostlen=(int)((colon?colon:p)-hostbeg);
    if(hostlen<1 || hostlen>NUTGET_HOST_MAX) return -1;
    memcpy(u->host,hostbeg,hostlen);u->host[hostlen]=0;
    for(i=0;i<hostlen;i++) if(u->host[i]=='['||u->host[i]==']') return -1; /* IPv4/DNS only. */

    if(colon)
    {
        if(nutget_parse_port(colon+1,(int)(p-(colon+1)),&u->port)<0) return -1;
    }

    pathbeg=p;
    if(*pathbeg=='\0' || *pathbeg=='#') strcpy(u->path,"/");
    else if(*pathbeg=='?')
    {
        const char *hash=strchr(pathbeg,'#');
        int n=hash?(int)(hash-pathbeg):(int)strlen(pathbeg);
        if(n+1>NUTGET_PATH_MAX) return -1;
        u->path[0]='/';memcpy(u->path+1,pathbeg,n);u->path[n+1]=0;
    }
    else
    {
        const char *hash=strchr(pathbeg,'#');
        int n=hash?(int)(hash-pathbeg):(int)strlen(pathbeg);
        if(n<1 || n>NUTGET_PATH_MAX) return -1;
        memcpy(u->path,pathbeg,n);u->path[n]=0;
    }
    return 0;
}

static void nutget_default_output(const NUTGET_URL *u,char *out,int outsz)
{
    const char *end,*beg;
    int n;
    if(!u||!out||outsz<=0) return;
    end=u->path;
    while(*end && *end!='?' && *end!='#') end++;
    if(end==u->path || end[-1]=='/') { strcpy(out,"index.html"); return; }
    beg=end;
    while(beg>u->path && beg[-1]!='/') beg--;
    n=(int)(end-beg);
    if(n<=0) { strcpy(out,"index.html"); return; }
    if(n>=outsz) n=outsz-1;
    memcpy(out,beg,n);out[n]=0;
}

static int nutget_parse_ulong(const char *s,unsigned long *value)
{
    unsigned long v=0;
    int digits=0;
    if(!s||!value) return -1;
    while(*s==' '||*s=='\t') s++;
    while(*s>='0'&&*s<='9')
    {
        unsigned int d=(unsigned int)(*s-'0');
        if(v>(0xffffffffUL-d)/10UL) return -1;
        v=v*10UL+d;s++;digits++;
    }
    while(*s==' '||*s=='\t') s++;
    if(!digits || (*s!='\0' && *s!='\r' && *s!='\n')) return -1;
    *value=v;return 0;
}

static int nutget_header_value(const char *headers,const char *name,char *out,int outsz)
{
    const char *p=headers,*e,*v;
    int namelen=(int)strlen(name),n;
    if(!headers||!name||!out||outsz<=0) return 0;
    while(*p)
    {
        e=strstr(p,"\r\n");
        if(!e) e=p+strlen(p);
        if((int)(e-p)>namelen && p[namelen]==':' && nutget_ieq_n(p,name,namelen))
        {
            v=p+namelen+1;while(v<e&&(*v==' '||*v=='\t'))v++;
            n=(int)(e-v);if(n>=outsz)n=outsz-1;
            memcpy(out,v,n);out[n]=0;return 1;
        }
        if(!*e)break;
        p=e+2;
        if(*p=='\r'&&p[1]=='\n')break;
    }
    return 0;
}

static int nutget_parse_status(const char *headers)
{
    const char *p;
    if(!headers || strncmp(headers,"HTTP/",5)) return -1;
    p=strchr(headers,' ');if(!p)return -1;
    while(*p==' ')p++;
    if(p[0]<'0'||p[0]>'9'||p[1]<'0'||p[1]>'9'||p[2]<'0'||p[2]>'9')return -1;
    return (p[0]-'0')*100+(p[1]-'0')*10+(p[2]-'0');
}

static int nutget_header_end(const char *buf,int n)
{
    int i;
    for(i=3;i<n;i++) if(buf[i-3]=='\r'&&buf[i-2]=='\n'&&buf[i-1]=='\r'&&buf[i]=='\n') return i+1;
    return -1;
}

static int nutget_interrupted(void)
{
    return network_consume_foreground_interrupt();
}

static int nutget_wait_cancelled(void)
{
    unsigned char discard[256];
    unsigned long start=GetTickCount();
    while(!JtHttpClientDone() && (unsigned long)(GetTickCount()-start)<2000UL) SwitchToThread();
    while(JtHttpClientRead(discard,sizeof(discard))>0) { }
    return 0;
}

static int nutget_make_redirect(const NUTGET_URL *base,const char *location,char *out,int outsz)
{
    int n;
    if(!location||!location[0]||!out||outsz<16)return -1;
    if(strlen(location)>=8 && nutget_ieq_n(location,"https://",8)) return -2;
    if(strlen(location)>=7 && nutget_ieq_n(location,"http://",7))
    {
        if((int)strlen(location)>=outsz)return -1;strcpy(out,location);return 0;
    }
    if(location[0]=='/')
    {
        if(base->port==80) n=sprintf(out,"http://%s%s",base->host,location);
        else n=sprintf(out,"http://%s:%d%s",base->host,base->port,location);
        return (n>0&&n<outsz)?0:-1;
    }
    return -3;
}

int nutget_app(int argc,char **argv)
{
    NUTGET_URL url;
    JNET_HOST_RESULT hr;
    unsigned char ip[4],io[NUTGET_IO_CHUNK];
    char request[1536],headers[NUTGET_HEADER_MAX],output[512],location[NUTGET_URL_MAX],nexturl[NUTGET_URL_MAX];
    char value[256];
    const char *urlarg=NULL,*outarg=NULL;
    unsigned long content_length=0,body_bytes=0,last_report=0;
    int have_length=0,header_used=0,header_done=0,status=-1;
    int i,n,k,rv=1,terminal=-1,saved_foreground=0,foreground_marked=0,redirects=0;
    int redirect_status=0,parse_rv;
    FILE *out=NULL;

    for(i=1;i<argc;i++)
    {
        if(!strcmp(argv[i],"-h")||!strcmp(argv[i],"--help"))
        {
            printf("Usage: nutget [-o FILE] http://HOST[:PORT]/PATH [FILE]\n");
            printf("Download one file with plain HTTP over JTMOS uIP. HTTPS/TLS is not supported.\n");
            printf("HTTP redirects are followed when they remain plain http:// (maximum %d).\n",NUTGET_MAX_REDIRECTS);
            return 0;
        }
        if(!strcmp(argv[i],"-o"))
        {
            if(++i>=argc){printf("nutget: -o requires a filename.\n");return 2;}
            outarg=argv[i];continue;
        }
        if(argv[i][0]=='-'){printf("nutget: unsupported option '%s'.\n",argv[i]);return 2;}
        if(!urlarg) urlarg=argv[i];
        else if(!outarg) outarg=argv[i];
        else {printf("Usage: nutget [-o FILE] URL [FILE]\n");return 2;}
    }
    if(!urlarg){printf("Usage: nutget [-o FILE] http://HOST[:PORT]/PATH [FILE]\n");return 2;}
    if(strlen(urlarg)>=sizeof(nexturl)){printf("nutget: URL is too long.\n");return 2;}
    strcpy(nexturl,urlarg);

    terminal=GetCurrentTerminal();
    if(terminal>=0)
    {
        saved_foreground=GetTerminalForegroundProcess(terminal);
        foreground_marked=(SetTerminalForegroundProcess(terminal,GetCurrentThread())==0);
        (void)ConsumeTerminalInterrupt(terminal);
    }

nutget_redirect:
    parse_rv=nutget_parse_url(nexturl,&url);
    if(parse_rv==-2){printf("nutget: HTTPS/TLS is not supported; use an http:// URL.\n");rv=2;goto nutget_cleanup;}
    if(parse_rv<0){printf("nutget: invalid or unsupported URL '%s'.\n",nexturl);rv=2;goto nutget_cleanup;}

    if(redirects==0)
    {
        if(outarg)
        {
            if(strlen(outarg)>=sizeof(output)){printf("nutget: output filename is too long.\n");rv=2;goto nutget_cleanup;}
            strcpy(output,outarg);
        }
        else nutget_default_output(&url,output,sizeof(output));
    }

    if(JtInternetState()!=JTMOS_INET_ONLINE)
    {printf("nutget: uIP network is not online.\n");rv=1;goto nutget_cleanup;}

    if(jnet_inet_pton(JNET_AF_INET,url.host,ip)!=1)
    {
        if(!jnet_config()->configured)
        {printf("nutget: DNS is unavailable without configured Ethernet IPv4; use a numeric IPv4 URL.\n");rv=1;goto nutget_cleanup;}
        rv=jnet_host_request(url.host,5000,&hr);
        if(rv==JNET_EINTR || nutget_interrupted()){printf("^C\n");rv=130;goto nutget_cleanup;}
        if(rv<0 || hr.count<1){printf("nutget: DNS lookup for %s failed (error %d).\n",url.host,rv);rv=1;goto nutget_cleanup;}
        memcpy(ip,hr.addr[0],4);
    }

    if(url.port==80)
        sprintf(request,"GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: nutget/JTMOS-V68\r\nAccept: */*\r\nConnection: close\r\n\r\n",url.path,url.host);
    else
        sprintf(request,"GET %s HTTP/1.0\r\nHost: %s:%d\r\nUser-Agent: nutget/JTMOS-V68\r\nAccept: */*\r\nConnection: close\r\n\r\n",url.path,url.host,url.port);
    if(strlen(request)>=sizeof(request)){printf("nutget: HTTP request is too long.\n");rv=2;goto nutget_cleanup;}

    printf("nutget: http://%s:%d%s -> %s\n",url.host,url.port,url.path,output);
    printf("nutget: connecting to %d.%d.%d.%d:%d...\n",ip[0],ip[1],ip[2],ip[3],url.port);
    rv=JtHttpClientStart(ip,url.port,request);
    if(rv<0){printf("nutget: TCP start failed (error %d).\n",rv);rv=1;goto nutget_cleanup;}

    header_used=0;header_done=0;status=-1;have_length=0;content_length=0;body_bytes=0;last_report=0;redirect_status=0;location[0]=0;

    for(;;)
    {
        if(nutget_interrupted())
        {
            printf("^C\nnutget: download interrupted.\n");
            JtHttpClientCancel();nutget_wait_cancelled();rv=130;goto nutget_cleanup;
        }

        n=JtHttpClientRead(io,sizeof(io));
        if(n<0){printf("nutget: TCP receive failed (%d).\n",n);JtHttpClientCancel();nutget_wait_cancelled();rv=1;goto nutget_cleanup;}
        if(n>0)
        {
            k=0;
            if(!header_done)
            {
                while(k<n && !header_done)
                {
                    if(header_used>=NUTGET_HEADER_MAX-1)
                    {printf("nutget: HTTP response headers exceed %d bytes.\n",NUTGET_HEADER_MAX);JtHttpClientCancel();nutget_wait_cancelled();rv=1;goto nutget_cleanup;}
                    headers[header_used++]=(char)io[k++];headers[header_used]=0;
                    if(nutget_header_end(headers,header_used)>=0)
                    {
                        header_done=1;
                        status=nutget_parse_status(headers);
                        if(status<0){printf("nutget: invalid HTTP status line.\n");JtHttpClientCancel();nutget_wait_cancelled();rv=1;goto nutget_cleanup;}
                        if(nutget_header_value(headers,"Transfer-Encoding",value,sizeof(value)) &&
                           (strstr(value,"chunked")||strstr(value,"Chunked")||strstr(value,"CHUNKED")))
                        {printf("nutget: server returned chunked transfer encoding; this HTTP/1.0 client requires Content-Length or connection-close framing.\n");JtHttpClientCancel();nutget_wait_cancelled();rv=1;goto nutget_cleanup;}
                        if(nutget_header_value(headers,"Content-Length",value,sizeof(value)) && nutget_parse_ulong(value,&content_length)==0) have_length=1;
                        if(nutget_header_value(headers,"Location",location,sizeof(location))) { }

                        if(status>=300 && status<400 && location[0])
                        {
                            redirect_status=1;
                            printf("nutget: HTTP %d redirect -> %s\n",status,location);
                            JtHttpClientCancel();nutget_wait_cancelled();
                            if(++redirects>NUTGET_MAX_REDIRECTS){printf("nutget: too many redirects.\n");rv=1;goto nutget_cleanup;}
                            parse_rv=nutget_make_redirect(&url,location,nexturl,sizeof(nexturl));
                            if(parse_rv==-2){printf("nutget: redirect requires HTTPS/TLS, which is intentionally unsupported.\n");rv=1;goto nutget_cleanup;}
                            if(parse_rv<0){printf("nutget: unsupported redirect Location '%s'.\n",location);rv=1;goto nutget_cleanup;}
                            goto nutget_redirect;
                        }
                        if(status<200 || status>=300)
                        {printf("nutget: HTTP server returned status %d.\n",status);JtHttpClientCancel();nutget_wait_cancelled();rv=1;goto nutget_cleanup;}

                        out=fopen(output,"wb");
                        if(!out){printf("nutget: cannot create '%s'.\n",output);JtHttpClientCancel();nutget_wait_cancelled();rv=1;goto nutget_cleanup;}
                        if(have_length) printf("nutget: HTTP %d, Content-Length %lu bytes.\n",status,content_length);
                        else printf("nutget: HTTP %d, length unknown; reading until connection close.\n",status);
                    }
                }
            }
            if(header_done && !redirect_status && k<n)
            {
                int body_n=n-k;
                if(have_length && body_bytes+(unsigned long)body_n>content_length)
                    body_n=(int)(content_length-body_bytes);
                if(body_n>0 && fwrite(io+k,1,(size_t)body_n,out)!=(size_t)body_n)
                {printf("nutget: write failed for '%s' after %lu bytes.\n",output,body_bytes);JtHttpClientCancel();nutget_wait_cancelled();rv=1;goto nutget_cleanup;}
                body_bytes+=(unsigned long)body_n;
                if(body_bytes-last_report>=262144UL)
                {
                    if(have_length) printf("nutget: %lu/%lu bytes\n",body_bytes,content_length);
                    else printf("nutget: %lu bytes\n",body_bytes);
                    last_report=body_bytes;
                }
            }
            continue;
        }

        if(JtHttpClientDone()) break;
        SwitchToThread();
    }

    rv=JtHttpClientResult();
    if(rv<0)
    {
        printf("nutget: TCP transfer failed (error %d).\n",rv);
        rv=1;goto nutget_cleanup;
    }
    if(!header_done){printf("nutget: connection closed before complete HTTP headers.\n");rv=1;goto nutget_cleanup;}
    if(have_length && body_bytes!=content_length)
    {
        printf("nutget: incomplete file: got %lu of %lu bytes.\n",body_bytes,content_length);
        rv=1;goto nutget_cleanup;
    }
    if(out){if(fclose(out)!=0){out=NULL;(void)remove(output);printf("nutget: close/flush failed for '%s'.\n",output);rv=1;goto nutget_cleanup;}out=NULL;}
    printf("nutget: saved %lu bytes to %s\n",body_bytes,output);
    rv=0;

nutget_cleanup:
    if(out){fclose(out);out=NULL;if(rv!=0)(void)remove(output);}
    if(foreground_marked) (void)SetTerminalForegroundProcess(terminal,saved_foreground>0?saved_foreground:0);
    return rv;
}

int internet_app(int argc, char **argv)
{
    const char *action="status";
    int com=1;
    int bps=115200;
    int rv;
    DWORD start;

    if(argc>1 && argv[1]!=NULL)
        action=argv[1];

    if(!strcmp(action,"status"))
    {
        internet_print_status();
        return 0;
    }

    if(!strcmp(action,"stats"))
    {
        if(argc>2)
        {
            if(argc==3 && (!strcmp(argv[2],"reset") || !strcmp(argv[2],"clear")))
            {
                internet_reset_packet_stats();
                printf("INET packet statistics reset; counters now start at zero.\n");
                internet_print_packet_stats();
                return 0;
            }
            printf("Usage: inet stats [reset]\n");
            return 1;
        }
        internet_print_packet_stats();
        return 0;
    }

    if(!strcmp(action,"static"))
    {
        BYTE ip[4],mask[4],gw[4]={0,0,0,0},dns[4]={0,0,0,0};
        if(argc<4 || argc>6 ||
           jnet_inet_pton(JNET_AF_INET,argv[2],ip)!=1 ||
           jnet_inet_pton(JNET_AF_INET,argv[3],mask)!=1 ||
           (argc>4 && jnet_inet_pton(JNET_AF_INET,argv[4],gw)!=1) ||
           (argc>5 && jnet_inet_pton(JNET_AF_INET,argv[5],dns)!=1))
        {
            printf("Usage: internet static IP MASK [GATEWAY] [DNS]\n");
            return 1;
        }
        if(!ethdev_present() && jnet_init_ethernet()<0)
        {
            printf("internet: no Ethernet adapter available.\n");
            return 1;
        }
        if(JtInternetState()==JTMOS_INET_OFFLINE)
        {
            rv=JtInternetStart(1,115200);
            if(rv<0 && rv!=1) { printf("internet: unable to start uIP (error %d).\n",rv); return 1; }
        }
        if(jnet_configure_static(ip,mask,gw,dns)<0)
        {
            printf("internet: unable to apply static IPv4 configuration.\n");
            return 1;
        }
        internet_print_status();
        return 0;
    }

    if(!strcmp(action,"restart") || !strcmp(action,"reset"))
    {
        printf("Internet: restarting TCP/IP and Ethernet...\n");
        rv=JtInternetRestart();
        if(rv<0)
        {
            printf("internet: restart failed (error %d).\n",rv);
            internet_print_status();
            return 1;
        }
        printf("Internet: Ethernet controller and TCP/IP state restarted; requesting fresh DHCP configuration.\n");
        start=GetTickCount();
        while(JtInternetState()==JTMOS_INET_STARTING &&
              (DWORD)(GetTickCount()-start)<3500UL)
            SwitchToThread();
        /* `inet reset` is the epoch for packet diagnostics: clear every
         * counter after DHCP/restart traffic has settled so subsequent values
         * describe exactly the test traffic generated by the user. */
        internet_reset_packet_stats();
        printf("Internet: packet statistics reset.\n");
        internet_print_status();
        return 0;
    }

    if(!strcmp(action,"stop") || !strcmp(action,"down"))
    {
        rv=JtInternetStop();
        if(rv==1)
        {
            printf("Internet: already offline.\n");
            return 0;
        }
        printf("Internet: stopping background network/uIP workers...\n");
        start=GetTickCount();
        while(JtInternetState()!=JTMOS_INET_OFFLINE &&
              (DWORD)(GetTickCount()-start)<2000)
            SwitchToThread();
        internet_print_status();
        return 0;
    }

    /* Starting is explicit.  A bare `inet`/`internet` is status so it is
     * useful in pipelines such as `inet|more`.  Optional start syntax:
     * internet start com2 115200 */
    if(strcmp(action,"start") && strcmp(action,"up"))
    {
        printf("Usage: internet [start [com1|com2|com3|com4] [bps]|static IP MASK [GW] [DNS]|restart|reset|stop|status|stats [reset]]\n");
        return 1;
    }

    if(argc>2)
    {
        com=parse_com(argv[2]);
        if(com<0)
        {
            printf("internet: invalid COM port '%s'.\n", argv[2]);
            return 1;
        }
    }
    if(argc>3)
    {
        if(parse_uint(argv[3], &bps) != 0 || bps<1200 || bps>115200)
        {
            printf("internet: baud rate must be 1200..115200.\n");
            return 1;
        }
    }

    rv=JtInternetStart(com,bps);
    if(rv==1)
    {
        printf("Internet: already started.\n");
        internet_print_status();
        return 0;
    }
    if(rv<0)
    {
        printf("internet: unable to start Ethernet/SLIP uIP (error %d).\n",rv);
        return 1;
    }

    if(ethdev_present())
    {
        printf("Internet: starting uIP over %s Ethernet in background.\n",ethdev_name());
        if(ethdev_backend()==ETHDEV_NFORCE)
            printf("Internet: direct-link fallback is JTMOS 192.168.50.2/24; peer may use 192.168.50.1/24.\n");
    }
    else
    {
        printf("Internet: starting RFC1055 SLIP on COM%d at %d bps in background.\n",com+1,bps);
        printf("Internet: Ubuntu peer must use 10.0.0.1, JTMOS uses 10.0.0.5.\n");
    }

    /* Give the worker enough time to initialize in the common direct-SLIP
     * case, but do not keep SMSH blocked if the peer is absent. */
    start=GetTickCount();
    while(JtInternetState()==JTMOS_INET_STARTING &&
          (DWORD)(GetTickCount()-start)<3500)
        SwitchToThread();
    internet_print_status();
    return 0;
}

int telnetd_app(int argc,char **argv)
{
    const char *action="status";
    int port=2323,rv;
    if(argc>1 && argv[1]) action=argv[1];
    if(argc>2) {
        if(parse_uint(argv[2],&port)!=0 || port<=0 || port>65535) {
            printf("telnetd: invalid TCP port.\n"); return 1;
        }
    } else if(JtTelnetdPort()>0) port=JtTelnetdPort();

    if(!strcmp(action,"status")) {
        printf("TELNETD: %s, requested=%s, TCP port=%d, DHCP autostart=%s, password=%s\n",
            JtTelnetdIsListening()?"listening":"stopped",
            JtTelnetdRequested()?"yes":"no",JtTelnetdPort(),
            JtTelnetdAutoEnabled()?"enabled":"disabled",
            JtTelnetdPasswordReady()?"configured":"NOT SET");
        printf("TELNETD shell: /bin/sqsh.bin; password source: global TELNETD_PASSWORD\n");
        return 0;
    }
    if(!strcmp(action,"stop")) {
        JtTelnetdDisable();
        printf("TELNETD: stop requested.\n"); return 0;
    }
    if(!strcmp(action,"auto")) {
        rv=JtTelnetdSetAuto(1,port);
        if(rv==-2) {
            printf("telnetd: set a >=8 character password first: setglobal TELNETD_PASSWORD <password>\n");
            return 1;
        }
        if(rv<0) { printf("telnetd: cannot enable auto mode (%d).\n",rv); return 1; }
        printf("TELNETD: DHCP autostart enabled on TCP port %d.\n",port); return 0;
    }
    if(strcmp(action,"start")) {
        printf("Usage: telnetd [status|start [port]|auto [port]|stop]\n");
        return 1;
    }
    rv=JtTelnetdRequest(port);
    if(rv==-2) {
        printf("telnetd: refusing unauthenticated listener; run: setglobal TELNETD_PASSWORD <password>\n");
        return 1;
    }
    if(rv<0) { printf("telnetd: start failed (%d).\n",rv); return 1; }
    if(JtInternetState()==JTMOS_INET_OFFLINE) {
        rv=JtInternetStart(1,115200);
        if(rv<0 && rv!=1) { printf("telnetd: network start failed (%d).\n",rv); return 1; }
    }
    printf("TELNETD: SQSH listener requested on TCP port %d.\n",port);
    return 0;
}


int www_app(int argc, char **argv)
{
    const char *action="start";
    int port=8080;
    int rv;

    if(argc>1 && argv[1]!=NULL)
        action=argv[1];

    if(!strcmp(action,"status"))
    {
        const JNET_CONFIG *nc=jnet_config();
        printf("WWW: %s, requested=%s, TCP port=%d, DHCP autostart=%s\n",
            JtHttpdIsListening()?"listening":"not listening",
            JtHttpdRequested()?"yes":"no", JtHttpdPort(),
            JtHttpdAutoEnabled()?"enabled":"disabled");
        if(nc && nc->configured)
            printf("WWW URL: http://%d.%d.%d.%d:%d/\n",
                nc->ip[0],nc->ip[1],nc->ip[2],nc->ip[3],JtHttpdPort());
        else if(!ethdev_present())
            printf("WWW URL: http://10.0.0.5:%d/\n",JtHttpdPort());
        else
            printf("WWW URL: waiting for an IPv4 configuration.\n");
        return 0;
    }

    if(!strcmp(action,"stop"))
    {
        JtHttpdDisable();
        printf("WWW: stop requested; uIP will remove the listener in background.\n");
        return 0;
    }

    if(!strcmp(action,"auto"))
    {
        JtHttpdSetAuto(1);
        if(JtInternetState()==JTMOS_INET_OFFLINE)
        {
            rv=JtInternetStart(1,115200);
            if(rv<0 && rv!=1)
            {printf("www: unable to start its network/uIP dependency (error %d).\n",rv);return 1;}
        }
        printf("WWW: DHCP autostart enabled; TCP port 8080 starts after a lease is bound.\n");
        return 0;
    }

    if(strcmp(action,"start"))
    {
        printf("Usage: www [start [port]|auto|stop|status]\n");
        return 1;
    }

    if(argc>2)
    {
        if(parse_uint(argv[2], &port) != 0 || port<=0 || port>65535)
        {
            printf("www: invalid TCP port.\n");
            return 1;
        }
    }

    if(JtInternetState()==JTMOS_INET_OFFLINE)
    {
        rv=JtInternetStart(1,115200);
        if(rv<0 && rv!=1)
        {
            printf("www: unable to start its network/uIP dependency (error %d).\n",rv);
            return 1;
        }
        printf("WWW: network dependency started on COM2/115200.\n");
    }

    if(JtHttpdEnable(port)!=0)
    {
        printf("www: unable to configure port %d.\n",port);
        return 1;
    }

    printf("WWW: background server requested on TCP port %d.\n",port);
    printf("WWW: SMSH returns now; the uIP service thread keeps the server alive.\n");
    {
        const JNET_CONFIG *nc=jnet_config();
        if(nc && nc->configured)
            printf("WWW: browse to http://%d.%d.%d.%d:%d/\n",
                nc->ip[0],nc->ip[1],nc->ip[2],nc->ip[3],port);
        else
            printf("WWW: URL becomes available after IPv4 configuration.\n");
    }
    return 0;
}
