/* rmwildcard.c - SMSH substring wildcard delete builtin. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rmwildcard.h"

#ifdef JTMOS
#include "kernel32.h"
#include "jtmfs.h"
#include "jtmfsAccess.h"

typedef struct rm_match {
    struct rm_match *next;
    char name[34];
} RM_MATCH;

static void rm_free_matches(RM_MATCH *head)
{
    RM_MATCH *next;

    while(head != NULL) {
        next = head->next;
        free(head);
        head = next;
    }
}

int rm_wildcard_main(int argc, char **argv)
{
    int dnr;
    int db;
    int matches;
    int deleted;
    int failures;
    int done;
    DIRWALK *dw;
    JTMFS_FILE_ENTRY *fe;
    RM_MATCH *head;
    RM_MATCH *tail;
    RM_MATCH *item;

    if(argc != 2 || argv == NULL || argv[1] == NULL || argv[1][0] == '\0') {
        printf("Usage: rm_wildcard [match string]\n");
        printf("Example: rm_wildcard lala\n");
        printf("Deletes regular files whose names contain the match string.\n");
        return 1;
    }

    dnr = GetCurrentDNR();
    db = GetCurrentDB();
    if(dnr < 0 || db <= 0 || !jtmfat_isJTMFS(dnr)) {
        printf("rm_wildcard: current directory is not on JTMFS.\n");
        return 1;
    }

    dw = (DIRWALK *)malloc(sizeof(DIRWALK));
    if(dw == NULL) {
        printf("rm_wildcard: unable to allocate directory walker.\n");
        return 1;
    }
    memset(dw, 0, sizeof(DIRWALK));

    if(jtmfs_ffirst(dnr, db, dw) != 0) {
        printf("rm_wildcard: unable to read current directory.\n");
        free(dw);
        return 1;
    }

    head = NULL;
    tail = NULL;
    matches = 0;
    done = 0;
    while(!done) {
        fe = dw->fe;
        if(fe != NULL &&
           fe->name[0] != '\0' &&
           !jtmfs_entryIsDeleted(fe) &&
           !JTMFS_TYPE_IS_DIRECTORY(fe->type) &&
           !JTMFS_TYPE_IS_DIRNAME(fe->type) &&
           strcmp(fe->name, ".") != 0 &&
           strcmp(fe->name, "..") != 0 &&
           strstr(fe->name, argv[1]) != NULL) {
            item = (RM_MATCH *)malloc(sizeof(RM_MATCH));
            if(item == NULL) {
                printf("rm_wildcard: out of memory while collecting matches.\n");
                jtmfs_fend(dw);
                free(dw);
                rm_free_matches(head);
                return 1;
            }
            memset(item, 0, sizeof(RM_MATCH));
            strncpy(item->name, fe->name, sizeof(item->name) - 1U);
            item->name[sizeof(item->name) - 1U] = '\0';
            item->next = NULL;
            if(tail != NULL)
                tail->next = item;
            else
                head = item;
            tail = item;
            ++matches;
        }

        if(jtmfs_fnext(dnr, dw) != 0)
            done = 1;
    }
    jtmfs_fend(dw);
    free(dw);

    deleted = 0;
    failures = 0;
    item = head;
    while(item != NULL) {
        printf("rm_wildcard: deleting %s ... ", item->name);
        if(jtmfs_DeleteFile(dnr, item->name, db) != 0) {
            printf("FAILED\n");
            ++failures;
        } else if(jtmfs_Fexist(dnr, item->name, db) != 0) {
            printf("FAILED (still exists)\n");
            ++failures;
        } else {
            printf("OK\n");
            ++deleted;
        }
        item = item->next;
    }

    rm_free_matches(head);
    printf("rm_wildcard: %d/%d file(s) deleted", deleted, matches);
    if(failures != 0)
        printf(", %d failure(s)", failures);
    printf(".\n");
    return failures ? 1 : 0;
}

#else /* !JTMOS */

#include <dirent.h>
#include <unistd.h>

int rm_wildcard_main(int argc, char **argv)
{
    DIR *dir;
    struct dirent *de;
    char **names;
    char **grown;
    int count;
    int capacity;
    int i;
    int deleted;

    if(argc != 2 || argv == NULL || argv[1] == NULL || argv[1][0] == '\0') {
        printf("Usage: rm_wildcard [match string]\n");
        return 1;
    }
    dir = opendir(".");
    if(dir == NULL)
        return 1;
    names = NULL;
    count = 0;
    capacity = 0;
    while((de = readdir(dir)) != NULL) {
        if(strstr(de->d_name, argv[1]) == NULL ||
           strcmp(de->d_name, ".") == 0 || strcmp(de->d_name, "..") == 0)
            continue;
        if(count == capacity) {
            int new_capacity;
            new_capacity = capacity == 0 ? 8 : capacity * 2;
            grown = (char **)realloc(names, (size_t)new_capacity * sizeof(char *));
            if(grown == NULL)
                break;
            names = grown;
            capacity = new_capacity;
        }
        names[count] = (char *)malloc(strlen(de->d_name) + 1U);
        if(names[count] == NULL)
            break;
        strcpy(names[count], de->d_name);
        ++count;
    }
    closedir(dir);

    deleted = 0;
    for(i = 0; i < count; ++i) {
        if(unlink(names[i]) == 0)
            ++deleted;
        free(names[i]);
    }
    free(names);
    printf("rm_wildcard: %d/%d file(s) deleted.\n", deleted, count);
    return deleted == count ? 0 : 1;
}

#endif
