# Makefile hierarchy

This package has been normalized so each meaningful source/header directory has a `Makefile`.

## Linux / SDL2 / GraOS

From the package root:

```sh
make
make check
make clean
```

The default Linux build creates:

- Linux Postman/PPCS wrapper and daemon
- SDL2/GraOS core host compatibility library
- portable JTMOS applications under `build/bin/`

## Native JTMOS

```sh
make JTMOS=1
```

This preserves the original application `*.mak` files and their i486 JTMOS build path. Kernel directories (`chiplevel`, `init`, `term`) are retained as native source, but this archive does not contain the complete original kernel linker/build tree needed to produce the whole JTMOS kernel by itself.

## Useful subdirectory commands

```sh
make -C apps
make -C compat/apps_sdl2
make -C compat/linux_postman
make -C compat/linux_sdl2
make -C chiplevel
make -C init
make -C term
```

The old `compat/linux_sdl2/Makefile.host` is retained as a wrapper around the new `Makefile`.
