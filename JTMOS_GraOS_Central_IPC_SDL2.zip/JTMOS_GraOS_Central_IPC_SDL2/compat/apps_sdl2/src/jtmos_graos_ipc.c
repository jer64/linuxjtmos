#define _GNU_SOURCE
#include "jtmos_graos_ipc.h"

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/un.h>
#include <unistd.h>

static char g_path[108];
static int g_path_ready;

const char *jtmos_graos_socket_path(void)
{
    const char *env = getenv("JTMOS_GRAOS_SOCKET");
    if (env && *env) return env;
    if (!g_path_ready) {
        snprintf(g_path, sizeof(g_path), "/tmp/jtmos-graos-%lu.sock",
                 (unsigned long)getuid());
        g_path_ready = 1;
    }
    return g_path;
}

static int write_full(int fd, const void *buf, size_t len)
{
    const unsigned char *p = (const unsigned char *)buf;
    while (len) {
        ssize_t n = write(fd, p, len);
        if (n < 0) { if (errno == EINTR) continue; return -1; }
        if (n == 0) return -1;
        p += (size_t)n;
        len -= (size_t)n;
    }
    return 0;
}

static int read_full(int fd, void *buf, size_t len)
{
    unsigned char *p = (unsigned char *)buf;
    while (len) {
        ssize_t n = read(fd, p, len);
        if (n < 0) { if (errno == EINTR) continue; return -1; }
        if (n == 0) return -1;
        p += (size_t)n;
        len -= (size_t)n;
    }
    return 0;
}

static int connect_server(void)
{
    int fd;
    struct sockaddr_un sa;
    const char *path = jtmos_graos_socket_path();
    fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    memset(&sa, 0, sizeof(sa));
    sa.sun_family = AF_UNIX;
    if (strlen(path) >= sizeof(sa.sun_path)) {
        close(fd); errno = ENAMETOOLONG; return -1;
    }
    strcpy(sa.sun_path, path);
    if (connect(fd, (struct sockaddr *)&sa, sizeof(sa)) != 0) {
        close(fd);
        return -1;
    }
    return fd;
}

static int sibling_graos(char *out, size_t n)
{
    char exe[PATH_MAX];
    ssize_t l = readlink("/proc/self/exe", exe, sizeof(exe)-1);
    char *slash;
    if (l <= 0 || (size_t)l >= sizeof(exe)) return -1;
    exe[l] = 0;
    slash = strrchr(exe, '/');
    if (!slash) return -1;
    *slash = 0;
    if (snprintf(out, n, "%s/graos", exe) >= (int)n) return -1;
    return 0;
}

static int start_server(void)
{
    const char *forced = getenv("JTMOS_GRAOS_BIN");
    char path[PATH_MAX];
    pid_t p;
    if (forced && *forced) {
        snprintf(path, sizeof(path), "%s", forced);
    } else if (sibling_graos(path, sizeof(path)) != 0) {
        snprintf(path, sizeof(path), "graos");
    }

    p = fork();
    if (p < 0) return -1;
    if (p == 0) {
        int fd;
        (void)setsid();
        fd = open("/dev/null", O_RDONLY);
        if (fd >= 0) { (void)dup2(fd, STDIN_FILENO); if (fd > STDERR_FILENO) close(fd); }
        execl(path, path, "--auto", (char *)NULL);
        execlp("graos", "graos", "--auto", (char *)NULL);
        _exit(127);
    }
    return 0;
}

int jtmos_graos_client_ensure(void)
{
    int fd, i;
    JTMOS_GRAOS_WIRE req, resp;
    fd = connect_server();
    if (fd >= 0) { close(fd); return 0; }
    if (getenv("JTMOS_GRAOS_NO_AUTOSTART")) return -1;
    if (start_server() != 0) return -1;
    for (i = 0; i < 200; ++i) {
        usleep(10000);
        fd = connect_server();
        if (fd >= 0) { close(fd); break; }
    }
    if (fd < 0) return -1;
    memset(&req, 0, sizeof(req));
    req.magic = JTMOS_GRAOS_WIRE_MAGIC;
    req.version = JTMOS_GRAOS_WIRE_VERSION;
    req.op = GRAOS_OP_PING;
    req.pid = (int32_t)getpid();
    if (jtmos_graos_client_call(&req, NULL, &resp, NULL, 0, NULL) != 0)
        return -1;
    return resp.status;
}

int jtmos_graos_client_call(JTMOS_GRAOS_WIRE *req,
                            const void *payload,
                            JTMOS_GRAOS_WIRE *resp,
                            void *out,
                            size_t out_cap,
                            size_t *out_len)
{
    int fd;
    size_t left;
    unsigned char discard[4096];
    if (out_len) *out_len = 0;
    if (!req || !resp) return -1;
    if (req->payload_len > JTMOS_GRAOS_MAX_PAYLOAD) return -1;
    fd = connect_server();
    if (fd < 0) return -1;
    if (write_full(fd, req, sizeof(*req)) != 0 ||
        (req->payload_len && (!payload || write_full(fd, payload, req->payload_len) != 0)) ||
        read_full(fd, resp, sizeof(*resp)) != 0) {
        close(fd); return -1;
    }
    if (resp->magic != JTMOS_GRAOS_WIRE_MAGIC ||
        resp->version != JTMOS_GRAOS_WIRE_VERSION ||
        resp->payload_len > JTMOS_GRAOS_MAX_PAYLOAD) {
        close(fd); return -1;
    }
    left = resp->payload_len;
    if (left && out && out_cap) {
        size_t take = left < out_cap ? left : out_cap;
        if (read_full(fd, out, take) != 0) { close(fd); return -1; }
        if (out_len) *out_len = take;
        left -= take;
    }
    while (left) {
        size_t take = left < sizeof(discard) ? left : sizeof(discard);
        if (read_full(fd, discard, take) != 0) { close(fd); return -1; }
        left -= take;
    }
    close(fd);
    return 0;
}
