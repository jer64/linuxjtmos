#ifndef JTMOS_GRAOS_CLIENT_IPC_INTERNAL_H
#define JTMOS_GRAOS_CLIENT_IPC_INTERNAL_H
#include <stddef.h>
#include <jtmos/graos_ipc.h>

int jtmos_graos_client_ensure(void);
int jtmos_graos_client_call(JTMOS_GRAOS_WIRE *req,
                            const void *payload,
                            JTMOS_GRAOS_WIRE *resp,
                            void *out,
                            size_t out_cap,
                            size_t *out_len);
const char *jtmos_graos_socket_path(void);

#endif
