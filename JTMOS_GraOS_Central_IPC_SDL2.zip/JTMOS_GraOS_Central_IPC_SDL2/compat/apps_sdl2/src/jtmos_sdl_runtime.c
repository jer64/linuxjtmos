#define _POSIX_C_SOURCE 200809L
#include "jtmos_sdl_runtime.h"
#include <dlfcn.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdio.h>

/* Minimal SDL2 ABI declarations. Kept private so libsdl2-dev is optional. */
typedef struct SDL_Window SDL_Window;
typedef struct SDL_Renderer SDL_Renderer;
typedef struct SDL_Texture SDL_Texture;
typedef int32_t SDL_Keycode;
typedef struct { int32_t scancode; SDL_Keycode sym; uint16_t mod; uint32_t unused; } SDL_Keysym;
typedef struct { uint32_t type,timestamp,windowID; uint8_t state,repeat,pad2,pad3; SDL_Keysym keysym; } SDL_KeyboardEvent;
typedef struct { uint32_t type,timestamp,windowID; char text[32]; } SDL_TextInputEvent;
typedef struct { uint32_t type,timestamp,windowID,which,state; int32_t x,y,xrel,yrel; } SDL_MouseMotionEvent;
typedef struct { uint32_t type,timestamp,windowID,which; uint8_t button,state,clicks,padding1; int32_t x,y; } SDL_MouseButtonEvent;
typedef union { uint32_t type; SDL_KeyboardEvent key; SDL_TextInputEvent text; SDL_MouseMotionEvent motion; SDL_MouseButtonEvent button; uint8_t padding[64]; } SDL_Event;

#define SDL_INIT_VIDEO  0x00000020u
#define SDL_INIT_EVENTS 0x00004000u
#define SDL_WINDOWPOS_CENTERED 0x2FFF0000u
#define SDL_WINDOW_SHOWN 0x00000004u
#define SDL_WINDOW_RESIZABLE 0x00000020u
#define SDL_RENDERER_SOFTWARE 0x00000001u
#define SDL_RENDERER_ACCELERATED 0x00000002u
#define SDL_RENDERER_PRESENTVSYNC 0x00000004u
#define SDL_TEXTUREACCESS_STREAMING 1
#define SDL_PIXELFORMAT_ARGB8888 372645892u
#define SDL_QUIT 0x100u
#define SDL_KEYDOWN 0x300u
#define SDL_TEXTINPUT 0x303u
#define SDL_MOUSEMOTION 0x400u
#define SDL_MOUSEBUTTONDOWN 0x401u
#define SDL_MOUSEBUTTONUP 0x402u
#define KMOD_CTRL 0x00c0u
#define KMOD_ALT 0x0300u

#define SDLK_RETURN 13
#define SDLK_ESCAPE 27
#define SDLK_BACKSPACE 8
#define SDLK_TAB 9
#define SDLK_DELETE 127
#define SDLK_CAPSLOCK 1073741881
#define SDLK_F1 1073741882
#define SDLK_F2 1073741883
#define SDLK_F3 1073741884
#define SDLK_F4 1073741885
#define SDLK_F5 1073741886
#define SDLK_F6 1073741887
#define SDLK_F7 1073741888
#define SDLK_F8 1073741889
#define SDLK_F9 1073741890
#define SDLK_F10 1073741891
#define SDLK_F11 1073741892
#define SDLK_F12 1073741893
#define SDLK_PRINTSCREEN 1073741894
#define SDLK_SCROLLLOCK 1073741895
#define SDLK_PAUSE 1073741896
#define SDLK_INSERT 1073741897
#define SDLK_HOME 1073741898
#define SDLK_PAGEUP 1073741899
#define SDLK_END 1073741901
#define SDLK_PAGEDOWN 1073741902
#define SDLK_RIGHT 1073741903
#define SDLK_LEFT 1073741904
#define SDLK_DOWN 1073741905
#define SDLK_UP 1073741906
#define SDLK_KP_ENTER 1073741912

#define JKEY_EXT(sc) ((int)((sc)<<8))

struct api {
 void *lib;
 int (*Init)(uint32_t);
 void (*Quit)(void);
 const char *(*GetError)(void);
 SDL_Window *(*CreateWindow)(const char*,int,int,int,int,uint32_t);
 void (*DestroyWindow)(SDL_Window*);
 SDL_Renderer *(*CreateRenderer)(SDL_Window*,int,uint32_t);
 void (*DestroyRenderer)(SDL_Renderer*);
 SDL_Texture *(*CreateTexture)(SDL_Renderer*,uint32_t,int,int,int);
 void (*DestroyTexture)(SDL_Texture*);
 int (*UpdateTexture)(SDL_Texture*,const void*,const void*,int);
 int (*RenderClear)(SDL_Renderer*);
 int (*RenderCopy)(SDL_Renderer*,SDL_Texture*,const void*,const void*);
 void (*RenderPresent)(SDL_Renderer*);
 int (*RenderSetLogicalSize)(SDL_Renderer*,int,int);
 int (*PollEvent)(SDL_Event*);
 void (*StartTextInput)(void);
 void (*StopTextInput)(void);
 void (*Delay)(uint32_t);
};
static struct api s;
static SDL_Window *win;
static SDL_Renderer *ren;
static SDL_Texture *tex;
static uint8_t *pix;
static uint32_t *argb;
static int w=640,h=480,scale_factor=1,started,quitflag;
static uint8_t palette[256][3];
static pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;
static int queued_keys[128], qh,qt;

static int sym(const char *name, void **out) { *out=dlsym(s.lib,name); return *out?0:-1; }
#define LOAD(name) do { if(sym("SDL_" #name,(void**)&s.name)) return -1; } while(0)

static void palette_init(void)
{
 static const uint8_t ega[16][3]={
  {0,0,0},{0,0,170},{0,170,0},{0,170,170},{170,0,0},{170,0,170},{170,85,0},{170,170,170},
  {85,85,85},{85,85,255},{85,255,85},{85,255,255},{255,85,85},{255,85,255},{255,255,85},{255,255,255}};
 int i;
 for(i=0;i<256;i++) palette[i][0]=palette[i][1]=palette[i][2]=(uint8_t)i;
 memcpy(palette,ega,sizeof(ega));
}

static int load_sdl(void)
{
 if(s.lib) return 0;
 s.lib=dlopen("libSDL2-2.0.so.0",RTLD_NOW|RTLD_LOCAL);
 if(!s.lib) s.lib=dlopen("libSDL2.so",RTLD_NOW|RTLD_LOCAL);
 if(!s.lib) return -1;
 LOAD(Init); LOAD(Quit); LOAD(GetError); LOAD(CreateWindow); LOAD(DestroyWindow);
 LOAD(CreateRenderer); LOAD(DestroyRenderer); LOAD(CreateTexture); LOAD(DestroyTexture);
 LOAD(UpdateTexture); LOAD(RenderClear); LOAD(RenderCopy); LOAD(RenderPresent); LOAD(RenderSetLogicalSize);
 LOAD(PollEvent); LOAD(StartTextInput); LOAD(StopTextInput); LOAD(Delay);
 return 0;
}

static int recreate_texture(void)
{
 if(tex) { s.DestroyTexture(tex); tex=NULL; }
 free(argb); argb=NULL;
 tex=s.CreateTexture(ren,SDL_PIXELFORMAT_ARGB8888,SDL_TEXTUREACCESS_STREAMING,w,h);
 if(!tex) return -1;
 argb=(uint32_t*)malloc((size_t)w*(size_t)h*sizeof(*argb));
 return argb?0:-1;
}

int jsdl_init(const char *title,int width,int height,int scale)
{
 if(started) return 0;
 if(load_sdl()) { fprintf(stderr,"JTMOS SDL2 wrapper: libSDL2-2.0 not found\n"); return -1; }
 if(width>0) w=width; if(height>0) h=height; if(scale>0) scale_factor=scale;
 palette_init();
 if(s.Init(SDL_INIT_VIDEO|SDL_INIT_EVENTS)!=0) return -2;
 win=s.CreateWindow(title?title:"JTMOS application",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,w*scale_factor,h*scale_factor,SDL_WINDOW_SHOWN|SDL_WINDOW_RESIZABLE);
 if(!win) return -3;
 ren=s.CreateRenderer(win,-1,SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);
 if(!ren) ren=s.CreateRenderer(win,-1,SDL_RENDERER_SOFTWARE);
 if(!ren) return -4;
 s.RenderSetLogicalSize(ren,w,h);
 pix=(uint8_t*)calloc((size_t)w,(size_t)h);
 if(!pix || recreate_texture()) return -5;
 s.StartTextInput(); started=1; quitflag=0; qh=qt=0; return 0;
}

int jsdl_resize(int width,int height)
{
 uint8_t *np;
 if(width<=0||height<=0) return -1;
 if(!started && jsdl_init("JTMOS application",width,height,2)) return -1;
 np=(uint8_t*)calloc((size_t)width,(size_t)height); if(!np) return -1;
 pthread_mutex_lock(&lock); free(pix); pix=np; w=width; h=height; s.RenderSetLogicalSize(ren,w,h); recreate_texture(); pthread_mutex_unlock(&lock); return 0;
}
uint8_t *jsdl_pixels(void){ return pix; }
int jsdl_width(void){ return w; }
int jsdl_height(void){ return h; }
void jsdl_set_palette(int idx,int r,int g,int b){ if(idx<0||idx>255)return; palette[idx][0]=(uint8_t)r; palette[idx][1]=(uint8_t)g; palette[idx][2]=(uint8_t)b; }

void jsdl_present(void)
{
 int i,n;
 if(!started||!pix||!argb) return;
 pthread_mutex_lock(&lock); n=w*h;
 for(i=0;i<n;i++){ unsigned c=pix[i]; argb[i]=0xff000000u|((uint32_t)palette[c][0]<<16)|((uint32_t)palette[c][1]<<8)|palette[c][2]; }
 s.UpdateTexture(tex,NULL,argb,w*4); s.RenderClear(ren); s.RenderCopy(ren,tex,NULL,NULL); s.RenderPresent(ren); pthread_mutex_unlock(&lock);
}
static void qpush(int k){ int n=(qt+1)&127; if(n!=qh){queued_keys[qt]=k;qt=n;} }
static int qpop(void){ int k;if(qh==qt)return 0;k=queued_keys[qh];qh=(qh+1)&127;return k; }
static int translate(SDL_Keycode k)
{
 switch(k){case SDLK_BACKSPACE:return 8;case SDLK_TAB:return 9;case SDLK_RETURN:case SDLK_KP_ENTER:return 13;case SDLK_ESCAPE:return 27;
 case SDLK_UP:return JKEY_EXT(0x48);case SDLK_DOWN:return JKEY_EXT(0x50);case SDLK_LEFT:return JKEY_EXT(0x4b);case SDLK_RIGHT:return JKEY_EXT(0x4d);
 case SDLK_HOME:return JKEY_EXT(0x47);case SDLK_END:return JKEY_EXT(0x4f);case SDLK_PAGEUP:return JKEY_EXT(0x49);case SDLK_PAGEDOWN:return JKEY_EXT(0x51);
 case SDLK_INSERT:return JKEY_EXT(0x52);case SDLK_DELETE:return JKEY_EXT(0x53);case SDLK_F1:return JKEY_EXT(0x3b);case SDLK_F2:return JKEY_EXT(0x3c);
 case SDLK_F3:return JKEY_EXT(0x3d);case SDLK_F4:return JKEY_EXT(0x3e);case SDLK_F5:return JKEY_EXT(0x3f);case SDLK_F6:return JKEY_EXT(0x40);
 case SDLK_F7:return JKEY_EXT(0x41);case SDLK_F8:return JKEY_EXT(0x42);case SDLK_F9:return JKEY_EXT(0x43);case SDLK_F10:return JKEY_EXT(0x44);
 case SDLK_F11:return JKEY_EXT(0x57);case SDLK_F12:return JKEY_EXT(0x58); default:return 0;}
}
static int translate_key_event(const SDL_Event *e)
{
 int k,mods=0;
 if(e->key.keysym.mod&KMOD_CTRL) mods|=0x10000;
 if(e->key.keysym.mod&KMOD_ALT) mods|=0x20000;
 if(e->key.keysym.sym>='a'&&e->key.keysym.sym<='z') return mods?(((int)e->key.keysym.sym)|mods):0;
 k=translate(e->key.keysym.sym);
 return k? (k|mods) : 0;
}

int jsdl_poll_event(JSDL_EVENT *out)
{
 SDL_Event e;
 if(out) memset(out,0,sizeof(*out));
 if(!started && jsdl_init("JTMOS GraOS",640,480,1)) return 0;
 while(s.PollEvent(&e)){
  if(e.type==SDL_QUIT){quitflag=1;if(out)out->type=JSDL_EVENT_QUIT;return 1;}
  if(e.type==SDL_TEXTINPUT){
   const unsigned char *p=(const unsigned char*)e.text.text;
   if(*p){ if(out){out->type=JSDL_EVENT_KEY;out->key=*p;} for(p++;*p;p++)qpush(*p); return 1; }
  }
  if(e.type==SDL_KEYDOWN){int k=translate_key_event(&e);if(k){if(out){out->type=JSDL_EVENT_KEY;out->key=k;}return 1;}}
  if(e.type==SDL_MOUSEMOTION){if(out){out->type=JSDL_EVENT_MOUSE_MOVE;out->x=e.motion.x/scale_factor;out->y=e.motion.y/scale_factor;out->buttons=(int)e.motion.state;}return 1;}
  if(e.type==SDL_MOUSEBUTTONDOWN||e.type==SDL_MOUSEBUTTONUP){if(out){out->type=e.type==SDL_MOUSEBUTTONDOWN?JSDL_EVENT_MOUSE_DOWN:JSDL_EVENT_MOUSE_UP;out->x=e.button.x/scale_factor;out->y=e.button.y/scale_factor;out->button=e.button.button;}return 1;}
 }
 return 0;
}
static void pump(void)
{
 JSDL_EVENT e;
 while(jsdl_poll_event(&e)){
  if(e.type==JSDL_EVENT_QUIT){quitflag=1;continue;}
  if(e.type==JSDL_EVENT_KEY)qpush(e.key);
 }
}
int jsdl_poll_key(void){int k;if(!started && jsdl_init("JTMOS console",640,480,1))return 0;pump();if(quitflag)return -1;k=qpop();return k;}
int jsdl_wait_key(void){int k;for(;;){k=jsdl_poll_key();if(k)return k;jsdl_sleep_ms(5);} }
int jsdl_quit_requested(void){pump();return quitflag;}
void jsdl_sleep_ms(unsigned int ms){if(s.lib&&s.Delay)s.Delay(ms);else{struct timespec ts={(time_t)(ms/1000),(long)(ms%1000)*1000000L};nanosleep(&ts,NULL);}}
void jsdl_shutdown(void){if(!started)return;s.StopTextInput();if(tex)s.DestroyTexture(tex);if(ren)s.DestroyRenderer(ren);if(win)s.DestroyWindow(win);free(argb);free(pix);tex=NULL;ren=NULL;win=NULL;argb=NULL;pix=NULL;s.Quit();started=0;}
