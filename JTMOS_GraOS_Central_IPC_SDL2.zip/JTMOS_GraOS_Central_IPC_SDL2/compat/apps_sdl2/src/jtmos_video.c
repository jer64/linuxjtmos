#define _POSIX_C_SOURCE 200809L
#include <jtmos/video.h>
#include <jtmos/graos.h>
#include <string.h>
#include <time.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdlib.h>

static BYTE *video_buf;
static int video_w=320,video_h=200,video_wid=-1;
static int ensure_video(void)
{
    if(!video_buf)video_buf=(BYTE*)calloc(1,(size_t)video_w*(size_t)video_h);
    if(!video_buf)return -1;
    if(video_wid<0)video_wid=JtmosGraOSCreateVideoWindow("JTMOS VGA application",video_w,video_h,video_buf);
    return video_wid<0?-1:0;
}
int setmode(int mode)
{
    if(mode==0x13){video_w=320;video_h=200;free(video_buf);video_buf=NULL;video_wid=-1;return ensure_video();}
    if(mode==3)return 0;
    return -1;
}
int setvmode(int mode){return setmode(mode);}
int setpalette(int index,int r,int g,int b){if(r<=63&&g<=63&&b<=63){r*=4;g*=4;b*=4;}return JtmosGraOSSetPalette(index,r,g,b);}
int setpalettemap(int offset,int amount,const BYTE *p){int i;if(!p)return-1;for(i=0;i<amount;i++)setpalette(offset+i,p[i*3],p[i*3+1],p[i*3+2]);return 0;}
void jtmos_drawframe1(const BYTE *buf){jtmos_drawframe3(buf,0,video_w*video_h);}
void jtmos_drawframe3(const BYTE *buf,int offset,int amount){int n;if(!buf)return;if(ensure_video()!=0)return;n=video_w*video_h;if(offset<0)offset=0;if(amount<0)amount=0;if(offset>=n)return;if(offset+amount>n)amount=n-offset;memcpy(video_buf+offset,buf,(size_t)amount);refreshWindow(video_wid);}
void waitretrace(void){struct timespec ts={0,16000000L};nanosleep(&ts,NULL);}
DWORD GetTickCount(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (DWORD)((uint64_t)t.tv_sec*1000u+(uint64_t)t.tv_nsec/1000000u);}

/* SDL2 queued-audio backend loaded dynamically. */
typedef uint32_t SDL_AudioDeviceID;typedef struct {int freq;uint16_t format;uint8_t channels,silence;uint16_t samples,padding;uint32_t size;void(*callback)(void*,uint8_t*,int);void*userdata;} SDL_AudioSpec;
#define AUDIO_U8 0x0008u
static void *alib; static SDL_AudioDeviceID adev;static SDL_AudioDeviceID(*pOpen)(const char*,int,const SDL_AudioSpec*,SDL_AudioSpec*,int);static void(*pPause)(SDL_AudioDeviceID,int);static int(*pQueue)(SDL_AudioDeviceID,const void*,uint32_t);static uint32_t(*pQueued)(SDL_AudioDeviceID);static void(*pClear)(SDL_AudioDeviceID);
static int audio_load(void){if(adev)return 0;if(!alib)alib=dlopen("libSDL2-2.0.so.0",RTLD_NOW|RTLD_LOCAL);if(!alib)return-1;pOpen=dlsym(alib,"SDL_OpenAudioDevice");pPause=dlsym(alib,"SDL_PauseAudioDevice");pQueue=dlsym(alib,"SDL_QueueAudio");pQueued=dlsym(alib,"SDL_GetQueuedAudioSize");pClear=dlsym(alib,"SDL_ClearQueuedAudio");return(pOpen&&pPause&&pQueue&&pQueued&&pClear)?0:-1;}
int InitAudio(void){SDL_AudioSpec want,have;if(audio_load())return-1;if(adev&&pClear)pClear(adev);if(!adev){memset(&want,0,sizeof(want));want.freq=11025;want.format=AUDIO_U8;want.channels=1;want.samples=2048;adev=pOpen(NULL,0,&want,&have,0);if(!adev)return-1;pPause(adev,0);}return 0;}
int SendAudio(const BYTE *data,int length,int channel,int rate){(void)channel;(void)rate;if(!adev&&InitAudio())return-1;return pQueue(adev,data,(uint32_t)length);}
int GetAudioPosition(void){if(!adev)return 0;return (int)pQueued(adev);}
#undef drawframe
void drawframe(const BYTE *buf, ...){jtmos_drawframe3(buf,0,320*200);}
