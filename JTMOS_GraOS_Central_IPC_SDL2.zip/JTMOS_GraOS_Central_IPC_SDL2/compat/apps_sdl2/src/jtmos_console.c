#define _POSIX_C_SOURCE 200809L
#include <jtmos/app_port.h>
#undef printf
#undef putchar
#undef puts
#undef getch
#undef kbhit
#undef clrscr
#undef gotoxy
#undef textcolor
#undef textbackground
#undef cprintf
#undef sleep
#undef delay
#include <jtmos/graos.h>

#include <stdarg.h>
#include <sys/stat.h>
#include <sys/sysinfo.h>
#include <sched.h>
#include <signal.h>
#include <errno.h>
#include <ctype.h>
#include <time.h>
#include <string.h>

extern int ActivateThreadMessageBox(int pid);

static int current_terminal_id=-1;
static int pending_key=-1;
static int pending_mods;
static int ctrl_state,alt_state;
static int fg=7,bg=0;

static int ensure_console(void)
{
    if(current_terminal_id>=0)return current_terminal_id;
    current_terminal_id=JtmosGraOSAutoConsole(NULL,80,60);
    if(current_terminal_id>=0){
        (void)JtmosGraOSTermColor(current_terminal_id,fg);
        (void)JtmosGraOSTermBackground(current_terminal_id,bg);
    }
    return current_terminal_id;
}

static int term_write(const char *s,size_t n)
{
    int t=ensure_console();
    if(t<0)return -1;
    while(n){
        int chunk=n>65536?65536:(int)n;
        if(JtmosGraOSTermWrite(t,s,chunk)!=0)return -1;
        s+=chunk;n-=(size_t)chunk;
    }
    return 0;
}

int jtmos_printf(const char *fmt,...)
{
    char b[8192];int n;va_list ap;
    va_start(ap,fmt);n=vsnprintf(b,sizeof(b),fmt,ap);va_end(ap);
    if(n<0)return n;
    term_write(b,(size_t)(n<(int)sizeof(b)?n:(int)sizeof(b)-1));
    if(getenv("JTMOS_CONSOLE_STDOUT")){fwrite(b,1,(size_t)(n<(int)sizeof(b)?n:(int)sizeof(b)-1),stdout);fflush(stdout);}
    return n;
}
int jtmos_cprintf(const char *fmt,...){char b[8192];int n;va_list ap;va_start(ap,fmt);n=vsnprintf(b,sizeof(b),fmt,ap);va_end(ap);if(n>=0)term_write(b,strlen(b));return n;}
int jtmos_putchar(int c){char ch=(char)c;term_write(&ch,1);return c;}
int jtmos_puts(const char *s){if(s)term_write(s,strlen(s));term_write("\n",1);return 0;}
void jtmos_clrscr(void){int t=ensure_console();if(t>=0)JtmosGraOSTermClear(t);}
void jtmos_gotoxy(int x,int y){int t=ensure_console();if(t>=0)JtmosGraOSTermGotoXY(t,x,y);}
void jtmos_textcolor(int c){fg=c&15;{int t=ensure_console();if(t>=0)JtmosGraOSTermColor(t,fg);}}
void jtmos_textbackground(int c){bg=c&15;{int t=ensure_console();if(t>=0)JtmosGraOSTermBackground(t,bg);}}
void jtmos_console_flush(void){/* graos compositor renders continuously */}
void jtmos_console_shutdown(void){current_terminal_id=-1;pending_key=-1;}

static int fetch_key(int block)
{
    int k,mods=0,t=ensure_console();
    if(t<0)return 27;
    if(pending_key>=0){k=pending_key;mods=pending_mods;pending_key=-1;}
    else for(;;){
        k=JtmosGraOSTermGetKey(t,&mods);
        if(k>=0)break;
        if(!block)return -1;
        sched_yield();
        {struct timespec ts={0,5000000L};nanosleep(&ts,NULL);}
    }
    ctrl_state=(mods&1)!=0;alt_state=(mods&2)!=0;
    return k;
}
int getch1(void){int k=fetch_key(0);return k<0?0:k;}
int jtmos_getch(void){return fetch_key(1);}
int jtmos_kbhit(void){int mods=0,k;if(pending_key>=0)return 1;k=JtmosGraOSTermGetKey(ensure_console(),&mods);if(k<0)return 0;pending_key=k;pending_mods=mods;return 1;}

void SwitchToThread(void){sched_yield();}
void Sleep(unsigned int ms){struct timespec ts={(time_t)(ms/1000),(long)(ms%1000)*1000000L};nanosleep(&ts,NULL);}
void jtmos_sleep_ticks(unsigned int ticks){Sleep(ticks*10u);}
int GetCurrentThread(void){return (int)getpid();}
static void namepath(char *out,size_t n,const char *name){size_t i,j=0;snprintf(out,n,"/tmp/jtmos-name-%u-",(unsigned)getuid());j=strlen(out);for(i=0;name&&name[i]&&j+1<n;i++)out[j++]=isalnum((unsigned char)name[i])?name[i]:'_';out[j]=0;}
void IdentifyThread(int pid,const char *name){char p[512];FILE *f;namepath(p,sizeof(p),name);f=fopen(p,"w");if(f){fprintf(f,"%d\n",pid);fclose(f);}}
int GetThreadPID(const char *name){char p[512];FILE *f;int pid=-1;namepath(p,sizeof(p),name);f=fopen(p,"r");if(!f)return-1;if(fscanf(f,"%d",&pid)!=1)pid=-1;fclose(f);if(pid>0&&kill(pid,0)==0)return pid;return-1;}
int KillThread(int pid){return pid>0?kill(pid,SIGTERM):-1;}
long fsizeof(const char *path){struct stat st;return(path&&stat(path,&st)==0)?(long)st.st_size:-1;}
int fexist(const char *path){struct stat st;if(!path||stat(path,&st))return 0;return S_ISDIR(st.st_mode)?2:1;}
void StretchPrint(const char *s,int width){int n=s?(int)strlen(s):0;char pad[256];if(s)term_write(s,strlen(s));while(n<width){int k=(width-n)>255?255:(width-n);memset(pad,' ',(size_t)k);term_write(pad,(size_t)k);n+=k;}}

int GetThreadCount(void){return 1;}
int GetThreadUniquePID(int index){return index==0?(int)getpid():-1;}
int GetThreadPriority(int pid){return pid==(int)getpid()?1:0;}
int GetThreadSpending(int pid){(void)pid;return (int)clock();}
int GetThreadMemoryUsage(int pid){char path[64],line[256];FILE *f;long total_pages=0,pages=0;snprintf(path,sizeof(path),"/proc/%d/statm",pid>0?pid:(int)getpid());f=fopen(path,"r");if(f){if(fgets(line,sizeof(line),f))(void)sscanf(line,"%ld %ld",&total_pages,&pages);fclose(f);}(void)total_pages;return (int)(pages*sysconf(_SC_PAGESIZE));}
int GetThreadName(int pid,char *out){char path[64];FILE *f;if(!out)return 1;snprintf(path,sizeof(path),"/proc/%d/comm",pid);f=fopen(path,"r");if(!f){strcpy(out,"linux-app");return 1;}if(!fgets(out,255,f))strcpy(out,"linux-app");fclose(f);out[strcspn(out,"\r\n")]=0;return 0;}
int GetMemorySize(void){long p=sysconf(_SC_PHYS_PAGES),s=sysconf(_SC_PAGESIZE);long long v=(long long)p*s;return v>0x7fffffff?0x7fffffff:(int)v;}
int GetAmountFree(void){struct sysinfo si;if(sysinfo(&si)==0){unsigned long long v=(unsigned long long)si.freeram*si.mem_unit;return v>0x7fffffff?0x7fffffff:(int)v;}return 0;}
int GetSeconds(void){return (int)time(NULL);}
int GetCTRL(void){return ctrl_state;}
int GetALT(void){return alt_state;}
int startMessageBox(void){return ActivateThreadMessageBox((int)getpid());}
int GetCurrentTerminal(void){return current_terminal_id;}
int SetThreadTerminal(int pid,int terminal){if(pid==(int)getpid())current_terminal_id=terminal;return 0;}
void delay(int ms){Sleep((unsigned int)(ms<0?0:ms));}
int cexec(const char *cmd,const char *search_path){(void)search_path;if(!cmd||!*cmd)return 1;return system(cmd)==0?0:1;}
char *sptstr(char *dst,const char *src,int delimiter,int index,int max_words){int i=0,n=0;(void)max_words;if(!dst||!src)return dst;while(*src&&i<index){if((unsigned char)*src==(unsigned char)delimiter){i++;while(*src==(char)delimiter)src++;}else src++;}while(*src&&*src!=(char)delimiter&&n<255)dst[n++]=*src++;dst[n]=0;return dst;}

/* Legacy console symbols used directly by a few JTMOS applications. */
void putch(unsigned char c){(void)jtmos_putchar((int)c);}
void print(const char *s){if(s)term_write(s,strlen(s));}
