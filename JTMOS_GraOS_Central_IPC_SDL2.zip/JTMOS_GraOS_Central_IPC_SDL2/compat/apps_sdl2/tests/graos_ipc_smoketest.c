#include <jtmos/graos.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    BYTE pixels[32*16];
    int ter,wid,wid2,k,mods=0,i;
    if(connectGraos()!=0){fprintf(stderr,"connectGraos failed\n");return 1;}
    ter=CreateTerminal();
    if(ter<0){fprintf(stderr,"CreateTerminal failed\n");return 2;}
    wid=createWindow(10,10,320,120,"IPC terminal smoke",STANDARD_WINDOW);
    if(wid<0||addFrameBuffer(wid,NULL,0,0,40,12,8,TYPE_TERMINAL_EMULATION,ter)<0)return 3;
    if(JtmosGraOSTermWrite(ter,"GraOS IPC terminal OK",21)!=0)return 4;
    OutTermKey(ter,'Q');
    k=JtmosGraOSTermGetKey(ter,&mods);
    if(k!='Q') {fprintf(stderr,"terminal key loop failed: %d\n",k);return 5;}
    for(i=0;i<(int)sizeof(pixels);i++)pixels[i]=(BYTE)(i&15);
    wid2=createWindow(60,80,32,16,"IPC bitmap smoke",STANDARD_WINDOW);
    if(wid2<0||addFrameBuffer(wid2,pixels,0,0,32,16,8,TYPE_BITMAP_SCREEN,0)<0)return 6;
    if(refreshWindow(wid2)!=0)return 7;
    closeWindow(wid2);
    closeWindow(wid);
    JtmosGraOSFreeTerminal(ter);
    fprintf(stderr,"GraOS IPC terminal + bitmap smoke test OK\n");
    return 0;
}
