#ifndef JTMOS_GRAOS_IPC_H
#define JTMOS_GRAOS_IPC_H

#include <stdint.h>

#define JTMOS_GRAOS_WIRE_MAGIC   0x4752414fu /* 'GRAO' */
#define JTMOS_GRAOS_WIRE_VERSION 2u
#define JTMOS_GRAOS_MAX_PAYLOAD  (1024u * 1024u)

/* Synchronous client -> central GraOS server operations. */
enum {
    GRAOS_OP_PING = 1,
    GRAOS_OP_SHUTDOWN = 2,
    GRAOS_OP_STATS = 3,

    GRAOS_OP_CREATE_WINDOW = 10,
    GRAOS_OP_CLOSE_WINDOW = 11,
    GRAOS_OP_REFRESH_WINDOW = 12,
    GRAOS_OP_ADD_SURFACE = 13,
    GRAOS_OP_UPDATE_SURFACE = 14,
    GRAOS_OP_CREATE_BUTTON = 15,

    GRAOS_OP_CREATE_TERMINAL = 20,
    GRAOS_OP_FREE_TERMINAL = 21,
    GRAOS_OP_TERM_WRITE = 22,
    GRAOS_OP_TERM_CLEAR = 23,
    GRAOS_OP_TERM_GOTOXY = 24,
    GRAOS_OP_TERM_FG = 25,
    GRAOS_OP_TERM_BG = 26,
    GRAOS_OP_TERM_GETKEY = 27,
    GRAOS_OP_TERM_PUTKEY = 28,

    GRAOS_OP_SET_PALETTE = 30
};

typedef struct {
    uint32_t magic;
    uint32_t version;
    uint32_t op;
    uint32_t payload_len;
    int32_t pid;
    int32_t wid;
    int32_t object;
    int32_t status;
    int32_t v[8];
} JTMOS_GRAOS_WIRE;

typedef struct {
    int32_t x, y, w, h;
    int32_t flags;
    char title[256];
} JTMOS_GRAOS_CREATE_WINDOW;

typedef struct {
    int32_t x, y, w, h;
    int32_t bpp;
    int32_t type;
    int32_t terminal_id;
} JTMOS_GRAOS_ADD_SURFACE;

typedef struct {
    int32_t x, y, w, h;
    int32_t id;
    char text[128];
} JTMOS_GRAOS_BUTTON;

#endif
