#define _GNU_SOURCE
#include <jtmos/graos_ipc.h>
#include "../apps_sdl2/src/jtmos_graos_ipc.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(int argc,char **argv)
{
    JTMOS_GRAOS_WIRE q,r;
    const char *cmd=argc>1?argv[1]:"status";
    memset(&q,0,sizeof(q));q.magic=JTMOS_GRAOS_WIRE_MAGIC;q.version=JTMOS_GRAOS_WIRE_VERSION;q.pid=(int)getpid();
    if(!strcmp(cmd,"shutdown"))q.op=GRAOS_OP_SHUTDOWN;else if(!strcmp(cmd,"ping"))q.op=GRAOS_OP_PING;else q.op=GRAOS_OP_STATS;
    if(jtmos_graos_client_call(&q,NULL,&r,NULL,0,NULL)!=0){fprintf(stderr,"graos: not running\n");return 1;}
    if(q.op==GRAOS_OP_STATS)printf("graos pid=%d windows=%d dynamic-terminals=%d focus=%d\n",r.pid,r.v[0],r.v[1],r.v[2]);
    else if(q.op==GRAOS_OP_SHUTDOWN)puts("graos shutdown requested");else puts("graos is running");
    return r.status?1:0;
}
