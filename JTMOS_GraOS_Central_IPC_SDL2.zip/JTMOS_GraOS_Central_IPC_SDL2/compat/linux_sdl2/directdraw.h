#ifndef JTMOS_LINUX_DIRECTDRAW_H
#define JTMOS_LINUX_DIRECTDRAW_H
void DirectFillRect(unsigned char *dst, int width, int height,
                    int x, int y, int w, int h, unsigned char color);
void DirectDrawText(unsigned char *dst, int width, int height,
                    const char *text, int x, int y);
void DirectDrawCharColor(unsigned char *dst, int width, int height,
                         unsigned char ch, int x, int y,
                         unsigned char fg, unsigned char bg);
void DirectDrawTextColor(unsigned char *dst, int width, int height,
                         const char *text, int x, int y,
                         unsigned char fg, unsigned char bg);
#endif
