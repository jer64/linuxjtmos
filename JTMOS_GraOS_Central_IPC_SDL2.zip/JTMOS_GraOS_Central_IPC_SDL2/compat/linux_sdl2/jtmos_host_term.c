#define _GNU_SOURCE
#include "jtmos_host_term.h"
#include "jtmos_host_chiplevel.h"

#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <sched.h>

#define KEY_BYTES 2048
#define DEFAULT_COLS 80
#define DEFAULT_ROWS 60

SCREEN screens[N_MAX_SCREENS];
int terminalLockPID;
int puts_busy;
static int visible_terminal;
static pthread_once_t term_once=PTHREAD_ONCE_INIT;
static pthread_mutex_t screen_mutex[N_MAX_SCREENS];

static void init_mutexes(void)
{
    pthread_mutexattr_t a;
    int i;
    pthread_mutexattr_init(&a);
    pthread_mutexattr_settype(&a,PTHREAD_MUTEX_RECURSIVE);
    for(i=0;i<N_MAX_SCREENS;i++) pthread_mutex_init(&screen_mutex[i],&a);
    pthread_mutexattr_destroy(&a);
}

static void screen_setup(SCREEN *s,int id)
{
    size_t bytes;
    memset(s,0,sizeof(*s));
    s->id=id;
    s->isFree=FALSE;
    s->width=DEFAULT_COLS;
    s->height=DEFAULT_ROWS;
    s->window.x1=0; s->window.y1=0;
    s->window.x2=s->width-1; s->window.y2=s->height-1;
    s->supallow=1; s->tc=0x07; s->updcur=1;
    bytes=(size_t)s->width*(size_t)s->height*2u;
    s->buf=(char*)malloc(bytes);
    s->key.buf=(BYTE*)malloc(KEY_BYTES);
    s->key.l_buf=KEY_BYTES;
    if(!s->buf || !s->key.buf) {
        free(s->buf); free(s->key.buf);
        memset(s,0,sizeof(*s)); s->id=id; s->isFree=TRUE;
        return;
    }
    memset(s->buf,0,bytes);
    sclrscr(s);
}

void VirtualTerminalInit(void)
{
    int i;
    pthread_once(&term_once,init_mutexes);
    for(i=0;i<N_MAX_SCREENS;i++) {
        memset(&screens[i],0,sizeof(screens[i]));
        screens[i].id=i; screens[i].isFree=TRUE;
    }
    for(i=0;i<10;i++) screen_setup(&screens[i],i);
    visible_terminal=0;
    SetThreadTerminal(GetCurrentThread(),0);
}

int IsTerminalValid(int id)
{
    return id>=0 && id<N_MAX_SCREENS && !screens[id].isFree && screens[id].buf!=NULL;
}

int ReserveTerminal(void)
{
    int i;
    for(i=10;i<N_MAX_SCREENS;i++) if(screens[i].isFree) return i;
    return -1;
}

int NewTerminal(void)
{
    int id=ReserveTerminal();
    if(id<0) return -1;
    screen_setup(&screens[id],id);
    return IsTerminalValid(id)?id:-1;
}

int CreateTerminal(void)
{
    int id=NewTerminal();
    if(id>=0) SetTerminalOwner(id,GetCurrentThread());
    return id;
}

void FreeScreen(SCREEN *s)
{
    int id;
    if(!s) return;
    id=s->id;
    if(id<10 || id>=N_MAX_SCREENS) return;
    pthread_mutex_lock(&screen_mutex[id]);
    free(s->buf); free(s->key.buf);
    memset(s,0,sizeof(*s)); s->id=id; s->isFree=TRUE;
    pthread_mutex_unlock(&screen_mutex[id]);
}

void FreePIDTerminals(int pid)
{
    int i;
    for(i=10;i<N_MAX_SCREENS;i++)
        if(IsTerminalValid(i) && screens[i].pid==pid) FreeScreen(&screens[i]);
}

int SetTerminalOwner(int id,int pid) { if(!IsTerminalValid(id)) return -1; screens[id].pid=pid; return 0; }
int GetTerminalOwner(int id) { return IsTerminalValid(id)?screens[id].pid:-1; }
int GetVisibleTerminal(void) { return visible_terminal; }
int SetVisibleTerminal(int which) { if(!IsTerminalValid(which)) return -1; visible_terminal=which; return 0; }
WORD GetCursorLocation(int ter) { return IsTerminalValid(ter)?(WORD)((screens[ter].curx&255)|((screens[ter].cury&255)<<8)):0; }

static int key_push(SCREEN *s,WORD w)
{
    int n;
    if(!s || !s->key.buf || s->key.l_buf<2) return 1;
    if(s->key.count>s->key.l_buf-2) return 1;
    n=s->key.l_buf;
    s->key.buf[s->key.tail]=(BYTE)(w&255); s->key.tail=(s->key.tail+1)%n;
    s->key.buf[s->key.tail]=(BYTE)(w>>8);  s->key.tail=(s->key.tail+1)%n;
    s->key.count+=2; s->key.total++;
    return 0;
}
static int key_pop(SCREEN *s)
{
    int n; WORD w;
    if(!s || !s->key.buf || s->key.count<2) return -1;
    n=s->key.l_buf;
    w=s->key.buf[s->key.head]; s->key.head=(s->key.head+1)%n;
    w|=(WORD)s->key.buf[s->key.head]<<8; s->key.head=(s->key.head+1)%n;
    s->key.count-=2; return (int)w;
}

int OutputTerminalKeyboardBuffer(SCREEN *s,int ch)
{
    int r;
    if(!s || s->isFree) return 1;
    pthread_mutex_lock(&screen_mutex[s->id]); r=key_push(s,(WORD)ch); pthread_mutex_unlock(&screen_mutex[s->id]);
    return r;
}
int InputTerminalKeyboardBuffer(SCREEN *s)
{
    int r;
    if(!s || s->isFree) return -1;
    pthread_mutex_lock(&screen_mutex[s->id]); r=key_pop(s); pthread_mutex_unlock(&screen_mutex[s->id]);
    return r;
}
void OutTermKey(int id,int ch) { if(IsTerminalValid(id)) OutputTerminalKeyboardBuffer(&screens[id],ch); }

void scrpoke(SCREEN *s,long ad,char data)
{
    long lim;
    if(!s || !s->buf) return;
    lim=s->width*s->height*2;
    if(ad<0 || ad>=lim) return;
    s->buf[ad]=data; s->revision++;
}
char scrpeek(SCREEN *s,long ad)
{
    long lim;
    if(!s || !s->buf) return 0;
    lim=s->width*s->height*2;
    return ad>=0 && ad<lim?s->buf[ad]:0;
}

void stextcolor(SCREEN *s,char c) { if(s) s->tc=(char)((s->tc&0xf0)|(c&15)); }
void stextbackground(SCREEN *s,char c) { if(s) s->tc=(char)((s->tc&0x0f)|((c&15)<<4)); }

static void clear_line(SCREEN *s,long y)
{
    long x;
    for(x=s->window.x1;x<=s->window.x2;x++) {
        long ad=(y*s->width+x)*2;
        scrpoke(s,ad,' '); scrpoke(s,ad+1,s->tc);
    }
}
static void scroll_up(SCREEN *s)
{
    long y,x;
    for(y=s->window.y1;y<s->window.y2;y++)
        for(x=s->window.x1;x<=s->window.x2;x++) {
            long d=(y*s->width+x)*2, q=((y+1)*s->width+x)*2;
            scrpoke(s,d,scrpeek(s,q)); scrpoke(s,d+1,scrpeek(s,q+1));
        }
    clear_line(s,s->window.y2);
}
static void newline(SCREEN *s)
{
    s->curx=s->window.x1;
    if(++s->cury>s->window.y2) {
        s->cury=s->window.y2;
        if(s->supallow) scroll_up(s);
    }
    s->revision++;
}

void sputch(SCREEN *s,char c)
{
    long ad;
    if(!s || s->isFree) return;
    pthread_mutex_lock(&screen_mutex[s->id]);
    switch((unsigned char)c) {
        case '\n': newline(s); break;
        case '\r': s->curx=s->window.x1; s->revision++; break;
        case '\b':
            if(s->curx>s->window.x1) s->curx--;
            ad=(s->cury*s->width+s->curx)*2; scrpoke(s,ad,' '); scrpoke(s,ad+1,s->tc); break;
        case '\t': do { sputch(s,' '); } while(((s->curx-s->window.x1)&7)!=0); break;
        default:
            ad=(s->cury*s->width+s->curx)*2; scrpoke(s,ad,c); scrpoke(s,ad+1,s->tc);
            if(++s->curx>s->window.x2) newline(s);
            break;
    }
    pthread_mutex_unlock(&screen_mutex[s->id]);
}
void sputs(SCREEN *s,const char *str) { if(str) while(*str) sputch(s,*str++); }

static SCREEN *current_screen(void)
{
    int id=GetCurrentTerminal();
    if(!IsTerminalValid(id)) id=0;
    return IsTerminalValid(id)?&screens[id]:NULL;
}
void putch(unsigned char c) { SCREEN *s=current_screen(); if(s) sputch(s,(char)c); }
void print(const char *str) { SCREEN *s=current_screen(); if(s) sputs(s,str); }
void clrscr(void) { SCREEN *s=current_screen(); if(s) sclrscr(s); }
void gotoxy(int x,int y) { SCREEN *s=current_screen(); if(s) sgotoxy(s,x,y); }
int wherex(void) { SCREEN *s=current_screen(); return s?swherex(s):0; }
int wherey(void) { SCREEN *s=current_screen(); return s?swherey(s):0; }
void textcolor(int c) { SCREEN *s=current_screen(); if(s) stextcolor(s,(char)c); }
void textbackground(int c) { SCREEN *s=current_screen(); if(s) stextbackground(s,(char)c); }

void sclrscr(SCREEN *s)
{
    long y;
    if(!s) return;
    for(y=s->window.y1;y<=s->window.y2;y++) clear_line(s,y);
    s->curx=s->window.x1; s->cury=s->window.y1; s->revision++;
}
void sgotoxy(SCREEN *s,int x,int y)
{
    long xx,yy;
    if(!s || x<1 || y<1) return;
    xx=s->window.x1+x-1; yy=s->window.y1+y-1;
    if(xx>s->window.x2 || yy>s->window.y2) return;
    s->curx=xx; s->cury=yy; s->revision++;
}
void sgotox(SCREEN *s,int x) { if(s) sgotoxy(s,x,(int)(s->cury-s->window.y1+1)); }
void sgotoy(SCREEN *s,int y) { if(s) sgotoxy(s,(int)(s->curx-s->window.x1+1),y); }
int swherex(SCREEN *s) { return s?(int)(s->curx-s->window.x1):0; }
int swherey(SCREEN *s) { return s?(int)(s->cury-s->window.y1):0; }

int swindow(SCREEN *s,long x1,long y1,long x2,long y2)
{
    if(!s) return 3;
    if(x1<0) x1=0;
    if(y1<0) y1=0;
    if(x2>=s->width) x2=s->width-1;
    if(y2>=s->height) y2=s->height-1;
    if(x2<x1) return 1;
    if(y2<y1) return 2;
    s->window.x1=x1;s->window.y1=y1;s->window.x2=x2;s->window.y2=y2;
    if(s->curx<x1||s->curx>x2)s->curx=x1;
    if(s->cury<y1||s->cury>y2)s->cury=y1;
    s->revision++;
    return 0;
}
int window(long x1,long y1,long x2,long y2) { SCREEN *s=current_screen(); return s?swindow(s,x1,y1,x2,y2):3; }
void CursorState(SCREEN *s,int state) { if(s){s->updcur=(char)state;s->revision++;} }
void SetTerminalScrolling(int id,int what) { if(IsTerminalValid(id)) screens[id].supallow=(char)(what?1:0); }

int waitkey(void)
{
    SCREEN *s=current_screen(); int k;
    if(!s) return -1;
    for(;;) { k=InputTerminalKeyboardBuffer(s); if(k>=0) return k; sched_yield(); delay(1); }
}

int SetTerminalLock(int pid)
{
    if(terminalLockPID && terminalLockPID!=GetCurrentThread()) return 1;
    terminalLockPID=pid; return 0;
}
int GetTerminalLock(void) { return terminalLockPID; }
