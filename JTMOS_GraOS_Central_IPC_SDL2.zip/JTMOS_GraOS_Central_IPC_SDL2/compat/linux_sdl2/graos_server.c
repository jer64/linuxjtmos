#define _GNU_SOURCE
#include <jtmos/graos_ipc.h>
#include <msgbox.h>
#include <jtmos/graosprotocol.h>
#include "../apps_sdl2/src/jtmos_sdl_runtime.h"
#include "jtmos_host_term.h"
#include "directdraw.h"

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/un.h>
#include <unistd.h>

typedef struct { int id; int v[32]; char text[256]; } GUICMD;
#define STANDARD_WINDOW 0x0001
#define WINDOW_AUTOCLEAR 0x0002
#define TASKBAR_WINDOW 0x0004
#define TYPE_BITMAP_SCREEN 1
#define TYPE_TERMINAL_EMULATION 2

#define DESK_W 640
#define DESK_H 480
#define MAX_WINDOWS 64
#define MAX_SURFACES 16
#define MAX_BUTTONS 16
#define TITLE_H 18
#define BORDER 2

typedef struct {int used,sid,x,y,w,h,bpp,type,ter;BYTE *data;size_t bytes;} SURFACE;
typedef struct {int used,id,x,y,w,h;char text[128];} BUTTON;
typedef struct {
 int used,wid,owner,x,y,w,h,flags,z;
 char title[256];
 SURFACE surf[MAX_SURFACES];int next_sid;
 BUTTON button[MAX_BUTTONS];
} GWINDOW;

static GWINDOW wins[MAX_WINDOWS];
static int next_wid=1,next_z=1,focus_wid=-1,autox=20,autoy=20;
static int server_fd=-1,running=1,drag_wid=-1,drag_dx,drag_dy;
static unsigned cleanup_tick;
static char sockpath[108];
static unsigned char term_mod[256][256];
static unsigned short term_mh[256],term_mt[256];

static void sigstop(int s){(void)s;running=0;}
static int write_full(int fd,const void *buf,size_t len){const unsigned char*p=buf;while(len){ssize_t n=write(fd,p,len);if(n<0){if(errno==EINTR)continue;return-1;}if(!n)return-1;p+=n;len-=(size_t)n;}return 0;}
static int read_full(int fd,void *buf,size_t len){unsigned char*p=buf;while(len){ssize_t n=read(fd,p,len);if(n<0){if(errno==EINTR)continue;return-1;}if(!n)return-1;p+=n;len-=(size_t)n;}return 0;}
static const char *socket_path(void){const char*e=getenv("JTMOS_GRAOS_SOCKET");if(e&&*e)return e;snprintf(sockpath,sizeof(sockpath),"/tmp/jtmos-graos-%lu.sock",(unsigned long)getuid());return sockpath;}
static GWINDOW *win_by_id(int id){int i;for(i=0;i<MAX_WINDOWS;i++)if(wins[i].used&&wins[i].wid==id)return&wins[i];return NULL;}
static SURFACE *surf_by_id(GWINDOW*w,int sid){int i;if(!w)return NULL;for(i=0;i<MAX_SURFACES;i++)if(w->surf[i].used&&w->surf[i].sid==sid)return&w->surf[i];return NULL;}
static int client_x(const GWINDOW*w){return w->x+((w->flags&TASKBAR_WINDOW)?0:BORDER);}
static int client_y(const GWINDOW*w){return w->y+((w->flags&TASKBAR_WINDOW)?0:(TITLE_H+BORDER));}
static int outer_w(const GWINDOW*w){return w->w+((w->flags&TASKBAR_WINDOW)?0:BORDER*2);}
static int outer_h(const GWINDOW*w){return w->h+((w->flags&TASKBAR_WINDOW)?0:(TITLE_H+BORDER*2));}
static void focus(GWINDOW*w){if(!w)return;focus_wid=w->wid;w->z=++next_z;}
static void free_window(GWINDOW *w)
{
 int i,wid;
 if(!w)return;
 wid=w->wid;
 for(i=0;i<MAX_SURFACES;i++){free(w->surf[i].data);w->surf[i].data=NULL;}
 memset(w,0,sizeof(*w));
 if(focus_wid==wid)focus_wid=-1;
 if(drag_wid==wid)drag_wid=-1;
}
static int process_alive(int pid)
{
 if(pid<=0)return 0;
 if(kill(pid,0)==0)return 1;
 return errno==EPERM;
}
static void cleanup_dead_clients(void)
{
 int i;
 /* Do this roughly once per second from the 60 Hz compositor loop. */
 if(++cleanup_tick<60)return;
 cleanup_tick=0;
 for(i=0;i<MAX_WINDOWS;i++)
     if(wins[i].used&&!process_alive(wins[i].owner))free_window(&wins[i]);
 for(i=10;i<N_MAX_SCREENS;i++)
     if(IsTerminalValid(i)&&!process_alive(GetTerminalOwner(i)))FreeScreen(&screens[i]);
}
static void send_gui_event(int pid,int id,int a,int b,int c){MSG m;GUICMD *g=(GUICMD*)m.buf;int tries;memset(&m,0,sizeof(m));memset(g,0,sizeof(*g));g->id=id;g->v[0]=a;g->v[1]=b;g->v[2]=c;m.protocol=MB_PROTOCOL_GRAOS;m.amount=sizeof(*g);for(tries=0;tries<20;tries++){if(sendMessage(&m,pid)==0)return;usleep(1000);}}
static int terminal_of_window(GWINDOW*w){int i;if(!w)return-1;for(i=0;i<MAX_SURFACES;i++)if(w->surf[i].used&&w->surf[i].type==TYPE_TERMINAL_EMULATION)return w->surf[i].ter;return-1;}
static void mod_push(int ter,int mods){unsigned short n;if(ter<0||ter>=256)return;n=(unsigned short)((term_mt[ter]+1u)&255u);if(n==term_mh[ter])term_mh[ter]=(unsigned short)((term_mh[ter]+1u)&255u);term_mod[ter][term_mt[ter]]=(unsigned char)mods;term_mt[ter]=n;}
static int mod_pop(int ter){int m=0;if(ter>=0&&ter<256&&term_mh[ter]!=term_mt[ter]){m=term_mod[ter][term_mh[ter]];term_mh[ter]=(unsigned short)((term_mh[ter]+1u)&255u);}return m;}
static void push_term_key(int ter,int key,int mods){if(IsTerminalValid(ter)){OutTermKey(ter,key);mod_push(ter,mods);}}

static void render_terminal(unsigned char*dst,int dw,int dh,int ox,int oy,SURFACE*s)
{
 SCREEN*t;int x,y,cols,rows,start=0,cy;if(!IsTerminalValid(s->ter))return;t=&screens[s->ter];cols=s->w<t->width?s->w:(int)t->width;rows=s->h<t->height?s->h:(int)t->height;if((int)t->height>rows&&(int)t->cury>=rows)start=(int)t->cury-rows+1;if(start+rows>(int)t->height)start=(int)t->height-rows;
 for(y=0;y<rows;y++)for(x=0;x<cols;x++){size_t a=((size_t)(y+start)*(size_t)t->width+(size_t)x)*2u;unsigned char ch=(unsigned char)t->buf[a],at=(unsigned char)t->buf[a+1];DirectDrawCharColor(dst,dw,dh,ch,ox+s->x+x*8,oy+s->y+y*8,at&15,(at>>4)&15);}
 cy=(int)t->cury-start;if(t->updcur&&t->curx>=0&&t->curx<cols&&cy>=0&&cy<rows)DirectFillRect(dst,dw,dh,ox+s->x+(int)t->curx*8,oy+s->y+cy*8+7,8,1,(unsigned char)(t->tc&15));
}
static void render_window(unsigned char*dst,GWINDOW*w)
{
 int i,x,y,cx=client_x(w),cy=client_y(w);if(w->flags&TASKBAR_WINDOW){DirectFillRect(dst,DESK_W,DESK_H,w->x,w->y,w->w,w->h,7);}else{DirectFillRect(dst,DESK_W,DESK_H,w->x,w->y,outer_w(w),outer_h(w),7);DirectFillRect(dst,DESK_W,DESK_H,w->x+BORDER,w->y+BORDER,w->w,TITLE_H,focus_wid==w->wid?1:8);DirectDrawTextColor(dst,DESK_W,DESK_H,w->title,w->x+6,w->y+6,15,focus_wid==w->wid?1:8);DirectFillRect(dst,DESK_W,DESK_H,w->x+outer_w(w)-18,w->y+4,14,12,4);DirectDrawTextColor(dst,DESK_W,DESK_H,"X",w->x+outer_w(w)-15,w->y+6,15,4);DirectFillRect(dst,DESK_W,DESK_H,cx,cy,w->w,w->h,0);}
 for(i=0;i<MAX_SURFACES;i++)if(w->surf[i].used){SURFACE*s=&w->surf[i];if(s->type==TYPE_BITMAP_SCREEN&&s->data){for(y=0;y<s->h;y++){int py=cy+s->y+y;if(py<0||py>=DESK_H)continue;for(x=0;x<s->w;x++){int px=cx+s->x+x;if(px>=0&&px<DESK_W)dst[py*DESK_W+px]=s->data[(size_t)y*(size_t)s->w+(size_t)x];}}}else if(s->type==TYPE_TERMINAL_EMULATION)render_terminal(dst,DESK_W,DESK_H,cx,cy,s);}
 for(i=0;i<MAX_BUTTONS;i++)if(w->button[i].used){BUTTON*b=&w->button[i];DirectFillRect(dst,DESK_W,DESK_H,cx+b->x,cy+b->y,b->w,b->h,7);DirectDrawTextColor(dst,DESK_W,DESK_H,b->text,cx+b->x+4,cy+b->y+8,0,7);}
}
static void render_desktop(void)
{
 unsigned char*dst=jsdl_pixels();int order[MAX_WINDOWS],n=0,i,j;if(!dst)return;DirectFillRect(dst,DESK_W,DESK_H,0,0,DESK_W,DESK_H,3);for(i=0;i<MAX_WINDOWS;i++)if(wins[i].used)order[n++]=i;for(i=0;i<n;i++)for(j=i+1;j<n;j++)if(wins[order[i]].z>wins[order[j]].z){int q=order[i];order[i]=order[j];order[j]=q;}for(i=0;i<n;i++)render_window(dst,&wins[order[i]]);jsdl_present();
}
static GWINDOW *hit_window(int x,int y)
{
 GWINDOW*best=NULL;int i;for(i=0;i<MAX_WINDOWS;i++)if(wins[i].used&&x>=wins[i].x&&y>=wins[i].y&&x<wins[i].x+outer_w(&wins[i])&&y<wins[i].y+outer_h(&wins[i]))if(!best||wins[i].z>best->z)best=&wins[i];return best;
}
static void handle_mouse_down(int x,int y,int button)
{
 GWINDOW*w=hit_window(x,y);int i,cx,cy;(void)button;if(!w)return;focus(w);cx=client_x(w);cy=client_y(w);if(!(w->flags&TASKBAR_WINDOW)&&y>=w->y&&y<w->y+TITLE_H+BORDER){if(x>=w->x+outer_w(w)-20){send_gui_event(w->owner,GSID_EXIT,0,0,0);free_window(w);return;}drag_wid=w->wid;drag_dx=x-w->x;drag_dy=y-w->y;return;}for(i=0;i<MAX_BUTTONS;i++)if(w->button[i].used){BUTTON*b=&w->button[i];if(x>=cx+b->x&&y>=cy+b->y&&x<cx+b->x+b->w&&y<cy+b->y+b->h){send_gui_event(w->owner,GSID_BUTTON,b->id,0,0);return;}}
}
static void handle_key(int raw)
{
 GWINDOW*w=win_by_id(focus_wid);int ter,key=raw&0xffff,mods=((raw&0x10000)?1:0)|((raw&0x20000)?2:0);if(!w)return;ter=terminal_of_window(w);if(ter>=0)push_term_key(ter,key,mods);else send_gui_event(w->owner,GSID_KEYPRESSED,key,mods,0);
}
static void pump_sdl(void)
{
 JSDL_EVENT e;while(jsdl_poll_event(&e)){if(e.type==JSDL_EVENT_QUIT){running=0;return;}if(e.type==JSDL_EVENT_KEY)handle_key(e.key);else if(e.type==JSDL_EVENT_MOUSE_DOWN)handle_mouse_down(e.x,e.y,e.button);else if(e.type==JSDL_EVENT_MOUSE_UP)drag_wid=-1;else if(e.type==JSDL_EVENT_MOUSE_MOVE&&drag_wid>=0){GWINDOW*w=win_by_id(drag_wid);if(w){w->x=e.x-drag_dx;w->y=e.y-drag_dy;}}}
}

static int process_request(int fd)
{
 JTMOS_GRAOS_WIRE q,r;unsigned char*payload=NULL;GWINDOW*w;SURFACE*s;int i;memset(&r,0,sizeof(r));r.magic=JTMOS_GRAOS_WIRE_MAGIC;r.version=JTMOS_GRAOS_WIRE_VERSION;if(read_full(fd,&q,sizeof(q))!=0)return-1;if(q.magic!=JTMOS_GRAOS_WIRE_MAGIC||q.version!=JTMOS_GRAOS_WIRE_VERSION||q.payload_len>JTMOS_GRAOS_MAX_PAYLOAD)return-1;if(q.payload_len){payload=malloc(q.payload_len);if(!payload)return-1;if(read_full(fd,payload,q.payload_len)!=0){free(payload);return-1;}}r.op=q.op;r.pid=getpid();r.wid=q.wid;r.object=q.object;r.status=0;
 switch(q.op){
 case GRAOS_OP_PING:break;
 case GRAOS_OP_SHUTDOWN:running=0;break;
 case GRAOS_OP_STATS:{int nw=0,nt=0;for(i=0;i<MAX_WINDOWS;i++)if(wins[i].used)nw++;for(i=10;i<N_MAX_SCREENS;i++)if(IsTerminalValid(i))nt++;r.v[0]=nw;r.v[1]=nt;r.v[2]=focus_wid;break;}
 case GRAOS_OP_CREATE_WINDOW:{JTMOS_GRAOS_CREATE_WINDOW*p=(void*)payload;if(!p||q.payload_len<sizeof(*p)){r.status=-1;break;}for(i=0;i<MAX_WINDOWS&&wins[i].used;i++);if(i==MAX_WINDOWS){r.status=-1;break;}w=&wins[i];memset(w,0,sizeof(*w));w->used=1;w->wid=next_wid++;w->owner=q.pid;w->w=p->w>0?p->w:320;w->h=p->h>0?p->h:200;w->flags=p->flags;w->x=p->x<0?autox:p->x;w->y=p->y<0?autoy:p->y;autox=(autox+28)%260+10;autoy=(autoy+24)%180+10;snprintf(w->title,sizeof(w->title),"%s",p->title);w->z=++next_z;w->next_sid=1;focus(w);r.wid=w->wid;break;}
 case GRAOS_OP_CLOSE_WINDOW:w=win_by_id(q.wid);if(w)free_window(w);else r.status=-1;break;
 case GRAOS_OP_REFRESH_WINDOW:if(!win_by_id(q.wid))r.status=-1;break;
 case GRAOS_OP_ADD_SURFACE:{JTMOS_GRAOS_ADD_SURFACE*p=(void*)payload;w=win_by_id(q.wid);if(!w||!p||q.payload_len<sizeof(*p)){r.status=-1;break;}for(i=0;i<MAX_SURFACES&&w->surf[i].used;i++);if(i==MAX_SURFACES){r.status=-1;break;}s=&w->surf[i];memset(s,0,sizeof(*s));s->used=1;s->sid=w->next_sid++;s->x=p->x;s->y=p->y;s->w=p->w;s->h=p->h;s->bpp=p->bpp;s->type=p->type;s->ter=p->terminal_id;if(s->type==TYPE_BITMAP_SCREEN){s->bytes=(size_t)s->w*(size_t)s->h;s->data=calloc(1,s->bytes);if(!s->data){memset(s,0,sizeof(*s));r.status=-1;break;}}r.object=s->sid;break;}
 case GRAOS_OP_UPDATE_SURFACE:w=win_by_id(q.wid);s=surf_by_id(w,q.object);if(!s||s->type!=TYPE_BITMAP_SCREEN||!s->data){r.status=-1;break;}if(q.payload_len>s->bytes){r.status=-1;break;}memcpy(s->data,payload,q.payload_len);break;
 case GRAOS_OP_CREATE_BUTTON:{JTMOS_GRAOS_BUTTON*p=(void*)payload;w=win_by_id(q.wid);if(!w||!p||q.payload_len<sizeof(*p)){r.status=-1;break;}for(i=0;i<MAX_BUTTONS&&w->button[i].used;i++);if(i==MAX_BUTTONS){r.status=-1;break;}w->button[i].used=1;w->button[i].id=p->id;w->button[i].x=p->x;w->button[i].y=p->y;w->button[i].w=p->w;w->button[i].h=p->h;snprintf(w->button[i].text,sizeof(w->button[i].text),"%s",p->text);break;}
 case GRAOS_OP_CREATE_TERMINAL:r.object=CreateTerminal();if(r.object<0)r.status=-1;else SetTerminalOwner(r.object,q.pid);break;
 case GRAOS_OP_FREE_TERMINAL:if(IsTerminalValid(q.object))FreeScreen(&screens[q.object]);else r.status=-1;break;
 case GRAOS_OP_TERM_WRITE:if(!IsTerminalValid(q.object)){r.status=-1;break;}for(i=0;i<(int)q.payload_len;i++)sputch(&screens[q.object],(char)payload[i]);break;
 case GRAOS_OP_TERM_CLEAR:if(IsTerminalValid(q.object))sclrscr(&screens[q.object]);else r.status=-1;break;
 case GRAOS_OP_TERM_GOTOXY:if(IsTerminalValid(q.object))sgotoxy(&screens[q.object],q.v[0],q.v[1]);else r.status=-1;break;
 case GRAOS_OP_TERM_FG:if(IsTerminalValid(q.object))stextcolor(&screens[q.object],(char)q.v[0]);else r.status=-1;break;
 case GRAOS_OP_TERM_BG:if(IsTerminalValid(q.object))stextbackground(&screens[q.object],(char)q.v[0]);else r.status=-1;break;
 case GRAOS_OP_TERM_GETKEY:if(IsTerminalValid(q.object)){r.v[0]=InputTerminalKeyboardBuffer(&screens[q.object]);r.v[1]=r.v[0]>=0?mod_pop(q.object):0;}else{r.status=-1;r.v[0]=-1;}break;
 case GRAOS_OP_TERM_PUTKEY:if(IsTerminalValid(q.object))push_term_key(q.object,q.v[0],q.v[1]);else r.status=-1;break;
 case GRAOS_OP_SET_PALETTE:jsdl_set_palette(q.v[0],q.v[1],q.v[2],q.v[3]);break;
 default:r.status=-1;break;
 }
 free(payload);r.payload_len=0;if(write_full(fd,&r,sizeof(r))!=0)return-1;return 0;
}

static int server_already_running(void)
{
 int fd;struct sockaddr_un sa;const char*path=socket_path();fd=socket(AF_UNIX,SOCK_STREAM,0);if(fd<0)return 0;memset(&sa,0,sizeof(sa));sa.sun_family=AF_UNIX;if(strlen(path)>=sizeof(sa.sun_path)){close(fd);return 0;}strcpy(sa.sun_path,path);if(connect(fd,(struct sockaddr*)&sa,sizeof(sa))==0){close(fd);return 1;}close(fd);return 0;
}
static int start_socket(void)
{
 struct sockaddr_un sa;int fl;const char*path=socket_path();if(server_already_running()){errno=EADDRINUSE;return-2;}server_fd=socket(AF_UNIX,SOCK_STREAM,0);if(server_fd<0)return-1;memset(&sa,0,sizeof(sa));sa.sun_family=AF_UNIX;if(strlen(path)>=sizeof(sa.sun_path))return-1;strcpy(sa.sun_path,path);unlink(path);if(bind(server_fd,(struct sockaddr*)&sa,sizeof(sa))!=0)return-1;if(listen(server_fd,32)!=0)return-1;fl=fcntl(server_fd,F_GETFL,0);fcntl(server_fd,F_SETFL,fl|O_NONBLOCK);return 0;
}
static void maybe_start_taskbar(const char*self,int enabled){pid_t p;char path[1024],*slash;if(!enabled)return;snprintf(path,sizeof(path),"%s",self);slash=strrchr(path,'/');if(slash){strcpy(slash+1,"taskbar");}else strcpy(path,"taskbar");p=fork();if(p==0){execl(path,path,(char*)NULL);execlp("taskbar","taskbar",(char*)NULL);_exit(127);}}

int main(int argc,char**argv)
{
 int i,taskbar=1;for(i=1;i<argc;i++){if(!strcmp(argv[i],"--auto")||!strcmp(argv[i],"--no-taskbar"))taskbar=0;else if(!strcmp(argv[i],"--taskbar"))taskbar=1;else if(!strcmp(argv[i],"--help")){printf("graos [--taskbar|--no-taskbar]\n");return 0;}}
 signal(SIGINT,sigstop);signal(SIGTERM,sigstop);VirtualTerminalInit();if(start_socket()!=0){perror("graos socket");return 1;}if(jsdl_init("JTMOS GraOS desktop",DESK_W,DESK_H,1)!=0){fprintf(stderr,"graos: SDL2 initialization failed\n");unlink(socket_path());return 2;}ActivateThreadMessageBox((int)getpid());maybe_start_taskbar(argv[0],taskbar);
 while(running){
  int c;
  for(;;){
   c=accept(server_fd,NULL,NULL);
   if(c<0){if(errno==EAGAIN||errno==EWOULDBLOCK)break;if(errno==EINTR)continue;running=0;break;}
   process_request(c);
   close(c);
  }
  pump_sdl();
  cleanup_dead_clients();
  render_desktop();
  jsdl_sleep_ms(16);
 }
 for(i=0;i<MAX_WINDOWS;i++)if(wins[i].used)free_window(&wins[i]);
 jsdl_shutdown();
 if(server_fd>=0)close(server_fd);
 unlink(socket_path());
 return 0;
}
