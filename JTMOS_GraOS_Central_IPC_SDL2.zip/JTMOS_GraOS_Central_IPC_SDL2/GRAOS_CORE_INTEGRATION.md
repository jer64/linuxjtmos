# GraOS core integration

The integrated package uses three host-side libraries:

1. `build/linux_sdl2/libjtmos_graos_linux.a` - GraOS framebuffer/SDL2 bridge, DirectDraw compatibility, virtual terminals and chiplevel host wrappers.
2. `compat/linux_postman/libjtmospostman.a` - Postman/PPCS Linux IPC and broker client.
3. `build/apps_sdl2/libjtmosapps.a` - application-facing console, video, filefind, network and GraOS compatibility calls.

The application SDK no longer compiles its own copies of `directdraw_linux_compat.c` or `jtmos_host_term.c`. Those symbols are provided by the shared GraOS core library.

Linux:

```sh
make core     # core + Postman + app SDK
make apps     # applications, after core
make          # everything
make check
```

Native JTMOS remains:

```sh
make JTMOS=1
```
