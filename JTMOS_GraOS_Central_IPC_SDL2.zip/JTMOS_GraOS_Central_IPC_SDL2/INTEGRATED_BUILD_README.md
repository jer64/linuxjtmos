# JTMOS GraOS SDL2 integrated tree

This package combines the GraOS host core, JTMOS virtual terminals, chiplevel Linux wrappers, Postman/PPCS IPC and the portable applications in one build tree.

## Linux / SDL2 host

```sh
make
make check
```

`make core` builds:

- `build/linux_sdl2/libjtmos_graos_linux.a` -- GraOS/chiplevel/terminal host core
- `compat/linux_postman/libjtmospostman.a` -- Postman/PPCS Linux IPC
- `build/apps_sdl2/libjtmosapps.a` -- application-side compatibility SDK

Applications are linked against the shared GraOS core instead of compiling another private copy of the DirectDraw and virtual-terminal backends.

## Native JTMOS

```sh
make JTMOS=1
```

The original `apps/*.mak` and JTMOS source branches remain available. Linux-only application includes are guarded by `#ifndef JTMOS`.
