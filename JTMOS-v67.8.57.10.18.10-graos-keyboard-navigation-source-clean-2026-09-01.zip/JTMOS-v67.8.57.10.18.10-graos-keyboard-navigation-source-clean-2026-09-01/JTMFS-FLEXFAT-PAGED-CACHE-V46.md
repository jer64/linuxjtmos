# JTMFS FlexFAT V46 paged cache

## Why the on-disk FAT is not a bitmap

JTMFS uses one 32-bit FAT entry per filesystem block. A normal allocated entry
contains the block number of the next block in the file/directory chain. Special
0xFFFFFFFx values mark reserved/bad/end-of-chain states and zero marks a free
block. A one-bit allocation bitmap can represent free/used state, but it cannot
represent the next-block links without introducing a second on-disk structure.
Therefore V46 intentionally keeps the JTMFS on-disk format unchanged.

## What changed

The RAM cache is now demand paged. The old FlexFAT allocated `getsize(dnr)*4`
bytes and read the complete FAT on first access after activation. V46 keeps up
to 64 FAT sectors resident per active block device.

Each resident slot has:

- one FAT sector of data;
- a FAT-sector tag;
- an LRU timestamp;
- one dirty byte.

A FAT entry lookup maps directly to:

    entry -> FAT sector -> cache slot -> DWORD within sector

Cache misses read only the requested FAT sector. Dirty LRU victims are written
before reuse. `flexFlushFAT()` writes only resident dirty sectors.

`FastSetBlocks()` additionally recognizes complete FAT-sector overwrites. During
mkfs, sectors that are being completely initialized can be created in cache
without a read-before-write.

## Memory scaling

For a 512-byte block device, 64 cache slots use 32 KiB of FAT data plus small
dynamic metadata. The amount is independent of total disk size.

Examples (FAT data only):

- JTMOS 15 MiB test disk: old ~116 KiB, V46 32 KiB
- 1 GiB disk: old 8 MiB, V46 32 KiB
- 8 GiB disk: old 64 MiB, V46 32 KiB

The old 64 MiB `MAX_FAT_SIZE` allocation ceiling is no longer needed by
FlexFAT. Other JTMFS/driver limits still apply; this change alone is not a claim
of arbitrary large-disk support.

## Compatibility

The disk format is unchanged. Existing JTMFS volumes do not need conversion.
All public FAT get/set calls retain their existing API.

`flexRWFAT(WRITE)` remains a flush operation. `flexRWFAT(READ)` is retained as a
compatibility entry point but now refreshes/invalidate the lazy cache instead of
loading the entire FAT. Current JTMFS code does not call it for ordinary reads.

## Runtime tests recommended

1. `mkfs ram`, `cd ram`, create/read/delete several files.
2. `mkfs hda`, `cd hda`, `sqa sys`, then run extracted programs.
3. Reboot and verify files remain readable.
4. Fragment a test file (create/delete many files), then verify chained reads.
5. With `debug on`, inspect FlexFAT hit/miss/read/write counters using the FAT
   information command if exposed by the shell.
