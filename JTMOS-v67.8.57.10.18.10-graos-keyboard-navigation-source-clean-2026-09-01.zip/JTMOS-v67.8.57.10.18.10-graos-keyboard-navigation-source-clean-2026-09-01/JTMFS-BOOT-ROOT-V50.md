# JTMOS V50 - boot RAM root and block-device mount points

V50 fixes the boot-time RAM filesystem lifecycle and changes the JTMFS namespace root
back to a real filesystem root backed by the mounted root device (currently `ram:`).

Boot order:

1. register/create `ram:`
2. initialize JTMFS access
3. format `ram:` when no persistent RAM-disk image exists
4. `mount_root(ram)`
5. set init-thread DNR/DB to the RAM JTMFS root
6. initialize IDE/partitions and remaining boot devices
7. create physical root-directory entries for registered storage block devices
8. reassert init-thread CWD `/`
9. create CP and SMSH, which inherit `/`

`rd_createdefaultramdisk()` is idempotent, so a later legacy RAM service cannot erase
an already-created/formatted `default_ramdisk` image.

The root directory contains mount-point names such as `ram`, `ramdisk`, `floppy`,
`sys`, `system`, and `hda` when those block devices are registered and have a usable
block geometry. A JTMFS-formatted device name switches pathname resolution to the
actual device DNR and its real JTMFS root DB. An unformatted/raw device remains an
ordinary placeholder directory on the RAM root until a supported filesystem is
available there.

Canonical paths:

- RAM root: `/`
- hda root when JTMFS-ready: `/hda`
- hda subdirectory: `/hda/bin`
- `..` from `/hda` returns to `/`

TODO: when persistent/preloaded RAM-disk image loading is implemented, skip the boot
format if a valid image was loaded, but still mount it and synchronize mount points.
