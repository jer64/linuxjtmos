# JTMOS V67.8.57.10.16 — Windows 98 UI refresh

This maintenance release refreshes GraOS presentation around three classic Windows 98 patterns while preserving the existing JTMOS/GraOS process and IPC model.

## Window chrome

- Active captions use a flat dark-blue title field and inactive captions use classic gray.
- The 20-pixel caption keeps the native 8-pixel bitmap title text at `y+6`, leaving about 3 pixels of clear space above and below it inside the title field.
- Title text is rendered once, without the former black drop shadow, for a crisper low-resolution result.
- Borders and title controls use classic raised/sunken 3-D edges.

## Taskbar and Start menu

- GraOS reserves a 30-pixel bottom taskbar.
- Both the integrated desktop panel and external `taskbar.bin` use a compact raised Start button, gray 3-D taskbar surfaces, and more breathing space.
- Start menus use 32-pixel rows, 16/24-pixel style icons, a dark-blue selection state, submenu arrows where appropriate, and a blue JTMOS98 branding strip.
- `taskbar.bin` now opens an actual popup Start menu with Programs, File Manager, Text Editor, Task Manager, Settings, Run, and Close Menu actions instead of launching the application list directly.

## Control Panel

- Internal and external Control Panels are now 740x430 two-pane windows.
- The left pane contains the Control Panel heading, short explanatory copy, and status.
- The right pane is a spaced icon grid for Terminal, File Manager, Text Editor, Task Manager, and desktop appearance actions.
- Icon-grid buttons are visually flat until selected, matching the Windows 98 Control Panel feel.

## API / protocol

- Added styled-button presentation bits (`MENU`, `ICON_VIEW`, `START`, icon IDs) without changing the existing GraOS command IDs.
- `createButtonStyled()` exposes those styles to external Ring3 GraOS applications.
- The CREATEBUTTON IPC request uses the previously unused `v[6]` field for style; old zero-filled clients remain standard-button compatible.
- GraOS version is V37 and the public default panel height is 30 pixels.

## Validation

- `graos.bin`: clean ELF32/i386 build.
- `controlpanel.bin`: clean ELF32/i386 build.
- `taskbar.bin`: clean ELF32/i386 build.
- `tools/check_graos_apps.sh`: PASS.
- `tools/check_graos_win98_ui.sh`: PASS.

The full legacy release-layout check cannot complete from this V67.8.57.10.15 source-clean base because that archive already lacks several historical `kernel32/core/{int,lowlevel,iodma}` paths referenced by the checker; this UI work does not touch those paths.
