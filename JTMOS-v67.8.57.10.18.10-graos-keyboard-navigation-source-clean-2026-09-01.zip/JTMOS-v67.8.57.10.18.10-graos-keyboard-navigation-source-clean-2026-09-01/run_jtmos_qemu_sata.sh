#!/bin/sh
# JTMOS V67.8.57.10.17 SATA/AHCI QEMU launcher
# A: boot-only floppy (boot32pm + kernel)
# B: root/system SQARC floppy (preferred sys: backend)
# CD-ROM: same root/system SQARC payload (legacy ATAPI fallback)
# HDA: attached to an explicit ICH9 AHCI controller so the native SATA path is tested.
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BOOT_FLOPPY=${JTMOS_FLOPPY:-${1:-$SCRIPT_DIR/jtm32.img}}
HDD=${JTMOS_HDD:-${2:-$SCRIPT_DIR/hd_jtmos.img}}
ROOT_FLOPPY=${JTMOS_ROOT_FLOPPY:-${3:-$SCRIPT_DIR/root1440.img}}
ROOT_CDROM=${JTMOS_ROOT_CDROM:-${4:-$SCRIPT_DIR/utilities.iso}}
RUNTIME=${JTMOS_SLIP_RUNTIME:-${XDG_RUNTIME_DIR:-/tmp}/jtmos-slip}
SLIP_PIPE=${JTMOS_SLIP_PIPE:-$RUNTIME/jtmos-slip}
SERIAL_LOG=${JTMOS_SERIAL_LOG:-$SCRIPT_DIR/serial_output.log}

command -v qemu-system-i386 >/dev/null 2>&1 || { echo "qemu-system-i386 not found in PATH." >&2; exit 127; }
[ -f "$BOOT_FLOPPY" ] || { echo "JTMOS boot floppy not found: $BOOT_FLOPPY" >&2; exit 1; }
if [ "$ROOT_FLOPPY" != none ] && [ ! -f "$ROOT_FLOPPY" ]; then
  echo "JTMOS B: root floppy not found: $ROOT_FLOPPY" >&2; exit 1
fi
if [ "$ROOT_CDROM" != none ] && [ ! -f "$ROOT_CDROM" ]; then
  echo "JTMOS ATAPI root image not found: $ROOT_CDROM" >&2; exit 1
fi
if [ "$ROOT_FLOPPY" = none ] && [ "$ROOT_CDROM" = none ]; then
  echo "No root medium selected; use B: root1440.img or utilities.iso." >&2; exit 1
fi
if [ ! -f "$HDD" ]; then "$SCRIPT_DIR/make_hd_jtmos.sh" "$HDD"; fi
if [ ! -p "$SLIP_PIPE.in" ] || [ ! -p "$SLIP_PIPE.out" ]; then
  echo "JTMOS SLIP FIFOs are not ready; run ubuntu-slip/slip-up.sh" >&2; exit 1
fi

echo "JTMOS QEMU configuration:"
echo "  floppy A / boot: $BOOT_FLOPPY"
echo "  floppy B / root: $ROOT_FLOPPY"
echo "  ATAPI root:      $ROOT_CDROM"
echo "  SATA/AHCI HDA:   $HDD"

set -- qemu-system-i386 -machine pc -m 512 -vga std \
  -drive "file=$BOOT_FLOPPY,format=raw,if=floppy,index=0" \
  -device ich9-ahci,id=jtmosahci \
  -drive "file=$HDD,format=raw,if=none,id=jtmosdisk,cache=writethrough" \
  -device ide-hd,drive=jtmosdisk,bus=jtmosahci.0
if [ "$ROOT_FLOPPY" != none ]; then
  set -- "$@" -drive "file=$ROOT_FLOPPY,format=raw,if=floppy,index=1"
fi
if [ "$ROOT_CDROM" != none ]; then
  set -- "$@" -cdrom "$ROOT_CDROM"
fi
set -- "$@" \
  -device gus,irq=5 \
  -netdev user,id=jtmosnet \
  -device ne2k_isa,netdev=jtmosnet,iobase=0x300,irq=9 \
  -serial "file:$SERIAL_LOG" \
  -serial "pipe:$SLIP_PIPE" \
  -boot a
exec "$@"
