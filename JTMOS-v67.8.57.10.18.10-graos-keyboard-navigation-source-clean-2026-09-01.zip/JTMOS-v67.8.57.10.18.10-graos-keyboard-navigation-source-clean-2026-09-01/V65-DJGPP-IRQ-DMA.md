JTMOS V65 - safe userspace IRQ / ISA DMA ABI and DJGPP compatibility
====================================================================
Date: 2026-08-22

V65 closes the first-generation application-driver ABI gap without executing
ring-3 code from an IRQ stack.

IRQ ABI
-------
New syscalls 115..117 implement subscribe, unsubscribe and wait/poll. A kernel
ISR records a pending event and acknowledges the 8259 PIC; application code
handles the event only after returning to normal syscall/thread context.
Subscriptions are process-owned, exclusive, automatically reclaimed on process
termination, and cannot steal an IRQ whose IDT gate is already owned by an
in-kernel driver. IRQ0 and cascade IRQ2 are always reserved.

DMA ABI
-------
New syscalls 118..121 allocate/free/program/stop a kernel-owned ISA DMA buffer.
V65 allocations are contiguous physical memory below 16 MiB, page aligned and
must not cross a 64 KiB 8237 boundary. The first safe ABI supports 8-bit DMA
channels 0..3 (channel 4 is the cascade). Buffers are mapped into the requesting
ELF32 process and are reclaimed at process exit. A2K recognizes these mappings,
so ordinary kernel syscalls can safely receive a DMA-buffer pointer.

FDC overlap correction
----------------------
The V64 floppy driver used a fixed 0x80000..0x8ffff bounce window. With a kernel
linked at 0x10000 and already around 463 KiB, that range can overlap the kernel
image. V65 removes the fixed address. FDC now requests a 64 KiB boundary-safe
low-memory buffer from the same physical-page broker after MM initialization.

DJGPP libc layer
----------------
Public headers jtmos/irq.h and jtmos/dma.h expose the native V65 API. dpmi.h and
go32.h provide the most useful source-compatibility subset. DPMI code/data lock
calls are no-ops that succeed because JTMOS does not swap ELF32 application
pages. Direct DPMI installation/chaining of application interrupt gates is
intentionally ENOTSUP: it would reintroduce unsafe userspace execution in IRQ
context. JTMOS-specific _go32_dpmi_jtmos_irq_* and _go32_dpmi_jtmos_dma_*
wrappers provide the safe replacement.

Important scope statement
-------------------------
V65 provides the missing kernel mediation needed to port IRQ/DMA application
drivers. The bundled Sound Blaster, GUS and FDC implementations are not all
claimed to have become external userspace drivers. FDC uses the new kernel DMA
allocator; SB/GUS remain kernel drivers in this snapshot until separately
ported to this ABI.

DJGPP compatibility reference
-----------------------------
The exposed lock/vector/wrapper signatures and Go32_Info_Block layout were
checked against the DJGPP libc reference at delorie.com. JTMOS deliberately
keeps the signatures where implemented but does not pretend to be a real DOS
DPMI host.
