# JTMOS SDL2 ports

`./sdl2/` is the common home/entry point for Linux SDL2 ports of JTMOS software.

* `cbmvm/` — CBMVM 0.6 C128 BASIC 7 core + graphics VM. One VM core, SDL2 graphics on Linux and
  native GraOS graphics on JTMOS.
* `graos/` — root-level entry point to the existing GraOS Linux/SDL2 host tree.

Build with the requested dual-core policy:

    make -C sdl2 -j2
    make -C sdl2/cbmvm -j2 test
    make -C sdl2/cbmvm -j2 jtmos

Linux CBMVM needs SDL 2.x development headers/libraries (`pkg-config sdl2` or
`sdl2-config`). Native JTMOS CBMVM does not link SDL; it uses the GraOS client
ABI and a 32-bit RGBA framebuffer window.
