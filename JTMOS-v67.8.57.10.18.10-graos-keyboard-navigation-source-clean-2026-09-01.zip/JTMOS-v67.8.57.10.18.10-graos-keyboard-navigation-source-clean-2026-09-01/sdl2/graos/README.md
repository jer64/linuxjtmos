# GraOS SDL2 port

This directory is the root-level SDL2 entry point requested for JTMOS ports.
The existing mature GraOS Linux host implementation remains under
`../../graos-host/` because it also contains the Postman compatibility layer,
portable applications and shared host SDK.  `make` here delegates to that
implementation so there is one source of truth instead of two diverging copies.
