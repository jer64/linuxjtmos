#include <stdio.h>
#include <string.h>
#include "cbmvm_engine.h"

typedef struct {
    unsigned int presents;
    unsigned int sprite_updates;
    unsigned int sprite_editor_calls;
    unsigned int clears;
} GFX_HOST;

static void on_present(void *p, const uint8_t *pixels, size_t bytes, int w, int h,
                       const uint8_t colors[7], int mode, int split)
{
    GFX_HOST *s=(GFX_HOST *)p;
    (void)pixels; (void)bytes; (void)w; (void)h; (void)colors; (void)mode; (void)split;
    s->presents++;
}
static void on_sprite(void *p, int number, int enabled, int x, int y, int color,
                      int priority, int xe, int ye, int multi, const uint8_t data[63])
{
    GFX_HOST *s=(GFX_HOST *)p;
    (void)number;(void)enabled;(void)x;(void)y;(void)color;(void)priority;(void)xe;(void)ye;(void)multi;(void)data;
    s->sprite_updates++;
}
static int on_editor(void *p, uint8_t data[8][63])
{
    GFX_HOST *s=(GFX_HOST *)p;
    s->sprite_editor_calls++;
    data[0][0]=0xff;
    data[0][1]=0x81;
    return 0;
}
static void on_clear(void *p) { ((GFX_HOST *)p)->clears++; }

static int run_file(CBMVM *vm, const char *name)
{
    int rc=cbmvm_load_prg_file(vm,name);
    if(rc!=CBMVM_OK) return rc;
    do { rc=cbmvm_run(vm,10000); } while(rc==CBMVM_YIELDED);
    return rc;
}

int main(void)
{
    CBMVM_HOST host;
    GFX_HOST state;
    CBMVM *vm;
    const CBMVM_GRAPHICS *g;
    unsigned int x,y,lit=0;
    int found_shape=0;
    memset(&host,0,sizeof(host)); memset(&state,0,sizeof(state));
    host.userdata=&state;
    host.graphics_present=on_present;
    host.sprite_update=on_sprite;
    host.sprite_editor=on_editor;
    host.screen_clear=on_clear;
    vm=cbmvm_create(&host);
    if(!vm) return 1;

    if(run_file(vm,"examples/graphics_demo.prg")!=CBMVM_HALTED){fprintf(stderr,"graphics demo: %s\n",cbmvm_last_error(vm));return 2;}
    g=cbmvm_graphic_state(vm);
    if(!g || g->mode!=1 || g->color[0]!=1 || g->color[1]!=2 || g->color[4]!=7) return 3;
    if(cbmvm_graphic_pixel(vm,5,5)!=1 || cbmvm_graphic_pixel(vm,160,95)!=1 || cbmvm_graphic_pixel(vm,250,30)!=1) return 4;
    for(y=0;y<CBMVM_GFX_HEIGHT;y++) for(x=0;x<CBMVM_GFX_WIDTH;x++) if(cbmvm_graphic_pixel(vm,(int)x,(int)y)) lit++;
    if(lit<5000) { fprintf(stderr,"too few graphics pixels: %u\n",lit); return 5; }
    if(g->sprites[0].enabled!=1 || g->sprites[0].color!=3 || g->sprites[0].x!=100 || g->sprites[0].y!=80) return 6;
    for(x=0;x<vm->variable_count;x++) if(strcmp(vm->variables[x].name,"A$")==0 && vm->variables[x].string_length>4) found_shape=1;
    if(!found_shape || state.presents<8 || state.sprite_updates<2) return 7;

    if(run_file(vm,"examples/sprite_motion.prg")!=CBMVM_HALTED) return 8;
    g=cbmvm_graphic_state(vm);
    if(!g->sprites[0].moving || (int)g->sprites[0].angle!=90 || (int)g->sprites[0].speed!=2) return 9;
    cbmvm_graphic_tick(vm,5);
    if(g->sprites[0].x!=110 || g->sprites[0].y!=80) { fprintf(stderr,"sprite tick x=%d y=%d\n",g->sprites[0].x,g->sprites[0].y); return 10; }

    if(run_file(vm,"examples/sprdef.prg")!=CBMVM_HALTED) return 11;
    if(state.sprite_editor_calls!=1 || cbmvm_graphic_state(vm)->sprites[0].data[0]!=0xff) return 12;

    if(run_file(vm,"examples/scnclr.prg")!=CBMVM_HALTED) return 13;
    if(cbmvm_graphic_pixel(vm,10,10)!=0 || state.clears<2) return 14; /* GRAPHIC 1,1 plus SCNCLR */

    cbmvm_destroy(vm);
    puts("PASS graphics-basic7");
    return 0;
}
