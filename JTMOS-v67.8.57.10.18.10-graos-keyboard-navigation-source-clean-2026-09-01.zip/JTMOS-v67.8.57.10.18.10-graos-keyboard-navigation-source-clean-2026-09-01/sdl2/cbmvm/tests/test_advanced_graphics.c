#include <stdio.h>
#include <string.h>
#include "cbmvm_engine.h"
#include "cbmvm_petscii.h"

typedef struct {
    unsigned int dirty_calls;
    unsigned int timer_calls;
    unsigned int sprite_color_calls;
    int last_mc1,last_mc2;
    int last_x,last_y,last_w,last_h,min_w;
} HOSTSTATE;

static void on_dirty(void *p,const uint8_t *px,size_t bytes,int w,int h,
                     const uint8_t colors[7],int mode,int split,int x,int y,int dw,int dh)
{
    HOSTSTATE *s=(HOSTSTATE*)p;
    (void)px;(void)bytes;(void)w;(void)h;(void)colors;(void)mode;(void)split;
    s->dirty_calls++;s->last_x=x;s->last_y=y;s->last_w=dw;s->last_h=dh;if(s->min_w==0||dw<s->min_w)s->min_w=dw;
}
static void on_tick(void *p,unsigned int hz,uint64_t jiffy)
{
    HOSTSTATE *s=(HOSTSTATE*)p;(void)hz;(void)jiffy;s->timer_calls++;
}
static void on_sprite_colors(void *p,int mc1,int mc2)
{
    HOSTSTATE *s=(HOSTSTATE*)p;s->sprite_color_calls++;s->last_mc1=mc1;s->last_mc2=mc2;
}

static CBMVM_VARIABLE *var(CBMVM *vm,const char *name)
{
    unsigned int i;for(i=0;i<vm->variable_count;i++)if(strcmp(vm->variables[i].name,name)==0)return &vm->variables[i];
    return NULL;
}

int main(void)
{
    CBMVM_GRAPHICS g;
    uint8_t rows[8];
    int x,y,w,h;
    CBMVM_HOST host;
    HOSTSTATE st;
    CBMVM *vm;
    const CBMVM_GRAPHICS *vg;
    CBMVM_VARIABLE *a;
    int rc,i;

    cbmvm_petscii_glyph('A',rows);
    if(!(rows[0]|rows[1]|rows[2]|rows[3]|rows[4]|rows[5]|rows[6]|rows[7])) return 1;
    cbmvm_petscii_glyph(0x60,rows);
    if(!(rows[0]|rows[1]|rows[2]|rows[3]|rows[4]|rows[5]|rows[6]|rows[7])) return 2;

    cbmvm_graphics_reset(&g);
    if(!cbmvm_graphics_take_dirty(&g,&x,&y,&w,&h)||w!=320||h!=200) return 3;
    cbmvm_graphics_put_pixel(&g,10,11,1);
    if(!cbmvm_graphics_take_dirty(&g,&x,&y,&w,&h)||x!=10||y!=11||w!=1||h!=1) return 4;
    if(cbmvm_graphics_set_mode(&g,1,1,-1)<0||cbmvm_graphics_set_scale(&g,1,1000,1000)<0) return 5;
    if(cbmvm_graphics_scale_x(&g,500)<159||cbmvm_graphics_scale_x(&g,500)>160) return 6;
    if(cbmvm_graphics_unscale_x(&g,cbmvm_graphics_scale_x(&g,500))<498) return 7;
    if(cbmvm_graphics_set_width(&g,2)<0) return 8;
    cbmvm_graphics_put_pixel(&g,20,20,1);
    if(cbmvm_graphics_get_pixel(&g,21,21)!=1) return 9;

    cbmvm_graphics_clear(&g,0);
    for(i=0;i<63;i++){g.sprites[0].data[i]=0xff;g.sprites[1].data[i]=0xff;}
    g.sprites[0].enabled=g.sprites[1].enabled=1;
    g.sprites[0].x=30;g.sprites[0].y=30;g.sprites[1].x=35;g.sprites[1].y=35;
    cbmvm_graphics_detect_collisions(&g);
    if(cbmvm_graphics_bump(&g,1)!=3||cbmvm_graphics_bump(&g,1)!=0) return 10;
    cbmvm_graphics_put_pixel(&g,30,30,1);
    cbmvm_graphics_detect_collisions(&g);
    if((cbmvm_graphics_bump(&g,2)&1)==0) return 11;

    memset(&host,0,sizeof(host));memset(&st,0,sizeof(st));host.userdata=&st;
    host.graphics_present_dirty=on_dirty;host.timer_tick=on_tick;host.sprite_colors=on_sprite_colors;
    vm=cbmvm_create(&host);if(!vm)return 12;
    if(cbmvm_load_prg_file(vm,"examples/graphics_advanced.prg")!=CBMVM_OK)return 13;
    do{rc=cbmvm_run(vm,10000);}while(rc==CBMVM_YIELDED);
    if(rc!=CBMVM_HALTED){fprintf(stderr,"advanced: %s\n",cbmvm_last_error(vm));return 14;}
    vg=cbmvm_graphic_state(vm);
    if(!vg->scale_enabled||vg->scale_xmax!=1000||vg->line_width!=2) return 15;
    if(vg->sprite_multicolor[0]!=6||vg->sprite_multicolor[1]!=8||st.sprite_color_calls==0||st.last_mc1!=6||st.last_mc2!=8) return 16;
    if(vg->sprites[0].x<159||vg->sprites[0].x>160||vg->sprites[0].x_expand!=1) return 17;
    if(st.dirty_calls==0||st.min_w>=320) return 18; /* final DRAW/CHAR path must exercise dirty compositor */

    if(cbmvm_load_prg_file(vm,"examples/sprsav.prg")!=CBMVM_OK)return 19;
    for(i=0;i<63;i++) vm->graphics.sprites[0].data[i]=(uint8_t)(i^0x5a);
    vm->graphics.sprites[0].multicolor=1;
    do{rc=cbmvm_run(vm,10000);}while(rc==CBMVM_YIELDED);
    if(rc!=CBMVM_HALTED)return 20;
    a=var(vm,"A$");if(!a||a->string_length!=67||memcmp(vm->graphics.sprites[0].data,vm->graphics.sprites[1].data,63)!=0||vm->graphics.sprites[1].multicolor!=1)return 21;

    if(cbmvm_load_prg_file(vm,"examples/collision_irq.prg")!=CBMVM_OK)return 22;
    if(cbmvm_step(vm)!=CBMVM_OK)return 23; /* install COLLISION 1,100 */
    for(i=0;i<63;i++){vm->graphics.sprites[0].data[i]=0xff;vm->graphics.sprites[1].data[i]=0xff;}
    vm->graphics.sprites[0].enabled=vm->graphics.sprites[1].enabled=1;
    vm->graphics.sprites[0].x=50;vm->graphics.sprites[0].y=50;vm->graphics.sprites[1].x=55;vm->graphics.sprites[1].y=55;
    cbmvm_timer_tick(vm);
    for(i=0;i<4;i++)if(cbmvm_step(vm)==CBMVM_ERR)return 24;
    a=var(vm,"A");if(!a||a->number<1.0)return 25;

    cbmvm_reset(vm);
    vm->graphics.sprites[0].enabled=1;vm->graphics.sprites[0].moving=1;vm->graphics.sprites[0].angle=90;vm->graphics.sprites[0].speed=2;vm->graphics.sprites[0].x=100;vm->graphics.sprites[0].y=80;
    if(cbmvm_set_video_hz(vm,50)!=CBMVM_OK)return 26;
    cbmvm_timer_advance_us(vm,100000); /* exactly five PAL frames */
    if(vm->graphics.sprites[0].x!=110||cbmvm_video_jiffy(vm)!=5||st.timer_calls<6) return 27;
    if(cbmvm_set_video_hz(vm,60)!=CBMVM_OK||cbmvm_video_hz(vm)!=60) return 28;

    cbmvm_destroy(vm);
    puts("PASS advanced-graphics-timer-collision");
    return 0;
}
