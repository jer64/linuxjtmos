#include <stdio.h>
#include <string.h>
#include "cbmvm_engine.h"
#include "cbmvm_jtmos.h"

typedef struct { uint64_t now; unsigned int ticks; } STATE;
static uint64_t now_us(void *p){return ((STATE*)p)->now;}
static void tick(void *p,unsigned int hz,uint64_t jiffy){STATE*s=(STATE*)p;(void)hz;(void)jiffy;s->ticks++;}
int main(void)
{
    STATE st; CBMVM_JTMOS_BINDINGS b; CBMVM_JTMOS_CONTEXT ctx; CBMVM_HOST host; CBMVM *vm; int rc;
    memset(&st,0,sizeof(st));memset(&b,0,sizeof(b));b.userdata=&st;b.monotonic_us=now_us;b.timer_tick=tick;
    cbmvm_jtmos_host_init(&ctx,&b,&host);vm=cbmvm_create(&host);if(!vm)return 1;
    if(cbmvm_load_prg_file(vm,"examples/infinite.prg")!=CBMVM_OK)return 2;
    vm->graphics.sprites[0].enabled=1;vm->graphics.sprites[0].moving=1;vm->graphics.sprites[0].angle=90;vm->graphics.sprites[0].speed=2;vm->graphics.sprites[0].x=100;vm->graphics.sprites[0].y=80;
    st.now=1000000;rc=cbmvm_jtmos_run_slice(vm,&ctx,1);if(rc!=CBMVM_YIELDED)return 3;
    st.now=1100000;rc=cbmvm_jtmos_run_slice(vm,&ctx,1);if(rc!=CBMVM_YIELDED)return 4;
    if(st.ticks!=5||cbmvm_video_jiffy(vm)!=5||vm->graphics.sprites[0].x!=110){fprintf(stderr,"ticks=%u jiffy=%llu x=%d\n",st.ticks,(unsigned long long)cbmvm_video_jiffy(vm),vm->graphics.sprites[0].x);return 5;}
    cbmvm_destroy(vm);puts("PASS jtmos-virtual-timer");return 0;
}
