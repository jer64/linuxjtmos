#include <stdio.h>
#include <string.h>
#include "cbmvm_engine.h"

typedef struct {
    char out[4096];
    size_t out_len;
    const unsigned char *input;
    size_t input_len, input_pos;
} CORE_HOST;

static void on_putc(void *p,int ch)
{
    CORE_HOST *s=(CORE_HOST*)p;
    if(s->out_len+1<sizeof(s->out)) s->out[s->out_len++]=(char)ch;
    s->out[s->out_len]=0;
}
static int on_getc(void *p)
{
    CORE_HOST *s=(CORE_HOST*)p;
    if(s->input_pos>=s->input_len) return -1;
    return s->input[s->input_pos++];
}
static int run_file(CBMVM *vm,const char *name)
{
    int rc=cbmvm_load_prg_file(vm,name);
    if(rc!=CBMVM_OK)return rc;
    do{rc=cbmvm_run(vm,1000);}while(rc==CBMVM_YIELDED);
    return rc;
}
static CBMVM_VARIABLE *var(CBMVM *vm,const char *name)
{
    unsigned int i;for(i=0;i<vm->variable_count;i++)if(strcmp(vm->variables[i].name,name)==0)return &vm->variables[i];return NULL;
}
int main(void)
{
    CBMVM_HOST host;CORE_HOST state;CBMVM*vm;CBMVM_VARIABLE*v;int rc;
    static const unsigned char input[]="JARI,42\rZ";
    memset(&host,0,sizeof(host));memset(&state,0,sizeof(state));host.userdata=&state;host.putc=on_putc;host.getc=on_getc;
    vm=cbmvm_create(&host);if(!vm)return 1;
    rc=run_file(vm,"examples/core_commands.prg");
    if(rc!=CBMVM_HALTED){fprintf(stderr,"core rc=%d err=%s\n",rc,cbmvm_last_error(vm));return 2;}
    if(!strstr(state.out,"ONOK\n")||!strstr(state.out,"10,20,30,HELLO,WORLD,10\n")||!strstr(state.out,"5,WOR,LD,ORL\n")||!strstr(state.out,"ELSEOK\n")||!strstr(state.out,"-1,3,2,3\n")||!strstr(state.out,"FN:17:X:10\n")){
        fprintf(stderr,"unexpected core output:\n%s\n",state.out);return 3;
    }
    v=var(vm,"A(2)");if(!v||v->number!=30.0)return 4;
    v=var(vm,"B$(1)");if(!v||strcmp(v->string,"WORLD")!=0)return 5;

    memset(&state,0,sizeof(state));state.input=input;state.input_len=sizeof(input)-1;host.userdata=&state;
    cbmvm_destroy(vm);vm=cbmvm_create(&host);if(!vm)return 6;
    rc=run_file(vm,"examples/input_get.prg");
    if(rc!=CBMVM_HALTED){fprintf(stderr,"input rc=%d err=%s\n",rc,cbmvm_last_error(vm));return 7;}
    if(!strstr(state.out,"NAMEJARI,42\n")||!strstr(state.out,"JARI:42:Z\n")){fprintf(stderr,"unexpected input output:\n%s\n",state.out);return 8;}
    v=var(vm,"N$");if(!v||strcmp(v->string,"JARI")!=0)return 9;
    v=var(vm,"A");if(!v||v->number!=42.0)return 10;

    memset(&state,0,sizeof(state));host.userdata=&state;
    cbmvm_destroy(vm);vm=cbmvm_create(&host);if(!vm)return 11;
    rc=run_file(vm,"examples/structured_commands.prg");
    if(rc!=CBMVM_HALTED){fprintf(stderr,"structured rc=%d err=%s\n",rc,cbmvm_last_error(vm));return 12;}
    if(!strstr(state.out,"DOWHILE:3\n")||!strstr(state.out,"EXIT:2\n")||!strstr(state.out,"UNTIL:2\n")||!strstr(state.out,"SKIP:0\n")||!strstr(state.out,"NEST:2\n")){fprintf(stderr,"unexpected structured output:\n%s\n",state.out);return 13;}

    memset(&state,0,sizeof(state));host.userdata=&state;
    cbmvm_destroy(vm);vm=cbmvm_create(&host);if(!vm)return 14;
    rc=cbmvm_load_prg_file(vm,"examples/getkey.prg");if(rc!=CBMVM_OK)return 15;
    rc=cbmvm_run(vm,100);if(rc!=CBMVM_YIELDED){fprintf(stderr,"GETKEY should yield without a key, rc=%d\n",rc);return 16;}
    {static const unsigned char key_input[]="Q";state.input=key_input;state.input_len=1;}
    do{rc=cbmvm_run(vm,100);}while(rc==CBMVM_YIELDED);
    if(rc!=CBMVM_HALTED||!strstr(state.out,"KEY:Q\n")){fprintf(stderr,"GETKEY failed rc=%d out=%s err=%s\n",rc,state.out,cbmvm_last_error(vm));return 17;}
    cbmvm_destroy(vm);
    puts("PASS core-basic-commands");return 0;
}
