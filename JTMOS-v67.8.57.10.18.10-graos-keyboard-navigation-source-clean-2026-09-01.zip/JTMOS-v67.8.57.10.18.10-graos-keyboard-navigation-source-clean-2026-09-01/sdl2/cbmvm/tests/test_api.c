#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cbmvm_engine.h"

typedef struct { unsigned int yields; } TEST_HOST;
static void on_yield(void *p) { ((TEST_HOST *)p)->yields++; }

int main(void)
{
    CBMVM_HOST host;
    TEST_HOST state;
    CBMVM *vm;
    int rc;
    memset(&host, 0, sizeof(host));
    memset(&state, 0, sizeof(state));
    host.userdata = &state;
    host.yield = on_yield;
    vm = cbmvm_create(&host);
    if (!vm) return 1;
    if (cbmvm_load_prg_file(vm, "examples/infinite.prg") != CBMVM_OK) {
        fprintf(stderr, "%s\n", cbmvm_last_error(vm));
        return 2;
    }
    rc = cbmvm_run(vm, 7);
    if (rc != CBMVM_YIELDED || vm->instructions != 7 || state.yields != 1) {
        fprintf(stderr, "budget failure rc=%d instructions=%lu yields=%u\n",
                rc, vm->instructions, state.yields);
        return 3;
    }
    if (cbmvm_instance_bytes(vm) > 139264u) {
        fprintf(stderr, "VM footprint too large: %zu\n", cbmvm_instance_bytes(vm));
        return 4;
    }
    cbmvm_destroy(vm);
    puts("PASS api-budget-footprint");
    return 0;
}
