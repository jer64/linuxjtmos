#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cbmvm_engine.h"

typedef struct { int border_writes; int last_border; unsigned int yields; } H;
static int iow(void *p,uint16_t a,uint8_t v){H*h=(H*)p;if(a==0xd020){h->border_writes++;h->last_border=v&15;}return 1;}
static void yld(void*p){((H*)p)->yields++;}

static CBMVM *make_vm(H *h,const uint8_t *code,size_t n)
{
    CBMVM_HOST host;CBMVM*vm;uint8_t *prg;size_t total=2u+(0x1000u-0x0801u)+n;size_t o;
    memset(&host,0,sizeof(host));host.userdata=h;host.io_write=iow;host.yield=yld;
    prg=(uint8_t*)calloc(1,total);if(!prg)return NULL;prg[0]=0x01;prg[1]=0x08;
    o=2;prg[o+0]=0;prg[o+1]=0;prg[o+2]=10;prg[o+3]=0;prg[o+4]=0x9e;memcpy(prg+o+5,"4096",4);prg[o+9]=0;
    memcpy(prg+2+(0x1000u-0x0801u),code,n);
    vm=cbmvm_create(&host);if(vm&&cbmvm_load_prg(vm,prg,total)!=CBMVM_OK){fprintf(stderr,"load: %s\n",cbmvm_last_error(vm));cbmvm_destroy(vm);vm=NULL;}free(prg);return vm;
}
static int run_done(CBMVM*vm){int rc;unsigned int guard=0;do{rc=cbmvm_run(vm,64);if(++guard>10000)return -99;}while(rc==CBMVM_YIELDED||rc==CBMVM_OK);return rc;}
int main(void)
{
    H h;CBMVM*vm;uint8_t v;int rc;
    static const uint8_t simple[]={0xa9,0x2a,0x8d,0x00,0xc0,0x60};
    static const uint8_t raster[]={0xa9,0x02,0xcd,0x12,0xd0,0xd0,0xfb,0xa9,0x55,0x8d,0x01,0xc0,0x60};
    static const uint8_t banking[]={0xa9,0x34,0x85,0x01,0xa9,0x02,0x8d,0x20,0xd0,0xa9,0x35,0x85,0x01,0xa9,0x05,0x8d,0x20,0xd0,0x60};
    static const uint8_t undocumented[]={0xa9,0xff,0x4b,0x0f,0x8d,0x02,0xc0,0x60};
    memset(&h,0,sizeof(h));vm=make_vm(&h,simple,sizeof(simple));if(!vm)return 1;rc=run_done(vm);cbmvm_peek(vm,0xc000,&v);if(rc!=CBMVM_HALTED||v!=0x2a){fprintf(stderr,"simple SYS rc=%d v=%u err=%s\n",rc,v,cbmvm_last_error(vm));return 2;}cbmvm_destroy(vm);
    memset(&h,0,sizeof(h));vm=make_vm(&h,raster,sizeof(raster));if(!vm)return 3;rc=run_done(vm);cbmvm_peek(vm,0xc001,&v);if(rc!=CBMVM_HALTED||v!=0x55){fprintf(stderr,"raster SYS rc=%d v=%u line=%u err=%s\n",rc,v,vm->cpu.raster_line,cbmvm_last_error(vm));return 4;}cbmvm_destroy(vm);
    memset(&h,0,sizeof(h));vm=make_vm(&h,banking,sizeof(banking));if(!vm)return 5;rc=run_done(vm);if(rc!=CBMVM_HALTED||h.last_border!=5||h.border_writes!=1){fprintf(stderr,"banking rc=%d writes=%d border=%d err=%s\n",rc,h.border_writes,h.last_border,cbmvm_last_error(vm));return 6;}cbmvm_destroy(vm);
    memset(&h,0,sizeof(h));vm=make_vm(&h,undocumented,sizeof(undocumented));if(!vm)return 7;rc=run_done(vm);cbmvm_peek(vm,0xc002,&v);if(rc!=CBMVM_HALTED||v!=7){fprintf(stderr,"undocumented ALR rc=%d v=%u err=%s\n",rc,v,cbmvm_last_error(vm));return 8;}cbmvm_destroy(vm);
    puts("PASS sys-6502-6510-raster-banking-undocumented");return 0;
}
