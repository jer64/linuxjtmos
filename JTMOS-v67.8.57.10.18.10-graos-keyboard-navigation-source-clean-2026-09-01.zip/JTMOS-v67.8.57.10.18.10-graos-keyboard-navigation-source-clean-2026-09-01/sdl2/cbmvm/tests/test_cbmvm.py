#!/usr/bin/env python3
import subprocess, sys

def run(name):
    p=subprocess.run(['./cbmvm','examples/'+name], text=True, capture_output=True)
    return p.returncode, p.stdout.replace('\r',''), p.stderr

tests={
 'hello.prg': 'HELLO WORLD\n',
 'counting.prg': '0\n1\n2\n3\n4\n5\n',
 'fornext.prg': '1\n2\n3\n',
 'gosub.prg': 'SUB\nDONE\n',
 'peekpoke.prg': '42\n',
 'printdemo2.prg': 'hello world again\n',
 'math.prg': '14\n',
 'forstep.prg': '5\n3\n1\n',
}
failed=0
for name, expected in tests.items():
    rc,out,err=run(name)
    if rc != 0 or out != expected:
        failed += 1
        print('FAIL',name,'rc=',rc)
        print(' expected:',repr(expected))
        print(' got     :',repr(out))
        print(' stderr  :',err)
    else:
        print('PASS',name)
if failed:
    sys.exit(1)
print('all tests passed')
