#ifndef CBMVM_PETSCII_H
#define CBMVM_PETSCII_H

#include <stdint.h>

/*
 * Produce an 8x8 bitmap for a PETSCII byte. This is a compact, clean-room
 * CBM-compatible fallback renderer, not a copy of Commodore character ROM.
 * A host may later replace it with a ROM-exact font asset if desired.
 */
void cbmvm_petscii_glyph(uint8_t petscii, uint8_t rows[8]);

#endif
