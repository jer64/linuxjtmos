#ifndef CBMVM_SDL2_H
#define CBMVM_SDL2_H

#ifndef JTMOS
#include <stdint.h>
#include "cbmvm_host.h"

struct CBMVM;

typedef struct CBMVM_SDL2_CONTEXT CBMVM_SDL2_CONTEXT;

CBMVM_SDL2_CONTEXT *cbmvm_sdl2_create(CBMVM_HOST *host_out, const char *title, int scale);
void cbmvm_sdl2_destroy(CBMVM_SDL2_CONTEXT *ctx);
uint64_t cbmvm_sdl2_monotonic_us(void);
int cbmvm_sdl2_quit_requested(const CBMVM_SDL2_CONTEXT *ctx);
void cbmvm_sdl2_present(CBMVM_SDL2_CONTEXT *ctx);
int cbmvm_sdl2_run_program(int argc, char **argv);
#endif

#endif
