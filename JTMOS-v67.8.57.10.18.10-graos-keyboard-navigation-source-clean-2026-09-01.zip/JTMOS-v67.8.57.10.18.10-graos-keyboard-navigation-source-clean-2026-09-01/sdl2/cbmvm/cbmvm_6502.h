#ifndef CBMVM_6502_H
#define CBMVM_6502_H

#include <stdint.h>
struct CBMVM;

typedef struct {
    uint16_t pc;
    uint8_t a, x, y, sp, p;
    uint8_t active;
    uint8_t stopped;
    uint8_t sys_sentinel_sp;
    uint8_t key_code;
    uint8_t key_ttl;
    uint16_t raster_line;
    uint16_t raster_cycle;
    uint64_t cycles;
    uint8_t vic[0x40];
    uint8_t sid[0x20];
    uint8_t cia1[0x10];
    uint8_t cia2[0x10];
    uint8_t color_ram[0x400];
    uint16_t cia1_ta, cia1_tb, cia1_ta_latch, cia1_tb_latch;
    uint16_t cia2_ta, cia2_tb, cia2_ta_latch, cia2_tb_latch;
    uint8_t cia1_icr_mask, cia1_icr_flags, cia2_icr_mask, cia2_icr_flags;
    uint8_t nmi_pending;
} CBMVM_M6502;

void cbmvm_6502_reset(struct CBMVM *vm);
int cbmvm_6502_sys(struct CBMVM *vm, uint16_t address);
int cbmvm_6502_run(struct CBMVM *vm, unsigned int instruction_budget);
int cbmvm_6502_active(const struct CBMVM *vm);

#endif
