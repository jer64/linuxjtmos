/*
 * cbmvm_6502.c - compact MOS 6502/6510 execution core for CBMVM SYS.
 * Clean-room implementation for CBMVM.  It implements the documented NMOS
 * 6502 instruction set, 6510 $0000/$0001 memory banking, a small VIC-II/CIA
 * timing model, and KERNAL traps useful to BASIC-launched machine code.
 */
#include <stdio.h>
#include <string.h>
#include "cbmvm_engine.h"
#include "cbmvm_6502.h"

#define F_C 0x01u
#define F_Z 0x02u
#define F_I 0x04u
#define F_D 0x08u
#define F_B 0x10u
#define F_U 0x20u
#define F_V 0x40u
#define F_N 0x80u

#define VIC_BASE 0xd000u
#define SID_BASE 0xd400u
#define COL_BASE 0xd800u
#define CIA1_BASE 0xdc00u
#define CIA2_BASE 0xdd00u

static void set_nz(CBMVM_M6502 *c, uint8_t v)
{
    c->p=(uint8_t)((c->p & ~(F_N|F_Z)) | (v==0?F_Z:0) | (v&F_N));
}

static int io_visible(const CBMVM *vm)
{
    uint8_t port=vm->ram[1];
    return (port & 0x04u) && (port & 0x03u);
}
static int kernal_visible(const CBMVM *vm){ return (vm->ram[1] & 0x02u)!=0; }

static int key_matrix(int ch, int *col, int *row)
{
    /* CIA keyboard matrix: column selected on port A, row read from port B. */
    static const struct { int ch,col,row; } k[] = {
        {'1',7,0},{'3',1,0},{'5',2,0},{'7',3,0},{'9',4,0},{'+',5,0},{'-',5,3},{'=',6,5},
        {'2',7,3},{'4',1,3},{'6',2,3},{'8',3,3},{'0',4,3},
        {'Q',7,6},{'W',1,1},{'E',1,6},{'R',2,1},{'T',2,6},{'Y',3,1},{'U',3,6},{'I',4,1},{'O',4,6},{'P',5,1},
        {'A',1,2},{'S',1,5},{'D',2,2},{'F',2,5},{'G',3,2},{'H',3,5},{'J',4,2},{'K',4,5},{'L',5,2},
        {'Z',1,4},{'X',2,7},{'C',2,4},{'V',3,7},{'B',3,4},{'N',4,7},{'M',4,4},
        {' ',7,4},{13,0,1},{8,0,0},{27,7,7},{',',5,7},{'.',5,4},{'/',6,7},{';',6,2},{':',5,5}
    };
    unsigned int i; int u=ch;
    if(u>='a'&&u<='z')u-=32;
    for(i=0;i<sizeof(k)/sizeof(k[0]);i++) if(k[i].ch==u){*col=k[i].col;*row=k[i].row;return 1;}
    return 0;
}

static uint8_t cia_read(CBMVM *vm,int which,uint8_t r)
{
    CBMVM_M6502*c=&vm->cpu;uint8_t *cia=which==1?c->cia1:c->cia2;uint16_t ta=which==1?c->cia1_ta:c->cia2_ta,tb=which==1?c->cia1_tb:c->cia2_tb;uint8_t *flags=which==1?&c->cia1_icr_flags:&c->cia2_icr_flags,*mask=which==1?&c->cia1_icr_mask:&c->cia2_icr_mask;
    r&=15u;
    if(which==1 && r==0)return cia[0];
    if(which==1 && r==1){uint8_t v=0xffu;int col,row;if(c->key_ttl&&key_matrix(c->key_code,&col,&row)){uint8_t pa=cia[0];if((pa&(1u<<col))==0)v=(uint8_t)(v&~(1u<<row));}return v;}
    if(r==4)return(uint8_t)ta;
    if(r==5)return(uint8_t)(ta>>8);
    if(r==6)return(uint8_t)tb;
    if(r==7)return(uint8_t)(tb>>8);
    if(r==13){uint8_t v=(uint8_t)(*flags|((*flags&*mask)?0x80u:0));*flags=0;return v;}
    return cia[r];
}

static void cia_write(CBMVM *vm,int which,uint8_t r,uint8_t v)
{
    CBMVM_M6502*c=&vm->cpu;uint8_t *cia=which==1?c->cia1:c->cia2;uint16_t *ta=which==1?&c->cia1_ta:&c->cia2_ta,*tb=which==1?&c->cia1_tb:&c->cia2_tb,*la=which==1?&c->cia1_ta_latch:&c->cia2_ta_latch,*lb=which==1?&c->cia1_tb_latch:&c->cia2_tb_latch;uint8_t *mask=which==1?&c->cia1_icr_mask:&c->cia2_icr_mask;
    r&=15u;
    if(r==4){*la=(uint16_t)((*la&0xff00u)|v);return;}if(r==5){*la=(uint16_t)((*la&0x00ffu)|((uint16_t)v<<8));if(!(cia[14]&1u))*ta=*la;return;}
    if(r==6){*lb=(uint16_t)((*lb&0xff00u)|v);return;}if(r==7){*lb=(uint16_t)((*lb&0x00ffu)|((uint16_t)v<<8));if(!(cia[15]&1u))*tb=*lb;return;}
    if(r==13){if(v&0x80u)*mask|=(uint8_t)(v&0x1fu);else *mask&=(uint8_t)~(v&0x1fu);return;}
    if(r==14){cia[14]=(uint8_t)(v&0xefu);if(v&0x10u)*ta=*la;return;}
    if(r==15){cia[15]=(uint8_t)(v&0xefu);if(v&0x10u)*tb=*lb;return;}
    cia[r]=v;
}

static uint8_t mread(CBMVM *vm, uint16_t a)
{
    CBMVM_M6502 *c=&vm->cpu;
    if(a==0 || a==1) return vm->ram[a];
    if(a>=0xd000u && a<=0xdfffu && io_visible(vm)) {
        if(a<0xd400u){
            uint8_t r=(uint8_t)((a-VIC_BASE)&0x3fu);
            if(r==0x11){ uint8_t v=c->vic[r]; if(c->raster_line&0x100u)v|=0x80u;else v&=0x7fu;return v; }
            if(r==0x12)return (uint8_t)c->raster_line;
            return c->vic[r];
        }
        if(a<0xd800u)return c->sid[(a-SID_BASE)&0x1fu];
        if(a<0xdc00u)return (uint8_t)(0xf0u | (c->color_ram[(a-COL_BASE)&0x3ffu]&0x0fu));
        if(a<0xdd00u)return cia_read(vm,1,(uint8_t)(a&15u));
        return cia_read(vm,2,(uint8_t)(a&15u));
    }
    return vm->ram[a];
}

static void mwrite(CBMVM *vm, uint16_t a, uint8_t v)
{
    CBMVM_M6502 *c=&vm->cpu;
    if(a==0 || a==1){vm->ram[a]=v;return;}
    if(a>=0xd000u && a<=0xdfffu && io_visible(vm)) {
        if(a<0xd400u){
            uint8_t r=(uint8_t)((a-VIC_BASE)&0x3fu);
            if(r==0x19){ c->vic[0x19]=(uint8_t)(c->vic[0x19] & ~(v&0x0fu)); return; }
            c->vic[r]=v;
            if((a==0xd020u||a==0xd021u) && vm->host.io_write) vm->host.io_write(vm->host.userdata,a,v);
            return;
        }
        if(a<0xd800u){c->sid[(a-SID_BASE)&0x1fu]=v;return;}
        if(a<0xdc00u){c->color_ram[(a-COL_BASE)&0x3ffu]=(uint8_t)(v&15u);if(vm->host.io_write)vm->host.io_write(vm->host.userdata,a,v);return;}
        if(a<0xdd00u){cia_write(vm,1,(uint8_t)(a&15u),v);return;}
        cia_write(vm,2,(uint8_t)(a&15u),v);return;
    }
    vm->ram[a]=v;
    if(a>=0x0400u && a<=0x07e7u && vm->host.io_write) vm->host.io_write(vm->host.userdata,a,v);
}

static uint16_t rw(CBMVM *vm,uint16_t a){uint8_t l=mread(vm,a),h=mread(vm,(uint16_t)(a+1));return(uint16_t)(l|((uint16_t)h<<8));}
static uint16_t rw_zp(CBMVM *vm,uint8_t a){uint8_t l=mread(vm,a),h=mread(vm,(uint8_t)(a+1));return(uint16_t)(l|((uint16_t)h<<8));}
static uint8_t fetch(CBMVM *vm){return mread(vm,vm->cpu.pc++);}
static uint16_t fetchw(CBMVM *vm){uint8_t l=fetch(vm),h=fetch(vm);return(uint16_t)(l|((uint16_t)h<<8));}
static void push(CBMVM *vm,uint8_t v){mwrite(vm,(uint16_t)(0x100u|vm->cpu.sp),v);vm->cpu.sp--;}
static uint8_t pull(CBMVM *vm){vm->cpu.sp++;return mread(vm,(uint16_t)(0x100u|vm->cpu.sp));}
static void pushw(CBMVM *vm,uint16_t v){push(vm,(uint8_t)(v>>8));push(vm,(uint8_t)v);}
static uint16_t pullw(CBMVM *vm){uint8_t l=pull(vm),h=pull(vm);return(uint16_t)(l|((uint16_t)h<<8));}

static uint16_t azp(CBMVM *vm){return fetch(vm);}
static uint16_t azpx(CBMVM *vm){return(uint8_t)(fetch(vm)+vm->cpu.x);}
static uint16_t azpy(CBMVM *vm){return(uint8_t)(fetch(vm)+vm->cpu.y);}
static uint16_t aabs(CBMVM *vm){return fetchw(vm);}
static uint16_t aabsx(CBMVM *vm){return(uint16_t)(fetchw(vm)+vm->cpu.x);}
static uint16_t aabsy(CBMVM *vm){return(uint16_t)(fetchw(vm)+vm->cpu.y);}
static uint16_t aix(CBMVM *vm){uint8_t z=(uint8_t)(fetch(vm)+vm->cpu.x);return rw_zp(vm,z);}
static uint16_t aiy(CBMVM *vm){uint8_t z=fetch(vm);return(uint16_t)(rw_zp(vm,z)+vm->cpu.y);}

static void op_cmp(CBMVM_M6502*c,uint8_t r,uint8_t v){uint16_t t=(uint16_t)r-(uint16_t)v;c->p=(uint8_t)((c->p&~(F_C|F_N|F_Z))|(r>=v?F_C:0)|(((uint8_t)t)==0?F_Z:0)|((uint8_t)t&F_N));}
static void op_adc(CBMVM_M6502*c,uint8_t v)
{
    unsigned int carry=(c->p&F_C)?1u:0u;
    unsigned int bin=(unsigned int)c->a+(unsigned int)v+carry;
    uint8_t br=(uint8_t)bin;
    uint8_t ov=(uint8_t)((~(c->a^v)&(c->a^br)&0x80u)?F_V:0);
    if(c->p&F_D){
        unsigned int lo=(c->a&15u)+(v&15u)+carry, hi=(c->a>>4)+(v>>4);
        if(lo>9){lo+=6;hi++;} if(hi>9)hi+=6;
        c->a=(uint8_t)((hi<<4)|(lo&15u));
        c->p=(uint8_t)((c->p&~(F_C|F_V|F_N|F_Z))|((hi>15)?F_C:0)|ov|(br==0?F_Z:0)|(br&F_N));
    }else{c->a=br;c->p=(uint8_t)((c->p&~(F_C|F_V|F_N|F_Z))|(bin>255?F_C:0)|ov|(br==0?F_Z:0)|(br&F_N));}
}
static void op_sbc(CBMVM_M6502*c,uint8_t v)
{
    unsigned int borrow=(c->p&F_C)?0u:1u; int diff=(int)c->a-(int)v-(int)borrow; uint8_t br=(uint8_t)diff;
    uint8_t ov=(uint8_t)(((c->a^br)&(c->a^v)&0x80u)?F_V:0);
    if(c->p&F_D){int al=(c->a&15)-(v&15)-(int)borrow, ah=(c->a>>4)-(v>>4);if(al<0){al-=6;ah--;}if(ah<0)ah-=6;c->a=(uint8_t)(((ah<<4)&0xf0)|(al&15));}
    else c->a=br;
    c->p=(uint8_t)((c->p&~(F_C|F_V|F_N|F_Z))|(diff>=0?F_C:0)|ov|(br==0?F_Z:0)|(br&F_N));
}

static uint8_t asl(CBMVM_M6502*c,uint8_t v){c->p=(uint8_t)((c->p&~F_C)|((v&0x80)?F_C:0));v<<=1;set_nz(c,v);return v;}
static uint8_t lsr(CBMVM_M6502*c,uint8_t v){c->p=(uint8_t)((c->p&~F_C)|((v&1)?F_C:0));v>>=1;set_nz(c,v);return v;}
static uint8_t rol(CBMVM_M6502*c,uint8_t v){uint8_t ci=(c->p&F_C)?1:0;c->p=(uint8_t)((c->p&~F_C)|((v&0x80)?F_C:0));v=(uint8_t)((v<<1)|ci);set_nz(c,v);return v;}
static uint8_t ror(CBMVM_M6502*c,uint8_t v){uint8_t ci=(c->p&F_C)?0x80:0;c->p=(uint8_t)((c->p&~F_C)|((v&1)?F_C:0));v=(uint8_t)((v>>1)|ci);set_nz(c,v);return v;}

static int branch(CBMVM *vm,int cond){int8_t d=(int8_t)fetch(vm);if(cond){vm->cpu.pc=(uint16_t)(vm->cpu.pc+d);return 3;}return 2;}

static void poll_key(CBMVM *vm)
{
    CBMVM_M6502*c=&vm->cpu; int ch;
    if(c->key_ttl)return;
    if(vm->host.getc && (ch=vm->host.getc(vm->host.userdata))>=0){c->key_code=(uint8_t)(ch&255);c->key_ttl=3;}
}

static void cia_timer_run(uint16_t *counter,uint16_t latch,uint8_t *cr,uint8_t *flags,uint8_t bit,unsigned int cycles)
{
    unsigned int left=cycles;
    if(!(*cr&1u))return;
    while(left){unsigned int cur=(unsigned int)(*counter);if(left<=cur){*counter=(uint16_t)(cur-left);break;}left-=cur+1u;*flags|=bit;*counter=latch;if(*cr&0x08u){*cr&=(uint8_t)~1u;break;}}
}
static void cia_tick(CBMVM *vm,unsigned int cycles)
{
    CBMVM_M6502*c=&vm->cpu;
    cia_timer_run(&c->cia1_ta,c->cia1_ta_latch,&c->cia1[14],&c->cia1_icr_flags,1u,cycles);
    if((c->cia1[15]&0x60u)==0)cia_timer_run(&c->cia1_tb,c->cia1_tb_latch,&c->cia1[15],&c->cia1_icr_flags,2u,cycles);
    cia_timer_run(&c->cia2_ta,c->cia2_ta_latch,&c->cia2[14],&c->cia2_icr_flags,1u,cycles);
    if((c->cia2[15]&0x60u)==0)cia_timer_run(&c->cia2_tb,c->cia2_tb_latch,&c->cia2[15],&c->cia2_icr_flags,2u,cycles);
    if(c->cia2_icr_flags&c->cia2_icr_mask)c->nmi_pending=1;
}

static void tick(CBMVM *vm,unsigned int cycles)
{
    CBMVM_M6502*c=&vm->cpu; unsigned int line_cycles=(vm->video_hz==60)?65u:63u,lines=(vm->video_hz==60)?262u:312u;
    c->cycles+=cycles;cia_tick(vm,cycles);c->raster_cycle=(uint16_t)(c->raster_cycle+cycles);
    while(c->raster_cycle>=line_cycles){
        c->raster_cycle=(uint16_t)(c->raster_cycle-line_cycles);c->raster_line++;
        if(c->raster_line>=lines){c->raster_line=0;if(c->key_ttl)c->key_ttl--;poll_key(vm);cbmvm_graphic_tick(vm,1);if(vm->host.machine_present)vm->host.machine_present(vm->host.userdata,vm->ram,vm->ram_size,c->color_ram,c->vic,c->cia2[0]);}
        {
            unsigned int target=(unsigned int)c->vic[0x12] | ((c->vic[0x11]&0x80u)?0x100u:0u);
            if(c->raster_line==target){c->vic[0x19]|=1u;}
        }
    }
}

static void enter_irq(CBMVM *vm)
{
    CBMVM_M6502*c=&vm->cpu; uint16_t v;
    pushw(vm,c->pc);push(vm,(uint8_t)((c->p&~F_B)|F_U));c->p|=F_I;
    v=kernal_visible(vm)?rw(vm,0x0314u):rw(vm,0xfffeu);if(v)c->pc=v;
}

static void enter_nmi(CBMVM *vm)
{
    CBMVM_M6502*c=&vm->cpu;uint16_t v;pushw(vm,c->pc);push(vm,(uint8_t)((c->p&~F_B)|F_U));c->p|=F_I;v=kernal_visible(vm)?rw(vm,0x0318u):rw(vm,0xfffau);if(v)c->pc=v;c->nmi_pending=0;
}

static int kernal_trap(CBMVM *vm)
{
    CBMVM_M6502*c=&vm->cpu; int ch;
    if(!kernal_visible(vm))return 0;
    switch(c->pc){
        case 0xffd2u: if(vm->host.putc)vm->host.putc(vm->host.userdata,c->a); c->pc=(uint16_t)(pullw(vm)+1u); return 1; /* CHROUT */
        case 0xffe4u: ch=vm->host.getc?vm->host.getc(vm->host.userdata):-1;c->a=(uint8_t)(ch<0?0:ch);set_nz(c,c->a);c->pc=(uint16_t)(pullw(vm)+1u);return 1; /* GETIN */
        case 0xffe1u: ch=vm->host.getc?vm->host.getc(vm->host.userdata):-1;c->p=(uint8_t)((c->p&~F_Z)|((ch==3||ch==27)?0:F_Z));c->pc=(uint16_t)(pullw(vm)+1u);return 1; /* STOP */
        case 0xff9fu: poll_key(vm);c->pc=(uint16_t)(pullw(vm)+1u);return 1; /* SCNKEY */
        case 0xffedu: c->x=40;c->y=25;c->pc=(uint16_t)(pullw(vm)+1u);return 1; /* SCREEN */
        default:return 0;
    }
}

static int step(CBMVM *vm)
{
    CBMVM_M6502*c=&vm->cpu; uint8_t op,v;uint16_t a;int cyc=2;
    if(kernal_trap(vm)){tick(vm,6);return 0;}
    if(c->nmi_pending){
        if(kernal_visible(vm) && rw(vm,0x0318u)==0xfe47u){c->cia2_icr_flags=0;c->nmi_pending=0;tick(vm,7);return 0;}
        enter_nmi(vm);tick(vm,7);return 0;
    }
    if((((c->vic[0x19]&c->vic[0x1a]&1u)!=0)||((c->cia1_icr_flags&c->cia1_icr_mask)!=0)) && !(c->p&F_I)){
        if(kernal_visible(vm) && rw(vm,0x0314u)==0xea31u && !(c->vic[0x19]&c->vic[0x1a]&1u)){c->cia1_icr_flags=0;poll_key(vm);tick(vm,7);return 0;}
        enter_irq(vm);tick(vm,7);return 0;
    }
    op=fetch(vm);
#define LDREG(r,val) do{c->r=(uint8_t)(val);set_nz(c,c->r);}while(0)
#define ST(addr,val) mwrite(vm,(addr),(uint8_t)(val))
#define RMW(addr,fn) do{a=(addr);v=mread(vm,a);v=fn(c,v);mwrite(vm,a,v);}while(0)
    switch(op){
        case 0x00: pushw(vm,(uint16_t)(c->pc+1));push(vm,(uint8_t)(c->p|F_B|F_U));c->p|=F_I;c->pc=rw(vm,0xfffe);cyc=7;break;
        /* NMOS 6502/6510 undocumented opcodes commonly used by C64 software. */
        case 0x0b: case 0x2b: c->a&=fetch(vm);set_nz(c,c->a);c->p=(uint8_t)((c->p&~F_C)|((c->a&0x80u)?F_C:0));cyc=2;break; /* ANC */
        case 0x4b: c->a&=fetch(vm);c->a=lsr(c,c->a);cyc=2;break; /* ALR/ASR */
        case 0x6b: { uint8_t oldc=(c->p&F_C)?0x80u:0;c->a&=fetch(vm);c->a=(uint8_t)((c->a>>1)|oldc);set_nz(c,c->a);c->p=(uint8_t)((c->p&~(F_C|F_V))|((c->a&0x40u)?F_C:0)|((((c->a>>6)^(c->a>>5))&1u)?F_V:0));cyc=2;break; } /* ARR */
        case 0x8b: c->a=(uint8_t)(c->x&fetch(vm));set_nz(c,c->a);cyc=2;break; /* XAA */
        case 0xcb: { uint8_t q=fetch(vm),ax=(uint8_t)(c->a&c->x);uint16_t t=(uint16_t)ax-(uint16_t)q;c->x=(uint8_t)t;c->p=(uint8_t)((c->p&~F_C)|(ax>=q?F_C:0));set_nz(c,c->x);cyc=2;break; } /* AXS/SBX */
        /* Two-byte/three-byte NOP families. */
        case 0x80: case 0x82: case 0x89: case 0xc2: case 0xe2: (void)fetch(vm);cyc=2;break;
        case 0x04: case 0x44: case 0x64: (void)azp(vm);cyc=3;break;
        case 0x14: case 0x34: case 0x54: case 0x74: case 0xd4: case 0xf4: (void)azpx(vm);cyc=4;break;
        case 0x0c: (void)aabs(vm);cyc=4;break;
        case 0x1c: case 0x3c: case 0x5c: case 0x7c: case 0xdc: case 0xfc: (void)aabsx(vm);cyc=4;break;
        case 0x1a: case 0x3a: case 0x5a: case 0x7a: case 0xda: case 0xfa: cyc=2;break;
        /* LAX */
        case 0xa3: v=mread(vm,aix(vm));c->a=c->x=v;set_nz(c,v);cyc=6;break;
        case 0xa7: v=mread(vm,azp(vm));c->a=c->x=v;set_nz(c,v);cyc=3;break;
        case 0xaf: v=mread(vm,aabs(vm));c->a=c->x=v;set_nz(c,v);cyc=4;break;
        case 0xb3: v=mread(vm,aiy(vm));c->a=c->x=v;set_nz(c,v);cyc=5;break;
        case 0xb7: v=mread(vm,azpy(vm));c->a=c->x=v;set_nz(c,v);cyc=4;break;
        case 0xbf: v=mread(vm,aabsy(vm));c->a=c->x=v;set_nz(c,v);cyc=4;break;
        /* SAX */
        case 0x83: ST(aix(vm),(uint8_t)(c->a&c->x));cyc=6;break;
        case 0x87: ST(azp(vm),(uint8_t)(c->a&c->x));cyc=3;break;
        case 0x8f: ST(aabs(vm),(uint8_t)(c->a&c->x));cyc=4;break;
        case 0x97: ST(azpy(vm),(uint8_t)(c->a&c->x));cyc=4;break;
        /* SLO = ASL + ORA */
        case 0x03: a=aix(vm);v=asl(c,mread(vm,a));mwrite(vm,a,v);c->a|=v;set_nz(c,c->a);cyc=8;break;
        case 0x07: a=azp(vm);v=asl(c,mread(vm,a));mwrite(vm,a,v);c->a|=v;set_nz(c,c->a);cyc=5;break;
        case 0x0f: a=aabs(vm);v=asl(c,mread(vm,a));mwrite(vm,a,v);c->a|=v;set_nz(c,c->a);cyc=6;break;
        case 0x13: a=aiy(vm);v=asl(c,mread(vm,a));mwrite(vm,a,v);c->a|=v;set_nz(c,c->a);cyc=8;break;
        case 0x17: a=azpx(vm);v=asl(c,mread(vm,a));mwrite(vm,a,v);c->a|=v;set_nz(c,c->a);cyc=6;break;
        case 0x1b: a=aabsy(vm);v=asl(c,mread(vm,a));mwrite(vm,a,v);c->a|=v;set_nz(c,c->a);cyc=7;break;
        case 0x1f: a=aabsx(vm);v=asl(c,mread(vm,a));mwrite(vm,a,v);c->a|=v;set_nz(c,c->a);cyc=7;break;
        /* RLA = ROL + AND */
        case 0x23: a=aix(vm);v=rol(c,mread(vm,a));mwrite(vm,a,v);c->a&=v;set_nz(c,c->a);cyc=8;break;
        case 0x27: a=azp(vm);v=rol(c,mread(vm,a));mwrite(vm,a,v);c->a&=v;set_nz(c,c->a);cyc=5;break;
        case 0x2f: a=aabs(vm);v=rol(c,mread(vm,a));mwrite(vm,a,v);c->a&=v;set_nz(c,c->a);cyc=6;break;
        case 0x33: a=aiy(vm);v=rol(c,mread(vm,a));mwrite(vm,a,v);c->a&=v;set_nz(c,c->a);cyc=8;break;
        case 0x37: a=azpx(vm);v=rol(c,mread(vm,a));mwrite(vm,a,v);c->a&=v;set_nz(c,c->a);cyc=6;break;
        case 0x3b: a=aabsy(vm);v=rol(c,mread(vm,a));mwrite(vm,a,v);c->a&=v;set_nz(c,c->a);cyc=7;break;
        case 0x3f: a=aabsx(vm);v=rol(c,mread(vm,a));mwrite(vm,a,v);c->a&=v;set_nz(c,c->a);cyc=7;break;
        /* SRE = LSR + EOR */
        case 0x43: a=aix(vm);v=lsr(c,mread(vm,a));mwrite(vm,a,v);c->a^=v;set_nz(c,c->a);cyc=8;break;
        case 0x47: a=azp(vm);v=lsr(c,mread(vm,a));mwrite(vm,a,v);c->a^=v;set_nz(c,c->a);cyc=5;break;
        case 0x4f: a=aabs(vm);v=lsr(c,mread(vm,a));mwrite(vm,a,v);c->a^=v;set_nz(c,c->a);cyc=6;break;
        case 0x53: a=aiy(vm);v=lsr(c,mread(vm,a));mwrite(vm,a,v);c->a^=v;set_nz(c,c->a);cyc=8;break;
        case 0x57: a=azpx(vm);v=lsr(c,mread(vm,a));mwrite(vm,a,v);c->a^=v;set_nz(c,c->a);cyc=6;break;
        case 0x5b: a=aabsy(vm);v=lsr(c,mread(vm,a));mwrite(vm,a,v);c->a^=v;set_nz(c,c->a);cyc=7;break;
        case 0x5f: a=aabsx(vm);v=lsr(c,mread(vm,a));mwrite(vm,a,v);c->a^=v;set_nz(c,c->a);cyc=7;break;
        /* RRA = ROR + ADC */
        case 0x63: a=aix(vm);v=ror(c,mread(vm,a));mwrite(vm,a,v);op_adc(c,v);cyc=8;break;
        case 0x67: a=azp(vm);v=ror(c,mread(vm,a));mwrite(vm,a,v);op_adc(c,v);cyc=5;break;
        case 0x6f: a=aabs(vm);v=ror(c,mread(vm,a));mwrite(vm,a,v);op_adc(c,v);cyc=6;break;
        case 0x73: a=aiy(vm);v=ror(c,mread(vm,a));mwrite(vm,a,v);op_adc(c,v);cyc=8;break;
        case 0x77: a=azpx(vm);v=ror(c,mread(vm,a));mwrite(vm,a,v);op_adc(c,v);cyc=6;break;
        case 0x7b: a=aabsy(vm);v=ror(c,mread(vm,a));mwrite(vm,a,v);op_adc(c,v);cyc=7;break;
        case 0x7f: a=aabsx(vm);v=ror(c,mread(vm,a));mwrite(vm,a,v);op_adc(c,v);cyc=7;break;
        /* DCP = DEC + CMP */
        case 0xc3: a=aix(vm);v=(uint8_t)(mread(vm,a)-1);mwrite(vm,a,v);op_cmp(c,c->a,v);cyc=8;break;
        case 0xc7: a=azp(vm);v=(uint8_t)(mread(vm,a)-1);mwrite(vm,a,v);op_cmp(c,c->a,v);cyc=5;break;
        case 0xcf: a=aabs(vm);v=(uint8_t)(mread(vm,a)-1);mwrite(vm,a,v);op_cmp(c,c->a,v);cyc=6;break;
        case 0xd3: a=aiy(vm);v=(uint8_t)(mread(vm,a)-1);mwrite(vm,a,v);op_cmp(c,c->a,v);cyc=8;break;
        case 0xd7: a=azpx(vm);v=(uint8_t)(mread(vm,a)-1);mwrite(vm,a,v);op_cmp(c,c->a,v);cyc=6;break;
        case 0xdb: a=aabsy(vm);v=(uint8_t)(mread(vm,a)-1);mwrite(vm,a,v);op_cmp(c,c->a,v);cyc=7;break;
        case 0xdf: a=aabsx(vm);v=(uint8_t)(mread(vm,a)-1);mwrite(vm,a,v);op_cmp(c,c->a,v);cyc=7;break;
        /* ISC/ISB = INC + SBC */
        case 0xe3: a=aix(vm);v=(uint8_t)(mread(vm,a)+1);mwrite(vm,a,v);op_sbc(c,v);cyc=8;break;
        case 0xe7: a=azp(vm);v=(uint8_t)(mread(vm,a)+1);mwrite(vm,a,v);op_sbc(c,v);cyc=5;break;
        case 0xef: a=aabs(vm);v=(uint8_t)(mread(vm,a)+1);mwrite(vm,a,v);op_sbc(c,v);cyc=6;break;
        case 0xf3: a=aiy(vm);v=(uint8_t)(mread(vm,a)+1);mwrite(vm,a,v);op_sbc(c,v);cyc=8;break;
        case 0xf7: a=azpx(vm);v=(uint8_t)(mread(vm,a)+1);mwrite(vm,a,v);op_sbc(c,v);cyc=6;break;
        case 0xfb: a=aabsy(vm);v=(uint8_t)(mread(vm,a)+1);mwrite(vm,a,v);op_sbc(c,v);cyc=7;break;
        case 0xff: a=aabsx(vm);v=(uint8_t)(mread(vm,a)+1);mwrite(vm,a,v);op_sbc(c,v);cyc=7;break;
        case 0xbb: v=(uint8_t)(mread(vm,aabsy(vm))&c->sp);c->a=c->x=c->sp=v;set_nz(c,v);cyc=4;break; /* LAS */
        case 0x9b: {uint16_t base=fetchw(vm);a=(uint16_t)(base+c->y);c->sp=(uint8_t)(c->a&c->x);mwrite(vm,a,(uint8_t)(c->sp&(((base>>8)+1u)&0xffu)));cyc=5;break;} /* TAS */
        case 0x93: {uint8_t z=fetch(vm);uint16_t base=rw_zp(vm,z);a=(uint16_t)(base+c->y);mwrite(vm,a,(uint8_t)(c->a&c->x&(((base>>8)+1u)&0xffu)));cyc=6;break;} /* AHX (zp),Y */
        case 0x9f: {uint16_t base=fetchw(vm);a=(uint16_t)(base+c->y);mwrite(vm,a,(uint8_t)(c->a&c->x&(((base>>8)+1u)&0xffu)));cyc=5;break;} /* AHX abs,Y */
        case 0x9e: {uint16_t base=fetchw(vm);a=(uint16_t)(base+c->y);mwrite(vm,a,(uint8_t)(c->x&(((base>>8)+1u)&0xffu)));cyc=5;break;} /* SHX */
        case 0x9c: {uint16_t base=fetchw(vm);a=(uint16_t)(base+c->x);mwrite(vm,a,(uint8_t)(c->y&(((base>>8)+1u)&0xffu)));cyc=5;break;} /* SHY */
        case 0x01: c->a|=mread(vm,aix(vm));set_nz(c,c->a);cyc=6;break;
        case 0x05: c->a|=mread(vm,azp(vm));set_nz(c,c->a);cyc=3;break;
        case 0x06: RMW(azp(vm),asl);cyc=5;break;
        case 0x08: push(vm,(uint8_t)(c->p|F_B|F_U));cyc=3;break;
        case 0x09: c->a|=fetch(vm);set_nz(c,c->a);cyc=2;break;
        case 0x0a: c->a=asl(c,c->a);cyc=2;break;
        case 0x0d: c->a|=mread(vm,aabs(vm));set_nz(c,c->a);cyc=4;break;
        case 0x0e: RMW(aabs(vm),asl);cyc=6;break;
        case 0x10: cyc=branch(vm,!(c->p&F_N));break;
        case 0x11: c->a|=mread(vm,aiy(vm));set_nz(c,c->a);cyc=5;break;
        case 0x15: c->a|=mread(vm,azpx(vm));set_nz(c,c->a);cyc=4;break;
        case 0x16: RMW(azpx(vm),asl);cyc=6;break;
        case 0x18: c->p&=(uint8_t)~F_C;break;
        case 0x19: c->a|=mread(vm,aabsy(vm));set_nz(c,c->a);cyc=4;break;
        case 0x1d: c->a|=mread(vm,aabsx(vm));set_nz(c,c->a);cyc=4;break;
        case 0x1e: RMW(aabsx(vm),asl);cyc=7;break;
        case 0x20: a=fetchw(vm);pushw(vm,(uint16_t)(c->pc-1));c->pc=a;cyc=6;break;
        case 0x21: c->a&=mread(vm,aix(vm));set_nz(c,c->a);cyc=6;break;
        case 0x24: v=mread(vm,azp(vm));c->p=(uint8_t)((c->p&~(F_N|F_V|F_Z))|(v&(F_N|F_V))|((c->a&v)?0:F_Z));cyc=3;break;
        case 0x25: c->a&=mread(vm,azp(vm));set_nz(c,c->a);cyc=3;break;
        case 0x26: RMW(azp(vm),rol);cyc=5;break;
        case 0x28: c->p=(uint8_t)((pull(vm)&~F_B)|F_U);cyc=4;break;
        case 0x29: c->a&=fetch(vm);set_nz(c,c->a);break;
        case 0x2a: c->a=rol(c,c->a);break;
        case 0x2c: v=mread(vm,aabs(vm));c->p=(uint8_t)((c->p&~(F_N|F_V|F_Z))|(v&(F_N|F_V))|((c->a&v)?0:F_Z));cyc=4;break;
        case 0x2d: c->a&=mread(vm,aabs(vm));set_nz(c,c->a);cyc=4;break;
        case 0x2e: RMW(aabs(vm),rol);cyc=6;break;
        case 0x30: cyc=branch(vm,c->p&F_N);break;
        case 0x31: c->a&=mread(vm,aiy(vm));set_nz(c,c->a);cyc=5;break;
        case 0x35: c->a&=mread(vm,azpx(vm));set_nz(c,c->a);cyc=4;break;
        case 0x36: RMW(azpx(vm),rol);cyc=6;break;
        case 0x38: c->p|=F_C;break;
        case 0x39: c->a&=mread(vm,aabsy(vm));set_nz(c,c->a);cyc=4;break;
        case 0x3d: c->a&=mread(vm,aabsx(vm));set_nz(c,c->a);cyc=4;break;
        case 0x3e: RMW(aabsx(vm),rol);cyc=7;break;
        case 0x40: c->p=(uint8_t)((pull(vm)&~F_B)|F_U);c->pc=pullw(vm);cyc=6;break;
        case 0x41: c->a^=mread(vm,aix(vm));set_nz(c,c->a);cyc=6;break;
        case 0x45: c->a^=mread(vm,azp(vm));set_nz(c,c->a);cyc=3;break;
        case 0x46: RMW(azp(vm),lsr);cyc=5;break;
        case 0x48: push(vm,c->a);cyc=3;break;
        case 0x49: c->a^=fetch(vm);set_nz(c,c->a);break;
        case 0x4a: c->a=lsr(c,c->a);break;
        case 0x4c: c->pc=fetchw(vm);cyc=3;break;
        case 0x4d: c->a^=mread(vm,aabs(vm));set_nz(c,c->a);cyc=4;break;
        case 0x4e: RMW(aabs(vm),lsr);cyc=6;break;
        case 0x50: cyc=branch(vm,!(c->p&F_V));break;
        case 0x51: c->a^=mread(vm,aiy(vm));set_nz(c,c->a);cyc=5;break;
        case 0x55: c->a^=mread(vm,azpx(vm));set_nz(c,c->a);cyc=4;break;
        case 0x56: RMW(azpx(vm),lsr);cyc=6;break;
        case 0x58: c->p&=(uint8_t)~F_I;break;
        case 0x59: c->a^=mread(vm,aabsy(vm));set_nz(c,c->a);cyc=4;break;
        case 0x5d: c->a^=mread(vm,aabsx(vm));set_nz(c,c->a);cyc=4;break;
        case 0x5e: RMW(aabsx(vm),lsr);cyc=7;break;
        case 0x60:
            if(c->sp==c->sys_sentinel_sp && mread(vm,(uint16_t)(0x101u+c->sp))==0xffu && mread(vm,(uint16_t)(0x102u+c->sp))==0xffu){c->sp=(uint8_t)(c->sp+2);c->active=0;return 1;}
            c->pc=(uint16_t)(pullw(vm)+1u);cyc=6;break;
        case 0x61: op_adc(c,mread(vm,aix(vm)));cyc=6;break;
        case 0x65: op_adc(c,mread(vm,azp(vm)));cyc=3;break;
        case 0x66: RMW(azp(vm),ror);cyc=5;break;
        case 0x68: c->a=pull(vm);set_nz(c,c->a);cyc=4;break;
        case 0x69: op_adc(c,fetch(vm));break;
        case 0x6a: c->a=ror(c,c->a);break;
        case 0x6c: a=fetchw(vm);c->pc=(uint16_t)(mread(vm,a)|((uint16_t)mread(vm,(uint16_t)((a&0xff00u)|((a+1)&0xffu)))<<8));cyc=5;break;
        case 0x6d: op_adc(c,mread(vm,aabs(vm)));cyc=4;break;
        case 0x6e: RMW(aabs(vm),ror);cyc=6;break;
        case 0x70: cyc=branch(vm,c->p&F_V);break;
        case 0x71: op_adc(c,mread(vm,aiy(vm)));cyc=5;break;
        case 0x75: op_adc(c,mread(vm,azpx(vm)));cyc=4;break;
        case 0x76: RMW(azpx(vm),ror);cyc=6;break;
        case 0x78: c->p|=F_I;break;
        case 0x79: op_adc(c,mread(vm,aabsy(vm)));cyc=4;break;
        case 0x7d: op_adc(c,mread(vm,aabsx(vm)));cyc=4;break;
        case 0x7e: RMW(aabsx(vm),ror);cyc=7;break;
        case 0x81: ST(aix(vm),c->a);cyc=6;break;
        case 0x84: ST(azp(vm),c->y);cyc=3;break;
        case 0x85: ST(azp(vm),c->a);cyc=3;break;
        case 0x86: ST(azp(vm),c->x);cyc=3;break;
        case 0x88: c->y--;set_nz(c,c->y);break;
        case 0x8a: c->a=c->x;set_nz(c,c->a);break;
        case 0x8c: ST(aabs(vm),c->y);cyc=4;break;
        case 0x8d: ST(aabs(vm),c->a);cyc=4;break;
        case 0x8e: ST(aabs(vm),c->x);cyc=4;break;
        case 0x90: cyc=branch(vm,!(c->p&F_C));break;
        case 0x91: ST(aiy(vm),c->a);cyc=6;break;
        case 0x94: ST(azpx(vm),c->y);cyc=4;break;
        case 0x95: ST(azpx(vm),c->a);cyc=4;break;
        case 0x96: ST(azpy(vm),c->x);cyc=4;break;
        case 0x98: c->a=c->y;set_nz(c,c->a);break;
        case 0x99: ST(aabsy(vm),c->a);cyc=5;break;
        case 0x9a: c->sp=c->x;break;
        case 0x9d: ST(aabsx(vm),c->a);cyc=5;break;
        case 0xa0: LDREG(y,fetch(vm));break;
        case 0xa1: LDREG(a,mread(vm,aix(vm)));cyc=6;break;
        case 0xa2: LDREG(x,fetch(vm));break;
        case 0xa4: LDREG(y,mread(vm,azp(vm)));cyc=3;break;
        case 0xa5: LDREG(a,mread(vm,azp(vm)));cyc=3;break;
        case 0xa6: LDREG(x,mread(vm,azp(vm)));cyc=3;break;
        case 0xa8: c->y=c->a;set_nz(c,c->y);break;
        case 0xa9: LDREG(a,fetch(vm));break;
        case 0xaa: c->x=c->a;set_nz(c,c->x);break;
        case 0xac: LDREG(y,mread(vm,aabs(vm)));cyc=4;break;
        case 0xad: LDREG(a,mread(vm,aabs(vm)));cyc=4;break;
        case 0xae: LDREG(x,mread(vm,aabs(vm)));cyc=4;break;
        case 0xb0: cyc=branch(vm,c->p&F_C);break;
        case 0xb1: LDREG(a,mread(vm,aiy(vm)));cyc=5;break;
        case 0xb4: LDREG(y,mread(vm,azpx(vm)));cyc=4;break;
        case 0xb5: LDREG(a,mread(vm,azpx(vm)));cyc=4;break;
        case 0xb6: LDREG(x,mread(vm,azpy(vm)));cyc=4;break;
        case 0xb8: c->p&=(uint8_t)~F_V;break;
        case 0xb9: LDREG(a,mread(vm,aabsy(vm)));cyc=4;break;
        case 0xba: c->x=c->sp;set_nz(c,c->x);break;
        case 0xbc: LDREG(y,mread(vm,aabsx(vm)));cyc=4;break;
        case 0xbd: LDREG(a,mread(vm,aabsx(vm)));cyc=4;break;
        case 0xbe: LDREG(x,mread(vm,aabsy(vm)));cyc=4;break;
        case 0xc0: op_cmp(c,c->y,fetch(vm));break;
        case 0xc1: op_cmp(c,c->a,mread(vm,aix(vm)));cyc=6;break;
        case 0xc4: op_cmp(c,c->y,mread(vm,azp(vm)));cyc=3;break;
        case 0xc5: op_cmp(c,c->a,mread(vm,azp(vm)));cyc=3;break;
        case 0xc6: a=azp(vm);v=(uint8_t)(mread(vm,a)-1);mwrite(vm,a,v);set_nz(c,v);cyc=5;break;
        case 0xc8: c->y++;set_nz(c,c->y);break;
        case 0xc9: op_cmp(c,c->a,fetch(vm));break;
        case 0xca: c->x--;set_nz(c,c->x);break;
        case 0xcc: op_cmp(c,c->y,mread(vm,aabs(vm)));cyc=4;break;
        case 0xcd: op_cmp(c,c->a,mread(vm,aabs(vm)));cyc=4;break;
        case 0xce: a=aabs(vm);v=(uint8_t)(mread(vm,a)-1);mwrite(vm,a,v);set_nz(c,v);cyc=6;break;
        case 0xd0: cyc=branch(vm,!(c->p&F_Z));break;
        case 0xd1: op_cmp(c,c->a,mread(vm,aiy(vm)));cyc=5;break;
        case 0xd5: op_cmp(c,c->a,mread(vm,azpx(vm)));cyc=4;break;
        case 0xd6: a=azpx(vm);v=(uint8_t)(mread(vm,a)-1);mwrite(vm,a,v);set_nz(c,v);cyc=6;break;
        case 0xd8: c->p&=(uint8_t)~F_D;break;
        case 0xd9: op_cmp(c,c->a,mread(vm,aabsy(vm)));cyc=4;break;
        case 0xdd: op_cmp(c,c->a,mread(vm,aabsx(vm)));cyc=4;break;
        case 0xde: a=aabsx(vm);v=(uint8_t)(mread(vm,a)-1);mwrite(vm,a,v);set_nz(c,v);cyc=7;break;
        case 0xe0: op_cmp(c,c->x,fetch(vm));break;
        case 0xe1: op_sbc(c,mread(vm,aix(vm)));cyc=6;break;
        case 0xe4: op_cmp(c,c->x,mread(vm,azp(vm)));cyc=3;break;
        case 0xe5: op_sbc(c,mread(vm,azp(vm)));cyc=3;break;
        case 0xe6: a=azp(vm);v=(uint8_t)(mread(vm,a)+1);mwrite(vm,a,v);set_nz(c,v);cyc=5;break;
        case 0xe8: c->x++;set_nz(c,c->x);break;
        case 0xe9: case 0xeb: op_sbc(c,fetch(vm));break;
        case 0xea: break;
        case 0xec: op_cmp(c,c->x,mread(vm,aabs(vm)));cyc=4;break;
        case 0xed: op_sbc(c,mread(vm,aabs(vm)));cyc=4;break;
        case 0xee: a=aabs(vm);v=(uint8_t)(mread(vm,a)+1);mwrite(vm,a,v);set_nz(c,v);cyc=6;break;
        case 0xf0: cyc=branch(vm,c->p&F_Z);break;
        case 0xf1: op_sbc(c,mread(vm,aiy(vm)));cyc=5;break;
        case 0xf5: op_sbc(c,mread(vm,azpx(vm)));cyc=4;break;
        case 0xf6: a=azpx(vm);v=(uint8_t)(mread(vm,a)+1);mwrite(vm,a,v);set_nz(c,v);cyc=6;break;
        case 0xf8: c->p|=F_D;break;
        case 0xf9: op_sbc(c,mread(vm,aabsy(vm)));cyc=4;break;
        case 0xfd: op_sbc(c,mread(vm,aabsx(vm)));cyc=4;break;
        case 0xfe: a=aabsx(vm);v=(uint8_t)(mread(vm,a)+1);mwrite(vm,a,v);set_nz(c,v);cyc=7;break;
        default:
            {
                char msg[96];snprintf(msg,sizeof(msg),"?ILLEGAL 6502 OPCODE $%02X AT $%04X",(unsigned)op,(unsigned)(uint16_t)(c->pc-1));
                strncpy(vm->error_message,msg,sizeof(vm->error_message)-1);vm->error_message[sizeof(vm->error_message)-1]=0;vm->error=1;vm->halted=1;c->active=0;return -1;
            }
    }
#undef LDREG
#undef ST
#undef RMW
    tick(vm,(unsigned int)cyc);return 0;
}

void cbmvm_6502_reset(CBMVM *vm)
{
    CBMVM_M6502*c;if(!vm)return;c=&vm->cpu;memset(c,0,sizeof(*c));c->sp=0xf6;c->p=F_I|F_U;c->raster_line=0;c->vic[0x11]=0x1b;c->vic[0x16]=0xc8;c->vic[0x18]=0x14;c->vic[0x20]=14;c->vic[0x21]=6;c->cia1[0]=0xff;c->cia1[1]=0xff;c->cia1[2]=0xff;c->cia1[3]=0xff;c->cia2[0]=0xff;c->cia2[1]=0xff;c->cia1_ta=c->cia1_tb=c->cia2_ta=c->cia2_tb=0xffffu;c->cia1_ta_latch=c->cia1_tb_latch=c->cia2_ta_latch=c->cia2_tb_latch=0xffffu;memset(c->color_ram,1,sizeof(c->color_ram));
    vm->ram[0]=0x2f;vm->ram[1]=0x37;
}

int cbmvm_6502_sys(CBMVM *vm,uint16_t address)
{
    CBMVM_M6502*c;if(!vm||!vm->ram)return CBMVM_ERR;if(address==0){snprintf(vm->error_message,sizeof(vm->error_message),"?ILLEGAL QUANTITY ERROR (SYS 0)");vm->error=1;vm->halted=1;return CBMVM_ERR;}
    c=&vm->cpu;c->pc=address;c->active=1;c->stopped=0;c->p=(uint8_t)((c->p|F_U)&~F_B);
    /* Synthetic JSR return.  A normal RTS leaves machine mode; programs that TXS/JMP forever simply keep running. */
    push(vm,0xff);push(vm,0xff);c->sys_sentinel_sp=c->sp;
    return CBMVM_OK;
}

int cbmvm_6502_run(CBMVM *vm,unsigned int instruction_budget)
{
    unsigned int i;int rc;if(!vm||!vm->cpu.active)return CBMVM_HALTED;if(!instruction_budget)instruction_budget=1024;
    for(i=0;i<instruction_budget;i++){rc=step(vm);if(rc<0)return CBMVM_ERR;if(!vm->cpu.active)return CBMVM_OK;}
    if(vm->host.yield) vm->host.yield(vm->host.userdata);
    return CBMVM_YIELDED;
}
int cbmvm_6502_active(const CBMVM *vm){return vm&&vm->cpu.active;}
