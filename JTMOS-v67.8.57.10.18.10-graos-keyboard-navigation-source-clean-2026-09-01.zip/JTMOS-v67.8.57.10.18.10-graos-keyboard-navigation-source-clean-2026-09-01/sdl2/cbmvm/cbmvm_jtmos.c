#include <string.h>
#include "cbmvm_jtmos.h"
#include "cbmvm_engine.h"
#include "cbmvm_c128_theme.h"

#define C64_SCREEN_BEGIN 0x0400u
#define C64_SCREEN_END   0x07e7u
#define C64_BORDER       0xd020u
#define C64_BACKGROUND   0xd021u
#define C64_COLOR_BEGIN  0xd800u
#define C64_COLOR_END    0xdbe7u

static void jt_putc(void *p, int ch)
{
    CBMVM_JTMOS_CONTEXT *ctx = (CBMVM_JTMOS_CONTEXT *)p;
    if (ctx->api.console_putc) ctx->api.console_putc(ctx->api.userdata, ch);
}

static int jt_getc(void *p)
{
    CBMVM_JTMOS_CONTEXT *ctx = (CBMVM_JTMOS_CONTEXT *)p;
    return ctx->api.console_getc ? ctx->api.console_getc(ctx->api.userdata) : -1;
}

static void jt_yield(void *p)
{
    CBMVM_JTMOS_CONTEXT *ctx = (CBMVM_JTMOS_CONTEXT *)p;
    if (ctx->api.yield) ctx->api.yield(ctx->api.userdata);
}

static int jt_io_write(void *p, uint16_t address, uint8_t value)
{
    CBMVM_JTMOS_CONTEXT *ctx = (CBMVM_JTMOS_CONTEXT *)p;
    if (address == C64_BORDER) {
        ctx->border = value & 0x0f;
        if (ctx->api.set_border) ctx->api.set_border(ctx->api.userdata, ctx->border);
        return 0;
    }
    if (address == C64_BACKGROUND) {
        ctx->background = value & 0x0f;
        if (ctx->api.set_background) ctx->api.set_background(ctx->api.userdata, ctx->background);
        return 0;
    }
    if (address >= C64_SCREEN_BEGIN && address <= C64_SCREEN_END) {
        if (ctx->api.screen_write) ctx->api.screen_write(ctx->api.userdata, address - C64_SCREEN_BEGIN, value);
        return 0;
    }
    if (address >= C64_COLOR_BEGIN && address <= C64_COLOR_END) {
        if (ctx->api.color_write) ctx->api.color_write(ctx->api.userdata, address - C64_COLOR_BEGIN, value & 0x0f);
        return 0;
    }
    return 1;
}

static int jt_io_read(void *p, uint16_t address, uint8_t *value)
{
    CBMVM_JTMOS_CONTEXT *ctx = (CBMVM_JTMOS_CONTEXT *)p;
    if (address == C64_BORDER) { *value = ctx->border; return 0; }
    if (address == C64_BACKGROUND) { *value = ctx->background; return 0; }
    return 1;
}

static void jt_screen_clear(void *p)
{
    CBMVM_JTMOS_CONTEXT *ctx=(CBMVM_JTMOS_CONTEXT *)p;
    if(ctx->api.screen_clear) ctx->api.screen_clear(ctx->api.userdata);
}

static void jt_graphics_mode(void *p, int mode, int split_line)
{
    CBMVM_JTMOS_CONTEXT *ctx=(CBMVM_JTMOS_CONTEXT *)p;
    if(ctx->api.graphics_mode) ctx->api.graphics_mode(ctx->api.userdata,mode,split_line);
}

static void jt_graphics_color(void *p, int source, int color)
{
    CBMVM_JTMOS_CONTEXT *ctx=(CBMVM_JTMOS_CONTEXT *)p;
    if(source==0) {
        ctx->background=(uint8_t)((color-1)&15);
        if(ctx->api.set_background) ctx->api.set_background(ctx->api.userdata,ctx->background);
    } else if(source==4) {
        ctx->border=(uint8_t)((color-1)&15);
        if(ctx->api.set_border) ctx->api.set_border(ctx->api.userdata,ctx->border);
    }
    if(ctx->api.graphics_color) ctx->api.graphics_color(ctx->api.userdata,source,color);
}

static int jt_sprite_editor(void *p, uint8_t data[8][63])
{
    CBMVM_JTMOS_CONTEXT *ctx=(CBMVM_JTMOS_CONTEXT *)p;
    return ctx->api.sprite_editor ? ctx->api.sprite_editor(ctx->api.userdata,data) : 0;
}

static void jt_graphics_present(void *p, const uint8_t *pixels, size_t bytes,
                                int width, int height, const uint8_t colors[7],
                                int mode, int split_line)
{
    CBMVM_JTMOS_CONTEXT *ctx=(CBMVM_JTMOS_CONTEXT *)p;
    if(ctx->api.graphics_present)
        ctx->api.graphics_present(ctx->api.userdata,pixels,bytes,width,height,colors,mode,split_line);
}


static void jt_graphics_present_dirty(void *p, const uint8_t *pixels, size_t bytes,
                                      int width, int height, const uint8_t colors[7],
                                      int mode, int split_line, int x, int y, int w, int h)
{
    CBMVM_JTMOS_CONTEXT *ctx=(CBMVM_JTMOS_CONTEXT *)p;
    if(ctx->api.graphics_present_dirty)
        ctx->api.graphics_present_dirty(ctx->api.userdata,pixels,bytes,width,height,colors,mode,split_line,x,y,w,h);
    else if(ctx->api.graphics_present)
        ctx->api.graphics_present(ctx->api.userdata,pixels,bytes,width,height,colors,mode,split_line);
}

static void jt_graphics_damage(void *p, int x, int y, int w, int h)
{
    CBMVM_JTMOS_CONTEXT *ctx=(CBMVM_JTMOS_CONTEXT *)p;
    if(ctx->api.graphics_damage) ctx->api.graphics_damage(ctx->api.userdata,x,y,w,h);
}

static void jt_timer_tick(void *p, unsigned int hz, uint64_t jiffy)
{
    CBMVM_JTMOS_CONTEXT *ctx=(CBMVM_JTMOS_CONTEXT *)p;
    if(ctx->api.timer_tick) ctx->api.timer_tick(ctx->api.userdata,hz,jiffy);
}

static void jt_sprite_colors(void *p, int multicolor1, int multicolor2)
{
    CBMVM_JTMOS_CONTEXT *ctx=(CBMVM_JTMOS_CONTEXT *)p;
    if(ctx->api.sprite_colors) ctx->api.sprite_colors(ctx->api.userdata,multicolor1,multicolor2);
}

static void jt_sprite_update(void *p, int number, int enabled, int x, int y,
                             int color, int priority, int xe, int ye, int multi,
                             const uint8_t data[63])
{
    CBMVM_JTMOS_CONTEXT *ctx=(CBMVM_JTMOS_CONTEXT *)p;
    if(ctx->api.sprite_update)
        ctx->api.sprite_update(ctx->api.userdata,number,enabled,x,y,color,priority,xe,ye,multi,data);
}

void cbmvm_jtmos_host_init(CBMVM_JTMOS_CONTEXT *ctx,
                           const CBMVM_JTMOS_BINDINGS *bindings,
                           CBMVM_HOST *host_out)
{
    if (!ctx || !host_out) return;
    memset(ctx, 0, sizeof(*ctx));
    memset(host_out, 0, sizeof(*host_out));
    if (bindings) ctx->api = *bindings;
    ctx->border = CBMVM_C128_DEFAULT_BORDER;
    ctx->background = CBMVM_C128_DEFAULT_BACKGROUND;
    host_out->userdata = ctx;
    host_out->putc = jt_putc;
    host_out->getc = jt_getc;
    host_out->yield = jt_yield;
    host_out->io_write = jt_io_write;
    host_out->io_read = jt_io_read;
    host_out->screen_clear = jt_screen_clear;
    host_out->graphics_mode = jt_graphics_mode;
    host_out->graphics_color = jt_graphics_color;
    host_out->sprite_editor = jt_sprite_editor;
    host_out->graphics_present = jt_graphics_present;
    host_out->graphics_present_dirty = jt_graphics_present_dirty;
    host_out->graphics_damage = jt_graphics_damage;
    host_out->timer_tick = jt_timer_tick;
    host_out->sprite_colors = jt_sprite_colors;
    host_out->sprite_update = jt_sprite_update;
}

int cbmvm_jtmos_run_slice(CBMVM *vm, CBMVM_JTMOS_CONTEXT *ctx, unsigned int statement_budget)
{
    if (!vm || !ctx) return CBMVM_ERR;
    if (ctx->api.monotonic_us) {
        uint64_t now=ctx->api.monotonic_us(ctx->api.userdata);
        if (ctx->last_monotonic_us && now >= ctx->last_monotonic_us)
            cbmvm_timer_advance_us(vm, now-ctx->last_monotonic_us);
        ctx->last_monotonic_us=now;
    }
    return cbmvm_run(vm,statement_budget);
}
