/* Simplified full-frame VIC-II renderer for SYS/6510 programs. */
#include <string.h>
#include "cbmvm_vicii.h"
#include "cbmvm_petscii.h"

static uint8_t r8(const uint8_t *ram,size_t n,uint16_t a){return a<n?ram[a]:0;}
static uint16_t vic_bank(uint8_t cia2){return (uint16_t)(((~cia2)&3u)*0x4000u);}
static void rom_glyph(uint8_t ch,uint8_t glyph[8]){cbmvm_petscii_glyph(ch,glyph);}

static void draw_text(const uint8_t *ram,size_t n,const uint8_t color_ram[0x400],const uint8_t vic[0x40],uint16_t bank,uint16_t screen,uint16_t chars,uint8_t out[CBMVM_VICII_PIXELS])
{
    int row,col,gy,gx;int multi=(vic[0x16]&0x10u)!=0,ecm=(vic[0x11]&0x40u)!=0;
    for(row=0;row<25;row++)for(col=0;col<40;col++){
        unsigned int cell=(unsigned int)row*40u+(unsigned int)col;uint8_t code=r8(ram,n,(uint16_t)(screen+cell));uint8_t cr=(uint8_t)(color_ram[cell&0x3ffu]&15u);uint8_t glyph[8];uint8_t bg=vic[0x21]&15u;
        if(ecm){uint8_t sel=(uint8_t)(code>>6);code&=63u;bg=vic[0x21u+sel]&15u;}
        /* VIC character ROM is visible to the VIC at $1000/$9000 even when CPU I/O is mapped. */
        if((chars&0x3000u)==0x1000u && ((bank==0x0000u)||(bank==0x8000u)))rom_glyph(code,glyph);
        else for(gy=0;gy<8;gy++)glyph[gy]=r8(ram,n,(uint16_t)(chars+(uint16_t)code*8u+(uint16_t)gy));
        for(gy=0;gy<8;gy++){
            if(multi && (cr&8u)){
                for(gx=0;gx<4;gx++){uint8_t bits=(uint8_t)((glyph[gy]>>(6-gx*2))&3u),c;int px=(col*8)+(gx*2),py=row*8+gy;if(bits==0)c=bg;else if(bits==1)c=vic[0x22]&15u;else if(bits==2)c=vic[0x23]&15u;else c=cr&7u;out[py*320+px]=c;out[py*320+px+1]=c;}
            }else for(gx=0;gx<8;gx++){int px=col*8+gx,py=row*8+gy;out[py*320+px]=((glyph[gy]>>(7-gx))&1u)?cr:bg;}
        }
    }
}

static void draw_bitmap(const uint8_t *ram,size_t n,const uint8_t color_ram[0x400],const uint8_t vic[0x40],uint16_t screen,uint16_t bitmap,uint8_t out[CBMVM_VICII_PIXELS])
{
    int row,col,gy,gx;int multi=(vic[0x16]&0x10u)!=0;
    for(row=0;row<25;row++)for(col=0;col<40;col++){
        unsigned int cell=(unsigned int)row*40u+(unsigned int)col;uint8_t sc=r8(ram,n,(uint16_t)(screen+cell));uint8_t cr=(uint8_t)(color_ram[cell&0x3ffu]&15u);
        for(gy=0;gy<8;gy++){uint8_t b=r8(ram,n,(uint16_t)(bitmap+(uint16_t)cell*8u+(uint16_t)gy));
            if(multi){for(gx=0;gx<4;gx++){uint8_t q=(uint8_t)((b>>(6-gx*2))&3u),c;int px=col*8+gx*2,py=row*8+gy;if(q==0)c=vic[0x21]&15u;else if(q==1)c=(sc>>4)&15u;else if(q==2)c=sc&15u;else c=cr;out[py*320+px]=c;out[py*320+px+1]=c;}}
            else for(gx=0;gx<8;gx++){int px=col*8+gx,py=row*8+gy;out[py*320+px]=((b>>(7-gx))&1u)?((sc>>4)&15u):(sc&15u);}
        }
    }
}

static void draw_sprites(const uint8_t *ram,size_t n,const uint8_t vic[0x40],uint16_t bank,uint16_t screen,uint8_t out[CBMVM_VICII_PIXELS])
{
    int s,row,b,dx,dy;uint8_t ena=vic[0x15],xmsb=vic[0x10],xexp=vic[0x1d],yexp=vic[0x17],multi=vic[0x1c];
    for(s=0;s<8;s++)if(ena&(1u<<s)){
        int sx=(int)vic[s*2]+((xmsb&(1u<<s))?256:0)-24;int sy=(int)vic[s*2+1]-50;uint8_t ptr=r8(ram,n,(uint16_t)(screen+0x3f8u+s));uint16_t data=(uint16_t)(bank+(uint16_t)ptr*64u);uint8_t scol=vic[0x27u+s]&15u;
        for(row=0;row<21;row++){
            if(multi&(1u<<s))for(b=0;b<12;b++){uint8_t q=(uint8_t)((r8(ram,n,(uint16_t)(data+row*3+b/4))>>(6-(b&3)*2))&3u),c;if(!q)continue;c=q==1?(vic[0x25]&15u):q==2?scol:(vic[0x26]&15u);for(dy=0;dy<((yexp&(1u<<s))?2:1);dy++)for(dx=0;dx<((xexp&(1u<<s))?4:2);dx++){int x=sx+b*((xexp&(1u<<s))?4:2)+dx,y=sy+row*((yexp&(1u<<s))?2:1)+dy;if(x>=0&&x<320&&y>=0&&y<200)out[y*320+x]=c;}}
            else for(b=0;b<24;b++)if((r8(ram,n,(uint16_t)(data+row*3+b/8))>>(7-(b&7)))&1u)for(dy=0;dy<((yexp&(1u<<s))?2:1);dy++)for(dx=0;dx<((xexp&(1u<<s))?2:1);dx++){int x=sx+b*((xexp&(1u<<s))?2:1)+dx,y=sy+row*((yexp&(1u<<s))?2:1)+dy;if(x>=0&&x<320&&y>=0&&y<200)out[y*320+x]=scol;}
        }
    }
}

void cbmvm_vicii_render(const uint8_t *ram,size_t n,const uint8_t color_ram[0x400],const uint8_t vic[0x40],uint8_t cia2,uint8_t out[CBMVM_VICII_PIXELS])
{
    uint16_t bank=vic_bank(cia2),screen=(uint16_t)(bank+((vic[0x18]>>4)&15u)*0x400u),chars=(uint16_t)(bank+((vic[0x18]>>1)&7u)*0x800u),bitmap=(uint16_t)(bank+((vic[0x18]>>3)&1u)*0x2000u);uint8_t bg=vic[0x21]&15u;
    if(!ram||!color_ram||!vic||!out)return;
    memset(out,bg,CBMVM_VICII_PIXELS);
    if(vic[0x11]&0x20u)draw_bitmap(ram,n,color_ram,vic,screen,bitmap,out);else draw_text(ram,n,color_ram,vic,bank,screen,chars,out);
    draw_sprites(ram,n,vic,bank,screen,out);
}
