# CBMVM 0.7 — C128 BASIC 7 + MOS 6502/6510 SYS VM for Linux/SDL2 and JTMOS/GraOS

CBMVM executes tokenized Commodore BASIC directly and, when BASIC executes `SYS`, can switch cooperatively into its integrated MOS 6502/6510 compatibility core. It is **not cycle-exact**, and it does not bundle Commodore ROM images; the VM stays sandboxed inside its 64 KiB guest address space and is designed to run as a JTMOS/GraOS process.

## Linux SDL2 + native JTMOS/GraOS

CBMVM now has two real graphical frontends selected at compile time:

* **Linux (`#ifndef JTMOS`)**: SDL 2.x window, keyboard event pump, PETSCII text,
  bitmap modes, split-screen modes and sprites.
* **JTMOS (`#ifdef JTMOS`)**: native GraOS RGBA32 framebuffer window using the
  same VM state and rendering semantics; no SDL library is linked on JTMOS.

The default C128-inspired colour schema is **green border, green text and grey
background**. POKE writes to `$D020/$D021`, screen RAM and colour RAM remain
visible on both frontends. The 320x200 C128 surface is surrounded by a 16-pixel
green border.

Build examples:

    make -j2                 # Linux SDL2 ./cbmvm
    make -j2 test-core       # VM regression tests without SDL2
    make -j2 jtmos           # native JTMOS cbmvm.bin

For a standalone CBMVM checkout, point `JTMOS_ROOT` at the JTMOS source root,
for example `make -j2 jtmos JTMOS_ROOT=/path/to/JTMOS`.


## Main features

- standard linked BASIC PRG loader/validator
- 64 KiB guest RAM; PEEK/POKE never become raw host pointers
- recursive-descent expression parser instead of the original multi-megabyte command queue
- cooperative `cbmvm_step()` / budgeted `cbmvm_run()`
- host callbacks for console, scheduler, virtual I/O and graphics
- BASIC V2 control flow, DATA/input, sparse arrays, DEF FN, variables and numeric/string expressions
- BASIC 7 structured `DO/LOOP/EXIT` control flow and cooperative `GETKEY`
- BASIC 7 graphics, colors, shapes and sprite commands
- packed 320x200 2-bit/source framebuffer (16,000 bytes)
- PETSCII/C128-compatible clean-room 8x8 character renderer (no Commodore ROM bytes bundled)
- dirty-rectangle bitmap presentation plus sprite old/new damage rectangles
- deterministic PAL 50 Hz / NTSC 60 Hz virtual video clock
- sprite-sprite and sprite-bitmap collision state with `BUMP()` and `COLLISION`
- binary-safe 255-byte BASIC strings for SSHAPE/GSHAPE and SPRSAV
- GraOS-facing JTMOS bridge that does not include GraOS headers


## SYS and machine-code programs in 0.7

`SYS address` now enters a cooperative NMOS MOS 6502/6510 execution mode instead of reporting token `$9E` as unsupported. A normal machine-code routine may `RTS` back to BASIC; programs that replace the stack and stay in machine code continue running cooperatively inside the SDL2/GraOS event loop.

The machine-code compatibility layer includes:

- the documented NMOS 6502 instruction set plus common C64 undocumented opcodes (`ALR`, `ANC`, `ARR`, `LAX`, `SAX`, `DCP`, `ISC`, `SLO`, `RLA`, `SRE`, `RRA`, `AXS`, `LAS` and the common undocumented NOP/store variants);
- 6510 `$0000/$0001` memory banking, including RAM-under-I/O behavior;
- separate 1 KiB color RAM rather than aliasing `$D800-$DBFF` RAM;
- VIC-II raster counter, raster IRQ basis and frame timing at the selected 50/60 Hz rate;
- CIA1/CIA2 timer-A/timer-B and interrupt-mask basics;
- keyboard-matrix input for common keys;
- small KERNAL traps for CHROUT, GETIN, STOP, SCNKEY and SCREEN when KERNAL ROM would be visible;
- full-frame VIC-II rendering for standard text, multicolor text, hires bitmap, multicolor bitmap and eight hardware sprites;
- identical machine-frame output path on Linux/SDL2 and native JTMOS/GraOS.

This is intentionally a compatibility VM rather than a cycle-exact C64 emulator. Raster split effects, exact bad-line timing, SID audio synthesis, every CIA serial/TOD feature and every unstable undocumented opcode are future accuracy work.

## Core BASIC commands in 0.6

The VM now implements the program-runtime commands needed by ordinary tokenized
C64/C128 BASIC programs instead of only the earlier minimal control-flow subset.

Statements / control flow:

- `END`, `STOP`, assignment / `LET`, `PRINT`, `REM`, `CLR`, `RUN`
- `GOTO`, `GOSUB` / `RETURN`, `ON ... GOTO`, `ON ... GOSUB`
- `IF ... THEN`, `IF ... GOTO`, C128 `ELSE` statement clauses
- `FOR` / `NEXT` / `STEP`
- `DO`, `DO WHILE`, `DO UNTIL`, `LOOP`, `LOOP WHILE`, `LOOP UNTIL`, `EXIT`
- `DATA`, `READ`, `RESTORE [line]`
- `DIM` with up to four dimensions; untouched arrays auto-dimension to 0..10
- `INPUT`, nonblocking `GET`, cooperative C128 `GETKEY`
- `WAIT address,mask[,xor]`, `POKE`
- numeric `DEF FN name(parameter)=expression` and `FN name(value)`

Functions / expressions:

- numeric/string variables and array elements, literals and concatenation
- `+ - * / ^`, comparisons, `AND`, `OR`, `NOT`, parentheses
- `PEEK`, `SGN`, `INT`, `ABS`, `SQR`, `RND`, `LOG`, `EXP`, `COS`, `SIN`, `TAN`, `ATN`
- `FRE`, `POS`, `LEN`, `STR$`, `VAL`, `ASC`, `CHR$`, `LEFT$`, `RIGHT$`, `MID$`
- `TAB()` and `SPC()` as bounded printable-space values

`INPUT` and `GETKEY` cooperate with the host scheduler: if input is not ready,
`cbmvm_step()` returns `CBMVM_YIELDED` instead of blocking JTMOS. `WAIT` uses the
same mechanism while its condition is false. `DO/LOOP` tracks nesting explicitly
and a skipped `DO WHILE/UNTIL` scans to the structurally matching `LOOP`.

Commands that fundamentally require a Commodore device/editor environment are
not silently emulated. `OPEN/CLOSE`, `INPUT#/GET#/PRINT#`, `LOAD/SAVE/VERIFY`,
`SYS/USR`, direct-mode `LIST/NEW/CONT`, disk-directory commands and SID music
commands remain a separate host/device layer to implement through explicit JTMOS
and SDL2 services.

## BASIC 7 graphics (0.3–0.5)

Screen / drawing:

- `GRAPHIC 0..5[,clear][,split]`, `GRAPHIC CLR`, `SCNCLR [mode]`
- `RGR(x)`, `RCLR(source)`, `RDOT(selector)`
- `LOCATE x,y`, `SCALE on[,xmax,ymax]`, `WIDTH 1|2`
- `DRAW`, `BOX`, `CIRCLE`, `PAINT`, `CHAR`, `COLOR`
- `SSHAPE` / `GSHAPE`

Sprites:

- `SPRITE`, `MOVSPR`, `SPRDEF`
- `SPRCOLOR`, `SPRSAV`
- `RSPRITE()`, `RSPPOS()`, `RSPCOLOR()`
- `BUMP()` collision registers
- `COLLISION type[,line]` BASIC callback dispatch

See `docs/BASIC7_GRAPHICS.md` for compatibility details.

## Build and test

```sh
make -j2
make test
make jtmos-check
make graphics-demo
```

`make graphics-demo` writes `examples/graphics_demo.ppm`. A ready rendered PNG from the earlier demo is included as `examples/graphics_demo.png`.

## Small VM API

```c
CBMVM *vm = cbmvm_create(&host);
cbmvm_load_prg(vm, prg_bytes, prg_length);
cbmvm_set_video_hz(vm, 50); /* PAL; use 60 for NTSC */

for (;;) {
    int rc = cbmvm_run(vm, 256);

    /* Advance using monotonic host time, not statement count. */
    cbmvm_timer_advance_us(vm, elapsed_us);

    if (rc == CBMVM_YIELDED)
        continue;
    if (rc == CBMVM_HALTED)
        break;
    if (rc == CBMVM_ERR)
        break;
}

cbmvm_destroy(vm);
```

A BASIC infinite loop cannot permanently monopolize the caller: execution is bounded by a statement budget and yields to the host.

## JTMOS/GraOS bridge

`cbmvm_jtmos.c` translates generic VM callbacks into application-supplied bindings. The generic JTMOS bridge bindings are:

```c
b.screen_clear           = my_clear;
b.graphics_mode          = my_mode;
b.graphics_color         = my_color;
b.graphics_present_dirty = my_blit_dirty_sources;
b.graphics_damage        = my_damage;          /* sprite old/new rectangles */
b.sprite_update          = my_sprite_update;
b.sprite_editor          = my_graos_sprite_editor;
b.monotonic_us           = my_monotonic_us;
b.timer_tick             = my_video_tick;
b.sprite_colors          = my_shared_sprite_colors;
```

Then a JTMOS process can use:

```c
for (;;) {
    int rc = cbmvm_jtmos_run_slice(vm, &ctx, 128);
    graos_dispatch_events();
    if (rc == CBMVM_HALTED || rc == CBMVM_ERR)
        break;
    process_yield();
}
```

`cbmvm_jtmos_run_slice()` converts the host monotonic microsecond clock into exact 50/60 Hz VM jiffies. It does not assume that one BASIC statement equals one video frame.

`graphics_present_dirty` receives the full packed framebuffer pointer plus the changed `(x,y,w,h)` rectangle. A GraOS compositor therefore reads only the affected source pixels. Sprite changes are reported separately through `graphics_damage`, including both the previous and new sprite bounds so moving sprites erase correctly.

Existing virtual C64 addresses remain supported:

- `$0400-$07E7` — text screen cells
- `$D800-$DBE7` — color cells
- `$D020` / 53280 — border
- `$D021` / 53281 — background

## Memory footprint

On the current 64-bit development build, `cbmvm_instance_bytes()` reports **132,160 bytes** (about 129.1 KiB), including the 64 KiB guest RAM, BASIC graphics state, the 6510 CPU state and separate 1 KiB C64 color RAM. Host-side VIC-II frame buffers are kept outside the VM instance. The footprint is bounded and deterministic.

## Font compatibility

The source package intentionally does **not** embed Commodore CHARGEN ROM bytes. `cbmvm_petscii.c` contains a clean-room 8x8 PETSCII/C128-compatible fallback renderer with uppercase letters, digits, punctuation, graphics characters and reverse-video handling. This is suitable for a self-contained JTMOS build, but is not claimed to be pixel-identical to every C128 ROM charset.

A future GraOS host can optionally provide a legally supplied exact CHARGEN asset without changing BASIC command semantics.

## PRG compatibility

The original 2021 example set remains under `legacy_examples/`. Generated active tests use valid linked PRGs. BASIC 7 programs use the actual C128 extension-token forms, including CE- and FE-prefixed sprite/function tokens.
