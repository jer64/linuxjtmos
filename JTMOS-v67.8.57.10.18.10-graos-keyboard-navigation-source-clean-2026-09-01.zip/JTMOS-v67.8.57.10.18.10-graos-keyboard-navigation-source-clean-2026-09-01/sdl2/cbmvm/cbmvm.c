#include "about_cbmvm.h"

#ifndef JTMOS
#include "cbmvm_sdl2.h"

int main(int argc, char **argv)
{
    if (argc < 2) {
        about_cbmvm();
        return 0;
    }
    return cbmvm_sdl2_run_program(argc, argv);
}
#else
#include <jtmos/process.h>
#include "cbmvm_jtmos_graos.h"
SYSMEMREQ(APPRAM_4096K)

int main(int argc, char **argv)
{
    return cbmvm_jtmos_graos_run_program(argc, argv);
}
#endif
