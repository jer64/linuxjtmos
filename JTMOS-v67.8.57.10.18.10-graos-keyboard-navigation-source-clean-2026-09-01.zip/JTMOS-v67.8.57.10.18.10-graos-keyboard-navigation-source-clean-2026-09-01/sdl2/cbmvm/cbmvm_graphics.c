#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "cbmvm_graphics.h"
#include "cbmvm_petscii.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

static int cbmvm_round_int(double x)
{
    return x >= 0.0 ? (int)(x + 0.5) : (int)(x - 0.5);
}

#define PAINT_STACK_MAX 4096

typedef struct { int x, y; } GFX_POINT;

static int clampi(int v, int lo, int hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static size_t pixel_index(int x, int y)
{
    return (size_t)y * CBMVM_GFX_WIDTH + (size_t)x;
}

static uint8_t packed_get(const uint8_t *p, size_t index)
{
    unsigned int shift = (unsigned int)((index & 3u) * 2u);
    return (uint8_t)((p[index >> 2] >> shift) & 3u);
}

static void packed_set(uint8_t *p, size_t index, uint8_t source)
{
    unsigned int shift = (unsigned int)((index & 3u) * 2u);
    uint8_t mask = (uint8_t)(3u << shift);
    p[index >> 2] = (uint8_t)((p[index >> 2] & (uint8_t)~mask) | ((source & 3u) << shift));
}

void cbmvm_graphics_mark_dirty(CBMVM_GRAPHICS *g, int x1, int y1, int x2, int y2)
{
    if (!g) return;
    if (x1 > x2) { int t=x1; x1=x2; x2=t; }
    if (y1 > y2) { int t=y1; y1=y2; y2=t; }
    if (x2 < 0 || y2 < 0 || x1 >= CBMVM_GFX_WIDTH || y1 >= CBMVM_GFX_HEIGHT) return;
    x1 = clampi(x1, 0, CBMVM_GFX_WIDTH - 1);
    x2 = clampi(x2, 0, CBMVM_GFX_WIDTH - 1);
    y1 = clampi(y1, 0, CBMVM_GFX_HEIGHT - 1);
    y2 = clampi(y2, 0, CBMVM_GFX_HEIGHT - 1);
    if (!g->dirty_valid) {
        g->dirty_valid=1;
        g->dirty_x1=(int16_t)x1; g->dirty_y1=(int16_t)y1;
        g->dirty_x2=(int16_t)x2; g->dirty_y2=(int16_t)y2;
    } else {
        if (x1 < g->dirty_x1) g->dirty_x1=(int16_t)x1;
        if (y1 < g->dirty_y1) g->dirty_y1=(int16_t)y1;
        if (x2 > g->dirty_x2) g->dirty_x2=(int16_t)x2;
        if (y2 > g->dirty_y2) g->dirty_y2=(int16_t)y2;
    }
}

void cbmvm_graphics_mark_all_dirty(CBMVM_GRAPHICS *g)
{
    cbmvm_graphics_mark_dirty(g, 0, 0, CBMVM_GFX_WIDTH-1, CBMVM_GFX_HEIGHT-1);
}

int cbmvm_graphics_take_dirty(CBMVM_GRAPHICS *g, int *x, int *y, int *w, int *h)
{
    if (!g || !g->dirty_valid) return 0;
    if (x) *x=g->dirty_x1;
    if (y) *y=g->dirty_y1;
    if (w) *w=g->dirty_x2-g->dirty_x1+1;
    if (h) *h=g->dirty_y2-g->dirty_y1+1;
    g->dirty_valid=0;
    return 1;
}

void cbmvm_graphics_reset(CBMVM_GRAPHICS *g)
{
    static const uint8_t defaults[CBMVM_GFX_COLOR_SOURCES] = { 1, 2, 3, 7, 1, 2, 1 };
    unsigned int i;
    if (!g) return;
    memset(g, 0, sizeof(*g));
    memcpy(g->color, defaults, sizeof(defaults));
    g->mode = 0;
    g->split_line = 19;
    g->pen_source = 1;
    g->line_width = 1;
    g->scale_xmax = 1023;
    g->scale_ymax = 1023;
    g->sprite_multicolor[0] = 3;
    g->sprite_multicolor[1] = 4;
    for (i = 0; i < CBMVM_SPRITE_COUNT; i++) {
        g->sprites[i].color = (uint8_t)(i + 1u);
        if (g->sprites[i].color > 16) g->sprites[i].color=2;
    }
    cbmvm_graphics_mark_all_dirty(g);
}

void cbmvm_graphics_clear(CBMVM_GRAPHICS *g, uint8_t source)
{
    uint8_t pattern;
    if (!g) return;
    source &= 3u;
    pattern = (uint8_t)(source | (source << 2) | (source << 4) | (source << 6));
    memset(g->pixels, pattern, sizeof(g->pixels));
    g->cursor_x = 0;
    g->cursor_y = 0;
    g->pen_source = source;
    cbmvm_graphics_mark_all_dirty(g);
    g->generation++;
}

int cbmvm_graphics_set_mode(CBMVM_GRAPHICS *g, int mode, int clear, int split_line)
{
    if (!g || mode < 0 || mode > 5) return -1;
    g->mode = (uint8_t)mode;
    g->scale_enabled = 0; /* Authentic BASIC 7: GRAPHIC disables SCALE. */
    g->scale_xmax = (uint16_t)((mode == 3 || mode == 4) ? 2047 : 1023);
    g->scale_ymax = 1023;
    if (split_line >= 0) g->split_line = (uint8_t)clampi(split_line, 0, 24);
    else if (mode == 2 || mode == 4) g->split_line = 19;
    if (clear) cbmvm_graphics_clear(g, 0);
    cbmvm_graphics_mark_all_dirty(g);
    g->generation++;
    return 0;
}

int cbmvm_graphics_set_color(CBMVM_GRAPHICS *g, int source, int color)
{
    if (!g || source < 0 || source >= CBMVM_GFX_COLOR_SOURCES || color < 1 || color > 16) return -1;
    g->color[source] = (uint8_t)color;
    cbmvm_graphics_mark_all_dirty(g); /* color source remaps already stored source pixels */
    g->generation++;
    return 0;
}

int cbmvm_graphics_set_scale(CBMVM_GRAPHICS *g, int enabled, int xmax, int ymax)
{
    if (!g || (enabled != 0 && enabled != 1)) return -1;
    if (!enabled) {
        g->scale_enabled=0;
        return 0;
    }
    if (xmax <= 0) xmax = (g->mode == 3 || g->mode == 4) ? 2047 : 1023;
    if (ymax <= 0) ymax = 1023;
    if (xmax < 320 || xmax > 32767 || ymax < 200 || ymax > 32767) return -1;
    g->scale_enabled=1;
    g->scale_xmax=(uint16_t)xmax;
    g->scale_ymax=(uint16_t)ymax;
    return 0;
}

int cbmvm_graphics_set_width(CBMVM_GRAPHICS *g, int width)
{
    if (!g || (width != 1 && width != 2)) return -1;
    g->line_width=(uint8_t)width;
    return 0;
}

int cbmvm_graphics_scale_x(const CBMVM_GRAPHICS *g, double x)
{
    double maxphys;
    int v;
    if (!g) return 0;
    maxphys=(g->mode==3 || g->mode==4) ? 159.0 : 319.0;
    if (g->scale_enabled) v=cbmvm_round_int(x * maxphys / (double)g->scale_xmax);
    else v=cbmvm_round_int(x);
    if (g->mode==3 || g->mode==4) v *= 2;
    return v;
}

int cbmvm_graphics_scale_y(const CBMVM_GRAPHICS *g, double y)
{
    if (!g) return 0;
    if (g->scale_enabled) return cbmvm_round_int(y * 199.0 / (double)g->scale_ymax);
    return cbmvm_round_int(y);
}

int cbmvm_graphics_unscale_x(const CBMVM_GRAPHICS *g, int x)
{
    double phys;
    if (!g) return 0;
    phys=(double)x;
    if (g->mode==3 || g->mode==4) phys/=2.0;
    if (g->scale_enabled) return cbmvm_round_int(phys * (double)g->scale_xmax / ((g->mode==3||g->mode==4)?159.0:319.0));
    return cbmvm_round_int(phys);
}

int cbmvm_graphics_unscale_y(const CBMVM_GRAPHICS *g, int y)
{
    if (!g) return 0;
    if (g->scale_enabled) return cbmvm_round_int((double)y * (double)g->scale_ymax / 199.0);
    return y;
}

uint8_t cbmvm_graphics_get_pixel(const CBMVM_GRAPHICS *g, int x, int y)
{
    if (!g || x < 0 || x >= CBMVM_GFX_WIDTH || y < 0 || y >= CBMVM_GFX_HEIGHT) return 0;
    return packed_get(g->pixels, pixel_index(x, y));
}

static void pixel_raw(CBMVM_GRAPHICS *g, int x, int y, uint8_t source)
{
    if (x < 0 || x >= CBMVM_GFX_WIDTH || y < 0 || y >= CBMVM_GFX_HEIGHT) return;
    packed_set(g->pixels, pixel_index(x,y), source);
}

static void pixel_width(CBMVM_GRAPHICS *g, int x, int y, uint8_t source)
{
    pixel_raw(g,x,y,source);
    if (g->line_width==2) {
        pixel_raw(g,x+1,y,source);
        pixel_raw(g,x,y+1,source);
        pixel_raw(g,x+1,y+1,source);
    }
}

void cbmvm_graphics_put_pixel(CBMVM_GRAPHICS *g, int x, int y, uint8_t source)
{
    int r;
    if (!g || x < 0 || x >= CBMVM_GFX_WIDTH || y < 0 || y >= CBMVM_GFX_HEIGHT) return;
    pixel_width(g,x,y,source);
    r=(g->line_width==2)?1:0;
    cbmvm_graphics_mark_dirty(g,x,y,x+r,y+r);
    g->cursor_x=(int16_t)x; g->cursor_y=(int16_t)y; g->pen_source=source&3u; g->generation++;
}

void cbmvm_graphics_line(CBMVM_GRAPHICS *g, int x0, int y0, int x1, int y1, uint8_t source)
{
    int dx, sx, dy, sy, err;
    int ox0=x0, oy0=y0;
    if (!g) return;
    dx=abs(x1-x0); sx=x0<x1?1:-1; dy=-abs(y1-y0); sy=y0<y1?1:-1; err=dx+dy;
    for (;;) {
        pixel_width(g,x0,y0,source);
        if (x0==x1 && y0==y1) break;
        { int e2=2*err; if(e2>=dy){err+=dy;x0+=sx;} if(e2<=dx){err+=dx;y0+=sy;} }
    }
    {
        int pad=(g->line_width==2)?1:0;
        int minx=ox0<x1?ox0:x1, maxx=ox0>x1?ox0:x1;
        int miny=oy0<y1?oy0:y1, maxy=oy0>y1?oy0:y1;
        cbmvm_graphics_mark_dirty(g,minx,miny,maxx+pad,maxy+pad);
    }
    g->cursor_x=(int16_t)x1; g->cursor_y=(int16_t)y1; g->pen_source=source&3u; g->generation++;
}

static void rotate_point(double cx, double cy, double angle, double x, double y, int *ox, int *oy)
{
    double r=angle*M_PI/180.0, c=cos(r), s=sin(r), dx=x-cx, dy=y-cy;
    *ox=cbmvm_round_int(cx+dx*c-dy*s); *oy=cbmvm_round_int(cy+dx*s+dy*c);
}

static void fill_polygon(CBMVM_GRAPHICS *g, const GFX_POINT *p, int n, uint8_t source)
{
    int y,miny=CBMVM_GFX_HEIGHT-1,maxy=0,minx=CBMVM_GFX_WIDTH-1,maxx=0,nodes[16],i,j;
    for(i=0;i<n;i++){
        if(p[i].y<miny)miny=p[i].y;
        if(p[i].y>maxy)maxy=p[i].y;
        if(p[i].x<minx)minx=p[i].x;
        if(p[i].x>maxx)maxx=p[i].x;
    }
    miny=clampi(miny,0,CBMVM_GFX_HEIGHT-1);maxy=clampi(maxy,0,CBMVM_GFX_HEIGHT-1);
    for(y=miny;y<=maxy;y++){
        int count=0;j=n-1;
        for(i=0;i<n;i++){
            if(((p[i].y<y&&p[j].y>=y)||(p[j].y<y&&p[i].y>=y))&&p[j].y!=p[i].y){
                if(count<(int)(sizeof(nodes)/sizeof(nodes[0]))) nodes[count++]=p[i].x+(y-p[i].y)*(p[j].x-p[i].x)/(p[j].y-p[i].y);
            }j=i;
        }
        for(i=0;i+1<count;i++){int k;for(k=i+1;k<count;k++)if(nodes[k]<nodes[i]){int t=nodes[i];nodes[i]=nodes[k];nodes[k]=t;}}
        for(i=0;i+1<count;i+=2){int x,x0=clampi(nodes[i],0,CBMVM_GFX_WIDTH-1),x1=clampi(nodes[i+1],0,CBMVM_GFX_WIDTH-1);for(x=x0;x<=x1;x++)pixel_raw(g,x,y,source);}
    }
    cbmvm_graphics_mark_dirty(g,minx,miny,maxx,maxy);
}

void cbmvm_graphics_box(CBMVM_GRAPHICS *g, int x1, int y1, int x2, int y2,double angle,int paint,uint8_t source)
{
    GFX_POINT p[4];double cx,cy;int i,minx,maxx,miny,maxy;
    if(!g)return;
    cx=((double)x1+x2)/2.0;
    cy=((double)y1+y2)/2.0;
    rotate_point(cx,cy,angle,x1,y1,&p[0].x,&p[0].y);rotate_point(cx,cy,angle,x2,y1,&p[1].x,&p[1].y);
    rotate_point(cx,cy,angle,x2,y2,&p[2].x,&p[2].y);rotate_point(cx,cy,angle,x1,y2,&p[3].x,&p[3].y);
    if(paint)fill_polygon(g,p,4,source);
    for(i=0;i<4;i++){int j=(i+1)&3;cbmvm_graphics_line(g,p[i].x,p[i].y,p[j].x,p[j].y,source);}
    minx=maxx=p[0].x;miny=maxy=p[0].y;for(i=1;i<4;i++){if(p[i].x<minx)minx=p[i].x;if(p[i].x>maxx)maxx=p[i].x;if(p[i].y<miny)miny=p[i].y;if(p[i].y>maxy)maxy=p[i].y;}
    cbmvm_graphics_mark_dirty(g,minx,miny,maxx+1,maxy+1);g->cursor_x=(int16_t)x2;g->cursor_y=(int16_t)y2;g->generation++;
}

void cbmvm_graphics_circle(CBMVM_GRAPHICS *g,int cx,int cy,int xr,int yr,double start_angle,double end_angle,double rotation,double increment,uint8_t source)
{
    double a,end;int first=1,px=cx,py=cy,minx=CBMVM_GFX_WIDTH,miny=CBMVM_GFX_HEIGHT,maxx=0,maxy=0;
    if(!g)return;
    if(yr<0)yr=-yr;
    if(xr<0)xr=-xr;
    if(yr==0)yr=xr;
    if(increment<=0.0)increment=2.0;
    if(increment>360.0)increment=360.0;
    while(end_angle<start_angle)end_angle+=360.0;
    end=end_angle;
    for(a=start_angle;a<=end+0.0001;a+=increment){
        double ar=a*M_PI/180.0,rr=rotation*M_PI/180.0,ex=cos(ar)*xr,ey=sin(ar)*yr;int x=cbmvm_round_int(cx+ex*cos(rr)-ey*sin(rr)),y=cbmvm_round_int(cy+ex*sin(rr)+ey*cos(rr));
        if(first){pixel_width(g,x,y,source);first=0;}else cbmvm_graphics_line(g,px,py,x,y,source);px=x;py=y;if(x<minx)minx=x;if(x>maxx)maxx=x;if(y<miny)miny=y;if(y>maxy)maxy=y;
    }
    cbmvm_graphics_mark_dirty(g,minx,miny,maxx+1,maxy+1);g->cursor_x=(int16_t)px;g->cursor_y=(int16_t)py;g->pen_source=source&3u;g->generation++;
}

int cbmvm_graphics_paint(CBMVM_GRAPHICS *g,int x,int y,uint8_t source,int mode)
{
    uint16_t stack[PAINT_STACK_MAX];unsigned int sp=0;uint8_t target;int minx=x,maxx=x,miny=y,maxy=y;
    if(!g||x<0||x>=CBMVM_GFX_WIDTH||y<0||y>=CBMVM_GFX_HEIGHT)return-1;
    source&=3u;
    target=cbmvm_graphics_get_pixel(g,x,y);
    if(target==source)return 0;
    stack[sp++]=(uint16_t)(y*CBMVM_GFX_WIDTH+x);
    while(sp){uint16_t idx=stack[--sp];int sx=idx%CBMVM_GFX_WIDTH,sy=idx/CBMVM_GFX_WIDTH,lx=sx,rx,nx;
        while(lx>0){uint8_t c=cbmvm_graphics_get_pixel(g,lx-1,sy);if((mode==0&&c!=target)||(mode!=0&&c!=0))break;lx--;}
        rx=lx;while(rx<CBMVM_GFX_WIDTH){uint8_t c=cbmvm_graphics_get_pixel(g,rx,sy);if((mode==0&&c!=target)||(mode!=0&&c!=0))break;pixel_raw(g,rx,sy,source);if(rx<minx)minx=rx;if(rx>maxx)maxx=rx;if(sy<miny)miny=sy;if(sy>maxy)maxy=sy;rx++;}
        for(nx=lx;nx<rx;nx++){int d;for(d=-1;d<=1;d+=2){int yy=sy+d;if(yy>=0&&yy<CBMVM_GFX_HEIGHT){uint8_t c=cbmvm_graphics_get_pixel(g,nx,yy);if((mode==0&&c==target)||(mode!=0&&c==0)){if(sp>=PAINT_STACK_MAX)return-2;stack[sp++]=(uint16_t)(yy*CBMVM_GFX_WIDTH+nx);while(nx+1<rx){uint8_t c2=cbmvm_graphics_get_pixel(g,nx+1,yy);if(!((mode==0&&c2==target)||(mode!=0&&c2==0)))break;nx++;}}}}}
    }
    cbmvm_graphics_mark_dirty(g,minx,miny,maxx,maxy);g->cursor_x=(int16_t)x;g->cursor_y=(int16_t)y;g->pen_source=source;g->generation++;return 0;
}

void cbmvm_graphics_char(CBMVM_GRAPHICS *g,int column,int row,unsigned char ch,uint8_t source,int reverse)
{
    uint8_t glyph[8];int base_x=column*8,base_y=row*8,yy,xx;
    if(!g)return;
    cbmvm_petscii_glyph(ch,glyph);
    for(yy=0;yy<8;yy++)for(xx=0;xx<8;xx++){
        int on=(glyph[yy]>>(7-xx))&1;if(reverse)on=!on;
        pixel_raw(g,base_x+xx,base_y+yy,(uint8_t)(on?source:0));
    }
    cbmvm_graphics_mark_dirty(g,base_x,base_y,base_x+7,base_y+7);g->cursor_x=(int16_t)base_x;g->cursor_y=(int16_t)base_y;g->pen_source=source&3u;g->generation++;
}

void cbmvm_graphics_text(CBMVM_GRAPHICS *g,int column,int row,const unsigned char *text,size_t length,uint8_t source,int reverse)
{
    size_t i;int x=column,y=row;if(!g||!text)return;
    for(i=0;i<length;i++){if(text[i]=='\n'||x>=40){x=0;y++;if(text[i]=='\n')continue;}if(y>=25)break;cbmvm_graphics_char(g,x++,y,text[i],source,reverse);}
    g->cursor_x=(int16_t)(x*8);g->cursor_y=(int16_t)(y*8);
}

static int sprite_w(const CBMVM_SPRITE *s){return 24*(s->x_expand?2:1);}
static int sprite_h(const CBMVM_SPRITE *s){return 21*(s->y_expand?2:1);}

static int sprite_opaque_at(const CBMVM_SPRITE *s,int gx,int gy)
{
    int lx,ly,rowbyte,bit;
    if(!s||!s->enabled)return 0;
    lx=gx-s->x;
    ly=gy-s->y;
    if(s->x_expand)lx/=2;
    if(s->y_expand)ly/=2;
    if(lx<0||lx>=24||ly<0||ly>=21)return 0;
    rowbyte=ly*3;
    if(s->multicolor){int pair=lx/2;int bytei=rowbyte+pair/4;int shift=6-(pair%4)*2;return ((s->data[bytei]>>shift)&3)!=0;}
    bit=23-lx;return (s->data[rowbyte+(bit/8)]>>(bit&7))&1;
}

void cbmvm_graphics_detect_collisions(CBMVM_GRAPHICS *g)
{
    int i,j;
    if(!g)return;
    for(i=0;i<CBMVM_SPRITE_COUNT;i++){
        CBMVM_SPRITE *a=&g->sprites[i];int ax0,ay0,ax1,ay1,x,y,hit=0;if(!a->enabled)continue;
        ax0=a->x;ay0=a->y;ax1=ax0+sprite_w(a)-1;ay1=ay0+sprite_h(a)-1;
        for(y=clampi(ay0,0,CBMVM_GFX_HEIGHT-1);y<=clampi(ay1,0,CBMVM_GFX_HEIGHT-1)&&!hit;y++)for(x=clampi(ax0,0,CBMVM_GFX_WIDTH-1);x<=clampi(ax1,0,CBMVM_GFX_WIDTH-1);x++)if(sprite_opaque_at(a,x,y)&&cbmvm_graphics_get_pixel(g,x,y)!=0){hit=1;break;}
        if(hit)g->bump_display|=(uint8_t)(1u<<i);
        for(j=i+1;j<CBMVM_SPRITE_COUNT;j++){
            CBMVM_SPRITE *b=&g->sprites[j];int bx0,by0,bx1,by1,ox0,oy0,ox1,oy1,coll=0;if(!b->enabled)continue;
            bx0=b->x;by0=b->y;bx1=bx0+sprite_w(b)-1;by1=by0+sprite_h(b)-1;ox0=ax0>bx0?ax0:bx0;oy0=ay0>by0?ay0:by0;ox1=ax1<bx1?ax1:bx1;oy1=ay1<by1?ay1:by1;if(ox0>ox1||oy0>oy1)continue;
            for(y=oy0;y<=oy1&&!coll;y++)for(x=ox0;x<=ox1;x++)if(sprite_opaque_at(a,x,y)&&sprite_opaque_at(b,x,y)){coll=1;break;}
            if(coll)g->bump_sprite|=(uint8_t)((1u<<i)|(1u<<j));
        }
    }
}

uint8_t cbmvm_graphics_bump(CBMVM_GRAPHICS *g,int kind)
{
    uint8_t v=0;if(!g)return 0;if(kind==1){v=g->bump_sprite;g->bump_sprite=0;}else if(kind==2){v=g->bump_display;g->bump_display=0;}return v;
}

void cbmvm_graphics_tick(CBMVM_GRAPHICS *g,unsigned int ticks)
{
    unsigned int i;if(!g||!ticks)return;
    for(i=0;i<CBMVM_SPRITE_COUNT;i++){
        CBMVM_SPRITE *s=&g->sprites[i];if(s->enabled&&s->moving&&s->speed>0.0){double r=s->angle*M_PI/180.0,d=s->speed*(double)ticks;s->x=(int16_t)cbmvm_round_int((double)s->x+sin(r)*d);s->y=(int16_t)cbmvm_round_int((double)s->y-cos(r)*d);}
    }
    cbmvm_graphics_detect_collisions(g);g->generation++;
}
