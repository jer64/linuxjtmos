/*
 * cbmvm_engine.c - small tokenized Commodore BASIC VM core.
 * Original project (C) 2021 Jari Tapio Tuominen.
 * Refactored 2026: standard PRG line links, compact execution core,
 * host callbacks, cooperative stepping and bounded guest memory.
 */
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cbmvm_engine.h"
#include "cbmvm_settings.h"
#include "cbmvm_graphics.h"
#include "cbmvm_6502.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

static int cbmvm_round_int(double x)
{
    return x >= 0.0 ? (int)(x + 0.5) : (int)(x - 0.5);
}

static int parse_decimal_number(const char *s, double *out);

/* Commodore BASIC V2 tokens used by this compact interpreter. */
#define T_END       0x80
#define T_FOR       0x81
#define T_NEXT      0x82
#define T_DATA      0x83
#define T_INPUTN    0x84
#define T_INPUT     0x85
#define T_DIM       0x86
#define T_READ      0x87
#define T_LET       0x88
#define T_GOTO      0x89
#define T_RUN       0x8a
#define T_IF        0x8b
#define T_RESTORE   0x8c
#define T_GOSUB     0x8d
#define T_RETURN    0x8e
#define T_REM       0x8f
#define T_STOP      0x90
#define T_ON        0x91
#define T_WAIT      0x92
#define T_LOAD      0x93
#define T_SAVE      0x94
#define T_VERIFY    0x95
#define T_DEF       0x96
#define T_POKE      0x97
#define T_PRINTN    0x98
#define T_PRINT     0x99
#define T_CONT      0x9a
#define T_LIST      0x9b
#define T_CLR       0x9c
#define T_CMD       0x9d
#define T_SYS       0x9e
#define T_OPEN      0x9f
#define T_CLOSE     0xa0
#define T_GET       0xa1
#define T_NEW       0xa2
#define T_TAB       0xa3
#define T_TO        0xa4
#define T_FN        0xa5
#define T_SPC       0xa6
#define T_THEN      0xa7
#define T_NOT       0xa8
#define T_STEP      0xa9
#define T_PLUS      0xaa
#define T_MINUS     0xab
#define T_MUL       0xac
#define T_DIV       0xad
#define T_POW       0xae
#define T_AND       0xaf
#define T_OR        0xb0
#define T_GT        0xb1
#define T_EQ        0xb2
#define T_LT        0xb3
#define T_SGN       0xb4
#define T_INT       0xb5
#define T_ABS       0xb6
#define T_USR       0xb7
#define T_FRE       0xb8
#define T_POS       0xb9
#define T_SQR       0xba
#define T_RND       0xbb
#define T_LOG       0xbc
#define T_EXP       0xbd
#define T_COS       0xbe
#define T_SIN       0xbf
#define T_TAN       0xc0
#define T_ATN       0xc1
#define T_PEEK      0xc2
#define T_LEN       0xc3
#define T_STR       0xc4
#define T_VAL       0xc5
#define T_ASC       0xc6
#define T_CHR       0xc7
#define T_LEFT      0xc8
#define T_RIGHT     0xc9
#define T_MID       0xca
/* BASIC 7.0 extension tokens. */
#define T_RGR       0xcc
#define T_RCLR      0xcd
#define T_EXT_CE    0xce
#define T_RDOT      0xd0
#define T_ELSE      0xd5
#define T_GRAPHIC   0xde
#define T_PAINT     0xdf
#define T_CHAR      0xe0
#define T_BOX       0xe1
#define T_CIRCLE    0xe2
#define T_GSHAPE    0xe3
#define T_SSHAPE    0xe4
#define T_DRAW      0xe5
#define T_LOCATE    0xe6
#define T_COLOR     0xe7
#define T_SCNCLR    0xe8
#define T_SCALE     0xe9
#define T_DO        0xeb
#define T_LOOP      0xec
#define T_EXIT      0xed
#define T_KEY       0xf9
#define T_UNTIL     0xfc
#define T_WHILE     0xfd
#define T_EXT_FE    0xfe
#define TCE_BUMP     0x03
#define TCE_RSPPOS   0x05
#define TCE_RSPRITE  0x06
#define TCE_RSPCOLOR 0x07
#define TFE_MOVSPR    0x06
#define TFE_SPRITE    0x07
#define TFE_SPRCOLOR  0x08
#define TFE_SPRSAV    0x16
#define TFE_COLLISION 0x17
#define TFE_WIDTH     0x1c
#define TFE_SPRDEF    0x1d

#define C64_BORDER  53280u
#define C64_BG      53281u

typedef struct {
    int is_string;
    double number;
    char string[CBMVM_MAX_STRING];
    uint16_t string_length;
} VALUE;

typedef struct {
    CBMVM *vm;
    uint16_t pos;
} PARSER;

static uint16_t rd16(const uint8_t *p)
{
    return (uint16_t)((uint16_t)p[0] | ((uint16_t)p[1] << 8));
}

static void vm_set_error(CBMVM *vm, const char *msg)
{
    if (!vm) return;
    vm->error = 1;
    vm->halted = 1;
    if (!msg) msg = "CBMVM error";
    strncpy(vm->error_message, msg, sizeof(vm->error_message) - 1);
    vm->error_message[sizeof(vm->error_message) - 1] = 0;
}

static void vm_syntax_error(CBMVM *vm, const char *msg)
{
    char tmp[160];
    snprintf(tmp, sizeof(tmp), "?SYNTAX ERROR IN %u: %s",
             (unsigned)vm->line_number, msg ? msg : "invalid statement");
    vm_set_error(vm, tmp);
}

static void vm_putc(CBMVM *vm, int ch)
{
    if (vm->host.putc) vm->host.putc(vm->host.userdata, ch);
    if (ch == '\n' || ch == '\r') vm->print_column = 0;
    else vm->print_column++;
}

static void vm_puts(CBMVM *vm, const char *s)
{
    if (!s) return;
    while (*s) vm_putc(vm, (unsigned char)*s++);
}


static void vm_graphics_present(CBMVM *vm)
{
    int x,y,w,h;
    if (!vm) return;
    if (!cbmvm_graphics_take_dirty(&vm->graphics,&x,&y,&w,&h)) return;
    if (vm->host.graphics_present_dirty) {
        vm->host.graphics_present_dirty(vm->host.userdata, vm->graphics.pixels,
                                        sizeof(vm->graphics.pixels),
                                        CBMVM_GFX_WIDTH, CBMVM_GFX_HEIGHT,
                                        vm->graphics.color, vm->graphics.mode,
                                        vm->graphics.split_line,x,y,w,h);
    } else if (vm->host.graphics_present) {
        vm->host.graphics_present(vm->host.userdata, vm->graphics.pixels,
                                  sizeof(vm->graphics.pixels),
                                  CBMVM_GFX_WIDTH, CBMVM_GFX_HEIGHT,
                                  vm->graphics.color, vm->graphics.mode,
                                  vm->graphics.split_line);
    }
}

static int sprite_present_w(const CBMVM_SPRITE *s) { return 24 * (s->x_expand ? 2 : 1); }
static int sprite_present_h(const CBMVM_SPRITE *s) { return 21 * (s->y_expand ? 2 : 1); }

static void vm_sprite_present(CBMVM *vm, int index)
{
    CBMVM_SPRITE *s;
    int nx,ny,nw,nh;
    if (!vm || index < 0 || index >= CBMVM_SPRITE_COUNT) return;
    s = &vm->graphics.sprites[index];
    nx=s->x; ny=s->y; nw=sprite_present_w(s); nh=sprite_present_h(s);
    if (vm->host.graphics_damage) {
        if (s->presented_valid)
            vm->host.graphics_damage(vm->host.userdata,s->presented_x,s->presented_y,s->presented_w,s->presented_h);
        if (s->enabled) vm->host.graphics_damage(vm->host.userdata,nx,ny,nw,nh);
    }
    if (vm->host.sprite_update)
        vm->host.sprite_update(vm->host.userdata, index + 1, s->enabled, s->x, s->y,
                               s->color, s->priority, s->x_expand, s->y_expand,
                               s->multicolor, s->data);
    s->presented_x=(int16_t)nx; s->presented_y=(int16_t)ny;
    s->presented_w=(uint8_t)nw; s->presented_h=(uint8_t)nh; s->presented_valid=s->enabled;
}
static void vm_print_number(CBMVM *vm, double n)
{
    char buf[48];
    if (fabs(n) < 0.000000000001) n = 0.0;
    snprintf(buf, sizeof(buf), "%.12g", n);
    vm_puts(vm, buf);
}

static void skip_spaces(PARSER *p)
{
    while (p->pos < p->vm->program_end && p->vm->ram[p->pos] == ' ') p->pos++;
}

static int at_statement_end(PARSER *p)
{
    uint8_t c;
    skip_spaces(p);
    if (p->pos >= p->vm->program_end) return 1;
    c = p->vm->ram[p->pos];
    return c == 0 || c == ':';
}

static uint16_t statement_delimiter(CBMVM *vm, uint16_t pos)
{
    int quoted = 0;
    while (pos < vm->program_end) {
        uint8_t c = vm->ram[pos];
        if (c == '"') quoted = !quoted;
        if (!quoted && (c == 0 || c == ':')) break;
        pos++;
    }
    return pos;
}

static int normalize_name(const char *src, char *dst, size_t dstlen)
{
    size_t i = 0;
    if (!src || !dst || dstlen < 2) return -1;
    while (*src && i + 1 < dstlen) {
        unsigned char c = (unsigned char)*src++;
        if (c == ' ') continue;
        dst[i++] = (char)toupper(c);
    }
    dst[i] = 0;
    return i ? 0 : -1;
}

static int parse_var_name(PARSER *p, char *name, size_t n)
{
    size_t i = 0;
    skip_spaces(p);
    if (p->pos >= p->vm->program_end || !isalpha((unsigned char)p->vm->ram[p->pos])) return -1;
    while (p->pos < p->vm->program_end && i + 1 < n) {
        uint8_t c = p->vm->ram[p->pos];
        if (!(isalnum((unsigned char)c) || c == '$' || c == '%')) break;
        name[i++] = (char)toupper(c);
        p->pos++;
        if (c == '$' || c == '%') break;
    }
    name[i] = 0;
    return i ? 0 : -1;
}

static CBMVM_VARIABLE *find_var(CBMVM *vm, const char *name, int create)
{
    unsigned int i;
    char normalized[CBMVM_MAX_VAR_NAME];
    if (normalize_name(name, normalized, sizeof(normalized)) < 0) return NULL;
    for (i = 0; i < vm->variable_count; i++) {
        if (strcmp(vm->variables[i].name, normalized) == 0) return &vm->variables[i];
    }
    if (!create || vm->variable_count >= CBMVM_MAX_VARIABLES) return NULL;
    i = vm->variable_count++;
    memset(&vm->variables[i], 0, sizeof(vm->variables[i]));
    snprintf(vm->variables[i].name, sizeof(vm->variables[i].name), "%s", normalized);
    vm->variables[i].type = strchr(normalized, '$') ? CBMVM_VALUE_STRING : CBMVM_VALUE_NUMBER;
    return &vm->variables[i];
}

static VALUE value_number(double n)
{
    VALUE v;
    memset(&v, 0, sizeof(v));
    v.number = n;
    return v;
}

static VALUE value_blob(const void *data, size_t length)
{
    VALUE v;
    memset(&v, 0, sizeof(v));
    v.is_string = 1;
    if (length >= sizeof(v.string)) length = sizeof(v.string) - 1u;
    if (data && length) memcpy(v.string, data, length);
    v.string[length] = 0;
    v.string_length = (uint16_t)length;
    return v;
}

static VALUE value_string(const char *s)
{
    return value_blob(s, s ? strlen(s) : 0u);
}

static int value_truth(const VALUE *v)
{
    if (v->is_string) return v->string_length != 0;
    return v->number != 0.0;
}

static int value_to_number(CBMVM *vm, VALUE *v, double *out)
{
    if (v->is_string) {
        vm_syntax_error(vm, "numeric expression expected");
        return -1;
    }
    *out = v->number;
    return 0;
}

static int parse_expression(PARSER *p, VALUE *out);
static int int_round(double x);
static int parse_sprite_number(CBMVM *vm, double d);

static CBMVM_ARRAY_DEF *find_array(CBMVM *vm, const char *name)
{
    unsigned int i;
    for (i = 0; i < vm->array_count; i++)
        if (strcmp(vm->arrays[i].name, name) == 0) return &vm->arrays[i];
    return NULL;
}

static CBMVM_ARRAY_DEF *define_array(CBMVM *vm, const char *name,
                                     const int *index, unsigned int dims, int explicit_dim)
{
    CBMVM_ARRAY_DEF *a;
    unsigned int i;
    a = find_array(vm, name);
    if (a) {
        if (explicit_dim) { vm_set_error(vm, "?REDIM'D ARRAY ERROR"); return NULL; }
        return a;
    }
    if (!dims || dims > CBMVM_MAX_ARRAY_DIMS || vm->array_count >= CBMVM_MAX_ARRAYS) {
        vm_set_error(vm, "?OUT OF MEMORY ERROR (DIM)"); return NULL;
    }
    a = &vm->arrays[vm->array_count++];
    memset(a, 0, sizeof(*a));
    snprintf(a->name, sizeof(a->name), "%s", name);
    a->dimensions = (uint8_t)dims;
    for (i = 0; i < dims; i++) a->upper[i] = (uint16_t)(explicit_dim ? index[i] : 10);
    return a;
}

/* Parse scalar or array reference and produce the sparse canonical variable key. */
static int parse_variable_reference(PARSER *p, char *key, size_t keylen, int explicit_dim)
{
    char base[CBMVM_MAX_VAR_NAME];
    int idx[CBMVM_MAX_ARRAY_DIMS];
    unsigned int dims = 0, i;
    CBMVM_ARRAY_DEF *a;
    size_t used;
    if (parse_var_name(p, base, sizeof(base)) < 0) return -1;
    skip_spaces(p);
    if (p->vm->ram[p->pos] != '(') {
        if (explicit_dim) { vm_syntax_error(p->vm, "DIM requires subscripts"); return -1; }
        snprintf(key, keylen, "%s", base);
        return 0;
    }
    p->pos++;
    for (;;) {
        VALUE v; double d;
        if (dims >= CBMVM_MAX_ARRAY_DIMS) { vm_set_error(p->vm, "?BAD SUBSCRIPT ERROR"); return -1; }
        if (parse_expression(p, &v) < 0 || value_to_number(p->vm, &v, &d) < 0) return -1;
        idx[dims] = int_round(d);
        if (idx[dims] < 0 || idx[dims] > 32767) { vm_set_error(p->vm, "?BAD SUBSCRIPT ERROR"); return -1; }
        dims++;
        skip_spaces(p);
        if (p->vm->ram[p->pos] == ',') { p->pos++; continue; }
        if (p->vm->ram[p->pos] != ')') { vm_syntax_error(p->vm, "missing ) in subscript"); return -1; }
        p->pos++;
        break;
    }
    a = define_array(p->vm, base, idx, dims, explicit_dim);
    if (!a) return -1;
    if (a->dimensions != dims) { vm_set_error(p->vm, "?BAD SUBSCRIPT ERROR"); return -1; }
    for (i = 0; i < dims; i++) if ((unsigned int)idx[i] > a->upper[i]) {
        vm_set_error(p->vm, "?BAD SUBSCRIPT ERROR"); return -1;
    }
    used = (size_t)snprintf(key, keylen, "%s(", base);
    for (i = 0; i < dims && used + 3 < keylen; i++) {
        int n = snprintf(key + used, keylen - used, "%s%d", i ? "," : "", idx[i]);
        if (n < 0 || (size_t)n >= keylen - used) { vm_set_error(p->vm, "?OUT OF MEMORY ERROR (NAME)"); return -1; }
        used += (size_t)n;
    }
    if (used + 2 > keylen) { vm_set_error(p->vm, "?OUT OF MEMORY ERROR (NAME)"); return -1; }
    key[used++] = ')'; key[used] = 0;
    return 0;
}

static int parse_primary(PARSER *p, VALUE *out)
{
    CBMVM *vm = p->vm;
    uint8_t c;
    char name[CBMVM_MAX_VAR_NAME];
    char text[CBMVM_MAX_STRING];
    size_t i;

    skip_spaces(p);
    if (p->pos >= vm->program_end) return -1;
    c = vm->ram[p->pos];

    if (c == '(') {
        p->pos++;
        if (parse_expression(p, out) < 0) return -1;
        skip_spaces(p);
        if (vm->ram[p->pos] != ')') { vm_syntax_error(vm, "missing )"); return -1; }
        p->pos++;
        return 0;
    }

    if (c == T_MINUS || c == '-') {
        double n;
        p->pos++;
        if (parse_primary(p, out) < 0 || value_to_number(vm, out, &n) < 0) return -1;
        *out = value_number(-n);
        return 0;
    }
    if (c == T_PLUS || c == '+') {
        p->pos++;
        return parse_primary(p, out);
    }
    if (c == T_NOT) {
        double n;
        p->pos++;
        if (parse_primary(p, out) < 0 || value_to_number(vm, out, &n) < 0) return -1;
        *out = value_number((double)(~(int)n));
        return 0;
    }

    if (c == T_RGR) {
        VALUE dummy;
        p->pos++;
        skip_spaces(p);
        if (p->pos < vm->program_end && vm->ram[p->pos] == '(') {
            p->pos++;
            if (parse_expression(p, &dummy) < 0) return -1;
            skip_spaces(p);
            if (vm->ram[p->pos] != ')') { vm_syntax_error(vm, "missing ) after RGR"); return -1; }
            p->pos++;
        }
        *out = value_number((double)vm->graphics.mode);
        return 0;
    }

    if (c == T_RCLR || c == T_RDOT) {
        uint8_t fn=c; VALUE a; double n; int arg;
        p->pos++; skip_spaces(p);
        if (vm->ram[p->pos] != '(') { vm_syntax_error(vm,"function requires ("); return -1; }
        p->pos++;
        if (parse_expression(p,&a)<0 || value_to_number(vm,&a,&n)<0) return -1;
        skip_spaces(p); if(vm->ram[p->pos]!=')'){vm_syntax_error(vm,"missing )");return -1;} p->pos++;
        arg=int_round(n);
        if(fn==T_RCLR){
            if(arg<0||arg>=CBMVM_GFX_COLOR_SOURCES){vm_syntax_error(vm,"RCLR source must be 0..6");return -1;}
            *out=value_number((double)vm->graphics.color[arg]);
        } else {
            if(arg==0)*out=value_number((double)cbmvm_graphics_unscale_x(&vm->graphics,vm->graphics.cursor_x));
            else if(arg==1)*out=value_number((double)cbmvm_graphics_unscale_y(&vm->graphics,vm->graphics.cursor_y));
            else if(arg==2)*out=value_number((double)vm->graphics.pen_source);
            else {vm_syntax_error(vm,"RDOT argument must be 0..2");return -1;}
        }
        return 0;
    }

    if (c == T_EXT_CE) {
        uint8_t ext; VALUE a,b; double da=0.0,db=0.0; int ia,ib,hasb=0;
        p->pos++; if(p->pos>=vm->program_end){vm_syntax_error(vm,"truncated $CE function");return -1;} ext=vm->ram[p->pos++];
        skip_spaces(p); if(vm->ram[p->pos]!='('){vm_syntax_error(vm,"BASIC 7 function requires (");return -1;} p->pos++;
        if(parse_expression(p,&a)<0||value_to_number(vm,&a,&da)<0)return -1;
        skip_spaces(p);
        if(vm->ram[p->pos]==','){p->pos++;if(parse_expression(p,&b)<0||value_to_number(vm,&b,&db)<0)return -1;hasb=1;}
        skip_spaces(p);if(vm->ram[p->pos]!=')'){vm_syntax_error(vm,"missing ) after BASIC 7 function");return -1;}p->pos++;
        ia=int_round(da);ib=int_round(db);
        if(ext==TCE_BUMP){
            if(ia!=1&&ia!=2){vm_syntax_error(vm,"BUMP argument must be 1 or 2");return -1;}
            cbmvm_graphics_detect_collisions(&vm->graphics);
            *out=value_number((double)cbmvm_graphics_bump(&vm->graphics,ia)); return 0;
        }
        if(ext==TCE_RSPCOLOR){
            if(ia<1||ia>2){vm_syntax_error(vm,"RSPCOLOR argument must be 1 or 2");return -1;}
            *out=value_number((double)vm->graphics.sprite_multicolor[ia-1]); return 0;
        }
        if(ext==TCE_RSPPOS){
            CBMVM_SPRITE *sp; int idx; if(!hasb){vm_syntax_error(vm,"RSPPOS(sprite,selector) expected");return -1;} idx=parse_sprite_number(vm,da); if(idx<0)return -1; sp=&vm->graphics.sprites[idx];
            if(ib==0)*out=value_number((double)cbmvm_graphics_unscale_x(&vm->graphics,sp->x));
            else if(ib==1)*out=value_number((double)cbmvm_graphics_unscale_y(&vm->graphics,sp->y));
            else if(ib==2)*out=value_number(sp->speed);
            else {vm_syntax_error(vm,"RSPPOS selector must be 0..2");return -1;}
            return 0;
        }
        if(ext==TCE_RSPRITE){
            CBMVM_SPRITE *sp; int idx; if(!hasb){vm_syntax_error(vm,"RSPRITE(sprite,selector) expected");return -1;} idx=parse_sprite_number(vm,da); if(idx<0)return -1; sp=&vm->graphics.sprites[idx];
            if(ib==0)*out=value_number((double)sp->enabled);
            else if(ib==1)*out=value_number((double)sp->color);
            else if(ib==2)*out=value_number((double)sp->priority);
            else if(ib==3)*out=value_number((double)sp->x_expand);
            else if(ib==4)*out=value_number((double)sp->y_expand);
            else if(ib==5)*out=value_number((double)sp->multicolor);
            else {vm_syntax_error(vm,"RSPRITE selector must be 0..5");return -1;}
            return 0;
        }
        vm_syntax_error(vm,"unsupported $CE BASIC 7 function"); return -1;
    }

    if (c == T_FN) {
        char fn_name[CBMVM_MAX_VAR_NAME];
        CBMVM_FN_DEF *def = NULL;
        VALUE arg, result;
        double n;
        unsigned int j, param_index;
        int existed;
        CBMVM_VARIABLE saved, *param;
        PARSER fp;
        p->pos++; skip_spaces(p);
        if (parse_var_name(p, fn_name, sizeof(fn_name)) < 0 || strchr(fn_name,'$')) {
            vm_syntax_error(vm,"numeric FN name expected"); return -1;
        }
        for(j=0;j<vm->function_count;j++) if(strcmp(vm->functions[j].name,fn_name)==0){def=&vm->functions[j];break;}
        if(!def){vm_set_error(vm,"?UNDEF'D FUNCTION ERROR");return -1;}
        skip_spaces(p);if(vm->ram[p->pos]!='('){vm_syntax_error(vm,"FN requires (");return -1;}p->pos++;
        if(parse_expression(p,&arg)<0 || value_to_number(vm,&arg,&n)<0)return -1;
        skip_spaces(p);if(vm->ram[p->pos]!=')'){vm_syntax_error(vm,"missing ) after FN");return -1;}p->pos++;
        if(vm->fn_depth>=CBMVM_FN_DEPTH){vm_set_error(vm,"?OUT OF MEMORY ERROR (FN)");return -1;}
        param=find_var(vm,def->parameter,0);existed=param!=NULL;
        if(existed){saved=*param;param_index=(unsigned int)(param-vm->variables);}
        else {param=find_var(vm,def->parameter,1);if(!param){vm_set_error(vm,"?OUT OF MEMORY ERROR");return -1;}param_index=(unsigned int)(param-vm->variables);}
        param->type=CBMVM_VALUE_NUMBER;param->number=n;param->string[0]=0;param->string_length=0;
        vm->fn_depth++;
        fp.vm=vm;fp.pos=def->expression_pc;
        if(parse_expression(&fp,&result)<0 || value_to_number(vm,&result,&n)<0){vm->fn_depth--;if(existed)vm->variables[param_index]=saved;else{memmove(&vm->variables[param_index],&vm->variables[param_index+1],(vm->variable_count-param_index-1u)*sizeof(vm->variables[0]));vm->variable_count--;}return -1;}
        vm->fn_depth--;
        if(existed)vm->variables[param_index]=saved;
        else {memmove(&vm->variables[param_index],&vm->variables[param_index+1],(vm->variable_count-param_index-1u)*sizeof(vm->variables[0]));vm->variable_count--;}
        *out=value_number(n);return 0;
    }

    if (c == T_PEEK) {
        VALUE a;
        double n;
        uint8_t b;
        p->pos++;
        skip_spaces(p);
        if (vm->ram[p->pos] == '(') p->pos++;
        if (parse_expression(p, &a) < 0 || value_to_number(vm, &a, &n) < 0) return -1;
        skip_spaces(p);
        if (vm->ram[p->pos] == ')') p->pos++;
        if (cbmvm_peek(vm, (uint16_t)((int)n & 0xffff), &b) < 0) return -1;
        *out = value_number((double)b);
        return 0;
    }

    if (c == T_INT || c == T_ABS || c == T_SGN || c == T_SQR || c == T_LOG ||
        c == T_EXP || c == T_COS || c == T_SIN || c == T_TAN || c == T_ATN) {
        uint8_t fn = c;
        VALUE a;
        double n;
        p->pos++;
        skip_spaces(p);
        if (vm->ram[p->pos] == '(') p->pos++;
        if (parse_expression(p, &a) < 0 || value_to_number(vm, &a, &n) < 0) return -1;
        skip_spaces(p);
        if (vm->ram[p->pos] == ')') p->pos++;
        if (fn == T_INT) *out = value_number(floor(n));
        else if (fn == T_ABS) *out = value_number(fabs(n));
        else if (fn == T_SGN) *out = value_number(n < 0.0 ? -1.0 : (n > 0.0 ? 1.0 : 0.0));
        else if (fn == T_SQR) {
            if (n < 0.0) { vm_set_error(vm, "?ILLEGAL QUANTITY ERROR"); return -1; }
            *out = value_number(sqrt(n));
        } else if (fn == T_LOG) {
            if (n <= 0.0) { vm_set_error(vm, "?ILLEGAL QUANTITY ERROR"); return -1; }
            *out = value_number(log(n));
        } else if (fn == T_EXP) *out = value_number(exp(n));
        else if (fn == T_COS) *out = value_number(cos(n));
        else if (fn == T_SIN) *out = value_number(sin(n));
        else if (fn == T_TAN) *out = value_number(tan(n));
        else *out = value_number(atan(n));
        return 0;
    }

    if (c == T_RND) {
        VALUE a; double n = 1.0;
        p->pos++; skip_spaces(p);
        if (vm->ram[p->pos] == '(') {
            p->pos++;
            if (parse_expression(p, &a) < 0 || value_to_number(vm, &a, &n) < 0) return -1;
            skip_spaces(p); if (vm->ram[p->pos] != ')') { vm_syntax_error(vm,"missing ) after RND"); return -1; } p->pos++;
        }
        if (n < 0.0) vm->random_state = (uint32_t)(fabs(n) * 2147483647.0) ^ 0xa5a55a5au;
        if (n != 0.0) vm->random_state = vm->random_state * 1664525u + 1013904223u;
        *out = value_number((double)(vm->random_state & 0x00ffffffu) / 16777216.0);
        return 0;
    }

    if (c == T_FRE || c == T_POS) {
        VALUE dummy; double n;
        uint8_t fn = c;
        p->pos++; skip_spaces(p);
        if (vm->ram[p->pos] == '(') {
            p->pos++;
            if (parse_expression(p,&dummy)<0 || value_to_number(vm,&dummy,&n)<0) return -1;
            (void)n; skip_spaces(p); if(vm->ram[p->pos]!=')'){vm_syntax_error(vm,"missing )");return -1;} p->pos++;
        }
        if (fn == T_POS) *out = value_number((double)vm->print_column);
        else {
            size_t used = (size_t)vm->variable_count * sizeof(CBMVM_VARIABLE);
            long free_bytes = (long)CBMVM_RAM_SIZE - (long)used;
            if (free_bytes > 32767) free_bytes = 32767;
            if (free_bytes < -32768) free_bytes = -32768;
            *out = value_number((double)free_bytes);
        }
        return 0;
    }

    if (c == T_LEN || c == T_ASC || c == T_VAL || c == T_STR || c == T_CHR ||
        c == T_LEFT || c == T_RIGHT || c == T_MID || c == T_TAB || c == T_SPC) {
        uint8_t fn = c; VALUE a,b,d; double n=0.0,m=0.0; int have_b=0,have_d=0;
        p->pos++; skip_spaces(p);
        if (vm->ram[p->pos] == '(') p->pos++; else { vm_syntax_error(vm,"function requires ("); return -1; }
        if (parse_expression(p,&a)<0) return -1;
        skip_spaces(p);
        if (vm->ram[p->pos]==',') { p->pos++; if(parse_expression(p,&b)<0)return -1; have_b=1; skip_spaces(p); }
        if (vm->ram[p->pos]==',') { p->pos++; if(parse_expression(p,&d)<0)return -1; have_d=1; skip_spaces(p); }
        if (vm->ram[p->pos]!=')') { vm_syntax_error(vm,"missing )"); return -1; }
        p->pos++;
        if (fn==T_LEN) {
            if(!a.is_string){vm_set_error(vm,"?TYPE MISMATCH ERROR");return -1;} *out=value_number((double)a.string_length); return 0;
        }
        if (fn==T_ASC) {
            if(!a.is_string){vm_set_error(vm,"?TYPE MISMATCH ERROR");return -1;} if(!a.string_length){vm_set_error(vm,"?ILLEGAL QUANTITY ERROR");return -1;} *out=value_number((unsigned char)a.string[0]); return 0;
        }
        if (fn==T_VAL) {
            double v=0.0; if(!a.is_string){vm_set_error(vm,"?TYPE MISMATCH ERROR");return -1;}
            if(a.string_length && parse_decimal_number(a.string,&v)<0) v=0.0;
            *out=value_number(v); return 0;
        }
        if (fn==T_STR) {
            char buf[64]; if(value_to_number(vm,&a,&n)<0)return -1; snprintf(buf,sizeof(buf)," %.12g",n); *out=value_string(buf); return 0;
        }
        if (fn==T_CHR) {
            unsigned char ch; if(value_to_number(vm,&a,&n)<0)return -1; ch=(unsigned char)((int)n&255); *out=value_blob(&ch,1); return 0;
        }
        if (fn==T_TAB || fn==T_SPC) {
            char buf[CBMVM_MAX_STRING]; unsigned int count,i;
            if(value_to_number(vm,&a,&n)<0)return -1;
            if(fn==T_TAB){unsigned int col=vm->print_column; unsigned int target=(unsigned int)((int)n<0?0:(int)n);count=target>col?target-col:0u;}
            else count=(unsigned int)((int)n<0?0:(int)n);
            if(count>=sizeof(buf))count=sizeof(buf)-1u;
            for(i=0;i<count;i++)buf[i]=' ';
            *out=value_blob(buf,count); return 0;
        }
        if (!a.is_string || !have_b || value_to_number(vm,&b,&n)<0) { vm_set_error(vm,"?TYPE MISMATCH ERROR"); return -1; }
        {
            int start=0,count=0; size_t len=a.string_length;
            if(fn==T_LEFT){start=0;count=(int)n;}
            else if(fn==T_RIGHT){count=(int)n;start=(int)len-count;if(start<0)start=0;}
            else { start=(int)n-1;if(start<0){vm_set_error(vm,"?ILLEGAL QUANTITY ERROR");return -1;}count=(int)len-start;if(have_d){if(value_to_number(vm,&d,&m)<0)return -1;count=(int)m;} }
            if(count<0){vm_set_error(vm,"?ILLEGAL QUANTITY ERROR");return -1;} if((size_t)start>len)start=(int)len;if((size_t)(start+count)>len)count=(int)len-start;
            *out=value_blob(a.string+start,(size_t)count); return 0;
        }
    }

    if (c == '"') {
        p->pos++;
        i = 0;
        while (p->pos < vm->program_end && vm->ram[p->pos] != '"' && vm->ram[p->pos] != 0) {
            if (i + 1 < sizeof(text)) text[i++] = (char)vm->ram[p->pos];
            p->pos++;
        }
        text[i] = 0;
        if (vm->ram[p->pos] == '"') p->pos++;
        *out = value_blob(text, i);
        return 0;
    }

    if (isdigit((unsigned char)c) || c == '.') {
        char numbuf[64];
        double parsed_number;
        i = 0;
        while (p->pos < vm->program_end && i + 1 < sizeof(numbuf)) {
            c = vm->ram[p->pos];
            if (!(isdigit((unsigned char)c) || c == '.' || c == 'E' || c == 'e' || c == '+' || c == '-')) break;
            /* +/- is only accepted following E/e. */
            if ((c == '+' || c == '-') && i > 0 && numbuf[i-1] != 'E' && numbuf[i-1] != 'e') break;
            numbuf[i++] = (char)c;
            p->pos++;
        }
        numbuf[i] = 0;
        if (parse_decimal_number(numbuf, &parsed_number) < 0) { vm_syntax_error(vm, "bad number"); return -1; }
        *out = value_number(parsed_number);
        return 0;
    }

    if (isalpha((unsigned char)c)) {
        CBMVM_VARIABLE *var;
        if (parse_variable_reference(p, name, sizeof(name), 0) < 0) return -1;
        var = find_var(vm, name, 1);
        if (!var) { vm_set_error(vm, "?OUT OF MEMORY ERROR"); return -1; }
        if (var->type == CBMVM_VALUE_STRING) *out = value_blob(var->string, var->string_length);
        else *out = value_number(var->number);
        return 0;
    }

    vm_syntax_error(vm, "expression expected");
    return -1;
}

static int parse_power(PARSER *p, VALUE *out)
{
    VALUE rhs;
    double a, b;
    if (parse_primary(p, out) < 0) return -1;
    skip_spaces(p);
    if (p->vm->ram[p->pos] == T_POW || p->vm->ram[p->pos] == '^') {
        p->pos++;
        if (parse_power(p, &rhs) < 0 || value_to_number(p->vm, out, &a) < 0 || value_to_number(p->vm, &rhs, &b) < 0) return -1;
        *out = value_number(pow(a, b));
    }
    return 0;
}

static int parse_mul(PARSER *p, VALUE *out)
{
    VALUE rhs;
    double a, b;
    uint8_t op;
    if (parse_power(p, out) < 0) return -1;
    for (;;) {
        skip_spaces(p); op = p->vm->ram[p->pos];
        if (!(op == T_MUL || op == '*' || op == T_DIV || op == '/')) break;
        p->pos++;
        if (parse_power(p, &rhs) < 0 || value_to_number(p->vm, out, &a) < 0 || value_to_number(p->vm, &rhs, &b) < 0) return -1;
        if ((op == T_DIV || op == '/') && b == 0.0) { vm_set_error(p->vm, "?DIVISION BY ZERO ERROR"); return -1; }
        *out = value_number((op == T_MUL || op == '*') ? a * b : a / b);
    }
    return 0;
}

static int parse_add(PARSER *p, VALUE *out)
{
    VALUE rhs;
    uint8_t op;
    if (parse_mul(p, out) < 0) return -1;
    for (;;) {
        double a, b;
        skip_spaces(p); op = p->vm->ram[p->pos];
        if (!(op == T_PLUS || op == '+' || op == T_MINUS || op == '-')) break;
        p->pos++;
        if (parse_mul(p, &rhs) < 0) return -1;
        if ((op == T_PLUS || op == '+') && (out->is_string || rhs.is_string)) {
            unsigned char temp[CBMVM_MAX_STRING];
            size_t used, add;
            if (!out->is_string || !rhs.is_string) { vm_syntax_error(p->vm, "type mismatch"); return -1; }
            used = out->string_length;
            if (used >= sizeof(temp)) used = sizeof(temp) - 1u;
            memcpy(temp, out->string, used);
            add = rhs.string_length;
            if (add > sizeof(temp) - 1u - used) add = sizeof(temp) - 1u - used;
            memcpy(temp + used, rhs.string, add);
            *out = value_blob(temp, used + add);
        } else {
            if (value_to_number(p->vm, out, &a) < 0 || value_to_number(p->vm, &rhs, &b) < 0) return -1;
            *out = value_number((op == T_PLUS || op == '+') ? a + b : a - b);
        }
    }
    return 0;
}

static int compare_values(CBMVM *vm, VALUE *a, VALUE *b, int relation)
{
    if (a->is_string || b->is_string) {
        int c;
        if (!a->is_string || !b->is_string) { vm_syntax_error(vm, "type mismatch"); return 0; }
        c = strcmp(a->string, b->string);
        if (relation == T_EQ) return c == 0;
        if (relation == T_LT) return c < 0;
        if (relation == T_GT) return c > 0;
        return 0;
    }
    if (relation == T_EQ) return a->number == b->number;
    if (relation == T_LT) return a->number < b->number;
    if (relation == T_GT) return a->number > b->number;
    return 0;
}

static int parse_compare(PARSER *p, VALUE *out)
{
    VALUE rhs;
    uint8_t op1, op2;
    int result;
    if (parse_add(p, out) < 0) return -1;
    skip_spaces(p);
    op1 = p->vm->ram[p->pos];
    if (!(op1 == T_EQ || op1 == T_LT || op1 == T_GT || op1 == '=' || op1 == '<' || op1 == '>')) return 0;
    p->pos++;
    skip_spaces(p);
    op2 = p->vm->ram[p->pos];
    if ((op1 == T_LT || op1 == '<') && (op2 == T_EQ || op2 == '=' || op2 == T_GT || op2 == '>')) p->pos++;
    else if ((op1 == T_GT || op1 == '>') && (op2 == T_EQ || op2 == '=')) p->pos++;
    else op2 = 0;
    if (parse_add(p, &rhs) < 0) return -1;

    if (op1 == '=') op1 = T_EQ;
    if (op1 == '<') op1 = T_LT;
    if (op1 == '>') op1 = T_GT;
    result = compare_values(p->vm, out, &rhs, op1);
    if (p->vm->error) return -1;
    if (op2 == T_GT || op2 == '>') result = !compare_values(p->vm, out, &rhs, T_EQ); /* <> */
    else if (op2 == T_EQ || op2 == '=') {
        if (op1 == T_LT) result = compare_values(p->vm, out, &rhs, T_LT) || compare_values(p->vm, out, &rhs, T_EQ);
        if (op1 == T_GT) result = compare_values(p->vm, out, &rhs, T_GT) || compare_values(p->vm, out, &rhs, T_EQ);
    }
    *out = value_number(result ? -1.0 : 0.0);
    return 0;
}

static int parse_logic(PARSER *p, VALUE *out)
{
    VALUE rhs;
    uint8_t op;
    double a, b;
    if (parse_compare(p, out) < 0) return -1;
    for (;;) {
        skip_spaces(p); op = p->vm->ram[p->pos];
        if (op != T_AND && op != T_OR) break;
        p->pos++;
        if (parse_compare(p, &rhs) < 0 || value_to_number(p->vm, out, &a) < 0 || value_to_number(p->vm, &rhs, &b) < 0) return -1;
        *out = value_number((double)(op == T_AND ? ((int)a & (int)b) : ((int)a | (int)b)));
    }
    return 0;
}

static int parse_expression(PARSER *p, VALUE *out)
{
    return parse_logic(p, out);
}

static int set_variable(CBMVM *vm, const char *name, const VALUE *v)
{
    CBMVM_VARIABLE *var = find_var(vm, name, 1);
    if (!var) { vm_set_error(vm, "?OUT OF MEMORY ERROR"); return -1; }
    if (var->type == CBMVM_VALUE_STRING) {
        if (!v->is_string) { vm_syntax_error(vm, "type mismatch"); return -1; }
        size_t n = v->string_length;
        if (n >= sizeof(var->string)) n = sizeof(var->string) - 1u;
        memcpy(var->string, v->string, n);
        var->string[n] = 0;
        var->string_length = (uint16_t)n;
    } else {
        if (v->is_string) { vm_syntax_error(vm, "type mismatch"); return -1; }
        var->number = v->number;
    }
    return 0;
}

static int value_from_text_for_variable(CBMVM *vm, const char *name,
                                        const char *text, size_t length, VALUE *v)
{
    if (strchr(name, '$')) {
        *v = value_blob(text, length);
        return 0;
    }
    {
        char buf[96]; size_t n = length; double d = 0.0;
        while (n && (*text == ' ' || *text == '\t')) { text++; n--; }
        while (n && (text[n-1] == ' ' || text[n-1] == '\t')) n--;
        if (!n) { *v = value_number(0.0); return 0; }
        if (n >= sizeof(buf)) { vm_set_error(vm, "?TYPE MISMATCH ERROR"); return -1; }
        memcpy(buf, text, n); buf[n] = 0;
        if (parse_decimal_number(buf, &d) < 0) { vm_set_error(vm, "?TYPE MISMATCH ERROR"); return -1; }
        *v = value_number(d);
        return 0;
    }
}

static int index_data_items(CBMVM *vm)
{
    uint16_t a = vm->first_line_address;
    unsigned int guard = 0;
    vm->data_item_count = 0; vm->data_index = 0;
    while (a && guard++ < 32768u) {
        uint16_t next = rd16(&vm->ram[a]);
        uint16_t line = rd16(&vm->ram[a+2]);
        uint16_t p = (uint16_t)(a + 4);
        int quoted = 0;
        while (p < vm->program_end && vm->ram[p] != 0) {
            uint8_t c = vm->ram[p];
            if (c == '"') { quoted = !quoted; p++; continue; }
            if (!quoted && c == T_REM) break;
            if (!quoted && c == T_DATA) {
                p++;
                for (;;) {
                    uint16_t start, end; int q = 0; uint8_t delim;
                    while (p < vm->program_end && vm->ram[p] == ' ') p++;
                    start = p;
                    while (p < vm->program_end) {
                        c = vm->ram[p];
                        if (c == '"') q = !q;
                        if (!q && (c == ',' || c == ':' || c == 0)) break;
                        p++;
                    }
                    end = p;
                    while (end > start && vm->ram[end-1] == ' ') end--;
                    delim = p < vm->program_end ? vm->ram[p] : 0;
                    if (end > start || delim == ',') {
                        CBMVM_DATA_ITEM *it;
                        if (vm->data_item_count >= CBMVM_MAX_DATA_ITEMS) { vm_set_error(vm,"?OUT OF MEMORY ERROR (DATA)"); return -1; }
                        it = &vm->data_items[vm->data_item_count++]; it->start=start; it->end=end; it->line=line;
                    }
                    if (delim == ',') { p++; continue; }
                    break;
                }
                continue;
            }
            p++;
        }
        if (!next) break;
        a = next;
    }
    return 0;
}

static int read_data_value(CBMVM *vm, const char *name, VALUE *v)
{
    CBMVM_DATA_ITEM *it; const uint8_t *s; size_t n; char buf[CBMVM_MAX_STRING]; size_t i,j=0;
    if (vm->data_index >= vm->data_item_count) { vm_set_error(vm, "?OUT OF DATA ERROR"); return -1; }
    it = &vm->data_items[vm->data_index++]; s = vm->ram + it->start; n = (size_t)(it->end - it->start);
    if (n >= 2 && s[0] == '"' && s[n-1] == '"') { s++; n -= 2; }
    if (strchr(name,'$')) { *v=value_blob(s,n); return 0; }
    for(i=0;i<n && j+1<sizeof(buf);i++) {
        uint8_t c=s[i]; if(c==T_MINUS)c='-'; else if(c==T_PLUS)c='+'; buf[j++]=(char)c;
    }
    buf[j]=0; return value_from_text_for_variable(vm,name,buf,j,v);
}

static int prepare_line(CBMVM *vm, uint16_t address)
{
    uint16_t next;
    if ((size_t)address + 4u > vm->ram_size || address >= vm->program_end) {
        vm_set_error(vm, "?BAD PROGRAM POINTER");
        return -1;
    }
    next = rd16(&vm->ram[address]);
    vm->line_address = address;
    vm->next_line_address = next;
    vm->line_number = rd16(&vm->ram[address + 2]);
    vm->pc = (uint16_t)(address + 4);
    return 0;
}

static int advance_line(CBMVM *vm)
{
    if (vm->next_line_address == 0) {
        vm->halted = 1;
        return CBMVM_HALTED;
    }
    return prepare_line(vm, vm->next_line_address) < 0 ? CBMVM_ERR : CBMVM_OK;
}

static int find_line(CBMVM *vm, uint16_t line, uint16_t *address)
{
    uint16_t a = vm->first_line_address;
    unsigned int guard = 0;
    while (a && guard++ < 65535u) {
        uint16_t next, nr;
        if ((size_t)a + 4u > vm->ram_size || a >= vm->program_end) return -1;
        next = rd16(&vm->ram[a]);
        nr = rd16(&vm->ram[a + 2]);
        if (nr == line) { *address = a; return 0; }
        if (next == 0) break;
        if (next <= a || next >= vm->program_end) return -1;
        a = next;
    }
    return 1;
}

static int jump_line(CBMVM *vm, uint16_t line)
{
    uint16_t a;
    int rc = find_line(vm, line, &a);
    if (rc != 0) {
        char msg[96];
        snprintf(msg, sizeof(msg), "?UNDEFINED STATEMENT ERROR: %u", (unsigned)line);
        vm_set_error(vm, msg);
        return -1;
    }
    return prepare_line(vm, a);
}

static int parse_line_number_expr(PARSER *p, uint16_t *line)
{
    VALUE v;
    double n;
    if (parse_expression(p, &v) < 0 || value_to_number(p->vm, &v, &n) < 0) return -1;
    if (n < 0 || n > 65535) { vm_syntax_error(p->vm, "bad line number"); return -1; }
    *line = (uint16_t)n;
    return 0;
}

static int statement_assignment(PARSER *p)
{
    char name[CBMVM_MAX_VAR_NAME];
    VALUE v;
    skip_spaces(p);
    if (parse_variable_reference(p, name, sizeof(name), 0) < 0) { vm_syntax_error(p->vm, "variable expected"); return -1; }
    skip_spaces(p);
    if (p->vm->ram[p->pos] != T_EQ && p->vm->ram[p->pos] != '=') { vm_syntax_error(p->vm, "= expected"); return -1; }
    p->pos++;
    if (parse_expression(p, &v) < 0) return -1;
    return set_variable(p->vm, name, &v);
}

static int statement_print(PARSER *p)
{
    CBMVM *vm = p->vm;
    int suppress_newline = 0;
    skip_spaces(p);
    if (at_statement_end(p)) { vm_putc(vm, '\n'); return 0; }
    while (!at_statement_end(p)) {
        VALUE v;
        uint8_t c;
        if (parse_expression(p, &v) < 0) return -1;
        if (v.is_string) vm_puts(vm, v.string); else vm_print_number(vm, v.number);
        skip_spaces(p);
        c = vm->ram[p->pos];
        if (c == ';') {
            p->pos++;
            suppress_newline = 1;
            skip_spaces(p);
            continue;
        }
        if (c == ',') {
            unsigned int target;
            p->pos++;
            target = ((vm->print_column / CBMVM_PRINT_ZONE) + 1u) * CBMVM_PRINT_ZONE;
            while (vm->print_column < target) vm_putc(vm, ' ');
            suppress_newline = 1;
            skip_spaces(p);
            continue;
        }
        suppress_newline = 0;
        break;
    }
    if (!suppress_newline) vm_putc(vm, '\n');
    return 0;
}

static int statement_poke(PARSER *p)
{
    VALUE a, v;
    double ad, val;
    if (parse_expression(p, &a) < 0 || value_to_number(p->vm, &a, &ad) < 0) return -1;
    skip_spaces(p);
    if (p->vm->ram[p->pos] != ',') { vm_syntax_error(p->vm, ", expected"); return -1; }
    p->pos++;
    if (parse_expression(p, &v) < 0 || value_to_number(p->vm, &v, &val) < 0) return -1;
    return cbmvm_poke(p->vm, (uint16_t)((int)ad & 0xffff), (uint8_t)((int)val & 0xff));
}

static int statement_dim(PARSER *p)
{
    char key[CBMVM_MAX_VAR_NAME];
    for (;;) {
        if (parse_variable_reference(p,key,sizeof(key),1)<0) return -1;
        skip_spaces(p);
        if (p->vm->ram[p->pos] != ',') break;
        p->pos++;
    }
    return 0;
}

static int statement_read(PARSER *p)
{
    char name[CBMVM_MAX_VAR_NAME]; VALUE v;
    for (;;) {
        if (parse_variable_reference(p,name,sizeof(name),0)<0) { vm_syntax_error(p->vm,"READ variable expected"); return -1; }
        if (read_data_value(p->vm,name,&v)<0 || set_variable(p->vm,name,&v)<0) return -1;
        skip_spaces(p);
        if (p->vm->ram[p->pos] != ',') break;
        p->pos++;
    }
    return 0;
}

static int statement_restore(PARSER *p)
{
    CBMVM *vm=p->vm; unsigned int i=0;
    skip_spaces(p);
    if (!at_statement_end(p)) {
        uint16_t line;
        if (parse_line_number_expr(p,&line)<0) return -1;
        while (i < vm->data_item_count && vm->data_items[i].line < line) i++;
    }
    vm->data_index=i;
    return 0;
}

static int parse_input_field(const char *s, size_t len, size_t *off, const char **out, size_t *outlen)
{
    size_t i=*off,start; int quoted=0;
    while(i<len && (s[i]==' '||s[i]=='\t'))i++;
    if(i<len && s[i]=='"'){quoted=1;i++;start=i;while(i<len&&s[i]!='"')i++;*out=s+start;*outlen=i-start;if(i<len&&s[i]=='"')i++;while(i<len&&s[i]!=',')i++;}
    else {start=i;while(i<len&&s[i]!=',')i++;while(i>start&&(s[i-1]==' '||s[i-1]=='\t'))i--;*out=s+start;*outlen=i-start;while(i<len&&s[i]!=',')i++;}
    if(i<len&&s[i]==',')i++;
    *off=i; (void)quoted; return 0;
}

static int statement_input(PARSER *p)
{
    CBMVM *vm=p->vm; uint16_t vars_pos; int first = !(vm->input_active && vm->input_statement_pc==vm->pc);
    VALUE prompt; int has_prompt=0;
    skip_spaces(p);
    if (vm->ram[p->pos]=='"') {
        if(parse_expression(p,&prompt)<0 || !prompt.is_string){vm_set_error(vm,"?TYPE MISMATCH ERROR");return -1;}
        skip_spaces(p); if(vm->ram[p->pos]!=';'&&vm->ram[p->pos]!=','){vm_syntax_error(vm,"; expected after INPUT prompt");return -1;} p->pos++; has_prompt=1;
    }
    vars_pos=p->pos;
    if(first){vm->input_active=1;vm->input_statement_pc=vm->pc;vm->input_length=0;if(has_prompt)vm_puts(vm,prompt.string);else vm_puts(vm,"? ");}
    for(;;){int ch=vm->host.getc?vm->host.getc(vm->host.userdata):-1;if(ch<0)return 2;if(ch=='\r'||ch=='\n'){vm_putc(vm,'\n');break;}if(ch==8||ch==127){if(vm->input_length){vm->input_length--;vm_putc(vm,8);}continue;}if(ch>=32&&ch<=255&&(size_t)vm->input_length+1u<sizeof(vm->input_buffer)){vm->input_buffer[vm->input_length++]=(char)ch;vm_putc(vm,ch);}}
    vm->input_buffer[vm->input_length]=0;
    p->pos=vars_pos;
    {size_t off=0;for(;;){char name[CBMVM_MAX_VAR_NAME];const char*field;size_t flen;VALUE v;if(parse_variable_reference(p,name,sizeof(name),0)<0){vm->input_active=0;return-1;}parse_input_field(vm->input_buffer,vm->input_length,&off,&field,&flen);if(value_from_text_for_variable(vm,name,field,flen,&v)<0||set_variable(vm,name,&v)<0){vm->input_active=0;return-1;}skip_spaces(p);if(vm->ram[p->pos]!=',')break;p->pos++;}}
    vm->input_active=0;vm->input_length=0;return 0;
}

static int statement_get(PARSER *p)
{
    CBMVM *vm=p->vm;
    int blocking=0;
    skip_spaces(p);
    /* C128 GETKEY is tokenized as GET followed by KEY ($F9). */
    if(vm->ram[p->pos]==T_KEY){blocking=1;p->pos++;skip_spaces(p);}
    for(;;){
        char name[CBMVM_MAX_VAR_NAME];VALUE v;int ch;
        if(parse_variable_reference(p,name,sizeof(name),0)<0){vm_syntax_error(vm,blocking?"GETKEY variable expected":"GET variable expected");return-1;}
        ch=vm->host.getc?vm->host.getc(vm->host.userdata):-1;
        if(blocking && ch<0) return 2;
        if(strchr(name,'$')){
            if(ch<0)v=value_string("");
            else{unsigned char c=(unsigned char)(ch&255);v=value_blob(&c,1);}
        }else{
            if(ch<0)v=value_number(0.0);
            else if(ch>='0'&&ch<='9')v=value_number((double)(ch-'0'));
            else{vm_set_error(vm,"?TYPE MISMATCH ERROR");return-1;}
        }
        if(set_variable(vm,name,&v)<0)return-1;
        skip_spaces(p);if(vm->ram[p->pos]!=',')break;p->pos++;
    }
    return 0;
}

static int statement_wait(PARSER *p)
{
    VALUE a,m,x;double ad,mask,xorv=0.0;uint8_t b;
    if(parse_expression(p,&a)<0||value_to_number(p->vm,&a,&ad)<0)return-1;
    skip_spaces(p);if(p->vm->ram[p->pos]!=','){vm_syntax_error(p->vm,", expected");return-1;}p->pos++;
    if(parse_expression(p,&m)<0||value_to_number(p->vm,&m,&mask)<0)return-1;
    skip_spaces(p);if(p->vm->ram[p->pos]==','){p->pos++;if(parse_expression(p,&x)<0||value_to_number(p->vm,&x,&xorv)<0)return-1;}
    if(cbmvm_peek(p->vm,(uint16_t)((int)ad&65535),&b)<0)return-1;
    if((((unsigned int)b ^ (unsigned int)((int)xorv&255)) & (unsigned int)((int)mask&255))==0u)return 2;
    return 0;
}

static int statement_on(PARSER *p)
{
    CBMVM *vm=p->vm;VALUE v;double d;int choice,i=1,is_gosub=0;uint16_t chosen=0;
    if(parse_expression(p,&v)<0||value_to_number(vm,&v,&d)<0)return-1;
    choice=(int)d;skip_spaces(p);
    if(vm->ram[p->pos]==T_GOTO){p->pos++;is_gosub=0;}else if(vm->ram[p->pos]==T_GOSUB){p->pos++;is_gosub=1;}else{vm_syntax_error(vm,"GOTO or GOSUB expected after ON");return-1;}
    while(!at_statement_end(p)){uint16_t line;if(parse_line_number_expr(p,&line)<0)return-1;if(i==choice)chosen=line;i++;skip_spaces(p);if(vm->ram[p->pos]!=',')break;p->pos++;}
    if(choice<=0||!chosen)return 0;
    if(is_gosub){uint16_t ret;if(vm->gosub_depth>=CBMVM_GOSUB_DEPTH){vm_set_error(vm,"?OUT OF MEMORY ERROR (GOSUB)");return-1;}ret=statement_delimiter(vm,p->pos);vm->gosub_stack[vm->gosub_depth].return_pc=ret;vm->gosub_stack[vm->gosub_depth].return_line_address=vm->line_address;vm->gosub_stack[vm->gosub_depth].is_interrupt=0;vm->gosub_depth++;}
    return jump_line(vm,chosen)<0?-1:1;
}


static int parse_numeric_fields(PARSER *p, double *v, unsigned char *present, int max_fields)
{
    int n = 0;
    while (n < max_fields && !at_statement_end(p)) {
        VALUE x;
        double d;
        skip_spaces(p);
        if (p->vm->ram[p->pos] == ',') {
            present[n] = 0;
            v[n] = 0.0;
            n++;
            p->pos++;
            continue;
        }
        if (parse_expression(p, &x) < 0 || value_to_number(p->vm, &x, &d) < 0) return -1;
        present[n] = 1;
        v[n] = d;
        n++;
        skip_spaces(p);
        if (p->vm->ram[p->pos] == ',') { p->pos++; continue; }
        break;
    }
    return n;
}


static int parse_decimal_number(const char *s, double *out)
{
    double v=0.0, frac=0.1, scale=1.0;
    int any=0, seen_dot=0, exp=0, exp_sign=1;
    if(!s || !out) return -1;
    while(*s) {
        if(*s>='0' && *s<='9') {
            any=1;
            if(!seen_dot) v=v*10.0+(double)(*s-'0');
            else { v+=(double)(*s-'0')*frac; frac*=0.1; }
            s++; continue;
        }
        if(*s=='.' && !seen_dot) { seen_dot=1; s++; continue; }
        break;
    }
    if(!any) return -1;
    if(*s=='e' || *s=='E') {
        int exp_any=0;
        s++;
        if(*s=='+' || *s=='-') { if(*s=='-') exp_sign=-1; s++; }
        while(*s>='0' && *s<='9') { exp_any=1; if(exp<1000) exp=exp*10+(*s-'0'); s++; }
        if(!exp_any) return -1;
        while(exp-- > 0) scale *= 10.0;
        if(exp_sign<0) v/=scale; else v*=scale;
    }
    if(*s!=0) return -1;
    *out=v;
    return 0;
}

static int int_round(double x)
{
    return cbmvm_round_int(x);
}

static int gfx_x(const CBMVM *vm, double x)
{
    return cbmvm_graphics_scale_x(&vm->graphics,x);
}

static int gfx_y(const CBMVM *vm, double y)
{
    return cbmvm_graphics_scale_y(&vm->graphics,y);
}

static int gfx_x_radius(const CBMVM *vm, double x)
{
    return abs(cbmvm_graphics_scale_x(&vm->graphics,x)-cbmvm_graphics_scale_x(&vm->graphics,0.0));
}

static int gfx_y_radius(const CBMVM *vm, double y)
{
    return abs(cbmvm_graphics_scale_y(&vm->graphics,y)-cbmvm_graphics_scale_y(&vm->graphics,0.0));
}

static int valid_source(CBMVM *vm, int source)
{
    if (source < 0 || source > 3) { vm_syntax_error(vm, "graphics color source must be 0..3"); return -1; }
    if ((vm->graphics.mode == 1 || vm->graphics.mode == 2) && source > 1) {
        vm_syntax_error(vm, "color source 2/3 requires multicolor mode");
        return -1;
    }
    return source;
}

static int statement_graphic(PARSER *p)
{
    CBMVM *vm = p->vm;
    double f[3] = {0,0,0};
    unsigned char has[3] = {0,0,0};
    int n, mode, clear = 0, split = -1;
    skip_spaces(p);
    if (vm->ram[p->pos] == T_CLR) {
        /* The real C128 frees bitmap RAM. CBMVM keeps its compact framebuffer but returns to text mode. */
        p->pos++;
        cbmvm_graphics_set_mode(&vm->graphics, 0, 0, -1);
        if (vm->host.graphics_mode) vm->host.graphics_mode(vm->host.userdata, 0, vm->graphics.split_line);
        vm_graphics_present(vm);
        return 0;
    }
    n = parse_numeric_fields(p, f, has, 3);
    if (n < 1 || !has[0]) { vm_syntax_error(vm, "GRAPHIC mode expected"); return -1; }
    mode = int_round(f[0]);
    if (n > 1 && has[1]) clear = int_round(f[1]) != 0;
    if (n > 2 && has[2]) split = int_round(f[2]);
    if (cbmvm_graphics_set_mode(&vm->graphics, mode, clear, split) < 0) {
        vm_syntax_error(vm, "GRAPHIC mode must be 0..5"); return -1;
    }
    if (vm->host.graphics_mode) vm->host.graphics_mode(vm->host.userdata, mode, vm->graphics.split_line);
    if (clear && vm->host.screen_clear) vm->host.screen_clear(vm->host.userdata);
    vm_graphics_present(vm);
    return 0;
}

static int statement_rgr(PARSER *p)
{
    VALUE v;
    double mode;
    if (at_statement_end(p)) return 0;
    if (parse_expression(p, &v) < 0 || value_to_number(p->vm, &v, &mode) < 0) return -1;
    if (cbmvm_graphics_set_mode(&p->vm->graphics, int_round(mode), 0, -1) < 0) {
        vm_syntax_error(p->vm, "RGR mode must be 0..5"); return -1;
    }
    if (p->vm->host.graphics_mode)
        p->vm->host.graphics_mode(p->vm->host.userdata, p->vm->graphics.mode, p->vm->graphics.split_line);
    vm_graphics_present(p->vm);
    return 0;
}

static int statement_scnclr(PARSER *p)
{
    CBMVM *vm = p->vm;
    int mode=vm->graphics.mode;
    if(!at_statement_end(p)){
        VALUE v;double d;if(parse_expression(p,&v)<0||value_to_number(vm,&v,&d)<0)return -1;mode=int_round(d);
        if(mode<0||mode>5){vm_syntax_error(vm,"SCNCLR mode must be 0..5");return -1;}
    }
    if(mode>=1&&mode<=4) cbmvm_graphics_clear(&vm->graphics,0);
    if (vm->host.screen_clear) vm->host.screen_clear(vm->host.userdata);
    vm_graphics_present(vm);
    return 0;
}

static int statement_color(PARSER *p)
{
    double f[2] = {0,0};
    unsigned char has[2] = {0,0};
    int n = parse_numeric_fields(p, f, has, 2);
    int source, color;
    if (n < 2 || !has[0] || !has[1]) { vm_syntax_error(p->vm, "COLOR source,color expected"); return -1; }
    source = int_round(f[0]); color = int_round(f[1]);
    if (cbmvm_graphics_set_color(&p->vm->graphics, source, color) < 0) {
        vm_syntax_error(p->vm, "COLOR source 0..6 and color 1..16 required"); return -1;
    }
    if (p->vm->host.graphics_color) p->vm->host.graphics_color(p->vm->host.userdata, source, color);
    vm_graphics_present(p->vm);
    return 0;
}

static int statement_locate(PARSER *p)
{
    VALUE vx,vy; double x,y; CBMVM *vm=p->vm;
    if(parse_expression(p,&vx)<0||value_to_number(vm,&vx,&x)<0)return -1;
    skip_spaces(p);if(vm->ram[p->pos]!=','){vm_syntax_error(vm,"LOCATE x,y expected");return -1;}p->pos++;
    if(parse_expression(p,&vy)<0||value_to_number(vm,&vy,&y)<0)return -1;
    vm->graphics.cursor_x=(int16_t)gfx_x(vm,x);
    vm->graphics.cursor_y=(int16_t)gfx_y(vm,y);
    return 0;
}

static int statement_scale(PARSER *p)
{
    double f[3]={0,0,0}; unsigned char has[3]={0,0,0}; int n,on,xmax=0,ymax=0;
    n=parse_numeric_fields(p,f,has,3);
    if(n<1||!has[0]){vm_syntax_error(p->vm,"SCALE on[,xmax,ymax] expected");return -1;}
    on=int_round(f[0]);
    if(n>1&&has[1])xmax=int_round(f[1]);
    if(n>2&&has[2])ymax=int_round(f[2]);
    if(cbmvm_graphics_set_scale(&p->vm->graphics,on,xmax,ymax)<0){vm_syntax_error(p->vm,"SCALE requires 0/1 and xmax>=320,ymax>=200");return -1;}
    return 0;
}

static int statement_width(PARSER *p)
{
    VALUE v;double d;if(parse_expression(p,&v)<0||value_to_number(p->vm,&v,&d)<0)return -1;
    if(cbmvm_graphics_set_width(&p->vm->graphics,int_round(d))<0){vm_syntax_error(p->vm,"WIDTH must be 1 or 2");return -1;}
    return 0;
}

static int statement_draw(PARSER *p)
{
    CBMVM *vm = p->vm;
    int source = vm->graphics.pen_source;
    int x, y;
    skip_spaces(p);
    if (vm->ram[p->pos] == T_TO) {
        x = vm->graphics.cursor_x; y = vm->graphics.cursor_y;
    } else {
        VALUE v;
        double d;
        if (vm->ram[p->pos] == ',') {
            p->pos++;
        } else {
            if (parse_expression(p, &v) < 0 || value_to_number(vm, &v, &d) < 0) return -1;
            source = int_round(d);
            if (valid_source(vm, source) < 0) return -1;
            skip_spaces(p);
            if (vm->ram[p->pos] != ',') { vm_syntax_error(vm, ", expected after DRAW source"); return -1; }
            p->pos++;
        }
        skip_spaces(p);
        if (vm->ram[p->pos] == T_TO) {
            x = vm->graphics.cursor_x; y = vm->graphics.cursor_y;
        } else {
            VALUE vx, vy; double dx, dy;
            if (parse_expression(p, &vx) < 0 || value_to_number(vm, &vx, &dx) < 0) return -1;
            skip_spaces(p); if (vm->ram[p->pos] != ',') { vm_syntax_error(vm, ", expected in DRAW"); return -1; } p->pos++;
            if (parse_expression(p, &vy) < 0 || value_to_number(vm, &vy, &dy) < 0) return -1;
            x = gfx_x(vm, dx); y = gfx_y(vm, dy);
            cbmvm_graphics_put_pixel(&vm->graphics, x, y, (uint8_t)source);
        }
    }
    while (!at_statement_end(p)) {
        VALUE vx, vy; double dx, dy;
        skip_spaces(p);
        if (vm->ram[p->pos] != T_TO) break;
        p->pos++;
        if (parse_expression(p, &vx) < 0 || value_to_number(vm, &vx, &dx) < 0) return -1;
        skip_spaces(p); if (vm->ram[p->pos] != ',') { vm_syntax_error(vm, ", expected after DRAW TO x"); return -1; } p->pos++;
        if (parse_expression(p, &vy) < 0 || value_to_number(vm, &vy, &dy) < 0) return -1;
        cbmvm_graphics_line(&vm->graphics, x, y, gfx_x(vm, dx), gfx_y(vm, dy), (uint8_t)source);
        x = gfx_x(vm, dx); y = gfx_y(vm, dy);
    }
    vm_graphics_present(vm);
    return 0;
}

static int statement_box(PARSER *p)
{
    CBMVM *vm = p->vm;
    double f[7] = {0,0,0,0,0,0,0};
    unsigned char has[7] = {0,0,0,0,0,0,0};
    int n = parse_numeric_fields(p, f, has, 7);
    int source, x1, y1, x2, y2, paint = 0;
    double angle = 0.0;
    if (n < 3 || !has[1] || !has[2]) { vm_syntax_error(vm, "BOX [source],x1,y1[,x2,y2][,angle][,paint]"); return -1; }
    source = has[0] ? int_round(f[0]) : vm->graphics.pen_source;
    if (valid_source(vm, source) < 0) return -1;
    x1 = gfx_x(vm, f[1]); y1 = gfx_y(vm, f[2]);
    x2 = (n > 3 && has[3]) ? gfx_x(vm, f[3]) : vm->graphics.cursor_x;
    y2 = (n > 4 && has[4]) ? gfx_y(vm, f[4]) : vm->graphics.cursor_y;
    if (n > 5 && has[5]) angle = f[5];
    if (n > 6 && has[6]) paint = int_round(f[6]) != 0;
    cbmvm_graphics_box(&vm->graphics, x1, y1, x2, y2, angle, paint, (uint8_t)source);
    vm_graphics_present(vm);
    return 0;
}

static int statement_circle(PARSER *p)
{
    CBMVM *vm = p->vm;
    double f[9] = {0,0,0,0,0,0,0,0,0};
    unsigned char has[9] = {0,0,0,0,0,0,0,0,0};
    int n = parse_numeric_fields(p, f, has, 9);
    int source, cx, cy, xr, yr;
    double sa = 0.0, ea = 360.0, angle = 0.0, inc = 2.0;
    if (n < 4 || !has[1] || !has[2] || !has[3]) { vm_syntax_error(vm, "CIRCLE [source],x,y,xr[,yr][,sa][,ea][,angle][,inc]"); return -1; }
    source = has[0] ? int_round(f[0]) : vm->graphics.pen_source;
    if (valid_source(vm, source) < 0) return -1;
    cx = gfx_x(vm, f[1]); cy = gfx_y(vm, f[2]); xr = gfx_x_radius(vm, f[3]);
    yr = (n > 4 && has[4]) ? gfx_y_radius(vm, f[4]) : gfx_y_radius(vm, f[3]);
    if (n > 5 && has[5]) sa = f[5];
    if (n > 6 && has[6]) ea = f[6];
    if (n > 7 && has[7]) angle = f[7];
    if (n > 8 && has[8]) inc = f[8];
    cbmvm_graphics_circle(&vm->graphics, cx, cy, xr, yr, sa, ea, angle, inc, (uint8_t)source);
    vm_graphics_present(vm);
    return 0;
}

static int statement_paint(PARSER *p)
{
    CBMVM *vm = p->vm;
    double f[4] = {0,0,0,0};
    unsigned char has[4] = {0,0,0,0};
    int n = parse_numeric_fields(p, f, has, 4);
    int source = (n > 0 && has[0]) ? int_round(f[0]) : vm->graphics.pen_source;
    int x = (n > 1 && has[1]) ? gfx_x(vm, f[1]) : vm->graphics.cursor_x;
    int y = (n > 2 && has[2]) ? gfx_y(vm, f[2]) : vm->graphics.cursor_y;
    int mode = (n > 3 && has[3]) ? int_round(f[3]) : 0;
    int rc;
    if (valid_source(vm, source) < 0) return -1;
    rc = cbmvm_graphics_paint(&vm->graphics, x, y, (uint8_t)source, mode);
    if (rc == -2) { vm_set_error(vm, "?PAINT COMPLEXITY ERROR"); return -1; }
    if (rc < 0) { vm_syntax_error(vm, "PAINT coordinate out of range"); return -1; }
    vm_graphics_present(vm);
    return 0;
}

static int statement_char(PARSER *p)
{
    CBMVM *vm = p->vm;
    VALUE a, b, text, rev;
    double source_d, x_d, y_d, rev_d = 0;
    int source;
    if (parse_expression(p, &a) < 0 || value_to_number(vm, &a, &source_d) < 0) return -1;
    skip_spaces(p); if (vm->ram[p->pos] != ',') { vm_syntax_error(vm, "CHAR source,x,y,string expected"); return -1; } p->pos++;
    if (parse_expression(p, &b) < 0 || value_to_number(vm, &b, &x_d) < 0) return -1;
    skip_spaces(p); if (vm->ram[p->pos] != ',') { vm_syntax_error(vm, "CHAR x,y expected"); return -1; } p->pos++;
    if (parse_expression(p, &a) < 0 || value_to_number(vm, &a, &y_d) < 0) return -1;
    skip_spaces(p);
    if (vm->ram[p->pos] == ',') {
        p->pos++;
        if (parse_expression(p, &text) < 0) return -1;
        if (!text.is_string) { vm_syntax_error(vm, "CHAR string expected"); return -1; }
        skip_spaces(p);
        if (vm->ram[p->pos] == ',') {
            p->pos++;
            if (parse_expression(p, &rev) < 0 || value_to_number(vm, &rev, &rev_d) < 0) return -1;
        }
    } else text = value_string("");
    source = int_round(source_d);
    if (valid_source(vm, source) < 0) return -1;
    cbmvm_graphics_text(&vm->graphics, int_round(x_d), int_round(y_d),
                        (const unsigned char *)text.string, text.string_length,
                        (uint8_t)source, int_round(rev_d) != 0);
    vm_graphics_present(vm);
    return 0;
}

static int statement_sshape(PARSER *p)
{
    CBMVM *vm = p->vm;
    char name[CBMVM_MAX_VAR_NAME];
    CBMVM_VARIABLE *var;
    double f[4] = {0,0,0,0};
    unsigned char has[4] = {0,0,0,0};
    int n, x1, y1, x2, y2, w, h, x, y;
    size_t pixels, payload, total, bi;
    unsigned char temp[CBMVM_MAX_STRING];
    if (parse_var_name(p, name, sizeof(name)) < 0 || !strchr(name, '$')) { vm_syntax_error(vm, "SSHAPE string variable expected"); return -1; }
    skip_spaces(p); if (vm->ram[p->pos] != ',') { vm_syntax_error(vm, "SSHAPE variable,x1,y1 expected"); return -1; } p->pos++;
    n = parse_numeric_fields(p, f, has, 4);
    if (n < 2 || !has[0] || !has[1]) { vm_syntax_error(vm, "SSHAPE coordinates expected"); return -1; }
    x1 = gfx_x(vm, f[0]); y1 = gfx_y(vm, f[1]);
    x2 = (n > 2 && has[2]) ? gfx_x(vm, f[2]) : vm->graphics.cursor_x;
    y2 = (n > 3 && has[3]) ? gfx_y(vm, f[3]) : vm->graphics.cursor_y;
    if (x2 < x1) { int t=x1; x1=x2; x2=t; }
    if (y2 < y1) { int t=y1; y1=y2; y2=t; }
    w = x2 - x1 + 1; h = y2 - y1 + 1;
    if (w <= 0 || h <= 0 || w > CBMVM_GFX_WIDTH || h > CBMVM_GFX_HEIGHT) { vm_syntax_error(vm, "SSHAPE area out of range"); return -1; }
    pixels = (size_t)w * (size_t)h;
    payload = (pixels + 3u) / 4u;
    total = 4u + payload;
    if (total >= CBMVM_MAX_STRING) { vm_set_error(vm, "?STRING TOO LONG ERROR (SSHAPE)"); return -1; }
    memset(temp, 0, total);
    temp[0]=(unsigned char)(w & 255); temp[1]=(unsigned char)((w>>8)&255); temp[2]=(unsigned char)h; temp[3]=vm->graphics.mode;
    bi = 0;
    for (y=0; y<h; y++) for (x=0; x<w; x++,bi++) {
        uint8_t src = cbmvm_graphics_get_pixel(&vm->graphics, x1+x, y1+y);
        temp[4u + (bi>>2)] |= (unsigned char)((src & 3u) << ((bi & 3u)*2u));
    }
    var = find_var(vm, name, 1);
    if (!var) { vm_set_error(vm, "?OUT OF MEMORY ERROR"); return -1; }
    memcpy(var->string, temp, total); var->string[total]=0; var->string_length=(uint16_t)total; var->type=CBMVM_VALUE_STRING;
    return 0;
}

static int statement_gshape(PARSER *p)
{
    CBMVM *vm = p->vm;
    char name[CBMVM_MAX_VAR_NAME];
    CBMVM_VARIABLE *var;
    double f[3] = {0,0,0};
    unsigned char has[3] = {0,0,0};
    int n, dx, dy, mode, w, h, x, y;
    size_t bi, required;
    if (parse_var_name(p, name, sizeof(name)) < 0 || !strchr(name, '$')) { vm_syntax_error(vm, "GSHAPE string variable expected"); return -1; }
    var = find_var(vm, name, 0);
    if (!var || var->type != CBMVM_VALUE_STRING || var->string_length < 4) { vm_syntax_error(vm, "GSHAPE invalid shape string"); return -1; }
    skip_spaces(p);
    if (vm->ram[p->pos] == ',') { p->pos++; n = parse_numeric_fields(p, f, has, 3); } else n = 0;
    dx = (n > 0 && has[0]) ? gfx_x(vm, f[0]) : vm->graphics.cursor_x;
    dy = (n > 1 && has[1]) ? gfx_y(vm, f[1]) : vm->graphics.cursor_y;
    mode = (n > 2 && has[2]) ? int_round(f[2]) : 0;
    if (mode < 0 || mode > 4) { vm_syntax_error(vm, "GSHAPE mode must be 0..4"); return -1; }
    w = (unsigned char)var->string[0] | ((unsigned char)var->string[1] << 8);
    h = (unsigned char)var->string[2];
    required = 4u + (((size_t)w*(size_t)h + 3u)/4u);
    if (w <= 0 || h <= 0 || required > var->string_length) { vm_syntax_error(vm, "GSHAPE corrupt shape string"); return -1; }
    bi = 0;
    for (y=0; y<h; y++) for (x=0; x<w; x++,bi++) {
        uint8_t src = ((unsigned char)var->string[4u+(bi>>2)] >> ((bi&3u)*2u)) & 3u;
        uint8_t old = cbmvm_graphics_get_pixel(&vm->graphics, dx+x, dy+y);
        uint8_t out = src;
        if (mode == 1) out = (uint8_t)(3u - src);
        else if (mode == 2) out = (uint8_t)((old | src) & 3u);
        else if (mode == 3) out = (uint8_t)((old & src) & 3u);
        else if (mode == 4) out = (uint8_t)((old ^ src) & 3u);
        cbmvm_graphics_put_pixel(&vm->graphics, dx+x, dy+y, out);
    }
    vm_graphics_present(vm);
    return 0;
}

static int parse_sprite_number(CBMVM *vm, double d)
{
    int n = int_round(d);
    if (n < 1 || n > 8) { vm_syntax_error(vm, "sprite number must be 1..8"); return -1; }
    return n - 1;
}

typedef struct {
    int is_string;
    int sprite_index;
    CBMVM_VARIABLE *var;
} SPRSAV_OPERAND;

static int parse_sprsav_operand(PARSER *p, SPRSAV_OPERAND *op)
{
    CBMVM *vm=p->vm;
    char name[CBMVM_MAX_VAR_NAME];
    VALUE v; double d;
    memset(op,0,sizeof(*op)); op->sprite_index=-1;
    skip_spaces(p);
    if(isalpha((unsigned char)vm->ram[p->pos])){
        uint16_t save=p->pos;
        if(parse_var_name(p,name,sizeof(name))==0 && strchr(name,'$')){
            op->is_string=1; op->var=find_var(vm,name,1);
            if(!op->var){vm_set_error(vm,"?OUT OF MEMORY ERROR");return -1;}
            op->var->type=CBMVM_VALUE_STRING;
            return 0;
        }
        p->pos=save;
    }
    if(parse_expression(p,&v)<0||value_to_number(vm,&v,&d)<0)return -1;
    op->sprite_index=parse_sprite_number(vm,d);
    return op->sprite_index<0?-1:0;
}

static int statement_sprcolor(PARSER *p)
{
    double f[2]={0,0}; unsigned char has[2]={0,0}; int n,i; CBMVM *vm=p->vm;
    n=parse_numeric_fields(p,f,has,2);
    if(n<1){vm_syntax_error(vm,"SPRCOLOR [mc1][,mc2] expected");return -1;}
    for(i=0;i<2;i++) if(i<n&&has[i]){
        int c=int_round(f[i]); if(c<1||c>16){vm_syntax_error(vm,"SPRCOLOR colors must be 1..16");return -1;}
        vm->graphics.sprite_multicolor[i]=(uint8_t)c;
    }
    vm->graphics.generation++;
    if(vm->host.sprite_colors)
        vm->host.sprite_colors(vm->host.userdata,vm->graphics.sprite_multicolor[0],vm->graphics.sprite_multicolor[1]);
    /* Shared sprite colors affect every enabled multicolor sprite. Damage their bounds. */
    for(i=0;i<CBMVM_SPRITE_COUNT;i++) if(vm->graphics.sprites[i].enabled && vm->graphics.sprites[i].multicolor)
        vm_sprite_present(vm,i);
    return 0;
}

static int statement_sprsav(PARSER *p)
{
    SPRSAV_OPERAND a,b; CBMVM *vm=p->vm;
    if(parse_sprsav_operand(p,&a)<0)return -1;
    skip_spaces(p);if(vm->ram[p->pos]!=','){vm_syntax_error(vm,"SPRSAV origin,destination expected");return -1;}p->pos++;
    if(parse_sprsav_operand(p,&b)<0)return -1;
    if(a.is_string&&b.is_string){vm_syntax_error(vm,"SPRSAV cannot copy string to string");return -1;}
    if(!a.is_string&&!b.is_string){
        memcpy(vm->graphics.sprites[b.sprite_index].data,vm->graphics.sprites[a.sprite_index].data,CBMVM_SPRITE_BYTES);
        vm_sprite_present(vm,b.sprite_index); return 0;
    }
    if(!a.is_string&&b.is_string){
        /* CBMVM 67-byte sprite/shape envelope: width, height, mode + 63 bytes. */
        b.var->string[0]=24; b.var->string[1]=0; b.var->string[2]=21; b.var->string[3]=(char)vm->graphics.sprites[a.sprite_index].multicolor;
        memcpy(b.var->string+4,vm->graphics.sprites[a.sprite_index].data,CBMVM_SPRITE_BYTES);
        b.var->string_length=67; b.var->string[67]=0; return 0;
    }
    if(a.var->string_length>=67 && (unsigned char)a.var->string[0]==24 && (unsigned char)a.var->string[2]==21) {
        memcpy(vm->graphics.sprites[b.sprite_index].data,a.var->string+4,CBMVM_SPRITE_BYTES);
        vm->graphics.sprites[b.sprite_index].multicolor=(uint8_t)((unsigned char)a.var->string[3]!=0);
    } else if(a.var->string_length>=CBMVM_SPRITE_BYTES)
        memcpy(vm->graphics.sprites[b.sprite_index].data,a.var->string,CBMVM_SPRITE_BYTES);
    else {vm_syntax_error(vm,"SPRSAV string must contain at least 63 sprite bytes");return -1;}
    vm_sprite_present(vm,b.sprite_index); return 0;
}

static int statement_collision(PARSER *p)
{
    CBMVM *vm=p->vm; VALUE v; double d; int type; uint16_t line=0;
    if(parse_expression(p,&v)<0||value_to_number(vm,&v,&d)<0)return -1;
    type=int_round(d);
    if(type<1||type>2){vm_syntax_error(vm,"COLLISION type must be 1 or 2");return -1;}
    skip_spaces(p);
    if(vm->ram[p->pos]==','){p->pos++;if(parse_line_number_expr(p,&line)<0)return -1;}
    vm->collision_handler[type-1]=line;
    if(!line) vm->collision_pending&=(uint8_t)~(1u<<(type-1));
    return 0;
}

static int statement_sprite(PARSER *p)
{
    CBMVM *vm = p->vm;
    double f[7] = {0,0,0,0,0,0,0};
    unsigned char has[7] = {0,0,0,0,0,0,0};
    int n = parse_numeric_fields(p, f, has, 7);
    int index;
    CBMVM_SPRITE *s;
    if (n < 1 || !has[0]) { vm_syntax_error(vm, "SPRITE number expected"); return -1; }
    index = parse_sprite_number(vm, f[0]); if (index < 0) return -1;
    s = &vm->graphics.sprites[index];
    if (n>1 && has[1]) s->enabled=(uint8_t)(int_round(f[1])!=0);
    if (n>2 && has[2]) { int c=int_round(f[2]); if(c<1||c>16){vm_syntax_error(vm,"sprite color must be 1..16");return -1;} s->color=(uint8_t)c; }
    if (n>3 && has[3]) s->priority=(uint8_t)(int_round(f[3])!=0);
    if (n>4 && has[4]) s->x_expand=(uint8_t)(int_round(f[4])!=0);
    if (n>5 && has[5]) s->y_expand=(uint8_t)(int_round(f[5])!=0);
    if (n>6 && has[6]) s->multicolor=(uint8_t)(int_round(f[6])!=0);
    vm->graphics.generation++;
    vm_sprite_present(vm,index);
    return 0;
}

static int statement_movspr(PARSER *p)
{
    CBMVM *vm=p->vm;
    VALUE v; double d, a, b;
    int index, relative_x=0, relative_y=0;
    skip_spaces(p);
    if (parse_expression(p,&v)<0 || value_to_number(vm,&v,&d)<0) return -1;
    index=parse_sprite_number(vm,d); if(index<0)return -1;
    skip_spaces(p); if(vm->ram[p->pos]!=','){vm_syntax_error(vm,"MOVSPR number,x,y expected");return -1;} p->pos++;
    skip_spaces(p); if(vm->ram[p->pos]==T_PLUS||vm->ram[p->pos]=='+'||vm->ram[p->pos]==T_MINUS||vm->ram[p->pos]=='-') relative_x=1;
    if(parse_expression(p,&v)<0||value_to_number(vm,&v,&a)<0)return -1;
    skip_spaces(p);
    if(vm->ram[p->pos]=='#') {
        p->pos++;
        if(parse_expression(p,&v)<0||value_to_number(vm,&v,&b)<0)return -1;
        vm->graphics.sprites[index].angle=a;
        vm->graphics.sprites[index].speed=b<0?0:b;
        vm->graphics.sprites[index].moving=(uint8_t)(b>0.0);
    } else if(vm->ram[p->pos]==';') {
        /* Polar relative move: distance ; angle. */
        double r;
        p->pos++;
        if(parse_expression(p,&v)<0||value_to_number(vm,&v,&b)<0)return -1;
        r=b*M_PI/180.0;
        a=(double)abs(gfx_x(vm,a)-gfx_x(vm,0.0));
        vm->graphics.sprites[index].x=(int16_t)cbmvm_round_int(vm->graphics.sprites[index].x + sin(r)*a);
        vm->graphics.sprites[index].y=(int16_t)cbmvm_round_int(vm->graphics.sprites[index].y - cos(r)*a);
        vm->graphics.sprites[index].moving=0;
    } else {
        if(vm->ram[p->pos]!=','){vm_syntax_error(vm,"MOVSPR y coordinate expected");return -1;} p->pos++;
        skip_spaces(p); if(vm->ram[p->pos]==T_PLUS||vm->ram[p->pos]=='+'||vm->ram[p->pos]==T_MINUS||vm->ram[p->pos]=='-') relative_y=1;
        if(parse_expression(p,&v)<0||value_to_number(vm,&v,&b)<0)return -1;
        if(relative_x||relative_y) {
            int dx=gfx_x(vm,a)-gfx_x(vm,0.0);
            int dy=gfx_y(vm,b)-gfx_y(vm,0.0);
            vm->graphics.sprites[index].x=(int16_t)(vm->graphics.sprites[index].x + dx);
            vm->graphics.sprites[index].y=(int16_t)(vm->graphics.sprites[index].y + dy);
        } else {
            vm->graphics.sprites[index].x=(int16_t)gfx_x(vm,a);
            vm->graphics.sprites[index].y=(int16_t)gfx_y(vm,b);
        }
        vm->graphics.sprites[index].moving=0;
    }
    vm->graphics.generation++;
    vm_sprite_present(vm,index);
    return 0;
}

static int statement_sprdef(PARSER *p)
{
    CBMVM *vm=p->vm;
    uint8_t data[CBMVM_SPRITE_COUNT][CBMVM_SPRITE_BYTES];
    int i, rc=0;
    (void)p;
    for(i=0;i<CBMVM_SPRITE_COUNT;i++) memcpy(data[i],vm->graphics.sprites[i].data,CBMVM_SPRITE_BYTES);
    /* C128 SPRDEF clears the bitmap work area. */
    cbmvm_graphics_clear(&vm->graphics,0);
    if(vm->host.sprite_editor) rc=vm->host.sprite_editor(vm->host.userdata,data);
    if(rc<0){vm_set_error(vm,"?SPRDEF HOST ERROR");return -1;}
    if(vm->host.sprite_editor) for(i=0;i<CBMVM_SPRITE_COUNT;i++){memcpy(vm->graphics.sprites[i].data,data[i],CBMVM_SPRITE_BYTES);vm_sprite_present(vm,i);}
    vm_graphics_present(vm);
    return 0;
}

static int statement_if(PARSER *p)
{
    VALUE cond;
    uint16_t line, q;
    if (parse_expression(p, &cond) < 0) return -1;
    skip_spaces(p);
    if (p->vm->ram[p->pos] != T_THEN) { vm_syntax_error(p->vm, "THEN expected"); return -1; }
    p->pos++;
    if (!value_truth(&cond)) {
        int quoted=0; q=p->pos;
        while(q<p->vm->program_end){uint8_t c=p->vm->ram[q];if(c=='"')quoted=!quoted;if(!quoted&&c==T_ELSE)break;if(!quoted&&(c==0||c==':')){q=0;break;}q++;}
        if(!q){p->pos=statement_delimiter(p->vm,p->pos);return 0;}
        p->pos=(uint16_t)(q+1);skip_spaces(p);
        if(isdigit((unsigned char)p->vm->ram[p->pos])){if(parse_line_number_expr(p,&line)<0)return-1;return jump_line(p->vm,line)<0?-1:1;}
        return 0;
    }
    skip_spaces(p);
    if (p->vm->ram[p->pos] == T_GOTO) {p->pos++;if(parse_line_number_expr(p,&line)<0)return-1;return jump_line(p->vm,line)<0?-1:1;}
    if (isdigit((unsigned char)p->vm->ram[p->pos])) {if(parse_line_number_expr(p,&line)<0)return-1;return jump_line(p->vm,line)<0?-1:1;}
    /* Statement form: leave PC at the first token after THEN; it executes next. */
    return 0;
}

static int statement_gosub(PARSER *p)
{
    CBMVM *vm = p->vm;
    uint16_t line, ret;
    if (vm->gosub_depth >= CBMVM_GOSUB_DEPTH) { vm_set_error(vm, "?OUT OF MEMORY ERROR (GOSUB)"); return -1; }
    if (parse_line_number_expr(p, &line) < 0) return -1;
    ret = statement_delimiter(vm, p->pos);
    vm->gosub_stack[vm->gosub_depth].return_pc = ret;
    vm->gosub_stack[vm->gosub_depth].return_line_address = vm->line_address;
    vm->gosub_stack[vm->gosub_depth].is_interrupt = 0;
    vm->gosub_depth++;
    return jump_line(vm, line) < 0 ? -1 : 1;
}

static int statement_return(CBMVM *vm)
{
    CBMVM_GOSUB_FRAME f;
    if (!vm->gosub_depth) { vm_set_error(vm, "?RETURN WITHOUT GOSUB ERROR"); return -1; }
    f = vm->gosub_stack[--vm->gosub_depth];
    if (prepare_line(vm, f.return_line_address) < 0) return -1;
    vm->pc = f.return_pc;
    if (f.is_interrupt) vm->collision_in_handler = 0;
    return 1;
}

static int statement_for(PARSER *p)
{
    CBMVM *vm = p->vm;
    char name[CBMVM_MAX_VAR_NAME];
    VALUE start, limit, step;
    double nstart, nlimit, nstep = 1.0;
    uint16_t loop_pc;
    if (vm->for_depth >= CBMVM_FOR_DEPTH) { vm_set_error(vm, "?OUT OF MEMORY ERROR (FOR)"); return -1; }
    if (parse_var_name(p, name, sizeof(name)) < 0) { vm_syntax_error(vm, "FOR variable expected"); return -1; }
    skip_spaces(p);
    if (vm->ram[p->pos] != T_EQ && vm->ram[p->pos] != '=') { vm_syntax_error(vm, "= expected"); return -1; }
    p->pos++;
    if (parse_expression(p, &start) < 0 || value_to_number(vm, &start, &nstart) < 0) return -1;
    skip_spaces(p);
    if (vm->ram[p->pos] != T_TO) { vm_syntax_error(vm, "TO expected"); return -1; }
    p->pos++;
    if (parse_expression(p, &limit) < 0 || value_to_number(vm, &limit, &nlimit) < 0) return -1;
    skip_spaces(p);
    if (vm->ram[p->pos] == T_STEP) {
        p->pos++;
        if (parse_expression(p, &step) < 0 || value_to_number(vm, &step, &nstep) < 0) return -1;
    }
    if (nstep == 0.0) { vm_syntax_error(vm, "STEP cannot be zero"); return -1; }
    start = value_number(nstart);
    if (set_variable(vm, name, &start) < 0) return -1;
    loop_pc = statement_delimiter(vm, p->pos);
    snprintf(vm->for_stack[vm->for_depth].variable, CBMVM_MAX_VAR_NAME, "%s", name);
    vm->for_stack[vm->for_depth].limit = nlimit;
    vm->for_stack[vm->for_depth].step = nstep;
    vm->for_stack[vm->for_depth].loop_pc = loop_pc;
    vm->for_stack[vm->for_depth].loop_line_address = vm->line_address;
    vm->for_depth++;
    p->pos = loop_pc;
    return 0;
}

static int statement_next(PARSER *p)
{
    CBMVM *vm = p->vm;
    char name[CBMVM_MAX_VAR_NAME];
    int idx;
    CBMVM_FOR_FRAME *f;
    CBMVM_VARIABLE *var;
    skip_spaces(p);
    name[0] = 0;
    if (isalpha((unsigned char)vm->ram[p->pos])) parse_var_name(p, name, sizeof(name));
    if (!vm->for_depth) { vm_set_error(vm, "?NEXT WITHOUT FOR ERROR"); return -1; }
    idx = (int)vm->for_depth - 1;
    if (name[0]) {
        while (idx >= 0 && strcmp(vm->for_stack[idx].variable, name) != 0) idx--;
        if (idx < 0) { vm_set_error(vm, "?NEXT WITHOUT FOR ERROR"); return -1; }
    }
    f = &vm->for_stack[idx];
    var = find_var(vm, f->variable, 0);
    if (!var || var->type != CBMVM_VALUE_NUMBER) { vm_set_error(vm, "?FOR STATE ERROR"); return -1; }
    var->number += f->step;
    if ((f->step > 0 && var->number <= f->limit) || (f->step < 0 && var->number >= f->limit)) {
        uint16_t la = f->loop_line_address;
        uint16_t pc = f->loop_pc;
        if (prepare_line(vm, la) < 0) return -1;
        vm->pc = pc;
        return 1;
    }
    vm->for_depth = (unsigned int)idx;
    return 0;
}

static int statement_def(PARSER *p)
{
    CBMVM *vm=p->vm;char name[CBMVM_MAX_VAR_NAME],param[CBMVM_MAX_VAR_NAME];
    CBMVM_FN_DEF *def=NULL;unsigned int i;
    skip_spaces(p);if(vm->ram[p->pos]!=T_FN){vm_syntax_error(vm,"FN expected after DEF");return -1;}p->pos++;
    if(parse_var_name(p,name,sizeof(name))<0 || strchr(name,'$')){vm_syntax_error(vm,"numeric FN name expected");return -1;}
    skip_spaces(p);if(vm->ram[p->pos]!='('){vm_syntax_error(vm,"( expected after FN name");return -1;}p->pos++;
    if(parse_var_name(p,param,sizeof(param))<0 || strchr(param,'$')){vm_syntax_error(vm,"numeric FN parameter expected");return -1;}
    skip_spaces(p);if(vm->ram[p->pos]!=')'){vm_syntax_error(vm,") expected after FN parameter");return -1;}p->pos++;
    skip_spaces(p);if(vm->ram[p->pos]!=T_EQ && vm->ram[p->pos]!='='){vm_syntax_error(vm,"= expected in DEF FN");return -1;}p->pos++;
    skip_spaces(p);if(at_statement_end(p)){vm_syntax_error(vm,"FN expression expected");return -1;}
    for(i=0;i<vm->function_count;i++)if(strcmp(vm->functions[i].name,name)==0){def=&vm->functions[i];break;}
    if(!def){if(vm->function_count>=CBMVM_MAX_FUNCTIONS){vm_set_error(vm,"?OUT OF MEMORY ERROR (DEF FN)");return -1;}def=&vm->functions[vm->function_count++];}
    memset(def,0,sizeof(*def));snprintf(def->name,sizeof(def->name),"%s",name);snprintf(def->parameter,sizeof(def->parameter),"%s",param);def->expression_pc=p->pos;def->line_address=vm->line_address;
    p->pos=statement_delimiter(vm,p->pos);return 0;
}

static int find_matching_loop(CBMVM *vm, uint16_t start_line, uint16_t start_pos,
                              uint16_t *out_line, uint16_t *out_pc)
{
    uint16_t line=start_line,pos=start_pos;
    unsigned int depth=1;
    while(line && line < vm->program_end){
        int quoted=0;
        while(pos < vm->program_end && vm->ram[pos]!=0){
            uint8_t c=vm->ram[pos];
            if(c=='"'){quoted=!quoted;pos++;continue;}
            if(quoted){pos++;continue;}
            if(c==T_REM || c==T_DATA){pos=statement_delimiter(vm,(uint16_t)(pos+1));continue;}
            if(c==T_EXT_FE || c==T_EXT_CE){pos=(uint16_t)(pos+2);continue;}
            if(c==T_DO) depth++;
            else if(c==T_LOOP){
                if(--depth==0){
                    *out_line=line;
                    *out_pc=statement_delimiter(vm,(uint16_t)(pos+1));
                    return 0;
                }
            }
            pos++;
        }
        {uint16_t next=rd16(&vm->ram[line]);if(!next)break;line=next;pos=(uint16_t)(line+4);}
    }
    vm_set_error(vm,"?LOOP NOT FOUND ERROR");
    return -1;
}

static int statement_do(PARSER *p)
{
    CBMVM *vm=p->vm;
    int enter=1;
    uint16_t loop_pc;
    skip_spaces(p);
    if(vm->ram[p->pos]==T_WHILE || vm->ram[p->pos]==T_UNTIL){
        uint8_t mode=vm->ram[p->pos++];VALUE v;double d;
        if(parse_expression(p,&v)<0 || value_to_number(vm,&v,&d)<0)return -1;
        enter=(mode==T_WHILE)?(d!=0.0):(d==0.0);
    }
    loop_pc=statement_delimiter(vm,p->pos);
    if(!enter){
        uint16_t line,after;
        if(find_matching_loop(vm,vm->line_address,loop_pc,&line,&after)<0)return -1;
        if(prepare_line(vm,line)<0)return -1;
        vm->pc=after;
        return 1;
    }
    if(vm->do_depth>=CBMVM_DO_DEPTH){vm_set_error(vm,"?OUT OF MEMORY ERROR (DO)");return -1;}
    vm->do_stack[vm->do_depth].do_pc=vm->pc;
    vm->do_stack[vm->do_depth].do_line_address=vm->line_address;
    vm->do_depth++;
    p->pos=loop_pc;
    return 0;
}

static int statement_loop(PARSER *p)
{
    CBMVM *vm=p->vm;int repeat=1;
    CBMVM_DO_FRAME f;
    if(!vm->do_depth){vm_set_error(vm,"?LOOP WITHOUT DO ERROR");return -1;}
    skip_spaces(p);
    if(vm->ram[p->pos]==T_WHILE || vm->ram[p->pos]==T_UNTIL){
        uint8_t mode=vm->ram[p->pos++];VALUE v;double d;
        if(parse_expression(p,&v)<0 || value_to_number(vm,&v,&d)<0)return -1;
        repeat=(mode==T_WHILE)?(d!=0.0):(d==0.0);
    }
    f=vm->do_stack[vm->do_depth-1];
    if(repeat){
        /* C128 LOOP returns to DO itself so a DO WHILE/UNTIL condition is reevaluated. */
        vm->do_depth--;
        if(prepare_line(vm,f.do_line_address)<0)return -1;
        vm->pc=f.do_pc;
        return 1;
    }
    vm->do_depth--;
    return 0;
}

static int statement_exit(CBMVM *vm)
{
    uint16_t line,after;
    if(!vm->do_depth){vm_set_error(vm,"?EXIT WITHOUT DO ERROR");return -1;}
    if(find_matching_loop(vm,vm->line_address,vm->pc,&line,&after)<0)return -1;
    vm->do_depth--;
    if(prepare_line(vm,line)<0)return -1;
    vm->pc=after;
    return 1;
}

static int execute_statement(CBMVM *vm, PARSER *p)
{
    uint8_t token;
    skip_spaces(p);
    token = vm->ram[p->pos];

    if (token == 0 || token == ':') return 0;
    if (isalpha((unsigned char)token)) return statement_assignment(p);

    p->pos++;
    if (token == T_EXT_FE) {
        uint8_t ext;
        if (p->pos >= vm->program_end) { vm_syntax_error(vm, "truncated BASIC 7 token"); return -1; }
        ext = vm->ram[p->pos++];
        switch (ext) {
            case TFE_MOVSPR: return statement_movspr(p);
            case TFE_SPRITE: return statement_sprite(p);
            case TFE_SPRCOLOR: return statement_sprcolor(p);
            case TFE_SPRSAV: return statement_sprsav(p);
            case TFE_COLLISION: return statement_collision(p);
            case TFE_WIDTH: return statement_width(p);
            case TFE_SPRDEF: return statement_sprdef(p);
            default: { char msg[80]; snprintf(msg,sizeof(msg),"unsupported BASIC 7 token $FE%02X",(unsigned)ext); vm_syntax_error(vm,msg); return -1; }
        }
    }
    switch (token) {
        case T_END:
        case T_STOP:
            vm->halted = 1;
            return 1;
        case T_LET:
            return statement_assignment(p);
        case T_DATA:
            p->pos = statement_delimiter(vm,p->pos);
            return 0;
        case T_INPUT:
            return statement_input(p);
        case T_DIM:
            return statement_dim(p);
        case T_READ:
            return statement_read(p);
        case T_PRINT:
            return statement_print(p);
        case T_GOTO: {
            uint16_t line;
            if (parse_line_number_expr(p, &line) < 0) return -1;
            return jump_line(vm, line) < 0 ? -1 : 1;
        }
        case T_IF:
            return statement_if(p);
        case T_RESTORE:
            return statement_restore(p);
        case T_GOSUB:
            return statement_gosub(p);
        case T_RETURN:
            return statement_return(vm);
        case T_FOR:
            return statement_for(p);
        case T_NEXT:
            return statement_next(p);
        case T_ON:
            return statement_on(p);
        case T_WAIT:
            return statement_wait(p);
        case T_DEF:
            return statement_def(p);
        case T_DO:
            return statement_do(p);
        case T_LOOP:
            return statement_loop(p);
        case T_EXIT:
            return statement_exit(vm);
        case T_POKE:
            return statement_poke(p);
        case T_SYS: {
            VALUE addr; double n; long a;
            if (parse_expression(p,&addr)<0 || value_to_number(vm,&addr,&n)<0) return -1;
            a=(long)n;
            if(a<0 || a>65535L){vm_set_error(vm,"?ILLEGAL QUANTITY ERROR (SYS)");return -1;}
            if(cbmvm_6502_sys(vm,(uint16_t)a)!=CBMVM_OK)return -1;
            return 0;
        }
        case T_GET:
            return statement_get(p);
        case T_RGR:
            return statement_rgr(p); /* CBMVM convenience alias; RGR(x) is the authentic function. */
        case T_GRAPHIC:
            return statement_graphic(p);
        case T_SCNCLR:
            return statement_scnclr(p);
        case T_DRAW:
            return statement_draw(p);
        case T_LOCATE:
            return statement_locate(p);
        case T_SCALE:
            return statement_scale(p);
        case T_BOX:
            return statement_box(p);
        case T_CIRCLE:
            return statement_circle(p);
        case T_PAINT:
            return statement_paint(p);
        case T_CHAR:
            return statement_char(p);
        case T_COLOR:
            return statement_color(p);
        case T_SSHAPE:
            return statement_sshape(p);
        case T_GSHAPE:
            return statement_gshape(p);
        case T_REM:
            p->pos = statement_delimiter(vm, p->pos);
            while (p->pos < vm->program_end && vm->ram[p->pos] != 0) p->pos++;
            return 0;
        case T_CLR:
            memset(vm->variables, 0, sizeof(vm->variables));
            vm->variable_count = 0;
            memset(vm->arrays, 0, sizeof(vm->arrays));
            vm->array_count = 0;
            vm->gosub_depth = 0;
            vm->for_depth = 0;
            vm->do_depth = 0;
            vm->function_count = 0;
            vm->fn_depth = 0;
            return 0;
        case T_RUN:
            vm->gosub_depth = 0;
            vm->for_depth = 0;
            vm->do_depth = 0;
            vm->function_count = 0;
            vm->fn_depth = 0;
            memset(vm->variables, 0, sizeof(vm->variables));
            vm->variable_count = 0;
            memset(vm->arrays, 0, sizeof(vm->arrays));
            vm->array_count = 0;
            vm->data_index = 0;
            vm->input_active = 0;
            return prepare_line(vm, vm->first_line_address) < 0 ? -1 : 1;
        default: {
            char msg[80];
            snprintf(msg, sizeof(msg), "unsupported BASIC token $%02X", (unsigned)token);
            vm_syntax_error(vm, msg);
            return -1;
        }
    }
}

CBMVM *cbmvm_create(const CBMVM_HOST *host)
{
    CBMVM *vm = (CBMVM *)calloc(1, sizeof(CBMVM));
    if (!vm) return NULL;
    vm->ram = (uint8_t *)calloc(1, CBMVM_RAM_SIZE);
    if (!vm->ram) { free(vm); return NULL; }
    vm->ram_size = CBMVM_RAM_SIZE;
    if (host) vm->host = *host;
    cbmvm_reset(vm);
    return vm;
}

void cbmvm_destroy(CBMVM *vm)
{
    if (!vm) return;
    free(vm->ram);
    vm->ram = NULL;
    free(vm);
}

int cbmvm_reset(CBMVM *vm)
{
    if (!vm || !vm->ram) return CBMVM_ERR;
    vm->line_address = vm->first_line_address;
    vm->next_line_address = 0;
    vm->pc = 0;
    vm->line_number = 0;
    vm->halted = 0;
    vm->error = 0;
    vm->instructions = 0;
    vm->variable_count = 0;
    vm->array_count = 0;
    vm->data_index = 0;
    vm->input_active = 0;
    vm->input_length = 0;
    vm->input_statement_pc = 0;
    vm->random_state = 0x12807001u;
    vm->gosub_depth = 0;
    vm->for_depth = 0;
    vm->do_depth = 0;
    vm->function_count = 0;
    vm->fn_depth = 0;
    vm->print_column = 0;
    vm->video_hz = CBMVM_VIDEO_HZ_PAL;
    vm->video_jiffy = 0;
    vm->timer_phase = 0;
    vm->collision_handler[0]=vm->collision_handler[1]=0;
    vm->collision_pending=0; vm->collision_in_handler=0;
    vm->error_message[0] = 0;
    memset(vm->variables, 0, sizeof(vm->variables));
    memset(vm->arrays, 0, sizeof(vm->arrays));
    memset(vm->functions, 0, sizeof(vm->functions));
    cbmvm_graphics_reset(&vm->graphics);
    cbmvm_6502_reset(vm);
    if (vm->first_line_address) return prepare_line(vm, vm->first_line_address);
    return CBMVM_OK;
}

int cbmvm_load_prg(CBMVM *vm, const void *data, size_t length)
{
    const uint8_t *src = (const uint8_t *)data;
    uint16_t load;
    size_t payload;
    if (!vm || !src || length < 6) return CBMVM_ERR;
    load = rd16(src);
    payload = length - 2;
    if ((size_t)load + payload > vm->ram_size) { vm_set_error(vm, "PRG does not fit guest RAM"); return CBMVM_ERR; }
    memset(vm->ram, 0, vm->ram_size);
    memcpy(vm->ram + load, src + 2, payload);
    vm->load_address = load;
    vm->first_line_address = load;
    vm->program_end = (uint16_t)(load + payload);
    if ((size_t)load + payload == 65536u) vm->program_end = 0xffffu;
    if (load != CBMVM_C64_BASIC_START && load != CBMVM_C128_BASIC_START && vm->debug)
        vm_puts(vm, "[CBMVM] warning: unusual BASIC load address\n");
    if (cbmvm_validate_basic_program(vm) < 0) return CBMVM_ERR;
    if (index_data_items(vm) < 0) return CBMVM_ERR;
    return cbmvm_reset(vm);
}

#ifndef JTMOS
int cbmvm_load_prg_file(CBMVM *vm, const char *filename)
{
    FILE *f;
    long n;
    uint8_t *buf;
    int rc;
    if (!filename) return CBMVM_ERR;
    f = fopen(filename, "rb");
    if (!f) { vm_set_error(vm, "cannot open PRG file"); return CBMVM_ERR; }
    if (fseek(f, 0, SEEK_END) != 0 || (n = ftell(f)) < 0 || fseek(f, 0, SEEK_SET) != 0) { fclose(f); vm_set_error(vm, "cannot size PRG file"); return CBMVM_ERR; }
    buf = (uint8_t *)malloc((size_t)n);
    if (!buf) { fclose(f); vm_set_error(vm, "out of host memory"); return CBMVM_ERR; }
    if (fread(buf, 1, (size_t)n, f) != (size_t)n) { free(buf); fclose(f); vm_set_error(vm, "cannot read PRG file"); return CBMVM_ERR; }
    fclose(f);
    rc = cbmvm_load_prg(vm, buf, (size_t)n);
    free(buf);
    return rc;
}
#endif

int cbmvm_validate_basic_program(CBMVM *vm)
{
    uint16_t a;
    unsigned int guard = 0;
    if (!vm || !vm->ram || !vm->first_line_address) return CBMVM_ERR;
    a = vm->first_line_address;
    while (guard++ < 32768u) {
        uint16_t next;
        uint16_t p;
        if ((size_t)a + 4u > vm->ram_size || a >= vm->program_end) { vm_set_error(vm, "invalid BASIC line address"); return CBMVM_ERR; }
        next = rd16(&vm->ram[a]);
        p = (uint16_t)(a + 4);
        while (p < vm->program_end && vm->ram[p] != 0) p++;
        if (p >= vm->program_end) { vm_set_error(vm, "unterminated BASIC line"); return CBMVM_ERR; }
        if (next == 0) return CBMVM_OK;
        if (next <= a || next >= vm->program_end || next < p + 1u) { vm_set_error(vm, "invalid BASIC next-line pointer"); return CBMVM_ERR; }
        a = next;
    }
    vm_set_error(vm, "BASIC line-chain loop");
    return CBMVM_ERR;
}

static int service_collision_interrupt(CBMVM *vm)
{
    int type; uint16_t line;
    if(!vm || vm->collision_in_handler || !vm->collision_pending) return 0;
    for(type=0;type<2;type++) if((vm->collision_pending&(1u<<type)) && vm->collision_handler[type]) break;
    if(type>=2) return 0;
    if(vm->gosub_depth>=CBMVM_GOSUB_DEPTH){vm_set_error(vm,"?OUT OF MEMORY ERROR (COLLISION)");return -1;}
    line=vm->collision_handler[type];
    vm->collision_pending&=(uint8_t)~(1u<<type);
    vm->gosub_stack[vm->gosub_depth].return_pc=vm->pc;
    vm->gosub_stack[vm->gosub_depth].return_line_address=vm->line_address;
    vm->gosub_stack[vm->gosub_depth].is_interrupt=1;
    vm->gosub_depth++; vm->collision_in_handler=1;
    return jump_line(vm,line)<0?-1:1;
}

int cbmvm_step(CBMVM *vm)
{
    PARSER p;
    int rc;
    if (!vm || vm->error) return CBMVM_ERR;
    if (vm->halted) return CBMVM_HALTED;
    if (cbmvm_6502_active(vm)) {
        rc=cbmvm_6502_run(vm,1024);
        if(rc==CBMVM_ERR)return CBMVM_ERR;
        if(rc==CBMVM_YIELDED)return CBMVM_YIELDED;
        return CBMVM_OK;
    }
    rc=service_collision_interrupt(vm);
    if(rc<0)return CBMVM_ERR;

    /* Move over line terminators and colon separators before executing. */
    for (;;) {
        if (vm->pc >= vm->program_end) { vm->halted = 1; return CBMVM_HALTED; }
        if (vm->ram[vm->pc] == ':') { vm->pc++; continue; }
        if (vm->ram[vm->pc] == T_ELSE) { vm->pc = statement_delimiter(vm,(uint16_t)(vm->pc+1)); continue; }
        if (vm->ram[vm->pc] == 0) {
            rc = advance_line(vm);
            if (rc != CBMVM_OK) return rc;
            continue;
        }
        break;
    }

    p.vm = vm;
    p.pos = vm->pc;
    rc = execute_statement(vm, &p);
    if (rc == 2) return CBMVM_YIELDED;
    vm->instructions++;
    if (rc < 0 || vm->error) return CBMVM_ERR;
    if (vm->halted) return CBMVM_HALTED;

    /* rc==1 means the statement changed control flow and already set vm->pc. */
    if (rc == 0) vm->pc = p.pos;

    return CBMVM_OK;
}

int cbmvm_run(CBMVM *vm, unsigned int statement_budget)
{
    unsigned int i;
    int rc;
    if (!statement_budget) statement_budget = CBMVM_DEFAULT_BUDGET;
    for (i = 0; i < statement_budget; i++) {
        rc = cbmvm_step(vm);
        if (rc != CBMVM_OK) return rc;
    }
    if (vm->host.yield) vm->host.yield(vm->host.userdata);
    return CBMVM_YIELDED;
}

int cbmvm_poke(CBMVM *vm, uint16_t address, uint8_t value)
{
    if (!vm || !vm->ram) return CBMVM_ERR;
    vm->ram[address] = value;
    if (vm->host.io_write) vm->host.io_write(vm->host.userdata, address, value);
    return CBMVM_OK;
}

int cbmvm_peek(CBMVM *vm, uint16_t address, uint8_t *value)
{
    uint8_t v;
    if (!vm || !vm->ram || !value) return CBMVM_ERR;
    v = vm->ram[address];
    if (vm->host.io_read) {
        uint8_t io = v;
        if (vm->host.io_read(vm->host.userdata, address, &io) == 0) v = io;
    }
    *value = v;
    return CBMVM_OK;
}

int cbmvm_graphic_mode(const CBMVM *vm)
{
    return vm ? vm->graphics.mode : -1;
}

uint8_t cbmvm_graphic_pixel(const CBMVM *vm, int x, int y)
{
    return vm ? cbmvm_graphics_get_pixel(&vm->graphics, x, y) : 0;
}

const CBMVM_GRAPHICS *cbmvm_graphic_state(const CBMVM *vm)
{
    return vm ? &vm->graphics : NULL;
}

void cbmvm_graphic_tick(CBMVM *vm, unsigned int ticks)
{
    unsigned int t; int i;
    if (!vm) return;
    for(t=0;t<ticks;t++){
        cbmvm_graphics_tick(&vm->graphics,1);
        vm->video_jiffy++;
        if(vm->graphics.bump_sprite && vm->collision_handler[0]) vm->collision_pending|=1u;
        if(vm->graphics.bump_display && vm->collision_handler[1]) vm->collision_pending|=2u;
        for(i=0;i<CBMVM_SPRITE_COUNT;i++) if(vm->graphics.sprites[i].enabled) vm_sprite_present(vm,i);
        if(vm->host.timer_tick) vm->host.timer_tick(vm->host.userdata,vm->video_hz,vm->video_jiffy);
    }
}

int cbmvm_set_video_hz(CBMVM *vm, unsigned int hz)
{
    if(!vm || (hz!=CBMVM_VIDEO_HZ_PAL && hz!=CBMVM_VIDEO_HZ_NTSC)) return CBMVM_ERR;
    vm->video_hz=(uint8_t)hz; vm->timer_phase=0; return CBMVM_OK;
}

unsigned int cbmvm_video_hz(const CBMVM *vm){return vm?vm->video_hz:0;}
uint64_t cbmvm_video_jiffy(const CBMVM *vm){return vm?vm->video_jiffy:0;}
void cbmvm_timer_tick(CBMVM *vm){cbmvm_graphic_tick(vm,1);}

void cbmvm_timer_advance_us(CBMVM *vm, uint64_t elapsed_us)
{
    uint64_t frames;
    if(!vm||!vm->video_hz)return;
    /* SYS/6510 mode advances VIC/CIA time from emulated CPU cycles. */
    if(cbmvm_6502_active(vm))return;
    vm->timer_phase += elapsed_us * (uint64_t)vm->video_hz;
    frames=vm->timer_phase/1000000u; vm->timer_phase%=1000000u;
    while(frames--) cbmvm_timer_tick(vm);
}

const char *cbmvm_last_error(const CBMVM *vm)
{
    return vm ? vm->error_message : "CBMVM is NULL";
}

void cbmvm_set_debug(CBMVM *vm, int enabled)
{
    if (vm) vm->debug = enabled != 0;
}

size_t cbmvm_instance_bytes(const CBMVM *vm)
{
    return vm ? sizeof(*vm) + vm->ram_size : 0;
}

#ifndef JTMOS
static void stdio_putc(void *userdata, int ch)
{
    (void)userdata;
    putchar(ch);
    fflush(stdout);
}

static int stdio_getc(void *userdata)
{
    (void)userdata;
    return getchar();
}

static int stdio_io_write(void *userdata, uint16_t address, uint8_t value)
{
    (void)userdata;
    if (address == C64_BORDER) fprintf(stderr, "[CBMVM] border=%u\n", (unsigned)value);
    else if (address == C64_BG) fprintf(stderr, "[CBMVM] background=%u\n", (unsigned)value);
    return 0;
}

int start_cbmvm_engine(int argc, char **argv)
{
    CBMVM_HOST host;
    CBMVM *vm;
    int rc;
    if (argc < 2) return 1;
    memset(&host, 0, sizeof(host));
    host.putc = stdio_putc;
    host.getc = stdio_getc;
    host.io_write = stdio_io_write;
    vm = cbmvm_create(&host);
    if (!vm) return 2;
    rc = cbmvm_load_prg_file(vm, argv[1]);
    if (rc == CBMVM_OK) {
        do { rc = cbmvm_run(vm, CBMVM_DEFAULT_BUDGET); } while (rc == CBMVM_YIELDED);
    }
    if (rc == CBMVM_ERR) fprintf(stderr, "%s\n", cbmvm_last_error(vm));
    cbmvm_destroy(vm);
    return rc == CBMVM_ERR ? 3 : 0;
}
#else
int start_cbmvm_engine(int argc, char **argv)
{
    (void)argc; (void)argv;
    return CBMVM_ERR;
}
#endif
