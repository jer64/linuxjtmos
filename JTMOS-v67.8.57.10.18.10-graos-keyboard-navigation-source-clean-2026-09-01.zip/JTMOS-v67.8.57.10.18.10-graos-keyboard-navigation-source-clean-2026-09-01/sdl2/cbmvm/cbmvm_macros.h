#ifndef CBMVM_MACROS_H
#define CBMVM_MACROS_H
#define CBMVM_UNUSED(x) ((void)(x))
#endif
