#ifndef CBMVM_C128_THEME_H
#define CBMVM_C128_THEME_H

#include <stdint.h>

/* Commodore 128 / VIC-II compatible 16-colour palette.  The user-facing
 * default theme deliberately uses green border + green text + grey paper. */
enum {
    CBMVM_C128_BLACK = 0,
    CBMVM_C128_WHITE = 1,
    CBMVM_C128_RED = 2,
    CBMVM_C128_CYAN = 3,
    CBMVM_C128_PURPLE = 4,
    CBMVM_C128_GREEN = 5,
    CBMVM_C128_BLUE = 6,
    CBMVM_C128_YELLOW = 7,
    CBMVM_C128_ORANGE = 8,
    CBMVM_C128_BROWN = 9,
    CBMVM_C128_LIGHT_RED = 10,
    CBMVM_C128_DARK_GREY = 11,
    CBMVM_C128_GREY = 12,
    CBMVM_C128_LIGHT_GREEN = 13,
    CBMVM_C128_LIGHT_BLUE = 14,
    CBMVM_C128_LIGHT_GREY = 15
};

#define CBMVM_C128_DEFAULT_BORDER     CBMVM_C128_GREEN
#define CBMVM_C128_DEFAULT_BACKGROUND CBMVM_C128_GREY
#define CBMVM_C128_DEFAULT_TEXT       CBMVM_C128_GREEN

#define CBMVM_VIEW_BORDER 16
#define CBMVM_VIEW_WIDTH  (320 + CBMVM_VIEW_BORDER * 2)
#define CBMVM_VIEW_HEIGHT (200 + CBMVM_VIEW_BORDER * 2)

static const uint8_t cbmvm_c128_rgb[16][3] = {
    {  0,  0,  0}, {255,255,255}, {136,  0,  0}, {170,255,238},
    {204, 68,204}, {  0,204, 85}, {  0,  0,170}, {238,238,119},
    {221,136, 85}, {102, 68,  0}, {255,119,119}, { 51, 51, 51},
    {119,119,119}, {170,255,102}, {  0,136,255}, {187,187,187}
};

static inline uint32_t cbmvm_c128_rgb24(unsigned int index)
{
    const uint8_t *c = cbmvm_c128_rgb[index & 15u];
    return ((uint32_t)c[0] << 16) | ((uint32_t)c[1] << 8) | (uint32_t)c[2];
}

#endif
