# Legacy examples

These are the original 2021 example files, preserved unchanged. Several of the old `.prg` files use inconsistent or malformed BASIC next-line pointers. The new `examples/` files are regenerated as strict standard linked C64 BASIC V2 PRGs by `tools/make_examples.py`.
