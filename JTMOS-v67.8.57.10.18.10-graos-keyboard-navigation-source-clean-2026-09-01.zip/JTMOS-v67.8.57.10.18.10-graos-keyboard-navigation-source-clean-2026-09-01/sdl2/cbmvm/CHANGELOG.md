# CBMVM 0.7 - SYS / 6502 / 6510 compatibility

- BASIC token `$9E` (`SYS`) is implemented.
- Added cooperative NMOS 6502/6510 execution core.
- Added 6510 memory banking and separate C64 color RAM.
- Added VIC-II raster timing, IRQ basis, CIA timer basics and keyboard matrix input.
- Added common undocumented 6502/6510 opcodes used by real C64 software.
- Added VIC-II text/bitmap/sprite frame rendering to SDL2 and JTMOS/GraOS.
- Added `tests/test_sys6502.c` regression coverage for SYS, RTS return, raster waits, banking and undocumented ALR.
- Existing BASIC 7, graphics, sprite, collision and virtual-timer regression suites remain passing.

# CBMVM 0.6 - mandatory BASIC runtime commands

- Added sparse `DIM` arrays with bounds checking and C128-style auto-dimensioning.
- Added indexed `DATA`, `READ` and `RESTORE [line]`.
- Added cooperative `INPUT`, nonblocking `GET`, and C128 `GETKEY` (`GET` + `KEY` tokens).
- Added `ON ... GOTO/GOSUB` and scheduler-friendly `WAIT`.
- Added C128 `ELSE` statement execution.
- Added BASIC 7 `DO`, `LOOP`, `WHILE`, `UNTIL`, and `EXIT`, including nested block skipping.
- Added numeric `DEF FN` / `FN()` user functions with parameter preservation and recursion guard.
- Added standard string functions and math functions (`LEN`, `STR$`, `VAL`, `ASC`, `CHR$`,
  `LEFT$`, `RIGHT$`, `MID$`, `SGN`, `SQR`, `RND`, `LOG`, `EXP`, trigonometry, `FRE`, `POS`, etc.).
- Added dedicated generated PRGs and regression coverage for the new runtime commands.
- Retained bounded/cooperative execution on both Linux/SDL2 and native JTMOS/GraOS.

# CBMVM 0.5 - SDL2/GraOS dual graphics frontend

- Added Linux SDL 2.x graphical frontend under `#ifndef JTMOS`.
- Added native JTMOS/GraOS RGBA32 frontend under `#ifdef JTMOS`.
- Added C128-inspired green-border / green-text / grey-background default theme.
- Added PETSCII text screen, screen/color RAM, bitmap, split-screen and sprite rendering to both hosts.
- Added one Makefile supporting Linux SDL2 and native JTMOS `cbmvm.bin`.
- Moved the integrated port into the JTMOS root `./sdl2/cbmvm/` tree.

# Changelog

## 0.4 (2026-09-01)

- Added a ROM-free, clean-room 8x8 PETSCII/C128-compatible character renderer for `CHAR`.
- Added `LOCATE`, `RDOT`, `RCLR`, `SCALE`, and `WIDTH` with C128-style token decoding.
- Added `SPRCOLOR`, `SPRSAV`, `RSPRITE`, `RSPPOS`, and `RSPCOLOR`.
- Added sprite-sprite and sprite-bitmap collision detection.
- Added read-and-clear `BUMP(1)` / `BUMP(2)` collision registers.
- Added `COLLISION type[,line]` handlers dispatched as BASIC GOSUB-style interrupts at statement boundaries.
- Added bitmap dirty rectangles and sprite old/new damage rectangles for efficient GraOS compositing.
- Added deterministic PAL 50 Hz / NTSC 60 Hz VM clock APIs and a JTMOS monotonic-microsecond adapter.
- Added advanced graphics, collision, SPRSAV and virtual-timer PRG fixtures and regression tests.
- Added JTMOS timer/damage bindings while retaining the older full-frame presentation fallback.
- Current 64-bit per-VM allocation is 121,648 bytes, including 64 KiB guest RAM and the graphics state.

## 0.3 (2026-08-31)

- Added packed 320x200 virtual graphics framebuffer.
- Added BASIC 7.0 `GRAPHIC`, `RGR`, `SCNCLR`, `DRAW`, `BOX`, `CIRCLE`, `PAINT`, `CHAR`, `COLOR`, `SSHAPE` and `GSHAPE`.
- Added C128 extended-token parsing for `MOVSPR`, `SPRITE` and `SPRDEF`.
- Added eight virtual sprite states, 63-byte sprite patterns and host-timed movement.
- Added JTMOS/GraOS graphics-present, mode/color, sprite and interactive sprite-editor callbacks.
- Made BASIC strings binary-safe and increased their usable capacity to 255 bytes.
- Added BASIC 7 PRG generator examples, graphics/sprite regression tests and a PPM demo renderer.

## 0.2 (2026-08-31)

- Rebuilt interpreter core around standard PRG linked lines.
- Reduced pre-graphics per-VM memory to roughly 87 KiB including 64 KiB guest RAM.
- Added host callback abstraction and JTMOS/GraOS adapter.
- Added cooperative `step/run` execution budget.
- Added expression precedence, variables and string values.
- Added GOTO/IF, GOSUB/RETURN, FOR/NEXT, POKE/PEEK and other core BASIC statements.
- Added strict program validation and regression tests.
- Preserved original examples under `legacy_examples/` and generated corrected standard examples.
