#include <stdio.h>
#include "about_cbmvm.h"

int about_cbmvm(void)
{
    printf("CBMVM 0.7 - C128 BASIC 7 + 6502/6510 SYS VM for Linux/SDL2 and JTMOS/GraOS.\n");
    printf("Usage: cbmvm program.prg\n");
    printf("The PRG must contain a standard linked BASIC program image.\n");
    return 0;
}
