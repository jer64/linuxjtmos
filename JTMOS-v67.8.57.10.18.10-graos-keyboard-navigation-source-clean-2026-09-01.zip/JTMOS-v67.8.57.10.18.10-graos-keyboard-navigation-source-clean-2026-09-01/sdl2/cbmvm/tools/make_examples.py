#!/usr/bin/env python3
"""Generate valid C64 BASIC V2 PRGs used by CBMVM tests."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / 'examples'

LOAD = 0x0801
TOK = {
    'END':0x80,'FOR':0x81,'NEXT':0x82,'DATA':0x83,'INPUT':0x85,'DIM':0x86,'READ':0x87,'LET':0x88,'GOTO':0x89,'IF':0x8b,'RESTORE':0x8c,
    'GOSUB':0x8d,'RETURN':0x8e,'DEF':0x96,'POKE':0x97,'PRINT':0x99,
    'ON':0x91,'WAIT':0x92,'GET':0xa1,
    'TO':0xa4,'FN':0xa5,'THEN':0xa7,'STEP':0xa9,'PLUS':0xaa,'MUL':0xac,'EQ':0xb2,
    'GT':0xb1,'LT':0xb3,'SGN':0xb4,'INT':0xb5,'ABS':0xb6,'SQR':0xba,'RND':0xbb,'PEEK':0xc2,
    'LEN':0xc3,'STR':0xc4,'VAL':0xc5,'ASC':0xc6,'CHR':0xc7,'LEFT':0xc8,'RIGHT':0xc9,'MID':0xca,
    'RGR':0xcc,'ELSE':0xd5,'GRAPHIC':0xde,'PAINT':0xdf,
    'CHAR':0xe0,'BOX':0xe1,'CIRCLE':0xe2,'GSHAPE':0xe3,'SSHAPE':0xe4,
    'DRAW':0xe5,'LOCATE':0xe6,'COLOR':0xe7,'SCNCLR':0xe8,'SCALE':0xe9,
    'DO':0xeb,'LOOP':0xec,'EXIT':0xed,'KEY':0xf9,'UNTIL':0xfc,'WHILE':0xfd,
    'RCLR':0xcd,'RDOT':0xd0,
}

def prg(lines, load=LOAD):
    chunks=[]
    address=load
    bodies=[]
    for line_no, body in lines:
        body=bytes(body)
        size=2+2+len(body)+1
        next_addr=address+size
        bodies.append((address,next_addr,line_no,body))
        address=next_addr
    out=bytearray((load & 255, load >> 8))
    for i,(address,next_addr,line_no,body) in enumerate(bodies):
        nxt=0 if i == len(bodies)-1 else next_addr
        out += bytes((nxt & 255, nxt >> 8, line_no & 255, line_no >> 8))
        out += body + b'\0'
    return bytes(out)

def A(s): return s.encode('ascii')

def write(name, lines, load=LOAD):
    (EXAMPLES / name).write_bytes(prg(lines, load))

def EXT(code): return bytes((0xfe, code))
def CEF(code): return bytes((0xce, code))

write('hello.prg', [
    (10, bytes([TOK['PRINT']])+A(' "HELLO WORLD"')),
    (20, bytes([TOK['END']])),
])
write('counting.prg', [
    (10, A('A')+bytes([TOK['EQ']])+A('0')),
    (20, bytes([TOK['PRINT']])+A(' A')),
    (30, A('A')+bytes([TOK['EQ']])+A('A')+bytes([TOK['PLUS']])+A('1')),
    (40, bytes([TOK['IF']])+A(' A')+bytes([TOK['GT']])+A('5 ')+bytes([TOK['THEN']])+A(' 60')),
    (50, bytes([TOK['GOTO']])+A(' 20')),
    (60, bytes([TOK['END']])),
])
write('printdemo1.prg', [
    (10, bytes([TOK['PRINT']])+A(' "HELLO WORLD"')),
    (20, bytes([TOK['POKE']])+A(' 53280,7')),
    (30, bytes([TOK['POKE']])+A(' 53281,0')),
    (40, bytes([TOK['END']])),
])
write('printdemo2.prg', [
    (10, bytes([TOK['PRINT']])+A(' "hello world ";')),
    (20, bytes([TOK['PRINT']])+A(' "again"')),
    (30, bytes([TOK['END']])),
])
write('fornext.prg', [
    (10, bytes([TOK['FOR']])+A(' I')+bytes([TOK['EQ']])+A('1 ')+bytes([TOK['TO']])+A(' 3')),
    (20, bytes([TOK['PRINT']])+A(' I')),
    (30, bytes([TOK['NEXT']])+A(' I')),
    (40, bytes([TOK['END']])),
])
write('gosub.prg', [
    (10, bytes([TOK['GOSUB']])+A(' 100')),
    (20, bytes([TOK['PRINT']])+A(' "DONE"')),
    (30, bytes([TOK['END']])),
    (100, bytes([TOK['PRINT']])+A(' "SUB"')),
    (110, bytes([TOK['RETURN']])),
])
write('peekpoke.prg', [
    (10, bytes([TOK['POKE']])+A(' 1000,42')),
    (20, bytes([TOK['PRINT']])+A(' ')+bytes([TOK['PEEK']])+A('(1000)')),
    (30, bytes([TOK['END']])),
])

write('math.prg', [
    (10, A('A')+bytes([TOK['EQ']])+A('2')+bytes([TOK['PLUS']])+A('3')+bytes([TOK['MUL']])+A('4')),
    (20, bytes([TOK['PRINT']])+A(' A')),
    (30, bytes([TOK['END']])),
])
write('forstep.prg', [
    (10, bytes([TOK['FOR']])+A(' I')+bytes([TOK['EQ']])+A('5 ')+bytes([TOK['TO']])+A(' 1 ')+bytes([TOK['STEP']])+A(' -2')),
    (20, bytes([TOK['PRINT']])+A(' I')),
    (30, bytes([TOK['NEXT']])+A(' I')),
    (40, bytes([TOK['END']])),
])
write('infinite.prg', [
    (10, bytes([TOK['GOTO']])+A(' 10')),
])

write('core_commands.prg', [
    (10, bytes([TOK['DIM']])+A(' A(2),B$(1)')),
    (20, bytes([TOK['DATA']])+A(' 10,20,30,"HELLO","WORLD"')),
    (30, bytes([TOK['READ']])+A(' A(0),A(1),A(2),B$(0),B$(1)')),
    (40, bytes([TOK['RESTORE']])),
    (50, bytes([TOK['READ']])+A(' X')),
    (60, bytes([TOK['ON']])+A(' 2 ')+bytes([TOK['GOSUB']])+A(' 200,300')),
    (70, bytes([TOK['PRINT']])+A(' A(0);",";A(1);",";A(2);",";B$(0);",";B$(1);",";X')),
    (80, bytes([TOK['PRINT'],TOK['LEN']])+A('(B$(0));",";')+bytes([TOK['LEFT']])+A('(B$(1),3);",";')+bytes([TOK['RIGHT']])+A('(B$(1),2);",";')+bytes([TOK['MID']])+A('(B$(1),2,3)')),
    (90, bytes([TOK['IF']])+A(' 0 ')+bytes([TOK['THEN'],TOK['PRINT']])+A(' "BAD" ')+bytes([TOK['ELSE'],TOK['PRINT']])+A(' "ELSEOK"')),
    (100, bytes([TOK['PRINT'],TOK['SGN']])+A('(-4);",";')+bytes([TOK['INT']])+A('(3.8);",";')+bytes([TOK['ABS']])+A('(-2);",";')+bytes([TOK['SQR']])+A('(9)')),
    (105, bytes([TOK['DEF'],TOK['FN']])+A(' F(X)')+bytes([TOK['EQ']])+A('X')+bytes([TOK['MUL']])+A('X')+bytes([TOK['PLUS']])+A('1')),
    (107, bytes([TOK['PRINT']])+A(' "FN:";')+bytes([TOK['FN']])+A(' F(4);":X:";X')),
    (110, bytes([TOK['END']])),
    (200, bytes([TOK['PRINT']])+A(' "BADON"')),
    (210, bytes([TOK['RETURN']])),
    (300, bytes([TOK['PRINT']])+A(' "ONOK"')),
    (310, bytes([TOK['RETURN']])),
])

write('input_get.prg', [
    (10, bytes([TOK['INPUT']])+A(' "NAME";N$,A')),
    (20, bytes([TOK['GET']])+A(' K$')),
    (30, bytes([TOK['PRINT']])+A(' N$;":";A;":";K$')),
    (40, bytes([TOK['END']])),
])


write('structured_commands.prg', [
    (10, A('A')+bytes([TOK['EQ']])+A('0')),
    (20, bytes([TOK['DO'],TOK['WHILE']])+A(' A')+bytes([TOK['LT']])+A('3')),
    (30, A('A')+bytes([TOK['EQ']])+A('A')+bytes([TOK['PLUS']])+A('1')),
    (40, bytes([TOK['LOOP']])),
    (50, bytes([TOK['PRINT']])+A(' "DOWHILE:";A')),
    (60, A('B')+bytes([TOK['EQ']])+A('0')),
    (70, bytes([TOK['DO']])),
    (80, A('B')+bytes([TOK['EQ']])+A('B')+bytes([TOK['PLUS']])+A('1')),
    (90, bytes([TOK['IF']])+A(' B')+bytes([TOK['EQ']])+A('2 ')+bytes([TOK['THEN'],TOK['EXIT']])),
    (100, bytes([TOK['LOOP']])),
    (110, bytes([TOK['PRINT']])+A(' "EXIT:";B')),
    (120, A('C')+bytes([TOK['EQ']])+A('0')),
    (130, bytes([TOK['DO']])),
    (140, A('C')+bytes([TOK['EQ']])+A('C')+bytes([TOK['PLUS']])+A('1')),
    (150, bytes([TOK['LOOP'],TOK['UNTIL']])+A(' C')+bytes([TOK['EQ']])+A('2')),
    (160, bytes([TOK['PRINT']])+A(' "UNTIL:";C')),
    (170, A('D')+bytes([TOK['EQ']])+A('0')),
    (180, bytes([TOK['DO'],TOK['UNTIL']])+A(' 1')),
    (190, bytes([TOK['DO']])),
    (200, A('D')+bytes([TOK['EQ']])+A('99')),
    (210, bytes([TOK['LOOP']])),
    (220, bytes([TOK['LOOP']])),
    (230, bytes([TOK['PRINT']])+A(' "SKIP:";D')),
    (240, A('E')+bytes([TOK['EQ']])+A('0')),
    (250, bytes([TOK['DO']])),
    (260, A('F')+bytes([TOK['EQ']])+A('0')),
    (270, bytes([TOK['DO']])),
    (280, A('F')+bytes([TOK['EQ']])+A('F')+bytes([TOK['PLUS']])+A('1')),
    (290, bytes([TOK['IF']])+A(' F')+bytes([TOK['EQ']])+A('1 ')+bytes([TOK['THEN'],TOK['EXIT']])),
    (300, bytes([TOK['LOOP']])),
    (310, A('E')+bytes([TOK['EQ']])+A('E')+bytes([TOK['PLUS']])+A('1')),
    (320, bytes([TOK['LOOP'],TOK['UNTIL']])+A(' E')+bytes([TOK['EQ']])+A('2')),
    (330, bytes([TOK['PRINT']])+A(' "NEST:";E')),
    (340, bytes([TOK['END']])),
])

write('getkey.prg', [
    (10, bytes([TOK['GET'],TOK['KEY']])+A(' K$')),
    (20, bytes([TOK['PRINT']])+A(' "KEY:";K$')),
    (30, bytes([TOK['END']])),
])


# C128 BASIC 7.0 graphics / sprite demo. These use the real extension token bytes.

write('sprdef.prg', [
    (10, EXT(0x1d)),
    (20, bytes([TOK['END']])),
], load=0x1c01)

write('scnclr.prg', [
    (10, bytes([TOK['GRAPHIC']])+A(' 1,1')),
    (20, bytes([TOK['DRAW']])+A(' 1,10,10')),
    (30, bytes([TOK['SCNCLR']])),
    (40, bytes([TOK['END']])),
], load=0x1c01)
write('graphics_demo.prg', [
    (10, bytes([TOK['COLOR']])+A(' 0,1')),
    (20, bytes([TOK['COLOR']])+A(' 1,2')),
    (30, bytes([TOK['COLOR']])+A(' 4,7')),
    (40, bytes([TOK['GRAPHIC']])+A(' 1,1')),
    (50, bytes([TOK['BOX']])+A(' 1,5,5,314,194')),
    (60, bytes([TOK['CIRCLE']])+A(' 1,160,95,50,30')),
    (70, bytes([TOK['PAINT']])+A(' 1,160,95')),
    (80, bytes([TOK['DRAW']])+A(' 1,20,170 ')+bytes([TOK['TO']])+A(' 300,170 ')+bytes([TOK['TO']])+A(' 160,20 ')+bytes([TOK['TO']])+A(' 20,170')),
    (90, bytes([TOK['CHAR']])+A(' 1,8,22,"JTMOS BASIC 7"')),
    (100, bytes([TOK['BOX']])+A(' 1,145,75,168,95,0,1')),
    (110, bytes([TOK['SSHAPE']])+A(' A$,145,75,168,95')),
    (120, bytes([TOK['GSHAPE']])+A(' A$,250,30,4')),
    (130, EXT(0x07)+A(' 1,1,3,0,0,0,0')),
    (140, EXT(0x06)+A(' 1,100,80')),
    (150, bytes([TOK['PRINT'],TOK['RGR']])+A('(0)')),
    (160, bytes([TOK['END']])),
], load=0x1c01)

write('sprite_motion.prg', [
    (10, EXT(0x07)+A(' 1,1,3,0,0,0,0')),
    (20, EXT(0x06)+A(' 1,100,80')),
    (30, EXT(0x06)+A(' 1,90#2')),
    (40, bytes([TOK['END']])),
], load=0x1c01)


write('graphics_advanced.prg', [
    (10, bytes([TOK['GRAPHIC']])+A(' 1,1')),
    (20, bytes([TOK['SCALE']])+A(' 1,1000,1000')),
    (30, bytes([TOK['LOCATE']])+A(' 500,500')),
    (40, bytes([TOK['PRINT'],TOK['RDOT']])+A('(0);" ";')+bytes([TOK['RDOT']])+A('(1)')),
    (50, EXT(0x1c)+A(' 2')),
    (60, bytes([TOK['DRAW']])+A(' 1,0,0 ')+bytes([TOK['TO']])+A(' 1000,1000')),
    (65, bytes([TOK['DRAW']])+A(' 1,100,100 ')+bytes([TOK['TO']])+A(' 120,120')),
    (70, bytes([TOK['COLOR']])+A(' 2,5')),
    (80, bytes([TOK['PRINT'],TOK['RCLR']])+A('(2)')),
    (90, EXT(0x08)+A(' 6,8')),
    (100, bytes([TOK['PRINT']])+CEF(0x07)+A('(1);" ";')+CEF(0x07)+A('(2)')),
    (110, EXT(0x07)+A(' 1,1,3,0,1,0,1')),
    (120, EXT(0x06)+A(' 1,500,500')),
    (130, bytes([TOK['PRINT']])+CEF(0x05)+A('(1,0);" ";')+CEF(0x06)+A('(1,3)')),
    (140, bytes([TOK['END']])),
], load=0x1c01)


write('sprsav.prg', [
    (10, EXT(0x07)+A(' 1,1,3')),
    (20, EXT(0x16)+A(' 1,A$')),
    (30, EXT(0x16)+A(' A$,2')),
    (40, bytes([TOK['END']])),
], load=0x1c01)

write('collision_irq.prg', [
    (10, EXT(0x17)+A(' 1,100')),
    (20, bytes([TOK['GOTO']])+A(' 20')),
    (100, A('A')+bytes([TOK['EQ']])+A('A')+bytes([TOK['PLUS']])+A('1')),
    (110, bytes([TOK['RETURN']])),
], load=0x1c01)

print('generated', len(list(EXAMPLES.glob('*.prg'))), 'PRG files')
