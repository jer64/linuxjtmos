#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cbmvm_engine.h"

static const unsigned char palette[16][3] = {
    {0,0,0},{255,255,255},{136,0,0},{170,255,238},
    {204,68,204},{0,204,85},{0,0,170},{238,238,119},
    {221,136,85},{102,68,0},{255,119,119},{51,51,51},
    {119,119,119},{170,255,102},{0,136,255},{187,187,187}
};

int main(int argc, char **argv)
{
    CBMVM *vm;
    CBMVM_HOST host;
    const CBMVM_GRAPHICS *g;
    FILE *f;
    int rc,x,y;
    const char *input = argc > 1 ? argv[1] : "examples/graphics_demo.prg";
    const char *output = argc > 2 ? argv[2] : "examples/graphics_demo.ppm";
    memset(&host,0,sizeof(host));
    vm=cbmvm_create(&host);
    if(!vm) return 1;
    if(cbmvm_load_prg_file(vm,input)!=CBMVM_OK){fprintf(stderr,"%s\n",cbmvm_last_error(vm));return 2;}
    do { rc=cbmvm_run(vm,10000); } while(rc==CBMVM_YIELDED);
    if(rc==CBMVM_ERR){fprintf(stderr,"%s\n",cbmvm_last_error(vm));return 3;}
    g=cbmvm_graphic_state(vm);
    f=fopen(output,"wb"); if(!f) return 4;
    fprintf(f,"P6\n%d %d\n255\n",CBMVM_GFX_WIDTH,CBMVM_GFX_HEIGHT);
    for(y=0;y<CBMVM_GFX_HEIGHT;y++) for(x=0;x<CBMVM_GFX_WIDTH;x++) {
        unsigned int source=cbmvm_graphic_pixel(vm,x,y);
        unsigned int color=(g->color[source]?g->color[source]:1)-1u;
        fwrite(palette[color&15u],1,3,f);
    }
    fclose(f);
    cbmvm_destroy(vm);
    return 0;
}
