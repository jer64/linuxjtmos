#ifndef CBMVM_VICII_H
#define CBMVM_VICII_H
#include <stddef.h>
#include <stdint.h>
#define CBMVM_VICII_WIDTH 320
#define CBMVM_VICII_HEIGHT 200
#define CBMVM_VICII_PIXELS (CBMVM_VICII_WIDTH*CBMVM_VICII_HEIGHT)
void cbmvm_vicii_render(const uint8_t *ram,size_t ram_size,const uint8_t color_ram[0x400],const uint8_t vic[0x40],uint8_t cia2_porta,uint8_t out[CBMVM_VICII_PIXELS]);
#endif
