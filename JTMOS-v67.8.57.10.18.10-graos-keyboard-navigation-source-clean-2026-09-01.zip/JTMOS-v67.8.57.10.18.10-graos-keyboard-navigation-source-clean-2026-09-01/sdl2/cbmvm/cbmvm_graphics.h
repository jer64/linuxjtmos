#ifndef CBMVM_GRAPHICS_H
#define CBMVM_GRAPHICS_H

#include <stddef.h>
#include <stdint.h>

#define CBMVM_GFX_WIDTH 320
#define CBMVM_GFX_HEIGHT 200
#define CBMVM_GFX_PIXELS (CBMVM_GFX_WIDTH * CBMVM_GFX_HEIGHT)
#define CBMVM_GFX_PACKED_BYTES (CBMVM_GFX_PIXELS / 4)
#define CBMVM_GFX_COLOR_SOURCES 7
#define CBMVM_SPRITE_COUNT 8
#define CBMVM_SPRITE_BYTES 63
#define CBMVM_VIDEO_HZ_PAL 50
#define CBMVM_VIDEO_HZ_NTSC 60

typedef struct {
    uint8_t enabled;
    uint8_t color;       /* BASIC color 1..16 */
    uint8_t priority;
    uint8_t x_expand;
    uint8_t y_expand;
    uint8_t multicolor;
    int16_t x;
    int16_t y;
    double angle;
    double speed;
    uint8_t moving;
    uint8_t data[CBMVM_SPRITE_BYTES];

    /* Host-compositor bookkeeping for dirty sprite rectangles. */
    int16_t presented_x;
    int16_t presented_y;
    uint8_t presented_w;
    uint8_t presented_h;
    uint8_t presented_valid;
} CBMVM_SPRITE;

typedef struct {
    uint8_t mode;        /* GRAPHIC 0..5 */
    uint8_t split_line;  /* split-screen text start */
    uint8_t color[CBMVM_GFX_COLOR_SOURCES]; /* BASIC colors 1..16 */
    uint8_t pen_source;  /* 0..3 */
    int16_t cursor_x;    /* physical bitmap pixel cursor */
    int16_t cursor_y;

    uint8_t scale_enabled;
    uint16_t scale_xmax;
    uint16_t scale_ymax;
    uint8_t line_width;  /* WIDTH 1 or 2 */

    uint8_t sprite_multicolor[2]; /* BASIC colors 1..16 */
    uint8_t bump_sprite;
    uint8_t bump_display;

    uint8_t pixels[CBMVM_GFX_PACKED_BYTES]; /* four 2-bit source pixels per byte */
    CBMVM_SPRITE sprites[CBMVM_SPRITE_COUNT];

    /* Damage tracking for GraOS. Inclusive rectangle. */
    uint8_t dirty_valid;
    int16_t dirty_x1;
    int16_t dirty_y1;
    int16_t dirty_x2;
    int16_t dirty_y2;

    uint32_t generation;
} CBMVM_GRAPHICS;

void cbmvm_graphics_reset(CBMVM_GRAPHICS *g);
void cbmvm_graphics_clear(CBMVM_GRAPHICS *g, uint8_t source);
int cbmvm_graphics_set_mode(CBMVM_GRAPHICS *g, int mode, int clear, int split_line);
int cbmvm_graphics_set_color(CBMVM_GRAPHICS *g, int source, int color);
int cbmvm_graphics_set_scale(CBMVM_GRAPHICS *g, int enabled, int xmax, int ymax);
int cbmvm_graphics_set_width(CBMVM_GRAPHICS *g, int width);
int cbmvm_graphics_scale_x(const CBMVM_GRAPHICS *g, double x);
int cbmvm_graphics_scale_y(const CBMVM_GRAPHICS *g, double y);
int cbmvm_graphics_unscale_x(const CBMVM_GRAPHICS *g, int x);
int cbmvm_graphics_unscale_y(const CBMVM_GRAPHICS *g, int y);

uint8_t cbmvm_graphics_get_pixel(const CBMVM_GRAPHICS *g, int x, int y);
void cbmvm_graphics_put_pixel(CBMVM_GRAPHICS *g, int x, int y, uint8_t source);
void cbmvm_graphics_line(CBMVM_GRAPHICS *g, int x0, int y0, int x1, int y1, uint8_t source);
void cbmvm_graphics_box(CBMVM_GRAPHICS *g, int x1, int y1, int x2, int y2,
                        double angle, int paint, uint8_t source);
void cbmvm_graphics_circle(CBMVM_GRAPHICS *g, int cx, int cy, int xr, int yr,
                           double start_angle, double end_angle, double rotation,
                           double increment, uint8_t source);
int cbmvm_graphics_paint(CBMVM_GRAPHICS *g, int x, int y, uint8_t source, int mode);
void cbmvm_graphics_char(CBMVM_GRAPHICS *g, int column, int row, unsigned char ch,
                         uint8_t source, int reverse);
void cbmvm_graphics_text(CBMVM_GRAPHICS *g, int column, int row,
                         const unsigned char *text, size_t length,
                         uint8_t source, int reverse);

void cbmvm_graphics_mark_dirty(CBMVM_GRAPHICS *g, int x1, int y1, int x2, int y2);
void cbmvm_graphics_mark_all_dirty(CBMVM_GRAPHICS *g);
int cbmvm_graphics_take_dirty(CBMVM_GRAPHICS *g, int *x, int *y, int *w, int *h);

void cbmvm_graphics_tick(CBMVM_GRAPHICS *g, unsigned int ticks);
void cbmvm_graphics_detect_collisions(CBMVM_GRAPHICS *g);
uint8_t cbmvm_graphics_bump(CBMVM_GRAPHICS *g, int kind);

#endif
