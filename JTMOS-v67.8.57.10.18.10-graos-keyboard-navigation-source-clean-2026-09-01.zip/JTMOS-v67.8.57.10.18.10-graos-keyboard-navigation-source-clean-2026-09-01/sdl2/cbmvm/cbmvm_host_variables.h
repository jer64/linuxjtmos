#ifndef CBMVM_HOST_VARIABLES_H
#define CBMVM_HOST_VARIABLES_H

#include <stddef.h>
#include <stdint.h>
#include "cbmvm_host.h"
#include "cbmvm_settings.h"
#include "cbmvm_graphics.h"
#include "cbmvm_6502.h"

typedef enum {
    CBMVM_VALUE_NUMBER = 0,
    CBMVM_VALUE_STRING = 1
} CBMVM_VALUE_TYPE;

typedef struct {
    uint16_t do_pc;
    uint16_t do_line_address;
} CBMVM_DO_FRAME;

typedef struct {
    char name[CBMVM_MAX_VAR_NAME];
    CBMVM_VALUE_TYPE type;
    double number;
    char string[CBMVM_MAX_STRING];
    uint16_t string_length;
} CBMVM_VARIABLE;

typedef struct {
    uint16_t return_pc;
    uint16_t return_line_address;
    uint8_t is_interrupt;
} CBMVM_GOSUB_FRAME;

typedef struct {
    char variable[CBMVM_MAX_VAR_NAME];
    double limit;
    double step;
    uint16_t loop_pc;
    uint16_t loop_line_address;
} CBMVM_FOR_FRAME;

typedef struct {
    char name[CBMVM_MAX_VAR_NAME];
    uint8_t dimensions;
    uint16_t upper[CBMVM_MAX_ARRAY_DIMS];
} CBMVM_ARRAY_DEF;

typedef struct {
    uint16_t start;
    uint16_t end;
    uint16_t line;
} CBMVM_DATA_ITEM;

typedef struct {
    char name[CBMVM_MAX_VAR_NAME];
    char parameter[CBMVM_MAX_VAR_NAME];
    uint16_t expression_pc;
    uint16_t line_address;
} CBMVM_FN_DEF;

typedef struct CBMVM {
    uint8_t *ram;
    size_t ram_size;

    uint16_t load_address;
    uint16_t program_end;
    uint16_t first_line_address;
    uint16_t line_address;
    uint16_t next_line_address;
    uint16_t pc;
    uint16_t line_number;

    int halted;
    int error;
    int debug;
    unsigned long instructions;

    CBMVM_HOST host;

    CBMVM_VARIABLE variables[CBMVM_MAX_VARIABLES];
    unsigned int variable_count;

    /* Sparse BASIC arrays: DIM records bounds; touched elements reuse variables[]. */
    CBMVM_ARRAY_DEF arrays[CBMVM_MAX_ARRAYS];
    unsigned int array_count;

    /* DATA is indexed once per loaded program so READ/RESTORE remain deterministic. */
    CBMVM_DATA_ITEM data_items[CBMVM_MAX_DATA_ITEMS];
    unsigned int data_item_count;
    unsigned int data_index;

    /* INPUT is cooperative: an incomplete host line yields instead of blocking JTMOS. */
    char input_buffer[CBMVM_INPUT_BUFFER];
    uint16_t input_length;
    uint16_t input_statement_pc;
    uint8_t input_active;

    uint32_t random_state;

    CBMVM_GOSUB_FRAME gosub_stack[CBMVM_GOSUB_DEPTH];
    unsigned int gosub_depth;

    CBMVM_FOR_FRAME for_stack[CBMVM_FOR_DEPTH];
    unsigned int for_depth;

    CBMVM_DO_FRAME do_stack[CBMVM_DO_DEPTH];
    unsigned int do_depth;

    CBMVM_FN_DEF functions[CBMVM_MAX_FUNCTIONS];
    unsigned int function_count;
    unsigned int fn_depth;

    unsigned int print_column;

    /* Deterministic C128-style PAL/NTSC virtual raster clock. */
    uint8_t video_hz;
    uint64_t video_jiffy;
    uint64_t timer_phase; /* elapsed_us * hz, modulo 1,000,000 */

    /* BASIC 7 COLLISION handlers (type 1 sprite/sprite, type 2 sprite/display). */
    uint16_t collision_handler[2];
    uint8_t collision_pending;
    uint8_t collision_in_handler;

    CBMVM_GRAPHICS graphics;

    /* SYS enters a cooperative MOS 6502/6510 execution mode. */
    CBMVM_M6502 cpu;
    char error_message[160];
} CBMVM;

#endif
