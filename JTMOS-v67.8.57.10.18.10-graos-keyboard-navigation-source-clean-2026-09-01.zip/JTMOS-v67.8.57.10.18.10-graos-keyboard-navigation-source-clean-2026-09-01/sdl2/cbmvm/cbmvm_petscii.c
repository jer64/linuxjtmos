#include <string.h>
#include "cbmvm_petscii.h"

static void expand5x7(const uint8_t in[7], uint8_t out[8])
{
    int y;
    memset(out, 0, 8);
    for (y = 0; y < 7; y++) out[y] = (uint8_t)(in[y] << 1);
}

static void glyph_ascii(uint8_t ch, uint8_t out[8])
{
    static const uint8_t blank[7] = {0,0,0,0,0,0,0};
    static const uint8_t digits[10][7] = {
        {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},{30,1,1,14,1,1,30},{2,6,10,18,31,2,2},
        {31,16,16,30,1,1,30},{14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},{14,17,17,15,1,1,14}
    };
    static const uint8_t letters[26][7] = {
        {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},{30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},
        {14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},{7,2,2,2,2,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
        {17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},{30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},
        {15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},{17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},
        {17,17,10,4,4,4,4},{31,1,2,4,8,16,31}
    };
    static const uint8_t bang[7]      = {4,4,4,4,4,0,4};
    static const uint8_t quote[7]     = {10,10,10,0,0,0,0};
    static const uint8_t hash[7]      = {10,31,10,10,31,10,0};
    static const uint8_t dollar[7]    = {4,15,20,14,5,30,4};
    static const uint8_t percent[7]   = {25,26,2,4,8,11,19};
    static const uint8_t amp[7]       = {12,18,20,8,21,18,13};
    static const uint8_t apos[7]      = {4,4,8,0,0,0,0};
    static const uint8_t lparen[7]    = {2,4,8,8,8,4,2};
    static const uint8_t rparen[7]    = {8,4,2,2,2,4,8};
    static const uint8_t star[7]      = {0,4,21,14,21,4,0};
    static const uint8_t plus[7]      = {0,4,4,31,4,4,0};
    static const uint8_t comma[7]     = {0,0,0,0,0,4,8};
    static const uint8_t minus[7]     = {0,0,0,31,0,0,0};
    static const uint8_t dot[7]       = {0,0,0,0,0,0,4};
    static const uint8_t slash[7]     = {1,2,4,8,16,0,0};
    static const uint8_t colon[7]     = {0,4,0,0,4,0,0};
    static const uint8_t semi[7]      = {0,4,0,0,4,4,8};
    static const uint8_t lt[7]        = {2,4,8,16,8,4,2};
    static const uint8_t eq[7]        = {0,0,31,0,31,0,0};
    static const uint8_t gt[7]        = {8,4,2,1,2,4,8};
    static const uint8_t question[7]  = {14,17,1,2,4,0,4};
    static const uint8_t at[7]        = {14,17,23,21,23,16,14};
    static const uint8_t lbr[7]       = {14,8,8,8,8,8,14};
    static const uint8_t backslash[7] = {16,8,4,2,1,0,0};
    static const uint8_t rbr[7]       = {14,2,2,2,2,2,14};
    static const uint8_t caret[7]     = {4,10,17,0,0,0,0};
    static const uint8_t under[7]     = {0,0,0,0,0,0,31};
    const uint8_t *g = blank;

    if (ch >= 'a' && ch <= 'z') ch = (uint8_t)(ch - 'a' + 'A');
    if (ch >= '0' && ch <= '9') g = digits[ch - '0'];
    else if (ch >= 'A' && ch <= 'Z') g = letters[ch - 'A'];
    else switch (ch) {
        case '!': g=bang; break; case '"': g=quote; break; case '#': g=hash; break;
        case '$': g=dollar; break; case '%': g=percent; break; case '&': g=amp; break;
        case '\'': g=apos; break; case '(': g=lparen; break; case ')': g=rparen; break;
        case '*': g=star; break; case '+': g=plus; break; case ',': g=comma; break;
        case '-': g=minus; break; case '.': g=dot; break; case '/': g=slash; break;
        case ':': g=colon; break; case ';': g=semi; break; case '<': g=lt; break;
        case '=': g=eq; break; case '>': g=gt; break; case '?': g=question; break;
        case '@': g=at; break; case '[': g=lbr; break; case '\\': g=backslash; break;
        case ']': g=rbr; break; case '^': g=caret; break; case '_': g=under; break;
        default: break;
    }
    expand5x7(g, out);
}

static void glyph_graphics(uint8_t code, uint8_t out[8])
{
    int y;
    memset(out, 0, 8);
    switch (code & 0x1f) {
        case 0:  for(y=0;y<8;y++) out[y]=0xff; break;                 /* solid */
        case 1:  for(y=0;y<8;y++) out[y]=0xf0; break;                 /* left half */
        case 2:  for(y=0;y<8;y++) out[y]=0x0f; break;                 /* right half */
        case 3:  for(y=0;y<4;y++) out[y]=0xff; break;                 /* upper half */
        case 4:  for(y=4;y<8;y++) out[y]=0xff; break;                 /* lower half */
        case 5:  for(y=0;y<8;y++) out[y]=0x18; break;                 /* vertical */
        case 6:  out[3]=out[4]=0xff; break;                           /* horizontal */
        case 7:  for(y=0;y<8;y++) out[y]=(uint8_t)(1u<<(7-y)); break;/* \ */
        case 8:  for(y=0;y<8;y++) out[y]=(uint8_t)(1u<<y); break;    /* / */
        case 9:  for(y=0;y<8;y++) out[y]=(y&1)?0x55:0xaa; break;     /* checker */
        case 10: for(y=0;y<8;y++) out[y]=(y&1)?0x00:0xff; break;     /* h stripes */
        case 11: for(y=0;y<8;y++) out[y]=0xaa; break;                 /* v stripes */
        case 12: out[0]=out[7]=0xff; for(y=1;y<7;y++) out[y]=0x81; break;
        case 13: for(y=0;y<8;y++) out[y]=(uint8_t)(0x80u>>(y/2)); break;
        case 14: for(y=0;y<8;y++) out[y]=(uint8_t)(1u<<(y/2)); break;
        case 15: out[0]=0x18;out[1]=0x3c;out[2]=0x7e;out[3]=0xff;out[4]=0xff;out[5]=0x7e;out[6]=0x3c;out[7]=0x18;break;
        case 16: for(y=0;y<8;y++) out[y]=(y<4)?0xcc:0x33; break;
        case 17: out[0]=out[1]=out[2]=out[3]=0x18; out[3]=0xff; break;
        case 18: out[3]=0xff; out[3]=out[4]=out[5]=out[6]=0x18; break;
        case 19: for(y=0;y<8;y++) out[y]=0x18; out[3]=0xff; break;
        case 20: out[3]=0xf8; for(y=3;y<8;y++) out[y]|=0x08; break;
        case 21: out[3]=0x1f; for(y=3;y<8;y++) out[y]|=0x10; break;
        case 22: out[4]=0xf8; for(y=0;y<=4;y++) out[y]|=0x08; break;
        case 23: out[4]=0x1f; for(y=0;y<=4;y++) out[y]|=0x10; break;
        case 24: for(y=0;y<8;y++) out[y]=(uint8_t)(0x80u | 0x01u); break;
        case 25: out[0]=out[7]=0xff; break;
        case 26: for(y=0;y<8;y++) out[y]=(uint8_t)((y<4)?(0xf0u>>(y)): (0x0fu<<(7-y))); break;
        case 27: for(y=0;y<8;y++) out[y]=(uint8_t)((y<4)?(0x0fu<<(y)): (0xf0u>>(7-y))); break;
        case 28: for(y=0;y<8;y++) out[y]=(uint8_t)((y==0||y==7)?0xff:0x18); break;
        case 29: for(y=0;y<8;y++) out[y]=(uint8_t)((y==3||y==4)?0xff:0x81); break;
        case 30: for(y=0;y<8;y++) out[y]=(uint8_t)(0x81u | ((y&1)?0x18:0x00)); break;
        default: for(y=0;y<8;y++) out[y]=(uint8_t)((y&1)?0x3c:0xc3); break;
    }
}

void cbmvm_petscii_glyph(uint8_t petscii, uint8_t rows[8])
{
    int y;
    uint8_t base = petscii;
    int reverse = 0;

    if (petscii >= 0x80) {
        reverse = 1;
        base = (uint8_t)(petscii & 0x7f);
    }

    /* Upper/graphics PETSCII: 0x60-0x7f are graphic symbols. */
    if (base >= 0x60 && base <= 0x7f) glyph_graphics(base, rows);
    else if (base < 0x20) memset(rows, 0, 8);
    else glyph_ascii(base, rows);

    if (reverse) for (y = 0; y < 8; y++) rows[y] = (uint8_t)~rows[y];
}
