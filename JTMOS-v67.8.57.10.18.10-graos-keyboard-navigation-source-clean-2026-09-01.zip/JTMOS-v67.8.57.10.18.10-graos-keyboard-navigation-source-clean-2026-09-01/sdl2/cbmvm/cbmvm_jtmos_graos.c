#ifdef JTMOS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/process.h>

#include "cbmvm_jtmos_graos.h"
#include "cbmvm_engine.h"
#include "cbmvm_graphics.h"
#include "cbmvm_petscii.h"
#include "cbmvm_vicii.h"
#include "cbmvm_c128_theme.h"

#define C64_SCREEN_BEGIN 0x0400u
#define C64_SCREEN_END   0x07e7u
#define C64_BORDER       0xd020u
#define C64_BACKGROUND   0xd021u
#define C64_COLOR_BEGIN  0xd800u
#define C64_COLOR_END    0xdbe7u
#define KEYQ 64

typedef struct {
    int enabled;
    int x,y,color,priority,x_expand,y_expand,multicolor;
    uint8_t data[63];
} JT_SPRITE;

typedef struct {
    int wid;
    GRAOS_PIXEL *pixels;
    int closed,focused,dirty;
    uint8_t screen[1000];
    uint8_t screen_color[1000];
    int cursor_x,cursor_y;
    uint8_t border,background,text_color;
    uint8_t gfx_pixels[CBMVM_GFX_PACKED_BYTES];
    uint8_t gfx_colors[CBMVM_GFX_COLOR_SOURCES];
    int gfx_mode,split_line,gfx_valid;
    int machine_mode;
    uint8_t machine_pixels[CBMVM_VICII_PIXELS];
    int sprite_multi1,sprite_multi2;
    JT_SPRITE sprite[CBMVM_SPRITE_COUNT];
    int keyq[KEYQ]; unsigned int key_head,key_tail;
} JT_CTX;

static GRAOS_PIXEL jt_color(unsigned int index)
{
    uint32_t rgb=cbmvm_c128_rgb24(index);
    return GRAOS_RGB((rgb>>16)&255u,(rgb>>8)&255u,rgb&255u);
}

static uint8_t packed_get(const uint8_t *p,size_t index)
{
    unsigned int shift=(unsigned int)((index&3u)*2u);
    return (uint8_t)((p[index>>2]>>shift)&3u);
}

static void key_push(JT_CTX *c,int ch)
{
    unsigned int n=(c->key_head+1u)%KEYQ; if(n==c->key_tail)return; c->keyq[c->key_head]=ch;c->key_head=n;
}
static int key_pop(JT_CTX *c){int ch;if(c->key_head==c->key_tail)return-1;ch=c->keyq[c->key_tail];c->key_tail=(c->key_tail+1u)%KEYQ;return ch;}

static void poll_events(JT_CTX *c)
{
    GUICMD ev; int er;
    if(!c||c->closed)return;
    while((er=JtmosGraOSPollEvent(c->wid,&ev))>0) {
        if(ev.id==GRAOS_GSID_EXIT){c->closed=1;return;}
        if(ev.id==GRAOS_GSID_WINDOW_FOCUS){c->focused=1;continue;}
        if(ev.id==GRAOS_GSID_WINDOW_BLUR||ev.id==GRAOS_GSID_WINDOW_MINIMIZED){c->focused=0;continue;}
        if(ev.id==GRAOS_GSID_WINDOW_RESTORED){c->focused=1;continue;}
        if(ev.id==GRAOS_GSID_KEYPRESSED) key_push(c,ev.v[0]);
    }
    if(er<0)c->closed=1;
}

static void clear_text(JT_CTX *c)
{
    unsigned int i; memset(c->screen,' ',sizeof(c->screen));for(i=0;i<sizeof(c->screen_color);i++)c->screen_color[i]=c->text_color;c->cursor_x=0;c->cursor_y=0;c->dirty=1;
}
static void scroll_text(JT_CTX *c)
{
    memmove(c->screen,c->screen+40,960);memmove(c->screen_color,c->screen_color+40,960);memset(c->screen+960,' ',40);memset(c->screen_color+960,c->text_color,40);c->cursor_y=24;
}

static void jt_putc(void *p,int ch)
{
    JT_CTX *c=(JT_CTX*)p;c->machine_mode=0;
    if(ch=='\r'){c->cursor_x=0;return;}
    if(ch=='\n'){c->cursor_x=0;c->cursor_y++;if(c->cursor_y>=25)scroll_text(c);c->dirty=1;return;}
    if(ch==8){if(c->cursor_x>0)c->cursor_x--;c->screen[c->cursor_y*40+c->cursor_x]=' ';c->dirty=1;return;}
    if(ch>=32&&ch<=255){int pos=c->cursor_y*40+c->cursor_x;c->screen[pos]=(uint8_t)ch;c->screen_color[pos]=c->text_color;c->cursor_x++;if(c->cursor_x>=40){c->cursor_x=0;c->cursor_y++;if(c->cursor_y>=25)scroll_text(c);}c->dirty=1;}
}
static int jt_getc(void *p){JT_CTX*c=(JT_CTX*)p;poll_events(c);return key_pop(c);}

static int jt_io_write(void*p,uint16_t a,uint8_t v)
{
    JT_CTX*c=(JT_CTX*)p;
    if(a==C64_BORDER){c->border=v&15u;c->dirty=1;return 0;}
    if(a==C64_BACKGROUND){c->background=v&15u;c->dirty=1;return 0;}
    if(a>=C64_SCREEN_BEGIN&&a<=C64_SCREEN_END){c->screen[a-C64_SCREEN_BEGIN]=v;c->dirty=1;return 0;}
    if(a>=C64_COLOR_BEGIN&&a<=C64_COLOR_END){c->screen_color[a-C64_COLOR_BEGIN]=v&15u;c->dirty=1;return 0;}
    return 1;
}
static int jt_io_read(void*p,uint16_t a,uint8_t*v)
{
    JT_CTX*c=(JT_CTX*)p;if(!v)return 1;
    if(a==C64_BORDER){*v=c->border;return 0;}if(a==C64_BACKGROUND){*v=c->background;return 0;}
    if(a>=C64_SCREEN_BEGIN&&a<=C64_SCREEN_END){*v=c->screen[a-C64_SCREEN_BEGIN];return 0;}
    if(a>=C64_COLOR_BEGIN&&a<=C64_COLOR_END){*v=c->screen_color[a-C64_COLOR_BEGIN];return 0;}return 1;
}
static void jt_screen_clear(void*p){clear_text((JT_CTX*)p);}
static void jt_graphics_mode(void*p,int m,int s){JT_CTX*c=(JT_CTX*)p;c->gfx_mode=m;c->split_line=s;c->dirty=1;}
static void jt_graphics_color(void*p,int s,int col){JT_CTX*c=(JT_CTX*)p;if(s>=0&&s<CBMVM_GFX_COLOR_SOURCES)c->gfx_colors[s]=(uint8_t)col;c->dirty=1;}
static void jt_graphics_present(void*p,const uint8_t*pix,size_t bytes,int w,int h,const uint8_t colors[7],int mode,int split)
{JT_CTX*c=(JT_CTX*)p;(void)w;(void)h;if(pix){if(bytes>sizeof(c->gfx_pixels))bytes=sizeof(c->gfx_pixels);memcpy(c->gfx_pixels,pix,bytes);c->gfx_valid=1;}if(colors)memcpy(c->gfx_colors,colors,sizeof(c->gfx_colors));c->gfx_mode=mode;c->split_line=split;c->dirty=1;}
static void jt_graphics_present_dirty(void*p,const uint8_t*pix,size_t bytes,int w,int h,const uint8_t colors[7],int mode,int split,int x,int y,int dw,int dh)
{(void)x;(void)y;(void)dw;(void)dh;jt_graphics_present(p,pix,bytes,w,h,colors,mode,split);}
static void jt_damage(void*p,int x,int y,int w,int h){JT_CTX*c=(JT_CTX*)p;(void)x;(void)y;(void)w;(void)h;c->dirty=1;}
static void jt_timer_tick(void*p,unsigned int hz,uint64_t j){JT_CTX*c=(JT_CTX*)p;(void)hz;(void)j;c->dirty=1;}
static void jt_sprite_colors(void*p,int a,int b){JT_CTX*c=(JT_CTX*)p;c->sprite_multi1=a;c->sprite_multi2=b;c->dirty=1;}
static void jt_sprite_update(void*p,int n,int en,int x,int y,int col,int pri,int xe,int ye,int multi,const uint8_t data[63])
{JT_CTX*c=(JT_CTX*)p;JT_SPRITE*s;if(n<1||n>CBMVM_SPRITE_COUNT)return;s=&c->sprite[n-1];s->enabled=en;s->x=x;s->y=y;s->color=col;s->priority=pri;s->x_expand=xe;s->y_expand=ye;s->multicolor=multi;if(data)memcpy(s->data,data,63);c->dirty=1;}

static void jt_machine_present(void*p,const uint8_t*ram,size_t bytes,const uint8_t color_ram[0x400],const uint8_t vic[0x40],uint8_t cia2_porta)
{JT_CTX*c=(JT_CTX*)p;if(!c||!ram||!vic)return;cbmvm_vicii_render(ram,bytes,color_ram,vic,cia2_porta,c->machine_pixels);c->border=vic[0x20]&15u;c->background=vic[0x21]&15u;c->machine_mode=1;c->dirty=1;}

static void draw_char(JT_CTX*c,int col,int row,uint8_t ch,uint8_t color)
{
    uint8_t glyph[8];int x,y;GRAOS_PIXEL fg=jt_color(color),bg=jt_color(c->background);cbmvm_petscii_glyph(ch,glyph);
    for(y=0;y<8;y++)for(x=0;x<8;x++){int sx=CBMVM_VIEW_BORDER+col*8+x,sy=CBMVM_VIEW_BORDER+row*8+y;c->pixels[sy*CBMVM_VIEW_WIDTH+sx]=((glyph[y]>>(7-x))&1)?fg:bg;}
}
static void draw_text_rows(JT_CTX*c,int first,int last)
{int r,x;if(first<0)first=0;if(last>24)last=24;for(r=first;r<=last;r++)for(x=0;x<40;x++){int p=r*40+x;draw_char(c,x,r,c->screen[p],c->screen_color[p]&15u);}}
static void draw_graphics(JT_CTX*c,int lasty)
{int x,y;if(lasty>199)lasty=199;for(y=0;y<=lasty;y++)for(x=0;x<320;x++){uint8_t s=c->gfx_valid?packed_get(c->gfx_pixels,(size_t)y*320u+(size_t)x):0;unsigned int basic=(s<CBMVM_GFX_COLOR_SOURCES)?c->gfx_colors[s]:1u;unsigned int idx=(basic>=1u&&basic<=16u)?basic-1u:0u;c->pixels[(CBMVM_VIEW_BORDER+y)*CBMVM_VIEW_WIDTH+CBMVM_VIEW_BORDER+x]=jt_color(idx);}}
static void draw_spixel(JT_CTX*c,int x,int y,GRAOS_PIXEL col){if(x<0||x>=320||y<0||y>=200)return;c->pixels[(y+CBMVM_VIEW_BORDER)*CBMVM_VIEW_WIDTH+x+CBMVM_VIEW_BORDER]=col;}
static void draw_sprites(JT_CTX*c)
{
    int n,row;for(n=0;n<CBMVM_SPRITE_COUNT;n++){JT_SPRITE*s=&c->sprite[n];if(!s->enabled)continue;for(row=0;row<21;row++){int b;if(s->multicolor){for(b=0;b<12;b++){int bi=row*3+b/4,sh=6-(b%4)*2,v=(s->data[bi]>>sh)&3,cidx,dx,dy;if(!v)continue;cidx=(v==1?c->sprite_multi1:(v==2?s->color:c->sprite_multi2));if(cidx>=1&&cidx<=16)cidx--;else cidx&=15;for(dy=0;dy<(s->y_expand?2:1);dy++)for(dx=0;dx<(s->x_expand?4:2);dx++)draw_spixel(c,s->x+b*(s->x_expand?4:2)+dx,s->y+row*(s->y_expand?2:1)+dy,jt_color(cidx));}}else{for(b=0;b<24;b++)if((s->data[row*3+b/8]>>(7-(b&7)))&1){int cidx=s->color,dx,dy;if(cidx>=1&&cidx<=16)cidx--;else cidx&=15;for(dy=0;dy<(s->y_expand?2:1);dy++)for(dx=0;dx<(s->x_expand?2:1);dx++)draw_spixel(c,s->x+b*(s->x_expand?2:1)+dx,s->y+row*(s->y_expand?2:1)+dy,jt_color(cidx));}}}}
}

static int present(JT_CTX*c)
{
    int i,n=CBMVM_VIEW_WIDTH*CBMVM_VIEW_HEIGHT,split;GRAOS_PIXEL border;if(!c||c->closed||!c->pixels)return-1;border=jt_color(c->border);for(i=0;i<n;i++)c->pixels[i]=border;
    if(c->machine_mode){int x,y;for(y=0;y<200;y++)for(x=0;x<320;x++)c->pixels[(CBMVM_VIEW_BORDER+y)*CBMVM_VIEW_WIDTH+CBMVM_VIEW_BORDER+x]=jt_color(c->machine_pixels[y*320+x]&15u);}
    else if(c->gfx_mode==0)draw_text_rows(c,0,24);else if(c->gfx_mode==2||c->gfx_mode==4){split=c->split_line;if(split<0)split=19;if(split>24)split=24;draw_graphics(c,split*8-1);draw_text_rows(c,split,24);}else draw_graphics(c,199);if(!c->machine_mode)draw_sprites(c);c->dirty=0;return refreshWindow(c->wid);
}
static void jt_yield(void*p){JT_CTX*c=(JT_CTX*)p;poll_events(c);if(c->dirty&&!c->closed)present(c);SwitchToThread();}

static int init_gui(JT_CTX*c,CBMVM_HOST*h)
{
    size_t bytes=(size_t)CBMVM_VIEW_WIDTH*(size_t)CBMVM_VIEW_HEIGHT*sizeof(GRAOS_PIXEL);memset(c,0,sizeof(*c));memset(h,0,sizeof(*h));c->wid=-1;c->focused=1;
    c->border=CBMVM_C128_DEFAULT_BORDER;c->background=CBMVM_C128_DEFAULT_BACKGROUND;c->text_color=CBMVM_C128_DEFAULT_TEXT;c->split_line=19;c->sprite_multi1=3;c->sprite_multi2=4;
    c->gfx_colors[0]=1;c->gfx_colors[1]=2;c->gfx_colors[2]=3;c->gfx_colors[3]=7;c->gfx_colors[4]=1;c->gfx_colors[5]=2;c->gfx_colors[6]=1;clear_text(c);
    if(connectGraos()!=0)return-1;c->pixels=(GRAOS_PIXEL*)malloc(bytes);if(!c->pixels)return-2;memset(c->pixels,0,bytes);
    c->wid=createWindow(-1,-1,CBMVM_VIEW_WIDTH,CBMVM_VIEW_HEIGHT+20,"CBMVM - C128 BASIC 7",GRAOS_WINDOW_STANDARD);if(c->wid<0){free(c->pixels);c->pixels=NULL;return-3;}
    if(addFrameBuffer(c->wid,c->pixels,0,0,CBMVM_VIEW_WIDTH,CBMVM_VIEW_HEIGHT,GRAOS_BPP,GRAOS_SURFACE_BITMAP,0)<0){closeWindow(c->wid);free(c->pixels);c->pixels=NULL;return-4;}
    h->userdata=c;h->putc=jt_putc;h->getc=jt_getc;h->yield=jt_yield;h->io_write=jt_io_write;h->io_read=jt_io_read;h->screen_clear=jt_screen_clear;h->graphics_mode=jt_graphics_mode;h->graphics_color=jt_graphics_color;h->graphics_present=jt_graphics_present;h->graphics_present_dirty=jt_graphics_present_dirty;h->graphics_damage=jt_damage;h->timer_tick=jt_timer_tick;h->sprite_colors=jt_sprite_colors;h->sprite_update=jt_sprite_update;h->machine_present=jt_machine_present;
    return present(c)<0?-5:0;
}
static void close_gui(JT_CTX*c){if(!c)return;if(c->wid>=0&&!c->closed)closeWindow(c->wid);if(c->pixels)free(c->pixels);c->pixels=NULL;c->wid=-1;c->closed=1;}

static int load_file(CBMVM*vm,const char*name)
{
    FILE*f;long n;uint8_t*buf;int rc;if(!name)return CBMVM_ERR;f=fopen(name,"rb");if(!f)return CBMVM_ERR;
    if(fseek(f,0,SEEK_END)!=0||(n=ftell(f))<0||n>65536L||fseek(f,0,SEEK_SET)!=0){fclose(f);return CBMVM_ERR;}buf=(uint8_t*)malloc((size_t)n);if(!buf){fclose(f);return CBMVM_ERR;}if(fread(buf,1,(size_t)n,f)!=(size_t)n){free(buf);fclose(f);return CBMVM_ERR;}fclose(f);rc=cbmvm_load_prg(vm,buf,(size_t)n);free(buf);return rc;
}

int cbmvm_jtmos_graos_run_program(int argc,char**argv)
{
    JT_CTX c;CBMVM_HOST h;CBMVM*vm;int rc,key;unsigned long last,now;
    if(argc<2){printf("Usage: cbmvm.bin program.prg\n");return 1;}if(init_gui(&c,&h)!=0){printf("CBMVM: GraOS initialization failed.\n");return 2;}vm=cbmvm_create(&h);if(!vm){close_gui(&c);return 2;}rc=load_file(vm,argv[1]);last=GetTickCount();
    while((rc==CBMVM_OK||rc==CBMVM_YIELDED)&&!c.closed){poll_events(&c);key=key_pop(&c);if(key==27){c.closed=1;break;}if(key>=0)key_push(&c,key);now=GetTickCount();cbmvm_timer_advance_us(vm,(uint64_t)(now-last)*1000u);last=now;rc=cbmvm_run(vm,512);if(c.dirty)present(&c);if(!c.focused)Sleep(10);}
    if(rc==CBMVM_ERR)printf("CBMVM: %s\n",cbmvm_last_error(vm));
    if(rc!=CBMVM_ERR&&!c.closed){jt_putc(&c,'\n');jt_putc(&c,'R');jt_putc(&c,'E');jt_putc(&c,'A');jt_putc(&c,'D');jt_putc(&c,'Y');jt_putc(&c,'.');present(&c);while(!c.closed){poll_events(&c);key=key_pop(&c);if(key==27)break;Sleep(20);}}
    cbmvm_destroy(vm);close_gui(&c);return rc==CBMVM_ERR?3:0;
}

#endif
