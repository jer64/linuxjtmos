#ifndef JTMOS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#if defined(__has_include)
# if __has_include(<SDL2/SDL.h>)
#  include <SDL2/SDL.h>
# elif __has_include(<SDL.h>)
#  include <SDL.h>
# else
#  error "SDL2 headers not found. Install libsdl2-dev (or equivalent)."
# endif
#else
# include <SDL2/SDL.h>
#endif

#include "cbmvm_sdl2.h"
#include "cbmvm_engine.h"
#include "cbmvm_graphics.h"
#include "cbmvm_petscii.h"
#include "cbmvm_vicii.h"
#include "cbmvm_c128_theme.h"

#define C64_SCREEN_BEGIN 0x0400u
#define C64_SCREEN_END   0x07e7u
#define C64_BORDER       0xd020u
#define C64_BACKGROUND   0xd021u
#define C64_COLOR_BEGIN  0xd800u
#define C64_COLOR_END    0xdbe7u
#define KEYQ 64

typedef struct {
    int enabled;
    int x, y;
    int color;
    int priority;
    int x_expand, y_expand;
    int multicolor;
    uint8_t data[63];
} SDL2_SPRITE;

struct CBMVM_SDL2_CONTEXT {
    SDL_Window *window;
    SDL_Renderer *renderer;
    SDL_Texture *texture;
    uint32_t *pixels;
    int started_sdl;
    int quit;
    int dirty;
    uint8_t screen[1000];
    uint8_t screen_color[1000];
    int cursor_x, cursor_y;
    uint8_t border;
    uint8_t background;
    uint8_t text_color;
    uint8_t gfx_pixels[CBMVM_GFX_PACKED_BYTES];
    uint8_t gfx_colors[CBMVM_GFX_COLOR_SOURCES];
    int gfx_mode;
    int split_line;
    int gfx_valid;
    int machine_mode;
    uint8_t machine_pixels[CBMVM_VICII_PIXELS];
    int sprite_multi1, sprite_multi2;
    SDL2_SPRITE sprite[CBMVM_SPRITE_COUNT];
    int keyq[KEYQ];
    unsigned int key_head, key_tail;
};

static uint32_t argb_color(unsigned int index)
{
    return 0xff000000u | cbmvm_c128_rgb24(index);
}

static uint8_t packed_get(const uint8_t *p, size_t index)
{
    unsigned int shift=(unsigned int)((index&3u)*2u);
    return (uint8_t)((p[index>>2]>>shift)&3u);
}

static void key_push(CBMVM_SDL2_CONTEXT *ctx, int ch)
{
    unsigned int next=(ctx->key_head+1u)%KEYQ;
    if(next==ctx->key_tail) return;
    ctx->keyq[ctx->key_head]=ch;
    ctx->key_head=next;
}

static int key_pop(CBMVM_SDL2_CONTEXT *ctx)
{
    int ch;
    if(ctx->key_head==ctx->key_tail) return -1;
    ch=ctx->keyq[ctx->key_tail];
    ctx->key_tail=(ctx->key_tail+1u)%KEYQ;
    return ch;
}

static void pump_events(CBMVM_SDL2_CONTEXT *ctx)
{
    SDL_Event ev;
    while(SDL_PollEvent(&ev)) {
        if(ev.type==SDL_QUIT) { ctx->quit=1; continue; }
        if(ev.type==SDL_KEYDOWN) {
            SDL_Keycode k=ev.key.keysym.sym;
            if(k==SDLK_ESCAPE) { key_push(ctx,27); continue; }
            if(k==SDLK_BACKSPACE) { key_push(ctx,8); continue; }
            if(k==SDLK_RETURN || k==SDLK_KP_ENTER) { key_push(ctx,13); continue; }
            if(k==SDLK_TAB) { key_push(ctx,9); continue; }
            if(k==SDLK_UP) { key_push(ctx,0x4800); continue; }
            if(k==SDLK_DOWN) { key_push(ctx,0x5000); continue; }
            if(k==SDLK_LEFT) { key_push(ctx,0x4b00); continue; }
            if(k==SDLK_RIGHT) { key_push(ctx,0x4d00); continue; }
            if((ev.key.keysym.mod & KMOD_CTRL) && k>=SDLK_a && k<=SDLK_z) {
                key_push(ctx,(int)(k-SDLK_a+1));
                continue;
            }
        }
        if(ev.type==SDL_TEXTINPUT) {
            const unsigned char *s=(const unsigned char *)ev.text.text;
            while(*s) key_push(ctx,(int)*s++);
        }
    }
}

static void clear_text(CBMVM_SDL2_CONTEXT *ctx)
{
    unsigned int i;
    memset(ctx->screen,' ',sizeof(ctx->screen));
    for(i=0;i<sizeof(ctx->screen_color);i++) ctx->screen_color[i]=ctx->text_color;
    ctx->cursor_x=0; ctx->cursor_y=0; ctx->dirty=1;
}

static void scroll_text(CBMVM_SDL2_CONTEXT *ctx)
{
    memmove(ctx->screen,ctx->screen+40,960);
    memmove(ctx->screen_color,ctx->screen_color+40,960);
    memset(ctx->screen+960,' ',40);
    memset(ctx->screen_color+960,ctx->text_color,40);
    ctx->cursor_y=24;
}

static void console_putc(void *p, int ch)
{
    CBMVM_SDL2_CONTEXT *ctx=(CBMVM_SDL2_CONTEXT *)p;
    ctx->machine_mode=0;
    fputc(ch,stdout); fflush(stdout);
    if(ch=='\r') { ctx->cursor_x=0; return; }
    if(ch=='\n') { ctx->cursor_x=0; ctx->cursor_y++; if(ctx->cursor_y>=25) scroll_text(ctx); ctx->dirty=1; return; }
    if(ch==8) {
        if(ctx->cursor_x>0) ctx->cursor_x--;
        ctx->screen[ctx->cursor_y*40+ctx->cursor_x]=' ';
        ctx->dirty=1; return;
    }
    if(ch>=32 && ch<=255) {
        int pos=ctx->cursor_y*40+ctx->cursor_x;
        ctx->screen[pos]=(uint8_t)ch;
        ctx->screen_color[pos]=ctx->text_color;
        ctx->cursor_x++;
        if(ctx->cursor_x>=40) { ctx->cursor_x=0; ctx->cursor_y++; if(ctx->cursor_y>=25) scroll_text(ctx); }
        ctx->dirty=1;
    }
}

static int console_getc(void *p)
{
    CBMVM_SDL2_CONTEXT *ctx=(CBMVM_SDL2_CONTEXT *)p;
    pump_events(ctx);
    return key_pop(ctx);
}

static void host_yield(void *p)
{
    CBMVM_SDL2_CONTEXT *ctx=(CBMVM_SDL2_CONTEXT *)p;
    pump_events(ctx);
    if(ctx->dirty) cbmvm_sdl2_present(ctx);
    SDL_Delay(1);
}

static int io_write(void *p, uint16_t address, uint8_t value)
{
    CBMVM_SDL2_CONTEXT *ctx=(CBMVM_SDL2_CONTEXT *)p;
    if(address==C64_BORDER) { ctx->border=value&15u; ctx->dirty=1; return 0; }
    if(address==C64_BACKGROUND) { ctx->background=value&15u; ctx->dirty=1; return 0; }
    if(address>=C64_SCREEN_BEGIN && address<=C64_SCREEN_END) {
        ctx->screen[address-C64_SCREEN_BEGIN]=value; ctx->dirty=1; return 0;
    }
    if(address>=C64_COLOR_BEGIN && address<=C64_COLOR_END) {
        ctx->screen_color[address-C64_COLOR_BEGIN]=value&15u; ctx->dirty=1; return 0;
    }
    return 1;
}

static int io_read(void *p, uint16_t address, uint8_t *value)
{
    CBMVM_SDL2_CONTEXT *ctx=(CBMVM_SDL2_CONTEXT *)p;
    if(!value) return 1;
    if(address==C64_BORDER) { *value=ctx->border; return 0; }
    if(address==C64_BACKGROUND) { *value=ctx->background; return 0; }
    if(address>=C64_SCREEN_BEGIN && address<=C64_SCREEN_END) { *value=ctx->screen[address-C64_SCREEN_BEGIN]; return 0; }
    if(address>=C64_COLOR_BEGIN && address<=C64_COLOR_END) { *value=ctx->screen_color[address-C64_COLOR_BEGIN]; return 0; }
    return 1;
}

static void screen_clear(void *p) { clear_text((CBMVM_SDL2_CONTEXT *)p); }
static void graphics_mode(void *p,int mode,int split) { CBMVM_SDL2_CONTEXT *c=(CBMVM_SDL2_CONTEXT*)p;c->gfx_mode=mode;c->split_line=split;c->dirty=1; }
static void graphics_color(void *p,int source,int color) { CBMVM_SDL2_CONTEXT *c=(CBMVM_SDL2_CONTEXT*)p;if(source>=0&&source<CBMVM_GFX_COLOR_SOURCES)c->gfx_colors[source]=(uint8_t)color;c->dirty=1; }

static void graphics_present(void *p,const uint8_t *packed,size_t bytes,int width,int height,const uint8_t colors[7],int mode,int split)
{
    CBMVM_SDL2_CONTEXT *ctx=(CBMVM_SDL2_CONTEXT*)p;
    (void)width; (void)height;
    if(packed) { if(bytes>sizeof(ctx->gfx_pixels)) bytes=sizeof(ctx->gfx_pixels); memcpy(ctx->gfx_pixels,packed,bytes); ctx->gfx_valid=1; }
    if(colors) memcpy(ctx->gfx_colors,colors,sizeof(ctx->gfx_colors));
    ctx->gfx_mode=mode; ctx->split_line=split; ctx->dirty=1;
    cbmvm_sdl2_present(ctx);
}

static void graphics_present_dirty(void *p,const uint8_t *packed,size_t bytes,int width,int height,const uint8_t colors[7],int mode,int split,int x,int y,int w,int h)
{
    (void)x;(void)y;(void)w;(void)h;
    graphics_present(p,packed,bytes,width,height,colors,mode,split);
}

static void graphics_damage(void *p,int x,int y,int w,int h) { CBMVM_SDL2_CONTEXT *c=(CBMVM_SDL2_CONTEXT*)p;(void)x;(void)y;(void)w;(void)h;c->dirty=1; }
static void timer_tick(void *p,unsigned int hz,uint64_t jiffy) { CBMVM_SDL2_CONTEXT *c=(CBMVM_SDL2_CONTEXT*)p;(void)hz;(void)jiffy;c->dirty=1; }
static void sprite_colors(void *p,int c1,int c2) { CBMVM_SDL2_CONTEXT *c=(CBMVM_SDL2_CONTEXT*)p;c->sprite_multi1=c1;c->sprite_multi2=c2;c->dirty=1; }

static void sprite_update(void *p,int number,int enabled,int x,int y,int color,int priority,int xe,int ye,int multi,const uint8_t data[63])
{
    CBMVM_SDL2_CONTEXT *ctx=(CBMVM_SDL2_CONTEXT*)p;
    SDL2_SPRITE *s;
    if(number<1 || number>CBMVM_SPRITE_COUNT) return;
    s=&ctx->sprite[number-1]; s->enabled=enabled; s->x=x; s->y=y; s->color=color; s->priority=priority;
    s->x_expand=xe; s->y_expand=ye; s->multicolor=multi; if(data) memcpy(s->data,data,63); ctx->dirty=1;
}

static void machine_present(void *p,const uint8_t *ram,size_t bytes,const uint8_t color_ram[0x400],const uint8_t vic[0x40],uint8_t cia2_porta)
{
    CBMVM_SDL2_CONTEXT *ctx=(CBMVM_SDL2_CONTEXT*)p;
    if(!ctx||!ram||!vic)return;
    cbmvm_vicii_render(ram,bytes,color_ram,vic,cia2_porta,ctx->machine_pixels);
    ctx->border=vic[0x20]&15u;ctx->background=vic[0x21]&15u;ctx->machine_mode=1;ctx->dirty=1;
}

static void draw_char(CBMVM_SDL2_CONTEXT *ctx,int col,int row,uint8_t ch,uint8_t color)
{
    uint8_t glyph[8]; int x,y; uint32_t fg=argb_color(color),bg=argb_color(ctx->background);
    cbmvm_petscii_glyph(ch,glyph);
    for(y=0;y<8;y++) for(x=0;x<8;x++) {
        int sx=CBMVM_VIEW_BORDER+col*8+x, sy=CBMVM_VIEW_BORDER+row*8+y;
        ctx->pixels[sy*CBMVM_VIEW_WIDTH+sx]=((glyph[y]>>(7-x))&1)?fg:bg;
    }
}

static void draw_text_rows(CBMVM_SDL2_CONTEXT *ctx,int first_row,int last_row)
{
    int row,col;
    if(first_row<0) first_row=0;
    if(last_row>24) last_row=24;
    for(row=first_row;row<=last_row;row++) for(col=0;col<40;col++) {
        int pos=row*40+col; draw_char(ctx,col,row,ctx->screen[pos],ctx->screen_color[pos]&15u);
    }
}

static void draw_graphics(CBMVM_SDL2_CONTEXT *ctx,int last_y)
{
    int x,y;
    if(last_y>199) last_y=199;
    for(y=0;y<=last_y;y++) for(x=0;x<320;x++) {
        uint8_t source=ctx->gfx_valid?packed_get(ctx->gfx_pixels,(size_t)y*320u+(size_t)x):0;
        unsigned int basic=(source<CBMVM_GFX_COLOR_SOURCES)?ctx->gfx_colors[source]:1u;
        unsigned int idx=(basic>=1u&&basic<=16u)?basic-1u:0u;
        ctx->pixels[(CBMVM_VIEW_BORDER+y)*CBMVM_VIEW_WIDTH+CBMVM_VIEW_BORDER+x]=argb_color(idx);
    }
}

static void draw_sprite_pixel(CBMVM_SDL2_CONTEXT *ctx,int x,int y,uint32_t color)
{
    int xx=x+CBMVM_VIEW_BORDER, yy=y+CBMVM_VIEW_BORDER;
    if(x<0||x>=320||y<0||y>=200) return;
    ctx->pixels[yy*CBMVM_VIEW_WIDTH+xx]=color;
}

static void draw_sprites(CBMVM_SDL2_CONTEXT *ctx)
{
    int n,row;
    for(n=0;n<CBMVM_SPRITE_COUNT;n++) {
        SDL2_SPRITE *s=&ctx->sprite[n]; if(!s->enabled) continue;
        for(row=0;row<21;row++) {
            int b;
            if(s->multicolor) {
                for(b=0;b<12;b++) {
                    int bytei=row*3+b/4, shift=6-(b%4)*2, v=(s->data[bytei]>>shift)&3;
                    int cidx,dx,dy,xx,yy;
                    if(v==0) continue;
                    cidx=(v==1?ctx->sprite_multi1:(v==2?s->color:ctx->sprite_multi2));
                    if(cidx>=1&&cidx<=16) cidx--; else cidx&=15;
                    for(dy=0;dy<(s->y_expand?2:1);dy++) for(dx=0;dx<(s->x_expand?4:2);dx++) {
                        xx=s->x+b*(s->x_expand?4:2)+dx; yy=s->y+row*(s->y_expand?2:1)+dy;
                        draw_sprite_pixel(ctx,xx,yy,argb_color((unsigned)cidx));
                    }
                }
            } else {
                for(b=0;b<24;b++) if((s->data[row*3+b/8]>>(7-(b&7)))&1) {
                    int cidx=s->color,dx,dy,xx,yy; if(cidx>=1&&cidx<=16)cidx--;else cidx&=15;
                    for(dy=0;dy<(s->y_expand?2:1);dy++) for(dx=0;dx<(s->x_expand?2:1);dx++) {
                        xx=s->x+b*(s->x_expand?2:1)+dx; yy=s->y+row*(s->y_expand?2:1)+dy;
                        draw_sprite_pixel(ctx,xx,yy,argb_color((unsigned)cidx));
                    }
                }
            }
        }
    }
}

void cbmvm_sdl2_present(CBMVM_SDL2_CONTEXT *ctx)
{
    size_t i,n=(size_t)CBMVM_VIEW_WIDTH*(size_t)CBMVM_VIEW_HEIGHT;
    uint32_t border;
    int split_row;
    if(!ctx||!ctx->renderer||!ctx->texture) return;
    border=argb_color(ctx->border);
    for(i=0;i<n;i++) ctx->pixels[i]=border;
    if(ctx->machine_mode) {
        int x,y;
        for(y=0;y<200;y++)for(x=0;x<320;x++)ctx->pixels[(CBMVM_VIEW_BORDER+y)*CBMVM_VIEW_WIDTH+CBMVM_VIEW_BORDER+x]=argb_color(ctx->machine_pixels[y*320+x]&15u);
    } else if(ctx->gfx_mode==0) {
        draw_text_rows(ctx,0,24);
    } else if(ctx->gfx_mode==2 || ctx->gfx_mode==4) {
        split_row=ctx->split_line; if(split_row<0)split_row=19; if(split_row>24)split_row=24;
        draw_graphics(ctx,split_row*8-1);
        draw_text_rows(ctx,split_row,24);
    } else {
        draw_graphics(ctx,199);
    }
    if(!ctx->machine_mode) draw_sprites(ctx);
    SDL_UpdateTexture(ctx->texture,NULL,ctx->pixels,CBMVM_VIEW_WIDTH*(int)sizeof(uint32_t));
    SDL_RenderClear(ctx->renderer); SDL_RenderCopy(ctx->renderer,ctx->texture,NULL,NULL); SDL_RenderPresent(ctx->renderer);
    ctx->dirty=0;
}

CBMVM_SDL2_CONTEXT *cbmvm_sdl2_create(CBMVM_HOST *host_out,const char *title,int scale)
{
    CBMVM_SDL2_CONTEXT *ctx;
    if(!host_out) return NULL;
    memset(host_out,0,sizeof(*host_out));
    if(scale<1) scale=2;
    ctx=(CBMVM_SDL2_CONTEXT*)calloc(1,sizeof(*ctx)); if(!ctx) return NULL;
    if(!(SDL_WasInit(SDL_INIT_VIDEO)&SDL_INIT_VIDEO)) { if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_EVENTS|SDL_INIT_TIMER)!=0){free(ctx);return NULL;} ctx->started_sdl=1; }
    ctx->window=SDL_CreateWindow(title?title:"CBMVM - Commodore 128 BASIC 7",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,CBMVM_VIEW_WIDTH*scale,CBMVM_VIEW_HEIGHT*scale,SDL_WINDOW_SHOWN|SDL_WINDOW_RESIZABLE);
    if(!ctx->window) { cbmvm_sdl2_destroy(ctx); return NULL; }
    ctx->renderer=SDL_CreateRenderer(ctx->window,-1,SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);
    if(!ctx->renderer) ctx->renderer=SDL_CreateRenderer(ctx->window,-1,SDL_RENDERER_SOFTWARE);
    if(!ctx->renderer) { cbmvm_sdl2_destroy(ctx); return NULL; }
    ctx->texture=SDL_CreateTexture(ctx->renderer,SDL_PIXELFORMAT_ARGB8888,SDL_TEXTUREACCESS_STREAMING,CBMVM_VIEW_WIDTH,CBMVM_VIEW_HEIGHT);
    if(!ctx->texture) { cbmvm_sdl2_destroy(ctx); return NULL; }
    ctx->pixels=(uint32_t*)malloc((size_t)CBMVM_VIEW_WIDTH*(size_t)CBMVM_VIEW_HEIGHT*sizeof(uint32_t));
    if(!ctx->pixels) { cbmvm_sdl2_destroy(ctx); return NULL; }
    SDL_RenderSetLogicalSize(ctx->renderer,CBMVM_VIEW_WIDTH,CBMVM_VIEW_HEIGHT); SDL_StartTextInput();
    ctx->border=CBMVM_C128_DEFAULT_BORDER; ctx->background=CBMVM_C128_DEFAULT_BACKGROUND; ctx->text_color=CBMVM_C128_DEFAULT_TEXT;
    ctx->gfx_colors[0]=1;ctx->gfx_colors[1]=2;ctx->gfx_colors[2]=3;ctx->gfx_colors[3]=7;ctx->gfx_colors[4]=1;ctx->gfx_colors[5]=2;ctx->gfx_colors[6]=1;
    ctx->split_line=19; ctx->sprite_multi1=3;ctx->sprite_multi2=4; clear_text(ctx);
    host_out->userdata=ctx; host_out->putc=console_putc; host_out->getc=console_getc; host_out->yield=host_yield;
    host_out->io_write=io_write; host_out->io_read=io_read; host_out->screen_clear=screen_clear; host_out->graphics_mode=graphics_mode;
    host_out->graphics_color=graphics_color; host_out->graphics_present=graphics_present; host_out->graphics_present_dirty=graphics_present_dirty;
    host_out->graphics_damage=graphics_damage; host_out->timer_tick=timer_tick; host_out->sprite_colors=sprite_colors; host_out->sprite_update=sprite_update; host_out->machine_present=machine_present;
    cbmvm_sdl2_present(ctx); return ctx;
}

void cbmvm_sdl2_destroy(CBMVM_SDL2_CONTEXT *ctx)
{
    if(!ctx) return;
    SDL_StopTextInput(); free(ctx->pixels); if(ctx->texture)SDL_DestroyTexture(ctx->texture); if(ctx->renderer)SDL_DestroyRenderer(ctx->renderer); if(ctx->window)SDL_DestroyWindow(ctx->window);
    if(ctx->started_sdl) SDL_Quit();
    free(ctx);
}

uint64_t cbmvm_sdl2_monotonic_us(void)
{
    uint64_t f=(uint64_t)SDL_GetPerformanceFrequency(), c=(uint64_t)SDL_GetPerformanceCounter();
    if(!f) return (uint64_t)SDL_GetTicks()*1000u;
    return (c/f)*1000000u + ((c%f)*1000000u)/f;
}

int cbmvm_sdl2_quit_requested(const CBMVM_SDL2_CONTEXT *ctx) { return ctx?ctx->quit:1; }

int cbmvm_sdl2_run_program(int argc,char **argv)
{
    CBMVM_HOST host; CBMVM_SDL2_CONTEXT *ctx; CBMVM *vm; int rc; uint64_t last,now;
    if(argc<2) return 1;
    ctx=cbmvm_sdl2_create(&host,"CBMVM - C128 BASIC 7 - SDL2",2); if(!ctx){fprintf(stderr,"CBMVM: SDL2 initialization failed\n");return 2;}
    vm=cbmvm_create(&host); if(!vm){cbmvm_sdl2_destroy(ctx);return 2;}
    rc=cbmvm_load_prg_file(vm,argv[1]); last=cbmvm_sdl2_monotonic_us();
    while(rc==CBMVM_OK || rc==CBMVM_YIELDED) {
        pump_events(ctx); if(ctx->quit) break;
        now=cbmvm_sdl2_monotonic_us(); cbmvm_timer_advance_us(vm,now-last); last=now;
        rc=cbmvm_run(vm,512);
    }
    if(rc!=CBMVM_ERR && !ctx->quit) {
        static const char ready[]="\nREADY.\n";
        size_t i;
        for(i=0;i<sizeof(ready)-1;i++) console_putc(ctx,(unsigned char)ready[i]);
        cbmvm_sdl2_present(ctx);
        /* A finite BASIC program should not make the graphics window vanish.
         * Keep the C128-style READY screen visible until close or Escape. */
        while(!ctx->quit) {
            int ch;
            pump_events(ctx);
            ch=key_pop(ctx);
            if(ch==27) break;
            SDL_Delay(20);
        }
    } else {
        cbmvm_sdl2_present(ctx);
    }
    if(rc==CBMVM_ERR) fprintf(stderr,"%s\n",cbmvm_last_error(vm));
    cbmvm_destroy(vm); cbmvm_sdl2_destroy(ctx); return rc==CBMVM_ERR?3:0;
}

#endif
