#include "cbmvm_settings.h"
/* Compatibility translation unit retained for old build systems. */
const unsigned int cbmvm_default_ram_size = CBMVM_RAM_SIZE;
