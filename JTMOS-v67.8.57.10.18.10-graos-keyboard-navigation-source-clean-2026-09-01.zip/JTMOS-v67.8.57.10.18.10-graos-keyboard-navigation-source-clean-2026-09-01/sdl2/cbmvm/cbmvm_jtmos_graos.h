#ifndef CBMVM_JTMOS_GRAOS_H
#define CBMVM_JTMOS_GRAOS_H

#ifdef JTMOS
int cbmvm_jtmos_graos_run_program(int argc, char **argv);
#endif

#endif
