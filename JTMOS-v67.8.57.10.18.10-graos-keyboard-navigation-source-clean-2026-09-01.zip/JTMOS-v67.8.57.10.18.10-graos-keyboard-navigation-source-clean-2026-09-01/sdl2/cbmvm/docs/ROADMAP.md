# CBMVM / JTMOS MiniVM roadmap

## Completed foundation — 0.2 to 0.4

- compact 64 KiB guest VM and safe linked-PRG loader
- cooperative statement-budget execution
- BASIC expression/control-flow core
- host abstraction and JTMOS adapter
- 320x200 packed BASIC 7 graphics surface
- DRAW/BOX/CIRCLE/PAINT/CHAR/COLOR/SSHAPE/GSHAPE
- PETSCII/C128-compatible clean-room 8x8 renderer
- GRAPHIC/SCNCLR/RGR/RCLR/RDOT/LOCATE/SCALE/WIDTH
- SPRITE/MOVSPR/SPRDEF/SPRCOLOR/SPRSAV and RSPRITE/RSPPOS/RSPCOLOR
- sprite-sprite and sprite-bitmap collision masks, BUMP and COLLISION callbacks
- dirty bitmap rectangle plus sprite damage notifications
- deterministic 50/60 Hz virtual video clock and JTMOS monotonic-time adapter
- regression tests for graphics, collision, sprite copying and timer behavior

## Next: BASIC language compatibility

1. `INPUT` and `GET` using non-blocking host keyboard callbacks.
2. `DIM` and numeric/string arrays.
3. `DATA`, `READ`, `RESTORE` with a pre-indexed DATA cursor.
4. `ON ... GOTO/GOSUB`.
5. String/math functions: `LEN`, `VAL`, `STR$`, `ASC`, `CHR$`, `LEFT$`, `RIGHT$`, `MID$`, `SQR`, trig, `RND`.
6. Commodore two-significant-character variable-name compatibility mode.
7. PETSCII-to-Unicode/GraOS text-screen mapping.
8. More C64/C128 numeric edge cases and error messages.

## Next: C128 display fidelity

- optional host-supplied exact CHARGEN font asset; do not bundle proprietary ROM bytes
- true 40-column text/bitmap split compositor in the GraOS `cbasic` reference app
- VDC-like 80-column text surface and later 640x200-class graphics target
- byte-compatible C128 SSHAPE/GSHAPE codec as an optional compatibility mode
- explicit resolved-color palette API for hosts that do not want to expand source colors themselves
- dirty **tile** tracking in addition to the current bounding rectangle for highly scattered drawing
- sprite occupancy masks / tile acceleration so collision checks remain cheap with dense animation

## Next: interactive BASIC computer

- direct mode: execute `PRINT 1+1` without a stored line number
- editable program store: line insertion/deletion, `LIST`, `NEW`, `RUN`
- `LOAD` / `SAVE` through sandboxed JTMOS VFS callbacks
- GraOS `cbasic` application with 40x25 text screen, cursor and keyboard
- virtual device 8 mapped to a per-VM JTMOS directory
- PETSCII keyboard translation and cursor/edit keys

## Next: timer/input compatibility

- expose `TI` / `TI$` from the same deterministic video-jiffy domain
- deterministic keyboard/joystick event queue timestamped in VM jiffies
- optional PAL/NTSC setting from PRG/application profile
- include timer phase, collision latches and pending events in snapshots
- future sound envelopes driven by the same clock rather than BASIC statement count

## Virtual device bus

Move special POKE cases behind registered devices:

```c
typedef struct {
    uint16_t first, last;
    int (*read)(...);
    int (*write)(...);
} CBMVM_DEVICE;
```

Possible devices include VIC-like video registers, a SID-like sound adapter mapped to JTMOS audio IPC, keyboard matrix, timers and virtual serial/storage endpoints. The VM must emulate useful semantics rather than expose physical JTMOS memory or unrestricted syscalls.

## Snapshot/debugger

- save/restore RAM, variables, stacks, graphics, sprites, timer phase and collision state
- BASIC statement single-step
- line-number breakpoints
- variable and POKE-address watches
- framebuffer/sprite-state inspection
- deterministic replay of keyboard/joystick events

Snapshots should be portable serialized data, never dumps of C pointers.

## General JTMOS MiniVM

After BASIC stabilizes, factor the execution substrate into an optional bytecode VM and keep BASIC as one frontend. Suggested instruction groups are stack, memory, arithmetic, branches/calls and a capability-checked `SYS` gateway.

`SYS` must **not** be a raw JTMOS syscall number. Each VM should receive a capability table (console, one directory, one GraOS window, optional audio/networking), and bytecode can address only granted capabilities.

## 6502/6510 backend (implemented in 0.7)

`SYS` now switches to an integrated cooperative NMOS 6502/6510 compatibility core sharing the same 64 KiB guest memory/device bus. Direct token-BASIC remains the fast path for BASIC statements. Future work is accuracy rather than basic availability: more exact VIC bad-line/raster timing, TOD/serial CIA behavior, SID synthesis, ROM-compatible service coverage and regression tests against a larger machine-code software suite.

## Demo/game compatibility suite

Once input exists, add deterministic BASIC 7 demos that double as tests: bouncing sprites with BUMP, vector starfield, shape stamp/paint, Breakout/Pong, rotating geometry, and split-screen status bar. Tests should hash final framebuffer/sprite/timer state so behavior stays stable between JTMOS releases.
