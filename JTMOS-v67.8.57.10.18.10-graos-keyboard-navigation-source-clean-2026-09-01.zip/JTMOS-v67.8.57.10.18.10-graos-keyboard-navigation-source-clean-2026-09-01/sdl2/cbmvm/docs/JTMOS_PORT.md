# JTMOS / GraOS port plan

## Process model

Run one `CBMVM` instance per JTMOS BASIC process/window. BASIC owns a fixed 64 KiB guest address space plus bounded interpreter/graphics state; BASIC never receives a JTMOS pointer.

Recommended loop for 0.4:

```c
while (!closing) {
    int rc = cbmvm_jtmos_run_slice(vm, &vmctx, 128);

    graos_dispatch_events();
    if (rc == CBMVM_HALTED || rc == CBMVM_ERR)
        break;
    process_yield();
}
```

Provide `bindings.monotonic_us`. The bridge converts elapsed real time to the VM's selected 50/60 Hz video domain. Do not advance one video tick per scheduler iteration; that would make sprite speed depend on host load and scheduling frequency.

## GraOS `cbasic` window

Recommended layout:

- 320x200 graphics surface scaled 1x/2x/fit-to-window
- optional 40x25 text layer
- border rendered outside the virtual bitmap
- split modes use `split_line` for the future text/bitmap compositor
- keyboard events feed future `INPUT`, `GET` and direct-mode editing

The VM provides a 16,000-byte packed framebuffer. Each 2-bit pixel is a BASIC color-source value. GraOS resolves it through the provided source-color table.

## Preferred 0.4 bindings

```c
CBMVM_JTMOS_BINDINGS b;
CBMVM_JTMOS_CONTEXT vmctx;
CBMVM_HOST host;

memset(&b, 0, sizeof(b));
b.userdata                 = app;
b.console_putc             = cbasic_putc;
b.yield                    = cbasic_yield;
b.set_border               = cbasic_border;
b.set_background           = cbasic_background;
b.graphics_mode            = cbasic_graphics_mode;
b.graphics_present_dirty   = cbasic_blit_dirty_sources;
b.graphics_damage          = cbasic_damage;
b.sprite_update            = cbasic_sprite_update;
b.sprite_colors            = cbasic_sprite_colors;
b.sprite_editor            = cbasic_sprite_editor;
b.monotonic_us             = cbasic_monotonic_us;
b.timer_tick               = cbasic_video_jiffy;

cbmvm_jtmos_host_init(&vmctx, &b, &host);
vm = cbmvm_create(&host);
```

`graphics_present` remains as a compatibility fallback, but new GraOS code should use `graphics_present_dirty`.

## Repaint model

Bitmap drawing produces a bounded dirty rectangle. Sprite changes produce old/new `graphics_damage` rectangles. GraOS should merge these with normal window expose damage, repaint the background within the invalid area, composite intersecting sprites using cached `sprite_update` state, and present only that area.

See `JTMOS_GRAOS_INTEGRATION.md` for a fuller compositor description.

## SPRDEF

The portable core deliberately contains no GUI event loop. `SPRDEF` calls a host editor with eight 63-byte sprite images. A GraOS editor can provide sprite selection, 24x21 pixels, foreground/multicolor sources, copy/clear and Save/Cancel. Returning 0 commits the edited image bytes.

## File model

JTMOS should load PRG bytes through VFS/FlexFAT and call `cbmvm_load_prg(vm, buffer, size)`. Future BASIC `LOAD`/`SAVE` should use explicit sandboxed host callbacks instead of linking filesystem code into the interpreter.

## Security rules

1. PEEK/POKE address guest memory or registered virtual devices only.
2. No BASIC address is cast to a host pointer.
3. Graphics write only to bounded VM surfaces/state.
4. No raw JTMOS syscall token is exposed to BASIC.
5. File access must pass through capability-scoped host callbacks.
6. Execution remains statement-budgeted and cooperative.
7. Strings, stacks, framebuffer, collision state and paint work queues are bounded.
8. Corrupt PRG line chains are rejected before execution.
9. Host callbacks receive explicit buffers/state, never arbitrary guest pointers.
10. Timer/collision delivery is deterministic at VM statement/video boundaries rather than asynchronous host signal context.
