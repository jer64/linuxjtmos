# JTMOS / GraOS integration notes for CBMVM 0.4

CBMVM does not include GraOS headers. A `cbasic` application owns one `CBMVM`, one `CBMVM_JTMOS_CONTEXT`, its GraOS window surface, and the compositor state.

## Recommended callbacks

Use `graphics_present_dirty` rather than `graphics_present`. The callback receives packed 2-bit source pixels and a dirty rectangle. For each pixel in the rectangle, read the 2-bit source index, map it through `colors[source]`, then write the corresponding GraOS palette/RGBA color.

Use `graphics_damage` for sprite damage. It is called for both old and new sprite bounds. Put those rectangles into the same GraOS invalidation accumulator used by window expose/paint events.

Use `sprite_update` to keep a compositor-side copy of sprite position/attributes/pattern data. Use `sprite_colors` for the two shared multicolor registers. Render sprites after the bitmap/text background when repainting a damaged region; apply sprite priority in that compositor pass.

## Timer

Provide a monotonic microsecond callback backed by the JTMOS timer API:

```c
bindings.monotonic_us = jt_monotonic_us;
bindings.timer_tick = cbasic_video_jiffy;
```

Then call:

```c
rc = cbmvm_jtmos_run_slice(vm, &vmctx, 128);
```

The bridge computes elapsed microseconds and emits exact 50/60 Hz VM jiffies, preserving fractional phase. Do not call `cbmvm_graphic_tick()` once per scheduler slice as a substitute; scheduler frequency and video frequency are different domains.

## Suggested GraOS paint pipeline

1. Merge bitmap dirty and sprite damage into the window invalidation region.
2. Repaint only invalid bitmap/text background pixels.
3. Composite every enabled sprite that intersects the invalid region.
4. Present the invalid GraOS window rectangle.
5. Return to the application event loop and yield normally.

This keeps BASIC drawing, moving sprites and window repainting cooperative and avoids 320x200 full-frame conversion for small changes.

## Split screen

`graphics_mode` exposes mode and split-line state, but the reference 40-column text/bitmap split compositor is not part of the portable VM. Implement it in `cbasic`: the VM owns BASIC semantics while GraOS owns window geometry, clipping and actual pixel format.
