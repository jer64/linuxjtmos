# BASIC 7 graphics support in CBMVM 0.4

CBMVM implements a compact C128-style graphics layer without emulating VIC-II/VDC cycles. BASIC graphics commands modify a sandboxed virtual framebuffer and sprite state; a JTMOS/GraOS host receives presentation and damage callbacks.

## Virtual display

- backing framebuffer: 320 x 200
- storage: 2 bits per pixel, 16,000 bytes total
- pixels store BASIC color **sources** 0..3, not host RGB values
- `COLOR` maps source numbers to Commodore palette indices
- modes 3/4 use multicolor-style logical x coordinates backed by the 320-pixel buffer
- drawing state includes pixel cursor, line width and optional logical coordinate scaling

## PETSCII / C128 character rendering

`CHAR` now uses `cbmvm_petscii.c`, a clean-room 8x8 renderer. It implements the useful PETSCII/C128 presentation domain needed by BASIC graphics: uppercase letters, digits, common punctuation, a procedural graphics-character range and reverse-video handling.

No Commodore character-ROM bytes are distributed in this package. The fallback is therefore deliberately **compatible in behavior rather than ROM-pixel-identical**. An exact CHARGEN asset can later be supplied by a host-side font provider without changing the VM's BASIC parser.

`SCALE` does not alter the character-cell coordinates used by `CHAR`; this matches the C128 command model.

## Screen, query and drawing commands

Implemented:

- `GRAPHIC mode[,clear][,split]`, modes 0..5
- `GRAPHIC CLR`
- `SCNCLR [mode]`
- `RGR(dummy)` — current graphics mode
- `RCLR(source)` — current color assigned to source 0..6
- `RDOT(0)` / `RDOT(1)` — current pixel cursor x/y
- `RDOT(2)` — source value at the current pixel cursor
- `LOCATE x,y`
- `SCALE on[,xmax,ymax]`
- `WIDTH 1|2`
- `DRAW [source],x,y [TO x,y]...`
- `BOX [source],x1,y1[,x2,y2][,angle][,paint]`
- `CIRCLE [source],x,y,xr[,yr][,start][,end][,rotation][,increment]`
- `PAINT [source],x,y[,mode]`
- `CHAR source,column,row[,string][,reverse]`
- `COLOR source,color`

When scaling is active, DRAW/BOX/CIRCLE/PAINT/LOCATE/MOVSPR coordinates pass through the logical-to-physical graphics transform. `CHAR` remains cell-based. Switching `GRAPHIC` mode resets scaling.

`WIDTH 2` draws a compact 2x2 stamp along line paths; `WIDTH 1` restores the single-pixel pen.

## Shapes

Implemented:

- `SSHAPE A$,x1,y1[,x2,y2]`
- `GSHAPE A$[,x,y][,mode]`
- `SPRSAV sprite,A$`
- `SPRSAV A$,sprite`
- `SPRSAV sprite1,sprite2`

CBMVM strings are binary-safe and support 255 payload bytes. SSHAPE/GSHAPE use a documented CBMVM-internal packed 2-bit shape format; it is not promised to match C128 ROM bytes exactly.

For SPRSAV, CBMVM sprite-to-string output is an internal 67-byte envelope: shape width/height metadata, a multicolor flag, then the 63-byte sprite pattern. String-to-sprite also accepts at least 63 raw sprite bytes. This keeps round trips deterministic and safe inside the VM.

## Sprites and query functions

Implemented:

- `SPRITE number[,on][,color][,priority][,x-expand][,y-expand][,multicolor]`
- `MOVSPR number,x,y`
- relative `MOVSPR number,+x,-y`
- `MOVSPR number,angle#speed`
- polar-relative `MOVSPR number,distance;angle`
- `SPRCOLOR multicolor1,multicolor2`
- `RSPCOLOR(1|2)`
- `RSPRITE(sprite,selector)` for enable/color/priority/x-expand/y-expand/multicolor
- `RSPPOS(sprite,selector)` for x/y/speed
- `SPRDEF` through a host editor callback

Eight virtual sprites each contain a 63-byte 24x21 image plus C128-style attributes. `SPRCOLOR` also emits the host `sprite_colors(multicolor1,multicolor2)` callback so a GraOS compositor receives shared multicolor changes without polling VM internals. Expansion and multicolor mode affect collision geometry as well as host presentation.

## Collisions: BUMP and COLLISION

The VM detects:

- sprite against sprite
- opaque sprite pixel against nonzero bitmap source pixel

Collision bits are accumulated until read. `BUMP(1)` returns the sprite-sprite mask and clears that mask. `BUMP(2)` returns the sprite-bitmap mask and clears that mask.

`COLLISION 1,line` and `COLLISION 2,line` register BASIC handlers. A detected collision becomes pending during a video tick. At the next BASIC statement boundary the VM pushes an interrupt-marked GOSUB frame, jumps to the handler line, and resumes the interrupted statement stream after `RETURN`. Handlers do not recursively nest while one collision handler is active. `COLLISION type,0` disables that handler.

This is deterministic statement-boundary delivery rather than cycle-accurate VIC-II IRQ timing.

## Dirty rectangles and GraOS presentation

Every bitmap mutation expands one in-VM dirty rectangle. Presentation consumes it through the preferred callback:

```c
void graphics_present_dirty(..., int x, int y, int w, int h);
```

The callback receives the complete packed framebuffer pointer plus only the rectangle that needs conversion/blitting. If the host does not provide this callback, CBMVM falls back to the older full-frame `graphics_present` callback.

Sprites are composited separately. When a sprite moves or changes state, `graphics_damage` receives both its old and new bounds. GraOS can therefore repaint the background under the old sprite and the destination area without invalidating the entire 320x200 surface.

## Deterministic 50/60 Hz virtual timer

The VM has its own video time domain:

```c
cbmvm_set_video_hz(vm, 50);      /* PAL */
cbmvm_set_video_hz(vm, 60);      /* NTSC */
cbmvm_timer_tick(vm);             /* exactly one video jiffy */
cbmvm_timer_advance_us(vm, dt);   /* fractional host time -> exact jiffies */
```

`cbmvm_timer_advance_us` preserves fractional phase, so repeated non-frame-sized host intervals do not accumulate statement-rate drift. Each video jiffy advances angle/speed sprite motion, samples collisions, increments the 64-bit VM jiffy and optionally calls the host `timer_tick` callback.

The JTMOS bridge exposes `monotonic_us`. `cbmvm_jtmos_run_slice()` calculates elapsed host microseconds and advances the virtual clock automatically before running the next cooperative BASIC slice.

## Deliberate compatibility limits

CBMVM remains a graphics VM rather than a cycle-accurate C128 emulator. Notable limits are:

- no VIC-II raster/cycle contention or exact IRQ timing
- no VDC 80-column graphics surface yet
- no VIC-II per-cell bitmap color restrictions
- no exact bundled C128 CHARGEN ROM image
- SSHAPE/GSHAPE bytes are CBMVM-specific
- collision testing is semantic pixel overlap, not VIC-II register timing
- split-screen modes expose mode/split state to the host; the reference full text/bitmap compositor is still future work

These constraints keep the VM bounded, portable and suitable for JTMOS while leaving a clear path toward stricter compatibility.
