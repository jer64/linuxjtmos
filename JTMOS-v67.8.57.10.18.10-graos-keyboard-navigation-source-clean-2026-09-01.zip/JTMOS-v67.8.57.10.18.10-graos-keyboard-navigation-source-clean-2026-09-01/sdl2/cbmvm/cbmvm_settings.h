#ifndef CBMVM_SETTINGS_H
#define CBMVM_SETTINGS_H

/* Small, deterministic defaults suitable for JTMOS. */
#define CBMVM_RAM_SIZE             65536u
#define CBMVM_C64_BASIC_START      0x0801u
#define CBMVM_C128_BASIC_START     0x1c01u
#define CBMVM_MAX_VARIABLES        128u
#define CBMVM_MAX_VAR_NAME         40u
#define CBMVM_MAX_STRING           256u
#define CBMVM_MAX_ARRAYS           24u
#define CBMVM_MAX_ARRAY_DIMS       4u
#define CBMVM_MAX_DATA_ITEMS       512u
#define CBMVM_INPUT_BUFFER         256u
#define CBMVM_GOSUB_DEPTH          32u
#define CBMVM_FOR_DEPTH            16u
#define CBMVM_DO_DEPTH             16u
#define CBMVM_MAX_FUNCTIONS        16u
#define CBMVM_FN_DEPTH             8u
#define CBMVM_PRINT_ZONE           10u
#define CBMVM_DEFAULT_BUDGET       10000u

#endif
