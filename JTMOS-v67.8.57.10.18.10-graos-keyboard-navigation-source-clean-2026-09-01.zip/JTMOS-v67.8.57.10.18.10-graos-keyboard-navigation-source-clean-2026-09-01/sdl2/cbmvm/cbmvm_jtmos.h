#ifndef CBMVM_JTMOS_H
#define CBMVM_JTMOS_H

#include <stddef.h>
#include <stdint.h>
#include "cbmvm_host.h"

struct CBMVM;

typedef struct {
    void *userdata;
    void (*console_putc)(void *userdata, int ch);
    int  (*console_getc)(void *userdata);
    void (*yield)(void *userdata);
    void (*set_border)(void *userdata, uint8_t color);       /* JTMOS palette 0..15 */
    void (*set_background)(void *userdata, uint8_t color);   /* JTMOS palette 0..15 */
    void (*screen_write)(void *userdata, unsigned int cell, uint8_t petscii);
    void (*color_write)(void *userdata, unsigned int cell, uint8_t color);

    /* GraOS-facing graphics bridge. packed_pixels stores four 2-bit source pixels/byte. */
    void (*screen_clear)(void *userdata);
    void (*graphics_mode)(void *userdata, int mode, int split_line);
    void (*graphics_color)(void *userdata, int source, int basic_color);
    void (*graphics_present)(void *userdata, const uint8_t *packed_pixels, size_t bytes,
                             int width, int height, const uint8_t colors[7],
                             int mode, int split_line);
    void (*graphics_present_dirty)(void *userdata, const uint8_t *packed_pixels, size_t bytes,
                                   int width, int height, const uint8_t colors[7],
                                   int mode, int split_line, int x, int y, int w, int h);
    void (*graphics_damage)(void *userdata, int x, int y, int w, int h);
    uint64_t (*monotonic_us)(void *userdata);
    void (*timer_tick)(void *userdata, unsigned int hz, uint64_t jiffy);
    void (*sprite_colors)(void *userdata, int multicolor1, int multicolor2);
    void (*sprite_update)(void *userdata, int number, int enabled, int x, int y,
                          int color, int priority, int x_expand, int y_expand,
                          int multicolor, const uint8_t data[63]);
    int (*sprite_editor)(void *userdata, uint8_t sprite_data[8][63]);
} CBMVM_JTMOS_BINDINGS;

typedef struct {
    CBMVM_JTMOS_BINDINGS api;
    uint8_t border;
    uint8_t background;
    uint64_t last_monotonic_us;
} CBMVM_JTMOS_CONTEXT;

/* Creates CBMVM_HOST callbacks without depending on GraOS header details. */
void cbmvm_jtmos_host_init(CBMVM_JTMOS_CONTEXT *ctx,
                           const CBMVM_JTMOS_BINDINGS *bindings,
                           CBMVM_HOST *host_out);

/* Run one cooperative VM slice and advance the 50/60 Hz virtual clock from JTMOS time. */
int cbmvm_jtmos_run_slice(struct CBMVM *vm, CBMVM_JTMOS_CONTEXT *ctx, unsigned int statement_budget);

#endif
