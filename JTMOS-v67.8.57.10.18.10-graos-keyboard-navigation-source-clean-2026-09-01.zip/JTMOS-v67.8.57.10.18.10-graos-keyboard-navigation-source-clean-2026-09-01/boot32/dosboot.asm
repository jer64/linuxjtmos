;=================================================================================
; JTMOS protected-mode starter for MS-DOS
; ---------------------------------------
;
; V67.8.57.10.18.2 DOS path:
;   DOS INT 21h reads KERNEL32.NZ through a 64 KiB conventional-memory bounce
;   area.  Because AH=3Fh has a 16-bit byte count, each full 64 KiB chunk is
;   filled by two 32 KiB reads.  The completed chunk is copied in protected
;   mode to JTMOS_BOOT_NZIP_STAGING_PHYS (16 MiB), exactly like the BIOS
;   HDD/floppy boot32pm path.  After the compressed stream has been staged,
;   the loader enters protected mode permanently and expands it directly to
;   JTMOS_KERNEL_LOAD_PHYS (0x00100000).
;
; The compressed input is deliberately kept separate from the 1 MiB raw-kernel
; destination.  Forward in-place decompression at 0x00100000 would overwrite
; unread nzip input.
;
; (C) 2006-2026 by Jari Tuominen.
;=================================================================================

[bits 16]
org 0x100

%define BOOT_VESA_GRAPHICS 1
%define VESA_BOOT_HANDOFF_SIGNATURE 0x41534556
%define GRAOS_VESA_MODE 0x0118
%define GRAOS_VESA_FALLBACK_MODE 0x0112
%define DOS_READ_HALF_CHUNK 0x8000
%define DOS_CHUNK_BYTES     0x10000
%define DOS_BOUNCE_PARAS    0x1000
%define UTILS_HANDOFF_ADDR    0x00001010
%define UTILS_HANDOFF_SIG     0x534C5455 ; "UTLS"
%define UTILS_HANDOFF_VER     1

%include "../kernel32/include/memory_layout.inc"
%include "doskernelmeta.inc"
%include "seg.mac"

; IMPORTANT: a DOS .COM program starts executing at the first emitted byte
; (CS:0100).  a20.inc and e820.inc contain actual procedure bodies, so the
; entry jump MUST be emitted before those includes.  Older DOSBOOT.COM images
; accidentally started inside a20(), whose final RET consumed DOS's initial
; COM return word and exited through PSP:0000/INT 20h.  The visible symptom was
; exactly: DOSBOOT -> immediate DOS prompt with no banner.
begin:
        jmp start

; Keep this invariant assembler-visible as well as covered by the source test.
; COM_ENTRY_OFFSET is scalar because it subtracts the section base.  TIMES with
; a negative count is an assembler error, so any future emitted byte before
; begin makes the build fail; the correct entry offset produces TIMES 0.
COM_ENTRY_OFFSET equ (begin - $$)
times -COM_ENTRY_OFFSET db 0

; These includes emit executable code and therefore must stay AFTER begin.
%include "a20.inc"
%include "e820.inc"

%if kernel_raw_bytes > 1048576
    %error "dosboot: raw kernel exceeds the 1 MiB linked kernel window"
%endif
%if kernel_nz_bytes > JTMOS_BOOT_NZIP_STAGING_BYTES
    %error "dosboot: compressed kernel exceeds the 1 MiB nzip staging window"
%endif

; The selector values intentionally match boot32pm for the selectors inherited
; by kernel32.  code32 is temporarily rebased to the DOS COM image while the
; loader runs, then restored to flat base zero immediately before kernel entry.
code32_idx          equ 0x08
data32_idx          equ 0x10
core32_idx          equ 0x18
code16_idx          equ 0x20
data16_idx          equ 0x28
loader_data32_idx   equ 0x30

;------------------------------------------------------------------------------
; DOS entry. CS=DS=ES=SS=PSP for a normal .COM launch.
;------------------------------------------------------------------------------
start:
        ; A .COM program enters with a valid DOS-owned stack.  Do NOT execute
        ; CLI before checking CR0.PE: under FreeDOS + JEMM386/EMM386 the
        ; program is running in V86 mode and CLI is privileged.  The old entry
        ; sequence could therefore fault before printing even the banner, which
        ; looked exactly like DOSBOOT.COM silently returning to the DOS prompt.
        mov ax,cs
        mov ds,ax
        mov es,ax
        cld

        mov [program_segment],ax

        mov dx,msg_banner
        call dos_puts

        ; Direct CR0/GDT transitions require genuine real mode.  EMM386,
        ; JEMM386, Windows Enhanced Mode and similar hosts run DOS applications
        ; with CR0.PE=1 (typically V86).  Do not use PUSHFD as a V86 probe: with
        ; IOPL<3 it can itself #GP.  SMSW is sufficient here because this loader
        ; only needs to distinguish real mode (PE=0) from a protected/V86 host
        ; (PE=1) before it executes CLI or writes CR0.
        smsw ax
        test al,1
        jnz dos_v86_unsupported

        ; We are now known to be in genuine real mode.  MOV SS inhibits external
        ; interrupts until after the immediately following MOV SP, so the stack
        ; switch is atomic without a premature CLI/STI pair.  This also preserves
        ; DOS's incoming interrupt-enable state.
        mov ax,cs
        mov ss,ax
        mov sp,dos_stack_top

        ; DOS current drive is 0=A:, 1=B:, 2=C: ... and is the closest useful
        ; equivalent of the BIOS boot-drive handoff for a DOS-launched kernel.
        mov ah,0x19
        int 0x21
        xor ah,ah
        mov [boot_drive_word],ax

        call prepare_bounce_area
        jc dos_not_enough_memory
        call init_loader_tables

        mov dx,kernel_filename
        mov ax,0x3D00                 ; DOS open read-only
        int 0x21
        jc dos_open_failed
        mov [dos_handle],ax

        mov dx,msg_loading
        call dos_puts

        ; High-memory PM copies require A20.  a20() deliberately CLI's while it
        ; talks to the 8042, so explicitly re-enable interrupts before DOS I/O.
        call a20
        sti

        mov dword [stream_high_dest],JTMOS_BOOT_NZIP_STAGING_PHYS
        mov dword [stream_remaining],kernel_nz_bytes

.dos_chunk_loop:
        mov eax,dword [stream_remaining]
        test eax,eax
        jz .dos_stream_done
        cmp eax,DOS_CHUNK_BYTES
        jbe .dos_chunk_size_ready
        mov eax,DOS_CHUNK_BYTES
.dos_chunk_size_ready:
        mov dword [stream_chunk_bytes],eax

        ; First half: min(chunk, 32 KiB) -> bounce:0000.
        mov ecx,eax
        cmp ecx,DOS_READ_HALF_CHUNK
        jbe .dos_first_count_ready
        mov ecx,DOS_READ_HALF_CHUNK
.dos_first_count_ready:
        mov ax,[bounce_segment]
        mov ds,ax
        xor dx,dx
        mov bx,[cs:dos_handle]
        mov ah,0x3F
        push cx                         ; DOS may clobber general registers
        int 0x21
        pop si                          ; POP preserves the INT 21h carry flag
        jc .dos_read_error_ds_bounce
        cmp ax,si
        jne .dos_short_read_ds_bounce

        ; Full chunks and final chunks larger than 32 KiB use a second DOS read
        ; into the upper half of the SAME 64 KiB bounce window.
        mov eax,dword [cs:stream_chunk_bytes]
        cmp eax,DOS_READ_HALF_CHUNK
        jbe .dos_chunk_filled
        sub eax,DOS_READ_HALF_CHUNK
        mov cx,ax                      ; remaining part is <= 0x8000
        mov dx,DOS_READ_HALF_CHUNK
        mov bx,[cs:dos_handle]
        mov ah,0x3F
        push cx                         ; keep exact requested byte count
        int 0x21
        pop si
        jc .dos_read_error_ds_bounce
        cmp ax,si
        jne .dos_short_read_ds_bounce

.dos_chunk_filled:
        push cs
        pop ds

        ; Defend the high scratch window even if a stale/corrupt metadata file
        ; is accidentally paired with this COM loader.
        mov eax,dword [stream_high_dest]
        add eax,dword [stream_chunk_bytes]
        jc dos_staging_overflow
        cmp eax,(JTMOS_BOOT_NZIP_STAGING_PHYS + JTMOS_BOOT_NZIP_STAGING_BYTES)
        ja dos_staging_overflow

        ; One PM round-trip per completed <=64 KiB chunk.  pmode_stream_copy32
        ; sees a flat source physical address and copies into the 16 MiB nzip
        ; staging area; it never writes the raw 1 MiB kernel destination.
        call pmode_stream_copy

        mov eax,dword [stream_chunk_bytes]
        add dword [stream_high_dest],eax
        sub dword [stream_remaining],eax
        jmp .dos_chunk_loop

.dos_read_error_ds_bounce:
        push cs
        pop ds
        jmp dos_read_failed

.dos_short_read_ds_bounce:
        push cs
        pop ds
        jmp dos_short_read

.dos_stream_done:
        ; The generated metadata describes the exact compressed stream.  A
        ; shorter file is caught above; also reject a longer/stale KERNEL32.NZ
        ; instead of silently ignoring a tail from a mismatched build.
        push cs
        pop ds
        mov bx,[dos_handle]
        mov cx,1
        mov dx,stream_probe_byte
        mov ah,0x3F
        int 0x21
        jc dos_read_failed
        test ax,ax
        jnz dos_long_read

        mov bx,[dos_handle]
        mov ah,0x3E
        int 0x21                       ; close before abandoning DOS
        jc dos_close_failed

        mov dx,msg_loaded
        call dos_puts

        ; Stage the DOS-side utility bank while INT 21h is still available.
        ; UTILS.ISO is required for this DOSBOOT profile and is copied into a
        ; dedicated 4 MiB physical window which the kernel later reserves from
        ; its allocator.  Only the actual file byte count is published.
        call load_utils_iso
        jc dos_utils_failed

%if BOOT_VESA_GRAPHICS
        ; Select the 32-bpp VESA linear-framebuffer mode while BIOS INT 10h is
        ; still callable.  DOSBOOT keeps the ModeInfoBlock inside its own COM
        ; image for now: physical 0x4000 may belong to DOS, so copying there is
        ; deliberately deferred until ALL DOS/BIOS services are finished.
        call dos_select_vesa_mode
%endif

        ; Do not touch the historical JTMOS low-memory handoff locations while
        ; DOS file services are still needed: 0x1000/0x4200/0x7C00 may overlap
        ; DOS-owned low memory.  Publish them only after the file is closed and
        ; there will be no further INT 21h calls.
        call detect_e820
        ; No DOS/BIOS service is called below this point.  Disable interrupts
        ; before publishing low-memory contracts because those physical bytes
        ; may overlap memory owned by the DOS environment we are abandoning.
        cli
        push es
        mov ax,0x0400
        mov es,ax
        mov dword [es:0x0100],0
        pop es
        call prepare_low_handoff
%if BOOT_VESA_GRAPHICS
        ; From this point onward DOS/BIOS is never called again.  It is now
        ; safe to publish the VBE ModeInfoBlock at the historical physical
        ; 0x4000 contract and mark 0x4100 with "VESA" for kernel32.
        cmp byte [vesa_selected],0
        je .no_dos_vesa_handoff
        call publish_dos_vesa_handoff
.no_dos_vesa_handoff:
%endif

        ; Disable NMI during the final mode transition, matching boot32.
        mov al,0x80
        out 0x70,al

        cli
        lgdt [global_descriptor_table]
        lidt [interrupt_descriptor_table]
        mov eax,cr0
        or eax,1
        mov cr0,eax
        jmp dword code32_idx:pmode_kernel_entry32

;------------------------------------------------------------------------------
; Prepare conventional-memory 64 KiB bounce area immediately after this COM
; image.  The dedicated loader stack is inside the image, so the bounce region
; cannot overwrite the active DOS stack.  PSP:0002 contains the segment just
; beyond the memory block DOS owns for this process.
; Return CF=1 if a full additional 64 KiB does not fit.
;------------------------------------------------------------------------------
prepare_bounce_area:
        mov ax,cs
        add ax,DOS_PROGRAM_PARAS
        mov [bounce_segment],ax
        mov dx,ax
        add dx,DOS_BOUNCE_PARAS
        jc .no_room
        cmp dx,[cs:0x0002]
        ja .no_room
        movzx eax,word [bounce_segment]
        shl eax,4
        mov dword [stream_bounce_phys],eax
        clc
        ret
.no_room:
        stc
        ret

;------------------------------------------------------------------------------
; Load UTILS.ISO with DOS INT 21h into the persistent protected-mode RAM bank.
; The file is measured with DOS seek (AH=42h), rejected if larger than the 4 MiB
; reservation, rewound, then streamed through the same conventional-memory
; bounce buffer used by KERNEL32.NZ.  Returns CF=0 on success, CF=1 on failure
; with utils_error_code selecting a diagnostic below.
;------------------------------------------------------------------------------
load_utils_iso:
        pushad
        mov byte [utils_error_code],0
        mov dword [utils_size],0
        mov dword [utils_phys],JTMOS_BOOT_UTILS_RAM_PHYS

        ; INT 15h/AH=88h reports contiguous extended KiB above 1 MiB.  The
        ; fixed 17..21 MiB RAM bank uses a conservative 32 MiB minimum so the kernel MM database also stays above the bank.
        ; Check before the first PM write so low-memory DOS machines fail
        ; cleanly rather than touching nonexistent physical addresses.
        mov ah,0x88
        int 0x15
        jc .ram_error
        cmp ax,31744
        jb .ram_error

        mov dx,utils_filename
        mov ax,0x3D00
        int 0x21
        jc .open_error
        mov [dos_handle],ax

        ; Query 32-bit file size: seek handle to EOF with signed offset 0.
        mov bx,ax
        xor cx,cx
        xor dx,dx
        mov ax,0x4202
        int 0x21
        jc .seek_error_close
        mov word [utils_size],ax
        mov word [utils_size+2],dx
        mov eax,dword [utils_size]
        test eax,eax
        jz .empty_error_close
        cmp eax,JTMOS_BOOT_UTILS_RAM_BYTES
        ja .large_error_close

        ; Return to offset zero.
        mov bx,[dos_handle]
        xor cx,cx
        xor dx,dx
        mov ax,0x4200
        int 0x21
        jc .seek_error_close

        mov dx,msg_utils_loading
        call dos_puts
        mov dword [stream_high_dest],JTMOS_BOOT_UTILS_RAM_PHYS
        mov eax,dword [utils_size]
        mov dword [stream_remaining],eax

.chunk_loop:
        mov eax,dword [stream_remaining]
        test eax,eax
        jz .done
        cmp eax,DOS_CHUNK_BYTES
        jbe .chunk_size_ready
        mov eax,DOS_CHUNK_BYTES
.chunk_size_ready:
        mov dword [stream_chunk_bytes],eax

        mov ecx,eax
        cmp ecx,DOS_READ_HALF_CHUNK
        jbe .first_count_ready
        mov ecx,DOS_READ_HALF_CHUNK
.first_count_ready:
        mov ax,[bounce_segment]
        mov ds,ax
        xor dx,dx
        mov bx,[cs:dos_handle]
        mov ah,0x3F
        push cx
        int 0x21
        pop si
        jc .read_error_ds
        cmp ax,si
        jne .short_error_ds

        mov eax,dword [cs:stream_chunk_bytes]
        cmp eax,DOS_READ_HALF_CHUNK
        jbe .filled
        sub eax,DOS_READ_HALF_CHUNK
        mov cx,ax
        mov dx,DOS_READ_HALF_CHUNK
        mov bx,[cs:dos_handle]
        mov ah,0x3F
        push cx
        int 0x21
        pop si
        jc .read_error_ds
        cmp ax,si
        jne .short_error_ds

.filled:
        push cs
        pop ds
        mov eax,dword [stream_high_dest]
        add eax,dword [stream_chunk_bytes]
        jc .large_error_close
        cmp eax,(JTMOS_BOOT_UTILS_RAM_PHYS + JTMOS_BOOT_UTILS_RAM_BYTES)
        ja .large_error_close
        call pmode_stream_copy
        mov eax,dword [stream_chunk_bytes]
        add dword [stream_high_dest],eax
        sub dword [stream_remaining],eax
        jmp .chunk_loop

.read_error_ds:
        push cs
        pop ds
        mov byte [utils_error_code],4
        jmp .close_fail
.short_error_ds:
        push cs
        pop ds
        mov byte [utils_error_code],5
        jmp .close_fail

.done:
        mov bx,[dos_handle]
        mov ah,0x3E
        int 0x21
        jc .close_error
        mov dx,msg_utils_loaded
        call dos_puts
        popad
        clc
        ret

.ram_error:
        mov byte [utils_error_code],8
        jmp .fail
.open_error:
        mov byte [utils_error_code],1
        jmp .fail
.seek_error_close:
        mov byte [utils_error_code],2
        jmp .close_fail
.empty_error_close:
        mov byte [utils_error_code],3
        jmp .close_fail
.large_error_close:
        mov byte [utils_error_code],6
.close_fail:
        mov bx,[dos_handle]
        mov ah,0x3E
        int 0x21
        jmp .fail
.close_error:
        mov byte [utils_error_code],7
.fail:
        popad
        stc
        ret

;------------------------------------------------------------------------------
; DOS-side VBE selection.
;
; The VBE ModeInfoBlock is first stored in vesa_mode_info inside the COM
; allocation.  This is important under FreeDOS/MS-DOS: physical 0x4000 cannot
; be assumed free while DOS is still alive.  publish_dos_vesa_handoff copies
; the 256-byte block to physical 0x4000 only after the last DOS/BIOS call.
;------------------------------------------------------------------------------
%if BOOT_VESA_GRAPHICS

dos_select_vesa_mode:
        pushad
        push ds
        push es
        push cs
        pop ds
        mov byte [vesa_selected],0

        mov cx,GRAOS_VESA_MODE
        call dos_try_vesa_mode
        jnc .selected

        mov cx,GRAOS_VESA_FALLBACK_MODE
        call dos_try_vesa_mode
        jc .done

.selected:
        mov byte [vesa_selected],1
.done:
        pop es
        pop ds
        popad
        ret

; Input: CX = VBE mode. CF=0 iff the BIOS reports a supported 32-bpp direct
; colour LFB and accepts the linear-framebuffer mode-set request.
dos_try_vesa_mode:
        push ax
        push bx
        push cx
        push di
        push es

        push cs
        pop es
        mov di,vesa_mode_info
        push cx
        mov ax,0x4F01
        int 0x10
        pop cx
        cmp ax,0x004F
        jne .fail
        test word [es:di+0x00],0x0080     ; linear framebuffer available
        jz .fail
        cmp byte [es:di+0x18],1           ; NumberOfPlanes
        jne .fail
        cmp byte [es:di+0x19],32          ; BitsPerPixel
        jne .fail
        cmp byte [es:di+0x1B],6           ; Direct Color memory model
        jne .fail
        cmp dword [es:di+0x28],0          ; PhysBasePtr
        je .fail

        mov bx,cx
        or bx,0x4000                      ; request linear framebuffer
        mov ax,0x4F02
        int 0x10
        cmp ax,0x004F
        jne .fail
        clc
        jmp .out
.fail:
        stc
.out:
        pop es
        pop di
        pop cx
        pop bx
        pop ax
        ret

publish_dos_vesa_handoff:
        ; Caller has already CLI'd permanently before publishing DOS-owned low
        ; memory.  Do not restore IF until kernel32 has installed its own IDT.
        push ax
        push cx
        push si
        push di
        push ds
        push es
        push cs
        pop ds
        xor ax,ax
        mov es,ax
        mov si,vesa_mode_info
        mov di,0x4000
        mov cx,128
        cld
        rep movsw
        mov dword [es:0x4100],VESA_BOOT_HANDOFF_SIGNATURE
        pop es
        pop ds
        pop di
        pop si
        pop cx
        pop ax
        ret
%endif

;------------------------------------------------------------------------------
; Publish the same low-memory contract as boot32pm.
; 1000 expected raw checksum
; 1002 measured raw checksum (filled by nzip decoder)
; 1004 DOS current drive
; Also provide the legacy boot-sector signature/drive bytes inspected later by
; InitSystem() so DOS boot does not produce a false "invalid loader" warning.
;------------------------------------------------------------------------------
prepare_low_handoff:
        push ax
        push es
        xor ax,ax
        mov es,ax
        mov word [es:0x1000],kchecksum
        mov word [es:0x1002],0
        mov ax,[cs:boot_drive_word]
        mov word [es:0x1004],ax
        mov byte [es:0x7DFD],al
        mov word [es:0x7DFE],0xAA55

        ; Persistent DOSBOOT utility-bank handoff.  Kernel snapshots these
        ; fields immediately after BSS clear, before low memory can be reused.
        mov dword [es:UTILS_HANDOFF_ADDR+0],UTILS_HANDOFF_SIG
        mov dword [es:UTILS_HANDOFF_ADDR+4],UTILS_HANDOFF_VER
        mov eax,dword [cs:utils_phys]
        mov dword [es:UTILS_HANDOFF_ADDR+8],eax
        mov eax,dword [cs:utils_size]
        mov dword [es:UTILS_HANDOFF_ADDR+12],eax
        mov dword [es:UTILS_HANDOFF_ADDR+16],JTMOS_BOOT_UTILS_RAM_BYTES
        pop es
        pop ax
        ret

;------------------------------------------------------------------------------
; Build a GDT whose loader code/data selectors are based at the runtime COM
; segment, while the kernel data selectors are already flat.  This lets a DOS
; program loaded at ANY conventional-memory segment execute temporary PM code.
;------------------------------------------------------------------------------
init_loader_tables:
        pushad
        mov ax,cs
        mov [pmode_stream_real_segment],ax
        movzx eax,ax
        shl eax,4
        mov dword [loader_phys_base],eax

        mov ebx,eax
        add ebx,dummy_descriptor
        mov dword [gdt_start+2],ebx
        mov ebx,eax
        add ebx,interrupt_0
        mov dword [idt_start+2],ebx

        mov edx,eax
        mov word [code32_descriptor+2],dx
        shr edx,16
        mov byte [code32_descriptor+4],dl
        mov byte [code32_descriptor+7],dh

        mov edx,eax
        mov word [code16_descriptor+2],dx
        shr edx,16
        mov byte [code16_descriptor+4],dl
        mov byte [code16_descriptor+7],dh

        mov edx,eax
        mov word [data16_descriptor+2],dx
        shr edx,16
        mov byte [data16_descriptor+4],dl
        mov byte [data16_descriptor+7],dh

        mov edx,eax
        mov word [loader_data32_descriptor+2],dx
        shr edx,16
        mov byte [loader_data32_descriptor+4],dl
        mov byte [loader_data32_descriptor+7],dh
        popad
        ret

;------------------------------------------------------------------------------
; Real-mode callable <=64 KiB bounce -> high-memory copy.
; DOS has filled bounce_segment:0000.  No stack operations are performed after
; PE is enabled, so the DOS real-mode SS cache does not become a PM dependency.
;------------------------------------------------------------------------------
pmode_stream_copy:
        cli
        lgdt [global_descriptor_table]
        lidt [interrupt_descriptor_table]
        mov eax,cr0
        or eax,1
        mov cr0,eax
        jmp dword code32_idx:pmode_stream_copy32

[bits 32]
pmode_stream_copy32:
        mov ax,data32_idx
        mov ds,ax
        mov es,ax
        mov gs,ax
        mov ax,loader_data32_idx
        mov fs,ax

        mov esi,dword [fs:stream_bounce_phys]
        mov edi,dword [fs:stream_high_dest]
        mov ecx,dword [fs:stream_chunk_bytes]
        mov edx,ecx
        shr ecx,2
        cld
        rep movsd
        mov ecx,edx
        and ecx,3
        rep movsb
        jmp word code16_idx:pmode_stream_copy16

[bits 16]
pmode_stream_copy16:
        mov ax,data16_idx
        mov ds,ax
        mov es,ax
        mov fs,ax
        mov gs,ax
        mov eax,cr0
        and eax,0xFFFFFFFE
        mov cr0,eax
        ; Immediate far jump is self-patched with the original DOS CS.
pmode_stream_real_jump:
        db 0xEA
        dw pmode_stream_real_return
pmode_stream_real_segment:
        dw 0

pmode_stream_real_return:
        mov ax,cs
        mov ds,ax
        mov es,ax
        mov fs,ax
        mov gs,ax
        lidt [real_mode_idtr]
        sti
        ret

;------------------------------------------------------------------------------
; Final protected-mode entry.  The nzip decoder consumes the high staging copy
; and writes the exact raw image to 0x00100000.  After successful verification,
; code32's descriptor base is changed from the DOS COM base to zero and the far
; jump reloads CS with the same flat selector used by boot32pm/kernel32.
;------------------------------------------------------------------------------
[bits 32]
pmode_kernel_entry32:
        mov ax,core32_idx
        mov ss,ax
        mov ds,ax
        mov es,ax
        mov gs,ax
        mov esp,JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP
        mov ax,loader_data32_idx
        mov fs,ax

        call nzip_decompress_kernel32
        test eax,eax
        jnz pmode_nzip_failed32

        ; Current CS keeps its cached DOS-COM base until the far jump below.
        ; Only the descriptor TABLE entry is flattened here.
        mov word [fs:code32_descriptor+2],0
        mov byte [fs:code32_descriptor+4],0
        mov byte [fs:code32_descriptor+7],0
        mov ax,core32_idx
        mov fs,ax
        jmp dword code32_idx:JTMOS_KERNEL_LOAD_PHYS

pmode_nzip_failed32:
        mov dword [0x00001008],eax
        mov word [0x000B8000],0x4F44   ; D
        mov word [0x000B8002],0x4F4F   ; O
        mov word [0x000B8004],0x4F53   ; S
        mov word [0x000B8006],0x4F4E   ; N
        mov word [0x000B8008],0x4F5A   ; Z
        mov word [0x000B800A],0x4F21   ; !
        cli
.halt:
        hlt
        jmp .halt

;------------------------------------------------------------------------------
; Tiny protected-mode nzip legacy decoder.  This intentionally matches the
; boot32pm decoder and accepts only the boot-safe --legacy record set.
;------------------------------------------------------------------------------
nzip_decompress_kernel32:
        cld
        mov esi,JTMOS_BOOT_NZIP_STAGING_PHYS
        mov edi,JTMOS_KERNEL_LOAD_PHYS
        mov edx,(JTMOS_BOOT_NZIP_STAGING_PHYS + kernel_nz_bytes)
        mov ebp,(JTMOS_KERNEL_LOAD_PHYS + kernel_raw_bytes)

.nz_next:
        cmp esi,edx
        jae .nz_err_truncated
        movzx eax,byte [esi]
        inc esi
        cmp al,0xE3
        je .nz_marker
        cmp al,0xE4
        je .nz_marker
        cmp al,0xE5
        je .nz_marker
        cmp al,0xEE
        je .nz_marker
        cmp al,0xEF
        je .nz_marker

.nz_literal:
        cmp edi,ebp
        jae .nz_err_output
        mov byte [edi],al
        inc edi
        jmp .nz_next

.nz_marker:
        cmp esi,edx
        jae .nz_err_truncated
        movzx ebx,byte [esi]
        inc esi
        cmp bl,0xFC
        jne .nz_not_control
        cmp al,0xEE
        je .nz_end
        cmp al,0xEF
        je .nz_fix
        cmp al,0xE3
        je .nz_rle
        cmp al,0xE4
        je .nz_backref
        cmp al,0xE5
        je .nz_err_bwt
        jmp .nz_err_format

.nz_not_control:
        cmp edi,ebp
        jae .nz_err_output
        mov byte [edi],al
        inc edi
        dec esi
        jmp .nz_next

.nz_fix:
        lea ebx,[esi+2]
        cmp ebx,edx
        ja .nz_err_truncated
        lea ebx,[edi+2]
        cmp ebx,ebp
        ja .nz_err_output
        mov ax,word [esi]
        mov word [edi],ax
        add esi,2
        add edi,2
        jmp .nz_next

.nz_rle:
        lea ebx,[esi+3]
        cmp ebx,edx
        ja .nz_err_truncated
        movzx ecx,word [esi]
        add esi,2
        test ecx,ecx
        jz .nz_err_format
        mov al,byte [esi]
        inc esi
        mov ebx,edi
        add ebx,ecx
        jc .nz_err_output
        cmp ebx,ebp
        ja .nz_err_output
        rep stosb
        jmp .nz_next

.nz_backref:
        lea ebx,[esi+6]
        cmp ebx,edx
        ja .nz_err_truncated
        movzx ecx,word [esi]
        add esi,2
        mov eax,dword [esi]
        add esi,4
        test ecx,ecx
        jz .nz_err_format
        mov ebx,edi
        sub ebx,JTMOS_KERNEL_LOAD_PHYS
        cmp eax,ebx
        jae .nz_err_backref
        sub ebx,eax
        cmp ecx,ebx
        ja .nz_err_backref
        mov ebx,edi
        add ebx,ecx
        jc .nz_err_output
        cmp ebx,ebp
        ja .nz_err_output
        push esi
        mov esi,JTMOS_KERNEL_LOAD_PHYS
        add esi,eax
        rep movsb
        pop esi
        jmp .nz_next

.nz_end:
        cmp edi,ebp
        jne .nz_err_size
        mov esi,JTMOS_KERNEL_LOAD_PHYS
        mov ecx,kernel_raw_bytes
        xor eax,eax
.nz_sum:
        test ecx,ecx
        jz .nz_sum_done
        movzx ebx,byte [esi]
        add ax,bx
        inc esi
        dec ecx
        jmp .nz_sum
.nz_sum_done:
        mov word [0x00001002],ax
        cmp ax,word [0x00001000]
        jne .nz_err_checksum
        xor eax,eax
        ret

.nz_err_truncated: mov eax,1
        ret
.nz_err_output:    mov eax,2
        ret
.nz_err_format:    mov eax,3
        ret
.nz_err_backref:   mov eax,4
        ret
.nz_err_bwt:       mov eax,5
        ret
.nz_err_size:      mov eax,6
        ret
.nz_err_checksum:  mov eax,7
        ret

[bits 16]
;------------------------------------------------------------------------------
; DOS diagnostics / fatal exits.
;------------------------------------------------------------------------------
dos_puts:
        mov ah,0x09
        int 0x21
        ret

dos_v86_unsupported:
        mov dx,msg_v86_failed
        jmp dos_fatal

dos_utils_failed:
        mov al,[utils_error_code]
        cmp al,1
        je .open
        cmp al,2
        je .seek
        cmp al,3
        je .empty
        cmp al,6
        je .large
        cmp al,7
        je .close
        cmp al,8
        je .ram
        cmp al,5
        je .short
        mov dx,msg_utils_read_failed
        jmp dos_fatal
.open:  mov dx,msg_utils_open_failed
        jmp dos_fatal
.seek:  mov dx,msg_utils_seek_failed
        jmp dos_fatal
.empty: mov dx,msg_utils_empty
        jmp dos_fatal
.large: mov dx,msg_utils_large
        jmp dos_fatal
.close: mov dx,msg_utils_close_failed
        jmp dos_fatal
.ram:   mov dx,msg_utils_ram_failed
        jmp dos_fatal
.short: mov dx,msg_utils_short_read
        jmp dos_fatal

dos_open_failed:
        mov dx,msg_open_failed
        jmp dos_fatal

dos_read_failed:
        mov dx,msg_read_failed
        jmp dos_fatal_close

dos_short_read:
        mov dx,msg_short_read
        jmp dos_fatal_close

dos_long_read:
        mov dx,msg_long_read
        jmp dos_fatal_close

dos_staging_overflow:
        mov dx,msg_staging_overflow
        jmp dos_fatal_close

dos_close_failed:
        mov dx,msg_close_failed
        jmp dos_fatal

dos_not_enough_memory:
        mov dx,msg_memory_failed
        jmp dos_fatal

dos_fatal_close:
        push dx
        mov bx,[dos_handle]
        mov ah,0x3E
        int 0x21
        pop dx
dos_fatal:
        mov ax,cs
        mov ds,ax
        call dos_puts
        mov ax,0x4C01
        int 0x21

;------------------------------------------------------------------------------
; Descriptor tables.  The pseudo-descriptor bases and four loader-relative
; descriptor bases are patched at runtime by init_loader_tables().
;------------------------------------------------------------------------------
global_descriptor_table:
gdt_start:
        dw gdt_size-1,0,0

gdtoff:
dummy_descriptor:
        dw 0,0
        db 0,0,0,0
code32_descriptor:
        dw 0xFFFF,0
        db 0,0x9A,0xCF,0
data32_descriptor:
        dw 0xFFFF,0
        db 0,0x92,0xCF,0
core32_descriptor:
        dw 0xFFFF,0
        db 0,0x92,0xCF,0
code16_descriptor:
        dw 0xFFFF,0
        db 0,0x9A,0x00,0
data16_descriptor:
        dw 0xFFFF,0
        db 0,0x92,0x00,0
loader_data32_descriptor:
        dw 0xFFFF,0
        db 0,0x92,0xCF,0

gdt_size equ $-dummy_descriptor

interrupt_descriptor_table:
idt_start:
        dw idt_size-1,0,0
interrupt_0:
        dw demo_int
        dw code32_idx
        db 0
        db 0x8E
        dw 0
idt_size equ $-interrupt_0

[bits 32]
demo_int:
        iretd

[bits 16]
real_mode_idtr:
        dw 0x03FF
        dd 0

program_segment      dw 0
boot_drive_word      dw 0
dos_handle           dw 0
bounce_segment       dw 0
loader_phys_base     dd 0
stream_bounce_phys   dd 0
stream_high_dest     dd JTMOS_BOOT_NZIP_STAGING_PHYS
stream_chunk_bytes   dd 0
stream_remaining     dd 0
stream_probe_byte    db 0
utils_phys            dd JTMOS_BOOT_UTILS_RAM_PHYS
%if BOOT_VESA_GRAPHICS
vesa_selected         db 0
vesa_mode_info        times 256 db 0
%endif
utils_size            dd 0
utils_error_code      db 0

kernel_filename      db 'KERNEL32.NZ',0
utils_filename       db 'UTILS.ISO',0
msg_banner           db 13,10,'JTMOS DOS nzip loader: 64 KiB protected-mode streaming',13,10,'$'
msg_loading          db 'Loading KERNEL32.NZ ...',13,10,'$'
msg_loaded           db 'Compressed kernel staged; expanding at 0x00100000 ...',13,10,'$'
msg_utils_loading    db 'Loading UTILS.ISO into 17 MiB RAM bank ...',13,10,'$'
msg_utils_loaded     db 'UTILS.ISO staged in protected-mode RAM.',13,10,'$'
msg_open_failed      db 'dosboot: cannot open KERNEL32.NZ',13,10,'$'
msg_read_failed      db 'dosboot: DOS read failed',13,10,'$'
msg_short_read       db 'dosboot: KERNEL32.NZ is shorter than build metadata',13,10,'$'
msg_long_read        db 'dosboot: KERNEL32.NZ is longer than build metadata; rebuild/copy matching pair',13,10,'$'
msg_staging_overflow db 'dosboot: compressed staging window overflow',13,10,'$'
msg_close_failed     db 'dosboot: DOS close failed',13,10,'$'
msg_memory_failed    db 'dosboot: not enough DOS conventional memory for 64 KiB bounce area',13,10,'$'
msg_v86_failed       db 'dosboot: V86/EMM386 host unsupported; boot from plain real-mode DOS',13,10,'$'
msg_utils_open_failed db 'dosboot: cannot open UTILS.ISO',13,10,'$'
msg_utils_seek_failed db 'dosboot: cannot determine/rewind UTILS.ISO size',13,10,'$'
msg_utils_empty       db 'dosboot: UTILS.ISO is empty',13,10,'$'
msg_utils_large       db 'dosboot: UTILS.ISO exceeds 4 MiB RAM-bank capacity',13,10,'$'
msg_utils_read_failed db 'dosboot: DOS read failed while loading UTILS.ISO',13,10,'$'
msg_utils_short_read  db 'dosboot: unexpected EOF while loading UTILS.ISO',13,10,'$'
msg_utils_close_failed db 'dosboot: DOS close failed for UTILS.ISO',13,10,'$'
msg_utils_ram_failed db 'dosboot: UTILS.ISO RAM bank needs at least 32 MiB physical RAM',13,10,'$'

; Keep the active stack inside the COM image.  This is essential: the 64 KiB
; bounce segment begins immediately after program_end and would overlap the
; traditional COM stack near CS:FFFE if we left DOS's default SP in use.
align 16
dos_stack:
        times 4096 db 0
dos_stack_top:
program_end:

; NASM 3.x treats a bare section-relative label as relocatable and therefore
; rejects shift/divide operators applied directly to it.  Subtracting $$ first
; produces a scalar file length.  Add the COM load origin (100h) and 15 for
; paragraph ceiling before shifting.  This is ceil((100h + file_bytes) / 16).
DOS_PROGRAM_PARAS equ (((program_end - $$) + 0x10F) >> 4)
