# JTMOS boot32pm nzip loader

`boot32pm` is the default protected-mode JTMOS boot loader.  It includes the
maintained `boot32/boot.asm` / `boot32/bootmod.inc` sources with
`BOOT32PM_CANDIDATE` and `BOOT32PM_NZIP_KERNEL` enabled.

## Kernel path

The default release stores `kernel32/kernel32.bin.nz` immediately after the
9 KiB boot track.  BIOS services stage that compressed stream below the VGA
hole at physical `0x00010000`.  After protected-mode entry the small boot32
legacy-nzip decoder expands it directly to `JTMOS_KERNEL_LOAD_PHYS`
(`0x00100000`) and verifies the 16-bit checksum of the resulting raw
`kernel32.bin` before entering the kernel.

Both floppy and IDE hard-disk boot use the same nzip contract:

1. `prepare_kernel_handoff` writes the expected raw-kernel checksum to `0x1000`.
2. The BIOS loader stages the compressed stream at `0x10000`.
3. Floppy uses track-rounded reads; HD uses exactly `kernel_nz_sectors` sectors.
4. Protected mode expands `kernel32.bin.nz` at 1 MiB.
5. The decoder writes the measured raw checksum to `0x1002` and compares it
   with the expected checksum at `0x1000`.
6. The BIOS boot drive is handed to the kernel at `0x1004`.

A bootable JTMFS HDD now reserves 576 KiB for the boot-kernel payload at
byte offset 16 KiB.  This exactly matches the conventional-memory staging
window at physical `0x10000..0x9FFFF`; `0xA0000` is the first excluded VGA
address.  Both floppy-track rounding and HDD-sector rounding must remain
inside that same 576 KiB limit.

`CopyKernel()` copies the 576 KiB payload region from the boot floppy to the
HDD.  For boot32pm this region begins with `kernel32.bin.nz`; for legacy boot32
it begins with raw `kernel32.bin`.  The checksum stored in the target boot
sector is copied from bytes 501..502 of the matching source loader and is
always the RAW `kernel32.bin` checksum -- never a checksum of compressed bytes.

Build with:

```sh
make -j2 boot
```

Static source validation is also available:

```sh
./tools/check_boot32_hd_nzip.sh
```

The normal full build additionally validates the raw 1 MiB linked kernel
window, the 576 KiB BIOS staging window, the 576 KiB JTMFS HDD payload region,
and the 9 KiB boot-track size.


## V67.8.57.1 streamed BIOS loader

The default BOOT32PM path no longer keeps the full compressed kernel below
640 KiB. BIOS INT 13h reads one sector at a time into a 64 KiB bounce window
at physical 0x10000. At each 128-sector boundary the loader enters protected
mode, copies the chunk to the 16 MiB boot scratch window, returns to real mode,
and continues BIOS I/O. The compressed and raw kernel limits are each 1 MiB.

Release media are split: A: contains boot32pm + kernel only; B: contains the
root/system SQARC archive. The same archive family may be supplied through an
ATAPI raw image, and sys: chooses a medium by verifying the SQARC520 signature.
