; JTMOS default protected-mode nzip kernel loader.
; BIOS loads the compressed legacy nzip stream below 1 MiB, then protected
; mode expands it directly into the linked kernel window at 0x00100000.
%define BOOT32PM_CANDIDATE 1
%define BOOT32PM_NZIP_KERNEL 1
%define BOOT32PM_STREAM_KERNEL 1
%include "../boot32/boot.asm"
