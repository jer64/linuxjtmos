#!/bin/sh
# Compatibility wrapper for older build scripts.
set -eu
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec make -C "$SCRIPT_DIR" all
