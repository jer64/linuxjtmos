#include <pc.h>
#include <go32.h>
#include <dpmi.h>
#include <jtmos/dma.h>
#include <jtmos/irq.h>
#include <stddef.h>
#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/sysinfo.h>
#include <sys/resource.h>
#include <signal.h>
#include <poll.h>
#include <jtmos/process.h>
#include <jtmos/filefind.h>
#include <jtmos/console.h>
#include <conio.h>
#include <mouse.h>
#include <graphics.h>
#include <jtgame.h>
#include <jtsprite.h>
#include <jtsound.h>
#include <jtmos/turboc.h>

_Static_assert(sizeof(FFBLK) == 296, "SYS_findfirst FFBLK ABI size");
_Static_assert(offsetof(FFBLK, ff_name) == 36, "SYS_findfirst FFBLK name offset");
_Static_assert(offsetof(FFBLK, ff_fsize) == 32, "SYS_findfirst FFBLK size offset");
_Static_assert(JTMFS_ID_DIRECTORY == 0x80, "JTMFS directory ABI bit");
_Static_assert(JTMFS_CLASS_MASK == 0xC0, "JTMFS class mask ABI");
_Static_assert(JTMFS_ATTR_MASK == 0x3F, "JTMFS attribute mask ABI");
_Static_assert(JTMFS_TYPE_IS_DIRECTORY(JTMFS_ID_DIRECTORY | JTMFS_ID_HIDDEN),
               "hidden directory keeps directory class");
_Static_assert(!JTMFS_TYPE_IS_FILE(JTMFS_ID_DIRECTORY | JTMFS_ID_ARCHIVE),
               "directory attributes must not turn it into a file");
_Static_assert(JTMFS_TYPE_IS_DIRNAME(JTMFS_ID_DIRNAME | JTMFS_ID_SYSTEM),
               "dirname metadata keeps class with attributes");
_Static_assert(JTMFS_TYPE_IS_FILE(JTMFS_ID_ARCHIVE | JTMFS_ID_EXECUTABLE),
               "attribute-only regular file keeps file class");
_Static_assert(JTMFS_TYPE_IS_VALID(JTMFS_ID_DIRECTORY | JTMFS_ID_HIDDEN),
               "combined directory classification is valid");
_Static_assert(!JTMFS_TYPE_IS_VALID(JTMFS_CLASS_RESERVED),
               "reserved JTMFS class is invalid");
_Static_assert(sizeof(struct pollfd) == 8, "pollfd ABI size");
_Static_assert(sizeof(struct utsname) == 325, "utsname ABI size");
int jtmos_header_smoke(void){char b[32];snprintf(b,sizeof b,"%u",(unsigned)sizeof(void*));return strcmp(b,"4");}
