#ifndef _JTMOS_JTGAME_H
#define _JTMOS_JTGAME_H

#include <jtmos/graos.h>
#include <jtmos/console.h>

/* Tiny single-window game API for JTMOS/GraOS.
 * The framebuffer is software-rendered; the screen changes only on
 * jtgame_present(), making whole-frame drawing cheap and predictable. */

#define JT_RGB(r,g,b) GRAOS_RGB((r),(g),(b))
#define JT_COLOR(n) JtmosMCGAColorToRGBA((n))

#define JT_KEY_ESC JKEY_ESC
#define JT_KEY_LEFT JKEY_CURSOR_LEFT
#define JT_KEY_RIGHT JKEY_CURSOR_RIGHT
#define JT_KEY_UP JKEY_CURSOR_UP
#define JT_KEY_DOWN JKEY_CURSOR_DOWN
#define JT_KEY_SPACE 32
#define JT_KEY_ENTER 13

#define JT_MOUSE_LEFT   1
#define JT_MOUSE_RIGHT  2
#define JT_MOUSE_MIDDLE 4

int jtgame_open(const char *title,int width,int height);
void jtgame_close(void);
int jtgame_running(void);
int jtgame_width(void);
int jtgame_height(void);
GRAOS_PIXEL *jtgame_pixels(void);

/* Input is event based. jtgame_key() never blocks; jtgame_getch() does. */
int jtgame_key(void);
int jtgame_kbhit(void);
int jtgame_getch(void);

/* Poll GraOS input without blocking.  present() also refreshes mouse state,
 * so the smallest game loop does not need an explicit poll call. */
void jtgame_poll(void);
int jtgame_mouse_x(void);
int jtgame_mouse_y(void);
int jtgame_mouse_buttons(void);
int jtgame_mouse_inside(void);
int jtgame_mouse_down(int button_mask);
int jtgame_mouse_pressed(int button_mask);
int jtgame_mouse_released(int button_mask);
int jtgame_mouse(int *x,int *y,int *buttons);

void jtgame_present(void);
void jtgame_clear(GRAOS_PIXEL color);
void jtgame_pixel(int x,int y,GRAOS_PIXEL color);
GRAOS_PIXEL jtgame_getpixel(int x,int y);
void jtgame_line(int x1,int y1,int x2,int y2,GRAOS_PIXEL color);
void jtgame_rect(int x,int y,int width,int height,GRAOS_PIXEL color);
void jtgame_fillrect(int x,int y,int width,int height,GRAOS_PIXEL color);
void jtgame_circle(int cx,int cy,int radius,GRAOS_PIXEL color);
void jtgame_blit(int x,int y,int width,int height,const GRAOS_PIXEL *pixels);
void jtgame_blit_key(int x,int y,int width,int height,const GRAOS_PIXEL *pixels,GRAOS_PIXEL transparent);

/* Call once per loop after present. fps <= 0 disables pacing. */
void jtgame_wait_frame(int fps);
void jtgame_sleep(unsigned long ms);
unsigned long jtgame_ticks(void);

#endif
