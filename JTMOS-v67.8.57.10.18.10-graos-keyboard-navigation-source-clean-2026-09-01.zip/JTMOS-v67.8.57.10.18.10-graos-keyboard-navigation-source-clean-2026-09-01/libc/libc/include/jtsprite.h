#ifndef _JTMOS_JTSPRITE_H
#define _JTMOS_JTSPRITE_H

#include <jtgame.h>

#define JTSPRITE_DRAW_NONE       0x0000
#define JTSPRITE_FLIP_X          0x0001
#define JTSPRITE_FLIP_Y          0x0002
#define JTSPRITE_TRANSPARENT_KEY 0x0004
#define JTSPRITE_TRANSPARENT_A0  0x0008

typedef struct JTSprite {
    GRAOS_PIXEL *pixels;
    int sheet_width,sheet_height;
    int frame_width,frame_height;
    int columns,frame_count;
    int frame;
    int anim_first,anim_last,anim_fps,anim_loop;
    unsigned long anim_next;
    GRAOS_PIXEL transparent_key;
    unsigned int draw_flags;
    int owns_pixels;
} JTSprite;

/* A sprite sheet is laid out left-to-right, top-to-bottom. */
int jtsprite_init(JTSprite *s,GRAOS_PIXEL *pixels,int sheet_width,int sheet_height,
                  int frame_width,int frame_height);
int jtsprite_load_raw32(JTSprite *s,const char *path,int sheet_width,int sheet_height,
                        int frame_width,int frame_height);
int jtsprite_load_raw8(JTSprite *s,const char *path,int sheet_width,int sheet_height,
                       int frame_width,int frame_height);
void jtsprite_free(JTSprite *s);

void jtsprite_set_frame(JTSprite *s,int frame);
void jtsprite_set_key(JTSprite *s,GRAOS_PIXEL key);
void jtsprite_set_flags(JTSprite *s,unsigned int flags);
void jtsprite_set_animation(JTSprite *s,int first,int last,int fps,int loop);
void jtsprite_update(JTSprite *s,unsigned long now);

void jtsprite_draw(const JTSprite *s,int x,int y);
void jtsprite_draw_frame(const JTSprite *s,int x,int y,int frame);
void jtsprite_draw_ex(const JTSprite *s,int x,int y,int frame,int scale,unsigned int extra_flags);

int jtsprite_overlap(int ax,int ay,int aw,int ah,int bx,int by,int bw,int bh);
int jtsprite_contains(int x,int y,int w,int h,int px,int py);

#endif
