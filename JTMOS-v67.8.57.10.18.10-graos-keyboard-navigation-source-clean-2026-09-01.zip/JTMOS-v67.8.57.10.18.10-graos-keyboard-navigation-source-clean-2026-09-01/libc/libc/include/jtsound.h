#ifndef _JTMOS_JTSOUND_H
#define _JTMOS_JTSOUND_H

#include <stddef.h>

#define JTSOUND_DEFAULT_RATE 11025
#define JTSOUND_MAX_VOICES 8
#define JTSOUND_VOLUME_MAX 255

typedef struct JTSoundSample {
    unsigned char *data;
    unsigned long length;
    int rate;
    int owns_data;
} JTSoundSample;

/* The mixer emits unsigned 8-bit mono to JTMOS's generic SB/GUS audio FIFO. */
int jtsound_init(void);
int jtsound_init_rate(int mix_rate);
void jtsound_shutdown(void);
void jtsound_update(void);
void jtsound_stop_all(void);
int jtsound_busy(void);
int jtsound_pending(void);
int jtsound_rate(void);
void jtsound_set_master_volume(int volume);

int jtsound_sample_init(JTSoundSample *sample,const unsigned char *data,
                        unsigned long length,int rate);
int jtsound_load_raw(JTSoundSample *sample,const char *path,int rate);
int jtsound_load_wav(JTSoundSample *sample,const char *path);
void jtsound_free_sample(JTSoundSample *sample);

/* Return a voice number [0..JTSOUND_MAX_VOICES-1], or a negative error. */
int jtsound_play(const JTSoundSample *sample,int volume,int loop);
int jtsound_tone(int frequency,int milliseconds,int volume);
int jtsound_beep(void);
void jtsound_stop(int voice);
int jtsound_voice_active(int voice);
void jtsound_voice_volume(int voice,int volume);

#endif
