#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
IMG=${1:-"$HERE/GraOS-boot-test.img"}
exec qemu-system-i386 -m 64 -drive file="$IMG",format=raw,if=floppy -boot a
