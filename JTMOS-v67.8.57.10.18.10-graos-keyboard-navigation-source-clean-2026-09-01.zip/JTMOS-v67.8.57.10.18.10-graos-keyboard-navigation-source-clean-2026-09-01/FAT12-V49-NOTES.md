# JTMOS FAT12 V49 cleanup

The old kernel32/fs/fat12 implementation was an unfinished 1.44 MiB read-only prototype.
V49 replaces it with BPB-derived FAT12 access while retaining the legacy _msdos_* entry points.

Implemented:
- BPB validation and FAT12 (<4085 cluster) type detection.
- Standard 12-bit packed FAT get/set, including odd/even cluster entries.
- Both FAT copies flushed on write.
- Root directory from BPB and cluster-chain subdirectories.
- DOS 8.3 case-insensitive short names; LFN entries are safely ignored.
- File read/write, create, append, truncate and set-size.
- Cluster allocation, chain extension, truncation and freeing.
- Directory enumeration and helpers for mkdir/unlink/existence.
- On-demand data/directory sector I/O; the whole 1.44 MiB disk is no longer buffered.
- FAT is cached in memory (normally only a few KiB on floppy FAT12 media).
- Hard-coded offsets 0x1400/0x2600 and fixed 2880-sector assumptions removed.
- Correct 32-byte FAT directory entry layout.

Deliberate limits in V49:
- DOS long file names (VFAT LFN) are ignored; creation is 8.3 only.
- The underlying JTMOS device block size must currently match the BPB sector size; boot mount currently starts with a 512-byte sector assumption.
- FAT16/FAT32 are rejected, not misinterpreted as FAT12.
- Partition-offset mounting is not part of this module yet; pass a partition block device if needed.
- A FAT12 formatter is not added in this change. Existing MS-DOS formatted FAT12 volumes are read/write.
- DOS timestamps are preserved for existing directory entries but new entries currently use zero timestamps.
