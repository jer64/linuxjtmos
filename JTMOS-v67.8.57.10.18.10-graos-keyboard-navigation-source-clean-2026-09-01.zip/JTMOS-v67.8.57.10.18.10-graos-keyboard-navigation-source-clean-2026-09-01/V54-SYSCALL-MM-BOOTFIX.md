# JTMOS V54 — syscall/MM clean-rebuild regression fix

V53 booted through MM, IDT, PIT and GDT initialization but stopped after
`Initializing System Calls.`. The first allocator-heavy action in `scall_init()`
is `init_filedes()`.

The V52/V51 release lineage contained known-working prebuilt MM and legacy NASM
objects. V53 was the first full clean rebuild of those areas in this release
sequence. In particular, `mm/mmAlloc.c` was rebuilt against the V52 cooperative
`LOCK` macro, changing allocator machine code even though the MM source itself
was unchanged. The V53 full rebuild also used a GNU-as compatibility path for
legacy NASM sources because NASM was unavailable in the build environment.

V54 therefore uses a conservative regression build:

* starts from the V51 known-working object set (GCC 14.2.0, i386);
* overlays the complete V53 source changes;
* recompiles every active C module actually changed by V52/V53;
* keeps unchanged MM and legacy NASM objects from the known-working lineage;
* links the full current V53/V54 source tree plus the new `sh/fsadmin.o`;
* retains the V53 SMSH root/mount/rootinstall policy and FDC DMA buffer at
  physical 0x00080000;
* adds serial diagnostics around syscall gate installation and FD database init.

Expected boot diagnostics now include:

    [SCALL] installing INT 0x7F gate...
    [SCALL] INT 0x7F gate installed.
    [SCALL] installing reserved INT 0x7E gate...
    [SCALL] INT 0x7E gate installed.
    [SCALL] initializing file descriptor database...
    [SCALL] file descriptor database initialized.
    System calls are enabled.

This build intentionally preserves its included object files. Until the clean
rebuild regression is fully isolated, do not run `make clean` when reproducing
this exact V54 boot image. `make purelinkit` / `make -f generated.mak linkit`
can relink the supplied object set.
