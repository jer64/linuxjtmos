# JTMOS V53 — SMSH root policy + safe mkfs + floppy DMA relocation

## Boot/root policy

KernelInit no longer formats or mounts `ram:` as the root filesystem.  After
storage probing and restoration of the normal PIT/TSS scheduler it starts SMSH,
and SMSH owns the root policy:

1. If `hda:` contains JTMFS **and** a non-zero rootinstall/kernel checksum in
   the JTMOS boot record, SMSH mounts `hda:` as `/`.
2. A merely `mkfs`-formatted `hda:` is not considered installed.
3. Otherwise SMSH enables `ram:`.  It formats `ram:` only if it is not already
   JTMFS, and mounts it as the volatile rescue/install root.

This keeps destructive filesystem creation out of KernelInit and permits the
normal installation workflow:

    mkfs hda
    cd hda
    sqa sys
    rootinstall hda
    reboot

## New SMSH inline commands

- `mount [device]` — list block devices or enable one device.
- `umount DEVICE` / `unmount DEVICE` — disable a device if it is not busy.
- `root DEVICE` — switch the JTMOS namespace root and the SMSH current root.
- `rootinstall TARGET [BOOT-SOURCE]` — copy the running boot medium's 512 KiB
  kernel region to the JTMFS boot area and update the boot checksum.
- `bootroot` — rerun the SMSH root selection policy.

`mkfs` now rejects a device if it is the current root, any live thread has its
CWD on that DNR, or any open file descriptor belongs to that DNR.  Error 16 is
used as the JTMOS EBUSY-style result.

## JTMFS boot freeze correction

The cooperative FAT/JTMFS yield no longer calls `SwitchToThread()` on iteration
zero and is disabled until `systemStarted & 1`.  This removes the V52 bootstrap
hazard at the first `jtmfat_getfreeblock1()` scan.

## Floppy DMA

The active 3.5-inch 1.44M floppy driver now uses a dedicated ISA DMA bounce
window at physical `0x00080000` (`0x80000..0x8ffff`) instead of `0x90000`.
This is 64 KiB aligned, below the ISA DMA 16 MiB ceiling, above the linked
low kernel text/data, and farther from the legacy 0x90000/EBDA neighbourhood.
The mirrored legacy IRQ floppy source was updated to the same address.
