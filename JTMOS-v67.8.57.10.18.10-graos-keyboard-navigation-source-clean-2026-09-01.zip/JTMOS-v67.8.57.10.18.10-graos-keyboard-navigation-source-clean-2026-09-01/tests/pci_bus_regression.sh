#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
PCI="$ROOT/kernel32/drivers/pci/pci.c"
H="$ROOT/kernel32/drivers/pci/pci.h"
AHCI="$ROOT/kernel32/drivers/sata/ahci.c"
HD="$ROOT/kernel32/drivers/hd/hdService.c"
AUTO="$ROOT/kernel32/autogen.pl"
SH="$ROOT/kernel32/sh/sh.c"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }

grep -q 'for(bus=0; bus<256;' "$PCI" || fail "PCI scanner does not enumerate all buses"
grep -q 'for(dev=0; dev<32;' "$PCI" || fail "PCI scanner does not enumerate all devices"
grep -q 'maxfun=(hdr&0x80U) ? 8 : 1' "$PCI" || fail "multifunction scan missing"
pass "bus/device/function enumeration"

! grep -q 'inportb(0xcf8==0x80000000)' "$PCI" || fail "old mechanism-1 typo remains"
! grep -Eq 'if\([[:space:]]*a1=0xffff' "$PCI" || fail "old assignment-vs-compare bug remains"
grep -q 'probe==0x80000000UL' "$PCI" || fail "mechanism-1 readback test missing"
pass "historical scanner bugs removed"

grep -q 'pci_config_read8' "$H" || fail "8-bit config API missing"
grep -q 'pci_config_read16' "$H" || fail "16-bit config API missing"
grep -q 'pci_config_read32' "$H" || fail "32-bit config API missing"
grep -q 'get_eflags(); disable();' "$PCI" || fail "CF8/CFC transactions are not IRQ serialized"
pass "shared serialized config-space API"

grep -q 'pci_scan_capabilities' "$PCI" || fail "capability parser missing"
grep -q 'PCI_CAP_ID_MSI' "$PCI" || fail "MSI capability missing"
grep -q 'PCI_CAP_ID_MSIX' "$PCI" || fail "MSI-X capability missing"
grep -q 'PCI_CAP_ID_EXP' "$PCI" || fail "PCIe capability missing"
grep -q 'int pci_get_bar' "$PCI" || fail "BAR decoder missing"
pass "capability and BAR decoding"

grep -q 'pci_find_device' "$H" || fail "vendor/device lookup API missing"
grep -q 'pci_find_class' "$H" || fail "class lookup API missing"
grep -q 'pci_enable_device' "$H" || fail "enable API missing"
pass "driver-facing PCI device API"

grep -q '#include "pci.h"' "$AHCI" || fail "AHCI does not use PCI core"
grep -q 'pci_find_class' "$AHCI" || fail "AHCI class lookup missing"
grep -q 'pci_get_bar(pdev,5' "$AHCI" || fail "AHCI BAR5 does not use shared BAR API"
! grep -q 'static DWORD pci_read32' "$AHCI" || fail "AHCI still has private PCI scanner/config reader"
pass "AHCI reuses existing JTMOS PCI scanner"

grep -q 'drivers/(?:pci|sata)' "$AUTO" || fail "PCI=0 dependency filtering missing"
grep -q '#if JTMOS_MOD_PCI' "$HD" || fail "legacy IDE fallback is not guarded for PCI=0"
pass "PCI-disabled profiles retain legacy IDE"

grep -q '"lspci", lspci_builtin' "$SH" || fail "lspci command missing"
grep -q 'pci_get_bar' "$SH" || fail "lspci -v BAR output missing"
pass "SMSH lspci command"

echo "PASS: JTMOS PCI bus regression complete"
