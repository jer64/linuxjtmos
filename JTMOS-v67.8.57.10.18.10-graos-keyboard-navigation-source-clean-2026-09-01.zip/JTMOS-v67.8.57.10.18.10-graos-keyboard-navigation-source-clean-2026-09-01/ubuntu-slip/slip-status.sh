#!/bin/sh
set -eu
RUNTIME=${JTMOS_SLIP_RUNTIME:-${XDG_RUNTIME_DIR:-/tmp}/jtmos-slip}
STATE=$RUNTIME/state
if [ ! -f "$STATE" ]; then
  echo 'JTMOS SLIP: down'
  exit 1
fi
# shellcheck disable=SC1090
. "$STATE"
echo 'JTMOS SLIP: configured'
printf '  pipe: %s.in / %s.out\n' "$PIPE_BASE" "$PIPE_BASE"
printf '  PTY: %s\n  iface: %s\n  peer: %s <-> %s\n  uplink: %s\n' "$PTY" "$SLIF" "$HOST_IP" "$GUEST_IP" "$WAN"
if kill -0 "$RELAY_PID" 2>/dev/null; then echo '  relay: running'; else echo '  relay: stopped'; fi
if sudo kill -0 "$SLATTACH_PID" 2>/dev/null; then echo '  slattach: running (plain slip)'; else echo '  slattach: stopped'; fi
ip -brief addr show dev "$SLIF" 2>/dev/null || true
ip route get "$GUEST_IP" 2>/dev/null || true
