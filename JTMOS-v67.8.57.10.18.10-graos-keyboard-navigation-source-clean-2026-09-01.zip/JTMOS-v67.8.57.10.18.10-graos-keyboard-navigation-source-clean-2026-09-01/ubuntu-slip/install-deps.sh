#!/bin/sh
set -eu
printf '%s\n' 'Installing JTMOS plain-SLIP host dependencies for Ubuntu...'
sudo apt-get update
sudo apt-get install -y qemu-system-x86 net-tools iproute2 iptables python3 curl
printf '%s\n' 'Loading Linux SLIP module...'
sudo modprobe slip
printf '%s\n' 'Done. slattach is supplied by the net-tools package.'
