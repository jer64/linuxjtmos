#!/usr/bin/env python3
"""Bridge QEMU's two named serial FIFOs to one PTY for Linux slattach.

QEMU -serial pipe:/path/jtmos-slip uses:
  /path/jtmos-slip.in   host -> QEMU/JTMOS
  /path/jtmos-slip.out  QEMU/JTMOS -> host

Linux slattach needs a TTY, so this relay exposes a PTY slave and copies bytes
without interpreting them.  RFC1055 framing is handled by Linux SLIP and JTMOS;
there is deliberately no CSLIP/VJ compression here.
"""
import argparse
import errno
import fcntl
import os
import pty
import selectors
import signal
import sys
import termios
import tty

running = True

def stop(_sig, _frame):
    global running
    running = False


def ensure_fifo(path: str) -> None:
    try:
        st = os.stat(path)
    except FileNotFoundError:
        os.mkfifo(path, 0o600)
        return
    if not __import__('stat').S_ISFIFO(st.st_mode):
        raise RuntimeError(f"{path} exists but is not a FIFO")


def nonblock(fd: int) -> None:
    flags = fcntl.fcntl(fd, fcntl.F_GETFL)
    fcntl.fcntl(fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)


def write_all_nonblocking(fd: int, data: bytes) -> None:
    view = memoryview(data)
    while view and running:
        try:
            n = os.write(fd, view)
            view = view[n:]
        except BlockingIOError:
            continue
        except OSError as exc:
            if exc.errno in (errno.EAGAIN, errno.EINTR):
                continue
            raise


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--base', required=True, help='QEMU pipe base pathname')
    ap.add_argument('--pty-file', required=True, help='write PTY slave pathname here')
    args = ap.parse_args()

    base = os.path.abspath(args.base)
    in_fifo = base + '.in'
    out_fifo = base + '.out'
    os.makedirs(os.path.dirname(base), exist_ok=True)
    ensure_fifo(in_fifo)
    ensure_fifo(out_fifo)

    master, slave = pty.openpty()
    tty.setraw(slave, when=termios.TCSANOW)
    nonblock(master)

    # O_RDWR avoids FIFO open-order deadlocks while QEMU starts/stops.
    qemu_in = os.open(in_fifo, os.O_RDWR | os.O_NONBLOCK)
    qemu_out = os.open(out_fifo, os.O_RDWR | os.O_NONBLOCK)

    slave_name = os.ttyname(slave)
    with open(args.pty_file, 'w', encoding='ascii') as fh:
        fh.write(slave_name + '\n')
    os.chmod(args.pty_file, 0o600)

    # Keep the slave fd open until slattach has had a chance to open it.
    print(slave_name, flush=True)

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    sel = selectors.DefaultSelector()
    # Kernel SLIP bytes written to PTY appear on master -> QEMU .in.
    sel.register(master, selectors.EVENT_READ, ('pty', qemu_in))
    # JTMOS/QEMU serial output appears in .out -> PTY master -> Linux SLIP.
    sel.register(qemu_out, selectors.EVENT_READ, ('qemu', master))

    try:
        while running:
            for key, _mask in sel.select(timeout=0.5):
                src = key.fd
                _name, dst = key.data
                try:
                    data = os.read(src, 65536)
                except BlockingIOError:
                    continue
                except OSError as exc:
                    if exc.errno in (errno.EAGAIN, errno.EINTR, errno.EIO):
                        continue
                    raise
                if data:
                    write_all_nonblocking(dst, data)
    finally:
        try:
            os.unlink(args.pty_file)
        except FileNotFoundError:
            pass
        for fd in (qemu_in, qemu_out, master, slave):
            try:
                os.close(fd)
            except OSError:
                pass
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
