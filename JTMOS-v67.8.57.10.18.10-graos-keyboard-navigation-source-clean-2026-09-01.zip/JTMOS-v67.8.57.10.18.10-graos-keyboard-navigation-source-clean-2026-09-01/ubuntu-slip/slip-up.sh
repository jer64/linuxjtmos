#!/bin/sh
set -eu
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
RUNTIME=${JTMOS_SLIP_RUNTIME:-${XDG_RUNTIME_DIR:-/tmp}/jtmos-slip}
PIPE_BASE=${JTMOS_SLIP_PIPE:-$RUNTIME/jtmos-slip}
HOST_IP=${JTMOS_SLIP_HOST_IP:-10.0.0.1}
GUEST_IP=${JTMOS_SLIP_GUEST_IP:-10.0.0.5}
BPS=${JTMOS_SLIP_BPS:-115200}
MTU=${JTMOS_SLIP_MTU:-1006}
STATE=$RUNTIME/state
PTY_FILE=$RUNTIME/pty
RELAY_PID_FILE=$RUNTIME/relay.pid
SLATTACH_PID_FILE=$RUNTIME/slattach.pid
LOG=$RUNTIME/relay.log
SLLOG=$RUNTIME/slattach.log

need() { command -v "$1" >/dev/null 2>&1 || { echo "Missing dependency: $1" >&2; exit 1; }; }
need python3
need ip
need sudo
if ! command -v slattach >/dev/null 2>&1 && [ ! -x /usr/sbin/slattach ]; then
  echo 'Missing slattach. Run ./install-deps.sh (package: net-tools).' >&2
  exit 1
fi
SLATTACH=$(command -v slattach 2>/dev/null || printf /usr/sbin/slattach)

mkdir -p "$RUNTIME"
chmod 700 "$RUNTIME"
if [ -f "$STATE" ]; then
  echo "JTMOS SLIP state already exists: $STATE" >&2
  echo 'Run ./slip-status.sh or ./slip-down.sh first.' >&2
  exit 1
fi

# Start byte-for-byte FIFO <-> PTY bridge. It creates PIPE_BASE.in/.out.
"$SCRIPT_DIR/slip_pipe_bridge.py" --base "$PIPE_BASE" --pty-file "$PTY_FILE" >"$LOG" 2>&1 &
RELAY_PID=$!
printf '%s\n' "$RELAY_PID" > "$RELAY_PID_FILE"

cleanup_fail() {
  kill "$RELAY_PID" 2>/dev/null || true
  rm -f "$RELAY_PID_FILE" "$PTY_FILE" "$PIPE_BASE.in" "$PIPE_BASE.out"
}
trap cleanup_fail INT TERM HUP EXIT

i=0
while [ ! -s "$PTY_FILE" ] && [ "$i" -lt 50 ]; do
  sleep 0.1
  i=$((i+1))
done
if [ ! -s "$PTY_FILE" ]; then
  echo "PTY relay did not start; see $LOG" >&2
  exit 1
fi
PTY=$(sed -n '1p' "$PTY_FILE")

sudo modprobe slip
BEFORE=$(ip -o link show | awk -F': ' '$2 ~ /^sl[0-9]+(@.*)?$/ {sub(/@.*/,"",$2); print $2}')
rm -f "$SLATTACH_PID_FILE"
# -p slip is deliberately plain RFC1055 SLIP, not cslip/adaptive/VJ.
# -d keeps slattach attached to this command so its real child PID is stable.
sudo sh -c 'echo $$ > "$1"; exec "$2" -d -p slip -s "$3" "$4"' sh \
  "$SLATTACH_PID_FILE" "$SLATTACH" "$BPS" "$PTY" >"$SLLOG" 2>&1 &

i=0
SLIF=''
while [ "$i" -lt 50 ]; do
  AFTER=$(ip -o link show | awk -F': ' '$2 ~ /^sl[0-9]+(@.*)?$/ {sub(/@.*/,"",$2); print $2}')
  for x in $AFTER; do
    found=0
    for y in $BEFORE; do [ "$x" = "$y" ] && found=1; done
    if [ "$found" -eq 0 ]; then SLIF=$x; break; fi
  done
  [ -n "$SLIF" ] && break
  sleep 0.1
  i=$((i+1))
done
if [ -z "$SLIF" ]; then
  echo "slattach did not create a new slN interface; see $SLLOG" >&2
  if [ -s "$SLATTACH_PID_FILE" ]; then sudo kill "$(cat "$SLATTACH_PID_FILE")" 2>/dev/null || true; fi
  exit 1
fi

WAN=$(ip route show default 0.0.0.0/0 | awk 'NR==1 {for(i=1;i<=NF;i++) if($i=="dev") {print $(i+1); exit}}')
if [ -z "$WAN" ]; then
  echo 'No default IPv4 route found; cannot configure Internet NAT.' >&2
  sudo kill "$(cat "$SLATTACH_PID_FILE")" 2>/dev/null || true
  exit 1
fi

OLD_FORWARD=$(sysctl -n net.ipv4.ip_forward 2>/dev/null || echo 0)
sudo ip addr add "$HOST_IP/32" peer "$GUEST_IP/32" dev "$SLIF"
sudo ip link set dev "$SLIF" mtu "$MTU" up
sudo sysctl -q -w net.ipv4.ip_forward=1

# Host Internet sharing. These are ordinary iptables rules and work on Ubuntu's
# iptables-nft compatibility layer too.
sudo iptables -t nat -C POSTROUTING -s "$GUEST_IP/32" -o "$WAN" -m comment --comment JTMOS-SLIP -j MASQUERADE 2>/dev/null || \
  sudo iptables -t nat -A POSTROUTING -s "$GUEST_IP/32" -o "$WAN" -m comment --comment JTMOS-SLIP -j MASQUERADE
sudo iptables -C FORWARD -i "$SLIF" -o "$WAN" -s "$GUEST_IP/32" -m comment --comment JTMOS-SLIP -j ACCEPT 2>/dev/null || \
  sudo iptables -I FORWARD 1 -i "$SLIF" -o "$WAN" -s "$GUEST_IP/32" -m comment --comment JTMOS-SLIP -j ACCEPT
sudo iptables -C FORWARD -i "$WAN" -o "$SLIF" -d "$GUEST_IP/32" -m conntrack --ctstate ESTABLISHED,RELATED -m comment --comment JTMOS-SLIP -j ACCEPT 2>/dev/null || \
  sudo iptables -I FORWARD 1 -i "$WAN" -o "$SLIF" -d "$GUEST_IP/32" -m conntrack --ctstate ESTABLISHED,RELATED -m comment --comment JTMOS-SLIP -j ACCEPT
sudo iptables -t mangle -C FORWARD -i "$SLIF" -p tcp --tcp-flags SYN,RST SYN -m comment --comment JTMOS-SLIP -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null || \
  sudo iptables -t mangle -I FORWARD 1 -i "$SLIF" -p tcp --tcp-flags SYN,RST SYN -m comment --comment JTMOS-SLIP -j TCPMSS --clamp-mss-to-pmtu

cat > "$STATE" <<EOF
PIPE_BASE=$PIPE_BASE
PTY=$PTY
SLIF=$SLIF
WAN=$WAN
HOST_IP=$HOST_IP
GUEST_IP=$GUEST_IP
BPS=$BPS
MTU=$MTU
OLD_FORWARD=$OLD_FORWARD
RELAY_PID=$RELAY_PID
SLATTACH_PID=$(cat "$SLATTACH_PID_FILE")
EOF
chmod 600 "$STATE"
trap - INT TERM HUP EXIT

echo "JTMOS plain SLIP is ready."
echo "  QEMU pipe:  $PIPE_BASE.in / $PIPE_BASE.out"
echo "  PTY:        $PTY"
echo "  Linux iface:$SLIF"
echo "  host/peer:  $HOST_IP <-> $GUEST_IP"
echo "  uplink:     $WAN (IPv4 NAT enabled)"
echo
echo "Now start QEMU with ../run_jtmos_qemu.sh, then in SMSH: internet"
echo "For the JTMOS web server: www start"
