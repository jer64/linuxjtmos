# JTMOS <-> Ubuntu RFC1055 SLIP bridge

This is **plain SLIP (RFC1055)**. It does not use CSLIP, VJ compression or
adaptive SLIP.

The bridge uses QEMU COM2 and two named pipes:

- `jtmos-slip.in`: Ubuntu/Linux SLIP -> QEMU COM2 -> JTMOS
- `jtmos-slip.out`: JTMOS COM2 -> QEMU -> Ubuntu/Linux SLIP

A small Python relay joins those two FIFOs to a PTY because Linux `slattach`
requires a TTY. `slattach -p slip` then creates a Linux `slN` interface.

Addresses:

- Ubuntu: `10.0.0.1`
- JTMOS: `10.0.0.5`
- serial: COM2, 115200, 8N1
- SLIP MTU: 1006 bytes (matches the JTMOS receive buffer)

## Install dependencies

```sh
cd ubuntu-slip
./install-deps.sh
```

Ubuntu packages used: `qemu-system-x86`, `net-tools` (`slattach`), `iproute2`,
`iptables`, `python3`, and `curl` for testing.

## Start

Either use the one-command wrapper (it tears the host link down when QEMU exits):

```sh
./run-qemu-slip.sh
```

or start the bridge and QEMU separately:

Terminal 1:

```sh
./slip-up.sh
```

Terminal 2, from the JTMOS tree:

```sh
./run_jtmos_qemu.sh
```

In SMSH:

```text
internet
internet status
www start
www status
```

Then Ubuntu can test the JTMOS HTTP server:

```sh
ping 10.0.0.5
curl http://10.0.0.5/
```

The host script enables IPv4 forwarding and MASQUERADE for `10.0.0.5`, so
JTMOS IP traffic can leave through Ubuntu's current default IPv4 interface.
Forwarded TCP SYN packets are MSS-clamped to the 1006-byte SLIP path MTU.
JTMOS currently has IP/TCP connectivity but no DNS resolver command in this
release, so outbound applications should use numeric IPv4 addresses unless
they implement DNS themselves.

## Stop

First in SMSH if desired:

```text
www stop
internet stop
```

Then on Ubuntu:

```sh
./slip-down.sh
```

`slip-down.sh` removes only rules tagged `JTMOS-SLIP` and restores the previous
`net.ipv4.ip_forward` value when it had been disabled before startup.
