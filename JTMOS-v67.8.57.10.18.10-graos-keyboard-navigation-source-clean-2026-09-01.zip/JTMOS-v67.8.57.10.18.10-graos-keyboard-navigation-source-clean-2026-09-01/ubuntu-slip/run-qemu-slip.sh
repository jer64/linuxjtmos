#!/bin/sh
set -eu
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
RUNTIME=${JTMOS_SLIP_RUNTIME:-${XDG_RUNTIME_DIR:-/tmp}/jtmos-slip}
STARTED=0
if [ ! -f "$RUNTIME/state" ]; then
  "$SCRIPT_DIR/slip-up.sh"
  STARTED=1
fi
cleanup() {
  if [ "$STARTED" -eq 1 ]; then
    "$SCRIPT_DIR/slip-down.sh" || true
  fi
}
trap cleanup EXIT INT TERM HUP
"$ROOT/run_jtmos_qemu.sh" "$@"
