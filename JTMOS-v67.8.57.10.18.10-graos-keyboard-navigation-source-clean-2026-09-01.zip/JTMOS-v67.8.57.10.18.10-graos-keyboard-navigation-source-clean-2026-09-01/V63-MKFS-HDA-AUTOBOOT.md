JTMOS V63 - mkfs hda automatic boot installation
=================================================
Date: 2026-08-21

Overview
--------
V63 makes the normal floppy-to-HDD installation path atomic from the shell's
point of view.  When JTMOS was booted from BIOS floppy A: or B:, the command:

    mkfs hda

now performs all of these operations:

1. Refuses to format hda if the device is still busy as root, as any process
   current working directory, or through an open file descriptor.
2. Formats hda as JTMFS and reserves the existing 16 KiB boot area plus the
   512 KiB kernel area.
3. Copies the exact current 18-sector (9 KiB) boot-loader track from the floppy
   which booted this JTMOS instance.
4. Patches the HDD copy of the first boot sector for BIOS drive 0x80, kernel
   byte offset 0x4000 (16 KiB), a zero checksum while installation is incomplete,
   and signature 0x55AA.
5. Writes the normal JTMFS information block/FAT/root directory metadata.
6. Copies exactly 1024 sectors (512 KiB), source sectors 18..1041, from the
   current boot floppy into hda's kernel area starting at byte 0x4000.
7. Reads the HDD kernel area back, verifies its 16-bit checksum, and only then
   commits that checksum to boot-sector bytes 501..502.

The normal install flow therefore becomes:

    mkfs hda
    cd hda:/
    sqa sys
    reboot

`rootinstall hda` remains available as an explicit kernel repair/reinstall
operation and for tests with an explicitly selected source device.

Disk layout used by the existing JTMOS loader
---------------------------------------------

    hda byte 0x0000 .. 0x23FF   18-sector loader/reserved boot track
    hda byte 0x2400 .. 0x3FFF   remaining reserved boot area
    hda byte 0x4000 .. 0x83FFF  512 KiB kernel image

Relevant first-sector fields:

    offset 501..502  16-bit kernel checksum
    offset 503..504  kernel byte offset (0x4000 on HDD)
    offset 505..506  legacy CHS cylinder field
    offset 507       legacy CHS heads field
    offset 508       legacy CHS sectors/track field
    offset 509       BIOS boot drive (0x80 for hda)
    offset 510..511  0x55AA signature

The source floppy layout remains unchanged: its kernel begins at sector 18.

Safety/failure behaviour
------------------------
`mkfs hda` returns EBUSY-style error 16 before destroying the filesystem if hda
is the active root, a process CWD, or referenced by an open descriptor.

Automatic boot installation requires GetBiosBootDrive() to report floppy A:
(0) or B: (1), and the corresponding JTMOS floppy device must be present with
512-byte sectors.  If the filesystem was created but no current boot-floppy
source exists, mkfs returns 17.  If the post-format kernel copy/readback fails,
it returns 18.  In incomplete cases the boot checksum remains zero, so SMSH's
root-selection policy does not mistake the disk for a completed system disk.

CopyKernel() no longer accepts partial floppy reads as success.  Every one of
the 1024 source sectors and every target write is checked, followed by complete
target readback/checksum verification.

Low-level jtmfs_formatdrive() callers do not automatically perform the final
kernel copy; the complete install policy belongs to the public mkfs("hda")
path.  This is useful for failsafe/internal formatting while keeping the shell
installation behaviour explicit.

Build-image checksum fix
------------------------
The historical host-side kchecksum.c and img.c both used feof() before the read.
That caused an EOF value to be converted into one spurious 0xFF byte.  V63 reads
first and checks EOF afterwards in both tools.  Consequently jtm32.img contains
kernel32.bin followed only by zero padding in its fixed 512 KiB kernel region,
and the boot checksum is exactly the checksum of that on-image region.

Current limitation / recommended next boot-loader work
------------------------------------------------------
The HDD loader still carries the historical CHS defaults 895/5/55 in the
on-disk boot record.  Its first sector calls INT 13h AH=08 to detect geometry,
but loading the full 18-sector loader can overwrite those values with the
on-disk copy.  V63 deliberately does not redesign this 16-bit loader while
changing mkfs semantics.

The best next improvement is either:

* use INT 13h Extensions (AH=42h) with LBA for HDD kernel reads; or
* at minimum rerun geometry detection after the complete loader has been copied
  into its final location.

LBA is preferable because it removes dependence on BIOS CHS translation and
will make hda boot substantially more robust on modern emulators and disks.
