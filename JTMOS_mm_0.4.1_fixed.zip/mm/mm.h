#ifndef __INCLUDED_MM_H__
#define __INCLUDED_MM_H__

// Virtual address where the allocation database is mapped.
#define MAPAD_MM_DB             0xF2000000

#include <stdio.h>

// To debug or not to debug
//#define MMPRINT               printk
#define MMPRINT                 //

// Page size for IA-32 JTMOS.
#define PAGESIZE                4096

// Allocation database backing store. The database contains the descriptor
// pointer array, descriptors themselves and a 4 GB / 4 KB free-page bitmap.
#define ALLOCATION_DATABASE_SIZE    (1024*1024*1)
#define MM_BITMAP_PAGES             (1024*1024)
#define MM_BITMAP_BYTES             (MM_BITMAP_PAGES/8)

// Virtual allocation-database mapping bounds (legacy exported names).
extern char *MSTART,*MEND,*REND;

// Memory Descriptor (MD)
typedef struct
{
    // INFO REGION
    // Physical beginning of the region.
    char *p;
    // Process ID of the process which owns this memory region.
    int PID;
    // Physical start page for the region.
    int page;
    // Length of the region in pages.
    int pages;
    // Allocated length of the region in bytes (page rounded).
    int bytes;
    // 1 = descriptor slot is free, 0 = descriptor is in use.
    int isFree;

    // Linear address where the memory is mapped.
    DWORD mapad;

    // DEBUG REGION
    char name[20];
} MD;

typedef struct
{
    // PTRs to the descriptors of allocated/free descriptor slots.
    MD **allocated;
    // High-water mark: number of descriptor slots introduced into the table.
    int n_allocated;
    // Maximum number of descriptor slots available in the DB.
    int max_allocated;
    // Physical free-page bitmap; one bit represents one 4 KB page.
    BYTE *bitmap;
    int l_bitmap;
} MM;
extern MM *p_mm;

extern int mallocOK;
extern int mm_debug;

// Core functions.
void mmInit(void *region, int length);
void mm_Diagnostics(void);
void ShowPageMap(void);
void MMPANIC(const char *msg);

#include "mmBit.h"
#include "mmEntry.h"
#include "paging.h"

#endif
