#ifndef __INCLUDED_PAGING_H__
#define __INCLUDED_PAGING_H__

// Physical locations occupied by JTMOS paging structures.
// These pages must never be returned by kmalloc().
#define PG_PAGE_DIRECTORY_PHYS       0x001FF000
#define PG_PAGE_TABLE_PHYS           0x00200000
#define PG_PAGE_TABLE_BYTES          (4*1024*1024)
#define PG_USER_PAGE_TABLES_PHYS     0x00600000
#define PG_USER_PAGE_TABLES_BYTES    (2*1024*1024)
#define PG_STRUCTURES_PHYS_START     PG_PAGE_DIRECTORY_PHYS
#define PG_STRUCTURES_PHYS_END       (PG_USER_PAGE_TABLES_PHYS + PG_USER_PAGE_TABLES_BYTES)

void pg_init(void);
void SetPage1(DWORD *p, DWORD which, DWORD where);
void SetPage(DWORD which, DWORD where);
DWORD GenLinTable(DWORD *p, DWORD ad);
void Demonstrate(void);
void *GetKernelPageDirPTR(void);
void *GetKernelPageTablePTR(void);
void pg_enable(void);
DWORD GetPage1(DWORD *p, DWORD which);
DWORD GetPage(DWORD which);
void *_pg_alloc(int amount);
void *_pg_allocEx(int amount, DWORD mapad);
extern char paging_enabled;
void pg_unmapmemory(DWORD addy, int pages);
DWORD pg_mapmemory(int realpage, int pages);
DWORD pg_mapmemory_at(int realpage, int pages, DWORD mapad);
void PageDump(DWORD spad, DWORD count);
void PageDumpNear(DWORD ad);
void *pg_QuickMap(DWORD phst, int length, DWORD mapad);
DWORD FindEmptyArea(int amount);
void pg_reserve_internal_pages(void);

extern DWORD lin_walk;
extern DWORD search_walk;

#endif
