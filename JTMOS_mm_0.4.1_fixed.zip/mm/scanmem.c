///////////////////////////////////////////////////////////////////////////////////
// scanmem.c
// (C) 2004-2005 Jari Tuominen.
// Fixed 2026: bounded probe loop and guaranteed IRQ restore on exit.
///////////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include "kernel32.h"
#include "scanmem.h"

#ifndef SCANMEM_MAX_KB
// Conservative default cap for direct probing. Raise this after bootloader/e820 support.
#define SCANMEM_MAX_KB (1024*1024)
#endif

//////////////////////////////////////////////////////////////////////////////////////////
MEMORY_INFORMATION ms;

//////////////////////////////////////////////////////////////////////////////////////////
// Returns amount of total memory space in bytes.
//
int scanmem1(void)
{
	volatile DWORD *mem;
	DWORD a;
	DWORD memkb;
	BYTE irq1, irq2;
	char str[256];
 
	irq1=inportb(0x21);
	irq2=inportb(0xA1);
 
	outportb(0x21, 0xFF);
	outportb(0xA1, 0xFF);
 
	memkb=0;

	// Probe in 64 KB steps starting from 1 MB. The old version had an
	// accidental trailing while-loop and could hang or probe forever.
	for(mem=(volatile DWORD *)0x100000; memkb < SCANMEM_MAX_KB;
		memkb+=64, mem+=(1024*64>>2))
	{
		a = *mem;
		*mem=0x55AA55AA;
		asm("":::"memory");
		if(*mem!=0x55AA55AA)
		{
			*mem=a;
			break;
		}

		*mem=0xAA55AA55;
		asm("":::"memory");
		if(*mem!=0xAA55AA55)
		{
			*mem=a;
			break;
		}

		asm("":::"memory");
		*mem=a;
	}

	outportb(0x21, irq1);
	outportb(0xA1, irq2);

	if(memkb<16384)
	{
		sprintf(str, "Insufficient amount of RAM detected (%dK).", memkb);
		disable();
		panic(str);
	}

	return memkb*1024;
}

//////////////////////////////////////////////////////////////////////////////////////////
int scanmem(void)
{
	int i;

	i=scanmem1();
	ms.amount=i;
 
	pd32(i/(1024*1024));
	print("M ram\n");
	return i;
}

//////////////////////////////////////////////////////////////////////////////////////////
int GetRamAmount(void)
{
	return ms.amount;
}

//
