#ifndef APPLICATIONMODULE_CEXEC_H
#define APPLICATIONMODULE_CEXEC_H

#include "kernel32.h"
#include "mm.h"

// Fast C-level exec for Application Modules.
// Entry prototype: int entry(int argc, char **argv, void *user);
typedef int (*CEXEC_ENTRY)(int argc, char **argv, void *user);

typedef struct CEXEC_REQUEST
{
	int pid;                 // owner PID; <=0 means current thread
	DWORD stack_size;        // zero means default 64 KB
	DWORD flags;             // reserved for future use
	const char *name;         // debug name for allocations
	void *user;              // passed as third argument to entry
} CEXEC_REQUEST;

#define CEXEC_OK              0
#define CEXEC_ERR_PARAM      -1
#define CEXEC_ERR_NOMEM      -2
#define CEXEC_ERR_OFFSET     -3

#ifndef CEXEC_DEFAULT_STACK
#define CEXEC_DEFAULT_STACK   (64*1024)
#endif

int turbo_cexec(CEXEC_ENTRY entry, int argc, char **argv, CEXEC_REQUEST *req);
int turbo_cexec_image(const void *image, int image_bytes, int entry_offset,
	int argc, char **argv, CEXEC_REQUEST *req);
int ApplicationModule_cexec(CEXEC_ENTRY entry, int argc, char **argv);

#endif
