/////////////////////////////////////////////////////////////////////////////////////////////////
//
// paging.c
// (C) 2004-2006 by Jari Tuominen.
// Fixed 2026: bounded virtual search, TLB invalidation, protected paging
//             structures, safe exact mappings and graceful address-space OOM.
//
/////////////////////////////////////////////////////////////////////////////////////////////////
#include "kernel32.h"
#include "mm.h"
#include "mmAlloc.h"
#include "paging.h"

static DWORD *page_directory;
static DWORD *physical_page_directory;
static DWORD *page_table;
static DWORD *user_page_tables;

char paging_enabled = FALSE;
DWORD lin_walk;
DWORD search_walk;
static DWORD search_walk_start;
static DWORD search_walk_end;

static DWORD pg_pages_for_bytes(DWORD bytes)
{
    if(bytes == 0)
        return 0;
    return (bytes / PAGESIZE) + ((bytes % PAGESIZE) ? 1 : 0);
}

static void pg_invalidate_page(DWORD which)
{
#if defined(__i386__) && !defined(LIBCVERSION)
    void *linear;

    if(!paging_enabled)
        return;

    linear = (void *)(which * (DWORD)PAGESIZE);
    asm volatile("invlpg (%0)" : : "r" (linear) : "memory");
#else
    (void)which;
#endif
}

static int pg_virtual_range_is_free(DWORD first_page, DWORD pages)
{
    DWORD i;

    if(pages == 0)
        return 0;
    if(first_page >= MM_BITMAP_PAGES)
        return 0;
    if(pages > MM_BITMAP_PAGES - first_page)
        return 0;

    for(i=0; i<pages; i++)
    {
        if(GetPage(first_page+i) & 1)
            return 0;
    }
    return 1;
}

DWORD pg_mapmemory_at(int realpage, int pages, DWORD mapad)
{
    DWORD dpa,rad;
    int i;

    if(realpage <= 0 || pages <= 0 || mapad == 0)
        return 0;
    if(mapad & (PAGESIZE-1))
        return 0;
    if((DWORD)realpage >= MM_BITMAP_PAGES)
        return 0;
    if((DWORD)pages > MM_BITMAP_PAGES - (DWORD)realpage)
        return 0;

    dpa = mapad / PAGESIZE;
    if(!pg_virtual_range_is_free(dpa, (DWORD)pages))
        return 0;

    rad = (DWORD)realpage * PAGESIZE;
    for(i=0; i<pages; i++,rad+=PAGESIZE)
        SetPage(dpa+(DWORD)i, rad | 3);

    return mapad;
}

DWORD pg_mapmemory(int realpage, int pages)
{
    DWORD mapad;

    if(realpage <= 0 || pages <= 0)
        return 0;

    mapad = FindEmptyArea(pages);
    if(!mapad)
        return 0;

    // FindEmptyArea() found this range free; pg_mapmemory_at() performs
    // the final bounds check and installs the PTEs.
    return pg_mapmemory_at(realpage, pages, mapad);
}

void pg_unmapmemory(DWORD addy, int pages)
{
    int i;
    DWORD dpa;

    if(addy == 0 || pages <= 0)
        return;
    if(addy & (PAGESIZE-1))
        return;

    dpa = addy / PAGESIZE;
    if(dpa >= MM_BITMAP_PAGES)
        return;
    if((DWORD)pages > MM_BITMAP_PAGES - dpa)
        pages = (int)(MM_BITMAP_PAGES - dpa);

    for(i=0; i<pages; i++)
        SetPage(dpa+(DWORD)i, 2); // RW, non-present
}

DWORD FindEmptyArea(int amount)
{
    DWORD ad,cnt,scanned,span;

    if(amount <= 0)
        return 0;

    span = search_walk_end - search_walk_start;
    if(span == 0 || (DWORD)amount > span)
        return 0;

    cnt = 0;
    ad = 0;
    for(scanned=0; scanned<span; scanned++,search_walk++)
    {
        if(search_walk >= search_walk_end)
        {
            search_walk = search_walk_start;
            cnt = 0;
            ad = 0;
        }

        if(!(GetPage(search_walk) & 1))
        {
            if(!cnt)
                ad = search_walk * PAGESIZE;
            cnt++;
            if(cnt >= (DWORD)amount)
            {
                // Continue the next search after this allocation.  The old
                // code skipped four pages as a pseudo-guard gap, but those
                // pages were not actually reserved and increased fragmentation.
                search_walk++;
                if(search_walk >= search_walk_end)
                    search_walk = search_walk_start;
                return ad;
            }
        }
        else
        {
            ad = 0;
            cnt = 0;
        }
    }

    // Virtual address-space exhaustion is a normal allocation failure.
    return 0;
}

void *_pg_alloc(int amount)
{
    if(amount <= 0)
        return NULL;

    // procmalloc() already allocates physical pages and maps them into the
    // allocator's virtual window. PID 0 keeps the historical kernel/permanent
    // ownership policy used by the old pg allocator.
    return procmalloc((DWORD)amount, 0, __FUNCTION__);
}

void *_pg_allocEx(int amount, DWORD mapad)
{
    if(amount <= 0 || mapad == 0 || (mapad & (PAGESIZE-1)))
        return NULL;

    // Allocate physical pages directly at the requested virtual address.
    // This avoids the old temporary-map/copy/unmap sequence, which could
    // accidentally choose the requested target as its temporary mapping.
    return _kmalloc_at(amount, 0, __FUNCTION__, mapad);
}

void *GetKernelPageDirPTR(void)
{
    return page_directory;
}

void *GetKernelPageTablePTR(void)
{
    return page_table;
}

void Demonstrate(void)
{
    int i,l,x;
    BYTE *p;

    for(x=0,p = (BYTE *)0xB8000; ; x++)
    {
        l = 80*25*2;
        for(i=0; i<l; i++)
            p[i] += i+x;
    }
}

DWORD GenLinTable(DWORD *p, DWORD ad)
{
    int i;

    for(i=0; i<1024; i++,ad+=PAGESIZE)
        p[i] = ad | 3;
    return ad;
}

DWORD GetPage(DWORD which)
{
    return GetPage1(page_table, which);
}

DWORD GetPage1(DWORD *p, DWORD which)
{
    if(p == NULL || which >= MM_BITMAP_PAGES)
        panic("GetPage1 illegal access");
    return p[which];
}

void SetPage(DWORD which, DWORD where)
{
    SetPage1(page_table, which, where);
}

void SetPage1(DWORD *p, DWORD which, DWORD where)
{
    if(p == NULL || which >= MM_BITMAP_PAGES)
        panic("SetPage1 illegal access");

    p[which] = where;

    // PTE changes made after paging is enabled must invalidate stale TLB
    // translations. Without this, kfree()+kmalloc() can keep using an old
    // physical page even though the page table has already changed.
    if(p == page_table)
        pg_invalidate_page(which);
}

void pg_enable(void)
{
    SETCR0(GETCR0() | 0x80000000);
}

void *pg_QuickMap(DWORD phst, int length, DWORD mapad)
{
    DWORD ad,i,i2,l,first;

    if(length <= 0 || mapad == 0)
        return NULL;
    if((phst & (PAGESIZE-1)) || (mapad & (PAGESIZE-1)))
        return NULL;

    l = pg_pages_for_bytes((DWORD)length);
    if(l == 0)
        return NULL;

    first = mapad / PAGESIZE;
    if(first >= MM_BITMAP_PAGES || l > MM_BITMAP_PAGES-first)
        return NULL;
    if((phst / PAGESIZE) >= MM_BITMAP_PAGES ||
       l > MM_BITMAP_PAGES-(phst/PAGESIZE))
        return NULL;

    for(i=first,i2=0,ad=phst; i2<l; i2++,ad+=PAGESIZE)
        SetPage(i+i2, ad|3);

    return (void *)mapad;
}

// Reserve the physical pages occupied by the live paging structures.
// mmInit() calls this after it marks the general RAM region free.
void pg_reserve_internal_pages(void)
{
    mmReserveRegionAD((char *)PG_STRUCTURES_PHYS_START,
        (char *)PG_STRUCTURES_PHYS_END);
}

void pg_init(void)
{
    DWORD i,i2,l;
    DWORD *p,ad,ad2;

    printk("Paging initializing:\n");
    printk("- Page tables ...\n");

    paging_enabled = FALSE;
    search_walk_start = 0x40000000/PAGESIZE;
    search_walk_end   = 0x70000000/PAGESIZE;
    search_walk       = search_walk_start;

    page_directory = (DWORD *)PG_PAGE_DIRECTORY_PHYS;
    page_table = (DWORD *)PG_PAGE_TABLE_PHYS;
    user_page_tables = (DWORD *)PG_USER_PAGE_TABLES_PHYS;

    memset(page_table, 0, PG_PAGE_TABLE_BYTES);
    memset(user_page_tables, 0, PG_USER_PAGE_TABLES_BYTES);
    physical_page_directory = NULL;

    // 1) wipe the whole 4 GB flat page table.
    l = MM_BITMAP_PAGES;
    printk("(1) ");
    for(i=0; i<l; i++)
        SetPage(i, 0);

    // 2) identity-map the first 8 MB.
    l = 1024*1024*8/PAGESIZE;
    printk("(2) ");
    for(i=0,ad=0; i<l; i++,ad+=PAGESIZE)
        SetPage(i, ad|3);

    if(vesa_frame_buf!=NULL)
    {
        l = 1024*1024*1/PAGESIZE;
        ad2 = (DWORD)vesa_frame_buf;
        for(i=ad2/PAGESIZE,ad=ad2,i2=0; i2<l; i++,i2++,ad+=PAGESIZE)
            SetPage(i, ad|3);
    }

    // Null pointer protection.
    SetPage(0, 2);

    printk("- Page directory ...\n");
    printk("(3) ");
    p = page_directory;
    for(i=0,ad=(DWORD)page_table; i<1024; i++,ad+=PAGESIZE)
        p[i] = ad | 3;

    // Keep the first 8 MB accessible through the historical 0x10000000 alias.
    l = 1024*1024*8/PAGESIZE;
    i2 = 0x10000000/PAGESIZE;
    for(i=0,ad=0; i<l; i++,ad+=PAGESIZE)
        SetPage(i+i2, ad|3);

    physical_page_directory = page_directory;

    printk("- Enabling paging ... ");
    SETCR3(physical_page_directory);
    pg_enable();
    paging_enabled = TRUE;
    printk("OK.\n");

    printk("\nDone (CR0 = 0x%x).\n", GETCR0());
    printk("page_directory = 0x%x\n", page_directory);
    printk("page_table =     0x%x\n", page_table);

    ad = (DWORD)p_mm;
    printk("p_mm =      0x%x\n", ad);
    printk("p_mm page = 0x%x\n", GetPage(ad/PAGESIZE));
}

void PageDump(DWORD spad, DWORD count)
{
    DWORD i,pad;

    printk("PDD@%x: ", spad);
    for(i=0,pad=spad; i<count; i++,pad++)
        printk("%x, ", GetPage(pad));
    printk("\n");
}

void PageDumpNear(DWORD ad)
{
    DWORD pad;

    pad = ad/PAGESIZE;
    PageDump(pad,20);
}
