#ifndef __INCLUDED_LAUNCHAPP_H__
#define __INCLUDED_LAUNCHAPP_H__

#include "int.h"
#include "mm.h"

/* JTMOS process virtual layout.
 *
 * 0x80000000 - 0x80003fff : initial 16 KiB user stack / runtime area
 * 0x80004000 - ...        : ELF32 PT_LOAD segments
 */
#define RTBASE              MM_USER_BASE
#define APP_STACK_SIZE      0x00004000UL
#define RTCODE              (RTBASE + APP_STACK_SIZE)

/* ELF32 applications must be linked into the JTMOS user window. */
#define APPLICATION_START_AD RTCODE

/* Keep the historical setting for source compatibility. LaunchApp() uses the
   same effective 64 KiB minimum as the prototype (4096 / 64), while the ELF
   loader automatically grows the backing when PT_LOAD segments need more. */
#define DEF_APP_SPACE_K     4096

#define LAUNCHAPP_ELF_OK                 0
#define LAUNCHAPP_ELF_BAD_ARGUMENT      -1
#define LAUNCHAPP_ELF_BAD_MAGIC         -2
#define LAUNCHAPP_ELF_UNSUPPORTED       -3
#define LAUNCHAPP_ELF_BAD_HEADER        -4
#define LAUNCHAPP_ELF_BAD_SEGMENT       -5
#define LAUNCHAPP_ELF_BAD_ENTRY         -6
#define LAUNCHAPP_ELF_NO_MEMORY         -7
#define LAUNCHAPP_ELF_CREATE_FAILED     -8
#define LAUNCHAPP_ELF_MAP_FAILED        -9

/* Return value: process PID in UNIPID format, or 0 on failure. */
int LaunchApp(BYTE *abin, int length);
int LaunchAppEx(BYTE *abin, int length, int memkb, int dnr, int db);

/* Cheap format test for callers that need to distinguish ELF32 from legacy
   raw binaries before calling LaunchApp(). */
int LaunchAppIsELF32(const BYTE *abin, int length);

DWORD launchapp_cleartogo;

#endif
