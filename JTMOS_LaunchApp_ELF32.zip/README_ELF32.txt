JTMOS LaunchApp / ELF32 prototype
================================

What changed
------------
1. LaunchApp now accepts ELF32/i386 ET_EXEC files instead of flat raw binaries.
2. PT_LOAD segments are validated and copied to their ELF virtual addresses.
3. p_memsz > p_filesz is zero-filled, so .bss works correctly.
4. e_entry is used as the thread entry point and must point inside an executable PT_LOAD.
5. The original JTMOS virtual layout is preserved:
      0x80000000..0x80003fff  initial 16 KiB stack/runtime area
      0x80004000..            ELF application segments
6. LaunchApp keeps the prototype's effective 64 KiB default, but backing memory automatically grows if ELF PT_LOAD segments exceed it.
7. The old uninitialized "selector" use was removed; thread_selector/thread_ss now use appseg.
8. mm.c/mm.h add page-oriented helpers and a Linux-mmap-like kmalloc() interface.

kmalloc()
---------
Prototype:
  void *kmalloc(void *addr, DWORD length, int prot, int flags,
                int fd, DWORD offset);

The first version supports anonymous mappings only:
  fd     = -1
  offset = 0
  flags  = MM_MAP_PRIVATE | MM_MAP_ANONYMOUS

MM_MAP_ZERO asks kmalloc() to clear the allocated pages.
MM_MAP_FIXED is intentionally conservative: because the old JTMOS malloc() cannot
request an exact address, kmalloc() succeeds with MM_MAP_FIXED only if malloc()
actually returned the requested address.

Process mapping
---------------
mm_map_process_range(pid, virtual_address, backing, length, prot) translates the
malloc-backed pages through GetPage() and writes them to the same per-PID page
table layout that the old AdaptAppPages() used.

The current JTMOS page-table representation stores a page number only, so prot
is part of the API but is not yet encoded in a PTE. Once the MMU code supports
user/read/write/execute bits, mm_map_process_range() is the one place to add them.

Building applications
---------------------
Use jtmos_elf32.ld. Applications must be linked as static/freestanding ELF32,
not as Linux dynamic executables:

  gcc -m32 -ffreestanding -fno-pie -fno-stack-protector -c app.c -o app.o
  ld -m elf_i386 -T jtmos_elf32.ld -o app.elf app.o <JTMOS runtime/libc objects>

Inspect the result with:
  readelf -h app.elf
  readelf -l app.elf

Expected essentials:
  Class:   ELF32
  Data:    little endian
  Type:    EXEC
  Machine: Intel 80386
  Entry:   >= 0x80004000
  LOAD virtual addresses: >= 0x80004000 and < 0x81000000

Integration notes
-----------------
Add mm.c to the kernel build and make sure LaunchApp.c can include mm.h and
elf32.h. The implementation expects the existing JTMOS symbols/functions:
  malloc, free, memset, GetPage, ChangeChunkOwner,
  _createAppThread, RPID, thread_base/thread_ss/thread_selector,
  thread_banks/thread_memkb, and the existing thread metadata functions.

One important limitation remains: page protections from ELF PF_R/PF_W/PF_X are
validated conceptually but the current old JTMOS page-table format shown in the
prototype does not expose PTE protection bits. The loader maps process backing
using the existing page-number format for compatibility.
