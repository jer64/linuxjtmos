#ifndef __JTMOS_MM_H__
#define __JTMOS_MM_H__

#include "int.h"

#define MM_PAGE_SIZE           4096UL
#define MM_PAGE_MASK           (MM_PAGE_SIZE - 1UL)

/* JTMOS application virtual address window: 4096 pages = 16 MiB. */
#define MM_USER_BASE           0x80000000UL
#define MM_USER_PAGES          4096UL
#define MM_USER_SIZE           (MM_USER_PAGES * MM_PAGE_SIZE)
#define MM_USER_TOP            (MM_USER_BASE + MM_USER_SIZE)

/* mmap-like protection bits. The current JTMOS page-table format does not
   yet encode these bits, but keeping them in the API makes the transition to
   protected user pages straightforward. */
#define MM_PROT_NONE           0x0000
#define MM_PROT_READ           0x0001
#define MM_PROT_WRITE          0x0002
#define MM_PROT_EXEC           0x0004

/* mmap-like allocation flags. */
#define MM_MAP_PRIVATE         0x0001
#define MM_MAP_ANONYMOUS       0x0002
#define MM_MAP_FIXED           0x0004
#define MM_MAP_ZERO            0x0008

#define MM_MAP_FAILED          ((void *)0)

DWORD mm_page_align_down(DWORD value);
DWORD mm_page_align_up(DWORD value);

/*
 * kmalloc() deliberately has mmap-like arguments.
 *
 * addr   = preferred kernel address (normally NULL)
 * length = requested bytes; rounded to 4 KiB
 * prot   = MM_PROT_*
 * flags  = MM_MAP_*
 * fd     = currently must be -1 (anonymous memory only)
 * offset = currently must be zero
 *
 * MM_MAP_FIXED is accepted only if the underlying allocator happened to
 * return exactly addr; JTMOS malloc() currently has no fixed-address API.
 */
void *kmalloc(void *addr, DWORD length, int prot, int flags, int fd, DWORD offset);
int   kmunmap(void *addr, DWORD length);

/* Process page-table helpers. */
void mm_clear_process_space(int pid);
int  mm_map_process_range(int pid, DWORD virtual_address,
                          void *kernel_address, DWORD length, int prot);
int  mm_unmap_process_range(int pid, DWORD virtual_address, DWORD length);

#endif
