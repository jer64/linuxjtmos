// ===========================================================
// LaunchApp.c - ELF32 application launcher for JTMOS.
//
// Based on the original 2002-2005 LaunchApp prototype by
// Jari Tuominen.  The raw-binary copy has been replaced by an
// ELF32/i386 PT_LOAD loader while preserving the existing JTMOS
// process/thread ownership and page-table model.
// ===========================================================

#include "int.h"
#include "cpu.h"
#include "sysglvar.h"
#include "kernel32.h" // FATALEXCEPTION
#include "delay.h"
#include "threads.h"
#include "caster.h"
#include "mm.h"
#include "elf32.h"
#include "LaunchApp.h"

#define ELF32_MAX_PROGRAM_HEADERS 128

static int range_inside(DWORD offset, DWORD amount, DWORD total)
{
    if(offset > total)
        return FALSE;
    if(amount > (total - offset))
        return FALSE;
    return TRUE;
}

static int add_overflows(DWORD a, DWORD b)
{
    return a > (0xffffffffUL - b);
}

static const Elf32_Phdr *elf32_program_header(const BYTE *abin,
                                               const Elf32_Ehdr *eh,
                                               int index)
{
    DWORD off;

    off = eh->e_phoff + ((DWORD)index * (DWORD)eh->e_phentsize);
    return (const Elf32_Phdr *)(abin + off);
}

static int elf32_validate(const BYTE *abin, DWORD length,
                          DWORD *image_end, DWORD *entry)
{
    const Elf32_Ehdr *eh;
    const Elf32_Phdr *ph;
    DWORD ph_bytes;
    DWORD seg_end;
    DWORD max_end;
    int entry_is_executable;
    int load_count;
    int i;

    if(abin == 0 || length < sizeof(Elf32_Ehdr))
        return LAUNCHAPP_ELF_BAD_ARGUMENT;

    eh = (const Elf32_Ehdr *)abin;

    if(eh->e_ident[EI_MAG0] != ELFMAG0 ||
       eh->e_ident[EI_MAG1] != ELFMAG1 ||
       eh->e_ident[EI_MAG2] != ELFMAG2 ||
       eh->e_ident[EI_MAG3] != ELFMAG3)
        return LAUNCHAPP_ELF_BAD_MAGIC;

    if(eh->e_ident[EI_CLASS] != ELFCLASS32 ||
       eh->e_ident[EI_DATA] != ELFDATA2LSB ||
       eh->e_ident[EI_VERSION] != EV_CURRENT ||
       eh->e_version != EV_CURRENT ||
       eh->e_machine != EM_386 ||
       eh->e_type != ET_EXEC)
        return LAUNCHAPP_ELF_UNSUPPORTED;

    if(eh->e_ehsize != sizeof(Elf32_Ehdr) ||
       eh->e_phentsize != sizeof(Elf32_Phdr) ||
       eh->e_phnum == 0 ||
       eh->e_phnum > ELF32_MAX_PROGRAM_HEADERS)
        return LAUNCHAPP_ELF_BAD_HEADER;

    if(add_overflows((DWORD)eh->e_phnum * (DWORD)eh->e_phentsize,
                     eh->e_phoff))
        return LAUNCHAPP_ELF_BAD_HEADER;

    ph_bytes = (DWORD)eh->e_phnum * (DWORD)eh->e_phentsize;
    if(!range_inside(eh->e_phoff, ph_bytes, length))
        return LAUNCHAPP_ELF_BAD_HEADER;

    max_end = RTCODE;
    load_count = 0;
    entry_is_executable = FALSE;

    for(i = 0; i < eh->e_phnum; ++i)
    {
        ph = elf32_program_header(abin, eh, i);
        if(ph->p_type != PT_LOAD)
            continue;

        ++load_count;

        if(ph->p_memsz < ph->p_filesz)
            return LAUNCHAPP_ELF_BAD_SEGMENT;

        if(!range_inside(ph->p_offset, ph->p_filesz, length))
            return LAUNCHAPP_ELF_BAD_SEGMENT;

        if(add_overflows(ph->p_vaddr, ph->p_memsz))
            return LAUNCHAPP_ELF_BAD_SEGMENT;

        seg_end = ph->p_vaddr + ph->p_memsz;

        /* Keep the original 16 KiB stack/runtime area reserved. */
        if(ph->p_vaddr < RTCODE || seg_end > MM_USER_TOP)
            return LAUNCHAPP_ELF_BAD_SEGMENT;

        /* ELF requires p_vaddr and p_offset to be congruent modulo p_align
           when p_align is greater than one. */
        if(ph->p_align > 1)
        {
            if((ph->p_align & (ph->p_align - 1)) != 0)
                return LAUNCHAPP_ELF_BAD_SEGMENT;
            if((ph->p_vaddr % ph->p_align) != (ph->p_offset % ph->p_align))
                return LAUNCHAPP_ELF_BAD_SEGMENT;
        }

        if(seg_end > max_end)
            max_end = seg_end;

        if((ph->p_flags & PF_X) != 0 &&
           eh->e_entry >= ph->p_vaddr &&
           eh->e_entry < seg_end)
            entry_is_executable = TRUE;
    }

    if(load_count == 0)
        return LAUNCHAPP_ELF_BAD_SEGMENT;

    if(eh->e_entry < RTCODE || eh->e_entry >= MM_USER_TOP ||
       !entry_is_executable)
        return LAUNCHAPP_ELF_BAD_ENTRY;

    *image_end = max_end;
    *entry = eh->e_entry;
    return LAUNCHAPP_ELF_OK;
}

static int elf32_copy_segments(const BYTE *abin,
                               BYTE *app_space,
                               const Elf32_Ehdr *eh)
{
    const Elf32_Phdr *ph;
    BYTE *dst;
    DWORD i;
    DWORD n;

    for(i = 0; i < eh->e_phnum; ++i)
    {
        ph = elf32_program_header(abin, eh, (int)i);
        if(ph->p_type != PT_LOAD)
            continue;

        dst = app_space + (ph->p_vaddr - RTBASE);

        for(n = 0; n < ph->p_filesz; ++n)
            dst[n] = abin[ph->p_offset + n];

        /* .bss and any other memsz > filesz tail. */
        for(n = ph->p_filesz; n < ph->p_memsz; ++n)
            dst[n] = 0;
    }

    return LAUNCHAPP_ELF_OK;
}

void Indication(void)
{
    nop();
    nop();
    nop();
    nop();
}

int LaunchAppIsELF32(const BYTE *abin, int length)
{
    if(abin == 0 || length < 5)
        return FALSE;

    return abin[EI_MAG0] == ELFMAG0 &&
           abin[EI_MAG1] == ELFMAG1 &&
           abin[EI_MAG2] == ELFMAG2 &&
           abin[EI_MAG3] == ELFMAG3 &&
           abin[EI_CLASS] == ELFCLASS32;
}

/* Launch application with defaults. */
int LaunchApp(BYTE *abin, int length)
{
    /* Preserve the prototype's effective 64 KiB default. ELF PT_LOAD data
       can grow the allocation automatically beyond this minimum. */
    return LaunchAppEx(abin, length, DEF_APP_SPACE_K / 64,
                       GetCurrentDNR(), GetCurrentDB());
}

/* Legacy compatibility helper. Keep the original two-argument ABI for any
   older kernel code that still calls AdaptAppPages() directly. New ELF code
   uses mm_map_process_range() with an explicit length. */
void AdaptAppPages(int pid, DWORD srcOffset)
{
    DWORD *dst;
    DWORD src;
    DWORD page;
    DWORD i;

    dst = (DWORD *)(0x00600000UL + ((DWORD)pid * 1024UL * 16UL));

    for(i = 0; i < 4096; ++i)
        dst[i] = 0;

    src = srcOffset / MM_PAGE_SIZE;
    for(i = 0; i < 4096; ++i)
    {
        page = GetPage(src + i);
        if(page < 8)
            break;
        dst[i] = page;
    }
}

/*
 * LaunchAppEx()
 *
 * abin/length : complete ELF32 file in memory
 * memkb       : minimum process backing allocation in KiB
 * dnr/db      : inherited JTMOS directory/database context
 *
 * Supported ELF profile:
 *   - ELFCLASS32
 *   - little endian
 *   - EM_386
 *   - ET_EXEC
 *   - PT_LOAD segments linked at >= 0x80004000
 *
 * The first 16 KiB of the process address window remains the initial stack.
 * Returns a UNIPID, or 0 on error.
 */
int LaunchAppEx(BYTE *abin, int length, int memkb, int dnr, int db)
{
    const Elf32_Ehdr *eh;
    BYTE *appSpace;
    DWORD image_end;
    DWORD required_bytes;
    DWORD requested_bytes;
    DWORD bytes;
    DWORD entry;
    int flags;
    int unipid;
    int status;

    if(abin == 0 || length <= 0)
        return 0;

    status = elf32_validate(abin, (DWORD)length, &image_end, &entry);
    if(status != LAUNCHAPP_ELF_OK)
    {
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        printk("%s: invalid/unsupported ELF32 image (%d).\n",
               __FUNCTION__, status);
        return 0;
    }

    required_bytes = mm_page_align_up(image_end - RTBASE);
    if(required_bytes == 0 || required_bytes > MM_USER_SIZE)
    {
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        return 0;
    }

    if(memkb < 16)
        memkb = 16;

    if((DWORD)memkb > (0xffffffffUL / 1024UL))
        return 0;

    requested_bytes = mm_page_align_up((DWORD)memkb * 1024UL);
    if(requested_bytes == 0)
        return 0;

    bytes = requested_bytes;
    if(bytes < required_bytes)
        bytes = required_bytes;

    if(bytes > MM_USER_SIZE)
    {
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        printk("%s: ELF32 process requests %d KiB; maximum is %d KiB.\n",
               __FUNCTION__, bytes / 1024UL, MM_USER_SIZE / 1024UL);
        return 0;
    }

    flags = get_eflags();
    disable();

    appSpace = (BYTE *)kmalloc(0, bytes,
                               MM_PROT_READ | MM_PROT_WRITE | MM_PROT_EXEC,
                               MM_MAP_PRIVATE | MM_MAP_ANONYMOUS | MM_MAP_ZERO,
                               -1, 0);
    if(appSpace == 0)
    {
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        set_eflags(flags);
        return 0;
    }

    eh = (const Elf32_Ehdr *)abin;
    status = elf32_copy_segments(abin, appSpace, eh);
    if(status != LAUNCHAPP_ELF_OK)
    {
        kmunmap(appSpace, bytes);
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        set_eflags(flags);
        return 0;
    }

    /* Original JTMOS selectors are preserved for now. User/kernel privilege
       separation can later be added without changing the ELF loader. */
    appseg = 0x08;
    appstackoffs = RTCODE - 16; /* stack grows down inside first 16 KiB */
    appoffset = entry;
    apprealoffs = appSpace;

    unipid = _createAppThread(appseg, appseg + 8,
                              appSpace, appoffset, appstackoffs);
    if(!unipid)
    {
        kmunmap(appSpace, bytes);
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        set_eflags(flags);
        return 0;
    }

    /* Install the backing pages before transferring chunk ownership.
       Interrupts are still disabled here, so the application cannot race the
       mapping setup. */
    mm_clear_process_space(RPID(unipid));
    if(mm_map_process_range(RPID(unipid), RTBASE, appSpace, bytes,
                            MM_PROT_READ | MM_PROT_WRITE | MM_PROT_EXEC) != 0)
    {
        mm_clear_process_space(RPID(unipid));
        /* No thread-destroy primitive was present in the supplied prototype.
           Do not free appSpace here: _createAppThread() already references it. */
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        printk("%s: unable to map ELF32 process pages for PID%d.\n",
               __FUNCTION__, unipid);
        set_eflags(flags);
        return 0;
    }

    ChangeChunkOwner((void *)appSpace, unipid);

    SetThreadDNR(unipid, dnr);
    SetThreadDB(unipid, db);
    ReportMessage("%s: Set PID%d DNR/DB to %d/%d\n",
                  __FUNCTION__, unipid, dnr, db);

    /* Mandatory thread accounting used by the existing deallocator. */
    thread_base[RPID(unipid)] = appSpace;
    thread_ss[RPID(unipid)] = appseg + 8;
    thread_selector[RPID(unipid)] = appseg;
    thread_banks[RPID(unipid)] = (bytes + (64UL * 1024UL - 1)) /
                                  (64UL * 1024UL);
    thread_memkb[RPID(unipid)] = bytes / 1024UL;
    SetThreadPriority(unipid, THREAD_PRIORITY_NORMAL);

    SetThreadType(unipid,
                  (GetThreadType(unipid) & (~THREAD_TYPE_KERNEL))
                  | THREAD_TYPE_APPLICATION);

    TrackThread(unipid, TRUE);

    ReportMessage("%s: ELF32 PID%d entry=0x%x base=0x%x memory=%d KiB\n",
                  __FUNCTION__, unipid, appoffset,
                  thread_base[RPID(unipid)], bytes / 1024UL);

    Indication();
    set_eflags(flags);
    return unipid;
}
