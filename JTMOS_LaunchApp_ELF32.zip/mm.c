/* ===========================================================
 * mm.c - Small page-oriented memory layer for JTMOS ELF32 apps.
 *
 * The existing JTMOS malloc()/GetPage() allocator is kept as the physical
 * backing allocator.  kmalloc() adds an mmap-like, page-granular interface,
 * while mm_map_process_range() installs those pages into an application's
 * 16 MiB virtual window starting at 0x80000000.
 * =========================================================== */

#include "int.h"
#include "sysglvar.h"
#include "mm.h"

DWORD mm_page_align_down(DWORD value)
{
    return value & ~MM_PAGE_MASK;
}

DWORD mm_page_align_up(DWORD value)
{
    if(value > (0xffffffffUL - MM_PAGE_MASK))
        return 0;

    return (value + MM_PAGE_MASK) & ~MM_PAGE_MASK;
}

void *kmalloc(void *addr, DWORD length, int prot, int flags, int fd, DWORD offset)
{
    DWORD bytes;
    void *p;

    (void)prot;

    if(length == 0)
        return MM_MAP_FAILED;

    /* First implementation is anonymous memory only. */
    if(fd != -1 || offset != 0)
        return MM_MAP_FAILED;

    if((flags & MM_MAP_ANONYMOUS) == 0)
        return MM_MAP_FAILED;

    bytes = mm_page_align_up(length);
    if(bytes == 0)
        return MM_MAP_FAILED;

    p = malloc(bytes);
    if(p == 0)
        return MM_MAP_FAILED;

    /* The old JTMOS page code already assumes malloc() returns page-aligned
       chunks (LaunchApp used GetPage((DWORD)malloc_result / 4096)). */
    if(((DWORD)p & MM_PAGE_MASK) != 0)
    {
        free(p);
        return MM_MAP_FAILED;
    }

    if((flags & MM_MAP_FIXED) != 0 && addr != 0 && p != addr)
    {
        free(p);
        return MM_MAP_FAILED;
    }

    if((flags & MM_MAP_ZERO) != 0)
        memset(p, 0, bytes);

    return p;
}

int kmunmap(void *addr, DWORD length)
{
    (void)length;

    if(addr == 0)
        return -1;

    free(addr);
    return 0;
}

static DWORD *mm_process_page_table(int pid)
{
    /* This preserves the original JTMOS process page-table layout used by
       AdaptAppPages(): one 16 KiB table per PID at 0x00600000. */
    return (DWORD *)(0x00600000UL + ((DWORD)pid * MM_USER_PAGES * sizeof(DWORD)));
}

void mm_clear_process_space(int pid)
{
    DWORD *table;
    DWORD i;

    table = mm_process_page_table(pid);
    for(i = 0; i < MM_USER_PAGES; ++i)
        table[i] = 0;
}

int mm_map_process_range(int pid, DWORD virtual_address,
                         void *kernel_address, DWORD length, int prot)
{
    DWORD *table;
    DWORD virtual_end;
    DWORD first_index;
    DWORD page_count;
    DWORD source_page;
    DWORD physical_page;
    DWORD i;

    (void)prot;

    if(kernel_address == 0 || length == 0)
        return -1;

    if((virtual_address & MM_PAGE_MASK) != 0 ||
       ((DWORD)kernel_address & MM_PAGE_MASK) != 0)
        return -1;

    length = mm_page_align_up(length);
    if(length == 0)
        return -1;

    if(virtual_address < MM_USER_BASE)
        return -1;

    if(virtual_address > (0xffffffffUL - length))
        return -1;

    virtual_end = virtual_address + length;
    if(virtual_end > MM_USER_TOP)
        return -1;

    first_index = (virtual_address - MM_USER_BASE) / MM_PAGE_SIZE;
    page_count = length / MM_PAGE_SIZE;
    source_page = ((DWORD)kernel_address) / MM_PAGE_SIZE;
    table = mm_process_page_table(pid);

    for(i = 0; i < page_count; ++i)
    {
        physical_page = GetPage(source_page + i);

        /* Preserve the old sanity rule: page numbers 0..7 are not usable
           application mappings in JTMOS. */
        if(physical_page < 8)
        {
            DWORD rollback;
            for(rollback = 0; rollback < i; ++rollback)
                table[first_index + rollback] = 0;
            return -1;
        }

        table[first_index + i] = physical_page;
    }

    return 0;
}

int mm_unmap_process_range(int pid, DWORD virtual_address, DWORD length)
{
    DWORD *table;
    DWORD virtual_end;
    DWORD first_index;
    DWORD page_count;
    DWORD i;

    if(length == 0 || (virtual_address & MM_PAGE_MASK) != 0)
        return -1;

    length = mm_page_align_up(length);
    if(length == 0 || virtual_address < MM_USER_BASE)
        return -1;

    if(virtual_address > (0xffffffffUL - length))
        return -1;

    virtual_end = virtual_address + length;
    if(virtual_end > MM_USER_TOP)
        return -1;

    first_index = (virtual_address - MM_USER_BASE) / MM_PAGE_SIZE;
    page_count = length / MM_PAGE_SIZE;
    table = mm_process_page_table(pid);

    for(i = 0; i < page_count; ++i)
        table[first_index + i] = 0;

    return 0;
}
