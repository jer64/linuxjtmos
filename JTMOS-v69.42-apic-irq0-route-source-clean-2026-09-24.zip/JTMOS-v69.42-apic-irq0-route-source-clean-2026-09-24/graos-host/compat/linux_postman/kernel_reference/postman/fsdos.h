//
#ifndef __INCLUDED_FILEAPI_DOS_H__
#define __INCLUDED_FILEAPI_DOS_H__

//
#include "basdef.h"
#include "dirtype.h"

/*
 * DOS-style compatibility names mapped onto the native JTMFS classification.
 * Do not infer DOS numeric attribute values from these aliases: JTMFS keeps
 * its historical on-disk bit assignments.  FA_LABEL maps to the internal
 * JTMFS directory-name metadata class and is not a normal user file class.
 */
#define FA_RDONLY JTMFS_ID_READONLY
#define FA_HIDDEN JTMFS_ID_HIDDEN
#define FA_SYSTEM JTMFS_ID_SYSTEM
#define FA_LABEL  JTMFS_ID_DIRNAME
#define FA_DIREC  JTMFS_ID_DIRECTORY
#define FA_ARCH   JTMFS_ID_ARCHIVE

//
typedef struct
{
	DWORD _ff_reserved[5];
	DWORD ff_attrib;
	DWORD ff_ftime;
	DWORD ff_fdate;
	DWORD ff_fsize;
	char ff_name[260];
}FFBLK;

//
int jtmfs_findfirst(int dnr, int db, const char *path, FFBLK *blk);
int jtmfs_findnext(int dnr, int db, int fd, FFBLK *blk);

#endif
