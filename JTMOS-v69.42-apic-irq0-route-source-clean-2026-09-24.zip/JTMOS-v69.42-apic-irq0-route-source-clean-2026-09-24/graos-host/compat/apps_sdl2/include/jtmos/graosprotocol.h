#ifndef JTMOS_GRAOSPROTOCOL_H
#define JTMOS_GRAOSPROTOCOL_H
#define GSID_EXIT 1
#define GSID_KEYPRESSED 2
#define GSID_BUTTON 3
/* Client-area pointer notification: v[0]=x, v[1]=y, v[2]=button. */
#define GSID_MOUSEBUTTON 20
#endif
