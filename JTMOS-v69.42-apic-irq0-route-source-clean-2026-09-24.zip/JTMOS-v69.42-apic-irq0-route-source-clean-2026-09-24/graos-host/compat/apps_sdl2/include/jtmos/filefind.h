#ifndef JTMOS_FILEFIND_H
#define JTMOS_FILEFIND_H
#ifdef JTMOS
/* Native header is supplied by JTMOS SDK. */
#else
#include <jtmos/app_port.h>
/* Mirror the native JTMFS public classification values in the Linux shim. */
#define JTMFS_ATTR_MASK       0x3FU
#define JTMFS_CLASS_FILE      0x00U
#define JTMFS_CLASS_DIRECTORY 0x80U
#define JTMFS_CLASS_MASK      0xC0U
#define JTMFS_ID_FILE         JTMFS_CLASS_FILE
#define JTMFS_ID_DIRECTORY    JTMFS_CLASS_DIRECTORY
#define JTMFS_TYPE_CLASS(t) ((unsigned int)(t) & JTMFS_CLASS_MASK)
#define JTMFS_TYPE_IS_FILE(t) (JTMFS_TYPE_CLASS(t) == JTMFS_CLASS_FILE)
#define JTMFS_TYPE_IS_DIRECTORY(t) \
    (JTMFS_TYPE_CLASS(t) == JTMFS_CLASS_DIRECTORY)
typedef struct {
    char ff_name[256];
    int ff_fsize;
    int ff_attrib;
} FFBLK;
int findfirst(const char *pattern, FFBLK *ff);
int findnext(int handle, FFBLK *ff);
#endif
#endif
