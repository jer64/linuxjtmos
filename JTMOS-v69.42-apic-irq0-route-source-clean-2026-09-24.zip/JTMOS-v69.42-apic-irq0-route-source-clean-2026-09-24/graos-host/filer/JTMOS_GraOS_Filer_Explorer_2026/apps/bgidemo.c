#include <graphics.h>
#include <conio.h>
#include <stdio.h>
int main(void){int gd=DETECT,gm=0,e;initgraph(&gd,&gm,"");e=graphresult();if(e!=grOk){printf("BGI: %s\n",grapherrormsg(e));return 1;}setbkcolor(BLACK);cleardevice();setcolor(LIGHTCYAN);rectangle(20,20,getmaxx()-20,getmaxy()-20);setcolor(YELLOW);circle(getmaxx()/2,getmaxy()/2,90);setfillstyle(SOLID_FILL,BLUE);bar(50,60,180,130);setcolor(WHITE);outtextxy(60,82,"JTMOS Turbo C BGI");setcolor(LIGHTGREEN);line(20,getmaxy()-40,getmaxx()-20,40);getch();closegraph();return 0;}
