// =======================================================================
// sqsh.c - Squirrel Shell 1.1 for JTMOS
// (C) 2002-2003 by Jari Tuominen(jari@vunet.org)
// =======================================================================
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <jtmos/console.h>
#include <jtmos/filefind.h>
#include <jtmos/dpi.h>
#include <jtmos/process.h>
#include <sys/stat.h>
#include <jtmos/directdisk.h>
#include <jtmos/file.h>
#include "sqsh.h"

void sqsh_about(void);

// Request 256K of RAM from the init process.
SYSMEMREQ(APPRAM_256K)

//
int sqsh_special=0;

//
struct
{
	//
	char *cmdline;
	char path[512];
	char dev[512];

	//
	char **cmdpar;
	char *cmdstore;

	//
	char **script;
	int lines_script;
	char *tmp;

	//
	char script_run;
	int line_script;
}sqsh;

#define SQSH_LINE_MAX 1024
#define SQSH_SCREEN_WIDTH 79
#define SQSH_MAX_PIPE_STAGES 16
#define SQSH_PIPE_NOT_HANDLED (-32767)


static int sqsh_argc(void)
{
    int i;
    for(i=0;i<SQSH_MAX_WORDS;i++) if(sqsh.cmdpar[i]==NULL || !sqsh.cmdpar[i][0]) break;
    return i;
}

static int sqsh_readline(char *line, int capacity)
{
    int used=0;

    if(line==NULL || capacity<2) return -1;
    line[0]=0;

    for(;;)
    {
        int key=getch();

        /* Native JTMOS key translation normally supplies LF for Enter, but
         * accept CR too so synthetic/GraOS terminal input behaves exactly
         * like the physical SMSH console. */
        if(key=='\n' || key=='\r')
        {
            putch('\n');
            line[used]=0;
            return used;
        }

        if(key=='\b' || key==127)
        {
            if(used>0)
            {
                --used;
                line[used]=0;
                putch('\b'); putch(' '); putch('\b');
            }
            continue;
        }

        /* Ctrl-C cancels the current line without terminating SQSH. */
        if(key==3 || key==27)
        {
            while(used>0)
            {
                --used;
                putch('\b'); putch(' '); putch('\b');
            }
            line[0]=0;
            putch('\n');
            return 0;
        }

        if(key<32 || key>255)
            continue;

        if(used+1<capacity)
        {
            line[used++]=(char)key;
            line[used]=0;
            putch(key);
        }
    }
}

static void sqsh_print_packed(const char *name, int *column)
{
    int len;
    if(name==NULL || column==NULL) return;
    len=(int)strlen(name);
    if(*column && *column+2+len>SQSH_SCREEN_WIDTH)
    {
        putch('\n');
        *column=0;
    }
    if(*column)
    {
        printf("  ");
        *column+=2;
    }
    printf("%s",name);
    *column+=len;
    if(*column>=SQSH_SCREEN_WIDTH)
    {
        putch('\n');
        *column=0;
    }
}

static int sqsh_ls(int argc, char **argv)
{
    FFBLK ff;
    char oldcwd[512];
    char display[300];
    const char *path=NULL;
    int fd, long_listing=0, i, col=0, files=0, dirs=0;
    unsigned long bytes=0;

    for(i=1;i<argc;i++)
    {
        if(!strcmp(argv[i],"-l")) long_listing=1;
        else if(path==NULL) path=argv[i];
        else { printf("Usage: ls [-l] [path]\n"); return 2; }
    }

    oldcwd[0]=0;
    if(path!=NULL)
    {
        if(getcwd(oldcwd,sizeof(oldcwd))==NULL || chdir(path)!=0)
        {
            printf("ls: cannot access %s\n",path);
            return 1;
        }
    }

    memset(&ff,0,sizeof(ff));
    fd=findfirst("*",&ff);
    if(fd<=0)
    {
        if(path!=NULL && oldcwd[0]) chdir(oldcwd);
        printf("ls: unable to read directory.\n");
        return 1;
    }

    for(;;)
    {
        if(ff.ff_fsize!=(DWORD)-1 && ff.ff_name[0])
        {
            if(JTMFS_TYPE_IS_DIRECTORY(ff.ff_attrib))
            {
                ++dirs;
                sprintf(display,"[%s]",ff.ff_name);
            }
            else
            {
                ++files;
                bytes+=(unsigned long)ff.ff_fsize;
                strcpy(display,ff.ff_name);
            }
            if(long_listing) printf("%s\n",display);
            else sqsh_print_packed(display,&col);
        }
        if(findnext(fd,&ff)) break;
    }
    close(fd);
    if(!long_listing && col) putch('\n');
    printf("%d File(s), %d Dir(s), %lu bytes\n",files,dirs,bytes);
    if(path!=NULL && oldcwd[0]) chdir(oldcwd);
    return 0;
}

static int sqsh_lsdev(int argc, char **argv)
{
    int dnr,active=0,col=0;
    char name[64];
    char display[70];

    if(argc!=1) { printf("Usage: lsdev\n"); return 2; }
    for(dnr=0;dnr<256;dnr++)
    {
        name[0]=0;
        if(getdevicename(dnr,name)!=0 || !name[0]) continue;
        if(dnr==0 && !strcmp(name,"dummy")) continue;
        sprintf(display,"%s:",name);
        sqsh_print_packed(display,&col);
        ++active;
    }
    if(col) putch('\n');
    printf("%d active device%s.\n",active,active==1?"":"s");
    return 0;
}

static int sqsh_wildcard_match(const char *pattern, const char *name)
{
    while(*pattern)
    {
        if(*pattern=='*')
        {
            ++pattern;
            if(!*pattern) return 1;
            while(*name)
            {
                if(sqsh_wildcard_match(pattern,name)) return 1;
                ++name;
            }
            return sqsh_wildcard_match(pattern,name);
        }
        if(*pattern!='?' && *pattern!=*name) return 0;
        if(!*name) return 0;
        ++pattern; ++name;
    }
    return *name==0;
}

static int sqsh_has_wildcard(const char *s)
{
    return s!=NULL && (strchr(s,'*')!=NULL || strchr(s,'?')!=NULL);
}

static void sqsh_normalize_path(char *out, int cap, const char *path)
{
    int n=0;
    const char *p=path;
    if(cap<1) return;
    while(p && p[0]=='.' && (p[1]=='/' || p[1]=='\\')) p+=2;
    while(p && *p && n+1<cap)
    {
        char c=*p++;
        if(c=='\\') c='/';
        if(c=='/' && n>0 && out[n-1]=='/') continue;
        if(c=='.' && n>0 && out[n-1]=='/' && (*p=='/' || *p=='\\'))
        { ++p; continue; }
        out[n++]=c;
    }
    while(n>1 && out[n-1]=='/') --n;
    out[n]=0;
}

static int sqsh_same_path(const char *a, const char *b)
{
    char na[512],nb[512];
    sqsh_normalize_path(na,sizeof(na),a);
    sqsh_normalize_path(nb,sizeof(nb),b);
    return !strcmp(na,nb);
}

static const char *sqsh_basename(const char *path)
{
    const char *p,*last=path;
    if(path==NULL) return "";
    for(p=path;*p;p++) if(*p=='/' || *p=='\\') last=p+1;
    return last;
}

static int sqsh_is_directory(const char *path)
{
    struct stat st;
    return path!=NULL && stat(path,&st)==0 && S_ISDIR(st.st_mode);
}

static int sqsh_join_path(char *out, int cap, const char *dir, const char *name)
{
    int n;
    if(out==NULL || cap<2 || dir==NULL || name==NULL) return -1;
    n=(int)strlen(dir);
    if(n+(int)strlen(name)+2>cap) return -1;
    strcpy(out,dir);
    if(n>0 && out[n-1]!='/' && out[n-1]!='\\') strcat(out,"/");
    strcat(out,name);
    return 0;
}

static int sqsh_copy_file(const char *src, const char *dst)
{
    FILE *in,*out;
    unsigned char buf[4096];
    size_t n;
    int rc=0;
    in=fopen(src,"rb");
    if(!in) return 1;
    out=fopen(dst,"wb");
    if(!out) { fclose(in); return 1; }
    while((n=fread(buf,1,sizeof(buf),in))!=0)
    {
        if(fwrite(buf,1,n,out)!=n) { rc=1; break; }
        SwitchToThread();
    }
    if(ferror(in)) rc=1;
    if(fclose(out)!=0) rc=1;
    fclose(in);
    if(rc) remove(dst);
    return rc;
}

static int sqsh_cat(int argc, char **argv)
{
    unsigned char buf[1024];
    FILE *f;
    size_t n;
    int i,rc=0;
    if(argc<2) { printf("Usage: cat file [file ...]\n"); return 2; }
    for(i=1;i<argc;i++)
    {
        f=fopen(argv[i],"rb");
        if(!f) { printf("cat: cannot open %s\n",argv[i]); rc=1; continue; }
        while((n=fread(buf,1,sizeof(buf),f))!=0)
        {
            if(fwrite(buf,1,n,stdout)!=n) { rc=1; break; }
            SwitchToThread();
        }
        if(ferror(f)) rc=1;
        fclose(f);
    }
    return rc;
}

static int sqsh_mkdir_cmd(int argc, char **argv)
{
    int i,rc=0;
    if(argc<2) { printf("Usage: mkdir DIRECTORY [DIRECTORY ...]\n"); return 2; }
    if(!strcmp(argv[1],"-h") || !strcmp(argv[1],"--help"))
    {
        printf("Usage: mkdir DIRECTORY [DIRECTORY ...]\n");
        printf("Create one or more JTMFS directories.\n");
        return 0;
    }
    for(i=1;i<argc;i++)
    {
        if(mkdir(argv[i],0777)!=0)
        {
            printf("mkdir: cannot create '%s'\n",argv[i]);
            rc=1;
        }
    }
    return rc;
}

static int sqsh_rm_pattern(const char *pattern, int force, int verbose)
{
    FFBLK ff;
    char **names=NULL;
    int fd,count=0,cap=0,i,rc=0;
    if(!sqsh_has_wildcard(pattern))
    {
        if(remove(pattern)!=0)
        {
            if(!force) printf("rm: failed: %s\n",pattern);
            return force?0:1;
        }
        if(verbose) printf("removed %s\n",pattern);
        return 0;
    }
    memset(&ff,0,sizeof(ff));
    fd=findfirst("*",&ff);
    if(fd<=0) return force?0:1;
    for(;;)
    {
        if(ff.ff_fsize!=(DWORD)-1 && ff.ff_name[0] &&
           !JTMFS_TYPE_IS_DIRECTORY(ff.ff_attrib) && sqsh_wildcard_match(pattern,ff.ff_name))
        {
            if(count==cap)
            {
                int nc=cap?cap*2:16;
                char **nn=(char **)realloc(names,(size_t)nc*sizeof(char *));
                if(!nn) { rc=1; break; }
                names=nn; cap=nc;
            }
            names[count]=(char *)malloc(strlen(ff.ff_name)+1);
            if(!names[count]) { rc=1; break; }
            strcpy(names[count],ff.ff_name); ++count;
        }
        if(findnext(fd,&ff)) break;
    }
    close(fd);
    if(count==0 && !force) { printf("rm: no match: %s\n",pattern); rc=1; }
    for(i=0;i<count;i++)
    {
        if(remove(names[i])!=0) { if(!force) printf("rm: failed: %s\n",names[i]); rc=1; }
        else if(verbose) printf("removed %s\n",names[i]);
        free(names[i]);
    }
    free(names);
    return rc;
}

static int sqsh_rm(int argc, char **argv)
{
    int i,force=0,verbose=0,operands=0,rc=0;
    if(argc<2) { printf("Usage: rm [-f] [-v] file [file ...]\n"); return 2; }
    for(i=1;i<argc;i++)
    {
        if(!strcmp(argv[i],"-f")) force=1;
        else if(!strcmp(argv[i],"-v")) verbose=1;
        else { ++operands; if(sqsh_rm_pattern(argv[i],force,verbose)) rc=1; }
    }
    if(!operands) { printf("Usage: rm [-f] [-v] file [file ...]\n"); return 2; }
    return rc;
}

static int sqsh_mv(int argc, char **argv)
{
    char dst[512];
    const char *target;
    if(argc!=3) { printf("Usage: mv old new\n"); return 2; }
    target=argv[2];
    if(sqsh_is_directory(argv[2]))
    {
        if(sqsh_join_path(dst,sizeof(dst),argv[2],sqsh_basename(argv[1]))!=0)
        { printf("mv: destination path is too long.\n"); return 1; }
        target=dst;
    }
    if(sqsh_same_path(argv[1],target)) return 0;
    if(rename(argv[1],target)==0) return 0;
    if(sqsh_copy_file(argv[1],target)==0)
    {
        if(remove(argv[1])==0) return 0;
        remove(target);
    }
    printf("mv: failed: %s -> %s\n",argv[1],target);
    return 1;
}

static int sqsh_rmwild(int argc, char **argv)
{
    FFBLK ff;
    char **names=NULL;
    int fd,count=0,cap=0,i,deleted=0;

    if(argc!=2) { printf("Usage: rmwild text\n"); return 2; }
    memset(&ff,0,sizeof(ff));
    fd=findfirst("*",&ff);
    if(fd<=0) { printf("rmwild: unable to read directory.\n"); return 1; }

    for(;;)
    {
        if(ff.ff_fsize!=(DWORD)-1 && ff.ff_name[0] &&
           !JTMFS_TYPE_IS_DIRECTORY(ff.ff_attrib) && strstr(ff.ff_name,argv[1])!=NULL)
        {
            if(count==cap)
            {
                int nc=cap?cap*2:16;
                char **nn=(char **)realloc(names,(size_t)nc*sizeof(char *));
                if(!nn) break;
                names=nn; cap=nc;
            }
            names[count]=(char *)malloc(strlen(ff.ff_name)+1);
            if(!names[count]) break;
            strcpy(names[count],ff.ff_name);
            ++count;
        }
        if(findnext(fd,&ff)) break;
    }
    close(fd);

    for(i=0;i<count;i++)
    {
        if(remove(names[i])==0) { printf("rmwild: %s\n",names[i]); ++deleted; }
        else printf("rmwild: failed: %s\n",names[i]);
        free(names[i]);
    }
    free(names);
    printf("rmwild: %d/%d file(s) deleted.\n",deleted,count);
    return deleted==count?0:1;
}

static int sqsh_fm(int argc, char **argv)
{
    FILE *f;
    unsigned long off=0;
    unsigned char b[16];
    size_t n,i;
    if(argc!=2) { printf("Usage: fm file\n"); return 2; }
    f=fopen(argv[1],"rb");
    if(!f) { printf("fm: cannot open %s\n",argv[1]); return 1; }
    while((n=fread(b,1,sizeof(b),f))!=0)
    {
        printf("%08lx  ",off);
        for(i=0;i<16;i++) { if(i<n) printf("%02x ",b[i]); else printf("   "); }
        printf(" ");
        for(i=0;i<n;i++) putch((b[i]>=32 && b[i]<127)?b[i]:'.');
        putch('\n');
        off+=(unsigned long)n;
        if((off&0xffUL)==0) SwitchToThread();
    }
    fclose(f);
    return 0;
}

static int sqsh_format(int argc, char **argv)
{
    if(argc!=2) { printf("Usage: format device\n"); return 2; }
    printf("format: formatting %s as JTMFS...\n",argv[1]);
    if(formatDrive(argv[1])!=0) { printf("format: failed: %s\n",argv[1]); return 1; }
    printf("format: completed.\n");
    return 0;
}

static void sqsh_echo_args(void)
{
    int i,n=sqsh_argc();
    for(i=1;i<n;i++) { if(i>1) putch(' '); printf("%s",sqsh.cmdpar[i]); }
    putch('\n');
}


static int sqsh_postman(void)
{
    int argc=sqsh_argc(),pid;
    char cmd[1024]; int i,used=0,n;
    const char *sub=argc>1?sqsh.cmdpar[1]:"status";
    if(!strcmp(sub,"status")){printf("Postman/current PID: %d\n",GetCurrentThread());printf("GraOS PID: %d\n",GetThreadPID("guiserver"));return 0;}
    if(!strcmp(sub,"find")){if(argc<3){printf("Usage: pm find NAME\n");return 1;}pid=GetThreadPID(sqsh.cmdpar[2]);printf("%s: %d\n",sqsh.cmdpar[2],pid);return pid>0?0:1;}
    if(!strcmp(sub,"exec")||!strcmp(sub,"launch")){if(argc<3){printf("Usage: pm exec COMMAND...\n");return 1;}cmd[0]=0;for(i=2;i<argc;i++){n=snprintf(cmd+used,sizeof(cmd)-used,"%s%s",used?" ":"",sqsh.cmdpar[i]);if(n<0||(size_t)n>=sizeof(cmd)-used)return 1;used+=n;}pid=bgexec(cmd,sqsh.path);if(pid<=0)printf("pm: launch failed: %s\n",cmd);else printf("PID %d: %s\n",pid,cmd);return pid>0?0:1;}
    if(!strcmp(sub,"cleanup")){printf("Postman cleanup: PID-owned native IPC needs no manual purge.\n");return 0;}
    printf("Postman: pm status | find NAME | exec COMMAND... | cleanup\n");return 0;
}

static int sqsh_graos_command(void)
{
    int pid=GetThreadPID("guiserver");
    if(pid>0){printf("GraOS already running, PID %d.\n",pid);return 0;}
    pid=bgexec("graos.bin",sqsh.path);
    if(pid<=0)printf("GraOS launch failed.\n");
    return pid>0?0:1;
}
static void sqsh_help(void)
{
    printf("Squirrel Shell 1.1 / SMSH userspace integration\n");
    printf("Builtins: help cd chdir pwd ls dir lsdev echo cat type mkdir rm del mv ren\n");
    printf("          rmwild rmw rm_wildcard fm format mkfs clear cls ver version\n");
    printf("          list load save gui graos postman pm exit quit\n");
    printf("ls [-l] [path]   compact directory listing; -l = one name per line\n");
    printf("mkdir DIR [...]  internal directory creation command\n");
    printf("External commands are launched through LaunchApp/cexec.\n");
    printf("Pipelines: command1 | command2 [| command3 ...] (max 16 stages).\n");
    printf("Pipeline data uses kernel pipes and kernel-owned file buffers.\n");
    printf("Examples: ls | cat, cat file.txt | cat, ps | cat\n");
    printf("Examples: ps, top, edit, filer, nzip, sqa, mkfs, cp\n");
    printf("Ring0-only SMSH administration remains privileged: mount, umount, root,\n");
    printf("rootinstall, bootroot, kyber, debug/report and kernel memory dump.\n");
}

static int sqsh_privileged_command(const char *name)
{
    static const char *p[]={"mount","umount","unmount","root","rootinstall",
        "bootroot","kyber","debug","debug1","report","debug2","m","kmed",NULL};
    int i;
    for(i=0;p[i];i++) if(!strcmp(name,p[i])) return 1;
    return 0;
}


// Load script
int loadscript(const char *fname)
{
    FILE *f;
    char line[SQSH_LINE_MAX];
    int i,ch,used,overflow=0;
    f=fopen(fname,"rb");
    if(f==NULL) return 1;
    if(sqsh.script==NULL)
    {
        sqsh.script=(char **)malloc((size_t)SCRIPT_MAX_LINES*sizeof(char *));
        if(sqsh.script==NULL) { fclose(f); return 1; }
        memset(sqsh.script,0,(size_t)SCRIPT_MAX_LINES*sizeof(char *));
    }
    for(i=0;i<sqsh.lines_script && i<SCRIPT_MAX_LINES;i++)
    {
        free(sqsh.script[i]); sqsh.script[i]=NULL;
    }
    sqsh.lines_script=0; sqsh.line_script=0; used=0;
    while((ch=fgetc(f))!=EOF)
    {
        if(ch=='\r') continue;
        if(ch!='\n')
        {
            if(used+1<SQSH_LINE_MAX) line[used++]=(char)ch;
            else overflow=1;
            continue;
        }
        line[used]=0;
        if(sqsh.lines_script>=SCRIPT_MAX_LINES) { overflow=1; break; }
        sqsh.script[sqsh.lines_script]=(char *)malloc((size_t)used+1);
        if(!sqsh.script[sqsh.lines_script]) { fclose(f); return 1; }
        strcpy(sqsh.script[sqsh.lines_script],line);
        if(sqsh_parsecmd(sqsh.script[sqsh.lines_script],1))
            printf("load: parse warning on line %d.\n",sqsh.lines_script+1);
        ++sqsh.lines_script; used=0;
    }
    if(used>0 && sqsh.lines_script<SCRIPT_MAX_LINES)
    {
        line[used]=0;
        sqsh.script[sqsh.lines_script]=(char *)malloc((size_t)used+1);
        if(!sqsh.script[sqsh.lines_script]) { fclose(f); return 1; }
        strcpy(sqsh.script[sqsh.lines_script],line);
        if(sqsh_parsecmd(sqsh.script[sqsh.lines_script],1))
            printf("load: parse warning on line %d.\n",sqsh.lines_script+1);
        ++sqsh.lines_script;
    }
    fclose(f);
    if(overflow) printf("load: script truncated to configured limits.\n");
    sqsh.script_run=sqsh.lines_script?1:0;
    return 0;
}

static int savescript(const char *fname)
{
    FILE *f;
    int i;
    if(fname==NULL || !fname[0]) return 1;
    f=fopen(fname,"wb");
    if(!f) return 1;
    for(i=0;i<sqsh.lines_script;i++)
    {
        if(fputs(sqsh.script[i]?sqsh.script[i]:"",f)==EOF || fputc('\n',f)==EOF)
        { fclose(f); return 1; }
    }
    return fclose(f)!=0;
}
//
void show_help_page(int argc, char **argv)
{
	printf("Squirrel Shell 1.1 for JTMOS\n");
	printf("    (C) 2002-2003 by Jari Tuominen\n");
	printf("\n");
	printf("Usage: %s [options] [files] [...]\n", argv[0]);
	printf("Options:\n");
	printf("          --help      shows help page(this)\n");
	printf("          --dir       specifies location to run at\n");
	printf("     e.g. --dir /\n");
}

//
int sqsh_allocate(void)
{
	int i,n=SQSH_MAX_WORDS+10;

	/* The historical shell performed more than 200 tiny heap allocations at
	 * startup.  Besides fragmentation, one failed allocation left a NULL slot
	 * that was dereferenced immediately.  Keep command words in one arena so
	 * SQSH starts reliably even with a small initial SYSMEMREQ heap. */
	sqsh.cmdline = (char *)malloc(SQSH_LINE_MAX);
	sqsh.cmdpar = (char **)malloc((size_t)n*sizeof(char *));
	sqsh.cmdstore = (char *)malloc((size_t)n*200U);
	if(!sqsh.cmdline || !sqsh.cmdpar || !sqsh.cmdstore)
		return 0;
	memset(sqsh.cmdline,0,SQSH_LINE_MAX);
	memset(sqsh.cmdstore,0,(size_t)n*200U);
	for(i=0;i<n;i++) sqsh.cmdpar[i]=sqsh.cmdstore+i*200;
	return 1;
}

// Change directory
void sqsh_cd(void)
{
//	printf("cding to '%s'\n", sqsh.cmdpar[1]);
	chdir(sqsh.cmdpar[1]);
}

// Echo on terminal
void sqsh_echo(const char *cmdline)
{
	int i,i2,i3,i4, l;

	//
	l = strlen(cmdline);

	//
	for(i=0; i<l; i++)
	{
		if(cmdline[i]=='\"')
		{
			for(i2=i+1; i2<l; i2++)
			{
				if(cmdline[i2]=='\"')
				{
					printf("\n");
					break;
				}
				printf("%c", cmdline[i2]);
			}
			return;
		}
	}

	//
	printf("Usage: echo \"text inside here\"\n");
	printf("Quote -marks are required.\n");
}

//
void sqsh_list(void)
{
	int i;

	//
	printf("Script contains %d lines.\n", sqsh.lines_script);
	for(i=0; i<sqsh.lines_script; i++)
	{
		if( (i&15)==15 )	if(getch()==27)break;
		printf("Line %d: \"%s\"\n",  i, sqsh.script[i]);
	}
}

//
void sqsh_load(void)
{
}

//
void sqsh_save(void)
{
}

// 0	=	ok
// -1	=	exit request
// -2	=	invalid parameter
// -3	=	nothing to do
//
int sqsh_parsecmd(const char *s, int test)
{
	//
	int pid;

	// Detect bad arguments
	if(s==NULL)return -2;
	if(!strlen(s))return -3;

	// Make cmdpar argument split strings
	sqsh_process_cmdstring(s);

	// Detect remarked lines and skip these
	if( sqsh.cmdpar[0][0]=='#' )
	{
		// One remark line skipped :)
		return 0;
	}


    /* Userspace-safe SMSH-compatible builtins.  Keep privileged kernel
     * administration in SMSH/ring0 rather than punching a generic shell
     * command syscall through the ring boundary. */
    if(!strcmp(sqsh.cmdpar[0],"help") || !strcmp(sqsh.cmdpar[0],"?"))
    {
        if(!test) sqsh_help();
        return 0;
    }
    if(!strcmp(sqsh.cmdpar[0],"pwd"))
    {
        if(!test) { char cwd[512]; if(getcwd(cwd,sizeof(cwd))) printf("%s\n",cwd); }
        return 0;
    }
    if(!strcmp(sqsh.cmdpar[0],"ls") || !strcmp(sqsh.cmdpar[0],"dir"))
    {
        if(!test) sqsh_ls(sqsh_argc(),sqsh.cmdpar); /* argc corrected below */
        return 0;
    }
    if(!strcmp(sqsh.cmdpar[0],"lsdev"))
    {
        if(!test) sqsh_lsdev(sqsh_argc(),sqsh.cmdpar);
        return 0;
    }
    if(!strcmp(sqsh.cmdpar[0],"cat") || !strcmp(sqsh.cmdpar[0],"type"))
    {
        if(!test) sqsh_cat(sqsh_argc(),sqsh.cmdpar);
        return 0;
    }
    if(!strcmp(sqsh.cmdpar[0],"mkdir"))
    {
        if(!test) sqsh_mkdir_cmd(sqsh_argc(),sqsh.cmdpar);
        return 0;
    }
    if(!strcmp(sqsh.cmdpar[0],"rm") || !strcmp(sqsh.cmdpar[0],"del"))
    {
        if(!test) sqsh_rm(sqsh_argc(),sqsh.cmdpar);
        return 0;
    }
    if(!strcmp(sqsh.cmdpar[0],"mv") || !strcmp(sqsh.cmdpar[0],"ren"))
    {
        if(!test) sqsh_mv(sqsh_argc(),sqsh.cmdpar);
        return 0;
    }
    if(!strcmp(sqsh.cmdpar[0],"rmwild") || !strcmp(sqsh.cmdpar[0],"rmw") || !strcmp(sqsh.cmdpar[0],"rm_wildcard"))
    {
        if(!test) sqsh_rmwild(sqsh_argc(),sqsh.cmdpar);
        return 0;
    }
    if(!strcmp(sqsh.cmdpar[0],"fm"))
    {
        if(!test) sqsh_fm(sqsh_argc(),sqsh.cmdpar);
        return 0;
    }
    if(!strcmp(sqsh.cmdpar[0],"format") || !strcmp(sqsh.cmdpar[0],"mkfs"))
    {
        if(!test) sqsh_format(sqsh_argc(),sqsh.cmdpar);
        return 0;
    }
    if(!strcmp(sqsh.cmdpar[0],"clear") || !strcmp(sqsh.cmdpar[0],"cls"))
    {
        if(!test) clrscr();
        return 0;
    }
    if(!strcmp(sqsh.cmdpar[0],"graos") || !strcmp(sqsh.cmdpar[0],"gui"))
    {
        if(!test) sqsh_graos_command();
        return 0;
    }
    if(!strcmp(sqsh.cmdpar[0],"postman") || !strcmp(sqsh.cmdpar[0],"pm"))
    {
        if(!test) sqsh_postman();
        return 0;
    }
    if(sqsh_privileged_command(sqsh.cmdpar[0]))
    {
        if(!test) printf("%s: ring0 SMSH command; run it from the kernel SMSH console.\n",sqsh.cmdpar[0]);
        return 0;
    }

	// List currently loaded script
	if( !strcmp(sqsh.cmdpar[0], "list") )
	{
		if(test==0)	sqsh_list();
		return 0;
	}

	// Load a script
	if( !strcmp(sqsh.cmdpar[0], "load") )
	{
		if(test==0)
		{
            if(sqsh_argc()!=2) { printf("Usage: load file\n"); return 0; }
			printf("Loading script '%s'\n", sqsh.cmdpar[1]);
			if(loadscript(sqsh.cmdpar[1])) printf("load: cannot read %s\n",sqsh.cmdpar[1]);
		}
		return 0;
	}

	// Save the currently loaded script.
	if( !strcmp(sqsh.cmdpar[0], "save") )
	{
		if(test==0)
		{
            if(sqsh_argc()!=2) { printf("Usage: save file\n"); return 0; }
            if(savescript(sqsh.cmdpar[1])) printf("save: cannot write %s\n",sqsh.cmdpar[1]);
            else printf("Saved %d line(s) to %s\n",sqsh.lines_script,sqsh.cmdpar[1]);
		}
		return 0;
	}
	//
	if( !strcmp(sqsh.cmdpar[0], "cd") )
	{
		if(test==0)
		{
			sqsh_cd();
		}
		return 0;
	}

	//
	if( !strcmp(sqsh.cmdpar[0], "echo") )
	{
		if(test==0) sqsh_echo_args();
		return 0;
	}

	//
	if( !strcmp(sqsh.cmdpar[0], "ver")
		||
	    !strcmp(sqsh.cmdpar[0], "version") )
	{
		if(test==0)
		{
			sqsh_about();
		}
		return 0;
	}

	//
	if( !strcmp(sqsh.cmdpar[0], "exit") )
	{
		if(test==0)
			return -1;
			else
			return 0;
	}

	// Empty?
	if( !strcmp(sqsh.cmdpar[0], "")
		||
	    sqsh.cmdpar[0][0]==' ' )
		return -2;

	// Try external command
	if( cexec(s, sqsh.path)==0 )return -2;
	return 0;
}

//
void sqsh_draw_prompt(void)
{
    char prompt=(getringlevel()==0)?'#':'$';
    printf("%s%c ",sqsh.path,prompt);
}

int sqsh_process_cmdstring(const char *s)
{
    int argc=0;
    const char *p=s;

    for(argc=0;argc<(SQSH_MAX_WORDS+10);argc++)
        sqsh.cmdpar[argc][0]=0;
    argc=0;
    if(!s) return 0;

    while(*p && argc<SQSH_MAX_WORDS)
    {
        int used=0;
        char quote=0;
        while(*p==' ' || *p=='\t') ++p;
        if(!*p) break;

        while(*p && used<198)
        {
            char c=*p;
            if(!quote && (c==' ' || c=='\t')) break;
            if(c=='\\' && p[1]) { sqsh.cmdpar[argc][used++]=p[1]; p+=2; continue; }
            if(c=='\'' || c=='"')
            {
                if(!quote) { quote=c; ++p; continue; }
                if(quote==c) { quote=0; ++p; continue; }
            }
            sqsh.cmdpar[argc][used++]=c;
            ++p;
        }
        sqsh.cmdpar[argc][used]=0;
        ++argc;
        while(*p==' ' || *p=='\t') ++p;
    }
    return argc;
}

static char *sqsh_pipe_trim(char *s)
{
    char *e;
    while(*s==' ' || *s=='\t') s++;
    e=s+strlen(s);
    while(e>s && (e[-1]==' ' || e[-1]=='\t')) *--e=0;
    return s;
}

static int sqsh_split_pipeline(char *line,char **stages,int maxstages)
{
    int n=1,escape=0,i;
    char quote=0,*p;
    if(!line || !stages || maxstages<1) return -1;
    stages[0]=line;
    for(p=line;*p;p++)
    {
        if(escape) { escape=0; continue; }
        if(*p=='\\') { escape=1; continue; }
        if(quote) { if(*p==quote) quote=0; continue; }
        if(*p=='\'' || *p=='"') { quote=*p; continue; }
        if(*p=='|')
        {
            if(n>=maxstages) return -2;
            *p=0; stages[n++]=p+1;
        }
    }
    if(n==1) return 0;
    for(i=0;i<n;i++)
    {
        stages[i]=sqsh_pipe_trim(stages[i]);
        if(!stages[i][0]) return -1;
    }
    return n;
}

/* Every SQSH pipeline stage is executed by a tiny no-banner SQSH child.  This
 * makes shell builtins and external programs obey exactly the same pipe fd
 * routing.  External grandchildren inherit the child's redirected stdio via
 * SYS_cexec, so there is no userspace pipe emulation. */
static int sqsh_make_pipe_stage_cmd(char *out,int cap,const char *stage)
{
    int used=0,i;
    const char *prefix="/bin/sqsh.bin --pipe-stage \"";
    if(!out || cap<8 || !stage) return -1;
    for(i=0;prefix[i];i++) { if(used+1>=cap) return -1; out[used++]=prefix[i]; }
    for(i=0;stage[i];i++)
    {
        if(stage[i]=='\\' || stage[i]=='"')
        {
            if(used+2>=cap) return -1;
            out[used++]='\\';
        }
        if(used+1>=cap) return -1;
        out[used++]=stage[i];
    }
    if(used+2>=cap) return -1;
    out[used++]='"'; out[used]=0;
    return 0;
}

static int sqsh_run_pipeline(char *line)
{
    char *stage[SQSH_MAX_PIPE_STAGES];
    int pfds[SQSH_MAX_PIPE_STAGES-1][2];
    int pids[SQSH_MAX_PIPE_STAGES];
    char launch[SQSH_LINE_MAX+64];
    int n,i,j,created=0,rc=0;

    n=sqsh_split_pipeline(line,stage,SQSH_MAX_PIPE_STAGES);
    if(n==0) return SQSH_PIPE_NOT_HANDLED;
    if(n<0) { printf("sqsh: invalid pipeline (max %d stages)\n",SQSH_MAX_PIPE_STAGES); return 2; }
    memset(pfds,-1,sizeof(pfds)); memset(pids,0,sizeof(pids));
    for(i=0;i<n-1;i++)
    {
        if(pipe(pfds[i])!=0) { perror("sqsh: pipe"); rc=1; goto cleanup; }
    }
    for(i=0;i<n;i++)
    {
        int in_fd=(i==0)?-1:pfds[i-1][0];
        int out_fd=(i==n-1)?-1:pfds[i][1];
        if(sqsh_make_pipe_stage_cmd(launch,sizeof(launch),stage[i])!=0)
        { printf("sqsh: pipeline stage too long\n"); rc=1; goto cleanup; }
        pids[i]=bgexecStdio(launch,sqsh.path,-1,in_fd,out_fd,-1);
        if(pids[i]<=0)
        { printf("sqsh: cannot launch pipeline stage %d: %s\n",i+1,stage[i]); rc=1; goto cleanup; }
        created++;
    }
cleanup:
    for(i=0;i<n-1;i++) for(j=0;j<2;j++) if(pfds[i][j]>=3) { close(pfds[i][j]); pfds[i][j]=-1; }
	if(rc) {
		for(i=0;i<created;i++) {
			if(pids[i]>0) KillThread(pids[i]);
		}
	} else {
		for(i=0;i<created;i++) {
			if(pids[i]>0) WaitProcessTermination(pids[i]);
		}
	}
    return rc;
}

// SQSH shell prompt
void sqsh_prompt(void)
{
	char str2[SQSH_LINE_MAX];
	int rv;

	//
	for(;;)
	{
retryagain:
		//
		SwitchToThread();

		// Get current path
		getcwd(sqsh.path, 250);

		//
		if(sqsh.script_run==2)
		{
			break;
		}

		//
		if(sqsh.script_run==1)
		{
			strcpy(sqsh.cmdline, sqsh.script[sqsh.line_script]);
			sqsh.line_script++;
			if( sqsh.line_script>=sqsh.lines_script )
			{
				// Last line of the script reached
				//sqsh.script_run=2;
				sqsh.script_run=0;
			}
		}
		else
		if(sqsh.script_run==0)
		{
			sqsh_draw_prompt();
			sqsh_readline(sqsh.cmdline,SQSH_LINE_MAX);
		}

		// Sanity check
		if( !strlen(sqsh.cmdline) )goto retryagain;
		// Copy the name to the temp buffer
		strcpy(str2, sqsh.cmdline);
		rv=sqsh_run_pipeline(str2);
		if(rv!=SQSH_PIPE_NOT_HANDLED) goto line_processed;
		rv = sqsh_parsecmd(str2, 0);
		switch(rv)
		{
			// End of session.
			case -1:
			goto outtahere;
			// File not found
			case -2:
			printf("Bad command or file name '%s'\n",
				str2);
			break;
			//
			default:
			break;
		}
line_processed:
	}
////////////////////////////////////////////////////////////////////////////////
outtahere:
}

// Initialize SQSH
int sqsh_init(void)
{
	strcpy(sqsh.path, "/");
	if(!sqsh_allocate()) {
		printf("sqsh: cannot allocate command workspace.\n");
		return 0;
	}
	return 1;
}

// Bring up some info about the shell
void sqsh_about(void)
{
	printf(" .    .     _ _   \n");
	printf(" |\\__/|  .~    ~. \n");
	printf(" /  o `./      .' JTMOS Squirrel Shell 1.1 \n");
	printf("{o__,   \\    {    \n");
	printf("  / .  . )    \\   (C) 2002-2003 by Jari Tuominen\n");
	printf("  `-` '-' \\    }  jari@vunet.org\n");
	printf(" .(   _(   )_.'  \n");
	printf("'---.~_ _ _|     \n");
}

// Start shell process itself
void sqsh_start(void)
{
	// Start prompt
	sqsh_prompt();
}

// Check sqsh start arguments for various options
int checkArgus(int argc, char **argv)
{
	if(argc>=2)
	{
		if(!strcmp(argv[1],"--dir"))
		{
            if(argc<3) { printf("sqsh: --dir requires a path.\n"); return 1; }
			if(chdir(argv[2])!=0) { printf("sqsh: cannot chdir to %s\n",argv[2]); return 1; }
			return -1;
		}

		if(!strcmp(argv[1],"--help"))
		{
			show_help_page(argc, argv);
			return 1;
		}
	}
	return 0;
}

// This is done in boot up sequence
void bootseq(void)
{
	if( !loadscript("/etc/boot.sh") )return;
	if( !loadscript("/bin/boot.sh") )return;
	if( !loadscript("/usr/etc/boot.sh") )return;
	if( !loadscript("/boot.sh") )return;
	printf("Cannot find boot.sh -automation script, entering manual start up ...\n");
}

//
int main(int argc, char **argv)
{
	int onecmd;
	memset(&sqsh, 0, sizeof(sqsh));

	/* Internal pipeline worker: no banner or prompt may leak into stdout. */
	if(argc>=3 && !strcmp(argv[1],"--pipe-stage"))
	{
		if(!sqsh_init()) return 125;
		getcwd(sqsh.path,sizeof(sqsh.path)-1);
		onecmd=sqsh_parsecmd(argv[2],0);
		return onecmd==-2 ? 127 : 0;
	}

	// Initialize
	printf("\rSquirrel Shell is now initialising ...                   \r");
	if(!sqsh_init()) return 2;
	printf("\r                                                         \r");

	//
	sqsh.script_run=0;
	sqsh.lines_script=0;

	//
	if( (sqsh_special=checkArgus(argc,argv))==1 )
	{
		// Shell quits
		return 0;
	}

	// Handle sqsh_special==-1 here
	// -1 = load start up sequence
	if(sqsh_special==-1)bootseq();

	// Load script if one defined
	if(argc>=2 && strstr(argv[1], "-")==NULL)
		loadscript(argv[1]);

	// Shell starts
	sqsh_start();

	//
	return 0;
}
