#include <stdio.h>
#include <string.h>
#include "sqa.h"

#if defined(JTMOS_APPLICATION)
#include <jtmos/process.h>
SYSMEMREQ(APPRAM_2048K)
#endif

int sqa_main(int argc, char **argv)
{
    int i,rc;
    int quiet_mode=0;
    char wanted[256];
    char destination[256];

    wanted[0]='\0';
    destination[0]='\0';
    if(argc < 2) {
        printf("Squirrel Archive Extractor V68.124\n");
        printf("Usage: %s archive-or-device [-q] [-u file] [-o directory]\n",argv[0]);
        return 0;
    }
    for(i=2;i<argc;++i) {
        if(strcmp(argv[i],"-q") == 0) quiet_mode=1;
        else if(strcmp(argv[i],"-u") == 0) {
            size_t n;
            if(++i >= argc) return 2;
            n=strlen(argv[i]);
            if(n >= sizeof(wanted)) return 2;
            memcpy(wanted,argv[i],n+1U);
        } else if(strcmp(argv[i],"-o") == 0) {
            size_t n;
            if(++i >= argc) return 2;
            n=strlen(argv[i]);
            if(n >= sizeof(destination)) return 2;
            memcpy(destination,argv[i],n+1U);
        } else {
            fprintf(stderr,"sqa: unknown option %s\n",argv[i]);
            return 2;
        }
    }
    rc=extract_archive_ex(argv[1],wanted,destination,0,quiet_mode);
    if(rc==1)
        rc=extract_archive_ex(argv[1],wanted,destination,640*1024,quiet_mode);
    if(rc != 0 && !quiet_mode) fprintf(stderr,"sqa: error %d\n",rc);
    return rc;
}

#ifndef JTMOSKERNEL
int main(int argc, char **argv) { return sqa_main(argc,argv); }
#endif
