/*
 * nzipMain.c - command line front-end for JTMOS nzip / unz.
 *
 * Historical unz semantics by Jari Tuominen:
 *   unz = nzip decompressor + automatic Squirrel-image extractor.
 *
 * UNCOMPRESS_ALL deliberately has no installer/media discovery policy.  With
 * no argument it processes .nz files in the caller's current directory.  With
 * one argument it processes exactly that archive.  If the decompressed output
 * ends in .img, the embedded SQA extractor is run on that image.  The .img is
 * retained; unz never changes cwd and never removes the decompressed image.
 */
#include <stdio.h>
#include <string.h>
#ifdef JTMOS_APPLICATION
#include <stdlib.h>
#include <unistd.h>
#endif
#include "nzip.h"

#ifdef UNCOMPRESS_ALL
#include "sqa.h"
#ifdef JTMOS_APPLICATION
#include <jtmos/filefind.h>
#endif

static int has_suffix(const char *s, const char *suffix)
{
    size_t n,m;
    if(s == NULL || suffix == NULL) return 0;
    n=strlen(s);
    m=strlen(suffix);
    return n>=m && strcmp(s+n-m,suffix)==0;
}

static int has_nz_suffix(const char *s)
{
    return has_suffix(s,".nz");
}

static int unz_one(const char *name)
{
    char out[512];
    int rc;

    if(!has_nz_suffix(name)) {
        fprintf(stderr,"unz: '%s' is not an .nz file\n",name ? name : "(null)");
        return 1;
    }
    if(nzip_output_name(out,sizeof(out),name) != 0) {
        fprintf(stderr,"unz: output name is too long\n");
        return 1;
    }

    printf("unz: %s -> %s\n",name,out);
    rc=nzip_uncompress(name,out);
    if(rc!=0) {
        fprintf(stderr,"unz: nzip decompression failed for %s (%d)\n",name,rc);
        return rc;
    }

    /* Historical two-stage behaviour: *.img.nz -> *.img -> SQA files. */
    if(has_suffix(out,".img")) {
        printf("unz: Squirrel image %s; extracting\n",out);
        rc=extract_archive_ex(out,"","",0,0);
        if(rc!=0) {
            fprintf(stderr,"unz: SQA extraction of %s failed (%d)\n",out,rc);
            return rc;
        }
        printf("unz: Squirrel image %s extracted\n",out);
    }
    return 0;
}

static void unz_usage(const char *argv0)
{
    const char *name=(argv0 && argv0[0]) ? argv0 : "unz";
    printf("Usage: %s [archive.nz]\n",name);
    printf("Without an argument, all .nz files in the current directory are unpacked.\n");
    printf("If the decompressed output ends in .img, SQA extraction follows automatically.\n");
}
#endif

#ifdef UNCOMPRESS_ALL
/*
 * Directory enumeration is intentionally isolated from archive extraction.
 * Extracting an image can create files/directories, so mutating the cwd while
 * a live findfirst/findnext cursor points into it is fragile.  Take a snapshot
 * of the .nz names first, close the descriptor, and only then decompress.
 *
 * FFBLK lives in static application storage rather than immediately below the
 * Ring-3 stack ceiling.  SYS_findfirst/findnext are also range-checked in the
 * kernel, but keeping the ABI object away from return frames makes legacy
 * callers substantially easier to diagnose and prevents a malformed copyout
 * from corrupting the active call chain.
 */
typedef struct UNZ_NAME_LIST {
    char (*name)[260];
    size_t count;
    size_t capacity;
} UNZ_NAME_LIST;

static FFBLK unz_ffblk;

static void unz_names_free(UNZ_NAME_LIST *l)
{
    if(l==NULL) return;
    free(l->name);
    l->name=NULL;
    l->count=0U;
    l->capacity=0U;
}

static int unz_names_append(UNZ_NAME_LIST *l,const char *name)
{
    size_t n;
    char (*p)[260];
    size_t newcap;
    if(l==NULL || name==NULL) return -1;
    n=strlen(name);
    if(n==0U || n>=260U) return -1;
    if(l->count==l->capacity) {
        newcap=l->capacity ? l->capacity*2U : 16U;
        if(newcap<l->capacity || newcap>((size_t)-1)/sizeof(l->name[0])) return -1;
        p=(char (*)[260])realloc(l->name,newcap*sizeof(l->name[0]));
        if(p==NULL) return -1;
        l->name=p;
        l->capacity=newcap;
    }
    memcpy(l->name[l->count],name,n+1U);
    l->count++;
    return 0;
}

static int unz_snapshot_current_directory(UNZ_NAME_LIST *l)
{
    int fd;
    int next_rc;
    int rc=0;
    if(l==NULL) return -1;
    memset(l,0,sizeof(*l));
    memset(&unz_ffblk,0,sizeof(unz_ffblk));
    fd=findfirst("*",&unz_ffblk);
    if(fd<=0) return -1;
    for(;;) {
        unz_ffblk.ff_name[sizeof(unz_ffblk.ff_name)-1U]='\0';
        if(has_nz_suffix(unz_ffblk.ff_name)) {
            if(unz_names_append(l,unz_ffblk.ff_name)!=0) { rc=-1; break; }
        }
        memset(&unz_ffblk,0,sizeof(unz_ffblk));
        next_rc=findnext(fd,&unz_ffblk);
        if(next_rc!=0) break;
    }
    if(close(fd)!=0 && rc==0) rc=-1;
    if(rc!=0) unz_names_free(l);
    return rc;
}

static int unz_all_in_current_directory(void)
{
    UNZ_NAME_LIST list;
    size_t i;
    int errors=0;
    if(unz_snapshot_current_directory(&list)!=0) {
        fprintf(stderr,"unz: unable to get current-directory listing\n");
        return 1;
    }
    if(list.count==0U) {
        fprintf(stderr,"unz: no .nz files found in current directory\n");
        unz_names_free(&list);
        return 1;
    }
    for(i=0U;i<list.count;i++)
        if(unz_one(list.name[i])!=0) errors++;
    unz_names_free(&list);
    return errors ? 1 : 0;
}

#endif /* UNCOMPRESS_ALL */

int nzip_main(int argc, char **argv)
{
#ifdef UNCOMPRESS_ALL
    if(argc>2) {
        unz_usage(argv ? argv[0] : "unz");
        return 1;
    }
    if(argc==2) {
        if(argv[1] && (!strcmp(argv[1],"-h") || !strcmp(argv[1],"--help"))) {
            unz_usage(argv[0]);
            return 0;
        }
        return unz_one(argv[1]);
    }

    /* No install.img.nz special case: historical unz scans only the cwd. */
    return unz_all_in_current_directory();
#else
    /* V16.71 default is NZIP2 fast LZ77.  Historical V1 codecs remain
     * selectable only for archive/recovery compatibility. */
    if(argc == 2) return nzip_compress_named_mode(argv[1],NZIP_MODE_AUTO);
    if(argc == 3 && strcmp(argv[1],"-d") == 0) return uncompress(argv[2]);
    if(argc == 3 && strcmp(argv[1],"--auto") == 0)
        return nzip_compress_named_mode(argv[2],NZIP_MODE_AUTO);
    if(argc == 3 && strcmp(argv[1],"--fast") == 0)
        return nzip_compress_named_mode(argv[2],NZIP_MODE_FAST);
    if(argc == 3 && strcmp(argv[1],"--legacy") == 0)
        return nzip_compress_named_mode(argv[2],NZIP_MODE_LEGACY);
    if(argc == 3 && strcmp(argv[1],"--bwt") == 0)
        return nzip_compress_named_mode(argv[2],NZIP_MODE_BWT);
#if defined(JTMOSKERNEL) || defined(SMSH_EMBEDDED)
    printf("Usage: %s file\n"
           "       %s --auto file\n"
           "       %s --fast file\n"
           "       %s --legacy file\n"
           "       %s --bwt file\n"
           "       %s -d file.nz\n",
           argv[0],argv[0],argv[0],argv[0],argv[0],argv[0]);
#else
    fprintf(stderr,"Usage: %s file\n"
                   "       %s --auto file\n"
                   "       %s --fast file\n"
                   "       %s --legacy file\n"
                   "       %s --bwt file\n"
                   "       %s -d file.nz\n",
            argv[0],argv[0],argv[0],argv[0],argv[0],argv[0]);
#endif
    return 1;
#endif
}

#if !defined(JTMOSKERNEL) && !defined(SMSH_EMBEDDED)
int main(int argc, char **argv)
{
    return nzip_main(argc,argv);
}
#endif
