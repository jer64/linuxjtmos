#include <stdio.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/process.h>
SYSMEMREQ(APPRAM_256K)
int main(int argc,char **argv)
{
    int wid,er; GUICMD ev;
    (void)argc;(void)argv;
    if(connectGraos()!=0) return 1;
    wid=createWindow(250,110,280,170,"IPC window (guitest)",GRAOS_WINDOW_STANDARD);
    if(wid<0) return 2;
    if(createLabel(wid,24,30,230,16,7400,0,GRAOS_LABEL_TRANSPARENT,
                   GRAOS_LABEL_ALIGN_LEFT,"Label + button IPC test")<0 ||
       createButton(wid,24,62,150,90,GRAOS_BUTTON_STANDARD,"IPC BUTTON")<0 ||
       refreshWindow(wid)<0) {
        closeWindow(wid);
        return 3;
    }
    for(;;) {
        while((er=JtmosGraOSPollEvent(wid,&ev))>0) {
            if(ev.id==GRAOS_GSID_EXIT) return 0;
            if(ev.id==GRAOS_GSID_BUTTON) setLabelText(wid,7400,"IPC button event received");
        }
        if(er<0) return 4;
        SwitchToThread();
    }
    return 0;
}
