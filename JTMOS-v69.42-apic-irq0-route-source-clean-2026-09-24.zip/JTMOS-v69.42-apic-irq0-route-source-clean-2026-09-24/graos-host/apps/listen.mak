# Historical JTMOS application placeholder.
APPNAME=listen
.PHONY: default clean
default:
	@echo "listen: source file is not present in the active libc/apps tree; target is archival only." >&2
	@false
clean:
	@rm -f listen.o listen.bin listen.map
