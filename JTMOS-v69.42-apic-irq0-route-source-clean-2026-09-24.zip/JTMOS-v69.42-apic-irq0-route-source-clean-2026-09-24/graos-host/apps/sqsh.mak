# JTMOS V67 static ELF32 application
APPNAME=sqsh
include app-common.mk
