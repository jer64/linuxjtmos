# JTMOS V67 static ELF32 application
APPNAME=sscanf_test
include app-common.mk
