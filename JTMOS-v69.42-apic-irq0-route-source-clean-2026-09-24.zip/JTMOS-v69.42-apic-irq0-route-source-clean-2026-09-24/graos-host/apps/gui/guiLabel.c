/* guiLabel.c - native GraOS label widget, V67.8 / GraOS V32. */
#include "guiLabel.h"
#include "guiWidget.h"
#include "guiRect.h"
#include "guifont.h"

static void label_copy_text(char *dst,int cap,const char *src)
{
    int i=0; if(!dst || cap<=0) return;
    if(src) while(i<cap-1 && src[i]) { dst[i]=src[i]; i++; }
    dst[i]=0;
}
LABEL *guiGetLabel(WINDOW *w,int id)
{
    int i; if(!w) return NULL;
    for(i=0;i<w->n_labels;i++)
        if(w->label[i].widget.visible && w->label[i].widget.id==id) return &w->label[i];
    return NULL;
}
LABEL *guiCreateLabel(WINDOW *w,int x,int y,int width,int height,int id,int fg,int bg,int align,const char *text)
{
    LABEL *l=NULL; int i;
    if(!w || width<=0 || height<=0) return NULL;
    if(align<GRAOS_LABEL_ALIGN_LEFT || align>GRAOS_LABEL_ALIGN_RIGHT) return NULL;
    if(fg<0 || fg>255 || bg>255 || bg<GRAOS_LABEL_TRANSPARENT) return NULL;
    if(guiGetLabel(w,id)) return NULL;
    for(i=0;i<w->n_labels;i++) if(!w->label[i].widget.visible) { l=&w->label[i]; break; }
    if(!l) { if(w->n_labels>=GRAOS_MAX_LABELS) return NULL; l=&w->label[w->n_labels++]; }
    memset(l,0,sizeof(*l));
    guiWidgetInit(&l->widget,GRAOS_WIDGET_LABEL,id,x,y,width,height,w->id,GRAOS_WIDGET_VISIBLE|GRAOS_WIDGET_ENABLED);
    l->fg=fg; l->bg=bg; l->align=align; label_copy_text(l->text,sizeof(l->text),text?text:"");
    return l;
}
int guiSetLabelText(WINDOW *w,int id,const char *text)
{ LABEL *l=guiGetLabel(w,id); if(!l)return 0; label_copy_text(l->text,sizeof(l->text),text?text:""); l->widget.flags|=GRAOS_WIDGET_DIRTY; return 1; }
int guiSetLabelStyle(WINDOW *w,int id,int fg,int bg,int align)
{
    LABEL *l=guiGetLabel(w,id); if(!l)return 0;
    if(align<GRAOS_LABEL_ALIGN_LEFT || align>GRAOS_LABEL_ALIGN_RIGHT) return 0;
    if(fg<0 || fg>255 || bg>255 || bg<GRAOS_LABEL_TRANSPARENT) return 0;
    l->fg=fg;l->bg=bg;l->align=align;l->widget.flags|=GRAOS_WIDGET_DIRTY;return 1;
}
int guiRemoveLabel(WINDOW *w,int id)
{ LABEL *l=guiGetLabel(w,id); if(!l)return 0; guiWidgetSetVisible(&l->widget,0); l->text[0]=0; return 1; }
void guiDrawLabel(VMODE *v,WINDOW *w,LABEL *l)
{
    char text[GRAOS_LABEL_TEXT_MAX]; int x,y,maxchars,n,tw; GRAOS_WIDGET *g;
    if(!v||!w||!l)return;
    g=&l->widget;
    if(!g->visible || g->width<=0 || g->height<=0) return;
    x=w->x+g->x; y=w->y+g->y;
    if(l->bg>=0) fillRect(v,x,y,x+g->width-1,y+g->height-1,l->bg);
    maxchars=g->width/8; if(maxchars<=0 || !l->text[0]) return;
    if(maxchars>=GRAOS_LABEL_TEXT_MAX) maxchars=GRAOS_LABEL_TEXT_MAX-1;
    n=0; while(n<maxchars && l->text[n] && l->text[n]!='\n' && l->text[n]!='\r'){text[n]=l->text[n];n++;} text[n]=0;
    tw=n*8; if(l->align==GRAOS_LABEL_ALIGN_CENTER)x+=(g->width-tw)/2; else if(l->align==GRAOS_LABEL_ALIGN_RIGHT)x+=(g->width-tw);
    y+=(g->height-8)/2; DrawText(v,text,x,y,l->fg,-1); g->flags&=~GRAOS_WIDGET_DIRTY;
}
