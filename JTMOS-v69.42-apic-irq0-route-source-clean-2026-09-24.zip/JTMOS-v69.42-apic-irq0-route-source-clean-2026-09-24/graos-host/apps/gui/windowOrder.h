#ifndef __INCLUDED_WINDOWORDER_H__
#define __INCLUDED_WINDOWORDER_H__
#include "graos.h"
int putWindowOnTop(VMODE *v, WINDOW *w);
#endif
