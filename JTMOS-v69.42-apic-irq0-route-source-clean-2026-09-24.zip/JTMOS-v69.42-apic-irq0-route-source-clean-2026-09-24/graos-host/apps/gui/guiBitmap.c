/* guiBitmap.c - native 32-bpp RGBA bitmap widget. */
#include "guiBitmap.h"
#include "guiWidget.h"
#include "guiBlit.h"
BITMAP *guiGetBitmap(WINDOW*w,int id){int i;if(!w)return NULL;for(i=0;i<w->n_bitmaps;i++)if(w->bitmap[i].widget.visible&&w->bitmap[i].widget.id==id)return&w->bitmap[i];return NULL;}
BITMAP *guiCreateBitmap(WINDOW*w,int x,int y,int width,int height,int id,int transparent,const GRAOS_PIXEL*pixels)
{BITMAP*b=NULL;int i,bytes;if(!w||!pixels||width<=0||height<=0)return NULL;if(width>GRAOS_BITMAP_MAX_WIDTH||height>GRAOS_BITMAP_MAX_HEIGHT)return NULL;if(transparent!=GRAOS_BLIT_OPAQUE&&transparent!=GRAOS_BLIT_ALPHA)return NULL;if(guiGetBitmap(w,id))return NULL;bytes=width*height*4;if(bytes<=0||bytes>GRAOS_BITMAP_MAX_BYTES)return NULL;for(i=0;i<w->n_bitmaps;i++)if(!w->bitmap[i].widget.visible){b=&w->bitmap[i];break;}if(!b){if(w->n_bitmaps>=GRAOS_MAX_BITMAPS)return NULL;b=&w->bitmap[w->n_bitmaps++];}memset(b,0,sizeof(*b));b->pixels=(GRAOS_PIXEL*)malloc((size_t)bytes);if(!b->pixels)return NULL;memcpy(b->pixels,pixels,(size_t)bytes);guiWidgetInit(&b->widget,GRAOS_WIDGET_BITMAP,id,x,y,width,height,w->id,GRAOS_WIDGET_VISIBLE|GRAOS_WIDGET_ENABLED);b->transparent=transparent;b->bytes=bytes;return b;}
int guiSetBitmapData(WINDOW*w,int id,const GRAOS_PIXEL*pixels,int bytes){BITMAP*b=guiGetBitmap(w,id);if(!b||!pixels||bytes!=b->bytes)return 0;memcpy(b->pixels,pixels,(size_t)bytes);b->widget.flags|=GRAOS_WIDGET_DIRTY;return 1;}
int guiRemoveBitmap(WINDOW*w,int id){BITMAP*b=guiGetBitmap(w,id);if(!b)return 0;if(b->pixels)free(b->pixels);memset(b,0,sizeof(*b));return 1;}
void guiFreeWindowBitmaps(WINDOW*w){int i;if(!w)return;for(i=0;i<w->n_bitmaps;i++){if(w->bitmap[i].pixels)free(w->bitmap[i].pixels);memset(&w->bitmap[i],0,sizeof(w->bitmap[i]));}w->n_bitmaps=0;}
void guiDrawBitmap(VMODE*v,WINDOW*w,BITMAP*b){GRAOS_WIDGET*g;if(!v||!w||!b||!b->pixels)return;g=&b->widget;if(!g->visible)return;guiBlit(v,w->x+g->x,w->y+g->y,g->width,g->height,b->pixels,g->width,b->transparent);g->flags&=~GRAOS_WIDGET_DIRTY;}
