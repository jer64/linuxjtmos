#include "guiRect.h"
void fillRectRGBA(VMODE *v,int x1,int y1,int x2,int y2,GRAOS_PIXEL c)
{
    int x,y,w,h;
    GRAOS_PIXEL *row;
    if(!v || !v->buf || v->width<=0 || v->height<=0) return;
    if(x1>x2){x=x1;x1=x2;x2=x;}
    if(y1>y2){y=y1;y1=y2;y2=y;}
    if(x2<0 || y2<0 || x1>=v->width || y1>=v->height) return;
    if(x1<0) x1=0;
    if(y1<0) y1=0;
    if(x2>=v->width) x2=v->width-1;
    if(y2>=v->height) y2=v->height-1;
    w=x2-x1+1;h=y2-y1+1;
    row=v->buf+y1*v->width+x1;
    for(x=0;x<w;x++) row[x]=c;
    for(y=1;y<h;y++) memcpy(v->buf+(y1+y)*v->width+x1,row,(size_t)w*4U);
    v->dirty=1;
}
void fillRect(VMODE *v,int x1,int y1,int x2,int y2,int c)
{ fillRectRGBA(v,x1,y1,x2,y2,graosIndexToPixel(c)); }
void drawRectRGBA(VMODE *v,int x1,int y1,int x2,int y2,GRAOS_PIXEL c)
{
    fillRectRGBA(v,x1,y1,x2,y1,c); fillRectRGBA(v,x1,y2,x2,y2,c);
    fillRectRGBA(v,x1,y1,x1,y2,c); fillRectRGBA(v,x2,y1,x2,y2,c);
}
void drawRect(VMODE *v,int x1,int y1,int x2,int y2,int c)
{ drawRectRGBA(v,x1,y1,x2,y2,graosIndexToPixel(c)); }
