#ifndef __INCLUDED_EGAFONT_DATA_H__
#define __INCLUDED_EGAFONT_DATA_H__
#include <jtmos/basdef.h>
#define EGA_FONT_WIDTH 8
#define EGA_FONT_HEIGHT 16
#define EGA_FONT_GLYPHS 256
extern const BYTE graos_ega_font[EGA_FONT_GLYPHS*EGA_FONT_HEIGHT];
#endif
