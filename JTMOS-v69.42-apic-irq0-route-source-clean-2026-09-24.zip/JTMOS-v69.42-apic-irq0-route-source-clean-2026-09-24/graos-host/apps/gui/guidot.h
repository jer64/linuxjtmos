#ifndef __INCLUDED_GUIDOT_H__
#define __INCLUDED_GUIDOT_H__
#include "graos.h"
int gui_dotPut(VMODE *v,int x,int y,int c);
int gui_dotGet(VMODE *v,int x,int y);
int gui_dotPutArea(VMODE *v,int x,int y,int width,int height,int c);
#endif
