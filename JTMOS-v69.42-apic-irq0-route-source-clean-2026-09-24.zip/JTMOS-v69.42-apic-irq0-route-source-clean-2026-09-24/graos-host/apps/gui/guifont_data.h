#ifndef __INCLUDED_GUIFONT_DATA_H__
#define __INCLUDED_GUIFONT_DATA_H__
#include <jtmos/basdef.h>
#define GRAOS_GUIFONT_BYTES 8192
extern const BYTE graos_guifont_raw[GRAOS_GUIFONT_BYTES];
#endif
