/* bitmapdemo.c - GraOS V34 RGBA Bitmap widget demo, JTMOS V67.8. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/process.h>
SYSMEMREQ(APPRAM_256K)

#define SQ_W 96
#define SQ_H 96
#define SQ_BYTES (SQ_W*SQ_H*4)
#define SQ_BITMAP 7001
#define SQ_LABEL 7002
#define SQ_CLOSE 7099

static int load_squirrel(GRAOS_PIXEL *buf)
{
    FILE *f;
    int n;
    const char *names[]={"squirrel16.raw","./squirrel16.raw","/bin/squirrel16.raw","ram:/bin/squirrel16.raw",NULL};
    int i;
    for(i=0;names[i];i++) {
        f=fopen(names[i],"rb");
        if(!f) continue;
        n=(int)fread(buf,1,SQ_BYTES,f);
        fclose(f);
        if(n==SQ_BYTES) return 0;
    }
    return -1;
}

int main(void)
{
    GRAOS_PIXEL *pixels;
    GUICMD ev;
    int wid,er,server_closed=0;
    if(connectGraos()!=0) return 1;
    pixels=(GRAOS_PIXEL*)malloc(SQ_BYTES);
    if(!pixels) return 2;
    if(load_squirrel(pixels)!=0) { free(pixels); return 3; }
    wid=createWindow(-1,-1,176,166,"GraOS Bitmap - Squirrel",GRAOS_WINDOW_STANDARD);
    if(wid<0) { free(pixels); return 5; }
    createLabel(wid,16,22,144,14,SQ_LABEL,0,7,GRAOS_LABEL_ALIGN_CENTER,
                "32-bpp RGBA RAW");
    if(createBitmap(wid,40,42,SQ_W,SQ_H,SQ_BITMAP,pixels,GRAOS_BITMAP_TRANSPARENT_NONE)<0) {
        closeWindow(wid); free(pixels); return 6;
    }
    createButton(wid,52,142,124,160,SQ_CLOSE,"Close");
    refreshWindow(wid);
    for(;;) {
        while((er=JtmosGraOSPollEvent(wid,&ev))>0) {
            if(ev.id==GRAOS_GSID_EXIT) { server_closed=1; goto out; }
            if(ev.id==GRAOS_GSID_BUTTON && ev.v[0]==SQ_CLOSE) goto out;
        }
        if(er<0) { server_closed=1; goto out; }
        SwitchToThread();
        Sleep(10);
    }
out:
    if(!server_closed) {
        removeBitmap(wid,SQ_BITMAP);
        closeWindow(wid);
    }
    free(pixels);
    return 0;
}
