#ifndef __INCLUDED_GUIBLIT_H__
#define __INCLUDED_GUIBLIT_H__
#include "graos.h"
void guiBlit(VMODE*,int,int,int,int,const GRAOS_PIXEL*,int,int);
#endif
