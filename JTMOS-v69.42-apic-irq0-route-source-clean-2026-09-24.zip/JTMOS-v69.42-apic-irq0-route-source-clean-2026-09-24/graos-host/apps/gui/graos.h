#ifndef __INCLUDED_GRAOS_H__
#define __INCLUDED_GRAOS_H__
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <jtmos/basdef.h>
#include <jtmos/process.h>
#include <jtmos/mouse.h>
#include <jtmos/scall.h>
#include <jtmos/msgbox.h>
#include <jtmos/syscallcodes.h>
#include "guiPixel.h"
#include "window.h"
#define GRAOS_VERSION "V37"
#define GRAOS_WIDTH 1024
#define GRAOS_HEIGHT 768
#define GRAOS_BPP 32
#define GRAOS_FRAME_PIXELS (GRAOS_WIDTH*GRAOS_HEIGHT)
#define GRAOS_FRAME_BYTES (GRAOS_FRAME_PIXELS*4)
#define GRAOS_PANEL_HEIGHT 30
#define GRAOS_SERVER_BURST 8
#define GRAOS_SERVER_PID_NAME "guiserver"
#define GRAOS_ENABLE_SERVER 1
#define GRAOS_ENABLE_BACKGROUND 0
#define GRAOS_ENABLE_CURSOR 1
typedef struct {
    GRAOS_PIXEL *buf;
    int width,height,bpp,l_buf;
    GRAOS_PIXEL *background;
    GRAOS_PIXEL cursor[32*32];
    int cursor_loaded;
    int x,y,lx,ly,buttons,last_buttons;
    WINDOW *selwin;
    WINDOW *underwin;
    BUTTON *underbut;
    WINDOW *movwin;
    int movingWindow;
    int origx,origy,oldx,oldy;
    BUTTON *pressed_button;
    WINDOW *pressed_window;
    int running;
    int dirty;
    unsigned long frame_counter;
    unsigned long terminal_poll_tick;
    unsigned long last_mouse_packet_count;
    int prompt_launch_state;
    int prompt_delay_yields;
    int start_menu_open;
    int start_menu_pressed_item;
    int start_button_pressed;
    int desktop_color;
    int desktop_solid;
} VMODE;

/* These terminal calls are implemented by the modern application libc but
 * are not yet exposed by its compact process.h compatibility header. */
int CreateTerminal(void);
int GetCursorLocation(int terminal_id);
int CopyThreadTerminal(int terminal_id,BYTE *buffer);
int graos_present(VMODE *v);
#endif
