#ifndef __INCLUDED_GUISTART_H__
#define __INCLUDED_GUISTART_H__
#include "graos.h"
#define GRAOS_MENU_TERMINAL 1
#define GRAOS_MENU_FILER 2
#define GRAOS_MENU_EDITOR 3
#define GRAOS_MENU_TOP 4
#define GRAOS_MENU_CONTROL 5
#define GRAOS_MENU_APPLICATIONS 6
#define GRAOS_MENU_CLOSE 7
VMODE *guiStart(void);
void guiReapExitedTerminalPrograms(VMODE *v);
int guiStartCommandPrompt(VMODE *v);
int guiStartTerminalProgram(VMODE *v,const char *program,const char *caption);
int guiLaunchBackgroundApp(VMODE *v,const char *program);
int guiOpenControlPanel(VMODE *v);
int guiStartMenuAction(VMODE *v,int action);
#endif
