#ifndef JTMOS_GRAOS_LAUNCH_COMPAT_H
#define JTMOS_GRAOS_LAUNCH_COMPAT_H

/*
 * GraOS application launch compatibility helpers.
 *
 * The desktop payload is installed on ram:/bin.  Historically JTMOS also
 * exposed that directory as the namespace-absolute /bin.  During storage/root
 * transitions a GUI process can keep a valid executable set while legacy /bin
 * resolution no longer describes the same device.  Desktop actions must not
 * all fail just because that compatibility spelling is unavailable.
 *
 * Always try the caller's normal command first.  For core /bin programs, retry
 * with an explicit ram:/ device path and an explicit RAM working directory.
 * This preserves old installations while making the boot desktop independent
 * of the process CWD and namespace-root alias.
 */

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <jtmos/process.h>

#define GRAOS_LAUNCH_CMD_MAX 512

static int graos_make_ram_command(const char *cmd,char *out,int cap)
{
    int n;
    if(!cmd || !out || cap<=0 || strncmp(cmd,"/bin/",5)!=0) return 0;
    n=snprintf(out,(size_t)cap,"ram:%s",cmd);
    if(n<0 || n>=cap) {
        out[0]=0;
        return 0;
    }
    return 1;
}

static int graos_try_bgexec_ex(const char *cmd,const char *cwd,int ter)
{
    if(!cmd || !*cmd || !cwd || !*cwd) return 0;
    return bgexecEx(cmd,cwd,ter);
}

static int graos_bgexec_ex_command(const char *cmd,const char *cwd,int ter)
{
    char ramcmd[GRAOS_LAUNCH_CMD_MAX];
    int pid;

    if(!cmd || !*cmd) return 0;

    /* First preserve the traditional process CWD and namespace semantics. */
    if(cwd && *cwd) {
        pid=graos_try_bgexec_ex(cmd,cwd,ter);
        if(pid>0) return pid;
    }
    if(!cwd || strcmp(cwd,"/")!=0) {
        pid=graos_try_bgexec_ex(cmd,"/",ter);
        if(pid>0) return pid;
    }

    /* Core desktop programs physically live on the RAM root medium. */
    if(!graos_make_ram_command(cmd,ramcmd,sizeof(ramcmd))) return 0;

    pid=graos_try_bgexec_ex(ramcmd,"ram:/bin",ter);
    if(pid<=0) pid=graos_try_bgexec_ex(ramcmd,"ram:/",ter);
    if(pid>0)
        printf("GraOS: legacy launch '%s' recovered as '%s'.\n",cmd,ramcmd);
    return pid;
}

static int graos_bgexec_command(const char *cmd,const char *cwd)
{
    return graos_bgexec_ex_command(cmd,cwd,-1);
}

static int graos_file_available(const char *path)
{
    char rampath[GRAOS_LAUNCH_CMD_MAX];
    int fd;

    if(!path || !*path) return 0;
    fd=open(path,O_RDONLY);
    if(fd>=0) {
        close(fd);
        return 1;
    }
    if(!graos_make_ram_command(path,rampath,sizeof(rampath))) return 0;
    /* File probes receive plain paths, not argument-bearing commands. */
    if(strchr(rampath,' ')!=NULL) return 0;
    fd=open(rampath,O_RDONLY);
    if(fd<0) return 0;
    close(fd);
    return 1;
}

#endif
