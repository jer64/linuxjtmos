# Native external GraOS applications (JTMOS V67.8)

These are Ring3 JTMOS clients of the central `graos.bin` window server.  They
are derived from the Linux/SDL2 GraOS application model but use the native
JTMOS message box, terminal and LaunchApp ABI.

- `terminal.bin` - 80x25 kernel terminal surface; defaults to `/bin/sqsh.bin`.
- `controlpanel.bin` - desktop controls and launch buttons.
- `launcher.bin` - common JTMOS applications and demos.
- `labeldemo.bin` - Label widget create/update/style/remove regression demo.
- `graosctl.bin` - server ping/status/shutdown/color CLI.
- `graostaskbar.bin` - optional external taskbar; not auto-started because GraOS V32
  already has a built-in taskbar/Start menu.

All programs use plain PIDs.  No generation-ID compatibility layer is linked.

## Label component (GraOS V32)

Window clients can add non-interactive text widgets with `createLabel()` and
update them without owning a bitmap framebuffer.  Labels support transparent or
solid backgrounds, legacy MCGA-index foreground/background colours converted to RGBA32, and left,
centre or right alignment.  Runtime updates use `setLabelText()` and
`setLabelStyle()`; `removeLabel()` releases a label slot for reuse.

## Bitmap component (GraOS V32 / JTMOS V67.8)

Native windows can host server-owned 32-bpp RGBA bitmap widgets through `createBitmap()`,
`setBitmapData()` and `removeBitmap()`.  Pixel buffers are copied from the client
process with the existing cross-process copy syscall; the compositor never keeps
a raw userspace pointer.  `bitmapdemo.bin` displays `squirrel16.raw`, a 96x96 RGBA32 RAW image. Legacy integer colours are converted through `JtmosMCGAColorToRGBA()`; bitmap pixels themselves are never palette indices.

Button events are queued per window and retrieved with `JtmosGraOSPollEvent()`.
This replaces the fragile one-shot mailbox push for client buttons while keeping
asynchronous EXIT messages compatible with existing close-window behaviour.

## V67.8 / GraOS V32 window manager

`STANDARD_WINDOW` now includes a Minimize control.  Native GraOS keeps window
focus and Z-order in the server, excludes minimized windows from draw/hit-test,
and exposes the most recently used windows as buttons on the integrated taskbar.
Clicking the active task button minimizes it; clicking a minimized/inactive task
restores and focuses it.

All server-side components share `GRAOS_WIDGET` as their first/base structure.
Button, Label and Bitmap therefore use the same geometry/state vocabulary, and a
WINDOW owns a root widget for its component tree.  This is the base intended for
future TextBox, ListBox, Menu and ScrollBar widgets.


## TextBox widget (V67.8)

`createTextBox()` creates a server-owned single-line editable text field based on
`GRAOS_WIDGET`. Clicking gives it keyboard focus. Printable ASCII, Backspace,
Escape (blur) and Enter are supported. Enter is reported as `GSID_TEXTBOX_ENTER`;
clients can fetch the current value with `getTextBoxText()`. `textboxdemo.bin` is
the standalone runtime test, and Launcher uses a TextBox as its direct command
field.
