/* labeldemo.c - GraOS V32 native Label widget regression/demo client. */
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/process.h>
SYSMEMREQ(APPRAM_256K)

#define LD_LEFT 6001
#define LD_CENTER 6002
#define LD_RIGHT 6003
#define LD_STATUS 6004
#define LD_CHANGE 6010
#define LD_TOGGLE 6011
#define LD_CLOSE 6099

int main(void)
{
    GUICMD ev; int er;
    int wid,alternate=0,removed=0,server_closed=0;
    if(connectGraos()!=0) return 1;
    wid=createWindow(-1,-1,430,250,"GraOS Label Demo",GRAOS_WINDOW_STANDARD);
    if(wid<0) return 2;

    createLabel(wid,24,30,370,18,LD_LEFT,0,7,GRAOS_LABEL_ALIGN_LEFT,"Left aligned label");
    createLabel(wid,24,58,370,18,LD_CENTER,15,1,GRAOS_LABEL_ALIGN_CENTER,"Centered label");
    createLabel(wid,24,86,370,18,LD_RIGHT,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_RIGHT,"Right aligned label");
    createLabel(wid,24,122,370,16,LD_STATUS,0,7,GRAOS_LABEL_ALIGN_LEFT,"Ready - labels are server-side widgets");
    createButton(wid,24,158,178,190,LD_CHANGE,"Change labels");
    createButton(wid,200,158,354,190,LD_TOGGLE,"Remove / add");
    createButton(wid,128,204,282,232,LD_CLOSE,"Close");
    refreshWindow(wid);

    for(;;) {
        while((er=JtmosGraOSPollEvent(wid,&ev))>0) {
            if(ev.id==GRAOS_GSID_EXIT) { server_closed=1; goto out; }
            if(ev.id!=GRAOS_GSID_BUTTON) continue;
            if(ev.v[0]==LD_CLOSE) goto out;
            if(ev.v[0]==LD_CHANGE) {
                alternate=!alternate;
                if(alternate) {
                    setLabelText(wid,LD_LEFT,"Text updated through setLabelText");
                    setLabelStyle(wid,LD_CENTER,0,14,GRAOS_LABEL_ALIGN_CENTER);
                    setLabelText(wid,LD_STATUS,"Changed text + style successfully");
                } else {
                    setLabelText(wid,LD_LEFT,"Left aligned label");
                    setLabelStyle(wid,LD_CENTER,15,1,GRAOS_LABEL_ALIGN_CENTER);
                    setLabelText(wid,LD_STATUS,"Restored original labels");
                }
            } else if(ev.v[0]==LD_TOGGLE) {
                if(!removed) {
                    if(removeLabel(wid,LD_RIGHT)==0) {
                        removed=1;
                        setLabelText(wid,LD_STATUS,"Right label removed");
                    }
                } else {
                    if(createLabel(wid,24,86,370,18,LD_RIGHT,0,GRAOS_LABEL_TRANSPARENT,
                                   GRAOS_LABEL_ALIGN_RIGHT,"Right label re-created")==0) {
                        removed=0;
                        setLabelText(wid,LD_STATUS,"Right label re-created");
                    }
                }
            }
        }
        if(er<0) { server_closed=1; goto out; }
        SwitchToThread();
        Sleep(10);
    }
out:
    if(!server_closed) closeWindow(wid);
    return 0;
}
