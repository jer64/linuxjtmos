#include "guiBlit.h"
void guiBlit(VMODE *v,int dx,int dy,int w,int h,const GRAOS_PIXEL *src,int stride,int mode)
{
    int x,y,sx0=0,sy0=0,cw=w,ch=h;
    if(!v || !v->buf || !src || v->width<=0 || v->height<=0 ||
       stride<w || w<=0 || h<=0) return;
    if(dx<0){if(dx<=-w)return;sx0=-dx;cw-=sx0;dx=0;}
    if(dy<0){if(dy<=-h)return;sy0=-dy;ch-=sy0;dy=0;}
    if(dx>=v->width || dy>=v->height) return;
    if(cw>v->width-dx) cw=v->width-dx;
    if(ch>v->height-dy) ch=v->height-dy;
    if(cw<=0||ch<=0)return;
    if(mode==GRAOS_BLIT_OPAQUE) {
        for(y=0;y<ch;y++)
            memcpy(v->buf+(size_t)(dy+y)*(size_t)v->width+(size_t)dx,
                   src+(size_t)(sy0+y)*(size_t)stride+(size_t)sx0,
                   (size_t)cw*4U);
    } else {
        for(y=0;y<ch;y++) for(x=0;x<cw;x++) {
            GRAOS_PIXEL s=src[(size_t)(sy0+y)*(size_t)stride+(size_t)(sx0+x)];
            GRAOS_PIXEL *d=&v->buf[(size_t)(dy+y)*(size_t)v->width+(size_t)(dx+x)];
            *d=graosAlphaOver(*d,s);
        }
    }
    v->dirty=1;
}
