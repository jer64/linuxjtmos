#ifndef __INCLUDED_WINDOWFUNC_H__
#define __INCLUDED_WINDOWFUNC_H__
#include "graos.h"
BUTTON *guiCreateButtonEx(WINDOW *w,int x1,int y1,int x2,int y2,int id,int style,const char *caption);
BUTTON *guiCreateButton(WINDOW *w,int x1,int y1,int x2,int y2,int type,const char *caption);
void guiCloseWindow(VMODE *v,WINDOW *w);
void guiMinimizeWindow(VMODE *v,WINDOW *w);
void guiRestoreWindow(VMODE *v,WINDOW *w);
int guiSwitchTask(VMODE *v,int direction);
int guiQueueWindowEvent(WINDOW *w,int id,int v0,int v1,int v2);
int guiPopWindowEvent(WINDOW *w,GRAOSEVENT *ev);
void onButtonClick(VMODE *v,WINDOW *w,BUTTON *b);
#endif
