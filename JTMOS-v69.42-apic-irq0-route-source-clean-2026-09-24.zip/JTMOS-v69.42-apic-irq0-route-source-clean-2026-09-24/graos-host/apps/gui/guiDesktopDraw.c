#include "guiDesktopDraw.h"
#include "guiBmp.h"
#include "guiResource.h"
#include "guiRect.h"
#include "guifont.h"
#include "guiStart.h"
#include "wdb.h"
#include "windowFunc.h"
#include <jtmos/console.h>

/* Windows 98 scale: a 30-pixel taskbar, a compact raised Start button and a
 * roomy menu with a blue branding strip and 16x16 glyphs. */
#define START_X1 3
#define START_X2 66
#define START_MENU_X 3
#define START_MENU_W 228
#define START_MENU_BRAND 27
#define START_ITEM_H 32
#define START_MENU_ITEMS 7
#define START_MENU_PAD 4
#define START_MENU_H (START_MENU_ITEMS*START_ITEM_H+START_MENU_PAD*2)
#define TASKBAR_X1 72
#define TASKBAR_X2 (GRAOS_WIDTH-150)
#define TASKBAR_SLOTS 7
#define TASKBAR_GAP 3
#define TRAY_X1 (GRAOS_WIDTH-142)

static const char *start_item_text[START_MENU_ITEMS]={
    "Programs","File Manager","Text Editor","Task Manager","Settings","Run...","Close Menu"
};
static const int start_item_action[START_MENU_ITEMS]={
    GRAOS_MENU_APPLICATIONS,GRAOS_MENU_FILER,GRAOS_MENU_EDITOR,GRAOS_MENU_TOP,
    GRAOS_MENU_CONTROL,GRAOS_MENU_TERMINAL,GRAOS_MENU_CLOSE
};
static const int start_item_icon[START_MENU_ITEMS]={1,2,3,4,5,6,7};

int guiLoadBackground(VMODE*v,const char*name)
{
    FILE*f;GUI_BMP_INFO bi;
    if(!v||!name)return 0;
    v->background=(GRAOS_PIXEL*)malloc(GRAOS_FRAME_BYTES);if(!v->background)return 0;
    f=guiOpenResource(name,"rb");if(!f){free(v->background);v->background=NULL;return 0;}
    if(!guiBmpLoad32Stretch(f,v->background,v->width,v->height,&bi)){fclose(f);free(v->background);v->background=NULL;return 0;}
    fclose(f);
    printf("GraOS: BMP wallpaper %dx%d stretched to %dx%d (32-bit RGBA).\n",bi.width,bi.height,v->width,v->height);
    return 1;
}

static int panel_y(void){return GRAOS_HEIGHT-GRAOS_PANEL_HEIGHT;}
static int start_menu_y(void){return panel_y()-START_MENU_H;}
static int in_rect(int x,int y,int x1,int y1,int x2,int y2){return x>=x1&&x<=x2&&y>=y1&&y<=y2;}
static int menu_item_at(int x,int y)
{
    int my=start_menu_y()+START_MENU_PAD,n;
    if(x<START_MENU_X+START_MENU_BRAND+START_MENU_PAD||x>START_MENU_X+START_MENU_W-START_MENU_PAD-1)return-1;
    if(y<my||y>=my+START_MENU_ITEMS*START_ITEM_H)return-1;
    n=(y-my)/START_ITEM_H;return(n>=0&&n<START_MENU_ITEMS)?n:-1;
}

static void bevel(VMODE*v,int x1,int y1,int x2,int y2,int sunken)
{
    GRAOS_PIXEL hi=sunken?GRAOS_RGB(0,0,0):GRAOS_RGB(255,255,255);
    GRAOS_PIXEL lo=sunken?GRAOS_RGB(255,255,255):GRAOS_RGB(0,0,0);
    GRAOS_PIXEL mid=sunken?GRAOS_RGB(128,128,128):GRAOS_RGB(223,223,223);
    GRAOS_PIXEL lom=sunken?GRAOS_RGB(223,223,223):GRAOS_RGB(128,128,128);
    fillRectRGBA(v,x1,y1,x2,y1,hi);fillRectRGBA(v,x1,y1,x1,y2,hi);
    fillRectRGBA(v,x1+1,y1+1,x2-1,y1+1,mid);fillRectRGBA(v,x1+1,y1+1,x1+1,y2-1,mid);
    fillRectRGBA(v,x1,y2,x2,y2,lo);fillRectRGBA(v,x2,y1,x2,y2,lo);
    fillRectRGBA(v,x1+1,y2-1,x2-1,y2-1,lom);fillRectRGBA(v,x2-1,y1+1,x2-1,y2-1,lom);
}

static void menu_icon(VMODE*v,int kind,int x,int y)
{
    GRAOS_PIXEL black=GRAOS_RGB(0,0,0),white=GRAOS_RGB(255,255,255),gray=GRAOS_RGB(192,192,192);
    if(kind==1){
        fillRectRGBA(v,x,y,x+6,y+6,GRAOS_RGB(255,0,0));fillRectRGBA(v,x+8,y,x+14,y+6,GRAOS_RGB(0,128,255));
        fillRectRGBA(v,x,y+8,x+6,y+14,GRAOS_RGB(0,192,0));fillRectRGBA(v,x+8,y+8,x+14,y+14,GRAOS_RGB(255,255,0));return;
    }
    if(kind==2){fillRectRGBA(v,x+1,y+5,x+14,y+14,GRAOS_RGB(255,255,0));drawRectRGBA(v,x+1,y+5,x+14,y+14,black);fillRectRGBA(v,x+3,y+2,x+8,y+5,GRAOS_RGB(255,255,192));return;}
    if(kind==3){fillRectRGBA(v,x+3,y+1,x+12,y+14,white);drawRectRGBA(v,x+3,y+1,x+12,y+14,black);fillRectRGBA(v,x+5,y+5,x+10,y+5,GRAOS_RGB(0,0,128));fillRectRGBA(v,x+5,y+8,x+10,y+8,GRAOS_RGB(0,0,128));return;}
    if(kind==4){fillRectRGBA(v,x+1,y+2,x+14,y+11,gray);drawRectRGBA(v,x+1,y+2,x+14,y+11,black);fillRectRGBA(v,x+3,y+4,x+12,y+9,GRAOS_RGB(0,0,128));fillRectRGBA(v,x+5,y+12,x+10,y+13,black);return;}
    if(kind==5){fillRectRGBA(v,x+4,y+3,x+11,y+13,GRAOS_RGB(128,128,128));fillRectRGBA(v,x+2,y+6,x+13,y+10,GRAOS_RGB(128,128,128));drawRectRGBA(v,x+5,y+5,x+10,y+11,black);return;}
    if(kind==6){fillRectRGBA(v,x+1,y+2,x+14,y+13,gray);drawRectRGBA(v,x+1,y+2,x+14,y+13,black);fillRectRGBA(v,x+3,y+4,x+12,y+10,black);fillRectRGBA(v,x+5,y+6,x+6,y+6,white);fillRectRGBA(v,x+6,y+7,x+7,y+7,white);fillRectRGBA(v,x+5,y+8,x+6,y+8,white);return;}
    fillRectRGBA(v,x+3,y+3,x+12,y+12,GRAOS_RGB(192,0,0));drawRectRGBA(v,x+3,y+3,x+12,y+12,black);fillRectRGBA(v,x+7,y+4,x+8,y+9,white);fillRectRGBA(v,x+5,y+8,x+6,y+10,white);fillRectRGBA(v,x+9,y+8,x+10,y+10,white);
}

static void draw_vertical_brand(VMODE*v,int x,int y,int h)
{
    const char *brand="JTMOS98";int i,by=y+h-13;
    fillRectRGBA(v,x,y,x+START_MENU_BRAND-1,y+h-1,GRAOS_RGB(0,0,128));
    for(i=0;brand[i];i++,by-=10){char c[2];c[0]=brand[i];c[1]=0;DrawText(v,c,x+9,by,15,-1);}
}

static int collect_task_windows(WINDOW **out,int cap)
{
    int i,n=0,j,low;WINDOW *w;
    if(!out||cap<=0)return 0;for(i=0;i<cap;i++)out[i]=NULL;
    for(i=0;i<wdb.n_windows;i++){
        w=&wdb.w[i];if(w->isfree||GRAOS_IS_TASKBAR_WINDOW(w->type))continue;
        if(n<cap)out[n++]=w;else{low=0;for(j=1;j<cap;j++)if(out[j]->z<out[low]->z)low=j;if(w->z>out[low]->z)out[low]=w;}
    }
    for(i=0;i<n;i++)for(j=i+1;j<n;j++)if(out[j]->z<out[i]->z){w=out[i];out[i]=out[j];out[j]=w;}
    return n;
}
static int task_slot_width(void){return (TASKBAR_X2-TASKBAR_X1+1-(TASKBAR_SLOTS-1)*TASKBAR_GAP)/TASKBAR_SLOTS;}
static WINDOW *taskbar_hit(int x,int y)
{
    WINDOW *list[TASKBAR_SLOTS];int n,i,sw=task_slot_width(),sx=TASKBAR_X1,py=panel_y();
    if(y<py+3||y>GRAOS_HEIGHT-4)return NULL;n=collect_task_windows(list,TASKBAR_SLOTS);
    for(i=0;i<n;i++,sx+=sw+TASKBAR_GAP)if(x>=sx&&x<sx+sw)return list[i];return NULL;
}
static void draw_taskbar_windows(VMODE*v)
{
    WINDOW *list[TASKBAR_SLOTS];int n,i,sw=task_slot_width(),sx=TASKBAR_X1,py=panel_y(),maxchars,j;char txt[32];
    n=collect_task_windows(list,TASKBAR_SLOTS);
    for(i=0;i<n;i++,sx+=sw+TASKBAR_GAP){WINDOW*w=list[i];int down=(w==v->selwin&&!w->minimized);fillRectRGBA(v,sx,py+4,sx+sw-1,GRAOS_HEIGHT-4,GRAOS_RGB(192,192,192));bevel(v,sx,py+4,sx+sw-1,GRAOS_HEIGHT-4,down);maxchars=(sw-12)/8;if(maxchars>30)maxchars=30;j=0;if(w->minimized&&j<maxchars)txt[j++]='[';while(j<maxchars&&w->caption[j-(w->minimized?1:0)]){txt[j]=w->caption[j-(w->minimized?1:0)];j++;}if(w->minimized&&j<maxchars)txt[j++]=']';txt[j]=0;DrawText(v,txt,sx+6+(down?1:0),py+11+(down?1:0),0,-1);}
}
static void draw_panel(VMODE*v)
{
    int y=panel_y(),down=v->start_menu_open?1:0;
    fillRectRGBA(v,0,y,GRAOS_WIDTH-1,GRAOS_HEIGHT-1,GRAOS_RGB(192,192,192));
    fillRectRGBA(v,0,y,GRAOS_WIDTH-1,y,GRAOS_RGB(255,255,255));
    fillRectRGBA(v,0,y+1,GRAOS_WIDTH-1,y+1,GRAOS_RGB(223,223,223));
    fillRectRGBA(v,START_X1,y+4,START_X2,GRAOS_HEIGHT-4,GRAOS_RGB(192,192,192));bevel(v,START_X1,y+4,START_X2,GRAOS_HEIGHT-4,down);
    menu_icon(v,1,START_X1+5+(down?1:0),y+8+(down?1:0));DrawText(v,"Start",START_X1+25+(down?1:0),y+11+(down?1:0),0,-1);
    draw_taskbar_windows(v);
    fillRectRGBA(v,TRAY_X1,y+4,GRAOS_WIDTH-4,GRAOS_HEIGHT-4,GRAOS_RGB(192,192,192));bevel(v,TRAY_X1,y+4,GRAOS_WIDTH-4,GRAOS_HEIGHT-4,1);
    DrawText(v,"GraOS V37",TRAY_X1+27,y+11,0,-1);
}

static void draw_start_menu(VMODE*v)
{
    int x=START_MENU_X,y=start_menu_y(),i,iy,item_x,fill,fg;
    if(!v->start_menu_open)return;
    fillRectRGBA(v,x,y,x+START_MENU_W-1,y+START_MENU_H-1,GRAOS_RGB(192,192,192));bevel(v,x,y,x+START_MENU_W-1,y+START_MENU_H-1,0);
    draw_vertical_brand(v,x+3,y+3,START_MENU_H-6);
    item_x=x+START_MENU_BRAND+START_MENU_PAD;iy=y+START_MENU_PAD;
    for(i=0;i<START_MENU_ITEMS;i++,iy+=START_ITEM_H){
        fill=(v->start_menu_pressed_item==i);fg=fill?15:0;
        fillRectRGBA(v,item_x,iy,x+START_MENU_W-START_MENU_PAD-1,iy+START_ITEM_H-1,fill?GRAOS_RGB(0,0,128):GRAOS_RGB(192,192,192));
        menu_icon(v,start_item_icon[i],item_x+7,iy+8);DrawText(v,start_item_text[i],item_x+31,iy+12,fg,-1);
        if(i==0||i==4){int ax=x+START_MENU_W-13,ay=iy+START_ITEM_H/2;GRAOS_PIXEL ac=fill?GRAOS_RGB(255,255,255):GRAOS_RGB(0,0,0);fillRectRGBA(v,ax,ay-3,ax,ay+3,ac);fillRectRGBA(v,ax+1,ay-2,ax+1,ay+2,ac);fillRectRGBA(v,ax+2,ay-1,ax+2,ay+1,ac);fillRectRGBA(v,ax+3,ay,ax+3,ay,ac);}
        if(i==4||i==5){fillRectRGBA(v,item_x+4,iy+START_ITEM_H-1,x+START_MENU_W-8,iy+START_ITEM_H-1,GRAOS_RGB(128,128,128));}
    }
}

int guiDesktopInput(VMODE*v)
{
    int down,was,item,py;WINDOW*tw;
    if(!v)return 0;down=(v->buttons&1)!=0;was=(v->last_buttons&1)!=0;py=panel_y();
    if(down&&!was){
        if(in_rect(v->x,v->y,START_X1,py+3,START_X2,GRAOS_HEIGHT-2)){v->start_menu_open=!v->start_menu_open;v->start_button_pressed=1;v->start_menu_pressed_item=-1;v->dirty=1;return 1;}
        tw=taskbar_hit(v->x,v->y);if(tw){if(tw==v->selwin&&!tw->minimized)guiMinimizeWindow(v,tw);else guiRestoreWindow(v,tw);return 1;}
        if(v->start_menu_open){item=menu_item_at(v->x,v->y);if(item>=0)v->start_menu_pressed_item=item;else{v->start_menu_open=0;v->start_menu_pressed_item=-1;}v->dirty=1;return 1;}
    }
    if(!down&&was){
        if(v->start_button_pressed){v->start_button_pressed=0;v->dirty=1;return 1;}
        if(v->start_menu_pressed_item>=0){int pressed=v->start_menu_pressed_item;item=menu_item_at(v->x,v->y);v->start_menu_pressed_item=-1;v->start_menu_open=0;v->dirty=1;if(item==pressed)guiStartMenuAction(v,start_item_action[pressed]);return 1;}
    }
    if(v->start_menu_open&&in_rect(v->x,v->y,START_MENU_X,start_menu_y(),START_MENU_X+START_MENU_W-1,py-1))return 1;
    return 0;
}

int guiDesktopHandleKey(VMODE*v,int key)
{
    int i;
    if(!v || !v->start_menu_open) return 0;
    if(key==JKEY_ESC) {
        v->start_menu_open=0; v->start_menu_pressed_item=-1; v->dirty=1;
        return 1;
    }
    if(key=='\t' || key==JKEY_CURSOR_DOWN) {
        i=v->start_menu_pressed_item;
        v->start_menu_pressed_item=(i<0)?0:((i+1)%START_MENU_ITEMS);
        v->dirty=1; return 1;
    }
    if(key==JKEY_SHIFT_TAB || key==JKEY_CURSOR_UP) {
        i=v->start_menu_pressed_item;
        v->start_menu_pressed_item=(i<0)?(START_MENU_ITEMS-1):((i+START_MENU_ITEMS-1)%START_MENU_ITEMS);
        v->dirty=1; return 1;
    }
    if(key=='\r' || key=='\n' || key==' ') {
        i=v->start_menu_pressed_item;
        if(i<0) i=0;
        v->start_menu_open=0; v->start_menu_pressed_item=-1; v->dirty=1;
        if(i>=0 && i<START_MENU_ITEMS) guiStartMenuAction(v,start_item_action[i]);
        return 1;
    }
    return 0;
}

void guiDesktopDraw(VMODE*v)
{
    int x,y,desktop_bottom;if(!v)return;desktop_bottom=GRAOS_HEIGHT-GRAOS_PANEL_HEIGHT;
    if(v->desktop_solid){fillRect(v,0,0,v->width-1,desktop_bottom-1,v->desktop_color);fillRectRGBA(v,0,desktop_bottom,v->width-1,v->height-1,GRAOS_RGB(192,192,192));}
    else if(v->background)memcpy(v->buf,v->background,GRAOS_FRAME_BYTES);
    else{for(y=0;y<desktop_bottom;y++){int g=96+(y*44)/desktop_bottom,b=112+(y*72)/desktop_bottom;GRAOS_PIXEL c=GRAOS_RGB(0,g,b);GRAOS_PIXEL*row=v->buf+y*v->width;for(x=0;x<v->width;x++)row[x]=c;}fillRectRGBA(v,0,desktop_bottom,v->width-1,v->height-1,GRAOS_RGB(192,192,192));}
    draw_panel(v);
}
void guiDesktopDrawPopup(VMODE*v){draw_start_menu(v);}
