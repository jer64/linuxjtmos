#ifndef __INCLUDED_GUIWIDGET_H__
#define __INCLUDED_GUIWIDGET_H__
#include "graosprotocol.h"
void guiWidgetInit(GRAOS_WIDGET *w,int type,int id,int x,int y,int width,int height,int owner,unsigned int flags);
int guiWidgetContains(const GRAOS_WIDGET *w,int x,int y);
void guiWidgetSetBounds(GRAOS_WIDGET *w,int x,int y,int width,int height);
void guiWidgetSetVisible(GRAOS_WIDGET *w,int visible);
void guiWidgetSetEnabled(GRAOS_WIDGET *w,int enabled);
#endif
