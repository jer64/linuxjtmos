/* guiTextBox.c - native GraOS editable TextBox widget, V67.8 / GraOS V32. */
#include "guiTextBox.h"
#include "guiWidget.h"
#include "guiRect.h"
#include "guifont.h"
#include "windowFunc.h"
#include <string.h>

static void copy_text_limit(char *dst,int cap,const char *src,int maxlen)
{
    int i=0,limit;
    if(!dst || cap<=0) return;
    limit=cap-1;
    if(maxlen>=0 && maxlen<limit) limit=maxlen;
    if(src) while(i<limit && src[i]) { dst[i]=src[i]; i++; }
    dst[i]=0;
}

TEXTBOX *guiGetTextBox(WINDOW *w,int id)
{
    int i;
    if(!w) return NULL;
    for(i=0;i<w->n_textboxes;i++)
        if(w->textbox[i].widget.id==id) return &w->textbox[i];
    return NULL;
}

TEXTBOX *guiCreateTextBox(WINDOW *w,int x,int y,int width,int height,int id,int maxlen,const char *text)
{
    TEXTBOX *t;
    if(!w || w->n_textboxes>=GRAOS_MAX_TEXTBOXES || width<16 || height<12) return NULL;
    if(guiGetTextBox(w,id)) return NULL;
    if(maxlen<=0 || maxlen>=GRAOS_TEXTBOX_TEXT_MAX) maxlen=GRAOS_TEXTBOX_TEXT_MAX-1;
    t=&w->textbox[w->n_textboxes++];
    memset(t,0,sizeof(*t));
    guiWidgetInit(&t->widget,GRAOS_WIDGET_TEXTBOX,id,x,y,width,height,w->id,
                  GRAOS_WIDGET_VISIBLE|GRAOS_WIDGET_ENABLED|GRAOS_WIDGET_FOCUSABLE);
    t->fg=0; t->bg=15; t->maxlen=maxlen;
    copy_text_limit(t->text,sizeof(t->text),text,maxlen);
    t->caret=(int)strlen(t->text);
    return t;
}

TEXTBOX *guiGetTextBoxAt(WINDOW *w,int local_x,int local_y)
{
    int i;
    if(!w) return NULL;
    for(i=w->n_textboxes-1;i>=0;i--)
        if(guiWidgetContains(&w->textbox[i].widget,local_x,local_y)) return &w->textbox[i];
    return NULL;
}

int guiSetTextBoxText(WINDOW *w,int id,const char *text)
{
    TEXTBOX *t=guiGetTextBox(w,id);
    if(!t) return 0;
    copy_text_limit(t->text,sizeof(t->text),text,t->maxlen);
    t->caret=(int)strlen(t->text);
    if(t->view_start>t->caret) t->view_start=t->caret;
    t->widget.flags|=GRAOS_WIDGET_DIRTY;
    return 1;
}

int guiGetTextBoxText(WINDOW *w,int id,char *out,int cap)
{
    TEXTBOX *t=guiGetTextBox(w,id);
    if(!t || !out || cap<=0) return 0;
    copy_text_limit(out,cap,t->text,-1);
    return 1;
}

int guiRemoveTextBox(WINDOW *w,int id)
{
    int i,j;
    if(!w) return 0;
    for(i=0;i<w->n_textboxes;i++) if(w->textbox[i].widget.id==id) {
        if(w->focused_widget_type==GRAOS_WIDGET_TEXTBOX && w->focused_widget_id==id) {
            w->focused_widget_type=GRAOS_WIDGET_NONE; w->focused_widget_id=0;
        }
        for(j=i;j<w->n_textboxes-1;j++) w->textbox[j]=w->textbox[j+1];
        w->n_textboxes--;
        return 1;
    }
    return 0;
}

void guiBlurTextBox(VMODE *v,WINDOW *w)
{
    TEXTBOX *old;
    if(!w || w->focused_widget_type!=GRAOS_WIDGET_TEXTBOX) return;
    old=guiGetTextBox(w,w->focused_widget_id);
    if(old) { old->focused=0; old->widget.flags|=GRAOS_WIDGET_DIRTY; guiQueueWindowEvent(w,GRAOS_GSID_TEXTBOX_BLUR,old->widget.id,0,0); }
    w->focused_widget_type=GRAOS_WIDGET_NONE; w->focused_widget_id=0;
    if(v) v->dirty=1;
}

void guiFocusTextBox(VMODE *v,WINDOW *w,TEXTBOX *t)
{
    if(!w || !t || !t->widget.enabled || !t->widget.visible) return;
    if(w->focused_widget_type==GRAOS_WIDGET_TEXTBOX && w->focused_widget_id==t->widget.id) return;
    guiBlurTextBox(v,w);
    t->focused=1;
    t->caret=(int)strlen(t->text);
    w->focused_widget_type=GRAOS_WIDGET_TEXTBOX;
    w->focused_widget_id=t->widget.id;
    t->widget.flags|=GRAOS_WIDGET_DIRTY;
    guiQueueWindowEvent(w,GRAOS_GSID_TEXTBOX_FOCUS,t->widget.id,0,0);
    if(v) v->dirty=1;
}

static void update_view(TEXTBOX *t)
{
    int chars;
    if(!t) return;
    chars=(t->widget.width-8)/8;
    if(chars<1) chars=1;
    if(t->caret<t->view_start) t->view_start=t->caret;
    if(t->caret>=t->view_start+chars) t->view_start=t->caret-chars+1;
    if(t->view_start<0) t->view_start=0;
}

int guiTextBoxHandleKey(VMODE *v,WINDOW *w,int key)
{
    TEXTBOX *t; int len,i;
    if(!w || w->focused_widget_type!=GRAOS_WIDGET_TEXTBOX) return 0;
    t=guiGetTextBox(w,w->focused_widget_id);
    if(!t || !t->focused || !t->widget.enabled) return 0;
    len=(int)strlen(t->text);
    if(key=='\r' || key=='\n') {
        guiQueueWindowEvent(w,GRAOS_GSID_TEXTBOX_ENTER,t->widget.id,len,0);
        if(v) v->dirty=1;
        return 1;
    }
    if(key==8 || key==127) {
        if(t->caret>0 && len>0) {
            for(i=t->caret-1;i<len;i++) t->text[i]=t->text[i+1];
            t->caret--;
            guiQueueWindowEvent(w,GRAOS_GSID_TEXTBOX_CHANGED,t->widget.id,t->caret,0);
        }
        update_view(t); t->widget.flags|=GRAOS_WIDGET_DIRTY; if(v) v->dirty=1; return 1;
    }
    if(key==27) { guiBlurTextBox(v,w); return 1; }
    if(key>=32 && key<=126) {
        if(len<t->maxlen && len<GRAOS_TEXTBOX_TEXT_MAX-1) {
            for(i=len;i>=t->caret;i--) t->text[i+1]=t->text[i];
            t->text[t->caret]=(char)key; t->caret++;
            guiQueueWindowEvent(w,GRAOS_GSID_TEXTBOX_CHANGED,t->widget.id,t->caret,0);
        }
        update_view(t); t->widget.flags|=GRAOS_WIDGET_DIRTY; if(v) v->dirty=1; return 1;
    }
    return 1;
}

void guiDrawTextBox(VMODE *v,WINDOW *w,TEXTBOX *t)
{
    GRAOS_WIDGET *g; int x1,y1,x2,y2,chars,len,n,i,caret_px; char visible[64];
    if(!v || !w || !t) return;
    g=&t->widget;
    if(!g->visible || g->width<=0 || g->height<=0) return;
    x1=w->x+g->x; y1=w->y+g->y; x2=x1+g->width-1; y2=y1+g->height-1;
    fillRect(v,x1,y1,x2,y2,t->bg);
    drawRect(v,x1,y1,x2,y2,t->focused?1:0);
    if(g->width>2 && g->height>2) { fillRect(v,x1+1,y1+1,x2-1,y1+1,8); fillRect(v,x1+1,y1+1,x1+1,y2-1,8); }
    chars=(g->width-8)/8; if(chars<1) chars=1; if(chars>(int)sizeof(visible)-1) chars=(int)sizeof(visible)-1;
    len=(int)strlen(t->text); n=0;
    for(i=t->view_start;i<len && n<chars;i++) visible[n++]=t->text[i];
    visible[n]=0;
    DrawText(v,visible,x1+4,y1+(g->height-8)/2,t->fg,-1);
    if(t->focused) {
        caret_px=(t->caret-t->view_start)*8;
        if(caret_px<0) caret_px=0;
        if(caret_px>g->width-8) caret_px=g->width-8;
        fillRect(v,x1+4+caret_px,y1+3,x1+4+caret_px,y2-3,t->fg);
    }
    g->flags&=~GRAOS_WIDGET_DIRTY;
}
