/* guiFocus.c - keyboard focus/navigation for native GraOS widgets. */
#include "guiFocus.h"
#include "guiTextBox.h"
#include "windowFunc.h"
#include <jtmos/console.h>

#define GRAOS_MAX_FOCUS_ITEMS (GRAOS_MAX_BUTTONS+GRAOS_MAX_TEXTBOXES)

static int widget_focusable(const GRAOS_WIDGET *g)
{
    return g && g->visible && g->enabled && g->focusable &&
           (g->flags&GRAOS_WIDGET_VISIBLE) &&
           (g->flags&GRAOS_WIDGET_ENABLED) &&
           (g->flags&GRAOS_WIDGET_FOCUSABLE);
}

static int widget_before(const GRAOS_WIDGET *a,const GRAOS_WIDGET *b)
{
    if(a->y!=b->y) return a->y<b->y;
    if(a->x!=b->x) return a->x<b->x;
    if(a->type!=b->type) return a->type<b->type;
    return a->id<b->id;
}

static int collect_focusable(WINDOW *w,GRAOS_WIDGET **out,int cap)
{
    int i,j,n=0;
    GRAOS_WIDGET *g;
    if(!w || !out || cap<=0) return 0;
    for(i=0;i<w->n_buttons && n<cap;i++) {
        g=&w->button[i].widget;
        if(widget_focusable(g)) out[n++]=g;
    }
    for(i=0;i<w->n_textboxes && n<cap;i++) {
        g=&w->textbox[i].widget;
        if(widget_focusable(g)) out[n++]=g;
    }
    /* Old GraOS applications have no tab-index metadata.  A stable spatial
     * order is deterministic and matches what a user sees on screen. */
    for(i=1;i<n;i++) {
        GRAOS_WIDGET *cur=out[i];
        j=i-1;
        while(j>=0 && widget_before(cur,out[j])) { out[j+1]=out[j]; j--; }
        out[j+1]=cur;
    }
    return n;
}

static BUTTON *button_by_id(WINDOW *w,int id)
{
    int i;
    if(!w) return NULL;
    for(i=0;i<w->n_buttons;i++)
        if(w->button[i].widget.id==id) return &w->button[i];
    return NULL;
}

void guiClearWidgetFocus(VMODE *v,WINDOW *w)
{
    if(!w) return;
    if(w->focused_widget_type==GRAOS_WIDGET_TEXTBOX) {
        guiBlurTextBox(v,w);
        return;
    }
    if(w->focused_widget_type!=GRAOS_WIDGET_NONE) {
        w->focused_widget_type=GRAOS_WIDGET_NONE;
        w->focused_widget_id=0;
        if(v) v->dirty=1;
    }
}

static int focus_widget(VMODE *v,WINDOW *w,GRAOS_WIDGET *g)
{
    TEXTBOX *t;
    if(!w || !widget_focusable(g)) return 0;
    if(g->type==GRAOS_WIDGET_TEXTBOX) {
        t=guiGetTextBox(w,g->id);
        if(!t) return 0;
        guiFocusTextBox(v,w,t);
        return 1;
    }
    if(g->type==GRAOS_WIDGET_BUTTON) {
        if(w->focused_widget_type==GRAOS_WIDGET_TEXTBOX)
            guiBlurTextBox(v,w);
        w->focused_widget_type=GRAOS_WIDGET_BUTTON;
        w->focused_widget_id=g->id;
        g->flags|=GRAOS_WIDGET_DIRTY;
        if(v) v->dirty=1;
        return 1;
    }
    return 0;
}

int guiFocusButton(VMODE *v,WINDOW *w,BUTTON *b)
{
    if(!b) return 0;
    return focus_widget(v,w,&b->widget);
}

int guiMoveFocus(VMODE *v,WINDOW *w,int direction)
{
    GRAOS_WIDGET *items[GRAOS_MAX_FOCUS_ITEMS];
    int n,i,cur=-1,next;
    if(!w) return 0;
    n=collect_focusable(w,items,GRAOS_MAX_FOCUS_ITEMS);
    if(n<=0) return 0;
    for(i=0;i<n;i++)
        if(items[i]->type==w->focused_widget_type &&
           items[i]->id==w->focused_widget_id) { cur=i; break; }
    if(direction<0)
        next=(cur<0)?(n-1):((cur+n-1)%n);
    else
        next=(cur<0)?0:((cur+1)%n);
    return focus_widget(v,w,items[next]);
}

int guiEnsureFocus(VMODE *v,WINDOW *w)
{
    GRAOS_WIDGET *items[GRAOS_MAX_FOCUS_ITEMS];
    int n,i;
    if(!v || !w || v->selwin!=w) return 0;
    n=collect_focusable(w,items,GRAOS_MAX_FOCUS_ITEMS);
    if(n<=0) return 0;
    for(i=0;i<n;i++)
        if(items[i]->type==w->focused_widget_type &&
           items[i]->id==w->focused_widget_id) return 1;
    return focus_widget(v,w,items[0]);
}

int guiWidgetIsFocused(const VMODE *v,const WINDOW *w,const GRAOS_WIDGET *g)
{
    if(!v || !w || !g || v->selwin!=w) return 0;
    return w->focused_widget_type==g->type && w->focused_widget_id==g->id;
}

int guiHandleNavigationKey(VMODE *v,WINDOW *w,int key)
{
    BUTTON *b;
    if(!v || !w) return 0;
    if(key=='\t') return guiMoveFocus(v,w,1);
    if(key==JKEY_SHIFT_TAB) return guiMoveFocus(v,w,-1);

    /* Start/popup menu rows support both focus traversal and traditional
     * cursor navigation.  Arrow keys are consumed only for menu buttons. */
    if((key==JKEY_CURSOR_UP || key==JKEY_CURSOR_DOWN) &&
       w->focused_widget_type==GRAOS_WIDGET_BUTTON) {
        b=button_by_id(w,w->focused_widget_id);
        if(b && (b->style&GRAOS_BUTTON_MENU))
            return guiMoveFocus(v,w,key==JKEY_CURSOR_UP?-1:1);
    }

    /* Enter/Space activates a focused button.  TextBox keeps its normal
     * semantics: Space inserts a space and Enter emits TEXTBOX_ENTER. */
    if((key=='\r' || key=='\n' || key==' ') &&
       w->focused_widget_type==GRAOS_WIDGET_BUTTON) {
        b=button_by_id(w,w->focused_widget_id);
        if(!b || !widget_focusable(&b->widget)) return 0;
        b->pressed=1;
        b->widget.flags|=GRAOS_WIDGET_DIRTY;
        v->dirty=1;
        onButtonClick(v,w,b);
        if(!w->isfree) {
            b=button_by_id(w,w->focused_widget_id);
            if(b) b->pressed=0;
        }
        return 1;
    }
    return 0;
}
