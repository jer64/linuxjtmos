#ifndef __INCLUDED_GUIWELCOME_H__
#define __INCLUDED_GUIWELCOME_H__
#include "graos.h"
int guiCreateWelcome(VMODE *v);
void guiDrawWelcomeDecor(VMODE *v,WINDOW *w);
#endif
