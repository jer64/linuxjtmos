#include "guiLoop.h"
#include "guiServer.h"
#include "windowMoving.h"
#include "guiDesktopDraw.h"
#include "windowDraw.h"
#include "guiArrow.h"
#include "guiUpdate.h"
#include "guifont.h"
#include "wdb.h"
#include "guiStart.h"
#include "guiTextBox.h"
#include "guiFocus.h"
#include <jtmos/console.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>

/* Normalize the three historical JTMOS extended-key encodings before any
 * desktop, global-hotkey or widget handler sees the key.  The raw keyboard
 * driver historically emitted 0xFF00|scan, newer public headers use
 * scan<<8, and E0 cursor decoding uses synthetic scan numbers 102..111.
 * Keeping this compatibility at the GraOS input boundary makes navigation
 * deterministic without forcing every widget/application to know all forms. */
static int guiNormalizeKey(int key)
{
    switch(key) {
    /* E0 cursor/navigation synthetic codes produced by scanasc.c. */
    case 0xff67: return JKEY_CURSOR_UP;
    case 0xff6c: return JKEY_CURSOR_DOWN;
    case 0xff69: return JKEY_CURSOR_LEFT;
    case 0xff6a: return JKEY_CURSOR_RIGHT;
    case 0xff66: return JKEY_HOME;
    case 0xff6b: return JKEY_END;
    case 0xff68: return JKEY_PAGE_UP;
    case 0xff6d: return JKEY_PAGE_DOWN;
    case 0xff6e: return JKEY_INSERT;
    case 0xff6f: return JKEY_DELETE;

    /* Historical 0xFF00|set-1 scan values. */
    case 0xff48: return JKEY_CURSOR_UP;
    case 0xff50: return JKEY_CURSOR_DOWN;
    case 0xff4b: return JKEY_CURSOR_LEFT;
    case 0xff4d: return JKEY_CURSOR_RIGHT;
    case 0xff47: return JKEY_HOME;
    case 0xff4f: return JKEY_END;
    case 0xff49: return JKEY_PAGE_UP;
    case 0xff51: return JKEY_PAGE_DOWN;
    case 0xff52: return JKEY_INSERT;
    case 0xff53: return JKEY_DELETE;

    case 0xff3b: return JKEY_F1;
    case 0xff3c: return JKEY_F2;
    case 0xff3d: return JKEY_F3;
    case 0xff3e: return JKEY_F4;
    case 0xff3f: return JKEY_F5;
    case 0xff40: return JKEY_F6;
    case 0xff41: return JKEY_F7;
    case 0xff42: return JKEY_F8;
    case 0xff43: return JKEY_F9;
    case 0xff44: return JKEY_F10;
    case 0xff57: return JKEY_F11;
    case 0xff58: return JKEY_F12;
    default: return key;
    }
}


/* Physical set-1/synthetic scan codes kept by the kernel keyboard driver. */
#define GRAOS_SC_TAB       0x0f
#define GRAOS_SC_LSHIFT    0x2a
#define GRAOS_SC_RSHIFT    0x36
#define GRAOS_SC_LALT      0x38
#define GRAOS_SC_F4        0x3e
#define GRAOS_SC_LWIN      91
#define GRAOS_SC_RWIN      92
#define GRAOS_SC_UP        103
#define GRAOS_SC_LEFT      105
#define GRAOS_SC_RIGHT     106
#define GRAOS_SC_DOWN      108

static int graos_raw_key_down(int sc)
{
    return (int)jtmos_syscall7(SYS_keystate,(uintptr_t)sc,0,0,0,0,0)>0;
}

/*
 * Navigation is sampled directly from the driver's make/break table.
 * This makes window/widget navigation independent of keyboard-layout,
 * translated extended-key encodings and terminal FIFO consumers.
 * Each physical key produces exactly one edge until it is released.
 */
static int guiPollRawNavigationKey(void)
{
    static int old_tab,old_up,old_down,old_left,old_right,old_f4;
    int tab,up,down,left,right,f4,shift,alt,win,key=0;

    shift=graos_raw_key_down(GRAOS_SC_LSHIFT) || graos_raw_key_down(GRAOS_SC_RSHIFT);
    alt=graos_raw_key_down(GRAOS_SC_LALT);
    win=graos_raw_key_down(GRAOS_SC_LWIN) || graos_raw_key_down(GRAOS_SC_RWIN);
    tab=graos_raw_key_down(GRAOS_SC_TAB);
    up=graos_raw_key_down(GRAOS_SC_UP);
    down=graos_raw_key_down(GRAOS_SC_DOWN);
    left=graos_raw_key_down(GRAOS_SC_LEFT);
    right=graos_raw_key_down(GRAOS_SC_RIGHT);
    f4=graos_raw_key_down(GRAOS_SC_F4);

    if(tab && !old_tab) {
        if(alt) key=shift?JKEY_SHIFT_ALT_TAB:JKEY_ALT_TAB;
        else if(win) key=shift?JKEY_SHIFT_WIN_TAB:JKEY_WIN_TAB;
        else key=shift?JKEY_SHIFT_TAB:JKEY_TAB;
    } else if(f4 && !old_f4 && alt) key=JKEY_ALT_F4;
    else if(up && !old_up) key=JKEY_CURSOR_UP;
    else if(down && !old_down) key=JKEY_CURSOR_DOWN;
    else if(left && !old_left) key=JKEY_CURSOR_LEFT;
    else if(right && !old_right) key=JKEY_CURSOR_RIGHT;

    old_tab=tab; old_up=up; old_down=down; old_left=left;
    old_right=right; old_f4=f4;
    return key;
}

static int guiIsRawNavigationKey(int key)
{
    return key==JKEY_TAB || key==JKEY_SHIFT_TAB ||
           key==JKEY_ALT_TAB || key==JKEY_SHIFT_ALT_TAB ||
           key==JKEY_WIN_TAB || key==JKEY_SHIFT_WIN_TAB ||
           key==JKEY_ALT_F4 || key==JKEY_CURSOR_UP ||
           key==JKEY_CURSOR_DOWN || key==JKEY_CURSOR_LEFT ||
           key==JKEY_CURSOR_RIGHT;
}

static void send_window_key(WINDOW *w,int key)
{
    if(!w || key<=0) return;

    /* A native terminal window is wired directly to term.c's keyboard FIFO.
     * This is the same input queue used by SMSH on a physical EGA console. */
    if(w->fb_type==GRAOS_SURFACE_TERMINAL && w->terminal_id>=0) {
        /* JTMOS terminal input is LF-oriented.  Accept DOS/BIOS-style CR
         * from GUI clients too, so Enter behaves identically to SMSH. */
        if(key=='\r') key='\n';
        OutputTerminalKeyboardBuffer(w->terminal_id,key);
        return;
    }

    if(w->pid<=0) return;
    /* Keep keyboard and mouse input on the server-owned per-window event
     * queue.  This avoids races with synchronous client request/response IPC
     * and makes JtmosGraOSPollEvent() the single delivery path. */
    guiQueueWindowEvent(w,GRAOS_GSID_KEYPRESSED,key,0,0);
}

static int has_terminal_window(void)
{
    int i;
    for(i=0;i<wdb.n_windows;i++)
        if(!wdb.w[i].isfree && !wdb.w[i].minimized && wdb.w[i].root.visible &&
           wdb.w[i].fb_type==GRAOS_SURFACE_TERMINAL && wdb.w[i].terminal_id>=0)
            return 1;
    return 0;
}

static int queue_taskbar_event(int event_id)
{
    int i;
    for(i=0;i<wdb.n_windows;i++) {
        WINDOW *w=&wdb.w[i];
        if(!w->isfree && GRAOS_IS_TASKBAR_WINDOW(w->type) && w->pid>0) {
            guiQueueWindowEvent(w,event_id,w->id,0,0);
            return 1;
        }
    }
    return 0;
}

static void close_shell_menus(VMODE *v)
{
    if(v) {
        v->start_menu_open=0;
        v->start_menu_pressed_item=-1;
        v->start_button_pressed=0;
        v->dirty=1;
    }
    queue_taskbar_event(GRAOS_GSID_CLOSEMENUS);
}

static int open_start_menu(VMODE *v)
{
    /* taskbar.bin owns the popup when it is running. */
    if(queue_taskbar_event(GRAOS_GSID_STARTMENU)) return 1;
    /* Native GraOS has an integrated taskbar too; retain a useful fallback
     * when external taskbar.bin is not running. */
    v->start_menu_open=!v->start_menu_open;
    v->start_menu_pressed_item=-1;
    v->start_button_pressed=0;
    v->dirty=1;
    return 1;
}

static int guiMinimizeAll(VMODE *v)
{
    int i;
    if(!v) return 0;
    for(i=0;i<wdb.n_windows;i++) {
        WINDOW *w=&wdb.w[i];
        if(w->isfree || GRAOS_IS_TASKBAR_WINDOW(w->type) ||
           GRAOS_IS_POPUP_WINDOW(w->type) || w->minimized) continue;
        guiMinimizeWindow(v,w);
    }
    return 1;
}

static int guiRestoreAll(VMODE *v)
{
    int i; WINDOW *last=NULL;
    if(!v) return 0;
    for(i=0;i<wdb.n_windows;i++) {
        WINDOW *w=&wdb.w[i];
        if(w->isfree || GRAOS_IS_TASKBAR_WINDOW(w->type) ||
           GRAOS_IS_POPUP_WINDOW(w->type) || !w->minimized) continue;
        w->minimized=0;
        guiWidgetSetVisible(&w->root,1);
        guiQueueWindowEvent(w,GRAOS_GSID_WINDOW_RESTORED,w->id,0,0);
        last=w;
    }
    if(last) SelectWindow(v,last);
    v->dirty=1;
    return 1;
}

static int guiToggleDesktop(VMODE *v)
{
    int i,visible=0;
    if(!v) return 0;
    for(i=0;i<wdb.n_windows;i++) {
        WINDOW *w=&wdb.w[i];
        if(!w->isfree && !GRAOS_IS_TASKBAR_WINDOW(w->type) &&
           !GRAOS_IS_POPUP_WINDOW(w->type) && !w->minimized) { visible=1; break; }
    }
    return visible ? guiMinimizeAll(v) : guiRestoreAll(v);
}

static int open_power_menu(VMODE *v)
{
    if(queue_taskbar_event(GRAOS_GSID_POWERMENU)) return 1;
    return guiStartTerminalProgram(v,"/bin/top.bin","JTMOS Task Manager");
}

static int guiHandleGlobalKey(VMODE *v,int key)
{
    if(!v) return 0;
    if(key==JKEY_ALT_TAB || key==JKEY_WIN_TAB) {
        close_shell_menus(v);
        return guiSwitchTask(v,1);
    }
    if(key==JKEY_SHIFT_ALT_TAB || key==JKEY_SHIFT_WIN_TAB) {
        close_shell_menus(v);
        return guiSwitchTask(v,-1);
    }
    if(key==JKEY_ALT_F4) {
        close_shell_menus(v);
        if(v->selwin && !v->selwin->isfree &&
           !GRAOS_IS_TASKBAR_WINDOW(v->selwin->type) &&
           !GRAOS_IS_POPUP_WINDOW(v->selwin->type))
            guiCloseWindow(v,v->selwin);
        return 1;
    }
    if(key==JKEY_START_MENU) return open_start_menu(v);
    if(key==JKEY_CTRL_SHIFT_N) {
        close_shell_menus(v);
        return guiStartTerminalProgram(v,"/bin/sqsh.bin",
                                       "JTMOS Command Prompt - Squirrel Shell");
    }
    if(key==JKEY_WIN_R) { close_shell_menus(v); return guiStartCommandPrompt(v); }
    if(key==JKEY_WIN_E) { close_shell_menus(v); return guiLaunchBackgroundApp(v,"/bin/filer.bin"); }
    if(key==JKEY_WIN_M) { close_shell_menus(v); return guiMinimizeAll(v); }
    if(key==JKEY_SHIFT_WIN_M) { close_shell_menus(v); return guiRestoreAll(v); }
    if(key==JKEY_WIN_D) { close_shell_menus(v); return guiToggleDesktop(v); }
    if(key==JKEY_WIN_X) { close_shell_menus(v); return open_power_menu(v); }
    return 0;
}

static void guiDispatchKey(VMODE *v,int key)
{
    if(!v || key<=0) return;
    key=guiNormalizeKey(key);
    if(!guiDesktopHandleKey(v,key) && !guiHandleGlobalKey(v,key) && v->selwin) {
        if(!guiHandleNavigationKey(v,v->selwin,key) &&
           !guiTextBoxHandleKey(v,v->selwin,key))
            send_window_key(v->selwin,key);
    }
}

int guiLoop(VMODE *v)
{
    char stat[96];

    while(v && v->running) {
        int key;

        guiServerPoll(v);
        guiReapExitedTerminalPrograms(v);
        if(v->selwin) guiEnsureFocus(v,v->selwin);

        v->lx=v->x;
        v->ly=v->y;
        v->last_buttons=v->buttons;
        v->x=GetMouseX();
        v->y=GetMouseY();
        v->buttons=GetMouseButtons();

        if(v->x<0) v->x=0;
        if(v->y<0) v->y=0;
        if(v->x>=v->width) v->x=v->width-1;
        if(v->y>=v->height) v->y=v->height-1;
        if(v->x!=v->lx || v->y!=v->ly || v->buttons!=v->last_buttons)
            v->dirty=1;

        if(!guiDesktopInput(v))
            windowInput(v);

        /* Desktop navigation uses raw make/break state and therefore cannot
         * disappear in a translated key-code/FIFO conversion. */
        {
            int rawkey=guiPollRawNavigationKey();
            if(rawkey>0) guiDispatchKey(v,rawkey);

            /* Keep SYS_GETCH for printable text, Start/Win shortcut events and
             * compatibility.  Navigation key events are discarded here because
             * the raw edge above is now their single authoritative source. */
            key=getch1();
            if(key>0) {
                key=guiNormalizeKey(key);
                if(!guiIsRawNavigationKey(key))
                    guiDispatchKey(v,key);
            }
        }

        /* The shell writes to kernel term.c without going through the GraOS
         * IPC server, so repaint terminal windows at a modest 20 Hz. */
        {
            unsigned long now=GetTickCount();
            /* Keep terminal contents and the mouse diagnostics alive even
             * when there is no window damage.  A 20 Hz present rate is light
             * enough for the 1024x768x32 RGBA framebuffer and makes a stalled event
             * loop immediately visible in the on-screen counters. */
            if((unsigned long)(now-v->terminal_poll_tick)>=50UL) {
                v->terminal_poll_tick=now;
                if(has_terminal_window() || GetMousePacketCount()!=v->last_mouse_packet_count)
                    v->dirty=1;
                v->last_mouse_packet_count=GetMousePacketCount();
            }
        }

        if(v->dirty) {
            guiDesktopDraw(v);
            drawAllWindows(v);
            guiDesktopDrawPopup(v);
            snprintf(stat,sizeof(stat),"%d,%d b=%x irq=%lu by=%lu pk=%lu s=%d",
                    v->x,v->y,v->buttons,GetMouseIRQCount(),
                    GetMouseByteCount(),GetMousePacketCount(),GetMouseStreamStatus());
            DrawText(v,stat,GRAOS_WIDTH-300,GRAOS_HEIGHT-14,0,7);
            guiDrawCursor(v);
            if(!guiUpdate(v)) {
                printf("GraOS: VESA draw_frame failed.\n");
                return 0;
            }
            v->frame_counter++;
        }

        /* One cooperative yield is enough when idle because rendering is
         * dirty-driven.  IPC is drained in small bursts by guiServerPoll(). */
        SwitchToThread();
    }
    return 1;
}
