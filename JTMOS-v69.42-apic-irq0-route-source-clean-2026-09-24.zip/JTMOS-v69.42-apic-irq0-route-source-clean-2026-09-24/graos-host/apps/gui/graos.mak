# JTMOS V67.2 GraOS V26 ring3 window server, static ELF32 application.
APPNAME=graos
LIBCDIR=../../libc
APP_OBJS=graos.o guiStart.o guiLoop.o guiUpdate.o guidot.o guiRect.o guiBlit.o \
	guifont.o guifont_data.o egafont_data.o guiArrow.o guiResource.o guiBmp.o guiDesktopDraw.o guiChrome.o guiWelcome.o guiStartup.o wdb.o windowDraw.o \
	windowFunc.o guiWidget.o guiFocus.o guiLabel.o guiBitmap.o guiTextBox.o windowMoving.o windowOrder.o guiServer.o
include ../app-common.mk
