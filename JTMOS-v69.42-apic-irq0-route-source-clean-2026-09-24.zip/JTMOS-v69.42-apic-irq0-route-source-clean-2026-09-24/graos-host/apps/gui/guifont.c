#include "guifont.h"

static const char lower[]="abcdefghijklmnopqrstuvwxyz0123456789_ ()-+.,%/#':;$[]<>=@*\\_^!?|~";
static const char upper[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_ ()-+.,%/#':;$[]<>=@*\\_^!?|~";

static int glyph_index(char ch)
{
    int i;
    for(i=0;lower[i] && upper[i];i++)
        if(ch==lower[i] || ch==upper[i]) return i;
    return -1;
}

void DrawText(VMODE *v,const char *s,int x,int y,int fg,int bg)
{
    int i,g,xx,yy,sx,sy;
    BYTE p;

    if(!v || !s) return;

    for(i=0;s[i];i++)
    {
        if(s[i]=='\n')
        {
            y+=9;
            x=0;
            continue;
        }

        g=glyph_index(s[i]);
        if(g<0)
        {
            x+=8;
            continue;
        }

        sx=(g%64)*8;
        sy=(g/64)*8;
        for(yy=0;yy<8;yy++)
        {
            for(xx=0;xx<8;xx++)
            {
                p=graos_guifont_raw[(sy+yy)*512+sx+xx];
                if(p)
                {
                    if(x+xx>=0 && x+xx<v->width && y+yy>=0 && y+yy<v->height)
                        v->buf[(y+yy)*v->width+x+xx]=graosIndexToPixel(fg);
                }
                else if(bg>=0 && x+xx>=0 && x+xx<v->width && y+yy>=0 && y+yy<v->height)
                {
                    v->buf[(y+yy)*v->width+x+xx]=graosIndexToPixel(bg);
                }
            }
        }
        x+=8;
    }
    v->dirty=1;
}
