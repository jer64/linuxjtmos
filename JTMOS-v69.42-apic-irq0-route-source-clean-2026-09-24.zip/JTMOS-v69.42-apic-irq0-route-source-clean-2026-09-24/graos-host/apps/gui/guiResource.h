#ifndef __INCLUDED_GUIRESOURCE_H__
#define __INCLUDED_GUIRESOURCE_H__
#include "graos.h"
FILE *guiOpenResource(const char *name,const char *mode);
#endif
