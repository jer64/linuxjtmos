#ifndef __INCLUDED_GRAOSPROTOCOL_H__
#define __INCLUDED_GRAOSPROTOCOL_H__
/* External GraOS server and clients share one canonical public protocol.
 * Keep this historical local include name as a thin source-compat wrapper. */
#include <jtmos/graosprotocol.h>
#endif
