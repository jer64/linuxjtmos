#include "guiResource.h"

static FILE *try_path(const char *prefix,const char *name,const char *mode)
{
    char path[256];
    size_t a,b;
    FILE *f;

    if(!name || !*name || !mode)
        return NULL;

    if(!prefix || !*prefix)
        return fopen(name,mode);

    a=strlen(prefix);
    b=strlen(name);
    if(a+b+1>=sizeof(path))
        return NULL;

    memcpy(path,prefix,a);
    memcpy(path+a,name,b+1);
    f=fopen(path,mode);
    return f;
}

FILE *guiOpenResource(const char *name,const char *mode)
{
    FILE *f;

    /* The utilities installer extracts GraOS runtime assets into the same
     * directory as graos.bin.  Keep current-directory lookup first, then
     * common JTMOS mounted roots for manually installed copies. */
    f=try_path("",name,mode);
    if(f) return f;
    f=try_path("ram:/",name,mode);
    if(f) return f;
    f=try_path("hda:/",name,mode);
    if(f) return f;
    f=try_path("sys:/",name,mode);
    return f;
}
