#ifndef __INCLUDED_GUILOOP_H__
#define __INCLUDED_GUILOOP_H__
#include "graos.h"
int guiLoop(VMODE *v);
#endif
