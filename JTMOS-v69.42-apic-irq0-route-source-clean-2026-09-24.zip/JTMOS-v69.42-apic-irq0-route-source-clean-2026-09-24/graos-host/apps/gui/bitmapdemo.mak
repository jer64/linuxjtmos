APPNAME=bitmapdemo
LIBCDIR=../../../libc/libc
include ../../../libc/apps/app-common.mk
