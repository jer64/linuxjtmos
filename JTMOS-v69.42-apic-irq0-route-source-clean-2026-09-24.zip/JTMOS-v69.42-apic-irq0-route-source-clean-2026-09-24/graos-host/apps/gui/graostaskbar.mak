APPNAME=graostaskbar
APP_OBJS=taskbar.o
LIBCDIR=../../../libc/libc
include ../../../libc/apps/app-common.mk
