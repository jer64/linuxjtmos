#include "guiArrow.h"
#include "guiBlit.h"
#include "guiResource.h"
static void guiFallbackCursor(VMODE*v)
{int x,y;if(!v)return;for(y=0;y<32;y++)for(x=0;x<32;x++)v->cursor[y*32+x]=GRAOS_RGBA(0,0,0,0);for(y=0;y<20;y++){int edge=(y<13)?(y/2+1):(20-y);if(edge<1)edge=1;if(edge>8)edge=8;for(x=0;x<edge;x++)v->cursor[y*32+x]=(x==0||x==edge-1||y==0)?GRAOS_RGB(0,0,0):GRAOS_RGB(255,255,255);}for(y=10;y<23;y++){x=4+(y-10)/2;if(x>=0&&x<32)v->cursor[y*32+x]=GRAOS_RGB(0,0,0);if(x+1<32)v->cursor[y*32+x+1]=GRAOS_RGB(255,255,255);}v->cursor_loaded=1;}
int guiLoadCursor(VMODE*v,const char*name){FILE*f;size_t n;if(!v)return 0;f=guiOpenResource(name,"rb");if(!f){guiFallbackCursor(v);return 1;}n=fread(v->cursor,1,sizeof(v->cursor),f);fclose(f);v->cursor_loaded=(n==sizeof(v->cursor));if(!v->cursor_loaded)guiFallbackCursor(v);return v->cursor_loaded;}
void guiDrawCursor(VMODE*v){if(v&&v->cursor_loaded)guiBlit(v,v->x,v->y,32,32,v->cursor,32,GRAOS_BLIT_ALPHA);}
