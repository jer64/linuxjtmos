#ifndef __INCLUDED_GUIBITMAP_H__
#define __INCLUDED_GUIBITMAP_H__
#include "graos.h"
BITMAP *guiCreateBitmap(WINDOW*,int,int,int,int,int,int,const GRAOS_PIXEL*);
BITMAP *guiGetBitmap(WINDOW*,int);
int guiSetBitmapData(WINDOW*,int,const GRAOS_PIXEL*,int);
int guiRemoveBitmap(WINDOW*,int);
void guiFreeWindowBitmaps(WINDOW*);
void guiDrawBitmap(VMODE*,WINDOW*,BITMAP*);
#endif
