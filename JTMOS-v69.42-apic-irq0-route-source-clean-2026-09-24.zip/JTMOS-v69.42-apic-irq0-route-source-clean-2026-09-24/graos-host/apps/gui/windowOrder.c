#include "windowOrder.h"
#include "wdb.h"
int putWindowOnTop(VMODE*v,WINDOW*w){(void)v;if(!w||w->isfree)return 0;wdb.top_z++;w->z=wdb.top_z;w->root.z=w->z;return 1;}
