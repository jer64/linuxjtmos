APPNAME=labeldemo
LIBCDIR=../../../libc/libc
include ../../../libc/apps/app-common.mk
