#ifndef __INCLUDED_GUIPIXEL_H__
#define __INCLUDED_GUIPIXEL_H__
#include <jtmos/basdef.h>

typedef DWORD GRAOS_PIXEL;

/* On little-endian i386 this DWORD is laid out in memory exactly R,G,B,A. */
#define GRAOS_RGBA(r,g,b,a) ((GRAOS_PIXEL)( \
    ((DWORD)((r)&255)) | ((DWORD)((g)&255)<<8) | \
    ((DWORD)((b)&255)<<16) | ((DWORD)((a)&255)<<24)))
#define GRAOS_RGB(r,g,b) GRAOS_RGBA((r),(g),(b),255)
#define GRAOS_R(p) ((BYTE)((p)&255))
#define GRAOS_G(p) ((BYTE)(((p)>>8)&255))
#define GRAOS_B(p) ((BYTE)(((p)>>16)&255))
#define GRAOS_A(p) ((BYTE)(((p)>>24)&255))

GRAOS_PIXEL JtmosMCGAColorToRGBA(int color);

#define GRAOS_BLIT_OPAQUE (-1)
#define GRAOS_BLIT_ALPHA  (-2)

static GRAOS_PIXEL graosIndexToPixel(int c)
{
    return JtmosMCGAColorToRGBA(c);
}

static GRAOS_PIXEL graosAlphaOver(GRAOS_PIXEL dst,GRAOS_PIXEL src)
{
    unsigned a=GRAOS_A(src),ia=255-a;
    unsigned r,g,b;
    if(a==0) return dst;
    if(a==255) return src;
    r=(GRAOS_R(src)*a+GRAOS_R(dst)*ia+127)/255;
    g=(GRAOS_G(src)*a+GRAOS_G(dst)*ia+127)/255;
    b=(GRAOS_B(src)*a+GRAOS_B(dst)*ia+127)/255;
    return GRAOS_RGBA(r,g,b,255);
}
#endif
