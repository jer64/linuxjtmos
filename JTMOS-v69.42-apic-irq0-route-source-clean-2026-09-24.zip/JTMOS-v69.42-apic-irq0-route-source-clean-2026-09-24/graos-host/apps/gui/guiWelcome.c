/* guiWelcome.c - Windows 98 era inspired JTMOS welcome experience. */
#include "guiWelcome.h"
#include "windowFunc.h"
#include "wdb.h"
#include "guiLabel.h"
#include "guiRect.h"
#include "guifont.h"

static void welcome_gradient(VMODE *v,int x1,int y1,int x2,int y2)
{
    static const BYTE colors[24]={32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55};
    int y,span=y2-y1+1,n;
    for(y=y1;y<=y2;y++) {
        n=((y-y1)*24)/span;
        if(n<0) n=0;
        if(n>23) n=23;
        fillRect(v,x1,y,x2,y,colors[n]);
    }
}

void guiDrawWelcomeDecor(VMODE *v,WINDOW *w)
{
    int top,left,right,bottom,y,x;
    if(!v||!w||!(w->type&GRAOS_WINDOW_WELCOME_STYLE)) return;
    top=w->y+w->captionHeight;
    left=w->x+3;
    right=w->x+w->width-4;
    bottom=w->y+w->height-4;

    /* A colour-heavy left panel echoes the late-90s consumer-PC campaigns:
     * saturated gradients, diagonal movement and a clear feature promise. */
    welcome_gradient(v,left,top,left+202,bottom);
    for(y=top;y<=bottom;y++) {
        x=left+30+((y-top)*2)/3;
        if(x<left+202) fillRect(v,left,y,x,y,53);
        x=left+155-((y-top)/3);
        if(x>left&&x<left+202) fillRect(v,x,y,left+202,y,35);
    }
    fillRect(v,left+12,top+18,left+190,top+20,15);
    DrawText(v,"JTMOS",left+28,top+42,15,-1);
    DrawText(v,"WELCOME 2026",left+28,top+60,14,-1);
    DrawText(v,"FAST",left+28,top+112,15,-1);
    DrawText(v,"SMALL",left+28,top+132,15,-1);
    DrawText(v,"DIRECT",left+28,top+152,15,-1);
    DrawText(v,"THE COMPUTER",left+28,top+208,31,-1);
    DrawText(v,"IS YOURS.",left+28,top+224,31,-1);

    fillRect(v,left+203,top,right,bottom,31);
    fillRect(v,left+203,top,left+208,bottom,28);
    DrawText(v,"Welcome to JTMOS",left+232,top+28,1,-1);
    DrawText(v,"A compact 32-bit operating system built to make",left+232,top+54,0,-1);
    DrawText(v,"the machine visible, programmable and yours.",left+232,top+68,0,-1);
    DrawText(v,"Protected multitasking | Ring 3 applications",left+232,top+92,8,-1);
    DrawText(v,"GraOS desktop | Squirrel Shell | VESA graphics",left+232,top+106,8,-1);
    DrawText(v,"i486 fallback | optional SSE3 acceleration",left+232,top+120,8,-1);
    fillRect(v,left+232,top+140,right-28,top+141,28);
    DrawText(v,"Choose what you want to explore:",left+232,top+154,0,-1);
    DrawText(v,"Tip: use the Start button for applications and tools.",left+232,bottom-34,8,-1);
}

int guiCreateWelcome(VMODE *v)
{
    WINDOW *w;
    int wid;
    if(!v) return 0;
    wid=guiCreateWindow(v,(GRAOS_WIDTH-760)/2,
                        (GRAOS_HEIGHT-GRAOS_PANEL_HEIGHT-460)/2,
                        760,460,"Welcome to JTMOS",
                        GRAOS_WINDOW_STANDARD|GRAOS_WINDOW_WELCOME_STYLE);
    w=GetWindowPTR(wid);
    if(!w) return 0;
    w->pid=0;
    guiCreateButton(w,235,206,455,238,GRAOS_BUTTON_STANDARD,"DISCOVER JTMOS");
    guiCreateButton(w,475,206,690,238,GRAOS_BUTTON_STANDARD,"OPEN TERMINAL");
    guiCreateButton(w,235,256,455,288,GRAOS_BUTTON_STANDARD,"EXPLORE FILES");
    guiCreateButton(w,475,256,690,288,GRAOS_BUTTON_STANDARD,"SYSTEM TOOLS");
    guiCreateLabel(w,235,318,455,16,GRAOS_INTERNAL_STATUS_LABEL_ID,1,31,
                   GRAOS_LABEL_ALIGN_LEFT,"Ready to explore JTMOS.");
    v->dirty=1;
    return 1;
}
