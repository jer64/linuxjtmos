#ifndef __INCLUDED_GUIUPDATE_H__
#define __INCLUDED_GUIUPDATE_H__
#include "graos.h"
int guiUpdate(VMODE *v);
#endif
