#ifndef __INCLUDED_GUIBMP_H__
#define __INCLUDED_GUIBMP_H__
#include "graos.h"
typedef struct {int width,height,top_down,colors;} GUI_BMP_INFO;
int guiBmpLoad32Stretch(FILE*,GRAOS_PIXEL*,int,int,GUI_BMP_INFO*);
#endif
