//----------------------------------------------------------
// taskbar.c - Windows 98 inspired external GraOS taskbar
//----------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/console.h>
#include <jtmos/process.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>
#include "guiLaunchCompat.h"

SYSMEMREQ(APPRAM_256K)

#define TASKBAR_H 30
#define START_ID 7000
#define MENU_W 228
#define MENU_ROW_H 32
#define MENU_ITEMS 7
#define MENU_H (MENU_ITEMS*MENU_ROW_H+8)
#define MENU_PROGRAMS 7101
#define MENU_FILER 7102
#define MENU_EDITOR 7103
#define MENU_TOP 7104
#define MENU_SETTINGS 7105
#define MENU_RUN 7106
#define MENU_CLOSE 7107
#define POWER_W 210
#define POWER_H 48
#define POWER_TASKMGR 7201

#define CLOCK_BUTTON_ID 7400
#define CLOCK_LABEL_ID 7401
#define CLOCK_W 84
#define CLOCK_POLL_MS 500UL

#define CAL_W 240
#define CAL_H 172
#define CAL_PREV 7410
#define CAL_NEXT 7411
#define CAL_TITLE 7420
#define CAL_WEEKDAYS 7421
#define CAL_WEEK0 7430
#define CAL_FOOTER 7440

static GRAOS_PIXEL *menu_brand_buf=NULL;

static void free_menu_brand(void)
{
    if(menu_brand_buf) { free(menu_brand_buf); menu_brand_buf=NULL; }
}

typedef struct {
    int second,minute,hour,day,month,year;
    int res[10];
} TASKBAR_DATE;

static int normalize_year(int year)
{
    if(year>=1900) return year;
    if(year>=70) return 1900+year;
    if(year>=0) return 2000+year;
    return 2000;
}

static int leap_year(int year)
{
    return ((year%4)==0 && (((year%100)!=0) || ((year%400)==0)));
}

static int month_days(int year,int month)
{
    static const int mdays[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    if(month<1 || month>12) return 30;
    if(month==2 && leap_year(year)) return 29;
    return mdays[month-1];
}

/* Monday=0 ... Sunday=6. */
static int weekday_monday(int year,int month,int day)
{
    static const int t[12]={0,3,2,5,0,3,5,1,4,6,2,4};
    int y=year,dow;
    if(month<3) y--;
    dow=(y+y/4-y/100+y/400+t[month-1]+day)%7; /* Sunday=0 */
    return (dow+6)%7;
}

static int read_wallclock(TASKBAR_DATE *d)
{
    if(!d) return -1;
    if(jtmos_syscall7(SYS_getdate,(uintptr_t)d,0,0,0,0,0)<0) return -1;
    if(d->hour<0 || d->hour>23 || d->minute<0 || d->minute>59 ||
       d->second<0 || d->second>59 || d->month<1 || d->month>12 ||
       d->day<1 || d->day>31) return -1;
    return 0;
}

static void format_clock(char *dst,int cap,const TASKBAR_DATE *d)
{
    if(!dst || cap<=0) return;
    if(!d) { snprintf(dst,(size_t)cap,"--:--"); return; }
    snprintf(dst,(size_t)cap,"%02d:%02d",d->hour,d->minute);
}

static int make_menu(int screen_height)
{
    int wid,y,i;
    GRAOS_PIXEL blue;
    wid=createWindow(3,screen_height-TASKBAR_H-MENU_H,MENU_W,MENU_H,"",
                     GRAOS_WINDOW_HAS_BORDER|GRAOS_WINDOW_AUTOCLEAR|GRAOS_WINDOW_POPUP_MENU);
    if(wid<0) return wid;

    free_menu_brand();
    menu_brand_buf=(GRAOS_PIXEL*)malloc((size_t)27*MENU_H*sizeof(GRAOS_PIXEL));
    if(menu_brand_buf) {
        blue=JtmosMCGAColorToRGBA(BLUE);
        for(i=0;i<27*MENU_H;i++) menu_brand_buf[i]=blue;
        if(addFrameBuffer(wid,menu_brand_buf,0,0,27,MENU_H,GRAOS_BPP,
                          GRAOS_SURFACE_BITMAP,0)<0) free_menu_brand();
    }
    createLabel(wid,5,12,18,12,7301,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"J");
    createLabel(wid,5,38,18,12,7302,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"T");
    createLabel(wid,5,64,18,12,7303,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"M");
    createLabel(wid,5,90,18,12,7304,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"O");
    createLabel(wid,5,116,18,12,7305,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"S");
    createLabel(wid,5,148,18,12,7306,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"9");
    createLabel(wid,5,174,18,12,7307,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"8");

    y=4;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_PROGRAMS,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_MENU_ARROW|GRAOS_BUTTON_ICON(GRAOS_ICON_PROGRAMS),"Programs");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_FILER,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_FOLDER),"File Manager");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_EDITOR,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_EDITOR),"Text Editor");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_TOP,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_TASKS),"Task Manager");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_SETTINGS,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_MENU_ARROW|GRAOS_BUTTON_ICON(GRAOS_ICON_SETTINGS),"Settings");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_RUN,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_TERMINAL),"Run...");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_CLOSE,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_POWER),"Close Menu");
    refreshWindow(wid);
    return wid;
}

static int make_power_menu(int screen_width,int screen_height)
{
    int x=6,y=screen_height-TASKBAR_H-POWER_H;
    int wid;
    if(x+POWER_W>screen_width) x=0;
    wid=createWindow(x,y,POWER_W,POWER_H,"",
                     GRAOS_WINDOW_HAS_BORDER|GRAOS_WINDOW_AUTOCLEAR|
                     GRAOS_WINDOW_POPUP_MENU);
    if(wid<0) return wid;
    createButtonStyled(wid,4,4,POWER_W-5,POWER_H-5,POWER_TASKMGR,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_TASKS),"Task Manager");
    refreshWindow(wid);
    return wid;
}

static void calendar_week(char *out,int cap,int year,int month,int week,
                          int today_y,int today_m,int today_d)
{
    int first,dim,col,day,pos=0;
    char cell[8];
    if(!out || cap<=0) return;
    out[0]=0;
    first=weekday_monday(year,month,1);
    dim=month_days(year,month);
    for(col=0;col<7;col++) {
        day=week*7-first+1+col;
        if(day<1 || day>dim) snprintf(cell,sizeof(cell),"    ");
        else if(year==today_y && month==today_m && day==today_d)
            snprintf(cell,sizeof(cell),"[%2d]",day);
        else snprintf(cell,sizeof(cell)," %2d ",day);
        if(pos+4<cap) {
            out[pos++]=cell[0]; out[pos++]=cell[1];
            out[pos++]=cell[2]; out[pos++]=cell[3]; out[pos]=0;
        }
    }
}

static void render_calendar(int wid,int year,int month,const TASKBAR_DATE *today)
{
    static const char *months[12]={
        "Tammikuu","Helmikuu","Maaliskuu","Huhtikuu","Toukokuu","Kesakuu",
        "Heinakuu","Elokuu","Syyskuu","Lokakuu","Marraskuu","Joulukuu"
    };
    char text[64];
    int i,ty=0,tm=0,td=0;
    if(today) { ty=normalize_year(today->year); tm=today->month; td=today->day; }
    snprintf(text,sizeof(text),"%s %d",months[month-1],year);
    setLabelText(wid,CAL_TITLE,text);
    for(i=0;i<6;i++) {
        calendar_week(text,sizeof(text),year,month,i,ty,tm,td);
        setLabelText(wid,CAL_WEEK0+i,text);
    }
    if(today) snprintf(text,sizeof(text),"Tanaan %d.%d.%d",today->day,today->month,ty);
    else snprintf(text,sizeof(text),"Tanaan --");
    setLabelText(wid,CAL_FOOTER,text);
}

static int make_calendar(int screen_width,int screen_height,int *year,int *month,const TASKBAR_DATE *today)
{
    int x,y,wid,i;
    char blank[2]="";
    x=screen_width-CAL_W-4;
    if(x<0) x=0;
    y=screen_height-TASKBAR_H-CAL_H-2;
    if(y<0) y=0;
    wid=createWindow(x,y,CAL_W,CAL_H,"",
                     GRAOS_WINDOW_HAS_BORDER|GRAOS_WINDOW_AUTOCLEAR|GRAOS_WINDOW_POPUP_MENU);
    if(wid<0) return wid;
    createButtonStyled(wid,4,4,28,25,CAL_PREV,GRAOS_BUTTON_STANDARD,"<");
    createButtonStyled(wid,CAL_W-29,4,CAL_W-5,25,CAL_NEXT,GRAOS_BUTTON_STANDARD,">");
    createLabel(wid,32,8,CAL_W-64,12,CAL_TITLE,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_CENTER,blank);
    createLabel(wid,8,32,CAL_W-16,12,CAL_WEEKDAYS,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_CENTER," Ma  Ti  Ke  To  Pe  La  Su ");
    for(i=0;i<6;i++)
        createLabel(wid,8,49+i*16,CAL_W-16,12,CAL_WEEK0+i,0,GRAOS_LABEL_TRANSPARENT,
                    GRAOS_LABEL_ALIGN_CENTER,blank);
    createLabel(wid,8,149,CAL_W-16,12,CAL_FOOTER,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_CENTER,blank);
    render_calendar(wid,*year,*month,today);
    refreshWindow(wid);
    return wid;
}

static void shift_calendar_month(int delta,int *year,int *month)
{
    if(!year || !month) return;
    *month+=delta;
    if(*month<1) { *month=12; (*year)--; }
    else if(*month>12) { *month=1; (*year)++; }
}

static void menu_action(int id)
{
    switch(id) {
    case MENU_PROGRAMS: graos_bgexec_command("/bin/launcher.bin","/"); break;
    case MENU_FILER: graos_bgexec_command("/bin/filer.bin","/"); break;
    case MENU_EDITOR: graos_bgexec_command("/bin/terminal.bin /bin/edit.bin","/"); break;
    case MENU_TOP: graos_bgexec_command("/bin/terminal.bin /bin/top.bin","/"); break;
    case MENU_SETTINGS: graos_bgexec_command("/bin/controlpanel.bin","/"); break;
    case MENU_RUN: graos_bgexec_command("/bin/terminal.bin","/"); break;
    default: break;
    }
}

static void toggle_menu(int *menu_wid,int screen_height)
{
    if(!menu_wid) return;
    if(*menu_wid>=0) {
        closeWindow(*menu_wid);
        *menu_wid=-1;
        free_menu_brand();
    } else *menu_wid=make_menu(screen_height);
}

static void close_popup(int *wid)
{
    if(wid && *wid>=0) { closeWindow(*wid); *wid=-1; }
}

static int mainLoop(int wid,int screen_width,int screen_height)
{
    GUICMD ev;
    TASKBAR_DATE now_date,last_date;
    int er,mer,menu_wid=-1,power_wid=-1,cal_wid=-1;
    int version_x,clock_x,cal_year=2000,cal_month=1,have_date=0,last_minute=-1;
    unsigned long last_clock_tick=0,now_tick;
    char clock_text[16];

    if(createButtonStyled(wid,3,4,66,TASKBAR_H-4,START_ID,
                          GRAOS_BUTTON_START,"Start")<0) return -1;

    clock_x=screen_width-CLOCK_W-4;
    if(clock_x<72) clock_x=72;
    createButtonStyled(wid,clock_x,4,screen_width-4,TASKBAR_H-4,CLOCK_BUTTON_ID,
                       GRAOS_BUTTON_SUNKEN,"");
    createLabel(wid,clock_x+2,8,CLOCK_W-4,14,CLOCK_LABEL_ID,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_CENTER,"--:--");

    version_x=clock_x-124;
    if(version_x>=72)
        createLabel(wid,version_x,8,120,14,7200,0,GRAOS_LABEL_TRANSPARENT,
                    GRAOS_LABEL_ALIGN_CENTER,"JTMOS / GraOS V37");

    if(read_wallclock(&now_date)==0) {
        have_date=1;
        last_date=now_date;
        last_minute=now_date.minute;
        cal_year=normalize_year(now_date.year);
        cal_month=now_date.month;
        format_clock(clock_text,sizeof(clock_text),&now_date);
        setLabelText(wid,CLOCK_LABEL_ID,clock_text);
    }
    refreshWindow(wid);

    for(;;) {
        while((er=JtmosGraOSPollEvent(wid,&ev))>0) {
            if(ev.id==GRAOS_GSID_EXIT) return 1;
            if(ev.id==GRAOS_GSID_STARTMENU) {
                close_popup(&power_wid); close_popup(&cal_wid);
                toggle_menu(&menu_wid,screen_height);
                continue;
            }
            if(ev.id==GRAOS_GSID_POWERMENU) {
                if(menu_wid>=0) { closeWindow(menu_wid); menu_wid=-1; free_menu_brand(); }
                close_popup(&cal_wid);
                if(power_wid>=0) close_popup(&power_wid);
                else power_wid=make_power_menu(screen_width,screen_height);
                continue;
            }
            if(ev.id==GRAOS_GSID_CLOSEMENUS) {
                if(menu_wid>=0) { closeWindow(menu_wid); menu_wid=-1; free_menu_brand(); }
                close_popup(&power_wid); close_popup(&cal_wid);
                continue;
            }
            if(ev.id==GRAOS_GSID_BUTTON && ev.v[0]==START_ID) {
                close_popup(&power_wid); close_popup(&cal_wid);
                toggle_menu(&menu_wid,screen_height);
                continue;
            }
            if(ev.id==GRAOS_GSID_BUTTON && ev.v[0]==CLOCK_BUTTON_ID) {
                if(menu_wid>=0) { closeWindow(menu_wid); menu_wid=-1; free_menu_brand(); }
                close_popup(&power_wid);
                if(cal_wid>=0) close_popup(&cal_wid);
                else {
                    if(read_wallclock(&now_date)==0) {
                        have_date=1; last_date=now_date;
                        cal_year=normalize_year(now_date.year); cal_month=now_date.month;
                    }
                    cal_wid=make_calendar(screen_width,screen_height,&cal_year,&cal_month,
                                          have_date?&last_date:NULL);
                }
                continue;
            }
        }
        if(er<0) return -2;

        if(menu_wid>=0) {
            while((mer=JtmosGraOSPollEvent(menu_wid,&ev))>0) {
                if(ev.id==GRAOS_GSID_EXIT) { menu_wid=-1; free_menu_brand(); break; }
                if(ev.id==GRAOS_GSID_KEYPRESSED && ev.v[0]==JKEY_ESC) {
                    closeWindow(menu_wid); menu_wid=-1; free_menu_brand(); break;
                }
                if(ev.id==GRAOS_GSID_BUTTON) {
                    int id=ev.v[0];
                    closeWindow(menu_wid); menu_wid=-1; free_menu_brand();
                    if(id!=MENU_CLOSE) menu_action(id);
                    break;
                }
            }
            if(mer<0) { menu_wid=-1; free_menu_brand(); }
        }
        if(power_wid>=0) {
            while((mer=JtmosGraOSPollEvent(power_wid,&ev))>0) {
                if(ev.id==GRAOS_GSID_EXIT) { power_wid=-1; break; }
                if(ev.id==GRAOS_GSID_KEYPRESSED && ev.v[0]==JKEY_ESC) {
                    closeWindow(power_wid); power_wid=-1; break;
                }
                if(ev.id==GRAOS_GSID_BUTTON) {
                    int id=ev.v[0];
                    closeWindow(power_wid); power_wid=-1;
                    if(id==POWER_TASKMGR)
                        graos_bgexec_command("/bin/terminal.bin /bin/top.bin","/");
                    break;
                }
            }
            if(mer<0) power_wid=-1;
        }
        if(cal_wid>=0) {
            while((mer=JtmosGraOSPollEvent(cal_wid,&ev))>0) {
                if(ev.id==GRAOS_GSID_EXIT) { cal_wid=-1; break; }
                if(ev.id==GRAOS_GSID_KEYPRESSED && ev.v[0]==JKEY_ESC) {
                    closeWindow(cal_wid); cal_wid=-1; break;
                }
                if(ev.id==GRAOS_GSID_BUTTON) {
                    if(ev.v[0]==CAL_PREV) shift_calendar_month(-1,&cal_year,&cal_month);
                    else if(ev.v[0]==CAL_NEXT) shift_calendar_month(1,&cal_year,&cal_month);
                    else continue;
                    render_calendar(cal_wid,cal_year,cal_month,have_date?&last_date:NULL);
                }
            }
            if(mer<0) cal_wid=-1;
        }

        now_tick=GetTickCount();
        if(last_clock_tick==0 || (unsigned long)(now_tick-last_clock_tick)>=CLOCK_POLL_MS) {
            last_clock_tick=now_tick;
            if(read_wallclock(&now_date)==0) {
                if(!have_date) {
                    have_date=1;
                    cal_year=normalize_year(now_date.year);
                    cal_month=now_date.month;
                    format_clock(clock_text,sizeof(clock_text),&now_date);
                    setLabelText(wid,CLOCK_LABEL_ID,clock_text);
                    last_minute=now_date.minute;
                    last_date=now_date;
                    if(cal_wid>=0)
                        render_calendar(cal_wid,cal_year,cal_month,&now_date);
                } else {
                    if(now_date.minute!=last_minute || now_date.hour!=last_date.hour) {
                        format_clock(clock_text,sizeof(clock_text),&now_date);
                        setLabelText(wid,CLOCK_LABEL_ID,clock_text);
                        last_minute=now_date.minute;
                    }
                    if(now_date.day!=last_date.day || now_date.month!=last_date.month ||
                       now_date.year!=last_date.year) {
                        if(cal_wid>=0)
                            render_calendar(cal_wid,cal_year,cal_month,&now_date);
                    }
                    last_date=now_date;
                }
            }
        }

        Sleep(40);
        SwitchToThread();
    }
}

int main(int argc,char **argv)
{
    int wid,screen_width,screen_height,bpp,panel_height,rv;
    (void)argc; (void)argv;

    rv=connectGraos();
    if(rv!=0) return 1;
    screen_width=GRAOS_SCREEN_WIDTH;
    screen_height=GRAOS_SCREEN_HEIGHT;
    bpp=GRAOS_SCREEN_BPP;
    panel_height=GRAOS_SCREEN_PANEL_HEIGHT;
    rv=JtmosGraOSGetScreenInfo(&screen_width,&screen_height,&bpp,&panel_height);
    if(rv<0) {
        screen_width=GRAOS_SCREEN_WIDTH;
        screen_height=GRAOS_SCREEN_HEIGHT;
    }
    if(screen_width<160 || screen_height<TASKBAR_H+CAL_H+4) return 2;

    wid=createWindow(0,screen_height-TASKBAR_H,screen_width,TASKBAR_H,"",
                     GRAOS_WINDOW_TASKBAR|GRAOS_WINDOW_AUTOCLEAR);
    if(wid<0) return 3;

    rv=mainLoop(wid,screen_width,screen_height);
    if(rv==0 || rv==-1) closeWindow(wid);
    return rv<0?4:0;
}
