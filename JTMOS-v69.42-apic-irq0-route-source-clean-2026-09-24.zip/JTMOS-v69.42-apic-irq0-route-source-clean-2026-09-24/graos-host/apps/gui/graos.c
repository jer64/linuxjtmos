#include <jtmos/cpu_features.h>
#include "graos.h"
#include "guiStart.h"
#include "guiLoop.h"

SYSMEMREQ(APPRAM_12288K)

int main(int argc,const char **argv)
{
    VMODE *v;
    (void)argc;
    (void)argv;

    if(GetThreadPID(GRAOS_SERVER_PID_NAME)>0) {
        printf("GraOS server already running.\n");
        return 1;
    }

    printf("GraOS %s: JTMOS V67.8.45 ring3 desktop, 1024x768x32 RGBA.\n",
           GRAOS_VERSION);
    printf("GraOS: Win98-style chrome, Welcome experience, IPC windows, widgets and task panel.\n");
    printf("GraOS RGBA pixel engine: %s.\n", jtmos_cpu_has(JTMOS_CPUF_SSE3_ACCEL) ?
           "SSE3 bulk fill/blit" : "generic i486");

    v=guiStart();
    if(!v) {
        printf("GraOS: initialization failed.\n");
        return 2;
    }

    if(!guiLoop(v))
        return 3;
    return 0;
}
