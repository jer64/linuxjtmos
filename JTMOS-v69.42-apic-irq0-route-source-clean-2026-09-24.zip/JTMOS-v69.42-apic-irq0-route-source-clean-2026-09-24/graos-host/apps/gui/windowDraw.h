#ifndef __INCLUDED_WINDOWDRAW_H__
#define __INCLUDED_WINDOWDRAW_H__
#include "graos.h"
void drawAllWindows(VMODE *v);
void windowDraw(VMODE *v,WINDOW *w);
#endif
