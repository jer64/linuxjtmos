#ifndef __INCLUDED_GUICHROME_H__
#define __INCLUDED_GUICHROME_H__
#include "graos.h"
int guiChromeInit(void);
void guiChromeDrawWindow(VMODE *v,WINDOW *w);
void guiChromeDrawButton(VMODE *v,WINDOW *w,BUTTON *b);
#endif
