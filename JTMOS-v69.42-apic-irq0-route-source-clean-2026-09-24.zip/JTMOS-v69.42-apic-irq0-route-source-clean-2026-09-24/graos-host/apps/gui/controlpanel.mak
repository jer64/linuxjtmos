APPNAME=controlpanel
LIBCDIR=../../../libc/libc
include ../../../libc/apps/app-common.mk
