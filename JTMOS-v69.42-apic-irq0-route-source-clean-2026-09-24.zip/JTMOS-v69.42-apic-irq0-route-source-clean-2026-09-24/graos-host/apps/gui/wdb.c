#include "wdb.h"
#include "windowFunc.h"
#include "windowOrder.h"
#include "guiWidget.h"
#include "guiTextBox.h"
#include "guiFocus.h"
WDB wdb;static int auto_x=24,auto_y=32;
static void copy_text(char*dst,int cap,const char*src){int i=0;if(!dst||cap<=0)return;if(src)while(i<cap-1&&src[i]){dst[i]=src[i];i++;}dst[i]=0;}
void wdbInit(void){int i;memset(&wdb,0,sizeof(wdb));for(i=0;i<N_MAX_WINDOWS;i++){wdb.w[i].id=i;wdb.w[i].isfree=1;}}
WINDOW *GetWindowPTR(int id){if(id<0||id>=N_MAX_WINDOWS||id>=wdb.n_windows)return NULL;if(wdb.w[id].isfree)return NULL;return &wdb.w[id];}
static WINDOW *new_window(void){int i;for(i=0;i<wdb.n_windows;i++)if(wdb.w[i].isfree)return&wdb.w[i];if(wdb.n_windows>=N_MAX_WINDOWS)return NULL;i=wdb.n_windows++;return&wdb.w[i];}
void SelectWindow(VMODE*v,WINDOW*w)
{
    WINDOW*old;if(!v||!w||w->isfree)return;if(w->minimized){w->minimized=0;guiWidgetSetVisible(&w->root,1);guiQueueWindowEvent(w,GRAOS_GSID_WINDOW_RESTORED,w->id,0,0);}
    old=v->selwin;if(old==w){putWindowOnTop(v,w);v->dirty=1;return;}
    if(old&&!old->isfree){guiClearWidgetFocus(v,old);guiQueueWindowEvent(old,GRAOS_GSID_WINDOW_BLUR,old->id,0,0);}
    putWindowOnTop(v,w);v->selwin=w;guiQueueWindowEvent(w,GRAOS_GSID_WINDOW_FOCUS,w->id,0,0);v->dirty=1;
}
int guiCreateWindow(VMODE*v,int x,int y,int width,int height,const char*caption,int type)
{
    WINDOW*w;
    int id,bottom,min_height;
    if(!v || v->width<=0 || v->height<=0 || width<32) return -1;
    bottom=(GRAOS_IS_TASKBAR_WINDOW(type))?v->height:(v->height-GRAOS_PANEL_HEIGHT);
    min_height=GRAOS_IS_TASKBAR_WINDOW(type)?16:24;
    if(height<min_height || width>v->width || height>bottom) return -1;
    w=new_window();
    if(!w) return -1;
    id=w->id;
    memset(w,0,sizeof(*w));
    w->id=id;w->isfree=0;w->fb_type=0;w->terminal_id=-1;
    if(x<0||y<0){
        x=auto_x;y=auto_y;auto_x+=20;auto_y+=18;
        if(auto_x>v->width-width)auto_x=24;
        if(auto_y>bottom-height)auto_y=32;
    }
    if(x<0)x=0;
    if(y<0)y=0;
    if(x>v->width-width)x=v->width-width;
    if(y>bottom-height)y=bottom-height;
    w->x=x;w->y=y;w->lx=x;w->ly=y;w->width=width;w->height=height;w->type=type;w->borderWidth=(type&GRAOS_WINDOW_HAS_BORDER)?DEF_BORDERWIDTH:0;w->captionHeight=(type&GRAOS_WINDOW_HAS_CAPTION)?20:0;copy_text(w->caption,sizeof(w->caption),caption?caption:"");
    guiWidgetInit(&w->root,GRAOS_WIDGET_WINDOW_ROOT,id,x,y,width,height,id,GRAOS_WIDGET_VISIBLE|GRAOS_WIDGET_ENABLED|GRAOS_WIDGET_FOCUSABLE);
    wdb.top_z++;w->z=wdb.top_z;w->root.z=w->z;
    if(type&GRAOS_WINDOW_MINIMIZE_BUTTON)guiCreateButton(w,0,0,14,14,GRAOS_WINDOW_MINIMIZE_BUTTON,"_");
    if(type&GRAOS_WINDOW_CLOSE_BUTTON)guiCreateButton(w,0,0,14,14,GRAOS_WINDOW_CLOSE_BUTTON|GRAOS_BUTTON_EXIT_ON_CLICK,"X");
    SelectWindow(v,w);return id;
}
WINDOW *getWindowUnderCursor(VMODE*v,int caption_only)
{
    int i,best=-2147483647;WINDOW*hit=NULL,*w;if(!v)return NULL;
    for(i=0;i<wdb.n_windows;i++){w=&wdb.w[i];if(w->isfree||w->minimized||GRAOS_IS_TASKBAR_WINDOW(w->type))continue;if(v->x>=w->x&&v->x<w->x+w->width&&v->y>=w->y&&v->y<w->y+(caption_only?w->captionHeight:w->height)&&w->z>best){best=w->z;hit=w;}}
    return hit;
}
BUTTON *getButtonUnderCursor(VMODE*v,WINDOW**owner)
{
    WINDOW*w=getWindowUnderCursor(v,0);int i;if(owner)*owner=NULL;if(!w)return NULL;
    for(i=0;i<w->n_buttons;i++){BUTTON*b=&w->button[i];int x1,y1,x2,y2;if(!b->widget.visible||!b->widget.enabled)continue;
        if(b->style&GRAOS_WINDOW_CLOSE_BUTTON){x1=w->width-18;y1=3;x2=w->width-4;y2=17;}
        else if(b->style&GRAOS_WINDOW_MINIMIZE_BUTTON){x1=w->width-36;y1=3;x2=w->width-22;y2=17;}
        else{x1=b->widget.x;y1=b->widget.y;x2=x1+b->widget.width;y2=y1+b->widget.height;}
        if(v->x>=w->x+x1&&v->x<w->x+x2&&v->y>=w->y+y1&&v->y<w->y+y2){if(owner)*owner=w;return b;}}
    return NULL;
}
