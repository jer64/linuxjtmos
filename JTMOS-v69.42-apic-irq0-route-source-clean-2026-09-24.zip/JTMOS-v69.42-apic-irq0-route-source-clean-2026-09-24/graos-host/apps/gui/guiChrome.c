/* guiChrome.c - Windows 98 inspired 32-bpp RGBA GraOS chrome. */
#include "guiChrome.h"
#include "guiRect.h"
#include "guiBlit.h"
#include "guiResource.h"
#include "guifont.h"
#include "guiFocus.h"
#define TITLE_ICON_W 14
#define TITLE_ICON_H 14
#define TITLE_ICON_PIXELS (TITLE_ICON_W*TITLE_ICON_H)
#define TITLE_ICON_BYTES (TITLE_ICON_PIXELS*4)
static GRAOS_PIXEL close_raw[TITLE_ICON_PIXELS];
static GRAOS_PIXEL minimize_raw[TITLE_ICON_PIXELS];
static int chrome_ready=0;

static int load_raw(const char *name,GRAOS_PIXEL *dst,int bytes)
{FILE*f;size_t n;if(!name||!dst||bytes<=0)return 0;f=guiOpenResource(name,"rb");if(!f)return 0;n=fread(dst,1,(size_t)bytes,f);fclose(f);return n==(size_t)bytes;}

static void make_fallback_button(GRAOS_PIXEL *dst,int close_button)
{
 int x,y;GRAOS_PIXEL face=GRAOS_RGB(192,192,192),white=GRAOS_RGB(255,255,255),dark=GRAOS_RGB(128,128,128),black=GRAOS_RGB(0,0,0);
 for(y=0;y<TITLE_ICON_H;y++)for(x=0;x<TITLE_ICON_W;x++)dst[y*TITLE_ICON_W+x]=face;
 for(x=0;x<TITLE_ICON_W;x++){dst[x]=white;dst[(TITLE_ICON_H-1)*TITLE_ICON_W+x]=black;}
 for(y=0;y<TITLE_ICON_H;y++){dst[y*TITLE_ICON_W]=white;dst[y*TITLE_ICON_W+TITLE_ICON_W-1]=black;}
 for(x=1;x<TITLE_ICON_W-1;x++)dst[(TITLE_ICON_H-2)*TITLE_ICON_W+x]=dark;
 for(y=1;y<TITLE_ICON_H-1;y++)dst[y*TITLE_ICON_W+TITLE_ICON_W-2]=dark;
 if(close_button){for(y=4;y<=9;y++){x=y;dst[y*TITLE_ICON_W+x]=black;if(x+1<TITLE_ICON_W-2)dst[y*TITLE_ICON_W+x+1]=black;x=13-y;dst[y*TITLE_ICON_W+x]=black;if(x-1>1)dst[y*TITLE_ICON_W+x-1]=black;}}
 else for(x=4;x<=9;x++){dst[9*TITLE_ICON_W+x]=black;dst[10*TITLE_ICON_W+x]=black;}
}

int guiChromeInit(void)
{int a=load_raw("title_close98.raw",close_raw,TITLE_ICON_BYTES),b=load_raw("title_minimize98.raw",minimize_raw,TITLE_ICON_BYTES);if(!a)make_fallback_button(close_raw,1);if(!b)make_fallback_button(minimize_raw,0);chrome_ready=1;return a&&b;}

static void draw_focus_rect(VMODE *v,int x1,int y1,int x2,int y2)
{
 int x,y;GRAOS_PIXEL c=GRAOS_RGB(0,0,0);
 if(!v||x2<=x1||y2<=y1)return;
 for(x=x1;x<=x2;x+=2){fillRectRGBA(v,x,y1,x,y1,c);fillRectRGBA(v,x,y2,x,y2,c);}
 for(y=y1+1;y<y2;y+=2){fillRectRGBA(v,x1,y,x1,y,c);fillRectRGBA(v,x2,y,x2,y,c);}
}

static void draw_bevel(VMODE*v,int x1,int y1,int x2,int y2,int sunken)
{
 GRAOS_PIXEL hi=sunken?GRAOS_RGB(0,0,0):GRAOS_RGB(255,255,255);
 GRAOS_PIXEL mid=sunken?GRAOS_RGB(128,128,128):GRAOS_RGB(223,223,223);
 GRAOS_PIXEL lo=sunken?GRAOS_RGB(255,255,255):GRAOS_RGB(0,0,0);
 GRAOS_PIXEL lom=sunken?GRAOS_RGB(223,223,223):GRAOS_RGB(128,128,128);
 fillRectRGBA(v,x1,y1,x2,y1,hi);fillRectRGBA(v,x1,y1,x1,y2,hi);
 fillRectRGBA(v,x1+1,y1+1,x2-1,y1+1,mid);fillRectRGBA(v,x1+1,y1+1,x1+1,y2-1,mid);
 fillRectRGBA(v,x1,y2,x2,y2,lo);fillRectRGBA(v,x2,y1,x2,y2,lo);
 fillRectRGBA(v,x1+1,y2-1,x2-1,y2-1,lom);fillRectRGBA(v,x2-1,y1+1,x2-1,y2-1,lom);
}

/* The blue caption field is deliberately flat like the supplied Windows 98
 * reference.  With captionHeight=20, the 8-pixel GUI font sits at y+6:
 * there are three clear pixels above and below it inside the title field. */
static void draw_title_field(VMODE*v,WINDOW*w,int active)
{
 int x1=w->x+3,x2=w->x+w->width-4,y1=w->y+3,y2=w->y+w->captionHeight-4;
 GRAOS_PIXEL c=active?GRAOS_RGB(0,0,128):GRAOS_RGB(128,128,128);
 if(x2<x1||y2<y1)return;
 fillRectRGBA(v,x1,y1,x2,y2,c);
}

static void draw_generic_window_icon(VMODE*v,int x,int y)
{
 GRAOS_PIXEL white=GRAOS_RGB(255,255,255),black=GRAOS_RGB(0,0,0),cyan=GRAOS_RGB(0,192,192),gray=GRAOS_RGB(192,192,192);
 fillRectRGBA(v,x,y,x+11,y+10,gray);drawRectRGBA(v,x,y,x+11,y+10,black);
 fillRectRGBA(v,x+2,y+2,x+9,y+7,cyan);fillRectRGBA(v,x+2,y+8,x+9,y+8,white);
}

void guiChromeDrawWindow(VMODE*v,WINDOW*w)
{
 int active,client_y,title_x;
 if(!v||!w)return;if(!chrome_ready)guiChromeInit();
 fillRectRGBA(v,w->x,w->y,w->x+w->width-1,w->y+w->height-1,GRAOS_RGB(192,192,192));
 if(w->type&GRAOS_WINDOW_HAS_BORDER)draw_bevel(v,w->x,w->y,w->x+w->width-1,w->y+w->height-1,0);
 if(w->type&GRAOS_WINDOW_HAS_CAPTION){
   active=(w==v->selwin);draw_title_field(v,w,active);title_x=w->x+7;
   if(w->caption[0]){draw_generic_window_icon(v,w->x+6,w->y+5);title_x=w->x+22;}
   /* Single-pass title text is much crisper than the old drop shadow. */
   DrawText(v,w->caption,title_x,w->y+6,15,-1);
 }
 client_y=w->y+w->captionHeight;
 if(client_y<w->y+w->height-3){
   if(w->type&GRAOS_WINDOW_CONTROL_PANEL_STYLE){
     int divider=w->x+202;
     fillRectRGBA(v,w->x+3,client_y,w->x+w->width-4,w->y+w->height-4,GRAOS_RGB(255,255,255));
     fillRectRGBA(v,divider,client_y+12,divider,w->y+w->height-16,GRAOS_RGB(192,192,192));
     fillRectRGBA(v,divider+1,client_y+12,divider+1,w->y+w->height-16,GRAOS_RGB(223,223,223));
     fillRectRGBA(v,w->x+18,client_y+62,w->x+183,client_y+62,GRAOS_RGB(0,128,128));
     fillRectRGBA(v,w->x+18,client_y+63,w->x+183,client_y+63,GRAOS_RGB(192,224,224));
   } else fillRectRGBA(v,w->x+3,client_y,w->x+w->width-4,w->y+w->height-4,GRAOS_RGB(192,192,192));
 }
}

static void icon_monitor(VMODE*v,int x,int y,int screen_color)
{
 GRAOS_PIXEL black=GRAOS_RGB(0,0,0),white=GRAOS_RGB(255,255,255),gray=GRAOS_RGB(192,192,192);
 fillRectRGBA(v,x+2,y+2,x+21,y+16,gray);drawRectRGBA(v,x+2,y+2,x+21,y+16,black);
 fillRect(v,x+4,y+4,x+19,y+13,screen_color);
 fillRectRGBA(v,x+10,y+17,x+13,y+20,black);fillRectRGBA(v,x+6,y+21,x+17,y+22,black);
 fillRectRGBA(v,x+4,y+4,x+18,y+4,white);
}
static void icon_folder(VMODE*v,int x,int y)
{
 GRAOS_PIXEL black=GRAOS_RGB(0,0,0),yellow=GRAOS_RGB(255,255,0),light=GRAOS_RGB(255,255,192);
 fillRectRGBA(v,x+2,y+7,x+21,y+20,yellow);drawRectRGBA(v,x+2,y+7,x+21,y+20,black);
 fillRectRGBA(v,x+4,y+4,x+11,y+7,light);drawRectRGBA(v,x+4,y+4,x+11,y+7,black);
 fillRectRGBA(v,x+4,y+9,x+19,y+10,light);
}
static void icon_editor(VMODE*v,int x,int y)
{
 GRAOS_PIXEL black=GRAOS_RGB(0,0,0),white=GRAOS_RGB(255,255,255),blue=GRAOS_RGB(0,0,128),yellow=GRAOS_RGB(255,255,0);
 fillRectRGBA(v,x+4,y+2,x+19,y+21,white);drawRectRGBA(v,x+4,y+2,x+19,y+21,black);
 fillRectRGBA(v,x+7,y+6,x+16,y+6,blue);fillRectRGBA(v,x+7,y+10,x+16,y+10,blue);fillRectRGBA(v,x+7,y+14,x+14,y+14,blue);
 fillRectRGBA(v,x+16,y+14,x+19,y+20,yellow);fillRectRGBA(v,x+15,y+19,x+18,y+22,black);
}
static void icon_tasks(VMODE*v,int x,int y)
{
 icon_monitor(v,x,y,1);
 fillRectRGBA(v,x+6,y+11,x+8,y+13,GRAOS_RGB(0,255,0));
 fillRectRGBA(v,x+10,y+8,x+12,y+13,GRAOS_RGB(255,255,0));
 fillRectRGBA(v,x+14,y+6,x+16,y+13,GRAOS_RGB(255,0,0));
}
static void icon_settings(VMODE*v,int x,int y)
{
 GRAOS_PIXEL black=GRAOS_RGB(0,0,0),gray=GRAOS_RGB(128,128,128),light=GRAOS_RGB(223,223,223);
 fillRectRGBA(v,x+7,y+5,x+17,y+19,gray);fillRectRGBA(v,x+5,y+8,x+19,y+16,gray);
 fillRectRGBA(v,x+9,y+7,x+15,y+17,light);fillRectRGBA(v,x+7,y+10,x+17,y+14,light);
 drawRectRGBA(v,x+10,y+9,x+14,y+15,black);fillRectRGBA(v,x+11,y+10,x+13,y+14,GRAOS_RGB(192,192,192));
}
static void icon_terminal(VMODE*v,int x,int y)
{
 GRAOS_PIXEL black=GRAOS_RGB(0,0,0),white=GRAOS_RGB(255,255,255),gray=GRAOS_RGB(192,192,192);
 fillRectRGBA(v,x+2,y+3,x+21,y+19,gray);drawRectRGBA(v,x+2,y+3,x+21,y+19,black);
 fillRectRGBA(v,x+4,y+5,x+19,y+16,black);
 fillRectRGBA(v,x+6,y+8,x+7,y+8,white);fillRectRGBA(v,x+7,y+9,x+8,y+9,white);fillRectRGBA(v,x+6,y+10,x+7,y+10,white);
 fillRectRGBA(v,x+11,y+12,x+15,y+12,white);
}
static void icon_power(VMODE*v,int x,int y)
{
 GRAOS_PIXEL black=GRAOS_RGB(0,0,0),red=GRAOS_RGB(192,0,0),white=GRAOS_RGB(255,255,255);
 fillRectRGBA(v,x+5,y+5,x+19,y+19,red);drawRectRGBA(v,x+5,y+5,x+19,y+19,black);
 fillRectRGBA(v,x+11,y+6,x+13,y+13,white);fillRectRGBA(v,x+8,y+11,x+9,y+16,white);fillRectRGBA(v,x+15,y+11,x+16,y+16,white);fillRectRGBA(v,x+10,y+17,x+14,y+18,white);
}
static void icon_windows(VMODE*v,int x,int y)
{
 fillRectRGBA(v,x+2,y+2,x+9,y+9,GRAOS_RGB(255,0,0));
 fillRectRGBA(v,x+12,y+2,x+19,y+9,GRAOS_RGB(0,128,255));
 fillRectRGBA(v,x+2,y+12,x+9,y+19,GRAOS_RGB(0,192,0));
 fillRectRGBA(v,x+12,y+12,x+19,y+19,GRAOS_RGB(255,255,0));
}
static void draw_style_icon(VMODE*v,int icon,int x,int y)
{
 switch(icon){
 case GRAOS_ICON_PROGRAMS: icon_windows(v,x,y);break;
 case GRAOS_ICON_FOLDER: icon_folder(v,x,y);break;
 case GRAOS_ICON_EDITOR: icon_editor(v,x,y);break;
 case GRAOS_ICON_TASKS: icon_tasks(v,x,y);break;
 case GRAOS_ICON_SETTINGS: icon_settings(v,x,y);break;
 case GRAOS_ICON_TERMINAL: icon_terminal(v,x,y);break;
 case GRAOS_ICON_POWER: icon_power(v,x,y);break;
 case GRAOS_ICON_DISPLAY: icon_monitor(v,x,y,9);break;
 case GRAOS_ICON_DESKTOP: icon_monitor(v,x,y,2);break;
 default: icon_windows(v,x,y);break;
 }
}

static void draw_standard_button(VMODE*v,WINDOW*w,BUTTON*b)
{
 GRAOS_WIDGET*g=&b->widget;int x1=w->x+g->x,y1=w->y+g->y,x2=x1+g->width-1,y2=y1+g->height-1,tx,ty,len;
 fillRectRGBA(v,x1,y1,x2,y2,GRAOS_RGB(192,192,192));draw_bevel(v,x1,y1,x2,y2,b->pressed?1:0);
 if(b->caption[0]){len=(int)strlen(b->caption)*8;tx=x1+(g->width-len)/2+(b->pressed?1:0);ty=y1+(g->height-8)/2+(b->pressed?1:0);if(tx<x1+3)tx=x1+3;DrawText(v,b->caption,tx,ty,0,-1);}
 if(guiWidgetIsFocused(v,w,g))draw_focus_rect(v,x1+4,y1+4,x2-4,y2-4);
}

static void draw_start_button(VMODE*v,WINDOW*w,BUTTON*b)
{
 GRAOS_WIDGET*g=&b->widget;int x1=w->x+g->x,y1=w->y+g->y,x2=x1+g->width-1,y2=y1+g->height-1,dy=b->pressed?1:0;
 fillRectRGBA(v,x1,y1,x2,y2,GRAOS_RGB(192,192,192));draw_bevel(v,x1,y1,x2,y2,b->pressed?1:0);
 draw_style_icon(v,GRAOS_ICON_PROGRAMS,x1+5+dy,y1+(g->height-20)/2+dy);
 DrawText(v,b->caption,x1+29+dy,y1+(g->height-8)/2+dy,0,-1);
 if(guiWidgetIsFocused(v,w,g))draw_focus_rect(v,x1+3,y1+3,x2-3,y2-3);
}

static void draw_menu_button(VMODE*v,WINDOW*w,BUTTON*b)
{
 GRAOS_WIDGET*g=&b->widget;int x1=w->x+g->x,y1=w->y+g->y,x2=x1+g->width-1,y2=y1+g->height-1;
 int icon=(b->style&GRAOS_BUTTON_ICON_MASK)>>GRAOS_BUTTON_ICON_SHIFT;
 int fg=b->pressed?15:0;
 fillRectRGBA(v,x1,y1,x2,y2,b->pressed?GRAOS_RGB(0,0,128):GRAOS_RGB(192,192,192));
 draw_style_icon(v,icon,x1+7,y1+(g->height-24)/2);
 DrawText(v,b->caption,x1+38,y1+(g->height-8)/2,fg,-1);
 if(b->style&GRAOS_BUTTON_MENU_ARROW){int ax=x2-10,ay=y1+g->height/2;fillRectRGBA(v,ax,ay-3,ax,ay+3,b->pressed?GRAOS_RGB(255,255,255):GRAOS_RGB(0,0,0));fillRectRGBA(v,ax+1,ay-2,ax+1,ay+2,b->pressed?GRAOS_RGB(255,255,255):GRAOS_RGB(0,0,0));fillRectRGBA(v,ax+2,ay-1,ax+2,ay+1,b->pressed?GRAOS_RGB(255,255,255):GRAOS_RGB(0,0,0));fillRectRGBA(v,ax+3,ay,ax+3,ay,b->pressed?GRAOS_RGB(255,255,255):GRAOS_RGB(0,0,0));}
 if(guiWidgetIsFocused(v,w,g))draw_focus_rect(v,x1+3,y1+3,x2-3,y2-3);
}

static void draw_icon_view_button(VMODE*v,WINDOW*w,BUTTON*b)
{
 GRAOS_WIDGET*g=&b->widget;int x1=w->x+g->x,y1=w->y+g->y,x2=x1+g->width-1,y2=y1+g->height-1;
 int icon=(b->style&GRAOS_BUTTON_ICON_MASK)>>GRAOS_BUTTON_ICON_SHIFT;
 int len=(int)strlen(b->caption)*8,tx=x1+(g->width-len)/2,iy=y1+9;
 if(b->pressed){fillRectRGBA(v,x1+3,y1+3,x2-3,y2-3,GRAOS_RGB(0,0,128));draw_style_icon(v,icon,x1+(g->width-24)/2,iy);if(tx<x1+3)tx=x1+3;DrawText(v,b->caption,tx,y2-17,15,-1);}
 else {draw_style_icon(v,icon,x1+(g->width-24)/2,iy);if(tx<x1+3)tx=x1+3;DrawText(v,b->caption,tx,y2-17,0,-1);}
 if(guiWidgetIsFocused(v,w,g))draw_focus_rect(v,x1+2,y1+2,x2-2,y2-2);
}

void guiChromeDrawButton(VMODE*v,WINDOW*w,BUTTON*b)
{
 int x1,y1;const GRAOS_PIXEL*raw;
 if(!v||!w||!b||!b->widget.visible)return;if(!chrome_ready)guiChromeInit();
 if(b->style&GRAOS_WINDOW_CLOSE_BUTTON){x1=w->x+w->width-18;y1=w->y+3;raw=close_raw;guiBlit(v,x1,y1,TITLE_ICON_W,TITLE_ICON_H,raw,TITLE_ICON_W,GRAOS_BLIT_OPAQUE);if(b->pressed)drawRectRGBA(v,x1+1,y1+1,x1+12,y1+12,GRAOS_RGB(0,0,0));return;}
 if(b->style&GRAOS_WINDOW_MINIMIZE_BUTTON){x1=w->x+w->width-36;y1=w->y+3;raw=minimize_raw;guiBlit(v,x1,y1,TITLE_ICON_W,TITLE_ICON_H,raw,TITLE_ICON_W,GRAOS_BLIT_OPAQUE);if(b->pressed)drawRectRGBA(v,x1+1,y1+1,x1+12,y1+12,GRAOS_RGB(0,0,0));return;}
 if(b->style&GRAOS_BUTTON_START){draw_start_button(v,w,b);return;}
 if(b->style&GRAOS_BUTTON_MENU){draw_menu_button(v,w,b);return;}
 if(b->style&GRAOS_BUTTON_ICON_VIEW){draw_icon_view_button(v,w,b);return;}
 draw_standard_button(v,w,b);
}
