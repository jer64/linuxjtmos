#ifndef __INCLUDED_WDB_H__
#define __INCLUDED_WDB_H__
#include "graos.h"
#define N_MAX_WINDOWS 32
#define DEF_BORDERWIDTH 1
typedef struct {
    WINDOW w[N_MAX_WINDOWS];
    int n_windows;
    int top_z;
} WDB;
extern WDB wdb;
void wdbInit(void);
WINDOW *GetWindowPTR(int id);
int guiCreateWindow(VMODE *v,int x,int y,int width,int height,const char *caption,int type);
void SelectWindow(VMODE *v, WINDOW *w);
WINDOW *getWindowUnderCursor(VMODE *v,int caption_only);
BUTTON *getButtonUnderCursor(VMODE *v, WINDOW **owner);
#endif
