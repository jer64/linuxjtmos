#include "guidot.h"
#include "guiRect.h"
#include "guiPixel.h"
int gui_dotPut(VMODE *v,int x,int y,int c)
{
    if(!v || !v->buf || x<0 || x>=v->width || y<0 || y>=v->height) return 0;
    v->buf[y*v->width+x]=graosIndexToPixel(c); v->dirty=1; return 1;
}
/* Area variant of Set Pixel.  Large spans/rectangles flow through fillRect()
 * -> memset(), which dispatches to SSE3 when the kernel reported it safe. */
int gui_dotPutArea(VMODE *v,int x,int y,int width,int height,int c)
{
    if(!v||width<=0||height<=0)return 0;
    fillRect(v,x,y,x+width-1,y+height-1,c);
    return 1;
}
int gui_dotGet(VMODE *v,int x,int y)
{
    if(!v || !v->buf || x<0 || x>=v->width || y<0 || y>=v->height) return 0;
    return v->buf[y*v->width+x];
}
