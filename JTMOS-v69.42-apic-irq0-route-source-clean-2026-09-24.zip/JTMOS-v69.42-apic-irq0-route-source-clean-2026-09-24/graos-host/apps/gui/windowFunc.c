#include "windowFunc.h"
#include "wdb.h"
#include "guiStart.h"
#include "guiLabel.h"
#include "guiBitmap.h"
#include "guiWidget.h"
#include "guiTextBox.h"
static void copy_caption(char*d,int cap,const char*s){int i=0;if(!d||cap<=0)return;if(s)while(i<cap-1&&s[i]){d[i]=s[i];i++;}d[i]=0;}
int guiQueueWindowEvent(WINDOW*w,int id,int v0,int v1,int v2)
{
    GRAOSEVENT*e;if(!w||w->isfree)return 0;
    if(w->event_count>=GRAOS_MAX_EVENTS){w->event_head=(w->event_head+1)%GRAOS_MAX_EVENTS;w->event_count--;}
    e=&w->event_q[w->event_tail];e->id=id;e->v0=v0;e->v1=v1;e->v2=v2;
    w->event_tail=(w->event_tail+1)%GRAOS_MAX_EVENTS;w->event_count++;return 1;
}
int guiPopWindowEvent(WINDOW*w,GRAOSEVENT*ev){if(!w||!ev||w->event_count<=0)return 0;*ev=w->event_q[w->event_head];w->event_head=(w->event_head+1)%GRAOS_MAX_EVENTS;w->event_count--;return 1;}
BUTTON *guiCreateButtonEx(WINDOW*w,int x1,int y1,int x2,int y2,int id,int style,const char*caption)
{
    BUTTON*b;int width=x2-x1+1,height=y2-y1+1;
    if(!w||w->n_buttons>=GRAOS_MAX_BUTTONS||width<=0||height<=0)return NULL;
    b=&w->button[w->n_buttons++];memset(b,0,sizeof(*b));
    guiWidgetInit(&b->widget,GRAOS_WIDGET_BUTTON,id,x1,y1,width,height,w->id,GRAOS_WIDGET_VISIBLE|GRAOS_WIDGET_ENABLED|GRAOS_WIDGET_FOCUSABLE);
    b->style=style;copy_caption(b->caption,sizeof(b->caption),caption?caption:"");return b;
}
BUTTON *guiCreateButton(WINDOW*w,int x1,int y1,int x2,int y2,int type,const char*caption)
{
    BUTTON *b;
    int id;
    /* Internal GraOS controls used to share id 0.  Focus is keyed by
     * (widget type,id), so one focused button made every id-0 button look
     * focused and Enter always resolved to the first one.  Give every
     * client-side internal button a stable per-window id instead. */
    if(type&GRAOS_WINDOW_CLOSE_BUTTON) id=GRAOS_INTERNAL_CLOSE_ID;
    else if(type&GRAOS_WINDOW_MINIMIZE_BUTTON) id=GRAOS_INTERNAL_MINIMIZE_ID;
    else id=GRAOS_INTERNAL_BUTTON_ID_BASE+w->n_buttons;
    b=guiCreateButtonEx(w,x1,y1,x2,y2,id,type,caption);
    /* Caption close/minimize controls stay mouse-only in the normal Tab
     * chain.  Tab navigation is intended for client-area controls. */
    if(b && (type&(GRAOS_WINDOW_CLOSE_BUTTON|GRAOS_WINDOW_MINIMIZE_BUTTON))) {
        b->widget.focusable=0;
        b->widget.flags&=~GRAOS_WIDGET_FOCUSABLE;
    }
    return b;
}
static void select_best_remaining(VMODE*v)
{
    int i,best=-2147483647;WINDOW*w=NULL;
    for(i=0;i<wdb.n_windows;i++)if(!wdb.w[i].isfree&&!wdb.w[i].minimized&&!GRAOS_IS_TASKBAR_WINDOW(wdb.w[i].type)&&!GRAOS_IS_POPUP_WINDOW(wdb.w[i].type)&&wdb.w[i].z>best){best=wdb.w[i].z;w=&wdb.w[i];}
    if(w)SelectWindow(v,w);else v->selwin=NULL;
}
void guiMinimizeWindow(VMODE*v,WINDOW*w)
{
    if(!v||!w||w->isfree||GRAOS_IS_TASKBAR_WINDOW(w->type)||w->minimized)return;
    guiBlurTextBox(v,w);w->minimized=1;guiWidgetSetVisible(&w->root,0);guiQueueWindowEvent(w,GRAOS_GSID_WINDOW_MINIMIZED,w->id,0,0);
    if(v->selwin==w){v->selwin=NULL;select_best_remaining(v);}v->dirty=1;
}
void guiRestoreWindow(VMODE*v,WINDOW*w)
{
    if(!v||!w||w->isfree)return;
    if(w->minimized){w->minimized=0;guiWidgetSetVisible(&w->root,1);guiQueueWindowEvent(w,GRAOS_GSID_WINDOW_RESTORED,w->id,0,0);}
    SelectWindow(v,w);v->dirty=1;
}

/* Alt+Tab traversal deliberately follows the stable window-id order rather
 * than z order.  SelectWindow() raises the chosen task, so cycling by z would
 * otherwise bounce between only the two most recent windows. */
int guiSwitchTask(VMODE*v,int direction)
{
    int n,start,step,i,idx;
    WINDOW *w;
    if(!v || wdb.n_windows<=0) return 0;
    n=wdb.n_windows;
    start=(v->selwin && !v->selwin->isfree)?v->selwin->id:(direction<0?0:n-1);
    step=(direction<0)?-1:1;
    for(i=1;i<=n;i++) {
        idx=(start+step*i)%n;
        if(idx<0) idx+=n;
        w=&wdb.w[idx];
        if(w->isfree || GRAOS_IS_TASKBAR_WINDOW(w->type) || GRAOS_IS_POPUP_WINDOW(w->type)) continue;
        guiRestoreWindow(v,w);
        return 1;
    }
    return 0;
}
void guiCloseWindow(VMODE*v,WINDOW*w)
{
    if(!v||!w||w->isfree)return;
    if(!strcmp(w->caption,"JTMOS Command Prompt - Squirrel Shell"))v->prompt_launch_state=0;
    if(w->pid>0){MSG m;GUICMD*c;memset((char*)&m,0,sizeof(m));m.protocol=JTMOS_MB_PROTOCOL_GRAOS;m.amount=sizeof(GUICMD);c=(GUICMD*)m.buf;c->magic=GRAOS_CMD_MAGIC;c->id=GRAOS_GSID_EXIT;c->wid=w->id;sendMessage(&m,w->pid);}
    if(w->terminal_pid>0){KillThread(w->terminal_pid);w->terminal_pid=0;}
    if(w->framebuffer){free(w->framebuffer);w->framebuffer=NULL;}guiFreeWindowBitmaps(w);
    w->framebuffer_user=0;w->framebuffer_owner=0;w->fb_type=0;w->terminal_id=-1;w->focused_widget_type=GRAOS_WIDGET_NONE;w->focused_widget_id=0;w->isfree=1;w->minimized=0;guiWidgetSetVisible(&w->root,0);
    if(v->selwin==w){v->selwin=NULL;select_best_remaining(v);}if(v->movwin==w){v->movwin=NULL;v->movingWindow=0;}v->dirty=1;
}
static void action_status(VMODE*v,WINDOW*w,const char*ok,const char*fail,int result){const char*msg=result?ok:fail;if(!v||!w)return;if(!guiSetLabelText(w,GRAOS_INTERNAL_STATUS_LABEL_ID,msg))copy_caption(w->qmsg,sizeof(w->qmsg),msg);v->dirty=1;}
void onButtonClick(VMODE*v,WINDOW*w,BUTTON*b)
{
    if(!v||!w||!b||!b->widget.enabled)return;
    if(b->style&GRAOS_WINDOW_CLOSE_BUTTON){guiCloseWindow(v,w);return;}
    if(b->style&GRAOS_WINDOW_MINIMIZE_BUTTON){guiMinimizeWindow(v,w);return;}
    if(b->style&GRAOS_BUTTON_EXIT_ON_CLICK){guiCloseWindow(v,w);return;}
    if(w->pid>0){guiQueueWindowEvent(w,GRAOS_GSID_BUTTON,b->widget.id,0,0);return;}
    if(!strcmp(b->caption,"TERMINAL")){action_status(v,w,"JTMOS Command Prompt started","Terminal launch failed",guiStartCommandPrompt(v));return;}
    if(!strcmp(b->caption,"FILE MANAGER")){action_status(v,w,"File Manager started","File Manager launch failed",guiLaunchBackgroundApp(v,"/bin/filer.bin"));return;}
    if(!strcmp(b->caption,"TEXT EDITOR")){action_status(v,w,"Text Editor started","Text Editor launch failed",guiStartTerminalProgram(v,"/bin/edit.bin","JTMOS Text Editor"));return;}
    if(!strcmp(b->caption,"TASK MANAGER")){action_status(v,w,"Task Manager started","Task Manager launch failed",guiStartTerminalProgram(v,"/bin/top.bin","JTMOS Task Manager"));return;}
    if(!strcmp(b->caption,"Terminal")){action_status(v,w,"JTMOS Command Prompt started","Terminal launch failed",guiStartCommandPrompt(v));return;}
    if(!strcmp(b->caption,"File Manager")){action_status(v,w,"File Manager started","File Manager launch failed",guiLaunchBackgroundApp(v,"/bin/filer.bin"));return;}
    if(!strcmp(b->caption,"Text Editor")){action_status(v,w,"Text Editor started","Text Editor launch failed",guiStartTerminalProgram(v,"/bin/edit.bin","JTMOS Text Editor"));return;}
    if(!strcmp(b->caption,"Task Manager")){action_status(v,w,"Task Manager started","Task Manager launch failed",guiStartTerminalProgram(v,"/bin/top.bin","JTMOS Task Manager"));return;}
    if(!strcmp(b->caption,"Blue Desktop")){v->desktop_color=BLUE;v->desktop_solid=1;action_status(v,w,"Desktop color: blue","Desktop color failed",1);return;}
    if(!strcmp(b->caption,"Green Desktop")){v->desktop_color=GREEN;v->desktop_solid=1;action_status(v,w,"Desktop color: green","Desktop color failed",1);return;}
    if(!strcmp(b->caption,"Dark Desktop")){v->desktop_color=DARKGRAY;v->desktop_solid=1;action_status(v,w,"Desktop color: dark gray","Desktop color failed",1);return;}
    if(!strcmp(b->caption,"OPEN TERMINAL")){action_status(v,w,"JTMOS Command Prompt started","Terminal launch failed",guiStartCommandPrompt(v));return;}
    if(!strcmp(b->caption,"EXPLORE FILES")){action_status(v,w,"File Manager started","File Manager launch failed",guiLaunchBackgroundApp(v,"/bin/filer.bin"));return;}
    if(!strcmp(b->caption,"SYSTEM TOOLS")){action_status(v,w,"Control Panel opened","Control Panel launch failed",guiOpenControlPanel(v));return;}
    if(!strcmp(b->caption,"DISCOVER JTMOS")){action_status(v,w,"Applications opened","Application launcher failed",guiLaunchBackgroundApp(v,"/bin/launcher.bin"));return;}
    {char msg[128];snprintf(msg,sizeof(msg),"Button clicked: %s",b->caption);if(!guiSetLabelText(w,GRAOS_INTERNAL_STATUS_LABEL_ID,msg))copy_caption(w->qmsg,sizeof(w->qmsg),msg);}v->dirty=1;
}
