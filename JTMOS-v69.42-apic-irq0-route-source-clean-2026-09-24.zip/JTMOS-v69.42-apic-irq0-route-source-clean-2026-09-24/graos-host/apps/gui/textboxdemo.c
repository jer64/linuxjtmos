/* textboxdemo.c - GraOS TextBox widget runtime test, V67.8. */
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/process.h>
SYSMEMREQ(APPRAM_256K)
#define TB_EDIT 5101
#define TB_SHOW 5102
#define TB_CLEAR 5103
#define TB_CLOSE 5104
#define TB_STATUS 5110
static void show_value(int wid)
{
    char value[128],msg[180];
    if(getTextBoxText(wid,TB_EDIT,value,sizeof(value))<0) strcpy(value,"<read error>");
    snprintf(msg,sizeof(msg),"Value: %s",value); setLabelText(wid,TB_STATUS,msg);
}
int main(void)
{
    GUICMD ev;int wid,er,server_closed=0;
    if(connectGraos()!=0)return 1;
    wid=createWindow(-1,-1,430,190,"GraOS TextBox Demo",GRAOS_WINDOW_STANDARD);if(wid<0)return 2;
    createLabel(wid,18,28,390,14,5001,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_LEFT,"Click the field and type. Enter submits the value.");
    createTextBox(wid,18,52,390,24,TB_EDIT,96,"hello from GraOS");
    createButton(wid,18,90,118,118,TB_SHOW,"Show");
    createButton(wid,132,90,232,118,TB_CLEAR,"Clear");
    createButton(wid,308,90,408,118,TB_CLOSE,"Close");
    createLabel(wid,18,132,390,16,TB_STATUS,0,7,GRAOS_LABEL_ALIGN_LEFT,"Ready");
    refreshWindow(wid);
    for(;;){while((er=JtmosGraOSPollEvent(wid,&ev))>0){
        if(ev.id==GRAOS_GSID_EXIT){server_closed=1;goto out;}
        if(ev.id==GRAOS_GSID_TEXTBOX_ENTER && ev.v[0]==TB_EDIT){show_value(wid);continue;}
        if(ev.id==GRAOS_GSID_BUTTON){
            if(ev.v[0]==TB_SHOW)show_value(wid);
            else if(ev.v[0]==TB_CLEAR){setTextBoxText(wid,TB_EDIT,"");setLabelText(wid,TB_STATUS,"Cleared");}
            else if(ev.v[0]==TB_CLOSE)goto out;
        }
    }if(er<0){server_closed=1;goto out;}SwitchToThread();Sleep(10);}
out:if(!server_closed)closeWindow(wid);return 0;
}
