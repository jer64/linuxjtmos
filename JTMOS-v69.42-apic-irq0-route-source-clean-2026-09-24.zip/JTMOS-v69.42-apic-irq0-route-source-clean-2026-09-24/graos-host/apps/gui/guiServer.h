#ifndef __INCLUDED_GUISERVER_H__
#define __INCLUDED_GUISERVER_H__
#include "graos.h"
void guiServerInit(void);
void guiServerPoll(VMODE *v);
#endif
