/* graosctl.c - native GraOS control/status client */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jtmos/graos.h>
SYSMEMREQ(APPRAM_128K)
int main(int argc,char **argv)
{
    const char *cmd=argc>1?argv[1]:"status";int w=0,t=0,f=-1,r;unsigned long frames=0;
    if(connectGraos()!=0){printf("graosctl: GraOS is not running.\n");return 1;}
    if(!strcmp(cmd,"ping")){r=JtmosGraOSPing();printf(r<0?"graos: ping failed\n":"graos: running\n");return r<0;}
    if(!strcmp(cmd,"shutdown")){r=JtmosGraOSShutdown();printf(r<0?"graos: shutdown failed\n":"graos: shutdown requested\n");return r<0;}
    if(!strcmp(cmd,"color")&&argc>2){r=JtmosGraOSSetDesktopColor(atoi(argv[2]));return r<0;}
    r=JtmosGraOSGetStats(&w,&t,&f,&frames);if(r<0)return 1;
    printf("GraOS pid=%d windows=%d terminals=%d focus=%d frames=%lu\n",getGraosPID(),w,t,f,frames);return 0;
}
