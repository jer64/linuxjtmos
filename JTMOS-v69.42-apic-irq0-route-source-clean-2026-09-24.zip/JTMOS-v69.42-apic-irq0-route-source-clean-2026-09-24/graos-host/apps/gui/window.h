#ifndef __INCLUDED_WINDOW_H__
#define __INCLUDED_WINDOW_H__
#include <jtmos/basdef.h>
#include "graosprotocol.h"
#define GRAOS_MAX_BUTTONS 32
#define GRAOS_MAX_LABELS 32
#define GRAOS_LABEL_TEXT_MAX 128
#define GRAOS_MAX_BITMAPS 8
#define GRAOS_MAX_TEXTBOXES 16
#define GRAOS_TEXTBOX_TEXT_MAX 128
#define GRAOS_BITMAP_MAX_WIDTH 160
#define GRAOS_BITMAP_MAX_HEIGHT 160
#define GRAOS_BITMAP_MAX_BYTES (GRAOS_BITMAP_MAX_WIDTH*GRAOS_BITMAP_MAX_HEIGHT*4)
#define GRAOS_MAX_EVENTS 16
#define GRAOS_INTERNAL_MINIMIZE_ID 0x7ff0
#define GRAOS_INTERNAL_CLOSE_ID 0x7ff1
#define GRAOS_INTERNAL_BUTTON_ID_BASE 0x7e00

typedef struct {
    GRAOS_WIDGET widget;
    int pressed;
    int style;
    char caption[64];
} BUTTON;

typedef struct {
    GRAOS_WIDGET widget;
    int fg,bg;
    int align;
    char text[GRAOS_LABEL_TEXT_MAX];
} LABEL;

typedef struct {
    GRAOS_WIDGET widget;
    int transparent;
    int bytes;
    GRAOS_PIXEL *pixels;
} BITMAP;

typedef struct {
    GRAOS_WIDGET widget;
    int fg,bg;
    int focused;
    int caret;
    int view_start;
    int maxlen;
    char text[GRAOS_TEXTBOX_TEXT_MAX];
} TEXTBOX;

typedef struct { int id; int v0,v1,v2; } GRAOSEVENT;

typedef struct {
    /* Root widget describes the whole window as a component container. */
    GRAOS_WIDGET root;
    int id;
    int borderWidth;
    char isfree;
    char minimized;
    int x,y,lx,ly;
    int width,height;
    DWORD type;
    char caption[100];
    char qmsg[160];
    int z;
    int captionHeight;
    int pid;
    GRAOS_PIXEL *framebuffer;
    DWORD framebuffer_user;
    int framebuffer_owner;
    int fb_type;
    int terminal_id;
    int terminal_pid;
    int fb_x,fb_y,fb_width,fb_height,fb_bpp,fb_stride;
    BUTTON button[GRAOS_MAX_BUTTONS];
    int n_buttons;
    LABEL label[GRAOS_MAX_LABELS];
    int n_labels;
    BITMAP bitmap[GRAOS_MAX_BITMAPS];
    int n_bitmaps;
    TEXTBOX textbox[GRAOS_MAX_TEXTBOXES];
    int n_textboxes;
    int focused_widget_type;
    int focused_widget_id;
    GRAOSEVENT event_q[GRAOS_MAX_EVENTS];
    int event_head,event_tail,event_count;
} WINDOW;
#endif
