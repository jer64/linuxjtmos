#include "guiServer.h"
#include "graosprotocol.h"
#include "wdb.h"
#include "windowFunc.h"
#include "guiLabel.h"
#include "guiBitmap.h"
#include "guiTextBox.h"
#include <jtmos/scall.h>


static int graos_copy_from_thread(int pid,const void *src,void *dst,DWORD len)
{
    return (int)scall(SYS_copyfromthread,(DWORD)pid,(DWORD)src,len,(DWORD)dst,0,0);
}

void guiServerInit(void)
{
#if GRAOS_ENABLE_SERVER
    IdentifyThread(GetCurrentThread(),GRAOS_SERVER_PID_NAME);
    startMessageBox();
#endif
}

static void response_ex(MSG *in,int rval,int wid,const int *values,int nvalues)
{
    MSG out;
    GUICMD *c;
    int i;

    if(!in || in->sndPID<=0) return;
    memset((char*)&out,0,sizeof(out));
    out.protocol=JTMOS_MB_PROTOCOL_GRAOS;
    out.amount=sizeof(GUICMD);
    c=(GUICMD*)out.buf;
    c->magic=GRAOS_CMD_MAGIC;
    c->id=GRAOS_GSID_RESPONSE;
    c->rval=(DWORD)rval;
    c->wid=wid;
    if(values) for(i=0;i<nvalues && i<20;i++) c->v[i]=values[i];
    sendMessage(&out,in->sndPID);
}
static void response(MSG *in,int rval,int wid){response_ex(in,rval,wid,NULL,0);}
static void response_text(MSG *in,int rval,int wid,const char *text)
{
    MSG out; GUICMD *c;
    if(!in || in->sndPID<=0) return;
    memset((char*)&out,0,sizeof(out)); out.protocol=JTMOS_MB_PROTOCOL_GRAOS; out.amount=sizeof(GUICMD);
    c=(GUICMD*)out.buf; c->magic=GRAOS_CMD_MAGIC; c->id=GRAOS_GSID_RESPONSE; c->rval=(DWORD)rval; c->wid=wid;
    if(text){strncpy(c->str,text,sizeof(c->str)-1);c->str[sizeof(c->str)-1]=0;}
    sendMessage(&out,in->sndPID);
}

static void server_stats(VMODE *v,int *values)
{
    int i,windows=0,terminals=0,focus=-1;
    for(i=0;i<wdb.n_windows;i++) if(!wdb.w[i].isfree) {
        windows++;
        if(wdb.w[i].fb_type==GRAOS_SURFACE_TERMINAL) terminals++;
    }
    if(v->selwin && !v->selwin->isfree) focus=v->selwin->id;
    values[0]=windows; values[1]=terminals; values[2]=focus;
    values[3]=(int)v->frame_counter;
}

static void handle_message(VMODE *v,MSG *m)
{
    GUICMD *c;
    WINDOW *w;
    int r=-1,wid=-1;

    if(!v || !m || m->protocol!=JTMOS_MB_PROTOCOL_GRAOS)
        return;
    if(m->amount<(int)sizeof(GUICMD))
        return;

    c=(GUICMD*)m->buf;
    if(c->magic!=GRAOS_CMD_MAGIC) {
        response(m,-2,-1);
        return;
    }

    switch(c->id) {
    case GRAOS_GSID_PING:
        r=0;
        break;

    case GRAOS_GSID_GETSTATS:
        { int values[4]; server_stats(v,values); response_ex(m,0,-1,values,4); return; }

    case GRAOS_GSID_GETSCREENINFO:
        {
            int values[4];
            values[0]=v->width; values[1]=v->height; values[2]=v->bpp;
            values[3]=GRAOS_PANEL_HEIGHT;
            response_ex(m,0,-1,values,4);
            return;
        }

    case GRAOS_GSID_SHUTDOWN:
        v->running=0;
        v->dirty=1;
        r=0;
        break;

    case GRAOS_GSID_SETDESKTOPCOLOR:
        if(c->v[0]<0 || c->v[0]>255) r=-6;
        else { v->desktop_color=c->v[0]; v->desktop_solid=1; v->dirty=1; r=0; }
        break;

    case GRAOS_GSID_SETPALETTE:
        if(c->v[0]==-1) r=JtmosVGASetPalette(-1,0,0,0);
        else if(c->v[0]<0 || c->v[0]>255 || c->v[1]<0 || c->v[1]>63 ||
           c->v[2]<0 || c->v[2]>63 || c->v[3]<0 || c->v[3]>63) r=-6;
        else r=JtmosVGASetPalette(c->v[0],c->v[1],c->v[2],c->v[3]);
        break;

    case GRAOS_GSID_FREETERMINAL:
        /* Kernel owns terminal lifetime and frees PID-owned dynamic terminals.
         * Detach matching surfaces immediately so stale IDs are never drawn. */
        {
            int i;
            for(i=0;i<wdb.n_windows;i++) {
                WINDOW *tw=&wdb.w[i];
                if(!tw->isfree && tw->fb_type==GRAOS_SURFACE_TERMINAL &&
                   tw->terminal_id==c->v[0] && tw->pid==m->sndPID) {
                    tw->fb_type=0; tw->terminal_id=-1; tw->terminal_pid=0;
                    v->dirty=1;
                }
            }
            r=0;
        }
        break;

    case GRAOS_GSID_OPENWINDOW:
        if(c->v[2]<32 || c->v[3]<(GRAOS_IS_TASKBAR_WINDOW(c->v[4])?16:24) ||
           c->v[2]>v->width ||
           c->v[3]>(GRAOS_IS_TASKBAR_WINDOW(c->v[4])?v->height:(v->height-GRAOS_PANEL_HEIGHT))) {
            r=-6;
            break;
        }
        wid=guiCreateWindow(v,c->v[0],c->v[1],c->v[2],c->v[3],c->str,c->v[4]);
        w=GetWindowPTR(wid);
        if(w) {
            w->pid=m->sndPID;
            r=wid;
        }
        break;

    case GRAOS_GSID_CLOSEWINDOW:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(w && (w->pid==0 || w->pid==m->sndPID)) {
            w->pid=0;
            guiCloseWindow(v,w);
            r=0;
        } else r=-7;
        break;

    case GRAOS_GSID_MINIMIZEWINDOW:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(w && (w->pid==0 || w->pid==m->sndPID)) { guiMinimizeWindow(v,w); r=0; }
        else r=-7;
        break;

    case GRAOS_GSID_RESTOREWINDOW:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(w && (w->pid==0 || w->pid==m->sndPID)) { guiRestoreWindow(v,w); r=0; }
        else r=-7;
        break;

    case GRAOS_GSID_REQUESTREFRESH:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(w && (w->pid==0 || w->pid==m->sndPID)) {
            if(w->framebuffer && w->framebuffer_user && w->framebuffer_owner>0) {
                DWORD bytes=(DWORD)w->fb_stride*(DWORD)w->fb_height*4UL;
                if(graos_copy_from_thread(w->framebuffer_owner,
                                          (void*)w->framebuffer_user,
                                          w->framebuffer,bytes)<0) {
                    r=-4;
                    break;
                }
            }
            v->dirty=1;
            r=0;
        } else r=-7;
        break;

    case GRAOS_GSID_CREATEBUTTON:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(w && (w->pid==0 || w->pid==m->sndPID) &&
           guiCreateButtonEx(w,c->v[1],c->v[2],c->v[3],c->v[4],c->v[5],c->v[6],c->str)) {
            v->dirty=1;
            r=0;
        } else r=-7;
        break;

    case GRAOS_GSID_CREATELABEL:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(!w || w->pid!=m->sndPID) { r=-7; break; }
        if(c->v[1]<0 || c->v[2]<0 || c->v[3]<=0 || c->v[4]<=0 ||
           c->v[1]+c->v[3]>w->width || c->v[2]+c->v[4]>w->height ||
           c->v[6]<0 || c->v[6]>255 ||
           c->v[7]<GRAOS_LABEL_TRANSPARENT || c->v[7]>255 ||
           c->v[8]<GRAOS_LABEL_ALIGN_LEFT || c->v[8]>GRAOS_LABEL_ALIGN_RIGHT) {
            r=-6;
            break;
        }
        if(guiCreateLabel(w,c->v[1],c->v[2],c->v[3],c->v[4],c->v[5],
                          c->v[6],c->v[7],c->v[8],c->str)) {
            v->dirty=1;
            r=0;
        } else r=-5;
        break;

    case GRAOS_GSID_SETLABELTEXT:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(w && w->pid==m->sndPID &&
           guiSetLabelText(w,c->v[1],c->str)) {
            v->dirty=1;
            r=0;
        } else r=-7;
        break;

    case GRAOS_GSID_SETLABELSTYLE:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(!w || w->pid!=m->sndPID) { r=-7; break; }
        if(c->v[2]<0 || c->v[2]>255 ||
           c->v[3]<GRAOS_LABEL_TRANSPARENT || c->v[3]>255 ||
           c->v[4]<GRAOS_LABEL_ALIGN_LEFT || c->v[4]>GRAOS_LABEL_ALIGN_RIGHT) {
            r=-6;
            break;
        }
        if(guiSetLabelStyle(w,c->v[1],c->v[2],c->v[3],c->v[4])) {
            v->dirty=1;
            r=0;
        } else r=-7;
        break;

    case GRAOS_GSID_REMOVELABEL:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(w && w->pid==m->sndPID && guiRemoveLabel(w,c->v[1])) {
            v->dirty=1;
            r=0;
        } else r=-7;
        break;

    case GRAOS_GSID_CREATEBITMAP:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(!w || w->pid!=m->sndPID) { r=-7; break; }
        if(c->v[1]<0 || c->v[2]<0 || c->v[3]<=0 || c->v[4]<=0 ||
           c->v[3]>GRAOS_BITMAP_MAX_WIDTH || c->v[4]>GRAOS_BITMAP_MAX_HEIGHT ||
           c->v[1]+c->v[3]>w->width || c->v[2]+c->v[4]>w->height ||
           (c->v[6]!=GRAOS_BLIT_OPAQUE && c->v[6]!=GRAOS_BLIT_ALPHA) || !c->ptr[0]) {
            r=-6;
            break;
        }
        {
            int bytes=c->v[3]*c->v[4]*4;
            GRAOS_PIXEL *tmp=(GRAOS_PIXEL*)malloc((size_t)bytes);
            if(!tmp) { r=-5; break; }
            if(graos_copy_from_thread(m->sndPID,c->ptr[0],tmp,(DWORD)bytes)<0) {
                free(tmp); r=-4; break;
            }
            if(guiCreateBitmap(w,c->v[1],c->v[2],c->v[3],c->v[4],c->v[5],c->v[6],tmp)) {
                v->dirty=1; r=0;
            } else r=-5;
            free(tmp);
        }
        break;

    case GRAOS_GSID_SETBITMAPDATA:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(!w || w->pid!=m->sndPID || !c->ptr[0]) { r=-7; break; }
        {
            BITMAP *b=guiGetBitmap(w,c->v[1]);
            if(!b || c->v[2]!=b->bytes) { r=-6; break; }
            if(graos_copy_from_thread(m->sndPID,c->ptr[0],b->pixels,(DWORD)b->bytes)<0) { r=-4; break; }
            v->dirty=1; r=0;
        }
        break;

    case GRAOS_GSID_REMOVEBITMAP:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(w && w->pid==m->sndPID && guiRemoveBitmap(w,c->v[1])) {
            v->dirty=1; r=0;
        } else r=-7;
        break;

    case GRAOS_GSID_POLLEVENT:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(!w || w->pid!=m->sndPID) { r=-7; break; }
        {
            GRAOSEVENT ev;
            int values[4];
            if(guiPopWindowEvent(w,&ev)) {
                values[0]=ev.id; values[1]=ev.v0; values[2]=ev.v1; values[3]=ev.v2;
                response_ex(m,1,wid,values,4);
            } else response_ex(m,0,wid,NULL,0);
            return;
        }


    case GRAOS_GSID_GETMOUSESTATE:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(!w || w->pid!=m->sndPID) { r=-7; break; }
        {
            int values[4];
            int mx=v->x-w->x-w->fb_x;
            int my=v->y-w->y-w->captionHeight-w->fb_y;
            int inside=(w->framebuffer && mx>=0 && my>=0 &&
                        mx<w->fb_width && my<w->fb_height) ? 1 : 0;
            values[0]=mx; values[1]=my; values[2]=v->buttons; values[3]=inside;
            response_ex(m,0,wid,values,4);
            return;
        }

    case GRAOS_GSID_CREATETEXTBOX:
        wid=c->v[0]; w=GetWindowPTR(wid);
        if(!w || w->pid!=m->sndPID) { r=-7; break; }
        if(c->v[1]<0 || c->v[2]<0 || c->v[3]<16 || c->v[4]<12 ||
           c->v[1]+c->v[3]>w->width || c->v[2]+c->v[4]>w->height ||
           c->v[6]<=0 || c->v[6]>=GRAOS_TEXTBOX_TEXT_MAX) { r=-6; break; }
        if(guiCreateTextBox(w,c->v[1],c->v[2],c->v[3],c->v[4],c->v[5],c->v[6],c->str)) { v->dirty=1; r=0; } else r=-5;
        break;

    case GRAOS_GSID_SETTEXTBOXTEXT:
        wid=c->v[0]; w=GetWindowPTR(wid);
        if(w && w->pid==m->sndPID && guiSetTextBoxText(w,c->v[1],c->str)) { v->dirty=1; r=0; } else r=-7;
        break;

    case GRAOS_GSID_GETTEXTBOXTEXT:
        wid=c->v[0]; w=GetWindowPTR(wid);
        if(!w || w->pid!=m->sndPID) { response_text(m,-7,wid,""); return; }
        { char text[GRAOS_TEXTBOX_TEXT_MAX];
          if(guiGetTextBoxText(w,c->v[1],text,sizeof(text))) response_text(m,0,wid,text);
          else response_text(m,-7,wid,"");
          return; }

    case GRAOS_GSID_REMOVETEXTBOX:
        wid=c->v[0]; w=GetWindowPTR(wid);
        if(w && w->pid==m->sndPID && guiRemoveTextBox(w,c->v[1])) { v->dirty=1; r=0; } else r=-7;
        break;

    case GRAOS_GSID_ADDFRAMEBUFFER:
        wid=c->v[0];
        w=GetWindowPTR(wid);
        if(!w || w->pid!=m->sndPID) {
            r=-7;
            break;
        }

        /* A terminal framebuffer is not client pixel memory.  It is an ID
         * for the kernel's real 80x25 terminal in term.c.  GraOS snapshots
         * that screen through SYS_copyterminal while drawing the window. */
        if(c->v[6]==GRAOS_SURFACE_TERMINAL) {
            if(c->v[7]<0 || c->v[7]>=256 ||
               c->v[3]<=0 || c->v[3]>80 || c->v[4]<=0 || c->v[4]>25 ||
               (c->v[5]!=0 && c->v[5]!=32)) {
                r=-6;
                break;
            }
            if(w->framebuffer) {
                free(w->framebuffer);
                w->framebuffer=NULL;
            }
            w->framebuffer_user=0;
            w->framebuffer_owner=0;
            w->fb_type=GRAOS_SURFACE_TERMINAL;
            w->terminal_id=c->v[7];
            w->terminal_pid=0;
            w->fb_x=c->v[1];
            w->fb_y=c->v[2];
            w->fb_width=c->v[3];
            w->fb_height=c->v[4];
            w->fb_bpp=0;
            w->fb_stride=c->v[3];
            v->dirty=1;
            r=0;
            break;
        }

        /* Bitmap client framebuffer.  GraOS V34 accepts RGBA32 surfaces only. */
        if(c->v[6]==GRAOS_SURFACE_BITMAP && c->ptr[0] &&
           c->v[3]>0 && c->v[4]>0 && c->v[5]==32 &&
           c->v[3]<=GRAOS_WIDTH && c->v[4]<=GRAOS_HEIGHT) {
            DWORD bytes=(DWORD)c->v[3]*(DWORD)c->v[4]*4UL;
            if(bytes>0 && bytes<=GRAOS_FRAME_BYTES) {
                GRAOS_PIXEL *newfb=(GRAOS_PIXEL*)malloc((size_t)bytes);
                if(!newfb) {
                    r=-5;
                    break;
                }
                if(graos_copy_from_thread(m->sndPID,c->ptr[0],newfb,bytes)<0) {
                    free(newfb);
                    r=-4;
                    break;
                }
                if(w->framebuffer)
                    free(w->framebuffer);
                w->framebuffer=newfb;
                w->framebuffer_user=(DWORD)c->ptr[0];
                w->framebuffer_owner=m->sndPID;
                w->fb_type=GRAOS_SURFACE_BITMAP;
                w->terminal_id=-1;
                w->terminal_pid=0;
                w->fb_x=c->v[1];
                w->fb_y=c->v[2];
                w->fb_width=c->v[3];
                w->fb_height=c->v[4];
                w->fb_bpp=32;
                w->fb_stride=c->v[3];
                v->dirty=1;
                r=0;
            }
        }
        break;

    default:
        r=-3;
        break;
    }

    response(m,r,wid);
}

void guiServerPoll(VMODE *v)
{
#if GRAOS_ENABLE_SERVER
    int i;
    MSG m;

    for(i=0;i<GRAOS_SERVER_BURST;i++) {
        memset((char*)&m,0,sizeof(m));
        if(!receiveMessage(&m))
            break;
        handle_message(v,&m);
    }
#else
    (void)v;
#endif
}
