/* launcher.c - external GraOS application launcher, V67.8.57.10.3 */
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/process.h>
#include "guiLaunchCompat.h"
SYSMEMREQ(APPRAM_256K)
typedef struct{int id;const char *text;const char *cmd;}ITEM;
#define LAUNCHER_LABEL 3190
#define LAUNCHER_CMD 3191
#define LAUNCHER_RUN 3192
static const ITEM items[]={
 {3001,"Terminal","/bin/terminal.bin"},{3016,"Squirrel Shell","/bin/terminal.bin /bin/sqsh.bin"},{3002,"File Manager","/bin/filer.bin"},
 {3003,"Text Editor","/bin/terminal.bin /bin/edit.bin"},{3004,"Task Manager","/bin/terminal.bin /bin/top.bin"},
 {3005,"Control Panel","/bin/controlpanel.bin"},{3006,"Process List","/bin/terminal.bin /bin/ps.bin"},
 {3007,"File List","/bin/terminal.bin /bin/ls.bin"},{3008,"Snake","/bin/snake.bin"},
 {3009,"Plasma","/bin/plasma.bin"},{3017,"Plasma II","/bin/plasma2.bin"},{3018,"VGA Plasma","/bin/vgaplasma.bin"},{3010,"Squirrel Family","/bin/picture.bin"},
 {3011,"Audio","/bin/terminal.bin /bin/sound.bin"},{3012,"Setup","/bin/terminal.bin /bin/setup.bin"},
 {3013,"Label Demo","/bin/labeldemo.bin"},{3014,"Squirrel Bitmap","/bin/bitmapdemo.bin"},{3015,"TextBox Demo","/bin/textboxdemo.bin"},
 {0,NULL,NULL}};
static int launch_cmd(const char *s){if(!s)return 0;return graos_bgexec_command(s,"/");}

/* Check every absolute executable token before exposing a launcher entry.
 * Optional/CD-only tools stay hidden; core windowed demos live in /bin. */
static int file_available(const char *path)
{
    return graos_file_available(path);
}

static int command_available(const char *cmd)
{
    char word[160]; int i=0,j,n;
    if(!cmd || !*cmd) return 0;
    while(cmd[i]) {
        while(cmd[i]==' '||cmd[i]=='\t') i++;
        if(!cmd[i]) break;
        j=0;
        while(cmd[i] && cmd[i]!=' ' && cmd[i]!='\t') {
            if(j<(int)sizeof(word)-1) word[j++]=cmd[i];
            i++;
        }
        word[j]=0;
        n=(int)strlen(word);
        if(word[0]=='/' && n>=4 && !strcmp(word+n-4,".bin") && !file_available(word))
            return 0;
    }
    return 1;
}

static const ITEM *find_item(int id)
{
    int i; for(i=0;items[i].id;i++) if(items[i].id==id) return &items[i];
    return NULL;
}

int main(void)
{
    GUICMD ev; int wid,i,x,y,pid,er,visible=0,server_closed=0; char msg[128]; const ITEM *it;
    if(connectGraos()!=0)return 1;
    wid=createWindow(-1,-1,500,500,"JTMOS Applications",GRAOS_WINDOW_STANDARD);if(wid<0)return 2;
    createLabel(wid,18,22,464,16,LAUNCHER_LABEL,0,7,GRAOS_LABEL_ALIGN_LEFT,"Installed applications");
    createTextBox(wid,18,44,364,24,LAUNCHER_CMD,110,"");
    createButton(wid,382,44,480,68,LAUNCHER_RUN,"Run");
    for(i=0;items[i].id;i++) {
        if(!command_available(items[i].cmd)) continue;
        x=(visible&1)?258:18; y=82+(visible/2)*38;
        createButton(wid,x,y,x+224,y+28,items[i].id,items[i].text);
        visible++;
    }
    createButton(wid,258,82+((visible+1)/2)*38,482,110+((visible+1)/2)*38,3099,"Close");
    refreshWindow(wid);
    for(;;) {
        while((er=JtmosGraOSPollEvent(wid,&ev))>0) {
            if(ev.id==GRAOS_GSID_EXIT){server_closed=1;goto done;}
            if(ev.id==GRAOS_GSID_TEXTBOX_ENTER && ev.v[0]==LAUNCHER_CMD) {
                char cmd[128]; cmd[0]=0; getTextBoxText(wid,LAUNCHER_CMD,cmd,sizeof(cmd));
                if(cmd[0]) { pid=launch_cmd(cmd); snprintf(msg,sizeof(msg),pid>0?"Launched: %s":"Launch failed: %s",cmd); setLabelText(wid,LAUNCHER_LABEL,msg); }
                continue;
            }
            if(ev.id!=GRAOS_GSID_BUTTON) continue;
            if(ev.v[0]==3099) goto done;
            if(ev.v[0]==LAUNCHER_RUN) {
                char cmd[128]; cmd[0]=0; getTextBoxText(wid,LAUNCHER_CMD,cmd,sizeof(cmd));
                if(cmd[0]) { pid=launch_cmd(cmd); snprintf(msg,sizeof(msg),pid>0?"Launched: %s":"Launch failed: %s",cmd); setLabelText(wid,LAUNCHER_LABEL,msg); }
                continue;
            }
            it=find_item(ev.v[0]);
            if(it && it->cmd) { pid=launch_cmd(it->cmd); snprintf(msg,sizeof(msg),pid>0?"Launched: %s":"Launch failed: %s",it->text); setLabelText(wid,LAUNCHER_LABEL,msg); }
        }
        if(er<0){server_closed=1;goto done;}
        SwitchToThread(); Sleep(10);
    }
done: if(!server_closed)closeWindow(wid); return 0;
}
