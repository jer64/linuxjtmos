/* guiWidget.c - common native GraOS widget base, V67.8 / GraOS V32. */
#include "guiWidget.h"
#include <string.h>
void guiWidgetInit(GRAOS_WIDGET *w,int type,int id,int x,int y,int width,int height,int owner,unsigned int flags)
{
    if(!w) return;
    memset(w,0,sizeof(*w));
    w->type=type; w->id=id; w->x=x; w->y=y; w->width=width; w->height=height;
    w->owner_window=owner; w->flags=flags;
    w->visible=(flags&GRAOS_WIDGET_VISIBLE)?1:0;
    w->enabled=(flags&GRAOS_WIDGET_ENABLED)?1:0;
    w->focusable=(flags&GRAOS_WIDGET_FOCUSABLE)?1:0;
}
int guiWidgetContains(const GRAOS_WIDGET *w,int x,int y)
{
    if(!w || !w->visible || !w->enabled || w->width<=0 || w->height<=0) return 0;
    return x>=w->x && y>=w->y && x<w->x+w->width && y<w->y+w->height;
}
void guiWidgetSetBounds(GRAOS_WIDGET *w,int x,int y,int width,int height)
{ if(w){w->x=x;w->y=y;w->width=width;w->height=height;w->flags|=GRAOS_WIDGET_DIRTY;} }
void guiWidgetSetVisible(GRAOS_WIDGET *w,int visible)
{ if(w){w->visible=visible?1:0;if(w->visible)w->flags|=GRAOS_WIDGET_VISIBLE;else w->flags&=~GRAOS_WIDGET_VISIBLE;w->flags|=GRAOS_WIDGET_DIRTY;} }
void guiWidgetSetEnabled(GRAOS_WIDGET *w,int enabled)
{ if(w){w->enabled=enabled?1:0;if(w->enabled)w->flags|=GRAOS_WIDGET_ENABLED;else w->flags&=~GRAOS_WIDGET_ENABLED;w->flags|=GRAOS_WIDGET_DIRTY;} }
