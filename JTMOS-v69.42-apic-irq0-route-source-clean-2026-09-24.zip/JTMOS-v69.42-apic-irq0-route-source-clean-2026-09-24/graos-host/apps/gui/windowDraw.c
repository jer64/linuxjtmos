#include "windowDraw.h"
#include "wdb.h"
#include "guiRect.h"
#include "guifont.h"
#include "guiLabel.h"
#include "guiBitmap.h"
#include "guiBlit.h"
#include "guiTextBox.h"
#include "egafont_data.h"
#include "guiChrome.h"
#include "guiWelcome.h"
#define GRAOS_TERM_COLS 80
#define GRAOS_TERM_ROWS 25
#define GRAOS_TERM_BYTES (GRAOS_TERM_COLS*GRAOS_TERM_ROWS*2)
static BYTE terminal_snapshot[GRAOS_TERM_BYTES];
static void draw_ega_glyph(VMODE*v,int x,int y,BYTE ch,BYTE attr)
{int yy,xx;BYTE bits,fg=(BYTE)(attr&15),bg=(BYTE)((attr>>4)&7);const BYTE*glyph=&graos_ega_font[((unsigned int)ch)*EGA_FONT_HEIGHT];GRAOS_PIXEL fgp=graosIndexToPixel(fg),bgp=graosIndexToPixel(bg);if(!v||!v->buf)return;for(yy=0;yy<EGA_FONT_HEIGHT;yy++){bits=glyph[yy];for(xx=0;xx<EGA_FONT_WIDTH;xx++){int dx=x+xx,dy=y+yy;if(dx>=0&&dx<v->width&&dy>=0&&dy<v->height)v->buf[dy*v->width+dx]=(bits&(0x80>>xx))?fgp:bgp;}}}
static void draw_terminal(VMODE*v,WINDOW*w)
{int row,col,cols,rows,base_x,base_y,cur,cx,cy,client_w,client_h,max_cols,max_rows;if(!v||!w||w->terminal_id<0)return;if(CopyThreadTerminal(w->terminal_id,terminal_snapshot)!=0)return;base_x=w->x+w->fb_x;base_y=w->y+w->captionHeight+w->fb_y;client_w=w->width-w->fb_x;client_h=w->height-w->captionHeight-w->fb_y;if(client_w<=0||client_h<=0)return;fillRect(v,base_x,base_y,base_x+client_w-1,base_y+client_h-1,0);cols=w->fb_width;rows=w->fb_height;if(cols>80)cols=80;if(rows>25)rows=25;max_cols=client_w/EGA_FONT_WIDTH;max_rows=client_h/EGA_FONT_HEIGHT;if(cols>max_cols)cols=max_cols;if(rows>max_rows)rows=max_rows;if(cols<=0||rows<=0)return;for(row=0;row<rows;row++)for(col=0;col<cols;col++){int off=(row*80+col)*2;BYTE ch=terminal_snapshot[off],attr=terminal_snapshot[off+1];if(attr==0)attr=7;draw_ega_glyph(v,base_x+col*EGA_FONT_WIDTH,base_y+row*EGA_FONT_HEIGHT,ch,attr);}cur=GetCursorLocation(w->terminal_id);cx=cur&255;cy=(cur>>8)&255;if(cx>=0&&cx<cols&&cy>=0&&cy<rows){int px=base_x+cx*EGA_FONT_WIDTH,py=base_y+cy*EGA_FONT_HEIGHT+EGA_FONT_HEIGHT-2;fillRect(v,px,py,px+EGA_FONT_WIDTH-1,py+1,15);}}
static void draw_framebuffer(VMODE*v,WINDOW*w)
{int yy,cw,ch,dx,dy,client_y;if(!v||!w||!w->framebuffer||w->fb_bpp!=32)return;client_y=w->captionHeight;cw=w->fb_width;ch=w->fb_height;dx=w->x+w->fb_x;dy=w->y+client_y+w->fb_y;if(cw<=0||ch<=0)return;guiBlit(v,dx,dy,cw,ch,w->framebuffer,w->fb_stride,GRAOS_BLIT_OPAQUE);}
static void buttonDraw(VMODE*v,WINDOW*w,BUTTON*b){if(!v||!w||!b||!b->widget.visible)return;guiChromeDrawButton(v,w,b);}

/* A GraOS window is opaque: guiChromeDrawWindow() fills its complete rectangle
 * before the client surface and child controls are painted.  This lets the
 * compositor reject a lower window when higher visible windows cover every
 * pixel of its on-screen rectangle. */
static int window_drawable(VMODE *v,const WINDOW *w)
{
    int x2,y2;
    if(!v||!w||w->isfree||w->minimized||!w->root.visible)return 0;
    if(w->width<=0||w->height<=0)return 0;
    x2=w->x+w->width;
    y2=w->y+w->height;
    if(x2<=0||y2<=0||w->x>=v->width||w->y>=v->height)return 0;
    return 1;
}

static int clipped_window_rect(VMODE *v,const WINDOW *w,int *x1,int *y1,int *x2,int *y2)
{
    int ax,ay,bx,by;
    if(!window_drawable(v,w))return 0;
    ax=w->x;ay=w->y;bx=w->x+w->width;by=w->y+w->height;
    if(ax<0)ax=0;if(ay<0)ay=0;if(bx>v->width)bx=v->width;if(by>v->height)by=v->height;
    if(ax>=bx||ay>=by)return 0;
    if(x1)*x1=ax;if(y1)*y1=ay;if(x2)*x2=bx;if(y2)*y2=by;
    return 1;
}

/* Exact rectangle-union test without heap allocation.  Y edges split the
 * target into horizontal bands; within each band the X intervals of every
 * higher opaque window are merged.  Only a completely covered window is
 * culled.  Partially visible windows are still painted normally. */
static int window_fully_occluded(VMODE *v,const WINDOW *target)
{
    int tx1,ty1,tx2,ty2;
    int yedge[2+N_MAX_WINDOWS*2],ny=0;
    int i,j,k;
    if(!clipped_window_rect(v,target,&tx1,&ty1,&tx2,&ty2))return 1;
    yedge[ny++]=ty1;yedge[ny++]=ty2;
    for(i=0;i<wdb.n_windows;i++){
        WINDOW *c=&wdb.w[i];int cx1,cy1,cx2,cy2;
        if(c==target||c->z<=target->z||!clipped_window_rect(v,c,&cx1,&cy1,&cx2,&cy2))continue;
        if(cx2<=tx1||cx1>=tx2||cy2<=ty1||cy1>=ty2)continue;
        if(cy1<ty1)cy1=ty1;if(cy2>ty2)cy2=ty2;
        yedge[ny++]=cy1;yedge[ny++]=cy2;
    }
    for(i=1;i<ny;i++){int t=yedge[i];j=i-1;while(j>=0&&yedge[j]>t){yedge[j+1]=yedge[j];j--;}yedge[j+1]=t;}
    for(i=0;i<ny-1;i++){
        int y0=yedge[i],y1=yedge[i+1],cursor=tx1;
        int ix1[N_MAX_WINDOWS],ix2[N_MAX_WINDOWS],n=0;
        if(y1<=y0)continue;
        for(j=0;j<wdb.n_windows;j++){
            WINDOW *c=&wdb.w[j];int cx1,cy1,cx2,cy2;
            if(c==target||c->z<=target->z||!clipped_window_rect(v,c,&cx1,&cy1,&cx2,&cy2))continue;
            if(cy1>y0||cy2<y1||cx2<=tx1||cx1>=tx2)continue;
            if(cx1<tx1)cx1=tx1;if(cx2>tx2)cx2=tx2;
            if(n<N_MAX_WINDOWS){ix1[n]=cx1;ix2[n]=cx2;n++;}
        }
        for(j=1;j<n;j++){
            int a=ix1[j],b=ix2[j];k=j-1;
            while(k>=0&&ix1[k]>a){ix1[k+1]=ix1[k];ix2[k+1]=ix2[k];k--;}
            ix1[k+1]=a;ix2[k+1]=b;
        }
        for(j=0;j<n&&cursor<tx2;j++){
            if(ix1[j]>cursor)break;
            if(ix2[j]>cursor)cursor=ix2[j];
        }
        if(cursor<tx2)return 0;
    }
    return 1;
}

void windowDraw(VMODE*v,WINDOW*w)
{
    int i;
    if(!window_drawable(v,w))return;
    guiChromeDrawWindow(v,w);
    if(w->type&GRAOS_WINDOW_WELCOME_STYLE)guiDrawWelcomeDecor(v,w);
    if(w->fb_type==GRAOS_SURFACE_TERMINAL)draw_terminal(v,w);else draw_framebuffer(v,w);
    if(w->qmsg[0])DrawText(v,w->qmsg,w->x+8,w->y+w->captionHeight+12,0,-1);
    for(i=0;i<w->n_bitmaps;i++)if(w->bitmap[i].widget.visible)guiDrawBitmap(v,w,&w->bitmap[i]);
    for(i=0;i<w->n_labels;i++)if(w->label[i].widget.visible)guiDrawLabel(v,w,&w->label[i]);
    for(i=0;i<w->n_textboxes;i++)if(w->textbox[i].widget.visible)guiDrawTextBox(v,w,&w->textbox[i]);
    for(i=0;i<w->n_buttons;i++)if(w->button[i].widget.visible)buttonDraw(v,w,&w->button[i]);
    w->root.flags&=~GRAOS_WIDGET_DIRTY;
}

void drawAllWindows(VMODE*v)
{
    int z,i,bestz,lastz=-2147483647,best;
    if(!v)return;
    for(z=0;z<wdb.n_windows;z++){
        best=-1;bestz=2147483647;
        for(i=0;i<wdb.n_windows;i++)
            if(window_drawable(v,&wdb.w[i])&&wdb.w[i].z>lastz&&wdb.w[i].z<bestz){best=i;bestz=wdb.w[i].z;}
        if(best<0)break;
        if(!window_fully_occluded(v,&wdb.w[best]))windowDraw(v,&wdb.w[best]);
        lastz=bestz;
    }
}
