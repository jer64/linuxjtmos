#ifndef __INCLUDED_GUIRECT_H__
#define __INCLUDED_GUIRECT_H__
#include "graos.h"
void fillRect(VMODE*,int,int,int,int,int);
void drawRect(VMODE*,int,int,int,int,int);
void fillRectRGBA(VMODE*,int,int,int,int,GRAOS_PIXEL);
void drawRectRGBA(VMODE*,int,int,int,int,GRAOS_PIXEL);
#endif
