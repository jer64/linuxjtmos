/* controlpanel.c - Windows 98 inspired native GraOS Control Panel. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/process.h>
#include "guiLaunchCompat.h"
SYSMEMREQ(APPRAM_256K)
#define CP_TERMINAL 2001
#define CP_EDITOR 2002
#define CP_FILER 2003
#define CP_TOP 2004
#define CP_BLUE 2010
#define CP_GREEN 2011
#define CP_DARK 2012
#define CP_CLOSE 2099
#define CP_LABEL_TITLE 2100
#define CP_LABEL_DESC1 2101
#define CP_LABEL_DESC2 2102
#define CP_LABEL_DESC3 2103
#define CP_LABEL_DESC4 2104
#define CP_LABEL_DESC5 2105
#define CP_LABEL_STATUS 2110

static int launch(const char *cmd)
{
    int p=graos_bgexec_command(cmd,"/");
    if(p<=0) printf("controlpanel: cannot launch %s\n",cmd);
    return p;
}
static void status(int wid,const char *text){setLabelText(wid,CP_LABEL_STATUS,text);}

int main(void)
{
    GUICMD ev;
    int wid,r,er,server_closed=0;
    int icon_style=GRAOS_BUTTON_ICON_VIEW;

    if(connectGraos()!=0) return 1;
    wid=createWindow(-1,-1,740,430,"JTMOS Control Panel",
                     GRAOS_WINDOW_STANDARD|GRAOS_WINDOW_CONTROL_PANEL_STYLE);
    if(wid<0) return 2;

    /* Left information pane, intentionally sparse like Windows 98. */
    createLabel(wid,20,42,168,16,CP_LABEL_TITLE,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_LEFT,"CONTROL PANEL");
    createLabel(wid,20,94,168,12,CP_LABEL_DESC1,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_LEFT,"Use these settings to");
    createLabel(wid,20,108,168,12,CP_LABEL_DESC2,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_LEFT,"open JTMOS tools and");
    createLabel(wid,20,122,168,12,CP_LABEL_DESC3,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_LEFT,"change the desktop.");
    createLabel(wid,20,158,168,12,CP_LABEL_DESC4,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_LEFT,"Select an icon to open");
    createLabel(wid,20,172,168,12,CP_LABEL_DESC5,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_LEFT,"a component.");
    createLabel(wid,20,365,168,14,CP_LABEL_STATUS,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_LEFT,"Ready");

    /* Right icon grid.  14px gaps and 24px icons leave enough breathing room. */
    createButtonStyled(wid,220,48,327,127,CP_TERMINAL,
                       icon_style|GRAOS_BUTTON_ICON(GRAOS_ICON_TERMINAL),"Terminal");
    createButtonStyled(wid,342,48,449,127,CP_FILER,
                       icon_style|GRAOS_BUTTON_ICON(GRAOS_ICON_FOLDER),"File Manager");
    createButtonStyled(wid,464,48,571,127,CP_EDITOR,
                       icon_style|GRAOS_BUTTON_ICON(GRAOS_ICON_EDITOR),"Text Editor");
    createButtonStyled(wid,586,48,693,127,CP_TOP,
                       icon_style|GRAOS_BUTTON_ICON(GRAOS_ICON_TASKS),"Task Manager");
    createButtonStyled(wid,220,153,327,232,CP_BLUE,
                       icon_style|GRAOS_BUTTON_ICON(GRAOS_ICON_DISPLAY),"Blue Desktop");
    createButtonStyled(wid,342,153,449,232,CP_GREEN,
                       icon_style|GRAOS_BUTTON_ICON(GRAOS_ICON_DESKTOP),"Green Desktop");
    createButtonStyled(wid,464,153,571,232,CP_DARK,
                       icon_style|GRAOS_BUTTON_ICON(GRAOS_ICON_SETTINGS),"Dark Desktop");

    refreshWindow(wid);
    for(;;) {
        while((er=JtmosGraOSPollEvent(wid,&ev))>0) {
            if(ev.id==GRAOS_GSID_EXIT) { server_closed=1; goto out; }
            if(ev.id!=GRAOS_GSID_BUTTON) continue;
            switch(ev.v[0]) {
            case CP_TERMINAL:r=launch("/bin/terminal.bin");status(wid,r>0?"Terminal launched":"Terminal launch failed");break;
            case CP_EDITOR:r=launch("/bin/terminal.bin /bin/edit.bin");status(wid,r>0?"Text editor launched":"Text editor launch failed");break;
            case CP_FILER:r=launch("/bin/filer.bin");status(wid,r>0?"File manager launched":"File manager launch failed");break;
            case CP_TOP:r=launch("/bin/terminal.bin /bin/top.bin");status(wid,r>0?"Task manager launched":"Task manager launch failed");break;
            case CP_BLUE:JtmosGraOSSetDesktopColor(BLUE);status(wid,"Desktop color: blue");break;
            case CP_GREEN:JtmosGraOSSetDesktopColor(GREEN);status(wid,"Desktop color: green");break;
            case CP_DARK:JtmosGraOSSetDesktopColor(DARKGRAY);status(wid,"Desktop color: dark gray");break;
            case CP_CLOSE:goto out;
            }
        }
        if(er<0) { server_closed=1; goto out; }
        SwitchToThread();
        Sleep(10);
    }
out:
    if(!server_closed) closeWindow(wid);
    return 0;
}
