#include "windowMoving.h"
#include "wdb.h"
#include "windowFunc.h"
#include "guiWidget.h"
#include "guiTextBox.h"
#include "guiFocus.h"

static void send_window_mouse(WINDOW *w,int sx,int sy,int button)
{
    int cx,cy;
    if(!w || w->pid<=0 || !w->framebuffer) return;
    if(w->tiled || w->maximized) {
        int lx,ly,dw,dh,rx,ry;
        if(!guiLayoutSurfaceRect(w,&lx,&ly,&dw,&dh) || dw<=0 || dh<=0) return;
        rx=sx-(w->x+lx); ry=sy-(w->y+ly);
        if(rx<0 || ry<0 || rx>=dw || ry>=dh) return;
        cx=(int)(((long)rx*(long)w->fb_width)/(long)dw);
        cy=(int)(((long)ry*(long)w->fb_height)/(long)dh);
    } else {
        cx=sx-w->x-w->fb_x;
        cy=sy-w->y-w->captionHeight-w->fb_y;
        if(cx<0 || cy<0 || cx>=w->fb_width || cy>=w->fb_height) return;
    }

    /* V69.0 input hotfix: client mouse events must use the same per-window
     * GraOS event queue as native buttons/textboxes.  The old direct Postman
     * send could be lost when the client's tiny mailbox was occupied by a
     * synchronous refresh/poll response, making framebuffer UIs look alive
     * but completely unclickable.  POLLEVENT drains this queue reliably and
     * preserves the window association. */
    guiQueueWindowEvent(w,GRAOS_GSID_MOUSEBUTTON,cx,cy,button);
}

static void clamp_window(VMODE *v,WINDOW *w)
{
    int max_x,max_y;
    if(!v || !w) return;
    max_x=v->width-w->width;
    max_y=(v->height-GRAOS_PANEL_HEIGHT)-w->height;
    if(max_x<0) max_x=0;
    if(max_y<0) max_y=0;
    if(w->x<0) w->x=0;
    if(w->y<0) w->y=0;
    if(w->x>max_x) w->x=max_x;
    if(w->y>max_y) w->y=max_y;
    guiWidgetSetBounds(&w->root,w->x,w->y,w->width,w->height);
}
void windowInput(VMODE *v)
{
    int down=(v->buttons&1)!=0, was=(v->last_buttons&1)!=0;
    WINDOW *bw=NULL; BUTTON *b=getButtonUnderCursor(v,&bw);
    if(down&&!was){
        if(b){v->pressed_button=b;v->pressed_window=bw;b->pressed=1;SelectWindow(v,bw);guiFocusButton(v,bw,b);v->dirty=1;}
        else {
            WINDOW *cw=getWindowUnderCursor(v,0);
            if(cw){
                TEXTBOX *tb; int local_x=v->x-cw->x,local_y=v->y-cw->y;
                SelectWindow(v,cw);
                tb=guiGetTextBoxAt(cw,local_x,local_y);
                if(tb) {
                    guiFocusTextBox(v,cw,tb);
                } else if(v->y < cw->y+cw->captionHeight){
                    guiBlurTextBox(v,cw);
                    v->movingWindow=1;v->movwin=cw;v->origx=v->x;v->origy=v->y;v->oldx=cw->x;v->oldy=cw->y;
                } else {
                    send_window_mouse(cw,v->x,v->y,1);
                }
            }
        }
    }
    if(down&&v->movingWindow&&v->movwin){v->movwin->x=v->oldx+(v->x-v->origx);v->movwin->y=v->oldy+(v->y-v->origy);clamp_window(v,v->movwin);v->dirty=1;}
    if(!down&&was){
        if(v->pressed_button){BUTTON *pb=v->pressed_button;WINDOW *pw=v->pressed_window; if(b==pb&&bw==pw)onButtonClick(v,pw,pb); if(pw&&!pw->isfree)pb->pressed=0; v->pressed_button=NULL;v->pressed_window=NULL;v->dirty=1;}
        v->movingWindow=0;v->movwin=NULL;
    }
}
