#ifndef __INCLUDED_GUILABEL_H__
#define __INCLUDED_GUILABEL_H__
#include "graos.h"

#define GRAOS_INTERNAL_STATUS_LABEL_ID 65000

LABEL *guiCreateLabel(WINDOW *w,int x,int y,int width,int height,int id,
                      int fg,int bg,int align,const char *text);
LABEL *guiGetLabel(WINDOW *w,int id);
int guiSetLabelText(WINDOW *w,int id,const char *text);
int guiSetLabelStyle(WINDOW *w,int id,int fg,int bg,int align);
int guiRemoveLabel(WINDOW *w,int id);
void guiDrawLabel(VMODE *v,WINDOW *w,LABEL *label);

#endif
