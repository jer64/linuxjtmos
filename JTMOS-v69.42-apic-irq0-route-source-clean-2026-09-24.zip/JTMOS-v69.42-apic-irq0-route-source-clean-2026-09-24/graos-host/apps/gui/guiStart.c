#include "guiStart.h"
#include "wdb.h"
#include "windowFunc.h"
#include "guiLabel.h"
#include "guifont.h"
#include "guiArrow.h"
#include "guiDesktopDraw.h"
#include "guiServer.h"
#include "guiChrome.h"
#include "guiStartup.h"
#include "guiWelcome.h"
#include "guiLaunchCompat.h"
#include <unistd.h>

static void get_workdir(char *cwd,int cap)
{
    if(!cwd || cap<=0) return;
    if(!getcwd(cwd,(size_t)cap)) {
        cwd[0]='/';
        if(cap>1) cwd[1]=0;
    }
}

static WINDOW *find_command_prompt(void)
{
    int i;
    for(i=0;i<wdb.n_windows;i++) {
        WINDOW *w=&wdb.w[i];
        if(!w->isfree && w->fb_type==GRAOS_SURFACE_TERMINAL &&
           !strcmp(w->caption,"JTMOS Command Prompt - Squirrel Shell"))
            return w;
    }
    return NULL;
}

int guiStartTerminalProgram(VMODE *v,const char *program,const char *caption)
{
    char cwd[256];
    WINDOW *w;
    int ter,pid,wid;

    if(!v || !program || !*program) return 0;
    /* Avoid allocating a GraOS-owned terminal for a program that is not even
     * installed.  Without a userspace FreeTerminal syscall that would leak a
     * dynamic terminal until the GraOS server itself exits. */
    if(!graos_file_available(program)) {
        printf("GraOS: program not installed: %s.\n",program);
        return 0;
    }
    ter=CreateTerminal();
    if(ter<0) {
        printf("GraOS: cannot create terminal for %s.\n",program);
        return 0;
    }

    get_workdir(cwd,sizeof(cwd));
    pid=graos_bgexec_ex_command(program,cwd,ter);
    if(pid<=0) {
        printf("GraOS: %s could not be launched.\n",program);
        return 0;
    }
    if(SetTerminalOwner(ter,pid)!=0) {
        printf("GraOS: cannot transfer terminal %d ownership to PID %d.\n",ter,pid);
        KillThread(pid);
        return 0;
    }

    /* Native terminal geometry remains 80x25 at 8x16 pixels (640x400),
     * wrapped in a 640x436 window.  On the 1024x768 desktop centre this
     * fixed-size terminal instead of pinning it to the old 640x480 edges. */
    wid=guiCreateWindow(v,(GRAOS_WIDTH-640)/2,
                        (GRAOS_HEIGHT-GRAOS_PANEL_HEIGHT-436)/2,
                        640,436,
                        caption?caption:"JTMOS Terminal",GRAOS_WINDOW_STANDARD);
    w=GetWindowPTR(wid);
    if(!w) {
        KillThread(pid);
        return 0;
    }

    w->pid=0;                 /* internal GraOS window */
    guiCreateLabel(w,4,20,632,16,64010,0,7,GRAOS_LABEL_ALIGN_LEFT,
                   "80x25 VGA terminal - native 8x16 font");
    w->fb_type=GRAOS_SURFACE_TERMINAL;
    w->terminal_id=ter;
    w->terminal_pid=pid;
    w->fb_x=0;
    w->fb_y=16;
    w->fb_width=80;
    w->fb_height=25;
    w->fb_bpp=0;
    w->fb_stride=80;
    w->qmsg[0]=0;
    v->dirty=1;
    return 1;
}

void guiReapExitedTerminalPrograms(VMODE *v)
{
    int i;
    if(!v) return;
    for(i=wdb.n_windows-1;i>=0;i--) {
        WINDOW *w=&wdb.w[i];
        if(w->isfree || w->pid!=0 || w->fb_type!=GRAOS_SURFACE_TERMINAL ||
           w->terminal_pid<=0) continue;
        if(GetThreadMemoryUsage(w->terminal_pid)!=0) continue;
        /* Kernel process cleanup already released the child-owned terminal.
         * Clear IDs before closing so guiCloseWindow never targets a reused PID. */
        w->terminal_pid=0;
        w->terminal_id=-1;
        w->fb_type=0;
        guiCloseWindow(v,w);
    }
}

int guiStartCommandPrompt(VMODE *v)
{
    WINDOW *w;

    if(!v) return 0;
    w=find_command_prompt();
    if(w) {
        SelectWindow(v,w);
        v->prompt_launch_state=2;
        return 1;
    }

    v->prompt_launch_state=1;
    if(!guiStartTerminalProgram(v,"/bin/sqsh.bin",
                                "JTMOS Command Prompt - Squirrel Shell")) {
        v->prompt_launch_state=0;
        return 0;
    }
    v->prompt_launch_state=2;
    return 1;
}

int guiLaunchBackgroundApp(VMODE *v,const char *program)
{
    char cwd[256];
    int pid;
    (void)v;
    if(!program || !*program) return 0;
    get_workdir(cwd,sizeof(cwd));
    pid=graos_bgexec_ex_command(program,cwd,GetCurrentTerminal());
    return pid>0;
}

int guiOpenControlPanel(VMODE *v)
{
    int wid;
    WINDOW *w;
    int i;

    if(!v) return 0;
    for(i=0;i<wdb.n_windows;i++) {
        w=&wdb.w[i];
        if(!w->isfree && !strcmp(w->caption,"JTMOS Control Panel")) {
            SelectWindow(v,w);
            return 1;
        }
    }

    wid=guiCreateWindow(v,(GRAOS_WIDTH-740)/2,
                        (GRAOS_HEIGHT-GRAOS_PANEL_HEIGHT-430)/2,
                        740,430,"JTMOS Control Panel",
                        GRAOS_WINDOW_STANDARD|GRAOS_WINDOW_CONTROL_PANEL_STYLE);
    w=GetWindowPTR(wid);
    if(!w) return 0;
    w->pid=0;

    /* Windows 98 Control Panel layout: explanatory pane on the left and
     * a roomy icon view on the right.  The 8x8 bitmap font is kept at native
     * size so text stays crisp instead of being resampled. */
    guiCreateLabel(w,20,42,168,16,64020,0,GRAOS_LABEL_TRANSPARENT,
                   GRAOS_LABEL_ALIGN_LEFT,"CONTROL PANEL");
    guiCreateLabel(w,20,94,168,12,64021,0,GRAOS_LABEL_TRANSPARENT,
                   GRAOS_LABEL_ALIGN_LEFT,"Use these settings to");
    guiCreateLabel(w,20,108,168,12,64022,0,GRAOS_LABEL_TRANSPARENT,
                   GRAOS_LABEL_ALIGN_LEFT,"open JTMOS tools and");
    guiCreateLabel(w,20,122,168,12,64023,0,GRAOS_LABEL_TRANSPARENT,
                   GRAOS_LABEL_ALIGN_LEFT,"change the desktop.");
    guiCreateLabel(w,20,158,168,12,64024,0,GRAOS_LABEL_TRANSPARENT,
                   GRAOS_LABEL_ALIGN_LEFT,"Select an icon to open");
    guiCreateLabel(w,20,172,168,12,64025,0,GRAOS_LABEL_TRANSPARENT,
                   GRAOS_LABEL_ALIGN_LEFT,"a component.");
    guiCreateLabel(w,20,365,168,14,GRAOS_INTERNAL_STATUS_LABEL_ID,0,
                   GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_LEFT,"Ready");

    guiCreateButtonEx(w,220,48,327,127,64101,
                      GRAOS_BUTTON_ICON_VIEW|GRAOS_BUTTON_ICON(GRAOS_ICON_TERMINAL),
                      "Terminal");
    guiCreateButtonEx(w,342,48,449,127,64102,
                      GRAOS_BUTTON_ICON_VIEW|GRAOS_BUTTON_ICON(GRAOS_ICON_FOLDER),
                      "File Manager");
    guiCreateButtonEx(w,464,48,571,127,64103,
                      GRAOS_BUTTON_ICON_VIEW|GRAOS_BUTTON_ICON(GRAOS_ICON_EDITOR),
                      "Text Editor");
    guiCreateButtonEx(w,586,48,693,127,64104,
                      GRAOS_BUTTON_ICON_VIEW|GRAOS_BUTTON_ICON(GRAOS_ICON_TASKS),
                      "Task Manager");
    guiCreateButtonEx(w,220,153,327,232,64105,
                      GRAOS_BUTTON_ICON_VIEW|GRAOS_BUTTON_ICON(GRAOS_ICON_DISPLAY),
                      "Blue Desktop");
    guiCreateButtonEx(w,342,153,449,232,64106,
                      GRAOS_BUTTON_ICON_VIEW|GRAOS_BUTTON_ICON(GRAOS_ICON_DESKTOP),
                      "Green Desktop");
    guiCreateButtonEx(w,464,153,571,232,64107,
                      GRAOS_BUTTON_ICON_VIEW|GRAOS_BUTTON_ICON(GRAOS_ICON_SETTINGS),
                      "Dark Desktop");
    v->dirty=1;
    return 1;
}

int guiStartMenuAction(VMODE *v,int action)
{
    if(!v) return 0;
    switch(action) {
    case GRAOS_MENU_TERMINAL:
        return guiStartCommandPrompt(v);
    case GRAOS_MENU_FILER:
        return guiLaunchBackgroundApp(v,"/bin/filer.bin");
    case GRAOS_MENU_EDITOR:
        return guiStartTerminalProgram(v,"/bin/edit.bin","JTMOS Text Editor");
    case GRAOS_MENU_TOP:
        return guiStartTerminalProgram(v,"/bin/top.bin","JTMOS Task Manager");
    case GRAOS_MENU_CONTROL:
        return guiOpenControlPanel(v);
    case GRAOS_MENU_APPLICATIONS:
        return guiLaunchBackgroundApp(v,"/bin/launcher.bin");
    case GRAOS_MENU_CLOSE:
        return 1;
    default:
        return 0;
    }
}

VMODE *guiStart(void)
{
    VMODE *v;
    int graphics_rv;

    v=(VMODE*)malloc(sizeof(VMODE));
    if(!v)
        return NULL;

    /*
     * V67.8.13: kernel boot remains in VGA text mode.  GraOS explicitly owns
     * the transition to 1024x768x32 RGBA, so there is no black graphics interval
     * between boot32 and userspace GUI startup.
     */
    graphics_rv=(int)jtmos_syscall7(SYS_graosgraphics,0,0,0,0,0,0);
    if(graphics_rv<=0) {
        printf("GraOS: 1024x768x32 RGBA graphics provider is unavailable.\n");
        free(v);
        return NULL;
    }

    memset(v,0,sizeof(*v)); v->width=GRAOS_WIDTH;v->height=GRAOS_HEIGHT;v->bpp=GRAOS_BPP;v->l_buf=GRAOS_FRAME_BYTES;v->running=1;
    v->buf=(GRAOS_PIXEL*)malloc(GRAOS_FRAME_BYTES); if(!v->buf){free(v);return NULL;}
#if GRAOS_ENABLE_CURSOR
    if(!guiLoadCursor(v,"mousecursor.raw")) printf("GraOS: cursor asset missing; continuing without cursor.\n");
#endif
#if GRAOS_ENABLE_BACKGROUND
    if(!guiLoadBackground(v,"background32.bmp")) printf("GraOS: 32-bit BMP background missing/invalid; using generated desktop.\n");
#endif
    if(!guiChromeInit())
        printf("GraOS: Win98-style title button RAW assets missing; using built-in fallback.\n");
    SetMouseRect(0,0,GRAOS_WIDTH-1,GRAOS_HEIGHT-1);
    guiStartupShowPoster(v);
    wdbInit(); guiServerInit();
    guiCreateWelcome(v);
    v->prompt_launch_state=0;
    v->prompt_delay_yields=0;
    v->start_menu_open=0;
    v->start_menu_pressed_item=-1;
    v->start_button_pressed=0;
    v->desktop_color=124;
    v->desktop_solid=0;
    v->x=GetMouseX(); v->y=GetMouseY();
    if(v->x<0 || v->x>=GRAOS_WIDTH) v->x=GRAOS_WIDTH/2;
    if(v->y<0 || v->y>=GRAOS_HEIGHT) v->y=GRAOS_HEIGHT/2;
    v->dirty=1;return v;
}
