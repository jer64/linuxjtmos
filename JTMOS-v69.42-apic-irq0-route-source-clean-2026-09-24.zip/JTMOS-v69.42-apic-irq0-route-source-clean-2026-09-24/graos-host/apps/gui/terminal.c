/* terminal.c - external native JTMOS GraOS terminal client, V67.8.57.6 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <unistd.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/process.h>
#include "guiLaunchCompat.h"
SYSMEMREQ(APPRAM_512K)
#define TERMINAL_LABEL 5001

static void child_command(char *out,int cap,int argc,char **argv)
{
    int i,used=0,n;
    if(argc<=1){strcpy(out,"/bin/sqsh.bin");return;}
    out[0]=0;
    for(i=1;i<argc;i++){
        n=snprintf(out+used,(size_t)(cap-used),"%s%s",used?" ":"",argv[i]);
        if(n<0 || n>=cap-used) break;
        used+=n;
    }
    if(!out[0]) strcpy(out,"/bin/sqsh.bin");
}
int main(int argc,char **argv)
{
    GUICMD ev;
    int wid=-1,ter=-1,pid=0,er,server_closed=0; char child[512],cwd[256],title[128],label[128];
    if(connectGraos()!=0){printf("terminal: GraOS is not running.\n");return 1;}
    ter=CreateTerminal(); if(ter<0)return 2;
    child_command(child,sizeof(child),argc,argv);
    if(!getcwd(cwd,sizeof(cwd))) strcpy(cwd,"/");
    pid=graos_bgexec_ex_command(child,cwd,ter);
    if(pid<=0){printf("terminal: cannot launch %s\n",child);return 3;}
    /* Keep terminal ownership in this wrapper.  If the child exits, its normal
     * process cleanup must not free the surface while the GraOS window still
     * references it.  The wrapper exits immediately after detecting the child. */
    if(argc>1) snprintf(title,sizeof(title),"JTMOS Terminal - %s",argv[1]);
    else strcpy(title,"JTMOS Command Prompt - Squirrel Shell");
    wid=createWindow((GRAOS_SCREEN_WIDTH-640)/2,(GRAOS_SCREEN_HEIGHT-GRAOS_SCREEN_PANEL_HEIGHT-436)/2,640,436,title,GRAOS_WINDOW_STANDARD);
    if(wid<0)goto done;
    snprintf(label,sizeof(label),"Terminal %d - 80x25 text surface - 8x16 font",ter);
    createLabel(wid,4,20,632,16,TERMINAL_LABEL,0,7,GRAOS_LABEL_ALIGN_LEFT,label);
    if(addFrameBuffer(wid,NULL,0,16,80,25,0,GRAOS_SURFACE_TERMINAL,ter)<0)goto done;
    refreshWindow(wid);
    for(;;){
        while((er=JtmosGraOSPollEvent(wid,&ev))>0){
            if(ev.id==GRAOS_GSID_EXIT){server_closed=1;goto done;}
        }
        if(er<0){server_closed=1;goto done;}
        /* Ring-3 application processes always own at least one 64 KiB bank.
         * Zero therefore means the child PID no longer exists. */
        if(pid>0 && GetThreadMemoryUsage(pid)==0) { pid=0; goto done; }
        SwitchToThread();
        Sleep(10);
    }
done:
    if(wid>=0) {
        JtmosGraOSFreeTerminal(ter);
        if(!server_closed) closeWindow(wid);
    }
    if(pid>0 && GetThreadMemoryUsage(pid)>0)KillThread(pid);
    return 0;
}
