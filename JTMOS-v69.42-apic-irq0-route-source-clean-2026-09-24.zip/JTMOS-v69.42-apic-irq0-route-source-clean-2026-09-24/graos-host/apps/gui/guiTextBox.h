#ifndef __INCLUDED_GUITEXTBOX_H__
#define __INCLUDED_GUITEXTBOX_H__
#include "graos.h"
#include "window.h"
TEXTBOX *guiCreateTextBox(WINDOW *w,int x,int y,int width,int height,int id,int maxlen,const char *text);
TEXTBOX *guiGetTextBox(WINDOW *w,int id);
TEXTBOX *guiGetTextBoxAt(WINDOW *w,int local_x,int local_y);
int guiSetTextBoxText(WINDOW *w,int id,const char *text);
int guiGetTextBoxText(WINDOW *w,int id,char *out,int cap);
int guiRemoveTextBox(WINDOW *w,int id);
void guiFocusTextBox(VMODE *v,WINDOW *w,TEXTBOX *t);
void guiBlurTextBox(VMODE *v,WINDOW *w);
int guiTextBoxHandleKey(VMODE *v,WINDOW *w,int key);
void guiDrawTextBox(VMODE *v,WINDOW *w,TEXTBOX *t);
#endif
