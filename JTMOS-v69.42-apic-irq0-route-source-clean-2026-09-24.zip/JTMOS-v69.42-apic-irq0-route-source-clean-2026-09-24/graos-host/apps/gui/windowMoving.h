#ifndef __INCLUDED_WINDOWMOVING_H__
#define __INCLUDED_WINDOWMOVING_H__
#include "graos.h"
void windowInput(VMODE *v);
#endif
