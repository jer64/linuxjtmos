#ifndef __INCLUDED_GUISTARTUP_H__
#define __INCLUDED_GUISTARTUP_H__
#include "graos.h"
int guiStartupShowPoster(VMODE *v);
#endif
