#ifndef __INCLUDED_GUIFONT_H__
#define __INCLUDED_GUIFONT_H__
#include "graos.h"
#include "guifont_data.h"
void DrawText(VMODE *v,const char *s,int x,int y,int fg,int bg);
#endif
