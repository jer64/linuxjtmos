#ifndef __INCLUDED_GUIDESKTOPDRAW_H__
#define __INCLUDED_GUIDESKTOPDRAW_H__
#include "graos.h"
int guiLoadBackground(VMODE *v,const char *name);
void guiDesktopDraw(VMODE *v);
void guiDesktopDrawPopup(VMODE *v);
/* Returns non-zero when the desktop/taskbar consumed this mouse event. */
int guiDesktopInput(VMODE *v);
int guiDesktopHandleKey(VMODE *v,int key);
#endif
