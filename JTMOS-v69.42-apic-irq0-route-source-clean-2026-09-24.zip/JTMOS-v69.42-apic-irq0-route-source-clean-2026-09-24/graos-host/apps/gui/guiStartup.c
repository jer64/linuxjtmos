/* guiStartup.c - fast 32-bpp RGBA JTMOS startup poster.
 *
 * V67.8.50: the old intro rebuilt and presented the complete 1024x768 frame
 * 32 times.  Each fade frame also repainted every already-visible 5x5 source
 * pixel.  That was needlessly expensive once GraOS moved to RGBA32.
 *
 * The new path paints the background once, reveals only the newly-visible
 * Bayer groups, and uses eight present steps in each direction.  Every poster
 * pixel is therefore written only once on fade-in and once on fade-out.
 */
#include "guiStartup.h"
#include "guiResource.h"
#include "guiUpdate.h"
#include "guiRect.h"

#define POSTER_W 128
#define POSTER_H 80
#define POSTER_PIXELS (POSTER_W*POSTER_H)
#define POSTER_BYTES (POSTER_PIXELS*4)
#define POSTER_SCALE 5
#define POSTER_FADE_STEPS 8

static const BYTE fade4x4[16]={0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5};

static void wait_cooperative(unsigned long ms)
{
    unsigned long start=GetTickCount();
    while((unsigned long)(GetTickCount()-start)<ms) SwitchToThread();
}

static int load_poster(GRAOS_PIXEL *dst)
{
    FILE *f;
    size_t n;
    f=guiOpenResource("jtmos_poster.raw","rb");
    if(!f) return 0;
    n=fread(dst,1,POSTER_BYTES,f);
    fclose(f);
    return n==POSTER_BYTES;
}

static void poster_origin(int *ox,int *oy)
{
    *ox=(GRAOS_WIDTH-POSTER_W*POSTER_SCALE)/2;
    *oy=(GRAOS_HEIGHT-POSTER_H*POSTER_SCALE)/2;
}

/* Paint one source pixel as a 5x5 block.  Build the first row once and clone
 * it with memcpy; this is much cheaper than 25 independent address calculations. */
static void paint_scaled_pixel(VMODE *v,int ox,int oy,int sx,int sy,GRAOS_PIXEL color)
{
    GRAOS_PIXEL *row;
    int x,y;
    row=v->buf+(oy+sy*POSTER_SCALE)*v->width+ox+sx*POSTER_SCALE;
    for(x=0;x<POSTER_SCALE;x++) row[x]=color;
    for(y=1;y<POSTER_SCALE;y++)
        memcpy(row+y*v->width,row,(size_t)POSTER_SCALE*4U);
}

static void draw_intro_base(VMODE *v,int ox,int oy)
{
    fillRectRGBA(v,0,0,v->width-1,v->height-1,GRAOS_RGB(0,0,0));
    fillRectRGBA(v,ox-6,oy-6,ox+POSTER_W*POSTER_SCALE+5,
                 oy+POSTER_H*POSTER_SCALE+5,GRAOS_RGB(0,40,120));
    fillRectRGBA(v,ox-3,oy-3,ox+POSTER_W*POSTER_SCALE+2,
                 oy+POSTER_H*POSTER_SCALE+2,GRAOS_RGB(255,255,255));
    fillRectRGBA(v,ox,oy,ox+POSTER_W*POSTER_SCALE-1,
                 oy+POSTER_H*POSTER_SCALE-1,GRAOS_RGB(0,0,0));
}

/* Reveal or erase exactly one pair of Bayer thresholds.  The old code redrew
 * all lower thresholds on every frame; this makes the animation O(pixels)
 * instead of O(pixels * fade_frames). */
static void draw_fade_group(VMODE *v,const GRAOS_PIXEL *src,int ox,int oy,
                            int first_threshold,int show)
{
    int x,y,t;
    GRAOS_PIXEL color;
    for(y=0;y<POSTER_H;y++) {
        for(x=0;x<POSTER_W;x++) {
            t=fade4x4[(y&3)*4+(x&3)];
            if(t<first_threshold || t>first_threshold+1) continue;
            color=show ? src[y*POSTER_W+x] : GRAOS_RGB(0,0,0);
            paint_scaled_pixel(v,ox,oy,x,y,color);
        }
    }
    v->dirty=1;
}

int guiStartupShowPoster(VMODE *v)
{
    GRAOS_PIXEL *poster;
    int step,ox,oy;
    if(!v||!v->buf) return 0;
    poster=(GRAOS_PIXEL*)malloc(POSTER_BYTES);
    if(!poster) return 0;
    if(!load_poster(poster)) { free(poster); return 0; }

    poster_origin(&ox,&oy);
    draw_intro_base(v,ox,oy);

    /* Eight progressive presents instead of sixteen full redraws. */
    for(step=0;step<POSTER_FADE_STEPS;step++) {
        draw_fade_group(v,poster,ox,oy,step*2,1);
        if(!guiUpdate(v)) { free(poster); return 0; }
        wait_cooperative(16);
    }

    wait_cooperative(500);

    for(step=POSTER_FADE_STEPS-1;step>=0;step--) {
        draw_fade_group(v,poster,ox,oy,step*2,0);
        if(!guiUpdate(v)) { free(poster); return 0; }
        wait_cooperative(14);
    }

    free(poster);
    return 1;
}
