#include "guiUpdate.h"
int graos_present(VMODE *v)
{
    if(!v||!v->buf)return 0;
    return (int)scall(SYS_vgadrawframe,(DWORD)v->buf,0,GRAOS_FRAME_BYTES,0,0,0);
}
int guiUpdate(VMODE *v)
{
    int ok;
    if(!v||!v->dirty)return 1;
    ok=graos_present(v); if(ok)v->dirty=0; return ok;
}
