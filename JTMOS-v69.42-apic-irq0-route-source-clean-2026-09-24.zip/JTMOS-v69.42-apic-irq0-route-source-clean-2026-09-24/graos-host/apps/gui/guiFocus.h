#ifndef __INCLUDED_GUIFOCUS_H__
#define __INCLUDED_GUIFOCUS_H__
#include "graos.h"

/* One logical child-widget focus per GraOS window.  Tab order is spatial:
 * top-to-bottom, then left-to-right, which keeps old applications usable
 * without requiring an explicit tab-index API. */
int guiMoveFocus(VMODE *v,WINDOW *w,int direction);
int guiEnsureFocus(VMODE *v,WINDOW *w);
int guiFocusButton(VMODE *v,WINDOW *w,BUTTON *b);
void guiClearWidgetFocus(VMODE *v,WINDOW *w);
int guiHandleNavigationKey(VMODE *v,WINDOW *w,int key);
int guiWidgetIsFocused(const VMODE *v,const WINDOW *w,const GRAOS_WIDGET *g);

#endif
