# JTMOS V67 static ELF32 application
APPNAME=cat
include app-common.mk
