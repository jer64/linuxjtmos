// Background process
//
#include <stdio.h>
#ifndef JTMOS
#include <jtmos/app_port.h>
#endif

static volatile char workload[256];

//
int main(int argc,char **argv)
{
	 //
	 int i;

 //
 while(1)
 {
	  //
	  for(i=0; i<(1024*16); i++) {
			workload[i&255] = i;
			workload[(i+64)&255] = 0;
			workload[(i+128)&255] = 128;
		}

  //
  Sleep(100);
 }

 //
 return 0;
}

//
