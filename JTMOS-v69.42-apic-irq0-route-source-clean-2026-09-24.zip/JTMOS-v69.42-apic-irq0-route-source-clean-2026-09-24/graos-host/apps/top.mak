# JTMOS V67 static ELF32 application
APPNAME=top
include app-common.mk
