/* picture.c - windowed GraOS RGBA32 picture viewer. */
#include <stdio.h>
#include <stdlib.h>
#include <jtmos/process.h>
#include "graos_demo.h"

#define PIC_W 320
#define PIC_H 200
#define PIC_BYTES (PIC_W*PIC_H*4)
SYSMEMREQ(APPRAM_512K)

static int read_picture(GRAOS_PIXEL *image)
{
    static const char *names[]={"/bin/sqfam.raw","sqfam.raw","ram:/bin/sqfam.raw","cdrom:/sqfam.raw",NULL};
    FILE *f; size_t n; int i;
    for(i=0;names[i];i++) {
        f=fopen(names[i],"rb"); if(!f) continue;
        n=fread(image,1,PIC_BYTES,f); fclose(f);
        if(n==PIC_BYTES) return 0;
    }
    return -1;
}

int main(void)
{
    JTMOS_GRAOS_DEMO d; int key;
    if(jtmos_demo_open(&d,"Squirrel Family - any key closes",PIC_W,PIC_H)!=0) return 1;
    if(read_picture(d.pixels)!=0) {
        printf("picture: sqfam.raw not installed or invalid.\n");
        jtmos_demo_close(&d); return 2;
    }
    if(jtmos_demo_present(&d)<0) { jtmos_demo_close(&d); return 3; }
    for(;;) {
        key=jtmos_demo_poll(&d);
        if(key<0 || key>0) break;
        jtmos_demo_idle(20);
    }
    jtmos_demo_close(&d);
    return 0;
}
