APPNAME=performance
include app-common.mk
