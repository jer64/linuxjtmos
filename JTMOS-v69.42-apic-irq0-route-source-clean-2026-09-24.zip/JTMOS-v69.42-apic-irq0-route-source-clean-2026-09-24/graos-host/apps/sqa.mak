# JTMOS V59 static ELF32 Squirrel Archive extractor
APPNAME=sqa
JTMOS_LIBC=../libc
CC=gcc
LD=ld
CFLAGS=-m32 -march=i486 -std=gnu89 -O2 -ffreestanding -fno-builtin -fno-stack-protector -fno-pie -fno-pic -fno-unwind-tables -fno-asynchronous-unwind-tables -nostdinc -Ulinux -U__linux -U__linux__ -DJTMOS=1 -DJTMOS_APPLICATION=1 -DJTMOS_LEGACY_SOURCE=1 -DCPU=i486 -I$(JTMOS_LIBC)/include
LDFLAGS=-m elf_i386 -static -z noexecstack -T $(JTMOS_LIBC)/jtmos_elf32.ld
CRT0=$(JTMOS_LIBC)/build/application/crt0.o
LIB=$(JTMOS_LIBC)/libcjtmos.a

default: $(APPNAME).bin

$(CRT0) $(LIB):
	$(MAKE) -C $(JTMOS_LIBC) application

sqa.o: sqa.c sqa.h
	$(CC) $(CFLAGS) -c sqa.c -o $@
sqaMain.o: sqaMain.c sqa.h
	$(CC) $(CFLAGS) -c sqaMain.c -o $@

$(APPNAME).bin: $(CRT0) $(LIB) sqa.o sqaMain.o
	$(LD) $(LDFLAGS) $(CRT0) sqa.o sqaMain.o $(LIB) -o $@

clean:
	rm -f sqa.o sqaMain.o sqa.bin sqa.map
