#==========================================================
# JTMOS unz
# Original program/concept (C) 1997-2005 by Jari Tuominen.
# Modern ELF32 build: nzip decompressor + automatic Squirrel-image extractor.
#==========================================================
APPNAME=unz
JTMOS_LIBC=../libc
CC=gcc
LD=ld
CFLAGS=-m32 -march=i486 -std=gnu89 -O2 -ffreestanding -fno-builtin -fno-stack-protector -fno-pie -fno-pic -fno-unwind-tables -fno-asynchronous-unwind-tables -nostdinc -Ulinux -U__linux -U__linux__ -DJTMOS=1 -DJTMOS_APPLICATION=1 -DJTMOS_LEGACY_SOURCE=1 -DCPU=i486 -DUNCOMPRESS_ALL -I$(JTMOS_LIBC)/include
LDFLAGS=-m elf_i386 -static -z noexecstack -T $(JTMOS_LIBC)/jtmos_elf32.ld
CRT0=$(JTMOS_LIBC)/build/application/crt0.o
LIB=$(JTMOS_LIBC)/libcjtmos.a

.PHONY: default clean

default: $(APPNAME).bin

# Serialize the shared libc build: a parallel multi-target recipe races on
# libcjtmos.a and build/application/*.o when both outputs are initially absent.
$(CRT0):
	$(MAKE) -C $(JTMOS_LIBC) application

$(LIB): $(CRT0)
	@test -f $@ || $(MAKE) -C $(JTMOS_LIBC) application

nzip-unz.o: nzip.c nzip.h
	$(CC) $(CFLAGS) -c nzip.c -o $@
nzipMain-unz.o: nzipMain.c nzip.h sqa.h
	$(CC) $(CFLAGS) -c nzipMain.c -o $@
sqa-unz.o: sqa.c sqa.h
	$(CC) $(CFLAGS) -c sqa.c -o $@

$(APPNAME).bin: $(CRT0) $(LIB) nzip-unz.o nzipMain-unz.o sqa-unz.o
	$(LD) $(LDFLAGS) $(CRT0) nzip-unz.o nzipMain-unz.o sqa-unz.o $(LIB) -o $@

clean:
	rm -f nzip-unz.o nzipMain-unz.o sqa-unz.o unz.bin unz.map
