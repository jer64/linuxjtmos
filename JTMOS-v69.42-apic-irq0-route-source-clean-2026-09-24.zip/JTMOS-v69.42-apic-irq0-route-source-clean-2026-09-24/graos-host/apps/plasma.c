/* plasma.c - windowed GraOS plasma. No global VGA mode switching. */
#include <jtmos/process.h>
#include "graos_demo.h"
SYSMEMREQ(APPRAM_512K)
#define W 320
#define H 200
static void render(JTMOS_GRAOS_DEMO *d,unsigned long frame)
{
    int x,y; unsigned int v,r,g,b;
    for(y=0;y<H;y++) for(x=0;x<W;x++) {
        v=(unsigned int)(((x+frame)^((y*3)+(frame>>1))) + ((x*y)>>4) + frame*3U) & 255U;
        r=(v<128)?v*2U:255U;
        g=(v<128)?(255U-v*2U):((v-128U)*2U);
        b=255U-v;
        d->pixels[y*W+x]=GRAOS_RGB(r,g,b);
    }
}
int main(void)
{
    JTMOS_GRAOS_DEMO d; unsigned long frame=0; int key;
    if(jtmos_demo_open(&d,"Plasma - Esc closes",W,H)!=0) return 1;
    for(;;) {
        key=jtmos_demo_poll(&d); if(key<0 || key==27) break;
        if(!d.focused) { jtmos_demo_idle(30); continue; }
        render(&d,frame++); if(jtmos_demo_present(&d)<0) break;
        jtmos_demo_idle(30);
    }
    jtmos_demo_close(&d); return 0;
}
