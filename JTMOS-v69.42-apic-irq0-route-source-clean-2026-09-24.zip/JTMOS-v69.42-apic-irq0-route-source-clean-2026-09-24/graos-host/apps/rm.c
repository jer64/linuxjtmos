/* rm.c - remove files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jtmos/filefind.h>

static int force_mode = 0;
static int verbose = 0;

static int has_wildcards(const char *s)
{
    return s != NULL && (strchr(s, '*') != NULL || strchr(s, '?') != NULL);
}

static int wildcard_match(const char *pattern, const char *text)
{
    while(*pattern) {
        if(*pattern == '*') {
            while(*pattern == '*') ++pattern;
            if(!*pattern) return 1;
            while(*text) {
                if(wildcard_match(pattern, text)) return 1;
                ++text;
            }
            return 0;
        }
        if(*pattern == '?') {
            if(!*text) return 0;
            ++pattern;
            ++text;
            continue;
        }
        if(*pattern != *text) return 0;
        ++pattern;
        ++text;
    }
    return *text == 0;
}

static int remove_one(const char *path)
{
    if(remove(path) != 0) {
        if(!force_mode) printf("rm: cannot remove '%s'\n", path);
        return force_mode ? 0 : 1;
    }
    if(verbose) printf("removed '%s'\n", path);
    return 0;
}

static int remove_pattern(const char *pattern)
{
    FFBLK ff;
    char **names = NULL;
    int fd;
    int matches = 0;
    int cap = 0;
    int i;
    int rc = 0;

    if(!has_wildcards(pattern)) return remove_one(pattern);

    fd = findfirst("*", &ff);
    if(fd <= 0) {
        if(!force_mode) printf("rm: cannot list current directory\n");
        return force_mode ? 0 : 1;
    }
    for(;;) {
        if(ff.ff_fsize != -1 && !JTMFS_TYPE_IS_DIRECTORY(ff.ff_attrib) &&
           wildcard_match(pattern, ff.ff_name)) {
            if(matches == cap) {
                int nc = cap ? cap * 2 : 16;
                char **nn = (char **)realloc(names, (size_t)nc * sizeof(char *));
                if(nn == NULL) { rc = 1; break; }
                names = nn;
                cap = nc;
            }
            names[matches] = (char *)malloc(strlen(ff.ff_name) + 1U);
            if(names[matches] == NULL) { rc = 1; break; }
            strcpy(names[matches], ff.ff_name);
            ++matches;
        }
        if(findnext(fd, &ff) != 0) break;
    }
    close(fd);

    if(matches == 0 && !force_mode) {
        printf("rm: no files match '%s'\n", pattern);
        rc = 1;
    }
    for(i = 0; i < matches; ++i) {
        if(remove_one(names[i]) != 0) rc = 1;
        free(names[i]);
    }
    free(names);
    return rc;
}

static void help(void)
{
    printf("Usage: rm [OPTIONS] FILE [FILE ...]\n");
    printf("Remove files. Wildcards '*' and '?' work in the current directory.\n");
    printf("  -f, --force     ignore nonexistent files\n");
    printf("  -v, --verbose   show removed files\n");
    printf("  -h, --help      show this help\n");
    printf("Directory recursion is intentionally not implemented.\n");
}

int main(int argc, char **argv)
{
    int i;
    int files = 0;
    int rc = 0;

    if(argc < 2) {
        help();
        return 1;
    }
    for(i = 1; i < argc; ++i) {
        if(!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help") || !strcmp(argv[i], "/?")) {
            help();
            return 0;
        }
        if(!strcmp(argv[i], "-f") || !strcmp(argv[i], "--force")) {
            force_mode = 1;
            continue;
        }
        if(!strcmp(argv[i], "-v") || !strcmp(argv[i], "--verbose")) {
            verbose = 1;
            continue;
        }
        ++files;
        if(remove_pattern(argv[i]) != 0) rc = 1;
    }
    if(files == 0) {
        printf("rm: missing file operand\n");
        return 1;
    }
    return rc;
}
