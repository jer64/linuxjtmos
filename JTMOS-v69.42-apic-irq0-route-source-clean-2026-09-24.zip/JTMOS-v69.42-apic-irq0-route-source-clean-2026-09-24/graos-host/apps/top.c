// ----------------------------------------------------------------
// top.c - JTMOS interactive process/CPU monitor.
// (C) 2002-2005 by Jari Tuominen.
//
// V67.8.57.10.2 2026:
//   - Linux-style continuously refreshing 80-column display
//   - q/ESC quits; no-key (getch1()==0) no longer exits top
//   - system memory summary through the existing sysinfo() syscall
//   - CPU or memory sorting with P/M
//   - cursor hidden while repainting and no clrscr() on every frame
// ----------------------------------------------------------------
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <sys/sysinfo.h>
#include <jtmos/filefind.h>

#define TOP_MAX_THREADS 256
#define TOP_MAX_ROWS     16
#define TOP_INTERVAL_MS  1000
#define TOP_POLL_MS      50
#define TOP_LINE_WIDTH   79

#define TOP_SORT_CPU     0
#define TOP_SORT_MEM     1

typedef struct
{
    int pid;
    int priority;
    DWORD total_ticks;
    DWORD delta_ticks;
    DWORD cpu_per_mille;
    DWORD mem_bytes;
    char name[32];
} PR;

static PR entries[TOP_MAX_THREADS];
static PR *sorted[TOP_MAX_THREADS];
static DWORD oldSpending[TOP_MAX_THREADS];
static int oldPid[TOP_MAX_THREADS];
static DWORD sample_total_delta=0;
static int sample_count=0;
static int sort_mode=TOP_SORT_CPU;
static JTMOS_CPU_STATS cpu;
static struct sysinfo si;

static void format_fixed_1000(char *out,DWORD value)
{
    sprintf(out,"%u.%03u",(unsigned)(value/1000UL),(unsigned)(value%1000UL));
}

static void format_percent_1(char *out,DWORD value)
{
    if(value>1000UL) value=1000UL;
    sprintf(out,"%u.%u",(unsigned)(value/10UL),(unsigned)(value%10UL));
}

static void format_mib_1(char *out,DWORD bytes)
{
    DWORD unit=1024UL*1024UL;
    DWORD whole=bytes/unit;
    DWORD tenth=((bytes%unit)*10UL)/unit;
    sprintf(out,"%u.%u",(unsigned)whole,(unsigned)tenth);
}

static void draw_line(int row,const char *text)
{
    gotoxy(1,row);
    printf("%-79.79s",text ? text : "");
}

static void do_init(void)
{
    int i;
    memset(entries,0,sizeof(entries));
    memset(sorted,0,sizeof(sorted));
    memset(oldSpending,0,sizeof(oldSpending));
    for(i=0;i<TOP_MAX_THREADS;i++)
    {
        oldPid[i]=-1;
        sorted[i]=&entries[i];
    }
    memset(&cpu,0,sizeof(cpu));
    memset(&si,0,sizeof(si));
}

/* Snapshot cumulative scheduler ticks and turn them into interval deltas. */
static void do_update(void)
{
    int i;
    int count;
    int pid;
    DWORD now;
    DWORD delta;

    count=GetThreadCount();
    if(count<0) count=0;
    if(count>TOP_MAX_THREADS) count=TOP_MAX_THREADS;
    sample_count=count;
    sample_total_delta=0;

    for(i=0;i<count;i++)
    {
        pid=i;
        entries[i].pid=pid;
        entries[i].priority=GetThreadPriority(pid);
        entries[i].mem_bytes=(DWORD)GetThreadMemoryUsage(pid);
        entries[i].name[0]=0;
        GetThreadName(pid,entries[i].name);
        if(!entries[i].name[0]) strcpy(entries[i].name,"[none]");

        now=(DWORD)GetThreadSpending(pid);
        if(oldPid[i] != pid || now < oldSpending[i])
        {
            /* Plain PIDs are table indices and can be reused. */
            delta=0;
            oldPid[i]=pid;
        }
        else
            delta=now-oldSpending[i];
        oldSpending[i]=now;
        entries[i].total_ticks=now;
        entries[i].delta_ticks=delta;
        entries[i].cpu_per_mille=0;
        sample_total_delta+=delta;
    }

    if(sample_total_delta)
        for(i=0;i<count;i++)
            entries[i].cpu_per_mille=(entries[i].delta_ticks*1000UL)/sample_total_delta;

    if(GetCPUStats(&cpu)!=0)
        memset(&cpu,0,sizeof(cpu));
    if(sysinfo(&si)!=0)
        memset(&si,0,sizeof(si));
}

static int before(PR *a,PR *b)
{
    if(sort_mode==TOP_SORT_MEM)
    {
        if(a->mem_bytes!=b->mem_bytes)
            return a->mem_bytes>b->mem_bytes;
        return a->delta_ticks>b->delta_ticks;
    }
    if(a->delta_ticks!=b->delta_ticks)
        return a->delta_ticks>b->delta_ticks;
    return a->mem_bytes>b->mem_bytes;
}

static void do_sort(void)
{
    int i,j;
    PR *tmp;

    for(i=0;i<sample_count;i++)
        sorted[i]=&entries[i];

    for(i=1;i<sample_count;i++)
    {
        tmp=sorted[i];
        j=i;
        while(j>0 && before(tmp,sorted[j-1]))
        {
            sorted[j]=sorted[j-1];
            j--;
        }
        sorted[j]=tmp;
    }
}

static void draw_header(void)
{
    char line[128];
    char la[20],lb[20],lc[20];
    char busy[12],idle[12];
    char mt[20],mf[20],mu[20],ma[20];
    DWORD sec;
    DWORD total,freeb,used,avail;
    int running,sleeping;

    sec=cpu.uptime_ms/1000UL;
    format_fixed_1000(la,cpu.load_a_x1000);
    format_fixed_1000(lb,cpu.load_b_x1000);
    format_fixed_1000(lc,cpu.load_c_x1000);

    snprintf(line,sizeof(line),
        "top - up %u:%02u:%02u,  load average: %s, %s, %s",
        (unsigned)(sec/3600UL),(unsigned)((sec/60UL)%60UL),(unsigned)(sec%60UL),
        la,lb,lc);
    draw_line(1,line);

    running=(int)cpu.runnable_threads;
    sleeping=(int)cpu.total_threads-running;
    if(sleeping<0) sleeping=0;
    snprintf(line,sizeof(line),
        "Tasks: %3u total, %3d running, %3d sleeping, %3d stopped, %3d zombie",
        (unsigned)cpu.total_threads,running,sleeping,0,0);
    draw_line(2,line);

    format_percent_1(busy,cpu.cpu_busy_per_mille);
    format_percent_1(idle,cpu.cpu_idle_per_mille);
    snprintf(line,sizeof(line),
        "%%Cpu(s): %5s busy, %5s idle                         PIT: %u Hz",
        busy,idle,(unsigned)cpu.hz);
    draw_line(3,line);

    total=(DWORD)(si.totalram * (si.mem_unit ? si.mem_unit : 1U));
    freeb=(DWORD)(si.freeram * (si.mem_unit ? si.mem_unit : 1U));
    used=total>=freeb ? total-freeb : 0;
    avail=freeb;
    format_mib_1(mt,total); format_mib_1(mf,freeb);
    format_mib_1(mu,used); format_mib_1(ma,avail);
    snprintf(line,sizeof(line),
        "MiB Mem : %7s total, %7s free, %7s used, %7s avail",
        mt,mf,mu,ma);
    draw_line(4,line);
    draw_line(5,"");
    draw_line(6,"  PID  PR     RES   %CPU   %MEM      TICKS COMMAND");
}

static void draw_processes(void)
{
    int row;
    int printed;
    int screen_row;
    DWORD total_k;
    DWORD mem_k;
    DWORD mem_pm;
    char line[128];
    char cpup[12];
    char memp[12];
    PR *pr;

    total_k=(DWORD)((si.totalram * (si.mem_unit ? si.mem_unit : 1U))/1024UL);
    screen_row=7;

    for(row=0,printed=0;row<sample_count && printed<TOP_MAX_ROWS;row++)
    {
        pr=sorted[row];
        if(pr->priority==0)
            continue;

        mem_k=pr->mem_bytes/1024UL;
        mem_pm=total_k ? (mem_k*1000UL)/total_k : 0;
        format_percent_1(cpup,pr->cpu_per_mille);
        format_percent_1(memp,mem_pm);

        snprintf(line,sizeof(line),"%5d %3d %6uK %6s %6s %10u %-27.27s",
            pr->pid,pr->priority,(unsigned)mem_k,cpup,memp,
            (unsigned)pr->total_ticks,pr->name);
        draw_line(screen_row++,line);
        printed++;
    }

    while(printed<TOP_MAX_ROWS)
    {
        draw_line(screen_row++,"");
        printed++;
    }
}

static void draw_footer(void)
{
    char line[128];
    draw_line(23,"");
    snprintf(line,sizeof(line),
        "q/ESC quit   SPACE refresh   P CPU sort   M memory sort   delay %u.%us",
        (unsigned)(TOP_INTERVAL_MS/1000),
        (unsigned)((TOP_INTERVAL_MS%1000)/100));
    draw_line(24,line);
    snprintf(line,sizeof(line),"sort: %s",sort_mode==TOP_SORT_MEM ? "memory" : "CPU");
    draw_line(25,line);
}

static void draw_screen(void)
{
    _setcursortype(_NOCURSOR);
    draw_header();
    draw_processes();
    draw_footer();
}

/* Wait without treating getch1()==0 (no key) as input.  Returns zero only
 * for an explicit quit key.  SPACE/P/M request an immediate new frame. */
static int wait_refresh(void)
{
    int elapsed;
    int ch;

    for(elapsed=0;elapsed<TOP_INTERVAL_MS;elapsed+=TOP_POLL_MS)
    {
        ch=getch1();
        if(ch==27 || ch=='q' || ch=='Q')
            return 0;
        if(ch=='p' || ch=='P')
        {
            sort_mode=TOP_SORT_CPU;
            return 1;
        }
        if(ch=='m' || ch=='M')
        {
            sort_mode=TOP_SORT_MEM;
            return 1;
        }
        if(ch==' ')
            return 1;
        Sleep(TOP_POLL_MS);
    }
    return 1;
}

static void do_top(void)
{
    clrscr();
    _setcursortype(_NOCURSOR);
    draw_line(1,"top - sampling CPU activity...");

    /* Prime cumulative counters so the first full frame describes one
     * interval rather than all CPU time accumulated since boot. */
    do_update();
    if(!wait_refresh())
    {
        _setcursortype(_NORMALCURSOR);
        return;
    }

    for(;;)
    {
        do_update();
        do_sort();
        draw_screen();
        if(!wait_refresh())
            break;
    }

    _setcursortype(_NORMALCURSOR);
    gotoxy(1,25);
    printf("\n");
}

static int do_args(int argc,char **argv)
{
    int i;
    for(i=1;i<argc;i++)
    {
        if(!strcmp(argv[i],"-h") || !strcmp(argv[i],"--help"))
            return 1;
    }
    return 0;
}

static void do_help(void)
{
    printf("top - display JTMOS CPU, memory and process activity\n");
    printf("The display refreshes continuously once per second.\n");
    printf("Keys: q/ESC quit, SPACE refresh, P sort by CPU, M sort by memory.\n");
}

int main(int argc,char **argv)
{
    if(do_args(argc,argv))
    {
        do_help();
        return 0;
    }

    do_init();
    do_top();
    return 0;
}
