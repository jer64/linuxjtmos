APPNAME=tsr
include app-common.mk
