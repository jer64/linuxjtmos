#!/bin/sh
# Compatibility entry point for the canonical V67.8 package builder.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
exec make -C "$ROOT" packages
