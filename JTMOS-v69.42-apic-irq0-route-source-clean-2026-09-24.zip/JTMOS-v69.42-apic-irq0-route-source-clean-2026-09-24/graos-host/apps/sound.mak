# JTMOS V67 static ELF32 application
APPNAME=sound
include app-common.mk
