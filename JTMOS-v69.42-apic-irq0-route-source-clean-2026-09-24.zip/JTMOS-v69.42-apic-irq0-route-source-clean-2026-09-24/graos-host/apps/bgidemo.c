/* bgidemo.c - JTMOS Turbo C BGI/GraOS runtime smoke test. */
#include <graphics.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <jtmos/process.h>

/* Keep the official test deterministic even on kernels where process mmap
 * growth is disabled or under diagnosis. */
SYSMEMREQ(APPRAM_4096K)

static int fail(const char *what)
{
    closegraph();
    printf("BGI SELFTEST: FAIL: %s\n",what);
    return 1;
}

int main(void)
{
    int gd=DETECT,gm=VGAHI,e;
    unsigned bytes;
    void *img;

    printf("BGI SELFTEST: starting (GraOS PID=%d)\n",GetThreadPID("guiserver"));
    initgraph(&gd,&gm,"");
    e=graphresult();
    if(e!=grOk){
        printf("BGI SELFTEST: initgraph FAIL: %s\n",grapherrormsg(e));
        printf("BGI SELFTEST: backend rc=%d\n",jtmos_graph_backend_error());
        printf("BGI SELFTEST: start GraOS with 'graos' and retry if PID is <= 0.\n");
        return 1;
    }

    if(!jtmos_graph_active())return fail("BGI window did not become active");
    if(getmaxx()!=639 || getmaxy()!=479)return fail("VGAHI dimensions are not 640x480");

    jtmos_graph_autorefresh(0);
    setbkcolor(BLACK);
    cleardevice();

    putpixel(7,9,LIGHTRED);
    if(getpixel(7,9)!=LIGHTRED)return fail("putpixel/getpixel readback");

    setcolor(LIGHTGREEN);
    line(20,20,120,20);
    if(getpixel(20,20)!=LIGHTGREEN || getpixel(120,20)!=LIGHTGREEN)
        return fail("line endpoint readback");

    setfillstyle(SOLID_FILL,BLUE);
    bar(40,40,100,80);
    if(getpixel(60,60)!=BLUE)return fail("solid bar fill readback");

    setviewport(120,100,220,200,1);
    putpixel(3,4,YELLOW);
    if(getpixel(3,4)!=YELLOW)return fail("viewport coordinate/readback");
    setviewport(0,0,639,479,1);

    bytes=imagesize(40,40,100,80);
    if(bytes==0)return fail("imagesize returned zero");
    img=malloc(bytes);
    if(!img)return fail("image buffer allocation");
    getimage(40,40,100,80,img);
    setfillstyle(SOLID_FILL,BLACK);
    bar(40,40,100,80);
    putimage(140,40,img,COPY_PUT);
    free(img);
    if(getpixel(160,60)!=BLUE)return fail("getimage/putimage readback");

    /* Visual coverage for primitives that are easiest to inspect by eye. */
    setcolor(LIGHTCYAN);
    rectangle(20,20,getmaxx()-20,getmaxy()-20);
    setcolor(YELLOW);
    circle(getmaxx()/2,getmaxy()/2,90);
    setcolor(LIGHTMAGENTA);
    ellipse(getmaxx()/2,getmaxy()/2,0,360,150,70);
    setfillstyle(SOLID_FILL,DARKGRAY);
    bar(230,330,410,380);
    setcolor(WHITE);
    outtextxy(245,345,"BGI SELFTEST PASS");
    setcolor(LIGHTGREEN);
    line(20,getmaxy()-40,getmaxx()-20,40);
    jtmos_graph_present();

    printf("BGI SELFTEST: primitive/readback checks PASS.\n");
    printf("BGI SELFTEST: press any key in the BGI window to test GraOS key events.\n");
    (void)getch();
    printf("BGI SELFTEST: keyboard event PASS.\n");
    closegraph();
    printf("BGI SELFTEST: PASS.\n");
    return 0;
}
