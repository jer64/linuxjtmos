// ----------------------------------------------------------------
// mkfs.c - make a JTMOS file system
// (C) 2002-2003 by Jari Tuominen
// ----------------------------------------------------------------
#include <stdio.h>
#include <string.h>
#include <jtmos/filefind.h>
#include <jtmos/directdisk.h>

static void do_help(void)
{
    printf("Usage: mkfs device [device ...]\n");
    printf("Examples:\n");
    printf("  mkfs ram\n");
    printf("  mkfs sys\n");
    printf("  mkfs floppy\n");
    printf("  mkfs hda    (JTMFS + boot loader + 1 MiB kernel reservation)\n");
}

static int do_mkfs(const char *path)
{
    int r;
    printf("Formatting drive %s: ... ", path);
    r=formatDrive(path);
    if(r)
    {
        printf("\rFormatting failed for device '%s:' (error %d).        \n", path, r);
        if(r==17)
            printf("mkfs: JTMFS was created, but no BIOS boot floppy was available for the 1 MiB kernel install.\n");
        else if(r==18)
            printf("mkfs: JTMFS was created, but the 1 MiB boot-kernel copy/verification failed.\n");
        return 1;
    }
    printf("\rFormatting of drive %s: completed.      \n", path);
    if(!strcmp(path,"hda") || !strcmp(path,"hda:"))
        printf("mkfs: bootable JTMFS reserves and verifies a full 1 MiB kernel payload.\n");
    return 0;
}

int main(int argc, char **argv)
{
    int i,rc=0;
    if(argc<2)
    {
        do_help();
        return 2;
    }
    if(!strcmp(argv[1],"-h") || !strcmp(argv[1],"--help"))
    {
        do_help();
        return 0;
    }
    for(i=1;i<argc;i++)
        if(do_mkfs(argv[i])) rc=1;
    return rc;
}
