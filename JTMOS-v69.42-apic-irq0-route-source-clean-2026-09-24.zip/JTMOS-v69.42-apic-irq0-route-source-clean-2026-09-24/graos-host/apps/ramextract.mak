# JTMOS V67 static ELF32 application
APPNAME=ramextract
include app-common.mk
