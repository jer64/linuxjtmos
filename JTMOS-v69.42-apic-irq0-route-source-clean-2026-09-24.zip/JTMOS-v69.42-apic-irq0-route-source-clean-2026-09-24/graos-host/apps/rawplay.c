// Audio Player Application
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jtmos/directdisk.h>
#include <jtmos/video.h>

#define AUDIO_CAPACITY (1024U*512U)

// Request 1024K of RAM from the init process.
SYSMEMREQ(APPRAM_1024K)

//
typedef struct
{
	int len;
}AUD;
AUD au;

//
DWORD audioOffs=0;

//
int read_audio(const char *fname, BYTE *audio)
{
	int i,d;
	FILE *f;

	if(fname==NULL || audio==NULL)
		return 1;

	//
	printf("Reading %s\n", fname);

	//
	f=fopen(fname, "rb");
	if(!f)
	{
		//
		printf("File not found.\n");
		return 1;
	}

	//
	for(i=0; i<(int)AUDIO_CAPACITY; i++)
	{
		//
		if( !(i&1023) ) { printf("."); }
		if( (d = fgetc(f))==EOF )break;
		audio[i] = d;
	}
	if(i==(int)AUDIO_CAPACITY && fgetc(f)!=EOF)
	{
		printf("\nrawplay: input is larger than %u bytes.\n",
		       (unsigned)AUDIO_CAPACITY);
		fclose(f);
		return 2;
	}

	//
	au.len = i;
	fclose(f);
	printf("\nRead done.\n");
	return 0;
}

//
void PlayMoreAudio(BYTE *audio)
{
	int amount;

	if(audio==NULL || au.len<=0)
		return;
	amount=au.len-(int)audioOffs;
	if(amount>1024*32) amount=1024*32;
	if(amount<=0) { audioOffs=0; amount=au.len; }
	if(amount>1024*32) amount=1024*32;

	//
	SendAudio(audio+audioOffs, amount, 0, 11025);
	audioOffs+=(DWORD)amount;
	if(audioOffs>=(DWORD)au.len) audioOffs=0;
}

//
void WaitUser(BYTE *audio)
{
	int key=0;
	WORD pos;

	//
	printf("Press 'm' to send more audio data\n");
	printf("Press 'r' to init audio device(may be needed)\n");
	printf("Press 'z' to play from start\n");
	printf("Press ESC to quit\n");
	while(key!=27)
	{
		key=getch1();
		printf( "Audio position = 0x%x      \r", (pos=GetAudioPosition()) );
		if(key=='z')
		{
			audioOffs=0;
			PlayMoreAudio(audio);
		}
		if(key=='\n' || key=='m' || pos>=0xff00)
		{
			//printf("Sending more audio to play ...                \n");
			PlayMoreAudio(audio);
		}
		if(key=='r')
		{
			printf("Commencing audio device init ...               \n");
			InitAudio();
		}
	}
	printf("User pressed ESC key, quiting ...                  \n");
}

void play_audio(BYTE *audio)
{
	printf("Press any key to play audio \n");
	getch();

	PlayMoreAudio(audio);

	WaitUser(audio);
}

int main(int argc, char **argv)
{
	BYTE *audio;

	if(argc<2)
	{
		printf("JTMOS audio demo - Cheering up the user.\n");
		printf("Will read audio from floppy & play it.\n");
		printf("Format: 8-bit, mono, 11 Khz\n");
		printf("Usage: rawplay [audio.raw]\n");
		return 0;
	}

	printf("Requires 512K RAM ");
	audio=malloc(AUDIO_CAPACITY);
	if(!audio) { exit(2); }
	memset(audio, 0x80, AUDIO_CAPACITY);
	printf("\r                       \r");
	InitAudio();
	if(read_audio(argv[1],audio))
	{
		free(audio);
		return 3;
	}
	if(au.len<=0)
	{
		printf("rawplay: input contains no audio data.\n");
		free(audio);
		return 3;
	}
	play_audio(audio);
	free(audio);

	printf("Exit.\n");
	return 0;
}
