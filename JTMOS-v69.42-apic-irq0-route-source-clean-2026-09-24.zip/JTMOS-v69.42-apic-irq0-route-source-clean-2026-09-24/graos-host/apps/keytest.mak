# JTMOS V67 static ELF32 application
APPNAME=keytest
include app-common.mk
