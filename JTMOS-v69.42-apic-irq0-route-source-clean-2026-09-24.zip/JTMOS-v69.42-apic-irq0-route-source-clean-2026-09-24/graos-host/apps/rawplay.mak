# JTMOS V67 static ELF32 application
APPNAME=rawplay
include app-common.mk
