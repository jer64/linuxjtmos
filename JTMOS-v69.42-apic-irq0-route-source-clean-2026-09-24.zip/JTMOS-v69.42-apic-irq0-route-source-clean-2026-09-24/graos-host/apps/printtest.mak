# JTMOS V67 static ELF32 application
APPNAME=printtest
include app-common.mk
