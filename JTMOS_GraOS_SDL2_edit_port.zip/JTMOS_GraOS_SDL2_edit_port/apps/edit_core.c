/*
 * edit_core.c - portable document model for the classic JTMOS edit editor.
 *
 * The 2003/2008 editor mixed terminal rendering, keyboard input and the text
 * buffer in one loop.  This version keeps the document model independent so
 * native JTMOS and SDL2/GraOS can render the very same ed.buf[] contents.
 */
#include "edit.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

EDITOR ed;

static void touch(void)
{
    ed.view.upd = 1;
    ed.revision++;
}

static void set_status(const char *s)
{
    size_t n;
    if(!s) s = "";
    n = strlen(s);
    if(n >= sizeof(ed.status)) n = sizeof(ed.status)-1;
    memcpy(ed.status, s, n);
    ed.status[n] = 0;
    touch();
}

static int clampi(int v, int lo, int hi)
{
    if(v < lo) return lo;
    if(v > hi) return hi;
    return v;
}

static void ensure_cursor_visible(void)
{
    int rows = ed.viewport_rows > 0 ? ed.viewport_rows : EDIT_DEFAULT_ROWS;
    int cols = ed.viewport_cols > 0 ? ed.viewport_cols : EDIT_COLUMNS;

    if(ed.cursor.y < ed.view.y)
        ed.view.y = ed.cursor.y;
    if(ed.cursor.y >= ed.view.y + rows)
        ed.view.y = ed.cursor.y - rows + 1;
    if(ed.cursor.x < ed.view.x)
        ed.view.x = ed.cursor.x;
    if(ed.cursor.x >= ed.view.x + cols)
        ed.view.x = ed.cursor.x - cols + 1;
    if(ed.view.y < 0) ed.view.y = 0;
    if(ed.view.x < 0) ed.view.x = 0;
}

static void clear_lines(void)
{
    int i;
    if(!ed.storage) return;
    memset(ed.storage, 0, (size_t)MAX_LINES * (size_t)MAX_PER_LINE);
    for(i=0; i<MAX_LINES; ++i)
        ed.buf[i] = ed.storage + (size_t)i * (size_t)MAX_PER_LINE;
    ed.lines = 1;
}

int EditorInit(void)
{
    memset(&ed, 0, sizeof(ed));
    ed.storage = (char *)calloc((size_t)MAX_LINES, (size_t)MAX_PER_LINE);
    if(!ed.storage)
        return -1;
    clear_lines();
    ed.insertMode = 1;
    ed.viewport_cols = EDIT_COLUMNS;
    ed.viewport_rows = EDIT_DEFAULT_ROWS;
    strcpy(ed.filename, "Untitled");
    strcpy(ed.status, "Ready");
    ed.revision = 1;
    ed.view.upd = 1;
    return 0;
}

void EditorShutdown(void)
{
    free(ed.storage);
    memset(&ed, 0, sizeof(ed));
}

void EditorReset(void)
{
    char *storage = ed.storage;
    int cols = ed.viewport_cols;
    int rows = ed.viewport_rows;
    char filename[sizeof(ed.filename)];

    if(!storage) return;
    memcpy(filename, ed.filename, sizeof(filename));
    memset(&ed, 0, sizeof(ed));
    ed.storage = storage;
    ed.viewport_cols = cols > 0 ? cols : EDIT_COLUMNS;
    ed.viewport_rows = rows > 0 ? rows : EDIT_DEFAULT_ROWS;
    memcpy(ed.filename, filename, sizeof(ed.filename));
    clear_lines();
    ed.insertMode = 1;
    strcpy(ed.status, "Ready");
    ed.revision = 1;
    ed.view.upd = 1;
}

void EditorSetFilename(const char *fname)
{
    size_t n;
    if(!fname || !*fname) fname = "Untitled";
    n = strlen(fname);
    if(n >= sizeof(ed.filename)) n = sizeof(ed.filename)-1;
    memcpy(ed.filename, fname, n);
    ed.filename[n] = 0;
    touch();
}

void EditorSetViewport(int cols, int rows)
{
    ed.viewport_cols = clampi(cols, 1, EDIT_COLUMNS);
    ed.viewport_rows = clampi(rows, 1, MAX_LINES);
    ensure_cursor_visible();
    touch();
}

int GetWritePointX(void) { return ed.cursor.x; }
int GetWritePointY(void) { return ed.cursor.y; }

const char *EditorGetLine(int line)
{
    if(!ed.storage || line < 0 || line >= MAX_LINES)
        return "";
    return ed.buf[line];
}

int EditorGetLineLength(int line)
{
    return (int)strlen(EditorGetLine(line));
}

void EmptyLine(char *s)
{
    if(s) s[0] = 0;
}

void OrderRefresh(void) { touch(); }

void ViewUp(int much)
{
    if(much < 0) { ViewDown(-much); return; }
    ed.view.y -= much;
    if(ed.view.y < 0) ed.view.y = 0;
    touch();
}

void ViewDown(int much)
{
    int max_top;
    if(much < 0) { ViewUp(-much); return; }
    max_top = MAX_LINES - (ed.viewport_rows > 0 ? ed.viewport_rows : 1);
    if(max_top < 0) max_top = 0;
    ed.view.y += much;
    if(ed.view.y > max_top) ed.view.y = max_top;
    touch();
}

void CursorHome(void)
{
    ed.cursor.x = 0;
    ensure_cursor_visible();
    touch();
}

void CursorEnd(void)
{
    ed.cursor.x = EditorGetLineLength(ed.cursor.y);
    if(ed.cursor.x > EDIT_COLUMNS) ed.cursor.x = EDIT_COLUMNS;
    ensure_cursor_visible();
    touch();
}

void CursorUp(void)
{
    if(ed.cursor.y > 0) ed.cursor.y--;
    ed.cursor.x = clampi(ed.cursor.x, 0, EditorGetLineLength(ed.cursor.y));
    ensure_cursor_visible();
    touch();
}

void CursorDown(void)
{
    if(ed.cursor.y + 1 < ed.lines) ed.cursor.y++;
    ed.cursor.x = clampi(ed.cursor.x, 0, EditorGetLineLength(ed.cursor.y));
    ensure_cursor_visible();
    touch();
}

void CursorLeft(void)
{
    if(ed.cursor.x > 0) {
        ed.cursor.x--;
    } else if(ed.cursor.y > 0) {
        ed.cursor.y--;
        ed.cursor.x = EditorGetLineLength(ed.cursor.y);
    }
    ensure_cursor_visible();
    touch();
}

void CursorRight(void)
{
    int len = EditorGetLineLength(ed.cursor.y);
    if(ed.cursor.x < len && ed.cursor.x < EDIT_COLUMNS) {
        ed.cursor.x++;
    } else if(ed.cursor.y + 1 < ed.lines) {
        ed.cursor.y++;
        ed.cursor.x = 0;
    }
    ensure_cursor_visible();
    touch();
}

void CursorPageUp(void)
{
    int n = ed.viewport_rows > 1 ? ed.viewport_rows - 1 : 1;
    ed.cursor.y -= n;
    if(ed.cursor.y < 0) ed.cursor.y = 0;
    ed.cursor.x = clampi(ed.cursor.x, 0, EditorGetLineLength(ed.cursor.y));
    ensure_cursor_visible();
    touch();
}

void CursorPageDown(void)
{
    int n = ed.viewport_rows > 1 ? ed.viewport_rows - 1 : 1;
    ed.cursor.y += n;
    if(ed.cursor.y >= ed.lines) ed.cursor.y = ed.lines-1;
    if(ed.cursor.y < 0) ed.cursor.y = 0;
    ed.cursor.x = clampi(ed.cursor.x, 0, EditorGetLineLength(ed.cursor.y));
    ensure_cursor_visible();
    touch();
}

static void mark_modified(void)
{
    ed.modified = 1;
    ed.quit_pending = 0;
    set_status("Modified");
}

int StoreChar(int ch)
{
    char *line;
    int len, x;

    if(!ed.storage || ed.cursor.y < 0 || ed.cursor.y >= MAX_LINES)
        return -1;
    if(ch < 0 || ch > 255 || ch == 0)
        return -1;

    line = ed.buf[ed.cursor.y];
    len = (int)strlen(line);
    x = ed.cursor.x;
    if(x < 0) x = 0;
    if(x >= EDIT_COLUMNS)
        return -1;

    if(x > len) {
        memset(line + len, ' ', (size_t)(x-len));
        line[x] = 0;
        len = x;
    }

    if(ed.insertMode) {
        if(len >= EDIT_COLUMNS)
            return -1;
        memmove(line + x + 1, line + x, (size_t)(len-x) + 1u);
        line[x] = (char)ch;
    } else {
        line[x] = (char)ch;
        if(x >= len) line[x+1] = 0;
    }

    if(ed.cursor.y + 1 > ed.lines) ed.lines = ed.cursor.y + 1;
    if(ed.cursor.x < EDIT_COLUMNS) ed.cursor.x++;
    mark_modified();
    ensure_cursor_visible();
    return 0;
}

static int insert_empty_line_after(int y)
{
    int i;
    if(ed.lines >= MAX_LINES) return -1;
    if(y < -1 || y >= MAX_LINES-1) return -1;
    for(i=ed.lines; i>y+1; --i)
        memcpy(ed.buf[i], ed.buf[i-1], MAX_PER_LINE);
    ed.buf[y+1][0] = 0;
    ed.lines++;
    return 0;
}

int EditorNewLine(void)
{
    char tail[MAX_PER_LINE];
    char *line;
    int len, x;

    if(ed.cursor.y < 0 || ed.cursor.y >= MAX_LINES) return -1;
    line = ed.buf[ed.cursor.y];
    len = (int)strlen(line);
    x = clampi(ed.cursor.x, 0, len);
    strcpy(tail, line + x);
    line[x] = 0;
    if(insert_empty_line_after(ed.cursor.y) != 0) {
        strcpy(line + x, tail);
        return -1;
    }
    strcpy(ed.buf[ed.cursor.y+1], tail);
    ed.cursor.y++;
    ed.cursor.x = 0;
    mark_modified();
    ensure_cursor_visible();
    return 0;
}

void CursorEnter(void)
{
    (void)EditorNewLine();
}

int EditorBackspace(void)
{
    char *line;
    int len;

    if(ed.cursor.x > 0) {
        line = ed.buf[ed.cursor.y];
        len = (int)strlen(line);
        if(ed.cursor.x <= len) {
            memmove(line + ed.cursor.x - 1,
                    line + ed.cursor.x,
                    (size_t)(len - ed.cursor.x) + 1u);
        }
        ed.cursor.x--;
        mark_modified();
        ensure_cursor_visible();
        return 0;
    }

    if(ed.cursor.y > 0) {
        int prev = ed.cursor.y - 1;
        int prevlen = EditorGetLineLength(prev);
        int curlen = EditorGetLineLength(ed.cursor.y);
        int i;
        if(prevlen + curlen > EDIT_COLUMNS)
            return -1;
        strcat(ed.buf[prev], ed.buf[ed.cursor.y]);
        for(i=ed.cursor.y; i<ed.lines-1; ++i)
            memcpy(ed.buf[i], ed.buf[i+1], MAX_PER_LINE);
        if(ed.lines > 1) {
            ed.lines--;
            ed.buf[ed.lines][0] = 0;
        }
        ed.cursor.y = prev;
        ed.cursor.x = prevlen;
        mark_modified();
        ensure_cursor_visible();
        return 0;
    }
    return 0;
}

int EditorDelete(void)
{
    char *line = ed.buf[ed.cursor.y];
    int len = (int)strlen(line);

    if(ed.cursor.x < len) {
        memmove(line + ed.cursor.x,
                line + ed.cursor.x + 1,
                (size_t)(len-ed.cursor.x));
        mark_modified();
        return 0;
    }

    if(ed.cursor.y + 1 < ed.lines) {
        int nextlen = EditorGetLineLength(ed.cursor.y+1);
        int i;
        if(len + nextlen > EDIT_COLUMNS) return -1;
        strcat(line, ed.buf[ed.cursor.y+1]);
        for(i=ed.cursor.y+1; i<ed.lines-1; ++i)
            memcpy(ed.buf[i], ed.buf[i+1], MAX_PER_LINE);
        ed.lines--;
        ed.buf[ed.lines][0] = 0;
        mark_modified();
    }
    return 0;
}

int EditorLoad(const char *fname)
{
    FILE *f;
    int c, line=0, col=0, last_cr=0;

    if(!ed.storage) return -1;
    EditorSetFilename(fname);
    f = fopen(ed.filename, "rb");
    if(!f) {
        EditorReset();
        EditorSetFilename(fname);
        set_status("New file");
        return 1;
    }

    clear_lines();
    while((c=fgetc(f)) != EOF && line < MAX_LINES) {
        if(c == '\r') {
            ed.buf[line][col] = 0;
            line++;
            col=0;
            last_cr=1;
            continue;
        }
        if(c == '\n') {
            if(last_cr) { last_cr=0; continue; }
            ed.buf[line][col] = 0;
            line++;
            col=0;
            continue;
        }
        last_cr=0;
        if(c == 0) break;
        if(c == '\t') {
            int spaces = 8 - (col & 7);
            while(spaces-- > 0 && line < MAX_LINES) {
                if(col >= EDIT_COLUMNS) { line++; col=0; if(line>=MAX_LINES) break; }
                ed.buf[line][col++]=' ';
            }
            continue;
        }
        if(col >= EDIT_COLUMNS) {
            ed.buf[line][EDIT_COLUMNS]=0;
            line++;
            col=0;
            if(line>=MAX_LINES) break;
        }
        ed.buf[line][col++] = (char)c;
        ed.buf[line][col] = 0;
    }
    fclose(f);

    ed.lines = line + ((line < MAX_LINES && (col>0 || line==0)) ? 1 : 0);
    if(ed.lines < 1) ed.lines=1;
    if(ed.lines > MAX_LINES) ed.lines=MAX_LINES;
    ed.cursor.x=ed.cursor.y=0;
    ed.view.x=ed.view.y=0;
    ed.modified=0;
    ed.quit_pending=0;
    set_status("File loaded");
    return 0;
}

int EditorSave(const char *fname)
{
    FILE *f;
    int y;
    if(fname && *fname) EditorSetFilename(fname);
    f = fopen(ed.filename, "wb");
    if(!f) {
        set_status("Save failed");
        return 1;
    }
    for(y=0; y<ed.lines; ++y) {
        if(fputs(ed.buf[y], f) == EOF || fputc('\n', f) == EOF) {
            fclose(f);
            set_status("Save failed");
            return 1;
        }
    }
    if(fclose(f) != 0) {
        set_status("Save failed");
        return 1;
    }
    ed.modified=0;
    ed.quit_pending=0;
    set_status("File saved");
    return 0;
}

int EditorSaveCurrent(void)
{
    return EditorSave(ed.filename);
}

int EditorHandleKey(int key)
{
    int rc = EDIT_ACTION_REDRAW;

    switch(key) {
        case EDIT_KEY_UP:       CursorUp(); return rc;
        case EDIT_KEY_DOWN:     CursorDown(); return rc;
        case EDIT_KEY_LEFT:     CursorLeft(); return rc;
        case EDIT_KEY_RIGHT:    CursorRight(); return rc;
        case EDIT_KEY_HOME:     CursorHome(); return rc;
        case EDIT_KEY_END:      CursorEnd(); return rc;
        case EDIT_KEY_PAGEUP:   CursorPageUp(); return rc;
        case EDIT_KEY_PAGEDOWN: CursorPageDown(); return rc;
        case EDIT_KEY_INSERT:
            ed.insertMode = !ed.insertMode;
            set_status(ed.insertMode ? "Insert mode" : "Overwrite mode");
            return rc;
        case EDIT_KEY_DELETE:
            if(EditorDelete()!=0) rc |= EDIT_ACTION_ERROR;
            return rc;
        case EDIT_KEY_F1:
            ed.help_visible = !ed.help_visible;
            set_status(ed.help_visible ? "Help shown" : "Help hidden");
            return rc;
        case EDIT_KEY_F2:
        case 15: /* Ctrl-O after SDL/JTMOS control translation */
            if(EditorSaveCurrent()==0) rc |= EDIT_ACTION_SAVED;
            else rc |= EDIT_ACTION_ERROR;
            return rc;
        case EDIT_KEY_F10:
        case 24: /* Ctrl-X */
            if(ed.modified && !ed.quit_pending) {
                ed.quit_pending=1;
                set_status("Modified: Ctrl-O saves, Ctrl-X again discards");
                return rc;
            }
            return rc | EDIT_ACTION_EXIT;
        case 8:
            if(EditorBackspace()!=0) rc |= EDIT_ACTION_ERROR;
            return rc;
        case 10:
        case 13:
            if(EditorNewLine()!=0) rc |= EDIT_ACTION_ERROR;
            return rc;
        case 27:
            ed.quit_pending=0;
            set_status("Ready");
            return rc;
        default:
            break;
    }

    if(key >= 32 && key <= 255) {
        if(StoreChar(key)!=0) {
            set_status("Line is full");
            rc |= EDIT_ACTION_ERROR;
        }
        return rc;
    }
    return EDIT_ACTION_NONE;
}
