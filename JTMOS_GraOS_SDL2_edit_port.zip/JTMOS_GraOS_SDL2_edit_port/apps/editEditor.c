/* Native JTMOS text-console frontend. SDL2/GraOS uses graos_edit_gui.c. */
#include "edit.h"
#include "editEditor.h"

#ifndef JTMOS_HOST_LINUX_SDL2
#include <stdio.h>
#include <conio.h>

int Editor(const char *fname)
{
    int key, action;
    if(EditorInit()!=0) return 1;
    (void)EditorLoad(fname);
    clrscr();
    for(;;) {
        int row;
        if(ed.view.upd) {
            clrscr();
            gotoxy(1,1);
            printf("JTMOS edit - %s%s\n", ed.filename, ed.modified ? " *" : "");
            for(row=0; row<EDIT_DEFAULT_ROWS-1; ++row) {
                int docrow=ed.view.y+row;
                gotoxy(1,row+2);
                printf("%-80.80s", docrow<ed.lines ? EditorGetLine(docrow) : "");
            }
            ed.view.upd=0;
        }
        gotoxy(ed.cursor.x+1, (ed.cursor.y-ed.view.y)+2);
        key=getch();
        action=EditorHandleKey(key);
        if(action & EDIT_ACTION_EXIT) break;
    }
    EditorShutdown();
    return 0;
}
#else
int Editor(const char *fname) { (void)fname; return -1; }
#endif
