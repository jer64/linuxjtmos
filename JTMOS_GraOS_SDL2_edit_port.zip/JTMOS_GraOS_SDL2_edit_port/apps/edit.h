#ifndef JTMOS_EDIT_H
#define JTMOS_EDIT_H

#include <stddef.h>

/* Historic JTMOS edit limits: 5000 lines, 80 visible characters/line. */
#define MAX_LINES         5000
#define EDIT_COLUMNS      80
#define MAX_PER_LINE      (EDIT_COLUMNS + 1) /* + NUL: fixes original 80-byte OOB */
#define EDIT_DEFAULT_ROWS 23

/* EditorHandleKey() result bits. */
#define EDIT_ACTION_NONE    0x00
#define EDIT_ACTION_REDRAW  0x01
#define EDIT_ACTION_SAVED   0x02
#define EDIT_ACTION_EXIT    0x04
#define EDIT_ACTION_ERROR   0x08

/* JTMOS/DOS-compatible extended key encoding used by the SDL2 bridge. */
#define EDIT_KEY_EXT(scan)  (0x100 | ((scan) & 0xff))
#define EDIT_KEY_UP         EDIT_KEY_EXT(0x48)
#define EDIT_KEY_DOWN       EDIT_KEY_EXT(0x50)
#define EDIT_KEY_LEFT       EDIT_KEY_EXT(0x4b)
#define EDIT_KEY_RIGHT      EDIT_KEY_EXT(0x4d)
#define EDIT_KEY_HOME       EDIT_KEY_EXT(0x47)
#define EDIT_KEY_END        EDIT_KEY_EXT(0x4f)
#define EDIT_KEY_PAGEUP     EDIT_KEY_EXT(0x49)
#define EDIT_KEY_PAGEDOWN   EDIT_KEY_EXT(0x51)
#define EDIT_KEY_INSERT     EDIT_KEY_EXT(0x52)
#define EDIT_KEY_DELETE     EDIT_KEY_EXT(0x53)
#define EDIT_KEY_F1         EDIT_KEY_EXT(0x3b)
#define EDIT_KEY_F2         EDIT_KEY_EXT(0x3c)
#define EDIT_KEY_F10        EDIT_KEY_EXT(0x44)

typedef struct
{
    int ctrl, alt;

    /* Lines point into storage; each line owns EDIT_COLUMNS + NUL bytes. */
    char *buf[MAX_LINES];
    char *storage;
    int lines;

    int insertMode;
    int modified;
    int help_visible;
    int quit_pending;

    /* Logical document cursor, zero based. */
    struct { int x, y; } cursor;

    /* First visible document cell and redraw trigger. */
    struct { int x, y; int upd; } view;
    int viewport_cols;
    int viewport_rows;

    unsigned long revision;
    char filename[256];
    char status[160];
} EDITOR;

extern EDITOR ed;

int  EditorInit(void);
void EditorShutdown(void);
void EditorReset(void);
void EditorSetFilename(const char *fname);
void EditorSetViewport(int cols, int rows);
int  EditorLoad(const char *fname);
int  EditorSave(const char *fname);
int  EditorSaveCurrent(void);

void ViewUp(int much);
void ViewDown(int much);
void CursorEnter(void);
void CursorUp(void);
void CursorDown(void);
void CursorLeft(void);
void CursorRight(void);
void CursorHome(void);
void CursorEnd(void);
void CursorPageUp(void);
void CursorPageDown(void);

int  StoreChar(int ch);
int  EditorBackspace(void);
int  EditorDelete(void);
int  EditorNewLine(void);
int  EditorHandleKey(int key);

int  GetWritePointX(void);
int  GetWritePointY(void);
const char *EditorGetLine(int line);
int  EditorGetLineLength(int line);
void OrderRefresh(void);
void EmptyLine(char *s);

#endif
