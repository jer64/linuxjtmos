/* Classic JTMOS edit program entry point. */
#include "edit.h"
#include "editEditor.h"
#include <string.h>

#ifdef JTMOS
#include "kernel32.h"
SYSMEMREQ(APPRAM_1024K)
#endif

int main(int argc, char **argv)
{
    const char *fname = argc>=2 ? argv[1] : "Untitled";
    return Editor(fname);
}
