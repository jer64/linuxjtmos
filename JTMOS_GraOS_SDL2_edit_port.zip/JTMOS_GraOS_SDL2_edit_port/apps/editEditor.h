#ifndef JTMOS_EDITEDITOR_H
#define JTMOS_EDITEDITOR_H
int Editor(const char *fname);
#endif
