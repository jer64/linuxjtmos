#ifndef __INCLUDED_ENVINT_H__
#define __INCLUDED_ENVINT_H__

/* SYS_env operation numbers shared by kernel and libc. */
#define JTMOS_ENV_GET_LOCAL      0
#define JTMOS_ENV_SET_LOCAL      1
#define JTMOS_ENV_UNSET_LOCAL    2
#define JTMOS_ENV_COUNT_LOCAL    3
#define JTMOS_ENV_ENTRY_LOCAL    4
#define JTMOS_ENV_GET_GLOBAL     5
#define JTMOS_ENV_SET_GLOBAL     6
#define JTMOS_ENV_UNSET_GLOBAL   7
#define JTMOS_ENV_COUNT_GLOBAL   8
#define JTMOS_ENV_ENTRY_GLOBAL   9

void initEnvDatabase(void);
int ksetenv(ENVDB *e,const char *name,const char *value);
int kgetenv(ENVDB *e,const char *name,char *value);
int kgetenv_ex(ENVDB *e,const char *name,char *value,unsigned int capacity);

int ksetglobalenv(const char *name,const char *value,int overwrite);
int kunsetglobalenv(const char *name);
int kgetglobalenv(const char *name,char *value,unsigned int capacity);
const char *kgetglobalenv_ptr(const char *name);

ENVDB *ProcessEnvGetDB(int pid,int create_if_missing);
int ProcessEnvInherit(int child,int parent);
void ProcessEnvRelease(int pid);
int ProcessEnvSet(int pid,const char *name,const char *value,int overwrite);
int ProcessEnvUnset(int pid,const char *name);
int ProcessEnvGet(int pid,const char *name,char *value,unsigned int capacity);
int ProcessEnvCount(int pid);
const char *ProcessEnvEntry(int pid,int index);

extern ENVDB *kenv;
#endif
