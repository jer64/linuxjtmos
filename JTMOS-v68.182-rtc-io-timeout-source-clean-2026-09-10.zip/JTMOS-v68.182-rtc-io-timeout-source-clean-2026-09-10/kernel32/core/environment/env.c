// env.c - POSIX-style environmental variable database.
#include "kernel32.h"
#include "env.h"

/* Early boot callers can ask for an environment value before the kernel
 * environment database has been allocated.  Return a stable empty C string
 * instead of NULL for that one case so debug/boot code can safely do
 * `if(value[0])` without a special pre-environment branch.  A genuinely
 * missing variable in an initialized database still returns NULL. */
static char static_string_null_terminated[2]={0,0};

static int envdb_find_slot(const ENVDB *e,const char *name)
{
    unsigned int nl;
    int i;
    if(e==NULL || e->magic!=__ENV_MAGIC || !envdb_ValidName(name)) return -1;
    nl=(unsigned int)strlen(name);
    for(i=0;i<e->n_vars;i++) {
        const char *p=e->var[i];
        if(p!=NULL && !strncmp(p,name,nl) && p[nl]=='=') return i;
    }
    return -1;
}

int envdb_ValidName(const char *name)
{
    const char *p;
    if(name==NULL || !name[0]) return 0;
    for(p=name;*p;p++) if(*p=='=') return 0;
    return 1;
}

ENVDB *envdb_CreateVariableDatabase(void)
{
    ENVDB *e=(ENVDB *)malloc(sizeof(ENVDB));
    if(e==NULL) return NULL;
    memset(e,0,sizeof(*e));
    e->magic=__ENV_MAGIC;
    e->n_vars=__N_MAX_VARS_IN_ENVDB;
    return e;
}

void envdb_DestroyVariableDatabase(ENVDB *e)
{
    int i;
    if(e==NULL || e->magic!=__ENV_MAGIC) return;
    for(i=0;i<e->n_vars;i++) {
        if(e->var[i]!=NULL) { free(e->var[i]); e->var[i]=NULL; }
    }
    e->used=0;
    e->magic=0;
    free(e);
}

int envdb_Clear(ENVDB *e)
{
    int i;
    if(e==NULL || e->magic!=__ENV_MAGIC) return -EINVAL;
    for(i=0;i<e->n_vars;i++) {
        if(e->var[i]!=NULL) { free(e->var[i]); e->var[i]=NULL; }
    }
    e->used=0;
    return 0;
}

int envdb_SetVariableEx(ENVDB *e,const char *name,const char *value,int overwrite)
{
    unsigned int nl,vl,total;
    int i,slot;
    char *entry;
    if(e==NULL || e->magic!=__ENV_MAGIC || !envdb_ValidName(name) || value==NULL)
        return -EINVAL;
    nl=(unsigned int)strlen(name);
    vl=(unsigned int)strlen(value);
    if(nl>0x7ffffffeU-vl-2U) return -ENOMEM;
    slot=envdb_find_slot(e,name);
    if(slot>=0 && !overwrite) return 0;
    if(slot<0) {
        for(i=0;i<e->n_vars;i++) if(e->var[i]==NULL) { slot=i; break; }
        if(slot<0) return -ENOMEM;
    }
    total=nl+1U+vl+1U;
    entry=(char *)malloc(total);
    if(entry==NULL) return -ENOMEM;
    memcpy(entry,name,nl); entry[nl]='=';
    memcpy(entry+nl+1U,value,vl); entry[nl+1U+vl]=0;
    if(e->var[slot]!=NULL) free(e->var[slot]);
    else e->used++;
    e->var[slot]=entry;
    return 0;
}

int envdb_SetVariable(ENVDB *e,const char *name,const char *value)
{
    return envdb_SetVariableEx(e,name,value,1);
}

const char *envdb_GetValuePtr(const ENVDB *e,const char *name)
{
    int slot;
    char *eq;
    if(e==NULL) return static_string_null_terminated;
    if(e->magic!=__ENV_MAGIC || !envdb_ValidName(name)) return NULL;
    slot=envdb_find_slot(e,name);
    if(slot<0) return NULL;
    eq=strchr(e->var[slot],'=');
    return eq ? eq+1 : NULL;
}

int envdb_GetVariableEx(const ENVDB *e,const char *name,char *content,unsigned int capacity)
{
    const char *v;
    unsigned int len;
    if(content==NULL || capacity==0) return -EINVAL;
    content[0]=0;
    v=envdb_GetValuePtr(e,name);
    if(v==NULL) return -ENOENT;
    len=(unsigned int)strlen(v);
    if(len+1U>capacity) return -ERANGE;
    memcpy(content,v,len+1U);
    return 0;
}

/* Historical kernel API: existing callers use 256-byte buffers. */
int envdb_GetVariable(ENVDB *e,const char *name,char *content)
{
    return envdb_GetVariableEx(e,name,content,256U);
}

int envdb_DeleteVariable(ENVDB *e,const char *name)
{
    int slot;
    if(e==NULL || e->magic!=__ENV_MAGIC || !envdb_ValidName(name)) return -EINVAL;
    slot=envdb_find_slot(e,name);
    if(slot<0) return 0; /* POSIX unsetenv() succeeds when absent. */
    free(e->var[slot]); e->var[slot]=NULL;
    if(e->used>0) e->used--;
    return 0;
}

int envdb_Count(const ENVDB *e)
{
    if(e==NULL || e->magic!=__ENV_MAGIC) return 0;
    return e->used;
}

const char *envdb_EntryAt(const ENVDB *e,int index)
{
    int i,n=0;
    if(e==NULL || e->magic!=__ENV_MAGIC || index<0) return NULL;
    for(i=0;i<e->n_vars;i++) if(e->var[i]!=NULL) {
        if(n==index) return e->var[i];
        n++;
    }
    return NULL;
}

ENVDB *envdb_CloneVariableDatabase(const ENVDB *src)
{
    ENVDB *dst;
    int i,rc;
    const char *entry,*eq;
    char name[256];
    unsigned int nl;
    if(src==NULL || src->magic!=__ENV_MAGIC) return envdb_CreateVariableDatabase();
    dst=envdb_CreateVariableDatabase();
    if(dst==NULL) return NULL;
    for(i=0;i<src->used;i++) {
        entry=envdb_EntryAt(src,i);
        if(entry==NULL) continue;
        eq=strchr(entry,'=');
        if(eq==NULL) continue;
        nl=(unsigned int)(eq-entry);
        if(nl==0 || nl>=sizeof(name)) { envdb_DestroyVariableDatabase(dst); return NULL; }
        memcpy(name,entry,nl); name[nl]=0;
        rc=envdb_SetVariable(dst,name,eq+1);
        if(rc<0) { envdb_DestroyVariableDatabase(dst); return NULL; }
    }
    return dst;
}
