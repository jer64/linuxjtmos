// envint.c - kernel global + per-process POSIX environment interface.
#include "kernel32.h"
#include "env.h"
#include "envint.h"
#include "threads.h"

ENVDB *kenv=NULL;

static ENVDB *env_source_for_parent(int parent)
{
    if(valid_pid(parent) && thread_envdb[parent]!=NULL &&
       thread_envdb[parent]->magic==__ENV_MAGIC)
        return thread_envdb[parent];
    return kenv;
}

void initEnvDatabase(void)
{
    int pid;
    if(kenv!=NULL) {
        dprintk("initEnvDatabase: already initialized.\n");
        return;
    }
    kenv=envdb_CreateVariableDatabase();
    if(kenv==NULL) {
        dprintk("initEnvDatabase: allocation failed; environment disabled.\n");
        return;
    }

    /* POSIX-ish system/process defaults.  Kernel options stay in keropt.c
     * and are intentionally not mirrored into this environment database. */
    ksetglobalenv("PATH","/bin:/usr/bin:ram:/bin:hda:/bin:hda1:/bin",1);
    ksetglobalenv("SHELL","/bin/sqsh.bin",1);
    ksetglobalenv("HOME","/",1);
    ksetglobalenv("PWD","/",1);
    ksetglobalenv("USER",DEFAULT_USER_NAME,1);
    ksetglobalenv("LOGNAME",DEFAULT_USER_NAME,1);
    ksetglobalenv("HOSTNAME",DEFAULT_SYSTEM_NAME,1);
    ksetglobalenv("HOSTTYPE","i386",1);
    ksetglobalenv("OSTYPE","JTMOS",1);
    ksetglobalenv("OS","JTMOS",1);
    ksetglobalenv("TERM","jtmos",1);
    ksetglobalenv("LANG","C",1);
    ksetglobalenv("TMPDIR","/tmp",1);
    ksetglobalenv("WWW_ROOT","cdrom:/",1);
    ksetglobalenv("UNIQUE","/bin/unique.bin",1);
    ksetglobalenv("SCRIPT","/bin/unique.bin",1);
    ksetglobalenv("SCRIPT_EXT",".uni",1);
    ksetglobalenv("LOG_DIR","ram:/logs",1);
    ksetglobalenv("SYSTEM_LOG","ram:/logs/system.log",1);
    ksetglobalenv("WWW_LOG","ram:/logs/www.log",1);
    ksetglobalenv("TELNETD_PORT","2323",1);
    /* TELNETD_PASSWORD intentionally has no compiled-in default.  The daemon
     * refuses to listen until an administrator explicitly sets one. */


    /* PID0/init gets a private snapshot too; every later process inherits a
     * copy from its parent, never a pointer to this global database. */
    pid=GetCurrentThread();
    if(valid_pid(pid)) (void)ProcessEnvInherit(pid,-1);
}

int ksetenv(ENVDB *e,const char *name,const char *value)
{
    return envdb_SetVariable(e,name,value);
}

int kgetenv(ENVDB *e,const char *name,char *value)
{
    return envdb_GetVariable(e,name,value);
}

int kgetenv_ex(ENVDB *e,const char *name,char *value,unsigned int capacity)
{
    return envdb_GetVariableEx(e,name,value,capacity);
}

int ksetglobalenv(const char *name,const char *value,int overwrite)
{
    if(kenv==NULL) return -ENOSYS;
    return envdb_SetVariableEx(kenv,name,value,overwrite);
}

int kunsetglobalenv(const char *name)
{
    if(kenv==NULL) return -ENOSYS;
    return envdb_DeleteVariable(kenv,name);
}

int kgetglobalenv(const char *name,char *value,unsigned int capacity)
{
    /* envdb_GetVariableEx(NULL,...) deliberately yields an empty C string
     * during the short pre-environment boot window. */
    return envdb_GetVariableEx(kenv,name,value,capacity);
}

const char *kgetglobalenv_ptr(const char *name)
{
    return envdb_GetValuePtr(kenv,name);
}

ENVDB *ProcessEnvGetDB(int pid,int create_if_missing)
{
    ENVDB *src;
    if(!valid_pid(pid)) return NULL;
    if(thread_envdb[pid]!=NULL && thread_envdb[pid]->magic==__ENV_MAGIC)
        return thread_envdb[pid];
    if(!create_if_missing) return NULL;
    /* Do not accidentally create a permanently empty process environment if
     * an early boot caller reaches here before initEnvDatabase(). */
    if(kenv==NULL || kenv->magic!=__ENV_MAGIC) return NULL;
    src=env_source_for_parent(-1);
    thread_envdb[pid]=envdb_CloneVariableDatabase(src);
    return thread_envdb[pid];
}

int ProcessEnvInherit(int child,int parent)
{
    ENVDB *src,*copy;
    if(!valid_pid(child)) return -ESRCH;
    if(kenv==NULL || kenv->magic!=__ENV_MAGIC) return -ENOSYS;
    src=env_source_for_parent(parent);
    copy=envdb_CloneVariableDatabase(src);
    if(copy==NULL) return -ENOMEM;
    if(thread_envdb[child]!=NULL) envdb_DestroyVariableDatabase(thread_envdb[child]);
    thread_envdb[child]=copy;
    return 0;
}

void ProcessEnvRelease(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return;
    if(thread_envdb[pid]!=NULL) {
        envdb_DestroyVariableDatabase(thread_envdb[pid]);
        thread_envdb[pid]=NULL;
    }
}

int ProcessEnvSet(int pid,const char *name,const char *value,int overwrite)
{
    ENVDB *e;
    if(kenv==NULL || kenv->magic!=__ENV_MAGIC) return -ENOSYS;
    e=ProcessEnvGetDB(pid,1);
    if(e==NULL) return -ENOMEM;
    return envdb_SetVariableEx(e,name,value,overwrite);
}

int ProcessEnvUnset(int pid,const char *name)
{
    ENVDB *e;
    if(kenv==NULL || kenv->magic!=__ENV_MAGIC) return -ENOSYS;
    e=ProcessEnvGetDB(pid,1);
    if(e==NULL) return -ENOMEM;
    return envdb_DeleteVariable(e,name);
}

int ProcessEnvGet(int pid,const char *name,char *value,unsigned int capacity)
{
    ENVDB *e=ProcessEnvGetDB(pid,1);
    if(e==NULL) {
        if(value==NULL || capacity==0) return -EINVAL;
        value[0]=0;
        return (kenv==NULL || kenv->magic!=__ENV_MAGIC) ? 0 : -ENOMEM;
    }
    return envdb_GetVariableEx(e,name,value,capacity);
}

int ProcessEnvCount(int pid)
{
    ENVDB *e=ProcessEnvGetDB(pid,1);
    return e ? envdb_Count(e) : 0;
}

const char *ProcessEnvEntry(int pid,int index)
{
    ENVDB *e=ProcessEnvGetDB(pid,1);
    return e ? envdb_EntryAt(e,index) : NULL;
}
