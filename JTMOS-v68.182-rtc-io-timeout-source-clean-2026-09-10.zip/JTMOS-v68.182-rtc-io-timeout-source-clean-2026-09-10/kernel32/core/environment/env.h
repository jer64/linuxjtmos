#ifndef __INCLUDED_ENV_H__
#define __INCLUDED_ENV_H__

/*
 * POSIX-style environment storage.
 *
 * Entries are dynamically allocated NAME=VALUE strings.  Empty values are
 * valid, names must be non-empty and may not contain '='.  The table itself
 * is bounded so a corrupt process cannot consume unbounded kernel metadata,
 * while individual values are limited only by available kernel memory.
 */
#define __N_MAX_VARS_IN_ENVDB 128
#define __ENV_MAGIC 0x26FD9CCCUL

typedef struct ENVDB {
    DWORD magic;
    int n_vars;                 /* capacity */
    int used;                   /* live NAME=VALUE entries */
    char *var[__N_MAX_VARS_IN_ENVDB];
} ENVDB;

int envdb_ValidName(const char *name);
ENVDB *envdb_CreateVariableDatabase(void);
ENVDB *envdb_CloneVariableDatabase(const ENVDB *src);
void envdb_DestroyVariableDatabase(ENVDB *e);
int envdb_Clear(ENVDB *e);
int envdb_SetVariableEx(ENVDB *e,const char *name,const char *value,int overwrite);
int envdb_SetVariable(ENVDB *e,const char *name,const char *value);
int envdb_GetVariableEx(const ENVDB *e,const char *name,char *content,unsigned int capacity);
int envdb_GetVariable(ENVDB *e,const char *name,char *content);
const char *envdb_GetValuePtr(const ENVDB *e,const char *name);
int envdb_DeleteVariable(ENVDB *e,const char *name);
int envdb_Count(const ENVDB *e);
const char *envdb_EntryAt(const ENVDB *e,int index);

#include "envint.h"
#endif
