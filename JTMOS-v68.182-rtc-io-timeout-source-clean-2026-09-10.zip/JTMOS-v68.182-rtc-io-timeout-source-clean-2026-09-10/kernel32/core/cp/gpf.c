/**********************************************************************
 * JTMOS General Purpose Exception Handler.
 * (C) 1999-2006 by Jari Tuominen.
 *
 * GPF/Etc. handler functions. Isolated from kernel32.c.
 * Check out FATALEXCEPTION.
 *
 * See exception.code for exception code.
 *
 **********************************************************************/

// Required includes.
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
#include "sb.h"
#include "syssh.h"
#include "ega.h"
#include "driver_sys.h"
#include "zero.h"
#include "null.h"
#include "pci.h"
#include "vga.h"
#include "threads.h"
#include "syssh_applications2.h"
#include "statusline.h" // statusline_terminate trigger
#include "panic.h"
#include "mm.h"
#include "keropt.h"

//
int EXCEPTION_HANDLER_ACTIVE=FALSE;

// from corner.mac
char irqActive=FALSE;

//------------------------------------------------------------------------------------------------------
//
inline void TellAtB8000(char *s)
{
	static char str[100];
	static int i,i2,l;
	static DWORD *ptr;
        static TSSEG *ts;
	static char *excact = "Exception caught";
	static char *excdea = "                ", *p;

	// Tell about exception.
	p = JTM_DWORD_TO_PTR(char,0xB8000);
	
	// Wipe off some space.
	for(i=0; i<(80*2*5); i+=2)
	{
		p[i+0] = ' ';
		p[i+1] = 0x0F;
	}

	//
	l = strlen(excact);
	for(i=0,i2=0; i<l; i++,i2+=2)
	{
		p[i2+0] = excact[i];
		p[i2+1] = 0x0F;
	}
	l = strlen(s); p+=160;
	for(i=0,i2=0; i<l; i++,i2+=2)
	{
		p[i2+0] = s[i];
		p[i2+1] = 0x0F;
	}

	//
	sprintf(str, "PID=%d, Last IRQ ID(irqActive)=%d, taskSwitchNr=%d",
		nr_curthread, irqActive,
		taskSwitchNr);
	p+=160;
	for(i=0,i2=0; str[i]!=0; i++,i2+=2)
	{
		p[i2+0] = str[i];
		p[i2+1] = 0x0F;
	}

	//
	sprintf(str, "Press ESC to continue.");
	p+=160;
	for(i=0,i2=0; str[i]!=0; i++,i2+=2)
	{
		p[i2+0] = str[i];
		p[i2+1] = 0x0F;
	}
	/* Do not poll i8042 port 0x60 here: that can consume PS/2 mouse data.
	 * Exception diagnostics are non-interactive now; keyboard input remains
	 * owned exclusively by the keyboard IRQ path. */
}

/* 
 * ------------------------------------------
 * FATALEXCEPTION - Default exception handler
 * ------------------------------------------
 */
//
// Update: terminates thread and calls SwitchToThread();
//
// Exception handler process (TSS task).
//
__attribute__ ((__noreturn__)) void FATALEXCEPTION(const char *s)
{
    TSSEG *ts;
    int pid;
    int from_user;
    int live_gp;
    int live_pf;
    int recover_kernel_gp;
    DWORD live_cs=0;
    DWORD live_eip=0;
    DWORD live_eflags=0;

    /* A fault while the exception handler is already active means the kernel
     * can no longer trust task-switch recovery.  Escalate to the minimal
     * serial-first fatal handler instead of recursively faulting forever. */
    if(EXCEPTION_HANDLER_ACTIVE)
        KernelFatalAt("nested CPU exception", "CPU exception handler", s, exception.code);

    EXCEPTION_HANDLER_ACTIVE=TRUE;
    pid=GetCurrentThread();
    if(tasks==NULL || pid<0 || pid>=nr_threads || pid>=N_MAX_THREADS)
        KernelFatalAt("CPU exception with invalid current task", "CPU exception handler", s, exception.code);

    ts=&tasks->tss[pid];
    live_gp=(exception.code==13 && gp_frame_valid==JTMOS_GP_FRAME_MAGIC);
    live_pf=(exception.code==14 && pf_frame_valid==JTMOS_PF_FRAME_MAGIC);

    if(live_gp) {
        live_cs=gp_frame_cs;
        live_eip=gp_frame_eip;
        live_eflags=gp_frame_eflags;
        from_user=((gp_frame_cs & 3U)==3U);
    } else if(live_pf) {
        live_cs=pf_frame_cs;
        live_eip=pf_frame_eip;
        live_eflags=pf_frame_eflags;
        from_user=((pf_frame_cs & 3U)==3U);
    } else {
        /* Legacy exception stubs may still have only a scheduler snapshot. */
        live_cs=ts->cs;
        live_eip=ts->eip;
        live_eflags=ts->eflags;
        from_user=((ts->cs & 3U)==3U);
    }

    DebugSerialEmergencyWrite("\n[EXCEPTION] "); DebugSerialEmergencyWrite(s ? s : "unknown");
    DebugSerialEmergencyWrite(" PID="); DebugSerialEmergencyWriteHex32((DWORD)pid);
    DebugSerialEmergencyWrite(" LIVE_CS="); DebugSerialEmergencyWriteHex32(live_cs);
    DebugSerialEmergencyWrite(" LIVE_EIP="); DebugSerialEmergencyWriteHex32(live_eip);
    DebugSerialEmergencyWrite(" LIVE_EFLAGS="); DebugSerialEmergencyWriteHex32(live_eflags);
    DebugSerialEmergencyWrite(" CR2="); DebugSerialEmergencyWriteHex32(GETCR2());
    DebugSerialEmergencyWrite("\n");

    printk("\nPID %d/%d(%s): %s  taskSwitchNr=%d\n",pid,nr_threads-1,
           thread_name[pid],s ? s : "unknown exception",taskSwitchNr);

    if(live_gp) {
        DWORD selector_index=(gp_frame_error>>3)&0x1fffU;
        printk("LIVE #GP: CS:EIP=%x:%x ERR=%x EFLAGS=%x ENTRY_ESP=%x\n",
               gp_frame_cs,gp_frame_eip,gp_frame_error,gp_frame_eflags,
               gp_frame_entry_esp);
        printk("LIVE regs: EAX=%x EBX=%x ECX=%x EDX=%x ESI=%x EDI=%x EBP=%x",
               gp_frame_eax,gp_frame_ebx,gp_frame_ecx,gp_frame_edx,
               gp_frame_esi,gp_frame_edi,gp_frame_ebp);
        if((gp_frame_cs & 3U)==3U)
            printk(" USER_SS:ESP=%x:%x",gp_frame_user_ss,gp_frame_user_esp);
        printk("\nGP decode: EXT=%u IDT=%u TI=%u selector-index=%u (%x)\n",
               (unsigned)(gp_frame_error&1U),
               (unsigned)((gp_frame_error>>1)&1U),
               (unsigned)((gp_frame_error>>2)&1U),
               (unsigned)selector_index,(unsigned)(selector_index<<3));
        printk("GP live frame is authoritative; TSS snapshot below may be stale.\n");
    } else if(live_pf) {
        printk("LIVE #PF: CS:EIP=%x:%x ERR=%x EFLAGS=%x CR2=%x ENTRY_ESP=%x\n",
               pf_frame_cs,pf_frame_eip,pf_frame_error,pf_frame_eflags,GETCR2(),
               pf_frame_entry_esp);
        printk("LIVE regs: EAX=%x EBX=%x ECX=%x EDX=%x ESI=%x EDI=%x EBP=%x",
               pf_frame_eax,pf_frame_ebx,pf_frame_ecx,pf_frame_edx,
               pf_frame_esi,pf_frame_edi,pf_frame_ebp);
        if((pf_frame_cs & 3U)==3U)
            printk(" USER_SS:ESP=%x:%x",pf_frame_user_ss,pf_frame_user_esp);
        printk("\nPF decode: %s %s %s%s%s\n",
               (pf_frame_error&1U)?"protection":"not-present",
               (pf_frame_error&2U)?"write":"read",
               (pf_frame_error&4U)?"user":"supervisor",
               (pf_frame_error&8U)?" reserved-bit":"",
               (pf_frame_error&16U)?" instruction-fetch":"");
        printk("TSS snapshot below is scheduler state and may have a stale EIP for interrupt-gate faults.\n");
    }

    tss_dump(ts);
    AnalyzeFault(ts,exception.code);

    /* V68.153 recovery policy:
     * - PID 0 and architecturally catastrophic exceptions stay fatal.
     * - Ring-3 faults keep the historical per-process isolation.
     * - A #GP attributed to a non-zero kernel task can also be isolated when
     *   GPF_RECOVER_NONZERO_PID is enabled.  This is intentionally narrower
     *   than recovering arbitrary Ring-0 faults: #GP is the failure mode seen
     *   in Build 151 and the offending task is discarded before rescheduling.
     */
    recover_kernel_gp=(exception.code==13 && pid!=0 && GPF_RECOVER_NONZERO_PID);
    if(pid==0 || exception.code==2 || exception.code==8 || exception.code==18 ||
       (!from_user && !recover_kernel_gp))
        KernelFatalAt(s ? s : "fatal CPU exception", "CPU exception handler",
                      "FATALEXCEPTION", exception.code);

    if(recover_kernel_gp && !from_user)
        printk("#GP isolated to non-zero kernel task PID %d by policy; task will be terminated.\n",pid);
    else
        printk("Exception isolated to PID %d; terminating task.\n",pid);

    /* We are running on the dedicated early exception stack, so freeing the
     * dead task's normal stack is safe.  Keep IF clear during teardown. */
    KillThreadEx(pid,KT_NO_THREAD_SWITCH);

    /* Never return through the faulting exception frame.  Clear global frame
     * state and the recursion guard before transferring control away. */
    gp_frame_valid=0;
    pf_frame_valid=0;
    EXCEPTION_HANDLER_ACTIVE=FALSE;

    /* Interrupt gates clear IF on entry.  The old handler then yielded forever
     * with IF=0, freezing IRQ0/IRQ1 for the whole machine even after a task was
     * killed.  Re-enable maskable interrupts only after the offending task has
     * been removed, then force the first transfer to PID 0. */
    enable();
    if(pid!=0)
        (void)SwitchToThreadEx(0);

    /* A dead PID must not become runnable again.  If the explicit transfer
     * unexpectedly returns, keep the system alive and continue yielding with
     * IF set instead of falling back into the bad exception frame. */
    for(;;) {
        enable();
        SwitchToThread();
    }
}

//
void Disassemble(BYTE *p)
{
	//
	if(p[0]==0xCD)
	{
		printk("Disassembly:    %x  INT 0x%x\n",
			p,p[1]);
	}
}

//
inline void ESCLOCK (void)
{
	/* Historical ESCLOCK polled port 0x60 directly.  0x60 is the shared
	 * i8042 output data register, so that stole AUX mouse bytes.  Use the
	 * software key-state table maintained by IRQ1 instead.  This routine is
	 * intentionally non-blocking when interrupts are disabled. */
	if(!kbstr.ktab)
		return;
	if(!(get_eflags() & (1U<<9)))
		return;
	while(kbstr.ktab[SCODE_ESCAPE])
		SwitchToThread();
	while(!kbstr.ktab[SCODE_ESCAPE])
		SwitchToThread();
	while(kbstr.ktab[SCODE_ESCAPE])
		SwitchToThread();
}

//------------------------------------------------------------------------------
// Backtrace.
//
void STACKWALK(DWORD ptr)
{
	DWORD i, i2, unit,ad;
	BYTE *p;

	//
	p = JTM_DWORD_TO_PTR(BYTE,ptr);

	//
	if(illegal(p))
	{
		return;
	}

	//
	printk("Backtrace: ");
	for(i=0; i<10; i++,p+=4)
	{
		ad = (p[3]<<24)|(p[2]<<16)|(p[1]<<8)|p[0];
		printk("%x ", ad);
	}
	printk("\n");
}

//------------------------------------------------------------------------------
// Displays a stack dump.
//
void STACKDUMP(DWORD whereAD)
{
	DWORD i, i2, unit;
	BYTE *p;

	// expecting that there is 80 marks per a line
	unit = 16;

	//
	p = A2K(whereAD);

	//
	printk("ESP=0x%x (fixed=0x%x)  ", whereAD, p);
	printk("Base=0x%x\n", GetCurrentThreadBase());

	//
	if(illegal(p))
	{
		printk("Stack pointer refers to an illegal memory region, won't make a stack dump.\n");
		PageDumpNear(JTM_PTR_TO_DWORD(p));
		return;
	}

	//
	printk("stack dump:\n");
	for(i=0; i<0x20; i+=unit)
	{
		//
		p32(JTM_PTR_TO_DWORD(p - i));
		printk(": ");
		for(i2 = 0; i2 < unit; i2++)
		{
			p8(p[i-i2-1]);
			printk(" ");
		}
		printk("\n");
	}
}

// Displays a program binary dump
void PRGDUMP(void)
{
	DWORD i, i2, unit;
	BYTE *p;

	// expecting that there is 80 marks per a line
	unit = 16;

	//
	p = A2K(tasks->tss[GetCurrentThread()].eip);

	//
	if(illegal(p))
	{
		printk("Program counter CS:EIP points to an illegal memory region, won't dump.\n");
		PageDumpNear(JTM_PTR_TO_DWORD(p));
		return;
	}

	//
	printk("executable binary dump:\n");
	for(i=0; i<0x20; i+=unit)
	{
		//
		p32(JTM_PTR_TO_DWORD(p - i));
		printk(": ");
		for(i2 = 0; i2 < unit; i2++)
		{
			p8(p[i+i2]);
			printk(" ");
		}
		printk("\n");
	}
}

//-----------------------------------------------------------------------------
//
void AnalyzeFault(TSSEG *s, int code)
{
	DWORD p1,p2;

	//
	p1 = GetThreadMemoryStart(GetCurrentThread());
	p2 = GetThreadMemoryEnd(GetCurrentThread());

	//
	if(code==14)
	{
		// Page fault:
		//------------------------------------------

		//
        {
            DWORD fault = GETCR2();
            DWORD *pd = (DWORD *)GetKernelPageDirPTR();
            DWORD pde = 0;
            DWORD pte = 0;
            int pid = GetCurrentThread();

            if(pd != NULL)
                pde = pd[fault >> 22];

            printk("Page fault address=0x%x, PID%d memory area 0x%x-0x%x.\n",
                   fault, pid, p1, p2);
            if(fault>=MM_USER_BASE && fault<MM_USER_TOP) {
                DWORD user_page=(fault-MM_USER_BASE)/PAGESIZE;
                pte=mm_get_process_pte(pid,fault);
                printk("Ring3 paging: PDE[%u]=0x%x PID-PTE[%u]=0x%x CR3=0x%x\n",
                       (unsigned)(fault >> 22),pde,(unsigned)user_page,pte,GetCR3());
            } else {
                printk("Ring3 paging: PDE[%u]=0x%x PID-PTE=n/a CR3=0x%x\n",
                       (unsigned)(fault >> 22),pde,GetCR3());
            }

            /* A Ring-3 NULL/low-address fault has no useful kernel flat-page
             * dump.  Avoid extra page-walker/console work while already inside
             * the exception path; kernel-origin faults still get that dump. */
            if(!(pf_frame_valid==JTMOS_PF_FRAME_MAGIC &&
                 (pf_frame_cs & 3U)==3U) &&
               (fault < MM_USER_BASE || fault >= MM_USER_TOP))
                PageDumpNear(fault);
        }
	}
}

//-----------------------------------------------------------------------------
//
void tss_dump(TSSEG *s)
{
	// Print registers
	printk("EAX=%x  EBX=%x  ECX=%x  EDX=%x\n",
		s->eax, s->ebx, s->ecx, s->edx);
	printk("ESI=%x  EDI=%x  EBP=%x  SS:ESP=%x:%x\n",
		s->esi, s->edi, s->ebp, s->ss, s->esp);
	printk("CS=%x  DS=%x  ES=%x  FS=%x  GS=%x  SS=%x\n",
		s->cs, s->ds, s->es, s->fs, s->gs, s->ss);
	printk("CS:EIP=%x:%x  Link=%x  EFLAGS=%x  CR3=%x  CR2=%x\n",
		s->cs, s->eip, s->link, s->eflags, s->cr3, GETCR2());
	if( !(s->eflags&(1<<9)) )
	{
		printk("eflags: Interrupts were disabled.\n");
	}
	else
	{
		printk("eflags: Interrupts were enabled.\n");
	}
}

//
void PROCESSINFO (void)
{
  int i;

  //
  for (i = 0; i < nr_threads; i++)
    {
      printk
	("PID %d: state %d, ESP=%x, SS=%x, tick=%d, name=%s, base=%x, limit=%x\n",
	 i + 1, thread_states[i], thread_esps[i], thread_ss[i],
	 thread_tick[i], thread_name[i], GetThreadBase(i),
	 GetThreadLimit (i));
    }

  //
}

//
