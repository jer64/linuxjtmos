/*
 * linuxabi.c - JTMOS V67.8.57.1 Linux/POSIX core compatibility layer.
 *
 * Ten practical Linux-style facilities are provided without replacing the
 * JTMOS microkernel model: process ancestry, waitpid/exit status, signals,
 * nice priorities, anonymous pipes, poll, proc-style pseudo files, /dev
 * pseudo devices, uname and sysinfo.  The implementation intentionally keeps
 * plain JTMOS PIDs and the existing JTMFS/VFS and responsive scheduler.
 */
#include "kernel32.h"
#include "linuxabi.h"
#include "scheduler.h"
#include "mm.h"
#include "filedescriptor.h"
#include "fcntlbits.h"
#include "dirdb.h"
#include "flexFat.h"
#include "hdCache.h"

#define LINUX_PIPE_CAPACITY 4096
#define LINUX_NSIG 32

typedef struct {
    BYTE data[LINUX_PIPE_CAPACITY];
    DWORD read_pos;
    DWORD write_pos;
    DWORD count;
    int readers;
    int writers;
} JTMOS_PIPE;

static short linux_parent[N_MAX_THREADS];
static BYTE linux_exit_valid[N_MAX_THREADS];
static BYTE linux_waitable[N_MAX_THREADS];
static WORD linux_wait_status[N_MAX_THREADS];
static signed char linux_nice[N_MAX_THREADS];
static BYTE linux_sigdisp[N_MAX_THREADS][LINUX_NSIG];
static DWORD linux_pending[N_MAX_THREADS];
static DWORD linux_random_state = 0x6a09e667UL;

/* Per-process standard descriptor routing. -1 means the native terminal.
 * JTMOS keeps fd 0/1/2 as permanent ABI descriptors, so anonymous pipes
 * cannot literally replace those global FDDB slots.  This small mapping gives
 * each process POSIX-style stdin/stdout/stderr without disturbing the legacy
 * global descriptor table. */
static short linux_stdio_fd[N_MAX_THREADS][3];

static int linux_valid_signal(int sig)
{
    return sig > 0 && sig < LINUX_NSIG;
}

static void linux_reset_process_slot(int pid)
{
    int s;
    if(pid < 0 || pid >= N_MAX_THREADS) return;
    linux_exit_valid[pid] = 0;
    linux_waitable[pid] = 0;
    linux_wait_status[pid] = 0;
    linux_nice[pid] = 0;
    linux_pending[pid] = 0;
    linux_stdio_fd[pid][0] = -1;
    linux_stdio_fd[pid][1] = -1;
    linux_stdio_fd[pid][2] = -1;
    for(s=0;s<LINUX_NSIG;s++) linux_sigdisp[pid][s] = JTMOS_SIG_DFL;
}

void LinuxProcessCreated(int pid, int parent_pid)
{
    if(pid < 0 || pid >= N_MAX_THREADS) return;
    linux_reset_process_slot(pid);
    if(pid == 0) linux_parent[pid] = 0;
    else if(parent_pid >= 0 && parent_pid < N_MAX_THREADS) linux_parent[pid] = (short)parent_pid;
    else linux_parent[pid] = 0;
}

void LinuxProcessForked(int parent_pid, int child_pid)
{
    int s;
    if(child_pid <= 0 || child_pid >= N_MAX_THREADS) return;
    LinuxProcessCreated(child_pid,parent_pid);
    if(parent_pid >= 0 && parent_pid < N_MAX_THREADS)
    {
        linux_nice[child_pid] = linux_nice[parent_pid];
        for(s=0;s<LINUX_NSIG;s++) linux_sigdisp[child_pid][s] = linux_sigdisp[parent_pid][s];
        (void)fd_inherit_process(parent_pid,child_pid);
        linux_stdio_fd[child_pid][0] = linux_stdio_fd[parent_pid][0];
        linux_stdio_fd[child_pid][1] = linux_stdio_fd[parent_pid][1];
        linux_stdio_fd[child_pid][2] = linux_stdio_fd[parent_pid][2];
        linux_waitable[child_pid] = 1;
    }
}

void LinuxProcessExit(int pid, int exit_code, int term_signal)
{
    int i;
    if(pid <= 0 || pid >= N_MAX_THREADS) return;
    if(linux_exit_valid[pid]) return;
    /* JTMOS has no permanent PID1 userspace reaper. Do not retain orphaned
     * fork zombies after their parent terminates. */
    for(i=1;i<nr_threads;i++)
        if(linux_parent[i]==pid) { linux_parent[i]=0; linux_waitable[i]=0; }
    if(term_signal > 0)
        linux_wait_status[pid] = (WORD)(term_signal & 0x7f);
    else
        linux_wait_status[pid] = (WORD)((exit_code & 0xff) << 8);
    linux_exit_valid[pid] = 1;
}

void LinuxProcessDiscard(int pid)
{
    if(pid <= 0 || pid >= N_MAX_THREADS) return;
    linux_parent[pid] = -1;
    linux_waitable[pid] = 0;
    linux_exit_valid[pid] = 0;
    linux_wait_status[pid] = 0;
}

int LinuxProcessPidReusable(int pid)
{
    int parent;
    if(pid <= 0 || pid >= N_MAX_THREADS) return 1;
    if(!linux_exit_valid[pid] || !linux_waitable[pid]) return 1;
    parent=(int)linux_parent[pid];
    /* Keep a terminated child PID stable until its living parent waitpid()s.
     * If there is no living parent, allow the old slot to be recycled rather
     * than leaking zombies forever in the JTMOS process table. */
    if(parent <= 0 || parent >= nr_threads || !thread_states[parent]) return 1;
    return 0;
}

int LinuxGetPPid(int pid)
{
    if(pid < 0 || pid >= N_MAX_THREADS) return 0;
    return (int)linux_parent[pid];
}

static int linux_is_child(int parent, int pid)
{
    if(pid <= 0 || pid >= N_MAX_THREADS) return 0;
    return linux_parent[pid] == parent;
}

int LinuxWaitPid(int parent, int wanted, int *status, int options)
{
    int i, found;
    if(parent < 0 || parent >= N_MAX_THREADS) return -ECHILD;
    if(options & ~JTMOS_WNOHANG) return -EINVAL;
    if(wanted == 0 || wanted < -1) return -EINVAL;

    for(;;)
    {
        found = 0;
        if(wanted > 0)
        {
            if(!linux_is_child(parent,wanted)) return -ECHILD;
            found = 1;
            if(linux_exit_valid[wanted])
            {
                if(status) *status = (int)linux_wait_status[wanted];
                linux_exit_valid[wanted] = 0;
                linux_waitable[wanted] = 0;
                linux_parent[wanted] = -1;
                return wanted;
            }
        }
        else
        {
            for(i=1;i<nr_threads;i++)
                if(linux_is_child(parent,i))
                {
                    found = 1;
                    if(linux_exit_valid[i])
                    {
                        if(status) *status = (int)linux_wait_status[i];
                        linux_exit_valid[i] = 0;
                        linux_waitable[i] = 0;
                        linux_parent[i] = -1;
                        return i;
                    }
                }
        }
        if(!found) return -ECHILD;
        if(options & JTMOS_WNOHANG) return 0;
        SchedulerWaitPause(1000UL);
    }
}

int LinuxSignalDisposition(int pid, int sig, int disposition)
{
    int old;
    if(pid <= 0 || pid >= N_MAX_THREADS || !linux_valid_signal(sig)) return -EINVAL;
    if(sig == JTMOS_SIGKILL && disposition != JTMOS_SIG_DFL) return -EINVAL;
    if(disposition < JTMOS_SIG_DFL || disposition > JTMOS_SIG_USER) return -EINVAL;
    old = linux_sigdisp[pid][sig];
    linux_sigdisp[pid][sig] = (BYTE)disposition;
    return old;
}

int LinuxSignalSend(int sender, int pid, int sig)
{
    int disp;
    (void)sender;
    if(!linux_valid_signal(sig)) return -EINVAL;
    if(pid <= 0 || pid >= nr_threads || !valid_pid(pid) || !thread_states[pid]) return -ESRCH;

    disp = linux_sigdisp[pid][sig];
    if(sig != JTMOS_SIGKILL && disp == JTMOS_SIG_IGN) return 0;
    if(sig != JTMOS_SIGKILL && disp == JTMOS_SIG_USER)
    {
        linux_pending[pid] |= (1UL << sig);
        SchedulerWakeThread(pid);
        return 0;
    }

    LinuxProcessExit(pid,0,sig);
    KillThreadEx((DWORD)pid, pid == GetCurrentThread() ? 0 : KT_NO_THREAD_SWITCH);
    return 0;
}

static BYTE linux_nice_to_priority(int value)
{
    if(value >= 15) return THREAD_PRIORITY_LOWEST;
    if(value >= 10) return THREAD_PRIORITY_IDLE;
    if(value >= 5) return THREAD_PRIORITY_BELOW_NORMAL;
    return THREAD_PRIORITY_NORMAL;
}

int LinuxSetPriority(int pid, int value)
{
    if(pid == 0) pid = GetCurrentThread();
    if(pid <= 0 || pid >= nr_threads || !thread_states[pid]) return -ESRCH;
    if(value < -20) value = -20;
    if(value > 19) value = 19;
    linux_nice[pid] = (signed char)value;
    SetThreadPriority((DWORD)pid,linux_nice_to_priority(value));
    return 0;
}

int LinuxGetPriority(int pid)
{
    if(pid == 0) pid = GetCurrentThread();
    if(pid <= 0 || pid >= nr_threads || !thread_states[pid]) return -ESRCH;
    return (int)linux_nice[pid];
}

int LinuxNice(int pid, int increment)
{
    int value;
    value = LinuxGetPriority(pid);
    if(value < -20) return value;
    value += increment;
    if(LinuxSetPriority(pid,value) < 0) return -ESRCH;
    return LinuxGetPriority(pid);
}

int LinuxUname(JTMOS_UTSNAME *u)
{
    if(!u) return -EFAULT;
    memset(u,0,sizeof(*u));
    strcpy(u->sysname,"JTMOS");
    strcpy(u->nodename,"jtmos");
    strcpy(u->release,"67.8.57.1");
    strcpy(u->version,"linux-core10 2026-08-28");
    strcpy(u->machine,"i486");
    return 0;
}

static DWORD linux_add_saturated(DWORD a,DWORD b)
{
    if(b>0xffffffffUL-a) return 0xffffffffUL;
    return a+b;
}

static DWORD linux_reclaimable_cache_bytes(void)
{
    DWORD flags,total,bytes;
    int n;

    bytes=0;
    flags=(DWORD)get_eflags();
    disable();

    bytes=linux_add_saturated(bytes,dirdb.bytes_allocated);
    if(fle!=NULL)
        for(n=0;n<N_MAX_FATS;n++)
            if(fle->FAT[n].isOK)
            {
                FLEFAT *f=&fle->FAT[n];
                total=0;
                if(f->l_buf>0) total=linux_add_saturated(total,(DWORD)f->l_buf);
                if(f->l_writemap>0) total=linux_add_saturated(total,(DWORD)f->l_writemap);
                if(f->l_cache_page>0) total=linux_add_saturated(total,(DWORD)f->l_cache_page);
                if(f->l_cache_age>0) total=linux_add_saturated(total,(DWORD)f->l_cache_age);
                bytes=linux_add_saturated(bytes,total);
            }
    if(hdCacheActive && hdb!=NULL && hdb->e!=NULL)
        for(n=0;n<hdb->n_e;n++)
            if(hdb->e[n]!=NULL && hdb->e[n]->l_buf>0)
                bytes=linux_add_saturated(bytes,(DWORD)hdb->e[n]->l_buf);

    set_eflags((int)flags);
    return bytes;
}

int LinuxSysinfo(JTMOS_SYSINFO *i)
{
    MM_MEMORY_STATS mmstats;
    JTMOS_CPU_STATS cpustats;
    if(!i) return -EFAULT;
    memset(i,0,sizeof(*i));
    memset(&mmstats,0,sizeof(mmstats));
    memset(&cpustats,0,sizeof(cpustats));
    mm_get_memory_stats(&mmstats);
    (void)SchedulerGetCpuStats(&cpustats,sizeof(cpustats));
    i->uptime = (long)(cpustats.uptime_ms / 1000UL);
    i->loads[0] = (unsigned long)((cpustats.load_a_x1000 * 65536UL) / 1000UL);
    i->loads[1] = (unsigned long)((cpustats.load_b_x1000 * 65536UL) / 1000UL);
    i->loads[2] = (unsigned long)((cpustats.load_c_x1000 * 65536UL) / 1000UL);
    i->totalram = mmstats.total_bytes;
    i->freeram = mmstats.free_bytes;
    i->bufferram = linux_reclaimable_cache_bytes();
    if(i->bufferram>i->totalram-i->freeram)
        i->bufferram=i->totalram-i->freeram;
    i->procs = (unsigned short)cpustats.total_threads;
    i->mem_unit = 1;
    return 0;
}

static int linux_proc_path_valid(const char *path)
{
    const char *p;
    int pid;
    if(!strcmp(path,"/proc/uptime") || !strcmp(path,"/proc/loadavg") ||
       !strcmp(path,"/proc/meminfo") || !strcmp(path,"/proc/version") ||
       !strcmp(path,"/proc/cpuinfo") || !strcmp(path,"/proc/self/status")) return 1;
    if(strncmp(path,"/proc/",6)) return 0;
    p=path+6; pid=0;
    if(*p<'0' || *p>'9') return 0;
    while(*p>='0' && *p<='9') { pid=pid*10+(*p-'0'); p++; }
    if(strcmp(p,"/status")) return 0;
    return pid>0 && pid<nr_threads;
}

static int linux_virtual_kind_from_path(const char *path)
{
    if(!strcmp(path,"/dev/null")) return JTMOS_FD_DEV_NULL;
    if(!strcmp(path,"/dev/zero")) return JTMOS_FD_DEV_ZERO;
    if(!strcmp(path,"/dev/random") || !strcmp(path,"/dev/urandom")) return JTMOS_FD_DEV_RANDOM;
    if(!strncmp(path,"/proc/",6)) return JTMOS_FD_PROC;
    return JTMOS_FD_NORMAL;
}

int LinuxVfsOpen(const char *path, int flags)
{
    FILEDES *f;
    int kind;
    if(path == NULL) return -EINVAL;
    kind = linux_virtual_kind_from_path(path);
    if(kind == JTMOS_FD_NORMAL) return JTMOS_VFS_NOT_HANDLED;
    if(kind == JTMOS_FD_PROC && !linux_proc_path_valid(path)) return -ENOENT;
    if(kind == JTMOS_FD_PROC && ((flags & O_ACCMODE) != O_RDONLY)) return -EROFS;
    f = NewFD();
    if(!f) return -EMFILE;
    f->v1 = kind;
    f->flags = flags;
    f->offset = 0;
    strncpy(f->name,path,sizeof(f->name)-1);
    f->name[sizeof(f->name)-1] = 0;
    return f->fd;
}

static DWORD linux_random32(void)
{
    DWORD x;
    x = linux_random_state ^ GetTickCount() ^ (DWORD)(GetCurrentThread()*0x9e37U);
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    if(!x) x = 0x243f6a88UL;
    linux_random_state = x;
    return x;
}

static int linux_proc_status(char *out, int pid)
{
    char name[96];
    int ppid;
    int mem;
    int nicev;
    if(pid <= 0 || pid >= nr_threads) return -ENOENT;
    name[0]=0;
    (void)GetThreadName(pid,name);
    if(!name[0]) strcpy(name,"?");
    ppid=LinuxGetPPid(pid);
    mem=GetThreadMemoryUsage(pid);
    nicev=(int)linux_nice[pid];
    return sprintf(out,
        "Name:\t%s\nPid:\t%d\nPPid:\t%d\nState:\t%s\nNice:\t%d\nVmSize:\t%d kB\nTerminal:\t%d\n",
        name,pid,ppid,thread_states[pid]?"R (running)":"Z (zombie)",nicev,mem/1024,
        GetThreadTerminal(pid));
}

static int linux_proc_render(const char *path, char *out, int out_size)
{
    JTMOS_CPU_STATS cs;
    MM_MEMORY_STATS ms;
    int pid;
    int n;
    const char *p;
    if(!out || out_size < 64) return -EINVAL;
    out[0]=0;
    memset(&cs,0,sizeof(cs));
    memset(&ms,0,sizeof(ms));
    (void)SchedulerGetCpuStats(&cs,sizeof(cs));

    if(!strcmp(path,"/proc/uptime"))
        n=sprintf(out,"%u.%02u %u.%02u\n",
            (unsigned)(cs.uptime_ms/1000UL),(unsigned)((cs.uptime_ms%1000UL)/10UL),
            (unsigned)((cs.uptime_ms*cs.cpu_idle_per_mille/1000UL)/1000UL),0U);
    else if(!strcmp(path,"/proc/loadavg"))
        n=sprintf(out,"%u.%03u %u.%03u %u.%03u %u/%u 0\n",
            (unsigned)(cs.load_a_x1000/1000UL),(unsigned)(cs.load_a_x1000%1000UL),
            (unsigned)(cs.load_b_x1000/1000UL),(unsigned)(cs.load_b_x1000%1000UL),
            (unsigned)(cs.load_c_x1000/1000UL),(unsigned)(cs.load_c_x1000%1000UL),
            (unsigned)cs.runnable_threads,(unsigned)cs.total_threads);
    else if(!strcmp(path,"/proc/meminfo"))
    {
        mm_get_memory_stats(&ms);
        {
            DWORD cache,available;
            cache=linux_reclaimable_cache_bytes();
            available=linux_add_saturated(ms.free_bytes,cache);
            if(available>ms.total_bytes) available=ms.total_bytes;
            n=sprintf(out,"MemTotal: %u kB\nMemFree: %u kB\nMemAvailable: %u kB\nBuffers: 0 kB\nCached: %u kB\nSwapTotal: 0 kB\nSwapFree: 0 kB\n",
                (unsigned)(ms.total_bytes/1024UL),(unsigned)(ms.free_bytes/1024UL),
                (unsigned)(available/1024UL),(unsigned)(cache/1024UL));
        }
    }
    else if(!strcmp(path,"/proc/version"))
        n=sprintf(out,"JTMOS 67.8.57.1 linux-core10 i486\n");
    else if(!strcmp(path,"/proc/cpuinfo"))
        n=sprintf(out,"processor\t: 0\nvendor_id\t: JTMOS\nmodel name\t: i486-compatible x86\nflags\t\t: cpuid runtime-dispatch\n");
    else if(!strcmp(path,"/proc/self/status"))
        n=linux_proc_status(out,GetCurrentThread());
    else
    {
        p=path+6;
        pid=0;
        if(*p<'0' || *p>'9') return -ENOENT;
        while(*p>='0' && *p<='9') { pid=pid*10+(*p-'0'); p++; }
        if(strcmp(p,"/status")) return -ENOENT;
        n=linux_proc_status(out,pid);
    }
    if(n < 0) return n;
    if(n >= out_size) n=out_size-1;
    out[n]=0;
    return n;
}

static int linux_pipe_read(JTMOS_PIPE *p, void *buf, int count)
{
    BYTE *b;
    int n;
    int flags;
    if(!p || !buf || count < 0) return -EINVAL;
    if(count==0) return 0;
    b=(BYTE *)buf;
    for(;;)
    {
        flags=get_eflags(); disable();
        if(p->count || p->writers==0) break;
        set_eflags(flags);
        SchedulerWaitPause(1000UL);
    }
    if(p->count==0 && p->writers==0) { set_eflags(flags); return 0; }
    n=0;
    while(n<count && p->count)
    {
        b[n++]=p->data[p->read_pos];
        p->read_pos=(p->read_pos+1U)%LINUX_PIPE_CAPACITY;
        p->count--;
    }
    set_eflags(flags);
    return n;
}

static int linux_pipe_write(JTMOS_PIPE *p, const void *buf, int count)
{
    const BYTE *b;
    int n;
    int flags;
    if(!p || (!buf && count) || count < 0) return -EINVAL;
    if(count==0) return 0;
    b=(const BYTE *)buf;
    n=0;
    while(n<count)
    {
        flags=get_eflags(); disable();
        if(p->readers==0) { set_eflags(flags); return n ? n : -EPIPE; }
        if(p->count < LINUX_PIPE_CAPACITY)
        {
            p->data[p->write_pos]=b[n++];
            p->write_pos=(p->write_pos+1U)%LINUX_PIPE_CAPACITY;
            p->count++;
            set_eflags(flags);
            continue;
        }
        set_eflags(flags);
        SchedulerWaitPause(1000UL);
    }
    return n;
}

int LinuxVfsRead(int fd, void *buf, int count)
{
    FILEDES *f;
    JTMOS_PIPE *p;
    char text[2048];
    int len,want,i;
    DWORD r=0;
    if(count < 0) return -EINVAL;
    if(count > 0 && !buf) return -EFAULT;
    f=get_filedesptr(fd);
    if(!f) return JTMOS_VFS_NOT_HANDLED;
    if(fd>=3 && !fd_has_owner(fd,GetCurrentThread())) return -EBADF;
    if(f->v1==JTMOS_FD_PIPE_READ)
    {
        p=(JTMOS_PIPE *)f->p1;
        return linux_pipe_read(p,buf,count);
    }
    if(f->v1==JTMOS_FD_PIPE_WRITE) return -EBADF;
    if(f->v1==JTMOS_FD_DEV_NULL) return 0;
    if(f->v1==JTMOS_FD_DEV_ZERO) { memset(buf,0,count); return count; }
    if(f->v1==JTMOS_FD_DEV_RANDOM)
    {
        for(i=0;i<count;i++)
        {
            if((i&3)==0) r=linux_random32();
            ((BYTE *)buf)[i]=(BYTE)(r >> ((i&3)*8));
        }
        return count;
    }
    if(f->v1!=JTMOS_FD_PROC) return JTMOS_VFS_NOT_HANDLED;
    len=linux_proc_render(f->name,text,sizeof(text));
    if(len<0) return len;
    if(f->offset>=len) return 0;
    want=count;
    if(want>len-f->offset) want=len-f->offset;
    memcpy(buf,text+f->offset,want);
    f->offset+=want;
    return want;
}

int LinuxVfsWrite(int fd, const void *buf, int count)
{
    FILEDES *f;
    JTMOS_PIPE *p;
    (void)buf;
    if(count < 0) return -EINVAL;
    if(count > 0 && !buf) return -EFAULT;
    f=get_filedesptr(fd);
    if(!f) return JTMOS_VFS_NOT_HANDLED;
    if(fd>=3 && !fd_has_owner(fd,GetCurrentThread())) return -EBADF;
    if(f->v1==JTMOS_FD_PIPE_WRITE)
    {
        p=(JTMOS_PIPE *)f->p1;
        return linux_pipe_write(p,buf,count);
    }
    if(f->v1==JTMOS_FD_PIPE_READ) return -EBADF;
    if(f->v1==JTMOS_FD_DEV_NULL || f->v1==JTMOS_FD_DEV_ZERO || f->v1==JTMOS_FD_DEV_RANDOM) return count;
    if(f->v1==JTMOS_FD_PROC) return -EROFS;
    return JTMOS_VFS_NOT_HANDLED;
}

int LinuxVfsClose(int fd)
{
    FILEDES *f;
    f=get_filedesptr(fd);
    if(!f) return JTMOS_VFS_NOT_HANDLED;
    if(fd>=3 && !fd_has_owner(fd,GetCurrentThread())) return -EBADF;
    if(f->v1==JTMOS_FD_NORMAL) return JTMOS_VFS_NOT_HANDLED;
    return FreeFD(fd)==0 ? 0 : -EBADF;
}

int LinuxVfsLseek(int fd, int offset, int whence)
{
    FILEDES *f;
    int base,newpos,len;
    char text[2048];
    f=get_filedesptr(fd);
    if(!f) return JTMOS_VFS_NOT_HANDLED;
    if(fd>=3 && !fd_has_owner(fd,GetCurrentThread())) return -EBADF;
    if(f->v1==JTMOS_FD_PIPE_READ || f->v1==JTMOS_FD_PIPE_WRITE) return -ESPIPE;
    if(f->v1==JTMOS_FD_DEV_NULL || f->v1==JTMOS_FD_DEV_ZERO || f->v1==JTMOS_FD_DEV_RANDOM) return 0;
    if(f->v1!=JTMOS_FD_PROC) return JTMOS_VFS_NOT_HANDLED;
    len=linux_proc_render(f->name,text,sizeof(text));
    if(len<0) return len;
    if(whence==SEEK_SET) base=0;
    else if(whence==SEEK_CUR) base=f->offset;
    else if(whence==SEEK_END) base=len;
    else return -EINVAL;
    newpos=base+offset;
    if(newpos<0) return -EINVAL;
    f->offset=newpos;
    return newpos;
}

void LinuxFdOwnerAdded(int fd, int pid)
{
    FILEDES *f;
    JTMOS_PIPE *p;
    (void)pid;
    if(fd < 3 || fd >= N_MAX_FD) return;
    f=fddb.fd[fd];
    if(!f || f->isFree || !f->p1) return;
    p=(JTMOS_PIPE *)f->p1;
    if(f->v1==JTMOS_FD_PIPE_READ) p->readers++;
    else if(f->v1==JTMOS_FD_PIPE_WRITE) p->writers++;
}

void LinuxFdOwnerReleased(int fd, int pid)
{
    FILEDES *f;
    JTMOS_PIPE *p;
    (void)pid;
    if(fd < 3 || fd >= N_MAX_FD) return;
    f=fddb.fd[fd];
    if(!f || f->isFree || !f->p1) return;
    p=(JTMOS_PIPE *)f->p1;
    if(f->v1==JTMOS_FD_PIPE_READ && p->readers>0) p->readers--;
    else if(f->v1==JTMOS_FD_PIPE_WRITE && p->writers>0) p->writers--;
    if(p->readers==0 && p->writers==0)
    {
        f->p1=NULL;
        free(p);
    }
}


int LinuxFdIsPipe(int fd)
{
    FILEDES *f=get_filedesptr(fd);
    if(!f) return 0;
    return f->v1==JTMOS_FD_PIPE_READ || f->v1==JTMOS_FD_PIPE_WRITE;
}

int LinuxResolveStdioFd(int pid, int stdfd)
{
    int mapped;
    if(pid < 0 || pid >= N_MAX_THREADS || stdfd < 0 || stdfd > 2) return stdfd;
    mapped=(int)linux_stdio_fd[pid][stdfd];
    if(mapped==-2) return -1;          /* explicitly closed */
    return mapped>=3 ? mapped : stdfd; /* -1 = native terminal */
}

int LinuxGetStdioRoute(int pid, int stdfd)
{
    if(pid<0 || pid>=N_MAX_THREADS || stdfd<0 || stdfd>2) return -1;
    return (int)linux_stdio_fd[pid][stdfd];
}

int LinuxCloseStdioFd(int pid, int stdfd)
{
    int fd,i;
    if(pid < 0 || pid >= N_MAX_THREADS || stdfd < 0 || stdfd > 2) return -EBADF;
    fd=(int)linux_stdio_fd[pid][stdfd];
    if(fd==-2) return -EBADF;
    if(fd<3) { linux_stdio_fd[pid][stdfd]=-2; return 0; }
    linux_stdio_fd[pid][stdfd] = -2;
    /* FD ownership is process based rather than descriptor-slot based.  Keep
     * the ownership reference while another stdio slot in this process still
     * aliases the same endpoint. */
    for(i=0;i<3;i++) if((int)linux_stdio_fd[pid][i]==fd) return 0;
    return FreeFD(fd)==0 ? 0 : -EBADF;
}

int LinuxDup2(int pid, int oldfd, int newfd)
{
    int realold,i;
    if(pid<0 || pid>=N_MAX_THREADS || newfd<0 || newfd>2) return -EINVAL;
    realold=(oldfd>=0 && oldfd<=2) ? LinuxResolveStdioFd(pid,oldfd) : oldfd;
    if(realold<0) return -EBADF;
    if(realold>=3 && (!isValidFD(realold) || !fd_has_owner(realold,pid))) return -EBADF;
    if(oldfd==newfd && realold==newfd) return newfd;
    if(LinuxCloseStdioFd(pid,newfd)<0) return -EBADF;
    if(realold<3)
    {
        linux_stdio_fd[pid][newfd]=-1;
        return newfd;
    }
    if(fd_add_owner(realold,pid)!=0) return -EMFILE;
    linux_stdio_fd[pid][newfd]=(short)realold;
    /* fd_add_owner is idempotent, and other aliases intentionally share the
     * same process ownership bit. */
    for(i=0;i<3;i++) if(i!=newfd && linux_stdio_fd[pid][i]==realold) break;
    return newfd;
}

int LinuxProcessExecSetup(int pid, int parent_pid, int stdin_fd, int stdout_fd, int stderr_fd)
{
    int map[3];
    int i,j;
    if(pid <= 0 || pid >= N_MAX_THREADS) return -EINVAL;
    if(parent_pid >= 0 && parent_pid < N_MAX_THREADS)
        linux_parent[pid]=(short)parent_pid;
    map[0]=stdin_fd; map[1]=stdout_fd; map[2]=stderr_fd;
    for(i=0;i<3;i++)
    {
        int fd=map[i];
        if(fd==-2) { linux_stdio_fd[pid][i]=-2; continue; }
        if(fd < 0) { linux_stdio_fd[pid][i]=-1; continue; }
        if(fd < 3 || !isValidFD(fd)) return -EBADF;
        if(parent_pid >= 0 && !fd_has_owner(fd,parent_pid)) return -EBADF;
        if(fd_add_owner(fd,pid)!=0) return -EMFILE;
        linux_stdio_fd[pid][i]=(short)fd;
        /* If one underlying endpoint is mapped to more than one stdio slot,
         * FDDB ownership is process-based, so do not add another owner count. */
        for(j=0;j<i;j++) if(map[j]==fd) break;
    }
    return 0;
}

int LinuxPipeCreate(int fds[2])
{
    JTMOS_PIPE *p;
    FILEDES *r,*w;
    int rfd,wfd;
    if(!fds) return -EFAULT;
    p=(JTMOS_PIPE *)malloc(sizeof(*p));
    if(!p) return -ENOMEM;
    memset(p,0,sizeof(*p));
    ChangeChunkOwner(p,0);
    r=NewFD();
    if(!r) { free(p); return -EMFILE; }
    rfd=r->fd;
    w=NewFD();
    if(!w) { FreeFD(rfd); free(p); return -EMFILE; }
    wfd=w->fd;
    r->v1=JTMOS_FD_PIPE_READ; r->p1=(char *)p; r->flags=O_RDONLY;
    w->v1=JTMOS_FD_PIPE_WRITE; w->p1=(char *)p; w->flags=O_WRONLY;
    strcpy(r->name,"pipe:[read]"); strcpy(w->name,"pipe:[write]");
    p->readers=1; p->writers=1;
    fds[0]=rfd; fds[1]=wfd;
    return 0;
}

static short linux_poll_one(int fd, short events)
{
    FILEDES *f;
    JTMOS_PIPE *p;
    short r=0;
    if(fd>=0 && fd<=2) fd=LinuxResolveStdioFd(GetCurrentThread(),fd);
    if(fd==1 || fd==2) return (events & JTMOS_POLLOUT) ? JTMOS_POLLOUT : 0;
    if(fd==0) return 0;
    f=get_filedesptr(fd);
    if(!f || (fd>=3 && !fd_has_owner(fd,GetCurrentThread()))) return JTMOS_POLLNVAL;
    if(f->v1==JTMOS_FD_PIPE_READ)
    {
        p=(JTMOS_PIPE *)f->p1;
        if((events&JTMOS_POLLIN) && p && p->count) r|=JTMOS_POLLIN;
        if(p && p->writers==0) r|=JTMOS_POLLHUP;
        return r;
    }
    if(f->v1==JTMOS_FD_PIPE_WRITE)
    {
        p=(JTMOS_PIPE *)f->p1;
        if(!p || p->readers==0) return JTMOS_POLLERR|JTMOS_POLLHUP;
        if((events&JTMOS_POLLOUT) && p->count<LINUX_PIPE_CAPACITY) r|=JTMOS_POLLOUT;
        return r;
    }
    if(events&JTMOS_POLLIN) r|=JTMOS_POLLIN;
    if((events&JTMOS_POLLOUT) && ((f->flags&O_ACCMODE)!=O_RDONLY)) r|=JTMOS_POLLOUT;
    return r;
}

int LinuxPoll(JTMOS_POLLFD *fds, unsigned int nfds, int timeout_ms)
{
    DWORD start,elapsed;
    unsigned int i;
    int ready;
    if(nfds>256U) return -EINVAL;
    if(nfds && !fds) return -EFAULT;
    start=GetTickCount();
    for(;;)
    {
        ready=0;
        for(i=0;i<nfds;i++)
        {
            fds[i].revents=linux_poll_one(fds[i].fd,fds[i].events);
            if(fds[i].revents) ready++;
        }
        if(ready || timeout_ms==0) return ready;
        if(timeout_ms>0)
        {
            elapsed=(DWORD)(GetTickCount()-start);
            if(elapsed >= (DWORD)timeout_ms) return 0;
        }
        SchedulerWaitPause(1000UL);
    }
}

int scall_getppid(SYSCALLPAR)
{
    (void)scall_eax;(void)scall_ebx;(void)scall_ecx;(void)scall_edx;(void)scall_esi;(void)scall_edi;(void)scall_ebp;
    return LinuxGetPPid(GetCurrentThread());
}

int scall_waitpid(SYSCALLPAR)
{
    int *status=NULL;
    if(scall_ecx) { status=(int *)A2KRange(scall_ecx,sizeof(int)); if(!status) return -EFAULT; }
    return LinuxWaitPid(GetCurrentThread(),(int)scall_ebx,status,(int)scall_edx);
}

int scall_kill_posix(SYSCALLPAR)
{
    return LinuxSignalSend(GetCurrentThread(),(int)scall_ebx,(int)scall_ecx);
}

int scall_sigdisp(SYSCALLPAR)
{
    return LinuxSignalDisposition(GetCurrentThread(),(int)scall_ebx,(int)scall_ecx);
}

int scall_pipe(SYSCALLPAR)
{
    int *fds;
    fds=(int *)A2KRange(scall_ebx,sizeof(int)*2);
    if(!fds) return -EFAULT;
    return LinuxPipeCreate(fds);
}

int scall_dup2(SYSCALLPAR)
{
    return LinuxDup2(GetCurrentThread(),(int)scall_ebx,(int)scall_ecx);
}

int scall_poll(SYSCALLPAR)
{
    JTMOS_POLLFD *fds;
    DWORD bytes;
    if(scall_ecx>256U) return -EINVAL;
    bytes=scall_ecx*sizeof(JTMOS_POLLFD);
    fds=scall_ecx ? (JTMOS_POLLFD *)A2KRange(scall_ebx,bytes) : NULL;
    if(scall_ecx && !fds) return -EFAULT;
    return LinuxPoll(fds,(unsigned int)scall_ecx,(int)scall_edx);
}

int scall_nice(SYSCALLPAR)
{
    int value;
    value=LinuxNice(GetCurrentThread(),(int)scall_ebx);
    /* Wire encoding is nice+20 so legitimate negative nice values never
     * collide with the kernel's negative errno convention. */
    if(value < -20 || value > 19) return -EINVAL;
    return value+20;
}

int scall_getpriority_posix(SYSCALLPAR)
{
    int pid,value;
    if((int)scall_ebx!=0) return -EINVAL;
    pid=(int)scall_ecx;
    if(pid==0) pid=GetCurrentThread();
    if(pid<=0 || pid>=nr_threads || !thread_states[pid]) return -ESRCH;
    value=LinuxGetPriority(pid);
    return value+20;
}

int scall_setpriority_posix(SYSCALLPAR)
{
    if((int)scall_ebx!=0) return -EINVAL;
    return LinuxSetPriority((int)scall_ecx,(int)scall_edx);
}

int scall_uname(SYSCALLPAR)
{
    JTMOS_UTSNAME *u;
    u=(JTMOS_UTSNAME *)A2KRange(scall_ebx,sizeof(*u));
    if(!u) return -EFAULT;
    return LinuxUname(u);
}

int scall_sysinfo(SYSCALLPAR)
{
    JTMOS_SYSINFO *i;
    i=(JTMOS_SYSINFO *)A2KRange(scall_ebx,sizeof(*i));
    if(!i) return -EFAULT;
    return LinuxSysinfo(i);
}
