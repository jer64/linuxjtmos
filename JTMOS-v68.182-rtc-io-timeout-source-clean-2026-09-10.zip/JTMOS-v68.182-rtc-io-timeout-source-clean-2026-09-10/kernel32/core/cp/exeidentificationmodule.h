#ifndef __INCLUDED_EXEIDENT_H__
#define __INCLUDED_EXEIDENT_H__

/* Historical JTMOS executable identity.  New libc binaries also emit the
 * numeric tag in .jtmos.ident; old binaries remain compatible through the
 * two textual markers. */
#define JTMOS_EXE_MAGIC1        0xFCE2E37BUL
#define JTMOS_EXE_MAGIC2        0xE38BA000UL
#define JTMOS_EXE_TAG_VERSION   1U

#define JTMOS_EXE_FORMAT_UNKNOWN     0
#define JTMOS_EXE_FORMAT_LEGACY_RAW  1
#define JTMOS_EXE_FORMAT_ELF32       2

#define EXEIDENT_OK                  0
#define EXEIDENT_BAD_ARGUMENT       -1
#define EXEIDENT_BAD_ELF            -2
#define EXEIDENT_BAD_IDENTITY       -3
#define EXEIDENT_UNSUPPORTED        -4

/* Fixed-size tag emitted by modern libc/crt0.S.  Keep the layout independent
 * of host packing rules: six 32-bit words, little-endian in ELF32/i386. */
typedef struct
{
    DWORD magic1;
    DWORD magic2;
    DWORD version;
    DWORD size;
    DWORD flags;
    DWORD reserved;
} JTMOS_EXE_TAG;

int verifyExeBinary(const BYTE *buf, int len, int *format_out);
int isExeBinary(BYTE *buf, int l);
extern int exeIdentAnythingGoes;
int getExeMemReq(BYTE *buf, int l);

#endif
