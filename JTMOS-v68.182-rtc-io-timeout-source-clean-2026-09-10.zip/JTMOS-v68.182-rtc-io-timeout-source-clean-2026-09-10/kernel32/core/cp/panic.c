/*
 * JTMOS kernel fatal-error handler.
 *
 * The old panic path changed SS:ESP inside a C function, re-enabled IRQs and
 * called high-level video/task code.  Any of those operations can recursively
 * fault when the kernel is already damaged.  This handler is deliberately
 * small, re-entrant-safe and serial-first.
 */
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "threads.h"
#include "panic.h"

volatile int kernel_panic_active=0;

static __attribute__((noreturn)) void panic_halt_forever(void)
{
    for(;;)
        __asm__ __volatile__("cli; hlt");
}

/* Retained for the old timer/stack-violation assembly path.  Unlike the old
 * implementation this function really leaves the machine in a critical state:
 * every maskable IRQ is masked and IF remains clear. */
void IRQStatusCritical(void)
{
    int i;
    disable();
    for(i=0;i<16;i++)
        disable_irq((unsigned short)i);
}

static void panic_serial_value(const char *name, DWORD value)
{
    DebugSerialEmergencyWrite(name);
    DebugSerialEmergencyWriteHex32(value);
    DebugSerialEmergencyWrite("\n");
}

/* Lock-free last-resort text output.  Never call terminal/printf code from a
 * fatal handler: a panic can originate while those locks or allocators are
 * already held.  VGA text memory is identity mapped by the early kernel. */
static void panic_vga_write(unsigned row, const char *text)
{
    volatile WORD *vga=(volatile WORD *)0xB8000;
    unsigned col=0;
    if(!text || row>=25) return;
    while(*text && col<80)
    {
        vga[row*80+col]=(WORD)(0x4F00U | (BYTE)*text);
        ++text; ++col;
    }
}

__attribute__((noreturn))
void KernelFatalAt(const char *msg, const char *file, const char *function, int line)
{
    DWORD flags, cr2, esp;
    int pid=-1;

    flags=get_eflags();
    cr2=GETCR2();
    esp=GETESP();
    disable();

    /* A second panic means diagnostics themselves faulted.  Never recurse into
     * printf, terminal switching, allocators or locks from here. */
    if(kernel_panic_active)
    {
        DebugSerialEmergencyWrite("\n*** NESTED KERNEL PANIC - CPU HALTED ***\n");
        panic_halt_forever();
    }
    kernel_panic_active=1;

    if(tasks!=NULL && nr_curthread>=0 && nr_curthread<N_MAX_THREADS)
        pid=nr_curthread;

    DebugSerialEmergencyWrite("\n*** JTMOS KERNEL PANIC ***\n");
    DebugSerialEmergencyWrite("message: "); DebugSerialEmergencyWrite(msg ? msg : "(null)"); DebugSerialEmergencyWrite("\n");
    DebugSerialEmergencyWrite("file: "); DebugSerialEmergencyWrite(file ? file : "(unknown)"); DebugSerialEmergencyWrite("\n");
    DebugSerialEmergencyWrite("function: "); DebugSerialEmergencyWrite(function ? function : "(unknown)"); DebugSerialEmergencyWrite("\n");
    panic_serial_value("line: ", (DWORD)line);
    panic_serial_value("pid: ", (DWORD)pid);
    panic_serial_value("CS: ", GETCS());
    panic_serial_value("SS: ", GETSS());
    panic_serial_value("ESP: ", esp);
    panic_serial_value("CR2: ", cr2);
    /* This is the EFLAGS at entry to KernelFatalAt(), not necessarily the
     * interrupted task's EFLAGS.  For interrupt-gate #GP/#PF the authoritative
     * fault-frame value is printed by FATALEXCEPTION as LIVE_EFLAGS. */
    panic_serial_value("EFLAGS(current before panic CLI): ", flags);
    DebugSerialEmergencyWrite("Interrupts are disabled. System halted safely.\n");

    /* Last-resort screen marker without locks, allocation, terminal switching
     * or formatting.  The complete report is already on the debug serial port. */
    panic_vga_write(0, "*** JTMOS KERNEL PANIC ***");
    panic_vga_write(1, msg ? msg : "(null)");
    panic_vga_write(2, "See serial log for CPU state. System halted.");

    panic_halt_forever();
}

__attribute__((noreturn)) void FATALERROR(const char *s)
{
    KernelFatalAt(s, "(legacy fatal)", "FATALERROR", 0);
}

/* Keep the historical symbol so old objects/modules still link.  This is not
 * used by new recoverable error paths. */
__attribute__((noreturn)) void panic(const char *s)
{
    KernelFatalAt(s, "(legacy panic)", "panic", 0);
}
