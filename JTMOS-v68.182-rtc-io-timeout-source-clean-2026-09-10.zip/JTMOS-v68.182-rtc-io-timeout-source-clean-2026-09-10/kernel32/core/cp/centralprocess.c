// ================================================================
// centralprocess.c - The process creator & Debug window view & Recycler
// (C) 2002-2005,2017 by Jari Tuominen(jari.t.tuominen@gmail.com).
// ================================================================
/*
 * How much to allocate memory for each of the processes?
 *
 * Check out file 'LaunchApp.h' for the amount of memory
 * the kernel will spend on each of the application
 * that runs inside it's own memory space.
 * For instance centralprocess process will be creating processes
 * that are depending on the setting of LaunchApp.h.
 */
#include "kernel32.h" // STATIC_APP_MEM_SIZE
#include "threads.h"
#include "centralprocess.h"
#include "centralprocessInit.h"
#include "sysglvar.h"
#include "keyb.h"
#include "syssh.h"	// ShellMain
#include "driver_api.h"	// driver_getLock
#include "centralprocessMain.h"
#include "linuxabi.h"
#include "jtmfsPath.h"
#include "jtmfsAccess.h"
#include "filedir.h"
#include "scheduler.h"

//#define centralprocess_DEBUG

//
VERBATIM centralprocess;
//
int turn=1;

// This function's purpose is to explain the happended error
// in human friendly English language, so that the user
// can understand the error. This information is used in
// debugging.
void centralprocessExplainError(void)
{
	//
	switch(centralprocess.error)
	{
		// No error
		case 0:
		break;
		//
		case CENTRALPROCESS_ERROR_LAUNCHAPPERROR:
		printk("CENTRALPROCESS: Application launch error, detail=%d.\n",
			centralprocess.launch_detail);
		break;
		//
		case CENTRALPROCESS_ERROR_FILENOTFOUND:
		printk("CENTRALPROCESS: Executable binary file not found.\n");
		break;
		//
		case CENTRALPROCESS_ERROR_CORRUPTEDEXE:
		printk("CENTRALPROCESS: Corrupted or non-JTMOS executable binary file.\n");
		break;
		//
		default:
		printk("CENTRALPROCESS: Unknown error occured while creating a process.\n");
		break;
	}
}

//
void trap1(void)
{
}

// fname = file name, ends at the first space(space not included)
// path = whole command line with arguments
int centralprocess_exec(const char *fname, const char *path, int dnr, int db,
		const char *runPath,
		int terID)
{
	{
		int caller=GetCurrentThread();
		return centralprocess_exec_stdio(fname,path,dnr,db,runPath,terID,
			LinuxGetStdioRoute(caller,0),LinuxGetStdioRoute(caller,1),
			LinuxGetStdioRoute(caller,2));
	}
}

int centralprocess_exec_stdio(const char *fname, const char *path, int dnr, int db,
		const char *runPath, int terID, int stdinFD, int stdoutFD, int stderrFD)
{
	DWORD entry_flags,cs_flags;
	int pid,error;
	int requesterPID;
	int run_dnr,run_db,run_rv;
	char canonical_runpath[256];
	const char *requested_runpath;

	if(fname==NULL)return 0;

	/* V67.8.57.10.18.16.31: libc cexec()/bgexec() use terminal -1 as
	 * the portable "inherit my controlling terminal" sentinel.  Never copy
	 * that sentinel into thread_terminal[]: console syscalls index screens[]
	 * with the child's terminal number, so -1 turns the first printf/getch into
	 * an out-of-bounds access.  SMSH passed an explicit terminal and therefore
	 * hid this bug; SQSH uses libc and exposed it almost every launch. */
	requesterPID=GetCurrentThread();

	/* Resolve the requested child CWD while the submitting process context is
	 * still authoritative.  The permanent Central Process has its own DNR/DB;
	 * resolving/chdir'ing later in that service loses device-qualified cwd
	 * information (for example hda:/work becoming /).  Empty workDir means
	 * inherit the caller exactly. */
	/* Empty workDir means exact CWD inheritance.  Do not round-trip the
	 * request through a textual path at all: DNR/DB is the authoritative
	 * filesystem location and preserves ram:/bin versus ram:/ exactly. */
	if(runPath==NULL || !runPath[0])
	{
		requested_runpath="<inherit>";
		run_dnr=dnr;
		run_db=db;
		run_rv=JTMFS_PATH_OK;
	}
	else
	{
		requested_runpath=runPath;
		run_dnr=dnr; run_db=db;
		run_rv=jtmfsResolvePathAt(dnr,db,requested_runpath,&run_dnr,&run_db);
		if(run_rv!=JTMFS_PATH_OK)
		{
			printk("CP: requester PID%d workdir '%s' cannot be resolved from DNR/DB=%d/%d (rv=%d).\n",
				requesterPID,requested_runpath,dnr,db,run_rv);
			return 0;
		}
	}
	canonical_runpath[0]=0;
    if(runPath==NULL || !runPath[0])
    {
        /* Exact inheritance: ask the per-thread cwd cache first.  This string is
         * diagnostic only; execution continues to use run_dnr/run_db directly. */
        if(jtmfs_GetThreadCWD(requesterPID,canonical_runpath,sizeof(canonical_runpath))!=JTMFS_PATH_OK)
            canonical_runpath[0]=0;
    }
    else if(jtmfsBuildPath(run_dnr,run_db,canonical_runpath,sizeof(canonical_runpath))!=JTMFS_PATH_OK)
        canonical_runpath[0]=0;

	if(!canonical_runpath[0])
	{
		/* A display-only fallback must not change the real runDNR/runDB. */
		if(runPath!=NULL && runPath[0])
			strncpy(canonical_runpath,runPath,sizeof(canonical_runpath)-1);
		else
			strncpy(canonical_runpath,"<caller-cwd>",sizeof(canonical_runpath)-1);
		canonical_runpath[sizeof(canonical_runpath)-1]=0;
	}

	if(terID==-1)
		terID=GetThreadTerminal(requesterPID);
	if(terID<0 || terID>=N_MAX_SCREENS)
	{
		printk("CP: invalid terminal %d for requester PID%d; using terminal 0.\n",
			terID,requesterPID);
		terID=0;
	}

	/* V68.153: centralprocess_exec() is a blocking process-context service.
	 * Build 151 kept CLI active across all of the SwitchToThread() wait loops;
	 * vt2 autostart made that path run on every normal boot.  That propagated
	 * IF=0 through voluntary task switches and left exception recovery without
	 * IRQ0/IRQ1.  Only the shared request publication itself needs to be atomic.
	 */
	entry_flags=get_eflags();
	for(;;)
	{
		cs_flags=get_eflags();
		disable();
		if(!centralprocess.isBusy && !centralprocess.resultPending)
		{
			centralprocess.isBusy=1;
			centralprocess.appPID=0;
			centralprocess.error=0;
			centralprocess.launch_detail=0;
			launchapp_cleartogo=0;
			centralprocess.terminalID=terID;
			centralprocess.requesterPID=requesterPID;
			centralprocess.stdinFD=stdinFD;
			centralprocess.stdoutFD=stdoutFD;
			centralprocess.stderrFD=stderrFD;
			strcpy(centralprocess.fname,fname);
			strcpy(centralprocess.path,path);
			if(strstr(centralprocess.fname,".")==NULL) strcat(centralprocess.fname,".bin");
			strcpy(centralprocess.runPath,canonical_runpath);
			centralprocess.dnr=dnr;
			centralprocess.db=db;
			centralprocess.callerDNR=dnr;
			centralprocess.callerDB=db;
			centralprocess.runDNR=run_dnr;
			centralprocess.runDB=run_db;
			centralprocess.inheritCWD=(runPath==NULL || !runPath[0]) ? 1 : 0;
			set_eflags(cs_flags);
			break;
		}
		set_eflags(cs_flags);
		SchedulerWaitPause(1000UL);
	}

	/* A blocking launch must not yield repeatedly with maskable interrupts
	 * disabled.  If a legacy caller entered with IF clear, temporarily enable
	 * IRQs while waiting and restore its entry state before returning. */
	if(!(entry_flags & 0x200UL))
	{
		dprintk("CP: exec requester PID%d entered with IF=0; enabling IRQs for blocking wait.\n",
			requesterPID);
		enable();
	}

	while(!launchapp_cleartogo) { SchedulerWaitPause(1000UL); }
	while(centralprocess.isBusy) { SchedulerWaitPause(1000UL); }

	/* Copy and release the single published result atomically.  resultPending
	 * prevents a second submitter from reusing the request record before this
	 * caller has consumed appPID/error. */
	cs_flags=get_eflags();
	disable();
	pid=centralprocess.appPID;
	error=centralprocess.error;
	centralprocess.resultPending=0;
	set_eflags(cs_flags);

	/* Preserve the caller's original IF contract, but only after all blocking
	 * work and cooperative yields have completed. */
	if(!(entry_flags & 0x200UL))
		disable();
	if(error) return 0;
	return pid;
}

// FILE NAME, PATH, TERMINAL ID
//
// dnr,db =	location where the EXE binary resides
// fname =	file name of the EXE binary file
// runPath =	the path where program will run/work at
//		(aka work path, e.g. '/tmp')
//
int centralprocessExecEx(const char *fname, const char *path, int terminalID,
		int dnr, int db, const char *runPath)
{
	return centralprocess_exec_stdio(fname,path,dnr,db,runPath,terminalID,-1,-1,-1);
}

//
void centralprocess_wait_moment(void)
{
	int i;

	//
	for(i=0; i<10; i++)
		SchedulerWaitPause(1000UL);
}

// Called by centralprocess main porcess to load up the exe
int centralprocess_loadEXE(const char *fname)
{
	static int sz;
	int NeedToLoad;
	char path[256],found[256],loadname[256];
	int fd;

	//
	NeedToLoad=1;

	// -----------------------------------------------
	// INITIALIZE
	// Set error
	centralprocess.error=0;
	// Set device
	SetThreadCWDContext(GetCurrentThread(), centralprocess.dnr, centralprocess.db);

	// -----------------------------------------------
	// LOAD EXECUTABLE FILE INTO centralprocess.bin -BUFFER

	/* Preserve the const input contract. Direct callers may pass a bare name. */
	strncpy(loadname,fname,sizeof(loadname)-1);
	loadname[sizeof(loadname)-1]=0;
	if(strstr(loadname, ".")==NULL && strlen(loadname)+4U<sizeof(loadname))
		strcat(loadname, ".bin");
	fname=loadname;

	// INTERNAL APPLICATION
	if(!strcmp(fname, ":install.bin"))
	{
		sz = 65536;
		//memcpy(centralprocess.bin, testapp, 65536);
		NeedToLoad=0;
		goto past11;
	}

	// INTERNAL DRIVER
	if(!strcmp(fname, ":hd.bin"))
	{
		sz = 65536;
	//	memcpy(centralprocess.bin, testdrv, 65536);
		NeedToLoad=0;
		goto past11;
	}

	/* V68.119: executable resolution has one important shell invariant:
	 * a bare command name must first mean "the file in the caller's current
	 * directory".  `ls` and `cexec("unz.bin", "")` must therefore agree.
	 *
	 * centralprocess_loadEXE() has already installed centralprocess.dnr/db as
	 * the CP thread's temporary filesystem context above, so open(fname) here
	 * is an exact probe against the original SYS_cexec caller DNR/DB.  Only if
	 * that probe fails do we search PATH.  This also avoids converting the cwd
	 * to text and back, which can lose device identity (ram:/ versus hda1:/).
	 *
	 * Explicit paths -- including device-qualified names such as ram:/unz.bin
	 * and ram:unz.bin -- never fall through to PATH. */
	strcpy(found, "");
	if(strchr(fname,'/')!=NULL || strchr(fname,'\\')!=NULL || strchr(fname,':')!=NULL)
	{
		strcpy(found,fname);
	}
	else
	{
		int cwd_fd;
		int cwd_sz;

		/* CWD first.  A zero-length executable is not useful, but it still
		 * counts as an existing pathname; the normal size validation below will
		 * report it as an invalid/not-loadable executable. */
		cwd_fd=open(fname,O_RDONLY);
		if(cwd_fd>=0)
		{
			cwd_sz=lseek(cwd_fd,0,SEEK_END);
			close(cwd_fd);
			if(cwd_sz>=0)
			{
				strcpy(found,fname);
				printk("Exec resolver: caller cwd match '%s' at DNR/DB=%d/%d.\n",
					fname,centralprocess.dnr,centralprocess.db);
			}
		}

		if(!found[0])
		{
			/* If the command is not in cwd, use the submitting process PATH.
			 * If that process has no local PATH yet, fall back to the system
			 * default rather than rejecting an otherwise healthy process. */
			strcpy(path, "");
			if(ProcessEnvGet(centralprocess.requesterPID,"PATH",path,sizeof(path))<0 || !path[0])
			{
				if(kgetglobalenv("PATH",path,sizeof(path))<0 || !path[0])
				{
					printk("Error: requester PID%d has no usable PATH environment variable.\n",
						centralprocess.requesterPID);
					goto error;
				}
			}

			if(!SearchThroughPath(path,fname,found))
			{
				printk("Exec resolver: '%s' not found in caller cwd DNR/DB=%d/%d or PATH='%s'.\n",
					fname,centralprocess.dnr,centralprocess.db,path);
				goto error;
			}
			printk("Exec resolver: PATH match at %s.\n",found);
		}
	}


	//-----------------------------------------------------------------------
	/*
	 * Use the kernel's integer file-descriptor API here.  The historical
	 * code accidentally called fopen(found, O_RDONLY), stored the FILE *
	 * in an int and then passed it to lseek().  SearchThroughPath() had
	 * already found the file correctly, but this second size check could
	 * therefore report zero and reject a perfectly valid executable.
	 */
	fd = open(found, O_RDONLY);
	if(fd >= 0)
	{
		sz = lseek(fd, 0, SEEK_END);
		close(fd);
		if(sz < 0) sz = 0;
	}
	else
	{
		sz = 0;
	}
past11:
	centralprocess.exesz = sz;
	printf("FILE '%s' SIZE = %d bytes (%x), maxsz = %d\n",
		fname, sz,sz, centralprocess.l_bin);
//	getch();
	if(sz>=centralprocess.l_bin)	goto error;
	if(sz<=0)
	{
		printk("centralprocess: File '%s'(%s) not found, sz=%d(0x%x)\n",
			fname, found, sz, sz);
error:
		disable();
		centralprocess.error = CENTRALPROCESS_ERROR_FILENOTFOUND; // 1 = file not found
		centralprocess.appPID=0;
		launchapp_cleartogo=3;
		/* centralprocess_run() publishes the completed result after diagnostics. */
		goto past;
	}

	// 1. Read exe binary
	if(NeedToLoad)
	{
		int got,total;

		printk("%s: Reading file '%s', size=%dK bytes, Buffer* = 0x%x.\n",
			__FUNCTION__, found, sz/1024+1,  centralprocess.bin);

		/* A regular read is allowed to return fewer bytes than requested.
		 * The old loader ignored the return value and immediately validated /
		 * executed the staging buffer.  On JTMFS/FlexFAT a read that ends at a
		 * cache, cluster or device boundary can therefore leave the tail of a
		 * larger ELF image stale from the previous executable.  Small commands
		 * then appear reliable while larger libc programs fail nondeterministically.
		 *
		 * Clear the image and read exactly the size established by lseek(). */
		memset(centralprocess.bin,0,sz);
		fd = open(found, O_RDONLY);
		if(fd < 0)
		{
			printk("centralprocess: unable to reopen executable '%s'.\n",found);
			goto error;
		}

		total=0;
		while(total < sz)
		{
			got=read(fd,centralprocess.bin+total,sz-total);
			if(got <= 0)
				break;
			total += got;
			SchedulerCooperate();
		}
		close(fd);

		if(total != sz)
		{
			printk("centralprocess: short executable read '%s': expected=%d got=%d.\n",
				found,sz,total);
			goto error;
		}
	}
dontload:

	// 2. Confirm executable identity + structural format using the same
	// validator that every LaunchApp entry point enforces.
	{
		int exe_format=0;
		int verify_rv=LaunchAppValidateImage(centralprocess.bin,sz,&exe_format);
		if(verify_rv!=LAUNCHAPP_ELF_OK)
		{
			disable();
			centralprocess.appPID=0;
			centralprocess.error = CENTRALPROCESS_ERROR_CORRUPTEDEXE;
			centralprocess.launch_detail=verify_rv;
			printk("centralprocess: executable verify failed detail=%d format=%d.\n",
				verify_rv,exe_format);
			launchapp_cleartogo=3;
			/* centralprocess_run() publishes the completed result after diagnostics. */
			goto past;
		}
	}

	// 3. Get memory requirement
	centralprocess.memrq = getExeMemReq(centralprocess.bin, sz);
	printk("Memory requirement = %dK\n", centralprocess.memrq);

	// 4. Report
	printk("Read complete, launching up application at directory '%s'\n",
		centralprocess.runPath);
past:
	// --------------------------------------------------------------
	return centralprocess.error;
}

// Called by process creator to summon up a new process.
int centralprocess_job(void)
{
	//
	// void centralprocess_createproc(const char *fname,
	// void *appcode,int appsize)
	return centralprocess_createproc(centralprocess.fname, centralprocess_runexe1, 1024*512);
}

// Called by centralprocess_job.
int centralprocess_createproc(const char *fname,
		void *appcode, int appsize)
{
	// ------------------------------------------------------------------
	static char *appstack;
	static int pid,pr,key,memkb;
	static char str[256];

	// ========== DISABLE INTERRUPTS ====================================
	/* Do not chdir() the permanent CP service.  The child work location was
	 * resolved in the requester context and is carried as exact DNR/DB. */
	printk("%s: child DNR/DB=%d/%d (cwd '%s')\n",
		__FUNCTION__, centralprocess.runDNR, centralprocess.runDB,
		centralprocess.runPath);

	//
	disable();
	// Get default memory requirement.
	memkb = STATIC_APP_MEM_SIZE;
	// Use custom memory requirement if one defined.
	if(centralprocess.memrq)
		memkb = centralprocess.memrq;
	/* V68.118: runDNR/runDB are immutable.  They were captured/resolved at the
	 * original SYS_cexec entry.  Re-reading the parent here is a race: the parent
	 * may have chdir()'d while this request waited for the Central Process. */

	/* Keep isBusy set until the complete process record is committed.  V66
	 * cleared it before LaunchAppEx(), allowing a concurrent exec request to
	 * overwrite the shared staging buffer/path while this launch was active. */
	{
		LAUNCHAPP_CONTEXT launchctx;
		launchctx.callerPID=centralprocess.requesterPID;
		launchctx.callerDNR=centralprocess.callerDNR;
		launchctx.callerDB=centralprocess.callerDB;
		launchctx.runDNR=centralprocess.runDNR;
		launchctx.runDB=centralprocess.runDB;
		pid = LaunchAppExContext(centralprocess.bin,centralprocess.exesz,memkb,&launchctx);
	}

	/* LaunchAppExContext() already receives the immutable intended DNR/DB, but make cwd
	 * inheritance a checked process invariant rather than an assumption.
	 * Do this before the child is selected for execution below. */
	if(pid > 0 && !centralprocess.error)
	{
		if(GetThreadDNR(pid)!=centralprocess.runDNR ||
		   GetThreadDB(pid)!=centralprocess.runDB)
		{
			printk("CP: repairing child PID%d cwd DNR/DB %d/%d -> %d/%d.\n",
				pid,GetThreadDNR(pid),GetThreadDB(pid),
				centralprocess.runDNR,centralprocess.runDB);
			SetThreadCWDContext(pid,centralprocess.runDNR,centralprocess.runDB);
		}
	}

    if(pid > 0 && !centralprocess.error && centralprocess.runPath[0] &&
       centralprocess.runPath[0]!='<')
        (void)SetThreadCWDCache(pid,centralprocess.runPath,FileDirPathGeneration());

	/* LaunchAppEx() is executed by the permanent Central Process service.
	 * Generic thread creation therefore initially inherits CP's environment.
	 * Replace that private snapshot with the actual exec requester's snapshot
	 * before interrupts are re-enabled and before the child can run. */
	if(pid > 0 && !centralprocess.error &&
	   ProcessEnvInherit(pid,centralprocess.requesterPID)<0)
	{
		/* Environment metadata must not be able to veto execution of an already
		 * loaded, valid binary.  Leave the child without a snapshot; the first
		 * environment access can lazily clone the global defaults when memory is
		 * available.  This is especially important for GraOS recovery tools. */
		printk("CP: warning: environment inherit PID%d -> PID%d failed; launching with lazy defaults.\n",
			centralprocess.requesterPID,pid);
		ProcessEnvRelease(pid);
	}

	if(pid > 0 && !centralprocess.error &&
	   LinuxProcessExecSetup(pid,centralprocess.requesterPID,
		centralprocess.stdinFD,centralprocess.stdoutFD,centralprocess.stderrFD)!=0)
	{
		printk("CP: unable to attach stdio for PID%d.\n",pid);
		KillThreadEx(pid,KT_NO_THREAD_SWITCH);
		pid=0;
		centralprocess.error=CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
		centralprocess.launch_detail=LAUNCHAPP_DETAIL_THREAD;
	}

	if(pid > 0 && !centralprocess.error)
	{
		SetThreadCmdLine(pid, centralprocess.path);
		IdentifyThread(pid, centralprocess.fname);
		SetThreadTerminal(pid, centralprocess.terminalID);
		syskey_terminate=0;
		pr=1;
		centralprocess.appPID = pid;
	}
	else
	{
		/* Never apply failed-launch metadata to PID 0. */
		centralprocess.appPID = 0;
		if(!centralprocess.error)
			centralprocess.error = CENTRALPROCESS_ERROR_LAUNCHAPPERROR;
	}

	launchapp_cleartogo=1;

	// ========== ENABLE INTERRUPTS ===================================
	enable();

	if(pid > 0 && !centralprocess.error)
		SwitchToThreadEx(pid);
	return pid;
}

//
void centralprocess_runexe1(void)
{
	//
	centralprocess_runexe(centralprocess.fname);
}

// centralprocess Run Exe
// Does not return any value.
int centralprocess_runexe(const char *fname)
{
	int memkb;

	/* The permanent CP service must not adopt the child's cwd. */

	// Get default memory requirement
	memkb = STATIC_APP_MEM_SIZE;
	// Use custom memory requirement if one defined
	if(centralprocess.memrq)
		memkb = centralprocess.memrq;

	// - Launch up application using the immutable original cexec context.
	{
		LAUNCHAPP_CONTEXT launchctx;
		launchctx.callerPID=centralprocess.requesterPID;
		launchctx.callerDNR=centralprocess.callerDNR;
		launchctx.callerDB=centralprocess.callerDB;
		launchctx.runDNR=centralprocess.runDNR;
		launchctx.runDB=centralprocess.runDB;
		centralprocess.appPID = LaunchAppExContext(centralprocess.bin,centralprocess.exesz,memkb,&launchctx);
	}
	if(centralprocess.appPID>0)
	{
		SetThreadDNR(centralprocess.appPID,centralprocess.runDNR);
		SetThreadDB(centralprocess.appPID,centralprocess.runDB);
	}
	launchapp_cleartogo=1;
	return centralprocess.appPID;
}

//
void centralprocess_HelpPage(void)
{
	//
	printk("'k'=Kill process  [Space]=List processes  's'=Launch new shell\n");
	printk("'l'=Show DRIVER API lock PID  'h'=Show this help page\n");
	printk("'u'=Force unlock DRIVER API lock  'y'=Show last function for lock owner\n");
	printk("'d'=Directory cache info  'f'=FILEDES info  'F'=JTMFAT info\n");
	printk("'D'=List devices  'v'=toggle verbose debugging  'r'=toggle serial console redirect\n");
}

//


