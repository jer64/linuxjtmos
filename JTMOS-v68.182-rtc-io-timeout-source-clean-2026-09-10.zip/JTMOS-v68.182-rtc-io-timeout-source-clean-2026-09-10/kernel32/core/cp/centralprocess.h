#ifndef __INCLUDED_CENTRALPROCESS_H__
#define __INCLUDED_CENTRALPROCESS_H__

// CENTRALPROCESS ERRORS
#define CENTRALPROCESS_ERROR_FILENOTFOUND	1
#define CENTRALPROCESS_ERROR_LAUNCHAPPERROR	2
#define CENTRALPROCESS_ERROR_CORRUPTEDEXE	3

// Time-out values
#define CENTRALPROCESS_EXEC_WAIT_TIMEOUT	6000

// 
typedef struct
{
	// EXE binary file is stored here
	int l_bin;
	BYTE *bin;
	// Executable precise size in bytes
	int exesz;
	// Set when centralprocess cannot get any new parameters
	int             isBusy;
	/* A completed request keeps its result reserved until the submitting
	 * caller has copied appPID/error.  Without this handshake a second exec
	 * could reset appPID to zero between completion and the first caller's
	 * return, producing the misleading "process created, PID=0" race. */
	int             resultPending;
	// File name of the binary to load the process binary
	// from, that will be created.
	char            fname[256];
	char            path[256];
	// 
	int             appPID;
	int             terminalID;
	/* Submitting process and optional process-local stdio routes.  A value
	 * below zero means native terminal/default semantics. */
	int             requesterPID;
	int             stdinFD, stdoutFD, stderrFD;
	//
	int memrq;
	//
	int error, dnr,db;
	/* Immutable original cexec caller cwd snapshot.  dnr/db above are the
	 * executable lookup base retained for legacy Central Process code; these
	 * fields make the origin explicit and must never be re-read later. */
	int callerDNR,callerDB;
	/* Resolved child working directory.  Unlike runPath, these values retain
	 * the caller's device/mount identity across the permanent CP service. */
	int runDNR,runDB;
	/* Non-zero when the exec caller supplied an empty workDir.  This means
	 * exact inheritance of the DNR/DB snapshot captured at exec submission;
	 * no textual cwd round-trip or late parent re-snapshot is permitted. */
	int inheritCWD;
	/* V67: detailed LaunchApp status, while error keeps the stable CP ABI. */
	int launch_detail;
	//
	char		runPath[256];
}VERBATIM;

// Internal functions:
void            centralprocess_run(void);
void            centralprocess_init(void);
int             centralprocess_runexe(const char *fname);
void            centralprocessExplainError(void);
int             centralprocess_loadEXE(const char *fname);
int             centralprocess_job(void);
int             centralprocess_createproc(const char *fname, void *appcode, int appsize);

// Functions used by system calls:
int             centralprocess_exec(const char *fname, const char *path,
		int dnr, int db,
		const char *runPath,
		int terID);
int             centralprocess_exec_stdio(const char *fname, const char *path,
		int dnr, int db, const char *runPath, int terID,
		int stdinFD, int stdoutFD, int stderrFD);
int		centralprocessExecEx(const char *fname, const char *path,
		int terminalID,
		int dnr, int db,
		const char *runPath);
void trap1(void);

// 
VERBATIM   centralprocess;

//
int isExeBinary(BYTE *buf, int l);
void centralprocess_runexe1(void);

//
#include "exeidentificationmodule.h"
#include "centralprocessMain.h"

#endif
