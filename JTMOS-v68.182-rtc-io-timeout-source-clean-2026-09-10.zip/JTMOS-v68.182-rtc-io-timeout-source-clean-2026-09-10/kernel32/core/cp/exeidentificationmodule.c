//=======================================================================
// JTMOS executable file identification.
// (C) 2003-2005 by Jari Tuominen.
// ELF32 / structured identity hardening 2026.
//=======================================================================
#include "kernel32.h"
#include "elf32.h"
#include "exeidentificationmodule.h"

#define EXEIDENT_MAX_PHDRS 128

/* Debug escape hatch retained for legacy bring-up.  It never disables ELF
 * structural validation: malformed ELF must not reach the loader even when
 * marker checking is intentionally bypassed. */
int exeIdentAnythingGoes = FALSE;

static const char exe_id_first[] = "[JTMOS LIBC (C) 2002 Jari Tuominen]";
static const char exe_id_tail[] = "[VALID JTMOS EXECUTABLE BINARY FILE FCE2E37BE38BA000]";
static const char exe_id_tag_v1[] = "[JTMOS EXE ABI TAG V1]";

static int exe_range_inside(DWORD off, DWORD amount, DWORD total)
{
    if(off > total) return FALSE;
    return amount <= total - off;
}

static int exe_add_overflows(DWORD a, DWORD b)
{
    return a > 0xffffffffUL - b;
}

static int exe_find_bytes(const BYTE *buf, int len, const BYTE *needle, int n,
                          int start, int search_len)
{
    int i,j,end;
    if(!buf || !needle || len <= 0 || n <= 0 || start < 0 || start > len)
        return -1;
    if(search_len < 0 || search_len > len-start) search_len=len-start;
    if(n > search_len) return -1;
    end=start+search_len-n;
    for(i=start;i<=end;i++) {
        for(j=0;j<n;j++) if(buf[i+j]!=needle[j]) break;
        if(j==n) return i;
    }
    return -1;
}

static int exe_find_string(const BYTE *buf, int len, const char *needle,
                           int start, int search_len)
{
    if(!needle) return -1;
    return exe_find_bytes(buf,len,(const BYTE *)needle,strlen(needle),start,search_len);
}

static int exe_is_elf_magic(const BYTE *buf, int len)
{
    return buf && len >= 5 &&
           buf[EI_MAG0]==ELFMAG0 && buf[EI_MAG1]==ELFMAG1 &&
           buf[EI_MAG2]==ELFMAG2 && buf[EI_MAG3]==ELFMAG3;
}

static int exe_tag_valid_at(const BYTE *buf, int len, int off)
{
    const JTMOS_EXE_TAG *tag;
    if(off < 0 || off > len-(int)sizeof(JTMOS_EXE_TAG)) return FALSE;
    tag=(const JTMOS_EXE_TAG *)(buf+off);
    return tag->magic1==JTMOS_EXE_MAGIC1 &&
           tag->magic2==JTMOS_EXE_MAGIC2 &&
           tag->version==JTMOS_EXE_TAG_VERSION &&
           tag->size==sizeof(JTMOS_EXE_TAG) &&
           tag->reserved==0;
}

/* Validate enough ELF structure here that identity matching cannot be tricked
 * by appending marker strings to a malformed file.  LaunchApp performs the
 * full virtual-layout validation again before mapping pages. */
static int exe_verify_elf32(const BYTE *buf, int len)
{
    const Elf32_Ehdr *eh;
    const Elf32_Phdr *ph;
    DWORD phbytes,off,segend;
    int i,loads,entry_exec,first_found,tail_found,tag_v1_found,tag_valid;

    if(len < (int)sizeof(Elf32_Ehdr)) return EXEIDENT_BAD_ELF;
    eh=(const Elf32_Ehdr *)buf;
    if(eh->e_ident[EI_CLASS]!=ELFCLASS32 ||
       eh->e_ident[EI_DATA]!=ELFDATA2LSB ||
       eh->e_ident[EI_VERSION]!=EV_CURRENT || eh->e_version!=EV_CURRENT)
        return EXEIDENT_UNSUPPORTED;
    if(eh->e_type!=ET_EXEC || eh->e_machine!=EM_386)
        return EXEIDENT_UNSUPPORTED;
    if(eh->e_ehsize!=sizeof(Elf32_Ehdr) ||
       eh->e_phentsize!=sizeof(Elf32_Phdr) || eh->e_phnum==0 ||
       eh->e_phnum>EXEIDENT_MAX_PHDRS)
        return EXEIDENT_BAD_ELF;
    phbytes=(DWORD)eh->e_phnum*(DWORD)eh->e_phentsize;
    if(exe_add_overflows(eh->e_phoff,phbytes) ||
       !exe_range_inside(eh->e_phoff,phbytes,(DWORD)len))
        return EXEIDENT_BAD_ELF;

    loads=0; entry_exec=FALSE; first_found=FALSE; tail_found=FALSE;
    tag_v1_found=FALSE; tag_valid=FALSE;
    for(i=0;i<eh->e_phnum;i++) {
        off=eh->e_phoff+(DWORD)i*(DWORD)eh->e_phentsize;
        ph=(const Elf32_Phdr *)(buf+off);
        if(ph->p_type!=PT_LOAD) continue;
        loads++;
        if(ph->p_memsz<ph->p_filesz ||
           !exe_range_inside(ph->p_offset,ph->p_filesz,(DWORD)len) ||
           exe_add_overflows(ph->p_vaddr,ph->p_memsz))
            return EXEIDENT_BAD_ELF;
        segend=ph->p_vaddr+ph->p_memsz;
        if((ph->p_flags&PF_X) && eh->e_entry>=ph->p_vaddr && eh->e_entry<segend)
            entry_exec=TRUE;
        if(ph->p_filesz) {
            if(exe_find_string(buf,len,exe_id_first,(int)ph->p_offset,(int)ph->p_filesz)>=0)
                first_found=TRUE;
            int tag_marker_off;
            if(exe_find_string(buf,len,exe_id_tail,(int)ph->p_offset,(int)ph->p_filesz)>=0)
                tail_found=TRUE;
            tag_marker_off=exe_find_string(buf,len,exe_id_tag_v1,
                                           (int)ph->p_offset,(int)ph->p_filesz);
            if(tag_marker_off>=0) {
                int tag_off=(tag_marker_off+(int)strlen(exe_id_tag_v1)+1+3)&~3;
                int seg_file_end=(int)(ph->p_offset+ph->p_filesz);
                tag_v1_found=TRUE;
                if(tag_off<=seg_file_end-(int)sizeof(JTMOS_EXE_TAG) &&
                   exe_tag_valid_at(buf,len,tag_off))
                    tag_valid=TRUE;
            }
        }
    }
    if(loads==0 || !entry_exec) return EXEIDENT_BAD_ELF;
    if(exeIdentAnythingGoes) return EXEIDENT_OK;

    /* Old ELF32 JTMOS applications have only the two historical strings.
     * New libc adds the numeric 0xFCE2E37B tag as a stronger unambiguous ABI
     * identity.  Both markers must be in PT_LOAD, never merely appended data. */
    if(!first_found || !tail_found) return EXEIDENT_BAD_IDENTITY;
    /* Presence of the V1 marker opts a modern binary into the structured tag
     * contract.  Old ELF32 binaries without that marker remain executable, but
     * a new binary with a damaged/missing 0xFCE2E37B tag is rejected. */
    if(tag_v1_found && !tag_valid) return EXEIDENT_BAD_IDENTITY;
    return EXEIDENT_OK;
}

int verifyExeBinary(const BYTE *buf, int len, int *format_out)
{
    int first_limit;
    if(format_out) *format_out=JTMOS_EXE_FORMAT_UNKNOWN;
    if(!buf || len<=0) return EXEIDENT_BAD_ARGUMENT;

    if(exe_is_elf_magic(buf,len)) {
        int rv=exe_verify_elf32(buf,len);
        if(rv==EXEIDENT_OK && format_out) *format_out=JTMOS_EXE_FORMAT_ELF32;
        return rv;
    }

    if(exeIdentAnythingGoes) {
        if(format_out) *format_out=JTMOS_EXE_FORMAT_LEGACY_RAW;
        return EXEIDENT_OK;
    }

    first_limit=(len<200)?len:200;
    if(exe_find_string(buf,len,exe_id_first,0,first_limit)<0 ||
       exe_find_string(buf,len,exe_id_tail,0,len)<0)
        return EXEIDENT_BAD_IDENTITY;

    if(format_out) *format_out=JTMOS_EXE_FORMAT_LEGACY_RAW;
    return EXEIDENT_OK;
}

int isExeBinary(BYTE *buf, int len)
{
    int fmt,rv;
    rv=verifyExeBinary((const BYTE *)buf,len,&fmt);
    if(rv!=EXEIDENT_OK) {
        printk("%s: executable verification failed rv=%d format=%d.\n",
               __FUNCTION__,rv,fmt);
        return FALSE;
    }
    return TRUE;
}

// Returns 0 if no MemReq string was found.
int getExeMemReq(BYTE *buf, int len)
{
    static const char ids[] = "SQUIRREL VERIFY APPLICATION MEMORY CONFIGURATION=";
    int off,p,value,digit,have_digit;

    off=exe_find_string(buf,len,ids,0,len);
    if(off<0) return 0;
    p=off+strlen(ids); value=0; have_digit=FALSE;
    while(p<len) {
        digit=buf[p]-'0';
        if(digit<0 || digit>9) break;
        have_digit=TRUE;
        if(value>(0x7fffffff-digit)/10) return 0;
        value=value*10+digit; p++;
    }
    if(!have_digit) return 0;
    printk("%s: application memory configuration = %dK\n",__FUNCTION__,value);
    return value;
}
