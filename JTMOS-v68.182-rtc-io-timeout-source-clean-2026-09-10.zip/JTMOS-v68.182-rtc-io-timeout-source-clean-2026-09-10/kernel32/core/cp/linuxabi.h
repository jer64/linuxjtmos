#ifndef __JTMOS_LINUXABI_H__
#define __JTMOS_LINUXABI_H__

#include "basdef.h"
#include "systemcalls.h"
#include "filedescriptor.h"

#define JTMOS_WNOHANG 1

#define JTMOS_SIG_DFL 0
#define JTMOS_SIG_IGN 1
#define JTMOS_SIG_USER 2
#define JTMOS_SIGHUP 1
#define JTMOS_SIGINT 2
#define JTMOS_SIGABRT 6
#define JTMOS_SIGKILL 9
#define JTMOS_SIGTERM 15

#define JTMOS_POLLIN  0x0001
#define JTMOS_POLLOUT 0x0004
#define JTMOS_POLLERR 0x0008
#define JTMOS_POLLHUP 0x0010
#define JTMOS_POLLNVAL 0x0020

typedef struct {
    int fd;
    short events;
    short revents;
} JTMOS_POLLFD;

typedef struct {
    char sysname[65];
    char nodename[65];
    char release[65];
    char version[65];
    char machine[65];
} JTMOS_UTSNAME;

typedef struct {
    long uptime;
    unsigned long loads[3];
    unsigned long totalram;
    unsigned long freeram;
    unsigned long sharedram;
    unsigned long bufferram;
    unsigned long totalswap;
    unsigned long freeswap;
    unsigned short procs;
    unsigned short pad;
    unsigned long totalhigh;
    unsigned long freehigh;
    unsigned int mem_unit;
} JTMOS_SYSINFO;

#define JTMOS_FD_NORMAL      0
#define JTMOS_FD_PIPE_READ   0x4a5001
#define JTMOS_FD_PIPE_WRITE  0x4a5002
#define JTMOS_FD_PROC        0x4a5003
#define JTMOS_FD_DEV_NULL    0x4a5004
#define JTMOS_FD_DEV_ZERO    0x4a5005
#define JTMOS_FD_DEV_RANDOM  0x4a5006
#define JTMOS_VFS_NOT_HANDLED (-32760)

void LinuxProcessCreated(int pid, int parent_pid);
void LinuxProcessForked(int parent_pid, int child_pid);
void LinuxProcessExit(int pid, int exit_code, int term_signal);
void LinuxProcessDiscard(int pid);
int LinuxProcessPidReusable(int pid);
int LinuxGetPPid(int pid);
int LinuxWaitPid(int parent, int wanted, int *status, int options);
int LinuxSignalSend(int sender, int pid, int sig);
int LinuxSignalDisposition(int pid, int sig, int disposition);
int LinuxNice(int pid, int increment);
int LinuxGetPriority(int pid);
int LinuxSetPriority(int pid, int value);
int LinuxUname(JTMOS_UTSNAME *u);
int LinuxSysinfo(JTMOS_SYSINFO *i);

int LinuxVfsOpen(const char *path, int flags);
int LinuxVfsRead(int fd, void *buf, int count);
int LinuxVfsWrite(int fd, const void *buf, int count);
int LinuxVfsClose(int fd);
int LinuxVfsLseek(int fd, int offset, int whence);
int LinuxPipeCreate(int fds[2]);
int LinuxFdIsPipe(int fd);
int LinuxResolveStdioFd(int pid, int stdfd);
int LinuxGetStdioRoute(int pid, int stdfd);
int LinuxCloseStdioFd(int pid, int stdfd);
int LinuxDup2(int pid, int oldfd, int newfd);
int LinuxProcessExecSetup(int pid, int parent_pid, int stdin_fd, int stdout_fd, int stderr_fd);
int LinuxPoll(JTMOS_POLLFD *fds, unsigned int nfds, int timeout_ms);
void LinuxFdOwnerAdded(int fd, int pid);
void LinuxFdOwnerReleased(int fd, int pid);

int scall_getppid(SYSCALLPAR);
int scall_waitpid(SYSCALLPAR);
int scall_kill_posix(SYSCALLPAR);
int scall_sigdisp(SYSCALLPAR);
int scall_pipe(SYSCALLPAR);
int scall_dup2(SYSCALLPAR);
int scall_poll(SYSCALLPAR);
int scall_nice(SYSCALLPAR);
int scall_getpriority_posix(SYSCALLPAR);
int scall_setpriority_posix(SYSCALLPAR);
int scall_uname(SYSCALLPAR);
int scall_sysinfo(SYSCALLPAR);

#endif
