#ifndef __INCLUDED_SCHEDULER_H__
#define __INCLUDED_SCHEDULER_H__

#include "basdef.h"

/* V68.121: normal IRQ0/yield scheduling uses interrupt gates. Per-process
 * TSSes remain the context-transfer format, but the dedicated scheduler-TSS
 * hop is skipped. Define 0 to retain the historical task-gate scheduler. */
#ifndef JTMOS_INTERRUPT_GATE_SCHEDULER
#define JTMOS_INTERRUPT_GATE_SCHEDULER 1
#endif

/*
 * JTMOS scheduler CPU/load statistics.
 *
 * load_a/load_b/load_c are fixed-point load averages multiplied by 1000:
 *   A = 1 minute, B = 5 minutes, C = 15 minutes.
 * cpu_idle/cpu_busy are per-mille values (0..1000) from the last 1 s sample.
 */
typedef struct
{
    DWORD version;
    DWORD size;
    DWORD hz;
    DWORD total_threads;
    DWORD runnable_threads;
    DWORD idle_pid;
    DWORD cpu_idle_per_mille;
    DWORD cpu_busy_per_mille;
    DWORD load_a_x1000;
    DWORD load_b_x1000;
    DWORD load_c_x1000;
    DWORD sample_ticks;
    DWORD sample_idle_ticks;
    DWORD uptime_ms;
} JTMOS_CPU_STATS;

#define JTMOS_CPU_STATS_VERSION 1

void _idle_moment(void);
void MapApplicationMemory(void);
void LLSchedule(void);
void TaskPitHandler(void);
void SchedulerCpuTick(void);
int SchedulerGetCpuStats(JTMOS_CPU_STATS *out, DWORD out_size);

/* V67.8.54 responsive reward scheduler. */
void SchedulerThreadInit(int pid);
void SchedulerPriorityChanged(int pid, BYTE prio);
void SchedulerOnVoluntaryYield(int pid);
void SchedulerRewardIO(int pid, int work_units);
/* V68.154: syscall-aware recent-work accounting.  Called from scallActive()
 * while the INT 0x7F gate still owns the CPU, so the per-PID FIFO update is
 * atomic on the current single-CPU scheduler. */
void SchedulerAccountSyscall(int pid, int syscall_nr);

/* V68.155: short-lived activity hints.  These are event notifications, not
 * permanent priorities: keyboard/mouse/network reception only affects the
 * process for a bounded latency window and never bypasses its explicit
 * base-priority floor. */
#define SCHED_ACTIVITY_KEYBOARD 1
#define SCHED_ACTIVITY_MOUSE    2
#define SCHED_ACTIVITY_NETWORK  3
void SchedulerNoteActivity(int pid, int kind, int work_units);
int SchedulerSleepCurrentUsec(DWORD usec);
void SchedulerWaitPause(DWORD usec);
int SchedulerCanCooperate(void);
void SchedulerCooperate(void);
void SchedulerCooperateEvery(DWORD iteration,DWORD interval);
void SchedulerWakeThread(int pid);
int SchedulerTimerShouldPreempt(void);
int SchedulerPickNext(int current);
void SchedulerOnSwitch(int old_pid, int new_pid);
void SchedulerDump(void);
void SchedulerIdleWait(void);
#define SCHED_IDLE_HLT_BURST 512U
void SchedulerTimerInterruptDispatch(void);
void SchedulerYieldInterruptDispatch(void);
void scheduler_yield_ISR(void);

/* V68.160: hardware-TSS switch diagnostics/hardening.  The dump routine is
 * deliberately serial-only and allocation-free so it is safe while IRQ0 is
 * temporarily held off during storage-safe -> steady-state restoration. */
void SchedulerDebugDumpRunnable(const char *tag);
int SchedulerTaskContextSane(int pid);

#endif
