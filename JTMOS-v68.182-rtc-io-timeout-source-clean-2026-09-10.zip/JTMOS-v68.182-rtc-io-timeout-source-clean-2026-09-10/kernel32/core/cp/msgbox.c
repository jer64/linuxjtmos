//========================================================
// IPC: Inter Process Communication: Message Box Communication System
// (Process to Process Communication System, PPCS).
// (C) 2003-2005,2013-2014 by Jari Tuominen.
//========================================================
#include "kernel32.h"
#include "msgbox.h"
#include "scheduler.h"

//
#define X(x) (((x)&255) | ((x)&255<<8) | ((x)&255<<16) | ((x)&255<<24))

//
static DWORD unique_number=0;

/* GraOS input events are delivered through the generic mailbox ABI.  Keep a
 * tiny stable prefix decoder here instead of making the kernel depend on the
 * full userspace GraOS header.  GUICMD starts with: magic, wid, id. */
#define SCHED_GRAOS_GSID_KEYPRESSED      7
#define SCHED_GRAOS_GSID_BUTTON         14
#define SCHED_GRAOS_GSID_MOUSEBUTTON    20
#define SCHED_GRAOS_GSID_TEXT_CHANGED   35
#define SCHED_GRAOS_GSID_TEXT_ENTER     36
#define SCHED_GRAOS_GSID_DOUBLECLICK    47
static int msgbox_graos_activity_kind(const MSG *m)
{
    int id;
    if(!m || m->protocol!=MB_PROTOCOL_GRAOS || m->amount<12) return 0;
    memcpy(&id,m->buf+8,sizeof(id));
    switch(id) {
    case SCHED_GRAOS_GSID_KEYPRESSED:
    case SCHED_GRAOS_GSID_TEXT_CHANGED:
    case SCHED_GRAOS_GSID_TEXT_ENTER:
        return SCHED_ACTIVITY_KEYBOARD;
    case SCHED_GRAOS_GSID_BUTTON:
    case SCHED_GRAOS_GSID_MOUSEBUTTON:
    case SCHED_GRAOS_GSID_DOUBLECLICK:
        return SCHED_ACTIVITY_MOUSE;
    default:
        return 0;
    }
}

/*
 * Mailbox synchronization model
 * -----------------------------
 * JTMOS is currently single-CPU, but the PIT may preempt normal kernel code
 * at almost any instruction.  Volatile is not a lock: a mailbox slot must not
 * become visible as MSG_RESERVED until the complete packet has been copied.
 *
 * Keep the short publication/consume sections interrupt-atomic.  Packet CRC
 * calculation and user-buffer copies stay outside the critical section so IRQ
 * latency is bounded to one ~2 KiB memcpy plus a five-slot metadata scan.
 */
static DWORD msgbox_next_sequence(void)
{
	DWORD flags;
	DWORD value;

	flags = get_eflags();
	disable();
	value = unique_number++;
	set_eflags(flags);
	return value;
}

static int msgbox_pid_alive(int pid)
{
	return valid_pid(pid) && pid >= 0 && pid < N_MAX_THREADS && thread_states[pid] != 0;
}

/* IEEE CRC32 over the complete fixed-size packet.  The checksum slot itself
 * is treated as zero, so every header field and all payload bytes are covered
 * without changing the public MSG ABI. */
DWORD MessageChecksum(const MSG *msg)
{
	DWORD crc=0xFFFFFFFFUL ^ MSGBOX_CHECKSUM_SEED;
	DWORD i,j;
	const BYTE *p=(const BYTE *)msg;
	DWORD checksum_offset=(DWORD)&((MSG *)0)->magic2;

	if(msg==NULL)
		return 0;
	for(i=0; i<sizeof(MSG); ++i)
	{
		BYTE value=(i>=checksum_offset && i<checksum_offset+sizeof(DWORD)) ? 0 : p[i];
		crc^=value;
		for(j=0; j<8; ++j)
			crc=(crc>>1) ^ (0xEDB88320UL & (0UL-(crc&1UL)));
	}
	return crc ^ 0xFFFFFFFFUL;
}

//-------------------------------------------------------------------------------------
// Activate a thread's message box
//
int ActivateThreadMessageBox(int pid)
{
	MSGBOX *candidate;
	DWORD flags;

	/* Do not allocate a mailbox for a dead/recycled PID slot. */
	if(!msgbox_pid_alive(pid))
		return 1;

	/* Fast path and publication are protected from PIT preemption. */
	flags = get_eflags();
	disable();
	if(thread_msgbox[pid] != NULL)
	{
		set_eflags(flags);
		return 0;
	}
	set_eflags(flags);

	/* Allocation may be relatively expensive, so never do it with IRQs off. */
	candidate = createMessageBox();
	if(candidate == NULL)
		return 1;

	flags = get_eflags();
	disable();
	if(!msgbox_pid_alive(pid))
	{
		set_eflags(flags);
		kfree(candidate);
		return 1;
	}
	if(thread_msgbox[pid] == NULL)
	{
		thread_msgbox[pid] = candidate;
		candidate = NULL;
	}
	set_eflags(flags);

	/* Another creator may have won the race. */
	if(candidate != NULL)
		kfree(candidate);
	return 0;
}

void DestroyThreadMessageBox(int pid)
{
	MSGBOX *box;
	DWORD flags;

	if(pid < 0 || pid >= N_MAX_THREADS)
		return;

	/* Detach first.  sendMessage()/receiveMessage() use the same IRQ atomicity,
	 * so no running sender can retain this pointer across the detach. */
	flags = get_eflags();
	disable();
	box = thread_msgbox[pid];
	thread_msgbox[pid] = NULL;
	set_eflags(flags);

	if(box != NULL)
		kfree(box);
}

//-------------------------------------------------------------------------------------
//
int VerifyMessage(MSG *msg)
{
	if(msg==NULL || msg->magic1!=MSGBOX_MAGIC1)
		return 0;
	if(msg->isFree!=MSG_RESERVED)
		return 0;
	if(msg->amount<0 || msg->amount>N_MAX_BYTES_PER_MSG)
		return 0;
	if(msg->protocol!=MB_PROTOCOL_DC &&
	   msg->protocol!=MB_PROTOCOL_POSTMAN &&
	   msg->protocol!=MB_PROTOCOL_GRAOS)
		return 0;
	return msg->magic2==MessageChecksum(msg);
}

//-------------------------------------------------------------------------------------
// Return value:
// 0 = Message delivered
// 1 = Message couldn't have been delivered
//
int sendMessage(MSG *deliver_this, int pid)
{
	int i,i2;
	MSGBOX *mb;
	MSG *me;
	MSG packet;
	DWORD ad;
	DCPACKET *dc;
    int activity_kind=0;
	static char str[256];

	//
	printf("%s/%s/line %d: deliver_this=%x, pid=%d\n",
		__FILE__, __FUNCTION__, __LINE__, (DWORD)deliver_this, pid);
	if(!pid) {
		printf("%s/%s/line %d: pid is zero (%d), can't deliver\n",
			__FILE__, __FUNCTION__, __LINE__, pid);
		return 1;
	}

	//-----------------------------------------------------------
        // Check that the process really exists.
        if(!valid_pid(pid)) {
		printf("%s/%s/line %d: process (%d) does not exist, can't deliver\n",
			__FILE__, __FUNCTION__, __LINE__, pid);
		return 1;
	}

	// Check for NULL pointer
	if( illegal(deliver_this) )
	{
		//
		printf("%s/%s: deliver_this = ILLEGAL POINTER\n",
			__FILE__, __FUNCTION__);
		// Hey it's an illegal ptr!
		return 1;
	}

	/* Snapshot once before inspecting nested fields.  A Ring3 sender cannot
	 * change protocol/payload between validation and mailbox insertion. */
	memcpy(&packet,deliver_this,sizeof(packet));
	if(packet.amount<0 || packet.amount>N_MAX_BYTES_PER_MSG)
		return 14;

	//-----------------------------------------------------------
repeat:
	/* Mailbox creation is done outside the IRQ-off publication section. */
	if(thread_msgbox[pid] == NULL)
	{
		if(ActivateThreadMessageBox(pid))
			return 1;
	}

	//--------------------------------------------------------------------
	// Make sure all required pointers in the MSG structure are valid.
	//

	// Verify a DC packet.
	switch(packet.protocol)
	{
		//
		case MB_PROTOCOL_DC:
		if(packet.amount<(int)sizeof(DCPACKET))
			return 15;
		dc = (DCPACKET *)&packet.buf;
		ad = JTM_PTR_TO_DWORD(dc->rval); ad += GetCurrentThread();

		//
		if(illegal((const void *)ad))
		{
			dprintk("%s: rejecting illegal DC packet from PID%d.\n",
				__FUNCTION__,GetCurrentThread());
			return 11;
		}
		break;

		//
		case MB_PROTOCOL_POSTMAN:
		break;
		case MB_PROTOCOL_GRAOS:
		break;

		//
		default:
	/**	sprintf(str, "%s/%s: Packet with unknown protocol (%d).",
			__FILE__, __FUNCTION__,
			deliver_this->protocol); **/
		printk("\n");
		p32(packet.protocol); printk("\n");
		printk("%s/%s line %d: msgbox unknown protocol value in deliver_this->protocol\n",
			__FUNCTION__,__FILE__,__LINE__);
		return 10;
	}

    activity_kind=msgbox_graos_activity_kind(&packet);

	//-----------------------------------------------------------
	// Set "to be sent" -message as reserved.
	packet.isFree = MSG_RESERVED;

	// Define sender's and receiver's PID
	packet.sndPID = GetCurrentThread();
	packet.rcvPID = pid;

	// Set magic numbers.
	packet.magic1 = MSGBOX_MAGIC1;

	// Define unique number
	packet.un = msgbox_next_sequence();
	packet.magic2 = 0;
	packet.magic2 = MessageChecksum(&packet);

	//
	if(!VerifyMessage(&packet))
	{
		dprintk("%s: outgoing message validation failed.\n",__FUNCTION__);
		return 12;
	}

	//------------------------------------------------------------------------
	/* Publish one complete packet atomically with respect to PIT scheduling.
	 * Without this, two senders can both observe the same MSG_FREE slot and a
	 * receiver can see MSG_RESERVED after only the first words were copied. */
	{
		DWORD flags = get_eflags();
		disable();

		if(!msgbox_pid_alive(pid) || (mb = thread_msgbox[pid]) == NULL)
		{
			set_eflags(flags);
			return 1;
		}

		for(i=0,me=NULL; i<mb->n_q; i++)
		{
			me = &mb->q[i];
			if(me->isFree == MSG_FREE)
			{
				memcpy(me, &packet, sizeof(MSG));
				set_eflags(flags);
                if(activity_kind)
                    SchedulerNoteActivity(pid,activity_kind,1);
				return 0;
			}
		}
		set_eflags(flags);
	}

	return 1;
}

// A thread can receive own messages
// through this function.
//
// Return value:
// Non-zero	message was received successfully
// Zero		no new messages available
//
int receiveMessage(MSG *user_packet_buffer)
{
	DWORD age;
	DWORD flags;
	int i,ind;
	int pid;
	MSGBOX *mailbox;
	MSG *message;
	MSG packet;

	if(user_packet_buffer == NULL)
		return 0;

	pid = GetCurrentThread();
	if(!msgbox_pid_alive(pid))
		return 0;

repeat:
	if(thread_msgbox[pid] == NULL)
	{
		if(ActivateThreadMessageBox(pid))
			return 0;
	}

	/* Reserved packets are immutable.  Select + snapshot + free one slot in a
	 * single short IRQ-off transaction, then verify/copy outside it. */
	flags = get_eflags();
	disable();
	mailbox = thread_msgbox[pid];
	if(mailbox == NULL)
	{
		set_eflags(flags);
		goto repeat;
	}

	age = 0xFFFFFFFFUL;
	ind = -1;
	for(i=0; i<mailbox->n_q; i++)
	{
		message = &mailbox->q[i];
		if(message->isFree == MSG_RESERVED && message->un <= age)
		{
			age = message->un;
			ind = i;
		}
	}

	if(ind < 0)
	{
		set_eflags(flags);
		return 0;
	}

	memcpy(&packet, &mailbox->q[ind], sizeof(packet));
	mailbox->q[ind].isFree = MSG_FREE;
	set_eflags(flags);

	if(!VerifyMessage(&packet) || packet.rcvPID != pid)
	{
		dprintk("%s: dropped corrupted packet #%d (magic=%x checksum=%x expected=%x).\n",
			__FUNCTION__, ind, packet.magic1, packet.magic2, MessageChecksum(&packet));
		return 0;
	}

	memcpy(user_packet_buffer, &packet, sizeof(packet));
	return 1;
}

// Initialize a message box
void initMessageBox(MSGBOX *queue)
{
	int i;

	//
	memset(queue, 0x66, sizeof(MSGBOX));

	//
	queue->n_q = N_MAX_QUEUED_MSGS;

	//
	for(i=0; i<queue->n_q; i++)
		queue->q[i].isFree = MSG_FREE;
}

// Create a new message box
MSGBOX *createMessageBox(void)
{
	MSGBOX *box;

	/* Mailboxes are kernel objects, not sender-owned process heap objects.
	 * A sender may create a receiver's box; tying it to GetCurrentThread()
	 * would let sender teardown free the receiver's live mailbox. */
	box = _kmalloc(sizeof(MSGBOX), -1, "msgbox");
	if(box==NULL)
		return NULL;

	// Initialize message box
	initMessageBox(box);

	// Return PTR to the new message box
	return box;
}

//
