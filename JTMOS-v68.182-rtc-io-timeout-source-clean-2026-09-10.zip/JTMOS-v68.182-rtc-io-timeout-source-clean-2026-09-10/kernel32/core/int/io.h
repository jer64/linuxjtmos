/*** IA-32 low level I/O functions (JTMOS V68.148) ***/
#ifndef __INCLUDED_IO_H__
#define __INCLUDED_IO_H__

#include "delay.h"
#include "basdef.h"

#ifdef __CPLUSPLUS__
extern "C" {
#endif

/*
 * Intel IA-32 port I/O rules:
 *  - IN/OUT operate on the separate 16-bit I/O-port address space.
 *  - access width is explicit: AL/AX/EAX for 8/16/32-bit transactions.
 *  - protected-mode permission is controlled by CPL/IOPL and the TSS I/O map.
 *
 * The compiler does not understand device side effects.  Every primitive is
 * therefore volatile and carries a "memory" clobber so ordinary memory/DMA
 * accesses cannot be moved across the programmed I/O operation by GCC.
 */
static __inline__ void io_compiler_barrier(void)
{
    __asm__ __volatile__("" : : : "memory");
}

/* Full memory-ordering point usable on the i486 target.  MFENCE is not an
 * i486 instruction; a locked memory RMW is the portable IA-32 barrier here.
 * Use this for coherent DMA descriptor publication/completion boundaries,
 * not as a generic delay primitive. */
static __inline__ void io_memory_barrier(void)
{
    __asm__ __volatile__("lock; addl $0,0(%%esp)" : : : "memory","cc");
}

static __inline__ void io_write8(WORD port,BYTE value)
{
    __asm__ __volatile__("outb %b0,%w1" : : "a"(value),"Nd"(port) : "memory");
}
static __inline__ BYTE io_read8(WORD port)
{
    BYTE value;
    __asm__ __volatile__("inb %w1,%b0" : "=a"(value) : "Nd"(port) : "memory");
    return value;
}
static __inline__ void io_write16(WORD port,WORD value)
{
    __asm__ __volatile__("outw %w0,%w1" : : "a"(value),"Nd"(port) : "memory");
}
static __inline__ WORD io_read16(WORD port)
{
    WORD value;
    __asm__ __volatile__("inw %w1,%w0" : "=a"(value) : "Nd"(port) : "memory");
    return value;
}
static __inline__ void io_write32(WORD port,DWORD value)
{
    __asm__ __volatile__("outl %0,%w1" : : "a"(value),"Nd"(port) : "memory");
}
static __inline__ DWORD io_read32(WORD port)
{
    DWORD value;
    __asm__ __volatile__("inl %w1,%0" : "=a"(value) : "Nd"(port) : "memory");
    return value;
}

/* Historical _p compatibility.  This is deliberately a CPU execution pause,
 * not an architectural I/O-ordering primitive: Intel already orders IN/OUT
 * transactions.  Device protocols that require a real interval (for example
 * ATA's 400 ns select delay) must use their documented status-read sequence. */
static __inline__ void io_legacy_pause(void)
{
    __asm__ __volatile__("jmp 1f\n1:\tjmp 2f\n2:" : : : "memory");
}

#define outb(value,port)       io_write8((WORD)(port),(BYTE)(value))
#define inb(port)              io_read8((WORD)(port))
#define outb_p(value,port)     do { io_write8((WORD)(port),(BYTE)(value)); io_legacy_pause(); } while(0)
#define inb_p(port)            ({ BYTE __v=io_read8((WORD)(port)); io_legacy_pause(); __v; })
#define outw_p(value,port)     do { io_write16((WORD)(port),(WORD)(value)); io_legacy_pause(); } while(0)
#define inw_p(port)            ({ WORD __v=io_read16((WORD)(port)); io_legacy_pause(); __v; })
#define outd_p(value,port)     do { io_write32((WORD)(port),(DWORD)(value)); io_legacy_pause(); } while(0)
#define ind_p(port)            ({ DWORD __v=io_read32((WORD)(port)); io_legacy_pause(); __v; })

extern void outportb(WORD port,BYTE value);
extern BYTE inportb(WORD port);
extern void outportw(WORD port,WORD value);
extern WORD inportw(WORD port);
extern void outportd(WORD port,DWORD value);
extern DWORD inportd(WORD port);

#ifdef __CPLUSPLUS__
}
#endif

#endif
