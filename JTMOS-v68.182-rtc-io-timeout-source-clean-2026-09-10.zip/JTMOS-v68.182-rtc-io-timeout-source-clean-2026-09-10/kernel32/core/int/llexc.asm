;------------------------------------------------------------------
; Exception Handling Low Level ASM Code.
; (C) 2003-2005 Jari Tuominen.
; ASMllexception_0 => llexception_0
; See coprocessor.asm for coprocessor not found handler.
;------------------------------------------------------------------
%include "core/int/exc.mac"  ; SAFE
extern llexception_0
extern llexception_1
extern llexception_2
extern llexception_3
extern llexception_4
extern llexception_5
extern llexception_6
extern llexception_7
extern llexception_8
extern llexception_9
extern llexception_10
extern llexception_11
extern llexception_12
extern llexception_13
extern llexception_14
extern llexception_15
extern llexception_16
extern llexception_17
extern llexception_18
extern llexception_19
extern llexception_20
extern llexception_21
extern llexception_22
extern llexception_23
extern llexception_24
extern llexception_25
extern llexception_26
extern llexception_27
extern llexception_28
extern llexception_29
extern llexception_30
extern llexception_31
extern early_pf_valid
extern early_pf_cr2
extern early_pf_error
extern early_pf_eip
extern early_pf_cs
extern early_pf_eflags
extern early_pf_esp
extern early_pf_ebp
;
global ASMllexception_0
global ASMllexception_1
global ASMllexception_2
global ASMllexception_3
global ASMllexception_4
global ASMllexception_5
global ASMllexception_6
global ASMllexception_7
global ASMllexception_8
global ASMllexception_9
global ASMllexception_10
global ASMllexception_11
global ASMllexception_12
global ASMllexception_13
global ASMllexception_14
global ASMllexception_15
global ASMllexception_16
global ASMllexception_17
global ASMllexception_18
global ASMllexception_19
global ASMllexception_20
global ASMllexception_21
global ASMllexception_22
global ASMllexception_23
global ASMllexception_24
global ASMllexception_25
global ASMllexception_26
global ASMllexception_27
global ASMllexception_28
global ASMllexception_29
global ASMllexception_30
global ASMllexception_31
global llHaltNow

ASMllexception_0:
			SAFE llexception_0

ASMllexception_1:
			SAFE llexception_1

ASMllexception_2:
			SAFE llexception_2

ASMllexception_3:
			SAFE llexception_3

ASMllexception_4:
			SAFE llexception_4

ASMllexception_5:
			SAFE llexception_5

ASMllexception_6:
			SAFE llexception_6

ASMllexception_7:
			SAFE llexception_7

ASMllexception_8:
			SAFE llexception_8

ASMllexception_9:
			SAFE llexception_9

ASMllexception_10:
			SAFE llexception_10

ASMllexception_11:
			SAFE llexception_11

ASMllexception_12:
			SAFE llexception_12

ASMllexception_13:
			SAFE llexception_13

ASMllexception_14:
            ; #PF pushes ERR,EIP,CS,EFLAGS before entering this stub.  Capture
            ; that frame before the generic SAFE macro replaces ESP.
            cli
            cld
            mov esi,esp
            mov edi,ebp
            mov eax,cr2
            mov bx,0x10
            mov ds,bx
            mov es,bx
            mov fs,bx
            mov gs,bx
            mov ss,bx
            mov dword [early_pf_valid],0
            mov [early_pf_esp],esi
            mov [early_pf_ebp],edi
            mov [early_pf_cr2],eax
            mov eax,[esi+0]
            mov [early_pf_error],eax
            mov eax,[esi+4]
            mov [early_pf_eip],eax
            mov eax,[esi+8]
            mov [early_pf_cs],eax
            mov eax,[esi+12]
            mov [early_pf_eflags],eax
            mov dword [early_pf_valid],0x50463134
            mov esp,JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP
            jmp llexception_14

ASMllexception_15:
			SAFE llexception_15

ASMllexception_16:
			SAFE llexception_16

ASMllexception_17:
			SAFE llexception_17

ASMllexception_18:
			SAFE llexception_18

ASMllexception_19:
			SAFE llexception_19

ASMllexception_20:
			SAFE llexception_20

ASMllexception_21:
			SAFE llexception_21

ASMllexception_22:
			SAFE llexception_22

ASMllexception_23:
			SAFE llexception_23

ASMllexception_24:
			SAFE llexception_24

ASMllexception_25:
			SAFE llexception_25

ASMllexception_26:
			SAFE llexception_26

ASMllexception_27:
			SAFE llexception_27

ASMllexception_28:
			SAFE llexception_28

ASMllexception_29:
			SAFE llexception_29

ASMllexception_30:
			SAFE llexception_30

ASMllexception_31:
			SAFE llexception_31

llHaltNow:
			cli
			cld
.loop:			hlt
			jmp .loop

