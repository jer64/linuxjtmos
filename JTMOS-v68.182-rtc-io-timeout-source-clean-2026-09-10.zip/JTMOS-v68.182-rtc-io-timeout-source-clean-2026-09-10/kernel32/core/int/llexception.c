/*
 * llexception.c & exc.asm - low level backup-exception handlres.
 */

//
#include "kernel32.h"
#include "int.h"
#include "exception.h"
#include "llexception.h"
#ifdef GRAOS
#include "graos.h"
#endif
#include "vesa.h"

//
EXCEPTION exception;

#define EARLY_PF_MAGIC       0x50463134UL
#define EARLY_STACK_LOW      JTMOS_KERNEL_EARLY_STACK_BOTTOM
#define EARLY_STACK_HIGH     JTMOS_KERNEL_EARLY_STACK_TOP
#define EARLY_STACK_WORDS    16
#define EARLY_FRAME_DEPTH    12

/* Filled by the vector-14 assembly entry before it switches to the emergency
 * stack.  Keeping the capture in assembly is essential: a C prologue has
 * already changed ESP and cannot reconstruct the CPU-created fault frame. */
volatile DWORD early_pf_valid;
volatile DWORD early_pf_cr2;
volatile DWORD early_pf_error;
volatile DWORD early_pf_eip;
volatile DWORD early_pf_cs;
volatile DWORD early_pf_eflags;
volatile DWORD early_pf_esp;
volatile DWORD early_pf_ebp;

static DWORD EarlyReadCR3(void)
{
    DWORD value;
    asm volatile("mov %%cr3,%0" : "=r" (value));
    return value;
}

static int EarlyStackAddressOK(DWORD address, DWORD bytes)
{
    if(address < EARLY_STACK_LOW || address >= EARLY_STACK_HIGH)
        return 0;
    if(bytes > EARLY_STACK_HIGH-address)
        return 0;
    return 1;
}

static void EarlyWriteField(const char *name, DWORD value)
{
    DebugSerialEmergencyWrite(name);
    DebugSerialEmergencyWriteHex32(value);
}

static void EarlyDumpPageFault(void)
{
    volatile DWORD *stack;
    volatile DWORD *frame;
    DWORD address,next;
    int i;

    if(early_pf_valid != EARLY_PF_MAGIC)
    {
        DebugSerialEmergencyWrite("Fault frame unavailable (old ASM exception stub).\n");
        return;
    }

    EarlyWriteField("CS=", early_pf_cs);
    EarlyWriteField(" EIP=", early_pf_eip);
    EarlyWriteField(" EFLAGS=", early_pf_eflags);
    DebugSerialEmergencyWrite("\n");
    EarlyWriteField("CR0=", GETCR0());
    EarlyWriteField(" CR2=", early_pf_cr2);
    EarlyWriteField(" CR3=", EarlyReadCR3());
    DebugSerialEmergencyWrite("\n");
    EarlyWriteField("PF_ERR=", early_pf_error);
    EarlyWriteField(" OLD_ESP=", early_pf_esp);
    EarlyWriteField(" OLD_EBP=", early_pf_ebp);
    DebugSerialEmergencyWrite("\nPF decode: ");
    DebugSerialEmergencyWrite((early_pf_error & 1) ? "protection " : "not-present ");
    DebugSerialEmergencyWrite((early_pf_error & 2) ? "write " : "read ");
    DebugSerialEmergencyWrite((early_pf_error & 4) ? "user " : "supervisor ");
    if(early_pf_error & 8) DebugSerialEmergencyWrite("reserved-bit ");
    if(early_pf_error & 16) DebugSerialEmergencyWrite("instruction-fetch ");
    DebugSerialEmergencyWrite("\n");

    /* The interrupted kernel stack is in the permanently identity-mapped low
     * stack reservation. Never follow arbitrary pointers while handling a
     * fault; an exception inside the reporter would otherwise triple-fault. */
    address=early_pf_esp+16; /* skip ERR,EIP,CS,EFLAGS */
    DebugSerialEmergencyWrite("Raw interrupted stack:");
    if(!EarlyStackAddressOK(address, EARLY_STACK_WORDS*sizeof(DWORD)))
        DebugSerialEmergencyWrite(" unavailable (outside safe low stack)\n");
    else
    {
        stack=(volatile DWORD *)address;
        for(i=0;i<EARLY_STACK_WORDS;i++)
        {
            if((i&3)==0) DebugSerialEmergencyWrite("\n  ");
            DebugSerialEmergencyWriteHex32(stack[i]);
            DebugSerialEmergencyWrite(" ");
        }
        DebugSerialEmergencyWrite("\n");
    }

    DebugSerialEmergencyWrite("EBP stack trace (return EIPs):\n");
    address=early_pf_ebp;
    for(i=0;i<EARLY_FRAME_DEPTH;i++)
    {
        if((address & 3) || !EarlyStackAddressOK(address, 2*sizeof(DWORD)))
            break;
        frame=(volatile DWORD *)address;
        next=frame[0];
        DebugSerialEmergencyWrite("  #"); DebugSerialEmergencyWriteHex32((DWORD)i);
        EarlyWriteField(" EIP=", frame[1]);
        EarlyWriteField(" EBP=", address);
        DebugSerialEmergencyWrite("\n");
        if(next<=address)
            break;
        address=next;
    }
    if(i==0)
        DebugSerialEmergencyWrite("  unavailable (frame pointers omitted or invalid)\n");
}

//
void SafeExcReport(const char *msg)
{
    volatile WORD *vga=(volatile WORD*)0xB8000;
    const char *p;
    int i;

    disable();
    DebugSerialEmergencyWrite("\n*** JTMOS EARLY CPU EXCEPTION ***\n");
    DebugSerialEmergencyWrite(msg ? msg : "(unknown exception)");
    DebugSerialEmergencyWrite("\nHANDLER_ESP="); DebugSerialEmergencyWriteHex32(GETESP());
    DebugSerialEmergencyWrite("\n");
    if(exception.code==14)
        EarlyDumpPageFault();
    DebugSerialEmergencyWrite("\nCPU halted; interrupts remain disabled.\n");

    /* Before the normal console exists, write only a tiny diagnostic directly
     * to VGA text memory.  Do not switch modes, allocate, lock or touch DAC
     * palette registers while handling an exception. */
    if(!vesa_enabled)
    {
        for(i=0;i<160;i++) vga[i]=(WORD)(0x0F00|' ');
        p="EARLY CPU EXCEPTION: ";
        for(i=0;p[i] && i<79;i++) vga[i]=(WORD)(0x4F00|(BYTE)p[i]);
        if(msg)
            for(i=0;msg[i] && i<79;i++) vga[80+i]=(WORD)(0x0F00|(BYTE)msg[i]);
    }
    HaltNow();
}

//
void llexception_0(void)
{
	exception.code=0;
	
	SafeExcReport("(00) divide by zero");
}

//
void llexception_1(void)
{
	exception.code=1;
	SafeExcReport("(01) single step");
}

//
void llexception_2(void)
{
	exception.code=2;
	SafeExcReport("(02) non-maskable (NMI)");
}

//
void llexception_3(void)
{
	exception.code=3;
	SafeExcReport("(03) breakpoint");
}

//
void llexception_4(void)
{
	exception.code=4;
	SafeExcReport("(04) overflow trap");
}

//
void llexception_5(void)
{
	exception.code=5;
	SafeExcReport("(05) BOUND range exceeded");
}

//
void llexception_6(void)
{
	exception.code=6;
	SafeExcReport("(06) invalid opcode");
}

// (obsolete, handled 100% in the exc.asm)
void llexception_7(void)
{
	exception.code=7;
	SafeExcReport("(07) coprocessor not available");
}

//
void llexception_8(void)
{
	exception.code=8;
	SafeExcReport("(08) double fault exception");
}

//
void llexception_9(void)
{
	exception.code=9;
	SafeExcReport("(09) coprocessor segment overrun");
}

//
void llexception_10(void)
{
	exception.code=10;
	SafeExcReport("(10) invalid task state segment");
}

//
void llexception_11(void)
{
	exception.code=11;
	SafeExcReport("(11) segment not present");
}

//
void llexception_12(void)
{
	exception.code=12;
	SafeExcReport("(12) stack exception");
}

//
void llexception_13(void)
{
	exception.code=13;
	SafeExcReport("(13) general protection fault");
}

//
void llexception_14(void)
{
	exception.code=14;
	SafeExcReport("(14) page fault");
}

//
void llexception_15(void)
{
	exception.code=15;
	SafeExcReport("(15) reserved/unknown");
}

// Coprocessor error.
void llexception_16(void)
{
	exception.code=16;
	SafeExcReport("(16) coprocessor error");
}

void llexception_17(void)
{
	exception.code=17;
	SafeExcReport("(17) alignment check");
}

void llexception_18(void)
{
	exception.code=18;
	SafeExcReport("(18) machine check");
}

void llexception_19(void)
{
	exception.code=19;
	SafeExcReport("(19) SIMD floating-point exception");
}

void llexception_20(void)
{
	exception.code=20;
	SafeExcReport("(20) virtualization exception");
}

void llexception_21(void)
{
	exception.code=21;
	SafeExcReport("(21) control protection exception");
}

void llexception_22(void)
{
	exception.code=22;
	SafeExcReport("(22) reserved exception");
}

void llexception_23(void)
{
	exception.code=23;
	SafeExcReport("(23) reserved exception");
}

void llexception_24(void)
{
	exception.code=24;
	SafeExcReport("(24) reserved exception");
}

void llexception_25(void)
{
	exception.code=25;
	SafeExcReport("(25) reserved exception");
}

void llexception_26(void)
{
	exception.code=26;
	SafeExcReport("(26) reserved exception");
}

void llexception_27(void)
{
	exception.code=27;
	SafeExcReport("(27) reserved exception");
}

void llexception_28(void)
{
	exception.code=28;
	SafeExcReport("(28) hypervisor injection exception");
}

void llexception_29(void)
{
	exception.code=29;
	SafeExcReport("(29) VMM communication exception");
}

void llexception_30(void)
{
	exception.code=30;
	SafeExcReport("(30) security exception");
}

void llexception_31(void)
{
	exception.code=31;
	SafeExcReport("(31) reserved exception");
}

//
void setup_llexception_handlers(void)
{
	//
	setint( 0,  ASMllexception_0,  SEG_CODE32, 0x8E00 );
	setint( 1,  ASMllexception_1,  SEG_CODE32, 0x8E00 );
	setint( 2,  ASMllexception_2,  SEG_CODE32, 0x8E00 );
	setint( 3,  ASMllexception_3,  SEG_CODE32, 0x8E00 );
	setint( 4,  ASMllexception_4,  SEG_CODE32, 0x8E00 );
	setint( 5,  ASMllexception_5,  SEG_CODE32, 0x8E00 );
	setint( 6,  ASMllexception_6,  SEG_CODE32, 0x8E00 );
	setint( 7,  ASMllexception_7,  SEG_CODE32, 0x8E00 );
	setint( 8,  ASMllexception_8,  SEG_CODE32, 0x8E00 );
	setint( 9,  ASMllexception_9,  SEG_CODE32, 0x8E00 );
	setint( 10, ASMllexception_10, SEG_CODE32, 0x8E00 );
	setint( 11, ASMllexception_11, SEG_CODE32, 0x8E00 );
	setint( 12, ASMllexception_12, SEG_CODE32, 0x8E00 );

	// GPF
	setint( 13, ASMllexception_13, SEG_CODE32, 0x8E00 );

	//
	setint( 14, ASMllexception_14, SEG_CODE32, 0x8E00 );
	setint( 15, ASMllexception_15, SEG_CODE32, 0x8E00 );
	setint( 16, ASMllexception_16, SEG_CODE32, 0x8E00 );
	setint( 17, ASMllexception_17, SEG_CODE32, 0x8E00 );
	setint( 18, ASMllexception_18, SEG_CODE32, 0x8E00 );
	setint( 19, ASMllexception_19, SEG_CODE32, 0x8E00 );
	setint( 20, ASMllexception_20, SEG_CODE32, 0x8E00 );
	setint( 21, ASMllexception_21, SEG_CODE32, 0x8E00 );
	setint( 22, ASMllexception_22, SEG_CODE32, 0x8E00 );
	setint( 23, ASMllexception_23, SEG_CODE32, 0x8E00 );
	setint( 24, ASMllexception_24, SEG_CODE32, 0x8E00 );
	setint( 25, ASMllexception_25, SEG_CODE32, 0x8E00 );
	setint( 26, ASMllexception_26, SEG_CODE32, 0x8E00 );
	setint( 27, ASMllexception_27, SEG_CODE32, 0x8E00 );
	setint( 28, ASMllexception_28, SEG_CODE32, 0x8E00 );
	setint( 29, ASMllexception_29, SEG_CODE32, 0x8E00 );
	setint( 30, ASMllexception_30, SEG_CODE32, 0x8E00 );
	setint( 31, ASMllexception_31, SEG_CODE32, 0x8E00 );
}

//
