;=====================================================================================
; int 0x7F
; JTMOS SYSTEM CALL HANDLER (for incoming system calls).
; (C) 2001-2005 by Jari Tuominen(jari.tuominen@kanetti.fi).
;
; 30.9.2003: Added system call tracing option.
;=====================================================================================
extern nr_scall_func
extern scall_functions
extern scall_irq_policy
extern relax_thread
extern scallDeactive
extern scallActive
extern GetCurrentThreadBase
extern thread_base
extern nr_curthread
global scall_dummy
global scall_handler
%include "core/int/segsave.mac"
%include "core/int/corner.mac"


			dd 0,0,0,0,0,0,0,0,0,0,0,0
			dd 0,0,0,0,0,0,0,0,0,0,0,0
			dd 0,0,0,0,0,0,0,0,0,0,0,0
			dd 0,0,0,0,0,0,0,0,0,0,0,0
junkstack2:
			dd 0,0,0,0,0,0,0,0,0,0,0,0



; All neccessary registers will be saved & restored.
;
scall_handler:
		; ----------------------------------------
		; ENTER THE SYSTEM CALL HANDLER:
		cld
		; V68.166: remember whether the caller had IF set before INT 0x7F.
		; An interrupt gate clears live IF before the first instruction.  Save
		; the interrupted EFLAGS now, before the normal register frame is built.
		; SS is the flat ring-0 stack/data selector on syscall entry, including
		; a CPL3 -> CPL0 transition, so this does not depend on the caller's DS.
		push eax
		mov eax,dword [ss:esp+12] ; saved EIP, CS, EFLAGS are above pushed EAX
		mov dword [ss:scall_entry_eflags],eax
		pop eax
		push eax
		push ebx
		push ecx
		push edx
		push esi
		push edi
		push ebp

		;
		S_SEGREGS
		SaneSelectors

		; ------------------------------------------
		; Store parameters
		mov dword [ds:scall_eax],eax
		mov dword [ds:scall_ebx],ebx
		mov dword [ds:scall_ecx],ecx
		mov dword [ds:scall_edx],edx
		mov dword [ds:scall_esi],esi
		mov dword [ds:scall_edi],edi
		mov dword [ds:scall_ebp],ebp
		;

		; Mark this syscall active before dispatch.  The old handler only
		; decremented the counter on return, causing it to underflow.
		push ebp
		push edi
		push esi
		push edx
		push ecx
		push ebx
		push eax
		call scallActive
		add esp,7*4

		;-------------------------------------------
		; CHANGE STACK ...
		;-------------------------------------------
		

		;-------------------------------------------
		; Let's make the call!
		;
		; Validate the syscall number before indexing the dispatch table.
		mov eax,dword [ds:scall_eax]
		cmp eax,dword [ds:nr_scall_func]
		jae scall_handler_invalid

		; Get the call address.  A NULL slot is an invalid/unimplemented call.
		mov edi,eax
		shl edi,2 ; x4
		add edi,scall_functions
		mov eax,dword [ds:edi]
		test eax,eax
		jz scall_handler_invalid
		mov dword [ds:scall_tmp1],eax

		;
		mov eax,dword [ds:scall_eax]
                mov ebx,dword [ds:scall_ebx]
                mov ecx,dword [ds:scall_ecx]
                mov edx,dword [ds:scall_edx]
                mov esi,dword [ds:scall_esi]
                mov edi,dword [ds:scall_edi]
                mov ebp,dword [ds:scall_ebp]
		push ebp
		push edi
		push esi
		push edx
		push ecx
		push ebx
		push eax
		;
		mov edx,dword [ds:scall_tmp1]
		mov ebp,esp

		; V68.166 syscall interrupt policy.  INT 0x7F is an interrupt gate,
		; so IF is clear on entry.  Do not STI until the function address and
		; all seven C arguments are already private to this task (EDX + stack):
		; the legacy scall_eax/... scratch above is global and may be overwritten
		; by another task after preemption.  STI's one-instruction shadow makes
		; the following CALL execute before an IRQ can be accepted.
		mov eax,dword [ds:scall_eax]
		cmp byte [ds:scall_irq_policy+eax],0
		je .irq_policy_ready
		; Never create interrupts that the caller deliberately had disabled.
		; Normal ring-3 applications enter with IF=1 and therefore get the
		; audited IRQ-enabled service path.  A kernel/service caller that used
		; INT 0x7F while IF=0 remains atomic unless the service itself performs
		; an explicit, locally-balanced enable/restore operation.
		test dword [ds:scall_entry_eflags],0x200
		jz .irq_policy_ready
		sti
.irq_policy_ready:
		; CALL TO THE SYSTEM CALL:
		call edx
		; Keep the common handler epilogue non-preemptible while segment
		; registers and the saved user frame are being restored.  IRET restores
		; the caller's original IF from its interrupt frame.
		cli
		add esp,7*4
		;mov dword [gs:scall_retval1],eax
		;
		jmp scall_handler_l1

scall_handler_invalid:
		; Stable error return for out-of-range / empty syscall slots.
		mov eax,-1

scall_handler_l1:
		
		;
		pushad
		call scallDeactive
		popad

		;-------------------------------------------

		;
		R_SEGREGS

                ; Pull back all registers except EAX...
		; (emulate popd)
		pop ebp
		pop edi
		pop esi
		pop edx
		pop ecx
		pop ebx
		pop ebx
		iret
;   Push(EAX);
;   Push(ECX);
;   Push(EDX);
;   Push(EBX);
;   Push(Temp);
;   Push(EBP);
;   Push(ESI);
;   Push(EDI);
;-----------------------------------------------------------------
tbase:
		;
		mov esi,thread_base
		mov edi,DWORD [DS:nr_curthread]
		shl edi,2
		add esi,edi
		mov eax,DWORD [DS:ESI]
		ret
;-----------------------------------------------------------------
scall_retval1:	dd 0
scall_entry_eflags dd 0
scall_tmp1	dd 0,0,0,0
;-----------------------------------------------------------------
; TEMPORARY VARIABLES
_scall_eax	dd 0
_scall_ebx	dd 0
_scall_ecx	dd 0
_scall_edx	dd 0
_scall_esi	dd 0
_scall_edi	dd 0
_scall_ebp	dd 0
;-----------------------------------------------------------------
scall_eax       dd 0
scall_ebx       dd 0
scall_ecx       dd 0
scall_edx       dd 0
scall_esi       dd 0
scall_edi       dd 0
scall_ebp       dd 0
;-----------------------------------------------------------------
; dummy code
scall_dummy:
		mov eax,-1
		ret
		; dummy data
		db 0,0,0,0
;-----------------------------------------------------------------
