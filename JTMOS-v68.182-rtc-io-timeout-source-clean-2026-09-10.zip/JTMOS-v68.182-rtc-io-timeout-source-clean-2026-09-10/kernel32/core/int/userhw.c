/*
 * userhw.c - JTMOS V65 userspace IRQ / ISA DMA broker
 *
 * The old SYS_setint/SYS_enableirq ABI predates protected application
 * drivers.  V65 adds a deliberately narrower interface: an application may
 * subscribe to a free hardware IRQ but its code is never entered from the
 * interrupt frame. The kernel ISR only records an event and acknowledges the
 * PIC; jtmos_irq_wait() consumes the event later in syscall/thread context.
 *
 * ISA DMA buffers are kernel-owned physical allocations below 16 MiB. They
 * are mapped into the requesting 32-bit ELF process, cannot cross a 64 KiB
 * DMA boundary, and are released automatically with the process.
 */
#include "kernel32.h"
#include "scheduler.h"
#include "userhw.h"
#include "dma.h"
#include "mm.h"
#include "paging.h"
#include "sys/mman.h"

#define USERHW_EPERM   (-1)
#define USERHW_ENOMEM  (-12)
#define USERHW_EBUSY   (-16)
#define USERHW_EINVAL  (-22)
#define USERHW_ENOSPC  (-28)
#define USERHW_ENOSYS  (-38)

#define USERHW_DMA_PHYS_LIMIT 0x01000000UL
#define USERHW_DMA_CHANNELS   4       /* 8237 8-bit controller: channels 0..3 */
#define USERHW_DMA_FROM_DEVICE 0
#define USERHW_DMA_TO_DEVICE   1

typedef struct {
    int owner;
    DWORD handle;
    volatile DWORD pending;
    volatile DWORD total;
    int irq;
    int active;
} USERIRQ_SLOT;

typedef struct {
    int owner;
    DWORD handle;
    DWORD physical;
    DWORD kernel_address;
    DWORD user_address;
    DWORD size;
    DWORD pages;
    int active;
} USERDMA_SLOT;

static USERIRQ_SLOT irq_slots[16];
static USERDMA_SLOT dma_slots[JTMOS_DMA_MAX_SLOTS];
static DWORD next_irq_handle = 0x65010000UL;
static DWORD next_dma_handle = 0x65d00000UL;
static int dma_channel_slot[USERHW_DMA_CHANNELS] = { -1, -1, -1, -1 };

extern void userirq_stub0(void); extern void userirq_stub1(void);
extern void userirq_stub2(void); extern void userirq_stub3(void);
extern void userirq_stub4(void); extern void userirq_stub5(void);
extern void userirq_stub6(void); extern void userirq_stub7(void);
extern void userirq_stub8(void); extern void userirq_stub9(void);
extern void userirq_stub10(void); extern void userirq_stub11(void);
extern void userirq_stub12(void); extern void userirq_stub13(void);
extern void userirq_stub14(void); extern void userirq_stub15(void);

static void *irq_stubs[16] = {
    userirq_stub0,userirq_stub1,userirq_stub2,userirq_stub3,
    userirq_stub4,userirq_stub5,userirq_stub6,userirq_stub7,
    userirq_stub8,userirq_stub9,userirq_stub10,userirq_stub11,
    userirq_stub12,userirq_stub13,userirq_stub14,userirq_stub15
};

static int userhw_irq_vector(int irq)
{
    if(irq < 0 || irq > 15)
        return -1;
    if(irq < 8)
        return M_VEC + irq;
    return S_VEC + (irq - 8);
}

static int userhw_find_irq_handle(int owner, DWORD handle)
{
    int i;
    for(i=0; i<16; ++i)
        if(irq_slots[i].active && irq_slots[i].owner == owner &&
           irq_slots[i].handle == handle)
            return i;
    return -1;
}

int userhw_irq_subscribe(int owner, int irq, DWORD flags)
{
    DWORD eflags;
    int vector;
    void *old_handler;

    (void)flags;
    if(owner <= 0 || irq < 0 || irq > 15 || irq == 0 || irq == 2)
        return USERHW_EINVAL;

    vector = userhw_irq_vector(irq);
    eflags = get_eflags();
    disable();

    if(irq_slots[irq].active)
    {
        set_eflags(eflags);
        return USERHW_EBUSY;
    }

    /* Do not steal an IRQ from an in-kernel driver. V65 accepts only a line
     * which still points to the default no-op handler installed by IDT init. */
    old_handler = getint(vector);
    if(old_handler != (void *)nullinterrupt)
    {
        set_eflags(eflags);
        return USERHW_EBUSY;
    }

    irq_slots[irq].owner = owner;
    irq_slots[irq].irq = irq;
    irq_slots[irq].pending = 0;
    irq_slots[irq].total = 0;
    irq_slots[irq].handle = ++next_irq_handle;
    if(irq_slots[irq].handle == 0)
        irq_slots[irq].handle = ++next_irq_handle;
    irq_slots[irq].active = 1;

    setint(vector, irq_stubs[irq], SEG_CODE32, D_PRESENT + D_INT);
    enable_irq((unsigned short)irq);
    set_eflags(eflags);
    return (int)irq_slots[irq].handle;
}

int userhw_irq_unsubscribe(int owner, DWORD handle)
{
    DWORD eflags;
    int slot;
    int irq;

    eflags = get_eflags();
    disable();
    slot = userhw_find_irq_handle(owner, handle);
    if(slot < 0)
    {
        set_eflags(eflags);
        return USERHW_EPERM;
    }

    irq = irq_slots[slot].irq;
    disable_irq((unsigned short)irq);
    setint(userhw_irq_vector(irq), nullinterrupt, SEG_CODE32, D_PRESENT + D_INT);
    memset(&irq_slots[slot], 0, sizeof(irq_slots[slot]));
    set_eflags(eflags);
    return 0;
}

void userhw_irq_dispatch(int irq)
{
    USERIRQ_SLOT *s;

    if(irq >= 0 && irq < 16)
    {
        s = &irq_slots[irq];
        if(s->active)
        {
            if(s->pending != 0xffffffffUL)
                s->pending++;
            if(s->total != 0xffffffffUL)
                s->total++;
        }
    }

    /* The broker owns the complete IRQ gate, so it also owns PIC EOI. */
    pic_send_eoi((unsigned short)irq);
}

int userhw_irq_wait(int owner, DWORD handle, DWORD timeout_ms)
{
    DWORD start;
    DWORD eflags;
    DWORD left;
    int slot;

    start = GetTickCount();
    for(;;)
    {
        eflags = get_eflags();
        disable();
        slot = userhw_find_irq_handle(owner, handle);
        if(slot < 0)
        {
            set_eflags(eflags);
            return USERHW_EPERM;
        }
        if(irq_slots[slot].pending)
        {
            irq_slots[slot].pending--;
            left = irq_slots[slot].pending;
            set_eflags(eflags);
            /* Positive means an event was consumed; encode queue depth + 1. */
            return (int)(left + 1);
        }
        set_eflags(eflags);

        if(timeout_ms == 0)
            return 0;
        if(timeout_ms != JTMOS_IRQ_WAIT_FOREVER &&
           (DWORD)(GetTickCount() - start) >= timeout_ms)
            return 0;

        /* Blocked IRQ wait must let CPU_IDLE reach HLT. */
        SchedulerWaitPause(1000UL);
    }
}

static DWORD userhw_find_dma_pages(DWORD pages)
{
    DWORD start;
    DWORD last_start;
    DWORD i;
    DWORD physical;
    DWORD bytes;
    int free_run;

    if(pages == 0)
        return 0;
    if(pages > USERHW_DMA_PHYS_LIMIT/PAGESIZE)
        return 0;

    bytes = pages * PAGESIZE;
    last_start = (USERHW_DMA_PHYS_LIMIT/PAGESIZE) - pages;

    /* General MM allocation starts at 10 MiB and searches upward. Search the
     * ISA-DMA aperture in the opposite direction so kernel/device DMA does
     * not unnecessarily collide with early malloc() traffic. */
    for(start=last_start; start>0; --start)
    {
        physical = start * PAGESIZE;
        if(physical + bytes > USERHW_DMA_PHYS_LIMIT)
            continue;
        if((physical & 0xffff0000UL) !=
           ((physical + bytes - 1) & 0xffff0000UL))
            continue;

        free_run = 1;
        for(i=0; i<pages; ++i)
        {
            if(mmBitGet(start+i))
            {
                free_run = 0;
                break;
            }
        }
        if(free_run)
            return start;
    }
    return 0;
}

DWORD userhw_dma_alloc_kernel(DWORD bytes, DWORD *physical_address)
{
    DWORD pages;
    DWORD start_page;
    DWORD kmap;
    DWORD eflags;

    if(physical_address == NULL || bytes == 0 || bytes > JTMOS_DMA_MAX_BYTES)
        return 0;
    bytes = mm_page_align_up(bytes);
    if(bytes == 0 || bytes > JTMOS_DMA_MAX_BYTES)
        return 0;
    pages = bytes / PAGESIZE;

    eflags = get_eflags();
    disable();
    start_page = userhw_find_dma_pages(pages);
    if(start_page == 0 || mmReserveRegion(start_page,start_page+pages) != 0)
    {
        set_eflags(eflags);
        return 0;
    }
    set_eflags(eflags);

    kmap = pg_mapmemory((int)start_page,(int)pages);
    if(!kmap)
    {
        mmFreeRegion(start_page,start_page+pages);
        return 0;
    }
    memset((void *)kmap,0,bytes);
    *physical_address = start_page*PAGESIZE;
    return kmap;
}

/* Allocate physically contiguous DMA memory for 32-bit PCI bus-master devices.
 * Unlike the legacy ISA helper above, PCI OHCI/AHCI/HDA are not restricted to
 * the first 16 MiB and do not have the 8237 64 KiB boundary rule.  Keeping the
 * APIs separate prevents modern PCI devices from exhausting the tiny ISA DMA
 * aperture reserved for the floppy/Sound Blaster paths. */
int userhw_dma_verify_kernel32(DWORD kernel_address, DWORD physical_address, DWORD bytes)
{
    DWORD pages,first_virtual_page,first_physical_page,i;
    DWORD expected,pte,actual;

    if(kernel_address == 0 || physical_address == 0 || bytes == 0)
        return -1;
    if((kernel_address & (PAGESIZE-1UL)) ||
       (physical_address & (PAGESIZE-1UL)))
        return -2;

    bytes = mm_page_align_up(bytes);
    if(bytes == 0)
        return -3;
    pages = bytes / PAGESIZE;
    if(pages == 0)
        return -4;
    if((unsigned long long)physical_address + bytes > 0x100000000ULL)
        return -5;

    first_virtual_page = kernel_address / PAGESIZE;
    first_physical_page = physical_address / PAGESIZE;
    if(first_virtual_page >= MM_BITMAP_PAGES ||
       pages > MM_BITMAP_PAGES-first_virtual_page ||
       first_physical_page >= MM_BITMAP_PAGES ||
       pages > MM_BITMAP_PAGES-first_physical_page)
        return -6;

    for(i=0; i<pages; i++)
    {
        expected = physical_address + i*PAGESIZE;
        pte = GetPage(first_virtual_page+i);
        if(!(pte & 1UL))
            return -7;
        actual = pte & 0xfffff000UL;
        if(actual != expected)
            return -8;
        /* DMA pages must remain reserved in the authoritative physical bitmap. */
        if(mmBitGet(first_physical_page+i) != 1)
            return -9;
    }

    return 0;
}

DWORD userhw_dma_alloc_kernel32(DWORD bytes, DWORD *physical_address)
{
    DWORD pages;
    DWORD start_page;
    DWORD kmap;
    DWORD flags;
    DWORD physical;
    int verify;

    if(physical_address == NULL || bytes == 0)
        return 0;
    *physical_address = 0;
    bytes = mm_page_align_up(bytes);
    if(bytes == 0)
        return 0;
    pages = bytes / PAGESIZE;
    if(pages == 0 || pages > 0x7fffffffUL)
        return 0;

    /* Keep physical-run selection, reservation and kernel virtual mapping in
     * one MM critical section.  kmalloc() uses the same critical section, so
     * DMA mappings cannot race its FindEmptyArea()/PTE installation phase. */
    flags = mmCriticalEnter();
    start_page = (DWORD)mmFindFreePages((int)pages);
    if(start_page == 0 ||
       ((unsigned long long)start_page * PAGESIZE + bytes) > 0x100000000ULL ||
       mmReserveRegion(start_page,start_page+pages) != 0)
    {
        mmCriticalLeave(flags);
        return 0;
    }

    kmap = pg_mapmemory((int)start_page,(int)pages);
    if(!kmap)
    {
        mmFreeRegion(start_page,start_page+pages);
        mmCriticalLeave(flags);
        return 0;
    }
    mmCriticalLeave(flags);

    physical = start_page*PAGESIZE;
    memset((void *)kmap,0,bytes);

    /* Prove the actual PTE chain is page-aligned, physically consecutive and
     * still reserved before a bus-master device is allowed to see the address. */
    verify = userhw_dma_verify_kernel32(kmap,physical,bytes);
    if(verify != 0)
    {
        dprintk("DMA32: physical continuity verification failed rc=%d virt=0x%x phys=0x%x bytes=%u\n",
            verify,kmap,physical,(unsigned)bytes);
        pg_unmapmemory(kmap,(int)pages);
        mmFreeRegion(start_page,start_page+pages);
        return 0;
    }

    dprintk("DMA32: verified contiguous allocation virt=0x%x phys=0x%x end=0x%x pages=%u bytes=%u\n",
        kmap,physical,physical+bytes-1,(unsigned)pages,(unsigned)bytes);
    *physical_address = physical;
    return kmap;
}

static int userhw_find_free_dma_slot(void)
{
    int i;
    for(i=0; i<JTMOS_DMA_MAX_SLOTS; ++i)
        if(!dma_slots[i].active)
            return i;
    return -1;
}

static int userhw_find_dma_handle(int owner, DWORD handle)
{
    int i;
    for(i=0; i<JTMOS_DMA_MAX_SLOTS; ++i)
        if(dma_slots[i].active && dma_slots[i].owner == owner &&
           dma_slots[i].handle == handle)
            return i;
    return -1;
}

int userhw_dma_alloc(int owner, DWORD bytes, DWORD flags, JTMOS_DMA_BUFFER_K *out)
{
    DWORD pages;
    DWORD start_page;
    DWORD kmap;
    DWORD user_address;
    DWORD eflags;
    int slot;

    (void)flags;
    if(owner <= 0 || out == NULL || bytes == 0 || bytes > JTMOS_DMA_MAX_BYTES)
        return USERHW_EINVAL;
    bytes = mm_page_align_up(bytes);
    if(bytes == 0 || bytes > JTMOS_DMA_MAX_BYTES)
        return USERHW_EINVAL;
    pages = bytes / PAGESIZE;

    eflags = get_eflags();
    disable();
    slot = userhw_find_free_dma_slot();
    start_page = userhw_find_dma_pages(pages);
    if(slot < 0 || start_page == 0)
    {
        set_eflags(eflags);
        return slot < 0 ? USERHW_ENOSPC : USERHW_ENOMEM;
    }
    if(mmReserveRegion(start_page, start_page+pages) != 0)
    {
        set_eflags(eflags);
        return USERHW_ENOMEM;
    }
    set_eflags(eflags);

    kmap = pg_mapmemory((int)start_page, (int)pages);
    if(!kmap)
    {
        mmFreeRegion(start_page, start_page+pages);
        return USERHW_ENOMEM;
    }

    user_address = mm_find_process_free_range(owner, bytes,
        MM_USER_BASE, MM_USER_TOP);
    if(!user_address || mm_map_process_range(owner, user_address,
        (void *)kmap, bytes, PROT_READ|PROT_WRITE) != 0)
    {
        pg_unmapmemory(kmap, (int)pages);
        mmFreeRegion(start_page, start_page+pages);
        return USERHW_ENOMEM;
    }

    memset((void *)kmap, 0, bytes);

    eflags = get_eflags();
    disable();
    dma_slots[slot].owner = owner;
    dma_slots[slot].handle = ++next_dma_handle;
    if(dma_slots[slot].handle == 0)
        dma_slots[slot].handle = ++next_dma_handle;
    dma_slots[slot].physical = start_page * PAGESIZE;
    dma_slots[slot].kernel_address = kmap;
    dma_slots[slot].user_address = user_address;
    dma_slots[slot].size = bytes;
    dma_slots[slot].pages = pages;
    dma_slots[slot].active = 1;

    out->handle = dma_slots[slot].handle;
    out->address = user_address;
    out->physical_address = dma_slots[slot].physical;
    out->size = bytes;
    set_eflags(eflags);
    return 0;
}

static void userhw_release_channel_slot(int slot)
{
    int ch;
    for(ch=0; ch<USERHW_DMA_CHANNELS; ++ch)
    {
        if(dma_channel_slot[ch] == slot)
        {
            dma_mask_channel((BYTE)ch);
            dma_channel_slot[ch] = -1;
        }
    }
}

int userhw_dma_free(int owner, DWORD handle)
{
    USERDMA_SLOT old;
    DWORD eflags;
    int slot;

    eflags = get_eflags();
    disable();
    slot = userhw_find_dma_handle(owner, handle);
    if(slot < 0)
    {
        set_eflags(eflags);
        return USERHW_EPERM;
    }
    userhw_release_channel_slot(slot);
    old = dma_slots[slot];
    memset(&dma_slots[slot], 0, sizeof(dma_slots[slot]));
    set_eflags(eflags);

    mm_unmap_process_range(old.owner, old.user_address, old.size);
    pg_unmapmemory(old.kernel_address, (int)old.pages);
    mmFreeRegion(old.physical/PAGESIZE,
                 old.physical/PAGESIZE + old.pages);
    return 0;
}

int userhw_dma_program(int owner, DWORD handle, int channel, DWORD length, int direction)
{
    DWORD eflags;
    int slot;

    if(channel < 0 || channel >= USERHW_DMA_CHANNELS || channel == 4)
        return USERHW_EINVAL;
    if(direction != USERHW_DMA_FROM_DEVICE && direction != USERHW_DMA_TO_DEVICE)
        return USERHW_EINVAL;

    eflags = get_eflags();
    disable();
    slot = userhw_find_dma_handle(owner, handle);
    if(slot < 0)
    {
        set_eflags(eflags);
        return USERHW_EPERM;
    }
    if(length == 0 || length > dma_slots[slot].size || length > 65536UL)
    {
        set_eflags(eflags);
        return USERHW_EINVAL;
    }
    if(dma_channel_slot[channel] >= 0 && dma_channel_slot[channel] != slot)
    {
        set_eflags(eflags);
        return USERHW_EBUSY;
    }
    dma_channel_slot[channel] = slot;
    set_eflags(eflags);

    /* Historical dma_xfer names the direction from the controller side:
     * FALSE = device -> memory, TRUE = memory -> device. */
    dma_xfer((BYTE)channel, dma_slots[slot].physical, (unsigned int)length,
        direction == USERHW_DMA_TO_DEVICE ? TRUE : FALSE);
    return 0;
}

int userhw_dma_stop(int owner, DWORD handle, int channel)
{
    DWORD eflags;
    int slot;

    if(channel < 0 || channel >= USERHW_DMA_CHANNELS)
        return USERHW_EINVAL;
    eflags = get_eflags();
    disable();
    slot = userhw_find_dma_handle(owner, handle);
    if(slot < 0)
    {
        set_eflags(eflags);
        return USERHW_EPERM;
    }
    if(dma_channel_slot[channel] == slot)
    {
        dma_mask_channel((BYTE)channel);
        dma_channel_slot[channel] = -1;
    }
    set_eflags(eflags);
    return 0;
}

DWORD userhw_dma_translate(int owner, DWORD user_address)
{
    return userhw_dma_translate_range(owner,user_address,1);
}

DWORD userhw_dma_translate_range(int owner, DWORD user_address, DWORD length)
{
    int i;
    DWORD off;

    for(i=0; i<JTMOS_DMA_MAX_SLOTS; ++i)
    {
        if(!dma_slots[i].active || dma_slots[i].owner != owner)
            continue;
        if(length == 0)
            return 0;
        if(user_address >= dma_slots[i].user_address &&
           user_address - dma_slots[i].user_address < dma_slots[i].size)
        {
            off = user_address - dma_slots[i].user_address;
            if(length <= dma_slots[i].size - off)
                return dma_slots[i].kernel_address + off;
        }
    }
    return 0;
}

void userhw_release_pid(int owner)
{
    DWORD irq_handles[16];
    DWORD dma_handles[JTMOS_DMA_MAX_SLOTS];
    int ni;
    int nd;
    int i;

    ni = nd = 0;
    for(i=0; i<16; ++i)
        if(irq_slots[i].active && irq_slots[i].owner == owner)
            irq_handles[ni++] = irq_slots[i].handle;
    for(i=0; i<JTMOS_DMA_MAX_SLOTS; ++i)
        if(dma_slots[i].active && dma_slots[i].owner == owner)
            dma_handles[nd++] = dma_slots[i].handle;

    for(i=0; i<ni; ++i)
        userhw_irq_unsubscribe(owner, irq_handles[i]);
    for(i=0; i<nd; ++i)
        userhw_dma_free(owner, dma_handles[i]);
}
