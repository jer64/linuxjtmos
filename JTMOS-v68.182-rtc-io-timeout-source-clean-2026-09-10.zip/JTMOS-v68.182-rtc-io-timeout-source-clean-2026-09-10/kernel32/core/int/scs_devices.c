// =======================================================
// scs.c - JTMOS system call services
// (C) 2002 by Jari Tuominen(jari@vunet.org).
// OBSOLETE....
// =======================================================
//
#include "kernel32.h"
#include "systemcalls.h" // aka scs.h
#include "scconf.h" // contains only defines, works with nasm
#include "postman.h" // POSTMANCMD, etc..
#include "ega.h"
#include "threads.h"

// ebx = name of the device
// Return value: handle of the device(DWORD)
DWORD scall_getdevnrbyname(SYSCALLPAR)
{
	char *s;

	//
	s = A2K(scall_ebx);
	return driver_getdevicenrbyname(s);
}

// ebx=devnr, ecx=blocknr, edx=pointer to buffer
DWORD scall_readblock(SYSCALLPAR)
{
	char *s;

	//
	s = A2K(scall_edx);
	return readblock(scall_ebx, scall_ecx, s);
}

// ebx=devnr, ecx=blocknr, edx=pointer to buffer
DWORD scall_writeblock(SYSCALLPAR)
{
	char *s;

	/* SCALL_IRQ_ON: block I/O may wait for a device IRQ. */
	s = A2K(scall_edx);
	return writeblock(scall_ebx, scall_ecx, s);
}



// ebx=devnr, ecx=first block, edx=user buffer, esi=block count
DWORD scall_readblocks(SYSCALLPAR)
{
    DWORD bytes;
    char *s;
    int bs,count;

    count=(int)scall_esi;
    if(count<=0 || !isValidDevice((int)scall_ebx)) return 0;
    bs=getblocksize((int)scall_ebx);
    if(bs<=0 || (DWORD)count > (0xffffffffUL/(DWORD)bs)) return 0;
    bytes=(DWORD)count*(DWORD)bs;
    s=(char *)A2KRange(scall_edx,bytes);
    if(s==NULL) return 0;
    return (DWORD)readblocks((long)scall_ebx,(long)scall_ecx,(BYTE *)s,count);
}

// ebx=devnr, ecx=first block, edx=user buffer, esi=block count
DWORD scall_writeblocks(SYSCALLPAR)
{
    DWORD bytes;
    char *s;
    int bs,count;

    count=(int)scall_esi;
    if(count<=0 || !isValidDevice((int)scall_ebx)) return 0;
    bs=getblocksize((int)scall_ebx);
    if(bs<=0 || (DWORD)count > (0xffffffffUL/(DWORD)bs)) return 0;
    bytes=(DWORD)count*(DWORD)bs;
    s=(char *)A2KRange(scall_edx,bytes);
    if(s==NULL) return 0;
    return (DWORD)writeblocks((long)scall_ebx,(long)scall_ecx,(BYTE *)s,count);
}
