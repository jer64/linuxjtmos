// ============================================================
// dfunc.c
// Debugging Functions Collection
// (C) 2002-2004 by Jari Tuominen.
// ============================================================
// Required includes
#include "kernel32.h" // preferences for kernel32(init)
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
#include "sb.h"
#include "syssh.h"
#include "driver_sys.h"
#include "zero.h"
#include "null.h"
#include "printf.h"
#include "stdarg.h"
#include "dfunc.h"
#include "logging.h"

// Debug sleep
int dsleep(int sec)
{
	//
	dprintk("%s: duration in seconds=%d\n",
		__FUNCTION__,
		sec);
	if(jtmos_debug)sleep(sec);
	return 0;
}

// Debug printk
int dprintk(const char *fmt, ...)
{
    va_list arg;
    char tmp[1024];

    if(!jtmos_debug)
        return 0;
    /* d0 may disable the expensive UART path during autostart.  Once the
     * in-memory system logger exists we can still preserve the stream and
     * flush it later, after JTMFS/root initialization is safely complete. */
    if(!DebugSerialRuntimeEnabled() && !SystemLoggingStreamEnabled())
        return 0;

    va_start(arg, fmt);
    svprintf(tmp, fmt, arg);
    va_end(arg);

    if(DebugSerialRuntimeEnabled() && serial_debug_line >= 0)
        DebugSerialWrite(tmp);
    if(SystemLoggingStreamEnabled())
        WriteSystemLogStream("DEBUG",tmp);

    return 0;
}

