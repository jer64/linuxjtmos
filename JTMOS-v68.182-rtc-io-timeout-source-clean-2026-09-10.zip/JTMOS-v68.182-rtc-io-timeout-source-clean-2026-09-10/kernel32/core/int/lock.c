//
#define JTMOS_LOCK_IMPLEMENTATION 1
#include "kernel32.h"
#include "scheduler.h"
#include "lock.h"

#define JTMOS_NAMED_LOCKS 1000
#define JTMOS_NAMED_TRACE_SLOTS 64

/* Keep the historical 1000-ID lock namespace without paying ~20-30 KiB of
 * extra BSS for debug metadata.  Only active named locks need metadata, so a
 * compact side table is enough.  The current tree does not actively use the
 * ID API, but old objects can still call it. */
static volatile int lock[JTMOS_NAMED_LOCKS];

typedef struct JTMOS_NAMED_LOCK_TRACE
{
    int used;
    int lock_id;
    int owner_pid;
    const char *owner_function;
    const char *owner_file;
    int owner_line;
    DWORD acquired_ms;
} JTMOS_NAMED_LOCK_TRACE;

static JTMOS_NAMED_LOCK_TRACE named_trace[JTMOS_NAMED_TRACE_SLOTS];

typedef struct JTMOS_LOCK_SNAPSHOT
{
    int owner_pid;
    const char *owner_function;
    const char *owner_file;
    int owner_line;
    DWORD acquired_ms;
} JTMOS_LOCK_SNAPSHOT;

static const char *lock_safe_string(const char *s)
{
    return s ? s : "?";
}

static DWORD lock_elapsed(DWORD now, DWORD then)
{
    /* Unsigned subtraction also gives the right elapsed interval across the
     * normal 32-bit millisecond counter wrap. */
    return (DWORD)(now - then);
}

/* Called only while interrupts are disabled by the named-lock code. */
static int named_trace_find_locked(int lockID)
{
    int i;
    for(i=0;i<JTMOS_NAMED_TRACE_SLOTS;i++)
        if(named_trace[i].used && named_trace[i].lock_id==lockID)
            return i;
    return -1;
}

/* Called only while interrupts are disabled. */
static int named_trace_set_locked(int lockID,int pid,const char *function,
                                  const char *file,int line,DWORD since)
{
    int i,free_slot=-1;
    for(i=0;i<JTMOS_NAMED_TRACE_SLOTS;i++)
    {
        if(named_trace[i].used && named_trace[i].lock_id==lockID)
        {
            free_slot=i;
            break;
        }
        if(!named_trace[i].used && free_slot<0)
            free_slot=i;
    }
    if(free_slot<0)
        return -1;
    named_trace[free_slot].used=1;
    named_trace[free_slot].lock_id=lockID;
    named_trace[free_slot].owner_pid=pid;
    named_trace[free_slot].owner_function=function;
    named_trace[free_slot].owner_file=file;
    named_trace[free_slot].owner_line=line;
    named_trace[free_slot].acquired_ms=since;
    return free_slot;
}

/* Called only while interrupts are disabled. */
static void named_trace_snapshot_locked(int lockID,JTMOS_LOCK_SNAPSHOT *s)
{
    int i;
    if(s==NULL) return;
    s->owner_pid=-1;
    s->owner_function=0;
    s->owner_file=0;
    s->owner_line=0;
    s->acquired_ms=0;
    i=named_trace_find_locked(lockID);
    if(i<0) return;
    s->owner_pid=named_trace[i].owner_pid;
    s->owner_function=named_trace[i].owner_function;
    s->owner_file=named_trace[i].owner_file;
    s->owner_line=named_trace[i].owner_line;
    s->acquired_ms=named_trace[i].acquired_ms;
}

/* Called only while interrupts are disabled. */
static void named_trace_clear_locked(int lockID)
{
    int i=named_trace_find_locked(lockID);
    if(i<0) return;
    named_trace[i].used=0;
    named_trace[i].lock_id=0;
    named_trace[i].owner_pid=0;
    named_trace[i].owner_function=0;
    named_trace[i].owner_file=0;
    named_trace[i].owner_line=0;
    named_trace[i].acquired_ms=0;
}

int LockWaitCanYield(int saved_eflags)
{
    int pid;

    if(!Multitasking || PitStorageSafeActive())
        return 0;

    if(saved_eflags & 0x200)
        return 1;

    /* INT 0x7F is an interrupt gate, so ring-3 syscalls enter with IF=0.
     * JTMOS already permits cooperative SwitchToThread() from syscall
     * services through INT 0x7E.  thread_scall_active distinguishes that
     * supported case from a true IRQ/exception IF=0 context. */
    pid=GetCurrentThread();
    if(valid_pid(pid) && thread_scall_active[pid])
        return 1;

    return 0;
}

void JtmosFunctionLockAcquire(JTMOS_LOCK_STATE *state,
                              const char *function,
                              const char *file,
                              int line)
{
    int flags,pid,owner_snapshot,owner_line_snapshot;
    unsigned long spins;
    unsigned long owner_depth_snapshot;
    DWORD wait_started,now,owner_since_snapshot;
    const char *owner_function_snapshot,*owner_file_snapshot;
    int logged_wait;

    if(!Multitasking || state==NULL)
        return;

    pid=GetCurrentThread();
    flags=get_eflags();
    spins=0;
    logged_wait=0;
    wait_started=GetTickCount();
    disable();

    while(state->owner_pid!=-1 && state->owner_pid!=pid)
    {
        owner_snapshot=state->owner_pid;
        owner_depth_snapshot=state->depth;
        owner_function_snapshot=state->owner_function;
        owner_file_snapshot=state->owner_file;
        owner_line_snapshot=state->owner_line;
        owner_since_snapshot=state->acquired_ms;
        set_eflags(flags);

        now=GetTickCount();
        if(!logged_wait)
        {
            dprintk("[LOCK] wait kind=function lock=%x caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d depth=%u held_ms=%u IF=%d\n",
                    (unsigned long)state,pid,
                    lock_safe_string(function),lock_safe_string(file),line,
                    owner_snapshot,lock_safe_string(owner_function_snapshot),
                    lock_safe_string(owner_file_snapshot),owner_line_snapshot,
                    (unsigned)owner_depth_snapshot,
                    (unsigned)lock_elapsed(now,owner_since_snapshot),
                    (flags&0x200)?1:0);
            logged_wait=1;
        }

        if(LockWaitCanYield(flags))
            SchedulerWaitPause(1000UL);
        else
        {
            unsigned long i;
            for(i=0;i<128;i++) cpu_relax();
        }

        disable();
        if(++spins>=JTMOS_LOCK_SPIN_LIMIT)
        {
            owner_snapshot=state->owner_pid;
            owner_depth_snapshot=state->depth;
            owner_function_snapshot=state->owner_function;
            owner_file_snapshot=state->owner_file;
            owner_line_snapshot=state->owner_line;
            owner_since_snapshot=state->acquired_ms;
            set_eflags(flags);
            now=GetTickCount();
            dprintk("[LOCK] TIMEOUT kind=function lock=%x caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d depth=%u held_ms=%u waited_ms=%u IF=%d\n",
                    (unsigned long)state,pid,
                    lock_safe_string(function),lock_safe_string(file),line,
                    owner_snapshot,lock_safe_string(owner_function_snapshot),
                    lock_safe_string(owner_file_snapshot),owner_line_snapshot,
                    (unsigned)owner_depth_snapshot,
                    (unsigned)lock_elapsed(now,owner_since_snapshot),
                    (unsigned)lock_elapsed(now,wait_started),
                    (flags&0x200)?1:0);
            spins=0;
            disable();
        }
    }

    if(state->owner_pid==pid)
    {
        state->depth++;
        owner_depth_snapshot=state->depth;
        set_eflags(flags);
#if JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
        dprintk("[LOCK] recurse kind=function lock=%x pid=%d at=%s %s:%d depth=%u\n",
                (unsigned long)state,pid,lock_safe_string(function),
                lock_safe_string(file),line,(unsigned)owner_depth_snapshot);
#endif
        return;
    }

    state->owner_pid=pid;
    state->depth=1;
    state->owner_function=function;
    state->owner_file=file;
    state->owner_line=line;
    state->acquired_ms=GetTickCount();
    now=state->acquired_ms;
    set_eflags(flags);

#if JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
    dprintk("[LOCK] acquire kind=function lock=%x pid=%d at=%s %s:%d waited_ms=%u IF=%d\n",
            (unsigned long)state,pid,lock_safe_string(function),
            lock_safe_string(file),line,
            (unsigned)lock_elapsed(now,wait_started),(flags&0x200)?1:0);
#endif
}

void JtmosFunctionLockRelease(JTMOS_LOCK_STATE *state,
                              const char *function,
                              const char *file,
                              int line)
{
    int flags,pid,owner_snapshot,owner_line_snapshot,released;
    unsigned long depth_snapshot;
    DWORD now,owner_since_snapshot;
    const char *owner_function_snapshot,*owner_file_snapshot;

    if(!Multitasking || state==NULL)
        return;

    pid=GetCurrentThread();
    flags=get_eflags();
    now=GetTickCount();
    released=0;
    disable();

    owner_snapshot=state->owner_pid;
    depth_snapshot=state->depth;
    owner_function_snapshot=state->owner_function;
    owner_file_snapshot=state->owner_file;
    owner_line_snapshot=state->owner_line;
    owner_since_snapshot=state->acquired_ms;

    if(state->owner_pid==pid && state->depth!=0)
    {
        state->depth--;
        depth_snapshot=state->depth;
        if(state->depth==0)
        {
            state->owner_pid=-1;
            state->owner_function=0;
            state->owner_file=0;
            state->owner_line=0;
            state->acquired_ms=0;
            released=1;
        }
        set_eflags(flags);
#if JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
        dprintk("[LOCK] release kind=function lock=%x pid=%d at=%s %s:%d owner_at=%s %s:%d depth=%u held_ms=%u%s\n",
                (unsigned long)state,pid,lock_safe_string(function),
                lock_safe_string(file),line,
                lock_safe_string(owner_function_snapshot),
                lock_safe_string(owner_file_snapshot),owner_line_snapshot,
                (unsigned)depth_snapshot,
                (unsigned)lock_elapsed(now,owner_since_snapshot),
                released?" final":" recursive");
#endif
        return;
    }

    set_eflags(flags);
    dprintk("[LOCK] BAD-UNLOCK kind=function lock=%x caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d depth=%u held_ms=%u\n",
            (unsigned long)state,pid,lock_safe_string(function),
            lock_safe_string(file),line,owner_snapshot,
            lock_safe_string(owner_function_snapshot),
            lock_safe_string(owner_file_snapshot),owner_line_snapshot,
            (unsigned)depth_snapshot,
            (unsigned)lock_elapsed(now,owner_since_snapshot));
}

void LockAt(int lockID, const char *function, const char *file, int line)
{
    int flags,pid,logged_wait,trace_slot;
    unsigned long spins;
    DWORD wait_started,now;
    JTMOS_LOCK_SNAPSHOT owner;

    if(!Multitasking)
        return;
    if(lockID<0 || lockID>=JTMOS_NAMED_LOCKS)
    {
        dprintk("[LOCK] invalid-id acquire id=%d caller=%s %s:%d\n",
                lockID,lock_safe_string(function),lock_safe_string(file),line);
        return;
    }

    pid=GetCurrentThread();
    flags=get_eflags();
    spins=0;
    logged_wait=0;
    wait_started=GetTickCount();
    disable();

    while(lock[lockID])
    {
        named_trace_snapshot_locked(lockID,&owner);
        set_eflags(flags);
        now=GetTickCount();

        if(!logged_wait)
        {
            dprintk("[LOCK] wait kind=id id=%d caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d held_ms=%u IF=%d\n",
                    lockID,pid,lock_safe_string(function),lock_safe_string(file),line,
                    owner.owner_pid,lock_safe_string(owner.owner_function),
                    lock_safe_string(owner.owner_file),owner.owner_line,
                    (unsigned)lock_elapsed(now,owner.acquired_ms),
                    (flags&0x200)?1:0);
            logged_wait=1;
        }

        if(LockWaitCanYield(flags))
            SchedulerWaitPause(1000UL);
        else
        {
            unsigned long i;
            for(i=0;i<128;i++) cpu_relax();
        }

        disable();
        if(++spins>=JTMOS_LOCK_SPIN_LIMIT)
        {
            named_trace_snapshot_locked(lockID,&owner);
            set_eflags(flags);
            now=GetTickCount();
            dprintk("[LOCK] TIMEOUT kind=id id=%d caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d held_ms=%u waited_ms=%u IF=%d\n",
                    lockID,pid,lock_safe_string(function),lock_safe_string(file),line,
                    owner.owner_pid,lock_safe_string(owner.owner_function),
                    lock_safe_string(owner.owner_file),owner.owner_line,
                    (unsigned)lock_elapsed(now,owner.acquired_ms),
                    (unsigned)lock_elapsed(now,wait_started),
                    (flags&0x200)?1:0);
            spins=0;
            disable();
        }
    }

    lock[lockID]=1;
    now=GetTickCount();
    trace_slot=named_trace_set_locked(lockID,pid,function,file,line,now);
    set_eflags(flags);

    if(trace_slot<0)
        dprintk("[LOCK] trace-table-full kind=id id=%d pid=%d at=%s %s:%d slots=%d\n",
                lockID,pid,lock_safe_string(function),lock_safe_string(file),line,
                JTMOS_NAMED_TRACE_SLOTS);
#if JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
    dprintk("[LOCK] acquire kind=id id=%d pid=%d at=%s %s:%d waited_ms=%u IF=%d\n",
            lockID,pid,lock_safe_string(function),lock_safe_string(file),line,
            (unsigned)lock_elapsed(now,wait_started),(flags&0x200)?1:0);
#endif
}

void UnlockAt(int lockID, const char *function, const char *file, int line)
{
    int flags,pid,was_locked;
    DWORD now;
    JTMOS_LOCK_SNAPSHOT owner;

    if(!Multitasking)
        return;
    if(lockID<0 || lockID>=JTMOS_NAMED_LOCKS)
    {
        dprintk("[LOCK] invalid-id release id=%d caller=%s %s:%d\n",
                lockID,lock_safe_string(function),lock_safe_string(file),line);
        return;
    }

    pid=GetCurrentThread();
    flags=get_eflags();
    now=GetTickCount();
    disable();
    was_locked=lock[lockID];
    named_trace_snapshot_locked(lockID,&owner);

    /* Preserve the historical ID-lock behaviour: Unlock releases the lock
     * even if the caller is not the recorded owner.  The mismatch is now loud
     * in the debug stream instead of being invisible. */
    lock[lockID]=0;
    named_trace_clear_locked(lockID);
    set_eflags(flags);

    if(!was_locked)
    {
        dprintk("[LOCK] BAD-UNLOCK kind=id id=%d caller_pid=%d caller=%s %s:%d reason=already-free\n",
                lockID,pid,lock_safe_string(function),lock_safe_string(file),line);
        return;
    }
    if(owner.owner_pid>=0 && owner.owner_pid!=pid)
        dprintk("[LOCK] BAD-UNLOCK kind=id id=%d caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d held_ms=%u reason=owner-mismatch\n",
                lockID,pid,lock_safe_string(function),lock_safe_string(file),line,
                owner.owner_pid,lock_safe_string(owner.owner_function),
                lock_safe_string(owner.owner_file),owner.owner_line,
                (unsigned)lock_elapsed(now,owner.acquired_ms));
#if JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
    dprintk("[LOCK] release kind=id id=%d pid=%d at=%s %s:%d owner_pid=%d owner_at=%s %s:%d held_ms=%u\n",
            lockID,pid,lock_safe_string(function),lock_safe_string(file),line,
            owner.owner_pid,lock_safe_string(owner.owner_function),
            lock_safe_string(owner.owner_file),owner.owner_line,
            (unsigned)lock_elapsed(now,owner.acquired_ms));
#endif
}

/* Legacy ABI entry points.  New source calls are rewritten by lock.h and carry
 * the real call site; old binary objects still get useful ownership timing. */
void Lock(int lockID)
{
    LockAt(lockID,"Lock","<legacy>",0);
}

void Unlock(int lockID)
{
    UnlockAt(lockID,"Unlock","<legacy>",0);
}
