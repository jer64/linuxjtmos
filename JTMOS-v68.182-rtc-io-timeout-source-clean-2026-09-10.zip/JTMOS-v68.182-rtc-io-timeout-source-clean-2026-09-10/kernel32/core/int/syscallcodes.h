/*
 * This header file is used by both JTMOS kernel and LIBC.
 * (C) 2002-2003 by Jari Tuominen.
 */

#ifndef __INCLUDED_SYSCALLCODES_H__
#define __INCLUDED_SYSCALLCODES_H__

//
#define SYS_IDLE			1
#define SYS_remove			2
#define SYS_mkfs			3
#define SYS_rename			4
#define SYS_PUTS			6
#define SYS_PUTCH			7
#define SYS_EXIT			8
#define SYS_CLRSCR			9
#define SYS_GETCH			10
#define SYS_GETCURDEV			12
#define SYS_POSTCMD			11
#define SYS_GOTOXY              	13
#define SYS_GETTICKCOUNT		14
#define SYS_GETAMEMSIZE			15
#define SYS_GETCURRENTTHREAD		16
#define SYS_GETARGC			17
#define SYS_GETARGV			18
#define SYS_open			19
#define SYS_close			20
#define SYS_read			21
#define SYS_write			22
#define SYS_lseek			23
#define SYS_cexec			24
#define SYS_getdevnrbyname		25
#define SYS_readblock			26
#define SYS_writeblock			27
#define SYS_waitprocterm		28
#define SYS_findfirst			29
#define SYS_findnext			30
#define SYS_textcolor			31
#define SYS_textbackground		32
#define SYS_inputmouse			33
#define SYS_setmouserect		34
#define SYS_vgadrawframe		35
#define SYS_GETCURDB			36
#define SYS_vgawaitretrace		37
#define SYS_chdir			38
#define SYS_getdevicename		39
#define SYS_getdate			40
#define SYS_WHEREX			41
#define SYS_WHEREY			42
#define SYS_vgaselectplane		43
#define SYS_getdevicenrbyname		44
#define SYS_getthreadpriority		45
#define SYS_getthreadspending		46
#define SYS_getthreadname		47
#define SYS_getthreadmemoryusage	48
#define SYS_getthreadcount		49
#define SYS_getctrl			50
#define SYS_getalt			51
#define SYS_activatemsgbox		52
#define SYS_sendmessage			53
#define SYS_receivemessage		54
#define SYS_getthreadpid		55
#define SYS_identifythread		56
#define SYS_getseconds			57
#define SYS_globalcopy			58
#define SYS_getthreadterminal		59
#define SYS_setthreadterminal		60
#define SYS_newterminal			61
#define SYS_outputterminalkeyboardbuffer	62
#define SYS_inputterminalkeyboardbuffer		63
#define SYS_copyterminal			64
#define SYS_killthread				65
#define SYS_getcursorlocation			66
#define SYS_setint				67
#define SYS_enableirq				68
#define SYS_diskchange				69
#define SYS_getpididentity			70
#define SYS_getthreaduniquepid			SYS_getpididentity /* deprecated compatibility alias */
#define SYS_registernewdevice			71
#define SYS_switchtothreadex			72
#define SYS_createterminal			73
#define SYS_setterminalowner			74
#define SYS_getterminalowner			75
#define SYS_serialget				76
#define SYS_serialput				77
#define SYS_setserialportspeed			78
#define SYS_receiverawpacket			79
#define SYS_transmitrawpacket			80
#define SYS_devicecall				81
#define SYS_milsleep				82
#define SYS_opensocket				83
#define SYS_closesocket				84
#define SYS_readsocket				85
#define SYS_writesocket				86
#define SYS_switchtothread			87
#define SYS_getcwd				88
#define SYS_stat				89
#define SYS_fstat				90
#define SYS_wgetch				91
#define SYS_mkdir				92
#define SYS_kmalloc				93
#define SYS_kfree				94

/***
        // 96 fexist
        scall_fexist,
        // 97
        scall_getfiledatablock,
        // 98
        scall_isdriveready,
        // 99
        scall_diskchange,
        // 100
        scall_getfilesize,
        // 101
        scall_read1
        // 102
        scall_setsize,
***/
#define SYS_fexist				95
#define SYS_getfiledatablock			96
#define SYS_isdriveready			97
/* Historical duplicate disk-change ABI slot.  SYS_diskchange remains 69. */
#define SYS_diskchange_compat			98
#define SYS_getfilesize				99
#define SYS_read1				100
#define SYS_write1				101
#define SYS_creat1				102
#define SYS_unlink1				103
#define SYS_setsize1				104
#define SYS_getcpustats			105
#define SYS_usleep				106
#define SYS_audioinit            107
#define SYS_audiowrite           108
#define SYS_audioposition        109
#define SYS_audiostop            110
#define SYS_audioinfo            111
#define SYS_audioselect          112
#define SYS_window               113
#define SYS_copyfromthread       114
#define SYS_irqsubscribe          115
#define SYS_irqunsubscribe        116
#define SYS_irqwait               117
#define SYS_dmaalloc              118
#define SYS_dmafree               119
#define SYS_dmaprogram            120
#define SYS_dmastop               121
#define SYS_vgasetpalette         122
#define SYS_getcpufeatures        123
#define SYS_graosgraphics          124
#define SYS_readblocks             125
#define SYS_writeblocks            126
#define SYS_fork                   127
#define SYS_getppid                 128
#define SYS_waitpid                 129
#define SYS_kill                    130
#define SYS_sigdisp                 131
#define SYS_pipe                    132
#define SYS_poll                    133
#define SYS_nice                    134
#define SYS_getpriority             135
#define SYS_setpriority             136
#define SYS_uname                   137
#define SYS_sysinfo                 138
#define SYS_filebuf_read            139
#define SYS_filebuf_write           140
#define SYS_filebuf_flush           141
#define SYS_filebuf_set             142
#define SYS_filebuf_seek            143
#define SYS_filebuf_tell            144
#define SYS_dup2                    145
#define SYS_cexec_stdio             146
#define SYS_mmap                    147
#define SYS_munmap                  148
#define SYS_mem_grow                149
#define SYS_setcursortype           150
#define SYS_bootutils               151
#define SYS_keystate                152
#define SYS_smsh_builtin            153
#define SYS_env                     154
#define SYS_resolvehost4            155
#define SYS_fsusage                 156
#define SYS_dprintk                 157

#endif


