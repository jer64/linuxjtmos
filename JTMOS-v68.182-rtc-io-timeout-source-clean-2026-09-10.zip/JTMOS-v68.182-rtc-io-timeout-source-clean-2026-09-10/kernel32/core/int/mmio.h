#ifndef __JTMOS_IA32_MMIO_H__
#define __JTMOS_IA32_MMIO_H__

#include "basdef.h"
#include "io.h"

extern int MMIO_TRACE_ENABLED;
void mmio_trace_access(const char *op,const volatile void *address,DWORD value,
                       int width,const char *function,const char *file,int line);
void mmio_trace_mapping(DWORD physical,DWORD virtual_address,int pages);

/* MMIO must be mapped uncached with pg_mapio().  These helpers provide
 * exact-width volatile accesses and compiler ordering.  The UC memory type
 * supplies architectural device ordering on IA-32; io_memory_barrier() is
 * available for coherent DMA publication/completion boundaries.
 *
 * V68.150: when MMIO_TRACE_ENABLED is non-zero, each access is emitted after
 * the actual transaction together with its C callsite.  The raw transaction
 * still occurs exactly once. */
static __inline__ BYTE __mmio_read8(const volatile void *address,
                                    const char *function,const char *file,int line)
{
    BYTE v;
    io_compiler_barrier();
    v=*(const volatile BYTE *)address;
    io_compiler_barrier();
    if(MMIO_TRACE_ENABLED)
        mmio_trace_access("R",address,(DWORD)v,8,function,file,line);
    return v;
}
static __inline__ WORD __mmio_read16(const volatile void *address,
                                     const char *function,const char *file,int line)
{
    WORD v;
    io_compiler_barrier();
    v=*(const volatile WORD *)address;
    io_compiler_barrier();
    if(MMIO_TRACE_ENABLED)
        mmio_trace_access("R",address,(DWORD)v,16,function,file,line);
    return v;
}
static __inline__ DWORD __mmio_read32(const volatile void *address,
                                      const char *function,const char *file,int line)
{
    DWORD v;
    io_compiler_barrier();
    v=*(const volatile DWORD *)address;
    io_compiler_barrier();
    if(MMIO_TRACE_ENABLED)
        mmio_trace_access("R",address,v,32,function,file,line);
    return v;
}
static __inline__ void __mmio_write8(volatile void *address,BYTE value,
                                     const char *function,const char *file,int line)
{
    io_compiler_barrier();
    *(volatile BYTE *)address=value;
    io_compiler_barrier();
    if(MMIO_TRACE_ENABLED)
        mmio_trace_access("W",address,(DWORD)value,8,function,file,line);
}
static __inline__ void __mmio_write16(volatile void *address,WORD value,
                                      const char *function,const char *file,int line)
{
    io_compiler_barrier();
    *(volatile WORD *)address=value;
    io_compiler_barrier();
    if(MMIO_TRACE_ENABLED)
        mmio_trace_access("W",address,(DWORD)value,16,function,file,line);
}
static __inline__ void __mmio_write32(volatile void *address,DWORD value,
                                      const char *function,const char *file,int line)
{
    io_compiler_barrier();
    *(volatile DWORD *)address=value;
    io_compiler_barrier();
    if(MMIO_TRACE_ENABLED)
        mmio_trace_access("W",address,value,32,function,file,line);
}

#define mmio_read8(address)     __mmio_read8((address),__FUNCTION__,__FILE__,__LINE__)
#define mmio_read16(address)     __mmio_read16((address),__FUNCTION__,__FILE__,__LINE__)
#define mmio_read32(address)     __mmio_read32((address),__FUNCTION__,__FILE__,__LINE__)
#define mmio_write8(address,value)     __mmio_write8((address),(value),__FUNCTION__,__FILE__,__LINE__)
#define mmio_write16(address,value)     __mmio_write16((address),(value),__FUNCTION__,__FILE__,__LINE__)
#define mmio_write32(address,value)     __mmio_write32((address),(value),__FUNCTION__,__FILE__,__LINE__)

/* Readback helper for posted MMIO writes where the device specification
 * explicitly requires completion before proceeding. */
static __inline__ DWORD __mmio_write32_flush(volatile void *address,DWORD value,
                                             const char *function,const char *file,int line)
{
    DWORD readback;
    __mmio_write32(address,value,function,file,line);
    readback=__mmio_read32(address,function,file,line);
    return readback;
}
#define mmio_write32_flush(address,value)     __mmio_write32_flush((address),(value),__FUNCTION__,__FILE__,__LINE__)

#endif
