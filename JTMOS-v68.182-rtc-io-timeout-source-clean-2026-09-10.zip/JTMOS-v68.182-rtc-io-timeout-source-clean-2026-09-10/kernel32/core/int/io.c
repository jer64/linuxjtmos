/*** IA-32 low level I/O functions ***/
#include "io.h"
#include "basdef.h"
#include "debug.h"
#include "sprintf.h"

/* Keep the historical public entry points delayed for old ISA drivers while
 * exposing exact-width raw primitives as io_read/io_write in io.h. */
void outportb(WORD port,BYTE value) { outb_p(value,port); }
BYTE inportb(WORD port) { return inb_p(port); }
void outportw(WORD port,WORD value) { outw_p(value,port); }
WORD inportw(WORD port) { return inw_p(port); }
void outportd(WORD port,DWORD value) { outd_p(value,port); }
DWORD inportd(WORD port) { return ind_p(port); }

/* V68.150 MMIO tracer.  Tracing is intentionally serialized with a small
 * recursion guard: dprintk ultimately reaches the serial UART through port I/O,
 * but future debug backends may themselves use MMIO.  A nested access is simply
 * not traced rather than recursively overflowing the kernel stack. */
extern int MMIO_TRACE_ENABLED;
static int mmio_trace_busy=0;

void mmio_trace_access(const char *op,const volatile void *address,DWORD value,
                       int width,const char *function,const char *file,int line)
{
    DWORD a;
    char msg[320];
    if(!MMIO_TRACE_ENABLED || mmio_trace_busy) return;
    mmio_trace_busy=1;
    a=JTM_PTR_TO_DWORD(address);
    snprintf(msg,sizeof(msg),
             "[MMIO] %s%d addr=0x%x value=0x%x at %s %s:%d\n",
             op?op:"?",width,a,value,function?function:"?",file?file:"?",line);
    /* MMIO tracing is an explicit bring-up switch, so d0/jtmos_debug must not
     * silently suppress it.  Emergency serial is polled with a finite guard. */
    DebugSerialEmergencyWrite(msg);
    mmio_trace_busy=0;
}

void mmio_trace_mapping(DWORD physical,DWORD virtual_address,int pages)
{
    char msg[192];
    if(!MMIO_TRACE_ENABLED || mmio_trace_busy || pages<=0) return;
    mmio_trace_busy=1;
    snprintf(msg,sizeof(msg),
             "[MMIO] MAP phys=0x%x virt=0x%x pages=%d bytes=%u PTE=P|RW|PWT|PCD\n",
             physical,virtual_address,pages,(unsigned)((DWORD)pages*4096UL));
    DebugSerialEmergencyWrite(msg);
    mmio_trace_busy=0;
}
