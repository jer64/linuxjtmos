#ifndef __INCLUDED_LOCK_H__
#define __INCLUDED_LOCK_H__

/*
 * Cooperative kernel locks with call-site tracing.
 *
 * Every public acquisition macro automatically records the source function,
 * file and line.  The implementation keeps the owner PID, recursion depth and
 * acquisition timestamp so lock stalls can be reconstructed from dprintk.
 *
 * Rules:
 *  - never leak a changed EFLAGS.IF state to the caller;
 *  - IRQ/exception context with IF=0 must never task-switch;
 *  - a ring-3 system call also enters with IF=0, but may cooperatively
 *    task-switch through JTMOS' INT 0x7E task gate;
 *  - never yield while the storage-safe PIT mode has disabled the TSS scheduler;
 *  - keep ownership test/update atomic;
 *  - never call dprintk while interrupts are forcibly disabled by the lock code.
 */
#define JTMOS_LOCK_SPIN_LIMIT 1000000UL

/* Set to 0 when only contention/timeout diagnostics are wanted. */
#ifndef JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
#define JTMOS_LOCK_TRACE_ACQUIRE_RELEASE 1
#endif

/* Function-local state used by the historical LOCK / UNLOCK pair. */
typedef struct JTMOS_LOCK_STATE
{
    volatile int owner_pid;
    volatile unsigned long depth;
    const char *owner_function;
    const char *owner_file;
    int owner_line;
    DWORD acquired_ms;
} JTMOS_LOCK_STATE;

#define JTMOS_LOCK_STATE_INITIALIZER { -1, 0, 0, 0, 0, 0 }

int LockWaitCanYield(int saved_eflags);

void JtmosFunctionLockAcquire(JTMOS_LOCK_STATE *state,
                              const char *function,
                              const char *file,
                              int line);
void JtmosFunctionLockRelease(JTMOS_LOCK_STATE *state,
                              const char *function,
                              const char *file,
                              int line);

/* ID-based lock API.  LockAt/UnlockAt are the implementation entry points;
 * Lock/Unlock remain exported as legacy ABI symbols for old kernel objects. */
void LockAt(int lockID, const char *function, const char *file, int line);
void UnlockAt(int lockID, const char *function, const char *file, int line);
void Lock(int lockID);
void Unlock(int lockID);

#ifndef JTMOS_LOCK_IMPLEMENTATION
#define Lock(lockID) \
    LockAt((lockID), __FUNCTION__, __FILE__, __LINE__)
#define Unlock(lockID) \
    UnlockAt((lockID), __FUNCTION__, __FILE__, __LINE__)
#endif

/*
 * Historical function-local lock API.  Existing source code can keep writing:
 *
 *     LOCK
 *     ... protected code ...
 *     UNLOCK
 *
 * The static state belongs to that function exactly as before, but the actual
 * acquire/release logic and diagnostics now live in lock.c.
 */
#define LOCK \
    static JTMOS_LOCK_STATE __jtmos_function_lock = JTMOS_LOCK_STATE_INITIALIZER; \
    JtmosFunctionLockAcquire(&__jtmos_function_lock, \
                             __FUNCTION__, __FILE__, __LINE__);

#define UNLOCK \
    JtmosFunctionLockRelease(&__jtmos_function_lock, \
                             __FUNCTION__, __FILE__, __LINE__);

#endif
