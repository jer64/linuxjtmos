; JTMOS V65 userspace IRQ broker stubs.
; No userspace code is called here.  The C dispatcher only records an event
; and acknowledges the PIC; application handling happens after syscall return.
bits 32
section .text
extern userhw_irq_dispatch
extern storesegregs
extern restoresegregs
%include "core/int/segsave.mac"

%macro IRQ_STUB 1
global userirq_stub%1
userirq_stub%1:
    cld
    pushad
    S_SEGREGS
    mov ax,0x10
    mov ds,ax
    mov es,ax
    push dword %1
    call userhw_irq_dispatch
    add esp,4
    R_SEGREGS
    popad
    iret
%endmacro

IRQ_STUB 0
IRQ_STUB 1
IRQ_STUB 2
IRQ_STUB 3
IRQ_STUB 4
IRQ_STUB 5
IRQ_STUB 6
IRQ_STUB 7
IRQ_STUB 8
IRQ_STUB 9
IRQ_STUB 10
IRQ_STUB 11
IRQ_STUB 12
IRQ_STUB 13
IRQ_STUB 14
IRQ_STUB 15
