// Kernel debug functions.
// See also dfunc.c.
#include "kernel32.h"
#include "logging.h"

/*
 * V67.8.55: split ordinary serial diagnostics from the emergency crash path.
 *
 * Normal serial output is intentionally runtime-switchable because a polled
 * 115200-baud UART can dominate kernel execution time when verbose printk,
 * dprintk or ReportMessage traffic is mirrored one byte at a time.  The SMSH
 * `d0` command disables this normal path for performance testing.
 *
 * Fatal exception/panic reporting uses DebugSerialEmergency*() instead.  That
 * path deliberately ignores the runtime switch so a crash can still be
 * captured after `d0`.
 */
static int debug_uart_initialized = 0;
static int debug_uart_line = -2;
static volatile int debug_serial_runtime_enabled = 1;

static unsigned int DebugSerialBase(int line)
{
    switch(line)
    {
        case 0: return 0x3F8; /* COM1 */
        case 1: return 0x2F8; /* COM2 */
        case 2: return 0x3E8; /* COM3 */
        case 3: return 0x2E8; /* COM4 */
    }
    return 0;
}

void DebugSerialEarlyInit(void)
{
    unsigned int base;

    if(serial_debug_line < 0)
        return;

    base = DebugSerialBase(serial_debug_line);
    if(!base)
        return;

    if(debug_uart_initialized && debug_uart_line == serial_debug_line)
        return;

    /* Disable UART IRQs.  115200 baud, 8 data bits, no parity, one stop bit. */
    outportb(base + 1, 0x00);
    outportb(base + 3, 0x80);  /* DLAB */
    outportb(base + 0, 0x01);  /* divisor low: 115200 */
    outportb(base + 1, 0x00);  /* divisor high */
    outportb(base + 3, 0x03);  /* 8N1 */
    outportb(base + 2, 0xC7);  /* FIFO on/clear, 14-byte threshold */
    outportb(base + 4, 0x03);  /* DTR + RTS, no OUT2 IRQ gate */

    debug_uart_line = serial_debug_line;
    debug_uart_initialized = 1;
}

static void DebugSerialPutCharRaw(int ch)
{
    unsigned int base;
    unsigned long guard;

    if(serial_debug_line < 0)
        return;

    DebugSerialEarlyInit();
    base = DebugSerialBase(serial_debug_line);
    if(!base)
        return;

    if(ch == '\n')
        DebugSerialPutCharRaw('\r');

    /* Polled output with a finite guard: diagnostics must never deadlock. */
    for(guard = 0; guard < 1000000UL; guard++)
    {
        if(inportb(base + 5) & 0x20)
        {
            outportb(base, ch);
            return;
        }
    }
}

void DebugSerialSetRuntimeEnabled(int enabled)
{
    debug_serial_runtime_enabled = enabled ? 1 : 0;
}

int DebugSerialRuntimeEnabled(void)
{
    return debug_serial_runtime_enabled ? 1 : 0;
}

void DebugSerialPutChar(int ch)
{
    if(!debug_serial_runtime_enabled)
        return;
    DebugSerialPutCharRaw(ch);
}

void DebugSerialWrite(const char *s)
{
    if(!debug_serial_runtime_enabled || !s)
        return;
    while(*s)
        DebugSerialPutCharRaw((unsigned char)*s++);
}

void DebugSerialWriteHex32(DWORD value)
{
    static const char hex[] = "0123456789ABCDEF";
    int shift;

    if(!debug_serial_runtime_enabled)
        return;

    DebugSerialWrite("0x");
    for(shift=28; shift>=0; shift-=4)
        DebugSerialPutCharRaw(hex[(value >> shift) & 0x0F]);
}

/* Emergency crash-report path.  Deliberately bypasses the runtime d0 gate. */
void DebugSerialEmergencyPutChar(int ch)
{
    DebugSerialPutCharRaw(ch);
}

void DebugSerialEmergencyWrite(const char *s)
{
    if(!s)
        return;
    while(*s)
        DebugSerialPutCharRaw((unsigned char)*s++);
}

void DebugSerialEmergencyWriteHex32(DWORD value)
{
    static const char hex[] = "0123456789ABCDEF";
    int shift;

    DebugSerialEmergencyWrite("0x");
    for(shift=28; shift>=0; shift-=4)
        DebugSerialPutCharRaw(hex[(value >> shift) & 0x0F]);
}

//-----------------------------------------------------------------------------------------------
// Debug Output Character
void doch(int ch)
{
    DebugSerialPutChar(ch);
}

//-----------------------------------------------------------------------------------------------
// Send report message (debug level 2).
// Report output is intentionally routed only to the serial debug line.
int ReportMessage(const char *fmt, ...)
{
    va_list arg;
    int result;
    char tmp[1024];

    if(!debug2)
        return 1;
    if(!DebugSerialRuntimeEnabled() && !SystemLoggingStreamEnabled())
        return 1;

    va_start(arg, fmt);
    result=svprintf(tmp, fmt,arg);
    va_end(arg);

    if(DebugSerialRuntimeEnabled() && serial_debug_line >= 0)
        DebugSerialWrite(tmp);
    if(SystemLoggingStreamEnabled())
        WriteSystemLogStream("REPORT",tmp);

    return result;
}
