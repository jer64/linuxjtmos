//===================================================================
// intgdt.c
// llint.asm multithreading system
// (C) 2001-2008 by Jari Tuominen.
//===================================================================
#include "kernel32.h"
#include "int.h"
#include "intgdt.h"

//
void randomscreen(void)
{
	char *p;
	int i;

	//
	p=JTM_DWORD_TO_PTR(char,0xB8000);
	for(i=0; i<(80*25*2); i++) p[i]=i;
}

//
void OnAppThread(void)
{
	/* Historical debugger trap removed: a valid application descriptor must
	 * never stop the scheduler.  Keep the symbol for source compatibility. */
	dprintk("OnAppThread: legacy debug hook ignored.\n");
}

//
void update_gdt_for_appthread(void)
{
	DWORD *p,*p2;
	int i,i2,i3,i4;

	//
	i = nr_curthread;
	if(i<N_MAX_THREADS && i>=0)
	{
		// Get pointers
		p=    (DWORD *)&gdt_table->appcode32;
		p2=   (DWORD *)thread_codedescs;
		// Copy
		p[0]= p2[0 + i*2];
		p[1]= p2[1 + i*2];

		// Get pointers
		p=     (DWORD *)&gdt_table->appdata32;
		p2=    (DWORD *)thread_datadescs;
		// Copy
		p[0]=  p2[0 + i*2];
		p[1]=  p2[1 + i*2];

		/* The old OnAppThread() debug trap intentionally looped forever whenever
		 * an application data descriptor was present.  A valid descriptor is not
		 * an error; never stop the scheduler here. */
	}
	else
	{
		dprintk("update_gdt_for_appthread: refusing invalid thread index %d.\n",i);
		return;
	}
}

//



