//================================================================
// logging.c - JTMOS persistent system logging service.
//================================================================
#include "kernel32.h"
#include "logging.h"
#include "diskspace.h"

/* V68.179: system messages are queued in RAM and written in batches.  The
 * preferred persistent sink is hda1:/logs when hda1 exists and is JTMFS.
 * keropt.c can disable that preference and/or select another device root,
 * for example ram:/. */
#define LOG_SUBDIR "logs"
#define SYSLOG_NAME "system.log"
#define WWWLOG_NAME "www.log"
#define KLOGGER_PID_NAME "klogger.pid"
#define DISKSPACE_LOG_NAME "diskspace.log"
#define DISKSPACE_SAMPLE_INTERVAL 10UL
#define DISKSPACE_PERSIST_INTERVAL 60UL
#define DISKSPACE_LOG_MAX_BYTES (256*1024)
#define DISKSPACE_LOG_RESERVE_BYTES (64*1024UL)
#define SYSTEMLOG_FIFO_BYTES (256*1024)
#define SYSTEMLOG_CHUNK_BYTES 8192
#define SYSTEMLOG_PRESSURE_BYTES ((SYSTEMLOG_FIFO_BYTES*3)/4)
#define SYSTEMLOG_TARGET_RECHECK_SECONDS 30UL

THREAD LoggerThread;
FBUF SystemLog;
int system_logging=FALSE;
static volatile int logging_storage_ready=0;
static volatile int logging_writer_pid=0;
static volatile DWORD logging_dropped_bytes=0;
static int logging_root_dnr=-1;
static int logging_root_db=-1;
static int logging_target_is_hda1=0;
static DWORD logging_last_diskspace_sample=0;
static DWORD logging_last_diskspace_persist=0;
static DWORD logging_last_flush=0;
static DWORD logging_last_target_probe=0;
static char logging_dir_path[512];
static char logging_syslog_path[512];
static char logging_wwwlog_path[512];
static char logging_klogger_pid_path[512];
static char logging_diskspace_path[512];

static int logging_writer_enter(void)
{
    int flags,pid,ok=0;
    pid=GetCurrentThread();
    flags=get_eflags();
    disable();
    if(logging_writer_pid==0) {
        logging_writer_pid=pid;
        ok=1;
    }
    set_eflags(flags);
    return ok;
}

static void logging_writer_leave(void)
{
    int flags,pid;
    pid=GetCurrentThread();
    flags=get_eflags();
    disable();
    if(logging_writer_pid==pid) logging_writer_pid=0;
    set_eflags(flags);
}

static int logging_writer_is_current(void)
{
    return logging_writer_pid==GetCurrentThread();
}

static int logging_write_all(int fd,const BYTE *buf,int len)
{
    int done=0,rv;
    while(done<len) {
        rv=write(fd,(void *)(buf+done),len-done);
        if(rv<=0) return -1;
        done+=rv;
    }
    return 0;
}

static int logging_make_path(char *dst,unsigned int cap,const char *root,const char *leaf)
{
    unsigned int n;
    int rv;

    if(dst==NULL || cap<4 || root==NULL || !root[0] || leaf==NULL || !leaf[0])
        return -1;
    n=(unsigned int)strlen(root);
    if(root[n-1]=='/')
        rv=snprintf(dst,cap,"%s%s",root,leaf);
    else if(root[n-1]==':')
        rv=snprintf(dst,cap,"%s/%s",root,leaf);
    else
        rv=snprintf(dst,cap,"%s/%s",root,leaf);
    if(rv<0 || (unsigned int)rv>=cap) {
        dst[0]=0;
        return -1;
    }
    return 0;
}

static int logging_device_from_root(const char *root)
{
    char dev[32];
    const char *p;
    unsigned int n;

    if(root==NULL || !root[0]) return -1;
    p=strchr(root,':');
    if(p==NULL) p=strchr(root,'/');
    n=p ? (unsigned int)(p-root) : (unsigned int)strlen(root);
    if(n==0 || n>=sizeof(dev)) return -1;
    memcpy(dev,root,n);
    dev[n]=0;
    return driver_getdevicenrbyname(dev);
}

static int logging_build_target_paths(const char *root,
                                      char *dir,char *syslog,char *wwwlog,
                                      char *pidlog,char *disklog)
{
    if(logging_make_path(dir,512,root,LOG_SUBDIR)!=0) return -1;
    if(logging_make_path(syslog,512,dir,SYSLOG_NAME)!=0) return -1;
    if(logging_make_path(wwwlog,512,dir,WWWLOG_NAME)!=0) return -1;
    if(logging_make_path(pidlog,512,dir,KLOGGER_PID_NAME)!=0) return -1;
    if(logging_make_path(disklog,512,dir,DISKSPACE_LOG_NAME)!=0) return -1;
    return 0;
}

static void logging_publish_paths(void)
{
    /* Keep the environment in sync with the actually selected sink so shell
     * tools and userland see the same paths as KLOGGER. */
    (void)ksetglobalenv("LOG_DIR",logging_dir_path,1);
    (void)ksetglobalenv("SYSTEM_LOG",logging_syslog_path,1);
    (void)ksetglobalenv("WWW_LOG",logging_wwwlog_path,1);
}

static void logging_resume_file_debug_streams(void)
{
    /* SMSH autostart may have issued d0 to quiet the serial console.  Once a
     * filesystem sink is safe, collect DEBUG/REPORT into RAM again without
     * re-enabling console-to-UART mirroring. */
    jtmos_debug=1;
    debug2=1;
    glvar.debugMsg=1;
}

/* Activate one device-root target.  The root is expected to look like hda1:/
 * or ram:/.  A target is accepted only when the named device exists, reports
 * JTMFS ready, has a valid JTMFS root DB and permits append-open in /logs. */
static int logging_activate_root(const char *root,int is_hda1)
{
    char dir[512],syslog[512],wwwlog[512],pidlog[512],disklog[512];
    int dnr,db,fd,saved_dnr,saved_db;

    if(root==NULL || !root[0]) return -1;
    dnr=logging_device_from_root(root);
    if(!isValidDevice(dnr) || !jtmfs_isDriveReady(dnr)) return -1;
    db=jtmfs_getrootdir(dnr);
    if(db<=0 || db>=getsize(dnr)) return -1;
    if(logging_build_target_paths(root,dir,syslog,wwwlog,pidlog,disklog)!=0)
        return -1;
    if(!logging_writer_enter()) return -1;

    saved_dnr=GetCurrentDNR();
    saved_db=GetCurrentDB();
    SetThreadDNR(GetCurrentThread(),dnr);
    SetThreadDB(GetCurrentThread(),db);

    /* mkdir is intentionally idempotent here.  If /logs already exists it
     * may return an error; the append-open below is the authoritative test. */
    (void)mkdir(dir,0);
    fd=open(syslog,O_WRONLY|O_CREAT|O_APPEND);
    if(fd<0) {
        SetThreadDNR(GetCurrentThread(),saved_dnr);
        SetThreadDB(GetCurrentThread(),saved_db);
        logging_writer_leave();
        return -1;
    }
    close(fd);
    fd=open(wwwlog,O_WRONLY|O_CREAT|O_APPEND);
    if(fd>=0) close(fd);

    logging_root_dnr=dnr;
    logging_root_db=db;
    logging_target_is_hda1=is_hda1 ? 1 : 0;
    strcpy(logging_dir_path,dir);
    strcpy(logging_syslog_path,syslog);
    strcpy(logging_wwwlog_path,wwwlog);
    strcpy(logging_klogger_pid_path,pidlog);
    strcpy(logging_diskspace_path,disklog);
    logging_storage_ready=1;
    if(LoggerThread.pid>0) {
        SetThreadDNR(LoggerThread.pid,dnr);
        SetThreadDB(LoggerThread.pid,db);
    }

    SetThreadDNR(GetCurrentThread(),saved_dnr);
    SetThreadDB(GetCurrentThread(),saved_db);
    logging_writer_leave();

    logging_publish_paths();
    logging_resume_file_debug_streams();
    WriteSystemLog("============================================================");
    WriteSystemLog("JTMOS RAM-buffered system log activated.");
    if(is_hda1)
        WriteSystemLog("KLOGGER: hda1 is present and JTMFS; persistent target is hda1:/logs/system.log.");
    else
        WriteSystemLog("KLOGGER: using configured non-hda1 logging target.");
    return 0;
}

static int logging_try_activate_target(int allow_fallback)
{
    if(!SYSTEMLOGGING) return -1;

    if(SYSTEMLOGGING_HDA1) {
        if(logging_target_is_hda1 && logging_storage_ready) return 0;
        if(logging_activate_root("hda1:/",1)==0) return 0;
    }

    if(!allow_fallback) return -1;
    if(SYSTEMLOGGING_TARGET_ROOT!=NULL && SYSTEMLOGGING_TARGET_ROOT[0])
        return logging_activate_root(SYSTEMLOGGING_TARGET_ROOT,0);
    return -1;
}

void initSystemLog(void)
{
    if(system_logging || !SYSTEMLOGGING) return;
    CreateBuffer(&SystemLog,SYSTEMLOG_FIFO_BYTES);
    if(SystemLog.buf==NULL) {
        dprintk("initSystemLog: unable to allocate log FIFO.\n");
        return;
    }
    system_logging=TRUE;
}

int SystemLoggingStreamEnabled(void)
{
    return SYSTEMLOGGING && system_logging;
}

int SystemLoggingStorageIsReady(void)
{
    return logging_storage_ready ? 1 : 0;
}

/* Queue exact bytes.  This remains filesystem-independent: interrupt/debug
 * producers only touch the RAM FIFO.  KLOGGER is the sole filesystem writer. */
void WriteSystemLogRaw(const char *msg,int len)
{
    int i;
    if(!SYSTEMLOGGING || !system_logging || msg==NULL || len<=0) return;
    if(logging_writer_is_current()) return;
    for(i=0;i<len;i++) {
        if(PutBuffer(&SystemLog,(BYTE)msg[i])!=0)
            logging_dropped_bytes++;
    }
}

void WriteSystemLogStream(const char *channel,const char *msg)
{
    int l;
    if(msg==NULL || !SystemLoggingStreamEnabled()) return;
    if(channel!=NULL && channel[0]) {
        WriteSystemLogRaw("[",1);
        WriteSystemLogRaw(channel,(int)strlen(channel));
        WriteSystemLogRaw("] ",2);
    }
    l=(int)strlen(msg);
    WriteSystemLogRaw(msg,l);
    if(l<=0 || msg[l-1]!='\n') WriteSystemLogRaw("\n",1);
}

void WriteSystemLog(const char *msg)
{
    int l;
    if(msg==NULL || !SystemLoggingStreamEnabled()) return;
    l=(int)strlen(msg);
    WriteSystemLogRaw(msg,l);
    if(l<=0 || msg[l-1]!='\n') WriteSystemLogRaw("\n",1);
}

/* Drain the RAM FIFO to the selected JTMFS target. */
int SystemLogFlushNow(void)
{
    static BYTE buf[SYSTEMLOG_CHUNK_BYTES];
    char dropmsg[128];
    DWORD dropped;
    int fd,d,i,n,rv=0;
    int saved_dnr,saved_db,flags;

    if(!SYSTEMLOGGING || !system_logging || !logging_storage_ready)
        return 0;
    if(!logging_writer_enter())
        return 0;

    saved_dnr=GetCurrentDNR();
    saved_db=GetCurrentDB();
    if(isValidDevice(logging_root_dnr)) {
        SetThreadDNR(GetCurrentThread(),logging_root_dnr);
        SetThreadDB(GetCurrentThread(),logging_root_db);
    }

    /* O_WRONLY is required.  O_CREAT|O_APPEND alone has O_ACCMODE==O_RDONLY
     * in JTMOS and makes write() reject the descriptor with EBADF. */
    fd=open(logging_syslog_path,O_WRONLY|O_CREAT|O_APPEND);
    if(fd<0) {
        rv=-1;
        goto out;
    }

    flags=get_eflags();
    disable();
    dropped=logging_dropped_bytes;
    logging_dropped_bytes=0;
    set_eflags(flags);
    if(dropped) {
        n=sprintf(dropmsg,"[KLOGGER] FIFO overflow: %u byte(s) were dropped before flush.\n",
                  (unsigned)dropped);
        if(n>0 && logging_write_all(fd,(BYTE *)dropmsg,n)!=0) rv=-1;
    }

    while(rv==0) {
        i=0;
        while(i<(int)sizeof(buf)) {
            d=GetBuffer(&SystemLog);
            if(d<0) break;
            if(d!=0) buf[i++]=(BYTE)d;
        }
        if(i==0) break;
        if(logging_write_all(fd,buf,i)!=0) rv=-1;
    }
    close(fd);

out:
    SetThreadDNR(GetCurrentThread(),saved_dnr);
    SetThreadDB(GetCurrentThread(),saved_db);
    logging_writer_leave();
    return rv;
}

/* Called after SMSH has a writable JTMFS root.  That root does not need to be
 * the logging target: hda1:/ is preferred independently when it exists and is
 * JTMFS.  If it is absent, SYSTEMLOGGING_TARGET_ROOT is used (ram:/ by
 * default). */
void SystemLoggingStorageReady(void)
{
    if(!SYSTEMLOGGING) { systemStarted|=2; return; }
    initSystemLog();
    if(system_logging)
        (void)logging_try_activate_target(1);
    systemStarted|=2;
}

void WriteWWWLog(const char *msg)
{
    int fd,saved_dnr,saved_db;
    if(!SYSTEMLOGGING || !logging_storage_ready || msg==NULL) return;
    if(!logging_writer_enter()) return;
    saved_dnr=GetCurrentDNR();
    saved_db=GetCurrentDB();
    if(isValidDevice(logging_root_dnr)) {
        SetThreadDNR(GetCurrentThread(),logging_root_dnr);
        SetThreadDB(GetCurrentThread(),logging_root_db);
    }
    fd=open(logging_wwwlog_path,O_WRONLY|O_CREAT|O_APPEND);
    if(fd>=0) {
        (void)logging_write_all(fd,(const BYTE *)msg,(int)strlen(msg));
        (void)logging_write_all(fd,(const BYTE *)"\n",1);
        close(fd);
    }
    SetThreadDNR(GetCurrentThread(),saved_dnr);
    SetThreadDB(GetCurrentThread(),saved_db);
    logging_writer_leave();
}

/* Persist the in-kernel block-device table as a compact rolling audit.
 * Keep 64 KiB of emergency headroom so diagnostics never become the writer
 * that consumes the final filesystem allocation units. */
static int SystemDiskSpacePersistNow(void)
{
    JTMOS_DISKSPACE_STATS st;
    unsigned long long free_bytes;
    int fd,end,saved_dnr,saved_db,rv=0;

    if(!SYSTEMLOGGING || !logging_storage_ready || !isValidDevice(logging_root_dnr))
        return 0;
    if(DiskSpaceGetStats(logging_root_dnr,&st,1)==0 &&
       (st.flags&DISKSPACE_FLAG_JTMFS))
    {
        free_bytes=(unsigned long long)st.free_units*(unsigned long long)st.unit_size;
        if(free_bytes<DISKSPACE_LOG_RESERVE_BYTES) return -ENOSPC;
    }
    if(!logging_writer_enter()) return 0;

    saved_dnr=GetCurrentDNR();
    saved_db=GetCurrentDB();
    SetThreadDNR(GetCurrentThread(),logging_root_dnr);
    SetThreadDB(GetCurrentThread(),logging_root_db);

    fd=open(logging_diskspace_path,O_WRONLY|O_CREAT|O_APPEND);
    if(fd<0) { rv=-1; goto out; }
    end=lseek(fd,0,SEEK_END);
    if(end>DISKSPACE_LOG_MAX_BYTES)
    {
        close(fd);
        fd=open(logging_diskspace_path,O_WRONLY|O_CREAT|O_TRUNC);
        if(fd<0) { rv=-1; goto out; }
    }
    if(DiskSpaceWriteSnapshot(fd)!=0) rv=-1;
    close(fd);

out:
    SetThreadDNR(GetCurrentThread(),saved_dnr);
    SetThreadDB(GetCurrentThread(),saved_db);
    logging_writer_leave();
    return rv;
}

void initSystemLogging(void)
{
    if(!SYSTEMLOGGING) return;
    initSystemLog();
    if(!system_logging) return;
    ThreadCreateStack(&LoggerThread,JTMOS_MIN_DYNAMIC_STACK);
    LoggerThread.pid=create_thread(LoggerThread.stack,LoggerThread.l_stack,LoggerThreadProgram);
    if(LoggerThread.pid>0) IdentifyThread(LoggerThread.pid,"KLOGGER");
}

void LoggerThreadProgram(void)
{
    int saved_dnr,saved_db,fd,flush_seconds;
    DWORD now;

    initSystemLog();
    if(!SYSTEMLOGGING) ExitThread(0);

    /* Storage may become writable after KLOGGER starts.  Retry target probing
     * instead of permanently depending on the instant SystemLoggingStorageReady
     * happened to run. */
    while(!logging_storage_ready) {
        (void)logging_try_activate_target(1);
        if(!logging_storage_ready) sleep(1);
    }

    if(isValidDevice(logging_root_dnr)) {
        SetThreadDNR(GetCurrentThread(),logging_root_dnr);
        SetThreadDB(GetCurrentThread(),logging_root_db);
    }
    WriteSystemLog("System started.");
    WriteSystemLog("KLOGGER: RAM FIFO -> selected /logs target.");

    saved_dnr=GetCurrentDNR();
    saved_db=GetCurrentDB();
    if(logging_writer_enter()) {
        fd=open(logging_klogger_pid_path,O_WRONLY|O_CREAT|O_APPEND);
        if(fd>=0) close(fd);
        logging_writer_leave();
    }
    SetThreadDNR(GetCurrentThread(),saved_dnr);
    SetThreadDB(GetCurrentThread(),saved_db);

    now=(DWORD)GetSeconds();
    logging_last_flush=now;
    logging_last_target_probe=now;

    while(1) {
        now=(DWORD)GetSeconds();
        flush_seconds=SYSTEMLOGGING_FLUSH_SECONDS;
        if(flush_seconds<1) flush_seconds=1;

        /* If boot initially had only ram:/, promote future RAM-buffer flushes
         * to hda1:/logs as soon as hda1 appears as a valid JTMFS partition.
         * Likewise, if hda1 preference is disabled, honor the configured root. */
        if(now-logging_last_target_probe>=SYSTEMLOG_TARGET_RECHECK_SECONDS) {
            if(SYSTEMLOGGING_HDA1 && !logging_target_is_hda1)
                (void)logging_try_activate_target(0);
            else if(!SYSTEMLOGGING_HDA1 && logging_target_is_hda1)
                (void)logging_try_activate_target(1);
            logging_last_target_probe=now;
        }

        /* Normal persistence is a roughly 30-second batch.  Under unusually
         * heavy debug traffic flush early at 75% FIFO occupancy rather than
         * dropping diagnostics. */
        if(SystemLog.count>=SYSTEMLOG_PRESSURE_BYTES ||
           now-logging_last_flush>=(DWORD)flush_seconds) {
            (void)SystemLogFlushNow();
            logging_last_flush=now;
        }

        if(now-logging_last_diskspace_sample>=DISKSPACE_SAMPLE_INTERVAL) {
            DiskSpacePeriodicSample();
            logging_last_diskspace_sample=now;
        }
        if(now-logging_last_diskspace_persist>=DISKSPACE_PERSIST_INTERVAL) {
            (void)SystemDiskSpacePersistNow();
            logging_last_diskspace_persist=now;
        }
        sleep(1);
    }
}
