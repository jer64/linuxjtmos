//=====================================================
// JTMOS THREADS - IdleThread.
// (C) 2001-2005 by Jari Tuominen.
//=====================================================
#include "cpu.h"
#include "kernel32.h"
#include "threads.h"
#include "IdleThread.h"

//
DWORD IdleThreadCounter=0;
//
THREAD IdleThread;

// Creates an idle thread
void init_IdleThread(void)
{
	//
	ThreadCreateStack(&IdleThread, JTMOS_MIN_DYNAMIC_STACK);
	IdleThread.pid = 
		create_thread(IdleThread.stack,
			IdleThread.l_stack, IdleThreadProgram);

	// max. 31 characters.
	IdentifyThread(IdleThread.pid, "CPU_IDLE");

	// Idle thread should be immortal.
	Immortal(IdleThread.pid);
}

//
void IdleThreadProgram(void)
{
	/*
	 * True CPU idle loop. SchedulerIdleWait() performs the V68.178
	 * 512-entry HLT burst (8x the previous 64-entry burst).  IRQ0 and device IRQs remain enabled throughout,
	 * so real work can preempt CPU_IDLE immediately while QEMU/real hardware
	 * spends the idle interval in the processor's HLT state.
	 */
	IdleThreadCounter=0;
	for(;;)
	{
		IdleThreadCounter++;
		SchedulerIdleWait();
	}
}

//

