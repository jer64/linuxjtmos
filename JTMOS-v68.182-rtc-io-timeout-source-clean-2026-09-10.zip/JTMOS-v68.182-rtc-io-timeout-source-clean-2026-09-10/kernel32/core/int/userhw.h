#ifndef __JTMOS_USERHW_H__
#define __JTMOS_USERHW_H__

#include "basdef.h"

/* V65 safe userspace hardware broker.
 * Hardware IRQ code always runs in kernel context. Applications receive
 * pending IRQ events from normal syscall context and therefore never run
 * application callbacks on an interrupt stack. */
#define JTMOS_IRQ_WAIT_FOREVER 0xffffffffUL
#define JTMOS_DMA_MAX_BYTES    65536UL
#define JTMOS_DMA_MAX_SLOTS    32

typedef struct {
    DWORD handle;
    DWORD address;
    DWORD physical_address;
    DWORD size;
} JTMOS_DMA_BUFFER_K;

int userhw_irq_subscribe(int owner, int irq, DWORD flags);
int userhw_irq_unsubscribe(int owner, DWORD handle);
int userhw_irq_wait(int owner, DWORD handle, DWORD timeout_ms);
void userhw_irq_dispatch(int irq);

int userhw_dma_alloc(int owner, DWORD bytes, DWORD flags, JTMOS_DMA_BUFFER_K *out);
int userhw_dma_free(int owner, DWORD handle);
int userhw_dma_program(int owner, DWORD handle, int channel, DWORD length, int direction);
int userhw_dma_stop(int owner, DWORD handle, int channel);
DWORD userhw_dma_translate(int owner, DWORD user_address);
DWORD userhw_dma_translate_range(int owner, DWORD user_address, DWORD length);
DWORD userhw_dma_alloc_kernel(DWORD bytes, DWORD *physical_address);
DWORD userhw_dma_alloc_kernel32(DWORD bytes, DWORD *physical_address);
int userhw_dma_verify_kernel32(DWORD kernel_address, DWORD physical_address, DWORD bytes);

/* Reclaims subscriptions, channel claims and DMA mappings when a process dies. */
void userhw_release_pid(int owner);

#endif
