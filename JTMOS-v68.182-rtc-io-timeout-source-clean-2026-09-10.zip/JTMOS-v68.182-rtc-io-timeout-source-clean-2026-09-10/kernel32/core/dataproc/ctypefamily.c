// ctypefamily.c - small freestanding ctype implementation for JTMOS kernel
#include "ctypefamily.h"

static int jt_is_byte(int c)
{
    return c>=0 && c<=255;
}

static int jt_is_finnish_upper(int c)
{
    unsigned int ch;
    if(!jt_is_byte(c)) return 0;
    ch=(unsigned int)c;
    return ch==0xC4U || ch==0xC5U || ch==0xD6U; /* Ä Å Ö */
}

static int jt_is_finnish_lower(int c)
{
    unsigned int ch;
    if(!jt_is_byte(c)) return 0;
    ch=(unsigned int)c;
    return ch==0xE4U || ch==0xE5U || ch==0xF6U; /* ä å ö */
}

int tolower(int c)
{
    unsigned int ch;
    if(!jt_is_byte(c)) return c;
    ch=(unsigned int)c;
    if(ch>='A' && ch<='Z') return (int)(ch+('a'-'A'));
    if(ch==0xC4U) return 0xE4;
    if(ch==0xC5U) return 0xE5;
    if(ch==0xD6U) return 0xF6;
    return c;
}

int toupper(int c)
{
    unsigned int ch;
    if(!jt_is_byte(c)) return c;
    ch=(unsigned int)c;
    if(ch>='a' && ch<='z') return (int)(ch-('a'-'A'));
    if(ch==0xE4U) return 0xC4;
    if(ch==0xE5U) return 0xC5;
    if(ch==0xF6U) return 0xD6;
    return c;
}

int isupper(int c)
{
    unsigned int ch;
    if(!jt_is_byte(c)) return 0;
    ch=(unsigned int)c;
    return (ch>='A' && ch<='Z') || jt_is_finnish_upper(c);
}

int islower(int c)
{
    unsigned int ch;
    if(!jt_is_byte(c)) return 0;
    ch=(unsigned int)c;
    return (ch>='a' && ch<='z') || jt_is_finnish_lower(c);
}

int isalpha(int c)
{
    return isupper(c) || islower(c);
}

int isdigit(int c)
{
    unsigned int ch;
    if(!jt_is_byte(c)) return 0;
    ch=(unsigned int)c;
    return ch>='0' && ch<='9';
}

int isalnum(int c)
{
    return isalpha(c) || isdigit(c);
}

int isxdigit(int c)
{
    unsigned int ch;
    if(!jt_is_byte(c)) return 0;
    ch=(unsigned int)c;
    return (ch>='0' && ch<='9') || (ch>='a' && ch<='f') ||
           (ch>='A' && ch<='F');
}

int isspace(int c)
{
    unsigned int ch;
    if(!jt_is_byte(c)) return 0;
    ch=(unsigned int)c;
    return ch==' ' || ch=='\t' || ch=='\n' || ch=='\r' ||
           ch=='\v' || ch=='\f';
}

int iscntrl(int c)
{
    unsigned int ch;
    if(!jt_is_byte(c)) return 0;
    ch=(unsigned int)c;
    return ch<0x20U || ch==0x7fU;
}

int isprint(int c)
{
    unsigned int ch;
    if(!jt_is_byte(c)) return 0;
    ch=(unsigned int)c;
    /* ASCII printable plus the printable high-byte console/Latin-1 range. */
    return (ch>=0x20U && ch<=0x7eU) || ch>=0xa0U;
}

int isgraph(int c)
{
    return isprint(c) && !isspace(c);
}

int ispunct(int c)
{
    return isgraph(c) && !isalnum(c);
}
