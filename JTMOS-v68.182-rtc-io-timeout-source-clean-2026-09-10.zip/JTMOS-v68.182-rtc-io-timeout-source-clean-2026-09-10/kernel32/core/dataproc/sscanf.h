#ifndef __JTMOS_SSCANF_H__
#define __JTMOS_SSCANF_H__

#include "basdef.h"
#include "stdarg.h"

int sscanf(const char *s,const char *fmt, ...);
int svscanf(const char *s,const char *fmt, va_list arg);

#endif
