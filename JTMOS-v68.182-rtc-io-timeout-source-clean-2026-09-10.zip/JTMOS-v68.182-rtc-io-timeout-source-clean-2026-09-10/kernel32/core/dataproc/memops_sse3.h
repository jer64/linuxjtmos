#ifndef JTMOS_MEMOPS_SSE3_H
#define JTMOS_MEMOPS_SSE3_H
#include <stdio.h>
void *jtmos_memcpy_sse3(void *dst,const void *src,size_t len);
void *jtmos_memset_sse3(void *dst,int c,size_t len);
#endif
