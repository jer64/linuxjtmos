// sscanf.c - compact freestanding scanner for the JTMOS i386 kernel
#include <stdio.h>
#include "sscanf.h"
#include "string.h"
#include "ctypefamily.h"

#define JT_SCAN_MAX_WIDTH 0x7fffffff

static int jt_digit_value(int c,int base)
{
    int d;
    if(c>='0' && c<='9') d=c-'0';
    else if(c>='a' && c<='f') d=c-'a'+10;
    else if(c>='A' && c<='F') d=c-'A'+10;
    else return -1;
    return d<base ? d : -1;
}

static int jt_scan_uint(const char **input,int width,int base,DWORD *out,int *negative)
{
    const char *s=*input;
    DWORD value=0;
    int used=0;
    int digits=0;
    int d;
    int neg=0;

    if(width<=0) return 0;
    if((*s=='+' || *s=='-') && used<width) {
        neg=(*s=='-');
        s++; used++;
    }
    if(base==0) {
        if(used+2<width && s[0]=='0' && (s[1]=='x' || s[1]=='X') &&
           jt_digit_value((unsigned char)s[2],16)>=0)
            base=16;
        else if(*s=='0')
            base=8;
        else
            base=10;
    }
    if(base==16 && used+2<width && s[0]=='0' && (s[1]=='x' || s[1]=='X') &&
       jt_digit_value((unsigned char)s[2],16)>=0) {
        s+=2; used+=2;
    }
    while(*s && used<width) {
        d=jt_digit_value((unsigned char)*s,base);
        if(d<0) break;
        if(value>(0xFFFFFFFFUL-(DWORD)d)/(DWORD)base) return 0;
        value=value*(DWORD)base+(DWORD)d;
        s++; used++; digits++;
    }
    if(!digits) return 0;
    *input=s;
    *out=value;
    if(negative) *negative=neg;
    return 1;
}

int sscanf(const char *s,const char *fmt,...)
{
    va_list arg;
    int result;
    va_start(arg,fmt);
    result=svscanf(s,fmt,arg);
    va_end(arg);
    return result;
}

int svscanf(const char *ss,const char *fmt,va_list arg)
{
    const char *s=ss;
    int assigned=0;
    int suppress;
    int width;
    int long_count;
    int spec;
    int n;
    int neg;
    DWORD value;
    char *dst;
    char *end;
    double dv;

    if(!s || !fmt) return 0;

    while(*fmt) {
        if(isspace((unsigned char)*fmt)) {
            while(isspace((unsigned char)*fmt)) fmt++;
            while(isspace((unsigned char)*s)) s++;
            continue;
        }

        if(*fmt!='%') {
            if(*s!=*fmt) break;
            s++; fmt++;
            continue;
        }
        fmt++;
        if(*fmt=='%') {
            if(*s!='%') break;
            s++; fmt++;
            continue;
        }

        suppress=0;
        if(*fmt=='*') { suppress=1; fmt++; }

        width=0;
        while(isdigit((unsigned char)*fmt)) {
            if(width<JT_SCAN_MAX_WIDTH/10)
                width=width*10+(*fmt-'0');
            fmt++;
        }
        if(width==0) width=JT_SCAN_MAX_WIDTH;

        long_count=0;
        while(*fmt=='l' || *fmt=='L') {
            long_count++;
            fmt++;
        }
        spec=(unsigned char)*fmt;
        if(!spec) break;
        fmt++;

        if(spec!='c')
            while(isspace((unsigned char)*s)) s++;

        if(spec=='s') {
            if(!*s) break;
            n=0;
            dst=suppress ? NULL : va_arg(arg,char *);
            while(*s && !isspace((unsigned char)*s) && n<width) {
                if(dst) dst[n]=*s;
                s++; n++;
            }
            if(n==0) break;
            if(dst) { dst[n]=0; assigned++; }
        } else if(spec=='c') {
            n=(width==JT_SCAN_MAX_WIDTH)?1:width;
            if(n<=0) break;
            dst=suppress ? NULL : va_arg(arg,char *);
            width=n;
            while(n>0 && *s) {
                if(dst) *dst++=*s;
                s++; n--;
            }
            if(n!=0) break;
            if(!suppress) assigned++;
        } else if(spec=='d' || spec=='i' || spec=='u' || spec=='x' || spec=='X') {
            int base=(spec=='x' || spec=='X')?16:(spec=='i'?0:10);
            neg=0;
            if(!jt_scan_uint(&s,width,base,&value,&neg)) break;
            if(!suppress) {
                if(spec=='d' || spec=='i') {
                    int signed_value;
                    if(neg) signed_value=(int)(0U-(unsigned int)value);
                    else signed_value=(int)value;
                    if(long_count) *va_arg(arg,long *)=(long)signed_value;
                    else *va_arg(arg,int *)=signed_value;
                } else {
                    DWORD unsigned_value=neg ? (DWORD)(0UL-value) : value;
                    if(long_count) *va_arg(arg,unsigned long *)=(unsigned long)unsigned_value;
                    else *va_arg(arg,DWORD *)=unsigned_value;
                }
                assigned++;
            }
        } else if(spec=='f' || spec=='e' || spec=='E' || spec=='g' || spec=='G') {
            /* strtod already stops at the first non-number.  Width-limited
             * floating scans are uncommon in JTMOS; honor unlimited/default
             * widths and reject a zero-length conversion. */
            dv=strtod(s,&end);
            if(end==s) break;
            if(width!=JT_SCAN_MAX_WIDTH && end-s>width) break;
            s=end;
            if(!suppress) {
                if(long_count) *va_arg(arg,double *)=dv;
                else *va_arg(arg,float *)=(float)dv;
                assigned++;
            }
        } else {
            break;
        }
    }
    return assigned;
}
