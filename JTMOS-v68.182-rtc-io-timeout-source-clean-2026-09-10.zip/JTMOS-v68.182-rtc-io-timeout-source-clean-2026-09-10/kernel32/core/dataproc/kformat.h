#ifndef __JTMOS_KFORMAT_H__
#define __JTMOS_KFORMAT_H__

#include "stdarg.h"

typedef void (*jt_format_emit_fn)(void *context, char ch);

/*
 * Small 32-bit kernel formatter shared by printk/printf and sprintf.
 * JTMOS/i386 uses 32-bit int, long, size_t and pointers.  The parser accepts
 * the common C flags, field width, precision and the h/l/z/t modifiers so a
 * format such as "%lu" or "%08lx" is consumed as one conversion instead of
 * leaking "lu"/"08lx" to the terminal.
 */
int jt_vformat(jt_format_emit_fn emit, void *context,
               const char *format, va_list args);

#endif
