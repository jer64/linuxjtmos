#include "strchr.h"

char *strchr(const char *s, int c)
{
    unsigned char wanted=(unsigned char)c;
    const unsigned char *p=(const unsigned char *)s;
    if(!p) return (char *)0;
    for(;;p++) {
        if(*p==wanted) return (char *)p;
        if(*p==0) return (char *)0;
    }
}
