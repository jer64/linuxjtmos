/* Optional SSE3 bulk memory paths.  The containing kernel is still built with
 * -march=i486.  GCC target attributes confine SIMD opcodes to these functions,
 * and callers execute them only after cpuEarlyInit() enabled OS XMM support.
 *
 * Kernel code may run asynchronously with respect to userspace, so preserve
 * every XMM register touched here. */
#include <stdio.h>
#include "memops_sse3.h"

#if defined(__GNUC__)
#define SSE3_FN __attribute__((target("sse3"),noinline))
#else
#define SSE3_FN
#endif

SSE3_FN void *jtmos_memcpy_sse3(void *dst,const void *src,size_t len)
{
    unsigned char xmm_save[64] __attribute__((aligned(16)));
    unsigned char *d=(unsigned char *)dst;
    const unsigned char *s=(const unsigned char *)src;
    void *ret=dst;

    __asm__ __volatile__(
        "movdqu %%xmm0,  0(%0)\n\t"
        "movdqu %%xmm1, 16(%0)\n\t"
        "movdqu %%xmm2, 32(%0)\n\t"
        "movdqu %%xmm3, 48(%0)\n\t"
        : : "r"(xmm_save) : "memory");

    while(len>=64)
    {
        __asm__ __volatile__(
            "lddqu   0(%0), %%xmm0\n\t"
            "lddqu  16(%0), %%xmm1\n\t"
            "lddqu  32(%0), %%xmm2\n\t"
            "lddqu  48(%0), %%xmm3\n\t"
            "movdqu %%xmm0,  0(%1)\n\t"
            "movdqu %%xmm1, 16(%1)\n\t"
            "movdqu %%xmm2, 32(%1)\n\t"
            "movdqu %%xmm3, 48(%1)\n\t"
            : : "r"(s), "r"(d)
            : "xmm0","xmm1","xmm2","xmm3","memory");
        s+=64; d+=64; len-=64;
    }
    while(len--) *d++=*s++;

    __asm__ __volatile__(
        "movdqu  0(%0), %%xmm0\n\t"
        "movdqu 16(%0), %%xmm1\n\t"
        "movdqu 32(%0), %%xmm2\n\t"
        "movdqu 48(%0), %%xmm3\n\t"
        : : "r"(xmm_save)
        : "xmm0","xmm1","xmm2","xmm3","memory");
    return ret;
}

SSE3_FN void *jtmos_memset_sse3(void *dst,int c,size_t len)
{
    unsigned char xmm_save[16] __attribute__((aligned(16)));
    unsigned char *d=(unsigned char *)dst;
    void *ret=dst;
    unsigned long pattern=(unsigned char)c;
    pattern|=pattern<<8; pattern|=pattern<<16;

    __asm__ __volatile__("movdqu %%xmm0,(%0)" : : "r"(xmm_save) : "memory");
    __asm__ __volatile__(
        "movd %0,%%xmm0\n\t"
        "pshufd $0,%%xmm0,%%xmm0\n\t"
        : : "r"(pattern) : "xmm0");

    while(len>=64)
    {
        __asm__ __volatile__(
            "movdqu %%xmm0, 0(%0)\n\t"
            "movdqu %%xmm0,16(%0)\n\t"
            "movdqu %%xmm0,32(%0)\n\t"
            "movdqu %%xmm0,48(%0)\n\t"
            : : "r"(d) : "memory");
        d+=64; len-=64;
    }
    while(len--) *d++=(unsigned char)c;
    __asm__ __volatile__("movdqu (%0),%%xmm0" : : "r"(xmm_save) : "xmm0","memory");
    return ret;
}
