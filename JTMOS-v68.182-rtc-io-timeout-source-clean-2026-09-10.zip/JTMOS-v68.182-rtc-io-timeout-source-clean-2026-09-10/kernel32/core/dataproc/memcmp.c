#include "kernel32.h"

int memcmp(const void *a, const void *b, size_t n)
{
    const unsigned char *pa = (const unsigned char *)a;
    const unsigned char *pb = (const unsigned char *)b;
    size_t i;

    for(i = 0; i < n; ++i)
    {
        if(pa[i] != pb[i])
            return (int)pa[i] - (int)pb[i];
    }
    return 0;
}
