#include <stdio.h>
#include "strtok_r.h"

char *__strtok_r(char *s, const char *delim, char **save_ptr)
{
    char *end;
    if(!delim || !save_ptr) return NULL;
    if(s==NULL) s=*save_ptr;
    if(s==NULL) return NULL;

    s += strspn(s,delim);
    if(*s=='\0') {
        *save_ptr=s;
        return NULL;
    }

    end=s+strcspn(s,delim);
    if(*end=='\0') {
        *save_ptr=end;
        return s;
    }
    *end='\0';
    *save_ptr=end+1;
    return s;
}

char *strtok_r(char *s, const char *delim, char **save_ptr)
{
    return __strtok_r(s,delim,save_ptr);
}
