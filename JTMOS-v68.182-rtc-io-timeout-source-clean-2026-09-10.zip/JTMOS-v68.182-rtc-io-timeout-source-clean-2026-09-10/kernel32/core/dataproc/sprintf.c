// sprintf.c
// V68.135: add C99-style snprintf()/vsnprintf() for the kernel.
// V67.8.48: shares the same format parser as printk/printf.
#include "kernel32.h"
#include "stdarg.h"
#include "sprintf.h"
#include "kformat.h"

#define JTM_SPRINTF_UNBOUNDED 0x7fffffffUL

typedef struct jt_string_output {
    char *buffer;
    unsigned long capacity;
    unsigned long position;
} jt_string_output;

static void jt_string_emit(void *context, char ch)
{
    jt_string_output *out;
    out = (jt_string_output *)context;

    /* Keep one byte for the terminating NUL.  position always counts the
     * characters that would have been produced, even after truncation. */
    if(out->buffer && out->capacity > 0UL &&
       out->position < out->capacity - 1UL)
        out->buffer[out->position] = ch;
    out->position++;
}

/*
 * Kernel string formatter used by sprintf/snprintf variants.
 *
 * snprintf semantics intentionally match C99/POSIX:
 *   - at most capacity-1 bytes are stored;
 *   - a NUL is stored whenever capacity is non-zero;
 *   - the return value is the number of bytes that would have been written,
 *     excluding the terminating NUL;
 *   - buffer may be NULL when capacity == 0, which allows size probing.
 *
 * A NULL buffer with non-zero capacity is rejected defensively instead of
 * faulting the kernel.
 */
static int jt_vsnprintf_kernel(char *s, unsigned long capacity,
                               const char *fmt, va_list arg)
{
    jt_string_output out;
    int result;

    if(!fmt)
        return -1;
    if(!s && capacity != 0UL)
        return -1;

    out.buffer = s;
    out.capacity = capacity;
    out.position = 0UL;

    if(s && capacity > 0UL)
        s[0] = 0;

    result = jt_vformat(jt_string_emit, &out, fmt, arg);

    if(s && capacity > 0UL) {
        if(out.position < out.capacity)
            s[out.position] = 0;
        else
            s[out.capacity - 1UL] = 0;
    }

    return result;
}

int snprintf(char *s, unsigned long capacity, const char *fmt, ...)
{
    va_list arg;
    int result;

    va_start(arg, fmt);
    result = jt_vsnprintf_kernel(s, capacity, fmt, arg);
    va_end(arg);
    return result;
}

int vsnprintf(char *s, unsigned long capacity, const char *fmt, va_list arg)
{
    return jt_vsnprintf_kernel(s, capacity, fmt, arg);
}

int sprintf(char *s, const char *fmt, ...)
{
    va_list arg;
    int result;

    va_start(arg, fmt);
    result = svprintf(s, fmt, arg);
    va_end(arg);
    return result;
}

int svprintf(char *s, const char *fmt, va_list arg)
{
    return jt_vsnprintf_kernel(s, JTM_SPRINTF_UNBOUNDED, fmt, arg);
}

int _vsprintf(char *s, const char *fmt, va_list arg, int max_len)
{
    /* Preserve the historical private helper's invalid-length behaviour. */
    if(max_len <= 0)
        return 0;
    return jt_vsnprintf_kernel(s, (unsigned long)max_len, fmt, arg);
}
