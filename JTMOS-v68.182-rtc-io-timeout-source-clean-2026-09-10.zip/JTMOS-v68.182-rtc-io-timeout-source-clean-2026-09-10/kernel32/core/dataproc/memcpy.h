//
#ifndef __INCLUDED_JTM_MEMCPY_H__
#define __INCLUDED_JTM_MEMCPY_H__

//
void dmemset(char *buf,char ch,int length,
        const char *fun);
void *dmemcpy(void *o,const void *s,DWORD l,
        const char *fun);
void *xmemcpy(void *o,const void *s,DWORD length);
void *memmove(void *o,const void *s,DWORD length);
void xmemset(char *buf,char ch,int length);
void *memset(void *dst,int c,size_t len);
#define memcpy(o,s,l) dmemcpy(o,s,l,  __FUNCTION__)
        // See memset.c:
//#define memset(q1,q2,q3) dmemset(q1,q2,q3,  __FUNCTION__)
int illegal(const void *ad);

#endif




