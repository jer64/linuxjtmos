/*
 * JTMOS kernel printf-format core.
 *
 * This deliberately stays freestanding and 32-bit.  It is used by both
 * console printf/printk and string formatting so the two paths understand
 * exactly the same format language.
 */
#include "kernel32.h"
#include "stdarg.h"
#include "kformat.h"
#include "memcpy.h"

#define JTM_FORMAT_SANE_LIMIT 10000

static int jt_u32toa(char *dst, DWORD value, unsigned base, int upper)
{
    char rev[33];
    const char *digits;
    int n, i;

    digits = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    n = 0;
    do {
        rev[n++] = digits[value % base];
        value /= base;
    } while(value != 0 && n < (int)sizeof(rev));

    for(i=0; i<n; i++)
        dst[i] = rev[n-1-i];
    dst[n] = 0;
    return n;
}

static int jt_text_len(const char *s, int precision)
{
    int n;
    n = 0;
    while(s[n] && (precision < 0 || n < precision))
        n++;
    return n;
}

static void jt_emit_repeat(jt_format_emit_fn emit, void *context,
                           char ch, int count, int *written)
{
    while(count-- > 0) {
        emit(context, ch);
        (*written)++;
    }
}

static void jt_emit_text(jt_format_emit_fn emit, void *context,
                         const char *text, int length, int *written)
{
    int i;
    for(i=0; i<length; i++) {
        emit(context, text[i]);
        (*written)++;
    }
}

int jt_vformat(jt_format_emit_fn emit, void *context,
               const char *format, va_list args)
{
    const char *f;
    int scanned, written;

    if(!emit || !format)
        return 0;

    f = format;
    scanned = 0;
    written = 0;

    while(*f && scanned < JTM_FORMAT_SANE_LIMIT) {
        int left, plus, space, alt, zero;
        int width, precision;
        int long_count, short_count;
        char spec;
        char number[40];
        const char *text;
        int text_len, numeric, negative;
        int base, upper;
        DWORD value;
        char sign;
        char prefix[2];
        int prefix_len, precision_zeroes, pad;
        int core_len;

        scanned++;
        if(*f != '%') {
            emit(context, *f++);
            written++;
            continue;
        }

        f++;
        if(*f == '%') {
            emit(context, '%');
            written++;
            f++;
            continue;
        }
        if(*f == 0) {
            emit(context, '%');
            written++;
            break;
        }

        left = plus = space = alt = zero = 0;
        width = 0;
        precision = -1;
        long_count = short_count = 0;

        for(;;) {
            if(*f == '-') left = 1;
            else if(*f == '+') plus = 1;
            else if(*f == ' ') space = 1;
            else if(*f == '#') alt = 1;
            else if(*f == '0') zero = 1;
            else break;
            f++;
        }

        if(*f == '*') {
            width = va_arg(args, int);
            if(width < 0) {
                left = 1;
                width = -width;
            }
            f++;
        } else {
            while(*f >= '0' && *f <= '9') {
                width = width * 10 + (*f - '0');
                f++;
            }
        }

        if(*f == '.') {
            f++;
            precision = 0;
            if(*f == '*') {
                precision = va_arg(args, int);
                if(precision < 0)
                    precision = -1;
                f++;
            } else {
                while(*f >= '0' && *f <= '9') {
                    precision = precision * 10 + (*f - '0');
                    f++;
                }
            }
        }

        if(*f == 'h') {
            short_count = 1;
            f++;
            if(*f == 'h') {
                short_count = 2;
                f++;
            }
        } else if(*f == 'l') {
            long_count = 1;
            f++;
            if(*f == 'l') {
                /* No kernel call currently uses ll; consume the modifier so
                 * it can never leak as text.  On i386 the supported kernel
                 * integer ABI remains 32-bit, so the low DWORD is formatted. */
                long_count = 2;
                f++;
            }
        } else if(*f == 'L') {
            long_count = 1;
            f++;
        } else if(*f == 'z' || *f == 't') {
            /* size_t/ptrdiff_t are 32-bit in the JTMOS i386 ABI. */
            long_count = 1;
            f++;
        }

        spec = *f;
        if(spec == 0) {
            emit(context, '%');
            written++;
            break;
        }
        f++;

        text = number;
        text_len = 0;
        numeric = 0;
        negative = 0;
        base = 10;
        upper = 0;
        value = 0;
        sign = 0;
        prefix_len = 0;

        if(spec == 's') {
            text = va_arg(args, const char *);
            if(!text || illegal(text))
                text = "[NULL]";
            text_len = jt_text_len(text, precision);
        } else if(spec == 'c') {
            number[0] = (char)va_arg(args, int);
            number[1] = 0;
            text_len = 1;
        } else if(spec == 'd' || spec == 'i') {
            long signed_value;
            numeric = 1;
            if(long_count)
                signed_value = va_arg(args, long);
            else
                signed_value = (long)va_arg(args, int);
            if(signed_value < 0) {
                negative = 1;
                value = (DWORD)(-(signed_value + 1L));
                value += 1U;
            } else {
                value = (DWORD)signed_value;
            }
            if(negative) sign = '-';
            else if(plus) sign = '+';
            else if(space) sign = ' ';
            if(precision == 0 && value == 0)
                text_len = 0;
            else
                text_len = jt_u32toa(number, value, 10U, 0);
        } else if(spec == 'u' || spec == 'x' || spec == 'X' || spec == 'o') {
            numeric = 1;
            if(long_count)
                value = (DWORD)va_arg(args, unsigned long);
            else {
                /* h/hh arguments are promoted to unsigned/int in varargs. */
                value = (DWORD)va_arg(args, unsigned int);
            }
            if(spec == 'x' || spec == 'X') {
                base = 16;
                upper = (spec == 'X');
            } else if(spec == 'o') {
                base = 8;
            }
            if(precision == 0 && value == 0)
                text_len = 0;
            else
                text_len = jt_u32toa(number, value, (unsigned)base, upper);
            if(alt && value != 0 && (spec == 'x' || spec == 'X')) {
                prefix[0] = '0';
                prefix[1] = spec;
                prefix_len = 2;
            } else if(alt && spec == 'o' &&
                      (text_len == 0 || number[0] != '0')) {
                prefix[0] = '0';
                prefix_len = 1;
            }
        } else if(spec == 'p') {
            numeric = 1;
            value = (DWORD)va_arg(args, void *);
            base = 16;
            prefix[0] = '0';
            prefix[1] = 'x';
            prefix_len = 2;
            text_len = jt_u32toa(number, value, 16U, 0);
        } else if(spec == 'f' || spec == 'F') {
            /* Preserve the historical kernel behaviour: floating point
             * formatting is intentionally not performed in printk context. */
            (void)va_arg(args, double);
            text = "";
            text_len = 0;
        } else {
            /* Unknown conversion: preserve it visibly instead of eating text. */
            emit(context, '%');
            emit(context, spec);
            written += 2;
            continue;
        }

        (void)short_count;
        if(numeric && precision >= 0)
            zero = 0;

        precision_zeroes = 0;
        if(numeric && precision > text_len)
            precision_zeroes = precision - text_len;

        core_len = text_len + precision_zeroes + prefix_len + (sign ? 1 : 0);
        pad = width > core_len ? width - core_len : 0;

        if(!left && !zero)
            jt_emit_repeat(emit, context, ' ', pad, &written);
        if(sign) {
            emit(context, sign);
            written++;
        }
        if(prefix_len)
            jt_emit_text(emit, context, prefix, prefix_len, &written);
        if(!left && zero)
            jt_emit_repeat(emit, context, '0', pad, &written);
        jt_emit_repeat(emit, context, '0', precision_zeroes, &written);
        jt_emit_text(emit, context, text, text_len, &written);
        if(left)
            jt_emit_repeat(emit, context, ' ', pad, &written);
    }

    return written;
}
