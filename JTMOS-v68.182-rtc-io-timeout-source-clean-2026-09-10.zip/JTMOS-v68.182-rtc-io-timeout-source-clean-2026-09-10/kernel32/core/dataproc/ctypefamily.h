#ifndef __INCLUDED_JTMLIBC_CTYPEFAMILY_H__
#define __INCLUDED_JTMLIBC_CTYPEFAMILY_H__

/* Kernel-local ctype family.  JTMOS uses an 8-bit console character set;
 * keep the ISO-8859-1 Finnish letters that the historical implementation
 * supported while providing normal ASCII C ctype semantics. */
int isalnum(int c);
int isalpha(int c);
int iscntrl(int c);
int ispunct(int c);
int isxdigit(int c);
int isspace(int c);
int islower(int c);
int isupper(int c);
int isprint(int c);
int isgraph(int c);
int toupper(int c);
int tolower(int c);
int isdigit(int c);

#endif
