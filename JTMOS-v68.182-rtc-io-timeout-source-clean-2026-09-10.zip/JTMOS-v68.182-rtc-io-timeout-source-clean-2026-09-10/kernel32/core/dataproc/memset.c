/* JTMOS freestanding memset: i486 baseline + optional SSE3 runtime path. */
#include <stdio.h>
#include "cpu.h"
#include "memops_sse3.h"

void *memset(void *dst,int c,size_t len)
{
    BYTE *p;
    BYTE v;
    if(cpuSSE3AccelerationEnabled() && len>=128)
        return jtmos_memset_sse3(dst,c,len);
    p=(BYTE *)dst; v=(BYTE)c;
    while(len){*p++=v;len--;}
    return dst;
}
