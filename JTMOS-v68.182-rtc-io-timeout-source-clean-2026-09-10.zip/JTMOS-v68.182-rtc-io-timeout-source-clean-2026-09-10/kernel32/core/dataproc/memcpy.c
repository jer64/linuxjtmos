//------------------------------------------------------------------------------------------
// Copy a region of memory to another place.
// (delivered from LIBC)
// (C) 2003-2004 by Jari Tuominen.
//------------------------------------------------------------------------------------------
#include "kernel32.h"
#include "memcpy.h"
#include "cpu.h"
#include "memops_sse3.h"

//----------------------------------------------------------------------------------------------
// Verify address.
//
int illegal(const void *ptr)
{
	DWORD ad=(DWORD)ptr;
	//
	if(paging_enabled)
	{
		//
		if( !(GetPage(ad/4096)&1) )
			// Illegal.
			return TRUE;
	}
	else
	{
		if(ad<=0x3FFFUL)
			return TRUE;
	}

	// Legal.
	return FALSE;
}

static int illegal_range(DWORD ad,DWORD length)
{
	DWORD end;
	DWORD page,last_page;
	if(length==0) return FALSE;
	if(ad>0xFFFFFFFFUL-(length-1UL)) return TRUE;
	end=ad+length-1UL;
	if(!paging_enabled) return illegal((const void *)ad) || illegal((const void *)end);
	page=ad/4096UL;
	last_page=end/4096UL;
	for(;;)
	{
		if(!(GetPage(page)&1)) return TRUE;
		if(page==last_page) break;
		page++;
	}
	return FALSE;
}

//----------------------------------------------------------------------------------------------
//
void *dmemcpy(void *o,const void *s,DWORD l,
	const char *fun)
{
	char str[256];

	//
	if(GetCurrentThread()!=0 && (illegal_range((DWORD)o,l) || illegal_range((DWORD)s,l)))
	{
		sprintf(str, "Illegal memcpy call: memcpy(%x,%x, %d); called by %s",
			o,s,l, fun);
		dprintk("%s\n",str);
		return NULL;
	}

	//
	return xmemcpy(o,s,l);
}

//----------------------------------------------------------------------------------------------
// The real copy function.
//
void *xmemcpy(void *_o,const void *_s,DWORD length)
{
	DWORD i;
	BYTE *o;
	const BYTE *s;
	o=(BYTE *)_o; s=(const BYTE *)_s;
	if(cpuSSE3AccelerationEnabled() && length>=128)
		return jtmos_memcpy_sse3(_o,_s,(size_t)length);
	for(i=0;i<length;i++) o[i]=s[i];
	return o;
}

//----------------------------------------------------------------------------------------------
// Overlap-safe memory move for the native kernel.
//
// The kernel is linked without the userspace libc, so any kernel module using
// memmove() must resolve to a native implementation here.  Copy forward when
// the destination is below the source and backward when it overlaps from
// above.  Do not route this through memcpy(): overlapping ranges are exactly
// the case where memcpy semantics are insufficient.
void *memmove(void *_o,const void *_s,DWORD length)
{
    BYTE *o=(BYTE *)_o;
    const BYTE *s=(const BYTE *)_s;
    DWORD od=(DWORD)o;
    DWORD sd=(DWORD)s;
    DWORD i;

    if(o==s || length==0) return _o;

    /* Copying forward is safe whenever destination starts below source, or
     * starts at least LENGTH bytes above it.  Using integer address
     * subtraction avoids forming s+length past the 32-bit address space. */
    if(od<sd || od-sd>=length) {
        for(i=0;i<length;i++) o[i]=s[i];
    } else {
        i=length;
        while(i>0) { i--; o[i]=s[i]; }
    }
    return _o;
}

//----------------------------------------------------------------------------------------------
//
void dmemset(char *buf,char ch,int length,
	const char *fun)
{
	char str[256];

	//
	if(GetCurrentThread()!=0 && length>0 && illegal_range((DWORD)buf,(DWORD)length))
	{
		sprintf(str, "Illegal memset call: memset(%x, %d, %d); called by %s",
			buf,ch,length, fun);
		dprintk("%s\n",str);
		return;
	}

	//
	xmemset(buf,ch,length);
}

//----------------------------------------------------------------------------------------------
// memset(buf,char,length)
//
void xmemset(char *buf,char ch,int length)
{
	if(length<=0)return;
	memset(buf,(unsigned char)ch,(size_t)length);
}

