//--------------------------------------------------------------------------
//
// printf.c
// printf & vprintf
// (C) 2002-2026 by Jari Tuominen.
//
// V67.8.49: the shared formatter is kept, but kernel console output must be
// atomic.  V67.8.48 emitted every formatted byte through putch(); once the
// syscall layer was live that meant one SYS_PUTCH per byte, allowing another
// runnable thread/IRQ-side diagnostic to interleave characters into gibberish.
//
// Format directly through _putch() while interrupts are disabled for the
// duration of one printf/vprintf call.  JTMOS is currently a uniprocessor i386
// kernel, so this also prevents scheduler preemption without introducing a
// lock that could deadlock from exception/IRQ diagnostic paths.
//--------------------------------------------------------------------------
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
#include "sb.h"
#include "driver_sys.h"
#include "zero.h"
#include "null.h"
#include "printf.h"
#include "stdarg.h"
#include "dfunc.h"
#include "kformat.h"
#include "logging.h"

typedef struct JT_CONSOLE_EMIT_CONTEXT {
    char logline[1024];
    unsigned int used;
} JT_CONSOLE_EMIT_CONTEXT;

static void jt_console_emit(void *context, char ch)
{
    JT_CONSOLE_EMIT_CONTEXT *ctx=(JT_CONSOLE_EMIT_CONTEXT *)context;
    /* Never recurse through the syscall gate from kernel printf. */
    _putch((unsigned char)ch);
    if(ctx!=NULL && ctx->used+1U<sizeof(ctx->logline))
        ctx->logline[ctx->used++]=ch;
}

int printf(const char *fmt, ...)
{
    va_list arg;
    int result;

    va_start(arg, fmt);
    result = vprintf(fmt, arg);
    va_end(arg);
    return result;
}

int vprintf(const char *fmt, va_list arg)
{
    DWORD flags;
    int result;
    JT_CONSOLE_EMIT_CONTEXT ctx;

    /*
     * Keep one formatted kernel message contiguous on the terminal.
     * The previous implementation used putch(), which becomes SYS_PUTCH once
     * scallsIsWorking is true; a task switch between characters can merge two
     * otherwise valid English messages into unreadable text.
     *
     * Saving/restoring the complete EFLAGS value preserves callers that
     * already have interrupts disabled (early boot, IRQ, exception, panic).
     */
    memset(&ctx,0,sizeof(ctx));
    flags = get_eflags();
    disable();
    result = jt_vformat(jt_console_emit, &ctx, fmt, arg);
    set_eflags(flags);

    /* Persistent system logging starts in RAM before a writable root exists.
     * Preserve the console text in KLOGGER's FIFO; trim line terminators
     * because WriteSystemLog() supplies the record newline itself. */
    while(ctx.used>0U && (ctx.logline[ctx.used-1U]=='\n' || ctx.logline[ctx.used-1U]=='\r'))
        ctx.used--;
    if(ctx.used>0U) { ctx.logline[ctx.used]=0; WriteSystemLog(ctx.logline); }
    return result;
}
