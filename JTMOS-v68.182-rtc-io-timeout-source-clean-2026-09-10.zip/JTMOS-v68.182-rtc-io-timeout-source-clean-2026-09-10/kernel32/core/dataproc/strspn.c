#include <stdio.h>

size_t strspn(const char *str, const char *accept)
{
    const unsigned char *s=(const unsigned char *)str;
    const unsigned char *a;
    size_t n=0;
    int found;
    if(!str || !accept) return 0;
    while(*s) {
        found=0;
        for(a=(const unsigned char *)accept; *a; a++) {
            if(*a==*s) { found=1; break; }
        }
        if(!found) break;
        n++;
        s++;
    }
    return n;
}
