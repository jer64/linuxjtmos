#include "strncat.h"

char *strncat(char *dest, const char *src, int n)
{
    char *d=dest;
    int copied=0;
    if(!dest || !src || n<=0) return dest;
    while(*d) d++;
    while(*src && copied<n) {
        *d++=*src++;
        copied++;
    }
    *d=0;
    return dest;
}
