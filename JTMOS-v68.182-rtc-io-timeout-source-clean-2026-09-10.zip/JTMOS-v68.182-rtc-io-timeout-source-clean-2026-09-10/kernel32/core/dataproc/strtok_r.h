#ifndef __INCLUDED_JTMOS_STRTOK_R_H__
#define __INCLUDED_JTMOS_STRTOK_R_H__

char *__strtok_r(char *s, const char *delim, char **save_ptr);
char *strtok_r(char *s, const char *delim, char **save_ptr);

#endif
