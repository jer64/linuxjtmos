#include <stdio.h>

size_t strcspn(const char *str, const char *reject)
{
    const unsigned char *s=(const unsigned char *)str;
    const unsigned char *r;
    size_t n=0;
    if(!str || !reject) return 0;
    while(*s) {
        for(r=(const unsigned char *)reject; *r; r++)
            if(*r==*s) return n;
        n++;
        s++;
    }
    return n;
}
