#ifndef __JTMOS_SPRINTF_H__
#define __JTMOS_SPRINTF_H__

#include "basdef.h"
#include "stdarg.h"

/*
 * Kernel formatting API.  JTMOS/i386 size_t is unsigned long, so the bounded
 * interfaces use unsigned long directly here.  This keeps dataproc independent
 * of fs/filedef.h while remaining ABI-compatible with size_t callers.
 */
int snprintf(char *s, unsigned long capacity, const char *fmt, ...);
int vsnprintf(char *s, unsigned long capacity, const char *fmt, va_list arg);
int sprintf(char *s, const char *fmt, ...);
int svprintf(char *s, const char *fmt, va_list arg);
int _vsprintf(char *s, const char *fmt, va_list arg, int max_len);

#endif
