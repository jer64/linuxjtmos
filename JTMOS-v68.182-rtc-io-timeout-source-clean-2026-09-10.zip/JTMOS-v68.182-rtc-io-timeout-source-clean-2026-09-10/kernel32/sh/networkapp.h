#ifndef SMSH_NETWORKAPP_H
#define SMSH_NETWORKAPP_H
int internet_app(int argc, char **argv);
int ping_app(int argc, char **argv);
int host_app(int argc, char **argv);
int async_app(int argc, char **argv);
int www_app(int argc, char **argv);
int telnetd_app(int argc, char **argv);
int nutget_app(int argc, char **argv);
#endif
