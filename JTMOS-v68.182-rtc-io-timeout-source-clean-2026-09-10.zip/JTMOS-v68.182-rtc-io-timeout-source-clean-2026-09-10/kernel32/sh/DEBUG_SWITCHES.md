# SMSH debug/report switches (V38)

Builtins:

- `debug` / `debug1`: toggle kernel debug level 1.
- `report` / `debug2`: toggle report/debug level 2.
- `d0`: immediately disables both debug levels, ordinary serial diagnostics, and console-to-serial mirroring. Emergency panic/CPU-exception serial output remains enabled. During automatic boot, once a writable JTMFS root is selected, the filesystem logger resumes DEBUG/REPORT collection to the selected RAM-buffered `/logs/system.log` target (hda1:/logs by default when hda1 is JTMFS) without re-enabling the UART path. A later manual `d0` disables those streams again until the next root/log activation.
- Optional argument: `on`, `off`, `toggle`, `status`, `1`, `0`, `enable`, `disable`.

Entry points:

    int DebugModeSwitchMain(int argc, char **argv);
    int ReportModeSwitchMain(int argc, char **argv);

The historical `DebugModeSwitch()` and `ReportModeSwitch()` symbols are retained
as compatibility wrappers, but they now return normally.  They no longer call
`ExitThread(0)`, because builtins execute in the persistent SMSH thread.

Level 1 keeps `glvar.debugMsg` and `jtmos_debug` synchronized.  Level 2 controls
`debug2`.


## V67.8.55 serial performance mode

`d0` no longer only clears the two verbosity flags. It also clears
`serial_console_redirect` and disables the ordinary polled UART writer. The
physical `serial_debug_line` remains configured so `KernelFatalAt()` and early
CPU exception handlers can use the separate `DebugSerialEmergency*()` path.
Explicit `debug on` or `report on` re-enables ordinary serial diagnostics, but
does not automatically re-enable full console mirroring.

## V16.80 build-time console profiles

The normal server/text build now starts with both ordinary console serial
switches disabled:

    serial_console_redirect = 0
    vesa_early_serial_only  = 0

This is the Linode/QEMU `-display curses` profile.  It keeps normal output on
the native VGA/text terminal and avoids duplicating every console byte to the
polled debug UART. `dprintk()` / `ReportMessage()` and emergency serial remain
separate as before.

The BIOS VESA/GraOS build selects `1/1` at compile time so the early kernel can
use the VESA-safe serial-only path until graphics/paging initialization clears
it. Use `make image-linode` for the explicit server profile or `make image-gui`
for the VESA profile. The generated `console_profile.generated.h` is a build
artifact and forces `init/keropt.o` to rebuild when the profile changes.
