/* SMSH/SQSH frontend for the kernel-native AI diagnostics engine. */
#include <stdio.h>
#include <string.h>
#include "sh.h"
#include "aiapp.h"
#include "ai/ai_native.h"

static const char *ai_domain_name(int d)
{
    switch(d) {
        case AI_DOMAIN_STORAGE:return "storage";
        case AI_DOMAIN_MEMORY:return "memory";
        case AI_DOMAIN_NETWORK:return "network";
        case AI_DOMAIN_TASKS:return "tasks";
        case AI_DOMAIN_HEALTH:return "system";
        default:return "system";
    }
}

static void ai_usage(void)
{
    smsh_printf("Usage: ai [diagnose|QUESTION...]\n");
    smsh_printf("Examples:\n");
    smsh_printf("  ai\n");
    smsh_printf("  ai why is the disk full\n");
    smsh_printf("  ai miksi internet ei toimi\n");
    smsh_printf("Native AI v1 is an offline explainable kernel diagnostic engine.\n");
}

int ai_native_app(int argc,char **argv)
{
    AI_NATIVE_RESULT r;
    int domain;

    if(argc>1 && (!strcmp(argv[1],"help") || !strcmp(argv[1],"--help") || !strcmp(argv[1],"-h"))) {
        ai_usage();
        return 0;
    }
    domain=AINativeQueryDomain(argc,argv);
    if(AINativeDiagnose(&r,domain)!=0) {
        smsh_printf("AI: unable to collect enough kernel telemetry.\n");
        return 1;
    }
    smsh_printf("JTMOS Native AI v%d - %s diagnosis\n",AI_NATIVE_VERSION,ai_domain_name(domain));
    smsh_printf("Diagnosis: %s\n",r.title);
    smsh_printf("Confidence: %d%%\n",r.score);
    smsh_printf("Evidence: %s\n",r.evidence);
    smsh_printf("Recommended action: %s\n",r.action);
    if(domain==AI_DOMAIN_AUTO)
        smsh_printf("Tip: ask a focused question, e.g. 'ai why is the network down'.\n");
    return 0;
}
