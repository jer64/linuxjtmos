#define _POSIX_C_SOURCE 200809L
/* sqaMain.c - POSIX-only command-line front end for the extractor */
#include <errno.h>
#include <stdio.h>
#include <string.h>
#ifndef JTMOS
#include <unistd.h>
#else
#include "kernel32.h"
#endif

#include "sqa.h"

#ifdef JTMOS
typedef long SQA_MAIN_IO_COUNT;
#else
typedef ssize_t SQA_MAIN_IO_COUNT;
#endif

static int copy_option(char *destination, size_t capacity, const char *source)
{
    size_t length;

    if (source == NULL) {
        return -1;
    }
    length = strlen(source);
    if (length >= capacity) {
        return -1;
    }
    memcpy(destination, source, length + 1U);
    return 0;
}

SQA_UINT32 syschksum(const BYTE *buf, size_t len)
{
    size_t i;
    SQA_UINT32 value = 0U;

    if (buf == NULL && len != 0U) {
        return 0U;
    }
    for (i = 0U; i < len; ++i) {
        value += (SQA_UINT32)buf[i] + 1U;
    }
    return value;
}

static void print_usage(const char *program)
{
    printf( "Squirrel Archive Extractor 1.0\n");
    printf( "(C) 2002-2026 by Jari Tuominen\n");
    printf( "Usage: ");
    printf("%s", program != NULL ? program : "sqa");
    printf( " archive.sqa [options]\n");
    printf( "Options:\n");
    printf( "  -q          quiet mode\n");
    printf( "  -u file     extract only the named file\n");
    printf( "  -o dir      write extracted files into dir\n");
}

int sqa_main(int argc, char **argv)
{
    int i;
    int result;
    int quiet_mode=0;
    char wanted[256];
    char destination[256];

    wanted[0]='\0';
    destination[0]='\0';

    if (argc < 2 || argv == NULL || argv[0] == NULL) {
        print_usage((argv != NULL) ? argv[0] : "sqa");
        return 0;
    }

    for (i = 2; i < argc; ++i) {
        if (strcmp(argv[i], "-q") == 0) {
            quiet_mode = 1;
        } else if (strcmp(argv[i], "-u") == 0) {
            ++i;
            if (i >= argc) {
                printf("Option -u requires a file name.\n");
                return 2;
            }
            if (copy_option(wanted, sizeof(wanted), argv[i]) != 0) {
                printf("File name supplied to -u is too long.\n");
                return 2;
            }
        } else if (strcmp(argv[i], "-o") == 0) {
            ++i;
            if (i >= argc) {
                printf("Option -o requires a directory.\n");
                return 2;
            }
            if (copy_option(destination, sizeof(destination), argv[i]) != 0) {
                printf("Directory supplied to -o is too long.\n");
                return 2;
            }
        } else {
            printf("Unknown option: %s\n", argv[i]);
            return 2;
        }
    }

    result = extract_archive_ex(argv[1], wanted, destination, 0, quiet_mode);
    if (result == 1)
        result = extract_archive_ex(argv[1], wanted, destination, 640 * 1024,
                                    quiet_mode);

    if (result != 0 && !quiet_mode)
        printf("Archive extraction failed (error %d).\n",result);
    return result;
}
