#ifndef __INCLUDED_SMSH_RMWILDCARD_H__
#define __INCLUDED_SMSH_RMWILDCARD_H__

int rm_wildcard_main(int argc, char **argv);

#endif
