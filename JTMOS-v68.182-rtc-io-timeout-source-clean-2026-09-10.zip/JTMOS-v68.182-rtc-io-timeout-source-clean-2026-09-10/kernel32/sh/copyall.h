#ifndef __INCLUDED_SMSH_COPYALL_H__
#define __INCLUDED_SMSH_COPYALL_H__

int copyall_main(int argc, char **argv);

#endif
