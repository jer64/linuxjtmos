#ifndef __SMSH_FSADMIN_H__
#define __SMSH_FSADMIN_H__

int lsdev_app(int argc, char **argv);
int mount_app(int argc, char **argv);
int umount_app(int argc, char **argv);
int root_app(int argc, char **argv);
int rootinstall_app(int argc, char **argv);
int bootroot_app(int argc, char **argv);
int sync_app(int argc, char **argv);
int hdatest_app(int argc, char **argv);
int fsgeom_app(int argc, char **argv);
int fsck_app(int argc, char **argv);
int diskspace_app(int argc, char **argv);
int smsh_boot_root_policy(void);

#endif
