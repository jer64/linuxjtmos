/* findapp.c - compact recursive JTMFS find command for kernel SMSH. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "findapp.h"

#ifdef JTMOS
#include "kernel32.h"
#include "jtmfs.h"
#include "jtmfsAccess.h"
#include "scheduler.h"

#define FIND_HARD_MAX_DEPTH 64
#define FIND_TYPE_ANY 0
#define FIND_TYPE_FILE 1
#define FIND_TYPE_DIR 2
#define FIND_PATH_MAX 1024

typedef struct FIND_ENTRY {
    struct FIND_ENTRY *next;
    int is_dir;
    int is_file;
    int child_db;
    char name[260];
} FIND_ENTRY;

typedef struct FIND_OPTIONS {
    const char *path;
    int maxdepth;
    int type;
} FIND_OPTIONS;

static void find_usage(void)
{
    printf("Usage: find [OPTIONS] [DIRECTORY] [OPTIONS]\n");
    printf("  -type f          print regular files\n");
    printf("  -type d          print directories\n");
    printf("  -maxdepth N      descend at most N levels (start directory is depth 0)\n");
    printf("Options may appear before or after DIRECTORY.\n");
}

static int find_parse_uint(const char *s, int *out)
{
    unsigned long n=0;
    int i;
    if(!s || !s[0] || !out) return 0;
    for(i=0;s[i];++i) {
        if(s[i]<'0' || s[i]>'9') return 0;
        n=n*10UL+(unsigned long)(s[i]-'0');
        if(n>(unsigned long)FIND_HARD_MAX_DEPTH) return 0;
    }
    *out=(int)n;
    return 1;
}

/* The pathname is the first non-option argument that was not consumed as an
 * option value.  This deliberately accepts, for example:
 *   find -maxdepth 2 /bin -type f
 * instead of assuming argv[1] must be the search directory. */
static int find_parse(int argc, char **argv, FIND_OPTIONS *opt)
{
    int i;
    const char *a;
    if(!opt) return 2;
    opt->path=".";
    opt->maxdepth=-1;
    opt->type=FIND_TYPE_ANY;
    {
        int path_seen=0;
        for(i=1;i<argc;++i) {
            a=argv[i];
            if(!a || !a[0]) continue;
            if(!strcmp(a,"-h") || !strcmp(a,"--help")) {
                find_usage();
                return -1;
            }
            if(!strcmp(a,"-maxdepth")) {
                if(i+1>=argc || !find_parse_uint(argv[i+1],&opt->maxdepth)) {
                    printf("find: -maxdepth requires an integer 0..%d\n",FIND_HARD_MAX_DEPTH);
                    return 2;
                }
                ++i;
                continue;
            }
            if(!strcmp(a,"-type")) {
                if(i+1>=argc) {
                    printf("find: -type requires 'f' or 'd'\n");
                    return 2;
                }
                ++i;
                if(!strcmp(argv[i],"f")) opt->type=FIND_TYPE_FILE;
                else if(!strcmp(argv[i],"d")) opt->type=FIND_TYPE_DIR;
                else {
                    printf("find: unsupported -type '%s' (use f or d)\n",argv[i]);
                    return 2;
                }
                continue;
            }
            if(a[0]=='-') {
                printf("find: unknown option '%s'\n",a);
                return 2;
            }
            if(path_seen) {
                printf("find: too many search paths ('%s')\n",a);
                return 2;
            }
            opt->path=a;
            path_seen=1;
        }
    }
    return 0;
}

static int find_join(char *out, int cap, const char *base, const char *name)
{
    size_t a,b;
    int slash;
    if(!out || cap<=0 || !base || !name) return 0;
    a=strlen(base); b=strlen(name);
    slash=(a>0 && base[a-1]!='/') ? 1 : 0;
    if(a+(size_t)slash+b+1U>(size_t)cap) return 0;
    memcpy(out,base,a);
    if(slash) out[a++]='/';
    memcpy(out+a,name,b+1U);
    return 1;
}

static void find_free_entries(FIND_ENTRY *e)
{
    FIND_ENTRY *n;
    while(e) { n=e->next; free(e); e=n; }
}

static int find_snapshot(int dnr, int db, FIND_ENTRY **out)
{
    DIRWALK *dw;
    FIND_ENTRY *head=NULL,*tail=NULL,*e;
    JTMFS_FILE_ENTRY *fe;
    int done=0;
    if(!out) return 1;
    *out=NULL;
    dw=(DIRWALK*)malloc(sizeof(DIRWALK));
    if(!dw) { printf("find: out of memory\n"); return 1; }
    memset(dw,0,sizeof(*dw));
    if(jtmfs_ffirst(dnr,db,dw)!=0) { free(dw); return 1; }
    while(!done) {
        SchedulerCooperate();
        fe=dw->fe;
        if(fe && fe->name[0] && !jtmfs_entryIsDeleted(fe) &&
           !JTMFS_TYPE_IS_DIRNAME(fe->type) &&
           strcmp(fe->name,".") && strcmp(fe->name,"..")) {
            int is_dir=JTMFS_TYPE_IS_DIRECTORY(fe->type)?1:0;
            int is_file=(JTMFS_TYPE_IS_FILE(fe->type) && fe->length>=0)?1:0;
            if(is_dir || is_file) {
                e=(FIND_ENTRY*)malloc(sizeof(*e));
                if(!e) {
                    jtmfs_fend(dw); free(dw); find_free_entries(head);
                    printf("find: out of memory\n");
                    return 1;
                }
                memset(e,0,sizeof(*e));
                strncpy(e->name,fe->name,sizeof(e->name)-1U);
                e->name[sizeof(e->name)-1U]=0;
                e->is_dir=is_dir;
                e->is_file=is_file;
                e->child_db=is_dir?(int)fe->FirstDataBlock:0;
                if(tail) tail->next=e; else head=e;
                tail=e;
            }
        }
        if(jtmfs_fnext(dnr,dw)!=0) done=1;
    }
    jtmfs_fend(dw);
    free(dw);
    *out=head;
    return 0;
}

static int find_should_print(int type, int is_dir, int is_file)
{
    if(type==FIND_TYPE_ANY) return is_dir || is_file;
    if(type==FIND_TYPE_DIR) return is_dir;
    return is_file;
}

static int find_walk(int dnr, int db, const char *display, int depth,
                     const FIND_OPTIONS *opt)
{
    FIND_ENTRY *list=NULL,*e;
    int rc=0;
    if(depth>=FIND_HARD_MAX_DEPTH) return 0;
    if(opt->maxdepth>=0 && depth>=opt->maxdepth) return 0;
    if(find_snapshot(dnr,db,&list)!=0) {
        printf("find: cannot read '%s'\n",display);
        return 1;
    }
    for(e=list;e;e=e->next) {
        char child[FIND_PATH_MAX];
        int child_depth=depth+1;
        SchedulerCooperate();
        if(!find_join(child,sizeof(child),display,e->name)) {
            printf("find: path too long below '%s'\n",display);
            rc=1;
            continue;
        }
        if(find_should_print(opt->type,e->is_dir,e->is_file))
            printf("%s\n",child);
        if(e->is_dir && e->child_db>0 &&
           (opt->maxdepth<0 || child_depth<opt->maxdepth) &&
           child_depth<FIND_HARD_MAX_DEPTH) {
            if(find_walk(dnr,e->child_db,child,child_depth,opt)!=0) rc=1;
        }
    }
    find_free_entries(list);
    return rc;
}

int find_app(int argc, char **argv)
{
    FIND_OPTIONS opt;
    int prc;
    int pid,old_dnr,old_db,start_dnr,start_db;
    int rc;
    prc=find_parse(argc,argv,&opt);
    if(prc<0) return 0;
    if(prc!=0) { find_usage(); return prc; }

    pid=GetCurrentThread();
    old_dnr=GetCurrentDNR();
    old_db=GetCurrentDB();
    if(jtmfs_chdir(opt.path)!=0) {
        printf("find: cannot access '%s'\n",opt.path);
        return 1;
    }
    start_dnr=GetCurrentDNR();
    start_db=GetCurrentDB();
    SetThreadDNR(pid,old_dnr);
    SetThreadDB(pid,old_db);

    if(find_should_print(opt.type,1,0)) printf("%s\n",opt.path);
    rc=find_walk(start_dnr,start_db,opt.path,0,&opt);
    return rc;
}

#else
int find_app(int argc, char **argv)
{
    (void)argc; (void)argv;
    return 1;
}
#endif
