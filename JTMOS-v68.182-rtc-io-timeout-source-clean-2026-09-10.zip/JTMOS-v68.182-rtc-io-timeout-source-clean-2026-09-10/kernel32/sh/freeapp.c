/* Linux free-like memory report for SMSH. */
#include <stdio.h>
#include <string.h>
#include "kernel32.h"
#include "mm.h"
#include "dirdb.h"
#include "flexFat.h"
#include "hdCache.h"
#include "core/kasync/kasync.h"
#include "freeapp.h"

extern void MilSleep(int periodMilliseconds);

typedef struct
{
    MM_MEMORY_STATS mm;
    DWORD dirdb_bytes;
    DWORD flexfat_bytes;
    DWORD hdcache_bytes;
    DWORD cache_bytes;
    DWORD available_bytes;
    DWORD used_bytes;
    DWORD kasync_bytes;
    int async_queued;
    int async_running;
    int async_finished;
} FREE_SNAPSHOT;

static DWORD add_saturated(DWORD a, DWORD b)
{
    if(b > 0xffffffffUL - a)
        return 0xffffffffUL;
    return a + b;
}

static void take_snapshot(FREE_SNAPSHOT *s)
{
    DWORD flags,total;
    int i;

    memset(s,0,sizeof(*s));
    mm_get_memory_stats(&s->mm);

    flags=(DWORD)get_eflags();
    disable();
    s->dirdb_bytes=dirdb.bytes_allocated;

    if(fle != NULL)
        for(i=0;i<N_MAX_FATS;i++)
            if(fle->FAT[i].isOK)
            {
                FLEFAT *f=&fle->FAT[i];
                total=0;
                if(f->l_buf>0) total=add_saturated(total,(DWORD)f->l_buf);
                if(f->l_writemap>0) total=add_saturated(total,(DWORD)f->l_writemap);
                if(f->l_cache_page>0) total=add_saturated(total,(DWORD)f->l_cache_page);
                if(f->l_cache_age>0) total=add_saturated(total,(DWORD)f->l_cache_age);
                s->flexfat_bytes=add_saturated(s->flexfat_bytes,total);
            }

    if(hdCacheActive && hdb != NULL && hdb->e != NULL)
        for(i=0;i<hdb->n_e;i++)
            if(hdb->e[i] != NULL && hdb->e[i]->l_buf>0)
                s->hdcache_bytes=add_saturated(s->hdcache_bytes,
                    (DWORD)hdb->e[i]->l_buf);
    set_eflags((int)flags);

    s->cache_bytes=add_saturated(s->dirdb_bytes,s->flexfat_bytes);
    s->cache_bytes=add_saturated(s->cache_bytes,s->hdcache_bytes);
    s->available_bytes=add_saturated(s->mm.free_bytes,s->cache_bytes);
    if(s->available_bytes>s->mm.total_bytes)
        s->available_bytes=s->mm.total_bytes;
    s->used_bytes=s->mm.total_bytes>=s->available_bytes ?
        s->mm.total_bytes-s->available_bytes : 0;
    s->kasync_bytes=kasync_memory_bytes();
    kasync_counts(&s->async_queued,&s->async_running,&s->async_finished);
}

static void format_value(char *out,DWORD bytes,DWORD divisor,int human)
{
    DWORD whole,tenth,unit;
    char suffix;

    if(!human)
    {
        sprintf(out,"%u",(unsigned int)(bytes/divisor));
        return;
    }

    unit=1;suffix='B';
    if(bytes>=1024UL){unit=1024UL;suffix='K';}
    if(bytes>=1024UL*1024UL){unit=1024UL*1024UL;suffix='M';}
    if(bytes>=1024UL*1024UL*1024UL){unit=1024UL*1024UL*1024UL;suffix='G';}
    whole=bytes/unit;
    if(unit==1 || whole>=10)
        sprintf(out,"%u%c",(unsigned int)whole,suffix);
    else
    {
        tenth=(bytes%unit)/(unit/10);
        sprintf(out,"%u.%u%c",(unsigned int)whole,(unsigned int)tenth,suffix);
    }
}

static void print_row(const char *name,DWORD a,DWORD b,DWORD c,DWORD d,
    DWORD e,DWORD f,DWORD divisor,int human)
{
    char sa[20],sb[20],sc[20],sd[20],se[20],sf[20];
    format_value(sa,a,divisor,human);format_value(sb,b,divisor,human);
    format_value(sc,c,divisor,human);format_value(sd,d,divisor,human);
    format_value(se,e,divisor,human);format_value(sf,f,divisor,human);
    printf("%-7s %12s %12s %12s %12s %12s %12s\n",
        name,sa,sb,sc,sd,se,sf);
}

static int positive_number(const char *text,int *value)
{
    DWORD n=0;
    if(text==NULL || *text=='\0') return 0;
    while(*text)
    {
        if(*text<'0' || *text>'9') return 0;
        if(n>214748364UL) return 0;
        n=n*10+(DWORD)(*text-'0');
        text++;
    }
    if(n==0 || n>2147483647UL) return 0;
    *value=(int)n;
    return 1;
}

static void usage(void)
{
    printf("Usage: free [-b|-k|-m|-g] [-h] [-w] [-s seconds] [-c count]\n");
    printf("  -b/-k/-m/-g  bytes, KiB, MiB or GiB (default KiB)\n");
    printf("  -h            human-readable values\n");
    printf("  -w            JTMOS cache, MM and KAsync details\n");
    printf("  -s seconds    refresh repeatedly (whole seconds)\n");
    printf("  -c count      stop after count reports\n");
}

int free_app(int argc,char **argv)
{
    DWORD divisor=1024UL;
    int human=0,wide=0,interval=0,count=1,count_set=0;
    int i,iteration;
    FREE_SNAPSHOT s;

    for(i=1;i<argc;i++)
    {
        if(!strcmp(argv[i],"-b") || !strcmp(argv[i],"--bytes")) divisor=1;
        else if(!strcmp(argv[i],"-k") || !strcmp(argv[i],"--kibi")) divisor=1024UL;
        else if(!strcmp(argv[i],"-m") || !strcmp(argv[i],"--mebi")) divisor=1024UL*1024UL;
        else if(!strcmp(argv[i],"-g") || !strcmp(argv[i],"--gibi")) divisor=1024UL*1024UL*1024UL;
        else if(!strcmp(argv[i],"-h") || !strcmp(argv[i],"--human")) human=1;
        else if(!strcmp(argv[i],"-w") || !strcmp(argv[i],"--wide")) wide=1;
        else if(!strcmp(argv[i],"--help")){usage();return 0;}
        else if(!strcmp(argv[i],"-s"))
        {
            if(++i>=argc || !positive_number(argv[i],&interval) || interval>86400)
            {printf("free: invalid refresh interval\n");return 1;}
        }
        else if(!strcmp(argv[i],"-c"))
        {
            if(++i>=argc || !positive_number(argv[i],&count))
            {printf("free: invalid report count\n");return 1;}
            count_set=1;
        }
        else {printf("free: unknown option '%s'\n",argv[i]);usage();return 1;}
    }
    if(interval && !count_set) count=0;

    for(iteration=0;count==0 || iteration<count;iteration++)
    {
        take_snapshot(&s);
        if(iteration) printf("\n");
        printf("%7s %12s %12s %12s %12s %12s %12s\n",
            "","total","used","free","shared","buff/cache","available");
        print_row("Mem:",s.mm.total_bytes,s.used_bytes,s.mm.free_bytes,0,
            s.cache_bytes,s.available_bytes,divisor,human);
        print_row("Swap:",0,0,0,0,0,0,divisor,human);
        if(wide)
        {
            char a[20],b[20],c[20],d[20];
            format_value(a,s.dirdb_bytes,divisor,human);
            format_value(b,s.flexfat_bytes,divisor,human);
            format_value(c,s.hdcache_bytes,divisor,human);
            format_value(d,s.kasync_bytes,divisor,human);
            printf("JTMOS: DirDB=%s FlexFAT=%s HD-cache=%s KAsync=%s\n",a,b,c,d);
            printf("MM descriptors: active=%d high-water=%d capacity=%d\n",
                s.mm.descriptors_active,s.mm.descriptors_highwater,
                s.mm.descriptors_capacity);
            printf("KAsync jobs: queued=%d running=%d finished=%d\n",
                s.async_queued,s.async_running,s.async_finished);
        }
        if((count==0 || iteration+1<count) && interval)
            MilSleep(interval*1000);
    }
    return 0;
}
