#ifndef __JTMOS_AIAPP_H__
#define __JTMOS_AIAPP_H__
int ai_native_app(int argc,char **argv);
#endif
