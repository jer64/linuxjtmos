# SMSH memory/file dump commands (V39)

The historical SMSH `m`/`kmed` and `fm` commands are now normal builtin
argc/argv commands in the persistent SMSH thread.

## Commands

    m <hex-address> [hex-length]
    kmed <hex-address> [hex-length]
    fm <filename>

Examples:

    m B8000 100
    m 0x100000 1000
    fm hello.bin

Unprefixed addresses and lengths intentionally remain hexadecimal for
compatibility with the historical `hex2int()` based command.

`m` defaults to a maximum length of 0xFFFFF bytes, but inspects mappings a
page at a time and stops at the first unmapped page.  ESC stops the pager.

`fm` allocates one 4096-byte heap buffer and streams the file through it; it
does not allocate the complete file on the SMSH stack or heap.  The final
partial 16-byte line is bounds-safe.

Neither command calls `ExitThread()`.  Both return normally to the persistent
SMSH prompt.
