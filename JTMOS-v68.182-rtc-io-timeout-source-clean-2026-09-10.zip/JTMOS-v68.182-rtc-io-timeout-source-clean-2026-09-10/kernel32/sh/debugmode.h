#ifndef __INCLUDED_SMSH_DEBUGMODE_H__
#define __INCLUDED_SMSH_DEBUGMODE_H__

/* New SMSH argc/argv entry points. */
int DebugModeSwitchMain(int argc, char **argv);
int ReportModeSwitchMain(int argc, char **argv);
int DebugReportOffMain(int argc, char **argv);

/* Legacy compatibility entry points.  Unlike the historical implementation,
 * these do NOT terminate the SMSH thread. */
void DebugModeSwitch(void);
void ReportModeSwitch(void);

#endif
