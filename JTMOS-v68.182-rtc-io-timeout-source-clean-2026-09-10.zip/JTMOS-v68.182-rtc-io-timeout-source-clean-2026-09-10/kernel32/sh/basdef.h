#ifndef __INCLUDED_BASDEF_H__
#define __INCLUDED_BASDEF_H__

/* Basic fixed-width types shared by the shell utilities. */
#ifndef NULL
#define NULL 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef JTMOS
#include <stdint.h>
#include <stdbool.h>

typedef uint32_t DWORD;
typedef uint16_t WORD;
typedef uint8_t  BYTE;
typedef uint8_t  BOOL;
#else
/* JTMOS is a 32-bit target and supplies no hosted <stdint.h>. */
typedef unsigned long int      DWORD;
typedef unsigned short int     WORD;
typedef unsigned char          BYTE;
typedef unsigned char          BOOL;
typedef signed long long int   int64_t;
typedef unsigned long long int uint64_t;
typedef unsigned short int     uint16_t;
typedef unsigned long int      uint32_t;
typedef signed long int        int32_t;
typedef unsigned char          uint8_t;
typedef signed char            int8_t;
typedef unsigned long int      uintptr_t;
typedef signed long int        intptr_t;
#ifndef bool
#define bool int
#endif
#endif

/* Explicit IA-32 pointer/register ABI conversions. */
#define JTM_PTR_TO_DWORD(ptr) ((DWORD)(uintptr_t)(ptr))
#define JTM_DWORD_TO_PTR(type, value) ((type *)(uintptr_t)(DWORD)(value))
#define JTM_DWORD_TO_CPTR(type, value) ((const type *)(uintptr_t)(DWORD)(value))
#define JTM_DWORD_TO_VOID(value) ((void *)(uintptr_t)(DWORD)(value))

#endif
