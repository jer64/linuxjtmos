# SMSH copyall / rm_wildcard

Builtins added to the new argc/argv-based SMSH:

- `copyall SOURCE_PATH`
  - source is snapshotted before target writes
  - target is the current JTMFS directory
  - copies regular files, including zero-byte files
  - uses two 16 KiB heap buffers
  - verifies every copied byte source vs target
  - restores the original DNR/DB on all normal/error exits

- `rm_wildcard TEXT` (`rmwild`, `rmw` aliases)
  - collects all matching regular-file names before deleting anything
  - avoids invalidating a live DIRWALK while the directory changes
  - verifies that each deleted entry no longer exists

Both commands expose conventional `int main-like(int argc, char **argv)` entry
points and do not call `ExitThread()`.
