//--------------------------------------------------------------------------------------------
// ls.c - Directory displayer kernel mode application.
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#ifndef JTMOS
#include <unistd.h>
#else
#include "kernel32.h"
#include "jtmfsPath.h"
#endif
#include "formatapp.h"

#ifdef JTMOS
/*
 * SMSH compatibility rule: a leading component that is exactly the name of
 * a registered device means that device's JTMFS root.  The generic V62 path
 * resolver intentionally keeps "hda" relative, but that shell behaviour is
 * too easy to confuse with the physical hda: device because /hda also exists
 * as a namespace placeholder on ram:.  Use ./hda to request the ordinary
 * relative directory explicitly.
 *
 * Examples:
 *   cd hda       -> hda:/
 *   cd hda/bin   -> hda:/bin
 *   cd ./hda     -> relative directory named hda
 */
static const char *smsh_cd_canonicalize(const char *path,
                                        char *out, int out_size)
{
    char devname[64];
    const char *slash;
    int prefix_len;
    int i;

    if(path==NULL || out==NULL || out_size<=0)
        return path;
    if(path[0]=='/' || path[0]=='.' || strchr(path, ':')!=NULL)
        return path;

    slash=strchr(path, '/');
    prefix_len=slash ? (int)(slash-path) : (int)strlen(path);
    if(prefix_len<=0 || prefix_len>=(int)sizeof(devname))
        return path;

    for(i=0; i<prefix_len; ++i)
        devname[i]=path[i];
    devname[prefix_len]=0;
    if(driver_getdevicenrbyname(devname)<0)
        return path;

    if(slash!=NULL)
    {
        if((int)strlen(path)+2>=out_size)
            return path;
        memcpy(out,path,(size_t)prefix_len);
        out[prefix_len]=':';
        strcpy(out+prefix_len+1,slash);
    }
    else
    {
        if((int)strlen(path)+3>=out_size)
            return path;
        strcpy(out,path);
        strcat(out,":/");
    }
    return out;
}
#endif

// Dir function (ls)
// -----------------
//
// This function outputs directory from specified block(linear) to stdout.
int chdir_app(int argc, char **argv)
{
	//
	if(argc<2)
	{
#ifdef JTMOS
        char cwd[JTMFS_PATH_MAX];
        if(getcwd(cwd, sizeof(cwd)) == 0)
            printf("%s\n", cwd);
        else
            printf("cd: unable to read current directory.\n");
#else
        char cwd[1024];
        if(getcwd(cwd, sizeof(cwd)) != NULL)
            printf("%s\n", cwd);
        else
            perror("getcwd");
#endif
	}
	else
	{
#ifdef JTMOS
        char canonical[JTMFS_PATH_MAX],oldcwd[JTMFS_PATH_MAX],newcwd[JTMFS_PATH_MAX];
        const char *path;
        if(getcwd(oldcwd,sizeof(oldcwd))==NULL) oldcwd[0]=0;
        path=smsh_cd_canonicalize(argv[1],canonical,sizeof(canonical));
        if(chdir(path)!=0) {
            printf("chdir failed: %s\n", argv[1]);
            return 1;
        }
        if(oldcwd[0]) (void)ProcessEnvSet(GetCurrentThread(),"OLDPWD",oldcwd,1);
        if(getcwd(newcwd,sizeof(newcwd))!=NULL)
            (void)ProcessEnvSet(GetCurrentThread(),"PWD",newcwd,1);
#else
		if (chdir(argv[1]) != 0) {
			perror("chdir");
			return 1;
		}
#endif
	}
	return 0;
}

