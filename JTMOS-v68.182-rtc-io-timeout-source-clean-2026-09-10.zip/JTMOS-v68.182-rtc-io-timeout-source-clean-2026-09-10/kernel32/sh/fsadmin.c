// fsadmin.c - SMSH inline filesystem/root administration commands.
// (C) 2026 Jari Tuominen / JTMOS
#include <stdio.h>
#include <string.h>
#include "fsadmin.h"

#ifdef JTMOS
#include "kernel32.h"
#include "jtmfs.h"
#include "mount.h"
#include "root.h"
#include "createfat.h"
#include "biosfunc.h"
#include "jtmfat.h"
#include "jtmfsIntegrity.h"
#include "diskcache/dirdbAccess.h"
#include "diskcache/flexFat.h"
#include "logging.h"
#include "diskspace.h"

static int smsh_device_arg(const char *arg, char *name, int capacity)
{
    int len, dnr;

    if(arg==NULL || name==NULL || capacity<2 || !isValidString(arg))
        return -1;
    len=(int)strlen(arg);
    if(len<=0 || len>=capacity)
        return -1;
    strcpy(name, arg);
    if(name[len-1]==':')
        name[len-1]=0;
    if(!name[0])
        return -1;
    dnr=driver_getdevicenrbyname(name);
    if(!isValidDevice(dnr))
        return -1;
    return dnr;
}

/* An hda: volume is considered installed only after a kernel has been copied
 * and its 16-bit checksum written into the JTMOS boot record.  Since V63 the
 * normal `mkfs hda` path performs this install automatically from the current
 * boot floppy.  Low-level/incomplete formats keep checksum 0 and must not
 * steal / from the RAM rescue environment on the next SMSH start. */
static int smsh_installed_root_ready(int dnr)
{
    BYTE boot[512],runtime[512];
    WORD checksum;
    JTMFAT_INFOBLOCK *inf;
    DWORD kernel_start,kernel_blocks,kernel_end;
    int blocksize;

    if(!isValidDevice(dnr))
        return 0;
    blocksize=getblocksize(dnr);
    if(blocksize<=0 || (FAT_BOOT_SECTION_LEN_K*1024UL)%(DWORD)blocksize ||
       JTMFS_KERNEL_RESERVE_BYTES%(DWORD)blocksize)
        return 0;
    if(!jtmfs_isDriveReady(dnr))
        return 0;
    inf=jtmfat_getinfoblock(dnr);
    if(inf==NULL)
        return 0;
    kernel_start=(DWORD)(FAT_BOOT_SECTION_LEN_K*1024UL)/(DWORD)blocksize;
    kernel_blocks=JTMFS_KERNEL_RESERVE_BYTES/(DWORD)blocksize;
    kernel_end=kernel_start+kernel_blocks;
    if(inf->kernel_offs!=kernel_start || inf->fat_offs<kernel_end ||
       inf->bootblock_size<kernel_end)
        return 0;
    if(inf->res3==JTMFS_BOOT_LAYOUT_TAG &&
       (inf->res4<JTMFS_KERNEL_RESERVE_BYTES ||
        inf->res5<JTMFS_BOOT_LAYOUT_VERSION))
        return 0;
    if(getblocksize(dnr)!=512 || readblock(dnr, 0, boot))
        return 0;
    if(boot[510]!=0x55 || boot[511]!=0xAA)
        return 0;

    /* V16.71.2 moved loader runtime metadata out of MBR bytes 446..509.
     * Accept the new LBA3 JMB2 record and retain legacy checksum fallback for
     * old whole-disk JTMFS volumes. */
    if(blocksize==512 && readblock(dnr,(int)(JTMFS_BOOT_RUNTIME_BYTE_OFFS/512UL),runtime)==0 &&
       ((DWORD)runtime[0] | ((DWORD)runtime[1]<<8) | ((DWORD)runtime[2]<<16) | ((DWORD)runtime[3]<<24))==JTMFS_BOOT_RUNTIME_MAGIC)
        checksum=(WORD)runtime[4] | ((WORD)runtime[5]<<8);
    else
        checksum=(WORD)boot[501] | ((WORD)boot[502]<<8);
    return checksum!=0;
}

static int smsh_set_root_dnr(int dnr, const char *name)
{
    int rootdb, r;

    if(!isValidDevice(dnr))
        return 1;

    /* mountDNR reopens a device which was disabled by SMSH umount. */
    if(mountDNR(dnr))
        return 2;
    if(!jtmfs_isDriveReady(dnr))
        return 3;
    if(mount_root(dnr))
        return 4;

    rootdb=getRootDB();
    if(rootdb<=0 || rootdb>=getsize(dnr))
        return 5;

    SetThreadDNR(GetCurrentThread(), dnr);
    SetThreadDB(GetCurrentThread(), rootdb);

    r=jtmfs_sync_block_device_mountpoints();
    if(r)
        printf("root: warning: block-device mountpoint sync returned %d.\n", r);

    /* Synchronization can exercise caches, but the shell must remain at /. */
    SetThreadDNR(GetCurrentThread(), dnr);
    SetThreadDB(GetCurrentThread(), rootdb);

    printf("root: %s: mounted as / (DNR=%d, DB=%d).\n",
           name ? name : "device", dnr, rootdb);
    /* Root/JTMFS is now writable.  This activates the RAM-buffered /logs logger after the
     * rescue ram mkfs/flexFAT path (or immediately on an installed hda root)
     * and releases KLOGGER to persist its buffered boot messages. */
    SystemLoggingStorageReady();
    return 0;
}

/* Compact list of active/registered JTMOS devices.  getdevicename() is the
 * public query: it returns NULL for unused/released DNR slots, so SMSH does
 * not need to know DEVICE_ENTRY layout or inspect devdb directly. */
int lsdev_app(int argc, char **argv)
{
    int i, amount, active, col;
    char name[32];

    if(argc != 1)
    {
        printf("Usage: lsdev\n");
        return 2;
    }

    amount=driver_getdeviceamount();
    active=0;
    col=0;

    for(i=0; i<amount; ++i)
    {
        int len;

        name[0]=0;
        if(getdevicename(i, name)==NULL || !name[0])
            continue;

        /* DNR 0 is the historical reserved sentinel, not a user device. */
        if(i==0 && !strcmp(name, "dummy"))
            continue;

        len=(int)strlen(name)+1; /* ':' */
        if(col && col+2+len>79)
        {
            printf("\n");
            col=0;
        }
        if(col)
        {
            printf("  ");
            col+=2;
        }
        printf("%s:", name);
        col+=len;
        ++active;
    }

    if(col)
        printf("\n");
    if(!active)
        printf("No active devices.\n");
    else
        printf("%d active device%s.\n", active, active==1 ? "" : "s");

    return 0;
}

static void smsh_print_mounts(void)
{
    int i, amount, rootdnr, cwddnr;
    DEVICE_ENTRY *e;

    rootdnr=getRootDNR();
    cwddnr=GetCurrentDNR();
    amount=driver_getdeviceamount();

    printf("Device        JTMFS  role\n");
    for(i=0; i<amount; ++i)
    {
        e=driver_getdevice(i);
        if(e==NULL || e->isfree || (e->type & DEVICE_TYPE_BLOCK)==0)
            continue;
        printf("%-12s  %-5s  %s%s\n",
               e->device_name,
               jtmfs_isDriveReady(i) ? "yes" : "no",
               i==rootdnr ? "root " : "",
               i==cwddnr ? "cwd" : "");
    }
}

int mount_app(int argc, char **argv)
{
    char name[32];
    int dnr;

    if(argc==1)
    {
        smsh_print_mounts();
        return 0;
    }
    if(argc!=2)
    {
        printf("Usage: mount [device]\n");
        return 2;
    }

    dnr=smsh_device_arg(argv[1], name, sizeof(name));
    if(dnr<0)
    {
        printf("mount: unknown device '%s'.\n", argv[1]);
        return 1;
    }
    if(mountDNR(dnr))
    {
        printf("mount: unable to enable '%s'.\n", name);
        return 1;
    }

    printf("mount: %s enabled; filesystem=%s.\n",
           name, jtmfs_isDriveReady(dnr) ? "JTMFS" : "raw/unformatted");
    return 0;
}

int umount_app(int argc, char **argv)
{
    char name[32];
    int dnr, r;

    if(argc!=2)
    {
        printf("Usage: umount [device]\n");
        return 2;
    }

    dnr=smsh_device_arg(argv[1], name, sizeof(name));
    if(dnr<0)
    {
        printf("umount: unknown device '%s'.\n", argv[1]);
        return 1;
    }

    r=unmountDNR(dnr);
    if(r==2)
    {
        printf("umount: %s is busy (root, process CWD, or open file).\n", name);
        return 1;
    }
    if(r)
    {
        printf("umount: unable to unmount %s (error %d).\n", name, r);
        return 1;
    }

    printf("umount: %s disabled.\n", name);
    return 0;
}

int root_app(int argc, char **argv)
{
    char name[32];
    int dnr, r;

    if(argc!=2)
    {
        printf("Usage: root [device]\n");
        return 2;
    }

    dnr=smsh_device_arg(argv[1], name, sizeof(name));
    if(dnr<0)
    {
        printf("root: unknown device '%s'.\n", argv[1]);
        return 1;
    }

    r=smsh_set_root_dnr(dnr, name);
    if(r)
    {
        printf("root: %s is not a usable JTMFS root (error %d).\n", name, r);
        return 1;
    }
    return 0;
}

/*
 * Reinstall/repair the running boot medium's 1 MiB boot-kernel payload in
 * the reserved JTMFS hard-disk region.  Default boot32pm uses kernel32.bin.nz;
 * legacy boot32 uses raw kernel32.bin.  V63 `mkfs hda` normally performs
 * this automatically; rootinstall remains useful for repair or explicit source
 * selection.  CopyKernel() writes and verifies the kernel and boot checksum.
 *
 * The historical CopyKernel source layout is the JTMOS floppy image: kernel
 * begins at sector 18.  An explicit source argument is accepted for testing,
 * but normal installation should simply use: rootinstall hda
 */
int rootinstall_app(int argc, char **argv)
{
    char target[32], source[256];
    int td, sd=-1, r, biosboot, source_is_device=0;

    if(argc<2 || argc>3)
    {
        printf("Usage: rootinstall [target] [floppy-device|floppy-image]\n");
        printf("Examples:\n");
        printf("  rootinstall hda\n");
        printf("  rootinstall hda floppy:\n");
        printf("  rootinstall hda jtm32.img\n");
        return 2;
    }

    td=smsh_device_arg(argv[1], target, sizeof(target));
    if(td<0)
    {
        printf("rootinstall: unknown target '%s'.\n", argv[1]);
        return 1;
    }
    mountDNR(td);
    /* A partitioned install deliberately keeps JTMFS on hda1 while hda owns
     * only the BIOS MBR + reserved boot/kernel area.  Therefore hda itself is
     * not required to mount as JTMFS.  CopyKernel* validates the MBR, reserved
     * gap and first partition LBA before touching it. */
    if(!jtmfs_isDriveReady(td) && strcmp(target,"hda")!=0 &&
       strcmp(target,"hdb")!=0 && strcmp(target,"hdc")!=0 &&
       strcmp(target,"hdd")!=0)
    {
        printf("rootinstall: target %s is not a bootable whole-disk target.\n",target);
        return 1;
    }
    if(DetermineBootdrv(target)<0x80 || DetermineBootdrv(target)>0x83)
    {
        printf("rootinstall: %s is not an IDE BIOS boot target.\n", target);
        return 1;
    }

    if(argc==3)
    {
        sd=smsh_device_arg(argv[2], source, sizeof(source));
        if(sd>=0)
        {
            source_is_device=1;
        }
        else
        {
            if(argv[2]==NULL || !isValidString(argv[2]) ||
               strlen(argv[2])==0 || strlen(argv[2])>=sizeof(source))
            {
                printf("rootinstall: invalid boot image path.\n");
                return 1;
            }
            strcpy(source,argv[2]);
            source_is_device=0;
        }
    }
    else
    {
        biosboot=GetBiosBootDrive();
        if(biosboot==1)
            strcpy(source, "floppy2");
        else
            strcpy(source, "floppy");
        sd=driver_getdevicenrbyname(source);
        if(!isValidDevice(sd))
        {
            printf("rootinstall: boot floppy device is unavailable.\n");
            printf("rootinstall: specify a raw floppy image, e.g. 'rootinstall %s jtm32.img'.\n",
                   target);
            return 1;
        }
        source_is_device=1;
    }

    if(source_is_device)
    {
        if(sd==td)
        {
            printf("rootinstall: source and target must be different devices.\n");
            return 1;
        }
        mountDNR(sd);
        printf("rootinstall: copying nzip/raw boot payload from device %s to %s ...\n",
               source, target);
        r=CopyKernel(source,target);
    }
    else
    {
        printf("rootinstall: copying nzip/raw boot payload from image %s to %s ...\n",
               source,target);
        r=CopyKernelImage(source,target);
    }

    if(r)
    {
        if(r==14)
            printf("rootinstall: target uses an older/smaller whole-disk JTMFS boot-payload reservation.\n");
        else if(r==17)
            printf("rootinstall: source boot image is not partition-safe V16.71.2+ (its sector-0 code/metadata overlaps the MBR table). Rebuild jtm32.img with the current boot32pm.\n");
        else if(r==18)
        {
            printf("rootinstall: first partition begins inside the reserved JTMOS HDD boot/system area; hda1 must start at LBA 4096 or later.\n");
            printf("rootinstall: after backing up needed data, run: partition hda auto ; mkfs hda1 ; rootinstall hda jtm32.img\n");
        }
        else if(r==19)
            printf("rootinstall: invalid/corrupt MBR partition geometry on %s.\n",target);
        else if(r==30)
            printf("rootinstall: cannot open boot image '%s'.\n",source);
        else if(r==6 && !source_is_device)
            printf("rootinstall: boot image '%s' is too small or cannot be seeked; expected a raw JTMOS floppy image with kernel at LBA36 + 1 MiB payload.\n",source);
        else if(r==8 && !source_is_device)
            printf("rootinstall: boot image '%s' has no valid 0x55AA JTMOS boot record.\n",source);
        printf("rootinstall: kernel installation failed (error %d).\n", r);
        return 1;
    }

    printf("rootinstall: %s boot code + reserved kernel area installed; the filesystem/root may live on %s1.\n",
           target,target);
    return 0;
}

/* SMSH boot policy: an installed hda: wins.  Only SMSH, not KernelInit,
 * creates the volatile rescue filesystem. */
int smsh_boot_root_policy(void)
{
    int dnr, r;

    dnr=driver_getdevicenrbyname("hda");
    if(isValidDevice(dnr))
    {
        mountDNR(dnr);
        if(smsh_installed_root_ready(dnr))
        {
            printf("SMSH boot: installed JTMFS/rootinstall image detected on hda:.\n");
            r=smsh_set_root_dnr(dnr, "hda");
            if(!r)
                return 0;
            printf("SMSH boot: hda: root activation failed (%d); using rescue RAM root.\n", r);
        }
        else if(jtmfs_isDriveReady(dnr))
        {
            printf("SMSH boot: hda: is formatted but boot installation is incomplete; using rescue RAM root.\n");
        }
        else
        {
            printf("SMSH boot: hda: is present but has no valid JTMFS filesystem; using rescue RAM root.\n");
            printf("SMSH boot: initialize a blank disk once with 'mkfs hda' (this erases hda:).\n");
        }
    }

    dnr=driver_getdevicenrbyname("ram");
    if(!isValidDevice(dnr))
    {
        printf("SMSH boot: no usable hda: and ram: device is unavailable.\n");
        return 1;
    }

    mountDNR(dnr);
    if(!jtmfs_isDriveReady(dnr))
    {
        printf("SMSH boot: formatting volatile ram: rescue filesystem ...\n");
        /* ram: is a volatile boot rescue volume.  Do not route this through
         * public mkfs(), whose EBUSY guard can reject the shell's inherited
         * placeholder CWD after an earlier GUI bootstrap attempt.  No
         * persistent medium can be destroyed here, so format the block device
         * directly before making it the namespace root. */
        r=jtmfs_formatdrive(dnr);
        if(r)
        {
            printf("SMSH boot: direct ram: JTMFS format failed (error %d).\n", r);
            return 2;
        }
        if(!jtmfat_chdev(dnr) || !jtmfs_isDriveReady(dnr))
        {
            printf("SMSH boot: ram: format completed but JTMFS readback failed.\n");
            return 2;
        }
    }
    else
    {
        printf("SMSH boot: existing ram: JTMFS detected; preserving it.\n");
    }

    r=smsh_set_root_dnr(dnr, "ram");
    if(r)
    {
        printf("SMSH boot: unable to activate ram: root (error %d).\n", r);
        return 3;
    }

    printf("SMSH boot: rescue/install root is ram:.\n");
    return 0;
}

int bootroot_app(int argc, char **argv)
{
    (void)argv;
    if(argc!=1)
    {
        printf("Usage: bootroot\n");
        return 2;
    }
    return smsh_boot_root_policy();
}

int sync_app(int argc, char **argv)
{
    char name[32];
    int dnr,r;

    if(argc==1)
    {
        (void)SystemLogFlushNow();
        r=sync();
        printf("sync: %s.\n", r==0 ? "all JTMFS metadata and block caches committed" : "writeback error");
        return r==0 ? 0 : 1;
    }
    if(argc!=2)
    {
        printf("Usage: sync [device]\n");
        return 2;
    }

    dnr=smsh_device_arg(argv[1],name,sizeof(name));
    if(dnr<0 || !jtmfs_isDriveReady(dnr))
    {
        printf("sync: '%s' is not an active JTMFS device.\n",argv[1]);
        return 1;
    }
    /* If this is the logging root, push queued report/debug output into the
     * filesystem first; syncdev() below then makes it durable with metadata. */
    (void)SystemLogFlushNow();
    r=syncdev(dnr);
    printf("sync: %s: %s.\n",name,r==0 ? "DIRDB/FAT/DAPI/device cache committed" : "writeback error");
    return r==0 ? 0 : 1;
}


int fsck_app(int argc, char **argv)
{
    JTMFS_CHECK_REPORT r;
    char name[32];
    const char *arg;
    int dnr,verbose,rv;

    verbose=0;
    if(argc==2)
        arg=argv[1];
    else if(argc==3 && (!strcmp(argv[1],"-v") || !strcmp(argv[1],"--verbose")))
    {
        verbose=1;
        arg=argv[2];
    }
    else
    {
        printf("Usage: fsck [-v] <device>\n");
        printf("Read-only physical JTMFS consistency check.\n");
        return 2;
    }

    dnr=smsh_device_arg(arg,name,sizeof(name));
    if(dnr<0 || !jtmfs_isDriveReady(dnr))
    {
        printf("fsck: '%s' is not an active JTMFS device.\n",arg);
        return 1;
    }

    /* The checker itself is read-only and bypasses caches.  First make any
     * caller-visible dirty state durable so the physical image is coherent. */
    if(syncdev(dnr)!=0)
    {
        printf("fsck: %s: unable to commit dirty metadata before scan.\n",name);
        return 1;
    }

    printf("fsck: checking %s from physical media (%d blocks x %d bytes)...\n",
           name,getsize(dnr),getblocksize(dnr));
    rv=jtmfs_check_device(dnr,verbose,&r);
    printf("fsck: FAT free=%u reserved=%u links=%u eoc=%u invalid=%u\n",
           r.fat_free,r.fat_reserved,r.fat_links,r.fat_eoc,r.fat_invalid);
    printf("fsck: dirs=%u files=%u entries=%u deleted=%u reachable=%u orphan=%u\n",
           r.directories,r.files,r.entries,r.deleted_entries,
           r.reachable_blocks,r.orphan_blocks);
    printf("fsck: bad_entries=%u bad_chains=%u crosslinks=%u size_mismatch=%u io_errors=%u\n",
           r.bad_entries,r.bad_chains,r.crosslinks,r.size_mismatches,r.io_errors);
    if(rv==0)
        printf("fsck: %s: CLEAN.\n",name);
    else
        printf("fsck: %s: ERRORS FOUND (read-only; no automatic repair performed).\n",name);
    return rv==0 ? 0 : 1;
}


static void diskspace_print_one(int dnr)
{
    JTMOS_DISKSPACE_STATS st;
    char name[32];
    DWORD total_kib,free_kib,pct,raw_kib;
    int raw_blocks,raw_bs;
    const char *state;

    name[0]=0;
    if(getdevicename(dnr,name)==NULL || !name[0]) return;
    if(DiskSpaceGetStats(dnr,&st,1)!=0) {
        printf("%-10s DNR=%d statistics unavailable.\n",name,dnr);
        return;
    }
    total_kib=DiskSpaceUnitsToKiB(st.total_units,st.unit_size);
    raw_blocks=getsize(dnr);
    raw_bs=getblocksize(dnr);
    raw_kib=(raw_blocks>0 && raw_bs>0) ?
            DiskSpaceUnitsToKiB((DWORD)raw_blocks,(DWORD)raw_bs) : 0;
    if(!(st.flags&DISKSPACE_FLAG_JTMFS)) {
        printf("%-10s DNR=%d raw/block capacity=%u KiB free=n/a\n",
               name,dnr,(unsigned)total_kib);
        return;
    }
    free_kib=DiskSpaceUnitsToKiB(st.free_units,st.unit_size);
    pct=DiskSpacePercentUnits(st.free_units,st.total_units);
    state=(st.flags&DISKSPACE_FLAG_FULL)?"FULL":
          ((st.flags&DISKSPACE_FLAG_CRITICAL)?"CRITICAL":
          ((st.flags&DISKSPACE_FLAG_LOW)?"LOW":"OK"));
    printf("%-10s DNR=%d JTMFS total=%u KiB free=%u KiB (%u%%) state=%s ENOSPC=%u DEVAPI=%u KiB\n",
           name,dnr,(unsigned)total_kib,(unsigned)free_kib,(unsigned)pct,state,
           (unsigned)st.enospc_events,(unsigned)raw_kib);
    if(name[0]=='h' && name[1]=='d' && raw_kib>0 && raw_kib<=64UL*1024UL)
        printf("  WARNING: hard-disk geometry is only %u KiB; if this disk should be larger, check ATA/AHCI IDENTIFY/geometry.\n",
               (unsigned)raw_kib);
}

int diskspace_app(int argc,char **argv)
{
    char name[32];
    int i,dnr,amount,shown=0;

    if(argc==1) {
        amount=driver_getdeviceamount();
        printf("Kernel block-device free-space statistics:\n");
        for(i=0;i<amount && i<DISKSPACE_MAX_DEVICES;i++) {
            if(!isValidDevice(i) || getsize(i)<=0 || getblocksize(i)<=0) continue;
            diskspace_print_one(i);
            shown++;
        }
        if(!shown) printf("diskspace: no block devices available.\n");
        printf("Persistent snapshots: selected /logs/diskspace.log (60 second interval).\n");
        return shown?0:1;
    }

    if(argc==2) {
        dnr=smsh_device_arg(argv[1],name,sizeof(name));
        if(dnr<0) { printf("diskspace: invalid device '%s'.\n",argv[1]); return 1; }
        (void)DiskSpaceRefreshDevice(dnr);
        diskspace_print_one(dnr);
        return 0;
    }

    if(argc==3 && !strcmp(argv[1],"troubleshoot")) {
        dnr=smsh_device_arg(argv[2],name,sizeof(name));
        if(dnr<0) { printf("diskspace: invalid device '%s'.\n",argv[2]); return 1; }
        return DiskSpaceTroubleshootDevice(dnr,"manual diskspace troubleshoot",0,1)==0 ? 0 : 1;
    }

    printf("Usage: diskspace [device]\n");
    printf("       diskspace troubleshoot <device>\n");
    return 2;
}

int fsgeom_app(int argc, char **argv)
{
    char name[32];
    int dnr;
    if(argc!=2) { printf("Usage: fsgeom <device>\n"); return 2; }
    dnr=smsh_device_arg(argv[1],name,sizeof(name));
    if(dnr<0) { printf("fsgeom: invalid device '%s'.\n",argv[1]); return 1; }
    printf("fsgeom: %s DEVAPI blocks=%d blocksize=%d bytes.\n",
           name,getsize(dnr),getblocksize(dnr));
    if(!jtmfs_isDriveReady(dnr))
    {
        printf("fsgeom: %s is not a ready JTMFS filesystem.\n",name);
        return 1;
    }
    jtmfat_dumpgeometry(dnr);
    return 0;
}

/* Two-stage persistence test for the real ATA-backed hda: filesystem.
 * Usage:
 *   hdatest write   -> create marker, flush it, physically re-read it
 *   reboot
 *   hdatest check   -> verify the same marker after a cold kernel restart
 */
int hdatest_app(int argc, char **argv)
{
    static const char marker[]="JTMOS-HDA-PERSISTENCE-V67.8.56.12\n";
    static const char path[]="hda:/PERSIST.TST";
    char buf[sizeof(marker)];
    int dnr,fd,n,sz,r;

    if(argc!=2 || (strcmp(argv[1],"write") && strcmp(argv[1],"check")))
    {
        printf("Usage: hdatest write|check\n");
        return 2;
    }

    dnr=driver_getdevicenrbyname("hda");
    if(!isValidDevice(dnr) || !jtmfs_isDriveReady(dnr))
    {
        printf("hdatest: hda: is not a ready JTMFS filesystem.\n");
        return 1;
    }

    if(!strcmp(argv[1],"write"))
    {
        fd=open(path,O_WRONLY|O_CREAT|O_TRUNC);
        if(fd<0)
        {
            printf("hdatest: cannot create %s.\n",path);
            return 1;
        }
        n=write(fd,(void *)marker,(int)sizeof(marker)-1);
        if(n!=(int)sizeof(marker)-1)
        {
            (void)close(fd);
            printf("hdatest: marker write failed (%d/%d).\n",n,(int)sizeof(marker)-1);
            return 1;
        }
        if(close(fd)!=0)
        {
            printf("hdatest: close/sync failed.\n");
            return 1;
        }
        if(syncdev(dnr)!=0)
        {
            printf("hdatest: sync hda failed.\n");
            return 1;
        }
        /* Simulate the filesystem side of a reboot before verification:
         * discard all clean namespace/FAT/block caches and reload the JTMFS
         * information record physically.  A pass below therefore proves that
         * the root directory, FAT chain and file data can all be reconstructed
         * from media, not merely from RAM state left by this process. */
        dirdb_DiskChange(dnr);
        flexDiskChange(dnr);
        driver_block_cache_invalidate(dnr);
        if(!jtmfat_loadinfoblock(dnr))
        {
            printf("hdatest: physical JTMFS geometry reload FAILED.\n");
            return 1;
        }
    }

    sz=getfilesize(path);
    if(sz!=(int)sizeof(marker)-1)
    {
        printf("hdatest: marker size mismatch/not found (%d, expected %d).\n",
               sz,(int)sizeof(marker)-1);
        return 1;
    }

    memset(buf,0,sizeof(buf));
    fd=open(path,O_RDONLY);
    if(fd<0)
    {
        printf("hdatest: cannot open %s.\n",path);
        return 1;
    }
    n=read(fd,buf,(int)sizeof(marker)-1);
    r=close(fd);
    if(n!=(int)sizeof(marker)-1 || r!=0 ||
       memcmp(buf,marker,(size_t)sizeof(marker)-1)!=0)
    {
        printf("hdatest: persistence verification FAILED.\n");
        return 1;
    }

    if(!strcmp(argv[1],"write"))
        printf("hdatest: cold-cache media reconstruction PASS. Run 'reboot', then 'hdatest check'.\n");
    else
        printf("hdatest: reboot persistence PASS; hda data survived restart.\n");
    return 0;
}

#else

int lsdev_app(int argc, char **argv) { (void)argc; (void)argv; printf("lsdev: JTMOS only.\n"); return 1; }
int mount_app(int argc, char **argv) { (void)argc; (void)argv; printf("mount: JTMOS only.\n"); return 1; }
int umount_app(int argc, char **argv) { (void)argc; (void)argv; printf("umount: JTMOS only.\n"); return 1; }
int root_app(int argc, char **argv) { (void)argc; (void)argv; printf("root: JTMOS only.\n"); return 1; }
int rootinstall_app(int argc, char **argv) { (void)argc; (void)argv; printf("rootinstall: JTMOS only.\n"); return 1; }
int bootroot_app(int argc, char **argv) { (void)argc; (void)argv; return 0; }
int smsh_boot_root_policy(void) { return 0; }
int sync_app(int argc, char **argv) { (void)argc; (void)argv; return 1; }
int hdatest_app(int argc, char **argv) { (void)argc; (void)argv; return 1; }
int fsgeom_app(int argc, char **argv) { (void)argc; (void)argv; return 1; }
int fsck_app(int argc, char **argv) { (void)argc; (void)argv; return 1; }
int diskspace_app(int argc, char **argv) { (void)argc; (void)argv; return 1; }

#endif
