#ifdef JTMOS
/* sqarc.c - bounded, deterministic JTMOS-native SQARC520 creator. */
#include <stdio.h>
#include <string.h>
#include "sqa.h"
#if defined(JTMOSKERNEL)
#include "scheduler.h"
#define SQARC_COOPERATE() SchedulerCooperate()
#else
#define SQARC_COOPERATE() ((void)0)
#endif

#define SQARC_IO_BUFFER 8192
#define SQARC_INITIAL_CAPACITY 64

static FE *jt_entries;
static int jt_entry_count;
static int jt_entry_capacity;

static void jt_release_entries(void)
{
    free(jt_entries);
    jt_entries = NULL;
    jt_entry_count = 0;
    jt_entry_capacity = 0;
}

static int jt_reserve_entry(void)
{
    FE *grown;
    int capacity;
    if(jt_entry_count >= (int)SQA_MAX_FILES) return 1;
    if(jt_entry_count < jt_entry_capacity) return 0;
    capacity = jt_entry_capacity ? jt_entry_capacity * 2 : SQARC_INITIAL_CAPACITY;
    if(capacity > (int)SQA_MAX_FILES) capacity = (int)SQA_MAX_FILES;
    grown = (FE *)malloc((size_t)capacity * sizeof(FE));
    if(grown == NULL) return 1;
    if(jt_entry_count != 0) memcpy(grown,jt_entries,(size_t)jt_entry_count*sizeof(FE));
    free(jt_entries);
    jt_entries = grown;
    jt_entry_capacity = capacity;
    return 0;
}

static int jt_duplicate_name(const char *name)
{
    int i;
    for(i=0;i<jt_entry_count;++i) {
        if((i&31)==31) SQARC_COOPERATE();
        if(strcmp(jt_entries[i].fname,name) == 0) return 1;
    }
    return 0;
}

static void jt_sort_entries(void)
{
    int i,j;
    for(i=1;i<jt_entry_count;++i) {
        FE key = jt_entries[i];
        SQARC_COOPERATE();
        j = i-1;
        while(j >= 0 && strcmp(jt_entries[j].fname,key.fname) > 0) {
            jt_entries[j+1] = jt_entries[j];
            --j;
        }
        jt_entries[j+1] = key;
    }
}

static int jt_write_all(int fd, const void *buffer, int length)
{
    const BYTE *p = (const BYTE *)buffer;
    int done = 0;
    while(done < length) {
        int n = write(fd,p+done,length-done);
        if(n <= 0) return 1;
        done += n;
        SQARC_COOPERATE();
    }
    return 0;
}

static int jt_write_u16_le(int fd, WORD value)
{
    BYTE b[2];
    b[0]=(BYTE)(value&0xffU); b[1]=(BYTE)((value>>8)&0xffU);
    return jt_write_all(fd,b,2);
}

static int jt_write_u32_le(int fd, DWORD value)
{
    BYTE b[4];
    b[0]=(BYTE)(value&0xffUL); b[1]=(BYTE)((value>>8)&0xffUL);
    b[2]=(BYTE)((value>>16)&0xffUL); b[3]=(BYTE)((value>>24)&0xffUL);
    return jt_write_all(fd,b,4);
}

static int jt_file_info(const char *name, DWORD *length, DWORD *checksum)
{
    BYTE *buffer;
    int fd,n,i;
    DWORD total=0U,sum=0U;
    fd=open(name,O_RDONLY);
    if(fd<0)return 1;
    buffer=(BYTE *)malloc(SQARC_IO_BUFFER);
    if(buffer==NULL){close(fd);return 1;}
    for(;;) {
        n=read(fd,buffer,SQARC_IO_BUFFER);
        if(n<0){free(buffer);close(fd);return 1;}
        if(n==0)break;
        if((DWORD)n > 0xffffffffUL-total){free(buffer);close(fd);return 1;}
        for(i=0;i<n;++i) {
            if((i&0xfff)==0xfff) SQARC_COOPERATE();
            sum+=(DWORD)buffer[i]+1U;
        }
        total+=(DWORD)n;
        SQARC_COOPERATE();
    }
    free(buffer);
    if(close(fd)!=0)return 1;
    *length=total; *checksum=sum;
    return 0;
}

static int jt_collect_current_directory(void)
{
    FFBLK ff;
    int findfd,done;
    jt_release_entries();
    findfd=findfirst("*",&ff);
    if(findfd<=0)return 1;
    done=0;
    while(!done) {
        SQARC_COOPERATE();
        if(ff.ff_fsize!=-1 && !JTMFS_TYPE_IS_DIRECTORY(ff.ff_attrib) && ff.ff_name[0]) {
            FE *entry;
            size_t nlen=strlen(ff.ff_name);
            if(nlen>=SQA_FILENAME_SIZE || strchr(ff.ff_name,'/')!=NULL
               || strchr(ff.ff_name,'\\')!=NULL || strchr(ff.ff_name,':')!=NULL
               || jt_duplicate_name(ff.ff_name) || jt_reserve_entry()) {
                printf("sqarc: invalid/duplicate file name: %s\n",ff.ff_name);
                close(findfd); jt_release_entries(); return 1;
            }
            entry=&jt_entries[jt_entry_count];
            memset(entry,0,sizeof(*entry));
            memcpy(entry->fname,ff.ff_name,nlen+1U);
            if(jt_file_info(ff.ff_name,&entry->length,&entry->chksum)) {
                printf("sqarc: unable to read %s\n",ff.ff_name);
                close(findfd); jt_release_entries(); return 1;
            }
            ++jt_entry_count;
        }
        if(findnext(findfd,&ff)!=0)done=1;
    }
    close(findfd);
    jt_sort_entries();
    return 0;
}

static int jt_write_header(int fd)
{
    BYTE zero[256];
    DWORD offset=0U;
    int i;
    memset(zero,0,sizeof(zero));
    for(i=0;i<(int)(SQA_SAFE_AREA_SIZE/(long)sizeof(zero));++i) {
        if(jt_write_all(fd,zero,sizeof(zero)))return 1;
        SQARC_COOPERATE();
    }
    if(jt_write_all(fd,SQA_IDENTIFIER,SQA_IDENTIFIER_SIZE)
       || jt_write_u16_le(fd,(WORD)jt_entry_count))return 1;
    for(i=0;i<jt_entry_count;++i) {
        BYTE reserved=0U;
        SQARC_COOPERATE();
        if(jt_entries[i].length>0xffffffffUL-offset)return 1;
        jt_entries[i].offset=offset;
        offset+=jt_entries[i].length;
        if(jt_write_all(fd,jt_entries[i].fname,SQA_FILENAME_SIZE)
           || jt_write_all(fd,&reserved,1)
           || jt_write_u32_le(fd,jt_entries[i].offset)
           || jt_write_u32_le(fd,jt_entries[i].length)
           || jt_write_u32_le(fd,jt_entries[i].chksum))return 1;
    }
    return 0;
}

static int jt_append_files(int archive_fd)
{
    BYTE *buffer;
    int i;
    buffer=(BYTE *)malloc(SQARC_IO_BUFFER);
    if(buffer==NULL)return 1;
    for(i=0;i<jt_entry_count;++i) {
        int fd,n;
        SQARC_COOPERATE();
        fd=open(jt_entries[i].fname,O_RDONLY);
        if(fd<0){free(buffer);return 1;}
        printf("Adding %s (%u bytes)\n",jt_entries[i].fname,(unsigned)jt_entries[i].length);
        for(;;) {
            n=read(fd,buffer,SQARC_IO_BUFFER);
            if(n<0){close(fd);free(buffer);return 1;}
            if(n==0)break;
            if(jt_write_all(archive_fd,buffer,n)){close(fd);free(buffer);return 1;}
            SQARC_COOPERATE();
        }
        if(close(fd)!=0){free(buffer);return 1;}
    }
    free(buffer);
    return 0;
}

int archive1(const char *pathx, const char *dst)
{
    char oldcwd[512];
    int archive_fd=-1,result=1;
    if(pathx==NULL||dst==NULL||!pathx[0]||!dst[0])return 1;
    if(getcwd(oldcwd,sizeof(oldcwd))==NULL){printf("sqarc: getcwd failed.\n");return 1;}
    if(chdir(pathx)!=0){printf("sqarc: directory not found: %s\n",pathx);return 1;}
    if(jt_collect_current_directory()!=0 || jt_entry_count==0)goto restore_only;
    if(chdir(oldcwd)!=0){jt_release_entries();return 1;}
    archive_fd=open(dst,O_WRONLY|O_TRUNC|O_CREAT);
    if(archive_fd<0){printf("sqarc: unable to create %s\n",dst);jt_release_entries();return 1;}
    if(jt_write_header(archive_fd))goto cleanup;
    if(chdir(pathx)!=0)goto cleanup;
    if(jt_append_files(archive_fd)){(void)chdir(oldcwd);goto cleanup;}
    if(chdir(oldcwd)!=0)goto cleanup;
    if(close(archive_fd)!=0){archive_fd=-1;goto cleanup;}
    archive_fd=-1;
    printf("%d file(s) archived to %s.\n",jt_entry_count,dst);
    result=0;
cleanup:
    if(archive_fd>=0)close(archive_fd);
    if(result!=0)remove(dst);
    jt_release_entries();
    return result;
restore_only:
    (void)chdir(oldcwd);
    jt_release_entries();
    return 1;
}

int archive(const char *pathx,const char *dst){return archive1(pathx,dst);}
int sqarc_main(int argc,char **argv)
{
    if(argc!=3){printf("sqarc - Squirrel Archiver / JTMOS V65\nUsage: sqarc directory archive.sqa\n");return 2;}
    return archive(argv[1],argv[2]);
}

#else
#define _POSIX_C_SOURCE 200809L
/* sqarc.c - POSIX-only Squirrel archiver */
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include "sqa.h"

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

#define COPY_BUFFER_SIZE 65536U
#define FILE_LIST_NAME "/tmp/sqarc.tmp"

static FE entries[SQA_MAX_FILES];
static char jtmosdir[PATH_MAX] = ".";

static int write_exact(int fd, const void *buffer, size_t length)
{
    const BYTE *input = (const BYTE *)buffer;
    size_t done = 0U;

    while (done < length) {
        ssize_t count = write(fd, input + done, length - done);

        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            return -1;
        }
        if (count == 0) {
            errno = EIO;
            return -1;
        }
        done += (size_t)count;
    }
    return 0;
}

static int read_exact(int fd, void *buffer, size_t length)
{
    BYTE *output = (BYTE *)buffer;
    size_t done = 0U;

    while (done < length) {
        ssize_t count = read(fd, output + done, length - done);

        if (count == 0) {
            errno = EIO;
            return -1;
        }
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            return -1;
        }
        done += (size_t)count;
    }
    return 0;
}

static void put_text(int fd, const char *text)
{
    if (text != NULL) {
        (void)write_exact(fd, text, strlen(text));
    }
}

static void put_unsigned(int fd, unsigned long value)
{
    char buffer[32];
    size_t used = 0U;

    do {
        buffer[used++] = (char)('0' + (value % 10UL));
        value /= 10UL;
    } while (value != 0UL && used < sizeof(buffer));

    while (used > 0U) {
        --used;
        (void)write_exact(fd, &buffer[used], 1U);
    }
}

static void put_error(const char *message, const char *name)
{
    if(errno==ENOSPC)
        put_text(STDERR_FILENO, "No space left on device: ");
    put_text(STDERR_FILENO, message);
    if (name != NULL) {
        put_text(STDERR_FILENO, name);
    }
    put_text(STDERR_FILENO, " (errno ");
    put_unsigned(STDERR_FILENO, (unsigned long)errno);
    put_text(STDERR_FILENO, ")\n");
}

static int copy_string(char *destination, size_t capacity, const char *source)
{
    size_t length;

    if (destination == NULL || capacity == 0U || source == NULL) {
        errno = EINVAL;
        return -1;
    }
    length = strlen(source);
    if (length >= capacity) {
        errno = ENAMETOOLONG;
        return -1;
    }
    memcpy(destination, source, length + 1U);
    return 0;
}

static int append_string(char *destination, size_t capacity, const char *text)
{
    size_t used;
    size_t extra;

    if (destination == NULL || text == NULL) {
        errno = EINVAL;
        return -1;
    }
    used = strlen(destination);
    extra = strlen(text);
    if (used + extra >= capacity) {
        errno = ENAMETOOLONG;
        return -1;
    }
    memcpy(destination + used, text, extra + 1U);
    return 0;
}

static int join_path(char *destination, size_t capacity,
                     const char *left, const char *right)
{
    size_t length;

    destination[0] = '\0';
    if (copy_string(destination, capacity, left) != 0) {
        return -1;
    }
    length = strlen(destination);
    if (length > 0U && destination[length - 1U] != '/') {
        if (append_string(destination, capacity, "/") != 0) {
            return -1;
        }
    }
    return append_string(destination, capacity, right);
}

static const char *base_name(const char *path)
{
    const char *slash;

    if (path == NULL) {
        return "";
    }
    slash = strrchr(path, '/');
    return slash != NULL ? slash + 1 : path;
}

void CutName(char *destination, const char *source)
{
    const char *name = base_name(source);

    if (destination == NULL) {
        return;
    }
    destination[0] = '\0';
    (void)copy_string(destination, SQA_FILENAME_SIZE, name);
}

SQA_UINT32 chksum(const BYTE *buffer, size_t length)
{
    size_t i;
    SQA_UINT32 value = 0U;

    for (i = 0U; i < length; ++i) {
        value += (SQA_UINT32)buffer[i] + 1U;
    }
    return value;
}

static int write_u16_le(int fd, unsigned int value)
{
    BYTE bytes[2];

    bytes[0] = (BYTE)(value & 0xffU);
    bytes[1] = (BYTE)((value >> 8U) & 0xffU);
    return write_exact(fd, bytes, sizeof(bytes));
}

static int write_u32_le(int fd, SQA_UINT32 value)
{
    BYTE bytes[4];

    bytes[0] = (BYTE)(value & 0xffU);
    bytes[1] = (BYTE)((value >> 8U) & 0xffU);
    bytes[2] = (BYTE)((value >> 16U) & 0xffU);
    bytes[3] = (BYTE)((value >> 24U) & 0xffU);
    return write_exact(fd, bytes, sizeof(bytes));
}

static int read_u16_record(int fd, unsigned int *value)
{
    BYTE bytes[2];
    ssize_t first;

    do {
        first = read(fd, bytes, 1U);
    } while (first < 0 && errno == EINTR);

    if (first == 0) {
        return 0;
    }
    if (first < 0 || read_exact(fd, bytes + 1U, 1U) != 0) {
        return -1;
    }
    *value = (unsigned int)bytes[0] | ((unsigned int)bytes[1] << 8U);
    return 1;
}

static int write_path_record(int fd, const char *path)
{
    size_t length = strlen(path);

    if (length == 0U || length > 65535U) {
        errno = ENAMETOOLONG;
        return -1;
    }
    if (write_u16_le(fd, (unsigned int)length) != 0
        || write_exact(fd, path, length) != 0) {
        return -1;
    }
    return 0;
}

static int read_path_record(int fd, char *path, size_t capacity)
{
    unsigned int length;
    int status = read_u16_record(fd, &length);

    if (status <= 0) {
        return status;
    }
    if ((size_t)length >= capacity) {
        errno = ENAMETOOLONG;
        return -1;
    }
    if (read_exact(fd, path, (size_t)length) != 0) {
        return -1;
    }
    path[length] = '\0';
    return 1;
}

static int file_size_and_checksum(const char *path, SQA_UINT32 *length,
                                  SQA_UINT32 *checksum)
{
    BYTE buffer[COPY_BUFFER_SIZE];
    SQA_UINT32 sum = 0U;
    SQA_UINT32 total = 0U;
    int fd = open(path, O_RDONLY);

    if (fd < 0) {
        return -1;
    }

    for (;;) {
        ssize_t count = read(fd, buffer, sizeof(buffer));
        size_t i;

        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            (void)close(fd);
            return -1;
        }
        if (count == 0) {
            break;
        }
        if ((SQA_UINT32)count > (SQA_UINT32)INT32_MAX - total) {
            (void)close(fd);
            errno = EFBIG;
            return -1;
        }
        for (i = 0U; i < (size_t)count; ++i) {
            sum += (SQA_UINT32)buffer[i] + 1U;
        }
        total += (SQA_UINT32)count;
    }

    if (close(fd) != 0) {
        return -1;
    }
    *length = total;
    *checksum = sum;
    return 0;
}

static int duplicate_archive_name(const char *name, size_t count)
{
    size_t i;

    for (i = 0U; i < count; ++i) {
        if (strcmp(entries[i].fname, name) == 0) {
            return 1;
        }
    }
    return 0;
}

static int collect_regular_file(const char *path, int list_fd,
                                size_t *file_count, SQA_UINT32 *next_offset)
{
    const char *name = base_name(path);
    FE *entry;
    size_t name_length;

    if (*file_count >= SQA_MAX_FILES) {
        put_text(STDERR_FILENO, "Too many files in source tree.\n");
        errno = EFBIG;
        return -1;
    }

    name_length = strlen(name);
    if (name_length == 0U || name_length >= SQA_FILENAME_SIZE) {
        put_text(STDERR_FILENO, "Archive file name is too long: ");
        put_text(STDERR_FILENO, path);
        put_text(STDERR_FILENO, "\n");
        errno = ENAMETOOLONG;
        return -1;
    }
    if (duplicate_archive_name(name, *file_count)) {
        put_text(STDERR_FILENO, "Duplicate archive file name: ");
        put_text(STDERR_FILENO, name);
        put_text(STDERR_FILENO, "\n");
        errno = EEXIST;
        return -1;
    }

    entry = &entries[*file_count];
    memset(entry, 0, sizeof(*entry));
    if (copy_string(entry->fname, sizeof(entry->fname), name) != 0
        || file_size_and_checksum(path, &entry->length,
                                  &entry->chksum) != 0) {
        put_error("Unable to read: ", path);
        return -1;
    }
    if ((SQA_UINT32)entry->length > (SQA_UINT32)INT32_MAX - *next_offset) {
        put_text(STDERR_FILENO, "Archive data is too large.\n");
        errno = EFBIG;
        return -1;
    }

    entry->offset = (DWORD)*next_offset;
    *next_offset += (SQA_UINT32)entry->length;

    if (write_path_record(list_fd, path) != 0) {
        put_error("Unable to save source path: ", path);
        return -1;
    }

    put_text(STDERR_FILENO, "Adding ");
    put_text(STDERR_FILENO, path);
    put_text(STDERR_FILENO, "\n");
    ++*file_count;
    return 0;
}

static int collect_tree(const char *path, int list_fd,
                        size_t *file_count, SQA_UINT32 *next_offset)
{
    struct stat status;

    if (lstat(path, &status) != 0) {
        put_error("Unable to inspect: ", path);
        return -1;
    }
    if (S_ISREG(status.st_mode)) {
        return collect_regular_file(path, list_fd, file_count, next_offset);
    }
    if (S_ISDIR(status.st_mode)) {
        DIR *directory = opendir(path);
        struct dirent *item;
        int result = 0;

        if (directory == NULL) {
            put_error("Unable to open directory: ", path);
            return -1;
        }

        errno = 0;
        while ((item = readdir(directory)) != NULL) {
            char child[PATH_MAX];

            if (strcmp(item->d_name, ".") == 0
                || strcmp(item->d_name, "..") == 0) {
                continue;
            }
            if (join_path(child, sizeof(child), path, item->d_name) != 0) {
                put_error("Path is too long below: ", path);
                result = -1;
                break;
            }
            if (collect_tree(child, list_fd, file_count, next_offset) != 0) {
                result = -1;
                break;
            }
            errno = 0;
        }
        if (item == NULL && errno != 0 && result == 0) {
            put_error("Unable to read directory: ", path);
            result = -1;
        }
        if (closedir(directory) != 0 && result == 0) {
            put_error("Unable to close directory: ", path);
            result = -1;
        }
        return result;
    }

    /* Symbolic links, devices, sockets and other non-regular files are skipped. */
    return 0;
}

static int write_safe_area(int archive_fd)
{
    char boot_path[PATH_MAX];
    BYTE buffer[SQA_SAFE_AREA_SIZE];
    size_t used = 0U;
    int boot_fd;

    memset(buffer, 0, sizeof(buffer));
    if (join_path(boot_path, sizeof(boot_path),
                  jtmosdir, "boot32/nonsysdisk.bin") != 0) {
        return -1;
    }

    boot_fd = open(boot_path, O_RDONLY);
    if (boot_fd < 0 && errno == ENOENT) {
        if (join_path(boot_path, sizeof(boot_path),
                      jtmosdir, "boot32/nonsysdisk.biz") != 0) {
            return -1;
        }
        boot_fd = open(boot_path, O_RDONLY);
    }
    if (boot_fd >= 0) {
        while (used < sizeof(buffer)) {
            ssize_t count = read(boot_fd, buffer + used,
                                 sizeof(buffer) - used);

            if (count < 0) {
                if (errno == EINTR) {
                    continue;
                }
                (void)close(boot_fd);
                return -1;
            }
            if (count == 0) {
                break;
            }
            used += (size_t)count;
        }
        if (close(boot_fd) != 0) {
            return -1;
        }
    } else if (errno != ENOENT) {
        return -1;
    } else {
        put_text(STDERR_FILENO,
                 "Warning: boot32/nonsysdisk.bin/.biz not found; using zeros.\n");
    }

    return write_exact(archive_fd, buffer, sizeof(buffer));
}

static int write_directory(int archive_fd, size_t file_count)
{
    size_t i;

    if (write_exact(archive_fd, SQA_IDENTIFIER, SQA_IDENTIFIER_SIZE) != 0
        || write_u16_le(archive_fd, (unsigned int)file_count) != 0) {
        return -1;
    }

    for (i = 0U; i < file_count; ++i) {
        const FE *entry = &entries[i];
        BYTE reserved = 0U;

        if (write_exact(archive_fd, entry->fname,
                        SQA_FILENAME_SIZE) != 0
            || write_exact(archive_fd, &reserved, 1U) != 0
            || write_u32_le(archive_fd,
                            (SQA_UINT32)entry->offset) != 0
            || write_u32_le(archive_fd,
                            (SQA_UINT32)entry->length) != 0
            || write_u32_le(archive_fd, entry->chksum) != 0) {
            return -1;
        }
    }
    return 0;
}

static int append_file(int archive_fd, const char *path)
{
    BYTE buffer[COPY_BUFFER_SIZE];
    int source_fd = open(path, O_RDONLY);

    if (source_fd < 0) {
        return -1;
    }

    for (;;) {
        ssize_t count = read(source_fd, buffer, sizeof(buffer));

        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            (void)close(source_fd);
            return -1;
        }
        if (count == 0) {
            break;
        }
        if (write_exact(archive_fd, buffer, (size_t)count) != 0) {
            (void)close(source_fd);
            return -1;
        }
    }

    return close(source_fd);
}

int archive1(const char *pathx, const char *dst)
{
    int list_fd = -1;
    int archive_fd = -1;
    size_t file_count = 0U;
    SQA_UINT32 next_offset = 0U;
    size_t i;
    int result = 1;

    if (pathx == NULL || dst == NULL
        || pathx[0] == '\0' || dst[0] == '\0') {
        errno = EINVAL;
        return 1;
    }

    memset(entries, 0, sizeof(entries));
    list_fd = open(FILE_LIST_NAME, O_RDWR | O_CREAT | O_TRUNC, 0600);
    if (list_fd < 0) {
        put_error("Unable to create temporary path list: ", FILE_LIST_NAME);
        goto cleanup;
    }

    if (collect_tree(pathx, list_fd, &file_count, &next_offset) != 0) {
        goto cleanup;
    }
    if (file_count == 0U) {
        put_text(STDERR_FILENO, "No regular files found.\n");
        goto cleanup;
    }
    if (lseek(list_fd, 0, SEEK_SET) == (off_t)-1) {
        put_error("Unable to rewind temporary path list", NULL);
        goto cleanup;
    }

    archive_fd = open(dst, O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (archive_fd < 0) {
        put_error("Unable to create archive: ", dst);
        goto cleanup;
    }

    if (write_safe_area(archive_fd) != 0
        || write_directory(archive_fd, file_count) != 0) {
        put_error("Unable to write archive header: ", dst);
        goto cleanup;
    }

    for (i = 0U; i < file_count; ++i) {
        char source_path[PATH_MAX];
        int record_status = read_path_record(list_fd, source_path,
                                             sizeof(source_path));

        if (record_status != 1) {
            put_error("Unable to read temporary source path", NULL);
            goto cleanup;
        }
        if (append_file(archive_fd, source_path) != 0) {
            put_error("Unable to archive: ", source_path);
            goto cleanup;
        }
    }

    if (close(archive_fd) != 0) {
        archive_fd = -1;
        put_error("Unable to finish archive: ", dst);
        goto cleanup;
    }
    archive_fd = -1;

    put_unsigned(STDERR_FILENO, (unsigned long)file_count);
    put_text(STDERR_FILENO, " file(s) archived.\n");
    result = 0;

cleanup:
    if (archive_fd >= 0) {
        (void)close(archive_fd);
    }
    if (list_fd >= 0) {
        (void)close(list_fd);
    }
    (void)unlink(FILE_LIST_NAME);
    if (result != 0) {
        (void)unlink(dst);
    }
    return result;
}

int archive(const char *pathx, const char *dst)
{
    return archive1(pathx, dst);
}

static void print_usage(void)
{
    put_text(STDOUT_FILENO, "sqarc - Squirrel Archiver\n");
    put_text(STDOUT_FILENO, "(C) 2002-2026 by Jari Tuominen\n");
    put_text(STDOUT_FILENO, "Usage: sqarc directory archive.sqa\n");
}

int sqarc_main(int argc, char **argv)
{
    if (argc < 3 || argv == NULL || argv[1] == NULL || argv[2] == NULL) {
        print_usage();
        return 0;
    }

    if (copy_string(jtmosdir, sizeof(jtmosdir), ".") != 0) {
        return 1;
    }
    return archive(argv[1], argv[2]);
}

#endif /* JTMOS */
