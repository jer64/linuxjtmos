/*
 * memdump.c - SMSH kernel-memory and file hex/ASCII dump builtins.
 *
 * Ported from the historical SMSH syssh_kmed/syssh_mf routines.  The old
 * implementation used global syssh.cmdpar[] state and, for mf, terminated a
 * temporary command thread with ExitThread().  Current SMSH builtins execute
 * in the persistent shell thread, so these commands expose conventional
 * argc/argv Main entry points and return normally to the prompt.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "memdump.h"

#ifdef JTMOS
#include "kernel32.h"
#endif

#define SMSH_DUMP_LINE_BYTES       16U
#define SMSH_DUMP_PAGE_LINES       16U
#define SMSH_FILE_DUMP_CHUNK       4096U
#define SMSH_KMED_DEFAULT_LENGTH   0x000fffffUL

static const char smsh_hex_digits[] = "0123456789ABCDEF";

static void smsh_print_hex_byte(unsigned int value)
{
    char hex[3];

    value &= 0xffU;
    hex[0] = smsh_hex_digits[(value >> 4) & 15U];
    hex[1] = smsh_hex_digits[value & 15U];
    hex[2] = '\0';

    /* JTMOS historically had a broken vararg %c implementation.  Keep the
     * hexdump independent of single-character varargs and emit the complete
     * byte as one string. */
    printf("%s", hex);
}

/* Preserve the historical kmed convention: an unprefixed address is hex.
 * 0x/0X is accepted as well. */
static int smsh_parse_hex32(const char *text, unsigned long *value)
{
    unsigned long v;
    unsigned int digit;
    const char *p;
    char ch;

    if(text == NULL || value == NULL || *text == '\0')
        return 1;

    p = text;
    if(p[0] == '0' && (p[1] == 'x' || p[1] == 'X'))
        p += 2;
    if(*p == '\0')
        return 1;

    v = 0;
    while(*p)
    {
        ch = *p++;
        if(ch >= '0' && ch <= '9')
            digit = (unsigned int)(ch - '0');
        else if(ch >= 'a' && ch <= 'f')
            digit = (unsigned int)(ch - 'a') + 10U;
        else if(ch >= 'A' && ch <= 'F')
            digit = (unsigned int)(ch - 'A') + 10U;
        else
            return 1;

        if(v > 0x0fffffffUL)
            return 1;
        v = (v << 4) | (unsigned long)digit;
    }

    *value = v;
    return 0;
}

#ifdef JTMOS
static int smsh_dump_range_readable(unsigned long address, unsigned int amount)
{
    unsigned long last;

    if(amount == 0U)
        return 1;
    if(address > 0xffffffffUL - (unsigned long)(amount - 1U))
        return 0;

    last = address + (unsigned long)(amount - 1U);
    if(illegal((const void *)address) || illegal((const void *)last))
        return 0;
    return 1;
}

static int smsh_dump_getch(void)
{
    return getch();
}
#else
static int smsh_dump_getch(void)
{
    return getchar();
}
#endif

/* Returns 1 if ESC aborted the display, otherwise 0. */
static int smsh_display_memory_internal(const unsigned char *buf,
                                        unsigned int sz,
                                        unsigned long display_offset,
                                        int memory_addresses,
                                        unsigned int *line_counter)
{
    unsigned int pos;
    unsigned int line_len;
    unsigned int x;
    unsigned int ch;
    unsigned long shown;
    int key;

    if(buf == NULL || line_counter == NULL)
        return 0;

    for(pos = 0; pos < sz; pos += line_len)
    {
        line_len = sz - pos;
        if(line_len > SMSH_DUMP_LINE_BYTES)
            line_len = SMSH_DUMP_LINE_BYTES;

#ifdef JTMOS
        if(memory_addresses &&
           !smsh_dump_range_readable((unsigned long)(buf + pos), line_len))
        {
            printf("%x: [unmapped memory - dump stopped]\n",
                   (unsigned int)(unsigned long)(buf + pos));
            return 1;
        }
#endif

        if(memory_addresses)
            shown = (unsigned long)(buf + pos);
        else
            shown = display_offset + (unsigned long)pos;

        printf("%x: ", (unsigned int)shown);

        for(x = 0; x < SMSH_DUMP_LINE_BYTES; ++x)
        {
            if(x < line_len)
                smsh_print_hex_byte((unsigned int)buf[pos + x]);
            else
                printf("  ");
            printf(" ");
        }
        printf(" ");

        for(x = 0; x < line_len; ++x)
        {
            ch = (unsigned int)buf[pos + x];
            if(ch < 0x20U || ch >= 0x7fU)
                ch = (unsigned int)'.';
            printf("%c", (int)ch);
        }
        printf("\n");

        ++(*line_counter);
        if((*line_counter % SMSH_DUMP_PAGE_LINES) == 0U)
        {
            printf("\r[Press any key, ESC to stop]\r");
            key = smsh_dump_getch();
            printf("\r                              \r");
            if(key == 27)
                return 1;
        }
    }

    return 0;
}

void DisplayMemory(char *buf, int sz, int offs, char memoryAddresses)
{
    unsigned int lines;

    if(buf == NULL || sz <= 0)
        return;

    lines = 0;
    (void)smsh_display_memory_internal((const unsigned char *)buf,
                                       (unsigned int)sz,
                                       (unsigned long)(unsigned int)offs,
                                       memoryAddresses ? 1 : 0,
                                       &lines);
}

void DisplayMemory2(char *buf, int sz, int offs)
{
    unsigned int lines;

    if(buf == NULL || sz <= 0)
        return;

    lines = 0;
    (void)smsh_display_memory_internal((const unsigned char *)buf,
                                       (unsigned int)sz,
                                       (unsigned long)(unsigned int)offs,
                                       0,
                                       &lines);
}

int kmed_main(int argc, char **argv)
{
    unsigned long address;
    unsigned long length;
    unsigned long remaining;
    unsigned long current;
    unsigned int part;
    unsigned int lines;

    if(argc < 2 || argc > 3 || argv == NULL || argv[1] == NULL)
    {
        printf("Usage: m <hex-address> [hex-length]\n");
        printf("Example: m B8000 100\n");
        printf("Example: m 0x100000 1000\n");
        return 1;
    }

    if(smsh_parse_hex32(argv[1], &address) != 0)
    {
        printf("m: invalid hexadecimal address '%s'.\n", argv[1]);
        return 1;
    }

    length = SMSH_KMED_DEFAULT_LENGTH;
    if(argc == 3)
    {
        if(argv[2] == NULL || smsh_parse_hex32(argv[2], &length) != 0 ||
           length == 0UL)
        {
            printf("m: invalid hexadecimal length.\n");
            return 1;
        }
    }

#ifdef JTMOS
    if(!smsh_dump_range_readable(address, 1U))
    {
        printf("m: address 0x%x is not mapped.\n", (unsigned int)address);
        return 1;
    }

    printf("Kernel memory dump 0x%x, up to 0x%x bytes.\n",
           (unsigned int)address, (unsigned int)length);

    remaining = length;
    current = address;
    lines = 0;
    while(remaining != 0UL)
    {
        /* Never ask the display routine to span more than one page at once.
         * This makes arbitrary-memory inspection stop cleanly at an unmapped
         * page instead of triggering a kernel page fault. */
        part = 4096U - ((unsigned int)current & 4095U);
        if((unsigned long)part > remaining)
            part = (unsigned int)remaining;

        if(!smsh_dump_range_readable(current, part))
        {
            printf("0x%x: [unmapped memory - dump stopped]\n",
                   (unsigned int)current);
            break;
        }

        if(smsh_display_memory_internal((const unsigned char *)current,
                                        part, current, 1, &lines))
            break;

        current += (unsigned long)part;
        remaining -= (unsigned long)part;
        if(current == 0UL)
            break;
    }
    return 0;
#else
    (void)address;
    (void)length;
    (void)remaining;
    (void)current;
    (void)part;
    (void)lines;
    printf("m: kernel memory dump is available only in JTMOS.\n");
    return 1;
#endif
}

int file_memory_dump_main(int argc, char **argv)
{
    const char *path;
    unsigned char *buf;
    unsigned int lines;
    unsigned int amount;
    unsigned long offset;
    long size;

    if(argc != 2 || argv == NULL || argv[1] == NULL)
    {
        printf("Usage: fm <filename>\n");
        printf("Example: fm kernel32.bin\n");
        return 1;
    }

    path = argv[1];

#ifdef JTMOS
    size = (long)getfilesize(path);
    if(size <= 0)
    {
        printf("File not found or empty: '%s'\n", path);
        return 1;
    }

    printf("%s = %d bytes\n", path, (int)size);
    buf = (unsigned char *)malloc(SMSH_FILE_DUMP_CHUNK);
    if(buf == NULL)
    {
        printf("fm: out of memory.\n");
        return 1;
    }

    lines = 0;
    offset = 0UL;
    while(offset < (unsigned long)size)
    {
        amount = (unsigned int)((unsigned long)size - offset);
        if(amount > SMSH_FILE_DUMP_CHUNK)
            amount = SMSH_FILE_DUMP_CHUNK;

        memset(buf, 0, amount);
        readfile((char *)path, (char *)buf, (int)offset, (int)amount);

        if(smsh_display_memory_internal(buf, amount, offset, 0, &lines))
            break;
        offset += (unsigned long)amount;
    }

    free(buf);
    return 0;
#else
    {
        FILE *fp;
        long file_size;
        size_t got;

        fp = fopen(path, "rb");
        if(fp == NULL)
        {
            printf("File not found: '%s'\n", path);
            return 1;
        }
        if(fseek(fp, 0L, SEEK_END) != 0)
        {
            fclose(fp);
            return 1;
        }
        file_size = ftell(fp);
        if(file_size < 0 || fseek(fp, 0L, SEEK_SET) != 0)
        {
            fclose(fp);
            return 1;
        }
        size = file_size;
        printf("%s = %ld bytes\n", path, size);

        buf = (unsigned char *)malloc(SMSH_FILE_DUMP_CHUNK);
        if(buf == NULL)
        {
            fclose(fp);
            printf("fm: out of memory.\n");
            return 1;
        }

        lines = 0;
        offset = 0UL;
        while(offset < (unsigned long)size)
        {
            got = fread(buf, 1, SMSH_FILE_DUMP_CHUNK, fp);
            if(got == 0U)
                break;
            if(smsh_display_memory_internal(buf, (unsigned int)got,
                                            offset, 0, &lines))
                break;
            offset += (unsigned long)got;
        }

        free(buf);
        fclose(fp);
        return 0;
    }
#endif
}
