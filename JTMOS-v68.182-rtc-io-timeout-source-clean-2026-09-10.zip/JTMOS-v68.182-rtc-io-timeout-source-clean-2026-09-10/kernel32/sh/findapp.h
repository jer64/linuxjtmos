#ifndef __INCLUDED_FINDAPP_H__
#define __INCLUDED_FINDAPP_H__
int find_app(int argc, char **argv);
#endif
