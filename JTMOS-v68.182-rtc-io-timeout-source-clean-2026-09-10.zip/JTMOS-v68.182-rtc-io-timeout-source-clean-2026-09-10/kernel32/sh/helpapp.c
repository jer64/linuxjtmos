//--------------------------------------------------------------------------------------------
// helpapp.c - Shell Manual.
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include "helpapp.h"

// Bring up the manual.
int help_app(int argc, char **argv)
{
	//
	printf("cd - changes directory\n");
	printf("chdir - changes directory\n");
	printf("ls [-l] - list directory; -l puts one name on each line\n");
	printf("dir [-l] - alias for ls\n");
	printf("find [OPTIONS] [DIRECTORY] [OPTIONS] - recursive search; supports -type f|d and -maxdepth N\n");
	printf("mkdir [-p] <directory> [directory ...] - create directories/parents\n");
	printf("set [NAME=VALUE] - list/set current process environment\n");
	printf("setglobal [NAME=VALUE] - list/set kernel global environment\n");
	printf("keymap [english|finnish] (alias: kbd) - show/change keyboard layout; default English\n");
	printf("usbinfo - show preliminary USB HID/input transport status\n");
	printf("mouseinfo [reinit] (alias: mouse) - show PS/2 status; reinit is diagnostic only\n");
	printf("lsdev - list active devices compactly\n");
#if JTMOS_MOD_PCI
	printf("lspci [-v] - list PCI functions, capabilities and BAR resources\n");
#endif
	printf("mkfs [device] - format an unused device as JTMFS\n");
	printf("mount [device] - enable/list block devices\n");
	printf("umount [device] - disable an unused block device\n");
	printf("root [device] - select an existing JTMFS namespace root\n");
	printf("rootinstall <target> [floppy-device|floppy-image] - install boot kernel; examples: rootinstall hda floppy: / rootinstall hda jtm32.img\n");
	printf("sound [sb|gus] [file.wav] - play 8-bit mono PCM WAV or built-in demo\n");
	printf("internet [start|static IP MASK [GW] [DNS]|restart|reset|stop|status|stats [reset]] - manage Ethernet DHCP/uIP and packet counters\n");
	printf("ping [-c count] <host|IPv4|gateway> - DHCP/DNS-routed ICMP echo through Ethernet/uIP\n");
	printf("more [-n lines] [file ...] - page external/piped output (example: inet status | more)\n");
	printf("host <hostname> - resolve DNS A records using DHCP DNS\n");
	printf("async [status|poll ID|wait ID|cancel ID|ping IP|host NAME] - KAsync jobs\n");
	printf("www [start [port]|auto|stop|status] - HTTP; auto starts port 8080 after a DHCP lease\n");
	printf("telnetd [status|start [port]|auto [port]|stop] - authenticated remote SQSH; default 2323\n");
	printf("bootroot - re-run SMSH root selection (hda first, ram rescue second)\n");
	printf("sync [device] - commit DIRDB/FAT/block caches (example: sync hda)\n");
	printf("hdatest write|check - write durable HDA marker / verify it after reboot\n");
	printf("fsgeom <device> - show DEVAPI/JTMFS block geometry and offsets\n");
	printf("fsck [-v] <device> - read-only physical JTMFS integrity scan\n");
	printf("diskspace [device] - kernel free-space counters; diskspace troubleshoot <device> for diagnostics\n");
	printf("ai [diagnose|QUESTION...] - offline Native AI diagnosis from live kernel telemetry\n");
	printf("reboot / reset - sync storage and reboot the system\n");
	printf("format [device name]\n");
	printf("help - this manual\n");
	printf("exit / quit - leave SMSH\n");
	printf("sqa archive.sqa [options] - extract Squirrel archive\n");
	printf("sqarc directory archive.sqa - create Squirrel archive\n");
	printf("nzip file / nzip -d file.nz - compress or extract\n");
	printf("kyber [status|on|off|target|targetms|reset] - low-latency block I/O scheduler\n");
	printf("sched - show responsive reward scheduler state and counters\n");
	printf("copyall [-r] <source> - copy+verify files; -r recursively preserves subdirectories\n");
	printf("rm_wildcard [text] (aliases: rmwild, rmw) - delete matching files\n");
	printf("debug [on|off|toggle|status] (alias: debug1) - kernel debug level 1\n");
	printf("report [on|off|toggle|status] (alias: debug2) - reporting level 2\n");
	printf("d0 - debug/report/normal serial off until next FS-log root activation; crash serial retained\n");
	printf("system log: hda1:/logs/system.log when hda1 is JTMFS; otherwise configured target /logs\n");
	printf("disk-space history: selected /logs/diskspace.log (rolling 60-second snapshots)\n");
	printf("m <hex-address> [hex-length] (alias: kmed) - kernel memory hex/ASCII dump\n");
	printf("fm <filename> - file hex/ASCII dump\n");
	printf("free [-b|-k|-m|-g] [-h] [-w] [-s seconds] [-c count] - memory usage\n");
	printf("fork - clone this ELF32 process and verify parent/child fork() returns\n");
	printf("gfx [auto|640x480|1024x768] - enable LFB virtual-terminal rendering\n");
	printf("gfx [geforce|vmvga] [640x480|1024x768] - force graphics provider/mode\n");
	printf("gfx vt 0..6 | gfx status | gfx off - select VT, inspect, or stop renderer\n");
	printf("graos / gui - start the Ring3 GraOS desktop (or report if already running)\n");
	printf("postman / pm [status|find NAME|exec COMMAND...|cleanup] - native IPC/process adapter\n");
	printf(":program [args] - load an external .bin through LaunchApp (example: :install)\n");
	printf(":program [args] & - start explicit external program in background\n");
	printf("command1 | command2 [| command3 ...] - kernel pipe pipeline (max 16 stages)\n");
	printf("  examples: ls | cat, cat file.txt | cat, ps | cat\n");
	printf("Unknown commands without ':' keep the legacy system() fallback.\n");
	printf("\n");

	return 0;
}
