/*
 * nzip.c - JTMOS Peanut/Nut Zip codec.
 *
 * V16.71 default encoder is NZIP2: a fast gzip/DEFLATE-style LZ77 stream
 * with a 32 KiB window and fixed tokens.  It removes ADVPAK/BWT from the hot
 * path and makes decompression linear-memory-copy work with no output seeks.
 *
 * The decoder remains compatible with the historical JTMOS V1 stream:
 *   0xFCE3 char packer (RLE)
 *   0xFCE4 absolute back-reference (sequence compressor)
 *   0xFCEE end marker
 *   0xFCEF escaped marker-looking literal pair
 *
 * V65 adds:
 *   0xFCE5 BWT block = BWT -> MTF -> zero-run coding, protected by CRC32.
 *
 * The default encoder works block-by-block.  It encodes the same raw block
 * with the legacy RLE/back-reference path and with BWT.  When BWT is smaller,
 * BWT wins; otherwise the legacy candidate is emitted.  The resulting .nz
 * stream can therefore mix all three compression methods.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "nzip.h"

#if defined(JTMOSKERNEL)
#include "kernel32.h"
#include "scheduler.h"
#define NZIP_COOPERATE() SchedulerCooperate()
#define NZIP_COOPERATE_EVERY(v) do { if((((size_t)(v))&0x0fffU)==0U) SchedulerCooperate(); } while(0)
#else
#define NZIP_COOPERATE() ((void)0)
#define NZIP_COOPERATE_EVERY(v) ((void)0)
#endif

#if defined(JTMOS_APPLICATION)
#include <jtmos/process.h>
/* 12 MiB is working memory, not a decoded-file size limit.  V16.70.1 writes
 * decompressed bytes directly to the destination file so output may be much
 * larger than the process SYSMEMREQ reservation. */
SYSMEMREQ(APPRAM_12288K)
#endif

typedef struct nzip_buffer {
    BYTE *data;
    size_t size;
    size_t capacity;
} NZIP_BUFFER;

typedef struct nzip_stats {
    unsigned long raw_bytes;
    unsigned long legacy_bytes;
    unsigned long bwt_bytes;
    unsigned legacy_blocks;
    unsigned bwt_blocks;
} NZIP_STATS;


typedef struct nzip_reader {
    FILE *file;
    BYTE *buffer;
    size_t pos;
    size_t length;
    size_t capacity;
} NZIP_READER;


#define NZIP_PROGRESS_WIDTH 22
#define NZIP_PROGRESS_STEPS 20U /* 5% updates: console I/O is expensive on JTMOS */

typedef struct nzip_progress_state {
    FILE *input;
    unsigned long total;
    unsigned long done;
    unsigned long step_bytes;
    unsigned long next_report;
    unsigned long start_ms;
    unsigned long last_ms;
    unsigned last_percent;
    int active;
    char label[19];
} NZIP_PROGRESS;

static NZIP_PROGRESS nzip_progress_state;

static unsigned long nzip_progress_now(void)
{
#if defined(JTMOSKERNEL) || defined(JTMOS_APPLICATION)
    return (unsigned long)GetTickCount();
#else
    return 0UL;
#endif
}

static unsigned nzip_progress_percent(unsigned long done,unsigned long total)
{
    if(total==0UL || done>=total) return 100U;
    while(total>0x02000000UL) { total>>=1; done>>=1; }
    return (unsigned)((done*100UL)/total);
}

static void nzip_progress_label(char out[19],const char *name)
{
    unsigned i;
    for(i=0U;i<18U;i++) out[i]=' ';
    out[18]='\0';
    if(name==NULL) return;
    for(i=0U;i<18U && name[i];i++) out[i]=name[i];
}

static void nzip_progress_render(NZIP_PROGRESS *p,int final)
{
    char bar[NZIP_PROGRESS_WIDTH+1];
    unsigned percent,filled,i,eta_s=0U,eta_m=0U,eta_ss=0U;
    unsigned long now,elapsed,remaining,rate,elapsed_s,eta_ms;
    int eta_known=0;
    if(p==NULL || !p->active) return;
    percent=nzip_progress_percent(p->done,p->total);
    now=nzip_progress_now();
    if(!final && percent==p->last_percent) return;
    if(!final && p->last_percent<=100U && now!=0UL && (unsigned long)(now-p->last_ms)<100UL) return;

    filled=(percent*NZIP_PROGRESS_WIDTH)/100U;
    for(i=0U;i<NZIP_PROGRESS_WIDTH;i++) bar[i]=(i<filled)?'#':'-';
    bar[NZIP_PROGRESS_WIDTH]='\0';

    elapsed=(unsigned long)(now-p->start_ms);
    remaining=p->total-p->done;
    if(p->done>0UL && elapsed>=250UL && remaining>0UL) {
        if(p->done>=elapsed) {
            rate=p->done/elapsed;
            if(rate>0UL) {
                eta_ms=(remaining+rate-1UL)/rate;
                eta_s=(unsigned)((eta_ms+999UL)/1000UL);
                eta_known=1;
            }
        } else {
            elapsed_s=(elapsed+999UL)/1000UL;
            rate=elapsed_s ? p->done/elapsed_s : 0UL;
            if(rate>0UL) {
                eta_s=(unsigned)((remaining+rate-1UL)/rate);
                eta_known=1;
            }
        }
    }
    if(final && p->done>=p->total) { eta_s=0U; eta_known=1; }
    eta_m=eta_s/60U;
    eta_ss=eta_s%60U;

    if(final) {
        unsigned elapsed_total_s=(unsigned)((elapsed+999UL)/1000UL);
        printf("\r%s [%s] %3u%% time %02u:%02u",p->label,bar,percent,
               elapsed_total_s/60U,elapsed_total_s%60U);
    } else if(eta_known)
        printf("\r%s [%s] %3u%% ETA %02u:%02u",p->label,bar,percent,eta_m,eta_ss);
    else
        printf("\r%s [%s] %3u%% ETA --:--",p->label,bar,percent);
    if(final) printf("\n");
#if !defined(JTMOSKERNEL)
    fflush(stdout);
#endif
    p->last_percent=percent;
    p->last_ms=now;
}

static void nzip_progress_begin(FILE *input,const char *name,unsigned long total)
{
    NZIP_PROGRESS *p=&nzip_progress_state;
    memset(p,0,sizeof(*p));
    p->input=input;
    p->total=total;
    p->step_bytes=total/(unsigned long)NZIP_PROGRESS_STEPS;
    if(p->step_bytes==0UL) p->step_bytes=1UL;
    p->next_report=p->step_bytes;
    p->start_ms=nzip_progress_now();
    p->last_ms=p->start_ms;
    p->last_percent=101U;
    p->active=1;
    nzip_progress_label(p->label,name);
    nzip_progress_render(p,0);
}

static void nzip_progress_note(FILE *input,unsigned long count)
{
    NZIP_PROGRESS *p=&nzip_progress_state;
    if(!p->active || p->input!=input || count==0UL) return;
    if(count>p->total-p->done) p->done=p->total;
    else p->done+=count;
    if(p->done<p->next_report && p->done<p->total) return;
    while(p->next_report<=p->done && p->next_report<p->total) {
        if(p->next_report>p->total-p->step_bytes) { p->next_report=p->total; break; }
        p->next_report+=p->step_bytes;
    }
    nzip_progress_render(p,0);
}

static void nzip_progress_end(int success)
{
    NZIP_PROGRESS *p=&nzip_progress_state;
    if(!p->active) return;
    if(success) p->done=p->total;
    nzip_progress_render(p,1);
    p->active=0;
    p->input=NULL;
}

static unsigned long nzip_stream_size(FILE *f)
{
    long cur,end;
    if(f==NULL) return 0UL;
    cur=ftell(f);
    if(cur<0L) return 0UL;
    if(fseek(f,0L,SEEK_END)!=0) return 0UL;
    end=ftell(f);
    if(fseek(f,cur,SEEK_SET)!=0) return 0UL;
    return end>0L ? (unsigned long)end : 0UL;
}

static unsigned nzip_hash3(const BYTE *p)
{
    unsigned v;
    v = (unsigned)p[0] * 251U;
    v ^= (unsigned)p[1] * 31U;
    v ^= (unsigned)p[2] * 257U;
    return v & (NZIP_HASH_SIZE - 1U);
}

static NZIP_UINT32 nzip_crc32(const BYTE *data, size_t length)
{
    NZIP_UINT32 crc;
    size_t i;
    unsigned bit;
    crc = (NZIP_UINT32)0xffffffffUL;
    for(i=0U;i<length;++i) {
        crc ^= (NZIP_UINT32)data[i];
        for(bit=0U;bit<8U;++bit) {
            NZIP_UINT32 mask = (NZIP_UINT32)(0UL - (crc & 1UL));
            crc = (crc >> 1U) ^ ((NZIP_UINT32)0xedb88320UL & mask);
        }
    }
    return crc ^ (NZIP_UINT32)0xffffffffUL;
}

static int put_le16(FILE *f, unsigned value)
{
    BYTE b[2];
    b[0]=(BYTE)(value & 0xffU);
    b[1]=(BYTE)((value >> 8U) & 0xffU);
    return fwrite(b,1U,sizeof(b),f)==sizeof(b) ? 0 : -1;
}

static int put_le32(FILE *f, NZIP_UINT32 value)
{
    BYTE b[4];
    b[0]=(BYTE)(value & 0xffU);
    b[1]=(BYTE)((value >> 8U) & 0xffU);
    b[2]=(BYTE)((value >> 16U) & 0xffU);
    b[3]=(BYTE)((value >> 24U) & 0xffU);
    return fwrite(b,1U,sizeof(b),f)==sizeof(b) ? 0 : -1;
}

static int nzip_reader_init(NZIP_READER *r, FILE *f)
{
    if(r==NULL || f==NULL) return -1;
    memset(r,0,sizeof(*r));
    r->buffer=(BYTE *)malloc((size_t)NZIP_IO_CHUNK);
    if(r->buffer==NULL) return -1;
    r->file=f;
    r->capacity=(size_t)NZIP_IO_CHUNK;
    return 0;
}

static void nzip_reader_destroy(NZIP_READER *r)
{
    if(r==NULL) return;
    if(r->buffer) free(r->buffer);
    memset(r,0,sizeof(*r));
}

static int nzip_reader_fill(NZIP_READER *r)
{
    size_t got;
    if(r==NULL || r->file==NULL || r->buffer==NULL) return -1;
    got=fread(r->buffer,1U,r->capacity,r->file);
    r->pos=0U;
    r->length=got;
    if(got!=0U) nzip_progress_note(r->file,(unsigned long)got);
    return got!=0U ? 1 : 0;
}

static int read_byte(NZIP_READER *r, unsigned *value)
{
    int fr;
    if(r==NULL || value==NULL) return -1;
    if(r->pos>=r->length) {
        fr=nzip_reader_fill(r);
        if(fr<=0) return fr;
    }
    *value=(unsigned)r->buffer[r->pos++];
    return 1;
}

static int read_exact(NZIP_READER *r, BYTE *dst, size_t count)
{
    size_t avail,n;
    int fr;
    while(count>0U) {
        if(r->pos>=r->length) {
            fr=nzip_reader_fill(r);
            if(fr<=0) return -1;
        }
        avail=r->length-r->pos;
        n=count<avail ? count : avail;
        memcpy(dst,r->buffer+r->pos,n);
        r->pos+=n;
        dst+=n;
        count-=n;
    }
    return 0;
}

static int read_le16(NZIP_READER *r, unsigned *value)
{
    BYTE b[2];
    if(read_exact(r,b,sizeof(b))!=0) return -1;
    *value=(unsigned)b[0] | ((unsigned)b[1] << 8U);
    return 0;
}

static int read_le32(NZIP_READER *r, NZIP_UINT32 *value)
{
    BYTE b[4];
    if(read_exact(r,b,sizeof(b))!=0) return -1;
    *value=(NZIP_UINT32)b[0] | ((NZIP_UINT32)b[1] << 8U)
           | ((NZIP_UINT32)b[2] << 16U) | ((NZIP_UINT32)b[3] << 24U);
    return 0;
}

static int buffer_reserve_limit(NZIP_BUFFER *b, size_t extra, size_t limit)
{
    size_t need,capacity,next;
    BYTE *grown;
    if(extra > (size_t)-1 - b->size) return -1;
    need = b->size + extra;
    if(need > limit) return -1;
    if(need <= b->capacity) return 0;
    capacity = b->capacity ? b->capacity : 4096U;
    while(capacity < need) {
        next = capacity * 2U;
        if(next < capacity || next > limit) next = limit;
        capacity = next;
        if(capacity < need && capacity == limit) return -1;
    }
    grown = (BYTE *)realloc(b->data,capacity);
    if(grown == NULL) return -1;
    b->data = grown;
    b->capacity = capacity;
    return 0;
}

static int enc_reserve(NZIP_BUFFER *b, size_t extra)
{
    return buffer_reserve_limit(b,extra,(size_t)NZIP_MAX_OUTPUT);
}

static void enc_reset(NZIP_BUFFER *b)
{
    b->size = 0U;
}

static int enc_byte(NZIP_BUFFER *b, unsigned value)
{
    if(enc_reserve(b,1U) != 0) return -1;
    b->data[b->size++] = (BYTE)(value & 0xffU);
    return 0;
}

static int enc_le16(NZIP_BUFFER *b, unsigned value)
{
    if(enc_byte(b,value) != 0 || enc_byte(b,value >> 8U) != 0) return -1;
    return 0;
}

static int buffer_byte(NZIP_BUFFER *b, BYTE value)
{
    if(buffer_reserve_limit(b,1U,(size_t)NZIP_MAX_OUTPUT) != 0) return -1;
    b->data[b->size++] = value;
    return 0;
}

static int buffer_append(NZIP_BUFFER *b, const BYTE *data, size_t count)
{
    if(count == 0U) return 0;
    if(data == NULL || buffer_reserve_limit(b,count,(size_t)NZIP_MAX_OUTPUT) != 0) return -1;
    memcpy(b->data+b->size,data,count);
    b->size += count;
    return 0;
}

static int buffer_repeat(NZIP_BUFFER *b, BYTE value, size_t count)
{
    if(buffer_reserve_limit(b,count,(size_t)NZIP_MAX_OUTPUT) != 0) return -1;
    memset(b->data+b->size,value,count);
    b->size += count;
    return 0;
}

static int buffer_backref(NZIP_BUFFER *b, size_t offset, size_t count)
{
    size_t i,known;
    known = b->size;
    /* Historical nzip deliberately forbids overlapping copies. */
    if(offset >= known || count > known-offset) return -1;
    if(buffer_reserve_limit(b,count,(size_t)NZIP_MAX_OUTPUT) != 0) return -1;
    for(i=0U;i<count;++i) {
        NZIP_COOPERATE_EVERY(i);
        b->data[b->size++] = b->data[offset+i];
    }
    return 0;
}

static int write_buffer(FILE *f, const BYTE *data, size_t length)
{
    size_t done,chunk;
    done = 0U;
    while(done < length) {
        chunk = length-done;
        if(chunk > NZIP_IO_CHUNK) chunk = NZIP_IO_CHUNK;
        if(fwrite(data+done,1U,chunk,f) != chunk) return -1;
        done += chunk;
        NZIP_COOPERATE();
    }
    return 0;
}

static int write_buffer_file(const char *name, const BYTE *data, size_t length)
{
    FILE *f;
    int rc;
    f = fopen(name,"wb");
    if(f == NULL) return -1;
    rc = write_buffer(f,data,length);
    if(fclose(f) != 0) rc = -1;
    return rc;
}


#define NZIP_STREAM_IO_ERROR    (-1)
#define NZIP_STREAM_SIZE_ERROR  (-2)

static int stream_room(unsigned long position, size_t count)
{
    if(position > (unsigned long)NZIP_MAX_DECODE_OUTPUT) return NZIP_STREAM_SIZE_ERROR;
    if(count > (size_t)((unsigned long)NZIP_MAX_DECODE_OUTPUT-position))
        return NZIP_STREAM_SIZE_ERROR;
    return 0;
}

typedef struct nzip_legacy_history {
    BYTE *data;
    size_t pos;
    size_t valid;
} NZIP_LEGACY_HISTORY;

static void legacy_history_append(NZIP_LEGACY_HISTORY *h, const BYTE *data, size_t count)
{
    size_t n;
    if(h==NULL || h->data==NULL || data==NULL) return;
    if(count>NZIP_MAX_LOOKBACK) {
        data+=count-NZIP_MAX_LOOKBACK;
        count=NZIP_MAX_LOOKBACK;
        h->pos=0U;
        h->valid=0U;
    }
    while(count!=0U) {
        n=NZIP_MAX_LOOKBACK-h->pos;
        if(n>count) n=count;
        memcpy(h->data+h->pos,data,n);
        h->pos=(h->pos+n)%NZIP_MAX_LOOKBACK;
        data+=n;
        count-=n;
        h->valid+=n;
        if(h->valid>NZIP_MAX_LOOKBACK) h->valid=NZIP_MAX_LOOKBACK;
    }
}

static int stream_write(FILE *f, unsigned long *position, const BYTE *data, size_t count,
                        NZIP_LEGACY_HISTORY *history)
{
    int rc;
    if(f == NULL || position == NULL || (count != 0U && data == NULL))
        return NZIP_STREAM_IO_ERROR;
    rc=stream_room(*position,count);
    if(rc != 0) return rc;
    if(count != 0U && write_buffer(f,data,count) != 0) return NZIP_STREAM_IO_ERROR;
    legacy_history_append(history,data,count);
    *position += (unsigned long)count;
    return 0;
}

static int stream_byte(FILE *f, unsigned long *position, BYTE value,
                       NZIP_LEGACY_HISTORY *history)
{
    return stream_write(f,position,&value,1U,history);
}

static int stream_repeat(FILE *f, unsigned long *position, BYTE value, size_t count,
                         NZIP_LEGACY_HISTORY *history)
{
    BYTE block[256];
    size_t n;
    int rc;
    memset(block,value,sizeof(block));
    while(count != 0U) {
        n=count;
        if(n > sizeof(block)) n=sizeof(block);
        rc=stream_write(f,position,block,n,history);
        if(rc != 0) return rc;
        count-=n;
    }
    return 0;
}

/* V16.71 compatibility acceleration: normal V1 encoders never look back more
 * than 128 KiB.  Serve those absolute ADVPAK references from a RAM history
 * ring.  Only unusual older streams with a farther absolute offset fall back
 * to seek/read of the destination file. */
static int stream_backref(FILE *f, unsigned long *position, NZIP_UINT32 offset, size_t count,
                          NZIP_LEGACY_HISTORY *history)
{
    BYTE block[4096];
    unsigned long src,dst,oldest_abs,relative;
    size_t n,oldest_idx,index,first;
    int rc;
    if(f == NULL || position == NULL) return NZIP_STREAM_IO_ERROR;
    src=(unsigned long)offset;
    dst=*position;
    if(src >= dst || count > (size_t)(dst-src)) return NZIP_STREAM_IO_ERROR;
    rc=stream_room(dst,count);
    if(rc != 0) return rc;

    if(history!=NULL && history->data!=NULL && history->valid!=0U) {
        oldest_abs=dst-(unsigned long)history->valid;
        if(src>=oldest_abs && src+(unsigned long)count<=dst) {
            oldest_idx=(history->pos+NZIP_MAX_LOOKBACK-history->valid)%NZIP_MAX_LOOKBACK;
            relative=src-oldest_abs;
            index=(oldest_idx+(size_t)relative)%NZIP_MAX_LOOKBACK;
            while(count!=0U) {
                n=count;
                if(n>sizeof(block)) n=sizeof(block);
                first=NZIP_MAX_LOOKBACK-index;
                if(first>n) first=n;
                memcpy(block,history->data+index,first);
                if(first<n) memcpy(block+first,history->data,n-first);
                rc=stream_write(f,position,block,n,history);
                if(rc!=0) return rc;
                count-=n;
                index=(index+n)%NZIP_MAX_LOOKBACK;
            }
            return 0;
        }
    }

    if(fflush(f) != 0) return NZIP_STREAM_IO_ERROR;
    while(count != 0U) {
        n=count;
        if(n > sizeof(block)) n=sizeof(block);
        if(fseek(f,(long)src,SEEK_SET) != 0) return NZIP_STREAM_IO_ERROR;
        if(fread(block,1U,n,f) != n) return NZIP_STREAM_IO_ERROR;
        if(fseek(f,(long)dst,SEEK_SET) != 0) return NZIP_STREAM_IO_ERROR;
        if(fwrite(block,1U,n,f) != n) return NZIP_STREAM_IO_ERROR;
        legacy_history_append(history,block,n);
        src += (unsigned long)n;
        dst += (unsigned long)n;
        count -= n;
    }
    *position=dst;
    return 0;
}

static size_t find_run(const BYTE *data, size_t end, size_t pos)
{
    size_t n;
    n = 1U;
    while(pos+n < end && data[pos+n] == data[pos] && n < NZIP_MAX_MATCH) ++n;
    return n;
}

static size_t find_backref(const BYTE *data, size_t end, size_t pos,
                           NZIP_INT32 *last, size_t *source)
{
    unsigned h;
    NZIP_INT32 candidate;
    size_t limit,n;
    if(pos+2U >= end) return 0U;
    h = nzip_hash3(data+pos);
    candidate = last[h];
    last[h] = (NZIP_INT32)pos;
    if(candidate < 0 || (size_t)candidate >= pos) return 0U;
    if(pos-(size_t)candidate > NZIP_MAX_LOOKBACK) return 0U;
    limit = end-pos;
    if(limit > NZIP_MAX_MATCH) limit = NZIP_MAX_MATCH;
    /* Legacy decoder forbids overlap, so cap to already-known source bytes. */
    if(limit > pos-(size_t)candidate) limit = pos-(size_t)candidate;
    n = 0U;
    while(n < limit && data[(size_t)candidate+n] == data[pos+n]) ++n;
    if(n < NZIP_MIN_BACKREF) return 0U;
    *source = (size_t)candidate;
    return n;
}

static void update_hashes(const BYTE *data, size_t length, size_t start, size_t count,
                          NZIP_INT32 *last)
{
    size_t i,end;
    end = start+count;
    if(end > length) end = length;
    for(i=start;i<end;++i) {
        NZIP_COOPERATE_EVERY(i-start);
        if(i+2U < length) last[nzip_hash3(data+i)] = (NZIP_INT32)i;
    }
}

static int legacy_encode_block(const BYTE *data, size_t length, size_t start,
                               size_t count, unsigned long base_offset,
                               const NZIP_INT32 *history, NZIP_INT32 *work,
                               NZIP_BUFFER *encoded)
{
    size_t pos,end,run,match,from;
    memcpy(work,history,NZIP_HASH_SIZE*sizeof(*work));
    enc_reset(encoded);
    pos = start;
    end = start+count;
    while(pos < end) {
        NZIP_COOPERATE_EVERY(pos-start);
        run = find_run(data,end,pos);
        if(run >= NZIP_MIN_RLE) {
            if(enc_le16(encoded,CODE_CHARPACK) != 0 || enc_le16(encoded,(unsigned)run) != 0
               || enc_byte(encoded,data[pos]) != 0) return -1;
            update_hashes(data,length,pos,run,work);
            pos += run;
            continue;
        }
        match = find_backref(data,end,pos,work,&from);
        if(match >= NZIP_MIN_BACKREF) {
            unsigned long absolute_from=base_offset+(unsigned long)from;
            if(absolute_from > 0x7fffffffUL) return -1;
            if(enc_le16(encoded,CODE_ADVPAK) != 0 || enc_le16(encoded,(unsigned)match) != 0
               || enc_byte(encoded,(unsigned)absolute_from) != 0
               || enc_byte(encoded,(unsigned)(absolute_from >> 8U)) != 0
               || enc_byte(encoded,(unsigned)(absolute_from >> 16U)) != 0
               || enc_byte(encoded,(unsigned)(absolute_from >> 24U)) != 0) return -1;
            if(match > 1U) update_hashes(data,length,pos+1U,match-1U,work);
            pos += match;
            continue;
        }
        /* All 0xFCxx control words are escaped when their little-endian byte
         * pair occurs literally.  This includes the new E5/FC BWT marker. */
        if(pos+1U < end && data[pos] >= 0xE3U && data[pos] <= 0xFEU
           && data[pos+1U] == 0xFCU) {
            if(enc_le16(encoded,CODE_FIX) != 0 || enc_byte(encoded,data[pos]) != 0
               || enc_byte(encoded,data[pos+1U]) != 0) return -1;
            update_hashes(data,length,pos,2U,work);
            pos += 2U;
        } else {
            if(enc_byte(encoded,data[pos]) != 0) return -1;
            update_hashes(data,length,pos,1U,work);
            ++pos;
        }
    }
    return 0;
}

/* Sort cyclic rotations using the O(n log n) prefix-doubling algorithm. */
static int bwt_transform(const BYTE *src, size_t n, BYTE *mtf, unsigned *primary)
{
    int *p,*c,*pn,*cn,*cnt,*swap;
    size_t i;
    unsigned classes,shift,b,idx;
    BYTE symbols[256];
    size_t count_cap;
    int rc;

    if(src == NULL || mtf == NULL || primary == NULL || n == 0U || n > NZIP_BWT_BLOCK) return -1;
    p = (int *)malloc(n*sizeof(int));
    c = (int *)malloc(n*sizeof(int));
    pn = (int *)malloc(n*sizeof(int));
    cn = (int *)malloc(n*sizeof(int));
    count_cap = n > 256U ? n : 256U;
    cnt = (int *)malloc(count_cap*sizeof(int));
    if(p == NULL || c == NULL || pn == NULL || cn == NULL || cnt == NULL) {
        free(p); free(c); free(pn); free(cn); free(cnt);
        return -1;
    }

    memset(cnt,0,256U*sizeof(int));
    for(i=0U;i<n;++i) { NZIP_COOPERATE_EVERY(i); ++cnt[src[i]]; }
    for(i=1U;i<256U;++i) cnt[i] += cnt[i-1U];
    i = n;
    while(i != 0U) {
        --i;
        p[--cnt[src[i]]] = (int)i;
    }
    classes = 1U;
    c[p[0]] = 0;
    for(i=1U;i<n;++i) {
        if(src[p[i]] != src[p[i-1U]]) ++classes;
        c[p[i]] = (int)(classes-1U);
    }

    shift = 1U;
    while((size_t)shift < n) {
        NZIP_COOPERATE();
        for(i=0U;i<n;++i) {
            int q = p[i]-(int)shift;
            NZIP_COOPERATE_EVERY(i);
            if(q < 0) q += (int)n;
            pn[i] = q;
        }
        memset(cnt,0,(size_t)classes*sizeof(int));
        for(i=0U;i<n;++i) ++cnt[c[pn[i]]];
        for(i=1U;i<(size_t)classes;++i) cnt[i] += cnt[i-1U];
        i = n;
        while(i != 0U) {
            int q;
            --i;
            q = pn[i];
            p[--cnt[c[q]]] = q;
        }
        classes = 1U;
        cn[p[0]] = 0;
        for(i=1U;i<n;++i) {
            int cur1,cur2,prev1,prev2;
            cur1 = c[p[i]];
            cur2 = c[(p[i]+(int)shift)%(int)n];
            prev1 = c[p[i-1U]];
            prev2 = c[(p[i-1U]+(int)shift)%(int)n];
            if(cur1 != prev1 || cur2 != prev2) ++classes;
            cn[p[i]] = (int)(classes-1U);
        }
        swap = c; c = cn; cn = swap;
        if(shift > 0x3fffU) break;
        shift <<= 1U;
    }

    for(i=0U;i<256U;++i) symbols[i] = (BYTE)i;
    *primary = 0U;
    for(i=0U;i<n;++i) {
        BYTE value;
        if(p[i] == 0) *primary = (unsigned)i;
        value = src[(p[i]+(int)n-1)%(int)n];
        idx = 0U;
        while(idx < 256U && symbols[idx] != value) ++idx;
        if(idx >= 256U) { rc = -1; goto done; }
        mtf[i] = (BYTE)idx;
        b = idx;
        while(b > 0U) { symbols[b] = symbols[b-1U]; --b; }
        symbols[0] = value;
    }
    rc = 0;
done:
    free(p); free(c); free(pn); free(cn); free(cnt);
    return rc;
}

static int bwt_pack(const BYTE *src, size_t n, NZIP_BUFFER *payload, unsigned *primary)
{
    BYTE *mtf;
    size_t i,run;
    int rc;
    enc_reset(payload);
    mtf = (BYTE *)malloc(n ? n : 1U);
    if(mtf == NULL) return -1;
    if(bwt_transform(src,n,mtf,primary) != 0) { free(mtf); return -1; }
    i = 0U;
    rc = 0;
    while(i < n) {
        if(mtf[i] == 0U) {
            run = 1U;
            while(i+run < n && mtf[i+run] == 0U && run < 65535U) ++run;
            if(enc_byte(payload,0U) != 0 || enc_le16(payload,(unsigned)run) != 0) { rc=-1; break; }
            i += run;
        } else {
            if(enc_byte(payload,mtf[i]) != 0) { rc=-1; break; }
            ++i;
        }
    }
    free(mtf);
    if(payload->size > 65535U) return -1;
    return rc;
}

static int bwt_unpack(const BYTE *packed, size_t packed_len, size_t raw_len,
                      unsigned primary, BYTE *raw)
{
    BYTE *mtf,*lastcol;
    int *next;
    size_t inpos,outpos,i,run;
    unsigned value,j;
    unsigned counts[256],cursor[256],sum;
    int rc;

    if(raw == NULL || packed == NULL || raw_len == 0U || raw_len > NZIP_BWT_BLOCK
       || primary >= raw_len) return -1;
    mtf = (BYTE *)malloc(raw_len);
    lastcol = (BYTE *)malloc(raw_len);
    next = (int *)malloc(raw_len*sizeof(int));
    if(mtf == NULL || lastcol == NULL || next == NULL) {
        free(mtf); free(lastcol); free(next); return -1;
    }

    inpos = 0U;
    outpos = 0U;
    while(inpos < packed_len && outpos < raw_len) {
        value = packed[inpos++];
        if(value == 0U) {
            if(inpos+2U > packed_len) { rc=-1; goto done; }
            run = (size_t)packed[inpos] | ((size_t)packed[inpos+1U] << 8U);
            inpos += 2U;
            if(run == 0U || run > raw_len-outpos) { rc=-1; goto done; }
            memset(mtf+outpos,0,run);
            outpos += run;
        } else {
            mtf[outpos++] = (BYTE)value;
        }
    }
    if(outpos != raw_len || inpos != packed_len) { rc=-1; goto done; }

    {
        BYTE list[256];
        for(i=0U;i<256U;++i) list[i] = (BYTE)i;
        for(i=0U;i<raw_len;++i) {
            BYTE byte;
            NZIP_COOPERATE_EVERY(i);
            value = (unsigned)mtf[i];
            if(value >= 256U) { rc=-1; goto done; }
            byte = list[value];
            lastcol[i] = byte;
            j = value;
            while(j > 0U) { list[j] = list[j-1U]; --j; }
            list[0] = byte;
        }
    }

    memset(counts,0,sizeof(counts));
    for(i=0U;i<raw_len;++i) { NZIP_COOPERATE_EVERY(i); ++counts[lastcol[i]]; }
    sum = 0U;
    for(i=0U;i<256U;++i) {
        cursor[i] = sum;
        sum += counts[i];
    }
    for(i=0U;i<raw_len;++i) {
        NZIP_COOPERATE_EVERY(i);
        value = lastcol[i];
        next[cursor[value]++] = (int)i;
    }
    j = primary;
    for(i=0U;i<raw_len;++i) {
        NZIP_COOPERATE_EVERY(i);
        j = (unsigned)next[j];
        if(j >= raw_len) { rc=-1; goto done; }
        raw[i] = lastcol[j];
    }
    rc = 0;
done:
    free(mtf); free(lastcol); free(next);
    return rc;
}


typedef struct nzip2_writer {
    FILE *file;
    BYTE group[1U + 8U*3U];
    unsigned flags;
    unsigned count;
    size_t payload;
    unsigned long bytes;
} NZIP2_WRITER;

typedef struct nzip2_output {
    FILE *file;
    BYTE *ring;
    BYTE *buffer;
    size_t ring_pos;
    size_t used;
    unsigned long produced;
} NZIP2_OUTPUT;

static int nzip2_magic(const BYTE *p)
{
    return p != NULL && p[0] == (BYTE)NZIP2_MAGIC0 && p[1] == (BYTE)NZIP2_MAGIC1
           && p[2] == (BYTE)NZIP2_MAGIC2 && p[3] == (BYTE)NZIP2_MAGIC3;
}

static int nzip2_flush_group(NZIP2_WRITER *w)
{
    size_t n;
    if(w == NULL || w->file == NULL) return -1;
    if(w->count == 0U) return 0;
    w->group[0] = (BYTE)w->flags;
    n = 1U+w->payload;
    if(write_buffer(w->file,w->group,n) != 0) return -1;
    w->bytes += (unsigned long)n;
    w->flags = 0U;
    w->count = 0U;
    w->payload = 0U;
    return 0;
}

static int nzip2_literal(NZIP2_WRITER *w, BYTE value)
{
    if(w == NULL) return -1;
    w->group[1U+w->payload++] = value;
    ++w->count;
    if(w->count == 8U) return nzip2_flush_group(w);
    return 0;
}

static int nzip2_match(NZIP2_WRITER *w, unsigned distance, unsigned length)
{
    unsigned d;
    if(w == NULL || distance == 0U || distance > NZIP2_WINDOW
       || length < NZIP2_MIN_MATCH || length > NZIP2_MAX_MATCH) return -1;
    d=distance-1U;
    w->flags |= 1U << w->count;
    w->group[1U+w->payload++] = (BYTE)d;
    w->group[1U+w->payload++] = (BYTE)(d >> 8U);
    w->group[1U+w->payload++] = (BYTE)(length-NZIP2_MIN_MATCH);
    ++w->count;
    if(w->count == 8U) return nzip2_flush_group(w);
    return 0;
}

static void nzip2_insert(const BYTE *data, size_t end, size_t pos,
                         NZIP_INT32 *head, NZIP_INT32 *prev)
{
    unsigned h;
    if(pos+2U >= end) { prev[pos]=(NZIP_INT32)-1; return; }
    h=nzip_hash3(data+pos);
    prev[pos]=head[h];
    head[h]=(NZIP_INT32)pos;
}

/* Hash-chain matcher: bounded candidate count is the radical speedup over the
 * old per-block candidate codec.  Overlapping LZ77 matches are intentional and
 * match DEFLATE semantics, e.g. distance=1 encodes arbitrarily long runs. */
static size_t nzip2_find_match(const BYTE *data, size_t end, size_t pos,
                               NZIP_INT32 *head, NZIP_INT32 *prev,
                               unsigned *distance)
{
    unsigned h,chain;
    NZIP_INT32 candidate;
    size_t best,limit,n,dist;
    if(distance == NULL || pos+2U >= end) return 0U;
    h=nzip_hash3(data+pos);
    candidate=head[h];
    prev[pos]=candidate;
    head[h]=(NZIP_INT32)pos;
    best=0U;
    chain=0U;
    limit=end-pos;
    if(limit>NZIP2_MAX_MATCH) limit=NZIP2_MAX_MATCH;
    while(candidate>=0 && chain<NZIP2_CHAIN_LIMIT) {
        if((size_t)candidate>=pos) break;
        dist=pos-(size_t)candidate;
        if(dist>NZIP2_WINDOW) break;
        /* Cheap tail check rejects most hash collisions before byte scanning. */
        if(best<limit && data[(size_t)candidate+best]==data[pos+best]) {
            n=0U;
            while(n<limit && data[(size_t)candidate+n]==data[pos+n]) ++n;
            if(n>best) {
                best=n;
                *distance=(unsigned)dist;
                if(best>=NZIP2_NICE_MATCH || best==limit) break;
            }
        }
        candidate=prev[(size_t)candidate];
        ++chain;
    }
    return best;
}

static int nzip2_compress_file(const char *source, const char *destination)
{
    FILE *in,*out;
    BYTE *window;
    NZIP_INT32 *head,*prev;
    NZIP2_WRITER writer;
    size_t history_len,new_len,window_len,pos,retain_len,i,match;
    unsigned h,distance;
    unsigned long total_size,consumed,literals,matches,matched_bytes;
    int rc;

    in=NULL; out=NULL; window=NULL; head=NULL; prev=NULL;
    memset(&writer,0,sizeof(writer));
    rc=1; consumed=0UL; literals=0UL; matches=0UL; matched_bytes=0UL;
    if(source==NULL || destination==NULL || strcmp(source,destination)==0) return 1;
    in=fopen(source,"rb");
    if(in==NULL) { fprintf(stderr,"nzip: unable to read %s\n",source); goto done; }
    total_size=nzip_stream_size(in);
    if(total_size>(unsigned long)NZIP_MAX_DECODE_OUTPUT) {
        fprintf(stderr,"nzip: source exceeds 32-bit NZIP2 size limit\n"); goto done;
    }
    if(fseek(in,0L,SEEK_SET)!=0) goto done;
    out=fopen(destination,"wb");
    if(out==NULL) { fprintf(stderr,"nzip: unable to create %s\n",destination); goto done; }
    if(fputc(NZIP2_MAGIC0,out)==EOF || fputc(NZIP2_MAGIC1,out)==EOF
       || fputc(NZIP2_MAGIC2,out)==EOF || fputc(NZIP2_MAGIC3,out)==EOF
       || put_le32(out,(NZIP_UINT32)total_size)!=0) goto done;

    window=(BYTE *)malloc((size_t)NZIP2_WINDOW+(size_t)NZIP_COMPRESS_READAHEAD);
    head=(NZIP_INT32 *)malloc(NZIP2_HASH_SIZE*sizeof(*head));
    prev=(NZIP_INT32 *)malloc(((size_t)NZIP2_WINDOW+(size_t)NZIP_COMPRESS_READAHEAD)*sizeof(*prev));
    if(window==NULL || head==NULL || prev==NULL) {
        fprintf(stderr,"nzip: out of working memory\n"); goto done;
    }
    writer.file=out;
    writer.bytes=NZIP2_HEADER_SIZE;
    history_len=0U;

    for(;;) {
        NZIP_COOPERATE();
        new_len=fread(window+history_len,1U,(size_t)NZIP_COMPRESS_READAHEAD,in);
        if(new_len==0U) {
            if(ferror(in)) { fprintf(stderr,"nzip: read error on %s\n",source); goto done; }
            break;
        }
        window_len=history_len+new_len;
        for(h=0U;h<NZIP2_HASH_SIZE;++h) head[h]=(NZIP_INT32)-1;
        for(i=0U;i<history_len;++i) nzip2_insert(window,window_len,i,head,prev);

        pos=history_len;
        while(pos<window_len) {
            NZIP_COOPERATE_EVERY(pos-history_len);
            distance=0U;
            match=nzip2_find_match(window,window_len,pos,head,prev,&distance);
            if(match>=NZIP2_MIN_EMIT_MATCH) {
                if(nzip2_match(&writer,distance,(unsigned)match)!=0) goto done;
                ++matches;
                matched_bytes+=(unsigned long)match;
                for(i=1U;i<match;++i) nzip2_insert(window,window_len,pos+i,head,prev);
                pos+=match;
            } else {
                if(nzip2_literal(&writer,window[pos])!=0) goto done;
                ++literals;
                ++pos;
            }
        }
        consumed+=(unsigned long)new_len;
        retain_len=window_len;
        if(retain_len>NZIP2_WINDOW) retain_len=NZIP2_WINDOW;
        if(retain_len!=0U) memmove(window,window+window_len-retain_len,retain_len);
        history_len=retain_len;
    }
    if(consumed!=total_size && total_size!=0UL) {
        fprintf(stderr,"nzip: source size changed while compressing\n"); goto done;
    }
    if(nzip2_flush_group(&writer)!=0 || fflush(out)!=0) goto done;
    rc=0;
done:
    if(in!=NULL && fclose(in)!=0) rc=1;
    if(out!=NULL && fclose(out)!=0) rc=1;
    free(window); free(head); free(prev);
    if(rc==0) {
        printf("nzip: %s -> %s complete (NZIP2 fast LZ77)\n",source,destination);
        printf("nzip: raw=%lu packed=%lu literals=%lu matches=%lu matched=%lu\n",
               total_size,writer.bytes,literals,matches,matched_bytes);
        printf("nzip: LZ77 window=32 KiB, read-ahead=256 KiB, chain<=%u\n",
               (unsigned)NZIP2_CHAIN_LIMIT);
    } else (void)remove(destination);
    return rc;
}

static int nzip2_output_flush(NZIP2_OUTPUT *o)
{
    if(o==NULL || o->file==NULL) return -1;
    if(o->used==0U) return 0;
    if(write_buffer(o->file,o->buffer,o->used)!=0) return -1;
    o->used=0U;
    return 0;
}

static int nzip2_emit(NZIP2_OUTPUT *o, BYTE value)
{
    if(o==NULL) return -1;
    o->ring[o->ring_pos]=value;
    o->ring_pos=(o->ring_pos+1U)&(NZIP2_WINDOW-1U);
    o->buffer[o->used++]=value;
    ++o->produced;
    if(o->used==NZIP_IO_CHUNK) return nzip2_output_flush(o);
    return 0;
}

static int nzip2_decode_stream(NZIP_READER *r, FILE *out, unsigned long raw_size,
                               unsigned long *decoded)
{
    NZIP2_OUTPUT o;
    unsigned flags,bit,b0,b1,b2,distance,length;
    unsigned long remaining;
    size_t i,src;
    int rr,rc;
    memset(&o,0,sizeof(o));
    o.file=out;
    o.ring=(BYTE *)malloc(NZIP2_WINDOW);
    o.buffer=(BYTE *)malloc(NZIP_IO_CHUNK);
    if(o.ring==NULL || o.buffer==NULL) { free(o.ring); free(o.buffer); return -2; }
    rc=-1;
    while(o.produced<raw_size) {
        NZIP_COOPERATE_EVERY(o.produced);
        rr=read_byte(r,&flags);
        if(rr!=1) goto done;
        for(bit=0U;bit<8U && o.produced<raw_size;++bit) {
            if((flags&(1U<<bit))==0U) {
                if(read_byte(r,&b0)!=1 || nzip2_emit(&o,(BYTE)b0)!=0) goto done;
            } else {
                if(read_byte(r,&b0)!=1 || read_byte(r,&b1)!=1 || read_byte(r,&b2)!=1) goto done;
                if((b1&0x80U)!=0U) goto done;
                distance=(b0|((b1&0x7fU)<<8U))+1U;
                length=b2+NZIP2_MIN_MATCH;
                remaining=raw_size-o.produced;
                if(distance==0U || distance>NZIP2_WINDOW || (unsigned long)distance>o.produced
                   || (unsigned long)length>remaining) goto done;
                for(i=0U;i<(size_t)length;++i) {
                    src=(o.ring_pos+NZIP2_WINDOW-(size_t)distance)&(NZIP2_WINDOW-1U);
                    if(nzip2_emit(&o,o.ring[src])!=0) goto done;
                }
            }
        }
    }
    if(nzip2_output_flush(&o)!=0) goto done;
    if(decoded!=NULL) *decoded=o.produced;
    rc=0;
done:
    free(o.ring); free(o.buffer);
    return rc;
}

static int nzip2_path_is_stream(const char *source)
{
    FILE *f;
    BYTE magic[4];
    size_t n;
    if(source==NULL) return 0;
    f=fopen(source,"rb");
    if(f==NULL) return 0;
    n=fread(magic,1U,sizeof(magic),f);
    (void)fclose(f);
    return n==sizeof(magic) && nzip2_magic(magic);
}

static int nzip2_uncompress_file(const char *source, const char *destination)
{
    FILE *in,*out;
    BYTE header[NZIP2_HEADER_SIZE];
    NZIP_READER reader;
    NZIP_UINT32 raw32;
    unsigned long raw_size,input_size,decoded;
    int rc,progress_started;
    in=NULL; out=NULL; memset(&reader,0,sizeof(reader));
    rc=1; progress_started=0; decoded=0UL;
    in=fopen(source,"rb");
    if(in==NULL) { fprintf(stderr,"nzip: unable to open %s\n",source); goto done; }
    if(fread(header,1U,sizeof(header),in)!=sizeof(header) || !nzip2_magic(header)) {
        fprintf(stderr,"nzip: invalid NZIP2 header\n"); goto done;
    }
    raw32=(NZIP_UINT32)header[4] | ((NZIP_UINT32)header[5]<<8U)
          | ((NZIP_UINT32)header[6]<<16U) | ((NZIP_UINT32)header[7]<<24U);
    raw_size=(unsigned long)raw32;
    if(raw_size>(unsigned long)NZIP_MAX_DECODE_OUTPUT) {
        fprintf(stderr,"nzip: NZIP2 output exceeds JTMOS file-offset limit\n"); goto done;
    }
    if(nzip_reader_init(&reader,in)!=0) { fprintf(stderr,"nzip: unable to allocate input buffer\n"); goto done; }
    out=fopen(destination,"wb");
    if(out==NULL) { fprintf(stderr,"nzip: unable to create %s\n",destination); goto done; }
    input_size=nzip_stream_size(in);
    if(input_size>0UL) { nzip_progress_begin(in,source,input_size); progress_started=1; }
    if(nzip2_decode_stream(&reader,out,raw_size,&decoded)!=0 || decoded!=raw_size) {
        fprintf(stderr,"nzip: corrupt/truncated NZIP2 LZ77 stream\n"); goto done;
    }
    if(fflush(out)!=0) goto done;
    rc=0;
done:
    if(progress_started) nzip_progress_end(rc==0);
    nzip_reader_destroy(&reader);
    if(in!=NULL) (void)fclose(in);
    if(out!=NULL && fclose(out)!=0) rc=1;
    if(rc!=0) (void)remove(destination);
    else printf("nzip: %s -> %s, %lu bytes (NZIP2 fast LZ77)\n",source,destination,decoded);
    return rc;
}

int nzip_output_name(char *output, size_t capacity, const char *source)
{
    size_t n;
    if(output == NULL || source == NULL || capacity == 0U) return -1;
    n = strlen(source);
    if(n < 3U || source[n-3U] != '.' || source[n-2U] != 'n' || source[n-1U] != 'z') return -1;
    if(n-2U > capacity) return -1;
    memcpy(output,source,n-3U);
    output[n-3U] = '\0';
    return 0;
}

void unNutFname(char *output, const char *source)
{
    size_t n;
    if(output == NULL) return;
    output[0] = '\0';
    if(source == NULL) return;
    n = strlen(source);
    if(n < 3U || source[n-3U] != '.' || source[n-2U] != 'n' || source[n-1U] != 'z') return;
    memcpy(output,source,n-3U);
    output[n-3U] = '\0';
}

int nzip_compress_mode(const char *source, const char *destination, int mode)
{
    BYTE *window;
    size_t history_len,new_len,window_len,pos,block_len,retain_len;
    unsigned long consumed,base_offset,total_size;
    NZIP_INT32 *history,*work;
    NZIP_BUFFER legacy,bwt;
    FILE *in,*out;
    int rc,use_bwt,bwt_ok;
    unsigned i,primary;
    size_t bwt_record_size;
    NZIP_STATS stats;

    window = NULL;
    history = NULL;
    work = NULL;
    in = NULL;
    out = NULL;
    memset(&legacy,0,sizeof(legacy));
    memset(&bwt,0,sizeof(bwt));
    memset(&stats,0,sizeof(stats));
    rc = 1;
    if(source == NULL || destination == NULL) return 1;
    if(mode == NZIP_MODE_AUTO || mode == NZIP_MODE_FAST)
        return nzip2_compress_file(source,destination);
    if(mode != NZIP_MODE_LEGACY && mode != NZIP_MODE_BWT) return 1;

    in=fopen(source,"rb");
    if(in == NULL) { fprintf(stderr,"nzip: unable to read %s\n",source); goto done; }
    total_size=nzip_stream_size(in);
    if(total_size > 0x7fffffffUL) {
        fprintf(stderr,"nzip: source too large for 32-bit back-reference offsets\n");
        goto done;
    }
    if(fseek(in,0L,SEEK_SET)!=0) { fprintf(stderr,"nzip: unable to seek %s\n",source); goto done; }

    /* V16.70.2: source input is bounded.  Keep only the legacy look-back tail
     * plus at most 256 KiB of new source data.  This avoids read_whole_file()
     * and lets nzip compress large inputs inside the fixed JTMOS SYSMEMREQ. */
    window=(BYTE *)malloc((size_t)NZIP_COMPRESS_HISTORY+(size_t)NZIP_COMPRESS_READAHEAD);
    history = (NZIP_INT32 *)malloc(NZIP_HASH_SIZE*sizeof(*history));
    work = (NZIP_INT32 *)malloc(NZIP_HASH_SIZE*sizeof(*work));
    if(window == NULL || history == NULL || work == NULL) {
        fprintf(stderr,"nzip: out of memory\n"); goto done;
    }
    out = fopen(destination,"wb");
    if(out == NULL) { fprintf(stderr,"nzip: unable to create %s\n",destination); goto done; }

    history_len=0U;
    consumed=0UL;
    for(;;) {
        NZIP_COOPERATE();
        new_len=fread(window+history_len,1U,(size_t)NZIP_COMPRESS_READAHEAD,in);
        if(new_len==0U) {
            if(ferror(in)) { fprintf(stderr,"nzip: read error on %s\n",source); goto done; }
            break;
        }
        if((unsigned long)new_len > 0x7fffffffUL-consumed) {
            fprintf(stderr,"nzip: source too large for 32-bit back-reference offsets\n");
            goto done;
        }
        window_len=history_len+new_len;
        base_offset=consumed-(unsigned long)history_len;

        for(i=0U;i<NZIP_HASH_SIZE;++i) history[i]=(NZIP_INT32)-1;
        if(history_len!=0U) update_hashes(window,window_len,0U,history_len,history);

        pos=history_len;
        while(pos<window_len) {
            NZIP_COOPERATE_EVERY(pos-history_len);
            block_len=window_len-pos;
            if(block_len>NZIP_BWT_BLOCK) block_len=NZIP_BWT_BLOCK;
            if(legacy_encode_block(window,window_len,pos,block_len,base_offset,
                                   history,work,&legacy)!=0) {
                fprintf(stderr,"nzip: legacy encoder ran out of memory\n"); goto done;
            }

            bwt_ok=0;
            primary=0U;
            bwt_record_size=(size_t)-1;
            if(mode!=NZIP_MODE_LEGACY && block_len>=NZIP_BWT_MIN_BLOCK) {
                if(bwt_pack(window+pos,block_len,&bwt,&primary)==0) {
                    bwt_record_size=NZIP_BWT_HEADER_SIZE+bwt.size;
                    bwt_ok=1;
                }
            }
            use_bwt=0;
            if(bwt_ok && (mode==NZIP_MODE_BWT || bwt_record_size<legacy.size)) use_bwt=1;

            if(use_bwt) {
                NZIP_UINT32 crc=nzip_crc32(window+pos,block_len);
                if(put_le16(out,CODE_BWT)!=0
                   || put_le16(out,(unsigned)block_len)!=0
                   || put_le16(out,primary)!=0
                   || put_le16(out,(unsigned)bwt.size)!=0
                   || put_le32(out,crc)!=0
                   || write_buffer(out,bwt.data,bwt.size)!=0) goto done;
                stats.bwt_bytes+=(unsigned long)bwt_record_size;
                ++stats.bwt_blocks;
            } else {
                if(write_buffer(out,legacy.data,legacy.size)!=0) goto done;
                stats.legacy_bytes+=(unsigned long)legacy.size;
                ++stats.legacy_blocks;
            }
            stats.raw_bytes+=(unsigned long)block_len;
            update_hashes(window,window_len,pos,block_len,history);
            pos+=block_len;
        }

        consumed+=(unsigned long)new_len;
        retain_len=window_len;
        if(retain_len>(size_t)NZIP_COMPRESS_HISTORY) retain_len=(size_t)NZIP_COMPRESS_HISTORY;
        if(retain_len!=0U) memmove(window,window+window_len-retain_len,retain_len);
        history_len=retain_len;
    }

    if(consumed!=total_size && total_size!=0UL) {
        fprintf(stderr,"nzip: source size changed while compressing\n"); goto done;
    }
    if(put_le16(out,CODE_END)!=0 || fflush(out)!=0) goto done;
    rc=0;

done:
    if(in!=NULL && fclose(in)!=0) rc=1;
    if(out!=NULL && fclose(out)!=0) rc=1;
    free(history); free(work); free(legacy.data); free(bwt.data); free(window);
    if(rc==0) {
        printf("nzip: %s -> %s complete\n",source,destination);
        printf("nzip: raw=%lu bytes, BWT blocks=%u (%lu bytes), legacy blocks=%u (%lu bytes)\n",
               stats.raw_bytes,stats.bwt_blocks,stats.bwt_bytes,
               stats.legacy_blocks,stats.legacy_bytes);
        printf("nzip: compression read-ahead=%u KiB, retained history<=%u KiB\n",
               (unsigned)(NZIP_COMPRESS_READAHEAD/1024U),
               (unsigned)(NZIP_COMPRESS_HISTORY/1024U));
    } else {
        (void)remove(destination);
    }
    return rc;
}

int nzip_compress(const char *source, const char *destination)
{
    return nzip_compress_mode(source,destination,NZIP_MODE_AUTO);
}

int nzip_uncompress(const char *source, const char *destination)
{
    FILE *in,*out;
    NZIP_READER reader;
    int pending,ended,rc,stream_rc;
    unsigned b0,b1,code,length,value,primary,packed_len;
    NZIP_UINT32 offset,stored_crc,actual_crc;
    unsigned long input_size,output_size;
    int progress_started;
    NZIP_LEGACY_HISTORY legacy_history;

    memset(&legacy_history,0,sizeof(legacy_history));
    in = NULL;
    out = NULL;
    memset(&reader,0,sizeof(reader));
    pending = -1;
    ended = 0;
    rc = 1;
    input_size = 0UL;
    output_size = 0UL;
    progress_started = 0;
    if(source == NULL || destination == NULL) return 1;
    if(strcmp(source,destination)==0) {
        fprintf(stderr,"nzip: source and destination must differ\n");
        return 1;
    }
    /* NZIP2 never seeks in the output.  Old V1 streams continue through the
     * compatibility decoder below, including ADVPAK/BWT recovery support. */
    if(nzip2_path_is_stream(source)) return nzip2_uncompress_file(source,destination);
    in = fopen(source,"rb");
    if(in == NULL) { fprintf(stderr,"nzip: unable to open %s\n",source); goto done; }
    if(nzip_reader_init(&reader,in)!=0) { fprintf(stderr,"nzip: unable to allocate input buffer\n"); goto done; }
    out = fopen(destination,"w+b");
    if(out == NULL) { fprintf(stderr,"nzip: unable to create %s\n",destination); goto done; }
    legacy_history.data=(BYTE *)malloc(NZIP_MAX_LOOKBACK);
    /* Allocation failure is non-fatal: compatibility decoder falls back to
     * the historical seek/read path, just more slowly. */
    input_size=nzip_stream_size(in);
    if(input_size>0UL) {
        nzip_progress_begin(in,source,input_size);
        progress_started=1;
    }

    while(!ended) {
        NZIP_COOPERATE();
        int r;
        if(pending >= 0) { b0 = (unsigned)pending; pending = -1; r = 1; }
        else r = read_byte(&reader,&b0);
        if(r == 0) { fprintf(stderr,"nzip: truncated stream (missing end marker)\n"); goto done; }

        if(b0 == 0xE3U || b0 == 0xE4U || b0 == 0xE5U
           || b0 == 0xEEU || b0 == 0xEFU) {
            if(read_byte(&reader,&b1) != 1) { fprintf(stderr,"nzip: truncated marker\n"); goto done; }
            code = b0 | (b1 << 8U);
            if(code == CODE_END) {
                ended = 1;
                break;
            }
            if(code == CODE_END_V65_BROKEN) {
                /* The accidental EE/FE marker is ambiguous with ordinary
                 * literal data. Accept it only when it is the final word. */
                if(read_byte(&reader,&value) == 0) {
                    ended = 1;
                    break;
                }
                stream_rc=stream_byte(out,&output_size,(BYTE)b0,&legacy_history);
                if(stream_rc != 0) goto stream_error;
                stream_rc=stream_byte(out,&output_size,(BYTE)b1,&legacy_history);
                if(stream_rc != 0) goto stream_error;
                pending = (int)value;
                continue;
            }
            if(code == CODE_FIX) {
                if(read_byte(&reader,&b0) != 1 || read_byte(&reader,&b1) != 1) {
                    fprintf(stderr,"nzip: invalid/truncated escaped literal\n"); goto done;
                }
                stream_rc=stream_byte(out,&output_size,(BYTE)b0,&legacy_history);
                if(stream_rc != 0) goto stream_error;
                stream_rc=stream_byte(out,&output_size,(BYTE)b1,&legacy_history);
                if(stream_rc != 0) goto stream_error;
                continue;
            }
            if(code == CODE_CHARPACK) {
                if(read_le16(&reader,&length) != 0 || read_byte(&reader,&value) != 1 || length == 0U) {
                    fprintf(stderr,"nzip: invalid/truncated char-pack record\n"); goto done;
                }
                stream_rc=stream_repeat(out,&output_size,(BYTE)value,(size_t)length,&legacy_history);
                if(stream_rc != 0) goto stream_error;
                continue;
            }
            if(code == CODE_ADVPAK) {
                if(read_le16(&reader,&length) != 0 || read_le32(&reader,&offset) != 0 || length == 0U) {
                    fprintf(stderr,"nzip: invalid/truncated back-reference\n"); goto done;
                }
                if((unsigned long)offset >= output_size
                   || (size_t)length > (size_t)(output_size-(unsigned long)offset)) {
                    fprintf(stderr,"nzip: invalid back-reference offset/length\n"); goto done;
                }
                stream_rc=stream_backref(out,&output_size,offset,(size_t)length,&legacy_history);
                if(stream_rc != 0) goto stream_error;
                continue;
            }
            if(code == CODE_BWT) {
                BYTE *packed,*raw;
                size_t got;
                if(read_le16(&reader,&length) != 0 || read_le16(&reader,&primary) != 0
                   || read_le16(&reader,&packed_len) != 0 || read_le32(&reader,&stored_crc) != 0
                   || length == 0U || length > NZIP_BWT_BLOCK || primary >= length
                   || packed_len == 0U || packed_len > (2U*NZIP_BWT_BLOCK+16U)) {
                    fprintf(stderr,"nzip: invalid/truncated BWT block header\n"); goto done;
                }
                packed = (BYTE *)malloc((size_t)packed_len);
                raw = (BYTE *)malloc((size_t)length);
                if(packed == NULL || raw == NULL) {
                    free(packed); free(raw);
                    fprintf(stderr,"nzip: out of working memory while decoding BWT block\n");
                    goto done;
                }
                got = (read_exact(&reader,packed,(size_t)packed_len)==0) ? (size_t)packed_len : 0U;
                if(got != (size_t)packed_len || bwt_unpack(packed,(size_t)packed_len,
                   (size_t)length,primary,raw) != 0) {
                    free(packed); free(raw);
                    fprintf(stderr,"nzip: corrupt BWT payload\n"); goto done;
                }
                actual_crc = nzip_crc32(raw,(size_t)length);
                if(actual_crc != stored_crc) {
                    free(packed); free(raw);
                    fprintf(stderr,"nzip: BWT CRC32 mismatch\n"); goto done;
                }
                stream_rc=stream_write(out,&output_size,raw,(size_t)length,&legacy_history);
                free(packed); free(raw);
                if(stream_rc != 0) goto stream_error;
                continue;
            }
            /* Not a recognized control code: first byte is literal and the
             * second one belongs to the following token. */
            stream_rc=stream_byte(out,&output_size,(BYTE)b0,&legacy_history);
            if(stream_rc != 0) goto stream_error;
            pending = (int)b1;
        } else {
            stream_rc=stream_byte(out,&output_size,(BYTE)b0,&legacy_history);
            if(stream_rc != 0) goto stream_error;
        }
    }

    if(!ended) goto done;
    if(fflush(out) != 0) {
        fprintf(stderr,"nzip: unable to flush %s\n",destination);
        goto done;
    }
    if(fclose(out) != 0) {
        out=NULL;
        fprintf(stderr,"nzip: unable to close %s\n",destination);
        goto done;
    }
    out=NULL;
    rc = 0;
    if(progress_started) { nzip_progress_end(1); progress_started=0; }
    printf("nzip: %s -> %s, %lu bytes\n",source,destination,output_size);
    goto done;

stream_error:
    if(stream_rc == NZIP_STREAM_SIZE_ERROR)
        fprintf(stderr,"nzip: decoded output exceeds JTMOS file-offset limit (%lu bytes max)\n",
                (unsigned long)NZIP_MAX_DECODE_OUTPUT);
    else
        fprintf(stderr,"nzip: read/write error while streaming decoded output\n");
done:
    if(progress_started) nzip_progress_end(rc==0);
    if(legacy_history.data!=NULL) free(legacy_history.data);
    nzip_reader_destroy(&reader);
    if(in != NULL) (void)fclose(in);
    if(out != NULL) (void)fclose(out);
    if(rc != 0) (void)remove(destination);
    return rc;
}

static int compress_mode_name(const char *fname, int mode)
{
    char *output;
    size_t n;
    int rc;
    if(fname == NULL) return 1;
    n = strlen(fname);
    if(n > (size_t)-1-4U) return 1;
    output = (char *)malloc(n+4U);
    if(output == NULL) return 1;
    memcpy(output,fname,n);
    memcpy(output+n,".nz",4U);
    rc = nzip_compress_mode(fname,output,mode);
    free(output);
    return rc;
}

int compress(const char *fname)
{
    return compress_mode_name(fname,NZIP_MODE_AUTO);
}

int uncompress(const char *fname)
{
    char *output;
    size_t n;
    int rc;
    if(fname == NULL) return 1;
    n = strlen(fname);
    output = (char *)malloc(n+1U);
    if(output == NULL) return 1;
    if(nzip_output_name(output,n+1U,fname) != 0) {
        fprintf(stderr,"nzip: '%s' does not end in .nz\n",fname);
        free(output);
        return 1;
    }
    rc = nzip_uncompress(fname,output);
    free(output);
    return rc;
}

/* CLI helper used by nzipMain.c. */
int nzip_compress_named_mode(const char *fname, int mode)
{
    return compress_mode_name(fname,mode);
}
