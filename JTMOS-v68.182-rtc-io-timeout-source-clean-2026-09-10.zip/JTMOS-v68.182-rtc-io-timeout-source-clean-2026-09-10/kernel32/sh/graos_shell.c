/* graos_shell.c - V67.6 native SMSH adapter for GraOS/Postman functionality.
 * Uses the existing plain-PID Central Process and msgbox implementation;
 * intentionally does not import the old SDL2 tree's legacy generation-ID msgbox code. */
#include <stdio.h>
#include <string.h>
#include "kernel32.h"
#include "centralprocess.h"
#include "threads.h"
#include "ps2mouse.h"

#define SH_NOT_HANDLED (-32767)

static int launch_background(const char *command)
{
    char exe[256]; size_t i=0; int pid;
    if(!command || !*command)return 1;
    while(command[i] && command[i]!=' ' && command[i]!='\t' && i<sizeof(exe)-1){exe[i]=command[i];i++;}
    exe[i]=0; if(!exe[0])return 1;
    pid=centralprocess_exec(exe,command,GetCurrentDNR(),GetCurrentDB(),"",GetCurrentTerminal());
    if(pid<=0){printf("launch failed: %s\n",command);return 1;}
    printf("PID %d: %s\n",pid,command);return 0;
}

static int launch_graos(void)
{
    int ter,pid,parent_terminal;

    parent_terminal=GetCurrentTerminal();

    /* The maintained START_GRAOS=0 boot path reaches GraOS through this SMSH
     * adapter, not GraOSBootStart().  Attach AUX/IRQ12 at the last safe moment:
     * root/UTILS.ISO recovery is complete, but graos.bin has not started yet. */
    if(PS2MOUSE_ENABLED)
    {
        printf("GraOS: preparing PS/2 mouse before GUI launch.\n");
        if(ps2mouse_prepare_graos())
            printf("GraOS: PS/2 mouse attach failed; GUI will continue keyboard-only.\n");
    }

    /* Never let the background SMSH and GraOS consume the same terminal FIFO.
     * Give the GUI server a private terminal and make that terminal the target
     * of physical keyboard IRQ1 input while GraOS is running. */
    ter=NewTerminal();
    if(ter<0) { printf("GraOS: cannot allocate input terminal.\n"); return 1; }

    pid=centralprocess_exec("graos.bin","graos.bin",GetCurrentDNR(),GetCurrentDB(),"",ter);
    if(pid<=0)
        pid=centralprocess_exec("graos.bin","graos.bin",GetCurrentDNR(),GetCurrentDB(),"/",ter);
    if(pid<=0) { printf("launch failed: graos.bin\n"); FreeTerminal(ter); return 1; }

    /* GraOS is the compositor/server and must be able to snapshot bitmap
     * surfaces owned by client processes.  Grant the capability here, in the
     * kernel-controlled GraOS launcher, instead of trusting the user-settable
     * process name "guiserver".  GraOSBootStart() grants the same bit on the
     * direct boot path. */
    SetThreadType(pid,GetThreadType(pid)|THREAD_TYPE_SERVICE);
    SetTerminalOwner(ter,pid);
    if(SwitchUserTerminal(ter)) {
        printf("GraOS: cannot focus terminal %d.\n",ter);
        return 1;
    }
    printf("PID %d: graos.bin (keyboard terminal %d; SMSH terminal %d)\n",
           pid,ter,parent_terminal);
    return 0;
}

static int join_args(int argc,char **argv,int first,char *out,int cap)
{
    int i,used=0,j;

    if(!out || cap<=0) return 0;
    out[0]=0;

    /* Kernel SMSH is not linked against the userspace stdio implementation.
     * Build the command line explicitly instead of depending on snprintf(). */
    for(i=first;i<argc;i++)
    {
        if(!argv[i]) continue;

        if(used)
        {
            if(used+1>=cap) { out[0]=0; return 0; }
            out[used++]=' ';
        }

        for(j=0;argv[i][j];j++)
        {
            if(used+1>=cap) { out[0]=0; return 0; }
            out[used++]=argv[i][j];
        }
        out[used]=0;
    }
    return used>0;
}
static void pm_help(void)
{
    printf("Postman commands:\n  pm status\n  pm find NAME\n  pm exec COMMAND...\n  pm cleanup\n");
}
static int pm_main(int argc,char **argv)
{
    const char *sub=argc>1?argv[1]:"status";
    if(!strcmp(sub,"status")){printf("Postman/current PID: %d\n",GetCurrentThread());printf("GraOS PID: %d\n",GetThreadPID("guiserver"));return 0;}
    if(!strcmp(sub,"find")){int p;if(argc<3){pm_help();return 1;}p=GetThreadPID(argv[2]);printf("%s: %d\n",argv[2],p);return p>0?0:1;}
    if(!strcmp(sub,"exec")||!strcmp(sub,"launch")){char cmd[1024];if(!join_args(argc,argv,2,cmd,sizeof(cmd))){pm_help();return 1;}return launch_background(cmd);}
    if(!strcmp(sub,"cleanup")){printf("Postman cleanup: native msgbox state is PID-owned and cleaned on process exit.\n");return 0;}
    pm_help();return !(!strcmp(sub,"help")||!strcmp(sub,"--help"));
}
int graos_shell_try_command(const char *command,int argc,char **argv)
{
    if(!command)return SH_NOT_HANDLED;
    if(!strcmp(command,"graos")||!strcmp(command,"gui")){
        if(GetThreadPID("guiserver")>0){printf("GraOS already running, PID %d.\n",GetThreadPID("guiserver"));return 0;}
        return launch_graos();
    }
    if(!strcmp(command,"postman")||!strcmp(command,"pm"))return pm_main(argc,argv);
    return SH_NOT_HANDLED;
}
