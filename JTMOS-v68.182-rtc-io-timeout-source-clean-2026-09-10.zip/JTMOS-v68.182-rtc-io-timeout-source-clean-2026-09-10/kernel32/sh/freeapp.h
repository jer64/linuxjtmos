#ifndef JTMOS_FREEAPP_H
#define JTMOS_FREEAPP_H
int free_app(int argc, char **argv);
#endif
