//
#include "kernel32.h"
#include "driver_sys.h"
#include "driver_api.h"
#include "driver_BlockCache.h"

//
BCACHE bc;

//
int cacheRB(int dnr, int bnr, BYTE *buf)
{
	/* Legacy block-cache entry point is currently unused.  Do not return an
	 * indeterminate value if an old caller reaches it. */
	(void)dnr; (void)bnr; (void)buf;
	return 0;
}





