/*
 * keymap.c - JTMOS built-in keyboard layouts
 *
 * Layout A: Finnish (ISO 102/105-key, ISO-8859-1 output)
 * Layout B: English (US, default)
 *
 * The keyboard driver owns modifier state; this file only translates one
 * scan-code-set-1 MAKE code plus modifier flags into a character.
 */
#include "keymap.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

typedef struct JTMOS_KEYMAP_ENTRY {
    unsigned short normal;
    unsigned short shifted;
    unsigned short altgr;
    unsigned char alphabetic;
} JTMOS_KEYMAP_ENTRY;

static int active_layout = KEYBOARD_LAYOUT_ENGLISH;

static int ascii_strieq(const char *a, const char *b)
{
    unsigned char ca, cb;
    if(a == NULL || b == NULL) return 0;
    while(*a && *b) {
        ca = (unsigned char)*a++;
        cb = (unsigned char)*b++;
        if(ca >= 'A' && ca <= 'Z') ca = (unsigned char)(ca + ('a' - 'A'));
        if(cb >= 'A' && cb <= 'Z') cb = (unsigned char)(cb + ('a' - 'A'));
        if(ca != cb) return 0;
    }
    return *a == 0 && *b == 0;
}

/* US English, scan code set 1.  The ISO extra key (0x56) is kept as < > so
 * the same physical 105-key keyboard remains fully usable in English mode. */
static const JTMOS_KEYMAP_ENTRY english_map[128] = {
    [0x02]={'1','!',0,0}, [0x03]={'2','@',0,0}, [0x04]={'3','#',0,0},
    [0x05]={'4','$',0,0}, [0x06]={'5','%',0,0}, [0x07]={'6','^',0,0},
    [0x08]={'7','&',0,0}, [0x09]={'8','*',0,0}, [0x0a]={'9','(',0,0},
    [0x0b]={'0',')',0,0}, [0x0c]={'-','_',0,0}, [0x0d]={'=','+',0,0},
    [0x10]={'q','Q',0,1}, [0x11]={'w','W',0,1}, [0x12]={'e','E',0,1},
    [0x13]={'r','R',0,1}, [0x14]={'t','T',0,1}, [0x15]={'y','Y',0,1},
    [0x16]={'u','U',0,1}, [0x17]={'i','I',0,1}, [0x18]={'o','O',0,1},
    [0x19]={'p','P',0,1}, [0x1a]={'[','{',0,0}, [0x1b]={']','}',0,0},
    [0x1e]={'a','A',0,1}, [0x1f]={'s','S',0,1}, [0x20]={'d','D',0,1},
    [0x21]={'f','F',0,1}, [0x22]={'g','G',0,1}, [0x23]={'h','H',0,1},
    [0x24]={'j','J',0,1}, [0x25]={'k','K',0,1}, [0x26]={'l','L',0,1},
    [0x27]={';',':',0,0}, [0x28]={'\'', '"',0,0}, [0x29]={'`','~',0,0},
    [0x2b]={'\\','|',0,0}, [0x2c]={'z','Z',0,1}, [0x2d]={'x','X',0,1},
    [0x2e]={'c','C',0,1}, [0x2f]={'v','V',0,1}, [0x30]={'b','B',0,1},
    [0x31]={'n','N',0,1}, [0x32]={'m','M',0,1}, [0x33]={',','<',0,0},
    [0x34]={'.','>',0,0}, [0x35]={'/','?',0,0}, [0x39]={' ',' ',0,0},
    [0x56]={'<','>',0,0}
};

/* Finnish ISO layout.  National letters are ISO-8859-1 because the existing
 * JTMOS text/font path is byte-oriented.  AltGr supplies the common symbols
 * needed for shell/programming use.  The acute/diaeresis keys are emitted as
 * spacing characters; JTMOS does not yet implement compose/dead-key state. */
static const JTMOS_KEYMAP_ENTRY finnish_map[128] = {
    [0x02]={'1','!',0,0},       [0x03]={'2','"','@',0},
    [0x04]={'3','#',0xa3,0},    [0x05]={'4',0xa4,'$',0},
    [0x06]={'5','%',0,0},       [0x07]={'6','&',0,0},
    [0x08]={'7','/','{',0},     [0x09]={'8','(','[',0},
    [0x0a]={'9',')',']',0},     [0x0b]={'0','=','}',0},
    [0x0c]={'+','?','\\',0},  [0x0d]={0xb4,'`',0,0},
    [0x10]={'q','Q',0,1}, [0x11]={'w','W',0,1}, [0x12]={'e','E',0,1},
    [0x13]={'r','R',0,1}, [0x14]={'t','T',0,1}, [0x15]={'y','Y',0,1},
    [0x16]={'u','U',0,1}, [0x17]={'i','I',0,1}, [0x18]={'o','O',0,1},
    [0x19]={'p','P',0,1}, [0x1a]={0xe5,0xc5,0,1},
    [0x1b]={0xa8,'^','~',0},
    [0x1e]={'a','A',0,1}, [0x1f]={'s','S',0,1}, [0x20]={'d','D',0,1},
    [0x21]={'f','F',0,1}, [0x22]={'g','G',0,1}, [0x23]={'h','H',0,1},
    [0x24]={'j','J',0,1}, [0x25]={'k','K',0,1}, [0x26]={'l','L',0,1},
    [0x27]={0xf6,0xd6,0,1}, [0x28]={0xe4,0xc4,0,1},
    [0x29]={0xa7,0xbd,0,0}, [0x2b]={'\'','*',0,0},
    [0x2c]={'z','Z',0,1}, [0x2d]={'x','X',0,1}, [0x2e]={'c','C',0,1},
    [0x2f]={'v','V',0,1}, [0x30]={'b','B',0,1}, [0x31]={'n','N',0,1},
    [0x32]={'m','M',0,1}, [0x33]={',',';',0,0}, [0x34]={'.',':',0,0},
    [0x35]={'-','_',0,0}, [0x39]={' ',' ',0,0}, [0x56]={'<','>','|',0}
};

static const JTMOS_KEYMAP_ENTRY *layout_table(int layout)
{
    if(layout == KEYBOARD_LAYOUT_FINNISH) return finnish_map;
    return english_map;
}

int KeyboardTranslateScancode(int layout, int scancode,
                              int shift, int altgr, int capslock)
{
    const JTMOS_KEYMAP_ENTRY *table;
    const JTMOS_KEYMAP_ENTRY *entry;
    int use_shift;

    if(scancode < 0 || scancode >= 128) return KEYMAP_UNMAPPED;
    table = layout_table(layout);
    entry = &table[scancode];
    if(entry->normal == 0 && entry->shifted == 0 && entry->altgr == 0)
        return KEYMAP_UNMAPPED;

    if(altgr && entry->altgr != 0)
        return (int)entry->altgr;

    /* Caps Lock affects letters only.  Shift XOR Caps gives normal keyboard
     * behaviour and, crucially, never uppercases punctuation. */
    use_shift = shift ? 1 : 0;
    if(entry->alphabetic && capslock)
        use_shift = !use_shift;

    if(use_shift && entry->shifted != 0)
        return (int)entry->shifted;
    return (int)entry->normal;
}

int KeyboardSetLayout(int layout)
{
    if(layout != KEYBOARD_LAYOUT_ENGLISH && layout != KEYBOARD_LAYOUT_FINNISH)
        return -1;
    active_layout = layout;
    return 0;
}

int KeyboardSetLayoutByName(const char *name)
{
    if(name == NULL) return -1;
    if(ascii_strieq(name,"english") || ascii_strieq(name,"en") ||
       ascii_strieq(name,"us") || ascii_strieq(name,"en-us"))
        return KeyboardSetLayout(KEYBOARD_LAYOUT_ENGLISH);
    if(ascii_strieq(name,"finnish") || ascii_strieq(name,"fi") ||
       ascii_strieq(name,"fi-fi"))
        return KeyboardSetLayout(KEYBOARD_LAYOUT_FINNISH);
    return -1;
}

int KeyboardGetLayout(void)
{
    return active_layout;
}

const char *KeyboardGetLayoutName(void)
{
    return active_layout == KEYBOARD_LAYOUT_FINNISH ? "Finnish" : "English (US)";
}
