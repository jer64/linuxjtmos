/**************************************************
 * keyb.c - Keyboard driver version 1.3           *
 * (C) 2002-2005 by Jari Tuominen.                *
 **************************************************/
//
////#define __KEYDEBUG__
//#define __KBIRQDEBUG__
//
#include <kernel32.h>
#include <cpu.h>
#include <io.h>
#include <keyb.h>
#include <sysglvar.h>
#include <ega.h>
#include <int.h>
#include <vga.h>
#include <scanasc.h>
#include <keymap.h>
#include <dispadmin.h>
//
#include <driver_sys.h> // driver_register_new_device, ...
#include <driver_api.h>
//
#include <ps2mouse.h>
#include "input_policy.h"
#if JTMOS_MOD_PCI
#include "usb_input.h"
#endif
#include <term.h>
#include <vesa.h>
#include <scheduler.h>

//
int syskey_terminate=0;

/* One Ctrl+C latch per terminal.  IRQ1 only sets a byte; process context
 * performs the destructive action.  This avoids killing a task from inside
 * the keyboard interrupt handler and prevents Ctrl+C on one VT from
 * terminating a foreground job on another VT. */
static volatile BYTE terminal_interrupt_pending[N_MAX_SCREENS];

void SignalTerminalInterrupt(int terminal)
{
    if(terminal<0 || terminal>=N_MAX_SCREENS)
        terminal=0;
    terminal_interrupt_pending[terminal]=1;
    syskey_terminate=1; /* compatibility with historical callapp monitor */
}

int PeekTerminalInterrupt(int terminal)
{
    if(terminal<0 || terminal>=N_MAX_SCREENS)
        return 0;
    return terminal_interrupt_pending[terminal] ? 1 : 0;
}

int ConsumeTerminalInterrupt(int terminal)
{
    DWORD flags;
    int i,hit=0,any=0;

    if(terminal<0 || terminal>=N_MAX_SCREENS)
        return 0;
    flags=get_eflags();
    disable();
    if(terminal_interrupt_pending[terminal])
    {
        terminal_interrupt_pending[terminal]=0;
        hit=1;
    }
    for(i=0;i<N_MAX_SCREENS;i++)
        if(terminal_interrupt_pending[i]) { any=1; break; }
    if(!any) syskey_terminate=0;
    set_eflags(flags);
    return hit;
}


// Key status.
KEYS keys;

//
KBSTR kbstr;

/* PS/2/i8042 diagnostics.  IRQ counters make it possible to distinguish a
 * dead IRQ1 path from a scan-code/terminal-routing problem without touching
 * port 0x60 from an unrelated debugger. */
volatile DWORD keyb_irq_count=0;
volatile DWORD keyb_byte_count=0;
volatile DWORD keyb_poll_count=0;
volatile int keyb_hwinit_status=-1;
volatile BYTE keyb_controller_byte=0;

#define I8042_CMD_READ_CBYTE       0x20
#define I8042_CMD_WRITE_CBYTE      0x60
#define I8042_CMD_DISABLE_AUX      0xA7
#define I8042_CMD_DISABLE_KBD      0xAD
#define I8042_CMD_ENABLE_KBD       0xAE
#define I8042_CMD_TEST_KBD_PORT    0xAB
#define I8042_CBYTE_IRQ1           0x01
#define I8042_CBYTE_KBD_DISABLED   0x10
#define I8042_CBYTE_TRANSLATION    0x40
#define KEYB_I8042_SPIN_LIMIT      300000UL
#define KEYB_RESET_SPIN_LIMIT      2000000UL
/* Preserve a firmware/FreeDOS-proven keyboard by default.  Linux i8042 also
 * makes keyboard-port reset opt-in because a hard reset is problematic on
 * some laptops and USB-legacy emulations. */
#define KEYB_FORCE_DEVICE_RESET     0
/* Default JTMOS policy: preserve the BIOS/POST i8042 + keyboard state.
 * Installing IRQ1 does not require touching the controller or device. */
#define KEYB_BIOS_PRESERVE          1

/* Lock keys are logical toggle state, not ordinary held modifiers.  LED
 * programming is deferred out of IRQ1 so keyboard ACK bytes never have to be
 * synchronously consumed from interrupt context. */
static volatile int keyb_led_update_pending=0;
static volatile int keyb_led_update_busy=0;
static volatile int keyb_command_response=0;


/* Scan-code-set-1 extended prefix state.  The old driver treated 0xE0 as a
 * BREAK byte, causing Right Alt to become Left Alt and making AltGr layouts
 * impossible. */
static int keyb_e0_prefix=0;
static int keyb_win_chord_used=0;
static int keyb_e1_bytes_left=0;

static int keyb_map_e0_scancode(BYTE raw)
{
    switch(raw)
    {
        case 0x1c: return SCODE_KEYPADENTER;
        case 0x1d: return SCODE_RIGHTCONTROL;
        case 0x35: return SCODE_KEYPADDIVIDE;
        case 0x38: return SCODE_RIGHTALT;
        case 0x5b: return SCODE_LWIN;
        case 0x5c: return SCODE_RWIN;
        case 0x47: return SCODE_HOME;
        case 0x48: return SCODE_CURSORBLOCKUP;
        case 0x49: return SCODE_PGUP;
        case 0x4b: return SCODE_CURSORBLOCKLEFT;
        case 0x4d: return SCODE_CURSORBLOCKRIGHT;
        case 0x4f: return SCODE_END;
        case 0x50: return SCODE_CURSORBLOCKDOWN;
        case 0x51: return SCODE_PGDN;
        case 0x52: return SCODE_INSERT;
        case 0x53: return SCODE_DELETE;
        default: return -1;
    }
}

static int keyb_handle_lock_make(BYTE scancode)
{
    BYTE mask=0;

    if(scancode==SCODE_CAPSLOCK) mask=LED_CAPS_LOCK;
    else if(scancode==SCODE_NUMLOCK) mask=LED_NUM_LOCK;
    else if(scancode==SCODE_SCROLLLOCK) mask=LED_SCROLL_LOCK;
    else return 0;

    kbstr.led_status ^= mask;
    keyb_led_update_pending=1;
    return 1;
}

/* Text-console hotkeys: Left Alt + F1..F7 => VT1..VT7.
 * Consume the raw function-key MAKE before scan_to_asc(), otherwise Alt+F4
 * would become the desktop close command.  The selector is active for both
 * native EGA/VGA mode-03h and the RAM-backed virtual VGA/LFB text console.
 * GraOS disables the text-console renderer when it owns the framebuffer, so
 * its Alt+F4 chord remains untouched. */
static int keyb_handle_alt_function_terminal(BYTE scancode, int was_down)
{
    int function_key;

    if(!kbstr.ktab[SCODE_LEFTALT])
        return 0;
    if(scancode < SCODE_F1 || scancode > SCODE_F7)
        return 0;
    if(!VgaFunctionTerminalHotkeysActive())
        return 0;

    function_key=(int)scancode-(int)SCODE_F1+1;

    /* Repeated MAKE codes are consumed, but only the first edge changes the
     * selected terminal. */
    if(!was_down)
        SwitchEgaFunctionTerminal(function_key);

    return 1;
}

/* Historical EGA/VGA text-console hotkey: Left Alt + top-row 1..9 selects
 * virtual terminal 1..9. Handle this from the raw MAKE path before
 * scan_to_asc(), because the Finnish legacy keymap also uses Alt+number for
 * printable symbols. Repeated MAKEs are consumed and do not retrigger. */
static int keyb_handle_terminal_hotkey(BYTE scancode, int was_down)
{
    int terminal;

    if(!VgaEgaTextConsoleActive())
        return 0;
    if(!kbstr.ktab[SCODE_LEFTALT])
        return 0;
    if(scancode < 0x02 || scancode > 0x0A)
        return 0;

    terminal = (int)scancode - 0x02;      /* 1 -> VT0, ... 9 -> VT8 */

    /* Switch only on the up->down edge. Repeated MAKE codes while the
     * number key is held are consumed but do not retrigger the switch. */
    if(!was_down)
        SwitchUserTerminal(terminal);

    return 1;
}

// Get CTRL key status.
int GetCTRL(void)
{
	return keys.ctrl;
}

/* BIOS Data Area 0040:0017 bit 2 says that either Ctrl key was held while
 * BIOS still owned the keyboard.  Page zero is deliberately unmapped once
 * JTMOS enables paging, so the BDA MUST be sampled before mmInit().  Keep the
 * sample in ordinary kernel storage and never dereference 0x417 afterwards. */
static volatile int boot_ctrl_bios_latched=0;

void KeyboardCaptureBootModifiers(void)
{
	BYTE bios_flags;
	DWORD bios_flags_addr=0x417U;
	/* This is an intentional physical BDA read before paging.  Keep it in
	 * inline assembly so GCC does not model 0x417 as an object relative to
	 * the C null pointer and emit a misleading array-bounds diagnostic. */
	__asm__ volatile("movb (%1),%0"
	                 : "=q"(bios_flags)
	                 : "r"(bios_flags_addr)
	                 : "memory");
	boot_ctrl_bios_latched=((bios_flags & 0x04U)!=0);
}

/* Once native input is live, also accept either JTMOS left/right Ctrl state.
 * This covers a Ctrl key pressed after the pre-paging BIOS snapshot. */
int KeyboardBootCtrlHeld(void)
{
	int live=0;

	if(kbstr.ktab!=NULL)
		live=kbstr.ktab[SCODE_LEFTCONTROL] || kbstr.ktab[SCODE_RIGHTCONTROL];
	return live || boot_ctrl_bios_latched;
}

// Get ALT key status.
int GetALT(void)
{
	return keys.alt;
}

// Get CTRL/ALT.
void HandleStickKeys(void)
{
	// Left and Right Ctrl are independent set-1 scancodes (29 and E0 1D).
	keys.ctrl =	kbstr.ktab[SCODE_LEFTCONTROL] || kbstr.ktab[SCODE_RIGHTCONTROL];
	/* Keep AltGr distinct from legacy Left-Alt shortcuts. */
	keys.alt =	kbstr.ktab[SCODE_LEFTALT];
}

static int keyb_i8042_wait_input_empty_spin(unsigned long limit)
{
    unsigned long i;
    for(i=0;i<limit;i++)
    {
        if(!(inportb(0x64)&KBD_STAT_IBF)) return 0;
        inportb(0x80);
    }
    return 1;
}

static int keyb_i8042_wait_output_spin(BYTE *status_out, BYTE *data_out,
                                       unsigned long limit)
{
    unsigned long i;
    BYTE status;

    for(i=0;i<limit;i++)
    {
        status=inportb(0x64);
        if(status&KBD_STAT_OBF)
        {
            if(status_out) *status_out=status;
            if(data_out) *data_out=inportb(0x60);
            else (void)inportb(0x60);
            return 0;
        }
        inportb(0x80);
    }
    return 1;
}

/* Controller/device setup runs before the PS/2 mouse driver is attached and
 * with CPU interrupts disabled.  Disable both ports first, then it is safe to
 * empty stale controller output exactly once during boot. */
static void keyb_i8042_flush_output(void)
{
    int i;
    for(i=0;i<64;i++)
    {
        if(!(inportb(0x64)&KBD_STAT_OBF)) break;
        (void)inportb(0x60);
    }
}

static int keyb_i8042_command(BYTE command)
{
    if(keyb_i8042_wait_input_empty_spin(KEYB_I8042_SPIN_LIMIT)) return 1;
    outportb(0x64,command);
    return 0;
}

static int keyb_i8042_read_command_byte(BYTE *value)
{
    BYTE status,data;
    if(value==NULL) return 1;
    if(keyb_i8042_command(I8042_CMD_READ_CBYTE)) return 2;
    if(keyb_i8042_wait_output_spin(&status,&data,KEYB_I8042_SPIN_LIMIT)) return 3;
    *value=data;
    return 0;
}

static int keyb_i8042_write_command_byte(BYTE value)
{
    if(keyb_i8042_command(I8042_CMD_WRITE_CBYTE)) return 1;
    if(keyb_i8042_wait_input_empty_spin(KEYB_I8042_SPIN_LIMIT)) return 2;
    outportb(0x60,value);
    return 0;
}

/* Send a keyboard command and synchronously consume ACK/RESEND.  This is a
 * boot-time polling path: IRQ1 is intentionally still masked. */
static int keyb_device_command_ack(BYTE command)
{
    int attempt;
    unsigned long i;
    BYTE status,data;

    for(attempt=0;attempt<3;attempt++)
    {
        if(keyb_i8042_wait_input_empty_spin(KEYB_I8042_SPIN_LIMIT)) return 1;
        outportb(0x60,command);

        for(i=0;i<KEYB_I8042_SPIN_LIMIT;i++)
        {
            status=inportb(0x64);
            if(status&KBD_STAT_OBF)
            {
                data=inportb(0x60);
                if(data==0xFA) return 0;
                if(data==0xFE) break;
                if(data==0xFC || data==0xFD) return 2;
                /* Stale scan code or BAT byte: consume it during the
                 * quiescent boot-time command exchange and keep waiting. */
            }
            inportb(0x80);
        }
    }
    return 3;
}

/* Reset requires two device responses.  Accept ACK (FA) and BAT OK (AA) in
 * either order; real controllers/keyboards differ in how tightly they queue
 * these bytes. */
static int keyb_device_reset(void)
{
    int attempt,saw_ack,saw_bat,resend;
    unsigned long i;
    BYTE status,data;

    for(attempt=0;attempt<3;attempt++)
    {
        saw_ack=0;
        saw_bat=0;
        resend=0;
        if(keyb_i8042_wait_input_empty_spin(KEYB_I8042_SPIN_LIMIT)) return 1;
        outportb(0x60,0xFF);

        for(i=0;i<KEYB_RESET_SPIN_LIMIT;i++)
        {
            status=inportb(0x64);
            if(status&KBD_STAT_OBF)
            {
                data=inportb(0x60);
                if(data==0xFE) { resend=1; break; }
                if(data==0xFA) saw_ack=1;
                else if(data==0xAA) saw_bat=1;
                else if(data==0xFC || data==0xFD) return 2;
                if(saw_ack && saw_bat) return 0;
            }
            inportb(0x80);
        }
        if(!resend && saw_bat) return 0; /* tolerate controllers hiding ACK */
    }
    return 3;
}

/* Bounded process-context fallback.  A correctly configured system uses IRQ1;
 * this only rescues input if firmware/chipset interrupt routing is broken. */
void KeyboardPollInputOnce(void)
{
    DWORD flags;
    BYTE status,key;

    flags=get_eflags();
    disable();
    status=inportb(0x64);
    if(status&KBD_STAT_OBF)
    {
        /* Before GraOS starts, AUX is deliberately disabled and no mouse
         * driver owns port 0x60.  In that keyboard-only phase do not trust
         * status bit 5: several 8042-compatible/legacy implementations give
         * it chipset-specific semantics.  Once the mouse is active, preserve
         * genuine AUX bytes for IRQ12/the mouse poller. */
        if(!ps2mouse_enabled || !(status&KBD_STAT_MOUSE_OBF))
        {
            key=inportb(0x60);
            keyb_poll_count++;
            keyb_byte_count++;
            keyb_receive_ps2_byte(key);
        }
    }
    set_eflags(flags);
}

//
// void set_vector(void *handler,
//            unsigned char interrupt, unsigned short control_major)
//
int InitKeyboard()
{
    int retval=0,i;
    DWORD flags;

    printk("Keyboard driver 1.5 / i8042 PS/2 IRQ1.\n");

    memset(&kbstr,0,sizeof(KBSTR));
    KeyboardSetLayout(KEYBOARD_LAYOUT_ENGLISH);
    kbstr.led_status=0;
    /* Avoid fresh command traffic at the very first SMSH getch().  The first
     * lock-key transition will request an LED update normally. */
    keyb_led_update_pending=0;
    keyb_irq_count=0;
    keyb_byte_count=0;
    keyb_poll_count=0;
    keyb_hwinit_status=-1;
    keyb_controller_byte=0;

    kbstr.macro=malloc(256);
    kbstr.ktab=malloc(1024*64);
    kbstr.buf=malloc(KEYBOARD_BUFFER_LENGTH*2+100);
    kbstr.abuf=malloc(KEYBOARD_BUFFER_LENGTH*2+100);
    if(!kbstr.macro || !kbstr.ktab || !kbstr.buf || !kbstr.abuf)
    {
        printk("Keyboard: buffer allocation failed.\n");
        return 10;
    }
    memset(kbstr.ktab,0,1024*64);
    memset(kbstr.buf,0,KEYBOARD_BUFFER_LENGTH*2+100);
    memset(kbstr.abuf,0,KEYBOARD_BUFFER_LENGTH*2+100);
    strcpy(kbstr.macro,"");

    /* BIOS-preserve attach.  POST/BIOS has already initialized the i8042 and
     * keyboard.  Normal boot must not disable ports, flush 0x60, reset the
     * device, change scan sets, or send F4: on real legacy/USB bridges those
     * operations can kill an otherwise working keyboard.  We only install the
     * IRQ gate and unmask IRQ1.  kb_hwinit() remains available as diagnostic
     * code but is not part of the default boot path. */
    flags=get_eflags();
    disable();
    disable_irq(1);
#if KEYB_BIOS_PRESERVE
    retval=0;
    keyb_hwinit_status=0;
#else
    retval=kb_hwinit();
    keyb_hwinit_status=retval;
#endif

    setint(M_VEC+1,keyb_ISR,GIMMIE_CS(),D_PRESENT+D_INT);
    enable_irq(1);
    set_eflags(flags);

    if(keyb_register_device())
        printk("Keyboard: DEVDB registration already present or failed.\n");

#if KEYB_BIOS_PRESERVE
    printk("Keyboard: BIOS-preserve attach, IRQ1 enabled; no i8042/device reset performed.\n");
#else
    if(retval)
        printk("Keyboard: hardware init warning stage=%d; IRQ1 + polling fallback enabled.\n",retval);
    else
        printk("Keyboard: ready, IRQ1 enabled, controller byte=%x.\n",keyb_controller_byte);
#endif

    /* Make sure no stale software state from a previous warm boot survives. */
    for(i=0;i<N_MAX_SCREENS;i++) terminal_interrupt_pending[i]=0;
    return retval;
}

//
void kb_outbuf(int akey)
{
	// Zero code?
	if(!akey)return;

	// Store if space left at the buffer.
	if(kbstr.ai<KEYBOARD_BUFFER_LENGTH)
	{
		kbstr.abuf[kbstr.ai]=akey;
		kbstr.ai++;
		kbstr.abuf[kbstr.ai]=0;
		//if(kbstr.ExtraKey)goto morekeys;
	}
}

// Converts scancodes to more practically useful ASCII codes.
// F.e. getch returns only ASCII codes.
//
int kb_output_asc_buffer(int key)
{
	int akey;

	//
	if(key==-1 || key==0)return 0;

	//
	if(kbstr.abuf[0]==0){kbstr.ai=0;}

	//
	if(kbstr.ai>=KEYBOARD_BUFFER_LENGTH)
	{
		kbstr.ai=0;
	}

	// CONVERT SCANCODE TO ASCII
	// Also gives a character from possible macro string, etc.
morekeys:
	akey=scan_to_asc(key);

	if(kbstr.ExtraKey==0xFF || kbstr.ExtraKeyCode)
	{
		akey=kbstr.ExtraKeyCode;
		kbstr.ExtraKey=0;
		kbstr.counter=0;
		kbstr.ExtraKeyCode=0;
	}

	if(akey)		kb_outbuf(akey);
	if(kbstr.ExtraKey)	goto morekeys;

	//
	return 0;
}

//
void incmark(void)
{
	char *buf;

	//
	buf=JTM_DWORD_TO_PTR(char,0xB8000);

	//
	buf[0]++;
}

//
char getmark(int offs)
{
	char *buf;

	/*
	 * In VESA text-console mode 0xB8000 is no longer the visible console.
	 * The logical VGA/EGA screen lives in the active terminal's RAM buffer
	 * and is rendered to the LFB by vesa.c.  Keep these historical helpers
	 * working so the existing text-mode mouse cursor can be used unchanged.
	 */
	if(vesa_text_console_enabled &&
	   visible_terminal>=0 && visible_terminal<N_MAX_SCREENS &&
	   screens[visible_terminal].buf!=NULL && offs>=0 && offs<80*25*2)
	{
		buf=screens[visible_terminal].buf;
		return buf[offs];
	}

	buf=(char *)0xb8000;
	return buf[offs];
}

//
void storemark(int which,int offs)
{
	char *buf;

	if(vesa_text_console_enabled &&
	   visible_terminal>=0 && visible_terminal<N_MAX_SCREENS &&
	   screens[visible_terminal].buf!=NULL && offs>=0 && offs<80*25*2)
	{
		buf=screens[visible_terminal].buf;
		buf[offs]=(char)which;
		VesaTextConsoleCellChanged(&screens[visible_terminal],offs);
		return;
	}

	buf=(char *)0xb8000+offs;
	buf[0]=(char)which;
}

// Terminal getch1
int getch1(void)
{
	int key;

	keyb_service();
	KeyboardPollInputOnce();
	SCREEN *s;

	// Get terminal
	s = &screens[GetThreadTerminal(GetCurrentThread())];

	// Input keyboard
	key = PopBufferW(&s->key);

	// Filter input data
	if(key==-1)
		return 0;
	else
		return key;
}

// Redirection of keyboard stream
// to appropriate terminal.
void RedirectKeyboardStream(void)
{
	int t,key;
	SCREEN *s;

	/* Route the physical keyboard to the active input terminal, not merely
	 * to the terminal whose text buffer happens to be visible.  GraOS runs
	 * in the background relative to SMSH and therefore needs an exclusive
	 * keyboard target to avoid both processes racing on VT0's FIFO. */
	t = GetInputTerminal();
	s = &screens[t];

	// Output all keys to the terminal's
	// keyboard buffer.
	while( (key=directgetch())>=1 )
	{
        int target_pid;
        /* Only a successfully queued physical key earns an activity boost.
         * Prefer the foreground child (editor/ping/etc.) over the shell that
         * owns the terminal itself. */
        if(PushBufferW(&s->key,key)==0) {
            target_pid=(s->foreground_pid>0)?s->foreground_pid:s->pid;
            SchedulerNoteActivity(target_pid,SCHED_ACTIVITY_KEYBOARD,1);
        }
	}
}

//
// Keyboard Interrupt Handler
//
static void keyb_process_scancode(BYTE key)
{
    int sc;
    int is_break;
    int was_down;

    /* Keyboard command responses are not key scancodes. */
    if(key==0xFA || key==0xFE)
        return;
    if(key==0xFC || key==0xFD)
    {
        printk("\nkeyb.c: keyboard error 0xfc/0xfd\n");
        return;
    }

    /* Decode scan-code-set-1 E0 sequences into the extended symbolic codes
     * already defined by scanasc.h.  This distinguishes Right Alt (AltGr)
     * from Left Alt and also makes the dedicated cursor block unambiguous. */
    if(key==0xE0)
    {
        keyb_e0_prefix=1;
        return;
    }
    if(keyb_e1_bytes_left>0)
    {
        keyb_e1_bytes_left--;
        return;
    }
    if(key==0xE1)
    {
        /* Pause/Break is E1 1D 45 E1 9D C5 in set 1.  Ignore the remaining
         * five bytes so they cannot look like Ctrl/NumLock transitions. */
        keyb_e0_prefix=0;
        keyb_e1_bytes_left=5;
        return;
    }

    is_break=(key&0x80) ? 1 : 0;
    sc=(int)(key&0x7f);
    if(keyb_e0_prefix)
    {
        keyb_e0_prefix=0;
        sc=keyb_map_e0_scancode((BYTE)sc);
        if(sc<0)
            return;
    }

    if(is_break)
    {
        int was_win=(sc==SCODE_LWIN || sc==SCODE_RWIN);
        kbstr.ktab[sc]=0;
        kbstr.rkey=(WORD)sc;
        /* Plain Win opens Start only on release.  If another key participated
         * in the chord, suppress the release action. */
        if(was_win && !kbstr.ktab[SCODE_LWIN] && !kbstr.ktab[SCODE_RWIN]) {
            if(!keyb_win_chord_used) kb_outbuf(JKEY_START_MENU);
            keyb_win_chord_used=0;
        }
        goto done;
    }

    was_down=kbstr.ktab[sc] ? 1 : 0;
    kbstr.ktab[sc]=1;
    if((sc==SCODE_LWIN || sc==SCODE_RWIN) && !was_down)
        keyb_win_chord_used=0;
    else if((kbstr.ktab[SCODE_LWIN] || kbstr.ktab[SCODE_RWIN]) &&
            sc!=SCODE_LWIN && sc!=SCODE_RWIN)
        keyb_win_chord_used=1;

    if(!was_down && keyb_handle_lock_make((BYTE)sc))
        goto done;
    if(was_down && (sc==SCODE_CAPSLOCK || sc==SCODE_NUMLOCK ||
                    sc==SCODE_SCROLLLOCK))
        goto done;

    if(keyb_handle_alt_function_terminal((BYTE)sc,was_down))
        goto done;
    if(keyb_handle_terminal_hotkey((BYTE)sc,was_down))
        goto done;

    /* Do not emit an event on Windows-key make; scanasc handles chords and
     * the raw release path above emits a lone Windows key. */
    if(sc==SCODE_LWIN || sc==SCODE_RWIN)
        goto done;

    /* Launch/close chords are edge-triggered.  Keep Tab repeatable for task
     * switching, but do not let typematic spawn apps or close many windows. */
    if(was_down && kbstr.ktab[SCODE_LEFTALT] && sc==SCODE_F4)
        goto done;
    if(was_down && (kbstr.ktab[SCODE_LWIN] || kbstr.ktab[SCODE_RWIN]) &&
       sc!=0x0f)
        goto done;

    if(!was_down && sc==SCODE_C &&
       (kbstr.ktab[SCODE_LEFTCONTROL] || kbstr.ktab[SCODE_RIGHTCONTROL]))
    {
        /* Use the same routing as GraOS-injected ETX: foreground child =>
         * terminal interrupt/SIGINT, shell prompt => byte 3 in its FIFO. */
        OutTermKey(GetInputTerminal(),3);
        goto done;
    }

    if(!was_down && sc==SCODE_D &&
       (kbstr.ktab[SCODE_LEFTCONTROL] || kbstr.ktab[SCODE_RIGHTCONTROL]))
    {
        /* POSIX/Linux-style terminal EOT.  Unlike Ctrl+C this is not a signal:
         * raw getch() readers receive byte 4 and canonical fd-0 readers turn
         * it into EOF.  Shells therefore exit on Ctrl+D at an empty prompt. */
        OutTermKey(GetInputTerminal(),4);
        goto done;
    }

    translate_keyboard_situation();
    if(kbstr.i<KEYBOARD_BUFFER_LENGTH)
    {
        kbstr.key_pressed=1;
        kb_output_asc_buffer(sc);
    }

done:
    HandleStickKeys();
    RedirectKeyboardStream();
}

/* Route one raw i8042 keyboard byte through the same state machine used by
 * IRQ1.  The PS/2 mouse driver uses this while it owns the shared 0x60 data
 * register for a short synchronous AUX command exchange, so a pending keyboard
 * byte is preserved instead of blocking or being discarded. */
void keyb_receive_byte(BYTE key)
{
    if(keyb_led_update_busy && (key==0xFA || key==0xFE))
        keyb_command_response=key;
    else
        keyb_process_scancode(key);
}

/* Physical i8042/BIOS-legacy keyboard source.  Always drain port 0x60, but
 * once native USB has produced a real HID keyboard report the single-seat
 * policy suppresses PS/2 events so they cannot override or duplicate USB. */
void keyb_receive_ps2_byte(BYTE key)
{
    if(input_policy_keyboard_event(INPUT_BACKEND_PS2))
        keyb_receive_byte(key);
}

// Keyboard Interrupt Handler
void keyb_handler(void)
{
    BYTE key,status;

    keyb_irq_count++;
    status=inportb(0x64);

    /* IRQ1 identifies the first PS/2 port.  Do not leave an OBF byte stuck
     * merely because status bit 5 is set: on older/single-channel 8042-family
     * implementations that bit has had other meanings, and a stuck OBF can
     * prevent any later keyboard edge from being delivered. */
    if(status&KBD_STAT_OBF)
    {
        key=inportb(0x60);
#ifdef __KBIRQDEBUG__
        incmark();
#endif
        /* BIOS/USB-legacy implementations occasionally signal an AUX byte on
         * IRQ1.  Once the mouse driver is registered, honor the i8042 AUX
         * source bit instead of feeding a mouse packet into the keyboard scan
         * decoder. */
        if(ps2mouse_enabled && (status&KBD_STAT_MOUSE_OBF))
            ps2mouse_receive_byte(key);
        else
        {
            keyb_byte_count++;
            keyb_receive_ps2_byte(key);
        }
    }

    pic_send_eoi(1);
}

// Output string to current terminal's keyboard buffer
int WriteKeyboard(const char *s)
{
	int l,i=0;

	//
	l = strlen(s);
	for(i=0; i<l; i++)
	{
		//
		OutputKeyboard(s[i]);
	}
	return 0;
}

// Output terminal's keyboard buffer
int OutputKeyboard(int ch)
{
	SCREEN *s;

	// Get terminal
	s = &screens[GetThreadTerminal(GetCurrentThread())];

	// Output keyboard
	PushBufferW(&s->key, ch);
	return 0;
}

//
int translate_keyboard_situation(void)
{
	// See removed.txt.
	return 0;
}

//
int keyb_device_call(DEVICE_CALL_PARS)
{
	switch(n_call)
	{
		//
		case DEVICE_CMD_INIT:
		break;
		//
		case DEVICE_CMD_SHUTDOWN:
		break;
		//
		case DEVICE_CMD_READBLOCK:
		break;
		//
		case DEVICE_CMD_WRITEBLOCK:
		break;
		//
		case DEVICE_CMD_GETSIZE:
		break;
		//
		case DEVICE_CMD_GETBLOCKSIZE:
		break;
		//
		case DEVICE_CMD_SEEK:
		break;
		//
		case DEVICE_CMD_GETCH:
		break;
		//
		case DEVICE_CMD_PUTCH:
		break;
		//
		case DEVICE_CMD_TELL:
		break;
		//
		default:
		break;
	}

	//
	return 0;
}

//
int keyb_register_device(void)
{
	//
	if( driver_getdevicebyname("keyb") )	return 1;

	//
	driver_register_new_device( "keyb", keyb_device_call, DEVICE_TYPE_CHAR );

	//
	return 0;
}

//
int kbwaitstatus(DWORD value,DWORD mask)
{
	//
	DWORD i,i2;

	//
	for(i=0; i<PS2MOUSE_TIMEOUT; i++)
	{
		if( (inportb(0x64)&mask)==value )return 0;
		inportb(0x80);
		for(i2=0; i2<10; i2++)nop();
	}

	//
	return 1;
}

//
int kbread(void)
{
	int i,status,d2;

	/* Never consume an AUX byte through the keyboard helper.  This helper is
	 * kept for legacy callers, but the physical 0x60 read is permitted only
	 * when the i8042 status explicitly identifies keyboard output. */
	for(i=0; i<PS2MOUSE_TIMEOUT; i++)
	{
		status=inportb(0x64);
		if(status & KBD_STAT_OBF)
		{
			if(status & KBD_STAT_MOUSE_OBF)
				return -1;
			d2=inportb(0x60);
			return d2;
		}
		inportb(0x80);
	}
	return -1;
}

// non-zero return value is an error
int kbwrite(int value)
{
	//
	static long i,i2,i3,i4,d;
 
	// When using PS/2 mouse we should wait here
	// for kbwaitmousebufferfull, so
	// it should be manually called before using
	// this function when commanding PS/2 mouse.

	//
	kbwait();

	// write the data
	outportb(0x60,value); for(i4=0; i4<10; i4++)inportb(0x80);
 
	//
	kbwait();

	//
	return 0;
}

// non-zero will be an error
int kbcmd(int cmd)
{
	//
	long i;
 
	//
	kbwait();
 
	// cmd_send
	outportb(0x64,cmd);
	for(i=0; i<20; i++)nop();
 
	//
	kbwait();

	//
	return 0;
}

//
void kbwait(void)
{
	long i;

	for( i=glvar.timer[0]; (inportb(0x64) & 2); )
	{
		if( (glvar.timer[0]-i)>200 )
		{
			print("syskeyb.c/kbwait: error, timeout occured\n");
			break;
		}
	}
}

// Waits until readable data is available
void kbwaitdata(void)
{
	//
	long i,i2;

	//
	for( i=glvar.timer[0],i2=0; !(inportb(0x64) & 1); i2++)
	{
		//
		inportb(0x80);
		//
		if(i2>10000)break;
		//
		if( (glvar.timer[0]-i)>200 )
		{
			printk("keyb.c/kbwaitdata: error, timeout occured\n");
			break;
		}
	}
 // 
}

/* Poll one keyboard (not AUX) byte.  The status/read pair is protected so
 * IRQ1 cannot race this thread between the 0x64 and 0x60 accesses. */
static int keyb_poll_byte(int *value)
{
    int flags,status;

    flags=get_eflags();
    disable();
    status=inportb(0x64);
    if(!(status & KBD_STAT_OBF) || (status & KBD_STAT_MOUSE_OBF))
    {
        set_eflags(flags);
        return 0;
    }
    *value=inportb(0x60);
    set_eflags(flags);
    return 1;
}

static int keyb_wait_input_empty(DWORD timeout_ms)
{
    RTC_IO_DEADLINE deadline;
    rtc_io_deadline_start(&deadline,timeout_ms,
        (unsigned int)(timeout_ms/1000UL)+2U,20000000UL);
    while(inportb(0x64) & KBD_STAT_IBF)
    {
        if(rtc_io_deadline_expired(&deadline)) return 1;
        if(Multitasking && !PitStorageSafeActive()) SchedulerWaitPause(100UL);
        else inportb(0x80);
    }
    return 0;
}

/* Return 0=ACK, 2=RESEND, 1=timeout/error.  Any real scancode encountered
 * while waiting is fed back through the normal decoder rather than lost. */
static int keyb_wait_ack(DWORD timeout_ms)
{
    int b;
    RTC_IO_DEADLINE deadline;

    rtc_io_deadline_start(&deadline,timeout_ms,
        (unsigned int)(timeout_ms/1000UL)+2U,20000000UL);
    while(!rtc_io_deadline_expired(&deadline))
    {
        if(keyb_command_response)
        {
            b=keyb_command_response;
            keyb_command_response=0;
            if(b==0xFA) return 0;
            if(b==0xFE) return 2;
        }
        if(keyb_poll_byte(&b))
        {
            if(b==0xFA) return 0;
            if(b==0xFE) return 2;
            keyb_process_scancode((BYTE)b);
        }
        else
            SchedulerWaitPause(100UL);
    }
    return 1;
}

static int keyb_send_ack_byte(BYTE value)
{
    int attempt,r;
    for(attempt=0; attempt<3; attempt++)
    {
        if(keyb_wait_input_empty(100)) return 1;
        keyb_command_response=0;
        outportb(0x60,value);
        r=keyb_wait_ack(150);
        if(r==0) return 0;
        if(r!=2) return 1;
    }
    return 1;
}

// Attempt to set keyboard LEDs from thread context.
void setleds(void)
{
    BYTE wanted;

    /* Native USB keyboard owns the logical keyboard now.  Do not send PS/2
     * LED commands through port 0x60; a future USB transport will implement
     * HID LED output reports separately. */
    if(input_policy_keyboard_backend()==INPUT_BACKEND_USB)
    {
        keyb_led_update_pending=0;
        return;
    }

    wanted=kbstr.led_status &
        (LED_SCROLL_LOCK|LED_NUM_LOCK|LED_CAPS_LOCK);

    if(keyb_led_update_busy)
        return;
    keyb_led_update_busy=1;

    if(!keyb_send_ack_byte(0xED) && !keyb_send_ack_byte(wanted))
        keyb_led_update_pending=0;

    keyb_led_update_busy=0;
}

void keyb_service(void)
{
#if JTMOS_MOD_PCI
    (void)usb_input_poll();
#endif
    if(keyb_led_update_pending && !keyb_led_update_busy)
        setleds();
}

// returns non-zero on error
int kb_hwinit(void)
{
    BYTE oldcb=0,setupcb=0,finalcb=0,status,data;
    int warning=0;
    int have_cb=0;
    int port_test=0;
    int rv;

    kbstr.kb_test_ok=0;

    /* Keep the AUX side quiet until GraOS actually needs the mouse.  This is
     * important for the SMSH rescue path: with only one producer on 0x60 the
     * shell can poll the keyboard even if IRQ1 delivery is broken. */
    if(keyb_i8042_command(I8042_CMD_DISABLE_KBD) && !warning) warning=1;
    (void)keyb_i8042_command(I8042_CMD_DISABLE_AUX);
    keyb_i8042_flush_output();

    rv=keyb_i8042_read_command_byte(&oldcb);
    if(rv==0)
    {
        have_cb=1;
        /* JTMOS currently decodes scan-code set 1.  PC firmware normally
         * leaves an MF2 keyboard in set 2 and uses i8042 translation, so keep
         * that established compatibility mode.  Keep IRQ1 off while the
         * device command below is exchanged. */
        setupcb=(BYTE)(oldcb & ~(I8042_CBYTE_IRQ1|I8042_CBYTE_KBD_DISABLED));
        setupcb|=I8042_CBYTE_TRANSLATION;
        if(keyb_i8042_write_command_byte(setupcb) && !warning) warning=2;
    }
    else if(!warning)
        warning=2;

    /* The interface test is diagnostic only.  A number of compatible
     * controllers/emulations have imperfect test-command behaviour while the
     * actual keyboard data path works. */
    if(!keyb_i8042_command(I8042_CMD_TEST_KBD_PORT) &&
       !keyb_i8042_wait_output_spin(&status,&data,KEYB_I8042_SPIN_LIMIT))
    {
        port_test=(int)data;
        if(port_test!=0)
            printk("Keyboard: i8042 first-port test returned %x (continuing).\n",port_test);
    }

    if(keyb_i8042_command(I8042_CMD_ENABLE_KBD) && !warning) warning=3;

#if KEYB_FORCE_DEVICE_RESET
    /* Hard device reset is intentionally opt-in.  If enabled and it fails,
     * never leave the keyboard dead: F4 and controller IRQ setup below still
     * run. */
    rv=keyb_device_reset();
    if(rv && !warning) warning=4;
#endif

    /* Always attempt Enable Scanning.  This is the critical recovery rule:
     * a missing BAT/ACK or a USB-legacy quirk must never return early with the
     * device left scanning-disabled. */
    rv=keyb_device_command_ack(0xF4);
    if(rv && !warning) warning=5;

    /* Controller IRQ1 setup is also best-effort and is performed even when a
     * device command above warned.  Polling remains available if IRQ routing
     * is absent. */
    if(have_cb)
    {
        finalcb=(BYTE)((setupcb|I8042_CBYTE_IRQ1|I8042_CBYTE_TRANSLATION) &
                       ~I8042_CBYTE_KBD_DISABLED);
        if(keyb_i8042_write_command_byte(finalcb))
        {
            if(!warning) warning=6;
        }
        else
            keyb_controller_byte=finalcb;
    }

    kbstr.kb_test_ok=(warning==0) ? 1 : 0;
    return warning;
}

// getch
//
// I don't know if keyb.c is the best place to store
// this getch() function, but let's think it's a
// inside kernel thing, applications will be not
// accessing it directly, instead via the interface.
//
int getch()
{
	int key;

	//
	while( !(key=getch1()) )
	{
		/* A blocked console reader is not runnable work.  Sleep briefly so an
		 * otherwise idle VM reaches CPU_IDLE/HLT instead of yield-spinning. */
		SchedulerWaitPause(1000UL);
	}
	return key;
}

// Direct input a char from keyboard
int directgetch()
{
	//
	int key;
	int i;
	
	// Buffer already empty?
	if( !kbstr.ai )return 0;

/*	// Check that the data is for us
	if( thread_terminal[GetCurrentThread()]!=visible_terminal )
	{
		return 0;
	}*/

	//
	key=kbstr.abuf[0];
	kbstr.ai--;
	kbstr.i--;
	
	//
	for(i=0; i<KEYBOARD_BUFFER_LENGTH; i++)
	{
		kbstr.buf[i]=kbstr.buf[i+1];
		kbstr.abuf[i]=kbstr.abuf[i+1];
	}

	//
	return key;
}

//
int kbhit()
{
	keyb_service();
	//
	if( !kbstr.ai ) return 0;

	//
	return 1;
}











