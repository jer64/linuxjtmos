#ifndef __JTMOS_KEYMAP_H__
#define __JTMOS_KEYMAP_H__

/* Built-in JTMOS keyboard layouts.  English is intentionally value zero so
 * zero-initialised state and early boot both default to the US layout. */
#define KEYBOARD_LAYOUT_ENGLISH 0
#define KEYBOARD_LAYOUT_FINNISH 1

#define KEYMAP_UNMAPPED (-1)

int KeyboardSetLayout(int layout);
int KeyboardSetLayoutByName(const char *name);
int KeyboardGetLayout(void);
const char *KeyboardGetLayoutName(void);

/* Pure scan-code-set-1 translation helper.  This has no kernel dependencies,
 * which makes the layout tables independently unit-testable on the host. */
int KeyboardTranslateScancode(int layout, int scancode,
                              int shift, int altgr, int capslock);

#endif
