/*** PARTITION TABLE SUPPORT ***
 * partsup.c - (C) 2008 Jari Tuominen.
 * Hardened MBR parsing, bounded partition I/O and live MBR rescan/sync.
 *
 * V67.8.57.10.18.16.25:
 *  - PARTITION records are copied out of the MBR, so a sync can safely free
 *    its temporary sector buffer while hda1..hda4 handlers remain active.
 *  - a small `partsup` control device accepts DEVICE_CMD_SYNC.
 *  - unchanged partition DNRs remain stable across sync; changed geometry
 *    invalidates DAPI cache, deleted entries are removed, new entries register.
 *
 * V68.8.57.10.18.16.52:
 *  - hdaN never calls the legacy IDE low-level routine directly.  Partition I/O
 *    is translated to parent LBAs and forwarded through the registered hda
 *    device, so IDE, AHCI and MCP61 backends share the same serialization and
 *    DMA/bounce-buffer ownership rules as non-partitioned disk I/O.
 *
 * V68.8.57.10.18.16.53:
 *  - partition aliases explicitly accept MOUNT/UNMOUNT.  These operations are
 *    logical no-ops at the block-driver layer: hda1 must not unmount the shared
 *    physical hda backend used by hda2..hda4.
 *
 * V68.8.57.10.18.16.55:
 *  - partition I/O is deliberately chunked to 4 KiB parent requests.  Clustered
 *    JTMFS can issue 32-128 KiB requests, while old MCP61/legacy PIO hardware is
 *    substantially happier with short bounded commands.  Each parent chunk is
 *    retried three times before the partition reports a hard I/O error.
 */
#include "basdef.h"
#include "sysmem.h"
#include "kernel32.h"
#include "hd.h"
#include "driver_sys.h"
#include "driver_api.h"
#include "driver_rw.h"
#include "partsup.h"
#include "../sata/mcp61.h"

static int hda1_device_call(DEVICE_CALL_PARS);
static int hda2_device_call(DEVICE_CALL_PARS);
static int hda3_device_call(DEVICE_CALL_PARS);
static int hda4_device_call(DEVICE_CALL_PARS);
static int partsup_device_call(DEVICE_CALL_PARS);

static PARTITION partitions[4];
static BYTE partition_present[4];
static int partition_dnr[4]={-1,-1,-1,-1};
static int partsup_dnr=-1;
static char *partdevs[]={"hda1","hda2","hda3","hda4"};
static void *handlers[]={hda1_device_call,hda2_device_call,hda3_device_call,hda4_device_call};

#define PARTSUP_PARENT_MAX_SECTORS 8
#define PARTSUP_IO_RETRIES 3

PARTITION *get_partition_table_by_name(char *devname)
{
    int i;
    if(devname==NULL) return NULL;
    for(i=0;i<4;i++)
        if(!strcmp(partdevs[i],devname))
            return partition_present[i] ? &partitions[i] : NULL;
    return NULL;
}

static int partition_transfer(PARTITION *tbl,int first,int count,BYTE *buf,int rw)
{
    DWORD rel,sec,disk_sectors;
    int hda,cmd;

    if(tbl==NULL || buf==NULL || first<0 || count<=0) return 1;
    rel=(DWORD)first;
    if(rel>=tbl->sector_count || (DWORD)count>tbl->sector_count-rel) return 1;
    sec=tbl->begsec+rel;
    if(sec<tbl->begsec) return 1;

    hda=ND("hda");
    if(hda<=0 || !isValidDevice(hda)) return 1;
    disk_sectors=(DWORD)getsize(hda);
    if(disk_sectors==0 || sec>=disk_sectors || (DWORD)count>disk_sectors-sec) return 1;

    /* Do not call hdSectorRW_LBA() here.  hda may be legacy IDE, AHCI or the
     * MCP61 rescue backend.  A nested device_call() is safe because the outer
     * partition device has already released device_call_busy before invoking
     * this handler; the parent hda DEVICE_ENTRY busy flag then serializes the
     * physical backend and protects shared AHCI command/bounce storage. */
    /* Keep the physical request size conservative.  hda1 is commonly a large
     * clustered JTMFS volume (32-64 KiB allocation units), and forwarding a
     * whole cluster as one legacy/MCP61 PIO command made otherwise-correct
     * partition reads much more sensitive to controller timing.  The outer
     * DAPI direct-access lock covers this complete function, so splitting here
     * does not allow another normal block request to interleave the chunks. */
    {
        DWORD done=0,left=(DWORD)count,chunk;
        int try_nr,rv=1;
        while(left) {
            chunk=left>PARTSUP_PARENT_MAX_SECTORS ?
                  PARTSUP_PARENT_MAX_SECTORS : left;
            cmd=(chunk==1)
                ? ((rw==WRITE) ? DEVICE_CMD_WRITEBLOCK : DEVICE_CMD_READBLOCK)
                : ((rw==WRITE) ? DEVICE_CMD_WRITEBLOCKS : DEVICE_CMD_READBLOCKS);
            for(try_nr=0;try_nr<PARTSUP_IO_RETRIES;try_nr++) {
                rv=device_call(hda,cmd,(long)(sec+done),(long)chunk,0,0,
                               buf+done*512UL,NULL);
                if(rv==0) break;
                dprintk("PARTSUP/io: %s parent hda LBA=%u count=%u try=%d rv=%d.\n",
                        rw==WRITE?"WRITE":"READ",(unsigned)(sec+done),
                        (unsigned)chunk,try_nr+1,rv);
                if(Multitasking && !PitStorageSafeActive()) SwitchToThread();
            }
            if(rv!=0) {
                printk("PARTSUP: %s failed parent hda LBA=%u count=%u after %d tries.\n",
                       rw==WRITE?"write":"read",(unsigned)(sec+done),
                       (unsigned)chunk,PARTSUP_IO_RETRIES);
                return 1;
            }
            done+=chunk;
            left-=chunk;
        }
    }
    return 0;
}

static int partition_device_call(PARTITION *tbl, DEVICE_CALL_PARS)
{
    DWORD *size;
    if(tbl==NULL) return 1;
    switch(n_call)
    {
        case DEVICE_CMD_READBLOCK:
            return partition_transfer(tbl,p1,1,(BYTE *)po1,READ);
        case DEVICE_CMD_WRITEBLOCK:
            return partition_transfer(tbl,p1,1,(BYTE *)po1,WRITE);
        case DEVICE_CMD_READBLOCKS:
            return partition_transfer(tbl,p1,p2,(BYTE *)po1,READ);
        case DEVICE_CMD_WRITEBLOCKS:
            return partition_transfer(tbl,p1,p2,(BYTE *)po1,WRITE);
        case DEVICE_CMD_GETSIZE:
            if(po1==NULL) return 1;
            size=(DWORD*)po1; *size=tbl->sector_count; return 0;
        case DEVICE_CMD_GETBLOCKSIZE:
            if(po1==NULL) return 1;
            size=(DWORD*)po1; *size=512; return 0;
        case DEVICE_CMD_MOUNT:
        case DEVICE_CMD_UNMOUNT:
            /* A partition is a logical view of the always-mounted parent hda.
             * Never forward UNMOUNT to hda: that would disable sibling
             * partitions as well.  Filesystem cache lifetime is handled by
             * driver_mountDNR()/driver_unmountDNR() for this partition DNR. */
            return 0;
        case DEVICE_CMD_FLUSH:
        {
            int hda=ND("hda");
            if(hda<=0 || !isValidDevice(hda)) return 1;
            return device_call(hda,DEVICE_CMD_FLUSH,0,0,0,0,NULL,NULL);
        }
        default:
            return 1;
    }
}

static int hda1_device_call(DEVICE_CALL_PARS){ return partition_device_call(partition_present[0]?&partitions[0]:NULL,n_call,p1,p2,p3,p4,po1,po2); }
static int hda2_device_call(DEVICE_CALL_PARS){ return partition_device_call(partition_present[1]?&partitions[1]:NULL,n_call,p1,p2,p3,p4,po1,po2); }
static int hda3_device_call(DEVICE_CALL_PARS){ return partition_device_call(partition_present[2]?&partitions[2]:NULL,n_call,p1,p2,p3,p4,po1,po2); }
static int hda4_device_call(DEVICE_CALL_PARS){ return partition_device_call(partition_present[3]?&partitions[3]:NULL,n_call,p1,p2,p3,p4,po1,po2); }

static int valid_partition(const PARTITION *t,DWORD disk_sectors,int slot)
{
    DWORD end;
    if(t->system_indicator==0 || t->sector_count==0) return 0;
    if(t->boot_indicator!=0 && t->boot_indicator!=0x80) {
        printk("partsup: ignoring hda%d: invalid boot flag 0x%x.\n",slot+1,t->boot_indicator);
        return 0;
    }
    end=t->begsec+t->sector_count;
    if(t->begsec==0 || end<t->begsec || end>disk_sectors) {
        printk("partsup: ignoring hda%d: partition range %u+%u exceeds disk %u.\n",
               slot+1,t->begsec,t->sector_count,disk_sectors);
        return 0;
    }
    return 1;
}

static int same_partition(const PARTITION *a,const PARTITION *b)
{
    return a->boot_indicator==b->boot_indicator &&
           a->system_indicator==b->system_indicator &&
           a->begsec==b->begsec && a->sector_count==b->sector_count;
}

/* Read the MBR and reconcile partsup's hda1..hda4 devices with it.
 * This is PROCESS CONTEXT ONLY.  Callers must not repartition a mounted/live
 * filesystem; the control application prints that warning explicitly. */
int partition_table_support_sync(void)
{
    int i,dnr,bs,registered=0,valid_mbr=0,old_dnr,rc;
    DWORD disk_sectors;
    BYTE *mbr;
    PARTITION next[4];
    BYTE next_present[4];
    char str[32];

    memset(next,0,sizeof(next));
    memset(next_present,0,sizeof(next_present));
    dnr=ND("hda");
    if(dnr<=0) return 1;
    bs=getblocksize(dnr);
    if(bs!=512) {
        printk("partsup: refusing MBR scan: hda logical block size is %d, expected 512.\n",bs);
        return 1;
    }
    disk_sectors=(DWORD)getsize(dnr);
    if(disk_sectors==0) return 1;

    /* Transactional ordering for live partition-table sync:
     *  1) drain every OLD partition cache while old geometry is authoritative;
     *  2) drain hda DAPI (including a newly written MBR) and hardware cache;
     *  3) invalidate hda cache and perform an uncached LBA0 readback;
     *  4) only then publish new hda1..hda4 geometry. */
    for(i=0;i<4;i++) {
        old_dnr=partition_dnr[i];
        if(old_dnr<0) old_dnr=ND(partdevs[i]);
        if(partition_present[i] && old_dnr>0 && isValidDevice(old_dnr)) {
            rc=driver_FlushDrive(old_dnr);
            if(rc!=0) {
                printk("partsup: sync refused: pre-MBR flush failed for %s (%d).\n",
                       partdevs[i],rc);
                return 3;
            }
        }
    }
    if(driver_FlushDrive(dnr)!=0) return 2;
    driver_block_cache_invalidate(dnr);

    mbr=malloc(bs);
    if(mbr==NULL) { printk("partsup: out of memory reading MBR.\n"); return 1; }
    if(readblock1(dnr,0,mbr)!=0) {
        printk("partsup: unable to read hda MBR.\n");
        free(mbr); return 1;
    }
    if(mbr[0x1FE]==0x55 && mbr[0x1FF]==0xAA) valid_mbr=1;
    if(valid_mbr) {
        for(i=0;i<4;i++) {
            memcpy(&next[i],mbr+446+(0x10*i),sizeof(PARTITION));
            if(valid_partition(&next[i],disk_sectors,i)) next_present[i]=1;
        }
    } else {
        printk("partsup: no valid MBR signature; no hdaN partition devices registered.\n");
    }
    free(mbr);

    dprintk("PARTSUP/sync: disk=%u sectors valid-mbr=%d.\n",disk_sectors,valid_mbr);
    for(i=0;i<4;i++) {
        old_dnr=partition_dnr[i];
        if(old_dnr<0) old_dnr=ND(partdevs[i]);

        if(partition_present[i] && old_dnr>0 &&
           (!next_present[i] || !same_partition(&partitions[i],&next[i])))
            driver_block_cache_invalidate(old_dnr);

        if(!next_present[i]) {
            if(old_dnr>0 && isValidDevice(old_dnr)) {
                driver_block_cache_invalidate(old_dnr);
                driver_removedevice(old_dnr);
                dprintk("PARTSUP/sync: removed %s DNR=%d.\n",partdevs[i],old_dnr);
            }
            partition_present[i]=0;
            partition_dnr[i]=-1;
            memset(&partitions[i],0,sizeof(PARTITION));
            continue;
        }

        partitions[i]=next[i];
        partition_present[i]=1;
        if(old_dnr>0 && isValidDevice(old_dnr)) {
            partition_dnr[i]=old_dnr;
            driver_block_cache_invalidate(old_dnr);
            /* A partition has its own DAPI cache namespace.  When hda is the
             * MCP61 rescue backend, disabling write-back only on the parent is
             * not enough: hda1 could still buffer writes here and later flush
             * a burst into the fragile PIO backend. */
            if(mcp61_sata_hda_active())
                driver_disableDAPIWriteBackCache(old_dnr);
        } else {
            sprintf(str,"hda%d",i+1);
            partition_dnr[i]=driver_register_new_device(str,handlers[i],
                                  DEVICE_TYPE_BLOCK|DEVICE_TYPE_MULTIBLOCK);
            if(partition_dnr[i]<0) {
                printk("partsup: failed to register %s.\n",str);
                partition_present[i]=0;
                partition_dnr[i]=-1;
                continue;
            }
            if(mcp61_sata_hda_active()) {
                driver_disableDAPIWriteBackCache(partition_dnr[i]);
                printk("PARTSUP: %s MCP61 safe-write policy: DAPI write-back disabled.\n",str);
            }
        }
        registered++;
        printk("%s: beginning=%u, %u sectors, system_indicator=%x%s\n",
               partdevs[i],partitions[i].begsec,partitions[i].sector_count,
               partitions[i].system_indicator,
               partitions[i].boot_indicator==0x80?" active":"");
    }
    dprintk("PARTSUP/sync: complete, %d partition device(s) active.\n",registered);
    return valid_mbr ? 0 : 4;
}

static int partsup_device_call(DEVICE_CALL_PARS)
{
    DWORD *out;
    int i,count=0,rv;
    (void)p1; (void)p2; (void)p3; (void)p4; (void)po2;
    switch(n_call) {
        case DEVICE_CMD_SYNC:
            rv=partition_table_support_sync();
            if(po1!=NULL) {
                for(i=0;i<4;i++) if(partition_present[i]) count++;
                out=(DWORD*)po1; *out=(DWORD)count;
            }
            return rv;
        case DEVICE_CMD_GETSIZE:
            if(po1==NULL) return 1;
            for(i=0;i<4;i++) if(partition_present[i]) count++;
            out=(DWORD*)po1; *out=(DWORD)count; return 0;
        case DEVICE_CMD_FLUSH:
            return 0;
        default:
            return 1;
    }
}

int partition_table_support_init(void)
{
    int rv;
    if(ND("hda")<=0) {
        printk("partsup: partition table support requires hda (not detected).\n");
        return 1;
    }
    if(partsup_dnr<0 || !isValidDevice(partsup_dnr)) {
        partsup_dnr=driver_register_new_device("partsup",partsup_device_call,DEVICE_TYPE_CHAR);
        if(partsup_dnr<0) {
            printk("partsup: unable to register control device.\n");
            return 1;
        }
        printk("partsup: control device registered; DEVICE_CMD_SYNC enabled.\n");
    }
    rv=partition_table_support_sync();
    /* A blank/non-MBR disk is not a fatal init error: partsup remains online so
     * partition.bin can create a table and ask us to sync it immediately. */
    return rv==4 ? 0 : rv;
}
