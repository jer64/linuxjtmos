#ifndef __INCLUDED_PARTSUP_H__
#define __INCLUDED_PARTSUP_H__

typedef struct
{
    BYTE boot_indicator;
    BYTE beg_chs1;
    BYTE beg_chs2;
    BYTE beg_chs3;
    BYTE system_indicator;
    BYTE end_chs1;
    BYTE end_chs2;
    BYTE end_chs3;
    DWORD begsec;
    DWORD sector_count;
} __attribute__((packed)) PARTITION;

int partition_table_support_init(void);
int partition_table_support_sync(void);
PARTITION *get_partition_table_by_name(char *devname);

#endif
