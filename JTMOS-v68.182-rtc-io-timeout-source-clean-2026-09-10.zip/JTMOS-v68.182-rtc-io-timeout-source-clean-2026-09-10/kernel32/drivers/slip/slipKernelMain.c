//-------------------------------------------------------------------------------
// Slip protocol driver 1.0 - kernel version main program.
// (C) 2005 by Jari Tuominen. Runtime lifecycle update 2026.
//-------------------------------------------------------------------------------
#include <stdio.h>
#include "slip.h"
#include "serial.h"
#include "slipLogin.h"
#include "slipKernelMain.h"
#include "slipStack.h"
#include "networkControl.h"

int SlipProcess(void)
{
    int rv;
    int dnr;
    int claimed = 0;

    if(getdevicenrbyname(SLIP_DEV_NAME) > 0)
    {
        printf("SLIP: device driver is already installed.\n");
        JtInternetThreadExited(0);
        ExitThread(1);
    }

    printf("SLIP protocol driver version 1.2 (RFC1055)\n");
    slipReadConfiguration();

    /* SLIP owns its UART exclusively. If the selected line is the debug UART,
     * an explicit internet start takes precedence and stops debug writes. */
    if(serial_debug_line==slip.port)
    {
        serial_console_redirect=0;
        serial_debug_line=-1;
        (void)serial_release_port(slip.port,SERIAL_OWNER_DEBUG);
        printf("SLIP: disabled debug UART on COM%d; line is now exclusive to SLIP.\n",
            slip.port+1);
    }

    if(serial_claim_port(slip.port,SERIAL_OWNER_SLIP))
    {
        printf("SLIP: COM%d is already owned by %s.\n",
            slip.port+1,serial_owner_name(serial_get_owner(slip.port)));
        JtInternetThreadExited(0);
        ExitThread(1);
    }
    claimed = 1;

    if(SetSerialPortSpeedOwned(slip.port,slip.bps,SERIAL_OWNER_SLIP))
    {
        printf("SLIP: unable to configure COM%d.\n",slip.port+1);
        goto fail;
    }

    rv = slipLogin("");
    if(rv)
        goto fail;

    slipOnline = TRUE;
    slipStack();

    slipOnline = FALSE;
    slipStackReady = 0;
    dnr = getdevicenrbyname(SLIP_DEV_NAME);
    if(dnr > 0)
        (void)driver_removedevice(dnr);
    if(claimed)
        (void)serial_release_port(slip.port,SERIAL_OWNER_SLIP);
    JtInternetThreadExited(0);
    ExitThread(0);
    return 0;

fail:
    slipOnline = FALSE;
    slipStackReady = 0;
    if(claimed)
        (void)serial_release_port(slip.port,SERIAL_OWNER_SLIP);
    JtInternetThreadExited(0);
    ExitThread(1);
    return 1;
}
