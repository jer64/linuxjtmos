/*===========================================================
        SLIP DIAL-UP ROUTINES - AUTOLOGIN FUNCTIONS
        SLIP LOGIN PROGRAM FOR JTMOS
   (C) 2002-2007 by Jari Tuominen(jari@vunet.org).
   COM2/direct-SLIP recovery update 2026.
  ===========================================================*/
#include <stdio.h>
#include "slipLogin.h"
#include "slip.h"
#include "serial.h"

SLIP slip;

static void slip_send_string(const char *s)
{
    while(s && *s)
        slip_send_char((BYTE)*s++);
}

static void slip_flush_input(DWORD quiet_ms)
{
    DWORD last;
    int ch;

    last = GetTickCount();
    while((DWORD)(GetTickCount()-last) < quiet_ms)
    {
        ch = serial_get_owned(slip.port,SERIAL_OWNER_SLIP);
        if(ch!=-1)
        {
            last = GetTickCount();
            continue;
        }
        SwitchToThread();
    }
}

static void slip_sync_raw_link(void)
{
    /* RFC1055 recommends END before a frame to flush line noise.  A few
     * empty END frames also give a raw SLIP server an unambiguous boundary. */
    slip_send_char(END);
    slip_send_char(END);
    slip_send_char(END);
}

static int slip_legacy_login(int manual)
{
    static char loginStr[50], passwdStr[50];
    static char str[512];

    printf("SLIP: legacy login prompt detected.\n");

    if(manual)
    {
        printf("Login: ");
        gets(loginStr);
        strcat(loginStr,"\n");
    }
    else
        sprintf(loginStr, "%s\n", user);
    slip_send_string(loginStr);

    if(WaitSerialStringTimeoutOwned(slip.port, "Password:", 5000, SERIAL_OWNER_SLIP))
    {
        printf("SLIP: password prompt timed out.\n");
        return 1;
    }

    if(manual)
    {
        printf("Password: ");
        gets(passwdStr);
        strcat(passwdStr,"\n");
    }
    else
        sprintf(passwdStr, "%s\n", passwd);
    slip_send_string(passwdStr);

    /* Old JTMOS expected a SLiRP banner.  Keep supporting it, but do not
     * reject other SLIP servers merely because they use a different banner. */
    if(!WaitSerialStringTimeoutOwned(slip.port, "Your address is ", 4000, SERIAL_OWNER_SLIP))
    {
        slip_gets(str, sizeof(str));
        if(str[0]) printk("SLIP peer assigned IP: %s\n", str);
        (void)WaitSerialStringTimeoutOwned(slip.port, "SLiRP Ready ...", 3000, SERIAL_OWNER_SLIP);
    }
    else
    {
        printf("SLIP: no SLiRP address banner; switching to raw SLIP mode.\n");
    }

    return 0;
}

/*
 * Establish the serial side of a SLIP link.
 *
 * A raw SLIP transport has no TCP-like connection handshake.  Therefore
 * AUTO mode first gives historical login/SLiRP servers a chance to present
 * "login:".  If no prompt appears, JTMOS synchronizes RFC1055 framing and
 * considers the serial link ready for IP packets.
 */
int slipLogin(const char *opt)
{
    int manual;

    slipOnline = 0;
    manual = (opt!=NULL && strcmp(opt,"")!=0);

    printf("SLIP link setup version 1.1\n");
    printf("SLIP: COM%d I/O=%x IRQ%d, %d bps, 8N1.\n",
        slip.port+1, serialport[slip.port].ad,
        serialport[slip.port].irq, slip.bps);

    /* Remove bytes left from boot/debug probing without blocking forever. */
    slip_flush_input(100);

    /* A login server usually emits its prompt immediately. */
    if(!WaitSerialStringTimeoutOwned(slip.port, "login:", 1200, SERIAL_OWNER_SLIP))
    {
        if(slip_legacy_login(manual))
            return 1;
    }
    else
    {
        /* One CR wakes traditional tty/sliplogin setups.  If it still does
         * not produce a login prompt, treat the peer as a raw SLIP server. */
        slip_send_char('\r');
        slip_send_char('\n');
        if(!WaitSerialStringTimeoutOwned(slip.port, "login:", 1200, SERIAL_OWNER_SLIP))
        {
            if(slip_legacy_login(manual))
                return 1;
        }
        else
        {
            printf("SLIP: no login prompt; using direct RFC1055 server mode.\n");
        }
    }

    slip_flush_input(50);
    slip_sync_raw_link();
    slipOnline = 1;

    printf("SLIP: serial link ready on COM%d.\n", slip.port+1);
    return 0;
}
