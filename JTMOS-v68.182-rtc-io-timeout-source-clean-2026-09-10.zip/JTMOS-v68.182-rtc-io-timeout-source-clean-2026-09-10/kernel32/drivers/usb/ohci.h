#ifndef __JTMOS_USB_OHCI_H__
#define __JTMOS_USB_OHCI_H__

int usb_ohci_init(void);
int usb_ohci_poll(void);
void usb_ohci_dump(void);
int usb_ohci_is_ready(void);

#endif
