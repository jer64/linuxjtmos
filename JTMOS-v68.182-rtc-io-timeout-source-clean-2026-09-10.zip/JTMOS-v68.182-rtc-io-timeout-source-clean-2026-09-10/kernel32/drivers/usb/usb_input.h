#ifndef __JTMOS_USB_INPUT_H__
#define __JTMOS_USB_INPUT_H__

#include "basdef.h"

typedef struct
{
    int initialized;
    int controller_count;
    int uhci_count;
    int ohci_count;
    int ehci_count;
    int xhci_count;
    int other_hc_count;
    int keyboard_dnr;
    int mouse_dnr;
    int transport_ready;
    DWORD keyboard_reports;
    DWORD mouse_reports;
    DWORD keyboard_events;
    DWORD mouse_events;
} USBINPUTSTATE;

extern USBINPUTSTATE usb_input;

/* Transport-independent USB HID input layer.  V67.8.57.10.18.16.16 adds a
 * minimal OHCI lower half for root-port boot keyboard/mouse devices; other HCI
 * types can feed the same decoded boot-protocol report functions later. */
void usb_input_init(void);
void usb_input_dump(void);
void usb_input_set_transport_ready(int ready);
int usb_input_transport_init(void);
int usb_input_poll(void);
int usb_hid_boot_keyboard_report(const BYTE *report,int len);
int usb_hid_boot_mouse_report(const BYTE *report,int len);

#endif
