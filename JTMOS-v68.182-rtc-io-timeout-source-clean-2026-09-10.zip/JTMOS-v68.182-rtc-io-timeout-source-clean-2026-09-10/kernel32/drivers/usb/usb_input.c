/*
 * JTMOS preliminary USB keyboard/mouse input layer.
 *
 * This file is the transport-independent HID upper half.  V67.8.57.10.18.16.16
 * adds a minimal OHCI lower half in drivers/usb/ohci.c for MCP61/root-port boot
 * keyboard and mouse devices; future UHCI/EHCI/xHCI transports can feed the
 * same report entry points.
 *
 * Keyboard reports are translated to scan-code-set-1 and then injected into
 * the existing JTMOS keyboard state machine.  Mouse reports update the generic
 * MOUSE object already consumed by GraOS.  Therefore Ctrl+Alt+Del, AltGr,
 * terminal input, mouse_union and GraOS all share the same input semantics
 * regardless of whether the lower transport is PS/2 or USB.
 */
#include "kernel32.h"
#include "driver_sys.h"
#include "driver_api.h"
#include "pci.h"
#include "keyb.h"
#include "mouse.h"
#include "input_policy.h"
#include "usb_input.h"
#include "ohci.h"

#define USB_PCI_CLASS_SERIAL       0x0c
#define USB_PCI_SUBCLASS_USB       0x03
#define USB_PROGIF_UHCI            0x00
#define USB_PROGIF_OHCI            0x10
#define USB_PROGIF_EHCI            0x20
#define USB_PROGIF_XHCI            0x30

#define USB_HID_BOOT_KBD_LEN       8
#define USB_HID_BOOT_MOUSE_MIN     3

USBINPUTSTATE usb_input;

static BYTE usb_kbd_prev_modifiers;
static BYTE usb_kbd_prev_keys[6];

static int usbmouse_device_call(DEVICE_CALL_PARS)
{
    (void)n_call;
    return 0;
}

/* DEVDB follows the logical single-mouse policy.  A placeholder USB mouse is
 * not installed during PCI discovery.  It appears only after the first real
 * HID mouse report, at which point the inactive PS/2 device entry is removed. */
static void usb_activate_mouse_device(void)
{
    int dnr;
    dnr=driver_getdevicenrbyname("ps2mouse");
    if(dnr>=0) (void)driver_removedevice(dnr);
    dnr=driver_getdevicenrbyname("usbmouse");
    if(dnr<0)
        dnr=driver_register_new_device("usbmouse",usbmouse_device_call,DEVICE_TYPE_CHAR);
    usb_input.mouse_dnr=dnr;
}

static int usb_key_in_report(const BYTE *keys,BYTE usage)
{
    int i;
    if(!usage) return 0;
    for(i=0;i<6;i++) if(keys[i]==usage) return 1;
    return 0;
}

/* Convert USB HID Keyboard/Keypad usage IDs to PS/2 scan-code-set-1.  Bit 8
 * marks an E0-prefixed scan code.  Zero means unsupported/no event. */
static WORD usb_hid_usage_to_set1(BYTE u)
{
    static const BYTE alpha[26]={
        0x1e,0x30,0x2e,0x20,0x12,0x21,0x22,0x23,0x17,0x24,0x25,0x26,0x32,
        0x31,0x18,0x19,0x10,0x13,0x1f,0x14,0x16,0x2f,0x11,0x2d,0x15,0x2c
    };
    static const BYTE digits[10]={0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b};

    if(u>=0x04 && u<=0x1d) return alpha[u-0x04];
    if(u>=0x1e && u<=0x27) return digits[u-0x1e];

    switch(u)
    {
        case 0x28: return 0x1c;       /* Enter */
        case 0x29: return 0x01;       /* Escape */
        case 0x2a: return 0x0e;       /* Backspace */
        case 0x2b: return 0x0f;       /* Tab */
        case 0x2c: return 0x39;       /* Space */
        case 0x2d: return 0x0c;       /* - */
        case 0x2e: return 0x0d;       /* = */
        case 0x2f: return 0x1a;       /* [ */
        case 0x30: return 0x1b;       /* ] */
        case 0x31: return 0x2b;       /* backslash */
        case 0x32: return 0x2b;       /* Non-US #/~, closest Set-1 key */
        case 0x33: return 0x27;       /* ; */
        case 0x34: return 0x28;       /* ' */
        case 0x35: return 0x29;       /* ` */
        case 0x36: return 0x33;       /* , */
        case 0x37: return 0x34;       /* . */
        case 0x38: return 0x35;       /* / */
        case 0x39: return 0x3a;       /* Caps Lock */

        case 0x3a: return 0x3b; case 0x3b: return 0x3c;
        case 0x3c: return 0x3d; case 0x3d: return 0x3e;
        case 0x3e: return 0x3f; case 0x3f: return 0x40;
        case 0x40: return 0x41; case 0x41: return 0x42;
        case 0x42: return 0x43; case 0x43: return 0x44;
        case 0x44: return 0x57; case 0x45: return 0x58;

        case 0x46: return 0x0100|0x37;/* Print Screen (simplified) */
        case 0x47: return 0x46;       /* Scroll Lock */
        case 0x49: return 0x0100|0x52;/* Insert */
        case 0x4a: return 0x0100|0x47;/* Home */
        case 0x4b: return 0x0100|0x49;/* Page Up */
        case 0x4c: return 0x0100|0x53;/* Delete */
        case 0x4d: return 0x0100|0x4f;/* End */
        case 0x4e: return 0x0100|0x51;/* Page Down */
        case 0x4f: return 0x0100|0x4d;/* Right */
        case 0x50: return 0x0100|0x4b;/* Left */
        case 0x51: return 0x0100|0x50;/* Down */
        case 0x52: return 0x0100|0x48;/* Up */
        case 0x53: return 0x45;       /* Num Lock */
        case 0x54: return 0x0100|0x35;/* Keypad / */
        case 0x55: return 0x37;       /* Keypad * */
        case 0x56: return 0x4a;       /* Keypad - */
        case 0x57: return 0x4e;       /* Keypad + */
        case 0x58: return 0x0100|0x1c;/* Keypad Enter */
        case 0x59: return 0x4f; case 0x5a: return 0x50;
        case 0x5b: return 0x51; case 0x5c: return 0x4b;
        case 0x5d: return 0x4c; case 0x5e: return 0x4d;
        case 0x5f: return 0x47; case 0x60: return 0x48;
        case 0x61: return 0x49; case 0x62: return 0x52;
        case 0x63: return 0x53;       /* Keypad . / Del */
        case 0x64: return 0x56;       /* ISO extra key */
        default: return 0;
    }
}

static WORD usb_modifier_to_set1(int bit)
{
    switch(bit)
    {
        case 0: return 0x1d;          /* Left Ctrl */
        case 1: return 0x2a;          /* Left Shift */
        case 2: return 0x38;          /* Left Alt */
        case 3: return 0x0100|0x5b;   /* Left GUI */
        case 4: return 0x0100|0x1d;   /* Right Ctrl */
        case 5: return 0x36;          /* Right Shift */
        case 6: return 0x0100|0x38;   /* Right Alt / AltGr */
        case 7: return 0x0100|0x5c;   /* Right GUI */
    }
    return 0;
}

static void usb_emit_set1(WORD code,int is_break)
{
    BYTE sc=(BYTE)(code&0xff);
    if(!sc) return;
    if(code&0x0100) keyb_receive_byte(0xe0);
    if(is_break) sc|=0x80;
    keyb_receive_byte(sc);
    usb_input.keyboard_events++;
}

int usb_hid_boot_keyboard_report(const BYTE *report,int len)
{
    BYTE mods;
    const BYTE *keys;
    int i;
    WORD sc;

    if(!report || len<USB_HID_BOOT_KBD_LEN) return 1;
    /* A real HID report is the point where USB becomes the active keyboard.
     * PCI controller discovery alone must never disable the PS/2/BIOS fallback. */
    if(!input_policy_keyboard_event(INPUT_BACKEND_USB)) return 3;
    if(usb_input.keyboard_dnr<0)
    {
        usb_input.keyboard_dnr=driver_getdevicenrbyname("usbkbd");
        if(usb_input.keyboard_dnr<0)
            usb_input.keyboard_dnr=driver_getdevicenrbyname("keyb");
    }
    mods=report[0];
    keys=report+2;
    usb_input.keyboard_reports++;

    /* 0x01..0x03 are HID ErrorRollOver/POSTFail/ErrorUndefined. */
    for(i=0;i<6;i++)
        if(keys[i]>=1 && keys[i]<=3) return 2;

    for(i=0;i<8;i++)
    {
        BYTE mask=(BYTE)(1U<<i);
        if((usb_kbd_prev_modifiers&mask) && !(mods&mask))
            usb_emit_set1(usb_modifier_to_set1(i),1);
    }
    for(i=0;i<6;i++)
    {
        BYTE u=usb_kbd_prev_keys[i];
        if(u && !usb_key_in_report(keys,u))
        {
            sc=usb_hid_usage_to_set1(u);
            if(sc) usb_emit_set1(sc,1);
        }
    }

    for(i=0;i<8;i++)
    {
        BYTE mask=(BYTE)(1U<<i);
        if((mods&mask) && !(usb_kbd_prev_modifiers&mask))
            usb_emit_set1(usb_modifier_to_set1(i),0);
    }
    for(i=0;i<6;i++)
    {
        BYTE u=keys[i];
        if(u && !usb_key_in_report(usb_kbd_prev_keys,u))
        {
            sc=usb_hid_usage_to_set1(u);
            if(sc) usb_emit_set1(sc,0);
        }
    }

    usb_kbd_prev_modifiers=mods;
    memcpy(usb_kbd_prev_keys,keys,6);
    return 0;
}

int usb_hid_boot_mouse_report(const BYTE *report,int len)
{
    int dx,dy;
    if(!report || len<USB_HID_BOOT_MOUSE_MIN) return 1;
    /* First genuine USB mouse report promotes the logical mouse to USB. */
    if(!input_policy_mouse_event(INPUT_BACKEND_USB)) return 2;
    if(usb_input.mouse_dnr<0) usb_activate_mouse_device();

    usb_input.mouse_reports++;
    dx=(int)(signed char)report[1];
    dy=(int)(signed char)report[2];

    mouse.buttons=(int)(report[0]&0x1f);
    mouse.mx=(char)dx;
    mouse.my=(char)dy;
    mouse.lx=mouse.x;
    mouse.ly=mouse.y;
    mouse.x+=dx;
    mouse.y+=dy; /* USB HID Y is positive down, matching GraOS coordinates. */

    if(mouse.x<mouse.frame.x1) mouse.x=mouse.frame.x1;
    if(mouse.x>mouse.frame.x2) mouse.x=mouse.frame.x2;
    if(mouse.y<mouse.frame.y1) mouse.y=mouse.frame.y1;
    if(mouse.y>mouse.frame.y2) mouse.y=mouse.frame.y2;

    if(dx || dy || report[0]) usb_input.mouse_events++;
    return 0;
}

void usb_input_set_transport_ready(int ready)
{
    usb_input.transport_ready=ready ? 1 : 0;
}

void usb_input_init(void)
{
    int i;
    const PCIDEVICE *d;

    if(usb_input.initialized) return;
    memset(&usb_input,0,sizeof(usb_input));
    memset(usb_kbd_prev_keys,0,sizeof(usb_kbd_prev_keys));
    usb_kbd_prev_modifiers=0;
    usb_input.keyboard_dnr=-1;
    usb_input.mouse_dnr=-1;

    pci_init();
    for(i=0;i<pci_get_device_count();i++)
    {
        d=pci_get_device(i);
        if(!d) continue;
        if(d->class_code!=USB_PCI_CLASS_SERIAL || d->subclass!=USB_PCI_SUBCLASS_USB)
            continue;
        usb_input.controller_count++;
        printk("USB PCI: %d:%d.%d %04x:%04x prog-if=%02x irq=%d.\n",
               d->bus,d->device,d->function,d->vendor_id,d->device_id,d->prog_if,d->irq_line);
        switch(d->prog_if)
        {
            case USB_PROGIF_UHCI: usb_input.uhci_count++; break;
            case USB_PROGIF_OHCI: usb_input.ohci_count++; break;
            case USB_PROGIF_EHCI: usb_input.ehci_count++; break;
            case USB_PROGIF_XHCI: usb_input.xhci_count++; break;
            default: usb_input.other_hc_count++; break;
        }
    }

    /* Do not register fake usbkbd:/usbmouse: devices here.  This layer has no
     * USB transport yet, and the system policy exposes only one logical
     * keyboard and one logical mouse.  A future host-controller driver feeds
     * reports directly into the generic keyb/mouse input objects. */
    usb_input.initialized=1;

    printk("USB input scaffold: %d host controller(s): UHCI=%d OHCI=%d EHCI=%d xHCI=%d other=%d.\n",
           usb_input.controller_count,usb_input.uhci_count,usb_input.ohci_count,
           usb_input.ehci_count,usb_input.xhci_count,usb_input.other_hc_count);
    if(usb_input.controller_count>0)
        printk("USB input scaffold: HID sinks ready; USB is preferred but claims input only after a real report.\n");
    else
        printk("USB input scaffold: no PCI USB host controller detected.\n");
}

int usb_input_transport_init(void)
{
    int rv=1;
    if(!usb_input.initialized) usb_input_init();
    if(usb_input.ohci_count>0)
    {
        rv=usb_ohci_init();
        if(rv==0) usb_input.transport_ready=1;
    }
    return rv;
}

int usb_input_poll(void)
{
    if(!usb_input.transport_ready) return 0;
    if(usb_ohci_is_ready()) return usb_ohci_poll();
    return 0;
}

void usb_input_dump(void)
{
    printk("USB input: controllers=%d UHCI=%d OHCI=%d EHCI=%d xHCI=%d other=%d\n",
           usb_input.controller_count,usb_input.uhci_count,usb_input.ohci_count,
           usb_input.ehci_count,usb_input.xhci_count,usb_input.other_hc_count);
    printk("USB input: transport=%s logical-device policy=single keyboard + single mouse\n",
           usb_input.transport_ready ? "ready" : "not implemented");
    printk("USB input: keyboard reports=%lu events=%lu; mouse reports=%lu events=%lu\n",
           (unsigned long)usb_input.keyboard_reports,(unsigned long)usb_input.keyboard_events,
           (unsigned long)usb_input.mouse_reports,(unsigned long)usb_input.mouse_events);
    input_policy_dump();
    usb_ohci_dump();
}
