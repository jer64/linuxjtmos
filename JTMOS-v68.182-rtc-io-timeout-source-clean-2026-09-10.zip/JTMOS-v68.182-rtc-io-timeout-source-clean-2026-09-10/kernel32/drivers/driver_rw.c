// =============================================================
// JTMOS DEVAPI block I/O
// V67.8.53: true readblocks/writeblocks + generic read/write-back cache.
// (C) 2002-2026 by Jari Tuominen.
// =============================================================
#include "basdef.h"
#include "sysmem.h"
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
#include "driver_api.h"
#include "driver_sys.h"
#include "driver_lock.h"
#include "driver_rw.h"
#include "kyber.h"
#include "scheduler.h"

/* Bigfoot V1: 256 resident 512-byte hda blocks allow a stream of legacy
 * one-sector writes to collapse into one 128 KiB DEVICE_CMD_WRITEBLOCKS
 * request.  Logical block size is unchanged; only the transfer footprint
 * grows.  Non-contiguous/random traffic still uses ordinary cache entries. */
#define DAPI_CACHE_ENTRIES            256
#define DAPI_CACHE_MAX_BLOCKSIZE      4096
#define DAPI_CACHE_READ_FILL_BLOCKS     16
#define DAPI_CACHE_DIRECT_BLOCKS        32
#define DAPI_CACHE_LOCK_NR               1

typedef struct {
    int valid;
    int dirty;
    int dnr;
    long block_nr;
    int block_size;
    int allocated;
    BYTE *data;
    DWORD age;
} DAPI_CACHE_ENTRY;

static DAPI_CACHE_ENTRY dapi_cache[DAPI_CACHE_ENTRIES];
static DWORD dapi_cache_clock=1;
static int dapi_dirty_owner=-1;
static BYTE *dapi_io_buffer=NULL;
static int dapi_io_buffer_size=0;
static DWORD dapi_cache_hits=0,dapi_cache_misses=0;
static DWORD dapi_cache_write_hits=0,dapi_cache_flush_blocks=0;
static DWORD dapi_cache_flush_runs=0,dapi_cache_max_flush_run=0;
static DWORD dapi_debug_direct_reads=0,dapi_debug_direct_writes=0;
static DWORD dapi_debug_flush_calls=0;

static int block_range_valid(int dnr,long block_nr,int count)
{
    int size;
    if(!isValidDevice(dnr) || block_nr<0 || count<=0) {
        dprintk("DAPI/range: reject dnr=%d block=%d count=%d (invalid device/negative/zero).\n",
                dnr,(int)block_nr,count);
        return 0;
    }
    size=getsize(dnr);
    if(size<=0 || block_nr>=(long)size) {
        dprintk("DAPI/range: reject dnr=%d block=%d count=%d size=%d.\n",
                dnr,(int)block_nr,count,size);
        return 0;
    }
    if((long)count>(long)size-block_nr) {
        dprintk("DAPI/range: reject tail dnr=%d block=%d count=%d size=%d remaining=%d.\n",
                dnr,(int)block_nr,count,size,(int)((long)size-block_nr));
        return 0;
    }
    return 1;
}

static void cache_touch(DAPI_CACHE_ENTRY *e)
{
    if(++dapi_cache_clock==0) dapi_cache_clock=1;
    e->age=dapi_cache_clock;
}

static DAPI_CACHE_ENTRY *cache_find_locked(int dnr,long block_nr)
{
    int i;
    for(i=0;i<DAPI_CACHE_ENTRIES;i++)
        if(dapi_cache[i].valid && dapi_cache[i].dnr==dnr &&
           dapi_cache[i].block_nr==block_nr)
            return &dapi_cache[i];
    return NULL;
}

static int cache_has_dirty_locked(int dnr)
{
    int i;
    for(i=0;i<DAPI_CACHE_ENTRIES;i++)
        if(dapi_cache[i].valid && dapi_cache[i].dirty &&
           (dnr<0 || dapi_cache[i].dnr==dnr)) return 1;
    return 0;
}

static void cache_refresh_dirty_owner_locked(void)
{
    int i;
    dapi_dirty_owner=-1;
    for(i=0;i<DAPI_CACHE_ENTRIES;i++)
        if(dapi_cache[i].valid && dapi_cache[i].dirty) {
            dapi_dirty_owner=dapi_cache[i].dnr;
            return;
        }
}

static int cache_ensure_io_locked(int bytes)
{
    BYTE *p;
    if(bytes<=0) return 0;
    if(dapi_io_buffer!=NULL && dapi_io_buffer_size>=bytes) return 1;
    p=(BYTE *)malloc((size_t)bytes);
    if(p==NULL) return 0;
    if(dapi_io_buffer) free(dapi_io_buffer);
    dapi_io_buffer=p;
    dapi_io_buffer_size=bytes;
    return 1;
}

/* Called with DAPI_CACHE_LOCK_NR held.  This intentionally uses the uncached
 * direct backend so flushing cannot recursively re-enter the cache. */
static int cache_flush_device_locked(int dnr)
{
    int i,j,bs,run,bytes,transferred,owner;
    long first,next;
    DAPI_CACHE_ENTRY *e;

    while(cache_has_dirty_locked(dnr)) {
        /* dnr < 0 means every device.  Keep the wildcard separate from the
         * selected owner; the old code overwrote dnr with the first owner and
         * silently stopped after flushing only that one device. */
        owner=dnr;
        if(owner<0) {
            owner=-1;
            for(i=0;i<DAPI_CACHE_ENTRIES;i++)
                if(dapi_cache[i].valid && dapi_cache[i].dirty) {
                    owner=dapi_cache[i].dnr;
                    break;
                }
            if(owner<0) break;
        }

        first=-1; bs=0;
        for(i=0;i<DAPI_CACHE_ENTRIES;i++) {
            e=&dapi_cache[i];
            if(!e->valid || !e->dirty || e->dnr!=owner) continue;
            if(first<0 || e->block_nr<first) {
                first=e->block_nr; bs=e->block_size;
            }
        }
        if(first<0) continue;

        /* Sequential workloads naturally form contiguous runs.  Gather the
         * longest resident run and issue one physical multi-block command. */
        run=1;
        while(run<DAPI_CACHE_ENTRIES) {
            next=first+run;
            e=cache_find_locked(owner,next);
            if(e==NULL || !e->dirty || e->block_size!=bs) break;
            run++;
        }
        bytes=run*bs;
        if(run>1 && cache_ensure_io_locked(bytes)) {
            for(j=0;j<run;j++) {
                e=cache_find_locked(owner,first+j);
                memcpy(dapi_io_buffer+j*bs,e->data,(size_t)bs);
            }
            if(run>=8 && (dapi_cache_flush_runs<8 || (dapi_cache_flush_runs&0xffUL)==0))
                dprintk("DAPI/flush-run: owner=%d first=%d run=%d bs=%d bytes=%d dirty-owner=%d.\n",
                        owner,(int)first,run,bs,bytes,dapi_dirty_owner);
            transferred=writeblocks1(owner,first,dapi_io_buffer,run);
            if(transferred!=run) {
                dprintk("DAPI/flush-run: FAILED owner=%d first=%d requested=%d transferred=%d.\n",
                        owner,(int)first,run,transferred);
                return 1;
            }
            for(j=0;j<run;j++) {
                e=cache_find_locked(owner,first+j);
                if(e) { e->dirty=0; cache_touch(e); }
            }
            dapi_cache_flush_blocks+=(DWORD)run;
        } else {
            e=cache_find_locked(owner,first);
            if(e==NULL || writeblocks1(owner,first,e->data,1)!=1) return 1;
            e->dirty=0; cache_touch(e);
            dapi_cache_flush_blocks++;
            run=1;
        }
        dapi_cache_flush_runs++;
        if((DWORD)run>dapi_cache_max_flush_run) dapi_cache_max_flush_run=(DWORD)run;
    }
    cache_refresh_dirty_owner_locked();
    return 0;
}

static void cache_drop_device_locked(int dnr)
{
    int i;
    for(i=0;i<DAPI_CACHE_ENTRIES;i++) {
        if(!dapi_cache[i].valid) continue;
        if(dnr<0 || dapi_cache[i].dnr==dnr) {
            dapi_cache[i].valid=0;
            dapi_cache[i].dirty=0;
        }
    }
    cache_refresh_dirty_owner_locked();
}

static void cache_drop_other_devices_locked(int dnr)
{
    int i;
    for(i=0;i<DAPI_CACHE_ENTRIES;i++)
        if(dapi_cache[i].valid && dapi_cache[i].dnr!=dnr && !dapi_cache[i].dirty)
            dapi_cache[i].valid=0;
}

static void cache_drop_range_locked(int dnr,long first,int count)
{
    int i;
    long end=first+(long)count;
    for(i=0;i<DAPI_CACHE_ENTRIES;i++)
        if(dapi_cache[i].valid && dapi_cache[i].dnr==dnr &&
           dapi_cache[i].block_nr>=first && dapi_cache[i].block_nr<end) {
            dapi_cache[i].valid=0;
            dapi_cache[i].dirty=0;
        }
    cache_refresh_dirty_owner_locked();
}

static DAPI_CACHE_ENTRY *cache_victim_locked(int dnr)
{
    int i,best=-1;
    DWORD oldest=0xffffffffUL;

    for(i=0;i<DAPI_CACHE_ENTRIES;i++)
        if(!dapi_cache[i].valid) return &dapi_cache[i];

    /* Prefer evicting clean data. */
    for(i=0;i<DAPI_CACHE_ENTRIES;i++)
        if(!dapi_cache[i].dirty && dapi_cache[i].age<=oldest) {
            oldest=dapi_cache[i].age; best=i;
        }
    if(best>=0) return &dapi_cache[best];

    /* All entries are dirty: write the current stream as large contiguous
     * requests, then retry the now-clean LRU search. */
    if(cache_flush_device_locked(dnr)!=0) return NULL;
    oldest=0xffffffffUL; best=-1;
    for(i=0;i<DAPI_CACHE_ENTRIES;i++)
        if(!dapi_cache[i].dirty && dapi_cache[i].age<=oldest) {
            oldest=dapi_cache[i].age; best=i;
        }
    return best>=0 ? &dapi_cache[best] : NULL;
}

static DAPI_CACHE_ENTRY *cache_store_locked(int dnr,long block_nr,int bs,
                                             const BYTE *src,int dirty)
{
    DAPI_CACHE_ENTRY *e;
    BYTE *p;
    e=cache_find_locked(dnr,block_nr);
    if(e==NULL) e=cache_victim_locked(dnr);
    if(e==NULL) return NULL;
    if(e->data==NULL || e->allocated<bs) {
        p=(BYTE *)malloc((size_t)bs);
        if(p==NULL) return NULL;
        if(e->data) free(e->data);
        e->data=p; e->allocated=bs;
    }
    memcpy(e->data,src,(size_t)bs);
    e->valid=1; e->dirty=dirty; e->dnr=dnr;
    e->block_nr=block_nr; e->block_size=bs;
    cache_touch(e);
    if(dirty) dapi_dirty_owner=dnr;
    return e;
}

static int cache_prepare_read_locked(int dnr)
{
    /* Logical devices may alias one physical disk (hda/hda1/etc).  Never let
     * dirty data for one DNR remain hidden when another DNR is read. */
    if(dapi_dirty_owner>=0 && dapi_dirty_owner!=dnr)
        return cache_flush_device_locked(dapi_dirty_owner);
    return 0;
}

static int cache_prepare_write_locked(int dnr)
{
    if(dapi_dirty_owner>=0 && dapi_dirty_owner!=dnr)
        if(cache_flush_device_locked(dapi_dirty_owner)!=0) return 1;
    /* We cannot in general map partition aliases back to physical LBAs here,
     * so invalidate clean entries belonging to other logical devices. */
    cache_drop_other_devices_locked(dnr);
    return 0;
}

int driver_block_cache_flush(int dnr)
{
    int r;
    DWORD seq=++dapi_debug_flush_calls;
    if(seq<=8 || (seq&0xffUL)==0)
        dprintk("DAPI/cache-flush #%u begin dnr=%d dirty-owner=%d.\n",
                (unsigned)seq,dnr,dapi_dirty_owner);
    driver_lockOn(DAPI_CACHE_LOCK_NR);
    r=cache_flush_device_locked(dnr);
    driver_lockOff(DAPI_CACHE_LOCK_NR);
    if(r || seq<=8 || (seq&0xffUL)==0)
        dprintk("DAPI/cache-flush #%u end dnr=%d rv=%d flushed=%u runs=%u max-run=%u.\n",
                (unsigned)seq,dnr,r,(unsigned)dapi_cache_flush_blocks,
                (unsigned)dapi_cache_flush_runs,(unsigned)dapi_cache_max_flush_run);
    return r;
}

void driver_block_cache_invalidate(int dnr)
{
    driver_lockOn(DAPI_CACHE_LOCK_NR);
    cache_drop_device_locked(dnr);
    driver_lockOff(DAPI_CACHE_LOCK_NR);
}

void driver_block_cache_stats(void)
{
    printk("DAPI cache: hits=%u misses=%u write-hits=%u flushed=%u blocks runs=%u max-run=%u dirty-owner=%d\n",
           (unsigned)dapi_cache_hits,(unsigned)dapi_cache_misses,
           (unsigned)dapi_cache_write_hits,(unsigned)dapi_cache_flush_blocks,
           (unsigned)dapi_cache_flush_runs,(unsigned)dapi_cache_max_flush_run,
           dapi_dirty_owner);
}

/* ------------------------------------------------------------------ */
/* Direct uncached backend.  One lock covers the whole multi-block command. */
int readblocks1(long dnr,long block_nr,BYTE *buf,int count)
{
    DEVICE_ENTRY *de;
    int i,r,done=0,bs;
    if(buf==NULL || !block_range_valid((int)dnr,block_nr,count)) return 0;
    de=driver_getdevice((int)dnr);
    if(de==NULL) return 0;
    bs=getblocksize((int)dnr);
    if(bs<=0) return 0;
    dapi_debug_direct_reads++;
    if(count>=8 && (dapi_debug_direct_reads<=8 || (dapi_debug_direct_reads&0x3ffUL)==0))
        dprintk("DAPI/direct-read #%u dnr=%d LBA=%d count=%d bytes=%u.\n",
                (unsigned)dapi_debug_direct_reads,(int)dnr,(int)block_nr,count,
                (unsigned)((DWORD)count*(DWORD)bs));

    driver_directAccessLockOn();
    HDLED(1);
    if(de->type & DEVICE_TYPE_MULTIBLOCK) {
        r=device_call(dnr,DEVICE_CMD_READBLOCKS,block_nr,count,0,0,buf,NULL);
        done=(r==0)?count:0;
    } else {
        for(i=0;i<count;i++) {
            r=device_call(dnr,DEVICE_CMD_READBLOCK,block_nr+i,0,0,0,
                          buf+(i*bs),NULL);
            if(r!=0) break;
            done++;
            /* Slow single-block backends (floppy/legacy devices) must not
             * monopolize a kernel task for an entire large request. */
            if((done&7)==0) SchedulerCooperate();
        }
    }
    HDLED(0);
    driver_directAccessLockOff();
    return done;
}

int writeblocks1(long dnr,long block_nr,BYTE *buf,int count)
{
    DEVICE_ENTRY *de;
    int i,r,done=0,bs;
    if(buf==NULL || !block_range_valid((int)dnr,block_nr,count)) return 0;
    de=driver_getdevice((int)dnr);
    if(de==NULL || (de->type & DEVICE_TYPE_READONLY)) return 0;
    bs=getblocksize((int)dnr);
    if(bs<=0) return 0;
    dapi_debug_direct_writes++;
    if(count>=8 && (dapi_debug_direct_writes<=8 || (dapi_debug_direct_writes&0x3ffUL)==0))
        dprintk("DAPI/direct-write #%u dnr=%d LBA=%d count=%d bytes=%u.\n",
                (unsigned)dapi_debug_direct_writes,(int)dnr,(int)block_nr,count,
                (unsigned)((DWORD)count*(DWORD)bs));

    driver_directAccessLockOn();
    HDLED(2);
    if(de->type & DEVICE_TYPE_MULTIBLOCK) {
        r=device_call(dnr,DEVICE_CMD_WRITEBLOCKS,block_nr,count,0,0,buf,NULL);
        done=(r==0)?count:0;
    } else {
        for(i=0;i<count;i++) {
            r=device_call(dnr,DEVICE_CMD_WRITEBLOCK,block_nr+i,0,0,0,
                          buf+(i*bs),NULL);
            if(r!=0) break;
            done++;
            if((done&7)==0) SchedulerCooperate();
        }
    }
    HDLED(0);
    driver_directAccessLockOff();
    return done;
}

int readblock1(long dnr,long block_nr,BYTE *buf)
{
    return readblocks1(dnr,block_nr,buf,1)==1 ? 0 : 1;
}

int writeblock1(long dnr,long block_nr,BYTE *buf)
{
    return writeblocks1(dnr,block_nr,buf,1)==1 ? 0 : 1;
}

static int physical_readblocks(int dnr,long block_nr,BYTE *buf,int count)
{
    if(kyber_should_schedule(dnr))
        return kyber_submit_sync_blocks(dnr,JTMOS_KYBER_READ,block_nr,buf,count)==0 ? count : 0;
    return readblocks1(dnr,block_nr,buf,count);
}

static int physical_writeblocks(int dnr,long block_nr,BYTE *buf,int count)
{
    if(kyber_should_schedule(dnr))
        return kyber_submit_sync_blocks(dnr,JTMOS_KYBER_WRITE,block_nr,buf,count)==0 ? count : 0;
    return writeblocks1(dnr,block_nr,buf,count);
}

/* ------------------------------------------------------------------ */
static void dapi_reward_io_progress(int blocks)
{
    if(blocks>0 && Multitasking) {
        SchedulerRewardIO(GetCurrentThread(),blocks);
        /* readblocks()/writeblocks() call this after releasing the DAPI cache
         * lock.  A sizeable completed transfer is therefore an ideal safe
         * cooperative boundary. */
        if(blocks>=8) SchedulerCooperate();
    }
}

int readblocks(long dnr,long block_nr,BYTE *buf,int count)
{
    DEVICE_ENTRY *de;
    int bs,i,j,run,got,use_read_cache,use_write_cache;
    DAPI_CACHE_ENTRY *e;

    if(buf==NULL || !block_range_valid((int)dnr,block_nr,count)) return 0;
    de=driver_getdevice((int)dnr);
    if(de==NULL) return 0;
    bs=getblocksize((int)dnr);
    if(bs<=0) return 0;
    use_read_cache=de->DAPIReadCache && bs<=DAPI_CACHE_MAX_BLOCKSIZE;
    use_write_cache=de->DAPIWriteBackCache && bs<=DAPI_CACHE_MAX_BLOCKSIZE;

    driver_lockOn(DAPI_CACHE_LOCK_NR);
    if(cache_prepare_read_locked((int)dnr)!=0) {
        driver_lockOff(DAPI_CACHE_LOCK_NR); return 0;
    }

    /* Large streaming reads should remain one real device request rather than
     * polluting a 64-entry random-access cache.  Flush dirty blocks first. */
    if(count>DAPI_CACHE_READ_FILL_BLOCKS) {
        if(cache_has_dirty_locked((int)dnr) && cache_flush_device_locked((int)dnr)!=0) {
            driver_lockOff(DAPI_CACHE_LOCK_NR); return 0;
        }
        got=physical_readblocks((int)dnr,block_nr,buf,count);
        driver_lockOff(DAPI_CACHE_LOCK_NR);
        dapi_reward_io_progress(got);
        return got;
    }

    i=0;
    while(i<count) {
        e=cache_find_locked((int)dnr,block_nr+i);
        if(e && (e->dirty || use_read_cache) && e->block_size==bs) {
            memcpy(buf+i*bs,e->data,(size_t)bs);
            cache_touch(e); dapi_cache_hits++; i++; continue;
        }
        dapi_cache_misses++;

        /* Coalesce consecutive misses into one hardware request. */
        run=1;
        while(i+run<count) {
            e=cache_find_locked((int)dnr,block_nr+i+run);
            if(e && (e->dirty || use_read_cache) && e->block_size==bs) break;
            run++;
        }
        got=physical_readblocks((int)dnr,block_nr+i,buf+i*bs,run);
        if(got!=run) {
            driver_lockOff(DAPI_CACHE_LOCK_NR);
            dapi_reward_io_progress(i+got);
            return i+got;
        }
        if(use_read_cache) {
            for(j=0;j<run;j++)
                (void)cache_store_locked((int)dnr,block_nr+i+j,bs,
                                         buf+(i+j)*bs,0);
        }
        i+=run;
    }
    driver_lockOff(DAPI_CACHE_LOCK_NR);
    dapi_reward_io_progress(count);
    return count;
}

int writeblocks(long dnr,long block_nr,BYTE *buf,int count)
{
    DEVICE_ENTRY *de;
    int bs,i,written,use_write_cache;
    DAPI_CACHE_ENTRY *e;

    if(buf==NULL || !block_range_valid((int)dnr,block_nr,count)) return 0;
    de=driver_getdevice((int)dnr);
    if(de==NULL || (de->type & DEVICE_TYPE_READONLY)) return 0;
    bs=getblocksize((int)dnr);
    if(bs<=0) return 0;
    use_write_cache=de->DAPIWriteBackCache && bs<=DAPI_CACHE_MAX_BLOCKSIZE;

    driver_lockOn(DAPI_CACHE_LOCK_NR);
    if(cache_prepare_write_locked((int)dnr)!=0) {
        driver_lockOff(DAPI_CACHE_LOCK_NR); return 0;
    }

    /* Large writes are already optimal as one READ/WRITE MULTIPLE-style
     * request.  Do not copy hundreds of blocks into a small write-back cache. */
    if(!use_write_cache || count>=DAPI_CACHE_DIRECT_BLOCKS) {
        if(cache_has_dirty_locked((int)dnr) && cache_flush_device_locked((int)dnr)!=0) {
            driver_lockOff(DAPI_CACHE_LOCK_NR); return 0;
        }
        cache_drop_range_locked((int)dnr,block_nr,count);
        written=physical_writeblocks((int)dnr,block_nr,buf,count);
        driver_lockOff(DAPI_CACHE_LOCK_NR);
        dapi_reward_io_progress(written);
        return written;
    }

    for(i=0;i<count;i++) {
        e=cache_find_locked((int)dnr,block_nr+i);
        if(e) dapi_cache_write_hits++;
        e=cache_store_locked((int)dnr,block_nr+i,bs,buf+i*bs,1);
        if(e==NULL) {
            /* Low-memory fallback: commit what we have and issue one direct
             * transfer for the caller's complete request. */
            if(cache_flush_device_locked((int)dnr)!=0) {
                driver_lockOff(DAPI_CACHE_LOCK_NR); return i;
            }
            cache_drop_range_locked((int)dnr,block_nr,count);
            written=physical_writeblocks((int)dnr,block_nr,buf,count);
            driver_lockOff(DAPI_CACHE_LOCK_NR);
            dapi_reward_io_progress(written);
            return written;
        }
    }
    driver_lockOff(DAPI_CACHE_LOCK_NR);
    dapi_reward_io_progress(count);
    return count;
}

int readblock(int dnr,int b,BYTE *buf)
{
    if(!isValidDevice(dnr)) return 1;
    if(b<0 || b>=getsize(dnr)) return 2;
    return readblocks(dnr,b,buf,1)==1 ? 0 : 1;
}

int writeblock(int dnr,int b,BYTE *buf)
{
    DEVICE_ENTRY *de;
    if(!isValidDevice(dnr)) return 1;
    de=driver_getdevice(dnr);
    if(de && (de->type & DEVICE_TYPE_READONLY)) return 3;
    if(b<0 || b>=getsize(dnr)) return 2;
    return writeblocks(dnr,b,buf,1)==1 ? 0 : 1;
}

int _readblock(int dnr,int b,BYTE *buf) { return readblock1(dnr,b,buf); }
int _writeblock(int dnr,int b,BYTE *buf) { return writeblock1(dnr,b,buf); }
int readblockCached(long dnr,long block_nr,BYTE *buf) { return readblock((int)dnr,(int)block_nr,buf); }
int writeblockCached(long dnr,long block_nr,BYTE *buf) { return writeblock((int)dnr,(int)block_nr,buf); }

void HDLED(int c)
{
#ifdef ENABLE_driver_HDLED
    char *p;
    int i,col;
    p=(char *)0xb8000;
    i=(80+79)*2;
    if(c==1) col=0x22;
    else if(c==2) col=0x44;
    else col=0;
    p[i+1]=(char)col;
#else
    (void)c;
#endif
}
