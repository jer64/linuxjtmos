#ifndef __JTMOS_AHCI_H__
#define __JTMOS_AHCI_H__

/* Probe a PCI AHCI controller and, when a SATA disk is found, register it as
 * the canonical JTMOS block device hda:.  Returns 1 on success, 0 when no
 * usable AHCI disk exists and -1 when an AHCI controller was found but could
 * not be brought online. */
int ahci_init_hda(void);
int ahci_hda_active(void);

#endif
