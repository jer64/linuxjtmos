#ifndef __JTMOS_MCP61_SATA_H__
#define __JTMOS_MCP61_SATA_H__

/* NVIDIA MCP61 (GeForce 6150SE/nForce 430) exposes SATA in PCI IDE/native
 * mode on common eMachines systems instead of class-code AHCI.  This backend
 * probes those native task-file BARs and registers the first usable SATA ATA
 * disk as hda:. */
int mcp61_sata_init_hda(void);
int mcp61_sata_hda_active(void);

#endif
