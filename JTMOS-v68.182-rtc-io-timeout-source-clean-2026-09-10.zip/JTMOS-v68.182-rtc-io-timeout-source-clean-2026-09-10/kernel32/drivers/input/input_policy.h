#ifndef __JTMOS_INPUT_POLICY_H__
#define __JTMOS_INPUT_POLICY_H__

#define INPUT_BACKEND_NONE 0
#define INPUT_BACKEND_PS2  1
#define INPUT_BACKEND_USB  2

/* One logical keyboard and one logical mouse are active at a time.
 * USB has priority over PS/2, but USB claims a class only after a real HID
 * report is received.  This keeps BIOS/PS2 legacy input usable until a native
 * USB transport actually produces data. */
void input_policy_init(void);
int input_policy_keyboard_event(int backend);
int input_policy_mouse_event(int backend);
void input_policy_release_keyboard(int backend);
void input_policy_release_mouse(int backend);
int input_policy_keyboard_backend(void);
int input_policy_mouse_backend(void);
const char *input_policy_backend_name(int backend);
void input_policy_dump(void);

#endif
