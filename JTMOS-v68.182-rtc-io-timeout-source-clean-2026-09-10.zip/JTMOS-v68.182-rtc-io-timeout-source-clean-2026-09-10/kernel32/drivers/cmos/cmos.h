#ifndef __INCLUDED_CMOS_H__
#define __INCLUDED_CMOS_H__

#include "kernel32.h"
#include "driver_sys.h"
#include "cmos_dev.h"

int cmos_read(int addr);
void cmos_write(int addr,int value);
BYTE cmos_batterycheck(void);
void cmos_sleepmilliseconds(DWORD milliseconds);
void cmos_init(void);

#endif
