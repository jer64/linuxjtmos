/****************************************************************
 *                                                              *
 * cmos.c - CMOS driver                                         *
 * (C)2002-2026 by Jari Tuominen                                *
 *                                                              *
 ****************************************************************/
#include "cmos.h"
#include "cmos_dev.h"
#include "basdef.h"
#include "rtc.h"

#define CMOS_INDEX_PORT      0x70
#define CMOS_DATA_PORT       0x71
#define CMOS_STATUS_A        0x0a
#define CMOS_STATUS_C        0x0c
#define CMOS_STATUS_D        0x0d
#define CMOS_PF              0x40
#define CMOS_RATE_1024HZ     0x06

static volatile int cmos_sleep_busy=0;

static int cmos_sleep_trylock(void)
{
    DWORD flags;
    int got_lock=0;

    flags=get_eflags();
    disable();
    if(!cmos_sleep_busy)
    {
        cmos_sleep_busy=1;
        got_lock=1;
    }
    set_eflags(flags);
    return got_lock;
}

static void cmos_sleep_unlock(void)
{
    DWORD flags;

    flags=get_eflags();
    disable();
    cmos_sleep_busy=0;
    set_eflags(flags);
}

/*
 * Port 0x70 is shared by the CMOS register selector and the NMI-mask bit.
 * JTMOS outportb() uses the normal outportb(port,value) argument order.
 * Keep each selector/data transaction interrupt-atomic so another kernel
 * thread/IRQ cannot change the selected register between the two accesses.
 */
int cmos_read(int addr)
{
    DWORD flags;
    int value;

    flags=get_eflags();
    disable();
    outportb(CMOS_INDEX_PORT,addr&0x7f);
    value=inportb(CMOS_DATA_PORT);
    set_eflags(flags);
    return value;
}

void cmos_write(int addr,int value)
{
    DWORD flags;

    flags=get_eflags();
    disable();
    outportb(CMOS_INDEX_PORT,addr&0x7f);
    outportb(CMOS_DATA_PORT,value&0xff);
    set_eflags(flags);
}

BYTE cmos_batterycheck(void)
{
    return (cmos_read(CMOS_STATUS_D)&0x80) ? TRUE : FALSE;
}

/*
 * Yield-friendly millisecond sleep using the MC146818-compatible RTC periodic
 * flag.  Rate-select 6 is 1024 Hz, i.e. one PF event every 0.9765625 ms.
 *
 * The function intentionally does not enable RTC IRQ8/PIE.  Status-C's PF bit
 * is polled directly through ports 70h/71h, and reading Status C clears the
 * latched flag.  The original Status-A rate is restored before returning.
 *
 * This is a scheduler-friendly delay, not a hard realtime timer: PF is a
 * latched bit rather than a counter, so a thread that is not scheduled for
 * several RTC periods may wake somewhat late.  It will never intentionally
 * return early.  Callers that need deadline/timeout semantics should continue
 * to use the kernel monotonic tick clock.
 */
void cmos_sleepmilliseconds(DWORD milliseconds)
{
    DWORD flags;
    DWORD seconds_part;
    DWORD remainder;
    DWORD ticks;
    DWORD seen;
    DWORD guard_start;
    DWORD guard_ms;
    int old_a;
    int yield_ok;

    if(!milliseconds)
        return;

    /*
     * Serialize users of Status C.  Reading Status C consumes PF, so two
     * simultaneous polling sleepers would steal ticks from each other.
     * Single-CPU JTMOS can protect this small software lock with CLI.
     */
    for(;;)
    {
        if(cmos_sleep_trylock())
        {
            old_a=cmos_read(CMOS_STATUS_A);
            cmos_write(CMOS_STATUS_A,(old_a&0xf0)|CMOS_RATE_1024HZ);

            /* Clear a stale periodic flag before starting the measurement. */
            (void)cmos_read(CMOS_STATUS_C);

            /* ceil(milliseconds * 1024 / 1000), without 64-bit arithmetic. */
            seconds_part=milliseconds/1000UL;
            remainder=milliseconds%1000UL;
            if(seconds_part > (0xffffffffUL/1024UL))
                ticks=0xffffffffUL;
            else
            {
                ticks=seconds_part*1024UL;
                ticks+=(remainder*1024UL+999UL)/1000UL;
                if(!ticks) ticks=1;
            }

            seen=0;
            guard_start=GetTickCount();
            guard_ms=milliseconds+2000UL;
            if(guard_ms<milliseconds) guard_ms=0xffffffffUL;

            flags=get_eflags();
            yield_ok=(Multitasking && !PitStorageSafeActive() && (flags&0x200)) ? 1 : 0;

            while(seen<ticks)
            {
                if(cmos_read(CMOS_STATUS_C)&CMOS_PF)
                    seen++;

                /* Broken/non-PC CMOS must not wedge the kernel forever. */
                if((DWORD)(GetTickCount()-guard_start)>=guard_ms)
                    break;

                if(yield_ok)
                    SchedulerWaitPause(1000UL);
            }

            cmos_write(CMOS_STATUS_A,old_a);

            cmos_sleep_unlock();
            return;
        }

        flags=get_eflags();
        if(Multitasking && !PitStorageSafeActive() && (flags&0x200))
            SchedulerWaitPause(1000UL);
    }
}

void cmos_init(void)
{
    dprintk("cmos battery state: ");
    if(cmos_batterycheck()==TRUE)
        dprintk("CMOS RAM has power, good\n");
    else
        dprintk("CMOS RAM has lost power\n");

    cmos_register_device();
}
