#ifndef __INCLUDED_RTC_H__
#define __INCLUDED_RTC_H__

//
#include "kernel32.h"
#include "cmos.h" // TIME -structure

// Date/Time structure
typedef struct
{
        int second,minute,hour,
                day,month,year;
        int res[10];
}DATE;

// ??
typedef struct
{
	int offs;
	int a1,a2,a3,a4;
}RTCSTR;

/*
 * Coarse hardware deadline based directly on the PC/AT CMOS seconds
 * register.  This intentionally counts *second transitions* instead of
 * converting the RTC to milliseconds: storage lock recovery must keep
 * working while the normal scheduler/tick based timing path is suspect.
 *
 * rtc_second_deadline_poll() performs a fresh CMOS port probe on every call.
 */
typedef struct
{
	int last_raw_second;
	unsigned int transitions;
} RTC_SECOND_DEADLINE;

/*
 * Unified I/O wait deadline.  Hardware polling must not depend on only one
 * timing source: early boot can have PIT IRQ0 masked/disabled, while a broken
 * RTC must not create a new infinite wait.  The deadline therefore combines
 * the normal millisecond clock, direct CMOS second transitions and a finite
 * poll budget.
 */
typedef struct
{
	DWORD pit_start;
	DWORD pit_timeout_ms;
	RTC_SECOND_DEADLINE rtc;
	unsigned int rtc_timeout_seconds;
	unsigned long polls;
	unsigned long poll_limit;
} RTC_IO_DEADLINE;

// Function prototypes
int rtc_init(void);
void rtc_getdate(DATE *d);
void rtc_busyWait(void);
int rtc_getseconds(void);
int GetSeconds(void);
void rtc_second_deadline_start(RTC_SECOND_DEADLINE *deadline);
int rtc_second_deadline_poll(RTC_SECOND_DEADLINE *deadline,
                             unsigned int transition_limit);
void rtc_io_deadline_start(RTC_IO_DEADLINE *deadline, DWORD timeout_ms,
                           unsigned int rtc_timeout_seconds,
                           unsigned long poll_limit);
int rtc_io_deadline_expired(RTC_IO_DEADLINE *deadline);

//
extern RTCSTR rtcstr;

// From Linux 1.0:
#ifndef BCD_TO_BIN
#define BCD_TO_BIN(val) ((val)=((val)&15) + ((val)>>4)*10)
#endif

#ifndef BIN_TO_BCD
#define BIN_TO_BCD(val) ((val)=(((val)/10)<<4) + (val)%10)
#endif

#endif
