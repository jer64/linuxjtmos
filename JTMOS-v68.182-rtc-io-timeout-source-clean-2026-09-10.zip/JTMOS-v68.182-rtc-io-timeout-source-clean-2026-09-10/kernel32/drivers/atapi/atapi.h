#ifndef __INCLUDED_JTMOS_ATAPI_H__
#define __INCLUDED_JTMOS_ATAPI_H__

/*
 * JTMOS ATAPI/IDE CD-ROM block driver.
 * Read-only, PIO/polling, 2048-byte logical blocks.
 */

#define ATAPI_MAX_DEVICES       4
#define ATAPI_CD_BLOCK_SIZE  2048

int atapi_init(void);

#endif
