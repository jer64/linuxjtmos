/*
 * atapi.c - ATA/IDE ATAPI CD-ROM block driver for JTMOS
 *
 * Read-only PIO implementation.  It deliberately uses polling instead of
 * IRQs so it can coexist with the historical JTMOS ATA driver without
 * changing the IRQ14/IRQ15 ownership model.
 *
 * Device ABI:
 *   cdrom:, cdrom1:, ...
 *   DEVICE_CMD_READBLOCK  -> one native 2048-byte CD logical block
 *   DEVICE_CMD_GETSIZE    -> number of 2048-byte logical blocks
 *   DEVICE_CMD_GETBLOCKSIZE -> 2048
 *   DEVICE_CMD_WRITEBLOCK -> rejected (read-only)
 */
#include "kernel32.h"
#include "driver_sys.h"
#include "driver_api.h"
#include <jtmos/dcpacket.h>
#include "atapi.h"
#include "scheduler.h"

#define ATA_REG_DATA        0
#define ATA_REG_ERROR       1
#define ATA_REG_FEATURES    1
#define ATA_REG_SECCOUNT    2
#define ATA_REG_LBA_LOW     3
#define ATA_REG_LBA_MID     4
#define ATA_REG_LBA_HIGH    5
#define ATA_REG_DRIVE       6
#define ATA_REG_STATUS      7
#define ATA_REG_COMMAND     7

#define ATA_SR_BSY       0x80
#define ATA_SR_DRDY      0x40
#define ATA_SR_DF        0x20
#define ATA_SR_DRQ       0x08
#define ATA_SR_ERR       0x01

#define ATA_CMD_IDENTIFY_PACKET 0xA1
#define ATA_CMD_PACKET          0xA0

#define SCSI_CMD_REQUEST_SENSE  0x03
#define SCSI_CMD_READ_CAPACITY  0x25
#define SCSI_CMD_READ_10        0x28

#define ATAPI_TIMEOUT_MS        5000UL
#define ATAPI_IDENTIFY_MS       3000UL
#define ATAPI_MAX_PHASE_BYTES  65536UL
#define ATAPI_MAX_READ_BLOCKS   31U /* 31*2048=63488 fits ATAPI byte-count window */
#define ATAPI_READ_RETRIES       3U  /* fresh-media UNIT ATTENTION / NOT READY */

#define ATAPI_OK                 0
#define ATAPI_ERR_ARGUMENT       1
#define ATAPI_ERR_TIMEOUT        2
#define ATAPI_ERR_NO_DEVICE      3
#define ATAPI_ERR_PROTOCOL       4
#define ATAPI_ERR_DEVICE         5
#define ATAPI_ERR_NO_MEDIA       6
#define ATAPI_ERR_RANGE          7
#define ATAPI_ERR_READ_ONLY      8

#define ATAPI_PERIPH_CDROM       5

typedef struct
{
    int present;
    int mounted;
    int media_ready;
    int channel;
    int drive;
    WORD io;
    WORD ctrl;
    int packet_size;
    DWORD block_size;
    DWORD block_count;
    int dnr;
    char model[48];
    BYTE last_sense_key;
    BYTE last_asc;
    BYTE last_ascq;
} ATAPI_DEVICE;

static ATAPI_DEVICE atapi_dev[ATAPI_MAX_DEVICES];
static int atapi_present_count=0;

static BYTE atapi_inb(ATAPI_DEVICE *d, int reg)
{
    return (BYTE)inportb((WORD)(d->io+reg));
}

static void atapi_outb(ATAPI_DEVICE *d, int reg, BYTE value)
{
    outportb((WORD)(d->io+reg),value);
}

static WORD atapi_inw(ATAPI_DEVICE *d)
{
    return inportw(d->io+ATA_REG_DATA);
}

static void atapi_outw(ATAPI_DEVICE *d, WORD value)
{
    outportw(d->io+ATA_REG_DATA,value);
}

static void atapi_400ns(ATAPI_DEVICE *d)
{
    inportb(d->ctrl); inportb(d->ctrl); inportb(d->ctrl); inportb(d->ctrl);
}

static void atapi_select(ATAPI_DEVICE *d)
{
    atapi_outb(d,ATA_REG_DRIVE,(BYTE)(0xA0|((d->drive&1)<<4)));
    atapi_400ns(d);
}

static int atapi_wait_not_busy(ATAPI_DEVICE *d, DWORD timeout, BYTE *status)
{
    BYTE s;
    RTC_IO_DEADLINE deadline;

    rtc_io_deadline_start(&deadline,timeout,
        (unsigned int)(timeout/1000UL)+2U,100000000UL);
    for(;;)
    {
        s=atapi_inb(d,ATA_REG_STATUS);
        if(status) *status=s;
        if(s==0x00 || s==0xFF) return ATAPI_ERR_NO_DEVICE;
        if(!(s&ATA_SR_BSY)) return ATAPI_OK;
        if(rtc_io_deadline_expired(&deadline)) return ATAPI_ERR_TIMEOUT;
        SchedulerWaitPause(250UL);
    }
}

static int atapi_wait_drq(ATAPI_DEVICE *d, DWORD timeout, BYTE *status)
{
    BYTE s;
    RTC_IO_DEADLINE deadline;

    rtc_io_deadline_start(&deadline,timeout,
        (unsigned int)(timeout/1000UL)+2U,100000000UL);
    for(;;)
    {
        s=atapi_inb(d,ATA_REG_STATUS);
        if(status) *status=s;
        if(s==0x00 || s==0xFF) return ATAPI_ERR_NO_DEVICE;
        if(!(s&ATA_SR_BSY))
        {
            if(s&(ATA_SR_ERR|ATA_SR_DF)) return ATAPI_ERR_DEVICE;
            if(s&ATA_SR_DRQ) return ATAPI_OK;
        }
        if(rtc_io_deadline_expired(&deadline)) return ATAPI_ERR_TIMEOUT;
        SchedulerWaitPause(250UL);
    }
}

/* Wait until a data phase starts or the command finishes. */
static int atapi_wait_phase(ATAPI_DEVICE *d, DWORD timeout, BYTE *status)
{
    BYTE s;
    RTC_IO_DEADLINE deadline;

    rtc_io_deadline_start(&deadline,timeout,
        (unsigned int)(timeout/1000UL)+2U,100000000UL);
    for(;;)
    {
        s=atapi_inb(d,ATA_REG_STATUS);
        if(status) *status=s;
        if(s==0x00 || s==0xFF) return ATAPI_ERR_NO_DEVICE;
        if(!(s&ATA_SR_BSY))
        {
            BYTE reason;
            if(s&(ATA_SR_ERR|ATA_SR_DF)) return ATAPI_ERR_DEVICE;
            if(s&ATA_SR_DRQ)
            {
                /* ATAPI interrupt reason: C/D=1,I/O=0 is still the command
                 * phase.  Do not mistake a lingering command DRQ for data. */
                reason=(BYTE)(atapi_inb(d,ATA_REG_SECCOUNT)&0x03);
                if(reason==0x01)
                {
                    atapi_400ns(d);
                    continue;
                }
            }
            return ATAPI_OK;
        }
        if(rtc_io_deadline_expired(&deadline)) return ATAPI_ERR_TIMEOUT;
        SchedulerWaitPause(250UL);
    }
}

static DWORD atapi_be32(const BYTE *p)
{
    return ((DWORD)p[0]<<24)|((DWORD)p[1]<<16)|((DWORD)p[2]<<8)|(DWORD)p[3];
}

static void atapi_put_be32(BYTE *p, DWORD v)
{
    p[0]=(BYTE)(v>>24);
    p[1]=(BYTE)(v>>16);
    p[2]=(BYTE)(v>>8);
    p[3]=(BYTE)v;
}

static void atapi_put_be16(BYTE *p, unsigned v)
{
    p[0]=(BYTE)(v>>8);
    p[1]=(BYTE)v;
}

static void atapi_trim_model(char *s)
{
    int n;
    n=(int)strlen(s);
    while(n>0 && (s[n-1]==' ' || s[n-1]=='\t')) s[--n]=0;
}

/*
 * Send one ATAPI packet and receive a PIO data-in response.  ATAPI may split
 * a transfer into several DRQ phases, each advertising its byte count in the
 * LBA MID/HIGH registers.  Always drain the full hardware phase even when the
 * caller supplied a smaller buffer, otherwise the channel remains wedged.
 */
static int atapi_packet_data_in(ATAPI_DEVICE *d,
                                const BYTE *cdb,
                                BYTE *buf,
                                DWORD buf_len,
                                DWORD *actual)
{
    BYTE packet[16];
    BYTE status;
    DWORD copied,total,phase_bytes,phase_words,i;
    WORD w;
    int r,psz;

    if(actual) *actual=0;
    if(d==NULL || cdb==NULL) return ATAPI_ERR_ARGUMENT;
    if(d->packet_size!=12 && d->packet_size!=16) return ATAPI_ERR_PROTOCOL;

    xmemset((char *)packet,0,(int)sizeof(packet));
    psz=d->packet_size;
    for(i=0;i<(DWORD)psz;i++) packet[i]=cdb[i];

    atapi_select(d);
    r=atapi_wait_not_busy(d,ATAPI_TIMEOUT_MS,&status);
    if(r) return r;

    /* PIO mode, no DMA.  Tell the device how much data can be accepted in
     * one phase.  Multi-block READ(10) remains below 64 KiB by design. */
    {
        DWORD window=buf_len;
        if(window==0U) window=ATAPI_CD_BLOCK_SIZE;
        if(window>0xFFFEUL) window=0xFFFEUL;
        atapi_outb(d,ATA_REG_FEATURES,0);
        atapi_outb(d,ATA_REG_SECCOUNT,0);
        atapi_outb(d,ATA_REG_LBA_LOW,0);
        atapi_outb(d,ATA_REG_LBA_MID,(BYTE)(window&0xFF));
        atapi_outb(d,ATA_REG_LBA_HIGH,(BYTE)(window>>8));
    }
    atapi_outb(d,ATA_REG_COMMAND,ATA_CMD_PACKET);
    atapi_400ns(d);

    r=atapi_wait_drq(d,ATAPI_TIMEOUT_MS,&status);
    if(r) return r;

    /* Command phase. */
    for(i=0;i<(DWORD)psz;i+=2)
    {
        w=(WORD)packet[i];
        if(i+1<(DWORD)psz) w|=(WORD)((WORD)packet[i+1]<<8);
        atapi_outw(d,w);
    }
    atapi_400ns(d);

    copied=0;
    total=0;
    for(;;)
    {
        r=atapi_wait_phase(d,ATAPI_TIMEOUT_MS,&status);
        if(r) return r;
        if(!(status&ATA_SR_DRQ)) break;

        phase_bytes=(DWORD)atapi_inb(d,ATA_REG_LBA_MID) |
                    ((DWORD)atapi_inb(d,ATA_REG_LBA_HIGH)<<8);
        if(phase_bytes==0) phase_bytes=ATAPI_MAX_PHASE_BYTES;
        if(phase_bytes>ATAPI_MAX_PHASE_BYTES) return ATAPI_ERR_PROTOCOL;

        phase_words=(phase_bytes+1U)/2U;
        for(i=0;i<phase_words;i++)
        {
            DWORD byte_off;
            w=atapi_inw(d);
            byte_off=i*2U;
            if(copied<buf_len && byte_off<phase_bytes)
                buf[copied++]=(BYTE)(w&0xFF);
            if(copied<buf_len && byte_off+1U<phase_bytes)
                buf[copied++]=(BYTE)(w>>8);
        }
        total+=phase_bytes;
        atapi_400ns(d);
    }

    if(actual) *actual=(copied<total)?copied:total;
    return ATAPI_OK;
}

static int atapi_request_sense(ATAPI_DEVICE *d)
{
    BYTE cdb[16];
    BYTE sense[18];
    DWORD actual;
    int r;

    xmemset((char *)cdb,0,(int)sizeof(cdb));
    xmemset((char *)sense,0,(int)sizeof(sense));
    cdb[0]=SCSI_CMD_REQUEST_SENSE;
    cdb[4]=sizeof(sense);

    r=atapi_packet_data_in(d,cdb,sense,sizeof(sense),&actual);
    if(r) return r;
    if(actual>=14)
    {
        d->last_sense_key=(BYTE)(sense[2]&0x0F);
        d->last_asc=sense[12];
        d->last_ascq=sense[13];
    }
    return ATAPI_OK;
}

static int atapi_read_capacity_once(ATAPI_DEVICE *d)
{
    BYTE cdb[16];
    BYTE cap[8];
    DWORD actual,last_lba,block_size;
    int r;

    xmemset((char *)cdb,0,(int)sizeof(cdb));
    xmemset((char *)cap,0,(int)sizeof(cap));
    cdb[0]=SCSI_CMD_READ_CAPACITY;
    r=atapi_packet_data_in(d,cdb,cap,sizeof(cap),&actual);
    if(r) return r;
    if(actual<8) return ATAPI_ERR_PROTOCOL;

    last_lba=atapi_be32(cap+0);
    block_size=atapi_be32(cap+4);
    if(block_size!=ATAPI_CD_BLOCK_SIZE)
    {
        printk("ATAPI: %s reports unsupported logical block size %u (expected %u).\n",
               d->model,(unsigned)block_size,(unsigned)ATAPI_CD_BLOCK_SIZE);
        return ATAPI_ERR_PROTOCOL;
    }
    if(last_lba==0xFFFFFFFFUL) return ATAPI_ERR_RANGE;

    d->block_size=block_size;
    d->block_count=last_lba+1U;
    d->media_ready=1;
    return ATAPI_OK;
}

static int atapi_refresh_capacity(ATAPI_DEVICE *d)
{
    int r;

    d->media_ready=0;
    d->block_count=0;
    d->block_size=ATAPI_CD_BLOCK_SIZE;
    d->last_sense_key=0;
    d->last_asc=0;
    d->last_ascq=0;

    r=atapi_read_capacity_once(d);
    if(!r) return ATAPI_OK;

    /* A newly inserted disc commonly raises UNIT ATTENTION on the first
     * command.  REQUEST SENSE clears it, after which READ CAPACITY is retried. */
    (void)atapi_request_sense(d);
    if(d->last_sense_key==0x06)
    {
        r=atapi_read_capacity_once(d);
        if(!r) return ATAPI_OK;
        (void)atapi_request_sense(d);
    }

    if(d->last_sense_key==0x02 && d->last_asc==0x3A)
        return ATAPI_ERR_NO_MEDIA;
    return r ? r : ATAPI_ERR_NO_MEDIA;
}

static int atapi_read_blocks(ATAPI_DEVICE *d, DWORD lba, unsigned count, BYTE *buf)
{
    BYTE cdb[16];
    DWORD actual,expected;
    unsigned chunk,attempt;
    int r,last_error;

    if(d==NULL || buf==NULL || count==0U) return ATAPI_ERR_ARGUMENT;
    if(!d->media_ready) {
        r=atapi_refresh_capacity(d);
        if(r) return r;
    }
    if(lba>=d->block_count || (DWORD)count>d->block_count-lba)
        return ATAPI_ERR_RANGE;

    while(count) {
        chunk=count>ATAPI_MAX_READ_BLOCKS ? ATAPI_MAX_READ_BLOCKS : count;
        expected=(DWORD)chunk*ATAPI_CD_BLOCK_SIZE;
        last_error=ATAPI_ERR_DEVICE;

        for(attempt=0U;attempt<ATAPI_READ_RETRIES;++attempt) {
            xmemset((char *)cdb,0,(int)sizeof(cdb));
            cdb[0]=SCSI_CMD_READ_10;
            atapi_put_be32(cdb+2,lba);
            atapi_put_be16(cdb+7,chunk);
            actual=0;

            r=atapi_packet_data_in(d,cdb,buf,expected,&actual);
            if(!r && actual==expected) {
                last_error=ATAPI_OK;
                break;
            }

            last_error=r ? r : ATAPI_ERR_PROTOCOL;
            d->media_ready=0;
            d->last_sense_key=0;
            d->last_asc=0;
            d->last_ascq=0;
            (void)atapi_request_sense(d);

            ReportMessage("ATAPI/read retry %u/%u %s LBA=%u blocks=%u rv=%d actual=%u sense=%02x/%02x/%02x.\n",
                          attempt+1U,ATAPI_READ_RETRIES,d->model,
                          (unsigned)lba,chunk,last_error,(unsigned)actual,
                          d->last_sense_key,d->last_asc,d->last_ascq);

            if(d->last_sense_key==0x02 && d->last_asc==0x3A)
                return ATAPI_ERR_NO_MEDIA;

            /* UNIT ATTENTION is expected once after media insertion.  Some
             * drives report transient NOT READY as well.  Refreshing capacity
             * both clears that state and verifies the geometry before retry. */
            if(d->last_sense_key==0x06 || d->last_sense_key==0x02) {
                r=atapi_refresh_capacity(d);
                if(r==ATAPI_ERR_NO_MEDIA) return r;
                if(!r && (lba>=d->block_count || (DWORD)chunk>d->block_count-lba))
                    return ATAPI_ERR_RANGE;
            }
        }
        if(last_error!=ATAPI_OK) return last_error;

        d->media_ready=1;
        lba+=(DWORD)chunk;
        buf+=expected;
        count-=chunk;
    }
    return ATAPI_OK;
}

static int atapi_read_block(ATAPI_DEVICE *d, DWORD lba, BYTE *buf)
{
    return atapi_read_blocks(d,lba,1U,buf);
}

static int atapi_identify(ATAPI_DEVICE *d)
{
    WORD id[256];
    BYTE status;
    WORD w;
    int r,i,type,packet_code;

    atapi_select(d);
    atapi_outb(d,ATA_REG_SECCOUNT,0);
    atapi_outb(d,ATA_REG_LBA_LOW,0);
    atapi_outb(d,ATA_REG_LBA_MID,0);
    atapi_outb(d,ATA_REG_LBA_HIGH,0);
    atapi_outb(d,ATA_REG_COMMAND,ATA_CMD_IDENTIFY_PACKET);
    atapi_400ns(d);

    status=atapi_inb(d,ATA_REG_STATUS);
    if(status==0x00 || status==0xFF) return 0;
    r=atapi_wait_drq(d,ATAPI_IDENTIFY_MS,&status);
    if(r) return 0;

    for(i=0;i<256;i++) id[i]=atapi_inw(d);

    type=(id[0]>>8)&0x1F;
    if(type!=ATAPI_PERIPH_CDROM) return 0;

    packet_code=id[0]&0x03;
    if(packet_code==0) d->packet_size=12;
    else if(packet_code==1) d->packet_size=16;
    else return 0;

    xmemset((char *)d->model,0,(int)sizeof(d->model));
    for(i=0;i<20;i++)
    {
        w=id[27+i];
        d->model[i*2]=(char)(w>>8);
        d->model[i*2+1]=(char)(w&0xFF);
    }
    d->model[40]=0;
    atapi_trim_model(d->model);
    d->present=1;
    d->mounted=1;
    d->block_size=ATAPI_CD_BLOCK_SIZE;
    return 1;
}

static int atapi_device_call_slot(int slot, DEVICE_CALL_PARS)
{
    ATAPI_DEVICE *d;
    DWORD *v;
    int r;

    if(slot<0 || slot>=ATAPI_MAX_DEVICES) return ATAPI_ERR_ARGUMENT;
    d=&atapi_dev[slot];
    if(!d->present) return ATAPI_ERR_NO_DEVICE;

    switch(n_call)
    {
        case DEVICE_CMD_INIT:
            return ATAPI_OK;

        case DEVICE_CMD_MOUNT:
            d->mounted=1;
            (void)atapi_refresh_capacity(d);
            return ATAPI_OK;

        case DEVICE_CMD_UNMOUNT:
            d->mounted=0;
            d->media_ready=0;
            return ATAPI_OK;

        case DEVICE_CMD_READBLOCK:
            if(!d->mounted) return ATAPI_ERR_NO_MEDIA;
            if(po1==NULL || p1<0) return ATAPI_ERR_ARGUMENT;
            return atapi_read_block(d,(DWORD)p1,(BYTE *)po1);

        case DEVICE_CMD_READBLOCKS:
            if(!d->mounted) return ATAPI_ERR_NO_MEDIA;
            if(po1==NULL || p1<0 || p2<=0) return ATAPI_ERR_ARGUMENT;
            return atapi_read_blocks(d,(DWORD)p1,(unsigned)p2,(BYTE *)po1);

        case DEVICE_CMD_WRITEBLOCK:
        case DEVICE_CMD_WRITEBLOCKS:
            return ATAPI_ERR_READ_ONLY;

        case DEVICE_CMD_GETSIZE:
            if(po1==NULL) return ATAPI_ERR_ARGUMENT;
            v=(DWORD *)po1;
            if(!d->mounted)
            {
                *v=0;
                return ATAPI_OK;
            }
            if(!d->media_ready) (void)atapi_refresh_capacity(d);
            *v=d->media_ready ? d->block_count : 0;
            return ATAPI_OK;

        case DEVICE_CMD_GETBLOCKSIZE:
            if(po1==NULL) return ATAPI_ERR_ARGUMENT;
            v=(DWORD *)po1;
            *v=ATAPI_CD_BLOCK_SIZE;
            return ATAPI_OK;

        case DEVICE_CMD_FLUSH:
        case DEVICE_CMD_SHUTDOWN:
            /* Read-only PIO device: there is no dirty state to flush. */
            return ATAPI_OK;

        default:
            r=ATAPI_OK;
            break;
    }
    return r;
}

#define ATAPI_WRAPPER(N) \
static int atapi_device_call##N(DEVICE_CALL_PARS) \
{ \
    return atapi_device_call_slot(N,n_call,p1,p2,p3,p4,po1,po2); \
}

ATAPI_WRAPPER(0)
ATAPI_WRAPPER(1)
ATAPI_WRAPPER(2)
ATAPI_WRAPPER(3)

static void *atapi_handlers[ATAPI_MAX_DEVICES]={
    atapi_device_call0,atapi_device_call1,atapi_device_call2,atapi_device_call3
};

static int atapi_register_slot(int slot, int ordinal)
{
    char name[32];
    int dnr;
    ATAPI_DEVICE *d;

    d=&atapi_dev[slot];
    strcpy(name,"cdrom");
    if(ordinal>0)
    {
        name[5]=(char)('0'+ordinal);
        name[6]=0;
    }

    dnr=driver_register_new_device(name,atapi_handlers[slot],
                                   DEVICE_TYPE_BLOCK|DEVICE_TYPE_READONLY|DEVICE_TYPE_MULTIBLOCK);
    if(dnr<0) return 1;
    d->dnr=dnr;

    /* Optical media is removable; never let the generic DAPI cache retain
     * blocks across a disc swap. */
    driver_disableDAPIReadCache(dnr);

    if(!atapi_refresh_capacity(d))
        printk("ATAPI: %s registered: %s, %u blocks x %u bytes (%u MiB), PIO read-only.\n",
               name,d->model,(unsigned)d->block_count,(unsigned)d->block_size,
               (unsigned)(d->block_count/512UL));
    else
        printk("ATAPI: %s registered: %s, no media, PIO read-only.\n",
               name,d->model);
    return 0;
}

int atapi_init(void)
{
    static const WORD io_base[2]={0x1F0,0x170};
    static const WORD ctrl_base[2]={0x3F6,0x376};
    int channel,drive,slot,ordinal;
    ATAPI_DEVICE *d;

    xmemset((char *)atapi_dev,0,(int)sizeof(atapi_dev));
    atapi_present_count=0;
    ordinal=0;

    for(channel=0;channel<2;channel++)
    {
        for(drive=0;drive<2;drive++)
        {
            slot=channel*2+drive;
            d=&atapi_dev[slot];
            d->channel=channel;
            d->drive=drive;
            d->io=io_base[channel];
            d->ctrl=ctrl_base[channel];
            d->dnr=-1;
            d->block_size=ATAPI_CD_BLOCK_SIZE;

            if(atapi_identify(d))
            {
                printk("ATAPI: IDE%d %s CD-ROM detected: %s (packet=%d).\n",
                       channel,drive ? "slave" : "master",d->model,d->packet_size);
                if(!atapi_register_slot(slot,ordinal))
                {
                    ordinal++;
                    atapi_present_count++;
                }
            }
        }
    }

    if(!atapi_present_count)
        printk("ATAPI: no ATA/IDE CD-ROM devices detected.\n");
    return atapi_present_count;
}
