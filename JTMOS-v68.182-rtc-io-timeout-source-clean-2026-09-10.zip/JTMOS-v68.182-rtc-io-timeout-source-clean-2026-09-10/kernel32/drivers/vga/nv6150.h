#ifndef __INCLUDED_NV6150_H__
#define __INCLUDED_NV6150_H__

/*
 * NVIDIA GeForce 6150SE / MCP61 (PCI 10DE:03D0) native LFB provider.
 *
 * The driver is intentionally a fallback behind a working boot32 VBE handoff.
 * Probe/prepare never changes the visible video mode.  The actual mode switch
 * happens only when GraOS explicitly requests graphics after paging is active.
 */

#define NV6150_PCI_VENDOR          0x10DE
#define NV6150_PCI_DEVICE          0x03D0

#define NV6150_GRAOS_WIDTH         1024
#define NV6150_GRAOS_HEIGHT        768
#define NV6150_FALLBACK_WIDTH      640
#define NV6150_FALLBACK_HEIGHT     480
#define NV6150_BPP                 32

/* Set to 0 for an emergency build which probes/maps the LFB but refuses to
 * touch the pixel clock.  The normal eMachines profile uses the native PLL. */
#ifndef NV6150_NATIVE_PLL
#define NV6150_NATIVE_PLL          1
#endif

extern int nv6150_prepared;
extern int nv6150_active;
extern DWORD nv6150_mmio_phys;
extern DWORD nv6150_lfb_phys;

int Nv6150Probe(void);
int Nv6150PrepareGraOS(void);
int Nv6150SetMode(int width, int height, int bpp);
int Nv6150SetupGraOS(void);
int Nv6150IsPrepared(void);
int Nv6150IsActive(void);
DWORD Nv6150GetFramebufferPhysical(void);
DWORD Nv6150GetFramebufferBytes(void);
int Nv6150FramebufferMapped(void);
void Nv6150SetFramebufferMapped(int mapped);
void Nv6150DumpState(void);

#endif
