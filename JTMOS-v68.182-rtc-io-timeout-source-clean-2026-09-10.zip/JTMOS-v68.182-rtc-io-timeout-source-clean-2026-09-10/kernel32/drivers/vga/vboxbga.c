//////////////////////////////////////////////////////////////////////////////////
// vboxbga.c
// VirtualBox / Bochs Graphics Adapter protected-mode LFB driver for JTMOS.
//
// Uses the Bochs VBE DISPI register pair at 0x01CE/0x01CF.  VirtualBox's
// legacy VBoxVGA adapter implements a compatible interface and additionally
// exposes the upper 16 bits of the framebuffer address through index 0x0B.
//
// The driver intentionally feeds JTMOS's existing vesa_* framebuffer contract.
// This lets the current paging code identity-map the physical framebuffer and
// lets GraOS continue to use VesaDrawFrame() without knowing which mode setter
// provided the LFB.
//////////////////////////////////////////////////////////////////////////////////
#include "kernel32.h"
#include "vesa.h"
#include "vboxbga.h"

#define BGA_INDEX_PORT             0x01CE
#define BGA_DATA_PORT              0x01CF

#define BGA_INDEX_ID               0x00
#define BGA_INDEX_XRES             0x01
#define BGA_INDEX_YRES             0x02
#define BGA_INDEX_BPP              0x03
#define BGA_INDEX_ENABLE           0x04
#define BGA_INDEX_BANK             0x05
#define BGA_INDEX_VIRT_WIDTH       0x06
#define BGA_INDEX_VIRT_HEIGHT      0x07
#define BGA_INDEX_X_OFFSET         0x08
#define BGA_INDEX_Y_OFFSET         0x09
#define BGA_INDEX_VBOX_VIDEO       0x0A
#define BGA_INDEX_FB_BASE_HI       0x0B

#define BGA_DISABLED               0x0000
#define BGA_ENABLED                0x0001
#define BGA_GETCAPS                0x0002
#define BGA_8BIT_DAC               0x0020
#define BGA_LFB_ENABLED            0x0040
#define BGA_NOCLEARMEM             0x0080

#define BGA_ID0                    0xB0C0
#define BGA_ID4                    0xB0C4
#define BGA_ID5                    0xB0C5
#define BGA_ID_VBOX_VIDEO          0xBE00
#define BGA_ID_HGSMI               0xBE01
#define BGA_ID_ANYX                0xBE02

#define PCI_CONFIG_ADDRESS         0x0CF8
#define PCI_CONFIG_DATA            0x0CFC
#define PCI_VENDOR_BOCHS           0x1234
#define PCI_DEVICE_BOCHS_VGA       0x1111
#define PCI_VENDOR_VIRTUALBOX      0x80EE
#define PCI_DEVICE_VBOX_VGA        0xBEEF

int vbox_bga_active = FALSE;
int vbox_bga_prepared = FALSE;
WORD vbox_bga_id = 0;
DWORD vbox_bga_lfb_phys = 0;

static void bga_write(WORD index, WORD value)
{
    outportw(BGA_INDEX_PORT, index);
    outportw(BGA_DATA_PORT, value);
}

static WORD bga_read(WORD index)
{
    outportw(BGA_INDEX_PORT, index);
    return inportw(BGA_DATA_PORT);
}

static int bga_id_supported(WORD id)
{
    if(id >= BGA_ID0 && id <= BGA_ID5)
        return TRUE;
    if(id >= BGA_ID_VBOX_VIDEO && id <= BGA_ID_ANYX)
        return TRUE;
    return FALSE;
}

/* PCI configuration mechanism #1 read.  This is local on purpose: the BGA
 * driver is needed before normal pci_init(), because pg_init() must know the
 * physical framebuffer address before CR0.PG is enabled. */
static DWORD bga_pci_read32(int bus, int dev, int func, int reg)
{
    DWORD address;

    address = 0x80000000UL |
              ((DWORD)(bus & 0xff) << 16) |
              ((DWORD)(dev & 0x1f) << 11) |
              ((DWORD)(func & 7) << 8) |
              ((DWORD)reg & 0xfc);
    outportd(PCI_CONFIG_ADDRESS, address);
    return inportd(PCI_CONFIG_DATA);
}

static DWORD bga_find_pci_lfb(void)
{
    int bus, dev, func, maxfunc;
    DWORD id, hdr, bar0;
    WORD vendor, device;

    /* The display controller is normally function zero.  If the header says
     * multi-function, inspect the remaining functions as well. */
    for(bus=0; bus<256; bus++)
    {
        for(dev=0; dev<32; dev++)
        {
            id = bga_pci_read32(bus, dev, 0, 0x00);
            vendor = (WORD)(id & 0xffff);
            if(vendor == 0xffff || vendor == 0x0000)
                continue;

            hdr = bga_pci_read32(bus, dev, 0, 0x0c);
            maxfunc = (hdr & 0x00800000UL) ? 8 : 1;

            for(func=0; func<maxfunc; func++)
            {
                id = bga_pci_read32(bus, dev, func, 0x00);
                vendor = (WORD)(id & 0xffff);
                device = (WORD)((id >> 16) & 0xffff);
                if(vendor == 0xffff || vendor == 0x0000)
                    continue;

                if(!((vendor == PCI_VENDOR_VIRTUALBOX &&
                      device == PCI_DEVICE_VBOX_VGA) ||
                     (vendor == PCI_VENDOR_BOCHS &&
                      device == PCI_DEVICE_BOCHS_VGA)))
                    continue;

                bar0 = bga_pci_read32(bus, dev, func, 0x10);

                /* BAR0 must be a memory BAR.  The VGA/BGA implementations
                 * used here expose the framebuffer below 4 GiB. */
                if(bar0 == 0 || bar0 == 0xffffffffUL || (bar0 & 1))
                    continue;
                bar0 &= 0xfffffff0UL;
                if(bar0 != 0)
                    return bar0;
            }
        }
    }

    return 0;
}

static DWORD bga_find_lfb(WORD id)
{
    WORD hi;
    DWORD phys;

    /* VirtualBox extension.  It is harmless to read this after accepting a
     * standard B0Cx ID too: VBoxVGA may expose the extension while retaining
     * a Bochs-compatible ID. */
    hi = bga_read(BGA_INDEX_FB_BASE_HI);
    if(hi != 0 && hi != 0xffff)
    {
        phys = ((DWORD)hi) << 16;
        if(phys >= 0x01000000UL)
            return phys;
    }

    /* QEMU's PCI BGA and VBoxVGA also expose the framebuffer through BAR0. */
    phys = bga_find_pci_lfb();
    if(phys != 0)
        return phys;

    /* ISA Bochs has no PCI BAR.  Historical Bochs assigns the BGA LFB here.
     * Do not use this fallback for VirtualBox-specific IDs. */
    if(id >= BGA_ID0 && id <= BGA_ID5)
        return 0xE0000000UL;

    return 0;
}

int VBoxBgaProbe(void)
{
    WORD id;
    DWORD phys;

    vbox_bga_active = FALSE;
    vbox_bga_prepared = FALSE;
    vbox_bga_id = 0;
    vbox_bga_lfb_phys = 0;

    id = bga_read(BGA_INDEX_ID);
    if(!bga_id_supported(id))
    {
        printk("VBox/BGA: unsupported DISPI id=0x%x (expected B0C0..B0C5 or VBox BE00..BE02).\n", id);
        return FALSE;
    }

    phys = bga_find_lfb(id);
    if(phys == 0)
    {
        printk("VBox/BGA: adapter id=0x%x found, but no LFB address.\n", id);
        return FALSE;
    }

    vbox_bga_id = id;
    vbox_bga_lfb_phys = phys;
    printk("VBox/BGA: id=0x%x LFB=0x%x detected.\n", id, phys);
    return TRUE;
}



/*
 * Discover the protected-mode BGA framebuffer during kernel boot without
 * changing the visible video mode.  pg_init() can then identity-map the
 * future 1024x768x32 LFB while the user continues to see VGA text mode.
 *
 * The actual DISPI mode switch is intentionally deferred until the GraOS
 * process asks for graphics.  This prevents the black-screen interval that
 * used to begin immediately after boot32/kernel graphics probing.
 */
int VBoxBgaPrepareGraOS(void)
{
    if(!VBoxBgaProbe())
        return FALSE;

    vesa_width = VBOX_BGA_GRAOS_WIDTH;
    vesa_height = VBOX_BGA_GRAOS_HEIGHT;
    vesa_bpp = VBOX_BGA_GRAOS_BPP;
    vesa_pitch = VBOX_BGA_GRAOS_WIDTH*4;
    vesa_frame_buf = (BYTE *)vbox_bga_lfb_phys;
    vb = vesa_frame_buf;
    vesa_frame_buf_bytes =
        (DWORD)VBOX_BGA_GRAOS_WIDTH * (DWORD)VBOX_BGA_GRAOS_HEIGHT * 4UL;
    vesa_mode_attributes = 0x0091;

    /* Prepared is not active: do not disable VGA text HW and do not let
     * VesaActivate() run during kernel boot. */
    vesa_boot_graphics = FALSE;
    vesa_enabled = FALSE;
    vbox_bga_active = FALSE;
    vbox_bga_prepared = TRUE;

    printk("VBox/BGA: GraOS LFB prepared at 0x%x (%dx%dx%d); text mode retained.\n",
        vbox_bga_lfb_phys, VBOX_BGA_GRAOS_WIDTH,
        VBOX_BGA_GRAOS_HEIGHT, VBOX_BGA_GRAOS_BPP);
    return TRUE;
}

int VBoxBgaSetMode(int width, int height, int bpp)
{
    WORD rx, ry, rbpp, virtw;

    if(vbox_bga_lfb_phys == 0)
        return FALSE;
    if(width <= 0 || height <= 0)
        return FALSE;
    if(bpp != 32)
        return FALSE;

    /* Geometry registers are changed while DISPI is disabled. */
    bga_write(BGA_INDEX_ENABLE, BGA_DISABLED);
    bga_write(BGA_INDEX_XRES, (WORD)width);
    bga_write(BGA_INDEX_YRES, (WORD)height);
    bga_write(BGA_INDEX_BPP, (WORD)bpp);
    bga_write(BGA_INDEX_VIRT_WIDTH, (WORD)width);
    bga_write(BGA_INDEX_X_OFFSET, 0);
    bga_write(BGA_INDEX_Y_OFFSET, 0);

    /* Enable the linear framebuffer.  Do not preserve old VRAM: JTMOS clears
     * the framebuffer after paging is installed, and a clean mode switch is
     * preferable during boot. */
    bga_write(BGA_INDEX_ENABLE, BGA_ENABLED | BGA_LFB_ENABLED);

    rx = bga_read(BGA_INDEX_XRES);
    ry = bga_read(BGA_INDEX_YRES);
    rbpp = bga_read(BGA_INDEX_BPP);
    virtw = bga_read(BGA_INDEX_VIRT_WIDTH);

    if(rx != (WORD)width || ry != (WORD)height || rbpp != (WORD)bpp)
    {
        printk("VBox/BGA: mode readback failed: %dx%dx%d requested, %dx%dx%d returned.\n",
            width, height, bpp, rx, ry, rbpp);
        bga_write(BGA_INDEX_ENABLE, BGA_DISABLED);
        return FALSE;
    }
    if(virtw < (WORD)width)
    {
        printk("VBox/BGA: invalid virtual width %d.\n", virtw);
        bga_write(BGA_INDEX_ENABLE, BGA_DISABLED);
        return FALSE;
    }

    /* Feed the already existing JTMOS packed-LFB contract.  These globals are
     * consumed by pg_init(), VesaActivate(), VesaDrawFrame(), and GraOS. */
    vesa_width = width;
    vesa_height = height;
    vesa_bpp = bpp;
    vesa_pitch = ((int)virtw * bpp + 7) / 8;
    vesa_red_mask_size=8; vesa_red_field_pos=16;
    vesa_green_mask_size=8; vesa_green_field_pos=8;
    vesa_blue_mask_size=8; vesa_blue_field_pos=0;
    vesa_alpha_mask_size=8; vesa_alpha_field_pos=24;
    if(vesa_pitch <= 0 || (DWORD)vesa_pitch > 0xffffffffUL/(DWORD)height)
    {
        bga_write(BGA_INDEX_ENABLE, BGA_DISABLED);
        return FALSE;
    }

    vesa_frame_buf = (BYTE *)vbox_bga_lfb_phys;
    vb = vesa_frame_buf;
    vesa_frame_buf_bytes = (DWORD)vesa_pitch * (DWORD)height;

    /* Same semantic bits VesaProbe() requires: supported, graphics, LFB.
     * The LFB layout is fixed to B,G,R,X bytes by the BGA interface. */
    vesa_mode_attributes = 0x0091;
    vesa_boot_graphics = TRUE;
    vesa_enabled = FALSE;      /* becomes TRUE only after pg_init() */
    vbox_bga_active = TRUE;
    vbox_bga_prepared = TRUE;

    printk("VBox/BGA: mode %dx%dx%d pitch=%d LFB=0x%x bytes=0x%x.\n",
        vesa_width, vesa_height, vesa_bpp, vesa_pitch,
        vesa_frame_buf, vesa_frame_buf_bytes);
    return TRUE;
}

int VBoxBgaSetupGraOS(void)
{
    if(!vbox_bga_prepared && !VBoxBgaPrepareGraOS())
        return FALSE;

    if(VBoxBgaSetMode(VBOX_BGA_GRAOS_WIDTH,
                      VBOX_BGA_GRAOS_HEIGHT,
                      VBOX_BGA_GRAOS_BPP))
        return TRUE;

    /* Keep the machine usable on older VBoxVGA/Bochs implementations even
     * when the 1024x768 mode cannot be programmed.  The kernel text console
     * can use this fallback, while VesaGraOSReady() intentionally refuses to
     * launch the fixed-size 1024x768 Ring3 desktop on it. */
    printk("VBox/BGA: 1024x768x32 unavailable, trying 640x480x32 recovery mode.\n");
    if(VBoxBgaSetMode(VBOX_BGA_FALLBACK_WIDTH,
                      VBOX_BGA_FALLBACK_HEIGHT,
                      VBOX_BGA_GRAOS_BPP))
        return TRUE;

    vbox_bga_active = FALSE;
    return FALSE;
}

int VBoxBgaIsActive(void)
{
    return vbox_bga_active;
}

int VBoxBgaIsPrepared(void)
{
    return vbox_bga_prepared;
}

DWORD VBoxBgaGetFramebufferPhysical(void)
{
    return vbox_bga_lfb_phys;
}
