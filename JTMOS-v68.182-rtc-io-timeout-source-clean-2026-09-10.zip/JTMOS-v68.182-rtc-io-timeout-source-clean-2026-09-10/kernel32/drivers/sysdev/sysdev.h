#ifndef __INCLUDED_SYSDEV_H__
#define __INCLUDED_SYSDEV_H__

/* Historical one-floppy compatibility window only. New builds use B:/CD. */
#define SYSDEV_LEGACY_START_BLOCK 1280
#define SYSDEV_LEGACY_BLOCK_COUNT 1600
#define SYSDEV_LEGACY_BLOCK_SIZE  512

int sysdev_init(void);
int sysdev_register_device(void);

#endif
