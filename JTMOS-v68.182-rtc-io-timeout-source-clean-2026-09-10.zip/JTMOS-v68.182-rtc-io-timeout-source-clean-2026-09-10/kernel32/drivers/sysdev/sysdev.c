/*** SYS:/ROOT MEDIA ALIAS DEVICE ***
 *
 * V67.8.57.1 Linux-style two-media boot policy:
 *   A: floppy   = boot32pm + kernel only
 *   B: floppy2  = root/system SQARC payload (preferred)
 *   cdrom:      = root/system SQARC payload (fallback/alternative)
 *
 * For compatibility with older one-floppy images, sys: can still fall back to
 * the historical 800 KiB window at A: block 1280.  New release images do not
 * place a system partition on A:.
 */
#include "basdef.h"
#include "kernel32.h"
#include "driver_sys.h"
#include "driver_api.h"
#include "driver_rw.h"
#include "driver_devcall.h"
#include "sysdev.h"

static int sysdev_backend = -1;
static int sysdev_start_block = 0;
static int sysdev_block_count = 0;
static int sysdev_block_size = 512;
static int sysdev_dev_mounted = 1;
static char sysdev_backend_name[16] = "none";

/* SQARC images reserve the first 2048 bytes as a safe/boot area and place
 * the eight-byte archive identifier immediately after it.  Probe the actual
 * medium instead of trusting floppy geometry: floppy2 is registered even when
 * no B: disk is inserted, while ATAPI reports its capacity dynamically. */
#define SYSDEV_SQARC_SAFE_BYTES 2048
#define SYSDEV_SQARC_ID         "SQARC520"
#define SYSDEV_SQARC_ID_BYTES   8
static BYTE sysdev_probe_block[2048];

static int sysdev_probe_sqarc(int dnr, int start_block, int blocksize)
{
    int header_block;
    if(dnr<0 || blocksize<=0 || blocksize>(int)sizeof(sysdev_probe_block))
        return 0;
    if((SYSDEV_SQARC_SAFE_BYTES % blocksize)!=0)
        return 0;
    header_block=start_block + SYSDEV_SQARC_SAFE_BYTES/blocksize;
    if(readblock(dnr,header_block,sysdev_probe_block)!=0)
        return 0;
    return memcmp(sysdev_probe_block,SYSDEV_SQARC_ID,SYSDEV_SQARC_ID_BYTES)==0;
}

static int sysdev_valid_block(int block)
{
    return block >= 0 && block < sysdev_block_count;
}

static int sysdev_select_backend(void)
{
    int dnr, size, blocksize;

    /* Linux-style default: separate root floppy B:. */
    dnr=driver_getdevicenrbyname("floppy2");
    if(dnr>=0)
    {
        size=getsize(dnr);
        blocksize=getblocksize(dnr);
        if(size>0 && blocksize>0 && sysdev_probe_sqarc(dnr,0,blocksize))
        {
            sysdev_backend=dnr;
            sysdev_start_block=0;
            sysdev_block_count=size;
            sysdev_block_size=blocksize;
            strcpy(sysdev_backend_name,"floppy2");
            return 0;
        }
    }

    /* A raw SQARC image padded to 2048-byte ATAPI sectors is also valid. */
    dnr=driver_getdevicenrbyname("cdrom");
    if(dnr>=0)
    {
        size=getsize(dnr);
        blocksize=getblocksize(dnr);
        if(size>0 && blocksize>0 && sysdev_probe_sqarc(dnr,0,blocksize))
        {
            sysdev_backend=dnr;
            sysdev_start_block=0;
            sysdev_block_count=size;
            sysdev_block_size=blocksize;
            strcpy(sysdev_backend_name,"cdrom");
            return 0;
        }
    }

    /* Legacy compatibility only: old A: carried sys: in its final 800 KiB. */
    dnr=driver_getdevicenrbyname("floppy");
    if(dnr>=0 && getblocksize(dnr)==SYSDEV_LEGACY_BLOCK_SIZE &&
       getsize(dnr) >= SYSDEV_LEGACY_START_BLOCK + SYSDEV_LEGACY_BLOCK_COUNT &&
       sysdev_probe_sqarc(dnr,SYSDEV_LEGACY_START_BLOCK,SYSDEV_LEGACY_BLOCK_SIZE))
    {
        sysdev_backend=dnr;
        sysdev_start_block=SYSDEV_LEGACY_START_BLOCK;
        sysdev_block_count=SYSDEV_LEGACY_BLOCK_COUNT;
        sysdev_block_size=SYSDEV_LEGACY_BLOCK_SIZE;
        strcpy(sysdev_backend_name,"floppy");
        return 0;
    }

    return 1;
}

int sysdev_device_call(DEVICE_CALL_PARS)
{
    DWORD *size;
    int r=0;

    if(n_call!=DEVICE_CMD_MOUNT && !sysdev_dev_mounted)
        return 1;

    switch(n_call)
    {
        case DEVICE_CMD_MOUNT:
            sysdev_dev_mounted=1;
            break;
        case DEVICE_CMD_UNMOUNT:
            sysdev_dev_mounted=0;
            break;
        case DEVICE_CMD_INIT:
        case DEVICE_CMD_SHUTDOWN:
            break;

        case DEVICE_CMD_READBLOCK:
        case DEVICE_CMD_WRITEBLOCK:
            if(sysdev_backend<0 || po1==NULL || !sysdev_valid_block(p1))
                return 1;
            r=device_call(sysdev_backend,n_call,
                          sysdev_start_block+p1,0,0,0,po1,NULL);
            break;

        case DEVICE_CMD_READBLOCKS:
        case DEVICE_CMD_WRITEBLOCKS:
            if(sysdev_backend<0 || po1==NULL || p1<0 || p2<=0 ||
               p1>=sysdev_block_count || p2>sysdev_block_count-p1)
                return 1;
            r=device_call(sysdev_backend,n_call,
                          sysdev_start_block+p1,p2,0,0,po1,NULL);
            break;

        case DEVICE_CMD_GETSIZE:
            if(po1==NULL) return 1;
            size=(DWORD *)po1;
            *size=sysdev_block_count;
            break;
        case DEVICE_CMD_GETBLOCKSIZE:
            if(po1==NULL) return 1;
            size=(DWORD *)po1;
            *size=sysdev_block_size;
            break;
        case DEVICE_CMD_FLUSH:
            if(sysdev_backend>=0)
                r=device_call(sysdev_backend,DEVICE_CMD_FLUSH,0,0,0,0,NULL,NULL);
            break;
        case DEVICE_CMD_SEEK:
        case DEVICE_CMD_GETCH:
        case DEVICE_CMD_PUTCH:
        case DEVICE_CMD_TELL:
            return 0;
        default:
            return 1;
    }
    return r;
}

int sysdev_register_device(void)
{
    int sys_dnr, system_dnr;

    if(driver_getdevicebyname("sys")!=NULL)
        return 0;

    if(sysdev_select_backend())
    {
        printk("sysdev: no root/system medium found (B: or cdrom:); sys: unavailable.\n");
        return 1;
    }

    sys_dnr=driver_register_new_deviceEx("sys",sysdev_device_call,
               0,0,DEVICE_TYPE_BLOCK|DEVICE_TYPE_MULTIBLOCK,0);
    if(sys_dnr<0)
        return 1;

    system_dnr=driver_register_new_deviceEx("system",sysdev_device_call,
               0,0,DEVICE_TYPE_BLOCK|DEVICE_TYPE_MULTIBLOCK,
               sys_dnr!=0 ? sys_dnr : 0);

    driver_disableDAPIReadCache(sys_dnr);
    driver_disableDAPIWriteBackCache(sys_dnr);
    if(system_dnr>=0)
    {
        driver_disableDAPIReadCache(system_dnr);
        driver_disableDAPIWriteBackCache(system_dnr);
    }

    printk("sysdev: sys: -> %s blocks %d..%d (%d-byte blocks, %d KiB).\n",
           sysdev_backend_name,sysdev_start_block,
           sysdev_start_block+sysdev_block_count-1,
           sysdev_block_size,
           (sysdev_block_count*sysdev_block_size)/1024);
    return 0;
}

int sysdev_init(void)
{
    return sysdev_register_device();
}
