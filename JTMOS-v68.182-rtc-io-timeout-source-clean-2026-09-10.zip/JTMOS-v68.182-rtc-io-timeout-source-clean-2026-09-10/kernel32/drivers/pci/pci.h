#ifndef __INCLUDED_PCI_H__
#define __INCLUDED_PCI_H__

/* JTMOS PCI core.  The historical pci_probe() scanner remains the public
 * entry point, but the scan is now retained as a device database which other
 * drivers can query instead of each driver poking 0xCF8/0xCFC itself. */

#define PCI_MAX_DEVICES          256
#define PCI_MAX_BARS             6

#define PCI_COMMAND_IO           0x0001
#define PCI_COMMAND_MEMORY       0x0002
#define PCI_COMMAND_MASTER       0x0004
#define PCI_COMMAND_INTX_DISABLE  0x0400
#define PCI_STATUS_CAP_LIST      0x0010

#define PCI_CAP_ID_PM            0x01
#define PCI_CAP_ID_MSI           0x05
#define PCI_CAP_ID_PCIX          0x07
#define PCI_CAP_ID_EXP           0x10
#define PCI_CAP_ID_MSIX          0x11

#define PCI_ENABLE_IO            0x01
#define PCI_ENABLE_MEMORY        0x02
#define PCI_ENABLE_MASTER        0x04

typedef struct
{
 int type;                  /* 0 none, 1 config mechanism #1, 2 mechanism #2 */
 int initialized;
 int device_count;          /* entries retained in devices[] */
 int devices_seen;          /* total functions discovered */
 int truncated;
} PCIBRIDGE;

typedef struct
{
 BYTE bus;
 BYTE device;
 BYTE function;
 WORD vendor_id;
 WORD device_id;
 WORD command;
 WORD status;
 BYTE revision;
 BYTE prog_if;
 BYTE subclass;
 BYTE class_code;
 BYTE cache_line_size;
 BYTE latency_timer;
 BYTE header_type;
 BYTE bist;
 BYTE irq_line;
 BYTE irq_pin;
 BYTE primary_bus;
 BYTE secondary_bus;
 BYTE subordinate_bus;
 BYTE cap_ptr;
 BYTE has_pm;
 BYTE has_msi;
 BYTE has_msix;
 BYTE has_pcie;
} PCIDEVICE;

typedef struct
{
 int valid;
 int io;
 int is64;
 int prefetchable;
 DWORD raw_low;
 DWORD raw_high;
 DWORD base_low;
 DWORD base_high;
} PCIBAR;

extern PCIBRIDGE pci;
extern PCIDEVICE pci_devices[PCI_MAX_DEVICES];

void pci_init(void);
int pci_device_call(DEVICE_CALL_PARS);
int pci_register_device(void);
void pci_probe(void);

/* Configuration-space API.  All accesses are serialized against interrupts
 * so a CF8/CFC address/data transaction cannot be torn by an IRQ handler. */
BYTE  pci_config_read8(BYTE bus,BYTE dev,BYTE fun,BYTE off);
WORD  pci_config_read16(BYTE bus,BYTE dev,BYTE fun,BYTE off);
DWORD pci_config_read32(BYTE bus,BYTE dev,BYTE fun,BYTE off);
void pci_config_write8(BYTE bus,BYTE dev,BYTE fun,BYTE off,BYTE value);
void pci_config_write16(BYTE bus,BYTE dev,BYTE fun,BYTE off,WORD value);
void pci_config_write32(BYTE bus,BYTE dev,BYTE fun,BYTE off,DWORD value);

int pci_get_device_count(void);
const PCIDEVICE *pci_get_device(int index);
const PCIDEVICE *pci_find_device(WORD vendor,WORD device,int index);
const PCIDEVICE *pci_find_class(BYTE class_code,BYTE subclass,BYTE prog_if,int index);
int pci_find_capability(const PCIDEVICE *dev,BYTE capability_id);
int pci_get_bar(const PCIDEVICE *dev,int barno,PCIBAR *bar);
int pci_enable_device(const PCIDEVICE *dev,int flags);
void pci_print_device(const PCIDEVICE *dev);
void pci_dump_devices(void);

#endif
