//----------------------------------------------------------
//
//                 JTMOS PCI BUS SUPPORT
//
// Historical scanner retained and modernized in V67.8.57.10.18:
// - complete bus/device/function enumeration using mechanism #1
// - multifunction devices
// - retained PCI device database for kernel drivers
// - safe 8/16/32-bit configuration accessors
// - BAR and capability parsing
// - common find/enable APIs used by AHCI and future drivers
// - legacy mechanism #2 scan retained as a compatibility fallback
//
// (C)2001-2003, 2026 by Jari Tuominen
//----------------------------------------------------------
#include "kernel32.h"
#include "sysmem.h"
#include "driver_sys.h"
#include "driver_api.h"
#include "pci.h"

#define PCI_CFG_ADDR 0x0cf8
#define PCI_CFG_DATA 0x0cfc

PCIBRIDGE pci;
PCIDEVICE pci_devices[PCI_MAX_DEVICES];

static DWORD pci_cfg_address(BYTE bus,BYTE dev,BYTE fun,BYTE off)
{
    return 0x80000000UL | ((DWORD)bus<<16) | ((DWORD)(dev&31)<<11) |
           ((DWORD)(fun&7)<<8) | ((DWORD)off&0xfcUL);
}

static int pci_mechanism1_available(void)
{
    DWORD saved,probe,flags;
    flags=get_eflags();
    disable();
    saved=inportd(PCI_CFG_ADDR);
    outportd(PCI_CFG_ADDR,0x80000000UL);
    probe=inportd(PCI_CFG_ADDR);
    outportd(PCI_CFG_ADDR,saved);
    set_eflags(flags);
    return probe==0x80000000UL;
}

static int pci_mechanism2_available(void)
{
    BYTE a,b,flags8;
    DWORD flags;
    flags=get_eflags();
    disable();
    a=inportb(0xcf8);
    b=inportb(0xcfa);
    outportb(0xcf8,0);
    outportb(0xcfa,0);
    flags8=(BYTE)(inportb(0xcf8)|inportb(0xcfa));
    outportb(0xcf8,a);
    outportb(0xcfa,b);
    set_eflags(flags);
    return flags8==0;
}

BYTE pci_config_read8(BYTE bus,BYTE dev,BYTE fun,BYTE off)
{
    DWORD flags;
    BYTE value;
    if(pci.type!=1) return 0xff;
    flags=get_eflags(); disable();
    outportd(PCI_CFG_ADDR,pci_cfg_address(bus,dev,fun,off));
    value=inportb((WORD)(PCI_CFG_DATA+(off&3)));
    set_eflags(flags);
    return value;
}

WORD pci_config_read16(BYTE bus,BYTE dev,BYTE fun,BYTE off)
{
    DWORD flags;
    WORD value;
    if(pci.type!=1 || (off&1)) return 0xffff;
    flags=get_eflags(); disable();
    outportd(PCI_CFG_ADDR,pci_cfg_address(bus,dev,fun,off));
    value=inportw((WORD)(PCI_CFG_DATA+(off&2)));
    set_eflags(flags);
    return value;
}

DWORD pci_config_read32(BYTE bus,BYTE dev,BYTE fun,BYTE off)
{
    DWORD flags,value;
    if(pci.type!=1 || (off&3)) return 0xffffffffUL;
    flags=get_eflags(); disable();
    outportd(PCI_CFG_ADDR,pci_cfg_address(bus,dev,fun,off));
    value=inportd(PCI_CFG_DATA);
    set_eflags(flags);
    return value;
}

void pci_config_write8(BYTE bus,BYTE dev,BYTE fun,BYTE off,BYTE value)
{
    DWORD flags;
    if(pci.type!=1) return;
    flags=get_eflags(); disable();
    outportd(PCI_CFG_ADDR,pci_cfg_address(bus,dev,fun,off));
    outportb((WORD)(PCI_CFG_DATA+(off&3)),value);
    set_eflags(flags);
}

void pci_config_write16(BYTE bus,BYTE dev,BYTE fun,BYTE off,WORD value)
{
    DWORD flags;
    if(pci.type!=1 || (off&1)) return;
    flags=get_eflags(); disable();
    outportd(PCI_CFG_ADDR,pci_cfg_address(bus,dev,fun,off));
    outportw((WORD)(PCI_CFG_DATA+(off&2)),value);
    set_eflags(flags);
}

void pci_config_write32(BYTE bus,BYTE dev,BYTE fun,BYTE off,DWORD value)
{
    DWORD flags;
    if(pci.type!=1 || (off&3)) return;
    flags=get_eflags(); disable();
    outportd(PCI_CFG_ADDR,pci_cfg_address(bus,dev,fun,off));
    outportd(PCI_CFG_DATA,value);
    set_eflags(flags);
}

static void pci_scan_capabilities(PCIDEVICE *d)
{
    BYTE p,id,next;
    int hops;
    d->cap_ptr=0;
    d->has_pm=d->has_msi=d->has_msix=d->has_pcie=0;
    if(!(d->status&PCI_STATUS_CAP_LIST)) return;
    if((d->header_type&0x7f)==2)
        p=pci_config_read8(d->bus,d->device,d->function,0x14);
    else
        p=pci_config_read8(d->bus,d->device,d->function,0x34);
    p&=0xfc;
    d->cap_ptr=p;
    for(hops=0; p>=0x40 && p<=0xfc && hops<48; ++hops) {
        id=pci_config_read8(d->bus,d->device,d->function,p);
        next=pci_config_read8(d->bus,d->device,d->function,(BYTE)(p+1));
        if(id==PCI_CAP_ID_PM) d->has_pm=1;
        else if(id==PCI_CAP_ID_MSI) d->has_msi=1;
        else if(id==PCI_CAP_ID_MSIX) d->has_msix=1;
        else if(id==PCI_CAP_ID_EXP) d->has_pcie=1;
        next&=0xfc;
        if(next==p) break;
        p=next;
    }
}

static void pci_record_function(BYTE bus,BYTE dev,BYTE fun)
{
    PCIDEVICE *d;
    DWORD v;
    int slot;
    pci.devices_seen++;
    if(pci.device_count>=PCI_MAX_DEVICES) {
        pci.truncated=1;
        return;
    }
    slot=pci.device_count++;
    d=&pci_devices[slot];
    memset(d,0,sizeof(*d));
    d->bus=bus; d->device=dev; d->function=fun;
    v=pci_config_read32(bus,dev,fun,0x00);
    d->vendor_id=(WORD)(v&0xffffU);
    d->device_id=(WORD)(v>>16);
    v=pci_config_read32(bus,dev,fun,0x04);
    d->command=(WORD)(v&0xffffU);
    d->status=(WORD)(v>>16);
    v=pci_config_read32(bus,dev,fun,0x08);
    d->revision=(BYTE)(v&0xffU);
    d->prog_if=(BYTE)((v>>8)&0xffU);
    d->subclass=(BYTE)((v>>16)&0xffU);
    d->class_code=(BYTE)((v>>24)&0xffU);
    v=pci_config_read32(bus,dev,fun,0x0c);
    d->cache_line_size=(BYTE)(v&0xffU);
    d->latency_timer=(BYTE)((v>>8)&0xffU);
    d->header_type=(BYTE)((v>>16)&0xffU);
    d->bist=(BYTE)((v>>24)&0xffU);
    d->irq_line=pci_config_read8(bus,dev,fun,0x3c);
    d->irq_pin=pci_config_read8(bus,dev,fun,0x3d);
    if(d->class_code==0x06 && d->subclass==0x04 && (d->header_type&0x7f)==1) {
        v=pci_config_read32(bus,dev,fun,0x18);
        d->primary_bus=(BYTE)(v&0xffU);
        d->secondary_bus=(BYTE)((v>>8)&0xffU);
        d->subordinate_bus=(BYTE)((v>>16)&0xffU);
    }
    pci_scan_capabilities(d);
}

static void pci_scan_mechanism1(void)
{
    int bus,dev,fun,maxfun;
    WORD vendor;
    BYTE hdr;
    for(bus=0; bus<256; ++bus) {
        for(dev=0; dev<32; ++dev) {
            vendor=pci_config_read16((BYTE)bus,(BYTE)dev,0,0x00);
            if(vendor==0xffffU) continue;
            hdr=pci_config_read8((BYTE)bus,(BYTE)dev,0,0x0e);
            maxfun=(hdr&0x80U) ? 8 : 1;
            for(fun=0; fun<maxfun; ++fun) {
                vendor=pci_config_read16((BYTE)bus,(BYTE)dev,(BYTE)fun,0x00);
                if(vendor==0xffffU) continue;
                pci_record_function((BYTE)bus,(BYTE)dev,(BYTE)fun);
            }
        }
    }
}

static void pci_scan_mechanism2(void)
{
    int dev;
    DWORD tmp,flags;
    WORD vendor,device;
    BYTE oldcf8,oldcfa;
    /* Mechanism #2 is retained only for very old hardware.  It exposes bus 0,
     * function 0 devices through C000-CFFF and cannot use the modern retained
     * configuration API, so report devices without pretending full support. */
    flags=get_eflags(); disable();
    oldcf8=inportb(0xcf8); oldcfa=inportb(0xcfa);
    outportb(0xcf8,0x80); outportb(0xcfa,0x00);
    for(dev=0; dev<16; ++dev) {
        tmp=inportd((WORD)(0xc000+dev*0x100));
        vendor=(WORD)(tmp&0xffffU); device=(WORD)(tmp>>16);
        if(vendor!=0xffffU && !(vendor==0 && device==0)) {
            pci.devices_seen++;
            dprintk("PCI2 %d: vendor=%x device=%x\n",dev,vendor,device);
        }
    }
    outportb(0xcf8,oldcf8); outportb(0xcfa,oldcfa);
    set_eflags(flags);
}

static const char *pci_class_name(BYTE c)
{
    switch(c) {
        case 0x01: return "storage";
        case 0x02: return "network";
        case 0x03: return "display";
        case 0x04: return "multimedia";
        case 0x05: return "memory";
        case 0x06: return "bridge";
        case 0x07: return "communication";
        case 0x08: return "system";
        case 0x09: return "input";
        case 0x0c: return "serial-bus";
        default: return "device";
    }
}

void pci_print_device(const PCIDEVICE *d)
{
    if(d==NULL) return;
    dprintk("PCI %d:%d.%d %x:%x class=%x/%x/%x %s hdr=%x irq=%d",
           d->bus,d->device,d->function,d->vendor_id,d->device_id,
           d->class_code,d->subclass,d->prog_if,pci_class_name(d->class_code),
           d->header_type&0x7f,d->irq_line);
    if(d->has_pcie) dprintk(" PCIe");
    if(d->has_msi) dprintk(" MSI");
    if(d->has_msix) dprintk(" MSI-X");
    if(d->has_pm) dprintk(" PM");
    dprintk("\n");
}

void pci_dump_devices(void)
{
    int i;
    printk("PCI: %d function(s), %d retained%s.\n",pci.devices_seen,
           pci.device_count,pci.truncated?" (table full)":"");
    for(i=0; i<pci.device_count; ++i) pci_print_device(&pci_devices[i]);
}

void pci_probe(void)
{
    memset(&pci_devices[0],0,sizeof(pci_devices));
    pci.device_count=0;
    pci.devices_seen=0;
    pci.truncated=0;
    pci.type=0;

    printk("Probing for PCI bus devices: ");
    if(pci_mechanism1_available()) pci.type=1;
    else if(pci_mechanism2_available()) pci.type=2;

    if(!pci.type) {
        printk("no PCI configuration mechanism found.\n");
        return;
    }
    printk("PCI configuration mechanism %d\n",pci.type);
    if(pci.type==1) {
        pci_scan_mechanism1();
        pci_dump_devices();
    } else {
        pci_scan_mechanism2();
        printk("PCI: legacy mechanism #2, %d function(s) seen.\n",pci.devices_seen);
    }
}

int pci_get_device_count(void)
{
    return pci.device_count;
}

const PCIDEVICE *pci_get_device(int index)
{
    if(index<0 || index>=pci.device_count) return NULL;
    return &pci_devices[index];
}

const PCIDEVICE *pci_find_device(WORD vendor,WORD device,int index)
{
    int i,n;
    n=0;
    for(i=0; i<pci.device_count; ++i) {
        if(pci_devices[i].vendor_id==vendor && pci_devices[i].device_id==device) {
            if(n==index) return &pci_devices[i];
            ++n;
        }
    }
    return NULL;
}

const PCIDEVICE *pci_find_class(BYTE class_code,BYTE subclass,BYTE prog_if,int index)
{
    int i,n;
    PCIDEVICE *d;
    n=0;
    for(i=0; i<pci.device_count; ++i) {
        d=&pci_devices[i];
        if(d->class_code==class_code && d->subclass==subclass &&
           (prog_if==0xffU || d->prog_if==prog_if)) {
            if(n==index) return d;
            ++n;
        }
    }
    return NULL;
}

int pci_find_capability(const PCIDEVICE *d,BYTE capability_id)
{
    BYTE p,id,next;
    int hops;
    if(d==NULL || !(d->status&PCI_STATUS_CAP_LIST)) return 0;
    p=d->cap_ptr&0xfc;
    for(hops=0; p>=0x40 && p<=0xfc && hops<48; ++hops) {
        id=pci_config_read8(d->bus,d->device,d->function,p);
        if(id==capability_id) return p;
        next=pci_config_read8(d->bus,d->device,d->function,(BYTE)(p+1))&0xfc;
        if(next==p) break;
        p=next;
    }
    return 0;
}

int pci_get_bar(const PCIDEVICE *d,int barno,PCIBAR *bar)
{
    int maxbars;
    BYTE hdr,off;
    DWORD lo,hi;
    if(d==NULL || bar==NULL) return 1;
    memset(bar,0,sizeof(*bar));
    hdr=d->header_type&0x7f;
    if(hdr==0) maxbars=6;
    else if(hdr==1) maxbars=2;
    else return 1;
    if(barno<0 || barno>=maxbars) return 1;
    off=(BYTE)(0x10+barno*4);
    lo=pci_config_read32(d->bus,d->device,d->function,off);
    if(lo==0 || lo==0xffffffffUL) return 1;
    bar->raw_low=lo;
    bar->valid=1;
    if(lo&1U) {
        bar->io=1;
        bar->base_low=lo&0xfffffffcUL;
        return 0;
    }
    bar->prefetchable=(lo&8U)?1:0;
    bar->base_low=lo&0xfffffff0UL;
    if((lo&6U)==4U) {
        if(barno+1>=maxbars) return 1;
        hi=pci_config_read32(d->bus,d->device,d->function,(BYTE)(off+4));
        bar->is64=1;
        bar->raw_high=hi;
        bar->base_high=hi;
    }
    return 0;
}

int pci_enable_device(const PCIDEVICE *d,int flags)
{
    WORD cmd,want;
    if(d==NULL || pci.type!=1) return 1;
    cmd=pci_config_read16(d->bus,d->device,d->function,0x04);
    want=cmd;
    if(flags&PCI_ENABLE_IO) want|=PCI_COMMAND_IO;
    if(flags&PCI_ENABLE_MEMORY) want|=PCI_COMMAND_MEMORY;
    if(flags&PCI_ENABLE_MASTER) want|=PCI_COMMAND_MASTER;
    if(want!=cmd) pci_config_write16(d->bus,d->device,d->function,0x04,want);
    cmd=pci_config_read16(d->bus,d->device,d->function,0x04);
    return (cmd&want)==want ? 0 : 1;
}

int pci_set_intx_disabled(const PCIDEVICE *d,int disabled)
{
    WORD cmd,want;
    if(d==NULL || pci.type!=1) return 1;
    cmd=pci_config_read16(d->bus,d->device,d->function,0x04);
    want=disabled ? (WORD)(cmd|PCI_COMMAND_INTX_DISABLE) :
                    (WORD)(cmd&~PCI_COMMAND_INTX_DISABLE);
    if(want!=cmd) pci_config_write16(d->bus,d->device,d->function,0x04,want);
    cmd=pci_config_read16(d->bus,d->device,d->function,0x04);
    return disabled ? ((cmd&PCI_COMMAND_INTX_DISABLE)?0:1) :
                      ((cmd&PCI_COMMAND_INTX_DISABLE)?1:0);
}

int pci_device_call(DEVICE_CALL_PARS)
{
    DWORD *size;
    switch(n_call) {
        case DEVICE_CMD_INIT:
        case DEVICE_CMD_SHUTDOWN:
        case DEVICE_CMD_READBLOCK:
        case DEVICE_CMD_WRITEBLOCK:
        case DEVICE_CMD_SEEK:
            break;
        case DEVICE_CMD_GETSIZE:
            size=po1; *size=(DWORD)pci.device_count; break;
        case DEVICE_CMD_GETBLOCKSIZE:
            size=po1; *size=0; break;
        case DEVICE_CMD_GETCH:
        case DEVICE_CMD_PUTCH:
        case DEVICE_CMD_TELL:
            size=po1; if(size) *size=0; break;
        default:
            break;
    }
    return 0;
}

int pci_register_device(void)
{
    if(driver_getdevicebyname("pci")) return 0;
    if(driver_register_new_device("pci",pci_device_call,DEVICE_TYPE_CHAR)<0) {
        printk("PCI: cannot register pci device.\n");
        return 1;
    }
    return 0;
}

void pci_init(void)
{
    if(pci.initialized) return;
    memset(&pci,0,sizeof(pci));
    pci_probe();
    pci.initialized=1;
    if(pci.type) pci_register_device();
    else printk("No PCI bus found.\n");
}
