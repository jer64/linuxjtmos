// ====================================================================================
// driver_devcall.c
// (C) 2002-2004,2017 by Jari Tuominen(jari.t.tuominen@gmail.com).
// Added special by-passing rights for cache manager threads.
// if( (GetThreadType()&1) ) { ... // Cache Manager Process }
// ====================================================================================
//
#include "basdef.h"
#include "sysmem.h"
#include "kernel32.h"
#include "scheduler.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "rtc.h"
#include "floppy.h"
#include "buildnr.h"
#include "driver_api.h"
#include "driver_sys.h"
#include "driver_lock.h"
#include "driver_rw.h" // readblock...
#include "driver_devcall.h"
#include "driver_remdevcall.h"
#include "_virtualfilesystem_devcall.h"

#define DEVICE_CALL_RTC_DEADLINE_SECONDS 3U

/* Debug ownership for the two legacy device_call serialization gates.  The
 * actual ABI-visible lock bits remain device_call_busy and DEVICE_ENTRY.busy.
 */
static int device_call_busy_owner=-1;
static int device_busy_owner[N_MAX_DEVICES];

static void device_call_global_release(int pid)
{
	int flags,owner;

	flags=get_eflags();
	disable();
	owner=device_call_busy_owner;
	if(device_call_busy && owner==pid)
	{
		device_call_busy=0;
		device_call_busy_owner=-1;
		set_eflags(flags);
		return;
	}
	set_eflags(flags);
	if(device_call_busy && owner!=pid)
		dprintk("[LOCK] STALE-RELEASE ignored kind=device-call-global caller_pid=%d owner_pid=%d\n",
			pid,owner);
}

static void device_call_device_release(DEVICE_ENTRY *de,long device_nr,int pid)
{
	int flags,owner=-1;

	if(de==NULL) return;
	flags=get_eflags();
	disable();
	if(device_nr>=0 && device_nr<N_MAX_DEVICES)
		owner=device_busy_owner[device_nr];
	if(de->busy && owner==pid)
	{
		de->busy=0;
		if(device_nr>=0 && device_nr<N_MAX_DEVICES)
			device_busy_owner[device_nr]=-1;
		set_eflags(flags);
		return;
	}
	set_eflags(flags);
	if(de->busy && owner!=pid)
		dprintk("[LOCK] STALE-RELEASE ignored kind=device dnr=%d dev=%s caller_pid=%d owner_pid=%d\n",
			(int)device_nr,de->device_name,pid,owner);
}

static void device_call_wait_relax(void)
{
	int flags=get_eflags();
	if(Multitasking && !PitStorageSafeActive() && (flags&0x200))
		SchedulerWaitPause(1000UL);
	else
	{
		volatile unsigned long i;
		for(i=0;i<128UL;i++) { }
	}
}

/*
 * Wait for the short global device-call gate.  If it remains asserted across
 * three observed CMOS second transitions, treat it as stale and CLEAR it.
 * This is deliberately recovery/deadline semantics rather than an endlessly
 * repeating deadlock warning.
 */
static void device_call_wait_global(long device_nr,long n_function,int pid)
{
	RTC_SECOND_DEADLINE deadline;
	int flags,old_owner;

	rtc_second_deadline_start(&deadline);
	while(device_call_busy)
	{
		if(rtc_second_deadline_poll(&deadline,
					    DEVICE_CALL_RTC_DEADLINE_SECONDS))
		{
			flags=get_eflags();
			disable();
			if(device_call_busy)
			{
				old_owner=device_call_busy_owner;
				device_call_busy=0;
				device_call_busy_owner=-1;
				set_eflags(flags);
				dprintk("[LOCK] DEADLINE-CLEAR kind=device-call-global dnr=%d cmd=%d caller_pid=%d owner_pid=%d rtc_changes=%u\n",
					(int)device_nr,(int)n_function,pid,old_owner,
					deadline.transitions);
			}
			else
				set_eflags(flags);
			break;
		}
		device_call_wait_relax();
	}
}

/* hda and every partsup alias (hda1..hda4) are serialized here through their
 * own DEVICE_ENTRY.busy flag.  A stale device busy bit therefore receives the
 * same three-CMOS-transition clear deadline as the DAPI locks. */
static void device_call_wait_device(DEVICE_ENTRY *de,long device_nr,
				    long n_function,int pid)
{
	RTC_SECOND_DEADLINE deadline;
	int flags,old_owner=-1;

	if(de==NULL) return;
	rtc_second_deadline_start(&deadline);
	while(de->busy)
	{
		if(rtc_second_deadline_poll(&deadline,
					    DEVICE_CALL_RTC_DEADLINE_SECONDS))
		{
			flags=get_eflags();
			disable();
			if(de->busy)
			{
				if(device_nr>=0 && device_nr<N_MAX_DEVICES)
					old_owner=device_busy_owner[device_nr];
				de->busy=0;
				if(device_nr>=0 && device_nr<N_MAX_DEVICES)
					device_busy_owner[device_nr]=-1;
				set_eflags(flags);
				dprintk("[LOCK] DEADLINE-CLEAR kind=device dnr=%d dev=%s cmd=%d caller_pid=%d owner_pid=%d rtc_changes=%u\n",
					(int)device_nr,de->device_name,(int)n_function,pid,
					old_owner,deadline.transitions);
			}
			else
				set_eflags(flags);
			break;
		}
		device_call_wait_relax();
	}
}

// Returns 0 if device is not valid.
int device_call(long device_nr,
		long n_function,
		long par1,long par2,long par3,long par4,
		void *p1,void *p2)
{
	int retval;
	int pid;
	void *ptr;
	DEVICE_ENTRY *de;
	static char str[100];

	//
	DEBLINE

	//
	if(!isValidDevice(device_nr))	return 0;
	pid=GetCurrentThread();

	// Multithread Handling
	//
	// Wait until current operation is finished.
	if( (GetThreadType(pid)&1) ) goto past1;
	device_call_wait_global(device_nr,n_function,pid);
past1:

	//
	disable();
	device_call_busy=1;
	device_call_busy_owner=pid;

	//
	de=driver_getdevice(device_nr);
	// Skip if device does not exist (is free).  Never leak the global gate.
	if(de==NULL || de->isfree)
	{
		device_call_global_release(pid);
		enable();
		return -123;
	}

	//
	switch(n_function)
	{
		case DEVICE_CMD_OPEN:
		case DEVICE_CMD_CREAT:
		case DEVICE_CMD_CLOSE:
		case DEVICE_CMD_READ:
		case DEVICE_CMD_WRITE:
		case DEVICE_CMD_LSEEK:
		case DEVICE_CMD_READDIR:
		case DEVICE_CMD_MKDIR:
		case DEVICE_CMD_UNLINK:
		case DEVICE_CMD_CHDIR:
		case DEVICE_CMD_GETCWD:
		case DEVICE_CMD_MKFS:
		ptr = (void *)virtual_file_system_device_call;
		break;
		//
		case DEVICE_CMD_READBLOCK:
		de->reads++;
		ptr = de->device_call;
		break;
		case DEVICE_CMD_READBLOCKS:
		de->reads += par2>0 ? par2 : 0;
		ptr = de->device_call;
		break;
		case DEVICE_CMD_WRITEBLOCK:
		de->writes++;
		ptr = de->device_call;
		break;
		case DEVICE_CMD_WRITEBLOCKS:
		de->writes += par2>0 ? par2 : 0;
		ptr = de->device_call;
		break;
		//
		default:
		// Get jump offset
		ptr = de->device_call;
		break;
	}

	// Check jump [offset] pointer
	if(ptr==NULL && (de->type&DEVICE_TYPE_NONKERNELDRV)==0)
	{
		device_call_global_release(pid);
		enable();
		return 0;
	}

	/* V68.161: a corrupted kernel-local DEVICE_ENTRY must never become an
	 * arbitrary indirect branch.  All cs==0 callbacks are linked into the
	 * resident kernel text image.  Reject anything outside that range before
	 * enabling interrupts or invoking it. */
	if(de->cs==0 && ptr!=NULL)
	{
		DWORD callad=JTM_PTR_TO_DWORD(ptr);
		DWORD textend=(DWORD)&etext;
		if(callad<JTMOS_KERNEL_LOAD_PHYS || callad>=textend)
		{
			dprintk("DEVICE/CALL: refusing corrupt callback dnr=%d dev=%s cmd=%d ptr=0x%x text=[0x%x,0x%x).\n",
			        (int)device_nr,de->device_name,(int)n_function,
			        (unsigned)callad,(unsigned)JTMOS_KERNEL_LOAD_PHYS,
			        (unsigned)textend);
			device_call_global_release(pid);
			enable();
			return -124;
		}
	}

	// Enable interrupts
	enable();

	// Wait until the device is free
	if( (GetThreadType(pid)&1) ) goto past2;
	device_call_wait_device(de,device_nr,n_function,pid);
past2:

	// Reserve the device
	de->busy=1;
	if(device_nr>=0 && device_nr<N_MAX_DEVICES)
		device_busy_owner[device_nr]=pid;

	//
	device_call_global_release(pid);

	// Is it a non-kernel mode driver?
	if( (de->type&DEVICE_TYPE_NONKERNELDRV) && 1==0 )
	{
		// REMOTE DEVICE CALL
		// 1) Non-kernel mode device driver call,
		// will use messages. *remdevcall*
		retval = remoteDeviceCall(device_nr, de->pid, n_function,
					par1,par2,par3,par4, p1,p2);
	}
	else
	// Call kernel mode
	if(de->cs==0)
	{
		// 2) Kernel mode device driver call.
		// (KERNEL LOCAL CALL)
		retval = (*(int (*)(DEVICE_CALL_PARS)) ptr)(n_function,par1,par2,par3,par4,p1,p2);
	}
	else
	{
		// 3) Custom mode device driver call
		// Far call, applications/drivers.
		// (NOT IMPLEMENTED YET, USE MESSAGES INSTEAD.).
		retval = fardcall(ptr,de->cs,
			n_function,par1,par2,par3,par4,p1,p2);
	}

	// We are done, unlock the device.
	device_call_device_release(de,device_nr,pid);

	//
	return retval;
}

