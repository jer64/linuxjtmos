/*
 * Gravis UltraSound GF1 support for JTMOS.
 * (C) 2002-2003, 2026 by Jari Tuominen.
 *
 * V58 implements a conservative 8-bit mono streaming backend using GUS DRAM
 * and one GF1 voice.  It deliberately avoids a not-yet-configured GUS DMA/IRQ
 * routing dependency: the CPU fills a bounded wavetable block and a worker
 * observes voice completion while yielding to the scheduler.
 */
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "threads.h"
#include "audio.h"
#include "driver_sys.h"
#include "driver_api.h"
#include "gus.h"

#define GUS_STREAM_BYTES (16*1024)
#define GUS_STREAM_VOICE 0
#define GUS_MAX_CLASSIC_RAM (1024*1024UL)

DWORD GUSBASE = 0x240;
DWORD GUSMEM = 0;
int nr_voices = 14;
int gusIRQ = 5;
THREAD gusThread;

static int gus_ready = 0;
static int gus_thread_started = 0;
static volatile int gus_playing = 0;
static volatile int gus_block_bytes = 0;

static const int freq_div_table[] = {
    44100, 41160, 38587, 36317, 34300, 32494, 30870, 29400, 28063,
    26843, 25725, 24696, 23746, 22866, 22050, 21289, 20580, 19916, 19293
};

static void gus_select_voice(BYTE voice)
{
    outportb(u_Voice, voice & 31);
}

static void gus_write8(int reg, BYTE value)
{
    outportb(u_Command, reg & 0xff);
    outportb(u_DataHi, value);
}

static void gus_write16(int reg, WORD value)
{
    outportb(u_Command, reg & 0xff);
    outportw(u_DataLo, value);
}

static BYTE gus_read8(int reg)
{
    outportb(u_Command, reg & 0xff);
    return inportb(u_DataHi);
}

static WORD gus_read16(int reg)
{
    outportb(u_Command, reg & 0xff);
    return inportw(u_DataLo);
}

void gus_delay(void)
{
    /* GF1 indirect registers need only a very small settling delay. */
    inportb(0x80);
    inportb(0x80);
}

int gus_peek(int loc)
{
    if(loc < 0) return -1;
    gus_write16(0x43, (WORD)(loc & 0xffff));
    gus_write8(0x44, (BYTE)((((DWORD)loc) >> 16) & 0xff));
    return inportb(u_DRAMIO);
}

void gus_poke(int loc,BYTE b)
{
    if(loc < 0) return;
    gus_write16(0x43, (WORD)(loc & 0xffff));
    gus_write8(0x44, (BYTE)((((DWORD)loc) >> 16) & 0xff));
    outportb(u_DRAMIO, b);
}

static void gus_write_address(int high_reg, int low_reg, DWORD address)
{
    gus_write16(high_reg, (WORD)((address >> 7) & 0x1fff));
    gus_write16(low_reg, (WORD)((address & 0x7f) << 9));
}

void gus_setfreq(BYTE voice,WORD frequency)
{
    DWORD fc;
    int divisor;
    int voices = nr_voices;

    if(voices < 14) voices = 14;
    if(voices > 32) voices = 32;
    divisor = freq_div_table[voices - 14];
    fc = ((((DWORD)frequency << 9) + ((DWORD)divisor >> 1)) / (DWORD)divisor) << 1;
    if(fc > 0xffffUL) fc = 0xffffUL;
    gus_select_voice(voice);
    gus_write16(0x01, (WORD)fc);
}

void gus_setvolume(BYTE voice,WORD volume)
{
    /* Public value is the 12-bit EEEE MMMMMMMM form.  GF1 current-volume
     * register stores it in bits 15..4. */
    if(volume > 0x0fff) volume = 0x0fff;
    gus_select_voice(voice);
    gus_write8(0x0d, 0x03); /* stop volume ramp */
    gus_write16(0x09, (WORD)(volume << 4));
}

void gus_setbalance(BYTE voice,BYTE balance)
{
    if(balance > 15) balance = 15;
    gus_select_voice(voice);
    gus_write8(0x0c, balance);
}

DWORD gus_voicepos(BYTE voice)
{
    WORD hi, lo;
    gus_select_voice(voice);
    hi = gus_read16(0x8a);
    lo = gus_read16(0x8b);
    return (((DWORD)(hi & 0x1fff)) << 7) | ((DWORD)lo >> 9);
}

static int gus_voice_stopped(BYTE voice)
{
    BYTE ctrl;
    gus_select_voice(voice);
    ctrl = gus_read8(0x80);
    return (ctrl & 0x01) != 0;
}

void gus_stopvoice(BYTE voice)
{
    BYTE ctrl;
    gus_select_voice(voice);
    ctrl = gus_read8(0x80);
    ctrl = (BYTE)((ctrl & 0xdc) | 0x03);
    gus_write8(0x00, ctrl);
    gus_delay();
    gus_write8(0x00, ctrl);
}

void gus_playvoice(BYTE voice, BYTE mode, int vbegin, int vstart, int vend)
{
    DWORD begin = (DWORD)vbegin;
    DWORD start = (DWORD)vstart;
    DWORD end = (DWORD)vend;

    if(end <= start)
        return;
    gus_select_voice(voice);
    gus_write_address(0x0a, 0x0b, begin);
    gus_write_address(0x02, 0x03, start);
    gus_write_address(0x04, 0x05, end);
    gus_write8(0x00, (BYTE)(mode & 0xfc));
}

static void gus_reset(void)
{
    int voice;

    gus_write8(0x4c, 0x00);
    UsecSleep(1000);
    gus_write8(0x4c, 0x01);
    UsecSleep(1000);

    gus_write8(0x41, 0x00); /* DRAM DMA off */
    gus_write8(0x45, 0x00); /* timers off */
    gus_write8(0x49, 0x00); /* sampling off */

    nr_voices = 14;
    gus_write8(0x0e, (BYTE)(0xc0 | (nr_voices - 1)));
    UsecSleep(100);

    for(voice = 0; voice < 32; ++voice)
    {
        gus_select_voice((BYTE)voice);
        gus_write8(0x00, 0x03);
        gus_write8(0x0d, 0x03);
        gus_write16(0x09, 0);
    }

    /* Run + DAC + master IRQ enable.  The streaming path itself is polling,
     * but 0x07 is the normal operational GF1 reset value. */
    gus_write8(0x4c, 0x07);

    /* Classic GUS mixer bit 1 mutes line output when set. */
    outportb(u_Mixer, inportb(u_Mixer) & (BYTE)~0x02);
}

int gus_testloc(DWORD ad)
{
    BYTE old, a, b;
    old = (BYTE)gus_peek((int)ad);
    gus_poke((int)ad, 0x55); a = (BYTE)gus_peek((int)ad);
    gus_poke((int)ad, 0xaa); b = (BYTE)gus_peek((int)ad);
    gus_poke((int)ad, old);
    return a == 0x55 && b == 0xaa;
}

DWORD gus_findmem(void)
{
    DWORD ad;
    BYTE old0, oldad;

    old0 = (BYTE)gus_peek(0);
    for(ad = 64*1024UL; ad <= GUS_MAX_CLASSIC_RAM; ad += 64*1024UL)
    {
        if(ad == GUS_MAX_CLASSIC_RAM)
        {
            /* 1 MiB is the full classic address space: reaching it means all
             * prior 64K banks were distinct. */
            gus_poke(0, old0);
            return GUS_MAX_CLASSIC_RAM;
        }
        oldad = (BYTE)gus_peek((int)ad);
        gus_poke(0, 0x35);
        gus_poke((int)ad, 0xca);
        if(gus_peek(0) != 0x35 || gus_peek((int)ad) != 0xca)
        {
            gus_poke(0, old0);
            return ad;
        }
        gus_poke((int)ad, oldad);
        gus_poke(0, old0);
    }
    return GUS_MAX_CLASSIC_RAM;
}

int gus_detect(void)
{
    BYTE old0, old100;

    gus_write8(0x4c, 0x00);
    UsecSleep(1000);
    gus_write8(0x4c, 0x01);
    UsecSleep(1000);

    old0 = (BYTE)gus_peek(0);
    old100 = (BYTE)gus_peek(0x100);
    gus_poke(0, 0xaa);
    gus_poke(0x100, 0x55);
    if(gus_peek(0) != 0xaa || gus_peek(0x100) != 0x55)
        return 0;
    gus_poke(0, old0);
    gus_poke(0x100, old100);
    GUSMEM = gus_findmem();
    return GUSMEM >= 64*1024UL;
}

static int gus_fill_block(void)
{
    int i, n;
    static BYTE temp[1024];
    int total = 0;

    while(total < GUS_STREAM_BYTES)
    {
        n = audio_fifo_read(temp, sizeof(temp));
        if(n <= 0)
            break;
        for(i = 0; i < n; ++i)
            gus_poke(total + i, temp[i]);
        total += n;
    }
    return total;
}

void gus_kick(void)
{
    int bytes;
    int flags;

    if(!gus_ready)
        return;
    flags = get_eflags();
    disable();
    if(gus_playing)
    {
        set_eflags(flags);
        return;
    }
    gus_playing = 2;
    set_eflags(flags);

    bytes = gus_fill_block();
    if(bytes <= 0)
    {
        gus_playing = 0;
        return;
    }

    gus_stopvoice(GUS_STREAM_VOICE);
    gus_setbalance(GUS_STREAM_VOICE, 7);
    gus_setvolume(GUS_STREAM_VOICE, 0x0d00);
    gus_setfreq(GUS_STREAM_VOICE, (WORD)(audio.frequency ? audio.frequency : 11025));
    gus_playvoice(GUS_STREAM_VOICE, 0x00, 0, 0, bytes - 1);
    gus_block_bytes = bytes;
    gus_playing = 1;
    audio.playing = 1;
}

void gus_stop(void)
{
    if(!gus_ready)
        return;
    gus_stopvoice(GUS_STREAM_VOICE);
    gus_block_bytes = 0;
    gus_playing = 0;
    audio.playing = 0;
}

int gus_is_ready(void) { return gus_ready; }
int gus_active_bytes(void) { return gus_playing == 1 ? gus_block_bytes : 0; }

void gusProcess(void)
{
    for(;;)
    {
        if(gus_playing == 1 && gus_voice_stopped(GUS_STREAM_VOICE))
        {
            int done = gus_block_bytes;
            gus_block_bytes = 0;
            gus_playing = 0;
            if(done > 0)
                audio_notify_played(done);
            gus_kick();
        }
        else if(!gus_playing && audio_fifo_count() > 0)
            gus_kick();

        if(gus_playing || audio_fifo_count()>0) SchedulerWaitPause(2000UL);
        else SchedulerWaitPause(10000UL);
    }
}

static void init_gusThread(void)
{
    if(gus_thread_started || !Multitasking)
        return;
    ThreadCreateStack(&gusThread, JTMOS_MIN_DYNAMIC_STACK);
    gusThread.pid = CreateThreadA(gusThread.stack, gusThread.l_stack, gusProcess);
    SetThreadTerminal(gusThread.pid, 6);
    IdentifyThread(gusThread.pid, "KGUS-AUDIO");
    gus_thread_started = 1;
}

void gus_irqhandler(void)
{
    /* The V58 PCM backend does not route GF1 IRQs, but keep a safe handler for
     * future wavetable IRQ use: read status and send correct PIC EOIs. */
    (void)inportb(u_IrqStatus);
    pic_send_eoi((unsigned short)gusIRQ);
}

int gus_device_call(DEVICE_CALL_PARS)
{
    DWORD *size;
    switch(n_call)
    {
        case DEVICE_CMD_GETSIZE:
            size = po1; if(size) size[0] = GUSMEM; break;
        case DEVICE_CMD_GETBLOCKSIZE:
            size = po1; if(size) size[0] = 0; break;
        default:
            break;
    }
    return 0;
}

static int gus_register_device(void)
{
    if(driver_getdevicebyname("gus"))
        return 0;
    driver_register_new_device("gus", gus_device_call, DEVICE_TYPE_CHAR);
    return 0;
}

int gus_init(void)
{
    static const WORD bases[] = { 0x240,0x220,0x260,0x280,0x2a0,0x2c0,0x2e0,0x300,0x210,0x230,0x250 };
    int i;

    if(gus_ready)
        return 1;

    printk("Gravis UltraSound GF1 driver 2.0: probing.\n");
    for(i = 0; i < (int)(sizeof(bases)/sizeof(bases[0])); ++i)
    {
        GUSBASE = bases[i];
        if(gus_detect())
        {
            gus_reset();
            gus_register_device();
            gus_ready = 1;
            init_gusThread();
            printk("GUS: GF1 at 0x%x, %dK DRAM, polling wavetable stream.\n",
                   GUSBASE, (int)(GUSMEM/1024));
            return 1;
        }
    }
    printk("GUS: no GF1-compatible card detected.\n");
    return 0;
}
