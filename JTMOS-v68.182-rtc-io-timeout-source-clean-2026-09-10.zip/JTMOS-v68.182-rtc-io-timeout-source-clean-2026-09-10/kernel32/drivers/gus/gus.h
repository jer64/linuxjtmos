#ifndef __INCLUDED_GUS_H__
#define __INCLUDED_GUS_H__

#include "kernel32.h"

#define gus_base GUSBASE
#define u_Base             (gus_base + 0x000)
#define u_Mixer            u_Base
#define u_Status           (gus_base + 0x006)
#define u_TimerControl     (gus_base + 0x008)
#define u_TimerData        (gus_base + 0x009)
#define u_IRQDMAControl    (gus_base + 0x00b)
#define u_MidiControl      (gus_base + 0x100)
#define u_MidiData         (gus_base + 0x101)
#define u_Voice            (gus_base + 0x102)
#define u_Command          (gus_base + 0x103)
#define u_DataLo           (gus_base + 0x104)
#define u_DataHi           (gus_base + 0x105)
#define u_IrqStatus        u_Status
#define u_DRAMIO           (gus_base + 0x107)

extern DWORD GUSBASE,GUSMEM;

int gus_init(void);
int gus_peek(int loc);
void gus_poke(int loc,BYTE b);
int gus_detect(void);
void gus_delay(void);
void gus_setbalance(BYTE voice,BYTE balance);
void gus_setfreq(BYTE voice,WORD frequency);
DWORD gus_voicepos(BYTE voice);
void gus_stopvoice(BYTE voice);
void gus_playvoice(BYTE voice,BYTE mode,int vbegin,int vstart,int vend);
void gus_setvolume(BYTE voice,WORD volume);
int gus_testloc(DWORD ad);
DWORD gus_findmem(void);
extern void gus_ISR(void);
void gus_irqhandler(void);

/* Generic-audio backend API. */
int gus_is_ready(void);
int gus_active_bytes(void);
void gus_kick(void);
void gus_stop(void);

#endif
