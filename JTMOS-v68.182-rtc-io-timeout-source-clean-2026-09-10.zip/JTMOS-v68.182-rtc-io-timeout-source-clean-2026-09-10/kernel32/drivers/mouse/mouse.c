//-----------------------------------------------------------------------------
// mouse.c - GENERIC MOUSE DRIVER.
// (C) 2006 Jari Tuominen.
//-----------------------------------------------------------------------------
#include "basdef.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "ega.h"
#include "syssh.h"
#include "io.h"
#include "floppy.h"
#include "dma.h"
#include "cpu.h"
#include "mouse.h"
#include "ps2mouse.h"
#include "kernel32.h"
#include "32x32_arrow.h"
#include "dispadmin.h"
#include "sysgfx.h"
#include "driver_sys.h"
#include "delay.h"
#include "vesa.h"
#include "input_policy.h"
#if JTMOS_MOD_PCI
#include "usb_input.h"
#endif

//
MOUSE mouse;

//
int mouse_isVisible(void)
{
        return mouse.isVisible;
}


// SET MOUSE FRAME (X1,Y1)-(X2,Y2)
void mouse_setframe(long x1,long y1,long x2,long y2)
{
        mouse.frame.x1=x1;
        mouse.frame.y1=y1;
        mouse.frame.x2=x2;
        mouse.frame.y2=y2;
}

// SET MOUSE POSITION (X,Y)
void mouse_setposition(long x,long y)
{
	//mouse_first_time=1;

        mouse.x=x;
        mouse.y=y;
        mouse.lx=-1;
        mouse.ly=-1;
}


/*
 * Poll the active pointing-device backend for queued input.  IRQ12 remains
 * the preferred PS/2 path, but this fallback makes GUI polling robust when
 * the slave-PIC interrupt is temporarily masked or a virtual machine has
 * already queued AUX bytes before the IRQ gate is live.
 */
int mouse_poll(void)
{
        int n=0;
#if JTMOS_MOD_PCI
        if(input_policy_mouse_backend()==INPUT_BACKEND_USB || usb_input.transport_ready)
                n+=usb_input_poll();
#endif
        if(input_policy_mouse_backend()!=INPUT_BACKEND_USB && ps2mouse_enabled)
                n+=ps2mouse_poll();
        return n;
}

/* Return the logical button mask used by userspace.  mouse_union is a generic
 * pointing-device policy, not a PS/2-specific quirk: when enabled, either
 * physical left or right becomes logical primary button 1, while middle and
 * extra buttons are preserved.  Clearing bit 1 avoids simultaneous left+right
 * semantics in GraOS. */
int mouse_getbuttons(void)
{
        int buttons=mouse.buttons;
        if(mouse_union && (buttons & 0x03))
                buttons=(buttons & ~0x03) | 0x01;
        return buttons;
}

//
// Wrappers:
void mouse_modeChange(int vmode)
{
        /*
         * While the VESA LFB is mirroring the traditional 80x25 console,
         * the pointing-device coordinate system must remain the text-mode
         * 80x25 grid.  boot32 may already be in VBE 0x101, so DISPADMIN's
         * hardware mode alone is not enough to decide this.
         */
        if(vesa_text_console_enabled)
                vmode=3;

        switch(vmode)
        {
                // 80x25 textmode, 2 colors
                case 3:
                mouse_setframe(0,0,79,24);
                mouse_setposition(40,12);
                break;

                // 640x480, graphic mode,       2 colors
                // --                           16 colors
                // 320x200, graphic mode,       256 colors
                default:
                case 0x11:
                case 0x12:
                case 0x13:
                mouse_setframe(0,0,639,479);
                mouse_setposition(320,240);
                break;
        }

	// Report to different mouse drivers specifically
	ps2mouse_modeChange(vmode);
}

// Some aliases
void mouse_showmouse(void)
{
        mouse_showcursor();
}
// Some aliases
void mouse_hidemouse(void)
{
        mouse_hidecursor();
}
//

//
void mouse_hidecursor(void)
{
        mouse.isVisible=0;
}

//
void mouse_showcursor(void)
{
        mouse.isVisible=1;
}

