/*
 * kyber.c - low-overhead latency-oriented JTMOS block scheduler
 *
 * JTMOS adaptation:
 *  - READ and WRITE scheduling domains
 *  - 2 ms read / 10 ms synchronous-write latency targets
 *  - bounded per-domain admission depths (tokens)
 *  - 16-read / 8-write batching with starvation deadlines
 *  - p90 I/O and p99 total-latency histograms
 *  - feedback-driven queue-depth adjustment
 *  - 25% global request-pool reservation for reads
 *
 * The legacy JTMOS device ABI performs a block command synchronously.  Thus
 * only one request per physical queue is dispatched into the old driver at a
 * time.  Multiple callers may nevertheless queue concurrently and Kyber can
 * choose the next request before the direct-access lock is taken.  A future
 * NVMe driver can reuse the policy while replacing the dispatch backend with
 * true asynchronous submissions.
 */
#include "basdef.h"
#include "kernel32.h"
#include "scheduler.h"
#include "macrodef.h"
#include "pit.h"
#include "threads.h"
#include "driver_sys.h"
#include "driver_rw.h"
#include "kyber.h"

#define KYBER_REQUESTS             64
#define KYBER_READ_RESERVE         16
#define KYBER_LAT_BUCKETS           8
#define KYBER_GOOD_BUCKETS          4
#define KYBER_ADJUST_SAMPLES       64
#define KYBER_ADJUST_US       1000000UL

#define KYBER_READ_TARGET_US     2000UL
#define KYBER_WRITE_TARGET_US   10000UL
#define KYBER_READ_BATCH           16
#define KYBER_WRITE_BATCH           8
#define KYBER_READ_INITIAL_DEPTH   16
#define KYBER_WRITE_INITIAL_DEPTH   8
#define KYBER_READ_MAX_DEPTH       48
#define KYBER_WRITE_MAX_DEPTH      32

#define KR_FREE        0
#define KR_PENDING     1
#define KR_DISPATCHED  2
#define KR_DONE        3

typedef struct kyber_request {
    int state;
    int next;
    int queue_key;
    int dnr;
    int domain;
    long block_nr;
    int count;
    BYTE *buf;
    int result;
    int owner_pid;
    DWORD submit_us;
    DWORD dispatch_us;
    DWORD sequence;
} KYBER_REQUEST;

typedef struct kyber_device_state {
    int initialized;
    int enabled;
    int manual_override;
    int dispatch_busy;
    int barrier;

    int head[JTMOS_KYBER_DOMAINS];
    int tail[JTMOS_KYBER_DOMAINS];
    unsigned int queued[JTMOS_KYBER_DOMAINS];
    unsigned int outstanding[JTMOS_KYBER_DOMAINS];

    unsigned int depth[JTMOS_KYBER_DOMAINS];
    unsigned int max_depth[JTMOS_KYBER_DOMAINS];
    unsigned int batch_limit[JTMOS_KYBER_DOMAINS];
    unsigned int current_domain;
    unsigned int batch_count;

    DWORD target_us[JTMOS_KYBER_DOMAINS];
    unsigned int total_hist[JTMOS_KYBER_DOMAINS][KYBER_LAT_BUCKETS];
    unsigned int io_hist[JTMOS_KYBER_DOMAINS][KYBER_LAT_BUCKETS];
    unsigned int samples[JTMOS_KYBER_DOMAINS];
    int last_p99[JTMOS_KYBER_DOMAINS];
    DWORD last_adjust_us;

    DWORD submitted[JTMOS_KYBER_DOMAINS];
    DWORD completed[JTMOS_KYBER_DOMAINS];
    DWORD errors[JTMOS_KYBER_DOMAINS];
    DWORD avg_latency_us[JTMOS_KYBER_DOMAINS];
    DWORD max_latency_us[JTMOS_KYBER_DOMAINS];
    DWORD depth_adjustments;
} KYBER_DEVICE_STATE;

static KYBER_REQUEST kyber_requests[KYBER_REQUESTS];
static KYBER_DEVICE_STATE kyber_devices[N_MAX_DEVICES];
static DWORD kyber_sequence = 1;
static int kyber_initialized = 0;

static int kyber_irq_lock(void)
{
    int flags = get_eflags();
    disable();
    return flags;
}

static void kyber_irq_unlock(int flags)
{
    set_eflags(flags);
}

static int kyber_prefix(const char *s, const char *prefix)
{
    if(s == NULL || prefix == NULL)
        return 0;
    while(*prefix)
    {
        if(*s++ != *prefix++)
            return 0;
    }
    return 1;
}

static int kyber_name_is_fast_storage(const char *name)
{
    if(name == NULL)
        return 0;

    /* Current JTMOS fixed disk plus conventional future fast-storage names. */
    if(kyber_prefix(name, "hda") || kyber_prefix(name, "hdb") ||
       kyber_prefix(name, "hdc") || kyber_prefix(name, "hdd") ||
       kyber_prefix(name, "nvme") || kyber_prefix(name, "sd") ||
       kyber_prefix(name, "vd"))
        return 1;

    return 0;
}

/* Map partition-style names to the physical queue when possible. */
static int kyber_queue_key(int dnr)
{
    DEVICE_ENTRY *de;
    char base[4];
    int key;

    de = driver_getdevice(dnr);
    if(de == NULL)
        return dnr;

    if((kyber_prefix(de->device_name, "hda") ||
        kyber_prefix(de->device_name, "hdb") ||
        kyber_prefix(de->device_name, "hdc") ||
        kyber_prefix(de->device_name, "hdd")) &&
       de->device_name[0] && de->device_name[1] && de->device_name[2])
    {
        base[0] = de->device_name[0];
        base[1] = de->device_name[1];
        base[2] = de->device_name[2];
        base[3] = 0;
        key = driver_getdevicenrbyname(base);
        if(key >= 0)
            return key;
    }

    return dnr;
}

static void kyber_state_defaults(int key)
{
    KYBER_DEVICE_STATE *ks;
    DEVICE_ENTRY *de;

    if(key < 0 || key >= N_MAX_DEVICES)
        return;

    ks = &kyber_devices[key];
    if(ks->initialized)
        return;

    xmemset((char *)ks, 0, (int)sizeof(*ks));
    ks->head[JTMOS_KYBER_READ] = -1;
    ks->head[JTMOS_KYBER_WRITE] = -1;
    ks->tail[JTMOS_KYBER_READ] = -1;
    ks->tail[JTMOS_KYBER_WRITE] = -1;

    ks->target_us[JTMOS_KYBER_READ] = KYBER_READ_TARGET_US;
    ks->target_us[JTMOS_KYBER_WRITE] = KYBER_WRITE_TARGET_US;
    ks->depth[JTMOS_KYBER_READ] = KYBER_READ_INITIAL_DEPTH;
    ks->depth[JTMOS_KYBER_WRITE] = KYBER_WRITE_INITIAL_DEPTH;
    ks->max_depth[JTMOS_KYBER_READ] = KYBER_READ_MAX_DEPTH;
    ks->max_depth[JTMOS_KYBER_WRITE] = KYBER_WRITE_MAX_DEPTH;
    ks->batch_limit[JTMOS_KYBER_READ] = KYBER_READ_BATCH;
    ks->batch_limit[JTMOS_KYBER_WRITE] = KYBER_WRITE_BATCH;
    ks->current_domain = JTMOS_KYBER_READ;
    ks->last_p99[JTMOS_KYBER_READ] = -1;
    ks->last_p99[JTMOS_KYBER_WRITE] = -1;
    ks->last_adjust_us = PitGetUsec();

    de = driver_getdevice(key);
    if(de != NULL && (de->type & DEVICE_TYPE_BLOCK) &&
       kyber_name_is_fast_storage(de->device_name))
        ks->enabled = 1;

    ks->initialized = 1;
}

void kyber_init(void)
{
    int i;

    xmemset((char *)kyber_requests, 0, (int)sizeof(kyber_requests));
    xmemset((char *)kyber_devices, 0, (int)sizeof(kyber_devices));
    for(i = 0; i < KYBER_REQUESTS; ++i)
        kyber_requests[i].next = -1;
    kyber_sequence = 1;
    kyber_initialized = 1;

    printk("Kyber I/O scheduler: latency domains enabled (read=%dus, write=%dus, pool=%d).\n",
           KYBER_READ_TARGET_US, KYBER_WRITE_TARGET_US, KYBER_REQUESTS);
}

static int kyber_free_slots_locked(void)
{
    int i;
    int free_count = 0;
    for(i = 0; i < KYBER_REQUESTS; ++i)
        if(kyber_requests[i].state == KR_FREE)
            ++free_count;
    return free_count;
}

static int kyber_find_free_locked(void)
{
    int i;
    for(i = 0; i < KYBER_REQUESTS; ++i)
        if(kyber_requests[i].state == KR_FREE)
            return i;
    return -1;
}

static void kyber_push_locked(KYBER_DEVICE_STATE *ks, int domain, int idx)
{
    KYBER_REQUEST *kr = &kyber_requests[idx];
    kr->next = -1;
    if(ks->tail[domain] >= 0)
        kyber_requests[ks->tail[domain]].next = idx;
    else
        ks->head[domain] = idx;
    ks->tail[domain] = idx;
    ++ks->queued[domain];
}

static int kyber_pop_locked(KYBER_DEVICE_STATE *ks, int domain)
{
    int idx = ks->head[domain];
    if(idx < 0)
        return -1;
    ks->head[domain] = kyber_requests[idx].next;
    if(ks->head[domain] < 0)
        ks->tail[domain] = -1;
    kyber_requests[idx].next = -1;
    if(ks->queued[domain])
        --ks->queued[domain];
    return idx;
}

static int kyber_oldest_expired_locked(KYBER_DEVICE_STATE *ks, DWORD now)
{
    int rd = ks->head[JTMOS_KYBER_READ];
    int wr = ks->head[JTMOS_KYBER_WRITE];
    DWORD rd_age = 0;
    DWORD wr_age = 0;
    int rd_exp = 0;
    int wr_exp = 0;

    if(rd >= 0)
    {
        rd_age = now - kyber_requests[rd].submit_us;
        rd_exp = rd_age >= (ks->target_us[JTMOS_KYBER_READ] * 4U);
    }
    if(wr >= 0)
    {
        wr_age = now - kyber_requests[wr].submit_us;
        wr_exp = wr_age >= (ks->target_us[JTMOS_KYBER_WRITE] * 4U);
    }

    if(rd_exp && wr_exp)
        return (rd_age >= wr_age) ? JTMOS_KYBER_READ : JTMOS_KYBER_WRITE;
    if(rd_exp)
        return JTMOS_KYBER_READ;
    if(wr_exp)
        return JTMOS_KYBER_WRITE;
    return -1;
}

static int kyber_select_domain_locked(KYBER_DEVICE_STATE *ks, DWORD now)
{
    int expired;
    int current;
    int other;

    expired = kyber_oldest_expired_locked(ks, now);
    if(expired >= 0)
        return expired;

    current = (int)ks->current_domain;
    other = (current == JTMOS_KYBER_READ) ? JTMOS_KYBER_WRITE : JTMOS_KYBER_READ;

    if(ks->head[current] >= 0 && ks->batch_count < ks->batch_limit[current])
        return current;
    if(ks->head[other] >= 0)
        return other;
    if(ks->head[current] >= 0)
        return current;
    return -1;
}

static unsigned int kyber_latency_bucket(DWORD latency, DWORD target)
{
    DWORD scaled;
    if(target == 0)
        target = 1;
    if(latency == 0)
        return 0;
    /* Avoid a 32-bit overflow in latency*4 on long stalls. Anything at
     * or above twice the target already belongs in the last bucket. */
    if(latency >= target * 2U)
        return KYBER_LAT_BUCKETS - 1;
    scaled = (latency * 4U) / target;
    if(scaled >= KYBER_LAT_BUCKETS)
        scaled = KYBER_LAT_BUCKETS - 1;
    return (unsigned int)scaled;
}

static int kyber_percentile(unsigned int *buckets, unsigned int percentile)
{
    unsigned int total = 0;
    unsigned int need;
    unsigned int i;

    for(i = 0; i < KYBER_LAT_BUCKETS; ++i)
        total += buckets[i];
    if(total == 0)
        return -1;

    need = (total * percentile + 99U) / 100U;
    for(i = 0; i < KYBER_LAT_BUCKETS; ++i)
    {
        if(need <= buckets[i])
            return (int)i;
        need -= buckets[i];
    }
    return KYBER_LAT_BUCKETS - 1;
}

static unsigned int kyber_clamp_depth(unsigned int depth, unsigned int max_depth)
{
    if(depth < 1U)
        depth = 1U;
    if(depth > max_depth)
        depth = max_depth;
    return depth;
}

static void kyber_adjust_locked(KYBER_DEVICE_STATE *ks, DWORD now)
{
    unsigned int all_samples;
    int d;
    int congestion = 0;
    int p90_io[JTMOS_KYBER_DOMAINS];
    int p99_total[JTMOS_KYBER_DOMAINS];

    all_samples = ks->samples[JTMOS_KYBER_READ] + ks->samples[JTMOS_KYBER_WRITE];
    if(all_samples < KYBER_ADJUST_SAMPLES &&
       (DWORD)(now - ks->last_adjust_us) < KYBER_ADJUST_US)
        return;
    if(all_samples == 0)
    {
        ks->last_adjust_us = now;
        return;
    }

    for(d = 0; d < JTMOS_KYBER_DOMAINS; ++d)
    {
        p90_io[d] = kyber_percentile(ks->io_hist[d], 90);
        p99_total[d] = kyber_percentile(ks->total_hist[d], 99);
        if(p90_io[d] >= KYBER_GOOD_BUCKETS)
            congestion = 1;
    }

    for(d = 0; d < JTMOS_KYBER_DOMAINS; ++d)
    {
        int p99 = p99_total[d];
        unsigned int old_depth;
        unsigned int new_depth;

        if(p99 < 0)
            p99 = ks->last_p99[d];
        else
            ks->last_p99[d] = p99;
        if(p99 < 0)
            continue;

        /* Same control idea as Kyber: during device congestion, domains with
         * good total latency are throttled harder while a starved/bad domain
         * gets more tokens. Without congestion, only a bad-latency domain is
         * opened up. */
        if(congestion || p99 >= KYBER_GOOD_BUCKETS)
        {
            old_depth = ks->depth[d];
            new_depth = (old_depth * (unsigned int)(p99 + 1)) >> 2;
            new_depth = kyber_clamp_depth(new_depth, ks->max_depth[d]);
            if(new_depth != old_depth)
            {
                ks->depth[d] = new_depth;
                ++ks->depth_adjustments;
            }
        }
    }

    /* Protect interactive reads aggressively if their p99 is above target. */
    if(p99_total[JTMOS_KYBER_READ] >= KYBER_GOOD_BUCKETS)
        ks->batch_limit[JTMOS_KYBER_WRITE] = 1;
    else
        ks->batch_limit[JTMOS_KYBER_WRITE] = KYBER_WRITE_BATCH;

    xmemset((char *)ks->total_hist, 0, (int)sizeof(ks->total_hist));
    xmemset((char *)ks->io_hist, 0, (int)sizeof(ks->io_hist));
    xmemset((char *)ks->samples, 0, (int)sizeof(ks->samples));
    ks->last_adjust_us = now;
}

static void kyber_record_completion_locked(KYBER_DEVICE_STATE *ks,
                                           KYBER_REQUEST *kr,
                                           DWORD now)
{
    DWORD total_latency = now - kr->submit_us;
    DWORD io_latency = now - kr->dispatch_us;
    unsigned int b;
    int d = kr->domain;

    b = kyber_latency_bucket(total_latency, ks->target_us[d]);
    ++ks->total_hist[d][b];
    b = kyber_latency_bucket(io_latency, ks->target_us[d]);
    ++ks->io_hist[d][b];
    ++ks->samples[d];
    ++ks->completed[d];
    if(kr->result != 0)
        ++ks->errors[d];
    /* Running mean avoids overflowing a 32-bit accumulated microsecond sum
     * during long-running systems. */
    if(ks->completed[d] == 1)
        ks->avg_latency_us[d] = total_latency;
    else if(total_latency >= ks->avg_latency_us[d])
        ks->avg_latency_us[d] +=
            (total_latency - ks->avg_latency_us[d]) / ks->completed[d];
    else
        ks->avg_latency_us[d] -=
            (ks->avg_latency_us[d] - total_latency) / ks->completed[d];
    if(total_latency > ks->max_latency_us[d])
        ks->max_latency_us[d] = total_latency;

    kyber_adjust_locked(ks, now);
}

static int kyber_kick_one(int key)
{
    KYBER_DEVICE_STATE *ks;
    KYBER_REQUEST *kr;
    int flags;
    int domain;
    int idx;
    int result;
    DWORD now;

    if(key < 0 || key >= N_MAX_DEVICES)
        return 0;

    flags = kyber_irq_lock();
    ks = &kyber_devices[key];
    /* `enabled` controls admission of new requests, not completion of
     * requests already admitted.  This lets `kyber off` and drain/barrier
     * paths finish an existing queue instead of stranding waiters. */
    if(!ks->initialized || ks->dispatch_busy)
    {
        kyber_irq_unlock(flags);
        return 0;
    }

    now = PitGetUsec();
    domain = kyber_select_domain_locked(ks, now);
    if(domain < 0)
    {
        kyber_irq_unlock(flags);
        return 0;
    }

    idx = kyber_pop_locked(ks, domain);
    if(idx < 0)
    {
        kyber_irq_unlock(flags);
        return 0;
    }

    if((unsigned int)domain != ks->current_domain)
    {
        ks->current_domain = (unsigned int)domain;
        ks->batch_count = 1;
    }
    else
        ++ks->batch_count;

    kr = &kyber_requests[idx];
    kr->state = KR_DISPATCHED;
    kr->dispatch_us = now;
    ks->dispatch_busy = 1;
    kyber_irq_unlock(flags);

    if(kr->domain == JTMOS_KYBER_READ)
        result = (readblocks1(kr->dnr, kr->block_nr, kr->buf, kr->count) == kr->count) ? 0 : 1;
    else
        result = (writeblocks1(kr->dnr, kr->block_nr, kr->buf, kr->count) == kr->count) ? 0 : 1;

    now = PitGetUsec();
    flags = kyber_irq_lock();
    kr->result = result;
    kr->state = KR_DONE;
    if(ks->outstanding[kr->domain])
        --ks->outstanding[kr->domain];
    ks->dispatch_busy = 0;
    kyber_record_completion_locked(ks, kr, now);
    kyber_irq_unlock(flags);
    return 1;
}

static void kyber_wait_moment(void)
{
    if(Multitasking && !PitStorageSafeActive())
        SchedulerWaitPause(1000UL);
    else
    {
        volatile unsigned long i;
        for(i = 0; i < 128; ++i) { }
    }
}

int kyber_should_schedule(int dnr)
{
    DEVICE_ENTRY *de;
    int key;
    int flags;
    int enabled;

    if(!kyber_initialized || !Multitasking || PitStorageSafeActive())
        return 0;
    if(!isValidDevice(dnr))
        return 0;

    de = driver_getdevice(dnr);
    if(de == NULL || !(de->type & DEVICE_TYPE_BLOCK) ||
       !kyber_name_is_fast_storage(de->device_name))
        return 0;

    key = kyber_queue_key(dnr);
    if(key < 0 || key >= N_MAX_DEVICES)
        return 0;

    flags = kyber_irq_lock();
    kyber_state_defaults(key);
    enabled = kyber_devices[key].enabled;
    kyber_irq_unlock(flags);
    return enabled;
}

int kyber_submit_sync_blocks(int dnr, int operation, long block_nr, BYTE *buf, int count)
{
    KYBER_DEVICE_STATE *ks;
    KYBER_REQUEST *kr;
    int key;
    int domain;
    int idx = -1;
    int flags;
    int result;

    if(operation != JTMOS_KYBER_READ && operation != JTMOS_KYBER_WRITE)
        return 1;
    if(buf == NULL || count <= 0)
        return 1;

    key = kyber_queue_key(dnr);
    if(key < 0 || key >= N_MAX_DEVICES)
        return 1;
    domain = operation;

    /* Admission loop.  A whole contiguous extent is represented by one
     * scheduler request, so 64-sector ATA transfers no longer consume 64
     * queue entries or 64 lock/unlock cycles. */
    for(;;)
    {
        int free_slots;
        flags = kyber_irq_lock();
        kyber_state_defaults(key);
        ks = &kyber_devices[key];
        free_slots = kyber_free_slots_locked();

        if(ks->barrier)
        {
            kyber_irq_unlock(flags);
            (void)kyber_kick_one(key);
            kyber_wait_moment();
            continue;
        }

        if(!ks->enabled)
        {
            kyber_irq_unlock(flags);
            if(domain == JTMOS_KYBER_READ)
                return readblocks1(dnr, block_nr, buf, count) == count ? 0 : 1;
            return writeblocks1(dnr, block_nr, buf, count) == count ? 0 : 1;
        }

        if(ks->outstanding[domain] < ks->depth[domain] &&
           free_slots > 0 &&
           (domain == JTMOS_KYBER_READ || free_slots > KYBER_READ_RESERVE))
        {
            idx = kyber_find_free_locked();
            if(idx >= 0)
            {
                kr = &kyber_requests[idx];
                xmemset((char *)kr, 0, (int)sizeof(*kr));
                kr->state = KR_PENDING;
                kr->next = -1;
                kr->queue_key = key;
                kr->dnr = dnr;
                kr->domain = domain;
                kr->block_nr = block_nr;
                kr->count = count;
                kr->buf = buf;
                kr->owner_pid = GetCurrentThread();
                kr->submit_us = PitGetUsec();
                kr->sequence = kyber_sequence++;
                if(kyber_sequence == 0)
                    kyber_sequence = 1;
                ++ks->outstanding[domain];
                ++ks->submitted[domain];
                kyber_push_locked(ks, domain, idx);
                kyber_irq_unlock(flags);
                break;
            }
        }
        kyber_irq_unlock(flags);

        (void)kyber_kick_one(key);
        kyber_wait_moment();
    }

    for(;;)
    {
        flags = kyber_irq_lock();
        kr = &kyber_requests[idx];
        if(kr->state == KR_DONE)
        {
            result = kr->result;
            xmemset((char *)kr, 0, (int)sizeof(*kr));
            kr->next = -1;
            kyber_irq_unlock(flags);
            return result;
        }
        kyber_irq_unlock(flags);

        (void)kyber_kick_one(key);
        kyber_wait_moment();
    }
}

int kyber_submit_sync(int dnr, int operation, long block_nr, BYTE *buf)
{
    return kyber_submit_sync_blocks(dnr,operation,block_nr,buf,1);
}

void kyber_drain(int dnr)
{
    int key;
    int flags;
    int busy;

    if(!kyber_initialized || !isValidDevice(dnr))
        return;
    key = kyber_queue_key(dnr);
    if(key < 0 || key >= N_MAX_DEVICES)
        return;

    for(;;)
    {
        flags = kyber_irq_lock();
        kyber_state_defaults(key);
        busy = kyber_devices[key].dispatch_busy ||
               kyber_devices[key].outstanding[JTMOS_KYBER_READ] ||
               kyber_devices[key].outstanding[JTMOS_KYBER_WRITE];
        kyber_irq_unlock(flags);
        if(!busy)
            break;
        (void)kyber_kick_one(key);
        kyber_wait_moment();
    }
}

void kyber_barrier_begin(int dnr)
{
    int key;
    int flags;

    if(!kyber_initialized || !isValidDevice(dnr))
        return;
    key = kyber_queue_key(dnr);
    if(key < 0 || key >= N_MAX_DEVICES)
        return;

    flags = kyber_irq_lock();
    kyber_state_defaults(key);
    if(!kyber_devices[key].enabled)
    {
        kyber_irq_unlock(flags);
        return;
    }
    kyber_devices[key].barrier = 1;
    kyber_irq_unlock(flags);

    /* No new scheduled request can pass the barrier now. */
    kyber_drain(dnr);
}

void kyber_barrier_end(int dnr)
{
    int key;
    int flags;

    if(!kyber_initialized || !isValidDevice(dnr))
        return;
    key = kyber_queue_key(dnr);
    if(key < 0 || key >= N_MAX_DEVICES)
        return;

    flags = kyber_irq_lock();
    kyber_state_defaults(key);
    kyber_devices[key].barrier = 0;
    kyber_irq_unlock(flags);
}

int kyber_set_enabled(int dnr, int enabled)
{
    int key;
    int flags;

    if(!isValidDevice(dnr))
        return 1;
    key = kyber_queue_key(dnr);
    if(key < 0 || key >= N_MAX_DEVICES)
        return 1;

    if(!enabled)
        kyber_barrier_begin(dnr);

    flags = kyber_irq_lock();
    kyber_state_defaults(key);
    kyber_devices[key].enabled = enabled ? 1 : 0;
    kyber_devices[key].manual_override = 1;
    kyber_irq_unlock(flags);

    if(!enabled)
        kyber_barrier_end(dnr);
    return 0;
}

int kyber_get_enabled(int dnr)
{
    int key;
    int flags;
    int enabled;

    if(!isValidDevice(dnr))
        return 0;
    key = kyber_queue_key(dnr);
    if(key < 0 || key >= N_MAX_DEVICES)
        return 0;
    flags = kyber_irq_lock();
    kyber_state_defaults(key);
    enabled = kyber_devices[key].enabled;
    kyber_irq_unlock(flags);
    return enabled;
}

int kyber_set_latency_targets(int dnr, DWORD read_us, DWORD write_us)
{
    int key;
    int flags;

    if(!isValidDevice(dnr) || read_us == 0 || write_us == 0 ||
       read_us > 60000000UL || write_us > 60000000UL)
        return 1;
    key = kyber_queue_key(dnr);
    if(key < 0 || key >= N_MAX_DEVICES)
        return 1;

    flags = kyber_irq_lock();
    kyber_state_defaults(key);
    kyber_devices[key].target_us[JTMOS_KYBER_READ] = read_us;
    kyber_devices[key].target_us[JTMOS_KYBER_WRITE] = write_us;
    xmemset((char *)kyber_devices[key].total_hist, 0, (int)sizeof(kyber_devices[key].total_hist));
    xmemset((char *)kyber_devices[key].io_hist, 0, (int)sizeof(kyber_devices[key].io_hist));
    xmemset((char *)kyber_devices[key].samples, 0, (int)sizeof(kyber_devices[key].samples));
    kyber_devices[key].last_adjust_us = PitGetUsec();
    kyber_irq_unlock(flags);
    return 0;
}

void kyber_reset_stats(int dnr)
{
    int key;
    int flags;
    KYBER_DEVICE_STATE *ks;

    if(!isValidDevice(dnr))
        return;
    key = kyber_queue_key(dnr);
    if(key < 0 || key >= N_MAX_DEVICES)
        return;

    flags = kyber_irq_lock();
    kyber_state_defaults(key);
    ks = &kyber_devices[key];
    xmemset((char *)ks->total_hist, 0, (int)sizeof(ks->total_hist));
    xmemset((char *)ks->io_hist, 0, (int)sizeof(ks->io_hist));
    xmemset((char *)ks->samples, 0, (int)sizeof(ks->samples));
    xmemset((char *)ks->submitted, 0, (int)sizeof(ks->submitted));
    xmemset((char *)ks->completed, 0, (int)sizeof(ks->completed));
    xmemset((char *)ks->errors, 0, (int)sizeof(ks->errors));
    xmemset((char *)ks->avg_latency_us, 0, (int)sizeof(ks->avg_latency_us));
    xmemset((char *)ks->max_latency_us, 0, (int)sizeof(ks->max_latency_us));
    ks->depth_adjustments = 0;
    ks->last_adjust_us = PitGetUsec();
    kyber_irq_unlock(flags);
}

void kyber_print_device(int dnr)
{
    int key;
    int flags;
    KYBER_DEVICE_STATE snapshot;
    DEVICE_ENTRY *de;

    if(!isValidDevice(dnr))
    {
        printk("kyber: invalid device %d.\n", dnr);
        return;
    }
    key = kyber_queue_key(dnr);
    if(key < 0 || key >= N_MAX_DEVICES)
        return;

    flags = kyber_irq_lock();
    kyber_state_defaults(key);
    xmemcpy(&snapshot, &kyber_devices[key], (DWORD)sizeof(snapshot));
    kyber_irq_unlock(flags);

    de = driver_getdevice(key);
    if(de == NULL)
        return;

    printk("kyber %s: %s%s target R/W=%d/%dus depth=%d/%d queued=%d/%d outstanding=%d/%d\n",
           de->device_name,
           snapshot.enabled ? "on" : "off",
           snapshot.barrier ? "[barrier]" : "",
           snapshot.target_us[JTMOS_KYBER_READ],
           snapshot.target_us[JTMOS_KYBER_WRITE],
           snapshot.depth[JTMOS_KYBER_READ],
           snapshot.depth[JTMOS_KYBER_WRITE],
           snapshot.queued[JTMOS_KYBER_READ],
           snapshot.queued[JTMOS_KYBER_WRITE],
           snapshot.outstanding[JTMOS_KYBER_READ],
           snapshot.outstanding[JTMOS_KYBER_WRITE]);
    printk("  completed R/W=%d/%d errors=%d/%d avg=%d/%dus max=%d/%dus adjustments=%d\n",
           snapshot.completed[JTMOS_KYBER_READ],
           snapshot.completed[JTMOS_KYBER_WRITE],
           snapshot.errors[JTMOS_KYBER_READ],
           snapshot.errors[JTMOS_KYBER_WRITE],
           snapshot.avg_latency_us[JTMOS_KYBER_READ],
           snapshot.avg_latency_us[JTMOS_KYBER_WRITE],
           snapshot.max_latency_us[JTMOS_KYBER_READ],
           snapshot.max_latency_us[JTMOS_KYBER_WRITE],
           snapshot.depth_adjustments);
}

void kyber_print_all(void)
{
    int dnr;
    int amount = driver_getdeviceamount();
    DEVICE_ENTRY *de;
    int key;

    printk("JTMOS Kyber block scheduler status:\n");
    for(dnr = 0; dnr < amount; ++dnr)
    {
        de = driver_getdevice(dnr);
        if(de == NULL || de->isfree || !(de->type & DEVICE_TYPE_BLOCK))
            continue;
        if(!kyber_name_is_fast_storage(de->device_name))
            continue;
        key = kyber_queue_key(dnr);
        if(key != dnr)
            continue; /* avoid duplicate partition status */
        kyber_print_device(dnr);
    }
}
