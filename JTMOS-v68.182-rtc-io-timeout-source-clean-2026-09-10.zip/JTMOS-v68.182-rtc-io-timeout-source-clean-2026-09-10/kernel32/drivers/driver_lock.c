//
#define JTMOS_DRIVER_LOCK_IMPLEMENTATION 1
#include "basdef.h"
#include "sysmem.h"
#include "kernel32.h"
#include "scheduler.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
#include "driver_api.h"
#include "driver_sys.h"
#include "lock.h"
#include "driver_lock.h"

#define DRIVER_LOCK_COUNT 100
#define DRIVER_LOCK_SPIN_LIMIT JTMOS_LOCK_SPIN_LIMIT
#define DRIVER_LOCK_RTC_DEADLINE_SECONDS 3U

int daLock=0;
static volatile int daLockOwner=-1;
static const char *daLockOwnerFunction=0;
static const char *daLockOwnerFile=0;
static int daLockOwnerLine=0;
static DWORD daLockSince=0;

/* driver_lock[] is a busy/free flag, not a PID.  PID 0 is a valid early-boot
 * kernel owner, so storing GetCurrentThread() directly in driver_lock[] would
 * make a PID-0 acquisition indistinguishable from an unlocked slot. */
static int driver_lock_owner_pid[DRIVER_LOCK_COUNT];
static unsigned long driver_lock_depth[DRIVER_LOCK_COUNT];
static const char *driver_lock_owner_function[DRIVER_LOCK_COUNT];
static const char *driver_lock_owner_file[DRIVER_LOCK_COUNT];
static int driver_lock_owner_line[DRIVER_LOCK_COUNT];
static DWORD driver_lock_since[DRIVER_LOCK_COUNT];

static const char *driver_lock_safe_string(const char *s)
{
    return s ? s : "?";
}

static DWORD driver_lock_elapsed(DWORD now,DWORD then)
{
    return (DWORD)(now-then);
}

void driver_directAccessLockOnAt(const char *function,const char *file,int line)
{
    int flags,pid,owner_snapshot,owner_line_snapshot,logged_wait;
    unsigned long spins;
    DWORD wait_started,now,owner_since_snapshot;
    const char *owner_function_snapshot,*owner_file_snapshot;
    RTC_SECOND_DEADLINE rtc_deadline;

    pid=GetCurrentThread();
    flags=get_eflags();
    spins=0;
    logged_wait=0;
    wait_started=GetTickCount();
    rtc_second_deadline_start(&rtc_deadline);
    disable();
    while(daLock)
    {
        owner_snapshot=daLockOwner;
        owner_function_snapshot=daLockOwnerFunction;
        owner_file_snapshot=daLockOwnerFile;
        owner_line_snapshot=daLockOwnerLine;
        owner_since_snapshot=daLockSince;
        set_eflags(flags);
        now=GetTickCount();
        if(!logged_wait)
        {
            dprintk("[LOCK] wait kind=driver-direct caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d held_ms=%u IF=%d\n",
                    pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
                    owner_snapshot,driver_lock_safe_string(owner_function_snapshot),
                    driver_lock_safe_string(owner_file_snapshot),owner_line_snapshot,
                    (unsigned)driver_lock_elapsed(now,owner_since_snapshot),
                    (flags&0x200)?1:0);
            logged_wait=1;
        }
        if(LockWaitCanYield(flags))
            SchedulerWaitPause(1000UL);
        else
        {
            volatile unsigned long i;
            for(i=0;i<128;i++) { }
        }

        /*
         * Storage lock recovery is a CLEAR deadline, not an endless
         * deadlock detector.  Probe the CMOS seconds register on every wait
         * pass and, after three real second transitions, discard the stale
         * lock owner so block I/O can make forward progress.
         */
        if(rtc_second_deadline_poll(&rtc_deadline,
                                    DRIVER_LOCK_RTC_DEADLINE_SECONDS))
        {
            disable();
            if(daLock)
            {
                owner_snapshot=daLockOwner;
                owner_function_snapshot=daLockOwnerFunction;
                owner_file_snapshot=daLockOwnerFile;
                owner_line_snapshot=daLockOwnerLine;
                owner_since_snapshot=daLockSince;
                daLock=0;
                daLockOwner=-1;
                daLockOwnerFunction=0;
                daLockOwnerFile=0;
                daLockOwnerLine=0;
                daLockSince=0;
                set_eflags(flags);
                now=GetTickCount();
                dprintk("[LOCK] DEADLINE-CLEAR kind=driver-direct caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d held_ms=%u rtc_changes=%u\n",
                        pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
                        owner_snapshot,driver_lock_safe_string(owner_function_snapshot),
                        driver_lock_safe_string(owner_file_snapshot),owner_line_snapshot,
                        (unsigned)driver_lock_elapsed(now,owner_since_snapshot),
                        rtc_deadline.transitions);
                disable();
            }
            else
            {
                set_eflags(flags);
                disable();
            }
            break;
        }
        disable();
        if(++spins>=DRIVER_LOCK_SPIN_LIMIT)
        {
            owner_snapshot=daLockOwner;
            owner_function_snapshot=daLockOwnerFunction;
            owner_file_snapshot=daLockOwnerFile;
            owner_line_snapshot=daLockOwnerLine;
            owner_since_snapshot=daLockSince;
            set_eflags(flags);
            now=GetTickCount();
            dprintk("[LOCK] SPIN-WARN kind=driver-direct caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d held_ms=%u waited_ms=%u IF=%d\n",
                    pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
                    owner_snapshot,driver_lock_safe_string(owner_function_snapshot),
                    driver_lock_safe_string(owner_file_snapshot),owner_line_snapshot,
                    (unsigned)driver_lock_elapsed(now,owner_since_snapshot),
                    (unsigned)driver_lock_elapsed(now,wait_started),(flags&0x200)?1:0);
            spins=0;
            disable();
        }
    }
    daLock=1;
    daLockOwner=pid;
    daLockOwnerFunction=function;
    daLockOwnerFile=file;
    daLockOwnerLine=line;
    daLockSince=GetTickCount();
    now=daLockSince;
    set_eflags(flags);
#if JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
    dprintk("[LOCK] acquire kind=driver-direct pid=%d at=%s %s:%d waited_ms=%u IF=%d\n",
            pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
            (unsigned)driver_lock_elapsed(now,wait_started),(flags&0x200)?1:0);
#endif
}

void driver_directAccessLockOffAt(const char *function,const char *file,int line)
{
    int flags,pid,owner_snapshot,owner_line_snapshot,was_locked;
    DWORD now,owner_since_snapshot;
    const char *owner_function_snapshot,*owner_file_snapshot;

    pid=GetCurrentThread();
    now=GetTickCount();
    flags=get_eflags();
    disable();
    was_locked=daLock;
    owner_snapshot=daLockOwner;
    owner_function_snapshot=daLockOwnerFunction;
    owner_file_snapshot=daLockOwnerFile;
    owner_line_snapshot=daLockOwnerLine;
    owner_since_snapshot=daLockSince;

    /* A deadline-cleared old owner may return after another PID has already
     * acquired the lock.  Never let that stale Unlock clear the new owner's
     * lock. */
    if(was_locked && owner_snapshot==pid)
    {
        daLock=0;
        daLockOwner=-1;
        daLockOwnerFunction=0;
        daLockOwnerFile=0;
        daLockOwnerLine=0;
        daLockSince=0;
    }
    set_eflags(flags);

    if(!was_locked || owner_snapshot!=pid)
        dprintk("[LOCK] BAD-UNLOCK kind=driver-direct caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d held_ms=%u reason=%s\n",
                pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
                owner_snapshot,driver_lock_safe_string(owner_function_snapshot),
                driver_lock_safe_string(owner_file_snapshot),owner_line_snapshot,
                (unsigned)driver_lock_elapsed(now,owner_since_snapshot),
                was_locked?"owner-mismatch":"already-free");
#if JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
    if(was_locked && owner_snapshot==pid)
        dprintk("[LOCK] release kind=driver-direct pid=%d at=%s %s:%d owner_pid=%d owner_at=%s %s:%d held_ms=%u\n",
                pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
                owner_snapshot,driver_lock_safe_string(owner_function_snapshot),
                driver_lock_safe_string(owner_file_snapshot),owner_line_snapshot,
                (unsigned)driver_lock_elapsed(now,owner_since_snapshot));
#endif
}

void driver_forceSetLock(int lockNr, int what)
{
    if(lockNr<0 || lockNr>=DRIVER_LOCK_COUNT)
        return;

    /* Legacy helper: zero means release; any non-zero value means busy and is
     * retained as the best available owner PID hint.  Normal acquisitions do
     * not use this helper because PID 0 must also be representable as owner. */
    if(!what)
    {
        driver_lock[lockNr]=0;
        driver_lock_owner_pid[lockNr]=-1;
        driver_lock_depth[lockNr]=0;
        driver_lock_owner_function[lockNr]=0;
        driver_lock_owner_file[lockNr]=0;
        driver_lock_owner_line[lockNr]=0;
        driver_lock_since[lockNr]=0;
        return;
    }

    driver_lock[lockNr]=1;
    driver_lock_owner_pid[lockNr]=what;
}

int driver_getLock(int lockNr)
{
    if(lockNr<0 || lockNr>=DRIVER_LOCK_COUNT)
        return 0;
    return driver_lock[lockNr] ? 1 : 0;
}

void driver_lockOnAt(int lockNr,const char *function,const char *file,int line)
{
    int flags,pid,owner_snapshot,owner_line_snapshot,logged_wait;
    unsigned long spins,depth_snapshot;
    DWORD wait_started,now,owner_since_snapshot;
    const char *owner_function_snapshot,*owner_file_snapshot;
    RTC_SECOND_DEADLINE rtc_deadline;

    if(lockNr<0 || lockNr>=DRIVER_LOCK_COUNT)
    {
        dprintk("[LOCK] invalid-id acquire kind=driver id=%d caller=%s %s:%d\n",
                lockNr,driver_lock_safe_string(function),driver_lock_safe_string(file),line);
        return;
    }

    pid=GetCurrentThread();
    flags=get_eflags();
    spins=0;
    logged_wait=0;
    wait_started=GetTickCount();
    rtc_second_deadline_start(&rtc_deadline);
    disable();

    if(driver_lock[lockNr] && driver_lock_owner_pid[lockNr]==pid &&
       driver_lock_depth[lockNr]!=0)
    {
        driver_lock_depth[lockNr]++;
        depth_snapshot=driver_lock_depth[lockNr];
        set_eflags(flags);
#if JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
        dprintk("[LOCK] recurse kind=driver id=%d pid=%d at=%s %s:%d depth=%u\n",
                lockNr,pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
                (unsigned)depth_snapshot);
#endif
        return;
    }

    while(driver_lock[lockNr])
    {
        owner_snapshot=driver_lock_owner_pid[lockNr];
        owner_function_snapshot=driver_lock_owner_function[lockNr];
        owner_file_snapshot=driver_lock_owner_file[lockNr];
        owner_line_snapshot=driver_lock_owner_line[lockNr];
        owner_since_snapshot=driver_lock_since[lockNr];
        set_eflags(flags);
        now=GetTickCount();
        if(!logged_wait)
        {
            dprintk("[LOCK] wait kind=driver id=%d caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d depth=%u held_ms=%u IF=%d\n",
                    lockNr,pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
                    owner_snapshot,driver_lock_safe_string(owner_function_snapshot),
                    driver_lock_safe_string(owner_file_snapshot),owner_line_snapshot,
                    (unsigned)driver_lock_depth[lockNr],
                    (unsigned)driver_lock_elapsed(now,owner_since_snapshot),(flags&0x200)?1:0);
            logged_wait=1;
        }
        if(LockWaitCanYield(flags))
            SchedulerWaitPause(1000UL);
        else
        {
            volatile unsigned long i;
            for(i=0;i<128;i++) { }
        }

        if(rtc_second_deadline_poll(&rtc_deadline,
                                    DRIVER_LOCK_RTC_DEADLINE_SECONDS))
        {
            disable();
            if(driver_lock[lockNr])
            {
                owner_snapshot=driver_lock_owner_pid[lockNr];
                owner_function_snapshot=driver_lock_owner_function[lockNr];
                owner_file_snapshot=driver_lock_owner_file[lockNr];
                owner_line_snapshot=driver_lock_owner_line[lockNr];
                owner_since_snapshot=driver_lock_since[lockNr];
                depth_snapshot=driver_lock_depth[lockNr];
                driver_forceSetLock(lockNr,0);
                set_eflags(flags);
                now=GetTickCount();
                dprintk("[LOCK] DEADLINE-CLEAR kind=driver id=%d caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d depth=%u held_ms=%u rtc_changes=%u\n",
                        lockNr,pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
                        owner_snapshot,driver_lock_safe_string(owner_function_snapshot),
                        driver_lock_safe_string(owner_file_snapshot),owner_line_snapshot,
                        (unsigned)depth_snapshot,
                        (unsigned)driver_lock_elapsed(now,owner_since_snapshot),
                        rtc_deadline.transitions);
                disable();
            }
            else
            {
                set_eflags(flags);
                disable();
            }
            break;
        }
        disable();
        if(++spins>=DRIVER_LOCK_SPIN_LIMIT)
        {
            owner_snapshot=driver_lock_owner_pid[lockNr];
            owner_function_snapshot=driver_lock_owner_function[lockNr];
            owner_file_snapshot=driver_lock_owner_file[lockNr];
            owner_line_snapshot=driver_lock_owner_line[lockNr];
            owner_since_snapshot=driver_lock_since[lockNr];
            depth_snapshot=driver_lock_depth[lockNr];
            set_eflags(flags);
            now=GetTickCount();
            dprintk("[LOCK] SPIN-WARN kind=driver id=%d caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d depth=%u held_ms=%u waited_ms=%u IF=%d\n",
                    lockNr,pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
                    owner_snapshot,driver_lock_safe_string(owner_function_snapshot),
                    driver_lock_safe_string(owner_file_snapshot),owner_line_snapshot,
                    (unsigned)depth_snapshot,(unsigned)driver_lock_elapsed(now,owner_since_snapshot),
                    (unsigned)driver_lock_elapsed(now,wait_started),(flags&0x200)?1:0);
            spins=0;
            disable();
        }
    }

    /* Keep busy state separate from the owner PID.  In particular PID 0 must
     * produce driver_lock[lockNr] == 1, otherwise early boot silently runs
     * without mutual exclusion. */
    driver_lock[lockNr]=1;
    driver_lock_owner_pid[lockNr]=pid;
    driver_lock_depth[lockNr]=1;
    driver_lock_owner_function[lockNr]=function;
    driver_lock_owner_file[lockNr]=file;
    driver_lock_owner_line[lockNr]=line;
    driver_lock_since[lockNr]=GetTickCount();
    now=driver_lock_since[lockNr];
    set_eflags(flags);
#if JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
    dprintk("[LOCK] acquire kind=driver id=%d pid=%d at=%s %s:%d waited_ms=%u IF=%d\n",
            lockNr,pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
            (unsigned)driver_lock_elapsed(now,wait_started),(flags&0x200)?1:0);
#endif
}

void driver_lockOffAt(int lockNr,const char *function,const char *file,int line)
{
    int flags,pid,owner_snapshot,owner_line_snapshot,was_locked;
    unsigned long depth_snapshot;
    DWORD now,owner_since_snapshot;
    const char *owner_function_snapshot,*owner_file_snapshot;

    if(lockNr<0 || lockNr>=DRIVER_LOCK_COUNT)
    {
        dprintk("[LOCK] invalid-id release kind=driver id=%d caller=%s %s:%d\n",
                lockNr,driver_lock_safe_string(function),driver_lock_safe_string(file),line);
        return;
    }

    pid=GetCurrentThread();
    now=GetTickCount();
    flags=get_eflags();
    disable();
    was_locked=driver_lock[lockNr];
    owner_snapshot=driver_lock_owner_pid[lockNr];
    owner_function_snapshot=driver_lock_owner_function[lockNr];
    owner_file_snapshot=driver_lock_owner_file[lockNr];
    owner_line_snapshot=driver_lock_owner_line[lockNr];
    owner_since_snapshot=driver_lock_since[lockNr];
    depth_snapshot=driver_lock_depth[lockNr];

    if(was_locked && owner_snapshot==pid && depth_snapshot>1)
    {
        driver_lock_depth[lockNr]--;
        depth_snapshot=driver_lock_depth[lockNr];
        set_eflags(flags);
#if JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
        dprintk("[LOCK] release kind=driver id=%d pid=%d at=%s %s:%d depth=%u held_ms=%u recursive\n",
                lockNr,pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
                (unsigned)depth_snapshot,(unsigned)driver_lock_elapsed(now,owner_since_snapshot));
#endif
        return;
    }

    if(!was_locked)
    {
        set_eflags(flags);
        dprintk("[LOCK] BAD-UNLOCK kind=driver id=%d caller_pid=%d caller=%s %s:%d reason=already-free\n",
                lockNr,pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line);
        return;
    }
    if(owner_snapshot!=pid)
    {
        /* See direct-access lock above: after DEADLINE-CLEAR an old owner must
         * not destroy the lock currently owned by another PID. */
        set_eflags(flags);
        dprintk("[LOCK] BAD-UNLOCK kind=driver id=%d caller_pid=%d caller=%s %s:%d owner_pid=%d owner=%s %s:%d depth=%u held_ms=%u reason=owner-mismatch\n",
                lockNr,pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
                owner_snapshot,driver_lock_safe_string(owner_function_snapshot),
                driver_lock_safe_string(owner_file_snapshot),owner_line_snapshot,
                (unsigned)depth_snapshot,(unsigned)driver_lock_elapsed(now,owner_since_snapshot));
        return;
    }

    driver_forceSetLock(lockNr,0);
    set_eflags(flags);
#if JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
    dprintk("[LOCK] release kind=driver id=%d pid=%d at=%s %s:%d owner_pid=%d owner_at=%s %s:%d depth=%u held_ms=%u final\n",
            lockNr,pid,driver_lock_safe_string(function),driver_lock_safe_string(file),line,
            owner_snapshot,driver_lock_safe_string(owner_function_snapshot),
            driver_lock_safe_string(owner_file_snapshot),owner_line_snapshot,
            (unsigned)depth_snapshot,(unsigned)driver_lock_elapsed(now,owner_since_snapshot));
#endif
}
