// ----------------------------------------------------------------
// fdc_dev.c - Device call handler.
// (C) 2002-2004,2017 by Jari Tuominen (jari.t.tuominen@gmail.com).
// Device call = A gateway to access the floppy driver,
// used by lowest level kernel drive access routines.
// ----------------------------------------------------------------
#include "basdef.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "ega.h"
#include "syssh.h"
#include "io.h"
#include "fdc.h"
#include "fdcCache.h"
#include "fdc2_dev.h"
#include "dma.h"
#include "kernel32.h"
//
#include "driver_sys.h" // driver_register_new_device, ...
#include "driver_api.h"
//
#define FD_THIS_DRIVE	0
//
int fdc_dev_mounted=1;

static int fdc_write_verified_block(int block,const BYTE *src)
{
    BYTE verify[512];
    int tries;
    for(tries=0;tries<8;tries++) {
        if(!fd_write_block(block,(void *)src)) continue;
        if(!fd_read_block(block,verify)) continue;
        if(memcmp(verify,src,512)==0) return 0;
        if((tries & 3)==3) fd_reset();
        fd_write_block(block,(void *)src);
        fd_write_block(block,(void *)src);
        fd_write_block(block,(void *)src);
    }
    printk("%s: block %d write failed after %d tries\n",__FUNCTION__,block,tries);
    return 1;
}

static int fdc_transfer_blocks(int first,int count,BYTE *buf,int rw)
{
    int i;
    if(first<0 || count<=0 || buf==NULL || first>=2880 || count>2880-first) return 1;
    fd_selectdrive(FD_THIS_DRIVE);
    for(i=0;i<count;i++) {
        if(rw==READ) {
            memset(buf+i*512,0,512);
            if(!fd_read_block(first+i,buf+i*512)) return 1;
        } else if(fdc_write_verified_block(first+i,buf+i*512)!=0) return 1;
    }
    return 0;
}

// Note: to see what does 'DEVICE_CALL_PARS' mean,
// check driver_api.h.
//
int floppy_device_call(DEVICE_CALL_PARS)
{
	DWORD *size;
	int i,i2,i3,i4;
	static char buf[512],*tmp;
	int flags;

        // If unmounted, we won't answer anything until mounted again.
        if(n_call!=DEVICE_CMD_MOUNT && !fdc_dev_mounted)
                return 0;

	/* Select the physical unit before cache/control operations too. */
	fd_selectdrive(FD_THIS_DRIVE);

	//
	switch(n_call)
	{
		case DEVICE_CMD_FLUSH:
		fdcFlushCache();
		fdcClearCache();
		break;
		case DEVICE_CMD_MOUNT:
		fdc_dev_mounted=1;
		fdcClearCache();
		break;
		case DEVICE_CMD_UNMOUNT:
		fdc_dev_mounted=0;
		fdcClearCache();
		break;
		//
		case DEVICE_CMD_INIT:
		break;
		//
		case DEVICE_CMD_SHUTDOWN:
		break;
		//
		case DEVICE_CMD_READBLOCK:
		return fdc_transfer_blocks(p1,1,(BYTE *)po1,READ);
		case DEVICE_CMD_WRITEBLOCK:
		return fdc_transfer_blocks(p1,1,(BYTE *)po1,WRITE);
		case DEVICE_CMD_READBLOCKS:
		return fdc_transfer_blocks(p1,p2,(BYTE *)po1,READ);
		case DEVICE_CMD_WRITEBLOCKS:
		return fdc_transfer_blocks(p1,p2,(BYTE *)po1,WRITE);
		//
		case DEVICE_CMD_GETSIZE:
		fd_selectdrive(FD_THIS_DRIVE);
		size=po1;
		size[0]=2880;
		break;
		//
		case DEVICE_CMD_GETBLOCKSIZE:
		fd_selectdrive(FD_THIS_DRIVE);
		size=po1;
		size[0]=512;
		break;
		//
		case DEVICE_CMD_SEEK:
		break;
		//
		case DEVICE_CMD_GETCH:
		break;
		//
		case DEVICE_CMD_PUTCH:
		break;
		//
		case DEVICE_CMD_TELL:
		break;
		//
		default:
		break;
	}

	//
	return 0;
}

// Registers device 'floppy'
int floppy_register_device(void)
{
	int dnr;

	// Check that the device isn't already registered
	if(driver_getdevicebyname("floppy"))
	{
		dprintk("floppy: already registered; registration is idempotent.\n");
		return 0;
	}

	// Register the device
	driver_register_new_device("floppy",floppy_device_call,DEVICE_TYPE_BLOCK|DEVICE_TYPE_MULTIBLOCK);

	// Disable read cache
	dnr = driver_getdevicenrbyname("floppy");
	driver_disableDAPIReadCache(dnr);
	driver_disableDAPIWriteBackCache(dnr);
	// Tell system that this device is a removable device.
	//RemovableDevice(dnr);

	//
	return 0;
}


