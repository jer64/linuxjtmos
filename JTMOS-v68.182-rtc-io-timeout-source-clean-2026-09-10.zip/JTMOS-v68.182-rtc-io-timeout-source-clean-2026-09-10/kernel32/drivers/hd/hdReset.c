//==============================================================
// hdReset.c
// (C) 2003-2004 by Jari Tuominen.
// V36: ATA software reset recovery made QEMU/legacy-IDE safe.
//==============================================================
#include <stdio.h>
#include "hd.h"
#include "hdReset.h"

/*
 * ATA software reset requirements:
 *  - assert SRST for at least 5 us
 *  - release SRST
 *  - allow the bus/device to recover before issuing commands
 *
 * hd400ns() performs four alternate-status reads.  Using it for the
 * short delays also avoids consuming the normal status register.
 */
static void hd_reset_assert_delay(void)
{
    int i;
    for(i=0; i<32; i++) hd400ns();       /* comfortably > 5 us */
}

static void hd_reset_recovery_delay(void)
{
    BYTE s;
    int i;
    RTC_IO_DEADLINE deadline;

    /* Give QEMU and real ATA devices an unconditional settling window. */
    for(i=0; i<4096; i++) hd400ns();

    /* Then wait for primary-bus BSY to clear, but never hang boot. */
    rtc_io_deadline_start(&deadline,HD_RESET_TIMEOUT_MS,
        (unsigned int)(HD_RESET_TIMEOUT_MS/1000UL)+2U,100000000UL);
    for(;;)
    {
        s=(BYTE)inportb(0x3F6);          /* alternate status */
        if(s==0x00 || s==0xFF) break;    /* no selected device is OK here */
        if(!(s & HD_STATUS_BUSY)) break;
        if(rtc_io_deadline_expired(&deadline)) break;
        hd400ns();
    }
}

// Reset primary IDE bus. Polling mode keeps ATA IRQ disabled (nIEN=1).
void hdReset1(void)
{
    HDDEBUG

    outportb(0x3F6, HD_DEVICE_CONTROL_NIEN | HD_RESET_BIT);
    hd_reset_assert_delay();

    outportb(0x3F6, HD_DEVICE_CONTROL_NIEN);
    hd_reset_recovery_delay();
}

// Reset current hard disk and wait for it to become ready.
void hdReset(HD *h)
{
    HDDEBUG
    hdReset1();
    hdWait(h);
}
