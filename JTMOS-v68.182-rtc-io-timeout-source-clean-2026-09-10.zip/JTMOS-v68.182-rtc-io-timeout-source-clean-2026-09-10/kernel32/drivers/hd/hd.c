// ==================================================
// IDE hard disk driver revision 3.0.
// (C) 2003-2004 by Jari Tuominen.
// ==================================================
#ifdef JTMOSKERNEL
#include <kernel32.h>
#else
#include <stdio.h>
#endif
#include "hd.h"

// We require some memory to provide good
// performance for hard disk access.
// Request 1024K(1M) of RAM from the init process.
//
// Note: If you edit this value below,
// then remember to edit cache/hdCacheConfig.h also.
#ifndef JTMOSKERNEL
SYSMEMREQ(APPRAM_1024K)
#endif

// Current HD in use
HD *chd=NULL;
// HD disk info structures
HD **hd=NULL;
// IRQ variables
int ideirqtick[10]={0};

#ifndef JTMOSKERNEL
// Debug message printer
int dprintk(const char *fmt, ...)
{
        va_list arg;
        int result;

	//
#ifdef ENABLE_HD_DEBUG_MESSAGES
        va_start(arg, fmt);
        result=vprintf(fmt,arg);
        va_end(arg);
#endif

	//
        return result;
}
#endif


static void hd_release_probe_state(void)
{
	int n;
	if(hd!=NULL) {
		for(n=0;n<5;n++) {
			if(hd[n]!=NULL) free(hd[n]);
		}
		free(hd);
	}
	hd=NULL;
	chd=NULL;
}

// Test HD drive
void hdTestDrive(void)
{
	BYTE *tmp;
	int dnr;
	int i,b;
	DWORD *p;

	//
	dnr = getdevicenrbyname("hda");

	//
	tmp=malloc(32768);
	if(tmp==NULL) { dprintk("hdTestDrive: no memory for test buffer.\n"); return; }

	//
	printk("Testing hard disk ");
	for(i=0,p=JTM_DWORD_TO_PTR(DWORD,0xF0000); i<100; i++,p++)
	{
		//
		b = (*p+i) % 1024;
		readblock(dnr, b, tmp);
		printk(".");
	}
	printk("\nTest completed.\n");

	//
}

//---------------------------------------------------------------------
// IDE HARD DISK DRIVER MASTER INIT FUNCTION
//---------------------------------------------------------------------
int hw_hd_init(void)
{
	static int i,dnr;

	hd=malloc(sizeof(HD *)*10);
	if(hd==NULL)
	{
		dprintk("hw_hd_init: unable to allocate drive pointer table.\n");
		return FALSE;
	}
	memset(hd,0,sizeof(HD *)*10);

	for(i=0;i<5;i++)
	{
		hd[i]=malloc(sizeof(HD));
		if(hd[i]==NULL)
		{
			dprintk("hw_hd_init: allocation failed for drive slot %d.\n",i);
			while(i>0) { i--; free(hd[i]); hd[i]=NULL; }
			free(hd); hd=NULL; chd=NULL;
			return FALSE;
		}
		memset(hd[i],0,sizeof(HD));
	}

	chd=hd[0];
	if(chd==NULL)
	{
		dprintk("hw_hd_init: no primary drive structure.\n");
		return FALSE;
	}

	// Detect drive
	if( hdDetect(chd) )
	{
		BYTE *sanity_a,*sanity_b;
		int sanity_ok=0;

		/* A successful IDENTIFY is not enough on some BIOS/native-SATA
		 * combinations.  Require two identical real sector-0 reads before
		 * the legacy 0x1f0 backend is allowed to claim hda:.  Failure here
		 * deliberately hands control to the PCI SATA rescue backends. */
		sanity_a=malloc(512);
		sanity_b=malloc(512);
		if(sanity_a && sanity_b &&
		   hdBlockRW(chd,sanity_a,512,0,chd->slave,READ)==0 &&
		   hdBlockRW(chd,sanity_b,512,0,chd->slave,READ)==0 &&
		   memcmp(sanity_a,sanity_b,512)==0)
			sanity_ok=1;
		if(sanity_a) free(sanity_a);
		if(sanity_b) free(sanity_b);
		if(!sanity_ok)
		{
			printk("IDE: IDENTIFY succeeded but sector-read sanity failed; trying SATA rescue.\n");
			hd_release_probe_state();
			return FALSE;
		}
		printk("IDE: sector-0 repeat-read sanity passed.\n");

		// Found drive:
		//--------------

		// Define cylinder buffer size in bytes
		chd->l_buf = chd->lbaMode ? chd->blocksize : chd->sectors*chd->blocksize;

		// Initialize cache system.
		if(chd->lbaMode)
		{
			// Start LBA cache...
			// NOT YET IMPLEMENTED.
		}
		else
		{
			/* Legacy CHS write-back cache is intentionally disabled.
			 * Direct PIO is slower but deterministic and crash-safe. */
			printk("IDE: CHS cache disabled; using direct PIO.\n");
		}

		//
		//hdTestDrive();
		return TRUE;
	}
	else
	{
		// -- Drive not found
		hd_release_probe_state();
		return FALSE;
	}
}
//---------------------------------------------------------------------

//




