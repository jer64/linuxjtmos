/*
 * JTMOS Kyber-inspired block I/O scheduler.
 *
 * This is a clean-room JTMOS implementation inspired by the design goals of
 * Linux Kyber: separate scheduling domains, latency targets, bounded queue
 * depths and feedback-driven depth control.  The current JTMOS block driver
 * ABI is synchronous, so this scheduler orders/admission-controls requests
 * before the device call; it does not pretend that legacy IDE/FDC drivers have
 * NVMe-style hardware queues.
 */
#ifndef JTMOS_DRIVER_KYBER_H
#define JTMOS_DRIVER_KYBER_H

#include "basdef.h"

#define JTMOS_KYBER_READ   0
#define JTMOS_KYBER_WRITE  1
#define JTMOS_KYBER_DOMAINS 2

void kyber_init(void);
int kyber_should_schedule(int dnr);
int kyber_submit_sync(int dnr, int operation, long block_nr, BYTE *buf);
int kyber_submit_sync_blocks(int dnr, int operation, long block_nr, BYTE *buf, int count);

int kyber_set_enabled(int dnr, int enabled);
int kyber_get_enabled(int dnr);
int kyber_set_latency_targets(int dnr, DWORD read_us, DWORD write_us);
void kyber_reset_stats(int dnr);
void kyber_drain(int dnr);
void kyber_barrier_begin(int dnr);
void kyber_barrier_end(int dnr);
void kyber_print_device(int dnr);
void kyber_print_all(void);

#endif
