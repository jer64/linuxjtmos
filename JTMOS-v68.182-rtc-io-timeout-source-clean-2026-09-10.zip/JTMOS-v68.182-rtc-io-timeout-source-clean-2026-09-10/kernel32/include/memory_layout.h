#ifndef JTMOS_MEMORY_LAYOUT_H
#define JTMOS_MEMORY_LAYOUT_H

/*
 * JTMOS canonical low-memory layout.
 *
 * Keep this file synchronized with memory_layout.inc (NASM) and
 * memory_layout.ld (GNU ld). tools/check_release_layout.sh verifies the three
 * representations byte-for-byte at the numeric-constant level.
 *
 * V67.8.37 EXPERIMENT: the complete fixed kernel/paging arena is shifted +1 MiB; the V67.8.35 safe baseline remains unchanged in its own release.
 */
#define JTMOS_KERNEL_LOAD_PHYS                 0x00100000
#define JTMOS_KERNEL_BSS_BASE                  0x00200000
#define JTMOS_KERNEL_EARLY_STACK_BOTTOM        0x002E0000
#define JTMOS_KERNEL_EARLY_STACK_TOP           0x002F0000
#define JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP   0x002EFFF0
#define JTMOS_KERNEL_IDT_BASE                  0x002F0000
#define JTMOS_KERNEL_IDT_END                   0x002FF000
#define JTMOS_KERNEL_PAGE_DIRECTORY_PHYS       0x002FF000
#define JTMOS_KERNEL_PAGE_TABLE_PHYS           0x00300000
#define JTMOS_KERNEL_PAGE_TABLE_BYTES          0x00400000
#define JTMOS_KERNEL_USER_PTES_PHYS            0x00700000
#define JTMOS_KERNEL_USER_PTES_BYTES           0x00400000
#define JTMOS_KERNEL_DYNAMIC_PHYS_START        0x00B00000
/* boot32pm scratch used only before kernel memory management starts. */
#define JTMOS_BOOT_NZIP_STAGING_PHYS            0x01000000
#define JTMOS_BOOT_NZIP_STAGING_BYTES           0x00100000

/* DOSBOOT persistent utilities.iso RAM bank. Reserved from the physical allocator. */
#define JTMOS_BOOT_UTILS_RAM_PHYS               0x01100000
#define JTMOS_BOOT_UTILS_RAM_BYTES              0x01000000
#define JTMOS_KERNEL_MAP_START                 0x40000000
#define JTMOS_KERNEL_MAP_END                   0x70000000

#define JTMOS_KERNEL_EARLY_STACK_BYTES \
    (JTMOS_KERNEL_EARLY_STACK_TOP-JTMOS_KERNEL_EARLY_STACK_BOTTOM)
#define JTMOS_KERNEL_PAGE_TABLE_END \
    (JTMOS_KERNEL_PAGE_TABLE_PHYS+JTMOS_KERNEL_PAGE_TABLE_BYTES)
#define JTMOS_KERNEL_USER_PTES_END \
    (JTMOS_KERNEL_USER_PTES_PHYS+JTMOS_KERNEL_USER_PTES_BYTES)

/* Stringification is used by the naked C entry where a literal assembly
 * operand is required before normal C execution begins. */
#define JTMOS_LAYOUT_STR1(x) #x
#define JTMOS_LAYOUT_STR(x) JTMOS_LAYOUT_STR1(x)
#define JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP_ASM \
    JTMOS_LAYOUT_STR(JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP)

#if JTMOS_KERNEL_EARLY_STACK_BYTES < 0x00010000
#error "JTMOS early kernel stack must be at least 64 KiB"
#endif
#if JTMOS_KERNEL_EARLY_STACK_TOP != JTMOS_KERNEL_IDT_BASE
#error "JTMOS early stack must end exactly where the IDT reserve begins"
#endif
#if JTMOS_KERNEL_IDT_END != JTMOS_KERNEL_PAGE_DIRECTORY_PHYS
#error "JTMOS IDT reserve must end at the page-directory page"
#endif
#if JTMOS_KERNEL_PAGE_TABLE_END != JTMOS_KERNEL_USER_PTES_PHYS
#error "JTMOS kernel PTE array must end at the user-PTE reserve"
#endif
#if JTMOS_KERNEL_USER_PTES_END != JTMOS_KERNEL_DYNAMIC_PHYS_START
#error "JTMOS fixed paging reserve must end at dynamic physical RAM"
#endif
#if JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP <= JTMOS_KERNEL_EARLY_STACK_BOTTOM || \
    JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP >= JTMOS_KERNEL_EARLY_STACK_TOP
#error "JTMOS initial ESP must lie inside the early stack"
#endif

#endif
