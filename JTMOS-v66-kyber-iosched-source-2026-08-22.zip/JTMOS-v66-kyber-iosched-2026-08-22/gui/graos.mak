# GraOS V23 - minimal VESA framebuffer bring-up application
APPNAME=graos
LIBCDIR=../..
JTMOSSTDLIBCLOC=$(LIBCDIR)/libc/stlibc.o
STDSRC=$(LIBCDIR)/lib/stdapp.src
CC=gcc
CFLAGS=-m32 -std=gnu89 -Wall -w -c -O2 -march=i486 -DCPU=i586 \
       -fno-pie -fno-stack-protector -fcommon -I$(LIBCDIR)/include
LD=ld
LDFLAGS=-m elf_i386 --oformat binary -Map $(APPNAME).map \
        -T$(STDSRC) -L../../lib -lcjtmos -o $(APPNAME).bin

default: linkit

linkit: application
	$(LD) $(JTMOSSTDLIBCLOC) $(APPNAME).o $(LDFLAGS)
	ls -l $(APPNAME).bin

application:
	$(CC) $(CFLAGS) $(APPNAME).c -o $(APPNAME).o

clean:
	rm -f $(APPNAME).o $(APPNAME).bin $(APPNAME).map
