JTMOS V58 - Sound Blaster / Gravis UltraSound audio refresh
============================================================
Date: 2026-08-21

Overview
--------
V58 makes audio a kernel-owned service and exposes it to SMSH and ELF32
applications through a small syscall/libc interface.  The first supported
stream format is unsigned 8-bit mono PCM at 4000..44100 Hz.

Kernel audio core
-----------------
* Generic drivers/audio audio FIFO enlarged to 128 KiB.
* Hardware probing is lazy: AUDIO_DRIVERS is compiled in by default, but the
  kernel does not touch an SB/GUS until sound playback is requested (unless
  the historical per-driver boot options are explicitly enabled).
* Backend selection supports AUTO, Sound Blaster, and Gravis UltraSound.
* Queue depth, active bytes, played bytes, sample rate and underruns are
  available through JTMOS_AUDIO_INFO.
* Hardware I/O, IRQ installation and DMA/DRAM access remain in kernel space.

Sound Blaster
-------------
* Reworked around IRQ-driven, single-cycle 8-bit DMA blocks instead of the old
  predictive/auto-init polling scheme.
* DSP reset uses the normal reset pulse and 0xAA acknowledgement.
* DMA block counts use length-1 and playback is memory-to-device.
* SB16 DSPs use output sample-rate command 0x41 and 8-bit single-cycle command
  0xC0.  Older DSP 2.x/3.x devices use the time-constant + 0x14 path.
* SB16 mixer resource registers are used to discover IRQ and 8-bit DMA when
  available; common legacy base addresses are probed.
* The ISR only acknowledges completion and records the finished byte count.
  Starting the next block happens in KSB-AUDIO thread context.
* Slave/master PIC EOI handling and 8-bit DSP IRQ acknowledgement are fixed.
* Long DSP-ready waits yield through SwitchToThread instead of burning CPU.

Gravis UltraSound / GF1
-----------------------
* Reworked into a conservative CPU-uploaded GF1 wavetable PCM streamer.  It
  does not depend on unconfigured GUS DMA/IRQ routing for basic playback.
* Active-voice programming uses voices-1 and the normal GF1 operational reset
  value enables DAC/IRQ operation after reset.
* Voice frequency/address and 12-bit current-volume programming are corrected.
* The historical 16 MiB destructive-looking DRAM scan is replaced by a bounded
  classic-GUS memory test up to 1 MiB, with bank/alias checks.
* Old VGA-memory writes from the interrupt handler are removed.
* Playback continuation runs in KGUS-AUDIO thread context and yields while a
  voice is active.

System calls / libc
-------------------
New syscalls:
  107 SYS_audioinit
  108 SYS_audiowrite
  109 SYS_audioposition
  110 SYS_audiostop
  111 SYS_audioinfo
  112 SYS_audioselect

Public libc API (<jtmos/audio.h>):
  int AudioInit(void);
  int AudioSelectBackend(int backend);
  int AudioWrite(const void *buf, int len, int type, int freq);
  int AudioStop(void);
  int AudioGetInfo(JTMOS_AUDIO_INFO *info);
  DWORD GetAudioPosition(void);
  void SendAudio(const void *buf, int len, int type, int freq);

Compatibility InitAudio()/SendAudio()/GetAudioPosition() names remain, but now
use the syscall-backed kernel audio service instead of the obsolete Postman or
no-op implementations.

SMSH built-in demo
------------------
The kernel contains drivers/audio/audiodemo.c and SMSH exposes it as:

  sound          auto-detect and play a short melody
  sound sb       force Sound Blaster
  sound gus      force Gravis UltraSound
  sound status   show backend/queue/play statistics
  sound stop     stop playback and clear the queue

The demo synthesizes an integer-only 11025 Hz triangle-wave melody and does not
require a sample file or FPU.

Separate ELF32 libc application
-------------------------------
libc/apps/sound.c implements the same demo through public libc calls only.
The built artifact is JTMOS-v58-sound.bin (static ELF32 executable).
It accepts the same sb/gus/status/stop arguments.

Runtime note
------------
The source/build/link checks in this package passed.  This environment has no
qemu-system-i386, Bochs or VBoxManage and no physical ISA sound card, so audible
runtime output on a real/emulated Sound Blaster or GUS is NOT claimed as tested.
