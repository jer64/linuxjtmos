/*
 * JTMOS V59 built-in sound command: demo + streaming 8-bit PCM WAV player.
 * Supported WAV: RIFF/WAVE PCM format 1, mono, unsigned 8-bit, 4000..44100 Hz.
 */
#include "kernel32.h"
#include "audio.h"
#include "audiodemo.h"

#define DEMO_RATE 11025
#define DEMO_CHUNK 512
#define WAV_CHUNK 4096

typedef struct {
    WORD encoding;
    WORD channels;
    DWORD sample_rate;
    DWORD byte_rate;
    WORD block_align;
    WORD bits_per_sample;
    DWORD data_offset;
    DWORD data_size;
} WAV_INFO;

static WORD wav16(const BYTE *p)
{
    return (WORD)((WORD)p[0] | ((WORD)p[1] << 8));
}

static DWORD wav32(const BYTE *p)
{
    return (DWORD)p[0] | ((DWORD)p[1] << 8) | ((DWORD)p[2] << 16) | ((DWORD)p[3] << 24);
}

static int wav_read_exact(int fd, BYTE *buf, int len)
{
    int done=0;
    while(done<len)
    {
        int n=read(fd,buf+done,len-done);
        if(n<=0) return -1;
        done+=n;
    }
    return 0;
}

static int wav_skip(int fd,DWORD n)
{
    if(n>0x7fffffffUL) return -1;
    return lseek(fd,(int)n,SEEK_CUR)<0 ? -1 : 0;
}

static int wav_probe(int fd,WAV_INFO *w)
{
    BYTE h[12],ch[8],fmt[16];
    int have_fmt=0,have_data=0;
    xmemset((char *)w,0,sizeof(*w));

    if(lseek(fd,0,SEEK_SET)<0 || wav_read_exact(fd,h,12)<0) return -2;
    if(memcmp(h,"RIFF",4) || memcmp(h+8,"WAVE",4)) return -1;

    while(!have_fmt || !have_data)
    {
        DWORD size,skip;
        int here;
        if(wav_read_exact(fd,ch,8)<0) break;
        size=wav32(ch+4);
        here=lseek(fd,0,SEEK_CUR);
        if(here<0) return -2;

        if(!memcmp(ch,"fmt ",4))
        {
            if(size<16 || wav_read_exact(fd,fmt,16)<0) return -2;
            w->encoding=wav16(fmt+0);
            w->channels=wav16(fmt+2);
            w->sample_rate=wav32(fmt+4);
            w->byte_rate=wav32(fmt+8);
            w->block_align=wav16(fmt+12);
            w->bits_per_sample=wav16(fmt+14);
            have_fmt=1;
            skip=size-16;
            if(wav_skip(fd,skip+(size&1UL))<0) return -2;
        }
        else if(!memcmp(ch,"data",4))
        {
            w->data_offset=(DWORD)here;
            w->data_size=size;
            have_data=1;
            if(have_fmt) break;
            if(wav_skip(fd,size+(size&1UL))<0) return -2;
        }
        else if(wav_skip(fd,size+(size&1UL))<0) return -2;
    }

    if(!have_fmt) return -3;
    if(!have_data) return -4;
    if(w->encoding!=1) return -5;
    if(w->channels!=1) return -6;
    if(w->bits_per_sample!=8) return -7;
    if(w->block_align!=1 || (w->byte_rate!=0 && w->byte_rate!=w->sample_rate)) return -8;
    if(w->sample_rate<4000UL || w->sample_rate>44100UL) return -9;
    return 0;
}

static void wav_report_error(const char *name,int e,WAV_INFO *w)
{
    printf("sound: %s: ",name);
    if(e==-1) printf("not a RIFF/WAVE file.\n");
    else if(e==-2) printf("truncated or malformed WAV file.\n");
    else if(e==-3) printf("missing fmt chunk.\n");
    else if(e==-4) printf("missing data chunk.\n");
    else if(e==-5) printf("unsupported WAV encoding %d; only PCM format 1 is supported.\n",(int)w->encoding);
    else if(e==-6) printf("unsupported channel count %d; only mono is supported.\n",(int)w->channels);
    else if(e==-7) printf("unsupported sample width %d-bit; only unsigned 8-bit PCM is supported.\n",(int)w->bits_per_sample);
    else if(e==-8) printf("invalid/unsupported PCM block alignment.\n");
    else if(e==-9) printf("unsupported sample rate %d Hz; supported range is 4000..44100 Hz.\n",(int)w->sample_rate);
    else printf("WAV read error.\n");
}

static int demo_backend_name(int backend)
{
    if(backend == AUDIO_BACKEND_SB) { printf("Sound Blaster"); return 0; }
    if(backend == AUDIO_BACKEND_GUS) { printf("Gravis UltraSound"); return 0; }
    printf("none");
    return 0;
}

static BYTE demo_triangle(DWORD phase, int rate)
{
    DWORD half=(DWORD)rate/2UL,v;
    if(phase<half) v=(phase*160UL)/half;
    else v=((DWORD)(rate-1)-phase)*160UL/half;
    if(v>160UL) v=160UL;
    return (BYTE)(48+v);
}

static int demo_note(int hz,int msec)
{
    BYTE buf[DEMO_CHUNK];
    DWORD phase=0;
    int left=(DEMO_RATE*msec)/1000;
    int i,n,wrote;
    while(left>0)
    {
        n=left>DEMO_CHUNK?DEMO_CHUNK:left;
        for(i=0;i<n;++i)
        {
            if(hz==0) buf[i]=0x80;
            else {
                phase+=(DWORD)hz;
                while(phase>=DEMO_RATE) phase-=DEMO_RATE;
                buf[i]=demo_triangle(phase,DEMO_RATE);
            }
        }
        i=0;
        while(i<n)
        {
            wrote=audio_write(buf+i,n-i,AUDIO_FORMAT_U8_MONO,DEMO_RATE);
            if(wrote<0) return wrote;
            if(wrote==0){ SwitchToThread(); continue; }
            i+=wrote;
        }
        left-=n;
    }
    return 0;
}

static int demo_status(void)
{
    JTMOS_AUDIO_INFO info;
    if(audio_get_info(&info)) return 1;
    printf("audio: backend="); demo_backend_name((int)info.backend);
    printf(" rate=%d Hz queued=%d active=%d played=%d underruns=%d\n",
           (int)info.sample_rate,(int)info.queued_bytes,(int)info.active_bytes,
           (int)info.played_bytes,(int)info.underruns);
    return 0;
}

static int wav_play(const char *name,int backend)
{
    WAV_INFO w;
    BYTE buf[WAV_CHUNK];
    DWORD left,start;
    int fd,e,n,off,wr;

    fd=open(name,O_RDONLY);
    if(fd<0){ printf("sound: cannot open WAV file '%s'.\n",name); return 1; }
    e=wav_probe(fd,&w);
    if(e){ wav_report_error(name,e,&w); close(fd); return 1; }

    if(audio_select_backend(backend)<0 || audio_ensure_backend(backend)<0)
    { printf("sound: no supported Sound Blaster/GUS backend found.\n"); close(fd); return 1; }
    audio_stop();

    if(lseek(fd,(int)w.data_offset,SEEK_SET)<0)
    { printf("sound: cannot seek to WAV PCM data.\n"); close(fd); return 1; }

    printf("Playing %s: PCM 8-bit mono, %d Hz, %d bytes via ",name,(int)w.sample_rate,(int)w.data_size);
    demo_backend_name(audio.backend); printf(".\n");

    left=w.data_size;
    while(left)
    {
        n=left>WAV_CHUNK?WAV_CHUNK:(int)left;
        if(wav_read_exact(fd,buf,n)<0)
        { printf("sound: truncated WAV PCM data.\n"); audio_stop(); close(fd); return 1; }
        off=0;
        while(off<n)
        {
            wr=audio_write(buf+off,n-off,AUDIO_FORMAT_U8_MONO,(int)w.sample_rate);
            if(wr<0){ printf("sound: AudioWrite failed (%d).\n",wr); audio_stop(); close(fd); return 1; }
            if(wr==0){ SwitchToThread(); continue; }
            off+=wr;
        }
        left-=(DWORD)n;
    }
    close(fd);

    audio_kick();
    start=(DWORD)(PitGetUsec()/1000UL);
    while(audio_pending_bytes()!=0)
    {
        if((DWORD)((DWORD)(PitGetUsec()/1000UL)-start)>120000UL)
        { printf("sound: playback completion timeout.\n"); return 1; }
        SwitchToThread();
    }
    return demo_status();
}

static void demo_usage(void)
{
    printf("sound - JTMOS 8-bit PCM WAV player\n");
    printf("  sound file.wav\n  sound sb file.wav\n  sound gus file.wav\n");
    printf("  sound             built-in demo\n  sound status\n  sound stop\n");
    printf("WAV support: PCM format 1, mono, unsigned 8-bit, 4000..44100 Hz.\n");
}

int AudioDemoMain(int argc,char **argv)
{
    int backend=AUDIO_BACKEND_AUTO;
    int arg=1,rv;
    DWORD start;

    if(argc>1 && !strcmp(argv[1],"status")) return demo_status();
    if(argc>1 && !strcmp(argv[1],"stop")) return audio_stop();
    if(argc>1 && (!strcmp(argv[1],"-h") || !strcmp(argv[1],"--help")))
    { demo_usage(); return 0; }
    if(argc>1 && !strcmp(argv[1],"sb")){ backend=AUDIO_BACKEND_SB; arg++; }
    else if(argc>1 && !strcmp(argv[1],"gus")){ backend=AUDIO_BACKEND_GUS; arg++; }

    if(arg<argc)
    {
        if(arg+1!=argc){ demo_usage(); return 1; }
        return wav_play(argv[arg],backend);
    }

    if(audio_select_backend(backend)<0 || audio_ensure_backend(backend)<0)
    { printf("sound: no supported Sound Blaster/GUS backend found.\n"); return 1; }
    audio_stop();
    printf("JTMOS sound demo: 8-bit mono %d Hz via ",DEMO_RATE);
    demo_backend_name(audio.backend); printf(".\n");

    rv=demo_note(262,180); if(rv<0) return 1;
    rv=demo_note(330,180); if(rv<0) return 1;
    rv=demo_note(392,180); if(rv<0) return 1;
    rv=demo_note(523,280); if(rv<0) return 1;
    rv=demo_note(392,180); if(rv<0) return 1;
    rv=demo_note(330,180); if(rv<0) return 1;
    rv=demo_note(262,360); if(rv<0) return 1;

    audio_kick();
    start=(DWORD)(PitGetUsec()/1000UL);
    while(audio_pending_bytes()!=0 && (DWORD)((DWORD)(PitGetUsec()/1000UL)-start)<6000UL)
        SwitchToThread();
    return demo_status();
}
