//
#ifndef __INCLUDED_HDSERVICE_H__
#define __INCLUDED_HDSERVICE_H__

//
int hd_init(void);

#endif





