#ifndef __INCLUDED_HDDEV_H__
#define __INCLUDED_HDDEV_H__

//
#include <jtmos/dcpacket.h>

//
int hd_device_call(DEVICE_CALL_PARS);
int hd_register_device(void);

#endif
