// ------------------------------------------------------
// hdDetect.c
// Drive detection code.
// (C) 2003-2004 by Jari Tuominen.
// V37: preserve the original JTMOS/QEMU IDENTIFY behaviour while
//      retaining V35/V36 bounds, timeout and 512-byte IDENTIFY fixes.
// ------------------------------------------------------
#include <stdio.h>
#include "hd.h"
#include "hdDetect.h"

static const char *hd_drive_name(int drive)
{
    return drive ? "slave" : "master";
}

/*
 * The historical JTMOS driver used the command-block STATUS register
 * (0x1F7) for device detection.  Keep that behaviour: some emulators
 * and old controllers are more useful here than the alternate-status
 * register immediately after drive selection/reset.
 */
static BYTE hd_probe_status(void)
{
    return (BYTE)inportb(0x1F7);
}

static void hd_probe_dump(int drive, const char *stage)
{
    BYTE st=hd_probe_status();
    BYTE ast=(BYTE)inportb(0x3F6);
    BYTE er=(BYTE)inportb(0x1F1);
    BYTE sc=(BYTE)inportb(0x1F2);
    BYTE lo=(BYTE)inportb(0x1F3);
    BYTE mi=(BYTE)inportb(0x1F4);
    BYTE hi=(BYTE)inportb(0x1F5);

    printk("IDE probe %s: %s status=0x%x alt=0x%x err=0x%x sc=0x%x lba=%x:%x:%x\n",
           hd_drive_name(drive), stage, st, ast, er, sc, hi, mi, lo);
}

/* Detect drive(master or slave) on primary IDE channel. */
int hdDetect(HD *h)
{
    int i,registered=0;

    hdReset1();

    for(i=0; i<2; i++)
    {
        if((registered=hdTryDevice(h,i))) break;
    }

    if(registered && hdPrimaryDetect(h)) registered=0;
    return registered;
}

void RecalculateTotalBlocks(HD *h)
{
#ifdef FORCE_BLOCKS
    h->n_blocks = FORCE_BLOCKS;
#else
    h->n_blocks = h->cylinders*h->heads*h->sectors;
#endif
}

/*
 * Receive ATA IDENTIFY data. Returns zero on success.
 *
 * Important V37 compatibility rule:
 *   Do NOT reject status 0x00 merely because it was observed after
 *   selecting master/slave.  The original working JTMOS driver issued
 *   IDENTIFY first and judged the device from the command response.
 */
int GetHDParam(HD *h, int drive, WORD *hdp)
{
    int i;
    BYTE status,mid,high;
    DWORD start;
    HDPARAM *hh;

    if(h==NULL) panic("GetHDParam called with h==NULL");
    if(sizeof(HDPARAM) != 512)
    {
        printk("IDE: internal HDPARAM size error: %d (expected 512).\n",(int)sizeof(HDPARAM));
        return 1;
    }

    /* Select device exactly as the historical driver did. */
    outportb(0x1F6, drive ? 0xB0 : 0xA0);
    hd400ns();

    /*
     * ATA IDENTIFY protocol.  Clearing these registers is harmless for
     * ATA disks and allows ATAPI signatures to be recognized later.
     * Crucially, there is no pre-IDENTIFY "status==0 => absent" exit.
     */
    outportb(0x1F2,0);
    outportb(0x1F3,0);
    outportb(0x1F4,0);
    outportb(0x1F5,0);
    outportb(0x1F7,0xEC);
    hd400ns();

    /* Only now is zero/FF meaningful as a failed command response. */
    status=hd_probe_status();
    if(status==0x00 || status==0xFF)
    {
        /*
         * One exact legacy retry: old JTMOS wrote only drive/head + ECh.
         * This costs almost nothing and preserves compatibility with
         * controllers/emulators that dislike the cleared task-file probe.
         */
        outportb(0x1F6, drive ? 0xB0 : 0xA0);
        hd400ns();
        outportb(0x1F7,0xEC);
        hd400ns();
        status=hd_probe_status();
        if(status==0x00 || status==0xFF)
        {
            hd_probe_dump(drive,"IDENTIFY produced no regular status");
            return 1;
        }
        printk("IDE probe %s: legacy IDENTIFY retry accepted (status=0x%x).\n",
               hd_drive_name(drive),status);
    }

    /* IDENTIFY may hold BSY for a while. */
    start=GetTickCount();
    while((status=hd_probe_status()) & HD_STATUS_BUSY)
    {
        if((DWORD)(GetTickCount()-start)>=HD_IDENTIFY_TIMEOUT_MS)
        {
            hd_probe_dump(drive,"IDENTIFY BSY timeout");
            return 1;
        }
        hd400ns();
    }

    /* After BSY clears, ATAPI devices report a non-zero signature. */
    mid=(BYTE)inportb(0x1F4);
    high=(BYTE)inportb(0x1F5);
    if(mid!=0 || high!=0)
    {
        hd_probe_dump(drive,"non-ATA signature (ATAPI/other)");
        return 1;
    }

    /* Wait for DRQ or an explicit ATA error. */
    start=GetTickCount();
    for(;;)
    {
        status=hd_probe_status();
        if(status==0x00 || status==0xFF)
        {
            hd_probe_dump(drive,"device vanished waiting DRQ");
            return 1;
        }
        if(!(status & HD_STATUS_BUSY))
        {
            if(status & HD_STATUS_ERROR)
            {
                hd_probe_dump(drive,"IDENTIFY ERR");
                return 1;
            }
            if(status & HD_STATUS_DRQ) break;
        }
        if((DWORD)(GetTickCount()-start)>=HD_IDENTIFY_TIMEOUT_MS)
        {
            hd_probe_dump(drive,"IDENTIFY DRQ timeout");
            return 1;
        }
        hd400ns();
    }

    for(i=0; i<256; i++)
    {
        WORD w=inportw(0x1F0);
        if(hdp) hdp[i]=w;
    }

    if(hdp)
    {
        hh=(HDPARAM *)hdp;
        StrFix(hh->ModelNumber,40);
        StrFix(hh->FirmwareRev,8);
        StrFix(hh->SerialNumber,20);
    }

    printk("IDE probe %s: ATA IDENTIFY succeeded (status port 0x1F7).\n",hd_drive_name(drive));
    return 0;
}

int hdTryDevice(HD *h, int selection)
{
    int tries;
    h->slave=selection;

    for(tries=0; tries<2; tries++)
    {
        if(!GetHDParam(h,h->slave,NULL)) return 1;
        /* Preserve the old driver's two complete IDENTIFY attempts. */
        hd400ns();
    }
    return 0;
}

int StrFix(BYTE *s, int l)
{
    int i;
    DWORD v1,v2;
    for(i=0; i<(l-1); i+=2)
    {
        v1=s[i+0]; v2=s[i+1];
        s[i+0]=v2; s[i+1]=v1;
    }
    return 0;
}

int hdPrimaryDetect(HD *h)
{
    int i;

    h->blocksize=512;
    memset(&h->hp,0,sizeof(HDPARAM));
    if(GetHDParam(h,h->slave,(WORD *)&h->hp))
    {
        printk("IDE: second IDENTIFY failed for selected %s drive.\n",hd_drive_name(h->slave));
        return 1;
    }

    h->lbaMode = h->hp.mod.n_lba ? TRUE : FALSE;
    HD_SetLBAMode(h->lbaMode);
    h->n_lba=h->hp.mod.n_lba;

    if(h->lbaMode)
    {
        h->cylinders=1;
        h->heads=1;
        h->sectors=1;
        h->n_blocks=h->n_lba;
        if((DWORD)h->n_blocks>HD_LBA28_MAX_SECTORS)
            h->n_blocks=(int)HD_LBA28_MAX_SECTORS;
        h->units=1;
    }
    else
    {
        h->cylinders=h->hp.cylinders;
        h->heads=h->hp.heads;
        h->sectors=h->hp.sectors;
        RecalculateTotalBlocks(h);
        hdDetermineUnits(h);
    }

    if(h->n_lba || h->hp.cylinders)
    {
        for(i=0;i<40;i++) h->ModelNumber[i]=h->hp.ModelNumber[i];
        h->ModelNumber[i]=0;
        for(i=0;i<8;i++) h->FirmwareRev[i]=h->hp.FirmwareRev[i];
        h->FirmwareRev[i]=0;
        for(i=0;i<20;i++) h->SerialNumber[i]=h->hp.SerialNumber[i];
        h->SerialNumber[i]=0;

        printk("HD parameters: ");
        if(h->lbaMode)
            printk("[LBA MODE] %u LBA sectors (%uM)\n",
                   (DWORD)h->n_lba, ((DWORD)h->n_lba*512UL)/(1024UL*1024UL));
        else
            printk("[CHS MODE] Cylinders=%d, Heads=%d, Sectors=%d\n",
                   h->cylinders,h->heads,h->sectors);
        printk("HD MODEL   : %s\n",h->ModelNumber);
        printk("HD SERIAL  : %s  ",h->SerialNumber);
        printk("HD FIRMREV : %s\n",h->FirmwareRev);
    }
    else
    {
        printk("Warning: IDENTIFY returned no usable LBA/CHS geometry.\n");
        return 1;
    }
    return 0;
}

void hdDetermineUnits(HD *h)
{
    if(h->n_blocks > (2*1024*768)) h->units=16;
    else if(h->n_blocks > (2*1024*256)) h->units=8;
    else if(h->n_blocks > (2*1024*80)) h->units=4;
    else if(h->n_blocks > (2*1024*20)) h->units=2;
    else h->units=1;
    printk("%s: 512 bytes units per block = %d\n",__FUNCTION__,h->units);
}
