JTMOS LaunchApp ELF32 + POSIX-style mmap
========================================

This package combines the ELF32 LaunchApp work with the supplied
JTMOS_mm_0.4.1_fixed memory manager.

IMPORTANT API CHANGE FROM THE PREVIOUS ELF32 PROTOTYPE
------------------------------------------------------
kmalloc is NOT mmap-like.

Kernel allocator:

    void *kmalloc(int size);
    void  kfree(void *ptr);

POSIX-call-compatible mapping API:

    #include <sys/mman.h>

    void *mmap(void *addr, size_t length, int prot, int flags,
               int fd, off_t offset);
    int munmap(void *addr, size_t length);

Standard heap API:

    #include <stdlib.h>

    void *malloc(size_t size);
    void free(void *ptr);
    void *calloc(size_t nmemb, size_t size);
    void *realloc(void *ptr, size_t size);
    void *reallocarray(void *ptr, size_t nmemb, size_t size);

FILES ADDED / CHANGED
---------------------
LaunchApp.c
    ELF32/i386 ET_EXEC loader. Uses mmap() for the kernel-side backing
    allocation. Maps the application stack and each PT_LOAD separately into
    the JTMOS per-process page table.

LaunchApp.h
    ELF32 process layout constants.

elf32.h
    Self-contained ELF32 structures/constants.

jtmos_elf32.ld
    Example linker script. Application text begins at 0x80004000.

mm/mmap.c
    mmap()/munmap(), page alignment helpers, and process mapping helpers.

mm/sys/mman.h
    PROT_*, MAP_*, MAP_FAILED and POSIX-style prototypes.

mm/stdlib.h
    malloc/free/calloc/realloc/reallocarray prototypes.

mm/mmAlloc.c + mm/mmAlloc.h
    kmalloc is one-argument again. Standard heap functions are implemented on
    top of the existing JTMOS page allocator. malloc1/free1 are retained for
    old code that wants explicit debug-property names.

mm/paging.c + mm/paging.h
    pg_protectmemory() added so PROT_WRITE/PROT_NONE can be represented in
    IA-32 PTEs.

mm/mm.h
    Adds the 16 MiB ELF32 process-window definitions and process-page mapping
    helpers needed by LaunchApp.

MMAP IMPLEMENTATION STATUS
--------------------------
Implemented:
  * mmap(NULL, len, prot, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0)
  * MAP_SHARED|MAP_ANONYMOUS (same physical semantics for now; no fork/COW)
  * exact-address MAP_FIXED/MAP_FIXED_NOREPLACE when the target is free
  * zero-filled anonymous pages
  * PROT_NONE / PROT_READ / PROT_WRITE page permissions
  * PROT_EXEC in the API
  * munmap() of one complete mmap allocation

Not implemented yet:
  * file-backed mmap
  * partial munmap / descriptor splitting
  * destructive POSIX MAP_FIXED replacement of an existing mapping
  * copy-on-write MAP_PRIVATE file mappings
  * NX enforcement for PROT_EXEC (plain IA-32 non-PAE has no NX bit)
  * user-space syscall entry/exit plumbing; mmap() here is the kernel-side
    implementation that can later be exposed through the JTMOS syscall ABI

ELF32 MEMORY LAYOUT
-------------------
0x80000000 - 0x80003fff   initial 16 KiB stack/runtime, READ|WRITE
0x80004000 - ...          ELF32 PT_LOAD segments
0x81000000                end of the current 16 MiB application window

Each PT_LOAD obtains protection from its ELF p_flags:

    PF_R -> PROT_READ
    PF_W -> PROT_WRITE
    PF_X -> PROT_EXEC

On current IA-32 paging, READ versus READ|EXEC cannot be distinguished and NX
cannot be enforced. Write protection is enforced through the PTE RW bit.

BUILD INTEGRATION
-----------------
Add mm/mmap.c to the MM/kernel object list and make the mm directory an include
path so these work:

    #include <sys/mman.h>
    #include <stdlib.h>

For example, the relevant object list gains something equivalent to:

    mm/mmAlloc.o mm/mmEntry.o mm/mmBit.o mm/paging.o mm/mmap.o

Compile LaunchApp.c with the same mm include directory.

APPLICATION LINKING
-------------------
Example:

    i686-elf-gcc -m32 -ffreestanding -fno-pie -c app.c -o app.o
    i686-elf-ld -m elf_i386 -T jtmos_elf32.ld app.o -o app.elf
    readelf -h -l app.elf

The ELF must be ELFCLASS32, little-endian, EM_386, ET_EXEC and its PT_LOAD
segments must fit inside the JTMOS 0x80004000..0x80ffffff area.

VALIDATION PERFORMED
--------------------
The changed LaunchApp.c, mm/mmap.c, mm/mmAlloc.c and mm/paging.c were checked
with GCC in 32-bit freestanding GNU89 syntax mode using -Wall -Wextra -Werror.
No syntax warnings/errors remained in the changed code under that i386 model.
