// ===========================================================
// LaunchApp.c - ELF32 application launcher for JTMOS.
//
// Based on the original 2002-2005 LaunchApp prototype by
// Jari Tuominen.  The raw-binary copy has been replaced by an
// ELF32/i386 PT_LOAD loader while preserving the existing JTMOS
// process/thread ownership and page-table model.
// ===========================================================

#include "int.h"
#include "cpu.h"
#include "sysglvar.h"
#include "kernel32.h" // FATALEXCEPTION
#include "delay.h"
#include "threads.h"
#include "caster.h"
#include "mm.h"
#include "mmAlloc.h"
#include <sys/mman.h>
#include "elf32.h"
#include "LaunchApp.h"

#define ELF32_MAX_PROGRAM_HEADERS 128

static int range_inside(DWORD offset, DWORD amount, DWORD total)
{
    if(offset > total)
        return FALSE;
    if(amount > (total - offset))
        return FALSE;
    return TRUE;
}

static int add_overflows(DWORD a, DWORD b)
{
    return a > (0xffffffffUL - b);
}

static const Elf32_Phdr *elf32_program_header(const BYTE *abin,
                                               const Elf32_Ehdr *eh,
                                               int index)
{
    DWORD off;

    off = eh->e_phoff + ((DWORD)index * (DWORD)eh->e_phentsize);
    return (const Elf32_Phdr *)(abin + off);
}

static int elf32_validate(const BYTE *abin, DWORD length,
                          DWORD *image_end, DWORD *entry)
{
    const Elf32_Ehdr *eh;
    const Elf32_Phdr *ph;
    DWORD ph_bytes;
    DWORD seg_end;
    DWORD max_end;
    int entry_is_executable;
    int load_count;
    int i;

    if(abin == 0 || length < sizeof(Elf32_Ehdr))
        return LAUNCHAPP_ELF_BAD_ARGUMENT;

    eh = (const Elf32_Ehdr *)abin;

    if(eh->e_ident[EI_MAG0] != ELFMAG0 ||
       eh->e_ident[EI_MAG1] != ELFMAG1 ||
       eh->e_ident[EI_MAG2] != ELFMAG2 ||
       eh->e_ident[EI_MAG3] != ELFMAG3)
        return LAUNCHAPP_ELF_BAD_MAGIC;

    if(eh->e_ident[EI_CLASS] != ELFCLASS32 ||
       eh->e_ident[EI_DATA] != ELFDATA2LSB ||
       eh->e_ident[EI_VERSION] != EV_CURRENT ||
       eh->e_version != EV_CURRENT ||
       eh->e_machine != EM_386 ||
       eh->e_type != ET_EXEC)
        return LAUNCHAPP_ELF_UNSUPPORTED;

    if(eh->e_ehsize != sizeof(Elf32_Ehdr) ||
       eh->e_phentsize != sizeof(Elf32_Phdr) ||
       eh->e_phnum == 0 ||
       eh->e_phnum > ELF32_MAX_PROGRAM_HEADERS)
        return LAUNCHAPP_ELF_BAD_HEADER;

    if(add_overflows((DWORD)eh->e_phnum * (DWORD)eh->e_phentsize,
                     eh->e_phoff))
        return LAUNCHAPP_ELF_BAD_HEADER;

    ph_bytes = (DWORD)eh->e_phnum * (DWORD)eh->e_phentsize;
    if(!range_inside(eh->e_phoff, ph_bytes, length))
        return LAUNCHAPP_ELF_BAD_HEADER;

    max_end = RTCODE;
    load_count = 0;
    entry_is_executable = FALSE;

    for(i = 0; i < eh->e_phnum; ++i)
    {
        ph = elf32_program_header(abin, eh, i);
        if(ph->p_type != PT_LOAD)
            continue;

        ++load_count;

        if(ph->p_memsz < ph->p_filesz)
            return LAUNCHAPP_ELF_BAD_SEGMENT;

        if(!range_inside(ph->p_offset, ph->p_filesz, length))
            return LAUNCHAPP_ELF_BAD_SEGMENT;

        if(add_overflows(ph->p_vaddr, ph->p_memsz))
            return LAUNCHAPP_ELF_BAD_SEGMENT;

        seg_end = ph->p_vaddr + ph->p_memsz;

        /* Keep the original 16 KiB stack/runtime area reserved. */
        if(ph->p_vaddr < RTCODE || seg_end > MM_USER_TOP)
            return LAUNCHAPP_ELF_BAD_SEGMENT;

        /* ELF requires p_vaddr and p_offset to be congruent modulo p_align
           when p_align is greater than one. */
        if(ph->p_align > 1)
        {
            if((ph->p_align & (ph->p_align - 1)) != 0)
                return LAUNCHAPP_ELF_BAD_SEGMENT;
            if((ph->p_vaddr % ph->p_align) != (ph->p_offset % ph->p_align))
                return LAUNCHAPP_ELF_BAD_SEGMENT;
        }

        if(seg_end > max_end)
            max_end = seg_end;

        if((ph->p_flags & PF_X) != 0 &&
           eh->e_entry >= ph->p_vaddr &&
           eh->e_entry < seg_end)
            entry_is_executable = TRUE;
    }

    if(load_count == 0)
        return LAUNCHAPP_ELF_BAD_SEGMENT;

    if(eh->e_entry < RTCODE || eh->e_entry >= MM_USER_TOP ||
       !entry_is_executable)
        return LAUNCHAPP_ELF_BAD_ENTRY;

    *image_end = max_end;
    *entry = eh->e_entry;
    return LAUNCHAPP_ELF_OK;
}

static int elf32_copy_segments(const BYTE *abin,
                               BYTE *app_space,
                               const Elf32_Ehdr *eh)
{
    const Elf32_Phdr *ph;
    BYTE *dst;
    DWORD i;
    DWORD n;

    for(i = 0; i < eh->e_phnum; ++i)
    {
        ph = elf32_program_header(abin, eh, (int)i);
        if(ph->p_type != PT_LOAD)
            continue;

        dst = app_space + (ph->p_vaddr - RTBASE);

        for(n = 0; n < ph->p_filesz; ++n)
            dst[n] = abin[ph->p_offset + n];

        /* .bss and any other memsz > filesz tail. */
        for(n = ph->p_filesz; n < ph->p_memsz; ++n)
            dst[n] = 0;
    }

    return LAUNCHAPP_ELF_OK;
}


static int elf32_segment_prot(const Elf32_Phdr *ph)
{
    int prot;

    prot = PROT_NONE;
    if(ph->p_flags & PF_R)
        prot |= PROT_READ;
    if(ph->p_flags & PF_W)
        prot |= PROT_WRITE;
    if(ph->p_flags & PF_X)
        prot |= PROT_EXEC;
    return prot;
}

static int elf32_map_process_image(int pid, BYTE *app_space,
                                   const Elf32_Ehdr *eh,
                                   DWORD stack_base)
{
    const Elf32_Phdr *ph;
    DWORD map_start;
    DWORD map_end;
    DWORD seg_end;
    BYTE *source;
    int prot;
    int i;

    /* Keep legacy ELF link addresses and place the enlarged stack after
       the loaded image so existing 0x80004000 applications remain valid. */
    if(mm_map_process_range(pid, stack_base,
                            app_space + (stack_base - RTBASE),
                            APP_STACK_SIZE, PROT_READ | PROT_WRITE) != 0)
        return -1;

    for(i = 0; i < eh->e_phnum; ++i)
    {
        ph = elf32_program_header((const BYTE *)eh, eh, i);
        if(ph->p_type != PT_LOAD || ph->p_memsz == 0)
            continue;

        seg_end = ph->p_vaddr + ph->p_memsz;
        map_start = mm_page_align_down(ph->p_vaddr);
        map_end = mm_page_align_up(seg_end);
        if(map_end == 0 || map_end <= map_start)
            return -1;

        source = app_space + (map_start - RTBASE);
        prot = elf32_segment_prot(ph);

        if(mm_map_process_range(pid, map_start, source,
                                map_end - map_start, prot) != 0)
            return -1;
    }

    return 0;
}

void Indication(void)
{
    nop();
    nop();
    nop();
    nop();
}

int LaunchAppIsELF32(const BYTE *abin, int length)
{
    if(abin == 0 || length < 5)
        return FALSE;

    return abin[EI_MAG0] == ELFMAG0 &&
           abin[EI_MAG1] == ELFMAG1 &&
           abin[EI_MAG2] == ELFMAG2 &&
           abin[EI_MAG3] == ELFMAG3 &&
           abin[EI_CLASS] == ELFCLASS32;
}

/* Launch application with defaults. */
int LaunchApp(BYTE *abin, int length)
{
    /* Preserve the prototype's effective 64 KiB default. ELF PT_LOAD data
       can grow the allocation automatically beyond this minimum. */
    return LaunchAppEx(abin, length, DEF_APP_SPACE_K / 64,
                       GetCurrentDNR(), GetCurrentDB());
}

/* Legacy compatibility helper. Keep the original two-argument ABI for any
   older kernel code that still calls AdaptAppPages() directly. New ELF code
   uses mm_map_process_range() with an explicit length. */
void AdaptAppPages(int pid, DWORD srcOffset)
{
    DWORD *dst;
    DWORD src;
    DWORD page;
    DWORD i;

    dst = (DWORD *)(0x00600000UL + ((DWORD)pid * 1024UL * 16UL));

    for(i = 0; i < 4096; ++i)
        dst[i] = 0;

    src = srcOffset / MM_PAGE_SIZE;
    for(i = 0; i < 4096; ++i)
    {
        page = GetPage(src + i);
        if(page < 8)
            break;
        dst[i] = page;
    }
}

/*
 * LaunchAppEx()
 *
 * abin/length : complete ELF32 file in memory
 * memkb       : minimum process backing allocation in KiB
 * dnr/db      : inherited JTMOS directory/database context
 *
 * Supported ELF profile:
 *   - ELFCLASS32
 *   - little endian
 *   - EM_386
 *   - ET_EXEC
 *   - PT_LOAD segments linked at >= 0x80004000
 *
 * V29 keeps the legacy 0x80004000 ELF link address but places a 256 KiB
 * stack immediately after the page-aligned ELF image.
 * Returns a PID, or 0 on error.
 */
int LaunchAppEx(BYTE *abin, int length, int memkb, int dnr, int db)
{
    const Elf32_Ehdr *eh;
    BYTE *appSpace;
    DWORD image_end;
    DWORD required_bytes;
    DWORD requested_bytes;
    DWORD bytes;
    DWORD stack_base;
    DWORD stack_end;
    DWORD entry;
    int flags;
    int pid;
    int status;

    if(abin == 0 || length <= 0)
        return 0;

    status = elf32_validate(abin, (DWORD)length, &image_end, &entry);
    if(status != LAUNCHAPP_ELF_OK)
    {
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        printk("%s: invalid/unsupported ELF32 image (%d).\n",
               __FUNCTION__, status);
        return 0;
    }

    stack_base = mm_page_align_up(image_end);
    if(stack_base == 0 || stack_base < image_end ||
       stack_base > RTBASE + MM_USER_SIZE - APP_STACK_SIZE)
    {
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        return 0;
    }
    stack_end = stack_base + APP_STACK_SIZE;
    required_bytes = mm_page_align_up(stack_end - RTBASE);
    if(required_bytes == 0 || required_bytes > MM_USER_SIZE)
    {
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        return 0;
    }

    if(memkb < 256)
        memkb = 256;

    if((DWORD)memkb > (0xffffffffUL / 1024UL))
        return 0;

    requested_bytes = mm_page_align_up((DWORD)memkb * 1024UL);
    if(requested_bytes == 0)
        return 0;

    bytes = requested_bytes;
    if(bytes < required_bytes)
        bytes = required_bytes;

    if(bytes > MM_USER_SIZE)
    {
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        printk("%s: ELF32 process requests %d KiB; maximum is %d KiB.\n",
               __FUNCTION__, bytes / 1024UL, MM_USER_SIZE / 1024UL);
        return 0;
    }

    flags = get_eflags();
    disable();

    appSpace = (BYTE *)mmap(NULL, bytes,
                             PROT_READ | PROT_WRITE,
                             MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if(appSpace == MAP_FAILED)
    {
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        set_eflags(flags);
        return 0;
    }

    eh = (const Elf32_Ehdr *)abin;
    status = elf32_copy_segments(abin, appSpace, eh);
    if(status != LAUNCHAPP_ELF_OK)
    {
        munmap(appSpace, bytes);
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        set_eflags(flags);
        return 0;
    }

    /* Original JTMOS selectors are preserved for now. User/kernel privilege
       separation can later be added without changing the ELF loader. */
    appseg = 0x08;
    appstackoffs = stack_end - 16; /* 256 KiB stack grows down after ELF image */
    appoffset = entry;
    apprealoffs = appSpace;

    pid = _createAppThread(appseg, appseg + 8,
                              appSpace, appoffset, appstackoffs);
    if(!pid)
    {
        munmap(appSpace, bytes);
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        set_eflags(flags);
        return 0;
    }

    /* Install the dynamically placed 256 KiB stack and ELF PT_LOAD pages.
       Segment PF_R/PF_W/PF_X
       flags are translated to JTMOS page protections where IA-32 permits it.
       Interrupts are still disabled here, so the application cannot race the
       mapping setup. */
    mm_clear_process_space(pid);
    if(elf32_map_process_image(pid, appSpace, eh, stack_base) != 0)
    {
        mm_clear_process_space(pid);
        /* No thread-destroy primitive was present in the supplied prototype.
           Do not free appSpace here: _createAppThread() already references it. */
        caster.error = CASTER_ERROR_LAUNCHAPPERROR;
        printk("%s: unable to map ELF32 process pages for PID%d.\n",
               __FUNCTION__, pid);
        set_eflags(flags);
        return 0;
    }

    ChangeChunkOwner((void *)appSpace, pid);

    SetThreadDNR(pid, dnr);
    SetThreadDB(pid, db);
    ReportMessage("%s: Set PID%d DNR/DB to %d/%d\n",
                  __FUNCTION__, pid, dnr, db);

    /* Mandatory thread accounting used by the existing deallocator. */
    thread_base[pid] = appSpace;
    thread_ss[pid] = appseg + 8;
    thread_selector[pid] = appseg;
    thread_banks[pid] = (bytes + (64UL * 1024UL - 1)) /
                                  (64UL * 1024UL);
    thread_memkb[pid] = bytes / 1024UL;
    SetThreadPriority(pid, THREAD_PRIORITY_NORMAL);

    SetThreadType(pid,
                  (GetThreadType(pid) & (~THREAD_TYPE_KERNEL))
                  | THREAD_TYPE_APPLICATION);

    TrackThread(pid, TRUE);

    ReportMessage("%s: ELF32 PID%d entry=0x%x base=0x%x memory=%d KiB stack=%x-%x\n",
                  __FUNCTION__, pid, appoffset,
                  thread_base[pid], bytes / 1024UL,
                  stack_base, stack_end);

    Indication();
    set_eflags(flags);
    return pid;
}
