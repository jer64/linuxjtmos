#ifndef __INCLUDED_LAUNCHAPP_H__
#define __INCLUDED_LAUNCHAPP_H__

/* JTMOS process virtual layout.  Keep this header dependency-light because
 * threads.h includes it very early while kernel32.h is still being assembled. */
#define RTBASE               0x80000000UL
#define RTCODE               (RTBASE + 0x00004000UL)
#define APP_STACK_SIZE       (256UL * 1024UL)
#define APP_GUARD_SIZE       4096UL
#define APPLICATION_START_AD RTCODE
#define DEF_APP_SPACE_K      4096

#define LAUNCHAPP_ELF_OK                 0
#define LAUNCHAPP_ELF_BAD_ARGUMENT      -1
#define LAUNCHAPP_ELF_BAD_MAGIC         -2
#define LAUNCHAPP_ELF_UNSUPPORTED       -3
#define LAUNCHAPP_ELF_BAD_HEADER        -4
#define LAUNCHAPP_ELF_BAD_SEGMENT       -5
#define LAUNCHAPP_ELF_BAD_ENTRY         -6
#define LAUNCHAPP_ELF_NO_MEMORY         -7
#define LAUNCHAPP_ELF_CREATE_FAILED     -8
#define LAUNCHAPP_ELF_MAP_FAILED        -9

int LaunchApp(BYTE *abin, int length);
int LaunchAppEx(BYTE *abin, int length, int memkb, int dnr, int db);
int LaunchAppIsELF32(const BYTE *abin, int length);
void AdaptAppPages(int pid, DWORD srcOffset);

extern DWORD launchapp_cleartogo;

#endif
