#ifndef __INCLUDED_GRAOS_BOOT_H__
#define __INCLUDED_GRAOS_BOOT_H__
int GraOSBootReady(void);
int GraOSBootInstall(void);
int GraOSBootStart(void);
#endif
