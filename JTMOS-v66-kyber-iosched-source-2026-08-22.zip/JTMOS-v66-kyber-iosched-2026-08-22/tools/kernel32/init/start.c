/**** JTMOS KERNEL - (C) 1999-2008 by Jari Tuominen. ***
 *
 *  KERNEL FIRST ROUTINE
 *
 */

// Required includes
#include "kernel32.h"	// Preferences for kernel32(init)
#include "keropt.h"	// Not included in kernel32.h !

//
static WORD *buf = 0xB8000;

// ^^================ BOOT UP =================================^^
// NOTICE: Keep this function on top of the code.
// it has to be in top of the file when Boot sector calls it.
// boot_up = int/llint.asm boot_up subroutine,
// which'll call up this C function.
/*
 * The BIOS loader enters the kernel at linear 0x10000 after it has already
 * established the protected-mode stack and flat segments.  Preserve that
 * loader-owned stack exactly: the C bootstrap must not rewrite SS or ESP.
 *
 * Keep this entry naked only so GCC cannot emit a prologue before we have
 * normalised EFLAGS.  _boot_up_c() is noreturn, so a jump is intentional.
 */
__attribute__((naked,noreturn)) void _boot_up(void)
{
    __asm__ __volatile__(
        "cli\n\t"
        "cld\n\t"
        /* Start C code with a clean EFLAGS image: reserved bit 1 set,
         * IF/DF/NT clear.  Do not alter the loader-provided stack. */
        "pushl $0x00000002\n\t"
        "popfl\n\t"
        "cld\n\t"
        "xorl %ebp, %ebp\n\t"
        "jmp _boot_up_c\n\t"
    );
}


/*
 * Do not trust the old 8042-only A20 sequence blindly.  In particular, if
 * A20 stays closed then the first paging memset at physical 0x00200000 aliases
 * low memory and destroys the running system.  Force the fast A20 gate and
 * verify it before KernelInit() touches any fixed structures above 1 MiB.
 */
static void KernelFastA20Enable(void)
{
    BYTE v;
    __asm__ __volatile__("inb $0x92,%0" : "=a" (v));
    v |= 0x02;          /* A20 enable */
    v &= (BYTE)~0x01;   /* never request fast reset */
    __asm__ __volatile__("outb %0,$0x92" : : "a" (v));
    __asm__ __volatile__("jmp 1f\n1: jmp 1f\n1:" : : : "memory");
}

static int KernelA20Enabled(void)
{
    volatile BYTE *low  = (volatile BYTE *)0x00000500;
    volatile BYTE *high = (volatile BYTE *)0x00100500;
    BYTE low_old, high_old;
    int enabled;

    low_old = *low;
    high_old = *high;

    *low = 0x00;
    *high = 0xFF;
    __asm__ __volatile__("" : : : "memory");
    enabled = (*low == 0x00);

    /* Restore in this order; it is safe even when high aliases low. */
    *high = high_old;
    *low = low_old;
    __asm__ __volatile__("" : : : "memory");
    return enabled;
}

static void KernelEnsureA20(void)
{
    KernelFastA20Enable();
    if(!KernelA20Enabled())
    {
        DebugSerialWrite("[A20] FATAL: A20 gate is still disabled; halting before high-memory writes.\n");
        for(;;)
            __asm__ __volatile__("cli; hlt");
    }
    DebugSerialWrite("[A20] verified: addresses above 1 MiB do not alias low memory.\n");
}

__attribute__ ((__noreturn__)) void _boot_up_c(void)
{
    EGASAFE = TRUE;
    KINIT = FALSE;
    KernelInitPassed = FALSE;
    mallocOK = FALSE;

    screens[0].buf = (char *)0xB8000;

    DebugSerialEarlyInit();
    DebugSerialWrite("\n[JTMOS V18] debug active; C entry inherits bootloader stack, ESP=");
    DebugSerialWriteHex32(GETESP());
    DebugSerialWrite("\n");
    KernelEnsureA20();

    KernelInit();
    halt();
}

