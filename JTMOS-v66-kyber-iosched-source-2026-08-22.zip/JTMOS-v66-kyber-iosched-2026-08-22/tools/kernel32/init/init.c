/**** JTMOS KERNEL - (C) 1999-2014,2017 by Jari Tuominen (jari.t.tuominen@gmail.com). ***
 *
 *  kernel32.c - KERNEL INIT PROCESS.
 *  The First Process Of The Operating System To Be Run.
 *
 * This software is distributed under GPL license
 * (see file 'COPYING').
 * See keropt.h for kernel options.
 *
 * New XML-based init function.
 */

//
#include <stdio.h>
// STATIC DATA ARRAYS, included once:
// Only include this once.
// This header includes array of
// complete boot sector binary,
// which'll be used when formatting
// a system disk.
#include "boot_bin.h"
// Hard disk driver.
#include "testdrv.h"
// System Maintenance Debug Shell
#if JTMOS_MOD_SH
#include "sh.h"
#endif
//
#define CHECKDEBUG debugKey();
//
#include "jtmfat.h"
#include "fs/jtmfs/root.h"
#include "drivers/sysdev/sysdev.h"
#if JTMOS_MOD_GRAOS_BOOT
#include "graos_boot.h"
#endif
#if JTMOS_MOD_NETWORK
#include "networkControl.h"
#endif

// Safe mode in the beginning of system start up
DWORD KernelInitPassed=FALSE;
int EGASAFE=TRUE;
int KINIT=0;
BIOS_DATA bios_data;

// DUMMY CODE:	PATH, CURRENT COMMAND STRING,
//		COMMAND PARAMETERS FOR /MINIMAL SYSTEM SHELL/
// Active device.
char str_device[255];
// f.e. "ls" "/" "-la"
// created using sptstr
char *cmdpar[100];
// this string will contain the entire command line
char *wholestring;

//---------------------------------------------------------------
void WaitSystemStart(void)
{
	//
	while(!systemStarted)
	{
		//
		SwitchToThread();
	}
}

//---------------------------------------------------------------
//
// Fix The EGA Memory (Text Mode)
// Nice and clean...
//
int FixEgaMemory(void)
{
	int i;
	char *p;

	p = 0xb8000;

	for(i=0; i<(80*25*2 * 4); i+=2)
	{
		p[i+0] = ' ';
		p[i+1] = 0x07;
	}
	
	return 0;
}

//---------------------------------------------------------------
// Start the SMSH shell process
void StartShellProcess(void)
{
#if JTMOS_MOD_SH
	//
	disable();

	//
	ThreadCreateStack(&ShellThread, JTMOS_MIN_DYNAMIC_STACK);
	ShellThread.pid=create_thread(
		ShellThread.stack,ShellThread.l_stack,run_shell);
	// With start up
	SetThreadTerminal(ShellThread.pid, 0);
	IdentifyThread(ShellThread.pid, "shell");

	//
/*	ThreadCreateStack(&ShellThread2, JTMOS_MIN_DYNAMIC_STACK);
	ShellThread2.pid=create_thread(
		ShellThread2.stack,ShellThread2.l_stack,run_shell);
	// With start up
	SetThreadTerminal(ShellThread2.pid, 1);
	IdentifyThread(ShellThread2.pid, "shell");*/
	
	//
	enable();

	//
	return;
#else
	printk("SMSH: optional shell module is disabled in this kernel build.\n");
	return;
#endif
}

//////////////////////////////////////////////////////////////////7
//
void BackupFailsafeSystem(void)
{
	int key,i;
	char *p;
	
	// Beginw with an information of devices avvailable:
	// DEVICES AVAILABLE:
	driver_simple_list_devices();
	
	//
	while(1)
	{
		printf("BACKUP FAILSAFE SYSTEM\n");
		printf("Press a key for an action:\n");
		printf("1) Enable Debugging (Slow)\n");
		printf("2) Disable Debugging (Fast)\n");
		printf("d) (Compact) List all devices (informational).\n");
		printf("D) (Verbose) LIst all devices (verbose, debugging information included).\n");
		printf("f) format ramdisk device\n");
		printf("F) format hard disk\n");
		printf("r) demo and read floppy disk on screen\n");
		printf("l) list directory on ramdisk device\n");
		printf("L) list directory on hard disk device\n");
		printf("s) enter shell\n");
		
		key = getch();
		
		if(key=='1')
		{
			jtmos_debug=                1;
			debug2=                     1;
		}

		if(key=='2')
		{
			jtmos_debug=                0;
			debug2=                     0;
		}
		

		if(key=='d')
		{
			driver_compact_list_devices();
		}

		if(key=='D')
		{
			driver_list_devices();
		}

		if(key=='f')
		{
			jtmfs_formatdrive( driver_getdevicenrbyname("ram") );
		}
		if(key=='F')
		{
			jtmfs_formatdrive( driver_getdevicenrbyname("hda") );
		}
		if(key=='r')
		{
			p = (void*) 0xC0000;
			for(i=0; i<2880; i++)
			{
				readblock( driver_getdevicenrbyname("floppy"), i, p );
			}
		}
		if(key=='l')
		{
			jtmfs_dir( driver_getdevicenrbyname("ram"), jtmfat_getrootdir(driver_getdevicenrbyname("ram")) );
		}
		if(key=='L')
		{
			jtmfs_dir( driver_getdevicenrbyname("hda"), jtmfat_getrootdir(driver_getdevicenrbyname("hda")) );
		}
		if(key=='s')
		{
#if JTMOS_MOD_SH
			StartShellProcess();
#else
			printk("SMSH is not linked into this kernel build.\n");
#endif
		}
	}
	
	//
}

//---------------------------------------------------------------
//
void OneMegCleanUp(void)
{
	BYTE *p;
	int i,i2;

	//
	for(i=0,p=0x100000; i<(1024*1024); i++)
	{
		p[i] = 0;
	}
}

//---------------------------------------------------------------
#if JTMOS_MOD_NETWORK
static void StartSerialNetworkProcesses(void)
{
	int rv;
	if(!START_SLIP)
		return;

	rv=JtInternetStart(SLIP_COM_PORT_N,DefaultSlipBPS);
	if(rv<0)
		printk("Network boot: unable to start SLIP/uIP (%d).\n",rv);
	else
		printk("Network boot: RFC1055 SLIP/uIP requested on COM%d.\n",
			SLIP_COM_PORT_N+1);
}
#endif

//---------------------------------------------------------------
/* Root policy deliberately lives in SMSH now.  KernelInit only brings block
 * devices and JTMFS infrastructure online; it never formats a filesystem. */

//---------------------------------------------------------------
// **** SYSTEM INITIALIZATION CODE ****
void KernelInit(void)
{
	char *buf;
	int i,i2,i3,i4;

	// Make sure we cannot be recalled
	if(KernelInitPassed==0xFCE2E37B)
	{
		Bingo();
		ExitThread(0);
	}

	// Indicate that we've already been here.
	KernelInitPassed = 0xFCE2E37B;

	// Get the BIOS data, we need it besides the PCI scanner (f.e. serial UART ports).
	memcpy(&bios_data,0x400,sizeof(BIOS_DATA));

	// This initializes basic kernel system(safe).
	// Start threads
	InitSystem();

	/* Storage drivers need PIT timekeeping, but the early boot path is not a
	 * safe place for thousands of hardware-TSS preemptions.  Use a normal
	 * interrupt-gate IRQ0 which only advances clocks until disk probing and
	 * the GraOS boot package read have completed. */
	PitStorageSafeBegin();

	//
	initSystemLogging();
#if JTMOS_MOD_STATUSLINE
	start_statusline();
#else
	printk("Status line module disabled.\n");
#endif

	// Major reason for the runtime to be at kinit(pid0) is the memory allocation.
	// Memory allocation from the init functions must be permanent.
	jtmfat_init();
	dirdb_init();
	fdc_init();
	/* sys: is a raw 800 KiB view of the tail of floppy:, so register it
	 * only after floppy: exists. */
	sysdev_init();
	ramdisk_init();
	/* JTMFS access must be initialized after the ram device exists. */
	jtmfs_init();

	/* ram: is only allocated/registered here.  Its JTMFS root is created
	 * after PitStorageSafeEnd(), before CP/SMSH. */

	hd_init();
	partition_table_support_init();

/* HWDET intentionally skipped during boot.
 * Hardware probes must not block normal JTMOS/GraOS startup. */
	printk("HWDET: boot-time hardware detection skipped.\n");
	/*
	buf = malloc(65536);
	printk("Reading RAMDISK boot block ...\n");
	readblock(ND("ram"), 0, buf);
	printk("Looking boot block for an identifier ...\n");
	for(i=0,i2=0; i<getblocksize(ND("ram")); i++) {
		printk("%.2x ", buf[i]);
		if(i2==0 && buf[i]=='J') { i2++; } else { i2=0; }
		if(i2==1 && buf[i]=='T') { i2++; } else { i2=0; }
		if(i2==2 && buf[i]=='M') { i2++; } else { i2=0; }
		if(i2==3 && buf[i]=='F') { i2++; } else { i2=0; }
		if(i2==4 && buf[i]=='S') { i2++; }
		if(i2==5) { i2=0; printk("%s: ", __FUNCTION__); break; }
	}*/

	// All shells require rd,hd init to be done (ramdisk, hard disk driver must be enabled)
	//register_shell();
	//StartShellProcess();
	/* The old BackupFailsafeSystem() is intentionally not entered here: it
	 * is an infinite interactive loop and prevented the normal boot path. */
#if JTMOS_MOD_GRAOS_BOOT
	if(START_GRAOS && GraOSBootReady())
	{
		/* InitSystem returns with IF=0, but IRQ0 is already unmasked because the
		 * floppy/IDE drivers depend on PIT based timekeeping.  Turn IF on for
		 * normal IRQ0/IRQ6 service while installing the GraOS payload. */
		asm volatile("cld; sti" ::: "memory");
		printk("GraOS boot: START_GRAOS=1; installing GUI payload.\n");
		printk("GraOS boot: IRQ window enabled; PIT tick-only storage mode active.\n");
		if(GraOSBootInstall())
		{
			disable();
			printk("GraOS boot payload installation failed. Entering failsafe.\n");
			BackupFailsafeSystem();
		}
	}
	else
	{
		if(!START_GRAOS)
			printk("GraOS boot: START_GRAOS=0; GUI startup disabled by keropt.c.\n");
		else
			printk("GraOS boot: requested, but VESA LFB is unavailable; continuing without GUI.\n");
	}

	/* End the storage-safe PIT phase whether or not GraOS was requested. */
	disable();
	PitStorageSafeEnd();
	disable();
	asm volatile("cld" ::: "memory");

#else
	/* Size/isolation build: storage probing is complete here. */
	disable();
	PitStorageSafeEnd();
	disable();
	asm volatile("cld" ::: "memory");
	printk("GraOS boot module disabled: continuing with native kernel only.\n");
#endif

	/* Filesystem formatting/root selection is an SMSH policy decision.  This
	 * keeps destructive mkfs operations out of KernelInit and lets an existing
	 * hda: installation win without touching ram:. */
	printk("Root filesystem selection deferred to SMSH boot policy.\n");

	/*
	 * Central Process is kernel core, not a GraOS/application-loader option.
	 * Start it after all boot storage/HW drivers and filesystems are ready and
	 * after PitStorageSafeEnd() has restored the normal scheduler.  From this
	 * point onward higher-level services and applications can serialize process
	 * creation through CP.
	 */
	centralprocess_init();

//	InitSystemPass2_XML(); // compiled from XML (kernel.xml)

	// Indicate a level 1 system start.
	// (init process will start functioning)
	// Level 2 indicates that system logs can be written
	// on the root file system, it also basically means
	// that the system is fully functional otherwise too.
	systemStarted |= 1;

#if JTMOS_MOD_NETWORK
	StartSerialNetworkProcesses();
#endif

#if JTMOS_MOD_GRAOS_BOOT
	if(START_GRAOS && GraOSBootReady())
	{
		/* GraOS is a normal JTMOS application. Launch it after systemStarted
		 * is visible, instead of calling the incomplete in-kernel GuiMain path. */
		GraOSBootStart();
	}
#endif

	/* PIT IRQ0 is already enabled before storage initialization.  Keep this
	 * final normalization for the steady-state scheduler, but do not rely on
	 * it to start the timer. */
	CLEARNT();
	asm volatile("cld" ::: "memory");
	enable_irq(0);
	enable();
	printk("Kernel boot: PIT timer/scheduler confirmed enabled.\n");

#if JTMOS_MOD_SH
	/* V27 integration boot: enter the native System Maintenance Shell after
	 * the critical kernel/storage/scheduler services are online.  GraOS is
	 * intentionally not started in this profile. */
	printk("SMSH boot: starting native maintenance shell on terminal 0.\n");
	StartShellProcess();
#else
	printk("SMSH boot requested, but JTMOS_MOD_SH=0.\n");
#endif

	//
	// ---------------------------------------------------
	// Stay at loop, spare all CPU time.
	// Execution will always stop here.
	while(1)
	{
		SwitchToThread();
	}
}

//---------------------------------------------------------------
void debugKey(void)
{
	// If space has been hit => Enable debug mode
	if(getch1()==27)	ENABLE_STARTUP=0;
	if(getch1()==32)	jtmos_debug=1;
}

//
