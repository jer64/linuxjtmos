//
#include "kernel32.h"

//
int systemStarted;
//
THREAD ShellThread;



#if !JTMOS_MOD_APP_LOADER
/* Keyboard Ctrl-Alt-Del path historically stores this flag in the central
 * process. Keep the flag available in size-oriented builds without linking
 * the application loader/central process. */
int reboot_now=FALSE;
#endif
