#ifndef __INCLUDED_VESA_H__
#define __INCLUDED_VESA_H__

/* GraOS VESA contract: boot32 selects this mode before entering protected mode. */
#define GRAOS_VESA_WIDTH       640
#define GRAOS_VESA_HEIGHT      480
#define GRAOS_VESA_BPP         8
#define GRAOS_VESA_FRAME_BYTES (GRAOS_VESA_WIDTH * GRAOS_VESA_HEIGHT)

extern BYTE *vesa_frame_buf;
extern DWORD vesa_frame_buf_bytes;
extern int vesa_enabled;
/* TRUE as soon as boot32 has successfully selected a VBE graphics mode.
 * Unlike vesa_enabled, this becomes true before paging/LFB activation and is
 * used to keep the legacy VGA text hardware completely untouched. */
extern int vesa_boot_graphics;
extern int vesa_width;
extern int vesa_height;
extern int vesa_bpp;
extern int vesa_pitch;
extern WORD vesa_mode_attributes;
extern BYTE *vb,*vesainfo;
extern BYTE egapal[];

int VesaProbe(void);
int VesaActivate(void);
int VesaSetup(void);
int VesaGraOSReady(void);
int VesaDrawFrame(const void *src, DWORD bytes);
void VesaDiagnosticPlasma(void);
void BlitCurrentTerminalToVesa(void);
void flashy(DWORD ad);

#endif
