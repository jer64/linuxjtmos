//////////////////////////////////////////////////////////////////////////////////
// vesa.c
// VESA Linear Frame Buffer Support.
// (C) 2008 by Jari Tuominen.
// Boot/paging integration fixes 2026.
//////////////////////////////////////////////////////////////////////////////////
#include "kernel32.h"
#include "paging.h"
#include "initsystem.h"
#ifdef GRAOS
#include "graos.h"
#include "directdraw.h"
#endif
#include "vesa.h"

// EGA palette.
BYTE egapal[]={
     0,0,0,
     128,0,0,
     0,128,0,
     128,128,0,
     0,0,128,
     128,0,128,
     0,128,128,
     192,192,192,
     128,128,128,
     255,0,0,
     0,255,0,
     255,255,0,
     0,0,255,
     255,0,255,
     0,255,255,
     255,255,255,
};

BYTE *vesa_frame_buf = NULL;
DWORD vesa_frame_buf_bytes = 0;
int vesa_enabled = FALSE;
int vesa_boot_graphics = FALSE;
int vesa_width = 0;
int vesa_height = 0;
int vesa_bpp = 0;
int vesa_pitch = 0;
WORD vesa_mode_attributes = 0;
BYTE *vb = NULL;
BYTE *vesainfo = (BYTE *)0x4000;

static WORD vesa_u16(int off)
{
    BYTE *m;
    m = (BYTE *)0x4000;
    return (WORD)((WORD)m[off] | ((WORD)m[off+1] << 8));
}

static DWORD vesa_u32(int off)
{
    BYTE *m;
    m = (BYTE *)0x4000;
    return (DWORD)m[off] |
           ((DWORD)m[off+1] << 8) |
           ((DWORD)m[off+2] << 16) |
           ((DWORD)m[off+3] << 24);
}

//---------------------------------------------------------------------------------------
void BlitCurrentTerminalToVesa(void)
{
    SCREEN *s;
    BYTE *buf;
    static char str[256];
    int i,x,y;

    s = &screens[ID_VIRTUAL_TERMINAL_1];
    buf = s->buf;
    if(!vesa_enabled || vesa_frame_buf == NULL || buf == NULL)
        return;

    for(y=0,i=0; y<60; y++)
    {
        for(x=0; x<80; x++,i+=2)
            str[x] = buf[i];
        str[x] = 0;
#ifdef GRAOS
        DirectDrawText(vesa_frame_buf,vesa_width,vesa_height,
            str,0,y<<3);
#endif
    }
}

// Legacy diagnostics retained, but never used by the early boot path.
static void flash(void)
{
    if(!vesa_enabled || vesa_frame_buf == NULL)
        return;
    sleep(1);
    xmemset(vesa_frame_buf, RED, vesa_frame_buf_bytes);
    sleep(1);
    xmemset(vesa_frame_buf, GREEN, vesa_frame_buf_bytes);
    sleep(1);
    xmemset(vesa_frame_buf, BLUE, vesa_frame_buf_bytes);
    sleep(1);
}

void flashy(DWORD ad)
{
    DWORD n;

    if(!vesa_enabled || vesa_frame_buf == NULL || ad >= vesa_frame_buf_bytes)
        return;
    n = (DWORD)vesa_pitch * 8;
    if(n > vesa_frame_buf_bytes-ad)
        n = vesa_frame_buf_bytes-ad;

    xmemset(vesa_frame_buf+ad, RED, n);
    xmemset(vesa_frame_buf+ad, GREEN, n);
    xmemset(vesa_frame_buf+ad, BLUE, n);
}

//---------------------------------------------------------------------------------------
// Read and validate the 256-byte VBE ModeInfoBlock that boot32/boot.asm places
// at physical 0x4000.  This routine deliberately does NOT touch PhysBasePtr;
// pg_init() must first map the physical LFB into the active page tables.
int VesaProbe(void)
{
    DWORD phys;
    DWORD bytes;
    WORD bank_pitch;
    WORD linear_pitch;
    int planes;
    int memory_model;

    vesa_enabled = FALSE;
    vesa_boot_graphics = FALSE;
    vesa_frame_buf = NULL;
    vesa_frame_buf_bytes = 0;
    vb = NULL;

    vesa_mode_attributes = vesa_u16(0x00);
    bank_pitch = vesa_u16(0x10);
    vesa_width = (int)vesa_u16(0x12);
    vesa_height = (int)vesa_u16(0x14);
    planes = (int)vesainfo[0x18];
    vesa_bpp = (int)vesainfo[0x19];
    memory_model = (int)vesainfo[0x1b];
    phys = vesa_u32(0x28);
    linear_pitch = vesa_u16(0x32);
    vesa_pitch = linear_pitch ? (int)linear_pitch : (int)bank_pitch;

    /* ModeAttributes D0: supported, D4: graphics, D7: linear framebuffer. */
    if((vesa_mode_attributes & 0x0091) != 0x0091)
    {
        printk("VESA probe: no supported graphics LFB (attrs=0x%x).\n",
            vesa_mode_attributes);
        return FALSE;
    }
    if(phys == 0 || vesa_width <= 0 || vesa_height <= 0 || vesa_pitch <= 0)
    {
        printk("VESA probe: invalid ModeInfoBlock.\n");
        return FALSE;
    }

    /* GraOS currently renders a packed 640x480x8 surface.  Refuse a mode that
     * merely happened to succeed but has incompatible pixel addressing. */
    if(vesa_width != GRAOS_VESA_WIDTH ||
       vesa_height != GRAOS_VESA_HEIGHT ||
       vesa_bpp != GRAOS_VESA_BPP ||
       vesa_pitch < GRAOS_VESA_WIDTH ||
       planes != 1 || memory_model != 4)
    {
        printk("VESA probe: unsupported GraOS mode %dx%dx%d planes=%d model=%d.\n",
            vesa_width, vesa_height, vesa_bpp, planes, memory_model);
        return FALSE;
    }

    if((DWORD)vesa_pitch > 0xffffffffUL/(DWORD)vesa_height)
    {
        printk("VESA probe: framebuffer size overflow.\n");
        return FALSE;
    }
    bytes = (DWORD)vesa_pitch * (DWORD)vesa_height;
    if(bytes == 0 || bytes > 16*1024*1024UL)
    {
        printk("VESA probe: unreasonable framebuffer size 0x%x.\n", bytes);
        return FALSE;
    }

    /* From this point onward the machine is known to be in a VBE graphics
     * mode selected by boot32.  Legacy B8000/CRTC text-console accesses must
     * stay disabled even though LFB rendering itself is not activated yet. */
    vesa_boot_graphics = TRUE;
    vb = (BYTE *)phys;
    vesa_frame_buf = vb;
    vesa_frame_buf_bytes = bytes;

    printk("VESA probe: %dx%dx%d pitch=%d LFB=0x%x bytes=0x%x attrs=0x%x.\n",
        vesa_width, vesa_height, vesa_bpp, vesa_pitch,
        vesa_frame_buf, vesa_frame_buf_bytes, vesa_mode_attributes);
    return TRUE;
}

// Draw one direct-LFB diagnostic frame before userspace exists.  This makes
// VESA/paging failures distinguishable from GraOS/application-loader failures.
void VesaDiagnosticPlasma(void)
{
    int x, y;
    DWORD ad;
    unsigned int a, b, c;

    if(!VesaGraOSReady())
        return;

    for(y=0; y<GRAOS_VESA_HEIGHT; y++)
    {
        ad = (DWORD)y * (DWORD)vesa_pitch;
        for(x=0; x<GRAOS_VESA_WIDTH; x++)
        {
            a = (unsigned int)x & 255U;
            b = (unsigned int)(y << 1) & 255U;
            c = (unsigned int)(x ^ y) & 255U;
            vesa_frame_buf[ad+x] = (BYTE)((a + b + c +
                (unsigned int)((x*y)>>5)) & 255U);
        }
    }

    for(x=0; x<GRAOS_VESA_WIDTH; x++)
    {
        vesa_frame_buf[x] = (BYTE)x;
        vesa_frame_buf[(GRAOS_VESA_HEIGHT-1)*vesa_pitch+x] = 255;
    }
    for(y=0; y<GRAOS_VESA_HEIGHT; y++)
    {
        vesa_frame_buf[y*vesa_pitch] = 255;
        vesa_frame_buf[y*vesa_pitch + GRAOS_VESA_WIDTH-1] = 255;
    }

    printk("VESA diagnostic: direct-LFB plasma frame drawn.\n");
}

// Activate screen writes only after pg_init() has installed the LFB mapping.
int VesaActivate(void)
{
    int i;

    if(vesa_frame_buf == NULL || vesa_frame_buf_bytes == 0)
        return FALSE;
    if(!paging_enabled)
    {
        printk("VESA activate: deferred until paging is enabled.\n");
        return FALSE;
    }

    /* Mode 101h is an 8-bit indexed mode.  Program a deterministic RGB332
     * palette when VGA DAC access is available so the first GraOS diagnostic
     * frame is useful on real hardware as well as emulators. */
    if((vesa_mode_attributes & 0x0020) == 0)
    {
        outportb(0x3C8, 0);
        for(i=0; i<256; i++)
        {
            int r = (i >> 5) & 7;
            int g = (i >> 2) & 7;
            int b = i & 3;
            outportb(0x3C9, (r * 63) / 7);
            outportb(0x3C9, (g * 63) / 7);
            outportb(0x3C9, (b * 63) / 3);
        }
    }
    else
    {
        printk("VESA activate: non-VGA LFB, leaving palette programmed by BIOS.\n");
    }

    /* Palette index 0 is explicitly black in egapal[].  Clearing the LFB to
     * index 0 must therefore always produce a black background. */
    xmemset(vesa_frame_buf, BLACK, vesa_frame_buf_bytes);
    vesa_enabled = TRUE;
    vesa_early_serial_only = FALSE;

    if(START_GRAOS)
        VesaDiagnosticPlasma();
    /* A VBE LFB is not the VGA text buffer.  Do not enable the legacy
     * 0xB8000 mirror here.  The terminal backing store stays in RAM and an
     * LFB renderer may blit it explicitly. */
    /* Do not call VisibleTerminals_SetHWCopy(FALSE) here: the historical
     * helper refreshes all VGA text windows even while disabling HWCopy. */
#ifdef GRAOS
    DirectDrawText(vesa_frame_buf,vesa_width,vesa_height,
        "jtmos operating system", vesa_width/2-(12*8),vesa_height/2-4);
#endif

    printk("VESA ENABLED: LFB=0x%x size=0x%x.\n",
        vesa_frame_buf, vesa_frame_buf_bytes);
    return TRUE;
}

// Compatibility entry point for code that expects the historical VesaSetup().
int VesaSetup(void)
{
    if(!VesaProbe())
        return FALSE;
    return VesaActivate();
}

//---------------------------------------------------------------------------------------
// GraOS is intentionally tied to the boot32 VBE 0x101 linear framebuffer.
int VesaGraOSReady(void)
{
    return vesa_enabled &&
           vesa_boot_graphics &&
           vesa_frame_buf != NULL &&
           vesa_width == GRAOS_VESA_WIDTH &&
           vesa_height == GRAOS_VESA_HEIGHT &&
           vesa_bpp == GRAOS_VESA_BPP &&
           vesa_pitch >= GRAOS_VESA_WIDTH &&
           vesa_frame_buf_bytes >= (DWORD)vesa_pitch * GRAOS_VESA_HEIGHT;
}

// Copy one complete packed 640x480x8 GraOS frame to the physical VESA LFB.
// The application surface never contains hardware pitch padding.
int VesaDrawFrame(const void *src, DWORD bytes)
{
    const BYTE *s;
    BYTE *d;
    int y;

    if(!VesaGraOSReady() || src == NULL || bytes != GRAOS_VESA_FRAME_BYTES)
        return FALSE;

    s = (const BYTE *)src;
    d = vesa_frame_buf;

    if(vesa_pitch == GRAOS_VESA_WIDTH)
    {
        memcpy(d, s, GRAOS_VESA_FRAME_BYTES);
        return TRUE;
    }

    for(y=0; y<GRAOS_VESA_HEIGHT; y++)
    {
        memcpy(d + y*vesa_pitch, s + y*GRAOS_VESA_WIDTH, GRAOS_VESA_WIDTH);
    }
    return TRUE;
}
