/*
 * GraOS self-contained boot test support, 2026.
 *
 * The legacy boot loader can safely load only the native kernel below the
 * 640K conventional-memory boundary.  GraOS files therefore live in a small
 * package after the fixed kernel area on the boot floppy.  Once the floppy
 * and RAM-disk drivers exist, this code copies that package into a freshly
 * formatted RAM JTMFS and launches /bin/graos.bin through centralprocess.
 */
#include "kernel32.h"
#include "jtmfs.h"
#include "jtmfat.h"
#include "root.h"
#include "directfileaccess.h"
#include "centralprocess.h"
#include "driver_rw.h"
#include "driver_api.h"
#include "graos_boot.h"
#include "vesa.h"

#define GRAOS_PACKAGE_SECTOR 1044
#define GRAOS_PACKAGE_MAGIC  "GRAOSPK1"
#define GRAOS_PACKAGE_COUNT_MAX 8
#define GRAOS_ENTRY_OFFSET   16
#define GRAOS_ENTRY_SIZE     40
#define GRAOS_NAME_SIZE      32
#define GRAOS_BLOCK_SIZE     512

static unsigned long graos_rd32(const unsigned char *p)
{
    return ((unsigned long)p[0]) |
           ((unsigned long)p[1] << 8) |
           ((unsigned long)p[2] << 16) |
           ((unsigned long)p[3] << 24);
}

static int install_package_file(int floppy, const char *name,
                                unsigned long rel_sector,
                                unsigned long bytes)
{
    unsigned char block[GRAOS_BLOCK_SIZE];
    char path[48];
    unsigned long done = 0;
    int chunk, r;

    if(!name[0] || strchr(name, '/') || strchr(name, '\\')) return 1;
    sprintf(path, "/bin/%s", name);

    if(exist(path)) unlink(path);
    r = createfile(path);
    if(r) return 2;

    while(done < bytes)
    {
        r = readblock(floppy,
                      GRAOS_PACKAGE_SECTOR + (int)rel_sector +
                      (int)(done / GRAOS_BLOCK_SIZE), block);
        if(r) return 10 + r;

        chunk = (int)(bytes - done);
        if(chunk > GRAOS_BLOCK_SIZE) chunk = GRAOS_BLOCK_SIZE;
        r = writefile(path, (char *)block, (int)done, chunk);
        if(r) return 20 + r;
        done += chunk;
    }

    r = setsize(path, (int)bytes);
    if(r) return 30 + r;
    return 0;
}


int GraOSBootReady(void)
{
    if(!VesaGraOSReady())
    {
        printk("GraOS boot: VESA 640x480x8 linear framebuffer is not active; GUI will not start.\n");
        return 0;
    }
    return 1;
}

int GraOSBootInstall(void)
{
    if(!GraOSBootReady()) return 100;
    unsigned char header[GRAOS_BLOCK_SIZE];
    char name[GRAOS_NAME_SIZE + 1];
    unsigned long count, rel_sector, bytes;
    int floppy, ram, rootdb, i, j, r;

    printk("GraOS boot: reading boot package from floppy...\n");
    floppy = driver_getdevicenrbyname("floppy");
    if(floppy < 0) return 10;
    if(getblocksize(floppy) != GRAOS_BLOCK_SIZE) return 11;

    r = readblock(floppy, GRAOS_PACKAGE_SECTOR, header);
    if(r) return 20 + r;
    if(memcmp(header, GRAOS_PACKAGE_MAGIC, 8)) return 30;

    count = graos_rd32(header + 8);
    if(count == 0 || count > GRAOS_PACKAGE_COUNT_MAX) return 31;

    printk("GraOS boot: creating RAM filesystem (%d files)...\n", (int)count);
    ram = driver_getdevicenrbyname("ram");
    if(ram < 0) return 40;

    r = jtmfs_formatdrive(ram);
    if(r) return 50 + r;

    mount_root(ram);
    rootdb = jtmfat_getrootdir(ram);
    SetThreadDNR(GetCurrentThread(), ram);
    SetThreadDB(GetCurrentThread(), rootdb);

    if(!exist("/bin"))
    {
        r = createdirectory("/bin");
        if(r) return 60 + r;
    }

    for(i = 0; i < (int)count; i++)
    {
        int e = GRAOS_ENTRY_OFFSET + i * GRAOS_ENTRY_SIZE;
        for(j = 0; j < GRAOS_NAME_SIZE; j++)
        {
            name[j] = (char)header[e + j];
            if(!name[j]) break;
        }
        name[GRAOS_NAME_SIZE] = 0;
        if(j == GRAOS_NAME_SIZE) name[GRAOS_NAME_SIZE] = 0;

        rel_sector = graos_rd32(header + e + 32);
        bytes      = graos_rd32(header + e + 36);
        if(rel_sector < 1 || bytes == 0) return 70;

        printk("GraOS boot: installing %s (%d bytes)\n", name, (int)bytes);
        r = install_package_file(floppy, name, rel_sector, bytes);
        if(r)
        {
            printk("GraOS boot: install failed: %s (%d)\n", name, r);
            return 80 + r;
        }
    }

    FlushAll();
    printk("GraOS boot: RAM filesystem ready.\n");
    return 0;
}

int GraOSBootStart(void)
{
    if(!GraOSBootReady()) return 100;
    int ram = driver_getdevicenrbyname("ram");
    int rootdb = jtmfat_getrootdir(ram);
    int pid;

    printk("GraOS boot: launching /bin/graos.bin ...\n");
    pid = centralprocess_exec("/bin/graos.bin", "/bin/graos.bin",
                              ram, rootdb, "/bin", 0);
    if(!pid)
    {
        printk("GraOS boot: GUI launch failed; starting recovery shell.\n");
        StartShellProcess();
        return 1;
    }
    printk("GraOS boot: GUI process PID=%d.\n", pid);
    return 0;
}
