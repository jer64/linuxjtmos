//--------------------------------------------------------------------------------------------
// ls.c - Directory displayer kernel mode application.
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lsapp.h"


#ifndef JTMOS
#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>

int ls_app(int argc, char **argv)
{
    const char *path = (argc >= 2 && argv[1] != NULL) ? argv[1] : ".";
    DIR *directory = opendir(path);
    struct dirent *entry;

    if (directory == NULL) {
        perror(path);
        return 1;
    }

    while ((entry = readdir(directory)) != NULL) {
        char full_path[4096];
        struct stat status;
        int is_directory = 0;

        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }

        if (snprintf(full_path, sizeof(full_path), "%s/%s", path, entry->d_name)
            < (int)sizeof(full_path)
            && stat(full_path, &status) == 0) {
            is_directory = S_ISDIR(status.st_mode);
        }

        if (is_directory) {
            printf("[%s] ", entry->d_name);
        } else {
            printf("%s ", entry->d_name);
        }
    }
    putchar('\n');

    if (closedir(directory) != 0) {
        perror("closedir");
        return 1;
    }
    return 0;
}
#endif

//
#ifdef JTMOS

// Dir function (ls)
// -----------------
//
// This function outputs directory from specified block(linear) to stdout.
int ls_app(int argc, char **argv)
{
	BYTE *buf,*p;
	WORD *wp;
	DWORD *dwp,i,i2,i3,i4,ii,ii2,ii3,ii4,l;
	JTMFS_FILE_ENTRY *fe;
	int k;
	DWORD ad;
	int current_block;
	char *str,*str2,*res1,*res2;
	int totalBytes,totalFiles,totalDirs;
	DIRWALK *dw;
	int lastone;
	int dnr,db;

        /* No argument is the normal case: list the caller's current JTMFS
         * directory.  The historical code required an unused argv[1], so a
         * plain `ls` could not perform the operation it already knew how to do. */
        (void)argc;
        (void)argv;

	// Local path.
	dnr =	GetCurrentDNR();
	db =	GetCurrentDB();

	//
	dw = malloc(sizeof(DIRWALK));

	// (TODO: add a dnr validity check here)
	//
	// JTMFS required
	if(!jtmfat_isJTMFS(dnr))
	{
		//
		printk("Looks like the drive is not JTMFS formatted.\n");
		return 1;
	}


	// Note: this must be freed afterwards:
	buf=malloc(16384);
	//
	str = malloc(256); str2 = malloc(256);
	res1 = malloc(256); res2 = malloc(256);
 
	// Begin walking
	if( jtmfs_ffirst(dnr,db, dw) )return 1;

	//
	for(i=0,totalFiles=0,totalBytes=0,totalDirs=0,lastone=0;
			; i++)
	{
		// Get current dir entry
		fe = dw->fe;

		// Give user a possibility to stop the directory listing
		if( (k = getch1())==27 )break;
 
		// Is it a ghost?->continue without notifying it (deleted file)
		// (ghost :  length == -1 )
		if( fe->length==-1 ) goto emptyEntry;
  
		// Empty filename? -> End of dir.
		if( !strlen(fe->name) )
		{
			break;
		}
   
		// --------- Start output string creation here: ----------
		strcpy(res1,""); strcpy(res2,"");

		//
		switch(fe->type)
		{
			// DIRECTORY
			case JTMFS_ID_DIRECTORY:
			strcat(res1, "[");
			break;
			// FILE
			default:
			break;
		}

		// PRINT FILENAME
		//
		// Note: I show filename so that all spaces show correctly,
		//       this requires putting the filename inside '"'s.
		sprintf(str, "%s", fe->name);
		strcat(res1, str);

		//
		switch(fe->type)
		{
			// DIRECTORY
			case JTMFS_ID_DIRECTORY:
			totalDirs++;
			strcat(res1, "]");
			break;
			// FILE
			default:
			totalFiles++;
			totalBytes += fe->length;
			sprintf(res2, "%d bytes", fe->length);
			break;
		}

		// Print strings in a style
		StretchPrint(res1, 30);
		StretchPrint(res2, 15);
		//
		printk("\n");

emptyEntry:
		//
		if( jtmfs_fnext(dnr, dw) )
			break;
	}

	//
	StretchPrint("", 10);
	sprintf(res1, "%d File(s)",	totalFiles);
	StretchPrint(res1, 15);
	sprintf(res1, "%d bytes",	totalBytes);
	StretchPrint(res1, 15);
	printk("\n");
	StretchPrint("", 10);
	sprintf(res1, "%d Dir(s)",	totalDirs);
	StretchPrint(res1, 15);
	sprintf(res1, "%d bytes",	totalBytes);
	StretchPrint(res1, 15);
	printk("\n");
	//
	//printk("End of directory.\n");

	//
	free(buf); free(str); free(str2);
	free(res1); free(res2);

	//
	free(dw);
 
	//
	return 0;
}

#endif

