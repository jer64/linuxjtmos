/* sqa.c - bounds-checked streaming SQARC520 extractor, JTMOS V65. */
#if defined(JTMOSKERNEL)
#include "kernel32.h"
#include "sqa.h"
typedef long SQA_IO_COUNT;
typedef long SQA_OFF;
#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include "sqa.h"
typedef ssize_t SQA_IO_COUNT;
typedef off_t SQA_OFF;
#endif

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

SQDSK sqdsk;
int quiet = 0;
char specific[256] = {0};
char dstdir[256] = {0};
int seloffs = 0;

static int read_exact(int fd, void *buffer, size_t length)
{
    BYTE *p;
    size_t done;
    p = (BYTE *)buffer;
    done = 0U;
    while(done < length) {
        SQA_IO_COUNT n = read(fd,p+done,length-done);
        if(n < 0) { if(errno == EINTR) continue; return -1; }
        if(n == 0) { errno = EIO; return -1; }
        done += (size_t)n;
    }
    return 0;
}

static int write_exact(int fd, const void *buffer, size_t length)
{
    const BYTE *p;
    size_t done;
    p = (const BYTE *)buffer;
    done = 0U;
    while(done < length) {
        SQA_IO_COUNT n = write(fd,p+done,length-done);
        if(n < 0) { if(errno == EINTR) continue; return -1; }
        if(n == 0) { errno = EIO; return -1; }
        done += (size_t)n;
    }
    return 0;
}

static DWORD decode_u32_le(const BYTE p[4])
{
    return (DWORD)p[0] | ((DWORD)p[1] << 8U)
         | ((DWORD)p[2] << 16U) | ((DWORD)p[3] << 24U);
}

static int read_u32_le(int fd, DWORD *value)
{
    BYTE p[4];
    if(read_exact(fd,p,sizeof(p)) != 0) return -1;
    *value = decode_u32_le(p);
    return 0;
}

static int valid_name(const char *name)
{
    return name != NULL && name[0] != '\0'
        && strcmp(name,".") != 0 && strcmp(name,"..") != 0
        && strchr(name,'/') == NULL && strchr(name,'\\') == NULL
        && strchr(name,':') == NULL;
}

static int duplicate_name(unsigned upto, const char *name)
{
    unsigned i;
    for(i=0U;i<upto;++i)
        if(strcmp(sqdsk.entries[i].fname,name) == 0) return 1;
    return 0;
}

static int make_output_name(char *out, size_t capacity, const char *name)
{
    size_t a,b;
    int slash;
    if(out == NULL || capacity == 0U || !valid_name(name)) return -1;
    a = strlen(dstdir);
    b = strlen(name);
    slash = a > 0U && dstdir[a-1U] != '/' && dstdir[a-1U] != ':';
    if(a + (slash ? 1U : 0U) + b + 1U > capacity) return -1;
    out[0] = '\0';
    if(a != 0U) {
        memcpy(out,dstdir,a+1U);
        if(slash) { out[a++] = '/'; out[a] = '\0'; }
    }
    memcpy(out+a,name,b+1U);
    return 0;
}

static void reset_archive(void)
{
    free(sqdsk.entries);
    memset(&sqdsk,0,sizeof(sqdsk));
}

static int archive_file_size(int fd, long *size)
{
    SQA_OFF current,end;
    current = lseek(fd,0,SEEK_CUR);
    if(current < 0) return -1;
    end = lseek(fd,0,SEEK_END);
    if(end < 0) return -1;
    if(lseek(fd,current,SEEK_SET) < 0) return -1;
    *size = (long)end;
    return 0;
}

static int load_directory(int fd)
{
    BYTE count[2];
    unsigned i;
    long header,dir_bytes,data_offset,archive_size;
    DWORD expected_offset;

    reset_archive();
    if(seloffs < 0) return 1;
    if(archive_file_size(fd,&archive_size) != 0) return 1;
    header = (long)seloffs + SQA_SAFE_AREA_SIZE;
    if(header < 0 || header > archive_size) return 1;
    if(lseek(fd,(SQA_OFF)header,SEEK_SET) < 0) return 1;
    if(read_exact(fd,sqdsk.identifier,SQA_IDENTIFIER_SIZE) != 0) return 1;
    sqdsk.identifier[SQA_IDENTIFIER_SIZE] = '\0';
    if(memcmp(sqdsk.identifier,SQA_IDENTIFIER,SQA_IDENTIFIER_SIZE) != 0) return 1;
    if(read_exact(fd,count,sizeof(count)) != 0) return 2;
    sqdsk.nr_files = (WORD)((WORD)count[0] | ((WORD)count[1] << 8U));
    if((unsigned)sqdsk.nr_files > SQA_MAX_FILES) return 2;

    dir_bytes = (long)sqdsk.nr_files * (long)SQA_DISK_ENTRY_SIZE;
    data_offset = header + (long)SQA_IDENTIFIER_SIZE + 2L + dir_bytes;
    if(data_offset < header || data_offset > archive_size) return 2;
    sqdsk.data_offset = data_offset;
    sqdsk.archive_size = archive_size;

    if(sqdsk.nr_files != 0U) {
        sqdsk.entries = (FE *)malloc((size_t)sqdsk.nr_files*sizeof(FE));
        if(sqdsk.entries == NULL) return 3;
        memset(sqdsk.entries,0,(size_t)sqdsk.nr_files*sizeof(FE));
    }

    expected_offset = 0U;
    for(i=0U;i<(unsigned)sqdsk.nr_files;++i) {
        FE *e;
        DWORD endoff;
        unsigned j;
        e = &sqdsk.entries[i];
        if(read_exact(fd,e->fname,SQA_FILENAME_SIZE) != 0
           || read_exact(fd,&e->reserved,1U) != 0
           || read_u32_le(fd,&e->offset) != 0
           || read_u32_le(fd,&e->length) != 0
           || read_u32_le(fd,&e->chksum) != 0) return 2;
        /* A valid disk name must contain a NUL within its fixed field. */
        for(j=0U;j<SQA_FILENAME_SIZE;++j) if(e->fname[j] == '\0') break;
        if(j == SQA_FILENAME_SIZE) return 2;
        if(!valid_name(e->fname) || duplicate_name(i,e->fname)) return 2;
        if(e->offset != expected_offset || e->length > 0xffffffffUL-e->offset) return 2;
        endoff = e->offset+e->length;
        if((unsigned long)endoff > (unsigned long)(archive_size-data_offset)) return 2;
        expected_offset = endoff;
    }
    return 0;
}

static int open_output_file(const char *path)
{
#if defined(JTMOSKERNEL)
    return open(path,O_WRONLY|O_CREAT|O_TRUNC);
#else
    return open(path,O_WRONLY|O_CREAT|O_TRUNC,0666);
#endif
}

static int extract_one(int fd, const FE *e, BYTE *buffer, size_t capacity)
{
    DWORD remaining,sum;
    char output[PATH_MAX];
    int outfd,rc;
    SQA_OFF pos;

    if(make_output_name(output,sizeof(output),e->fname) != 0) {
        if(!quiet) printf("sqa: unsafe or too-long output name '%s'\n",e->fname);
        return 6;
    }
    pos = (SQA_OFF)sqdsk.data_offset + (SQA_OFF)e->offset;
    if(pos < (SQA_OFF)sqdsk.data_offset || lseek(fd,pos,SEEK_SET) < 0) return 8;
    outfd = open_output_file(output);
    if(outfd < 0) return 10;

    remaining = e->length;
    sum = 0U;
    rc = 0;
    while(remaining != 0U) {
        size_t chunk,i;
        chunk = remaining > (DWORD)capacity ? capacity : (size_t)remaining;
        if(read_exact(fd,buffer,chunk) != 0) { rc=8; break; }
        for(i=0U;i<chunk;++i) sum += (DWORD)buffer[i]+1U;
        if(write_exact(outfd,buffer,chunk) != 0) { rc=11; break; }
        remaining -= (DWORD)chunk;
    }
    if(close(outfd) != 0 && rc == 0) rc = 11;
    if(rc != 0 || sum != e->chksum) {
        (void)remove(output);
        if(rc == 0) rc = 9;
        if(!quiet && rc == 9)
            printf("sqa: checksum mismatch for %s (%08lx != %08lx)\n",
                   e->fname,(unsigned long)sum,(unsigned long)e->chksum);
        return rc;
    }
    if(!quiet) printf("%s (%lu bytes)\n",output,(unsigned long)e->length);
    return 0;
}

int extract_archive(const char *fname, const char *spec)
{
    int fd,rc;
    unsigned i,produced;
    BYTE *buffer;

    if(fname == NULL || fname[0] == '\0') return 3;
    specific[0] = '\0';
    if(spec != NULL && spec[0] != '\0') {
        size_t n = strlen(spec);
        if(n >= sizeof(specific)) return 6;
        memcpy(specific,spec,n+1U);
    }
    fd = open(fname,O_RDONLY);
    if(fd < 0) { if(!quiet) printf("sqa: cannot open %s\n",fname); return 3; }
    rc = load_directory(fd);
    if(rc != 0) { (void)close(fd); reset_archive(); return rc; }

    buffer = (BYTE *)malloc(SQA_COPY_BUFFER_SIZE);
    if(buffer == NULL) { (void)close(fd); reset_archive(); return 7; }
    produced = 0U;
    for(i=0U;i<(unsigned)sqdsk.nr_files;++i) {
        FE *e = &sqdsk.entries[i];
        if(specific[0] != '\0' && strcmp(specific,e->fname) != 0) continue;
        rc = extract_one(fd,e,buffer,SQA_COPY_BUFFER_SIZE);
        if(rc != 0) break;
        ++produced;
    }
    free(buffer);
    if(close(fd) != 0 && rc == 0) rc = 11;
    if(rc == 0 && specific[0] != '\0' && produced == 0U) rc = 12;
    if(!quiet && rc == 0) printf("sqa: %u file(s) extracted\n",produced);
    reset_archive();
    return rc;
}
