/* SMSH runtime networking commands for JTMOS V64. */
#include "kernel32.h"
#include "networkapp.h"
#include "networkControl.h"
#include "jt_httpd.h"
#include "slip.h"
#include "slipStack.h"

static const char *inet_state_name(int state)
{
    switch(state)
    {
        case JTMOS_INET_STARTING: return "starting";
        case JTMOS_INET_ONLINE: return "online";
        case JTMOS_INET_STOPPING: return "stopping";
        default: return "offline";
    }
}

static int parse_uint(const char *s, int *out)
{
    int value = 0;

    if(s == NULL || *s == '\0' || out == NULL)
        return -1;
    while(*s)
    {
        if(*s < '0' || *s > '9')
            return -1;
        if(value > 100000000)
            return -1;
        value = value * 10 + (*s - '0');
        ++s;
    }
    *out = value;
    return 0;
}

static int parse_com(const char *s)
{
    if(s==NULL || *s=='\0') return -1;
    if(!strcmp(s,"com1") || !strcmp(s,"COM1") || !strcmp(s,"1")) return 0;
    if(!strcmp(s,"com2") || !strcmp(s,"COM2") || !strcmp(s,"2")) return 1;
    if(!strcmp(s,"com3") || !strcmp(s,"COM3") || !strcmp(s,"3")) return 2;
    if(!strcmp(s,"com4") || !strcmp(s,"COM4") || !strcmp(s,"4")) return 3;
    return -1;
}

static void internet_print_status(void)
{
    int state=JtInternetState();
    printf("Internet: %s, stack=%s, COM%d, %d bps\n",
        inet_state_name(state), JtInternetStackName(),
        JtInternetComPort()+1, JtInternetBPS());
    printf("  IPv4: 10.0.0.5  peer/gateway: 10.0.0.1\n");
    printf("  slipd PID=%d  stack PID=%d  slipOnline=%d  slipStackReady=%d\n",
        JtInternetSlipPID(), JtInternetStackPID(),
        (int)slipOnline, slipStackReady);
    printf("  Note: raw SLIP has no peer handshake; 'online' means the local RFC1055 link is ready.\n");
}

int internet_app(int argc, char **argv)
{
    const char *action="start";
    int com=1;
    int bps=115200;
    int rv;
    DWORD start;

    if(argc>1 && argv[1]!=NULL)
        action=argv[1];

    if(!strcmp(action,"status"))
    {
        internet_print_status();
        return 0;
    }

    if(!strcmp(action,"stop") || !strcmp(action,"down"))
    {
        rv=JtInternetStop();
        if(rv==1)
        {
            printf("Internet: already offline.\n");
            return 0;
        }
        printf("Internet: stopping background SLIP/uIP workers...\n");
        start=GetTickCount();
        while(JtInternetState()!=JTMOS_INET_OFFLINE &&
              (DWORD)(GetTickCount()-start)<2000)
            SwitchToThread();
        internet_print_status();
        return 0;
    }

    /* `internet`, `internet start`, and `internet up` all start the default
     * COM2/115200 link.  Optional syntax: internet start com2 115200 */
    if(strcmp(action,"start") && strcmp(action,"up"))
    {
        printf("Usage: internet [start [com1|com2|com3|com4] [bps]|stop|status]\n");
        return 1;
    }

    if(argc>2)
    {
        com=parse_com(argv[2]);
        if(com<0)
        {
            printf("internet: invalid COM port '%s'.\n", argv[2]);
            return 1;
        }
    }
    if(argc>3)
    {
        if(parse_uint(argv[3], &bps) != 0 || bps<1200 || bps>115200)
        {
            printf("internet: baud rate must be 1200..115200.\n");
            return 1;
        }
    }

    rv=JtInternetStart(com,bps);
    if(rv==1)
    {
        printf("Internet: already started.\n");
        internet_print_status();
        return 0;
    }
    if(rv<0)
    {
        printf("internet: unable to start SLIP/uIP (error %d).\n",rv);
        return 1;
    }

    printf("Internet: starting RFC1055 SLIP on COM%d at %d bps in background.\n",
        com+1,bps);
    printf("Internet: Ubuntu peer must use 10.0.0.1, JTMOS uses 10.0.0.5.\n");

    /* Give the worker enough time to initialize in the common direct-SLIP
     * case, but do not keep SMSH blocked if the peer is absent. */
    start=GetTickCount();
    while(JtInternetState()==JTMOS_INET_STARTING &&
          (DWORD)(GetTickCount()-start)<3500)
        SwitchToThread();
    internet_print_status();
    return 0;
}

int www_app(int argc, char **argv)
{
    const char *action="start";
    int port=80;
    int rv;

    if(argc>1 && argv[1]!=NULL)
        action=argv[1];

    if(!strcmp(action,"status"))
    {
        printf("WWW: %s, requested=%s, TCP port=%d\n",
            JtHttpdIsListening()?"listening":"not listening",
            JtHttpdRequested()?"yes":"no", JtHttpdPort());
        printf("WWW URL from Ubuntu host: http://10.0.0.5:%d/\n",JtHttpdPort());
        return 0;
    }

    if(!strcmp(action,"stop"))
    {
        JtHttpdDisable();
        printf("WWW: stop requested; uIP will remove the listener in background.\n");
        return 0;
    }

    if(strcmp(action,"start"))
    {
        printf("Usage: www [start [port]|stop|status]\n");
        return 1;
    }

    if(argc>2)
    {
        if(parse_uint(argv[2], &port) != 0 || port<=0 || port>65535)
        {
            printf("www: invalid TCP port.\n");
            return 1;
        }
    }

    if(JtInternetState()==JTMOS_INET_OFFLINE)
    {
        rv=JtInternetStart(1,115200);
        if(rv<0 && rv!=1)
        {
            printf("www: unable to start its SLIP/uIP dependency (error %d).\n",rv);
            return 1;
        }
        printf("WWW: network dependency started on COM2/115200.\n");
    }

    if(JtHttpdEnable(port)!=0)
    {
        printf("www: unable to configure port %d.\n",port);
        return 1;
    }

    printf("WWW: background server requested on TCP port %d.\n",port);
    printf("WWW: SMSH returns now; the uIP service thread keeps the server alive.\n");
    printf("WWW: browse from Ubuntu to http://10.0.0.5:%d/\n",port);
    return 0;
}
