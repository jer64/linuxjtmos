// (C) 2020-2026 JTT.
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sh.h"
#include "lsapp.h"
#include "formatapp.h"
#include "chdirapp.h"
#include "helpapp.h"
#include "exitapp.h"
#include "nzip.h"
#include "sqa.h"
#include "copyall.h"
#include "rmwildcard.h"
#include "debugmode.h"
#include "memdump.h"
#include "fsadmin.h"
#include "kyberapp.h"
#if JTMOS_MOD_NETWORK
#include "networkapp.h"
#endif

#ifdef JTMOS
#include "kernel32.h"
#include "jtmfsPath.h"
#include "centralprocess.h"
#endif

#define SH_MAX_LINE 65536U
#define SH_MAX_ARGS 100
#define SH_NOT_HANDLED (-32767)

typedef int (*shell_command_fn)(int argc, char **argv);

typedef struct shell_command {
    const char *name;
    shell_command_fn function;
} SHELL_COMMAND;

/* When shell_graos.o is linked, this weak hook adds gui/graos/postman/pm
 * without making the standalone shell depend on SDL2 or Postman. */
#if defined(__GNUC__)
extern int graos_shell_try_command(const char *command, int argc, char **argv)
    __attribute__((weak));
extern int AudioDemoMain(int argc, char **argv) __attribute__((weak));
#endif

static int sound_builtin(int argc, char **argv)
{
#if defined(__GNUC__)
    if(AudioDemoMain != NULL)
        return AudioDemoMain(argc, argv);
#endif
    printf("sound: audio drivers are not included in this kernel build.\n");
    return 1;
}

static int sh_debug = 0;

static const SHELL_COMMAND shell_commands[] = {
    {"cd", chdir_app},
    {"chdir", chdir_app},
    {"ls", ls_app},
    {"dir", ls_app},
    {"mkfs", format_app},
    {"format", format_app},
    {"mount", mount_app},
    {"umount", umount_app},
    {"unmount", umount_app},
    {"root", root_app},
    {"rootinstall", rootinstall_app},
    {"bootroot", bootroot_app},
    {"help", help_app},
    {"exit", exit_app},
    {"quit", exit_app},
    {"sqa", sqa_main},
    {"sqarc", sqarc_main},
    {"nzip", nzip_main},
    {"kyber", kyber_app},
    {"copyall", copyall_main},
    {"rm_wildcard", rm_wildcard_main},
    {"rmwild", rm_wildcard_main},
    {"rmw", rm_wildcard_main},
    {"debug", DebugModeSwitchMain},
    {"debug1", DebugModeSwitchMain},
    {"report", ReportModeSwitchMain},
    {"debug2", ReportModeSwitchMain},
    {"m", kmed_main},
    {"kmed", kmed_main},
    {"fm", file_memory_dump_main},
    {"sound", sound_builtin},
#if JTMOS_MOD_NETWORK
    {"internet", internet_app},
    {"inet", internet_app},
    {"www", www_app},
#endif
    {NULL, NULL}
};

int sh_dprint(const char *fmt, ...)
{
    va_list args;

    if (!sh_debug || fmt == NULL) {
        return 0;
    }

    va_start(args, fmt);
    (void)vprintf(fmt, args);
    va_end(args);
    return 0;
}

char *splitter(char *split_what, char *with_what, int n_occurance)
{
    char *cursor;
    size_t separator_length;
    int found = 0;

    if (split_what == NULL || with_what == NULL || n_occurance <= 0) {
        return split_what;
    }

    separator_length = strlen(with_what);
    if (separator_length == 0U) {
        return split_what;
    }

    cursor = split_what;
    while (*cursor != '\0') {
        if (strncmp(cursor, with_what, separator_length) == 0) {
            ++found;
            cursor += separator_length;
            if (found == n_occurance) {
                return cursor;
            }
        } else {
            ++cursor;
        }
    }
    return cursor;
}

static int is_separator(char value, const char *separators)
{
    if (separators == NULL || separators[0] == '\0') {
        return value == ' ' || value == '\t';
    }
    return strchr(separators, value) != NULL;
}

static void free_argv(char **argv, int argc)
{
    int i;

    if (argv == NULL) {
        return;
    }
    for (i = 0; i < argc; ++i) {
        free(argv[i]);
    }
    free(argv);
}

/* Build a conventional argv array. Quoted strings and backslash escapes are
 * accepted, so e.g. postman exec "program name" remains one argument. */
char **argvbuilder(char *cmdstr, char *filterstring, int *pointer_to_argc)
{
    const char *cursor;
    char **argv;
    int argc = 0;

    if (pointer_to_argc != NULL) {
        *pointer_to_argc = 0;
    }
    if (cmdstr == NULL) {
        return NULL;
    }

    argv = (char **)calloc((size_t)SH_MAX_ARGS + 1U, sizeof(*argv));
    if (argv == NULL) {
        return NULL;
    }

    cursor = cmdstr;
    while (*cursor != '\0' && argc < SH_MAX_ARGS) {
        const char *start;
        char quote = '\0';
        char *argument;
        size_t capacity;
        size_t used = 0U;

        while (*cursor != '\0' && is_separator(*cursor, filterstring)) {
            ++cursor;
        }
        if (*cursor == '\0') {
            break;
        }

        start = cursor;
        capacity = strlen(start) + 1U;
        argument = (char *)malloc(capacity);
        if (argument == NULL) {
            free_argv(argv, argc);
            return NULL;
        }

        while (*cursor != '\0') {
            char value = *cursor;

            if (quote == '\0' && is_separator(value, filterstring)) {
                break;
            }
            if (value == '\\' && cursor[1] != '\0') {
                argument[used++] = cursor[1];
                cursor += 2;
                continue;
            }
            if (value == '\'' || value == '"') {
                if (quote == '\0') {
                    quote = value;
                    ++cursor;
                    continue;
                }
                if (quote == value) {
                    quote = '\0';
                    ++cursor;
                    continue;
                }
            }
            argument[used++] = value;
            ++cursor;
        }
        argument[used] = '\0';
        argv[argc++] = argument;

        while (*cursor != '\0' && is_separator(*cursor, filterstring)) {
            ++cursor;
        }
    }

    argv[argc] = NULL;
    if (pointer_to_argc != NULL) {
        *pointer_to_argc = argc;
    }
    return argv;
}

char **old_argvbuilder(char *cmdstr, char *filterstring, int *pointer_to_argc)
{
    return argvbuilder(cmdstr, filterstring, pointer_to_argc);
}

/* Legacy flat-buffer helper. The returned buffer is a copy of the command
 * line; pointer_to_argc receives the parsed argument count. */
char *b_argvbuilder(char *cmdstr, char *filterstring, char *pointer_to_argc)
{
    char **argv;
    char *copy;
    int argc = 0;

    if (cmdstr == NULL) {
        return NULL;
    }
    argv = argvbuilder(cmdstr, filterstring, &argc);
    if (argv == NULL) {
        return NULL;
    }
    copy = (char *)malloc(strlen(cmdstr) + 1U);
    if (copy != NULL) {
        strcpy(copy, cmdstr);
    }
    if (pointer_to_argc != NULL) {
        *pointer_to_argc = (char)((argc > 127) ? 127 : argc);
    }
    free_argv(argv, argc);
    return copy;
}

/* Legacy tokenizer for callers that supply an argv array. */
int getargumentlist(char *command_line, char **argv)
{
    static char storage[8192];
    char *token;
    int argc = 0;

    if (command_line == NULL || argv == NULL) {
        return 0;
    }
    strncpy(storage, command_line, sizeof(storage) - 1U);
    storage[sizeof(storage) - 1U] = '\0';

    token = strtok(storage, " \t");
    while (token != NULL && argc < SH_MAX_ARGS) {
        argv[argc++] = token;
        token = strtok(NULL, " \t");
    }
    argv[argc] = NULL;
    return argc;
}

static shell_command_fn find_builtin(const char *name)
{
    size_t i;

    if (name == NULL) {
        return NULL;
    }
    for (i = 0U; shell_commands[i].name != NULL; ++i) {
        if (strcmp(shell_commands[i].name, name) == 0) {
            return shell_commands[i].function;
        }
    }
    return NULL;
}


/* Native JTMOS has a terminal getch() primitive but no fgets()-based pipe
 * stream for interactive input. Keep fgets() only in the host test branch. */
static int sh_readline(char *line, size_t capacity)
{
#ifdef JTMOS
    size_t used = 0U;
    int overflow = 0;

    if(line == NULL || capacity < 2U) return -1;
    line[0] = '\0';

    for(;;) {
        int key = getch();

        if(key == '\r' || key == '\n') {
            putchar('\n');
            break;
        }
        if(key == 4 && used == 0U) return -1; /* Ctrl-D */
        if(key == '\b' || key == 127) {
            if(used > 0U) {
                --used;
                line[used] = '\0';
                putchar('\b'); putchar(' '); putchar('\b');
            }
            continue;
        }
        if(key == 27 || key < 32 || key > 255) continue;

        if(used + 1U < capacity) {
            line[used++] = (char)key;
            line[used] = '\0';
            putchar(key);
        } else {
            overflow = 1;
        }
    }

    if(overflow) {
        printf("sh: command line too long (maximum %u characters)\\n",
               (unsigned)(capacity - 1U));
        line[0] = '\0';
        return -2;
    }
    return (int)used;
#else
    size_t length;
    if(line == NULL || capacity < 2U) return -1;
    if(fgets(line, (int)capacity, stdin) == NULL) return -1;
    length = strlen(line);
    if(length > 0U && line[length-1U] != '\n' && !feof(stdin)) {
        int ch;
        while((ch = getchar()) != '\n' && ch != EOF) { }
        line[0] = '\0';
        return -2;
    }
    while(length > 0U && (line[length-1U] == '\n' || line[length-1U] == '\r'))
        line[--length] = '\0';
    return (int)length;
#endif
}

static int try_optional_dispatch(const char *command, int argc, char **argv)
{
#if defined(__GNUC__)
    if (graos_shell_try_command != NULL) {
        return graos_shell_try_command(command, argc, argv);
    }
#else
    (void)command;
    (void)argc;
    (void)argv;
#endif
    return SH_NOT_HANDLED;
}

#ifdef JTMOS
/*
 * Explicit external-program path for the native SMSH.
 *
 *   :install
 *   :ls /ram
 *   :/bin/test.bin arg1 arg2
 *
 * The leading ':' belongs to SMSH syntax only and is stripped before the
 * application loader sees the filename.  This is important because old
 * centralprocess_loadEXE() has historical pseudo-names such as
 * ":install.bin"; V27 deliberately bypasses those and loads the real file
 * from JTMFS/PATH.  centralprocess_exec() then reaches LaunchAppEx() after
 * the executable has been loaded from disk.
 */
static int smsh_launch_external(const char *line)
{
    char command[256];
    char executable[256];
    char workdir[256];
    const char *src;
    size_t len;
    size_t i;
    int pid;
    int background = 0;

    if(line == NULL || line[0] != ':')
        return -1;

    src = line + 1;
    while(*src == ' ' || *src == '\t')
        ++src;

    if(*src == '\0') {
        printf("SMSH: ':' requires an external program name.\n");
        return -1;
    }

    len = strlen(src);
    if(len >= sizeof(command)) {
        printf("SMSH: external command is too long (max %u bytes).\n",
               (unsigned)(sizeof(command) - 1U));
        return -1;
    }

    strcpy(command, src);

    /* A trailing ampersand is SMSH background syntax for explicit external
     * programs.  Remove it from argv before LaunchApp and, after a successful
     * launch, do not wait for process termination. */
    while(len>0U && (command[len-1U]==' ' || command[len-1U]=='\t'))
        command[--len]='\0';
    if(len>0U && command[len-1U]=='&')
    {
        background=1;
        command[--len]='\0';
        while(len>0U && (command[len-1U]==' ' || command[len-1U]=='\t'))
            command[--len]='\0';
    }
    if(len==0U)
    {
        printf("SMSH: background marker requires an external program.\n");
        return -1;
    }

    /* centralprocess_exec() wants argv[0]/filename separately from the full
     * command line.  Keep quoting/arguments intact in command[]. */
    for(i = 0U; i < sizeof(executable) - 1U && command[i] != '\0'; ++i) {
        if(command[i] == ' ' || command[i] == '\t')
            break;
        executable[i] = command[i];
    }
    executable[i] = '\0';

    if(executable[0] == '\0') {
        printf("SMSH: invalid external program name.\n");
        return -1;
    }

    if(getcwd(workdir, sizeof(workdir) - 1U) == NULL)
        strcpy(workdir, "ram:/");
    workdir[sizeof(workdir) - 1U] = '\0';

    printf("SMSH LaunchApp: '%s' (cwd=%s)\n", command, workdir);
    pid = centralprocess_exec(executable, command,
                              GetCurrentDNR(), GetCurrentDB(),
                              workdir, GetCurrentTerminal());
    if(pid <= 0) {
        printf("SMSH LaunchApp: unable to load/execute '%s'.\n", executable);
        return -1;
    }

    if(background)
    {
        printf("SMSH LaunchApp: PID %d started in background.\n", pid);
        return 0;
    }

    printf("SMSH LaunchApp: PID %d started; waiting for termination.\n", pid);
    WaitProcessTermination(pid);
    printf("SMSH LaunchApp: PID %d terminated.\n", pid);
    return 0;
}
#endif

int run_shell(void)
{
    char *line;

    line = (char *)malloc(SH_MAX_LINE);
    if (line == NULL) {
        fprintf(stderr, "sh: unable to allocate command buffer\n");
        return 1;
    }

#ifdef JTMOS
    if(smsh_boot_root_policy()!=0)
        printf("SMSH boot: root filesystem is not available; maintenance shell continues.\n");
#endif

    printf("Built-In System Maintenance Debug Shell 1.2 / 2020-2026\n");

    for (;;) {
        char **argv;
        int argc = 0;
        int dispatch_result;
        shell_command_fn command;

#ifdef JTMOS
        {
            char cwd[JTMFS_PATH_MAX];
            if(getcwd(cwd, sizeof(cwd)) == 0 && cwd[0] != '\0')
                printf("%s# ", cwd);
            else
                printf("?# ");
        }
#else
        printf("# ");
        fflush(stdout);
#endif

        {
            int read_result = sh_readline(line, SH_MAX_LINE);
            if(read_result == -1) {
                putchar('\n');
                break;
            }
            if(read_result == -2) {
                printf("sh: input discarded\n");
                continue;
            }
        }
        argv = argvbuilder(line, " \t", &argc);
        if (argv == NULL) {
            fprintf(stderr, "sh: unable to parse command line\n");
            continue;
        }
        if (argc == 0) {
            free_argv(argv, argc);
            continue;
        }

#ifdef JTMOS
        /* A leading ':' always means "load an external executable".
         * Do this before builtin lookup so :help can launch help.bin rather
         * than invoking the SMSH builtin help command. */
        if(line[0] == ':') {
            (void)smsh_launch_external(line);
            free_argv(argv, argc);
            continue;
        }
#endif

        command = find_builtin(argv[0]);
        if (command != NULL) {
            int command_result = command(argc, argv);
            free_argv(argv, argc);
            if(command_result == SHELL_EXIT_REQUEST)
                break;
            continue;
        }

        dispatch_result = try_optional_dispatch(argv[0], argc, argv);
        if (dispatch_result != SH_NOT_HANDLED) {
            free_argv(argv, argc);
            continue;
        }

        /* Preserve the original external-program path.  GRAOS/Postman gets
         * the first chance through the optional dispatcher above. */
        if (system(line) == -1) {
#ifndef JTMOS
            perror("system");
#else
            printf("Unable to launch: %s\n", argv[0]);
#endif
        }
        free_argv(argv, argc);
    }

    free(line);
    sh_dprint("Exiting Shell, Thank You For Visiting Us!\n");
    return 0;
}
