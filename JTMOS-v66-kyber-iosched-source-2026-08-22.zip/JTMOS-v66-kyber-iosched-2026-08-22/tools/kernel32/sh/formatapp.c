//--------------------------------------------------------------------------------------------
// formatapp.c - SMSH JTMFS formatter command.
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include <string.h>
#include "formatapp.h"

int format_app(int argc, char **argv)
{
    int result;

    if(argc != 2)
    {
        printf("Usage: %s [device]\n", (argc > 0 && argv && argv[0]) ? argv[0] : "format");
        printf("Examples: format ram | format sys | format floppy | format hda\n");
        return 2;
    }

#ifdef JTMOS
    result = mkfs(argv[1]);
    if(result != 0)
    {
        if(result == 16)
            printf("mkfs: device '%s' is busy (root, process CWD, or open file).\n", argv[1]);
        else if(result == 17)
            printf("mkfs: hda JTMFS was created, but the current BIOS boot source is not a floppy; boot install was not completed.\n");
        else if(result == 18)
            printf("mkfs: hda JTMFS was created, but boot-kernel copy/verification failed.\n");
        else
            printf("Invalid device or formatting failed: '%s' (error %d)\n", argv[1], result);
        return 1;
    }
    printf("Formatting of drive %s completed.\n", argv[1]);
    if(!strcmp(argv[1], "hda") || !strcmp(argv[1], "hda:"))
        printf("mkfs: current floppy boot loader and 512K kernel installed to hda; rootinstall is no longer required for a normal floppy install.\n");
    return 0;
#else
    (void)result;
    printf("%s: formatting is disabled in the host test build.\n", argv[0]);
    return 1;
#endif
}
