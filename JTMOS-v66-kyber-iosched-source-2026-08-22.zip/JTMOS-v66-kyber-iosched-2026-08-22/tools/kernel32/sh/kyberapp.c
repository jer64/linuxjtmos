#include <stdio.h>
#include <string.h>

#include "driver_sys.h"
#include "kyber.h"
#include "kyberapp.h"


static int kyber_parse_positive(const char *s, unsigned long max_value, int *value)
{
    unsigned long v = 0;
    if(s == NULL || value == NULL || *s == 0)
        return 1;
    while(*s)
    {
        if(*s < '0' || *s > '9')
            return 1;
        v = v * 10UL + (unsigned long)(*s - '0');
        if(v > max_value)
            return 1;
        ++s;
    }
    if(v == 0)
        return 1;
    *value = (int)v;
    return 0;
}

static void kyber_usage(void)
{
    printf("kyber [status [device]]\n");
    printf("kyber on|off <device>\n");
    printf("kyber target <device> <read-us> <write-us>\n");
    printf("kyber targetms <device> <read-ms> <write-ms>\n");
    printf("kyber reset <device>\n");
}

static int kyber_device_arg(const char *name)
{
    int dnr;
    if(name == NULL)
        return -1;
    dnr = driver_getdevicenrbyname(name);
    if(dnr < 0)
        printf("kyber: device '%s' not found.\n", name);
    return dnr;
}

int kyber_app(int argc, char **argv)
{
    int dnr;
    int read_value;
    int write_value;

    if(argc <= 1 || !strcmp(argv[1], "status"))
    {
        if(argc >= 3)
        {
            dnr = kyber_device_arg(argv[2]);
            if(dnr < 0) return 1;
            kyber_print_device(dnr);
        }
        else
            kyber_print_all();
        return 0;
    }

    if((!strcmp(argv[1], "on") || !strcmp(argv[1], "off")) && argc >= 3)
    {
        dnr = kyber_device_arg(argv[2]);
        if(dnr < 0) return 1;
        if(kyber_set_enabled(dnr, !strcmp(argv[1], "on")) != 0)
            return 1;
        kyber_print_device(dnr);
        return 0;
    }

    if((!strcmp(argv[1], "target") || !strcmp(argv[1], "targetms")) && argc >= 5)
    {
        DWORD read_us;
        DWORD write_us;
        dnr = kyber_device_arg(argv[2]);
        if(dnr < 0) return 1;
        if(!strcmp(argv[1], "targetms"))
        {
            if(kyber_parse_positive(argv[3], 60000UL, &read_value) != 0 ||
               kyber_parse_positive(argv[4], 60000UL, &write_value) != 0)
            {
                printf("kyber: millisecond targets must be 1..60000.\n");
                return 1;
            }
            read_us = (DWORD)read_value * 1000UL;
            write_us = (DWORD)write_value * 1000UL;
        }
        else
        {
            if(kyber_parse_positive(argv[3], 60000000UL, &read_value) != 0 ||
               kyber_parse_positive(argv[4], 60000000UL, &write_value) != 0)
            {
                printf("kyber: microsecond targets must be 1..60000000.\n");
                return 1;
            }
            read_us = (DWORD)read_value;
            write_us = (DWORD)write_value;
        }
        if(kyber_set_latency_targets(dnr, read_us, write_us) != 0)
            return 1;
        kyber_print_device(dnr);
        return 0;
    }

    if(!strcmp(argv[1], "reset") && argc >= 3)
    {
        dnr = kyber_device_arg(argv[2]);
        if(dnr < 0) return 1;
        kyber_reset_stats(dnr);
        kyber_print_device(dnr);
        return 0;
    }

    kyber_usage();
    return 1;
}
