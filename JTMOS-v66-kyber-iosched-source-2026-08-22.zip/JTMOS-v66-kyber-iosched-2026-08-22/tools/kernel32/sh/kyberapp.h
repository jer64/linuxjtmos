#ifndef JTMOS_SMSH_KYBERAPP_H
#define JTMOS_SMSH_KYBERAPP_H
int kyber_app(int argc, char **argv);
#endif
