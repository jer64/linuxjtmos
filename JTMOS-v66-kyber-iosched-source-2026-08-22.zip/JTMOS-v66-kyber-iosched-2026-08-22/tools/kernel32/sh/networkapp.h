#ifndef SMSH_NETWORKAPP_H
#define SMSH_NETWORKAPP_H
int internet_app(int argc, char **argv);
int www_app(int argc, char **argv);
#endif
