//--------------------------------------------------------------------------------------------
// helpapp.c - Shell Manual.
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include "helpapp.h"

// Bring up the manual.
int help_app(int argc, char **argv)
{
	//
	printf("cd - changes directory\n");
	printf("chdir - changes directory\n");
	printf("ls - lists directory\n");
	printf("dir - lists directory\n");
	printf("mkfs [device] - format an unused device as JTMFS\n");
	printf("mount [device] - enable/list block devices\n");
	printf("umount [device] - disable an unused block device\n");
	printf("root [device] - select an existing JTMFS namespace root\n");
	printf("rootinstall [device] - install boot kernel (example: rootinstall hda)\n");
	printf("sound [sb|gus] [file.wav] - play 8-bit mono PCM WAV or built-in demo\n");
	printf("internet [start [com2] [115200]|stop|status] - manage RFC1055 SLIP/uIP\n");
	printf("www [start [port]|stop|status] - background HTTP server (default port 80)\n");
	printf("bootroot - re-run SMSH root selection (hda first, ram rescue second)\n");
	printf("format [device name]\n");
	printf("help - this manual\n");
	printf("exit / quit - leave SMSH\n");
	printf("sqa archive.sqa [options] - extract Squirrel archive\n");
	printf("sqarc directory archive.sqa - create Squirrel archive\n");
	printf("nzip file / nzip -d file.nz - compress or extract\n");
	printf("kyber [status|on|off|target|targetms|reset] - low-latency block I/O scheduler\n");
	printf("copyall [source path] - copy and verify all source files into current directory\n");
	printf("rm_wildcard [text] (aliases: rmwild, rmw) - delete matching files\n");
	printf("debug [on|off|toggle|status] (alias: debug1) - kernel debug level 1\n");
	printf("report [on|off|toggle|status] (alias: debug2) - reporting level 2\n");
	printf("m <hex-address> [hex-length] (alias: kmed) - kernel memory hex/ASCII dump\n");
	printf("fm <filename> - file hex/ASCII dump\n");
	printf(":program [args] - load an external .bin through LaunchApp (example: :install)\n");
	printf(":program [args] & - start explicit external program in background\n");
	printf("Unknown commands without ':' keep the legacy system() fallback.\n");
	printf("\n");

	return 0;
}

