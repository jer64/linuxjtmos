#ifndef JTMOS_NZIP_H
#define JTMOS_NZIP_H

/*
 * Peanut/Nut Zip stream format.
 *
 * V65 keeps the historical byte-stream records readable and adds an adaptive
 * BWT block record.  New encoders may freely mix legacy RLE/back-reference
 * records with BWT blocks; the decoder reconstructs one continuous output.
 */
#if defined(JTMOSKERNEL)
#include "basdef.h"
typedef signed long NZIP_INT32;
typedef unsigned long NZIP_UINT32;
#elif defined(JTMOS_APPLICATION)
#include <stdint.h>
#include <stddef.h>
#include <jtmos/types.h>
typedef int32_t NZIP_INT32;
typedef uint32_t NZIP_UINT32;
#else
#include <stdint.h>
#include <stddef.h>
typedef int32_t NZIP_INT32;
typedef uint32_t NZIP_UINT32;
typedef uint8_t BYTE;
typedef uint16_t WORD;
typedef uint32_t DWORD;
#endif

/* Historical codes.  CODE_END is 0xFCEE in the original JTMOS format. */
#define CODE_CHARPACK       0xFCE3U
#define CODE_ADVPAK         0xFCE4U
#define CODE_BWT            0xFCE5U
#define CODE_END            0xFCEEU
#define CODE_FIX            0xFCEFU
/* A short-lived V65 development build accidentally emitted 0xFEEE.  Decode
 * it for recovery, but never emit it again. */
#define CODE_END_V65_BROKEN 0xFEEEU

#define NZIP_MAX_MATCH       65535U
#define NZIP_MIN_RLE         8U
#define NZIP_MIN_BACKREF     10U
#define NZIP_MAX_LOOKBACK    (128U * 1024U)
#define NZIP_HASH_SIZE       65536U
#define NZIP_IO_CHUNK        32768U

/* BWT is deliberately block based: it bounds RAM use, allows mixed codecs,
 * and keeps the inverse transform practical on a small 32-bit OS. */
#define NZIP_BWT_BLOCK       16384U
#define NZIP_BWT_MIN_BLOCK   256U
#define NZIP_BWT_HEADER_SIZE 12U /* marker + raw + primary + packed + CRC32 */

enum {
    NZIP_MODE_AUTO = 0,      /* compare legacy and BWT per block */
    NZIP_MODE_LEGACY = 1,    /* historical char-pack/back-reference only */
    NZIP_MODE_BWT = 2        /* prefer BWT blocks; legacy fallback on failure */
};

#if defined(JTMOS_APPLICATION)
#define NZIP_MAX_OUTPUT      (32U * 1024U * 1024U)
#elif defined(JTMOSKERNEL)
#define NZIP_MAX_OUTPUT      (32U * 1024U * 1024U)
#else
#define NZIP_MAX_OUTPUT      (512U * 1024U * 1024U)
#endif

int nzip_main(int argc, char **argv);
int nzip_compress(const char *source, const char *destination);
int nzip_compress_mode(const char *source, const char *destination, int mode);
int nzip_compress_named_mode(const char *fname, int mode);
int nzip_uncompress(const char *source, const char *destination);
int nzip_output_name(char *output, size_t capacity, const char *source);

/* Historical source-level names retained for JTMOS applications/shell code. */
int compress(const char *fname);
int uncompress(const char *fname);
void unNutFname(char *output, const char *source);

#endif
