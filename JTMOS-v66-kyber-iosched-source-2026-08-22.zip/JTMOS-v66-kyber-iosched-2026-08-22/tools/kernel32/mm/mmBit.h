// mmBit.h - MM bitmap bit functions header file
#ifndef __INCLUDED_MMBIT_H__
#define __INCLUDED_MMBIT_H__

extern BYTE mmOrBits[];
extern BYTE mmAndBits[];

// Safe bitmap operations. Out-of-range reads are treated as reserved pages.
int mmBitGet(DWORD which);
int mmBitSet(DWORD which);
int mmBitRemove(DWORD which);
int mmBitWrite(DWORD which, int state);

#define BIT(WHICH, STATE) mmBitWrite((DWORD)(WHICH), (STATE))

int mmSetRegion(DWORD s, DWORD e, int STATE);
int mmFreeRegionAD(char *p_s, char *p_e);
int mmReserveRegionAD(char *p_s, char *p_e);
int mmFreeRegion(DWORD s, DWORD e);
int mmReserveRegion(DWORD s, DWORD e);
int mmFindFreePages(int pages);
DWORD malloc_getmemoryfree(void);
int malloc_getamountfree(void);

#endif
