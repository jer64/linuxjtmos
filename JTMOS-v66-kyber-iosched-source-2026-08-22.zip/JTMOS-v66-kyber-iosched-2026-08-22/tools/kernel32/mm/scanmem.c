///////////////////////////////////////////////////////////////////////////////////
// scanmem.c
// (C) 2004-2005 Jari Tuominen.
// Fixed 2026: bounded probe loop and guaranteed IRQ restore on exit.
///////////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include "kernel32.h"
#include "scanmem.h"

#ifndef SCANMEM_MAX_KB
// Conservative default cap for direct probing. Raise this after bootloader/e820 support.
#define SCANMEM_MAX_KB (1024*1024)
#endif

//////////////////////////////////////////////////////////////////////////////////////////
MEMORY_INFORMATION ms;

//////////////////////////////////////////////////////////////////////////////////////////
// Returns amount of total memory space in bytes.
//
int scanmem1(void)
{
#ifdef GRAOS_BOOT_TEST_RAM_MB
    /*
     * GraOS/QEMU boot-test path.
     *
     * Do NOT probe RAM by writing test patterns to physical addresses here.
     * The legacy scan walked through kernel/IDT/page-table memory and also
     * touched the first address past QEMU's configured RAM.  That can corrupt
     * live kernel state and caused the V6 boot to stop at scanmem().
     *
     * For this test build the emulator RAM size is an explicit build contract:
     * run QEMU with the matching -m value (64 MB in V7).  A later native
     * implementation should obtain the BIOS E820 map in boot32 and pass it to
     * the kernel instead of destructive probing.
     */
    int bytes = GRAOS_BOOT_TEST_RAM_MB * 1024 * 1024;

    DebugSerialWrite("[scanmem] safe test path entered\n");
    printk("scanmem: safe QEMU test mode, RAM=%d MB (no destructive probe).\n",
           GRAOS_BOOT_TEST_RAM_MB);
    DebugSerialWrite("[scanmem] status printk returned\n");

    ms.usable = bytes;
    ms.unusable = 0;
    DebugSerialWrite("[scanmem] safe test path returning\n");
    return bytes;
#else
    volatile DWORD *mem;
    DWORD a;
    DWORD memkb;
    BYTE irq1, irq2;
    char str[256];

    irq1=inportb(0x21);
    irq2=inportb(0xA1);

    outportb(0x21, 0xFF);
    outportb(0xA1, 0xFF);

    memkb=0;

    /* Legacy destructive probe kept for non-test builds only. */
    for(mem=(volatile DWORD *)0x100000; memkb < SCANMEM_MAX_KB;
        memkb+=64, mem+=(1024*64>>2))
    {
        a = *mem;
        *mem=0x55AA55AA;
        asm("":::"memory");
        if(*mem!=0x55AA55AA)
        {
            *mem=a;
            break;
        }

        *mem=0xAA55AA55;
        asm("":::"memory");
        if(*mem!=0xAA55AA55)
        {
            *mem=a;
            break;
        }

        asm("":::"memory");
        *mem=a;
    }

    outportb(0x21, irq1);
    outportb(0xA1, irq2);

    if(memkb<16384)
    {
        sprintf(str, "Insufficient amount of RAM detected (%dK).", memkb);
        disable();
        panic(str);
    }

    ms.usable = memkb*1024;
    ms.unusable = 0;
    return memkb*1024;
#endif
}

//////////////////////////////////////////////////////////////////////////////////////////
int scanmem(void)
{
	int i;

	DebugSerialWrite("[scanmem] wrapper enter\n");
	i=scanmem1();
	DebugSerialWrite("[scanmem] scanmem1 returned\n");
	ms.amount=i;
 
	pd32(i/(1024*1024));
	print("M ram\n");
	DebugSerialWrite("[scanmem] wrapper leave\n");
	return i;
}

//////////////////////////////////////////////////////////////////////////////////////////
int GetRamAmount(void)
{
	return ms.amount;
}

//
