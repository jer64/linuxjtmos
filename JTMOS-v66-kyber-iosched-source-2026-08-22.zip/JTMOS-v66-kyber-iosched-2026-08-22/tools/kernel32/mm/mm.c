// ================================================================
// Enhanced memory management system 0.4.1.
// for JTMOS Operating System.
//
// (C) 2002-2006 by Jari Tuominen.
// Reliability fixes 2026.
// ================================================================
#include <stdio.h>
#include "mm.h"
#include "mmAlloc.h"
#include "mmTest.h"
#include "lock.h"

void *aldb;
char *MSTART,*phMSTART;
char *MEND,*phMEND;
char *REND,*phREND;
MM mm;
MM *p_mm = NULL;
int mallocOK = FALSE;
int mm_debug = FALSE;

static DWORD mm_align_up(DWORD v, DWORD a)
{
    if(a == 0)
        return v;
    return (v + a - 1) & ~(a - 1);
}

static DWORD mm_align_down(DWORD v, DWORD a)
{
    if(a == 0)
        return v;
    return v & ~(a - 1);
}

static DWORD mm_overlap_pages(DWORD a0, DWORD a1, DWORD b0, DWORD b1)
{
    DWORD s,e;

    s = a0 > b0 ? a0 : b0;
    e = a1 < b1 ? a1 : b1;
    if(e <= s)
        return 0;

    /* All MM layout boundaries reaching this helper are page aligned. */
    return (e - s) / PAGESIZE;
}

void MMPANIC(const char *msg)
{
    printf("\n");
    printf("last function which called 'malloc' = '%s'\n", malloc_caller);
    printf("last function which called 'free' =   '%s'\n", free_caller);
    printf("%s: '%s'\n", __FUNCTION__, msg ? msg : "(null)");
    printf("%s: %u bytes free\n",
        __FUNCTION__, (unsigned int)malloc_getmemoryfree());
    printf("%s: descriptor high-water = %d\n",
        __FUNCTION__, mm.n_allocated);
    printf("%s: descriptor maximum = %d\n",
        __FUNCTION__, mm.max_allocated);
    panic("MMPANIC (description printed above)");
}

void mm_Diagnostics(void)
{
    printf("%s: phMSTART=0x%x, phMEND=0x%x, phREND=0x%x\n",
        __FUNCTION__, phMSTART, phMEND, phREND);
    printf("%s: DB map MSTART=0x%x, MEND=0x%x, REND=0x%x\n",
        __FUNCTION__, MSTART, MEND, REND);
    printf("%s: mm.allocated=0x%x(max=%d), mm.bitmap=0x%x(len=%d)\n",
        __FUNCTION__, mm.allocated, mm.max_allocated,
        mm.bitmap, mm.l_bitmap);
    printf("%s: paging physical reserve=0x%x..0x%x\n",
        __FUNCTION__, PG_STRUCTURES_PHYS_START, PG_STRUCTURES_PHYS_END);
}

void ShowPageMap(void)
{
    DWORD i,ad,mask;

    printk("%s\n", __FUNCTION__);
    for(i=0,ad=0; i<1024; i++,ad+=PAGESIZE)
    {
        if((i&255)==0)
            mask=0;
        mask |= GetPage(i);
        if((i&255)==255)
            printk("%x: mask=%x\n", ad/(1024*1024), mask);
    }
}

// Initialize the JTMOS physical-page allocator and allocation database.
// 'region' and 'length' describe the physical RAM range offered to MM.
void mmInit(void *region, int length)
{
    DWORD i;
    DWORD raw_start,raw_end,usable_start,usable_end,db_phys;
    DWORD db_start,db_end,bitmap_start,descriptor_start;
    DWORD db_without_bitmap,max_guess,max_by_ptr,max_by_desc;
    DWORD ptr_bytes,align;
    DWORD expected_free_pages,actual_free_pages,reserved_overlap_pages;
    char *p;

    mallocOK = FALSE;
    mm_debug = FALSE;

    if(region == NULL || length <= 0)
        panic("mmInit: invalid RAM region");

    raw_start = (DWORD)region;
    if((DWORD)length > 0xffffffffU - raw_start)
        panic("mmInit: RAM region wraps address space");
    raw_end = raw_start + (DWORD)length;

    usable_start = mm_align_up(raw_start, PAGESIZE);
    usable_end = mm_align_down(raw_end, PAGESIZE);

    if(usable_end <= usable_start)
        panic("mmInit: empty page-aligned RAM region");
    if((ALLOCATION_DATABASE_SIZE & (PAGESIZE-1)) != 0)
        panic("mmInit: allocation database size is not page aligned");
    if(usable_end < PG_STRUCTURES_PHYS_END)
        panic("mmInit: RAM does not cover fixed paging structures");
    if((usable_end - usable_start) <= ALLOCATION_DATABASE_SIZE + PAGESIZE)
        panic("mmInit: RAM region too small for MM database");

    db_phys = usable_end - ALLOCATION_DATABASE_SIZE;
    if(db_phys <= usable_start)
        panic("mmInit: MM database overlaps allocatable RAM start");
    if(db_phys < PG_STRUCTURES_PHYS_END &&
       usable_end > PG_STRUCTURES_PHYS_START)
        panic("mmInit: MM database overlaps paging structures");

    phMSTART = (char *)usable_start;
    phMEND = (char *)db_phys;
    phREND = (char *)usable_end;

    memset(&mm, 0, sizeof(MM));
    p_mm = &mm;

    // Paging structures have fixed physical locations and must exist before
    // the high virtual MM database mapping is installed.
    printk("MM physical layout: dynamic=0x%x..0x%x, DB=0x%x..0x%x\n",
        usable_start, db_phys, db_phys, usable_end);
    printk("MM fixed paging reserve: 0x%x..0x%x\n",
        PG_STRUCTURES_PHYS_START, PG_STRUCTURES_PHYS_END);
    printk("p_mm=0x%x\nESP = 0x%x\n", p_mm, GETESP());
    pg_init();

    MSTART = (char *)MAPAD_MM_DB;
    printk("pg_QuickMap: phst=%x, length=%x, mapad=%x\n",
        phMEND, ALLOCATION_DATABASE_SIZE, MSTART);
    if(pg_QuickMap((DWORD)phMEND, ALLOCATION_DATABASE_SIZE,
        (DWORD)MSTART) == NULL)
        panic("mmInit: cannot map allocation database");

    // Legacy names: the MM database begins at MEND/MSTART and ends at REND.
    MEND = MSTART;
    REND = MSTART + ALLOCATION_DATABASE_SIZE;
    aldb = MEND;

    memset(MEND, 0, ALLOCATION_DATABASE_SIZE);

    // Robust database layout:
    //   [ MD* pointer table ][ aligned MD descriptors ][ free-page bitmap ]
    // The bitmap has a fixed size (128 KB for the full 4 GB / 4 KB map).
    db_start = (DWORD)MEND;
    db_end = (DWORD)REND;
    bitmap_start = db_end - MM_BITMAP_BYTES;
    db_without_bitmap = bitmap_start - db_start;

    align = sizeof(DWORD);
    max_guess = db_without_bitmap / (sizeof(MD *) + sizeof(MD));
    if(max_guess == 0)
        panic("mmInit: allocation database cannot hold descriptors");

    // Reduce until pointer and descriptor areas fit after alignment.
    for(;;)
    {
        ptr_bytes = max_guess * sizeof(MD *);
        descriptor_start = mm_align_up(db_start + ptr_bytes, align);

        if(descriptor_start <= bitmap_start)
        {
            max_by_ptr = (descriptor_start - db_start) / sizeof(MD *);
            max_by_desc = (bitmap_start - descriptor_start) / sizeof(MD);
            if(max_guess <= max_by_ptr && max_guess <= max_by_desc)
                break;
        }

        if(max_guess == 0)
            panic("mmInit: allocation DB layout failed");
        max_guess--;
    }

    mm.max_allocated = (int)max_guess;
    mm.n_allocated = 0;
    mm.allocated = (MD **)MEND;
    mm.bitmap = (BYTE *)bitmap_start;
    mm.l_bitmap = MM_BITMAP_BYTES;

    for(i=0,p=(char *)descriptor_start; i<(DWORD)mm.max_allocated;
        i++,p+=sizeof(MD))
    {
        mm.allocated[i] = (MD *)p;
        memset(mm.allocated[i], 0, sizeof(MD));
        mm.allocated[i]->isFree = 1;
        mm.allocated[i]->PID = -1;
    }

    // Start fully reserved. Only the validated allocatable RAM range is freed.
    memset(mm.bitmap, 0xFF, mm.l_bitmap);
    mmFreeRegionAD(phMSTART, phMEND);

    // CRITICAL: pg_init() uses physical 0x001FF000..0x00800000 for the page
    // directory/tables. If this overlaps the allocatable RAM range, reserve it
    // again after freeing the general region so kmalloc() can never hand those
    // live paging pages to a caller.
    pg_reserve_internal_pages();

    // Keep the MM database and everything outside the offered user region
    // explicitly reserved as a defensive invariant.
    mmReserveRegionAD(phMEND, phREND);
    mmReserveRegionAD((char *)0, phMSTART);

    /* Cross-check the bitmap against the physical layout before the first
     * allocation is allowed.  This catches exactly the class of bugs where
     * a paging/DB page accidentally becomes allocatable. */
    expected_free_pages = (db_phys - usable_start) / PAGESIZE;
    reserved_overlap_pages = mm_overlap_pages(usable_start, db_phys,
        PG_STRUCTURES_PHYS_START, PG_STRUCTURES_PHYS_END);
    if(reserved_overlap_pages > expected_free_pages)
        panic("mmInit: paging overlap exceeds allocatable region");
    expected_free_pages -= reserved_overlap_pages;
    actual_free_pages = malloc_getmemoryfree() / PAGESIZE;
    if(actual_free_pages != expected_free_pages)
    {
        printk("mmInit: bitmap mismatch expected=%u pages actual=%u pages\n",
            expected_free_pages, actual_free_pages);
        panic("mmInit: physical allocation bitmap does not match layout");
    }
    printk("MM bitmap verified: %u allocatable pages (%u bytes).\n",
        actual_free_pages, actual_free_pages * (DWORD)PAGESIZE);

    mallocOK = TRUE;

    ShowPageMap();
    mm_Diagnostics();
    printf("%s: %u bytes free\n",
        __FUNCTION__, (unsigned int)malloc_getmemoryfree());
    printk("MM initialization passed.\n");
}

#ifdef LIBCVERSION
void disable(void)
{
}
void enable(void)
{
}
int get_eflags(void)
{
    return 0;
}
void set_eflags(int flags)
{
    (void)flags;
}

void malloc_init(char *p, int l)
{
    mmInit(p, l);
}
#endif
