// =================================================================================
// ApplicationModule_cexec.c
// Turbo cexec for JTMOS Application Module.
//
// Purpose:
//   - call a C entry point using a private application stack
//   - optionally copy a flat/position-independent module image to executable memory
//   - keep memory ownership in the MM database through procmalloc()/kfree()
//
// Entry prototype:
//   int app_main(int argc, char **argv, void *user);
//
// Notes:
//   - This is for flat 32-bit x86 JTMOS-style modules, not ELF relocation.
//   - For ELF, call the ELF loader first, then pass the resolved entry to turbo_cexec().
// =================================================================================
#include "kernel32.h"
#include "mm.h"
#include "mmAlloc.h"
#include "ApplicationModule_cexec.h"

static DWORD cexec_round_up(DWORD v, DWORD a)
{
	if(a == 0)
		return v;
	return (v + a - 1) & ~(a - 1);
}

static int cexec_pid(CEXEC_REQUEST *req)
{
	if(req != NULL && req->pid > 0)
		return req->pid;
	return GetCurrentThread();
}

static const char *cexec_name(CEXEC_REQUEST *req, const char *fallback)
{
	if(req != NULL && req->name != NULL)
		return req->name;
	return fallback;
}

static DWORD cexec_stack_size(CEXEC_REQUEST *req)
{
	DWORD s;

	s = CEXEC_DEFAULT_STACK;
	if(req != NULL && req->stack_size != 0)
		s = req->stack_size;

	if(s < PAGESIZE)
		s = PAGESIZE;
	return cexec_round_up(s, PAGESIZE);
}

static int cexec_call_on_stack(CEXEC_ENTRY entry, int argc, char **argv,
	void *user, void *stack_top)
{
	int ret;

#if defined(__i386__)
	asm volatile(
		"movl %%esp, %%esi\n\t"
		"movl %5, %%esp\n\t"
		"andl $0xfffffff0, %%esp\n\t"
		"pushl %4\n\t"
		"pushl %3\n\t"
		"pushl %2\n\t"
		"call *%1\n\t"
		"movl %%esi, %%esp\n\t"
		: "=a" (ret)
		: "r" (entry), "r" (argc), "r" (argv), "r" (user), "r" (stack_top)
		: "esi", "memory", "cc"
	);
#else
	// Host/libc build fallback. Kernel build on JTMOS should use i386 path.
	ret = entry(argc, argv, user);
#endif
	return ret;
}

int turbo_cexec(CEXEC_ENTRY entry, int argc, char **argv, CEXEC_REQUEST *req)
{
	void *stack;
	void *stack_top;
	DWORD stack_size;
	int pid;
	int ret;

	if(entry == NULL)
		return CEXEC_ERR_PARAM;
	if(!mallocOK)
		return CEXEC_ERR_NOMEM;

	pid = cexec_pid(req);
	stack_size = cexec_stack_size(req);

	stack = procmalloc(stack_size, pid, cexec_name(req, "cexec.stack"));
	if(stack == NULL)
		return CEXEC_ERR_NOMEM;

	// Keep stack ownership explicit in case procmalloc() was called with fallback PID.
	ChangeChunkOwner(stack, pid);

	stack_top = (void *)((DWORD)stack + stack_size - 16);
	ret = cexec_call_on_stack(entry, argc, argv,
		req != NULL ? req->user : NULL, stack_top);

	kfree(stack);
	return ret;
}

int turbo_cexec_image(const void *image, int image_bytes, int entry_offset,
	int argc, char **argv, CEXEC_REQUEST *req)
{
	void *code;
	CEXEC_ENTRY entry;
	int pid;
	int ret;

	if(image == NULL || image_bytes <= 0)
		return CEXEC_ERR_PARAM;
	if(entry_offset < 0 || entry_offset >= image_bytes)
		return CEXEC_ERR_OFFSET;
	if(!mallocOK)
		return CEXEC_ERR_NOMEM;

	pid = cexec_pid(req);
	code = procmalloc(image_bytes, pid, cexec_name(req, "cexec.image"));
	if(code == NULL)
		return CEXEC_ERR_NOMEM;

	memcpy(code, image, image_bytes);
	ChangeChunkOwner(code, pid);

	entry = (CEXEC_ENTRY)((DWORD)code + entry_offset);
	ret = turbo_cexec(entry, argc, argv, req);

	kfree(code);
	return ret;
}

int ApplicationModule_cexec(CEXEC_ENTRY entry, int argc, char **argv)
{
	CEXEC_REQUEST req;

	memset(&req, 0, sizeof(req));
	req.pid = GetCurrentThread();
	req.stack_size = CEXEC_DEFAULT_STACK;
	req.name = "ApplicationModule.cexec";
	req.user = NULL;

	return turbo_cexec(entry, argc, argv, &req);
}

//
