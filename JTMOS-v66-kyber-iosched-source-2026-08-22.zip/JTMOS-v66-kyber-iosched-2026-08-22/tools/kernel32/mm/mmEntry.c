// =================================================================
// mmEntry.c - Entry database management functions.
// (C) 2002-2005 by Jari Tuominen.
// Fixed 2026: safer descriptor reuse, bounds validation and graceful
//             descriptor exhaustion.
// =================================================================
#include <stdio.h>
#include "mm.h"
#include "mmEntry.h"

void mmRemoveEntry(MD *m)
{
    DWORD start,end;

    if(m == NULL || m->isFree)
        return;

    if(m->page > 0 && m->pages > 0)
    {
        start = (DWORD)m->page;
        end = start + (DWORD)m->pages;
        if(end >= start)
            mmFreeRegion(start, end);
    }

    memset(m, 0, sizeof(MD));
    m->PID = -1;
    m->isFree = 1;
}

// Exact allocation-base lookup. free() must receive the pointer returned by malloc().
MD *mmGiveMD(void *ptr)
{
    int i;
    DWORD ad;
    MD *m;

    if(p_mm == NULL || ptr == NULL)
        return NULL;

    ad = (DWORD)ptr;
    for(i=0; i<p_mm->n_allocated; i++)
    {
        m = p_mm->allocated[i];
        if(m == NULL || m->isFree)
            continue;

        if(m->mapad == ad)
            return m;
    }

    return NULL;
}

MD *mmGetNewEntry(void)
{
    MD *m;

    m = mmFindFreeEntry();
    if(m == NULL)
        m = mmNewEntry();

    return m;
}

MD *mmNewEntry(void)
{
    int i;

    if(p_mm == NULL || p_mm->allocated == NULL)
        return NULL;
    if(p_mm->n_allocated < 0 || p_mm->max_allocated <= 0)
        return NULL;
    if(p_mm->n_allocated >= p_mm->max_allocated)
        return NULL;

    i = p_mm->n_allocated++;
    if(p_mm->allocated[i] == NULL)
    {
        p_mm->n_allocated--;
        return NULL;
    }

    memset(p_mm->allocated[i], 0, sizeof(MD));
    p_mm->allocated[i]->PID = -1;
    p_mm->allocated[i]->isFree = 0;
    return p_mm->allocated[i];
}

MD *mmFindFreeEntry(void)
{
    int i;

    if(p_mm == NULL || p_mm->allocated == NULL)
        return NULL;

    for(i=0; i<p_mm->n_allocated; i++)
    {
        if(p_mm->allocated[i] != NULL && p_mm->allocated[i]->isFree)
            return p_mm->allocated[i];
    }

    return NULL;
}

int GetChunkOwner(void *p)
{
    MD *m;

    m = mmDetermineOwner(p);
    if(m == NULL)
        return 0;
    return m->PID;
}

// Locate the descriptor containing an arbitrary pointer inside an allocation.
MD *mmDetermineOwner(void *p)
{
    int i;
    DWORD ad,p1,len;
    MD *m;

    if(p_mm == NULL || p == NULL)
        return NULL;

    ad = (DWORD)p;
    for(i=0; i<p_mm->n_allocated; i++)
    {
        m = p_mm->allocated[i];
        if(m == NULL || m->isFree || m->mapad == 0 || m->bytes <= 0)
            continue;

        p1 = m->mapad;
        len = (DWORD)m->bytes;

        // Overflow-safe containment check: ad in [p1,p1+len).
        if(ad >= p1 && (ad - p1) < len)
            return m;
    }

    return NULL;
}

void *mmAddEntry(int sp, int pages, int bytes)
{
    MD *m;

    if(!mallocOK)
        return NULL;
    if(sp <= 0 || pages <= 0 || bytes <= 0)
        return NULL;

    m = mmGetNewEntry();
    if(m == NULL)
    {
        // Descriptor exhaustion is handled like ordinary OOM. The caller
        // rolls back the physical bitmap reservation.
        return NULL;
    }

    memset(m, 0, sizeof(MD));
    m->isFree = 0;
    m->PID = -1;
    m->page = sp;
    m->pages = pages;
    m->bytes = bytes;
    m->p = (void *)((DWORD)sp * PAGESIZE);

    return m;
}
