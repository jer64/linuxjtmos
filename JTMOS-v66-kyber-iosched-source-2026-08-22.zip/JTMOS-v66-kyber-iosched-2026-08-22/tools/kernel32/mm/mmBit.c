// ============================================================================
// Memory management system - Free memory bitmap operations.
// (C) 2002-2005 by Jari Tuominen.
// Fixed 2026: bounds-safe bit access, exact page search and conservative
//             address rounding for free/reserve operations.
// ============================================================================
#include <stdio.h>
#include "mm.h"
#include "mmBit.h"

BYTE mmOrBits[8]={1,2,4,8, 16,32,64,128};
BYTE mmAndBits[8]={255-1, 255-2, 255-4, 255-8,
        255-16, 255-32, 255-64, 255-128};

static DWORD mm_bitmap_pages(void)
{
    if(p_mm != NULL && p_mm->bitmap != NULL && p_mm->l_bitmap > 0)
        return (DWORD)p_mm->l_bitmap * 8;
    return 0;
}

int mmBitGet(DWORD which)
{
    DWORD pages;

    pages = mm_bitmap_pages();
    // Outside the represented bitmap is never allocatable.
    if(pages == 0 || which >= pages)
        return 1;

    return (p_mm->bitmap[which >> 3] & mmOrBits[which & 7]) ? 1 : 0;
}

int mmBitSet(DWORD which)
{
    DWORD pages;

    pages = mm_bitmap_pages();
    if(pages == 0 || which >= pages)
        return -1;

    p_mm->bitmap[which >> 3] |= mmOrBits[which & 7];
    return 0;
}

int mmBitRemove(DWORD which)
{
    DWORD pages;

    pages = mm_bitmap_pages();
    if(pages == 0 || which >= pages)
        return -1;

    p_mm->bitmap[which >> 3] &= mmAndBits[which & 7];
    return 0;
}

int mmBitWrite(DWORD which, int state)
{
    if(state)
        return mmBitSet(which);
    return mmBitRemove(which);
}

int malloc_getamountfree(void)
{
    DWORD free_bytes;

    free_bytes = malloc_getmemoryfree();
    // Preserve the historical signed-int API without returning a negative
    // value on machines with more than 2 GB free.
    if(free_bytes > 0x7fffffffU)
        return 0x7fffffff;
    return (int)free_bytes;
}

// Returns total amount of free physical memory represented by the bitmap.
DWORD malloc_getmemoryfree(void)
{
    DWORD i,l,freePages;

    l = mm_bitmap_pages();
    freePages = 0;
    for(i=0; i<l; i++)
    {
        if(!mmBitGet(i))
            freePages++;
    }

    return freePages * (DWORD)PAGESIZE;
}

// Returns the start page number containing at least 'pages' contiguous free pages.
int mmFindFreePages(int pages)
{
    DWORD i,l;
    int c,sp;

    if(pages <= 0)
        return 0;

    l = mm_bitmap_pages();
    if(l == 0 || (DWORD)pages > l)
        return 0;

    // Page zero is intentionally never returned: address 0 is also the
    // allocator's failure sentinel and should stay non-present.
    for(i=1,c=0,sp=0; i<l; i++)
    {
        if(!mmBitGet(i))
        {
            if(!c)
                sp = (int)i;
            c++;
            if(c >= pages)
                return sp;
        }
        else
        {
            c = 0;
            sp = 0;
        }
    }

    return 0;
}

// Mark an address range free. Only complete pages fully contained in
// [p_s,p_e) are freed; this avoids exposing bytes belonging to a neighbour.
int mmFreeRegionAD(char *p_s, char *p_e)
{
    DWORD s,e;

    s = (DWORD)p_s;
    e = (DWORD)p_e;
    if(e <= s)
        return 0;

    s = (s / PAGESIZE) + ((s % PAGESIZE) ? 1 : 0); // ceil(start)
    e = e / PAGESIZE;                                  // floor(end)
    if(e <= s)
        return 0;

    return mmFreeRegion(s,e);
}

// Mark an address range reserved. Every page touched by [p_s,p_e) is reserved.
int mmReserveRegionAD(char *p_s, char *p_e)
{
    DWORD s,e;

    s = (DWORD)p_s;
    e = (DWORD)p_e;
    if(e <= s)
        return 0;

    s = s / PAGESIZE;                                      // floor(start)
    e = (e / PAGESIZE) + ((e % PAGESIZE) ? 1 : 0);       // ceil(end)
    return mmReserveRegion(s,e);
}

int mmFreeRegion(DWORD s, DWORD e)
{
    return mmSetRegion(s,e,0);
}

int mmReserveRegion(DWORD s, DWORD e)
{
    return mmSetRegion(s,e,1);
}

// Fill [startPage,endPage) in the bitmap to a defined state (0 or 1).
int mmSetRegion(DWORD startPage, DWORD endPage, int STATE)
{
    DWORD i,l;

    l = mm_bitmap_pages();
    if(l == 0)
        return -1;
    if(startPage > endPage)
        return -1;
    if(startPage == endPage)
        return 0;
    if(startPage >= l)
        return -1;
    if(endPage > l)
        endPage = l;

    for(i=startPage; i<endPage; i++)
        mmBitWrite(i, STATE ? 1 : 0);

    return 0;
}
