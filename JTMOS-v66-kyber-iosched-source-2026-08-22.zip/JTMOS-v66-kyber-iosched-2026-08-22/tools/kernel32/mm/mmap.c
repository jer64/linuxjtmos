// ============================================================================
// mmap.c - POSIX-call-compatible mmap()/munmap() and ELF32 process mappings.
//
// The public mmap API is intentionally separate from kmalloc(). kmalloc keeps
// its historical one-argument kernel allocation role: kmalloc(size).
//
// Current JTMOS limitations:
//   * anonymous mappings are implemented;
//   * file-backed mappings are not implemented yet;
//   * MAP_FIXED requires a free exact range (it does not destroy an old map);
//   * munmap currently releases one complete mmap allocation, not a subrange;
//   * IA-32 non-PAE paging cannot enforce PROT_EXEC/NX separately.
// ============================================================================

#include <stddef.h>
#include "mm.h"
#include "mmAlloc.h"
#include "paging.h"
#include "sys/mman.h"

#if defined(N_MAX_THREADS) && (N_MAX_THREADS > MM_PROCESS_PAGE_TABLE_CAPACITY)
#error "JTMOS MM: PG_USER_PAGE_TABLES_BYTES is too small for N_MAX_THREADS"
#endif


static DWORD mmap_align_up(DWORD value)
{
    if(value > (0xffffffffUL - MM_PAGE_MASK))
        return 0;
    return (value + MM_PAGE_MASK) & ~MM_PAGE_MASK;
}

static int mmap_valid_prot(int prot)
{
    return (prot & ~(PROT_READ | PROT_WRITE | PROT_EXEC)) == 0;
}

void *mmap(void *addr, size_t length, int prot, int flags,
           int fd, off_t offset)
{
    DWORD bytes;
    void *p;
    int sharing;
    int pages;

    if(length == 0 || length > (size_t)0x7fffffffU)
        return MAP_FAILED;
    if(!mmap_valid_prot(prot))
        return MAP_FAILED;

    sharing = flags & (MAP_PRIVATE | MAP_SHARED);
    if(sharing != MAP_PRIVATE && sharing != MAP_SHARED)
        return MAP_FAILED;

    /* The first JTMOS implementation is anonymous-memory only. */
    if((flags & MAP_ANONYMOUS) == 0)
        return MAP_FAILED;
    if(fd != -1 || offset != 0)
        return MAP_FAILED;

    bytes = mmap_align_up((DWORD)length);
    if(bytes == 0 || bytes > 0x7fffffffUL)
        return MAP_FAILED;
    pages = (int)(bytes / PAGESIZE);

    if((flags & (MAP_FIXED | MAP_FIXED_NOREPLACE)) != 0)
    {
        if(addr == NULL || (((DWORD)addr) & MM_PAGE_MASK) != 0)
            return MAP_FAILED;

        /* Safe JTMOS interpretation: exact address, but never silently
           destroy an existing allocation. */
        p = _kmalloc_at((int)bytes, GetCurrentThread(), "mmap", (DWORD)addr);
    }
    else
    {
        /* addr is a POSIX hint here. The current JTMOS virtual allocator has
           no nearest-to-hint search, so an available mapping is selected. */
        p = kmalloc((int)bytes);
    }

    if(p == NULL)
        return MAP_FAILED;

    /* Anonymous mmap pages must initially read as zero. Do this while the
       mapping is writable, then apply the requested protection bits. */
    memset(p, 0, bytes);

    if(pg_protectmemory((DWORD)p, pages, prot) != 0)
    {
        kfree(p);
        return MAP_FAILED;
    }

    return p;
}

int munmap(void *addr, size_t length)
{
    DWORD bytes;
    int allocation_bytes;

    if(addr == NULL || addr == MAP_FAILED || length == 0)
        return -1;
    if(((DWORD)addr & MM_PAGE_MASK) != 0)
        return -1;
    if(length > (size_t)0x7fffffffU)
        return -1;

    bytes = mmap_align_up((DWORD)length);
    if(bytes == 0)
        return -1;

    allocation_bytes = malloc_getsize(addr);
    if(allocation_bytes <= 0)
        return -1;

    /* The MM descriptor currently represents one contiguous allocation.
       Reject partial unmaps rather than freeing more memory than requested. */
    if((DWORD)allocation_bytes != bytes)
        return -1;

    kfree(addr);
    return 0;
}

DWORD mm_page_align_down(DWORD value)
{
    return value & ~MM_PAGE_MASK;
}

DWORD mm_page_align_up(DWORD value)
{
    return mmap_align_up(value);
}

static DWORD *mm_process_page_table(int pid)
{
    DWORD bytes_per_process;
    DWORD maximum_processes;

    if(pid < 0)
        return NULL;

    bytes_per_process = MM_PROCESS_PAGE_TABLE_BYTES;
    maximum_processes = MM_PROCESS_PAGE_TABLE_CAPACITY;
    if((DWORD)pid >= maximum_processes)
        return NULL;

    return (DWORD *)(PG_USER_PAGE_TABLES_PHYS +
                     ((DWORD)pid * bytes_per_process));
}

static DWORD mm_pte_flags_from_prot(int prot)
{
    DWORD flags;

    if(prot == PROT_NONE)
        return 0;

    flags = 1;                  /* present */
    if(prot & PROT_WRITE)
        flags |= 2;             /* writable */

    /* IA-32 non-PAE has no NX bit, so PROT_EXEC cannot be independently
       enforced. PROT_READ/PROT_EXEC both mean a present, read-only PTE when
       PROT_WRITE is absent. */
    return flags;
}

void mm_clear_process_space(int pid)
{
    DWORD *table;
    DWORD i;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return;

    for(i = 0; i < MM_USER_PAGES; ++i)
        table[i] = 0;
}

int mm_map_process_range(int pid, DWORD virtual_address,
                         void *kernel_address, DWORD length, int prot)
{
    DWORD *table;
    DWORD virtual_end;
    DWORD first_index;
    DWORD page_count;
    DWORD source_page;
    DWORD source_pte;
    DWORD physical;
    DWORD pte_flags;
    DWORD i;

    if(kernel_address == NULL || length == 0 || !mmap_valid_prot(prot))
        return -1;
    if((virtual_address & MM_PAGE_MASK) != 0 ||
       ((DWORD)kernel_address & MM_PAGE_MASK) != 0)
        return -1;

    length = mm_page_align_up(length);
    if(length == 0 || virtual_address < MM_USER_BASE)
        return -1;
    if(virtual_address > 0xffffffffUL - length)
        return -1;

    virtual_end = virtual_address + length;
    if(virtual_end > MM_USER_TOP)
        return -1;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return -1;

    first_index = (virtual_address - MM_USER_BASE) / PAGESIZE;
    page_count = length / PAGESIZE;
    source_page = ((DWORD)kernel_address) / PAGESIZE;
    pte_flags = mm_pte_flags_from_prot(prot);

    for(i = 0; i < page_count; ++i)
    {
        source_pte = GetPage(source_page + i);
        physical = source_pte & 0xfffff000UL;

        if((source_pte & 1) == 0 || physical < PG_STRUCTURES_PHYS_END)
            return -1;

        table[first_index + i] = physical | pte_flags;
    }

    return 0;
}

int mm_protect_process_range(int pid, DWORD virtual_address,
                             DWORD length, int prot)
{
    DWORD *table;
    DWORD virtual_end;
    DWORD first_index;
    DWORD page_count;
    DWORD pte;
    DWORD pte_flags;
    DWORD i;

    if(length == 0 || !mmap_valid_prot(prot) ||
       (virtual_address & MM_PAGE_MASK) != 0)
        return -1;

    length = mm_page_align_up(length);
    if(length == 0 || virtual_address < MM_USER_BASE)
        return -1;
    if(virtual_address > 0xffffffffUL - length)
        return -1;

    virtual_end = virtual_address + length;
    if(virtual_end > MM_USER_TOP)
        return -1;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return -1;

    first_index = (virtual_address - MM_USER_BASE) / PAGESIZE;
    page_count = length / PAGESIZE;
    pte_flags = mm_pte_flags_from_prot(prot);

    for(i = 0; i < page_count; ++i)
    {
        pte = table[first_index + i];
        if((pte & 0xfffff000UL) == 0)
            return -1;
        table[first_index + i] = (pte & 0xfffff000UL) | pte_flags;
    }

    return 0;
}

int mm_unmap_process_range(int pid, DWORD virtual_address, DWORD length)
{
    DWORD *table;
    DWORD virtual_end;
    DWORD first_index;
    DWORD page_count;
    DWORD i;

    if(length == 0 || (virtual_address & MM_PAGE_MASK) != 0)
        return -1;

    length = mm_page_align_up(length);
    if(length == 0 || virtual_address < MM_USER_BASE)
        return -1;
    if(virtual_address > 0xffffffffUL - length)
        return -1;

    virtual_end = virtual_address + length;
    if(virtual_end > MM_USER_TOP)
        return -1;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return -1;

    first_index = (virtual_address - MM_USER_BASE) / PAGESIZE;
    page_count = length / PAGESIZE;
    for(i = 0; i < page_count; ++i)
        table[first_index + i] = 0;

    return 0;
}

DWORD mm_find_process_free_range(int pid, DWORD length, DWORD low, DWORD high)
{
    DWORD *table;
    DWORD pages;
    DWORD low_index;
    DWORD high_index;
    DWORD start;
    DWORD i;
    int free_range;

    length = mm_page_align_up(length);
    if(length == 0)
        return 0;
    if(low < MM_USER_BASE)
        low = MM_USER_BASE;
    if(high > MM_USER_TOP)
        high = MM_USER_TOP;
    low = mm_page_align_up(low);
    high = mm_page_align_down(high);
    if(high <= low || length > high-low)
        return 0;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return 0;
    pages = length / PAGESIZE;
    low_index = (low-MM_USER_BASE)/PAGESIZE;
    high_index = (high-MM_USER_BASE)/PAGESIZE;
    if(high_index < pages)
        return 0;

    start = high_index-pages;
    for(;;)
    {
        if(start < low_index)
            break;
        free_range = 1;
        for(i=0; i<pages; ++i)
        {
            if(table[start+i] & 1)
            {
                free_range = 0;
                break;
            }
        }
        if(free_range)
            return MM_USER_BASE + start*PAGESIZE;
        if(start == 0)
            break;
        --start;
    }
    return 0;
}
