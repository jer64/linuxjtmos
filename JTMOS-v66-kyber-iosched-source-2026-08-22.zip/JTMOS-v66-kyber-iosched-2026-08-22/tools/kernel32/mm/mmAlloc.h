#ifndef __INCLUDED_MMALLOC_H__
#define __INCLUDED_MMALLOC_H__

#include <stddef.h>

extern char free_caller[];
extern char malloc_caller[];

/* Standard C/POSIX-style heap interface. */
void *malloc(size_t size);
void free(void *ptr);
void *calloc(size_t nmemb, size_t size);
void *realloc(void *ptr, size_t size);
void *reallocarray(void *ptr, size_t nmemb, size_t size);

/* Historical debug-aware entry points remain available to old JTMOS code. */
void *malloc1(int count, const char *_property_name);
void free1(void *ptr, const char *_property_name);

/* Kernel allocator: deliberately remains kmalloc(X), not mmap-like. */
void *kmalloc(int l);
void kfree(void *ptr);

void *procmalloc(DWORD l, int PID, const char *_property_name);
void *_kmalloc(int bytes, int PID, const char *_property_name);
void *_kmalloc_at(int bytes, int PID, const char *_property_name, DWORD mapad);
void _kfree(void *ptr);
int ChangeChunkOwner(void *PTR, int PID);
int malloc_getsize(void *PTR);
void AffectProcessML(int pid, int affection);
void malloc_freeprocmem(int pid);
void SetMemoryName(void *ptr, const char *name);
void mmPause(void);

#endif
