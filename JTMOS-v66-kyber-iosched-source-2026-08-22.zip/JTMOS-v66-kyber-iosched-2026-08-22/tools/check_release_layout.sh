#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
! grep -Eq '^([[:space:]]*)\$\(MAKE\)[[:space:]]+-C[[:space:]]+kernel32[[:space:]]+imp([[:space:]]|$)' Makefile || {
    echo "check: obsolete kernel32 imp target call still present" >&2; exit 1;
}
grep -q '^image:' Makefile

grep -q '^default: image utilsimage' Makefile
grep -q '^linkit: image' Makefile
grep -q 'RD_DEFAULT_SIZE=[[:space:]]*65536' kernel32/init/keropt.c
grep -q 'rd_default_blocks_for_ram' kernel32/drivers/ramdisk/ramdisk.c
grep -q '\{"sqa", sqa_main\}' kernel32/sh/sh.c
grep -q 'install.img.nz' tools/build_install_image.sh
grep -q ':unz install.img.nz' tools/build_install_image.sh
grep -q 'jtm32-util.cfg' Makefile
grep -q 'tools/utils1440.sqa' jtm32-util.cfg
grep -q 'make image' Makefile || true
# V66 Kyber scheduler integration invariants.
[ -f kernel32/drivers/kyber.c ]
[ -f kernel32/drivers/kyber.h ]
[ -f kernel32/sh/kyberapp.c ]
grep -q '\{"kyber", kyber_app\}' kernel32/sh/sh.c
grep -q 'kyber_should_schedule' kernel32/drivers/driver_rw.c
grep -q 'kyber_barrier_begin' kernel32/drivers/driver_flush.c
grep -q 'kyber_barrier_begin' kernel32/drivers/driver_api.c
grep -q 'KYBER_READ_TARGET_US[[:space:]]*2000' kernel32/drivers/kyber.c
grep -q 'KYBER_WRITE_TARGET_US[[:space:]]*10000' kernel32/drivers/kyber.c
# SMSH SQA support must remain present in both command front-end and extractor.
[ -f kernel32/sh/sqaMain.c ]
[ -f kernel32/sh/sqa.c ]
[ ! -f jtm32.img ] || [ "$(wc -c < jtm32.img)" -eq 1474560 ]
[ ! -f utils1440.img ] || [ "$(wc -c < utils1440.img)" -eq 1474560 ]
echo "release layout checks: PASS"
