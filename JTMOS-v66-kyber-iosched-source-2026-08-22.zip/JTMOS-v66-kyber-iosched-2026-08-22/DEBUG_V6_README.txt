GraOS / JTMOS V6 serial + QEMU exception debug build
====================================================

This build intentionally enables:
  jtmos_debug       = 1
  debug2            = 1
  serial_debug_line = 0   (COM1)

Important V6 change:
All kernel console output is mirrored to a polling COM1 debug UART from the
very beginning of the 32-bit C kernel.  It does not depend on serial_init(),
IDT, PIC, malloc, interrupts or multitasking.  This is needed because VESA
mode hides the legacy VGA text console.

Run from the source tree:
  ./scripts/run_qemu_debug_v6.sh

Or from the release directory:
  ./run_qemu_debug_v6.sh

Outputs:
  qemu-debug-v6/jtmos-serial.log   JTMOS printk/dprintk/ReportMessage stream
  qemu-debug-v6/qemu-cpu.log      QEMU exceptions/register dumps
  qemu-debug-v6/analysis.txt      automatic EIP -> kernel symbol analysis

If the QEMU window stays open after a fault, close it.  The analysis script
then runs automatically.

Why V5 looked black:
The V5 boot loader successfully enters VESA 640x480x8 mode, but the native
kernel is not compiled with -DGRAOS and VesaSetup() is still disabled in the
normal kernel boot path.  Its text output therefore continues to legacy
0xB8000 memory, which is not visible while the display is in VESA graphics
mode.  A black display alone does not prove that the kernel has crashed.
