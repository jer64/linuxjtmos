JTMOS V62 - device-qualified CWD, chdir/getcwd and SMSH prompt
==============================================================
Date: 2026-08-21

Path rules
----------
* Canonical absolute paths returned by getcwd() always include a device:
    ram:/
    sys:/
    hda:/
    hda:/apps
* A device prefix is optional on input.  Plain names are relative to the
  current device/current directory: `cd apps`, `cd ../bin`.
* Explicit device paths such as `cd sys:/` and `cd hda:/apps` start at that
  device root.
* Historical `/hda/...` namespace paths remain accepted for compatibility,
  but new code should use `hda:/...`.
* `..` at a device root stays at that device root.

Kernel/libc fixes
-----------------
* kernel32/fs/_chdir.c was an empty stub; it now calls jtmfs_chdir().
* SYS_chdir translates the application pointer and returns 0 / negative error.
* SYS_getcwd now uses both the buffer pointer and buffer length supplied by libc.
* Legacy libc getcwd() now returns the caller buffer on success rather than
  casting the raw syscall result to char *.

SMSH
----
The prompt shows the canonical current working directory before '#', e.g.:
    sys:/#
    hda:/apps#
`cd` without arguments prints the canonical CWD.
