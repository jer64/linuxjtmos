;=================================================================================
; JTMOS kernel loader for DOS operating system.
; (C) 2007-2008 by Jari Tuominen.
;=================================================================================
;
[bits 16]
org 0x100  ; 'COM file' start address

jmp start

%include "../boot32/seg.mac"
%include "../boot32/a20.inc"
%include "kchecksum.inc"
%include "dosputs.mac"

;----------------------------------------------------------------------------

start:
    puts txt_announce

    ; Open kernel file
    mov ax, cs
    mov ds, ax
    mov dx, fn_dosker32
    mov ah, 0x3D
    mov al, 0x00
    int 0x21
    jnc file_opened_ok
    jmp terminate_program

file_opened_ok:
    mov word [cs:fhandle], ax

    ; Set kernel load pointer at 0x20000
    mov ax, 0x2000
    mov word [cs:kerloadptr_seg], ax
    xor ax, ax
    mov word [cs:kerloadptr_offs], ax

load_loop:
    mov ax, word [cs:kerloadptr_seg]
    mov ds, ax
    mov dx, word [cs:kerloadptr_offs]
    mov bx, word [cs:fhandle]
    mov cx, 0x1000
    mov ah, 0x3F
    int 0x21
    jnc nerror
    jmp terminate_program

nerror:
    cmp ax, 0
    je end_of_file

    push ax
    mov ax, word [cs:kerloadptr_seg]
    mov ds, ax
    mov si, 0
    pop cx

calcl:
    mov al, byte [ds:si]
    xor ah, ah
    add word [cs:measkerchksum], ax
    inc si
    loop calcl

    mov ax, word [cs:kerloadptr_seg]
    add ax, 0x100
    mov word [cs:kerloadptr_seg], ax

    puts txt_progress
    jmp load_loop

end_of_file:
    mov ah, 0x3E
    mov bx, word [cs:fhandle]
    int 0x21

    puts txt_ld_chksum_is
    mov ax, word [cs:measkerchksum]
    call phex16
    puts txt_enter

    puts txt_cr_chksum_is
    mov ax, kchecksum
    call phex16
    puts txt_enter

    mov ax, word [cs:kchecksum]
    mov bx, word [cs:measkerchksum]
    cmp ax, bx
    je checksum_matches
    puts txt_mismatch
    jmp skipsuc

checksum_matches:
    puts txt_success
skipsuc:

    puts txt_f1_to_launch

    ; Wait for key press (F1 to launch kernel)
    mov ah, 0
    int 0x16
    cmp ax, 0x3B00
    jne terminate_program

proceed:
    puts txt_enter

    ; Ensure keyboard buffer is flushed
    xor ax, ax
    int 0x16

    ; A20 setup and check
    call a20
    call check_a20
    jnc a20_ok
    puts txt_a20_failed
    jmp terminate_program
a20_ok:

    puts txt_a20_ok

    ; Entering Protected Mode
    cli
    lgdt [dword global_descriptor_table]
    lidt [dword interrupt_descriptor_table]

    mov eax, cr0
    or al, 1
    mov cr0, eax

    ; Mandatory far jump to protected mode
    db 0x66, 0xEA
    dd 0x00020000
    dw code32_idx

terminate_program:
    puts txt_failure
    mov ax, 0x4C00
    int 0x21
    jmp $

; Data storage
kerloadptr_seg: dw 0
kerloadptr_offs: dw 0
measkerchksum: dw 0
fhandle: dw 0
fn_dosker32: db "dosker32.bin",0

; A20 verification function
check_a20:
    pusha
    mov ax, 0
    mov es, ax
    mov di, 0x500
    mov al, [es:di]
    mov ah, [es:di + 0x100000]
    cmp al, ah
    popa
    jc a20_enabled
    clc
    ret
a20_enabled:
    stc
    ret

; Descriptor tables
global_descriptor_table:
gdt_start: dw gdt_size, 0, 0
gdtoff:
segdes dummy_descriptor, 0xFFFF, 0, 0, 0x9A, 0xCF, 0
segdes code32_descriptor, 0xFFFF, 0, 0, 0x9A, 0xCF, 0
segdes data32_descriptor, 0xFFFF, 0, 0, 0x92, 0xCF, 0
segdes core32_descriptor, 0xFFFF, 0, 0, 0x92, 0xCF, 0
segdes code16_descriptor, 0xFFFF, 0, 0, 0x9A, 0, 0
segdes data16_descriptor, 0xFFFF, 0, 0, 0x92, 0, 0

gdt_size equ $ - (gdtoff)
code32_idx equ 0x08

interrupt_descriptor_table:
idt_start: dw idt_size, 0, 0
intdes interrupt_0, demo_int, code32_idx, 0, 0x8E, 0
idt_size equ $ - (interrupt_0)

demo_int:
    iretd

; Output messages
txt_a20_ok: db "A20 enabled successfully.",13,10,'$'
txt_a20_failed: db "A20 enable failed.",13,10,'$'
txt_bad_vesa: db "Video BIOS has no VESA 2.0 support.",13,10,'$'
txt_enter: db 13,10,'$'
txt_ld_chksum_is: db 13,10,'Loaded kernel checksum: $'
txt_cr_chksum_is: db 13,10,'Expected kernel checksum: $'
txt_announce: db "JTMOS kernel loader for DOS.",13,10,'$'
txt_success: db 13,10,'Kernel loaded successfully.',13,10,'$'
txt_f1_to_launch: db 13,10,'Press F1 to launch kernel: ','$'
txt_mismatch: db 13,10,'Error: Checksum mismatch.',13,10,'$'
txt_failure: db 13,10,'Kernel load failed.',13,10,'$'
txt_progress: db '.','$'

phex16:
    pusha                 ; Save all registers
    mov cx, 4             ; We need to print 4 hex digits
    mov bx, 0xF000        ; Mask for extracting the highest nibble

hex_loop:
    mov dx, ax            ; Copy AX to DX
    and dx, bx            ; Mask only the relevant nibble
    shr dx, 12            ; Shift into lowest 4-bit position

    cmp dl, 10            ; Check if digit is 0-9 or A-F
    jl  print_digit
    add dl, 'A' - 10      ; Convert 10-15 to 'A'-'F'
    jmp print

print_digit:
    add dl, '0'           ; Convert 0-9 to '0'-'9'

print:
    mov al, dl            ; Move character into AL for putchar
    putchar al            ; Print character

    rol ax, 4             ; Rotate to the next highest nibble
    loop hex_loop         ; Repeat for remaining nibbles

    popa                  ; Restore registers
    ret
