GraOS/JTMOS V8 low-stack + A20 diagnostic build

Changes from V7:
- boot32/boot.asm explicitly has %define VESA_ENABLED 1
- protected-mode bootloader stack restored to ESP=0x00007C00
- kernel naked bootstrap also restores ESP=0x00007C00
- kernel forces fast A20 via port 0x92 before KernelInit and verifies 0x500 vs 0x100500
- if A20 verification fails, kernel halts before it can corrupt low memory
- paging.c logs before/after clearing physical 0x00200000 and 0x00600000 page-table regions
- V6/V7 COM1 debug remains enabled
- safe 64 MiB scanmem test mode remains enabled

Run with:
  ./scripts/run_qemu_debug_v8.sh

Expected early serial markers:
  [JTMOS V8] early COM1 serial debug active; ESP=0x7C00
  [A20] verified: addresses above 1 MiB do not alias low memory.

Then during paging:
  - clear page_table @0x200000, bytes=0x400000 ...
  - clear page_table OK
  - clear user_page_tables @0x600000, bytes=0x200000 ...
  - clear user_page_tables OK
