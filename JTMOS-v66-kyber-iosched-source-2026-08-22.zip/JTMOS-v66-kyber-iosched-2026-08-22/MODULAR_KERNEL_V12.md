# JTMOS V12 modular kernel test

The kernel build can now leave secondary modules out of `kernel32.bin`.
`kernel32/modules.conf` is the active default profile. `modules.full.conf`
reproduces the previous full V11 link, while `modules.small.conf` is the
size/isolation profile.

Options currently supported:

- SH: integrated SMSH/Squirrel/nzip shell utilities
- GRAOS_BOOT: GraOS floppy payload installer/launcher
- APP_LOADER: central process + application binary loader
- NETWORK: SLIP and TCP/IP stack
- AUDIO_DRIVERS: generic audio, GUS and Sound Blaster drivers
- HWDET: secondary hardware-detection process
- PCI: PCI bus driver
- LPT: parallel-port driver
- VMWARE: VMware-specific driver
- USERADMIN: user administration module
- XML_INIT: legacy XML init pass
- STATUSLINE: kernel status-line task

The small profile deliberately keeps the low-level kernel, memory manager,
paging, interrupts, scheduler, serial debug, keyboard, VGA/EGA console,
floppy/HD, RAM disk and JTMFS filesystem. This makes it useful for testing
whether large linked-in secondary subsystems are involved in the historical
double-fault behaviour.

Build examples:

    ./scripts/build_kernel_profile.sh small
    ./scripts/build_kernel_profile.sh full

The generated `modules.generated.h` is used as a make dependency so changing
the module profile forces C objects to be rebuilt with the new feature macros.
