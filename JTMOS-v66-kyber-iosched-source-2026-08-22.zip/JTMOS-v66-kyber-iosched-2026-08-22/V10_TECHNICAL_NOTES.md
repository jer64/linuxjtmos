# JTMOS/GraOS V10 changes

- C kernel bootstrap no longer writes SS or ESP. The protected-mode stack is owned by `boot32/boot.asm`; current bootloader value is `ESP=0x7C00`.
- Added `serial_console_redirect` to `kernel32/keropt.c`.
  - `1`: mirror normal `printk`/`printf`/`print`/`puts` terminal bytes to `serial_debug_line`.
  - `0`: do not mirror ordinary console output to the debug UART.
- `dprintk`, `ReportMessage`, and direct `DebugSerialWrite` remain usable on the debug UART when normal console mirroring is disabled.
- Central process key `r` toggles `serial_console_redirect` at runtime.
- Early logger prints the inherited C-entry ESP for verification without changing it.
- Build script rejects future changes that write ESP from `kernel32/init/start.c`.
