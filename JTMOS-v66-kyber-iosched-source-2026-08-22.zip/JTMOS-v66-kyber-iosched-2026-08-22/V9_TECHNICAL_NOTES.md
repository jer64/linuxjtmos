# JTMOS / GraOS V9 expert-fix boot test

This build concentrates on the first reproducible failure in the serial trace:
`Paging initializing: - Page tables ...`.

## Concrete bugs corrected

1. **Broken freestanding memset**
   `kernel32/core/dataproc/memset.c` had `OPSIZ=4` but `op_t=char`.
   Its bulk loop wrote 8 bytes and then advanced 32 bytes, so 75% of a large
   destination was never initialized.  Page tables must start from known zero
   entries, so V9 replaces this with a deliberately simple byte-accurate
   freestanding implementation.

2. **Paging bootstrap is now bounded and observable**
   The 4 MiB PTE array at 0x00200000 and the user PT reserve at 0x00600000 are
   cleared in 256 KiB chunks with a COM1 progress line every MiB.  The redundant
   second 4 MiB zeroing pass was removed.  Alignment and CR0.PG preconditions are
   checked before the page structures are touched.

3. **IDTR limit off by one**
   256 x 8-byte IA-32 gates occupy 0x800 bytes, therefore IDTR.limit must be
   0x7ff (highest legal byte offset), not 0x800.

4. **boot32 clear_memory used the wrong segment**
   The routine initialized DS=0x1000 but incremented ES, while stores still used
   DS.  It repeatedly cleared the same 16 bytes instead of the whole intended
   0x10000..0x8ffff kernel-load region.  Source and the shipped prebuilt
   boot.bin are both corrected to use ES.

5. **VBE framebuffer/paging handoff**
   boot32 already obtains the VBE ModeInfoBlock at physical 0x4000.  V9 now
   separates this into VesaProbe() before paging and VesaActivate() after paging.
   The kernel validates mode support, graphics mode, LFB availability, the
   expected 640x480x8 packed-pixel layout, pitch and PhysBasePtr.  pg_init()
   identity-maps the actual `pitch * height` framebuffer range before setting
   CR0.PG.  This replaces the old fixed 1 MiB mapping and the old disabled
   VesaSetup() handoff.

6. **Low bootstrap stack preserved**
   ESP remains 0x00007c00 as requested, growing downward in conventional memory.
   The kernel still verifies/enables A20 before touching the >1 MiB paging area.

## VESA source state

`boot32/boot.asm` contains an active:

    %define VESA_ENABLED 1

The release boot.bin contains VBE 4F01h and 4F02h / mode 4101h calls and is
validated by `scripts/verify_vesa_boot.py`.

## QEMU

Run:

    ./scripts/run_qemu_debug_v9.sh /path/to/GraOS-boot-test-v9-expertfix-2026-08-19.img

The important serial sequence should now include lines similar to:

    [JTMOS V9] expert-fix debug active; ESP=0x7C00
    [A20] verified: addresses above 1 MiB do not alias low memory.
    VESA pre-paging probe:
    VESA probe: 640x480x8 ...
    mmInit:
    Paging initializing:
    - CR0 before paging = ...
    - Page tables: flat PTE array 0x200000..0x600000
      kernel PTE: cleared through 0x300000
      kernel PTE: cleared through 0x400000
      kernel PTE: cleared through 0x500000
      kernel PTE: cleared through 0x600000
      user PT: cleared through 0x700000
      user PT: cleared through 0x800000
    - identity mapping first 8 MiB ... OK
    - identity mapping VESA LFB ... OK
    - Loading CR3=0x1ff000 ... OK
    - Setting CR0.PG ... OK

If it stops, the last serial line now tells us the exact MiB boundary or whether
failure occurs on CR3/CR0.PG rather than in a generic memset.

## Reference design notes

The changes were cross-checked against:

- Intel 64 and IA-32 Architectures Software Developer's Manual, Vol. 3,
  paging and IDTR sections.
- VESA BIOS Extension (VBE) Core Functions Standard 3.0, ModeInfoBlock,
  PhysBasePtr and linear-framebuffer requirements.
- OSDev Wiki: A20 Line, Detecting Memory (x86), Setting Up Paging and VESA
  Video Modes.

For a later native-hardware build, replace the remaining test-only 64 MiB RAM
contract with a real-mode BIOS INT 15h EAX=E820 memory-map handoff.  This V9
intentionally does not change that loader/kernel ABI while the paging fault is
being isolated.
