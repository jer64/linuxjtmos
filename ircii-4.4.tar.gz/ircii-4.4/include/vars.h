/*
 * vars.h: header for vars.c
 *
 * Generated from vars.h.proto automatically by the Makefile
 *
 * @(#)$Id: vars.h,v 1.8 1997/03/26 03:22:41 mrg Exp $
 */

#ifndef __vars_h_
#define __vars_h_

	int	do_boolean _((char *, int *));
	void	set_variable _((char *, char *, char *));
	int	get_int_var _((int));
	char	*get_string_var _((int));
	void	set_int_var _((int, unsigned int));
	void	set_string_var _((int, char *));
	void	init_variables _((void));
	char	*make_string_var _((char *));
	void	set_highlight_char _((char *));
	int	charset_size _((void));
	void	save_variables _((FILE *, int));
	void	set_var_value _((int, char *));

extern	char	*var_settings[];
extern	int	loading_global;

/* var_settings indexes ... also used in display.c for highlights */
#define OFF 0
#define ON 1
#define TOGGLE 2

#define	DEBUG_COMMANDS		0x0001
#define	DEBUG_EXPANSIONS	0x0002
#define DEBUG_FUNCTIONS		0x0004

/* indexes for the irc_variable array */
#define ALWAYS_SPLIT_BIGGEST_VAR 0
#define AUTO_UNMARK_AWAY_VAR 1
#define AUTO_WHOWAS_VAR  2
#define BEEP_VAR 3
#define BEEP_MAX_VAR 4
#define BEEP_ON_MSG_VAR 5
#define BEEP_WHEN_AWAY_VAR 6
#define	BOLD_VIDEO_VAR 7
#define CHANNEL_NAME_WIDTH_VAR 8
#define CLIENTINFO_VAR 9
#define CLOCK_VAR 10
#define CLOCK_24HOUR_VAR 11
#define CLOCK_ALARM_VAR 12
#define CMDCHARS_VAR 13
#define COMMAND_MODE_VAR 14
#define CONTINUED_LINE_VAR 15
#define CTCP_REPLY_BACKLOG_SECONDS_VAR 16
#define CTCP_REPLY_FLOOD_SIZE_VAR 17
#define CTCP_REPLY_IGNORE_SECONDS_VAR 18
#define DCC_BLOCK_SIZE_VAR 19
#define	DEBUG_VAR 20
#define DISPLAY_VAR 21
#define EIGHT_BIT_CHARACTERS_VAR 22
#define ENCRYPT_PROGRAM_VAR 23
#define EXEC_PROTECTION_VAR 24
#define FLOOD_AFTER_VAR 25
#define FLOOD_RATE_VAR 26
#define FLOOD_USERS_VAR 27
#define FLOOD_WARNING_VAR 28
#define FULL_STATUS_LINE_VAR 29
#define HELP_PAGER_VAR 30
#define HELP_PATH_VAR 31
#define HELP_PROMPT_VAR 32
#define HELP_WINDOW_VAR 33
#define HIDE_PRIVATE_CHANNELS_VAR 34
#define HIGHLIGHT_CHAR_VAR 35
#define HISTORY_VAR 36
#define HISTORY_FILE_VAR 37
#define HOLD_MODE_VAR 38
#define HOLD_MODE_MAX_VAR 39
#define INDENT_VAR 40
#define INPUT_ALIASES_VAR 41
#define INPUT_PROMPT_VAR 42
#define INPUT_PROTECTION_VAR 43
#define INSERT_MODE_VAR 44
#define INVERSE_VIDEO_VAR 45
#define LASTLOG_VAR 46
#define LASTLOG_LEVEL_VAR 47
#define	LOAD_PATH_VAR 48
#define LOG_VAR 49
#define LOGFILE_VAR 50
#define MAIL_VAR 51
#define MAX_RECURSIONS_VAR 52
#define	MENU_VAR 53
#define MINIMUM_SERVERS_VAR 54
#define MINIMUM_USERS_VAR 55
#define NO_CTCP_FLOOD_VAR 56
#define NOTIFY_HANDLER_VAR 57
#define NOTIFY_LEVEL_VAR 58
#define NOTIFY_ON_TERMINATION_VAR 59
#define NOVICE_VAR 60
#define REALNAME_VAR 61
#define SAME_WINDOW_ONLY_VAR 62
#define SCREEN_OPTIONS_VAR 63
#define SCROLL_VAR 64
#define SCROLL_LINES_VAR 65
#define SEND_IGNORE_MSG_VAR 66
#define SHELL_VAR 67
#define SHELL_FLAGS_VAR 68
#define SHELL_LIMIT_VAR 69
#define SHOW_AWAY_ONCE_VAR 70
#define SHOW_CHANNEL_NAMES_VAR 71
#define SHOW_END_OF_MSGS_VAR 72
#define SHOW_NUMERICS_VAR 73
#define SHOW_STATUS_ALL_VAR 74
#define SHOW_WHO_HOPCOUNT_VAR 75
#define STATUS_AWAY_VAR 76
#define STATUS_CHANNEL_VAR 77
#define	STATUS_CHANOP_VAR 78
#define STATUS_CLOCK_VAR 79
#define STATUS_FORMAT_VAR 80
#define STATUS_FORMAT1_VAR 81
#define STATUS_FORMAT2_VAR 82
#define	STATUS_GROUP_VAR 83
#define STATUS_HOLD_VAR 84
#define STATUS_HOLD_LINES_VAR 85
#define STATUS_INSERT_VAR 86
#define STATUS_MAIL_VAR 87
#define STATUS_MODE_VAR 88
#define STATUS_NOTIFY_VAR 89
#define STATUS_OPER_VAR 90
#define STATUS_OVERWRITE_VAR 91
#define STATUS_QUERY_VAR 92
#define STATUS_SERVER_VAR 93
#define	STATUS_UMODE_VAR 94
#define STATUS_USER_VAR 95
#define STATUS_USER1_VAR 96
#define STATUS_USER2_VAR 97
#define STATUS_USER3_VAR 98
#define STATUS_WINDOW_VAR 99
#define SUPPRESS_SERVER_MOTD_VAR 100
#define TAB_VAR 101
#define	TAB_MAX_VAR 102
#define TRANSLATION_VAR 103
#define UNDERLINE_VIDEO_VAR 104
#define USE_OLD_MSG_VAR 105
#define USER_INFO_VAR 106
#define	USER_WALLOPS_VAR 107
#define VERBOSE_CTCP_VAR 108
#define WARN_OF_IGNORES_VAR 109
#define XTERM_OPTIONS_VAR 110
#define NUMBER_OF_VARIABLES 111

#endif /* __vars_h_ */
