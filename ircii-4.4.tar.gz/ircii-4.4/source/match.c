int	match(char *string, char *pattern)
{
	char *string2;

	while (*string && *pattern && *pattern!='*')
	{
		if (*pattern=='?' || mkupper(*pattern)==mkupper(*string))
			pattern++, string++;
		else
			break;
	}
	if (*pattern=='*')
	{
		pattern++;
		while (*string)
		{
			if (match(string, pattern))
				return 1;
			else
				string++;
		}
	}
	if (!*string && !*pattern)
		return 1;
	return 0;
}
