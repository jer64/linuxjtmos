JTMOS / GraOS SDL2 Linux merge
==============================

Purpose
-------
This package merges the supplied chiplevel tree with the previously prepared
GUI virtual-terminal bridge.  The compatibility direction is deliberately:

    GraOS / terminal code -> stable JTMOS-like API -> Linux/POSIX/SDL2 wrapper

Native JTMOS keeps the original x86 kernel implementation.
Linux/SDL2 does not execute privileged x86 kernel instructions.

New files
---------
init/jtmos_platform.h
init/jtmos_platform.c
    Pointer-safe OS seam used by gui_terminal.c.  On native JTMOS it delegates
    to create_thread()/disable()/enable().  On Linux it delegates to pthread
    and host critical-section wrappers.

compat/linux_sdl2/jtmos_host_chiplevel.[ch]
    pthread scheduler subset, per-thread terminal selection, monotonic ticks,
    delay/yield, IRQ critical-section emulation, lock IDs, and safe I/O-port
    shadowing.  No cli/sti/inb/outb instruction is executed in userspace.

compat/linux_sdl2/jtmos_host_term.[ch]
    Host fallback for the kernel virtual-terminal service.  It keeps SCREEN,
    dynamic terminal IDs (10..255), cursor/revision state, scrolling and the
    16-bit keyboard FIFO.  Use this when the SDL2 port does not already link
    the full JTMOS term.c implementation.

compat/linux_sdl2/graos_sdl2_bridge.[ch]
    VESA-compatible 8-bit framebuffer exposed as vesa_frame_buf plus an SDL2
    presenter.  Existing GraOS code may continue drawing into the old buffer.
    JtmosSDL2GraOSHandleEvent() can be called from an existing SDL event loop;
    JtmosSDL2GraOSPumpEvents() is only a convenience for standalone use.

compat/linux_sdl2/include/
    Header overlays for cpu.h, io.h, threads.h, int.h, pit.h, delay.h and
    lock.h. Put this directory before native chiplevel include paths in Linux
    builds. Privileged operations are redirected to the host wrappers.

compat/linux_sdl2/directdraw_linux_compat.c
    Weak fallback for DirectFillRect()/DirectDrawText().  If the real SDL2
    GraOS already implements these names, its strong functions override the
    fallback automatically.

Important changes to GUI terminal bridge
----------------------------------------
1. GuiTerminalStartShell() no longer passes stack/function pointers directly
   through DWORD on Linux.  This avoids x86_64 pointer truncation.
2. Rendering gets framebuffer width/height via VesaGetWidth()/Height(), not
   hard-coded 640x480 clipping.
3. JTMOS_HOST_LINUX_SDL2 builds use host terminal/chiplevel headers without
   pulling in x86 GDT/TSS/IRQ kernel headers.
4. Native build behavior remains behind the existing JTMOS APIs.

Linux build rule that matters
-----------------------------
Do NOT add init/ as a normal -I search directory for host code.  JTMOS contains
its own stdio.h, stddef.h and stdlib.h.  A command such as:

    cc -Iinit ...

can accidentally replace glibc's <stddef.h>/<stdio.h> and cause type conflicts.
Use:

    -iquote init -Icompat/linux_sdl2/include

for JTMOS quote-includes and host overlays instead.  Makefile.host already does
this.  init/cpu.h and init/macrodef.h are also conditionalized so their local
include precedence is safe when JTMOS_HOST_LINUX_SDL2 is defined.

SDL2 build
----------
Install your distribution's SDL2 development package, then:

    cd compat/linux_sdl2
    make -f Makefile.host

The SDL2 source auto-detects <SDL2/SDL.h>.  If SDL2 headers are absent it still
compiles as a framebuffer-only compatibility layer, but SDL presentation is
not enabled.

Integrating with an existing SDL2 GraOS main loop
-------------------------------------------------
Startup order:

    JtmosHostInit();
    VirtualTerminalInit();
    JtmosSDL2GraOSInit("JTMOS GraOS", 640, 480, 2);
    GuiTerminalInit();

Create a terminal window:

    win = GuiTerminalCreate(16, 24, 78, 25, "JTMOS Terminal");

or, when run_shell is linked:

    win = GuiTerminalCreateShell(16, 24, 78, 25, "JTMOS Shell");

In an existing SDL_Event loop pass each event to:

    JtmosSDL2GraOSHandleEvent(&event);

Then once per GUI frame:

    GuiTerminalTick();
    JtmosSDL2GraOSPresent();

If the existing GraOS already owns the event loop, prefer HandleEvent().
Do not also call PumpEvents(), because two consumers should not drain the same
SDL event queue.

Using an existing GraOS framebuffer
-----------------------------------
If the SDL2 port already allocates an 8-bit software framebuffer, attach it:

    JtmosSDL2GraOSAttachFramebuffer(buffer, width, height, pitch);

Then vesa_frame_buf points at that same storage and old VESA/DirectDraw-facing
code can continue to use it.

Native vs host source selection
-------------------------------
Native JTMOS:
    compile original chiplevel/*.c + assembly, term/term.c and init/vesa.c.

Linux/SDL2 fallback mode:
    do NOT compile the hardware implementations of threads.c, int.c, io.c,
    pit.c, delay.c, lock.c or init/vesa.c alongside the host wrappers, because
    they intentionally export overlapping JTMOS API symbols.  Likewise choose
    either term/term.c or jtmos_host_term.c, not both.

Tested here
-----------
- Linux wrapper sources compile with -Wall -Wextra -Werror.
- pthread virtual thread receives its own terminal ID.
- emulated port I/O round-trip works without privileged CPU instructions.
- virtual terminal ID 10 was created and rendered through gui_terminal.c.
- GUI key 'A' travelled back into terminal ID 10's 16-bit FIFO.
- framebuffer render produced non-zero pixels through the DirectDraw fallback.

EDIT APPLICATION PORT (2026-08-18)
----------------------------------
The default sdl2_graos_loop_example.c now uses the JTMOS edit application as
its text source. See EDIT_GRAOS_PORT_README.txt.

Unlike the virtual-terminal GUI, the edit frontend renders the application's
ed.buf[] lines directly. Terminal windows remain available for shell use.
