JTMOS edit -> SDL2 GraOS port
=============================

Goal
----
The GraOS GUI now renders text from the JTMOS edit application's document
buffer, not from a virtual terminal. The canonical data path is:

    SDL2 events
       -> JtmosSDL2GraOSHandleEvent()
       -> GuiEditFocusedKey()
       -> EditorHandleKey()
       -> ed.buf[]
       -> GuiEditRender()
       -> vesa_frame_buf
       -> JtmosSDL2GraOSPresent()

This keeps the editor model usable on native JTMOS while Linux/SDL2 is only a
frontend/backend compatibility layer.

New/ported source
-----------------
apps/edit.h
    Portable EDITOR structure and editor key API. Lines are still limited to
    the historic 80 columns, but storage is now 81 bytes so byte 80 is the NUL
    terminator rather than an out-of-bounds write.

apps/edit_core.c
    Console-independent editor engine: load/save, cursor/view movement,
    insert/overwrite, Backspace, Delete, Enter line split, line merge, PgUp,
    PgDn, Home/End, F1 help state, Ctrl-O/F2 save and Ctrl-X/F10 exit.

apps/editEditor.c
    Small native-JTMOS console frontend retained for source compatibility.

compat/linux_sdl2/graos_edit_gui.c/.h
    GraOS view/controller. Rendering reads EditorGetLine()/ed.buf[] directly.
    It never reads SCREEN.buf and does not need a virtual terminal.

compat/linux_sdl2/sdl2_graos_edit_example.c
    Standalone SDL2 editor program. Give a filename as argv[1].

compat/linux_sdl2/sdl2_graos_loop_example.c
    The general GraOS loop example now launches edit instead of a terminal.
    The old terminal example is preserved as sdl2_graos_terminal_example.c.

Build on Linux
--------------
    sudo apt install build-essential pkg-config libsdl2-dev
    cd compat/linux_sdl2
    make -f Makefile.host check
    make -f Makefile.host graos_edit_demo
    ./graos_edit_demo README.txt

Controls
--------
    Arrow keys       move
    Home / End       start/end of line
    Page Up/Down     move by visible page
    Insert           toggle insert/overwrite
    Delete           delete at cursor / join next line
    Backspace        delete before cursor / join previous line
    Enter            split line
    F1               help overlay
    Ctrl-O or F2     save
    Ctrl-X or F10    exit

If the document is modified, the first Ctrl-X/F10 arms discard confirmation;
a second Ctrl-X/F10 exits without saving. Ctrl-O/F2 saves and clears it.

Compatibility notes
-------------------
* MAX_LINES remains 5000.
* Visible line length remains 80 bytes/characters, like the original editor.
* The host SDL_TEXTINPUT bridge is byte-oriented. ASCII is exact; UTF-8 bytes
  can enter the buffer but the current 5x7 fallback font is not a Unicode font.
* The terminal GUI is still present in the tree for shells. edit simply no
  longer uses the terminal as its rendering data source.
