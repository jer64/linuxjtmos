# JTMOS apps -> Linux SDL2/GraOS port

This tree keeps the native JTMOS application source path and adds a Linux backend.
Linux-specific source inclusion is guarded with `#ifndef JTMOS`; the original JTMOS
`.mak` files remain in `apps/`.

## Linux build

```sh
cd compat/apps_sdl2
make -j2
make check
```

No SDL2 development headers are required by this port. `jtmos_sdl_runtime.c` loads
`libSDL2-2.0.so.0` with `dlopen()`. A normal distro SDL2 runtime package is enough.
If SDL2 development files are present, they are not required or preferred.

Binaries are written to `build/bin/`. The current build produces 58 application binaries, including the `listen` variant of `talk.c`.

## Compatibility layers

* **conio / text applications:** 80x60 text surface rendered into a 640x480 SDL2
  indexed framebuffer. `gotoxy`, `textcolor`, `textbackground`, `clrscr`, `getch`,
  `getch1`, JTMOS extended keys and the traditional colour numbers are preserved.
* **VGA applications:** mode 13h style 320x200x8 framebuffer, 256-entry palette,
  `setmode`/`setvmode`, `drawframe`, `setpalette`, `setpalettemap`, `waitretrace`.
* **Audio:** JTMOS `InitAudio`, `SendAudio`, `GetAudioPosition` map to SDL2 queued
  unsigned 8-bit mono audio.
* **GraOS applications:** `connectGraos`, `createWindow`, `addFrameBuffer`,
  `refreshWindow`, `createButton` and GraOS `MSG/GUICMD` events are mapped to SDL2.
* **Postman / MessageBox:** the previous Linux Unix-domain-socket Postman backend is
  included and linked, so `sendMessage`/`receiveMessage` remain portable.
* **filefind:** `FFBLK`, `findfirst`, `findnext` map to POSIX directories + `fnmatch`.
* **network:** `OpenSocket`/`CloseSocket` map to POSIX TCP sockets.
* **direct disk:** named devices map to image files. Use `JTMOS_FLOPPY_IMAGE`,
  `JTMOS_RAM_IMAGE`, and `JTMOS_HDA_IMAGE` to choose images.

## Native JTMOS support

Do **not** define `JTMOS` for the Linux build. For the native build, define `JTMOS`
and use the original JTMOS SDK/include path and original `apps/*.mak` files. The
compatibility includes inserted into the application sources are inside
`#ifndef JTMOS` blocks, so they disappear from a native build.

## Hardware-specific IDE utility

`ide.c` is buildable on Linux so the full source tree stays portable, but direct
BIOS/ATA port I/O is deliberately stubbed on Linux. Linux user processes must not
execute the old `in/out` hardware instructions. Native JTMOS keeps its hardware
path. For real Linux disk inspection, a future backend should use `/sys`, `ioctl`,
or a deliberately opened disk-image/device abstraction instead.

## Compatibility corrections made to legacy sources

A few source-level corrections are shared by both targets because they fix invalid
or compiler-dependent C: the missing `char` in `aud.c`, missing return values in
several int functions, GNU inline semantics in `nzip.c`, the duplicate FAT boot
sector field name in `msdos.h`, Linux-vs-Borland detection in `snake.c`, and explicit
Linux `fcntl.h` use in `sqa.c`.
