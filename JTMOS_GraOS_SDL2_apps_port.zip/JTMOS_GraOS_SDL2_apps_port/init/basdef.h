#ifndef __INCLUDED_BASDEF_H__
#define __INCLUDED_BASDEF_H__

/*** Basic Definations ***/
#ifndef NULL
#define NULL 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef DWORD
//#define DWORD unsigned long int
typedef unsigned long int DWORD;
#endif

#ifndef WORD
//#define WORD unsigned short int
typedef unsigned short int WORD;
#endif

#ifndef BYTE
//#define BYTE unsigned char
typedef unsigned char BYTE;
#endif

//
#ifndef BOOL
//#define BOOL BYTE
typedef unsigned char BOOL;
#endif

typedef signed long long int   int64_t;
typedef unsigned long long int uint64_t;

typedef unsigned short int     uint16_t;

typedef unsigned int uint32_t;
typedef signed int   int32_t;

//typedef signed long int        int32_t;
//typedef unsigned long int      uint32_t;

typedef unsigned char          uint8_t;
typedef signed char            int8_t;
typedef unsigned int	uint32_t;
typedef unsigned int uintptr_t;
typedef signed int intptr_t;
#define bool int

#endif
