/*
 * gui_terminal.c - JTMOS GUI bridge for kernel virtual terminals.
 *
 * This module does not implement a second terminal emulator.  It displays the
 * existing kernel SCREEN buffer and forwards GUI keyboard events to the
 * existing terminal FIFO with OutTermKey().  Therefore a shell/application
 * attached with SetThreadTerminal(pid, terminal_id) sees exactly the same
 * terminal from both kernel and GUI sides.
 */
#ifdef JTMOS_HOST_LINUX_SDL2
#include "gui_terminal.h"
#include "vesa.h"
#include "jtmos_platform.h"
#include "../compat/linux_sdl2/jtmos_host_chiplevel.h"
#include <stdio.h>
#include <string.h>
#ifndef THREAD_PRIORITY_NORMAL
#define THREAD_PRIORITY_NORMAL 1
#endif
#if defined(__GNUC__)
extern void run_shell(void) __attribute__((weak));
#else
extern void run_shell(void);
#endif
#else
#include "kernel32.h"
#include "gui_terminal.h"
#include "vesa.h"
#include "string.h"
#include "sh.h"
#include "jtmos_platform.h"
#endif

#ifdef GRAOS
#include "directdraw.h"
#endif

GUI_TERMINAL_WINDOW gui_terminal_windows[GUI_TERMINAL_MAX_WINDOWS];
static int gui_terminal_focus = -1;

static int GuiTerminalValidWindow(int window_id)
{
    if(window_id<0 || window_id>=GUI_TERMINAL_MAX_WINDOWS)
        return FALSE;
    return gui_terminal_windows[window_id].used ? TRUE : FALSE;
}

static int GuiTerminalAllocWindow(void)
{
    int i;
    for(i=0; i<GUI_TERMINAL_MAX_WINDOWS; i++)
        if(!gui_terminal_windows[i].used)
            return i;
    return -1;
}

static void GuiTerminalCopyTitle(GUI_TERMINAL_WINDOW *w,
                                  const char *title,
                                  int terminal_id)
{
    int i;

    if(title!=NULL && title[0])
    {
        for(i=0; i<GUI_TERMINAL_TITLE_LEN-1 && title[i]; i++)
            w->title[i] = title[i];
        w->title[i] = 0;
    }
    else
    {
        sprintf(w->title, "JTMOS Terminal %d", terminal_id);
    }
}

static void GuiTerminalClampSize(GUI_TERMINAL_WINDOW *w)
{
    SCREEN *s;

    if(!IsTerminalValid(w->terminal_id))
        return;
    s = &screens[w->terminal_id];

    if(w->cols<1) w->cols=1;
    if(w->rows<1) w->rows=1;
    if(w->cols>s->width)  w->cols=s->width;
    if(w->rows>s->height) w->rows=s->height;
}

void GuiTerminalInit(void)
{
    memset(gui_terminal_windows, 0, sizeof(gui_terminal_windows));
    gui_terminal_focus = -1;
}

int GuiTerminalAttach(int terminal_id, int x, int y,
                      int cols, int rows, const char *title)
{
    int window_id;
    GUI_TERMINAL_WINDOW *w;

    if(!IsTerminalValid(terminal_id))
        return -1;

    window_id = GuiTerminalAllocWindow();
    if(window_id<0)
        return -1;

    w = &gui_terminal_windows[window_id];
    memset(w, 0, sizeof(*w));
    w->used = TRUE;
    w->terminal_id = terminal_id;
    w->x = x<0 ? 0 : x;
    w->y = y<0 ? 0 : y;
    w->cols = cols;
    w->rows = rows;
    w->last_revision = (DWORD)-1;
    GuiTerminalCopyTitle(w, title, terminal_id);
    GuiTerminalClampSize(w);

    if(gui_terminal_focus<0)
        GuiTerminalSetFocus(window_id);

    return window_id;
}

int GuiTerminalCreate(int x, int y, int cols, int rows, const char *title)
{
    int terminal_id;
    int window_id;

    terminal_id = CreateTerminal();
    if(terminal_id<0)
        return -1;

    window_id = GuiTerminalAttach(terminal_id, x, y, cols, rows, title);
    if(window_id<0)
    {
        FreeScreen(&screens[terminal_id]);
        return -1;
    }

    return window_id;
}

/* Start the normal JTMOS kernel shell on an existing GUI terminal. */
int GuiTerminalStartShell(int window_id)
{
    int pid;
    int terminal_id;

    if(!GuiTerminalValidWindow(window_id))
        return -1;
    terminal_id = gui_terminal_windows[window_id].terminal_id;
    if(!IsTerminalValid(terminal_id))
        return -1;

#ifdef JTMOS_HOST_LINUX_SDL2
#if defined(__GNUC__)
    if(!run_shell)
        return -1;
#endif
#endif

    /*
     * Do not pass code/stack pointers through DWORD here.  Native JTMOS still
     * uses its original create_thread ABI inside jtmos_platform.c, while the
     * x86_64 Linux/SDL2 build uses a pointer-safe pthread wrapper.
     */
    pid = JtmosPlatformCreateThread((JTMOS_PLATFORM_THREAD_ENTRY)run_shell,
                                    1024UL*32UL,
                                    "gui-shell",
                                    terminal_id,
                                    THREAD_PRIORITY_NORMAL);
    if(pid<0)
        return -1;

    SetTerminalOwner(terminal_id, pid);
    return pid;
}

/* Convenience call used by a Terminal icon/menu item in GraOS. */
int GuiTerminalCreateShell(int x, int y, int cols, int rows, const char *title)
{
    int window_id;

    window_id = GuiTerminalCreate(x, y, cols, rows, title);
    if(window_id<0)
        return -1;
    if(GuiTerminalStartShell(window_id)<0)
    {
        GuiTerminalRelease(window_id);
        return -1;
    }
    return window_id;
}

void GuiTerminalDestroy(int window_id)
{
    int was_focused;

    if(!GuiTerminalValidWindow(window_id))
        return;

    was_focused = gui_terminal_windows[window_id].focused;
    memset(&gui_terminal_windows[window_id], 0,
           sizeof(gui_terminal_windows[window_id]));

    if(was_focused)
    {
        gui_terminal_focus = -1;
        GuiTerminalSetFocus(-1);
    }
}

/*
 * Explicitly release the underlying dynamically-created kernel terminal too.
 * The caller must ensure no running thread still has this terminal selected.
 */
int GuiTerminalRelease(int window_id)
{
    int terminal_id;

    if(!GuiTerminalValidWindow(window_id))
        return -1;
    terminal_id = gui_terminal_windows[window_id].terminal_id;

    if(terminal_id<10)
        return -1;

    GuiTerminalDestroy(window_id);
    FreeScreen(&screens[terminal_id]);
    return 0;
}

int GuiTerminalGetTerminal(int window_id)
{
    if(!GuiTerminalValidWindow(window_id))
        return -1;
    return gui_terminal_windows[window_id].terminal_id;
}

int GuiTerminalBindThread(int window_id, int pid)
{
    int terminal_id;

    if(!GuiTerminalValidWindow(window_id) || pid<0)
        return -1;

    terminal_id = gui_terminal_windows[window_id].terminal_id;
    if(SetTerminalOwner(terminal_id, pid))
        return -1;

    SetThreadTerminal(pid, terminal_id);
    return 0;
}

int GuiTerminalSetFocus(int window_id)
{
    int i;

    if(window_id>=0 && !GuiTerminalValidWindow(window_id))
        return -1;

    for(i=0; i<GUI_TERMINAL_MAX_WINDOWS; i++)
    {
        if(gui_terminal_windows[i].used)
        {
            gui_terminal_windows[i].focused = FALSE;
            gui_terminal_windows[i].last_revision = (DWORD)-1;
        }
    }

    gui_terminal_focus = window_id;
    if(window_id>=0)
    {
        gui_terminal_windows[window_id].focused = TRUE;
        gui_terminal_windows[window_id].last_revision = (DWORD)-1;
    }
    return 0;
}

int GuiTerminalGetFocus(void)
{
    return gui_terminal_focus;
}

int GuiTerminalKey(int window_id, int key)
{
    int terminal_id;

    if(!GuiTerminalValidWindow(window_id))
        return -1;
    terminal_id = gui_terminal_windows[window_id].terminal_id;
    if(!IsTerminalValid(terminal_id))
        return -1;

    OutTermKey(terminal_id, key);
    return 0;
}

int GuiTerminalFocusedKey(int key)
{
    if(gui_terminal_focus<0)
        return -1;
    return GuiTerminalKey(gui_terminal_focus, key);
}

void GuiTerminalMove(int window_id, int x, int y)
{
    GUI_TERMINAL_WINDOW *w;
    if(!GuiTerminalValidWindow(window_id))
        return;
    w = &gui_terminal_windows[window_id];
    w->x = x<0 ? 0 : x;
    w->y = y<0 ? 0 : y;
    w->last_revision = (DWORD)-1;
}

void GuiTerminalResize(int window_id, int cols, int rows)
{
    GUI_TERMINAL_WINDOW *w;
    if(!GuiTerminalValidWindow(window_id))
        return;
    w = &gui_terminal_windows[window_id];
    w->cols = cols;
    w->rows = rows;
    GuiTerminalClampSize(w);
    w->last_revision = (DWORD)-1;
}

void GuiTerminalInvalidate(int window_id)
{
    if(!GuiTerminalValidWindow(window_id))
        return;
    gui_terminal_windows[window_id].last_revision = (DWORD)-1;
}

#ifdef GRAOS
static void GuiTerminalFillRect(BYTE *fb, int fbw, int fbh,
                                int x, int y, int w, int h, BYTE color)
{
    int yy;
    int x1=x, y1=y, x2=x+w, y2=y+h;

    if(fb==NULL || fbw<=0 || fbh<=0 || w<=0 || h<=0)
        return;
    if(x1<0) x1=0;
    if(y1<0) y1=0;
    if(x2>fbw) x2=fbw;
    if(y2>fbh) y2=fbh;
    if(x1>=x2 || y1>=y2)
        return;

    for(yy=y1; yy<y2; yy++)
        memset(fb + yy*fbw + x1, color, x2-x1);
}
#endif

void GuiTerminalRender(int window_id)
{
    GUI_TERMINAL_WINDOW *w;
    SCREEN *s;

    if(!GuiTerminalValidWindow(window_id))
        return;
    w = &gui_terminal_windows[window_id];
    if(!IsTerminalValid(w->terminal_id))
        return;
    s = &screens[w->terminal_id];

    if(w->last_revision==s->revision)
        return;

#ifdef GRAOS
    if(vesa_enabled && vesa_frame_buf!=NULL)
    {
        char line[81];
        char draw_title[GUI_TERMINAL_TITLE_LEN];
        char cursor[2];
        int row,col,offset;
        int px,py;
        int draw_cols,draw_rows;
        int title_chars;
        int body_width,body_height;
        int fbw,fbh;

        GuiTerminalClampSize(w);
        fbw = VesaGetWidth();
        fbh = VesaGetHeight();
        if(fbw<=0 || fbh<=0)
            return;

        draw_cols = w->cols;
        draw_rows = w->rows;
        if(w->x>=fbw || w->y>=fbh)
            return;
        if(w->x + draw_cols*8 > fbw)
            draw_cols = (fbw-w->x)/8;
        if(w->y + 12 + draw_rows*8 > fbh)
            draw_rows = (fbh-w->y-12)/8;
        if(draw_cols<1 || draw_rows<1)
            return;

        body_width = draw_cols*8;
        body_height = draw_rows*8;

        // Simple framebuffer window. The surrounding GraOS window manager can
        // replace this frame while keeping the terminal bridge unchanged.
        GuiTerminalFillRect(vesa_frame_buf, fbw,fbh,
                            w->x, w->y, body_width, 12, BLUE);
        GuiTerminalFillRect(vesa_frame_buf, fbw,fbh,
                            w->x, w->y+12, body_width, body_height, BLACK);

        title_chars = draw_cols;
        if(title_chars>GUI_TERMINAL_TITLE_LEN-1)
            title_chars=GUI_TERMINAL_TITLE_LEN-1;
        for(col=0; col<title_chars && w->title[col]; col++)
            draw_title[col]=w->title[col];
        draw_title[col]=0;
        DirectDrawText(vesa_frame_buf,fbw,fbh,draw_title,w->x,w->y+2);

        for(row=0; row<draw_rows; row++)
        {
            for(col=0; col<draw_cols; col++)
            {
                offset = ((row*s->width+col)<<1);
                line[col] = s->buf[offset];
                if(line[col]==0)
                    line[col] = ' ';
            }
            line[draw_cols] = 0;
            px = w->x;
            py = w->y+12+(row<<3);
            DirectDrawText(vesa_frame_buf,fbw,fbh,line,px,py);
        }

        // GUI cursor. It is intentionally drawn separately and never modifies
        // the terminal's character buffer.
        if(w->focused && s->curx>=0 && s->curx<draw_cols &&
           s->cury>=0 && s->cury<draw_rows)
        {
            cursor[0] = '_';
            cursor[1] = 0;
            DirectDrawText(vesa_frame_buf,fbw,fbh,cursor,
                           w->x+(s->curx<<3),
                           w->y+12+(s->cury<<3));
        }

        // Mark clean only after a real framebuffer draw. If VESA is not ready
        // yet, the first later GuiTerminalTick() must still render the window.
        w->last_revision = s->revision;
    }
#endif
}

void GuiTerminalRenderAll(void)
{
    int i;
    for(i=0; i<GUI_TERMINAL_MAX_WINDOWS; i++)
        if(gui_terminal_windows[i].used)
            GuiTerminalRender(i);
}

/* Call this from the GraOS/GUI main loop. */
void GuiTerminalTick(void)
{
    GuiTerminalRenderAll();
}
