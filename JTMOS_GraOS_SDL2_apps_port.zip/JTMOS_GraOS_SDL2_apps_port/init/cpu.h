/*** CPU modes ***/
#ifndef __INCLUDED_CPU_H__
#define __INCLUDED_CPU_H__

#ifdef JTMOS_HOST_LINUX_SDL2
#include "../compat/linux_sdl2/jtmos_host_chiplevel.h"
#define disable() JtmosHostDisableInterrupts()
#define enable()  JtmosHostEnableInterrupts()
#define nop()     idle_moment()
#else
#define disable() asm("cli")
#define enable() asm("sti")
#define nop() asm("nop")
#endif

#endif
