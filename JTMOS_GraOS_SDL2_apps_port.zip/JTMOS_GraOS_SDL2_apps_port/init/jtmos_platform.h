#ifndef __INCLUDED_JTMOS_PLATFORM_H__
#define __INCLUDED_JTMOS_PLATFORM_H__

/*
 * Small source-compatibility seam between native JTMOS and Linux/SDL2 GraOS.
 * Keep kernel-only pointer ABI out of GUI code.
 */

typedef void (*JTMOS_PLATFORM_THREAD_ENTRY)(void);

int JtmosPlatformCreateThread(JTMOS_PLATFORM_THREAD_ENTRY entry,
                              unsigned long stack_size,
                              const char *name,
                              int terminal_id,
                              int priority);

void JtmosPlatformCriticalEnter(void);
void JtmosPlatformCriticalLeave(void);
unsigned long JtmosPlatformTicks(void);
void JtmosPlatformSleepMs(unsigned long ms);

#endif
