#ifndef __INCLUDED_GUI_TERMINAL_H__
#define __INCLUDED_GUI_TERMINAL_H__

#ifdef JTMOS_HOST_LINUX_SDL2
#include "../compat/linux_sdl2/jtmos_host_term.h"
#else
#include "basdef.h"
#include "term.h"
#endif

#define GUI_TERMINAL_MAX_WINDOWS 16
#define GUI_TERMINAL_TITLE_LEN   48

typedef struct
{
    int used;
    int terminal_id;
    int x;
    int y;
    int cols;
    int rows;
    int focused;
    DWORD last_revision;
    char title[GUI_TERMINAL_TITLE_LEN];
} GUI_TERMINAL_WINDOW;

extern GUI_TERMINAL_WINDOW gui_terminal_windows[GUI_TERMINAL_MAX_WINDOWS];

void GuiTerminalInit(void);
int  GuiTerminalCreate(int x, int y, int cols, int rows, const char *title);
int  GuiTerminalCreateShell(int x, int y, int cols, int rows, const char *title);
int  GuiTerminalStartShell(int window_id);
int  GuiTerminalAttach(int terminal_id, int x, int y, int cols, int rows, const char *title);
void GuiTerminalDestroy(int window_id);
int  GuiTerminalRelease(int window_id);
int  GuiTerminalGetTerminal(int window_id);
int  GuiTerminalBindThread(int window_id, int pid);
int  GuiTerminalSetFocus(int window_id);
int  GuiTerminalGetFocus(void);
int  GuiTerminalKey(int window_id, int key);
int  GuiTerminalFocusedKey(int key);
void GuiTerminalMove(int window_id, int x, int y);
void GuiTerminalResize(int window_id, int cols, int rows);
void GuiTerminalInvalidate(int window_id);
void GuiTerminalRender(int window_id);
void GuiTerminalRenderAll(void);
void GuiTerminalTick(void);

#endif
