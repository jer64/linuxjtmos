#include "jtmos_platform.h"

#ifdef JTMOS_HOST_LINUX_SDL2

#include "../compat/linux_sdl2/jtmos_host_chiplevel.h"

int JtmosPlatformCreateThread(JTMOS_PLATFORM_THREAD_ENTRY entry,
                              unsigned long stack_size,
                              const char *name,
                              int terminal_id,
                              int priority)
{
    int pid;

    pid = JtmosHostCreateThread(entry, (size_t)stack_size);
    if(pid<0)
        return -1;

    SetThreadPriority((uint32_t)pid, (unsigned char)priority);
    SetThreadTerminal(pid, terminal_id);
    if(name)
        IdentifyThread((uint32_t)pid, name);
    return pid;
}

void JtmosPlatformCriticalEnter(void) { JtmosHostDisableInterrupts(); }
void JtmosPlatformCriticalLeave(void) { JtmosHostEnableInterrupts(); }
unsigned long JtmosPlatformTicks(void) { return (unsigned long)GetTickCount(); }
void JtmosPlatformSleepMs(unsigned long ms) { delay((uint32_t)ms); }

#else

#include "kernel32.h"

int JtmosPlatformCreateThread(JTMOS_PLATFORM_THREAD_ENTRY entry,
                              unsigned long stack_size,
                              const char *name,
                              int terminal_id,
                              int priority)
{
    THREAD thread;
    int pid;

    memset(&thread, 0, sizeof(thread));
    ThreadCreateStack(&thread, (int)stack_size);
    if(thread.stack==NULL)
        return -1;

    disable();
    pid = (int)create_thread((DWORD)thread.stack,
                             (DWORD)thread.l_stack,
                             (DWORD)entry);
    if(pid<0) {
        enable();
        ThreadDestroyStack(&thread);
        return -1;
    }

    SetThreadPriority(pid, (BYTE)priority);
    SetThreadTerminal(pid, terminal_id);
    if(name)
        IdentifyThread(pid, name);
    enable();
    return pid;
}

void JtmosPlatformCriticalEnter(void) { disable(); }
void JtmosPlatformCriticalLeave(void) { enable(); }
unsigned long JtmosPlatformTicks(void) { return (unsigned long)GetTickCount(); }
void JtmosPlatformSleepMs(unsigned long ms) { delay((DWORD)ms); }

#endif
