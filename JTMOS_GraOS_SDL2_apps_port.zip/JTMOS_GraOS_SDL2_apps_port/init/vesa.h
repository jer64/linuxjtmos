#ifndef __INCLUDED_VESA_H__
#define __INCLUDED_VESA_H__

//
extern BYTE *vesa_frame_buf;
int VesaSetup(void);
extern int vesa_enabled;
extern unsigned char *vb,*vesainfo;
extern BYTE egapal[];

/* Framebuffer geometry abstraction used by native VESA and SDL2 host. */
int VesaGetWidth(void);
int VesaGetHeight(void);
int VesaGetPitch(void);

#endif

