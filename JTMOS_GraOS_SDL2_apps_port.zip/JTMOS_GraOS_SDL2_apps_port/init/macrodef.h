/*** Macro like functions ***/
#ifndef __INCLUDED_MACRODEF_H__
#define __INCLUDED_MACRODEF_H__

#ifdef JTMOS_HOST_LINUX_SDL2
#include "../compat/linux_sdl2/jtmos_host_chiplevel.h"
#define cli() JtmosHostDisableInterrupts()
#define sti() JtmosHostEnableInterrupts()
#define nop() idle_moment()
#else
#define cli() asm("cli")
#define sti() asm("sti")
#define nop() asm("nop")
#endif

#endif
