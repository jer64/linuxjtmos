//
#include "basdef.h"
#include "kernel32.h"
