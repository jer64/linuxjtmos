// clear.c - Clear the terminal screen
#include <stdio.h>
#include <jtmos/filefind.h>
#ifndef JTMOS
#include <jtmos/app_port.h>
#endif

int main(int argc, char **argv)
{
	clrscr();
	return 0;
}
