// mkdir.c
#include <stdio.h>
#ifndef JTMOS
#include <jtmos/app_port.h>
#endif

//
int main(int argc, char **argv)
{
	if(argc<2)
	{
		printf("%s: too few arguments\n", argv[0]);
		printf("Try `%s --help' for more information.\n", argv[0]);
		return 0;
	}

	mkdir(argv[1]);
	return 0;
}

//

