//
#include <stdio.h>
#ifndef JTMOS
#include <jtmos/app_port.h>
#endif

//
int main(int argc,char **argv)
{
	//
	puts("Please press any key to continue ...\n");
	getch();
	puts("Thank you.\n");

	//
	return 0;
}
