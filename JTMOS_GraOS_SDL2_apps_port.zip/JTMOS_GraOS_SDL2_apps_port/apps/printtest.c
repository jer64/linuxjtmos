// This sophisticated application was
// brought to you by Jari Tuominen!!
//
#include <stdio.h>
#ifndef JTMOS
#include <jtmos/app_port.h>
#endif

//
void testi(void)
{
 //

 //
}

//
int main(int argc,char **argv)
{
 //
 long i;

 //
 for(; ;)
 {
	testi();
	puts("Hello world!");
	Sleep(100);
 }

 //
 return 0;
}

//

