#!/bin/sh
set -eu
cd "$(dirname "$0")/compat/apps_sdl2"
make -j2
printf '\nBuilt applications are in ../../build/bin/\n'
printf 'Example: ../../build/bin/snake\n'
printf 'Example: ../../build/bin/edit filename.txt\n'
