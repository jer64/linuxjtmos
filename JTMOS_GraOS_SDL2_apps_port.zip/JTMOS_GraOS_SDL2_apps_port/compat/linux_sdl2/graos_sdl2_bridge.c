#include "graos_sdl2_bridge.h"

#include <stdlib.h>
#include <string.h>

#if defined(__has_include)
# if __has_include(<SDL2/SDL.h>)
#  include <SDL2/SDL.h>
#  define JTMOS_HAVE_SDL2 1
# elif __has_include(<SDL.h>)
#  include <SDL.h>
#  define JTMOS_HAVE_SDL2 1
# else
#  define JTMOS_HAVE_SDL2 0
# endif
#else
# define JTMOS_HAVE_SDL2 0
#endif

/* Provided by the terminal GUI bridge when it is linked. */
#if defined(__GNUC__)
extern int GuiTerminalFocusedKey(int key) __attribute__((weak));
#else
extern int GuiTerminalFocusedKey(int key);
#endif

/* VESA-compatible globals expected by old GraOS/JTMOS drawing code. */
unsigned char *vesa_frame_buf = NULL;
int vesa_enabled = 0;
unsigned char *vb = NULL;
unsigned char *vesainfo = NULL;
unsigned char egapal[] = {
    0,0,0,       128,0,0,     0,128,0,     128,128,0,
    0,0,128,     128,0,128,   0,128,128,   192,192,192,
    128,128,128, 255,0,0,     0,255,0,     255,255,0,
    0,0,255,     255,0,255,   0,255,255,   255,255,255
};

static int fb_width = 640;
static int fb_height = 480;
static int fb_pitch = 640;
static int owns_fb = 0;
static JTMOS_SDL2_KEY_SINK key_sink = NULL;

#if JTMOS_HAVE_SDL2
static SDL_Window *host_window;
static SDL_Renderer *host_renderer;
static SDL_Texture *host_texture;
static uint32_t *argb_pixels;
static int sdl_started_here;
#endif

int VesaGetWidth(void) { return fb_width; }
int VesaGetHeight(void) { return fb_height; }
int VesaGetPitch(void) { return fb_pitch; }

int JtmosSDL2GraOSAttachFramebuffer(unsigned char *fb, int width, int height, int pitch)
{
    if(!fb || width<=0 || height<=0 || pitch<width)
        return -1;
    if(owns_fb) {
        free(vesa_frame_buf);
        owns_fb = 0;
    }
    vesa_frame_buf = fb;
    vb = fb;
    fb_width = width;
    fb_height = height;
    fb_pitch = pitch;
    vesa_enabled = 1;
    return 0;
}

/* Host replacement for the bootloader-based native VesaSetup(). */
int VesaSetup(void)
{
    if(vesa_frame_buf) {
        vesa_enabled = 1;
        return 1;
    }
    vesa_frame_buf = (unsigned char *)calloc((size_t)fb_height, (size_t)fb_pitch);
    if(!vesa_frame_buf) {
        vesa_enabled = 0;
        return 0;
    }
    vb = vesa_frame_buf;
    owns_fb = 1;
    vesa_enabled = 1;
    return 1;
}

void JtmosSDL2GraOSSetKeySink(JTMOS_SDL2_KEY_SINK sink)
{
    key_sink = sink;
}

#if JTMOS_HAVE_SDL2
static void emit_key(int key)
{
    if(key_sink) {
        key_sink(key);
        return;
    }
#if defined(__GNUC__)
    if(GuiTerminalFocusedKey)
        GuiTerminalFocusedKey(key);
#else
    GuiTerminalFocusedKey(key);
#endif
}

static int translate_special(SDL_Keycode sym)
{
    switch(sym) {
        case SDLK_BACKSPACE: return 8;
        case SDLK_TAB:       return 9;
        case SDLK_RETURN:
        case SDLK_KP_ENTER:  return 13;
        case SDLK_ESCAPE:    return 27;
        case SDLK_UP:        return JTMOS_KEY_UP;
        case SDLK_DOWN:      return JTMOS_KEY_DOWN;
        case SDLK_LEFT:      return JTMOS_KEY_LEFT;
        case SDLK_RIGHT:     return JTMOS_KEY_RIGHT;
        case SDLK_HOME:      return JTMOS_KEY_HOME;
        case SDLK_END:       return JTMOS_KEY_END;
        case SDLK_PAGEUP:    return JTMOS_KEY_PAGEUP;
        case SDLK_PAGEDOWN:  return JTMOS_KEY_PAGEDOWN;
        case SDLK_INSERT:    return JTMOS_KEY_INSERT;
        case SDLK_DELETE:    return JTMOS_KEY_DELETE;
        case SDLK_F1:        return JTMOS_KEY_EXT(0x3b);
        case SDLK_F2:        return JTMOS_KEY_EXT(0x3c);
        case SDLK_F3:        return JTMOS_KEY_EXT(0x3d);
        case SDLK_F4:        return JTMOS_KEY_EXT(0x3e);
        case SDLK_F5:        return JTMOS_KEY_EXT(0x3f);
        case SDLK_F6:        return JTMOS_KEY_EXT(0x40);
        case SDLK_F7:        return JTMOS_KEY_EXT(0x41);
        case SDLK_F8:        return JTMOS_KEY_EXT(0x42);
        case SDLK_F9:        return JTMOS_KEY_EXT(0x43);
        case SDLK_F10:       return JTMOS_KEY_EXT(0x44);
        case SDLK_F11:       return JTMOS_KEY_EXT(0x57);
        case SDLK_F12:       return JTMOS_KEY_EXT(0x58);
        default:             return 0;
    }
}
#endif

int JtmosSDL2GraOSInit(const char *title, int width, int height, int scale)
{
    if(width>0) fb_width = width;
    if(height>0) fb_height = height;
    fb_pitch = fb_width;
    if(scale<1) scale=1;
    if(!VesaSetup()) return -1;

#if JTMOS_HAVE_SDL2
    if(!(SDL_WasInit(SDL_INIT_VIDEO) & SDL_INIT_VIDEO)) {
        if(SDL_InitSubSystem(SDL_INIT_VIDEO | SDL_INIT_EVENTS)!=0)
            return -2;
        sdl_started_here = 1;
    }

    host_window = SDL_CreateWindow(title ? title : "JTMOS GraOS",
                                   SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                   fb_width*scale, fb_height*scale,
                                   SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);
    if(!host_window) return -3;

    host_renderer = SDL_CreateRenderer(host_window, -1,
                                       SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if(!host_renderer)
        host_renderer = SDL_CreateRenderer(host_window, -1, SDL_RENDERER_SOFTWARE);
    if(!host_renderer) return -4;

    host_texture = SDL_CreateTexture(host_renderer, SDL_PIXELFORMAT_ARGB8888,
                                     SDL_TEXTUREACCESS_STREAMING,
                                     fb_width, fb_height);
    if(!host_texture) return -5;

    argb_pixels = (uint32_t *)malloc((size_t)fb_width*(size_t)fb_height*sizeof(uint32_t));
    if(!argb_pixels) return -6;

    SDL_RenderSetLogicalSize(host_renderer, fb_width, fb_height);
    SDL_StartTextInput();
    return 0;
#else
    (void)title; (void)scale;
    /* Source still builds on machines without SDL2 headers; presentation is disabled. */
    return -100;
#endif
}

int JtmosSDL2GraOSHandleEvent(const void *sdl_event)
{
#if JTMOS_HAVE_SDL2
    const SDL_Event *ev=(const SDL_Event *)sdl_event;
    if(!ev) return 0;
    if(ev->type==SDL_QUIT)
        return 2;
    if(ev->type==SDL_TEXTINPUT) {
        const unsigned char *p=(const unsigned char *)ev->text.text;
        /* JTMOS terminal FIFO is byte-oriented for ordinary text. */
        while(*p) emit_key((int)*p++);
        return 1;
    }
    if(ev->type==SDL_KEYDOWN) {
        int key;
        if((ev->key.keysym.mod & KMOD_CTRL) &&
           ev->key.keysym.sym>=SDLK_a && ev->key.keysym.sym<=SDLK_z) {
            emit_key((int)(ev->key.keysym.sym-SDLK_a+1));
            return 1;
        }
        key = translate_special(ev->key.keysym.sym);
        if(key) { emit_key(key); return 1; }
    }
#else
    (void)sdl_event;
#endif
    return 0;
}

int JtmosSDL2GraOSPumpEvents(void)
{
#if JTMOS_HAVE_SDL2
    SDL_Event ev;
    while(SDL_PollEvent(&ev)) {
        int r=JtmosSDL2GraOSHandleEvent(&ev);
        if(r==2) return 1;
    }
#endif
    return 0;
}

void JtmosSDL2GraOSPresent(void)
{
#if JTMOS_HAVE_SDL2
    int x,y;
    if(!host_renderer || !host_texture || !vesa_frame_buf || !argb_pixels)
        return;

    for(y=0; y<fb_height; ++y) {
        const unsigned char *src = vesa_frame_buf + (size_t)y*(size_t)fb_pitch;
        uint32_t *dst = argb_pixels + (size_t)y*(size_t)fb_width;
        for(x=0; x<fb_width; ++x) {
            unsigned int idx = src[x];
            unsigned int r,g,b;
            if(idx<16) {
                /* egapal is historically B,G,R in native VESA setup. */
                b=egapal[idx*3+0]; g=egapal[idx*3+1]; r=egapal[idx*3+2];
            } else {
                r=g=b=idx;
            }
            dst[x] = 0xff000000u | (r<<16) | (g<<8) | b;
        }
    }

    SDL_UpdateTexture(host_texture, NULL, argb_pixels, fb_width*(int)sizeof(uint32_t));
    SDL_RenderClear(host_renderer);
    SDL_RenderCopy(host_renderer, host_texture, NULL, NULL);
    SDL_RenderPresent(host_renderer);
#endif
}

void JtmosSDL2GraOSShutdown(void)
{
#if JTMOS_HAVE_SDL2
    SDL_StopTextInput();
    free(argb_pixels); argb_pixels=NULL;
    if(host_texture) SDL_DestroyTexture(host_texture);
    host_texture=NULL;
    if(host_renderer) SDL_DestroyRenderer(host_renderer);
    host_renderer=NULL;
    if(host_window) SDL_DestroyWindow(host_window);
    host_window=NULL;
    if(sdl_started_here) SDL_QuitSubSystem(SDL_INIT_VIDEO | SDL_INIT_EVENTS);
    sdl_started_here=0;
#endif
    if(owns_fb) free(vesa_frame_buf);
    owns_fb=0;
    vesa_frame_buf=NULL;
    vb=NULL;
    vesa_enabled=0;
}
