#include "jtmos_host_chiplevel.h"
#include "graos_sdl2_bridge.h"
#include "directdraw.h"
#include <stdio.h>

extern unsigned char *vesa_frame_buf;
extern int vesa_enabled;
extern int VesaSetup(void);
extern int VesaGetWidth(void);
extern int VesaGetHeight(void);

static volatile int child_ok;
static void child(void)
{
    SetThreadTerminal(GetCurrentThread(), 12);
    if(GetCurrentTerminal()==12) child_ok=1;
}

int main(void)
{
    int pid;
    unsigned long nonzero=0;
    int i;

    if(JtmosHostInit()!=0) return 1;
    pid=JtmosHostCreateThread(child, 32768);
    if(pid<0) return 2;
    WaitProcessTermination(pid);
    if(!child_ok) return 3;

    if(!VesaSetup() || !vesa_enabled || !vesa_frame_buf) return 4;
    DirectFillRect(vesa_frame_buf,VesaGetWidth(),VesaGetHeight(),0,0,80,16,1);
    DirectDrawText(vesa_frame_buf,VesaGetWidth(),VesaGetHeight(),"JTMOS SDL2",0,0);
    for(i=0;i<80*16;i++) if(vesa_frame_buf[i]) ++nonzero;
    if(nonzero==0) return 5;

    outportb(0x3c8, 0x5a);
    if(inportb(0x3c8)!=0x5a) return 6;

    printf("host smoke test OK: pid=%d pixels=%lu ticks=%u\n", pid, nonzero, GetTickCount());
    JtmosSDL2GraOSShutdown();
    return 0;
}
