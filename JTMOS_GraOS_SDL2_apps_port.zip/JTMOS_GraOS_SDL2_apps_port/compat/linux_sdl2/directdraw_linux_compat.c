/*
 * Weak Linux fallback for the small DirectDraw subset used by the terminal.
 * If the real SDL2 GraOS already exports these symbols, its strong symbols win.
 */
#include "directdraw.h"
#include <ctype.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#if defined(__GNUC__)
#define JTMOS_WEAK __attribute__((weak))
#else
#define JTMOS_WEAK
#endif

JTMOS_WEAK void DirectFillRect(unsigned char *dst, int width, int height,
                               int x, int y, int w, int h, unsigned char color)
{
    int yy, x1=x, y1=y, x2=x+w, y2=y+h;
    if(!dst || width<=0 || height<=0 || w<=0 || h<=0) return;
    if(x1<0) x1=0;
    if(y1<0) y1=0;
    if(x2>width) x2=width;
    if(y2>height) y2=height;
    if(x1>=x2 || y1>=y2) return;
    for(yy=y1; yy<y2; ++yy)
        memset(dst + (size_t)yy*(size_t)width + (size_t)x1, color, (size_t)(x2-x1));
}

/* 5x7 host fallback font. Lowercase is rendered as uppercase. */
static uint8_t glyph_row(unsigned char ch, int row)
{
    static const uint8_t digits[10][7] = {
        {14,17,19,21,25,17,14}, {4,12,4,4,4,4,14},
        {14,17,1,2,4,8,31},     {30,1,1,14,1,1,30},
        {2,6,10,18,31,2,2},     {31,16,16,30,1,1,30},
        {14,16,16,30,17,17,14}, {31,1,2,4,8,8,8},
        {14,17,17,14,17,17,14}, {14,17,17,15,1,1,14}
    };
    static const uint8_t upper[26][7] = {
        {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},
        {14,17,16,16,16,17,14},{30,17,17,17,17,17,30},
        {31,16,16,30,16,16,31},{31,16,16,30,16,16,16},
        {14,17,16,23,17,17,15},{17,17,17,31,17,17,17},
        {14,4,4,4,4,4,14},{7,2,2,2,18,18,12},
        {17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
        {17,27,21,21,17,17,17},{17,25,21,19,17,17,17},
        {14,17,17,17,17,17,14},{30,17,17,30,16,16,16},
        {14,17,17,17,21,18,13},{30,17,17,30,20,18,17},
        {15,16,16,14,1,1,30},{31,4,4,4,4,4,4},
        {17,17,17,17,17,17,14},{17,17,17,17,17,10,4},
        {17,17,17,21,21,21,10},{17,17,10,4,10,17,17},
        {17,17,10,4,4,4,4},{31,1,2,4,8,16,31}
    };
    if(row<0 || row>6) return 0;
    if(ch>='a' && ch<='z') ch=(unsigned char)(ch-'a'+'A');
    if(ch>='0' && ch<='9') return digits[ch-'0'][row];
    if(ch>='A' && ch<='Z') return upper[ch-'A'][row];

    switch(ch) {
        case ' ': return 0;
        case '.': return row==6 ? 4 : 0;
        case ',': return row==5 ? 4 : row==6 ? 8 : 0;
        case ':': return (row==2 || row==5) ? 4 : 0;
        case ';': return row==2 ? 4 : row==5 ? 4 : row==6 ? 8 : 0;
        case '-': return row==3 ? 14 : 0;
        case '_': return row==6 ? 31 : 0;
        case '+': return row==3 ? 31 : (row>=1 && row<=5 ? 4 : 0);
        case '=': return (row==2 || row==4) ? 31 : 0;
        case '/': return (uint8_t)(1u << (row<5 ? (4-row) : 0));
        case '\\': return (uint8_t)(1u << (row<5 ? row : 4));
        case '|': return 4;
        case '!': return row<5 ? 4 : row==6 ? 4 : 0;
        case '?': { static const uint8_t q[7]={14,17,1,2,4,0,4}; return q[row]; }
        case '(': return (row==0||row==6)?2:row==1||row==5?4:8;
        case ')': return (row==0||row==6)?8:row==1||row==5?4:2;
        case '[': return (row==0||row==6)?14:8;
        case ']': return (row==0||row==6)?14:2;
        case '<': return row==1?2:row==2?4:row==3?8:row==4?4:row==5?2:0;
        case '>': return row==1?8:row==2?4:row==3?2:row==4?4:row==5?8:0;
        case '#': return (row==2||row==4)?31:10;
        case '*': return row==2?21:row==3?14:row==4?21:0;
        case '%': return row==0?17:row==1?2:row==2?4:row==3?8:row==4?16:row==6?17:0;
        case '@': { static const uint8_t a[7]={14,17,23,21,23,16,14}; return a[row]; }
        case '$': { static const uint8_t d[7]={4,15,20,14,5,30,4}; return d[row]; }
        case '&': { static const uint8_t a[7]={12,18,20,8,21,18,13}; return a[row]; }
        case '\'': return row<2 ? 4 : 0;
        case '"': return row<2 ? 10 : 0;
        default: { static const uint8_t q[7]={14,17,1,2,4,0,4}; return q[row]; }
    }
}

JTMOS_WEAK void DirectDrawText(unsigned char *dst, int width, int height,
                               const char *text, int x, int y)
{
    int cx=x;
    if(!dst || !text || width<=0 || height<=0) return;
    for(; *text; ++text, cx+=8) {
        unsigned char ch=(unsigned char)*text;
        int row,col;
        if(ch=='\n') { y+=8; cx=x-8; continue; }
        for(row=0; row<7; ++row) {
            uint8_t bits=glyph_row(ch,row);
            int py=y+row;
            if(py<0 || py>=height) continue;
            for(col=0; col<5; ++col) {
                int px=cx+col+1;
                if(px>=0 && px<width && (bits & (1u << (4-col))))
                    dst[(size_t)py*(size_t)width + (size_t)px]=15;
            }
        }
    }
}
