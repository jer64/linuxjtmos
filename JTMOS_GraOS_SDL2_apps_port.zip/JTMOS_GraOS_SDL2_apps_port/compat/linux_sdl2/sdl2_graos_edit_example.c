/*
 * Minimal SDL2 GraOS entry point using JTMOS edit as the GUI text source.
 * Build with: make -f Makefile.host graos_edit_demo
 */
#include "graos_sdl2_bridge.h"
#include "graos_edit_gui.h"
#include "jtmos_host_chiplevel.h"

#include <stdio.h>

int main(int argc, char **argv)
{
    const char *fname=argc>1 ? argv[1] : "Untitled.txt";
    int rc;

    if(JtmosHostInit()!=0) {
        fprintf(stderr,"JTMOS host init failed\n");
        return 1;
    }
    rc=JtmosSDL2GraOSInit("JTMOS GraOS - edit",640,480,2);
    if(rc<0) {
        fprintf(stderr,"SDL2/GraOS init failed: %d\n",rc);
        return 2;
    }

    if(GuiEditOpen(fname,0,0,80,54)!=0) {
        fprintf(stderr,"edit GUI init failed\n");
        JtmosSDL2GraOSShutdown();
        return 3;
    }

    while(!GuiEditShouldClose() && !JtmosSDL2GraOSPumpEvents()) {
        GuiEditTick();
        JtmosSDL2GraOSPresent();
        delay(16);
    }

    GuiEditClose();
    JtmosSDL2GraOSShutdown();
    JtmosHostShutdown();
    return 0;
}
