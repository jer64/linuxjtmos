#ifndef JTMOS_GRAOS_EDIT_GUI_H
#define JTMOS_GRAOS_EDIT_GUI_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int active;
    int x, y;
    int cols, rows;
    int should_close;
    unsigned long last_revision;
} GUI_EDIT_WINDOW;

extern GUI_EDIT_WINDOW gui_edit_window;

/* Opens fname into the classic JTMOS edit document model and makes it GUI input focus. */
int  GuiEditOpen(const char *fname, int x, int y, int cols, int rows);
void GuiEditClose(void);
void GuiEditResize(int x, int y, int cols, int rows);
int  GuiEditKey(int key);
int  GuiEditFocusedKey(int key);
void GuiEditInvalidate(void);
void GuiEditRender(void);
void GuiEditTick(void);
int  GuiEditShouldClose(void);

#ifdef __cplusplus
}
#endif

#endif
