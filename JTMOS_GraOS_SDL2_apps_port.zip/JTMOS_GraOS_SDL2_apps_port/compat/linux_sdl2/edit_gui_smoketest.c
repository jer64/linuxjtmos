#include "graos_edit_gui.h"
#include "graos_sdl2_bridge.h"
#include "edit.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int nonzero_pixels(const unsigned char *p, size_t n)
{
    int c=0;
    while(n--) if(*p++) ++c;
    return c;
}

int main(void)
{
    unsigned char *fb=(unsigned char *)calloc(640u*480u,1u);
    const char *in="/tmp/jtmos_edit_input.txt";
    const char *out="/tmp/jtmos_edit_output.txt";
    FILE *f;
    char buf[256];
    int pix;

    if(!fb) return 1;
    f=fopen(in,"wb");
    if(!f) return 2;
    fputs("Hello JTMOS\nSecond line\n",f);
    fclose(f);

    if(JtmosSDL2GraOSAttachFramebuffer(fb,640,480,640)!=0) return 3;
    if(GuiEditOpen(in,0,0,80,40)!=0) return 4;
    GuiEditTick();
    pix=nonzero_pixels(fb,640u*480u);
    if(pix<100) return 5;

    /* The GUI sends keys to edit directly, not through SCREEN. */
    GuiEditKey(EDIT_KEY_END);
    GuiEditKey('!');
    if(strcmp(EditorGetLine(0),"Hello JTMOS!")!=0) return 6;

    GuiEditKey(EDIT_KEY_DOWN);
    GuiEditKey(EDIT_KEY_HOME);
    GuiEditKey('>');
    if(strncmp(EditorGetLine(1),">Second line",12)!=0) return 7;

    if(EditorSave(out)!=0) return 8;
    f=fopen(out,"rb");
    if(!f) return 9;
    memset(buf,0,sizeof(buf));
    fread(buf,1,sizeof(buf)-1,f);
    fclose(f);
    if(strstr(buf,"Hello JTMOS!\n>Second line\n")==NULL) return 10;

    GuiEditClose();
    free(fb);
    remove(in);
    remove(out);
    printf("edit GUI integration OK: pixels=%d, direct ed.buf rendering verified\n",pix);
    return 0;
}
