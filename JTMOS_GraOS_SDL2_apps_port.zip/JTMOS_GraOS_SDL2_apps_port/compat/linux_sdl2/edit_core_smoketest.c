#include "edit.h"
#include <stdio.h>
#include <string.h>

#define CHECK(x,n) do { if(!(x)) { fprintf(stderr,"check %d failed\n",(n)); return (n); } } while(0)

int main(void)
{
    int i;
    CHECK(EditorInit()==0,1);
    for(i=0;i<EDIT_COLUMNS;i++) CHECK(StoreChar('a'+(i%26))==0,2);
    CHECK(EditorGetLineLength(0)==EDIT_COLUMNS,3);
    CHECK(StoreChar('X')!=0,4); /* no 81st visible byte */

    CursorHome();
    CHECK(EditorDelete()==0,5);
    CHECK(EditorGetLineLength(0)==EDIT_COLUMNS-1,6);
    CHECK(EditorNewLine()==0,7);
    CHECK(ed.lines==2,8);
    CHECK(ed.cursor.y==1 && ed.cursor.x==0,9);
    CHECK(EditorBackspace()==0,10); /* at column 0: merge line 1 back into line 0 */
    CHECK(ed.lines==1,11);
    CHECK(EditorGetLineLength(0)==EDIT_COLUMNS-1,12);
    CHECK(StoreChar('Z')==0,13);

    /* Ctrl-X requires confirmation while modified, then exits on second press. */
    CHECK(!(EditorHandleKey(24)&EDIT_ACTION_EXIT),14);
    CHECK(EditorHandleKey(24)&EDIT_ACTION_EXIT,15);
    EditorShutdown();
    puts("edit core OK: 80-column boundary, newline, merge and quit confirmation");
    return 0;
}
