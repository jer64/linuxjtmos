/* Integration sketch: adapt the surrounding main()/shutdown to your GraOS port. */
#include "graos_sdl2_bridge.h"
#include "jtmos_host_chiplevel.h"
#include "jtmos_host_term.h"
#include "gui_terminal.h"

int JtmosSDL2GraOSExample(void)
{
    int win;

    if(JtmosHostInit()!=0) return -1;
    VirtualTerminalInit();
    if(JtmosSDL2GraOSInit("JTMOS GraOS",640,480,2)<0) return -2;
    GuiTerminalInit();

    win=GuiTerminalCreate(16,24,76,25,"JTMOS Terminal");
    if(win<0) return -3;

    sputs(&screens[GuiTerminalGetTerminal(win)],
          "JTMOS virtual terminal through Linux/SDL2 wrappers\n");

    while(!JtmosSDL2GraOSPumpEvents()) {
        GuiTerminalTick();
        JtmosSDL2GraOSPresent();
        delay(16);
    }

    JtmosSDL2GraOSShutdown();
    return 0;
}
