#ifndef JTMOS_GRAOS_SDL2_BRIDGE_H
#define JTMOS_GRAOS_SDL2_BRIDGE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * SDL2/Linux host for the old 8-bit 640x480 VESA-style GraOS framebuffer.
 * The terminal/DirectDraw side still sees BYTE *vesa_frame_buf.
 */
int  JtmosSDL2GraOSInit(const char *title, int width, int height, int scale);
void JtmosSDL2GraOSShutdown(void);
/* Existing GraOS SDL event loop can pass SDL_Event* as void* here.
 * Return: 0=not handled, 1=handled, 2=quit requested. */
int  JtmosSDL2GraOSHandleEvent(const void *sdl_event);
int  JtmosSDL2GraOSPumpEvents(void); /* 0 = continue, 1 = quit requested */
void JtmosSDL2GraOSPresent(void);

/* Attach an existing tightly-packed 8-bit GraOS framebuffer instead of allocating one. */
int  JtmosSDL2GraOSAttachFramebuffer(unsigned char *fb, int width, int height, int pitch);

/* Optional input sink; NULL restores GuiTerminalFocusedKey(). */
typedef int (*JTMOS_SDL2_KEY_SINK)(int key);
void JtmosSDL2GraOSSetKeySink(JTMOS_SDL2_KEY_SINK sink);

/* VESA compatibility exported by the host backend. */
extern unsigned char *vesa_frame_buf;
extern int vesa_enabled;
int VesaSetup(void);
int VesaGetWidth(void);
int VesaGetHeight(void);
int VesaGetPitch(void);

/* DOS/JTMOS-style extended key values stored in the terminal's int FIFO. */
#define JTMOS_KEY_EXT(scan) (0x100 | ((scan) & 0xff))
#define JTMOS_KEY_UP         JTMOS_KEY_EXT(0x48)
#define JTMOS_KEY_DOWN       JTMOS_KEY_EXT(0x50)
#define JTMOS_KEY_LEFT       JTMOS_KEY_EXT(0x4b)
#define JTMOS_KEY_RIGHT      JTMOS_KEY_EXT(0x4d)
#define JTMOS_KEY_HOME       JTMOS_KEY_EXT(0x47)
#define JTMOS_KEY_END        JTMOS_KEY_EXT(0x4f)
#define JTMOS_KEY_PAGEUP     JTMOS_KEY_EXT(0x49)
#define JTMOS_KEY_PAGEDOWN   JTMOS_KEY_EXT(0x51)
#define JTMOS_KEY_INSERT     JTMOS_KEY_EXT(0x52)
#define JTMOS_KEY_DELETE     JTMOS_KEY_EXT(0x53)

#ifdef __cplusplus
}
#endif

#endif
