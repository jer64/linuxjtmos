#ifndef JTMOS_HOST_TERM_H
#define JTMOS_HOST_TERM_H

#include <stdint.h>

#ifndef NULL
#define NULL ((void*)0)
#endif
#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

typedef uint8_t BYTE;
typedef uint16_t WORD;
typedef uint32_t DWORD;

typedef struct {
    BYTE *buf;
    int l_buf;
    int head, tail;
    int count;
    DWORD magic;
    int total;
} FBUF;

typedef struct {
    long x1,y1,x2,y2,a1,a2,a3,a4;
} WINDOW;

typedef struct {
    int isFree;
    char isRemoteCOM;
    struct { int length; char *buf; int offs; } cap;
    WINDOW window;
    char supallow,tc,updcur;
    long width,height,curx,cury;
    char *buf,*copy;
    char ac,HWCopy;
    char ansi[50];
    int ptr_ansi;
    FBUF key;
    int pid;
    int id;
    DWORD revision;
} SCREEN;

#define N_MAX_SCREENS 256
#define N_VIRTUAL_TERMINALS 9

#define BLACK 0
#define BLUE 1
#define GREEN 2
#define CYAN 3
#define RED 4
#define MAGENTA 5
#define BROWN 6
#define LIGHTGRAY 7
#define DARKGRAY 8
#define LIGHTBLUE 9
#define LIGHTGREEN 10
#define LIGHTCYAN 11
#define LIGHTRED 12
#define LIGHTMAGENTA 13
#define YELLOW 14
#define WHITE 15

extern SCREEN screens[N_MAX_SCREENS];
extern int terminalLockPID;
extern int puts_busy;

void VirtualTerminalInit(void);
int CreateTerminal(void);
int NewTerminal(void);
int ReserveTerminal(void);
void FreeScreen(SCREEN *s);
void FreePIDTerminals(int pid);
int IsTerminalValid(int id);
int SetTerminalOwner(int id, int pid);
int GetTerminalOwner(int id);
int GetVisibleTerminal(void);
int SetVisibleTerminal(int which);
WORD GetCursorLocation(int ter);

void OutTermKey(int terID, int ch);
int OutputTerminalKeyboardBuffer(SCREEN *s, int ch);
int InputTerminalKeyboardBuffer(SCREEN *s);

void stextcolor(SCREEN *s,char c);
void stextbackground(SCREEN *s,char c);
void sclrscr(SCREEN *s);
void sgotoxy(SCREEN *s,int x,int y);
void sgotox(SCREEN *s,int x);
void sgotoy(SCREEN *s,int y);
int swherex(SCREEN *s);
int swherey(SCREEN *s);
void sputch(SCREEN *s,char c);
void sputs(SCREEN *s,const char *str);
void putch(unsigned char c);
void print(const char *str);
void clrscr(void);
void gotoxy(int x,int y);
int wherex(void);
int wherey(void);
void textcolor(int c);
void textbackground(int c);
int waitkey(void);
int swindow(SCREEN *s,long x1,long y1,long x2,long y2);
int window(long x1,long y1,long x2,long y2);
void CursorState(SCREEN *s,int state);
void SetTerminalScrolling(int terid,int what);
void scrpoke(SCREEN *s,long ad,char data);
char scrpeek(SCREEN *s,long ad);

int SetTerminalLock(int newLockPID);
int GetTerminalLock(void);

#endif
