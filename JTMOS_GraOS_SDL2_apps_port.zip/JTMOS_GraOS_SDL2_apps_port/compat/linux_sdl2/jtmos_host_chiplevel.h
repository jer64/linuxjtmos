#ifndef JTMOS_HOST_CHIPLEVEL_H
#define JTMOS_HOST_CHIPLEVEL_H

/*
 * Linux/SDL2 host-side replacement layer for JTMOS chiplevel services.
 *
 * This header intentionally does not include the original JTMOS threads.h/int.h
 * because those headers describe 32-bit x86 kernel state (GDT/TSS/IRQ ABI).
 * Host code uses pointer-safe interfaces here and exports a compatible subset
 * of the traditional function names for source-level portability.
 */

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef JTMOS_HOST_MAX_THREADS
#define JTMOS_HOST_MAX_THREADS 256
#endif

#ifndef JTMOS_HOST_MAX_LOCKS
#define JTMOS_HOST_MAX_LOCKS 1000
#endif

/* Same logical priority constants can be passed through from JTMOS callers. */
extern int Multitasking;

int  JtmosHostInit(void);
void JtmosHostShutdown(void);

/* Pointer-safe thread creation for x86_64 Linux. */
int  JtmosHostCreateThread(void (*entry)(void), size_t stack_size);
int  GetCurrentThread(void);
int  GetCurrentTerminal(void);
int  GetThreadTerminal(int pid);
void SetThreadTerminal(int pid, int terminal_id);
void SetThreadPriority(uint32_t pid, unsigned char priority);
unsigned char GetThreadPriority(uint32_t pid);
void IdentifyThread(uint32_t pid, const char *name);
void _IdentifyThread(uint32_t pid, const char *name);
int  GetThreadName(int pid, char *out);
int  GetThreadCount(void);
uint32_t GetRunningThreadsCount(void);
int  SwitchToThread(void);
int  SwitchToThreadEx(int pid);
void WaitProcessTermination(int pid);
void KillThread(uint32_t pid);
void KillThreadEx(uint32_t pid, uint32_t options);
void ExitThread(int rval);
int  jtmos_getpid(void);

/* Millisecond monotonic tick source. */
uint32_t GetTickCount(void);
uint32_t GetTickCount2(void);
void delay(uint32_t duration_ms);
void xsleep(uint32_t duration_ms);
int  jtmos_sleep(int seconds);

/* Host emulation of interrupt critical sections. */
void JtmosHostDisableInterrupts(void);
void JtmosHostEnableInterrupts(void);
uint32_t get_eflags(void);
void set_eflags(uint32_t flags);
void idle_moment(void);

/* JTMOS lock ID API mapped to pthread mutexes. */
void Lock(int lock_id);
void Unlock(int lock_id);

/* Safe user-space emulation for x86 I/O ports. No privileged I/O is executed. */
void     outportb(uint16_t port, uint8_t value);
uint8_t  inportb(uint16_t port);
void     outportw(uint16_t port, uint16_t value);
uint16_t inportw(uint16_t port);
void     outportd(uint32_t port, uint32_t value);
uint32_t inportd(uint32_t port);
void     enable_irq(unsigned short irq_num);
void     disable_irq(unsigned short irq_num);

/* Small compatibility stack object, useful to old code being ported gradually. */
typedef struct JTMOS_HOST_THREAD_STACK {
    int pid;
    unsigned char *stack;
    int l_stack;
} JTMOS_HOST_THREAD_STACK;

void JtmosHostThreadCreateStack(JTMOS_HOST_THREAD_STACK *t, int stack_size);
void JtmosHostThreadDestroyStack(JTMOS_HOST_THREAD_STACK *t);

/* Prefer these remaps only in host translation units. */
#ifdef JTMOS_HOST_REMAP_LEGACY_NAMES
# define disable() JtmosHostDisableInterrupts()
# define enable()  JtmosHostEnableInterrupts()
# define cli()     JtmosHostDisableInterrupts()
# define sti()     JtmosHostEnableInterrupts()
# define nop()     idle_moment()
# define sleep(x)  jtmos_sleep((x))
# define getpid()  jtmos_getpid()
#endif

#ifdef __cplusplus
}
#endif

#endif
