#ifndef JTMOS_HOST_OVERLAY_PIT_H
#define JTMOS_HOST_OVERLAY_PIT_H
#include "../jtmos_host_chiplevel.h"
static inline void InitTimer(void) { (void)JtmosHostInit(); }
static inline void init_pit(long hz, unsigned char channel) { (void)hz; (void)channel; }
#endif
