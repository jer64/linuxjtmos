#ifndef JTMOS_HOST_OVERLAY_IO_H
#define JTMOS_HOST_OVERLAY_IO_H
#include "../jtmos_host_chiplevel.h"
#define outb(value,port)   outportb((uint16_t)(port),(uint8_t)(value))
#define inb(port)          inportb((uint16_t)(port))
#define outb_p(value,port) outportb((uint16_t)(port),(uint8_t)(value))
#define inb_p(port)        inportb((uint16_t)(port))
#define outw_p(value,port) outportw((uint16_t)(port),(uint16_t)(value))
#define inw_p(port)        inportw((uint16_t)(port))
#endif
