#ifndef JTMOS_HOST_OVERLAY_LOCK_H
#define JTMOS_HOST_OVERLAY_LOCK_H
#include "../jtmos_host_chiplevel.h"
/* Generic legacy LOCK/UNLOCK fallback: serialize as a host critical section. */
#define LOCK   JtmosHostDisableInterrupts()
#define UNLOCK JtmosHostEnableInterrupts()
#endif
