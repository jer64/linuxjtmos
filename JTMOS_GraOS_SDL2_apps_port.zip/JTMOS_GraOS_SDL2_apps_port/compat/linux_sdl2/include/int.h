#ifndef JTMOS_HOST_OVERLAY_INT_H
#define JTMOS_HOST_OVERLAY_INT_H
#include "../jtmos_host_chiplevel.h"
#define PUSHFLAGS do { } while(0)
#define POPFLAGS  do { } while(0)
static inline void Init8259(void) { }
static inline void init_idt(void) { }
static inline void init_safe_idt(void) { }
#endif
