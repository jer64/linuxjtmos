#ifndef JTMOS_HOST_OVERLAY_CPU_H
#define JTMOS_HOST_OVERLAY_CPU_H
#include "../jtmos_host_chiplevel.h"
#define disable() JtmosHostDisableInterrupts()
#define enable()  JtmosHostEnableInterrupts()
#define cli()     JtmosHostDisableInterrupts()
#define sti()     JtmosHostEnableInterrupts()
#define nop()     idle_moment()
#endif
