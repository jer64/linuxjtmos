#ifndef JTMOS_HOST_OVERLAY_THREADS_H
#define JTMOS_HOST_OVERLAY_THREADS_H
#include "../jtmos_host_chiplevel.h"
#include "../jtmos_host_term.h"

typedef JTMOS_HOST_THREAD_STACK THREAD;
#ifndef THREAD_PRIORITY_NORMAL
#define THREAD_PRIORITY_TIME_CRITICAL 1
#define THREAD_PRIORITY_HIGHEST 1
#define THREAD_PRIORITY_ABOVE_NORMAL 1
#define THREAD_PRIORITY_NORMAL 1
#define THREAD_PRIORITY_BELOW_NORMAL 2
#define THREAD_PRIORITY_IDLE 4
#define THREAD_PRIORITY_LOWEST 8
#endif

#define ThreadCreateStack(t,n)  JtmosHostThreadCreateStack((JTMOS_HOST_THREAD_STACK *)(t),(n))
#define ThreadDestroyStack(t)   JtmosHostThreadDestroyStack((JTMOS_HOST_THREAD_STACK *)(t))
/* stack is ignored by pthread; entry remains a real pointer on x86_64. */
#define create_thread(stack,stacksize,entry) \
    ((void)(stack), JtmosHostCreateThread((void (*)(void))(entry),(size_t)(stacksize)))
#define getpid() jtmos_getpid()
#endif
