/*
 * graos_edit_gui.c - SDL2/GraOS frontend for JTMOS edit.
 *
 * IMPORTANT ARCHITECTURE RULE:
 *   The text shown here comes directly from edit's ed.buf[] document model.
 *   It is not copied from a virtual terminal SCREEN buffer.  SDL2 input is
 *   routed to EditorHandleKey(), and redraw reads the resulting edit buffer.
 */
#include "graos_edit_gui.h"
#include "graos_sdl2_bridge.h"
#include "directdraw.h"
#include "edit.h"

#include <stdio.h>
#include <string.h>

GUI_EDIT_WINDOW gui_edit_window;

static int mini(int a, int b) { return a < b ? a : b; }
static int maxi(int a, int b) { return a > b ? a : b; }

static void fill(int x, int y, int w, int h, unsigned char color)
{
    if(!vesa_frame_buf) return;
    DirectFillRect(vesa_frame_buf, VesaGetWidth(), VesaGetHeight(), x,y,w,h,color);
}

static void text(const char *s, int x, int y)
{
    if(!vesa_frame_buf || !s) return;
    DirectDrawText(vesa_frame_buf, VesaGetWidth(), VesaGetHeight(), s,x,y);
}

void GuiEditInvalidate(void)
{
    gui_edit_window.last_revision = ~0UL;
}

int GuiEditOpen(const char *fname, int x, int y, int cols, int rows)
{
    int load_rc;

    memset(&gui_edit_window, 0, sizeof(gui_edit_window));
    if(EditorInit()!=0)
        return -1;

    gui_edit_window.active=1;
    gui_edit_window.x=maxi(0,x);
    gui_edit_window.y=maxi(0,y);
    gui_edit_window.cols=cols;
    gui_edit_window.rows=rows;
    gui_edit_window.should_close=0;
    GuiEditResize(x,y,cols,rows);

    load_rc=EditorLoad(fname && *fname ? fname : "Untitled");
    /* A missing file is a valid new document, not a GUI startup error. */
    if(load_rc<0) {
        GuiEditClose();
        return -2;
    }

    JtmosSDL2GraOSSetKeySink(GuiEditFocusedKey);
    GuiEditInvalidate();
    return 0;
}

void GuiEditClose(void)
{
    JtmosSDL2GraOSSetKeySink(NULL);
    if(gui_edit_window.active)
        EditorShutdown();
    memset(&gui_edit_window, 0, sizeof(gui_edit_window));
}

void GuiEditResize(int x, int y, int cols, int rows)
{
    int fbw=VesaGetWidth();
    int fbh=VesaGetHeight();
    int max_cols, max_rows;

    gui_edit_window.x=maxi(0,x);
    gui_edit_window.y=maxi(0,y);
    max_cols=(fbw-gui_edit_window.x)/8;
    /* 12 title + 12 status + 8 help/status margin. */
    max_rows=(fbh-gui_edit_window.y-32)/8;
    if(max_cols<1) max_cols=1;
    if(max_rows<1) max_rows=1;
    gui_edit_window.cols=mini(maxi(cols,1), mini(EDIT_COLUMNS,max_cols));
    gui_edit_window.rows=mini(maxi(rows,1), max_rows);
    EditorSetViewport(gui_edit_window.cols, gui_edit_window.rows);
    GuiEditInvalidate();
}

int GuiEditKey(int key)
{
    int action;
    if(!gui_edit_window.active) return -1;
    action=EditorHandleKey(key);
    if(action & EDIT_ACTION_EXIT)
        gui_edit_window.should_close=1;
    if(action & EDIT_ACTION_REDRAW)
        GuiEditInvalidate();
    return 0;
}

int GuiEditFocusedKey(int key)
{
    return GuiEditKey(key);
}

int GuiEditShouldClose(void)
{
    return gui_edit_window.should_close;
}

static void pad_copy(char *dst, size_t cap, const char *src, int chars)
{
    int i=0;
    if(cap==0) return;
    if(chars>(int)cap-1) chars=(int)cap-1;
    while(i<chars && src && src[i]) { dst[i]=src[i]; ++i; }
    while(i<chars) dst[i++]=' ';
    dst[i]=0;
}

void GuiEditRender(void)
{
    char line[EDIT_COLUMNS+1];
    char title[256];
    char status[256];
    int row;
    int x,y,cols,rows;
    int body_y;
    int width_px;
    int cursor_screen_y;
    int cursor_screen_x;
    int docrow;

    if(!gui_edit_window.active || !vesa_enabled || !vesa_frame_buf)
        return;
    if(gui_edit_window.last_revision==ed.revision)
        return;

    x=gui_edit_window.x;
    y=gui_edit_window.y;
    cols=gui_edit_window.cols;
    rows=gui_edit_window.rows;
    width_px=cols*8;
    body_y=y+12;

    /* GraOS application chrome + edit-owned document surface. */
    fill(x,y,width_px,12,1);                 /* title bar */
    fill(x,body_y,width_px,rows*8,0);        /* editor body */
    fill(x,body_y+rows*8,width_px,12,8);     /* status bar */

    snprintf(title,sizeof(title),"edit: %.220s%s  [%s]",
             ed.filename,
             ed.modified ? " *" : "",
             ed.insertMode ? "INS" : "OVR");
    title[cols>0 && cols<(int)sizeof(title) ? cols : (int)sizeof(title)-1]=0;
    text(title,x,y+2);

    for(row=0; row<rows; ++row) {
        docrow=ed.view.y+row;
        if(docrow>=0 && docrow<ed.lines)
            pad_copy(line,sizeof(line),EditorGetLine(docrow)+mini(ed.view.x,EditorGetLineLength(docrow)),cols);
        else
            pad_copy(line,sizeof(line),"",cols);
        text(line,x,body_y+row*8);
    }

    if(ed.help_visible && rows>=5) {
        int hy=body_y+(rows-5)*8;
        fill(x,hy,width_px,5*8,4);
        text("JTMOS edit / GraOS SDL2",x,hy);
        text("Ctrl-O/F2 Save   Ctrl-X/F10 Exit",x,hy+8);
        text("Arrows/Home/End  PgUp/PgDn Move",x,hy+16);
        text("Ins toggles insert   Del/Backspace edit",x,hy+24);
        text("F1 closes this help",x,hy+32);
    }

    snprintf(status,sizeof(status),"Ln %d Col %d  %d lines  %s",
             ed.cursor.y+1,ed.cursor.x+1,ed.lines,ed.status);
    status[cols>0 && cols<(int)sizeof(status) ? cols : (int)sizeof(status)-1]=0;
    text(status,x,body_y+rows*8+2);

    /* Cursor is a GUI overlay. It never modifies ed.buf[]. */
    cursor_screen_y=ed.cursor.y-ed.view.y;
    cursor_screen_x=ed.cursor.x-ed.view.x;
    if(cursor_screen_y>=0 && cursor_screen_y<rows &&
       cursor_screen_x>=0 && cursor_screen_x<cols) {
        fill(x+cursor_screen_x*8,
             body_y+cursor_screen_y*8+7,
             7,1,15);
    }

    gui_edit_window.last_revision=ed.revision;
    ed.view.upd=0;
}

void GuiEditTick(void)
{
    GuiEditRender();
}
