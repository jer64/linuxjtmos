/*
 * GraOS SDL2 main-loop integration after the edit port.
 * The GUI text source is the JTMOS edit document model (ed.buf[]).
 */
#include "graos_sdl2_bridge.h"
#include "graos_edit_gui.h"
#include "jtmos_host_chiplevel.h"

int JtmosSDL2GraOSExample(void)
{
    if(JtmosHostInit()!=0) return -1;
    if(JtmosSDL2GraOSInit("JTMOS GraOS - edit",640,480,2)<0) return -2;

    /* New/nonexistent paths intentionally open as an empty edit document. */
    if(GuiEditOpen("Untitled.txt",0,0,80,54)!=0) return -3;

    while(!GuiEditShouldClose() && !JtmosSDL2GraOSPumpEvents()) {
        /* This redraw reads ed.buf[] directly. */
        GuiEditTick();
        JtmosSDL2GraOSPresent();
        delay(16);
    }

    GuiEditClose();
    JtmosSDL2GraOSShutdown();
    JtmosHostShutdown();
    return 0;
}
