#define _GNU_SOURCE
#include "jtmos_host_chiplevel.h"

#include <pthread.h>
#include <sched.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define JTMOS_IF_FLAG 0x00000200u
#define JTMOS_HOST_NAME_LEN 48

typedef struct {
    int used;
    int joined;
    int terminal_id;
    unsigned char priority;
    pthread_t thread;
    void (*entry)(void);
    char name[JTMOS_HOST_NAME_LEN];
} HOST_THREAD_REC;

static HOST_THREAD_REC host_threads[JTMOS_HOST_MAX_THREADS];
static pthread_mutex_t thread_table_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_once_t host_once = PTHREAD_ONCE_INIT;
static pthread_key_t current_pid_key;
static pthread_mutex_t irq_mutex;
static pthread_mutex_t host_locks[JTMOS_HOST_MAX_LOCKS];
static uint32_t port_shadow[65536];
static unsigned char irq_enabled[256];
static struct timespec boot_time;
static _Thread_local unsigned int irq_depth;

int Multitasking = 1;

static void host_init_once(void)
{
    pthread_mutexattr_t attr;
    int i;

    clock_gettime(CLOCK_MONOTONIC, &boot_time);
    pthread_key_create(&current_pid_key, NULL);

    pthread_mutexattr_init(&attr);
    pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(&irq_mutex, &attr);
    pthread_mutexattr_destroy(&attr);

    for(i=0; i<JTMOS_HOST_MAX_LOCKS; ++i)
        pthread_mutex_init(&host_locks[i], NULL);
    for(i=0; i<256; ++i)
        irq_enabled[i] = 1;

    /* PID 0 represents the SDL/GraOS main thread. */
    host_threads[0].used = 1;
    host_threads[0].terminal_id = 0;
    host_threads[0].thread = pthread_self();
    strncpy(host_threads[0].name, "graos-main", JTMOS_HOST_NAME_LEN-1);
    pthread_setspecific(current_pid_key, (void *)(intptr_t)1); /* stored pid+1 */
}

int JtmosHostInit(void)
{
    return pthread_once(&host_once, host_init_once);
}

void JtmosHostShutdown(void)
{
    /* Deliberately conservative: process teardown releases pthread resources. */
}

static int host_current_pid(void)
{
    intptr_t v;
    JtmosHostInit();
    v = (intptr_t)pthread_getspecific(current_pid_key);
    if(v==0)
        return 0;
    return (int)(v-1);
}

static int alloc_pid(void)
{
    int i;
    pthread_mutex_lock(&thread_table_mutex);
    for(i=1; i<JTMOS_HOST_MAX_THREADS; ++i) {
        if(!host_threads[i].used) {
            memset(&host_threads[i], 0, sizeof(host_threads[i]));
            host_threads[i].used = 1;
            host_threads[i].terminal_id = 0;
            pthread_mutex_unlock(&thread_table_mutex);
            return i;
        }
    }
    pthread_mutex_unlock(&thread_table_mutex);
    return -1;
}

static void *host_thread_trampoline(void *arg)
{
    int pid = (int)(intptr_t)arg;
    void (*entry)(void);

    pthread_setspecific(current_pid_key, (void *)(intptr_t)(pid+1));
    pthread_mutex_lock(&thread_table_mutex);
    entry = host_threads[pid].entry;
    pthread_mutex_unlock(&thread_table_mutex);

    if(entry)
        entry();
    return NULL;
}

int JtmosHostCreateThread(void (*entry)(void), size_t stack_size)
{
    pthread_attr_t attr;
    int pid, rc;

    if(!entry)
        return -1;
    JtmosHostInit();
    pid = alloc_pid();
    if(pid<0)
        return -1;

    host_threads[pid].entry = entry;
    pthread_attr_init(&attr);
#ifdef PTHREAD_STACK_MIN
    if(stack_size >= (size_t)PTHREAD_STACK_MIN)
        pthread_attr_setstacksize(&attr, stack_size);
#else
    (void)stack_size;
#endif
    rc = pthread_create(&host_threads[pid].thread, &attr,
                        host_thread_trampoline, (void *)(intptr_t)pid);
    pthread_attr_destroy(&attr);
    if(rc!=0) {
        pthread_mutex_lock(&thread_table_mutex);
        memset(&host_threads[pid], 0, sizeof(host_threads[pid]));
        pthread_mutex_unlock(&thread_table_mutex);
        return -1;
    }
    return pid;
}

int GetCurrentThread(void) { return host_current_pid(); }
int GetCurrentTerminal(void) { return GetThreadTerminal(host_current_pid()); }

int GetThreadTerminal(int pid)
{
    int term = 0;
    JtmosHostInit();
    if(pid<0 || pid>=JTMOS_HOST_MAX_THREADS)
        return 0;
    pthread_mutex_lock(&thread_table_mutex);
    if(host_threads[pid].used)
        term = host_threads[pid].terminal_id;
    pthread_mutex_unlock(&thread_table_mutex);
    return term;
}

void SetThreadTerminal(int pid, int terminal_id)
{
    JtmosHostInit();
    if(pid<0 || pid>=JTMOS_HOST_MAX_THREADS)
        return;
    pthread_mutex_lock(&thread_table_mutex);
    if(host_threads[pid].used)
        host_threads[pid].terminal_id = terminal_id;
    pthread_mutex_unlock(&thread_table_mutex);
}

void SetThreadPriority(uint32_t pid, unsigned char priority)
{
    JtmosHostInit();
    if(pid>=JTMOS_HOST_MAX_THREADS) return;
    pthread_mutex_lock(&thread_table_mutex);
    if(host_threads[pid].used) host_threads[pid].priority = priority;
    pthread_mutex_unlock(&thread_table_mutex);
}

unsigned char GetThreadPriority(uint32_t pid)
{
    unsigned char p = 0;
    if(pid>=JTMOS_HOST_MAX_THREADS) return 0;
    pthread_mutex_lock(&thread_table_mutex);
    if(host_threads[pid].used) p = host_threads[pid].priority;
    pthread_mutex_unlock(&thread_table_mutex);
    return p;
}

void IdentifyThread(uint32_t pid, const char *name)
{
    if(pid>=JTMOS_HOST_MAX_THREADS || !name) return;
    pthread_mutex_lock(&thread_table_mutex);
    if(host_threads[pid].used) {
        strncpy(host_threads[pid].name, name, JTMOS_HOST_NAME_LEN-1);
        host_threads[pid].name[JTMOS_HOST_NAME_LEN-1] = 0;
    }
    pthread_mutex_unlock(&thread_table_mutex);
}
void _IdentifyThread(uint32_t pid, const char *name) { IdentifyThread(pid, name); }

int GetThreadName(int pid, char *out)
{
    if(!out || pid<0 || pid>=JTMOS_HOST_MAX_THREADS) return -1;
    pthread_mutex_lock(&thread_table_mutex);
    if(!host_threads[pid].used) {
        pthread_mutex_unlock(&thread_table_mutex);
        return -1;
    }
    strcpy(out, host_threads[pid].name);
    pthread_mutex_unlock(&thread_table_mutex);
    return 0;
}

int GetThreadCount(void)
{
    int i, n=0;
    pthread_mutex_lock(&thread_table_mutex);
    for(i=0; i<JTMOS_HOST_MAX_THREADS; ++i) if(host_threads[i].used) ++n;
    pthread_mutex_unlock(&thread_table_mutex);
    return n;
}
uint32_t GetRunningThreadsCount(void) { return (uint32_t)GetThreadCount(); }

int SwitchToThread(void) { sched_yield(); return 0; }
int SwitchToThreadEx(int pid) { (void)pid; sched_yield(); return 0; }

void WaitProcessTermination(int pid)
{
    pthread_t th;
    if(pid<=0 || pid>=JTMOS_HOST_MAX_THREADS) return;
    pthread_mutex_lock(&thread_table_mutex);
    if(!host_threads[pid].used || host_threads[pid].joined) {
        pthread_mutex_unlock(&thread_table_mutex);
        return;
    }
    th = host_threads[pid].thread;
    host_threads[pid].joined = 1;
    pthread_mutex_unlock(&thread_table_mutex);
    pthread_join(th, NULL);
    pthread_mutex_lock(&thread_table_mutex);
    memset(&host_threads[pid], 0, sizeof(host_threads[pid]));
    pthread_mutex_unlock(&thread_table_mutex);
}

void KillThread(uint32_t pid)
{
    if(pid==0 || pid>=JTMOS_HOST_MAX_THREADS) return;
    pthread_mutex_lock(&thread_table_mutex);
    if(host_threads[pid].used)
        pthread_cancel(host_threads[pid].thread);
    pthread_mutex_unlock(&thread_table_mutex);
}
void KillThreadEx(uint32_t pid, uint32_t options) { (void)options; KillThread(pid); }
void ExitThread(int rval) { pthread_exit((void *)(intptr_t)rval); }
int jtmos_getpid(void) { return host_current_pid(); }

static uint64_t elapsed_ms(void)
{
    struct timespec now;
    uint64_t sec, nsec;
    clock_gettime(CLOCK_MONOTONIC, &now);
    sec = (uint64_t)(now.tv_sec - boot_time.tv_sec);
    if(now.tv_nsec >= boot_time.tv_nsec) {
        nsec = (uint64_t)(now.tv_nsec - boot_time.tv_nsec);
    } else {
        --sec;
        nsec = (uint64_t)(1000000000L + now.tv_nsec - boot_time.tv_nsec);
    }
    return sec*1000u + nsec/1000000u;
}

uint32_t GetTickCount(void) { JtmosHostInit(); return (uint32_t)elapsed_ms(); }
uint32_t GetTickCount2(void) { return GetTickCount(); }

void delay(uint32_t ms)
{
    struct timespec ts;
    ts.tv_sec = (time_t)(ms/1000u);
    ts.tv_nsec = (long)(ms%1000u)*1000000L;
    while(nanosleep(&ts, &ts)==-1) { }
}
void xsleep(uint32_t ms) { delay(ms); }
int jtmos_sleep(int seconds) { if(seconds>0) delay((uint32_t)seconds*1000u); return 0; }

void JtmosHostDisableInterrupts(void)
{
    JtmosHostInit();
    if(irq_depth++==0)
        pthread_mutex_lock(&irq_mutex);
}

void JtmosHostEnableInterrupts(void)
{
    if(irq_depth==0) return;
    if(--irq_depth==0)
        pthread_mutex_unlock(&irq_mutex);
}

uint32_t get_eflags(void)
{
    return irq_depth ? 0u : JTMOS_IF_FLAG;
}

void set_eflags(uint32_t flags)
{
    if(flags & JTMOS_IF_FLAG) {
        while(irq_depth) JtmosHostEnableInterrupts();
    } else if(!irq_depth) {
        JtmosHostDisableInterrupts();
    }
}

void idle_moment(void) { sched_yield(); }

void Lock(int id)
{
    JtmosHostInit();
    if(id<0 || id>=JTMOS_HOST_MAX_LOCKS) return;
    pthread_mutex_lock(&host_locks[id]);
}
void Unlock(int id)
{
    if(id<0 || id>=JTMOS_HOST_MAX_LOCKS) return;
    pthread_mutex_unlock(&host_locks[id]);
}

void outportb(uint16_t port, uint8_t value) { port_shadow[port] = (port_shadow[port]&0xffffff00u)|value; }
uint8_t inportb(uint16_t port) { return (uint8_t)port_shadow[port]; }
void outportw(uint16_t port, uint16_t value) { port_shadow[port] = (port_shadow[port]&0xffff0000u)|value; }
uint16_t inportw(uint16_t port) { return (uint16_t)port_shadow[port]; }
void outportd(uint32_t port, uint32_t value) { if(port<65536u) port_shadow[port] = value; }
uint32_t inportd(uint32_t port) { return port<65536u ? port_shadow[port] : 0u; }
void enable_irq(unsigned short irq) { if(irq<256) irq_enabled[irq]=1; }
void disable_irq(unsigned short irq) { if(irq<256) irq_enabled[irq]=0; }

void JtmosHostThreadCreateStack(JTMOS_HOST_THREAD_STACK *t, int stack_size)
{
    if(!t) return;
    t->pid = -1;
    t->stack = NULL;
    t->l_stack = 0;
    if(stack_size<=0) return;
    t->stack = (unsigned char *)malloc((size_t)stack_size);
    if(t->stack) t->l_stack = stack_size;
}
void JtmosHostThreadDestroyStack(JTMOS_HOST_THREAD_STACK *t)
{
    if(!t) return;
    free(t->stack);
    t->stack = NULL;
    t->l_stack = 0;
}
