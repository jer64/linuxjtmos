#ifndef JTMOS_LINUX_DIRECTDRAW_H
#define JTMOS_LINUX_DIRECTDRAW_H

/* Compatible subset used by the supplied JTMOS/GraOS sources. */
void DirectFillRect(unsigned char *dst, int width, int height,
                    int x, int y, int w, int h, unsigned char color);
void DirectDrawText(unsigned char *dst, int width, int height,
                    const char *text, int x, int y);

#endif
