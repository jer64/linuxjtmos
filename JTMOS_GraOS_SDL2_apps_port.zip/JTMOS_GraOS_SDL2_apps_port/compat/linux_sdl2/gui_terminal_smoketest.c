#include "gui_terminal.h"
#include "jtmos_host_chiplevel.h"
#include "jtmos_host_term.h"
#include "graos_sdl2_bridge.h"
#include "vesa.h"
#include <stdio.h>

int main(void)
{
    int window_id, terminal_id, i, nonzero=0;

    if(JtmosHostInit()!=0) return 1;
    VirtualTerminalInit();
    if(!VesaSetup()) return 2;
    GuiTerminalInit();

    window_id=GuiTerminalCreate(8,8,40,12,"Virtual terminal");
    if(window_id<0) return 3;
    terminal_id=GuiTerminalGetTerminal(window_id);
    if(terminal_id<10) return 4;

    SetThreadTerminal(GetCurrentThread(),terminal_id);
    sputs(&screens[terminal_id],"JTMOS SDL2 virtual terminal\nwrapper test OK");
    GuiTerminalSetFocus(window_id);
    GuiTerminalTick();

    for(i=0;i<VesaGetWidth()*VesaGetHeight();i++)
        if(vesa_frame_buf[i]) nonzero++;
    if(nonzero<20) return 5;

    GuiTerminalFocusedKey('A');
    if(InputTerminalKeyboardBuffer(&screens[terminal_id])!='A') return 6;

    printf("GUI integration OK: window=%d terminal=%d pixels=%d\n",
           window_id,terminal_id,nonzero);
    JtmosSDL2GraOSShutdown();
    return 0;
}
