#ifndef JTMOS_TYPES_COMPAT_H
#define JTMOS_TYPES_COMPAT_H

#ifdef JTMOSVERSION
/* Native JTMOS builds are expected to include their normal base/kernel types. */
#else
#include <stdint.h>
typedef uint8_t BYTE;
typedef uint16_t WORD;
typedef uint32_t DWORD;
#endif

#endif
