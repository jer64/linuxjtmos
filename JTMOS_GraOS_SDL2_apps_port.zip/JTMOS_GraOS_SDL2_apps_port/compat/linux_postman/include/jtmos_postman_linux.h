#ifndef JTMOS_POSTMAN_LINUX_H
#define JTMOS_POSTMAN_LINUX_H

#include <stddef.h>
#include <stdint.h>
#include "msgbox.h"
#include "postman.h"

#ifdef __cplusplus
extern "C" {
#endif

#define JTMOS_LINUX_POSTMAN_VERSION 1u
#define JTMOS_LINUX_POSTMAN_MAX_TRANSFER (1024u * 1024u)

/* Linux process ID is used as the default portable JTMOS IPC ID. */
int JtmosLinuxGetCurrentThread(void);
int JtmosLinuxIPCInit(void);
void JtmosLinuxIPCShutdown(void);
int JtmosLinuxIPCEnsureBroker(void);
int JtmosLinuxIPCStopBroker(void);
const char *JtmosLinuxIPCSocketPath(void);

/* Synchronous host-side equivalent of SYS_POSTCMD / PostmanPost. */
int JtmosLinuxPostmanCall(POSTMANCMD *p);

/* Local host service hook, useful for SDL2/GraOS multimedia commands. */
typedef int (*JTMOS_LINUX_POST_SERVICE)(POSTMANCMD *p, void *opaque);
int JtmosLinuxPostmanRegisterLocalService(int first_id, int last_id,
                                         JTMOS_LINUX_POST_SERVICE fn,
                                         void *opaque);
void JtmosLinuxPostmanClearLocalServices(void);

#ifdef JTMOS_LINUX_REMAP_LEGACY_THREAD_API
#define GetCurrentThread() JtmosLinuxGetCurrentThread()
#endif

#ifdef __cplusplus
}
#endif
#endif
