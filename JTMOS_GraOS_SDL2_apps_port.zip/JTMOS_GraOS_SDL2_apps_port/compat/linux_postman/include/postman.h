#ifndef __INCLUDED_POSTMAN_H__
#define __INCLUDED_POSTMAN_H__

#include "msgbox.h"

#define SERVICE_RESTART_SECONDS (60*5)

#define KFILESYS_1 0
#define KFILESYS_2 999
#define PCMD_CREATE_FILE       1
#define PCMD_DELETE_FILE       2
#define PCMD_WRITE_FILE        3
#define PCMD_READ_FILE         4
#define PCMD_GET_FILE_SIZE     5
#define PCMD_ADD_BLOCKS        6
#define PCMD_EXIST             7
#define PCMD_READBLOCK         8
#define PCMD_WRITEBLOCK        9
#define PCMD_FINDFIRST         10
#define PCMD_FINDNEXT          11
#define PCMD_RENAME_FILE       12
#define PCMD_SETSIZE           13
#define PCMD_GETFILEDATABLOCK  14
#define PCMD_CREATEDIRECTORY   15
#define PCMD_FORMATDRIVE       16
#define PCMD_CLOSE             17
#define PCMD_CHDIR             18
#define PCMD_IS_DRIVE_READY    19
#define PCMD_GETCWD            20

#define KMULTIMEDIA_1 1000
#define KMULTIMEDIA_2 2999
#define PCMD_SETMODE           1000
#define PCMD_DRAWFRAME         1001
#define PCMD_SETPALETTE        1002
#define PCMD_SETPALETTEMAP     1003
#define PCMD_INITAUDIO         2000
#define PCMD_SENDAUDIO         2001
#define PCMD_GETAUDIOPOSITION  2002

#define N_MAX_POSTMAN_POSTS 50
#define POSTMAN_MAGIC 0xFCE2E37Bu

typedef struct {
    DWORD magic;
    int *acknowledged;
    int *rv;
    int id;
    char *par1,*par2,*par3,*par4,*par5,*par6,*par7,*par8;
    int v1,v2,v3,v4;
    int dnr,db,pid;
} POSTMANCMD;

typedef struct { POSTMANCMD post[N_MAX_POSTMAN_POSTS]; } POSTMAN;

typedef struct {
    POSTMANCMD *p;
    MSG tmp;
    int id;
    int t;
} PSERVICE;

extern POSTMAN postman;
extern int postmanPID;

void postman_init(void);
int postman_postrequest(POSTMANCMD *p);
void postmanThread(void);

#endif
