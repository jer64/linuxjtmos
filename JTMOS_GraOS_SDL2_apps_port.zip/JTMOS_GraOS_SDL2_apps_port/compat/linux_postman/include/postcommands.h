#ifndef __INCLUDED_POSTCOMMANDS_H__
#define __INCLUDED_POSTCOMMANDS_H__
#include "postman.h"

DWORD post_exist(POSTMANCMD *post, const char *fname);
DWORD post_create(POSTMANCMD *post, const char *fname, int flags);
DWORD post_delete(POSTMANCMD *post, const char *fname);
DWORD post_get_file_size(POSTMANCMD *post, const char *fname);
int post_read_file(POSTMANCMD *post, const char *fname, void *buf, int amount, int offset);
int post_write_file(POSTMANCMD *post, const char *fname, const void *buf, int amount, int offset);
int post_rename_file(POSTMANCMD *post, const char *oldname, const char *newname);
int post_mkdir(POSTMANCMD *post, const char *path);
int post_chdir(POSTMANCMD *post, const char *path);
int post_getcwd(POSTMANCMD *post, char *buf, int size);
#endif
