#define _GNU_SOURCE
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include "jtmos_postman_linux.h"

int main(void)
{
    int ready[2], go[2];
    pid_t child;
    int i, status;
    if (pipe(ready) || pipe(go)) return 1;
    child = fork();
    if (child < 0) return 2;
    if (child == 0) {
        char c;
        MSG m;
        close(ready[0]); close(go[1]);
        if (JtmosLinuxIPCInit() != 0) _exit(3);
        c='R'; if (write(ready[1], &c, 1) != 1) _exit(4);
        if (read(go[0], &c, 1) != 1) _exit(5);
        for (i=0; i<N_MAX_QUEUED_MSGS; ++i) {
            int tries;
            for (tries=0; tries<100 && !receiveMessage(&m); ++tries) usleep(1000);
            if (tries == 100 || m.type != i || m.buf[0] != (BYTE)('0'+i)) _exit(10+i);
        }
        if (receiveMessage(&m)) _exit(30);
        _exit(0);
    }
    close(ready[1]); close(go[0]);
    {
        char c;
        if (read(ready[0], &c, 1) != 1) return 3;
    }
    for (i=0; i<N_MAX_QUEUED_MSGS; ++i) {
        MSG m;
        memset(&m,0,sizeof(m)); m.protocol=MB_PROTOCOL_GRAOS; m.type=i; m.amount=1; m.buf[0]=(BYTE)('0'+i);
        if (sendMessage(&m,(int)child)!=0) { kill(child,SIGKILL); return 4; }
    }
    {
        MSG m;
        memset(&m,0,sizeof(m)); m.protocol=MB_PROTOCOL_GRAOS; m.amount=1; m.buf[0]='X';
        if (sendMessage(&m,(int)child)!=1) { kill(child,SIGKILL); return 5; }
        m.protocol=123;
        if (sendMessage(&m,(int)child)!=10) { kill(child,SIGKILL); return 6; }
    }
    {
        char c='G'; if (write(go[1],&c,1)!=1) { kill(child,SIGKILL); return 7; }
    }
    waitpid(child,&status,0);
    if (!WIFEXITED(status) || WEXITSTATUS(status)!=0) return 8;
    puts("Mailbox depth/order/protocol semantics OK");
    return 0;
}
