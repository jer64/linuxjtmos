#define _GNU_SOURCE
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include "jtmos_postman_linux.h"

int main(void)
{
    int ready[2];
    pid_t child;
    if (pipe(ready) != 0) { perror("pipe"); return 1; }
    if (JtmosLinuxIPCEnsureBroker() != 0) { fprintf(stderr, "broker start failed\n"); return 1; }
    child = fork();
    if (child < 0) { perror("fork"); return 1; }
    if (child == 0) {
        MSG m;
        char c = 'R';
        int tries;
        close(ready[0]);
        if (JtmosLinuxIPCInit() != 0) _exit(2);
        if (write(ready[1], &c, 1) != 1) _exit(3);
        for (tries = 0; tries < 500; ++tries) {
            if (receiveMessage(&m)) {
                if (m.protocol != MB_PROTOCOL_GRAOS || strcmp((char *)m.buf, "hello from Linux Postman") != 0)
                    _exit(4);
                printf("receiver pid=%d got #%u from pid=%d: %s\n",
                       JtmosLinuxGetCurrentThread(), (unsigned)m.un, m.sndPID, (char *)m.buf);
                fflush(stdout);
                _exit(0);
            }
            usleep(10000);
        }
        _exit(5);
    }
    close(ready[1]);
    {
        char c;
        MSG m;
        int status;
        if (read(ready[0], &c, 1) != 1) return 1;
        memset(&m, 0, sizeof(m));
        m.protocol = MB_PROTOCOL_GRAOS;
        strcpy((char *)m.buf, "hello from Linux Postman");
        m.amount = (int)strlen((char *)m.buf) + 1;
        if (sendMessage(&m, (int)child) != 0) {
            fprintf(stderr, "sendMessage failed\n"); kill(child, SIGKILL); return 1;
        }
        waitpid(child, &status, 0);
        if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
            fprintf(stderr, "child failed: %d\n", status); return 1;
        }
        printf("IPC smoke test OK, sender=%d receiver=%d packet=%u\n",
               JtmosLinuxGetCurrentThread(), (int)child, (unsigned)m.un);
    }
    return 0;
}
