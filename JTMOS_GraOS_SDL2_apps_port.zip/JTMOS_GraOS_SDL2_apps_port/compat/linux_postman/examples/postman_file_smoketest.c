#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "jtmos_postman_linux.h"
#include "postcommands.h"

int main(void)
{
    POSTMANCMD p;
    char path[256], renamed[256], out[128];
    const char data[] = "JTMOS Postman portable file service\n";
    snprintf(path, sizeof(path), "/tmp/jtmos-postman-test-%d.txt", JtmosLinuxGetCurrentThread());
    snprintf(renamed, sizeof(renamed), "/tmp/jtmos-postman-test-%d-renamed.txt", JtmosLinuxGetCurrentThread());
    unlink(path); unlink(renamed);

    if (post_create(&p, path, 0) != 0) return 1;
    if (post_write_file(&p, path, data, (int)sizeof(data), 0) < 0) return 2;
    if (post_exist(&p, path) != 1) return 3;
    if (post_get_file_size(&p, path) != sizeof(data)) return 4;
    memset(out, 0, sizeof(out));
    if (post_read_file(&p, path, out, (int)sizeof(data), 0) < 0) return 5;
    if (memcmp(out, data, sizeof(data)) != 0) return 6;
    if (post_rename_file(&p, path, renamed) != 0) return 7;
    if (post_exist(&p, path) != 0 || post_exist(&p, renamed) != 1) return 8;
    if (post_delete(&p, renamed) != 0) return 9;
    puts("Postman file service smoke test OK");
    return 0;
}
