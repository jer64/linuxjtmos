/* Example: keep SDL2/GraOS multimedia operations inside the GUI process. */
#include <stdio.h>
#include "jtmos_postman_linux.h"
#include "postcmds_com.h"

static int graos_multimedia_service(POSTMANCMD *p, void *opaque)
{
    (void)opaque;
    switch (p->id) {
    case PCMD_SETMODE:
        printf("GraOS host setmode request: %d x %d\n", p->v1, p->v2);
        if (p->rv) *p->rv = 0;
        if (p->acknowledged) *p->acknowledged = 1;
        return 0;
    default:
        return 95; /* ENOTSUP on Linux, kept literal for tiny cross-build demos. */
    }
}

int main(void)
{
    POSTMANCMD p;
    int ack = 0, rv = 0;
    JtmosLinuxPostmanRegisterLocalService(KMULTIMEDIA_1, KMULTIMEDIA_2,
                                          graos_multimedia_service, NULL);
    p = (POSTMANCMD){0};
    p.id = PCMD_SETMODE; p.v1 = 640; p.v2 = 480; p.acknowledged = &ack; p.rv = &rv;
    if (PostmanPost(&p) != 0 || !ack || rv != 0) return 1;
    return 0;
}
