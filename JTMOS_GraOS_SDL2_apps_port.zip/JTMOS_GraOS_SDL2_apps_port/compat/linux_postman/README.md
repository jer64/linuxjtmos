# JTMOS Postman Linux compatibility wrapper

This directory ports the JTMOS Message Box / Postman programming model to normal
Linux user space. The goal is source portability: application code can keep using
`MSG`, `sendMessage()`, `receiveMessage()`, `ActivateThreadMessageBox()`,
`POSTMANCMD` and `PostmanPost()` while the backend changes at build time.

## Architecture

Native JTMOS:

    application -> SYS_POSTCMD / msgbox -> kernel Postman -> JTMOS services

Linux host:

    application -> libjtmospostman.a -> Unix-domain socket -> jtmos-postman broker
                                               |-> mailbox queues
                                               |-> POSIX file service

The Linux broker is automatically started on first use, or can be run explicitly
with `./jtmos-postmand`. The socket is per-user:

    /tmp/jtmos-postman-<uid>.sock

and is mode 0600.

## Important ABI rule: POSTMANCMD pointers are never put on the wire

The original `POSTMANCMD` contains process pointers (`rv`, `acknowledged`, and
`par1..par8`). Such addresses are meaningful in the JTMOS design but invalid in
a different Linux process. The Linux wrapper therefore marshals known Postman
commands into a pointer-free wire packet, sends the pointed-to data, and copies
returned data back into the caller's original buffers.

The source-side `POSTMANCMD` layout is retained so portable applications do not
need a second application data model.

## Generic Message Box compatibility

The following legacy functions are exported:

    ActivateThreadMessageBox(pid)
    sendMessage(&msg, pid)
    receiveMessage(&msg)
    VerifyMessage(&msg)
    createMessageBox()
    initMessageBox()

Linux uses the OS process ID as the portable JTMOS IPC ID. This gives stable IDs
between separate processes and matches the original PPCS intent. A sender's PID,
receiver PID, magic values, reserved/free state and global packet number are
filled by the broker.

Each mailbox has five entries (`N_MAX_QUEUED_MSGS`) to match the supplied JTMOS
header. `sendMessage()` returns 1 if the target queue is full/unavailable and 10
for an unknown protocol, preserving the old interface's key return values.

## Postman commands currently mapped to POSIX

Supported by the central Linux service:

- PCMD_EXIST
- PCMD_CREATE_FILE
- PCMD_DELETE_FILE
- PCMD_WRITE_FILE (up to 1 MiB per call)
- PCMD_READ_FILE (up to 1 MiB per call)
- PCMD_GET_FILE_SIZE
- PCMD_RENAME_FILE
- PCMD_SETSIZE
- PCMD_CREATEDIRECTORY
- PCMD_IS_DRIVE_READY

`PCMD_CHDIR` and `PCMD_GETCWD` are intentionally executed inside the calling
Linux process rather than in the broker, because cwd is process-local on Linux.

Raw disk block operations, JTMFS data-block lookup, formatting, and directory
FFBLK iteration are not silently guessed. They currently return ENOTSUP until a
portable representation is defined.

## GraOS / SDL2 services

SDL resources must remain in the process that owns the SDL renderer/window.
For that reason the wrapper has a local service hook:

    JtmosLinuxPostmanRegisterLocalService(first_id, last_id, callback, opaque);

Register `KMULTIMEDIA_1..KMULTIMEDIA_2` from the GraOS SDL2 process. The same
application can then continue to issue Postman multimedia command IDs while the
Linux build dispatches them to the SDL2 adapter rather than a remote daemon.
See `examples/graos_service_example.c`.

## Build and test

    make
    make check

Programs can link with:

    cc -Iinclude myapp.c libjtmospostman.a -o myapp

For a host source file that expects `GetCurrentThread()` to mean the portable IPC
process ID, include `jtmos_postman_linux.h` with:

    #define JTMOS_LINUX_REMAP_LEGACY_THREAD_API
    #include "jtmos_postman_linux.h"

Do not enable that remap inside the existing SDL2 chiplevel scheduler wrapper,
because that wrapper has its own process-local pthread scheduler IDs. Use the
explicit `JtmosLinuxGetCurrentThread()` where both layers coexist.

## Cross-building the same application

Keep OS-specific selection in one small portability header:

    #ifdef JTMOSVERSION
    # include "kernel32.h"
    # include "msgbox.h"
    # include "postman.h"
    #else
    # include "jtmos_postman_linux.h"
    #endif

The application's packet construction and Postman command IDs can remain common.
