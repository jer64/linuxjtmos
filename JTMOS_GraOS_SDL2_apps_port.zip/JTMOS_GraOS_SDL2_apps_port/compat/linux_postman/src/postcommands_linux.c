#include <errno.h>
#include <string.h>
#include "jtmos_postman_linux.h"
#include "postcommands.h"

static void prep(POSTMANCMD *p, int id, int *ack, int *rv)
{
    memset(p, 0, sizeof(*p));
    p->id = id;
    p->acknowledged = ack;
    p->rv = rv;
    *ack = 0;
    *rv = 0;
}

DWORD post_exist(POSTMANCMD *p, const char *fname)
{
    int ack, rv;
    if (!p || !fname || !*fname) return 0;
    prep(p, PCMD_EXIST, &ack, &rv); p->par1 = (char *)fname;
    (void)JtmosLinuxPostmanCall(p);
    p->acknowledged = NULL; p->rv = NULL;
    return (DWORD)rv;
}

DWORD post_create(POSTMANCMD *p, const char *fname, int flags)
{
    int ack, rv;
    (void)flags;
    if (!p || !fname || !*fname) return (DWORD)EINVAL;
    prep(p, PCMD_CREATE_FILE, &ack, &rv); p->par1 = (char *)fname;
    (void)JtmosLinuxPostmanCall(p);
    p->acknowledged = NULL; p->rv = NULL;
    return (DWORD)rv;
}

DWORD post_delete(POSTMANCMD *p, const char *fname)
{
    int ack, rv;
    if (!p || !fname || !*fname) return (DWORD)EINVAL;
    prep(p, PCMD_DELETE_FILE, &ack, &rv); p->par1 = (char *)fname;
    (void)JtmosLinuxPostmanCall(p);
    p->acknowledged = NULL; p->rv = NULL;
    return (DWORD)rv;
}

DWORD post_get_file_size(POSTMANCMD *p, const char *fname)
{
    int ack, rv;
    if (!p || !fname || !*fname) return 0;
    prep(p, PCMD_GET_FILE_SIZE, &ack, &rv); p->par1 = (char *)fname;
    (void)JtmosLinuxPostmanCall(p);
    p->acknowledged = NULL; p->rv = NULL;
    return (DWORD)rv;
}

int post_read_file(POSTMANCMD *p, const char *fname, void *buf, int amount, int offset)
{
    int ack, rv, rc;
    if (!p || !fname || !buf || amount <= 0) return EINVAL;
    prep(p, PCMD_READ_FILE, &ack, &rv); p->par1 = (char *)fname; p->par2 = (char *)buf; p->v1 = amount; p->v2 = offset;
    rc = JtmosLinuxPostmanCall(p);
    p->acknowledged = NULL; p->rv = NULL;
    return rc;
}

int post_write_file(POSTMANCMD *p, const char *fname, const void *buf, int amount, int offset)
{
    int ack, rv, rc;
    if (!p || !fname || !buf || amount <= 0) return EINVAL;
    prep(p, PCMD_WRITE_FILE, &ack, &rv); p->par1 = (char *)fname; p->par2 = (char *)(uintptr_t)buf; p->v1 = amount; p->v2 = offset;
    rc = JtmosLinuxPostmanCall(p);
    p->acknowledged = NULL; p->rv = NULL;
    return rc;
}

int post_rename_file(POSTMANCMD *p, const char *oldname, const char *newname)
{
    int ack, rv, rc;
    if (!p || !oldname || !newname) return EINVAL;
    prep(p, PCMD_RENAME_FILE, &ack, &rv); p->par1 = (char *)oldname; p->par2 = (char *)newname;
    rc = JtmosLinuxPostmanCall(p);
    p->acknowledged = NULL; p->rv = NULL;
    return rc;
}

int post_mkdir(POSTMANCMD *p, const char *path)
{
    int ack, rv, rc;
    if (!p || !path) return EINVAL;
    prep(p, PCMD_CREATEDIRECTORY, &ack, &rv); p->par1 = (char *)path;
    rc = JtmosLinuxPostmanCall(p);
    p->acknowledged = NULL; p->rv = NULL;
    return rc;
}

int post_chdir(POSTMANCMD *p, const char *path)
{
    int ack, rv, rc;
    if (!p || !path) return EINVAL;
    prep(p, PCMD_CHDIR, &ack, &rv); p->par1 = (char *)path;
    rc = JtmosLinuxPostmanCall(p);
    p->acknowledged = NULL; p->rv = NULL;
    return rc;
}

int post_getcwd(POSTMANCMD *p, char *buf, int size)
{
    int ack, rv, rc;
    if (!p || !buf || size <= 0) return EINVAL;
    prep(p, PCMD_GETCWD, &ack, &rv); p->par1 = buf; p->v1 = size;
    rc = JtmosLinuxPostmanCall(p);
    p->acknowledged = NULL; p->rv = NULL;
    return rc;
}
