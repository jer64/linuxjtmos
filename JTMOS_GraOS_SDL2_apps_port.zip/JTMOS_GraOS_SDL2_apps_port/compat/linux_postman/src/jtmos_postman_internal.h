#ifndef JTMOS_POSTMAN_INTERNAL_H
#define JTMOS_POSTMAN_INTERNAL_H
#include <stddef.h>
#include <stdint.h>
#include "jtmos_postman_wire.h"

int jtmos_ipc_request(const JTMOS_IPC_HDR *req, const void *payload,
                      JTMOS_IPC_HDR *resp, void *out, size_t out_cap,
                      size_t *out_len);
int jtmos_broker_run(void);
int jtmos_postman_service_handle(const JTMOS_POST_WIRE_REQ *req,
                                 const unsigned char *payload,
                                 size_t payload_len,
                                 JTMOS_POST_WIRE_RESP *resp,
                                 unsigned char **out_data);
#endif
