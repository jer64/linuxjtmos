#define _GNU_SOURCE
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "jtmos_postman_linux.h"
#include "postcmds_com.h"
#include "jtmos_postman_internal.h"

POSTMAN postman;
int postmanPID;

#define MAX_LOCAL_SERVICES 16
typedef struct {
    int used, first_id, last_id;
    JTMOS_LINUX_POST_SERVICE fn;
    void *opaque;
} LOCAL_SERVICE;
static LOCAL_SERVICE local_services[MAX_LOCAL_SERVICES];

static int run_local_service(POSTMANCMD *p, int *handled)
{
    int i;
    *handled = 0;
    for (i = 0; i < MAX_LOCAL_SERVICES; ++i) {
        if (local_services[i].used && p->id >= local_services[i].first_id &&
            p->id <= local_services[i].last_id) {
            *handled = 1;
            return local_services[i].fn(p, local_services[i].opaque);
        }
    }
    return ENOTSUP;
}

int JtmosLinuxPostmanRegisterLocalService(int first_id, int last_id,
                                         JTMOS_LINUX_POST_SERVICE fn,
                                         void *opaque)
{
    int i;
    if (!fn || first_id > last_id) return 1;
    for (i = 0; i < MAX_LOCAL_SERVICES; ++i) {
        if (!local_services[i].used) {
            local_services[i].used = 1;
            local_services[i].first_id = first_id;
            local_services[i].last_id = last_id;
            local_services[i].fn = fn;
            local_services[i].opaque = opaque;
            return 0;
        }
    }
    return 1;
}

void JtmosLinuxPostmanClearLocalServices(void)
{
    memset(local_services, 0, sizeof(local_services));
}

static int set_ack(POSTMANCMD *p, int rv, int ack)
{
    if (p->rv) *p->rv = rv;
    if (p->acknowledged) *p->acknowledged = ack;
    return rv;
}

static int local_cwd_command(POSTMANCMD *p, int *handled)
{
    *handled = 1;
    if (p->id == PCMD_CHDIR) {
        if (!p->par1) return set_ack(p, EINVAL, 1);
        return set_ack(p, chdir(p->par1) == 0 ? 0 : errno, 1);
    }
    if (p->id == PCMD_GETCWD) {
        if (!p->par1 || p->v1 <= 0) return set_ack(p, EINVAL, 1);
        if (!getcwd(p->par1, (size_t)p->v1)) return set_ack(p, errno, 1);
        return set_ack(p, 0, 1);
    }
    *handled = 0;
    return 0;
}

static int append_arg(unsigned char *dst, size_t cap, size_t *off,
                      const void *src, size_t len)
{
    if (len > cap - *off) return 1;
    if (len) memcpy(dst + *off, src, len);
    *off += len;
    return 0;
}

int JtmosLinuxPostmanCall(POSTMANCMD *p)
{
    JTMOS_POST_WIRE_REQ wr;
    JTMOS_POST_WIRE_RESP wresp;
    JTMOS_IPC_HDR req, resp;
    unsigned char *payload = NULL;
    unsigned char *reply = NULL;
    size_t payload_len = 0, reply_len = 0, off = 0;
    size_t a1 = 0, a2 = 0;
    int handled, lr, rc = 0;

    if (!p) return EINVAL;
    p->magic = POSTMAN_MAGIC;
    p->pid = JtmosLinuxGetCurrentThread();

    lr = local_cwd_command(p, &handled);
    if (handled) return lr;
    lr = run_local_service(p, &handled);
    if (handled) return lr;

    memset(&wr, 0, sizeof(wr));
    wr.id = p->id; wr.v1 = p->v1; wr.v2 = p->v2; wr.v3 = p->v3; wr.v4 = p->v4;
    wr.dnr = p->dnr; wr.db = p->db; wr.pid = p->pid;

    switch (p->id) {
    case PCMD_EXIST:
    case PCMD_CREATE_FILE:
    case PCMD_DELETE_FILE:
    case PCMD_GET_FILE_SIZE:
    case PCMD_SETSIZE:
    case PCMD_CREATEDIRECTORY:
    case PCMD_READ_FILE:
        if (!p->par1) return set_ack(p, EINVAL, 1);
        a1 = strlen(p->par1) + 1u;
        break;
    case PCMD_RENAME_FILE:
        if (!p->par1 || !p->par2) return set_ack(p, EINVAL, 1);
        a1 = strlen(p->par1) + 1u;
        a2 = strlen(p->par2) + 1u;
        break;
    case PCMD_WRITE_FILE:
        if (!p->par1 || !p->par2 || p->v1 <= 0 ||
            (uint32_t)p->v1 > JTMOS_LINUX_POSTMAN_MAX_TRANSFER)
            return set_ack(p, EINVAL, 1);
        a1 = strlen(p->par1) + 1u;
        a2 = (size_t)p->v1;
        break;
    case PCMD_IS_DRIVE_READY:
        break;
    default:
        return set_ack(p, ENOTSUP, 2);
    }

    if (a1 > 4096u || a2 > JTMOS_LINUX_POSTMAN_MAX_TRANSFER) return set_ack(p, E2BIG, 1);
    wr.arg1_len = (uint32_t)a1;
    wr.arg2_len = (uint32_t)a2;
    payload_len = sizeof(wr) + a1 + a2;
    payload = (unsigned char *)malloc(payload_len ? payload_len : 1u);
    if (!payload) return set_ack(p, ENOMEM, 1);
    memcpy(payload, &wr, sizeof(wr)); off = sizeof(wr);
    if (append_arg(payload, payload_len, &off, p->par1, a1) ||
        append_arg(payload, payload_len, &off, p->par2, a2)) {
        free(payload); return set_ack(p, EINVAL, 1);
    }

    memset(&req, 0, sizeof(req));
    req.magic = JTMOS_IPC_WIRE_MAGIC;
    req.version = JTMOS_IPC_WIRE_VERSION;
    req.op = JTMOS_IPC_OP_POSTCALL;
    req.src = p->pid;
    req.payload_len = (uint32_t)payload_len;

    reply = (unsigned char *)malloc(sizeof(wresp) + JTMOS_LINUX_POSTMAN_MAX_TRANSFER);
    if (!reply) { free(payload); return set_ack(p, ENOMEM, 1); }
    if (jtmos_ipc_request(&req, payload, &resp, reply,
                          sizeof(wresp) + JTMOS_LINUX_POSTMAN_MAX_TRANSFER,
                          &reply_len) != 0) {
        rc = EIO; goto out;
    }
    if (resp.status != 0) { rc = resp.status; goto out; }
    if (reply_len < sizeof(wresp)) { rc = EPROTO; goto out; }
    memcpy(&wresp, reply, sizeof(wresp));
    if (reply_len != sizeof(wresp) + wresp.data_len) { rc = EPROTO; goto out; }

    if (p->id == PCMD_READ_FILE && wresp.data_len) {
        if (!p->par2 || wresp.data_len > (uint32_t)p->v1) { rc = EFAULT; goto out; }
        memcpy(p->par2, reply + sizeof(wresp), wresp.data_len);
    }
    rc = wresp.rv;
    set_ack(p, wresp.rv, wresp.acknowledged);
out:
    free(reply);
    free(payload);
    if (rc != 0 && (!p->acknowledged || *p->acknowledged == 0)) set_ack(p, rc, 1);
    return rc;
}

int PostmanPost(POSTMANCMD *p) { return JtmosLinuxPostmanCall(p); }
int postman_postrequest(POSTMANCMD *p) { return JtmosLinuxPostmanCall(p); }
int PostmanWaitAck(POSTMANCMD *p)
{
    if (!p) return EINVAL;
    if (p->acknowledged && *p->acknowledged) return p->rv ? *p->rv : 0;
    return JtmosLinuxPostmanCall(p);
}
void postman_SetReturnValue(POSTMANCMD *p, int val) { if (p && p->rv) *p->rv = val; }
void PostmanAckPacket(POSTMANCMD *p, int whichAck)
{
    (void)whichAck;
    if (!p) return;
    if (p->acknowledged) *p->acknowledged = 1;
    p->id = 0;
}
void postman_init(void)
{
    memset(&postman, 0, sizeof(postman));
    postmanPID = JtmosLinuxGetCurrentThread();
    (void)JtmosLinuxIPCInit();
}
void postmanThread(void) { /* Linux broker replaces the kernel polling thread. */ }
