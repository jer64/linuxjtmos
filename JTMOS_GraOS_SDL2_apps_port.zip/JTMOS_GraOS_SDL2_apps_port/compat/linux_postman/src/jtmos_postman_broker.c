#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/un.h>
#include <unistd.h>

#include "jtmos_postman_internal.h"
#include "jtmos_postman_linux.h"

#define MAX_MAILBOXES 1024

typedef struct {
    int used;
    int id;
    MSG q[N_MAX_QUEUED_MSGS];
} HOST_MAILBOX;

static HOST_MAILBOX mailboxes[MAX_MAILBOXES];
static uint32_t global_message_number;
static volatile sig_atomic_t broker_quit;

static int write_full(int fd, const void *buf, size_t len)
{
    const unsigned char *p = (const unsigned char *)buf;
    while (len) {
        ssize_t n = write(fd, p, len);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) return -1;
        p += (size_t)n;
        len -= (size_t)n;
    }
    return 0;
}

static int read_full(int fd, void *buf, size_t len)
{
    unsigned char *p = (unsigned char *)buf;
    while (len) {
        ssize_t n = read(fd, p, len);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) return -1;
        p += (size_t)n;
        len -= (size_t)n;
    }
    return 0;
}

static int process_exists(int pid)
{
    if (pid <= 0) return 0;
    if (kill((pid_t)pid, 0) == 0) return 1;
    return errno == EPERM;
}

static HOST_MAILBOX *find_mailbox(int id, int create)
{
    int i;
    HOST_MAILBOX *free_box = NULL;
    for (i = 0; i < MAX_MAILBOXES; ++i) {
        if (mailboxes[i].used && mailboxes[i].id == id) return &mailboxes[i];
        if (!mailboxes[i].used && free_box == NULL) free_box = &mailboxes[i];
    }
    if (!create || free_box == NULL) return NULL;
    memset(free_box, 0, sizeof(*free_box));
    free_box->used = 1;
    free_box->id = id;
    for (i = 0; i < N_MAX_QUEUED_MSGS; ++i) free_box->q[i].isFree = MSG_FREE;
    return free_box;
}

static int valid_protocol(int protocol)
{
    return protocol == MB_PROTOCOL_DC ||
           protocol == MB_PROTOCOL_POSTMAN ||
           protocol == MB_PROTOCOL_GRAOS;
}

static int broker_send_message(const JTMOS_IPC_HDR *h, MSG *m)
{
    HOST_MAILBOX *box;
    int i;
    if (!process_exists(h->dst)) return 1;
    if (!valid_protocol(m->protocol)) return 10;
    if (m->amount < 0 || m->amount > N_MAX_BYTES_PER_MSG) return 1;

    box = find_mailbox(h->dst, 1);
    if (box == NULL) return 1;
    for (i = 0; i < N_MAX_QUEUED_MSGS; ++i) {
        if (box->q[i].isFree == MSG_FREE) {
            m->isFree = MSG_RESERVED;
            m->sndPID = h->src;
            m->rcvPID = h->dst;
            m->magic1 = MSGBOX_MAGIC1;
            m->magic2 = MSGBOX_MAGIC2;
            m->un = global_message_number++;
            memcpy(&box->q[i], m, sizeof(*m));
            return 0;
        }
    }
    return 1;
}

static int broker_recv_message(int id, MSG *out)
{
    HOST_MAILBOX *box = find_mailbox(id, 1);
    uint32_t age = UINT32_MAX;
    int chosen = -1;
    int i;
    if (box == NULL) return 0;
    for (i = 0; i < N_MAX_QUEUED_MSGS; ++i) {
        MSG *m = &box->q[i];
        if (m->isFree != MSG_RESERVED) continue;
        if (m->magic1 != MSGBOX_MAGIC1 || m->magic2 != MSGBOX_MAGIC2) {
            m->isFree = MSG_FREE;
            continue;
        }
        if (chosen < 0 || m->un <= age) {
            chosen = i;
            age = m->un;
        }
    }
    if (chosen < 0) return 0;
    memcpy(out, &box->q[chosen], sizeof(*out));
    box->q[chosen].isFree = MSG_FREE;
    return 1;
}

static void broker_signal(int sig)
{
    (void)sig;
    broker_quit = 1;
}

static int handle_connection(int cfd)
{
    JTMOS_IPC_HDR req, resp;
    struct ucred cred;
    socklen_t cred_len = sizeof(cred);
    unsigned char *payload = NULL;
    unsigned char *out = NULL;
    size_t out_len = 0;

    if (getsockopt(cfd, SOL_SOCKET, SO_PEERCRED, &cred, &cred_len) != 0) return -1;
    if (read_full(cfd, &req, sizeof(req)) != 0) return -1;
    if (req.magic != JTMOS_IPC_WIRE_MAGIC || req.version != JTMOS_IPC_WIRE_VERSION)
        return -1;
    /* Never trust a caller-supplied sender ID on Linux. */
    req.src = (int32_t)cred.pid;
    if (req.payload_len > JTMOS_LINUX_POSTMAN_MAX_TRANSFER + sizeof(MSG) + 4096u)
        return -1;

    if (req.payload_len) {
        payload = (unsigned char *)malloc(req.payload_len);
        if (!payload) return -1;
        if (read_full(cfd, payload, req.payload_len) != 0) {
            free(payload);
            return -1;
        }
    }

    memset(&resp, 0, sizeof(resp));
    resp.magic = JTMOS_IPC_WIRE_MAGIC;
    resp.version = JTMOS_IPC_WIRE_VERSION;
    resp.op = req.op;
    resp.src = req.dst;
    resp.dst = req.src;

    switch (req.op) {
    case JTMOS_IPC_OP_PING:
        resp.status = 0;
        break;
    case JTMOS_IPC_OP_ACTIVATE:
        /* A process activates its own mailbox; sendMessage can create targets lazily. */
        if (req.dst != req.src || !process_exists(req.dst)) resp.status = 1;
        else resp.status = find_mailbox(req.dst, 1) ? 0 : 1;
        break;
    case JTMOS_IPC_OP_SEND:
        if (req.payload_len != sizeof(MSG)) {
            resp.status = 1;
        } else {
            MSG tmp;
            memcpy(&tmp, payload, sizeof(tmp));
            resp.status = broker_send_message(&req, &tmp);
            if (resp.status == 0) {
                out = (unsigned char *)malloc(sizeof(tmp));
                if (!out) { resp.status = 1; break; }
                memcpy(out, &tmp, sizeof(tmp));
                out_len = sizeof(tmp);
            }
        }
        break;
    case JTMOS_IPC_OP_RECV: {
        MSG tmp;
        int got = broker_recv_message(req.src, &tmp);
        resp.status = got;
        if (got) {
            out = (unsigned char *)malloc(sizeof(tmp));
            if (!out) { resp.status = 0; break; }
            memcpy(out, &tmp, sizeof(tmp));
            out_len = sizeof(tmp);
        }
        break;
    }
    case JTMOS_IPC_OP_POSTCALL:
        if (req.payload_len < sizeof(JTMOS_POST_WIRE_REQ)) {
            resp.status = EINVAL;
        } else {
            JTMOS_POST_WIRE_REQ ph;
            JTMOS_POST_WIRE_RESP pr;
            unsigned char *service_out = NULL;
            size_t service_payload_len;
            memcpy(&ph, payload, sizeof(ph));
            service_payload_len = req.payload_len - sizeof(ph);
            memset(&pr, 0, sizeof(pr));
            resp.status = jtmos_postman_service_handle(&ph,
                        payload + sizeof(ph), service_payload_len,
                        &pr, &service_out);
            if (resp.status == 0) {
                out_len = sizeof(pr) + pr.data_len;
                out = (unsigned char *)malloc(out_len ? out_len : 1u);
                if (!out) {
                    free(service_out);
                    resp.status = ENOMEM;
                    out_len = 0;
                    break;
                }
                memcpy(out, &pr, sizeof(pr));
                if (pr.data_len) memcpy(out + sizeof(pr), service_out, pr.data_len);
                free(service_out);
            }
        }
        break;
    case JTMOS_IPC_OP_SHUTDOWN:
        resp.status = 0;
        broker_quit = 1;
        break;
    default:
        resp.status = EINVAL;
        break;
    }

    resp.payload_len = (uint32_t)out_len;
    if (write_full(cfd, &resp, sizeof(resp)) == 0 && out_len)
        (void)write_full(cfd, out, out_len);
    free(out);
    free(payload);
    return 0;
}

int jtmos_broker_run(void)
{
    int sfd = -1, lockfd = -1;
    struct sockaddr_un sa;
    char lock_path[108];
    const char *sock_path = JtmosLinuxIPCSocketPath();

    snprintf(lock_path, sizeof(lock_path), "/tmp/jtmos-postman-%lu.lock", (unsigned long)getuid());
    lockfd = open(lock_path, O_CREAT | O_RDWR, 0600);
    if (lockfd < 0) return 1;
    if (flock(lockfd, LOCK_EX | LOCK_NB) != 0) {
        close(lockfd);
        return 0;
    }

    sfd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (sfd < 0) goto fail;
    memset(&sa, 0, sizeof(sa));
    sa.sun_family = AF_UNIX;
    if (strlen(sock_path) >= sizeof(sa.sun_path)) goto fail;
    strcpy(sa.sun_path, sock_path);
    unlink(sock_path);
    if (bind(sfd, (struct sockaddr *)&sa, sizeof(sa)) != 0) goto fail;
    (void)chmod(sock_path, 0600);
    if (listen(sfd, 32) != 0) goto fail;

    signal(SIGTERM, broker_signal);
    signal(SIGINT, broker_signal);
    signal(SIGPIPE, SIG_IGN);
    memset(mailboxes, 0, sizeof(mailboxes));
    global_message_number = 0;
    broker_quit = 0;

    while (!broker_quit) {
        int cfd = accept(sfd, NULL, NULL);
        if (cfd < 0) {
            if (errno == EINTR) continue;
            break;
        }
        (void)handle_connection(cfd);
        close(cfd);
    }

    close(sfd);
    unlink(sock_path);
    flock(lockfd, LOCK_UN);
    close(lockfd);
    return 0;
fail:
    if (sfd >= 0) close(sfd);
    unlink(sock_path);
    flock(lockfd, LOCK_UN);
    close(lockfd);
    return 1;
}
