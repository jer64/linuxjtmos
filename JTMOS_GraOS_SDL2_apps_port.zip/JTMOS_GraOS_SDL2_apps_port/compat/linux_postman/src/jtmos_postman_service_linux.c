#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include "postman.h"
#include "jtmos_postman_linux.h"
#include "jtmos_postman_internal.h"

static char *copy_arg_string(const unsigned char *p, size_t n)
{
    char *s;
    if (!p || n == 0 || n > 4096u) return NULL;
    s = (char *)malloc(n + 1u);
    if (!s) return NULL;
    memcpy(s, p, n);
    s[n] = '\0';
    if (memchr(s, '\0', n) != NULL) {
        /* Accept C strings sent with their terminator; force one terminator. */
    }
    return s;
}

static int posix_errno_or_zero(int rc)
{
    return rc == 0 ? 0 : errno;
}

int jtmos_postman_service_handle(const JTMOS_POST_WIRE_REQ *req,
                                 const unsigned char *payload,
                                 size_t payload_len,
                                 JTMOS_POST_WIRE_RESP *resp,
                                 unsigned char **out_data)
{
    const unsigned char *arg1;
    const unsigned char *arg2;
    char *path1 = NULL, *path2 = NULL;
    int fd = -1;
    struct stat st;
    ssize_t n;

    if (!req || !resp || !out_data) return EINVAL;
    *out_data = NULL;
    if ((size_t)req->arg1_len + (size_t)req->arg2_len != payload_len)
        return EINVAL;
    arg1 = payload;
    arg2 = payload + req->arg1_len;
    resp->acknowledged = 1;
    resp->rv = 0;
    resp->data_len = 0;

    switch (req->id) {
    case PCMD_EXIST:
        path1 = copy_arg_string(arg1, req->arg1_len);
        if (!path1) return EINVAL;
        if (stat(path1, &st) != 0) resp->rv = 0;
        else if (S_ISDIR(st.st_mode)) resp->rv = 2;
        else resp->rv = 1;
        break;

    case PCMD_CREATE_FILE:
        path1 = copy_arg_string(arg1, req->arg1_len);
        if (!path1) return EINVAL;
        fd = open(path1, O_CREAT | O_WRONLY, 0666);
        if (fd < 0) resp->rv = errno;
        else { close(fd); resp->rv = 0; }
        break;

    case PCMD_DELETE_FILE:
        path1 = copy_arg_string(arg1, req->arg1_len);
        if (!path1) return EINVAL;
        resp->rv = posix_errno_or_zero(unlink(path1));
        break;

    case PCMD_GET_FILE_SIZE:
        path1 = copy_arg_string(arg1, req->arg1_len);
        if (!path1) return EINVAL;
        if (stat(path1, &st) != 0) resp->rv = 0;
        else if (st.st_size > INT32_MAX) resp->rv = INT32_MAX;
        else resp->rv = (int32_t)st.st_size;
        break;

    case PCMD_RENAME_FILE:
        path1 = copy_arg_string(arg1, req->arg1_len);
        path2 = copy_arg_string(arg2, req->arg2_len);
        if (!path1 || !path2) { free(path1); free(path2); return EINVAL; }
        resp->rv = posix_errno_or_zero(rename(path1, path2));
        break;

    case PCMD_SETSIZE:
        path1 = copy_arg_string(arg1, req->arg1_len);
        if (!path1 || req->v1 < 0) { free(path1); return EINVAL; }
        resp->rv = posix_errno_or_zero(truncate(path1, (off_t)req->v1));
        break;

    case PCMD_CREATEDIRECTORY:
        path1 = copy_arg_string(arg1, req->arg1_len);
        if (!path1) return EINVAL;
        if (mkdir(path1, 0777) == 0 || errno == EEXIST) resp->rv = 0;
        else resp->rv = errno;
        break;

    case PCMD_READ_FILE:
        path1 = copy_arg_string(arg1, req->arg1_len);
        if (!path1 || req->v1 <= 0 || (uint32_t)req->v1 > JTMOS_LINUX_POSTMAN_MAX_TRANSFER || req->v2 < 0) {
            free(path1); return EINVAL;
        }
        fd = open(path1, O_RDONLY);
        if (fd < 0) { resp->rv = -errno; break; }
        *out_data = (unsigned char *)malloc((size_t)req->v1);
        if (!*out_data) { close(fd); free(path1); return ENOMEM; }
        n = pread(fd, *out_data, (size_t)req->v1, (off_t)req->v2);
        close(fd); fd = -1;
        if (n < 0) {
            resp->rv = -errno;
            free(*out_data); *out_data = NULL;
        } else {
            resp->rv = (int)n;
            resp->data_len = (uint32_t)n;
        }
        break;

    case PCMD_WRITE_FILE:
        path1 = copy_arg_string(arg1, req->arg1_len);
        if (!path1 || req->v1 <= 0 || (uint32_t)req->v1 > JTMOS_LINUX_POSTMAN_MAX_TRANSFER || req->v2 < 0 || req->arg2_len != (uint32_t)req->v1) {
            free(path1); return EINVAL;
        }
        fd = open(path1, O_CREAT | O_WRONLY, 0666);
        if (fd < 0) { resp->rv = -errno; break; }
        n = pwrite(fd, arg2, req->arg2_len, (off_t)req->v2);
        close(fd); fd = -1;
        resp->rv = n < 0 ? -errno : (int)n;
        break;

    case PCMD_IS_DRIVE_READY:
        resp->rv = 1;
        break;

    case PCMD_CHDIR:
    case PCMD_GETCWD:
        /* These are handled in the client process so cwd semantics remain correct. */
        return ENOTSUP;

    default:
        return ENOTSUP;
    }

    free(path1);
    free(path2);
    if (fd >= 0) close(fd);
    return 0;
}
