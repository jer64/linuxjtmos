#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <unistd.h>

#include "jtmos_postman_linux.h"
#include "jtmos_postman_internal.h"

static char socket_path[108];
static int path_ready;

const char *JtmosLinuxIPCSocketPath(void)
{
    if (!path_ready) {
        snprintf(socket_path, sizeof(socket_path), "/tmp/jtmos-postman-%lu.sock",
                 (unsigned long)getuid());
        path_ready = 1;
    }
    return socket_path;
}

int JtmosLinuxGetCurrentThread(void)
{
    /* Process-level IDs make the JTMOS PPCS model naturally cross-process. */
    return (int)getpid();
}

static int connect_broker(void)
{
    int fd;
    struct sockaddr_un sa;
    const char *path = JtmosLinuxIPCSocketPath();
    fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    memset(&sa, 0, sizeof(sa));
    sa.sun_family = AF_UNIX;
    if (strlen(path) >= sizeof(sa.sun_path)) { close(fd); errno = ENAMETOOLONG; return -1; }
    strcpy(sa.sun_path, path);
    if (connect(fd, (struct sockaddr *)&sa, sizeof(sa)) != 0) {
        close(fd);
        return -1;
    }
    return fd;
}

static int write_full(int fd, const void *buf, size_t len)
{
    const unsigned char *p = (const unsigned char *)buf;
    while (len) {
        ssize_t n = write(fd, p, len);
        if (n < 0) { if (errno == EINTR) continue; return -1; }
        if (n == 0) return -1;
        p += (size_t)n; len -= (size_t)n;
    }
    return 0;
}

static int read_full(int fd, void *buf, size_t len)
{
    unsigned char *p = (unsigned char *)buf;
    while (len) {
        ssize_t n = read(fd, p, len);
        if (n < 0) { if (errno == EINTR) continue; return -1; }
        if (n == 0) return -1;
        p += (size_t)n; len -= (size_t)n;
    }
    return 0;
}

int JtmosLinuxIPCEnsureBroker(void)
{
    JTMOS_IPC_HDR req, resp;
    int fd, i;
    memset(&req, 0, sizeof(req));
    req.magic = JTMOS_IPC_WIRE_MAGIC;
    req.version = JTMOS_IPC_WIRE_VERSION;
    req.op = JTMOS_IPC_OP_PING;
    req.src = JtmosLinuxGetCurrentThread();

    fd = connect_broker();
    if (fd >= 0) {
        int ok = write_full(fd, &req, sizeof(req)) == 0 &&
                 read_full(fd, &resp, sizeof(resp)) == 0 && resp.status == 0;
        close(fd);
        if (ok) return 0;
    }

    {
        pid_t child = fork();
        if (child < 0) return 1;
        if (child == 0) {
            int nullfd;
            (void)setsid();
            nullfd = open("/dev/null", O_RDWR);
            if (nullfd >= 0) {
                (void)dup2(nullfd, STDIN_FILENO);
                (void)dup2(nullfd, STDOUT_FILENO);
                (void)dup2(nullfd, STDERR_FILENO);
                if (nullfd > STDERR_FILENO) close(nullfd);
            }
            _exit(jtmos_broker_run());
        }
    }

    for (i = 0; i < 100; ++i) {
        usleep(10000);
        fd = connect_broker();
        if (fd >= 0) {
            int ok = write_full(fd, &req, sizeof(req)) == 0 &&
                     read_full(fd, &resp, sizeof(resp)) == 0 && resp.status == 0;
            close(fd);
            if (ok) return 0;
        }
    }
    return 1;
}

int jtmos_ipc_request(const JTMOS_IPC_HDR *req, const void *payload,
                      JTMOS_IPC_HDR *resp, void *out, size_t out_cap,
                      size_t *out_len)
{
    int fd;
    unsigned char discard[4096];
    size_t left;
    if (out_len) *out_len = 0;
    if (JtmosLinuxIPCEnsureBroker() != 0) return -1;
    fd = connect_broker();
    if (fd < 0) return -1;
    if (write_full(fd, req, sizeof(*req)) != 0 ||
        (req->payload_len && write_full(fd, payload, req->payload_len) != 0) ||
        read_full(fd, resp, sizeof(*resp)) != 0) {
        close(fd); return -1;
    }
    left = resp->payload_len;
    if (left && out && out_cap) {
        size_t take = left < out_cap ? left : out_cap;
        if (read_full(fd, out, take) != 0) { close(fd); return -1; }
        if (out_len) *out_len = take;
        left -= take;
    }
    while (left) {
        size_t take = left < sizeof(discard) ? left : sizeof(discard);
        if (read_full(fd, discard, take) != 0) { close(fd); return -1; }
        left -= take;
    }
    close(fd);
    return 0;
}

int JtmosLinuxIPCInit(void)
{
    if (JtmosLinuxIPCEnsureBroker() != 0) return 1;
    return ActivateThreadMessageBox(JtmosLinuxGetCurrentThread());
}

void JtmosLinuxIPCShutdown(void)
{
    /* Mailboxes are broker-owned and naturally disappear when broker exits. */
}

int JtmosLinuxIPCStopBroker(void)
{
    JTMOS_IPC_HDR req, resp;
    memset(&req, 0, sizeof(req));
    req.magic = JTMOS_IPC_WIRE_MAGIC;
    req.version = JTMOS_IPC_WIRE_VERSION;
    req.op = JTMOS_IPC_OP_SHUTDOWN;
    req.src = JtmosLinuxGetCurrentThread();
    return jtmos_ipc_request(&req, NULL, &resp, NULL, 0, NULL) == 0 ? resp.status : 1;
}

MSGBOX *createMessageBox(void)
{
    MSGBOX *box = (MSGBOX *)malloc(sizeof(*box));
    if (box) initMessageBox(box);
    return box;
}

void initMessageBox(MSGBOX *queue)
{
    int i;
    if (!queue) return;
    memset(queue, 0, sizeof(*queue));
    queue->n_q = N_MAX_QUEUED_MSGS;
    for (i = 0; i < queue->n_q; ++i) queue->q[i].isFree = MSG_FREE;
}

int VerifyMessage(MSG *msg)
{
    return msg != NULL && msg->magic1 == MSGBOX_MAGIC1 && msg->magic2 == MSGBOX_MAGIC2;
}

int ActivateThreadMessageBox(int pid)
{
    JTMOS_IPC_HDR req, resp;
    memset(&req, 0, sizeof(req));
    req.magic = JTMOS_IPC_WIRE_MAGIC;
    req.version = JTMOS_IPC_WIRE_VERSION;
    req.op = JTMOS_IPC_OP_ACTIVATE;
    req.src = JtmosLinuxGetCurrentThread();
    req.dst = pid;
    if (jtmos_ipc_request(&req, NULL, &resp, NULL, 0, NULL) != 0) return 1;
    return resp.status;
}

int sendMessage(MSG *m, int pid)
{
    JTMOS_IPC_HDR req, resp;
    MSG returned;
    size_t got = 0;
    if (!m) return 1;
    if (m->amount < 0 || m->amount > N_MAX_BYTES_PER_MSG) return 1;
    memset(&req, 0, sizeof(req));
    req.magic = JTMOS_IPC_WIRE_MAGIC;
    req.version = JTMOS_IPC_WIRE_VERSION;
    req.op = JTMOS_IPC_OP_SEND;
    req.src = JtmosLinuxGetCurrentThread();
    req.dst = pid;
    req.payload_len = sizeof(*m);
    if (jtmos_ipc_request(&req, m, &resp, &returned, sizeof(returned), &got) != 0) return 1;
    if (resp.status == 0 && got == sizeof(returned)) memcpy(m, &returned, sizeof(*m));
    return resp.status;
}

int receiveMessage(MSG *m)
{
    JTMOS_IPC_HDR req, resp;
    size_t got = 0;
    if (!m) return 0;
    memset(&req, 0, sizeof(req));
    req.magic = JTMOS_IPC_WIRE_MAGIC;
    req.version = JTMOS_IPC_WIRE_VERSION;
    req.op = JTMOS_IPC_OP_RECV;
    req.src = JtmosLinuxGetCurrentThread();
    if (jtmos_ipc_request(&req, NULL, &resp, m, sizeof(*m), &got) != 0) return 0;
    return resp.status == 1 && got == sizeof(*m) ? 1 : 0;
}
