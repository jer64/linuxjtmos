#ifndef JTMOS_POSTMAN_WIRE_H
#define JTMOS_POSTMAN_WIRE_H

#include <stdint.h>
#include "msgbox.h"

#define JTMOS_IPC_WIRE_MAGIC 0x4A544D50u /* JTMP */
#define JTMOS_IPC_WIRE_VERSION 1u

enum {
    JTMOS_IPC_OP_PING = 1,
    JTMOS_IPC_OP_ACTIVATE = 2,
    JTMOS_IPC_OP_SEND = 3,
    JTMOS_IPC_OP_RECV = 4,
    JTMOS_IPC_OP_POSTCALL = 5,
    JTMOS_IPC_OP_SHUTDOWN = 6
};

typedef struct {
    uint32_t magic;
    uint32_t version;
    uint32_t op;
    int32_t src;
    int32_t dst;
    int32_t status;
    uint32_t payload_len;
} JTMOS_IPC_HDR;

typedef struct {
    int32_t id;
    int32_t v1,v2,v3,v4;
    int32_t dnr,db,pid;
    uint32_t arg1_len;
    uint32_t arg2_len;
} JTMOS_POST_WIRE_REQ;

typedef struct {
    int32_t rv;
    int32_t acknowledged;
    uint32_t data_len;
} JTMOS_POST_WIRE_RESP;

#endif
