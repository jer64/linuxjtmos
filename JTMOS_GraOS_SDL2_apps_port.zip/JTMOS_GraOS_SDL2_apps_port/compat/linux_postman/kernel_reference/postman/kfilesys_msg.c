// =====================================================================
// KFilesys message handler.
// =====================================================================
#include "kernel32.h"
#include "postman.h"
#include "kfilesys_msg.h"

//
int kfilesysLastPacketID=0;
// Seconds count when kfilesys_msg was last ran,
// this is determined by kfilesys with rtc_getseconds().
// Is set to zero if kfilesys is busy.
int kfilesysLastSec=0;

//
int kfilesys_packetHandler(int id, POSTMANCMD *p)
{
	// We are now busy
	kfilesysLastSec = 0;

	// Set last packet ID
	kfilesysLastPacketID = id;

	// If we got a job to do
	switch(id)
	{
		// FILE FUNCTIONS:
		// ---------------
		case PCMD_CHDIR:
		kfilesys_pcmd_chdir(p);
		break;

		case PCMD_CREATEDIRECTORY:
		kfilesys_pcmd_createdirectory(p);
		break;

		case PCMD_GETFILEDATABLOCK:
		kfilesys_pcmd_getfiledatablock(p);
		break;

		// Set file size
		case PCMD_SETSIZE:
		kfilesys_pcmd_setsize(p);
		break;

		// Rename a file
		case PCMD_RENAME_FILE:
		kfilesys_pcmd_rename_file(p);
		break;

		// Create a file
		case PCMD_CREATE_FILE:
		kfilesys_pcmd_create_file(p);
		break;

		// Delete a file
		case PCMD_DELETE_FILE:
		kfilesys_pcmd_delete_file(p);
		break;

		// Read from a file
		case PCMD_READ_FILE:
		kfilesys_pcmd_read_file(p);
		break;

		// Write to a file
		case PCMD_WRITE_FILE:
		kfilesys_pcmd_write_file(p);
		break;

		// Get file size
		case PCMD_GET_FILE_SIZE:
		kfilesys_pcmd_get_file_size(p);
		break;

		//
		case PCMD_ADD_BLOCKS:
		kfilesys_pcmd_add_blocks(p);
		break;

		//
		case PCMD_EXIST:
		kfilesys_pcmd_exist(p);
		break;

		//
		case PCMD_CLOSE:
		kfilesys_pcmd_close(p);
		break;

		//
		case PCMD_READBLOCK:
		kfilesys_pcmd_readblock(p);
		break;

		//
		case PCMD_WRITEBLOCK:
		kfilesys_pcmd_readblock(p);
		break;

		//
		case PCMD_FINDFIRST:
		kfilesys_pcmd_findfirst(p);
		break;

		//
		case PCMD_FINDNEXT:
		kfilesys_pcmd_findnext(p);
		break;

		//
		case PCMD_FORMATDRIVE:
		kfilesys_pcmd_formatdrive(p);
		break;

		//
		case PCMD_IS_DRIVE_READY:
		kfilesys_pcmd_is_drive_ready(p);
		break;

		//
		case PCMD_GETCWD:
		kfilesys_pcmd_getcwd(p);
		break;

		// ------------------------------
		// Just ack unhandled packets:
		//
		default:
		p->acknowledged=2;
		p->id=0;
		return 1;
	} // switch

	// Declare that we have now completed
	// by storing the seconds count.
	kfilesysLastSec = rtc_getseconds();
	return 0;
}


