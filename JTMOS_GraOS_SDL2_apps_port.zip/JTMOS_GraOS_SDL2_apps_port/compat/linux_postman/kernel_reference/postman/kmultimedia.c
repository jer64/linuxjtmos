// ======================================================
// kmultimedia.c - Central Multimedia Process functions
// (C) 2002-2003 by Jari Tuominen
// ======================================================
#include "basdef.h"
#include "kernel32.h"
#include "postman.h"
#include "postcmds.h"
#include "scs.h"
#include "devsys.h"
#include "jtmfs.h"
#include "jtmfat.h"
#include "devapi.h"
#include "sysgfx.h" // SetVideoMode, setvmode
#include "dispadmin.h" // dispadmin_getcurrentmode
#include "postcmds_com.h"
#include "kfilesys.h"
#include "kmultimedia.h"
#include "verify_ptr.h"
#include "sb.h"
#include "audio.h" // SendAudio

//
void media_pcmd_setpalette(POSTMANCMD *p)
{
	//
	setpalette(p->v1, p->v2,p->v3,p->v4);

	//
	PostmanAckPacket(p,1);
}

//
void media_pcmd_setpalettemap(POSTMANCMD *p)
{
	//
	panic("media_pcmd_setpalettemap: Obsolete function.");

	//
	VERIFY_PTR(p->pid, p->par1)

	//
	setpalettemap(p->v1, p->v2, p->par1);

	//
	PostmanAckPacket(p,1);
}

// AUDIO FUNCTIONS
// Initialize audio system
// (not allowed, not needed)
void media_pcmd_initaudio(POSTMANCMD *p)
{
	//
//	InitAudioDevice();
//	sb_reset();
//	sb_start_playing();

	//
	PostmanAckPacket(p,1);
}

// Send a chunk of audio to the audio buffer
void media_pcmd_sendaudio(POSTMANCMD *p)
{
	int i,i2;
	BYTE *d;

	// Check requested audio type
	if(p->v2!=0)
	{
		dprintk("%s: audio type 0x%x not supported\n", __FUNCTION__, p->v2);
		// Not supported.
		PostmanAckPacket(p,2);
		return;
	}

	//
	dprintk("%s: %d Hz, %d bytes, type 0x%x\n",
		__FUNCTION__, p->v3, p->v1, p->v2);

	// Send more audio data to the buffer
	SendAudio(p->par1, p->v1, p->v3);

	//
	PostmanAckPacket(p,1);
}

// Stores position in return variable v4.
void media_pcmd_getaudioposition(POSTMANCMD *p)
{
	// Return amount of bytes in the audio buffer
	postman_SetReturnValue(p, aud.count);

	//
	PostmanAckPacket(p,1);
}

// VIDEO FUNCTIONS
//
void media_pcmd_setmode(POSTMANCMD *p)
{
	DEBUGLINE
	dsleep(5);

	// Now we switch the video mode.
	// We shall not be interrupted.
	PUSHFLAGS;
	disable();
	setvmode(p->v1);
	dispadmin_reportmodechange(p->v1);
	POPFLAGS;

	// Check which mode, and define a new terminal ID
	switch(p->v1)
	{
		// TEXT TERMINAL
		// Hmmz, we are returning back to textmode,
		// therefore there's no idea what is an appropriate
		// terminal to use, because last terminal used
		// was most probably vga_terminal -one.
		case 3:
		SetThreadTerminal(p->pid, 0);
		if(visible_before_switch!=-1)
			SetVisibleTerminal(visible_before_switch);
		else
			SetVisibleTerminal(0);
		break;

		// GRAPHICAL TERMINAL
		// We assume it is a graphical terminal.
		default:
		SetThreadTerminal(p->pid, vga_terminal);
		SetVisibleTerminal(vga_terminal);
		break;
	}

	//
	PostmanAckPacket(p,1);
}

//
void media_pcmd_drawframe(POSTMANCMD *p)
{
	//
	char *vf,*src;
	int i,i2;

	// Define VGA memory.
	vf=0xa0000;
	// Define source.
	src=p->par1;

	// v1-v2

	//
	switch( dispadmin_getcurrentmode() )
	{
		// 320x200 256c video mode
		case 0x13:
		if( (p->v1+p->v2)<=0xffff )
			memcpy(vf + p->v1, src, p->v2);
		break;
		// 640x480 2c video mode
		case 0x11:
		if( (p->v1+p->v2)<=0xffff )
			memcpy(vf + p->v1, src, p->v2);
		break;
		// 640x480 16c video mode
		case 0x12:
		if( (p->v1+p->v2)<=0xffff )
			memcpy(vf + p->v1, src, p->v2);
		break;
	}

	//
	PostmanAckPacket(p,1);
}


//

