//==================================================================
// kfilesysService.c  - kernel file system service
//==================================================================
#include "kernel32.h"
#include "postman.h"
#include "kfilesys.h"

// Explanations for command IDs
char *kfilesysCmdName[]={
	"[nothing]",
	"PCMD_CREATE_FILE",
	"PCMD_DELETE_FILE",
	"PCMD_WRITE_FILE",
	"PCMD_READ_FILE",
	"PCMD_GET_FILE_SIZE",
	"PCMD_ADD_BLOCKS",
	"PCMD_EXIST",
	"PCMD_READBLOCK",
	"PCMD_WRITEBLOCK",
	"PCMD_FINDFIRST",
	"PCMD_FINDNEXT",
	"PCMD_RENAME_FILE",
	"PCMD_SETSIZE",
	"PCMD_GETFILEDATABLOCK",
	"PCMD_CREATEDIRECTORY",
	"PCMD_FORMATDRIVE",
	"PCMD_CLOSE",
	"PCMD_CHDIR",
	"PCMD_IS_DRIVE_READY",
	"PCMD_GETCWD",
	""
	};

// Init KFILESYS
void kfilesys_init(void)
{
	//
	memset(&kfilesysThread, 0, sizeof(kfilesysThread));
}

// Restart KFILESYS service
void kfilesys_restart(void)
{
	// Already running? Stop process.
	if(kfilesysThread.pid)
	{
		ReportMessage("%s: restarting service process\n", __FUNCTION__);
		KillThread(kfilesysThread.pid);
	}

	// We create exceptionally big stack
	// because of huge stack demand:
	ThreadCreateStack(&kfilesysThread, 1024*64);
	kfilesysThread.pid =
		create_thread(kfilesysThread.stack, kfilesysThread.l_stack, kfilesysService);
	// max. 31 characters
	IdentifyThread(kfilesysThread.pid, "KFILESYS");
	// Select terminal for the process
	SetThreadTerminal(kfilesysThread.pid, ID_VIRTUAL_TERMINAL_6);
	SetThreadPriority(kfilesysThread.pid, THREAD_PRIORITY_NORMAL);
}

// KFILESYS process
void kfilesysService(void)
{
	DATE d;

	// Report in
	ReportMessage("%s: Waking up.\n",	__FUNCTION__);

	// Service main loop
	while(1)
	{
		// Cache flush going on? Wait until it has finished.
		if(FlushFat)
		{
			dprintk("%s: waiting until completion of cache flush operation.\n", __FUNCTION__);
			while(FlushFat)
			{
				//
				// ZZzZZZzzzz....
				SwitchToThread();
			}
			dprintk("%s: cache flush completed.\n", __FUNCTION__);
		}

		//
		FFCHECK

		// Got a job to do?
		if(kfilesys.p!=NULL)
		{
			//
			rtc_getdate(&d);
			SwitchColorNow();
			printk("[%s %d:%d:%d]: Command %d(%s) from PID%d.\n",
					__FUNCTION__,
					d.hour, d.minute, d.second,
					kfilesys.id,
					kfilesysCmdName[kfilesys.id],
					kfilesys.p->pid);

			//
			FFCHECK
			// Do the job
			kfilesys_packetHandler(kfilesys.id, kfilesys.p);
			// Job done
			kfilesys.p = NULL;
			//
			FFCHECK
		}

		// Idle moment
		SwitchToThread();
		// Mark up when we last time ran
		// (for automatic service restart).
		kfilesys.t = rtc_getseconds();
	}
}



