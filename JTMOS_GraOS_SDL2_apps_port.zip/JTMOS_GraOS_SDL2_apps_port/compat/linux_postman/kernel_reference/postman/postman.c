// ==========================================================================
// postman.c - Postman process.
// (C) 2002-2005 by Jari Tuominen(jari@vunet.org).
// ==========================================================================
#include "kernel32.h"
#include "threads.h"
#include "postman.h"
#include "postcmds.h"
#include "kfilesys.h"
#include "kfilesys_msg.h"
#include "kmultimedia.h"
#include "cache.h"
//
//#define POSTMAN_SERIAL_TO_TERM0

// Remove comment from front to enable more verbose messages for postman
//#define DEBUG

// Allow service restarting?
int ALLOW_SERVICE_RESTARTING=0;
// Postman's PID if one exists (0=does not exist).
int postmanPID=0;
// set this to non-zero if you want the postman thread to terminate
char postmanPleaseQuit=0;
// Main structure with post(s)
POSTMAN postman;
// Thread structures
THREAD PostmanThread;
THREAD kfilesysThread;
THREAD kmultimediaThread;
PSERVICE kfilesys, kmultimedia;

//
int pong=0;
//
void SwitchColorNow(void)
{
	pong++;
	if( (pong&1) )
		textcolor(YELLOW);
		else
		textcolor(7);
}

// Inits postman
//
// note: can be called only once,
// or atleast the thread of possible existing
// postman thread must be killed before to
// prevent conflicts
//
void postman_init(void)
{
	int i;

	// Init all packets first
	for(i=0; i<N_MAX_POSTMAN_POSTS; i++)
	{
		memset(&postman.post[i], 0, sizeof(POSTMANCMD));
	} 

	// We create exceptionally big stack
	// because of huge stack demand:
	ThreadCreateStack(&PostmanThread, 1024*64);
	PostmanThread.pid =
		create_thread(PostmanThread.stack, PostmanThread.l_stack, postmanThread);
	// max. 31 characters
	IdentifyThread(PostmanThread.pid, "KPOSTMAN");

	// Init both services
	kfilesys_init();
	kmultimedia_init();

	// Restart services(will basically create both processes at the first place)
	kfilesys_restart();
	kmultimedia_restart();
}

/*
 *    //
 *    printf("Postman got some mail!\n");
 *    printf("id = %d, par8=%x, par1 content='%s'\n",
 *	postman.post[i].id, postman.post[i].par8, postman.post[i].par1);
 */
//
void postmanThread(void)
{
	// ----------------------------------------------------
	static int key1,pr,i,i2,i3,i4,key,lti,ti,id,waiting;
	static POSTMANCMD *p,*newpost;
	static MSG m;
	static int hasDoneWork=0;
	static int devnr;
	static DATE d;
	static int tick,t;
	char str[256],str2[256];

	// Show that we really are here
	postmanPID = GetCurrentThread();

	// Select terminal
	SetThreadTerminal(GetCurrentThread(), 6);

	// Report in
	printk("Postman process running(PID=%d).\n", postmanPID);

	//-------------------------------------------------------------------
	// Main loop
	for(lti = rtc_getseconds(),waiting=FALSE; ; )
	{
		// Get out time
		ti = rtc_getseconds();
		// Flush time?
		if( (ti-lti)>=10 && !DISABLE_CACHE_AUTO_FLUSH )
		{
			// Commence flush now
			FlushAll();
			// Next wait starts after the flush
			ti = rtc_getseconds();
			lti = ti;
		}

		//
		if(hasDoneWork)
		{
			//
			hasDoneWork=0;
#ifdef DEBUG
			ReportMessage("Postman has no jobs currently.\n");
#endif
		}

		// Redirect COM1 to the keyboard buffer
		// (temporary solution.)
#ifdef POSTMAN_SERIAL_TO_TERM0
		if( (key=serial_get(0))!=-1 )
		{
			//
			kb_outbuf( vt2202asc(key) );
		}
#endif

		//--------------------------------------------------------------------------------------
		// Probe for a new message
		//
		if( receiveMessage(&m) )
		{
			//
			if(waiting)printk("\r                                             \r");
			waiting = FALSE,

			// Got new message:

			//
			newpost = &m.buf;

			// Check magic
			if(newpost->magic != POSTMAN_MAGIC)
			{
				// Report.
				panic("postman panic 1");
				printk("%s: Packet has invalid magic number(%x!=%x).\n",
					newpost->magic, POSTMAN_MAGIC);
				if(debug2) Attention();
				// Go to past processing.
				goto past;
			}
#ifdef DEBUG
			//
			if(!hasDoneWork){ ReportMessage("Postman is doing work:\n"); }
#endif
			//
			hasDoneWork=1;

			// Get packet ID
			id = newpost->id;

			//------------------------------------------------------------------------------
			// Loop until someone can take this packet.
			// (or discard it if it is unknown/corrupted)
			ReportMessage("%s: delivering packet(id=%d) to the service\n",
				__FUNCTION__, id);
			//
			for(t=GetSeconds(); ; )
			{
				// Handle kfilesys packets
				if(id>=KFILESYS_1 && id<=KFILESYS_2 && kfilesys.p==NULL)
				{
					//
				//	printk("postman > kfilesys\n");

					// Store packet in kfilesys's tmp buffer
					memcpy(&kfilesys.tmp,newpost, sizeof(POSTMANCMD));
	
					// Set vars.
					kfilesys.id = id;
					kfilesys.p = &kfilesys.tmp;
					break;
				}

				// Handle kmultimedia packets
				if(id>=KMULTIMEDIA_1 && id<=KMULTIMEDIA_2 && kmultimedia.p==NULL)
				{
					//
				//	printk("postman > kmultimedia\n");

					// Store packet in kmultimedia's tmp buffer.
					memcpy(&kmultimedia.tmp,newpost, sizeof(POSTMANCMD));
	
					// Set vars.
					kmultimedia.id = id;
					kmultimedia.p = &kmultimedia.tmp;
					break;
				}

				// Discard illegal packet
				if( !( (id>=KMULTIMEDIA_1 && id<=KMULTIMEDIA_2) ||
					(id>=KFILESYS_1 && id<=KFILESYS_2) )  )
				{
					// Report.
					if(debug2) Attention();
					printk("%s: UNKNOWN PACKET(id=%d)!\n",
						__FUNCTION__, id);
					if(debug2) sleep(2);

					// Break loop.
					break;
				}

				// Time-out handler.
				if( (GetSeconds()-t)>=45 )
				{
					//
					sprintf(str, "Postman: Time-out error (t=%d) while waiting for a service to pick up the packet, service process not responding. Packet ID = %d.",
						GetSeconds()-t, id);
					printk("%s\n", str);
					break;
				}

				// Schedule
				SwitchToThread();
			}

#ifdef SPEED_UP_WITH_SWITCHING
			// Go back to the caller
		        SwitchToThreadEx(newpost->pid);
#endif
past:
		} // ^^new post arrived
		else
		{
			//
			if(!waiting)
			{
				printk("\r%s: Waiting for incoming messages ", 
					__FUNCTION__);
				waiting = TRUE;
			}
		}

		// Quit on quit request.
		if(postmanPleaseQuit)break;

		// Schedule
		SwitchToThread();
	}

	// before we exit, we clear the PID value
	// show that we are no more here...
	postmanPID=0;

	//
	ExitThread(0);
}

// Returns -1 if no free entry is found,
int postman_getnewentry(void)
{
	int i;

	//
	for(i=0; i<N_MAX_POSTMAN_POSTS; i++)
	{
		if(!postman.post[i].id)return i;
	}

	//
	return -1;
}

// postman_postrequest
//
// Posts a request to postman with 6 arguments
// the first argument is the function
// returns non-zero value if the request could not be processed.
//
int postman_postrequest(POSTMANCMD *p)
{
	int i,flags;
	MSG m;
	char *ptr,*ptr2;

	//
	if(postmanPID==0)
		// Postman is not active.
		return 1;


	//
	ptr =  A2K(&m.buf);
	ptr2 = A2K(&m);

	// We need to do this smoothly:
	// Save state.
	flags = get_eflags();
	// Disable interrupts
	disable();

	// Copy some content.
	memcpy(ptr,p, sizeof(POSTMANCMD));

	//
	m.protocol = MB_PROTOCOL_POSTMAN;

	// Send message to the postman process.
	sendMessage(ptr2, postmanPID);

	// Restore state.
	set_eflags(flags);

	// Success:
	return 0;
}

//

