// ================================================================
// postcmds.c - Handler functions for miscellaneous postman packets
// (C) 2002-2003 by Jari Tuominen
// ================================================================
#include "basdef.h"
#include "kernel32.h"
#include "postman.h"
#include "postcmds.h"
#include "scs.h"
#include "devsys.h"
#include "jtmfs.h"
#include "jtmfat.h"
#include "devapi.h"
#include "sysgfx.h" // SetVideoMode, setvmode
#include "dispadmin.h" // dispadmin_getcurrentmode
#include "postcmds_com.h"
#include "kfilesys.h"

// No functions here yet.
// All misc. functions will be added here,
// that don't fit in other categories.
