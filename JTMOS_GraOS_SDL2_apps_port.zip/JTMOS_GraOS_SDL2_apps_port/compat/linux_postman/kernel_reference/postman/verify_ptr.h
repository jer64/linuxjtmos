#ifndef __INCLUDED_VERIFY_PTR_H__
#define __INCLUDED_VERIFY_PTR_H__

// If this line below will be remarked,
// then a panic will be triggered on
// all pointer violations
#define KILL_PTR_VIOLATING_PROCESS

// Prototype
int _verify_ptr(int pid, DWORD ptr, const char *func);

// This function verifies that the specified pointer
// resides within the process memory space.
// This check is skipped for kernel memory space processes,
// which can access all memory at once.
#define VERIFY_PTR(PID, PTR)	\
		_verify_ptr(PID, PTR, __FUNCTION__);

#endif


