//=====================================================================
// verify_ptr.c - pointer verification system
// This system verifies a pointer, and determines whether if
// it is valid within specified thread's own private memory space.
//=====================================================================
#include "kernel32.h"
#include "verify_ptr.h"
// Debugging feature
#define VERIFY_PTR_DEBUG

// Handles pointer violations.
int PTRViolation(int PID, void *PTR, const char *func, char viol1, char viol2)
{
	static char str[256];

	//
	return 0;

	// Ignore violations from system call functions.
	// (are mostly non-violations)
	if( thread_scall_active[PID] )
		// It's a scall, ignore the error.
		return 0;

	// ERROR
	printk("PID%d memory region 0x%x-0x%x\n",
		PID,
		GetThreadMemoryStart(PID),
		GetThreadMemoryEnd(PID));
	printk("Violating PTR = 0x%x\n", PTR);
	printk("Service function = '%s',  client PID = %d,  PTR = 0x%x",
		func, PID, PTR);
	// Optional panic here:
	sprintf(str, "Pointer verification failure: PID%d memory region 0x%x-0x%x - violating pointer = 0x%x\n",
		PID,
		GetThreadMemoryStart(PID),
		GetThreadMemoryEnd(PID),
		PTR);
	if(viol1)
		printk("VIOLATION REASON 1 TRUE\n");
	if(viol2)
		printk("VIOLATION REASON 2 TRUE\n");
#ifdef KILL_PTR_VIOLATING_PROCESS
	printk("%s", str);
	printk("Killing violating process.\n");
	KillThread(PID);
	if(debug2)
	{
		Attention();
		sleep(2);
	}
#else
	panic(str);
#endif

	//
	return 1;
}

// This function verifies that the specified pointer
// resides within specified PID's memory space
int _verify_ptr(int PID, DWORD PTR, const char *func)
{
	static char str[256],viol1,viol2;

	//-------------------------------------------------------------------------------
	// Defaults: no violations detected
	//
	viol1 = FALSE;
	viol2 = FALSE;

	//-------------------------------------------------------------------------------
	// Check for violation
	//
	if(     GetThreadMemoryEnd(PID)         // If not a kernel mode process
			&&
			(PTR<GetThreadMemoryStart(PID)  // PTR crosses memory region start
			||
			PTR>=GetThreadMemoryEnd(PID))   ) // or PTR crosses memory region end
	{
		//
		if(PTR<GetThreadMemoryStart(PID))
			viol1 = TRUE;
		if(PTR>=GetThreadMemoryEnd(PID))
			viol2 = TRUE;

		//
		return PTRViolation(PID, PTR, func, viol1,viol2);
	}
	else
	{
#ifdef VERIFY_PTR_DEBUG
		// Report
		if( !GetThreadMemoryEnd(PID) )
		{
			dprintk("%s: Letting go: Kernel mode process(PID=%d), PTR=0x%x\n",
				__FUNCTION__, PID, PTR);
		}
		else
		{
			dprintk("%s: Application(PID=%d) PTR=0x%x is allowable(appmem: %x-%x)\n",
				__FUNCTION__, PID, PTR,
				GetThreadMemoryStart(PID),
				GetThreadMemoryEnd(PID));
		}
#endif
	}
	return 0;
}


