// =====================================================================
// kmultimedia message handler
// =====================================================================
#include "kernel32.h"
#include "postman.h"
#include "kmultimedia_msg.h"

// Packet handler for multimedia related things
int kmultimedia_packetHandler(int id, POSTMANCMD *p)
{
	// If we got a job to do
	switch(id)
	{
		// ----------------------------------------
		// VIDEO FUNCTIONS
		//
		case PCMD_SETMODE:
		media_pcmd_setmode(p);
		break;

		//
		case PCMD_DRAWFRAME:
		media_pcmd_drawframe(p);
		break;

		//
		case PCMD_SETPALETTE:
		media_pcmd_setpalette(p);
		break;

		//
		case PCMD_SETPALETTEMAP:
		media_pcmd_setpalettemap(p);
		break;

		// ------------------------------------------
		// AUDIO FUNCTIONS
		//
		case PCMD_INITAUDIO:
		media_pcmd_initaudio(p);
		break;

		//
		case PCMD_SENDAUDIO:
		media_pcmd_sendaudio(p);
		break;

		//
		case PCMD_GETAUDIOPOSITION:
		media_pcmd_getaudioposition(p);
		break;

		// ------------------------------
		// Just ack unhandled packets:
		//
		default:
		p->acknowledged=2;
		p->id=0;
		return 1;
	} // switch
	return 0;
}

