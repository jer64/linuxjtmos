#ifndef __INCLUDED_KMULTIMEDIA_MSG_H__
#define __INCLUDED_KMULTIMEDIA_MSG_H__

int kmultimedia_packetHandler(int id, POSTMANCMD *p);

#endif


