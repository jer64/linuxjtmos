// kmultimediaService.c
#include "kernel32.h"
#include "postman.h"
#include "kmultimedia.h"
#include "kmultimediaService.h"

// Init KMULTIMEDIA
void kmultimedia_init(void)
{
	//
	memset(&kmultimediaThread, 0, sizeof(kmultimediaThread));
}

// Restart KMULTIMEDIA service
void kmultimedia_restart(void)
{
	// Already running? Stop process.
	if(kmultimediaThread.pid)
	{
		ReportMessage("%s: Restarting service process\n", __FUNCTION__);
		KillThread(kmultimediaThread.pid);
	}

	// We create exceptionally big stack
	// because of huge stack demand:
	ThreadCreateStack(&kmultimediaThread, 1024*64);
	kmultimediaThread.pid =
		create_thread(kmultimediaThread.stack, kmultimediaThread.l_stack, kmultimediaService);
	// max. 31 characters
	IdentifyThread(kmultimediaThread.pid, "KMULTIMEDIA");
	// Select terminal for the process
	SetThreadTerminal(kmultimediaThread.pid, ID_VIRTUAL_TERMINAL_6);
	SetThreadPriority(kmultimediaThread.pid, THREAD_PRIORITY_NORMAL);
}

// KMULTIMEDIA process
void kmultimediaService(void)
{
	static DATE d;

	// Report in
	ReportMessage("%s: Waking up\n",	__FUNCTION__);

	// Service main loop
	while(1)
	{
		// Got a job to do?
		if(kmultimedia.p!=NULL)
		{
			//
			rtc_getdate(&d);
			SwitchColorNow();
			ReportMessage("[%s %d:%d:%d]: Command %d from PID %d\n",
					__FUNCTION__,
					d.hour, d.minute, d.second,
					kmultimedia.id,
					kmultimedia.p->pid);

			// Do the job
			kmultimedia_packetHandler(kmultimedia.id, kmultimedia.p);
			// Job done
			kmultimedia.p = NULL;
		}

		// Idle moment
		SwitchToThread();
		// Mark up when we last time ran
		// (for automatic service restart).
		kmultimedia.t = rtc_getseconds();
	}
}
