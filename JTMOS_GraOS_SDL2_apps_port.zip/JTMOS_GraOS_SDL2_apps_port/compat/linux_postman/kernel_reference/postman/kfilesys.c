//==============================================================================
// kfilesys.c - KFILESYS - command functions.
// (C) 2002-2005 by Jari Tuominen.
//
// Postman commands should be SHORT in durability.
// Absolute maximum time for a single command to
// take is 5 minutes, after this, the command will be discarded.
//
// To avoid longer operations taking too long time from
// other postman clients, command packets should be splitted
// into several shorter commands.
// (TODO)
//
//==============================================================================
#include "basdef.h"
#include "kernel32.h"
#include "postman.h"
#include "postcmds.h"
#include "scs.h"
#include "devsys.h"
#include "jtmfs.h"
#include "jtmfat.h"
#include "devapi.h"
#include "sysgfx.h" // SetVideoMode, setvmode
#include "dispadmin.h" // dispadmin_getcurrentmode
#include "postcmds_com.h"
#include "kfilesys.h"
#include "verify_ptr.h"

//
#define ddprintk dprintk

// Read/Write temporary block buffer
static BYTE *rwtmp=NULL;
static int l_rwtmp;

//
void kfilesys_pcmd_rename_file(POSTMANCMD *p)
{
	// ----------------------------------------------------
	static int key1,pr,i,i2,i3,i4,devnr;

	//
	VERIFY_PTR(p->pid, p->par1)
	VERIFY_PTR(p->pid, p->par2)

	//
	if( p->par1 && isValidString(p->par1) && strlen(p->par1)
		&&
		p->par2 && isValidString(p->par2) && strlen(p->par2) )
	{
		devnr = p->dnr;
		jtmfs_RenameFile(devnr, p->par1, p->par2, p->db);
	}

	//
	PostmanAckPacket(p,1);
	
}

// Create file
// 9/2003: Changed to properly return return value.
void kfilesys_pcmd_create_file(POSTMANCMD *p)
{
	// ----------------------------------------------------
	static int key1,pr,i,i2,i3,i4,rv,devnr;

	//
	VERIFY_PTR(p->pid, p->par1)

	//
	if( p->par1 && isValidString(p->par1) && strlen(p->par1) )
	{
		//
		ReportMessage("%s: Calling jtmfs_CreateFile, dnr=%d, db=%d, fname='%s'.\n",
			__FUNCTION__, p->dnr, p->db, p->par1);
		rv = jtmfs_CreateFile(p->dnr, p->db, p->par1, 0);
	}
	else
	{
		//
		ddprintk("%s: Invalid call.\n");
		rv = 1984;
	}

	//
	postman_SetReturnValue(p, rv);
	//
	PostmanAckPacket(p,1);
}

// Remove a file
void kfilesys_pcmd_delete_file(POSTMANCMD *p)
{
	// ----------------------------------------------------
	static int key1,pr,i,i2,i3,i4,devnr;

	//
	VERIFY_PTR(p->pid, p->par1)

	// Check path
	if( p->par1 && isValidString(p->par1) && strlen(p->par1) )
	{
		devnr = p->dnr;
		jtmfs_DeleteFile(devnr, p->par1, p->db);
	}

	//
	PostmanAckPacket(p,1);
}

// Read specified part of file
// par1 = fname
// par2 = load buffer
// v1 = amount to load in bytes
// v2 = read offset
void kfilesys_pcmd_read_file(POSTMANCMD *p)
{
	// ----------------------------------------------------
	static int key1,pr,i,i2,i3,i4,devnr,d1,l,bs,s,ii,count,
		amount,offset;
	DWORD ad;
	char *tp;
	BYTE *tmp;
	void *ldbuf,*fname;

	//
	FFCHECK

	//
	printk("%s: Read %d bytes from '%s', beginning from offset 0x%x\n",
		__FUNCTION__, p->v1, p->par1, p->v2);

	// Check amount of bytes to read
	if(p->v1 >= (1024*1024*1) || p->v1 <= 0)
	{
		printk("%s: illegal size %d\n",
			__FUNCTION__, p->v1);
		goto past;
	}

	//
	FFCHECK

	//
	// par1 = fname
	// par2 = load buffer
	// v1 = amount to load in bytes
	// v2 = read offset
	VERIFY_PTR(p->pid, p->par1)
	VERIFY_PTR(p->pid, p->par2)
	VERIFY_PTR(p->pid, p->par2+p->v1) // Upto the amount of bytes to read
	if(!isValidString(p->par1))
	{
		printk("%s: INVALID STRING\n", __FUNCTION__);
		goto past;
	}

	//
	fname = p->par1;
	ldbuf = p->par2;
	amount = p->v1;
	offset = p->v2;

	//
	FFCHECK

	//
	ddprintk("%s: '%s' 0x%x-0x%x\n",
		__FUNCTION__, fname,offset,offset+amount);

	//---------------------------------------------------------------------
	// Is it a device?
	if( (d1=devsys_getdevicenrbyname(fname))!=-1 )
	{
		// ************** TODO ****************** !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

		// Read device.
		bs = getblocksize(d1);
		s = offset/bs;		// start block offset
		l = (amount/bs)+1 + s;	// end block offset
		count = amount/bs+1;

		//
		if(rwtmp==NULL || l_rwtmp<(bs*count))
		{
			if(rwtmp)	free(rwtmp);
			l_rwtmp = bs*(count+2);
			rwtmp = malloc(l_rwtmp);
		}
		memset(rwtmp, 0xBD, l_rwtmp);

		//
		tmp = rwtmp;
		VERIFY_PTR(p->pid, ldbuf+(amount/bs)*bs)

		// Read whole area at once.
		for(i=0,tp=tmp; i<(count+1); i++,tp+=bs)
		{
			//
			ReportMessage("r");
			readblock(d1, i+s, tp);
		}

		// Copy area from the tmp to client buffer.
		ad = tmp; ad += (offset % bs);
		memcpy(ldbuf,ad, amount);

		//
		ReportMessage("\n");
		goto past;
	}

	//---------------------------------------------------------------------
	// par1 = fname
	// par2 = load buffer
	// v1 = amount to load in bytes
	// v2 = read offset
	if( p->par1 && p->par2 && isValidString(p->par1) && strlen(p->par1) )
	{
		ReportMessage("%s: '%s', dnr=%d, db=%d, len=%d\n",
			__FUNCTION__, p->par1, p->dnr, p->db, p->v1);
		jtmfs_ReadFile(p->dnr,p->par1,p->db,
			p->par2, 0, p->v1, p->v2);
		goto past;
	}

past:
	//
	PostmanAckPacket(p,1);
}

// Write specified part to a file
// par1 = fname
// par2 = data buffer
// v1 = amount to write in bytes
// v2 = write offset
void kfilesys_pcmd_write_file(POSTMANCMD *p)
{
	// ----------------------------------------------------
	static int key1,pr,i,i2,i3,i4,devnr,bs,l,d1,s,ii,count;
	char *tp;
	BYTE *tmp;

	// Check amount of bytes to read
	if(p->v1 >= (1024*1024*1) || p->v1 <= 0)
	{
		ReportMessage("%s: illegal size %d\n",
			__FUNCTION__, p->v1);
		goto past;
	}

	//
	VERIFY_PTR(p->pid, p->par1)
	VERIFY_PTR(p->pid, p->par2)
	VERIFY_PTR(p->pid, p->par2+p->v1) // Upto the amount of bytes to write
	if(!isValidString(p->par1))
		goto past;

	//---------------------------------------------------------------------
	// Is it a device?
	if( (d1=devsys_getdevicenrbyname(p->par1))!=-1 )
	{
		// Read device
		bs = getblocksize(d1);
		s = p->v2/bs;		// start block offset
		l = (p->v1/bs)+1 + s;	// end block offset
		count = p->v1/bs;
		if(rwtmp==NULL || l_rwtmp<(bs*count))
		{
			if(rwtmp)	free(rwtmp);
			l_rwtmp = bs*(count+2);
			rwtmp = malloc(l_rwtmp);
		}
		tmp = rwtmp;
		VERIFY_PTR(p->pid, p->par1+(p->v1/bs)*bs)

		// Copy client area to the write buffer
		memcpy(tmp, p->par2, p->v1);

		// Write whole area at once
		for(i=0,tp=tmp; i<count; i++,tp+=bs)
		{
			//
			ReportMessage("w");
			writeblock(d1, i+s, tp);
		}

		//
		ReportMessage("\n");
		goto past;
	}

	//
	if( p->par1 && p->par2 && isValidString(p->par1) && strlen(p->par1) )
	{
		//
		dprintk("%s: '%s', dnr=%d, db=%d, len=%d\n",
			__FUNCTION__, p->par1, p->dnr, p->db, p->v1);

		//
		devnr = p->dnr;
		jtmfs_WriteFile(devnr,
			p->par1, p->db, p->par2,
			0, p->v1, p->v2); // v1=amount, v2=offset
		goto past;
	}

past:
	//
	PostmanAckPacket(p,1);
}

//
void kfilesys_pcmd_get_file_size(POSTMANCMD *p)
{
	// ----------------------------------------------------
	static int key1,pr,i,i2,i3,i4,devnr,d1;


	//
	VERIFY_PTR(p->pid, p->par1)

	// Validate string
	if(!isValidString(p->par1))
		// Invalid string
		goto past;

	//--------------------------------------------------------
	// Is it a device?
	if( (d1=devsys_getdevicenrbyname(p->par1))!=-1 )
	{
		// Get device size in bytes and set it as return value
		postman_SetReturnValue(p,
				getblocksize(d1)*getsize(d1) );
		goto past;
	}

	//--------------------------------------------------------
	// Check path
	if( p->par1 && isValidString(p->par1) && strlen(p->par1) )
	{
		// Get file size and set it as return value
		postman_SetReturnValue(p,
			jtmfs_GetFileSize(p->dnr, p->par1,
				p->db));
		goto past;
	}
	else
	{
		//
		postman_SetReturnValue(p, 0);
		dprintk("%s: Defective file name\n", __FUNCTION__);
		goto past;
	}

past:
	PostmanAckPacket(p,1);
}

//
void kfilesys_pcmd_add_blocks(POSTMANCMD *p)
{
	//
	static int key1,pr,i,i2,i3,i4,devnr;

	//
	VERIFY_PTR(p->pid, p->par1)

	// Check path
	if( p->par1 && isValidString(p->par1) && strlen(p->par1) )
	{
		devnr = p->dnr;
		dprintk("jtmfs_AddBlocks(devnr=%d, '%s'(0x%x), 0, count=%d);\n",
			devnr, p->par1, p->par1, p->v1);
		jtmfs_AddBlocks(devnr, p->par1, p->db, p->v1);
	}
	else
	{
		dprintk("%s: error par1==NULL\n", __FUNCTION__);
	}

	//
	PostmanAckPacket(p,1);
}

//
void kfilesys_pcmd_setsize(POSTMANCMD *p)
{
	static int key1,pr,i,i2,i3,i4,devnr;

	//
//	VERIFY_PTR(p->pid, p->par1)

	// Check path
	if( p->par1 && isValidString(p->par1) && strlen(p->par1) )
	{
		devnr = p->dnr;
		ReportMessage("jtmfs_SetSize(devnr=%d, '%s'(0x%x), 0, size=%d);\n",
			devnr, p->par1, p->par1, p->v1);
		jtmfs_SetSize(devnr, p->par1, p->v1, p->db);
	}
	else
	{
		dprintk("%s: error par1==NULL\n", __FUNCTION__);
	}

	//
	PostmanAckPacket(p,1);
}

// Check file existance and return it's type.
// -1/0: Not found.
// 1: File.
// 2: Directory.
// Other values: Unknown.
void kfilesys_pcmd_exist(POSTMANCMD *p)
{
	//
	postman_SetReturnValue(p, 0);

	//
	VERIFY_PTR(p->pid, p->par1)

	//
	if( p->par1 && isValidString(p->par1) && strlen(p->par1) )
	{
		// v4 will contain the return value.
		postman_SetReturnValue(p,
			jtmfs_Fexist(p->dnr, p->par1, p->db));
	//	printk("%s: Returns %d on '%s'(len=%d)-\n",
	//	__FUNCTION__, p->v4, p->par1, strlen(p->par1));
	}
	else
	{
		printk("%s: Malformed request.\n", __FUNCTION__);
	}

	//
	PostmanAckPacket(p,1);
}

void kfilesys_pcmd_readblock(POSTMANCMD *p)
{
	//
	VERIFY_PTR(p->pid, p->par1)

	// v1=dnr, v2=blocknr, par1=block buffer pointer
	readblock(p->v1, p->v2, p->par1);

	//
	PostmanAckPacket(p,1);
}

void kfilesys_pcmd_writeblock(POSTMANCMD *p)
{
	//
	VERIFY_PTR(p->pid, p->par1)

	// v1=dnr, v2=blocknr, par1=block buffer pointer
	writeblock(p->v1, p->v2, p->par1);

	//
	PostmanAckPacket(p,1);
}

// Start a directory search
void kfilesys_pcmd_findfirst(POSTMANCMD *p)
{
	int fd;

	//
	VERIFY_PTR(p->pid, p->par1)
	VERIFY_PTR(p->pid, p->par2)

	// const char *path,	FFBLK *
	// (par1)		(par2)
	dprintk("%s: path(par1)='%s', par2=%x\n",
			__FUNCTION__, p->par1, p->par2);
	// Do findfirst
	fd = findfirst(p->dnr, p->db, p->par1, p->par2);
	// Put fd under sender's ownership
	changeFDOwner(fd, p->pid);
	//
	postman_SetReturnValue(p, fd);

	//
	PostmanAckPacket(p,1);
}

// Continue directory search
void kfilesys_pcmd_findnext(POSTMANCMD *p)
{
	//
	VERIFY_PTR(p->pid, p->par1)

	// int fd,	FFBLK *
	// (v1)		(par1)
	postman_SetReturnValue(p,
		findnext(p->dnr, p->db, p->v1, p->par1));

	PostmanAckPacket(p,1);
}

// Close file descriptor
void kfilesys_pcmd_close(POSTMANCMD *p)
{
	// int fd,	FFBLK *
	// (v1)		(par1)
	postman_SetReturnValue(p,
		close(p->v1));

	PostmanAckPacket(p,1);
}

// Get file data block number
void kfilesys_pcmd_getfiledatablock(POSTMANCMD *p)
{
	//
	VERIFY_PTR(p->pid, p->par1)

	//
	postman_SetReturnValue(p,
		jtmfs_GetFileDataBlock(p->dnr, p->db, p->par1));
	PostmanAckPacket(p,1);

}

// Create directory
void kfilesys_pcmd_createdirectory(POSTMANCMD *p)
{
	//
	VERIFY_PTR(p->pid, p->par1)

	//
	disable();
	jtmfs_CreateDirectory(p->dnr, p->db, p->par1);
	enable();

	//
	postman_SetReturnValue(p, p->db);
	PostmanAckPacket(p,1);
}

// Format a drive(multitasking safe)
void kfilesys_pcmd_formatdrive(POSTMANCMD *p)
{
	int r;

	//
	r = jtmfs_formatdrive(p->v1);
	postman_SetReturnValue(p, r);
	PostmanAckPacket(p, 1);
}

// Change directory
void kfilesys_pcmd_chdir(POSTMANCMD *p)
{
	// ----------------------------------------------------
	static int key1,pr,i,i2,i3,i4,devnr,r;

	//
	VERIFY_PTR(p->pid, p->par1)

	// Check path
	if( p->par1!=NULL && isValidString(p->par1) && strlen(p->par1) )
	{
		// Get PID's own DNR/DB
		SetThreadDNR(GetCurrentThread(), p->dnr);
		SetThreadDB(GetCurrentThread(), p->db);

		// Change to specified directory
		r = jtmfs_chdir(p->par1);

		// Store changes to caller's environment if OK
		SetThreadDNR(p->pid, GetCurrentDNR());
		SetThreadDB(p->pid, GetCurrentDB());
	}
	else
	{
		// Arguments were bad
		r=1;
	}

	// Set return value
	postman_SetReturnValue(p, r);

	//
	PostmanAckPacket(p,1);
}

// Checks whether if specified drive is ready for writing/reading,
// in other words that the drive is healthy and properly formatted.
void kfilesys_pcmd_is_drive_ready(POSTMANCMD *p)
{
	// Set return value
	postman_SetReturnValue(p, jtmfs_isDriveReady(p->v1));

	//
	PostmanAckPacket(p,1);
}

// Get current work directory.
void kfilesys_pcmd_getcwd(POSTMANCMD *p)
{
	// Get PID's own DNR/DB
	SetThreadDNR(GetCurrentThread(), p->dnr);
	SetThreadDB(GetCurrentThread(), p->db);

	// Set return value
	postman_SetReturnValue(p, jtmfs_GetCWD(p->par1, p->v1));

	//
	PostmanAckPacket(p,1);
}

//

