#include "basdef.h"
#include "kernel32.h"
#include "filedes.h"
#include "filedesbuf.h"

//
int FlushFDBuffers(int fd)
{
	//
	return 0;
}

