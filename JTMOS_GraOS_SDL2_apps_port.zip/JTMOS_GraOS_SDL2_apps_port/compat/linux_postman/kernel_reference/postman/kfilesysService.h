//
#ifndef __INCLUDED_KFILESYSSERVICE_H__
#define __INCLUDED_KFILESYSSERVICE_H__

//
void kfilesys_init(void);
void kfilesys_restart(void);
void kfilesysService(void);

#endif




