//====================================================================================
// Postman packet communication help functions.
//====================================================================================
#include "basdef.h"
#include "kernel32.h"
#include "postman.h"
#include "postcmds.h"
#include "scs.h"
#include "devsys.h"
#include "jtmfs.h"
#include "jtmfat.h"
#include "devapi.h"
#include "sysgfx.h" // SetVideoMode, setvmode
#include "dispadmin.h" // dispadmin_getcurrentmode
#include "postcmds_com.h"
// #define DEBUG

//============================================================
int PostmanPost(POSTMANCMD *p)
{
        //
        p->magic = POSTMAN_MAGIC;

        //
        return scall(SYS_POSTCMD, p,0,0, 0,0,0);
}

//============================================================
// PostmanWaitAck.
// Will return the proper result.
int PostmanWaitAck(POSTMANCMD *p)
{
	int i;

	//
	panic("PostmanWaitAck/kernel: this function should not be implemented");
}

// Set return value.
void postman_SetReturnValue(POSTMANCMD *p, int val)
{
	// Only if postman is active.
	if(!XON_POSTMAN)	return;

	// Set return value
	*p->rv = val;
}

// Ack packet.
void PostmanAckPacket(POSTMANCMD *p, int whichAck)
{
	//
	FFCHECK

	//
	if(!XON_POSTMAN)	return;

	//
	*p->acknowledged = TRUE;

	//
	p->id=0;

	//
#ifdef	DEBUG
	printk("PostmanAckPacket(): done\n");
#endif
}



