//
#ifndef __INCLUDED_POSTCOMMANDS_H__
#define __INCLUDED_POSTCOMMANDS_H__

//
#include "basdef.h"
#include "kernel32.h"
#include "postman.h"
#include "fsdos.h" // FFBLK typedef structure

//
DWORD post_exist(POSTMANCMD *post, const char *fname);
DWORD post_create(POSTMANCMD *post, const char *fname, int flags); // returns fd
DWORD post_findfirst(POSTMANCMD *post, const char *fname, FFBLK *ff); // returns fd
DWORD post_findnext(POSTMANCMD *post, int fd, FFBLK *ff);

#endif



