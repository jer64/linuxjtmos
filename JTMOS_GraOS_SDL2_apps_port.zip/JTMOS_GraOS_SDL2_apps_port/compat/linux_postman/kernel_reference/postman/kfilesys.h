#ifndef __INCLUDED_KFILESYS_H__
#define __INCLUDED_KFILESYS_H__

#include "postman.h"

// KFILESYS functions
void PostmanAckPacket(POSTMANCMD *p,int whichAck);
void kfilesys_pcmd_create_file(POSTMANCMD *p);
void kfilesys_pcmd_delete_file(POSTMANCMD *p);
void kfilesys_pcmd_read_file(POSTMANCMD *p);
void kfilesys_pcmd_write_file(POSTMANCMD *p);
void kfilesys_pcmd_get_file_size(POSTMANCMD *p);
void kfilesys_pcmd_add_blocks(POSTMANCMD *p);
void kfilesys_pcmd_fexist(POSTMANCMD *p);
void kfilesys_pcmd_readblock(POSTMANCMD *p);
void kfilesys_pcmd_writeblock(POSTMANCMD *p);
void kfilesys_pcmd_drawframe(POSTMANCMD *p);
void kfilesys_pcmd_setsize(POSTMANCMD *p);
void kfilesys_pcmd_getfiledatablock(POSTMANCMD *p);
void kfilesys_pcmd_createdirectory(POSTMANCMD *p);
void kfilesys_pcmd_formatdrive(POSTMANCMD *p);
void kfilesys_pcmd_findnext(POSTMANCMD *p);
void kfilesys_pcmd_findfirst(POSTMANCMD *p);
void kfilesys_pcmd_close(POSTMANCMD *p);
void kfilesys_pcmd_chdir(POSTMANCMD *p);
void kfilesys_pcmd_is_drive_ready(POSTMANCMD *p);
void kfilesys_pcmd_getcwd(POSTMANCMD *p);

// For [cache high](FAT/FS) flusher:
extern int kfilesysLastSec;

//
#include "kfilesysService.h"

#endif

