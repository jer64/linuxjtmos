#ifndef __INCLUDED_KFILESYS_MSG_H__
#define __INCLUDED_KFILESYS_MSG_H__

int kfilesys_packetHandler(int id, POSTMANCMD *p);
int kfilesysLastPacketID;

#endif

