//
#ifndef __INCLUDED_KMULTIMEDIASERVICE_H__
#define __INCLUDED_KMULTIMEDIASERVICE_H__

//
void kmultimedia_init(void);
void kmultimedia_restart(void);
void kmultimediaService(void);

#endif


