#ifndef __INCLUDED_POSTCMDS_COM_H__
#define __INCLUDED_POSTCMDS_COM_H__

//
int PostmanWaitAck(POSTMANCMD *p);
void postman_SetReturnValue(POSTMANCMD *p, int val);
void PostmanAckPacket(POSTMANCMD *p, int whichAck);
int PostmanPost(POSTMANCMD *p);

#endif
