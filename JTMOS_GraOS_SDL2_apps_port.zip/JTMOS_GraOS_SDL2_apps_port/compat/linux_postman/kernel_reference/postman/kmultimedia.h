#ifndef __INCLUDED_KMULTIMEDIA_H__
#define __INCLUDED_KMULTIMEDIA_H__

#include "kernel32.h"
#include "postman.h"

void media_pcmd_setpalettemap(POSTMANCMD *p);
void media_pcmd_setpalette(POSTMANCMD *p);
void media_pcmd_initaudio(POSTMANCMD *p);
void media_pcmd_sendaudio(POSTMANCMD *p);
void media_pcmd_getaudioposition(POSTMANCMD *p);

//
#include "kmultimediaService.h"

#endif
