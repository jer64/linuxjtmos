#ifndef JTMOS_LINUX_WINDOWS_COMPAT_H
#define JTMOS_LINUX_WINDOWS_COMPAT_H
#include <jtmos/app_port.h>
#endif
