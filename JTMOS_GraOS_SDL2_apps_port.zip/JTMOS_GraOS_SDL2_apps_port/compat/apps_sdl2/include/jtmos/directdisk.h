#ifndef JTMOS_DIRECTDISK_H
#define JTMOS_DIRECTDISK_H
#ifdef JTMOS
#else
#include <jtmos/app_port.h>
int getdevnrbyname(const char *name);
int getdevicenrbyname(const char *name);
int readblock(int devnr,int block,BYTE *buf);
int writeblock(int devnr,int block,const BYTE *buf);
int diskChange(int devnr);
int formatDrive(const char *name);
#endif
#endif
