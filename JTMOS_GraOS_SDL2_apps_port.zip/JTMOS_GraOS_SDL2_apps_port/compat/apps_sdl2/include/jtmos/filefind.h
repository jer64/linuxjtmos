#ifndef JTMOS_FILEFIND_H
#define JTMOS_FILEFIND_H
#ifdef JTMOS
/* Native header is supplied by JTMOS SDK. */
#else
#include <jtmos/app_port.h>
#define JTMFS_ID_FILE 1
#define JTMFS_ID_DIRECTORY 2
typedef struct {
    char ff_name[256];
    int ff_fsize;
    int ff_attrib;
} FFBLK;
int findfirst(const char *pattern, FFBLK *ff);
int findnext(int handle, FFBLK *ff);
#endif
#endif
