#ifndef JTMOS_VIDEO_H
#define JTMOS_VIDEO_H
#ifdef JTMOS
/* Native JTMOS SDK header is used in a JTMOS build. */
#else
#include <jtmos/app_port.h>
int setmode(int mode);
int setvmode(int mode);
int setpalette(int index,int r,int g,int b);
int setpalettemap(int offset,int amount,const BYTE *palette);
void jtmos_drawframe1(const BYTE *buf);
void jtmos_drawframe3(const BYTE *buf,int offset,int amount);
#define JTMOS_DF_PICK(_1,_2,_3,NAME,...) NAME
#define drawframe(...) JTMOS_DF_PICK(__VA_ARGS__,jtmos_drawframe3,jtmos_drawframe3,jtmos_drawframe1)(__VA_ARGS__)
void waitretrace(void);
DWORD GetTickCount(void);
int InitAudio(void);
int SendAudio(const BYTE *data,int length,int channel,int rate);
int GetAudioPosition(void);
#endif
#endif
