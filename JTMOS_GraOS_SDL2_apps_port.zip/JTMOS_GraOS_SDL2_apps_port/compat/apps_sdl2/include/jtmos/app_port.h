#ifndef JTMOS_APP_PORT_H
#define JTMOS_APP_PORT_H

#ifdef JTMOS
/* Native JTMOS build: do not replace the operating-system ABI. */
#else

#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

#ifndef BYTE
typedef uint8_t BYTE;
#endif
#ifndef WORD
typedef uint16_t WORD;
#endif
#ifndef DWORD
typedef uint32_t DWORD;
#endif

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

/* Borland/JTMOS compatible colour numbers. */
#ifndef BLACK
#define BLACK 0
#define BLUE 1
#define GREEN 2
#define CYAN 3
#define RED 4
#define MAGENTA 5
#define BROWN 6
#define LIGHTGRAY 7
#define DARKGRAY 8
#define LIGHTBLUE 9
#define LIGHTGREEN 10
#define LIGHTCYAN 11
#define LIGHTRED 12
#define LIGHTMAGENTA 13
#define YELLOW 14
#define WHITE 15
#endif

/* JTMOS key values use an extended-key word: low byte 0, scan code high byte. */
#define JKEY_EXT(sc)       ((int)((sc) << 8))
#define JKEY_ESC           27
#define JKEY_BACKSPACE     8
#define JKEY_CURSOR_UP     JKEY_EXT(0x48)
#define JKEY_CURSOR_DOWN   JKEY_EXT(0x50)
#define JKEY_CURSOR_LEFT   JKEY_EXT(0x4b)
#define JKEY_CURSOR_RIGHT  JKEY_EXT(0x4d)
#define JKEY_HOME          JKEY_EXT(0x47)
#define JKEY_END           JKEY_EXT(0x4f)
#define JKEY_PAGE_UP       JKEY_EXT(0x49)
#define JKEY_PAGE_DOWN     JKEY_EXT(0x51)
#define JKEY_INSERT        JKEY_EXT(0x52)
#define JKEY_DELETE        JKEY_EXT(0x53)
#define JKEY_F1            JKEY_EXT(0x3b)
#define JKEY_F2            JKEY_EXT(0x3c)
#define JKEY_F3            JKEY_EXT(0x3d)
#define JKEY_F4            JKEY_EXT(0x3e)
#define JKEY_F5            JKEY_EXT(0x3f)
#define JKEY_F6            JKEY_EXT(0x40)
#define JKEY_F7            JKEY_EXT(0x41)
#define JKEY_F8            JKEY_EXT(0x42)
#define JKEY_F9            JKEY_EXT(0x43)
#define JKEY_F10           JKEY_EXT(0x44)
#define JKEY_F11           JKEY_EXT(0x57)
#define JKEY_F12           JKEY_EXT(0x58)

#define APPRAM_256K  (256u*1024u)
#define APPRAM_1024K (1024u*1024u)
#define APPRAM_2048K (2048u*1024u)
#define APPRAM_4096K (4096u*1024u)
#define SYSMEMREQ(x) /* native JTMOS loader metadata; no-op on Linux */

void SwitchToThread(void);
void Sleep(unsigned int ms);
void jtmos_sleep_ticks(unsigned int ticks);
int GetCurrentThread(void);
int GetThreadPID(const char *name);
void IdentifyThread(int pid, const char *name);
int KillThread(int pid);

int GetThreadCount(void);
int GetThreadUniquePID(int index);
int GetThreadPriority(int pid);
int GetThreadSpending(int pid);
int GetThreadMemoryUsage(int pid);
int GetThreadName(int pid, char *out);
int GetMemorySize(void);
int GetAmountFree(void);
int GetSeconds(void);
int GetCTRL(void);
int GetALT(void);
int startMessageBox(void);
int GetCurrentTerminal(void);
int SetThreadTerminal(int pid, int terminal);
int cexec(const char *cmd, const char *search_path);
char *sptstr(char *dst, const char *src, int delimiter, int index, int max_words);

int getch1(void);
int jtmos_getch(void);
int jtmos_kbhit(void);
void jtmos_clrscr(void);
void jtmos_gotoxy(int x, int y);
void jtmos_textcolor(int c);
void jtmos_textbackground(int c);
int jtmos_cprintf(const char *fmt, ...);
int jtmos_printf(const char *fmt, ...);
int jtmos_putchar(int c);
int jtmos_puts(const char *s);
void jtmos_console_flush(void);
void jtmos_console_shutdown(void);

long fsizeof(const char *path);
int fexist(const char *path);
void StretchPrint(const char *s, int width);

/* Remap only after the system headers above have already been parsed. */
#define getch()             jtmos_getch()
#define kbhit()             jtmos_kbhit()
#define clrscr()            jtmos_clrscr()
#define gotoxy(x,y)         jtmos_gotoxy((x),(y))
#define textcolor(c)        jtmos_textcolor((c))
#define textbackground(c)   jtmos_textbackground((c))
#define cprintf             jtmos_cprintf
#define printf              jtmos_printf
#define putchar(c)          jtmos_putchar((c))
#define puts(s)             jtmos_puts((s))
#define delay(ms)           Sleep((unsigned int)(ms))

/* Legacy JTMOS sleep() uses scheduler ticks in these applications. */
#define sleep(ticks)        jtmos_sleep_ticks((unsigned int)(ticks))

#endif /* !JTMOS */
#endif
