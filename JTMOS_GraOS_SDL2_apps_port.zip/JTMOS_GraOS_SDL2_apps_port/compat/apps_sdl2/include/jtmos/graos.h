#ifndef JTMOS_GRAOS_H
#define JTMOS_GRAOS_H
#ifdef JTMOS
/* Native SDK supplies this header. */
#else
#include <jtmos/app_port.h>
#include <jtmos/msgbox.h>
#include <jtmos/graosprotocol.h>
typedef struct { int id; int v[32]; char text[256]; } GUICMD;
#define STANDARD_WINDOW 0x0001
#define WINDOW_AUTOCLEAR 0x0002
#define TASKBAR_WINDOW 0x0004
#define TYPE_BITMAP_SCREEN 1
#define TYPE_TERMINAL_EMULATION 2
int connectGraos(void);
int createWindow(int x,int y,int w,int h,const char *title,int flags);
int closeWindow(int wid);
int refreshWindow(int wid);
int addFrameBuffer(int wid,BYTE *buf,int x,int y,int w,int h,int bpp,int type,int terID);
int createButton(int wid,int x,int y,int w,int h,int id,const char *text);
int bgexecEx(const char *program,const char *cwd,int terminal_id);
int CreateTerminal(void);
void OutTermKey(int terID,int key);
#define OutputTerminalKeyboardBuffer(terID,key) OutTermKey((terID),(key))
void jtmos_graos_pump(void);
#endif
#endif
