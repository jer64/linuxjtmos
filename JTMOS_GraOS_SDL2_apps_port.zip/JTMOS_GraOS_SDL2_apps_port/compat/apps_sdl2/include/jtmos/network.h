#ifndef JTMOS_NETWORK_H
#define JTMOS_NETWORK_H
#ifdef JTMOS
#else
#include <jtmos/app_port.h>
#define IP_PROTO_ICMP 1
#define IP_PROTO_TCP 6
#pragma pack(push,1)
typedef struct { unsigned ihl:4,version:4; BYTE tos; WORD len; WORD ipid; WORD ipoffset; BYTE ttl; BYTE proto; WORD chksum; DWORD srcip; DWORD dstip; } IPHDR;
typedef struct { WORD srcport,dstport; DWORD seqno,ackno; unsigned reserved:4,doff:4; unsigned fin:1,syn:1,rst:1,psh:1,ack:1,urg:1,ece:1,cwr:1; WORD window,chksum,urgp; } TCPHDR;
#pragma pack(pop)
int OpenSocket(DWORD ip,int port);
int CloseSocket(int sh);
#endif
#endif
