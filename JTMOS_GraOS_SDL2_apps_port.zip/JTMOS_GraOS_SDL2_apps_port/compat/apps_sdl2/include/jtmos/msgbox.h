#ifndef __INCLUDED_MSGBOX_H__
#define __INCLUDED_MSGBOX_H__

#include <jtmos/app_port.h>

#define MB_PROTOCOL_DC       12341234
#define MB_PROTOCOL_POSTMAN  46842632
#define MB_PROTOCOL_GRAOS    99436111

#define MSG_RESERVED         0x55555555u
#define MSG_FREE             0xAAAAAAAAu
#define ISFREEX              0x00000010u
#define MSGBOX_MAGIC1        0x55AACCEEu
#define MSGBOX_MAGIC2        0xFF0088DDu

#define N_MAX_QUEUED_MSGS    5
#define N_MAX_BYTES_PER_MSG  2048

typedef struct {
    DWORD magic1;
    DWORD isFree;
    int type;
    int protocol;
    int sndPID;
    int rcvPID;
    int amount;
    DWORD un;
    DWORD magic2;
    BYTE buf[N_MAX_BYTES_PER_MSG];
} MSG;

typedef struct {
    char isFree;
    char name[256];
    MSG q[N_MAX_QUEUED_MSGS];
    int n_q;
} MSGBOX;

MSGBOX *createMessageBox(void);
void initMessageBox(MSGBOX *m);
int receiveMessage(MSG *om);
int sendMessage(MSG *m, int pid);
int ActivateThreadMessageBox(int pid);
int VerifyMessage(MSG *msg);

#endif
