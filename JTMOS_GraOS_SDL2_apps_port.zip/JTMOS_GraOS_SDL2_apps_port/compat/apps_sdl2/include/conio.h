#ifndef JTMOS_LINUX_CONIO_H
#define JTMOS_LINUX_CONIO_H
#include <jtmos/app_port.h>
#endif
