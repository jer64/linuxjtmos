#ifndef JTMOS_LINUX_DOS_H
#define JTMOS_LINUX_DOS_H
#include <jtmos/app_port.h>
#ifndef JTMOS
#define far
#define MK_FP(seg,off) ((void*)0)
#endif
#endif
