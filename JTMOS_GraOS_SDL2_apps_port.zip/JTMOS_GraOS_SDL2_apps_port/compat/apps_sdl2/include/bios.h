#ifndef JTMOS_LINUX_BIOS_COMPAT_H
#define JTMOS_LINUX_BIOS_COMPAT_H
#include <jtmos/app_port.h>
#ifndef JTMOS
#define far
#define _NORMALCURSOR 1
#define _NOCURSOR 0
#define MK_FP(seg,off) ((void*)0)
static inline void *_jtmos_getvect(int n){(void)n;return NULL;}
#define getvect(n) _jtmos_getvect(n)
static inline void _setcursortype(int t){(void)t;}
static inline unsigned char inp(unsigned short p){(void)p;return 0;}
static inline unsigned char outp(unsigned short p,unsigned char v){(void)p;return v;}
#endif
#endif
#ifndef _DISK_READ
#define _DISK_READ 2
#define _DISK_WRITE 3
#endif
static inline int biosdisk(int cmd,int drive,int head,int track,int sector,int nsects,void *buf){(void)cmd;(void)drive;(void)head;(void)track;(void)sector;(void)nsects;if(buf)memset(buf,0,(size_t)(nsects>0?nsects:1)*512u);return 1;}
static inline unsigned short inpw(unsigned short p){(void)p;return 0;}
static inline unsigned char peekb(unsigned short seg,unsigned short off){(void)seg;(void)off;return 0;}
static inline unsigned char inportb(unsigned short p){return inp(p);}
static inline void outportb(unsigned short p,unsigned char v){(void)outp(p,v);}
