#define _POSIX_C_SOURCE 200809L
#include <jtmos/filefind.h>
#include <dirent.h>
#include <fnmatch.h>
#include <sys/stat.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct { int used; DIR *d; char dir[1024]; char pat[256]; } FINDCTX;
static FINDCTX ctx[32];
static int fill(FINDCTX *c, FFBLK *ff)
{
 struct dirent *de;struct stat st;char path[1400];
 while((de=readdir(c->d))!=NULL){if(!strcmp(de->d_name,".")||!strcmp(de->d_name,".."))continue;if(fnmatch(c->pat,de->d_name,0)!=0)continue;snprintf(path,sizeof(path),"%s/%s",c->dir,de->d_name);memset(ff,0,sizeof(*ff));snprintf(ff->ff_name,sizeof(ff->ff_name),"%s",de->d_name);if(stat(path,&st)==0){ff->ff_attrib=S_ISDIR(st.st_mode)?JTMFS_ID_DIRECTORY:JTMFS_ID_FILE;ff->ff_fsize=S_ISDIR(st.st_mode)?0:(st.st_size>0x7fffffff?0x7fffffff:(int)st.st_size);}else ff->ff_fsize=-1;return 0;}return 1;
}
int findfirst(const char *pattern, FFBLK *ff)
{
 int i;const char *slash;char dir[1024]=".";char pat[256]="*";if(!pattern||!ff)return 0;slash=strrchr(pattern,'/');if(slash){size_t n=(size_t)(slash-pattern);if(n==0)strcpy(dir,"/");else{if(n>=sizeof(dir))n=sizeof(dir)-1;memcpy(dir,pattern,n);dir[n]=0;}snprintf(pat,sizeof(pat),"%s",slash+1);}else snprintf(pat,sizeof(pat),"%s",pattern);if(!*pat)strcpy(pat,"*");for(i=0;i<32;i++)if(!ctx[i].used)break;if(i==32)return 0;ctx[i].d=opendir(dir);if(!ctx[i].d)return 0;ctx[i].used=1;snprintf(ctx[i].dir,sizeof(ctx[i].dir),"%s",dir);snprintf(ctx[i].pat,sizeof(ctx[i].pat),"%s",pat);if(fill(&ctx[i],ff)){closedir(ctx[i].d);memset(&ctx[i],0,sizeof(ctx[i]));return 0;}return 10000+i;
}
int findnext(int handle, FFBLK *ff)
{
 int i=handle-10000;if(i<0||i>=32||!ctx[i].used||!ff)return 1;if(fill(&ctx[i],ff)==0)return 0;closedir(ctx[i].d);memset(&ctx[i],0,sizeof(ctx[i]));return 1;
}
