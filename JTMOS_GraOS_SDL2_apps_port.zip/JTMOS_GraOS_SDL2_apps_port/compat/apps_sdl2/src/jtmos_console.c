#define _POSIX_C_SOURCE 200809L
#include <jtmos/app_port.h>
#undef printf
#undef putchar
#undef puts
#undef getch
#undef kbhit
#undef clrscr
#undef gotoxy
#undef textcolor
#undef textbackground
#undef cprintf
#undef sleep
#undef delay
#include "jtmos_sdl_runtime.h"
#include <stdarg.h>
#include <sys/stat.h>
#include <sched.h>
#include <signal.h>
#include <errno.h>
#include <ctype.h>
#include <time.h>
extern int ActivateThreadMessageBox(int pid);

#define COLS 80
#define ROWS 60
typedef struct { unsigned char ch,fg,bg; } CELL;
static CELL cells[ROWS][COLS];
static int cx,cy,fg=7,bg=0,console_init;
static int pending_key;
static int ctrl_state, alt_state;

static uint8_t glyph_row(unsigned char ch,int row)
{
 static const uint8_t digits[10][7]={{14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},{30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},{14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},{14,17,17,15,1,1,14}};
 static const uint8_t upper[26][7]={{14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},{30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},{14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},{7,2,2,2,18,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},{17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},{30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},{15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},{17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},{17,17,10,4,4,4,4},{31,1,2,4,8,16,31}};
 if(row<0||row>6)return 0;if(ch>='a'&&ch<='z')ch=(unsigned char)(ch-'a'+'A');if(ch>='0'&&ch<='9')return digits[ch-'0'][row];if(ch>='A'&&ch<='Z')return upper[ch-'A'][row];
 switch(ch){case ' ':return 0;case '.':return row==6?4:0;case ',':return row==5?4:row==6?8:0;case ':':return(row==2||row==5)?4:0;case ';':return row==2?4:row==5?4:row==6?8:0;case '-':return row==3?14:0;case '_':return row==6?31:0;case '+':return row==3?31:(row>=1&&row<=5?4:0);case '=':return(row==2||row==4)?31:0;case '/':return(uint8_t)(1u<<(row<5?(4-row):0));case '\\':return(uint8_t)(1u<<(row<5?row:4));case '|':return 4;case '!':return row<5?4:row==6?4:0;case '?':{static const uint8_t q[7]={14,17,1,2,4,0,4};return q[row];}case '(' :return(row==0||row==6)?2:(row==1||row==5?4:8);case ')':return(row==0||row==6)?8:(row==1||row==5?4:2);case '[':return(row==0||row==6)?14:8;case ']':return(row==0||row==6)?14:2;case '#':return(row==2||row==4)?31:10;case '*':return row==2?21:row==3?14:row==4?21:0;case '$':{static const uint8_t d[7]={4,15,20,14,5,30,4};return d[row];}default:return 0;}
}
static void ensure_console(void)
{
 int y,x;if(console_init)return;for(y=0;y<ROWS;y++)for(x=0;x<COLS;x++){cells[y][x].ch=' ';cells[y][x].fg=7;cells[y][x].bg=0;}if(jsdl_init("JTMOS SDL2/GraOS console",640,480,1)==0)console_init=1;else console_init=-1;
}
static void scroll_up(void)
{
 int x;memmove(cells[0],cells[1],sizeof(cells)-sizeof(cells[0]));for(x=0;x<COLS;x++){cells[ROWS-1][x].ch=' ';cells[ROWS-1][x].fg=(unsigned char)fg;cells[ROWS-1][x].bg=(unsigned char)bg;}cy=ROWS-1;
}
static void cell_put(int ch)
{
 ensure_console();if(ch=='\r'){cx=0;return;}if(ch=='\n'){cx=0;if(++cy>=ROWS)scroll_up();return;}if(ch=='\b'){if(cx>0)cx--;cells[cy][cx].ch=' ';return;}if(ch=='\t'){int n=8-(cx&7);while(n--)cell_put(' ');return;}if(ch<32)return;if(cx>=COLS){cx=0;if(++cy>=ROWS)scroll_up();}cells[cy][cx].ch=(unsigned char)ch;cells[cy][cx].fg=(unsigned char)fg;cells[cy][cx].bg=(unsigned char)bg;if(++cx>=COLS){cx=0;if(++cy>=ROWS)scroll_up();}
}
void jtmos_console_flush(void)
{
 int x,y,r,c;uint8_t *p;ensure_console();if(console_init!=1)return;p=jsdl_pixels();if(!p)return;for(y=0;y<ROWS;y++)for(x=0;x<COLS;x++){CELL ce=cells[y][x];for(r=0;r<8;r++){uint8_t bits=r<7?glyph_row(ce.ch,r):0;for(c=0;c<8;c++)p[(y*8+r)*640+x*8+c]=(c>=1&&c<=5&&(bits&(1u<<(5-c))))?ce.fg:ce.bg;}}/* cursor */if(cx>=0&&cx<COLS&&cy>=0&&cy<ROWS)for(c=1;c<7;c++)p[(cy*8+7)*640+cx*8+c]=(uint8_t)fg;jsdl_present();
}
int jtmos_printf(const char *fmt,...)
{
 char b[8192];int n,i;va_list ap;va_start(ap,fmt);n=vsnprintf(b,sizeof(b),fmt,ap);va_end(ap);if(n<0)return n;fwrite(b,1,(size_t)(n<(int)sizeof(b)?n:(int)sizeof(b)-1),stdout);fflush(stdout);for(i=0;b[i]&&i<(int)sizeof(b);i++)cell_put((unsigned char)b[i]);jtmos_console_flush();return n;
}
int jtmos_cprintf(const char *fmt,...){char b[8192];int n,i;va_list ap;va_start(ap,fmt);n=vsnprintf(b,sizeof(b),fmt,ap);va_end(ap);for(i=0;b[i];i++)cell_put((unsigned char)b[i]);fputs(b,stdout);fflush(stdout);jtmos_console_flush();return n;}
int jtmos_putchar(int c){fputc(c,stdout);fflush(stdout);cell_put(c);jtmos_console_flush();return c;}
int jtmos_puts(const char *s){int i;fputs(s,stdout);fputc('\n',stdout);fflush(stdout);for(i=0;s[i];i++)cell_put((unsigned char)s[i]);cell_put('\n');jtmos_console_flush();return 0;}
void jtmos_clrscr(void){int x,y;ensure_console();for(y=0;y<ROWS;y++)for(x=0;x<COLS;x++){cells[y][x].ch=' ';cells[y][x].fg=(unsigned char)fg;cells[y][x].bg=(unsigned char)bg;}cx=cy=0;jtmos_console_flush();}
void jtmos_gotoxy(int x,int y){ensure_console();cx=x>0?x-1:0;cy=y>0?y-1:0;if(cx>=COLS)cx=COLS-1;if(cy>=ROWS)cy=ROWS-1;}
void jtmos_textcolor(int c){fg=c&15;}void jtmos_textbackground(int c){bg=c&15;}
int getch1(void){int k;if(pending_key){k=pending_key;pending_key=0;}else{k=jsdl_poll_key();}if(k<0){ctrl_state=alt_state=0;return 27;}ctrl_state=(k&0x10000)?1:0;alt_state=(k&0x20000)?1:0;return k&0xffff;}
int jtmos_getch(void){int k;if(pending_key){k=pending_key;pending_key=0;}else{k=jsdl_wait_key();}if(k<0){ctrl_state=alt_state=0;return 27;}ctrl_state=(k&0x10000)?1:0;alt_state=(k&0x20000)?1:0;return k&0xffff;}
int jtmos_kbhit(void){int k;if(pending_key)return 1;k=jsdl_poll_key();if(k<0){pending_key=27;return 1;}if(!k)return 0;pending_key=k;return 1;}
void jtmos_console_shutdown(void){jsdl_shutdown();console_init=0;}
extern void jtmos_graos_pump(void) __attribute__((weak));
void SwitchToThread(void){if(jtmos_graos_pump)jtmos_graos_pump();sched_yield();}
void Sleep(unsigned int ms){jsdl_sleep_ms(ms);}
void jtmos_sleep_ticks(unsigned int ticks){jsdl_sleep_ms(ticks*10u);}
int GetCurrentThread(void){return (int)getpid();}
static void namepath(char *out,size_t n,const char *name){size_t i,j=0;snprintf(out,n,"/tmp/jtmos-name-%u-",(unsigned)getuid());j=strlen(out);for(i=0;name&&name[i]&&j+1<n;i++)out[j++]=isalnum((unsigned char)name[i])?name[i]:'_';out[j]=0;}
void IdentifyThread(int pid,const char *name){char p[512];FILE *f;namepath(p,sizeof(p),name);f=fopen(p,"w");if(f){fprintf(f,"%d\n",pid);fclose(f);}}
int GetThreadPID(const char *name){char p[512];FILE *f;int pid=-1;namepath(p,sizeof(p),name);f=fopen(p,"r");if(!f)return-1;if(fscanf(f,"%d",&pid)!=1)pid=-1;fclose(f);if(pid>0&&kill(pid,0)==0)return pid;return-1;}
int KillThread(int pid){return pid>0?kill(pid,SIGTERM):-1;}
long fsizeof(const char *path){struct stat st;return(path&&stat(path,&st)==0)?(long)st.st_size:-1;}
int fexist(const char *path){struct stat st;if(!path||stat(path,&st))return 0;return S_ISDIR(st.st_mode)?2:1;}
void StretchPrint(const char *s,int width){int i,n=s?(int)strlen(s):0;for(i=0;i<n;i++)cell_put((unsigned char)s[i]);for(i=n;i<width;i++)cell_put(' ');fputs(s?s:"",stdout);for(i=n;i<width;i++)fputc(' ',stdout);fflush(stdout);jtmos_console_flush();}

#include <sys/sysinfo.h>
int GetThreadCount(void){return 1;}
int GetThreadUniquePID(int index){return index==0?(int)getpid():-1;}
int GetThreadPriority(int pid){return pid==(int)getpid()?1:0;}
int GetThreadSpending(int pid){(void)pid;return (int)clock();}
int GetThreadMemoryUsage(int pid){char path[64],line[256];FILE *f;long pages=0;(void)pid;snprintf(path,sizeof(path),"/proc/%d/statm",(int)getpid());f=fopen(path,"r");if(f){if(fgets(line,sizeof(line),f))sscanf(line,"%*ld %ld",&pages);fclose(f);}return (int)(pages*sysconf(_SC_PAGESIZE));}
int GetThreadName(int pid,char *out){char path[64];FILE *f;if(!out)return 1;snprintf(path,sizeof(path),"/proc/%d/comm",pid);f=fopen(path,"r");if(!f){strcpy(out,"linux-app");return 1;}if(!fgets(out,255,f))strcpy(out,"linux-app");fclose(f);out[strcspn(out,"\r\n")]=0;return 0;}
int GetMemorySize(void){long p=sysconf(_SC_PHYS_PAGES),s=sysconf(_SC_PAGESIZE);long long v=(long long)p*s;return v>0x7fffffff?0x7fffffff:(int)v;}
int GetAmountFree(void){struct sysinfo si;if(sysinfo(&si)==0){unsigned long long v=(unsigned long long)si.freeram*si.mem_unit;return v>0x7fffffff?0x7fffffff:(int)v;}return 0;}
int GetSeconds(void){return (int)time(NULL);}
int GetCTRL(void){return ctrl_state;}
int GetALT(void){return alt_state;}
int startMessageBox(void){return ActivateThreadMessageBox((int)getpid());}
static __thread int current_terminal_id;
int GetCurrentTerminal(void){return current_terminal_id;}
int SetThreadTerminal(int pid,int terminal){if(pid==(int)getpid())current_terminal_id=terminal;return 0;}
void delay(int ms){Sleep((unsigned int)(ms<0?0:ms));}
int cexec(const char *cmd,const char *search_path){(void)search_path;if(!cmd||!*cmd)return 1;return system(cmd)==0?0:1;}
char *sptstr(char *dst,const char *src,int delimiter,int index,int max_words){int i=0,n=0;(void)max_words;if(!dst||!src)return dst;while(*src&&i<index){if((unsigned char)*src==(unsigned char)delimiter){i++;while(*src==(char)delimiter)src++;}else src++;}while(*src&&*src!=(char)delimiter&&n<255)dst[n++]=*src++;dst[n]=0;return dst;}
