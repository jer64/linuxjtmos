#include <jtmos/network.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
int OpenSocket(DWORD ip,int port){int s;struct sockaddr_in a;s=socket(AF_INET,SOCK_STREAM,0);if(s<0)return-1;memset(&a,0,sizeof(a));a.sin_family=AF_INET;a.sin_port=htons((uint16_t)port);a.sin_addr.s_addr=(uint32_t)ip;if(connect(s,(struct sockaddr*)&a,sizeof(a))<0){close(s);return-1;}return s;}
int CloseSocket(int sh){return close(sh);}
