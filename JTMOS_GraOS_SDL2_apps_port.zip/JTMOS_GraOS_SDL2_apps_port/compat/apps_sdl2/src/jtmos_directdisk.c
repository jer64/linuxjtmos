#define _POSIX_C_SOURCE 200809L
#include <jtmos/directdisk.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
static int devfd[16];static char initd;
static void init(void){int i;if(initd)return;for(i=0;i<16;i++)devfd[i]=-1;initd=1;}
static const char* image_name(const char *name){const char *e;if(!name)return NULL;if(!strcmp(name,"floppy")){e=getenv("JTMOS_FLOPPY_IMAGE");return e?e:"floppy.img";}if(!strcmp(name,"ram")){e=getenv("JTMOS_RAM_IMAGE");return e?e:"ram.img";}if(!strcmp(name,"hda")){e=getenv("JTMOS_HDA_IMAGE");return e?e:"hda.img";}return name;}
int getdevnrbyname(const char *name){int i;const char *p=image_name(name);init();for(i=0;i<16;i++)if(devfd[i]<0){devfd[i]=open(p,O_RDWR|O_CREAT,0644);return devfd[i]>=0?i:-1;}return-1;}
int getdevicenrbyname(const char *name){return getdevnrbyname(name);}
int readblock(int d,int b,BYTE *buf){init();if(d<0||d>=16||devfd[d]<0||!buf)return-1;return pread(devfd[d],buf,512,(off_t)b*512)==512?0:-1;}
int writeblock(int d,int b,const BYTE *buf){init();if(d<0||d>=16||devfd[d]<0||!buf)return-1;return pwrite(devfd[d],buf,512,(off_t)b*512)==512?0:-1;}
int diskChange(int d){(void)d;return 0;}
int formatDrive(const char *name){const char *p=image_name(name);int fd=open(p,O_RDWR|O_CREAT|O_TRUNC,0644);if(fd<0)return 1;close(fd);return 0;}
