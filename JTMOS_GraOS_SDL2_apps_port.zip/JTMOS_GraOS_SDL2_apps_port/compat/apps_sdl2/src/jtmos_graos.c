#define _POSIX_C_SOURCE 200809L
#include <jtmos/graos.h>
#include "jtmos_sdl_runtime.h"
#undef OutputTerminalKeyboardBuffer
#undef clrscr
#undef gotoxy
#undef textcolor
#undef textbackground
#include "../../linux_sdl2/jtmos_host_term.h"
#include "../../linux_sdl2/directdraw.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

typedef struct {BYTE *buf;int x,y,w,h,bpp,type,ter;} FB;
static int gw=640,gh=480,wid_next=1,selfpid;static FB fb[8];static int nfb;
static void post_gui(int id,int value){MSG m;GUICMD *c=(GUICMD*)m.buf;memset(&m,0,sizeof(m));memset(c,0,sizeof(*c));c->id=id;c->v[0]=value;m.protocol=MB_PROTOCOL_GRAOS;m.amount=sizeof(*c);sendMessage(&m,selfpid);}
int connectGraos(void){selfpid=(int)getpid();ActivateThreadMessageBox(selfpid);VirtualTerminalInit();return 0;}
int createWindow(int x,int y,int w,int h,const char *title,int flags){(void)x;(void)y;(void)flags;gw=w>0?w:640;gh=h>0?h:480;jsdl_init(title?title:"GraOS",gw,gh,1);jsdl_resize(gw,gh);return wid_next++;}
int closeWindow(int wid){(void)wid;jsdl_shutdown();return 0;}
int addFrameBuffer(int wid,BYTE *buf,int x,int y,int w,int h,int bpp,int type,int terID){(void)wid;if(nfb>=8)return-1;fb[nfb]=(FB){buf,x,y,w,h,bpp,type,terID};return nfb++;}
int createButton(int wid,int x,int y,int w,int h,int id,const char *text){(void)wid;(void)id;BYTE *p=jsdl_pixels();int xx,yy;if(!p)return-1;for(yy=y;yy<y+h&&yy<gh;yy++)for(xx=x;xx<x+w&&xx<gw;xx++)if(xx>=0&&yy>=0)p[yy*gw+xx]=7;DirectDrawText(p,gw,gh,text?text:"",x+4,y+8);return 0;}
static void render_terminal(FB *f){BYTE *p=jsdl_pixels();SCREEN *s;int x,y;if(!p||!IsTerminalValid(f->ter))return;s=&screens[f->ter];for(y=0;y<f->h&&y<s->height;y++){char line[129];int n=f->w<128?f->w:128;for(x=0;x<n&&x<s->width;x++)line[x]=s->buf[(y*s->width+x)*2];line[x]=0;DirectDrawText(p,gw,gh,line,f->x,f->y+y*8);}}
int refreshWindow(int wid){int i,x,y;BYTE *p=jsdl_pixels();(void)wid;if(!p)return-1;for(i=0;i<nfb;i++){FB *f=&fb[i];if(f->type==TYPE_BITMAP_SCREEN&&f->buf){for(y=0;y<f->h;y++)if(f->y+y>=0&&f->y+y<gh)for(x=0;x<f->w;x++)if(f->x+x>=0&&f->x+x<gw)p[(f->y+y)*gw+f->x+x]=f->buf[y*f->w+x];}else if(f->type==TYPE_TERMINAL_EMULATION)render_terminal(f);}jsdl_present();jtmos_graos_pump();return 0;}
void jtmos_graos_pump(void){int k=jsdl_poll_key();if(k<0){post_gui(GSID_EXIT,0);return;}if(k){if(k&0x10000){int ch=k&0xff;if(ch>='a'&&ch<='z')k=ch-'a'+1;}post_gui(GSID_KEYPRESSED,k&0xffff);}}
int bgexecEx(const char *program,const char *cwd,int terminal_id){pid_t p=fork();(void)terminal_id;if(p==0){if(cwd)chdir(cwd);execlp(program,program,(char*)NULL);_exit(127);}return p<0?-1:(int)p;}
