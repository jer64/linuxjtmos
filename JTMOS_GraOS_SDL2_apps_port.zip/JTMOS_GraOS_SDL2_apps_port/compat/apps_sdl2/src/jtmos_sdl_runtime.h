#ifndef JTMOS_SDL_RUNTIME_H
#define JTMOS_SDL_RUNTIME_H
#include <stdint.h>

int jsdl_init(const char *title, int width, int height, int scale);
void jsdl_shutdown(void);
int jsdl_resize(int width, int height);
uint8_t *jsdl_pixels(void);
int jsdl_width(void);
int jsdl_height(void);
void jsdl_set_palette(int idx, int r, int g, int b);
void jsdl_present(void);
int jsdl_poll_key(void);      /* 0 if none, -1 on close */
int jsdl_wait_key(void);      /* blocks until key/close */
int jsdl_quit_requested(void);
void jsdl_sleep_ms(unsigned int ms);

#endif
