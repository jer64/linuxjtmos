# JTMOS V67.8.57.10.18.16.12 — PS/2 mouse reset-only attach

Target hardware result on eMachines EL1352:

- PS/2 keyboard works when BIOS/POST state is preserved.
- PS/2 mouse requires a device reset after POST.

Normal boot policy is therefore split by device:

1. Keyboard: BIOS-preserve; no device/controller reset.
2. Mouse: AUX-only recovery using i8042 D4 -> mouse FF, wait for FA/AA, then D4 -> F4.
3. No AD/AE keyboard disable/enable, no keyboard FF, and no i8042 command-byte rewrite.
4. GraOS does not reinitialize PS/2 hardware; it only consumes the stream.
5. IRQ12-less packet polling also preserves keyboard state and never disables the keyboard port.

`mouseinfo reinit` uses the same keyboard-preserving AUX-only reset path.
