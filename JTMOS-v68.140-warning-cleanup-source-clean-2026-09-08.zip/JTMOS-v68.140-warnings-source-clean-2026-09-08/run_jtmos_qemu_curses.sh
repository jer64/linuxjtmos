#!/bin/sh
set -eu
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
# Headless Linode/demo-friendly launcher. PS/2 input is enough for curses and
# avoids adding USB graphics/input complexity to a server VM.
export JTMOS_DISPLAY=${JTMOS_DISPLAY:-curses}
export JTMOS_USB_INPUT=${JTMOS_USB_INPUT:-off}
exec "$DIR/run_jtmos_qemu.sh" "$@"
