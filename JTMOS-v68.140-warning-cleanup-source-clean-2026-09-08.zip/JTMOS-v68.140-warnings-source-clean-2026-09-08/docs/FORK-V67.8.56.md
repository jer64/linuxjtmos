# JTMOS V67.8.56 fork()

JTMOS now exposes `pid_t fork(void)` to ELF32 Ring3 applications through syscall 127.

Semantics implemented in this generation:

- parent receives the new plain PID;
- child receives zero;
- the ELF image, libc heap and user stack are private copied pages;
- the child inherits the parent's current device/directory, terminal, command line,
  process name, page protections and scheduling priority;
- the existing unmapped stack guard page remains unmapped in the child;
- PID 0 and Ring0/kernel tasks cannot call `fork()`.

The userspace wrapper is deliberately assembly-level.  It passes the kernel the
caller's return EIP/ESP plus i386 callee-saved registers, allowing the child to
resume exactly as a C caller expects after `fork()` without depending on the
kernel's interrupt-handler stack layout.

Not inherited yet: kernel-mediated IRQ subscriptions, DMA allocations, message
boxes and device registrations.  Those privileged resources have explicit PID
ownership and must be reacquired by the child.  Open file descriptors are not
yet advertised as POSIX-inherited either because the current JTMOS descriptor
layer does not have shared open-file-description reference counting.  The child
also starts with a fresh lazy FPU/SSE save area rather than a bit-for-bit copy of
the parent's live coprocessor state.  The first fork ABI does not claim POSIX
multi-threaded-process semantics; JTMOS applications currently map one scheduled
task to one process PID.

The `fork` command in `libc/apps/fork.c` is a runtime smoke test.  Expected form:

    JTMOS fork test 1.0: parent PID=10
    fork: parent PID=10, child PID=11
    fork: child PID=11, fork()=0
    fork: child PID=11 terminated

The exact interleaving of the parent/child output is scheduler-dependent.
