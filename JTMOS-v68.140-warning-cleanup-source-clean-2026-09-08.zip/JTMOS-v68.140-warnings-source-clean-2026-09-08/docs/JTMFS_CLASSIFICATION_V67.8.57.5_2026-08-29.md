# JTMOS V67.8.57.5 — JTMFS entry classification

## Problem

JTMFS historically stored both entry kind and attributes in `JTMFS_FILE_ENTRY.type`,
but callers frequently treated that field as a single enum value.  For example,
`type == JTMFS_ID_DIRECTORY` recognizes `0x80` but misclassifies a hidden directory
`0x80 | 0x20 == 0xA0` as a normal file.  The same problem applies to the internal
`DIRNAME` metadata entry when attributes are present.

The tree also had two unrelated type namespaces named `ID_DIRECTORY` / `ID_FILE`:
one for the on-disk JTMFS entry and another for the RAM-only DirDB cache object.
That made accidental cross-layer comparisons easy.

## ABI-preserving classification

No existing on-disk bit is moved or renumbered.  V67.8.57.5 defines the low byte as:

| Bits | Mask | Meaning |
|---|---:|---|
| 0..5 | `0x3F` | attributes |
| 6..7 | `0xC0` | entry class |

Entry classes:

| Class | Value | Meaning |
|---|---:|---|
| `JTMFS_CLASS_FILE` | `0x00` | regular file; attributes may occupy bits 0..5 |
| `JTMFS_CLASS_DIRNAME` | `0x40` | internal directory-name metadata |
| `JTMFS_CLASS_DIRECTORY` | `0x80` | directory |
| `JTMFS_CLASS_RESERVED` | `0xC0` | invalid/reserved for future format use |

Attributes retain their historical values: read-only `0x01`, system `0x02`, device
`0x04`, archive `0x08`, executable `0x10`, hidden `0x20`.  The old public names remain
aliases, including the historical `JTMFS_ID_WRITEONLY` spelling for bit `0x01`.
`JTMFS_ID_READONLY` is now also defined because the DOS compatibility header already
referred to that spelling.

## API rules

Code must use `JTMFS_TYPE_IS_FILE`, `JTMFS_TYPE_IS_DIRNAME`,
`JTMFS_TYPE_IS_DIRECTORY`, `JTMFS_TYPE_HAS_ATTR`, and `JTMFS_TYPE_IS_VALID` instead
of comparing the whole `type` field to a bare class value.  `JTMFS_TYPE_BUILD`
constructs a class plus attributes without allowing the fields to overlap.

This means all of these remain directories:

- `0x80` — ordinary directory
- `0xA0` — hidden directory
- `0x88` — archive-marked directory
- `0xA2` — hidden + system directory

## DirDB separation

The directory cache now names its RAM-only object kinds `DIRDB_KIND_DIRECTORY` and
`DIRDB_KIND_FILE`.  Old `ID_DIRECTORY` / `ID_FILE` names remain source-compatibility
aliases, but new code uses the namespaced forms.  DirDB corruption validation rejects
live cache records whose kind is neither of the two valid RAM kinds.

## Integrity policy

`jtmfs_check()` / fsck rejects directory entries with unknown upper bits or the
reserved `0xC0` class.  Creation through `jtmfs_fentry()` also rejects invalid type
values.  Existing valid disks remain readable because all historical bit values are
unchanged.

The V67.8.57.4 SYSTEM-WALL remains independent of this change: filesystem entry
classification cannot weaken the geometric protection around boot, kernel, FAT, and
other JTMFS system blocks.

## Regression test

`tools/check_jtmfs_classification.sh` verifies:

1. the stable class/attribute masks;
2. identical public kernel/libc classification headers;
3. hidden/system/archive combinations retain their correct class;
4. reserved and unknown classifications are rejected;
5. no live kernel/userspace code falls back to exact DIRECTORY/DIRNAME equality;
6. DirDB and on-disk JTMFS type namespaces remain separated.
