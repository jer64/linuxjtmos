# JTMOS Turbo C / GraOS Game SDK

JTMOS provides two deliberately small ways to write graphical programs.

## 1. Turbo C source compatibility

Old DOS-era source can keep using `graphics.h`, `conio.h` and `dos.h`. `initgraph()` opens a GraOS window and gives the program a software RGBA framebuffer. BGI coordinates, colors, lines, rectangles, circles, text, viewports, palettes and `getimage()` / `putimage()` are translated by libc. `getch()` and `kbhit()` read keys from the active GraOS window while BGI is active.

```c
#include <graphics.h>
#include <conio.h>

int main(void)
{
    int gd=DETECT,gm;
    initgraph(&gd,&gm,"");
    setcolor(YELLOW);
    circle(320,240,80);
    getch();
    closegraph();
    return 0;
}
```

For games, call `jtmos_graph_autorefresh(0)` after `initgraph()`, draw a whole frame, and call `jtmos_graph_present()` once. This avoids one GraOS IPC refresh for every BGI primitive.

## 2. jtgame.h -- the easy path

`jtgame.h` is the small native JTMOS game API. A game needs no window manager or Postman code. It opens one GraOS window, owns one software framebuffer, polls keys, draws, presents and optionally paces the frame rate.

```c
#include <jtgame.h>

int main(void)
{
    if(jtgame_open("Game",320,200)) return 1;
    while(jtgame_running()) {
        if(jtgame_key()==JT_KEY_ESC) break;
        jtgame_clear(JT_RGB(0,0,20));
        jtgame_fillrect(100,70,40,40,JT_COLOR(YELLOW));
        jtgame_present();
        jtgame_wait_frame(60);
    }
    jtgame_close();
    return 0;
}
```

Useful calls are `jtgame_pixel`, `jtgame_line`, `jtgame_rect`, `jtgame_fillrect`, `jtgame_circle`, `jtgame_blit`, `jtgame_blit_key`, `jtgame_key`, `jtgame_kbhit`, `jtgame_present` and `jtgame_wait_frame`.

## Compile one program

From the JTMOS source tree:

```
./tools/jtcc libc/examples/turboc/jtgame_easy.c -o mygame.bin
```

The driver builds the JTMOS libc with two jobs and emits a static ELF32 JTMOS application.

## Compatibility design

The compatibility layer is source-level, not DOS binary emulation. `far`, `near` and `interrupt` are accepted compatibility spellings, but a JTMOS application is a flat 32-bit process. Programs that draw through BGI or `jtgame.h` are portable to GraOS; programs that write directly to DOS segment `A000:0000`, hook real-mode interrupts or depend on a specific BGI driver file still need conversion.

The intentional architecture is:

```
Turbo C source       jtgame.h source
      |                    |
 graphics.h/conio.h         |
      |                    |
      +------ JTMOS libc ---+
                 |
        GraOS client IPC
                 |
        window framebuffer
                 |
          GraOS desktop
```

This keeps beginner code short while preserving a lower-level route for classic C programs.

## 3. Game SDK 2: mouse, sprites and sound

The second SDK layer keeps the one-window model but adds the pieces a small game normally needs.

### Mouse

`jtgame_present()` refreshes the window-relative mouse state automatically. `jtgame_poll()` can be called at the start of a frame when edge-triggered button input is wanted immediately.

```c
jtgame_poll();
if(jtgame_mouse_inside() && jtgame_mouse_pressed(JT_MOUSE_LEFT)) {
    player_x=jtgame_mouse_x();
    player_y=jtgame_mouse_y();
}
```

The GraOS protocol command `GRAOS_GSID_GETMOUSESTATE` returns framebuffer-relative x/y coordinates, button bits and an inside/outside flag. This avoids exposing desktop/window geometry to games. The compatibility `mouse.h` also provides `initmouse`, `mousex`, `mousey`, `mousebuttons`, `getmousepos` and `setmouserange` for simple non-GraOS programs.

### Sprites

`jtsprite.h` treats an RGBA32 or indexed MCGA/VGA RAW image as a left-to-right sprite sheet. Sprites support animation ranges, looping, color-key or alpha-zero transparency, X/Y flipping, integer scaling and clipped drawing into the active `jtgame` framebuffer.

```c
JTSprite hero;
jtsprite_load_raw8(&hero,"hero.raw",64,16,16,16); /* four frames */
jtsprite_set_animation(&hero,0,3,8,1);

jtsprite_update(&hero,jtgame_ticks());
jtsprite_draw(&hero,x,y);
```

`jtsprite_init()` can point directly at a C pixel array, so tiny games do not need a resource loader. `jtsprite_overlap()` and `jtsprite_contains()` provide basic rectangular hit testing.

### Sound

`jtsound.h` is a small userspace mixer over the existing JTMOS generic audio syscalls. It mixes up to eight voices into unsigned 8-bit mono and sends short blocks to the kernel SB/GUS FIFO. A voice may be a sample or a generated square-wave tone. Samples can use their own rates; the mixer performs simple nearest-neighbour rate conversion while playing.

```c
JTSoundSample laser;
if(jtsound_init()==0) {
    if(jtsound_load_wav(&laser,"laser.wav")==0)
        jtsound_play(&laser,220,0);
}
```

The WAV loader accepts uncompressed PCM, mono or stereo, 8 or 16 bit, from 4 kHz through 44.1 kHz, and converts it to the mixer format. `jtsound_load_raw()` accepts unsigned 8-bit mono RAW data. `jtsound_tone()` and `jtsound_beep()` need no asset file. When `jtgame` is used, `jtgame_present()` calls `jtsound_update()` automatically. A sound-only program can call `jtsound_update()` itself in its loop.

### Complete small-game loop

```c
#include <jtgame.h>
#include <jtsprite.h>
#include <jtsound.h>

int main(void)
{
    if(jtgame_open("Game",320,200)) return 1;
    jtsound_init();

    while(jtgame_running()) {
        jtgame_poll();
        if(jtgame_key()==JT_KEY_ESC) break;
        if(jtgame_mouse_pressed(JT_MOUSE_LEFT)) jtsound_beep();

        jtgame_clear(JT_RGB(10,10,20));
        /* update and draw game objects here */
        jtgame_present();
        jtgame_wait_frame(60);
    }

    jtsound_shutdown();
    jtgame_close();
    return 0;
}
```

See `libc/examples/turboc/game_sdk2.c` for a self-contained animated sprite, mouse and sound demo.

## Runtime qualification

The JTMOS BGI layer is a GraOS client, not a direct-VESA fallback. `initgraph()`
therefore requires the `guiserver` process to be running. Use `graos` or
`pm find guiserver` from SQSH before starting a BGI application.

`bgidemo.bin` is the runtime smoke test. It checks VGAHI dimensions,
putpixel/getpixel, line endpoints, solid fills, viewport coordinates,
getimage/putimage readback and finally a GraOS keyboard event. A clean PASS on
the target machine is the minimum qualification before diagnosing a larger BGI
game such as `stuntcar.bin` at the game-logic level.

BGI is still considered experimental until this smoke test and representative
programs have been exercised on QEMU and real target hardware. Build/static
validation alone is not sufficient to call the compatibility layer production
ready.
