# JTMOS V67.8.57.1 — 64 KiB BIOS/PMODE kernel streaming and split root media

## Goal

Remove the old 576 KiB conventional-memory ceiling without asking BIOS INT 13h
to DMA across the VGA hole or across a 64 KiB DMA page. Keep BIOS disk access
in real mode, but use brief protected-mode copies between BIOS reads.

## Kernel loading

- A: boot image starts with the 9 KiB boot32pm loader (18 sectors).
- kernel32.bin.nz follows at logical floppy sector 18.
- BIOS reads 512-byte sectors into physical 0x00010000..0x0001FFFF.
- After 128 sectors (64 KiB), boot32pm enters protected mode and copies the
  completed bounce buffer to the high compressed staging area beginning at
  physical 0x01000000 (16 MiB).
- The loader returns to real mode before the next BIOS INT 13h call.
- The final partial chunk is copied in the same way.
- After all compressed bytes have been staged, boot32pm enters protected mode
  normally and nzip expands the stream to physical 0x00100000.
- Raw linked kernel window: 0x00100000..0x001FFFFF (1 MiB maximum).
- Compressed boot staging window: 0x01000000..0x010FFFFF (1 MiB maximum).
- The old 0x000A0000 VGA boundary is never crossed by BIOS staging.

The 593277-byte compressed image that failed the 576 KiB check needs 1159
512-byte sectors and ten protected-mode copy rounds (nine full 64 KiB chunks
plus one partial chunk), and is below the new 1 MiB limit.

## Media layout

### A: boot floppy — `jtm32.img`

1. boot32pm/boot.bin, logical sectors 0..17
2. kernel32/kernel32.bin.nz, beginning at logical sector 18
3. no sys:/system payload

### B: root floppy — `root1440.img`

- 1.44 MiB raw floppy image.
- Contains `tools/utilsdisk.img` at byte zero and zero padding after it.
- `utilsdisk.img` is a SQARC520 bootstrap archive.
- The historical 800 KiB boot-floppy sys: limit no longer applies; the root
  payload may use up to the full 1.44 MiB image.

### ATAPI root alternative — `utilities.iso`

- Raw SQARC utilities archive padded to 2048-byte sectors.
- `sys:` probes for the SQARC520 identifier after the 2048-byte safe area.
- B: is preferred when it contains a valid root archive; otherwise ATAPI is
  selected. The old A: sys partition remains only as a compatibility fallback.

The current GraOS startup extracts the selected root/system archive to the RAM
JTMFS root. Thus A: is boot-only and B:/ATAPI is the persistent distribution
medium, while the runtime root remains the existing RAM filesystem model.

## HDD installation

JTMFS boot payload reservation is increased to 1 MiB / 2048 sectors. Existing
volumes with the old smaller reservation must be reformatted before installing
the larger boot payload; the existing layout guard prevents overwriting FAT
metadata.

## Build outputs

A plain `make` (GNU make jobserver fixed at two jobs) produces:

- `jtm32.img` — A: boot-only image
- `root1440.img` — B: root/system image
- `utilities.iso` — ATAPI root/demo image

`run_jtmos_qemu.sh` attaches A:, B:, HDA and optionally the ATAPI image.
