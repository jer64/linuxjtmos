# JTMOS V67.8.54 responsive reward scheduler

The V67.8.53 scheduler entered the TSS scheduler on every PIT tick. With divisor 0x100 that is about 4661 IRQ0 events/s and only ~214 us between timer interrupts. V67.8.54 deliberately lowers the PIT rate to divisor 0x800 (~583 Hz) and decouples a PIT clock tick from a process preemption.

Policy: four dynamic levels (interactive, normal, background, batch) with approximately 5.1/6.9/10.3/17.2 ms quanta at the default PIT rate. Short voluntary bursts are promoted, full-quantum CPU bursts are demoted, successful block I/O gives one bounded promotion, and runnable waiters receive ~40 ms aging windows so no task can starve. Explicit JTMOS priority remains a floor for reward promotion.

The design intentionally gives CPU-bound background work longer uninterrupted quanta but lower dispatch preference. This improves throughput while bounding how long another runnable task can be delayed.

Timed `UsecSleep`/`MilSleep` now use scheduler deadline blocking instead of repeatedly yielding in a polling loop. A sleeping PID is not runnable until its deadline expires; `SwitchToThreadEx(pid)` explicitly wakes it.

## Empty-yield protection

A repeated `SwitchToThread()` loop that performs no work is not treated as interactive progress. Four consecutive zero-tick yields demote the task by one dynamic class. This prevents a background polling/yield loop from gaming the interactive reward while still preserving voluntary-yield fairness for tasks that actually execute a short burst first.
