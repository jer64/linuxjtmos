# JTMOS V67.8.57.6 — GraOS application/runtime fixes

Date: 2026-08-29

## Scope

This release audits the external GraOS applications and the common client/runtime
path rather than patching only one launcher failure.  The on-disk JTMFS format is
unchanged from V67.8.57.5.

## Main findings and fixes

### Window event routing

`graos_compat.c` used one small FIFO for asynchronous events and returned the next
queued event without checking which window it belonged to.  The queue is now
window-aware, grows to 32 entries, and preserves events for sibling windows until
the matching client requests them.  GraOS server PID discovery is also revalidated
so a restarted server does not leave clients using a stale cached PID.

### Terminal lifecycle

The external terminal client no longer transfers terminal ownership to its child.
The wrapper owns the terminal while GraOS references its surface, detects normal
child exit, detaches/frees the GraOS terminal surface, and closes the window.  The
internal GraOS terminal launcher similarly checks that the target program exists
before allocating a terminal and reaps terminal windows whose child has exited.

### Launcher

Launcher now checks whether each fixed `/bin/*.bin` program actually exists before
creating its button.  Programs that live only on the utilities/CD image therefore
do not produce dead buttons on the compact system/root image.  The manual command
box remains available.

### Filer

Filer no longer hard-codes `/hda/bin/edit.bin` and `/hda/bin/filer.hlp`; it uses
root-independent `/bin/...` paths.  Opening a file starts the editor through a
visible GraOS terminal with `bgexec` instead of blocking Filer with a foreground
`cexec`.  Executable files are also launched asynchronously so File Explorer
remains responsive.

### Picture and BGI input

Picture no longer waits on console `getch()` even though its input arrives as
GraOS window events.  It polls the actual bitmap window and exits on a key or the
window close event.  The BGI compatibility layer now exposes
`jtmos_graph_getch()`, which reads keyboard/close events from the actual GraOS BGI
window; `bgidemo` uses it instead of terminal input.

### Resources and install media

Picture searches `sqfam.raw` in the current directory, `/bin`, and `ram:/bin`.
The full utilities payload now includes `sqfam.raw`, while `picture.bin` and the
256000-byte image remain CD/utilities-only so the compact root image does not lose
256 KiB to a demo asset.  Bitmap demo receives equivalent `/bin`/RAM resource
fallbacks.

### Scheduling and taskbar

Idle GraOS clients use short `Sleep(10)` polling delays rather than tight loops.
The legacy taskbar's accidental `sleep(4)` four-second refresh was changed to
`Sleep(40)`, and it launches `/bin/launcher.bin` instead of depending on CWD.

### Canonical GraOS namespace and sources

External clients now use the canonical `GRAOS_*` protocol names.  Obsolete duplicate
`libc/apps/terminal.c(.mak)` and `controlpanel.c(.mak)` sources were removed; the
maintained implementations live under `libc/apps/gui/`.  This also makes the
release namespace check pass instead of carrying old GSID/window aliases in external
clients.

### Build dispatch

The app dispatcher Makefiles now use a `FORCE` prerequisite on `%.bin`.  This forces
entry into each app-specific Makefile even when an old `.bin` exists, while the
specific Makefile still performs normal timestamp checking.  A clean build therefore
cannot silently validate a stale client binary.

## Regression check

`tools/check_graos_apps.sh` checks the event router, PID revalidation, terminal child
lifecycle, internal terminal reaper, Picture/BGI input path, Launcher availability,
Filer asynchronous editor/executable launch, resource packaging, WinShell event
handling, taskbar timing/path, build dispatch, and canonical source layout.

It is part of the top-level `make check` target.

## Validation

Validated on the source tree with parallelism `-j2`:

- clean release app build: 50 ELF32 applications plus GraOS/external clients PASS;
- `make -j2 -C libc/apps check`: PASS;
- `make -j2 -C libc/apps/gui check`: PASS;
- `make -j2 -C graos-host check`: PASS;
- `make -j2 check`: PASS, including release layout and all JTMFS SYSTEM-WALL /
  1 MiB / classification checks;
- system install payload: 817590 bytes, below the 1.44 MiB root-media limit;
- full payload contains Picture plus `sqfam.raw`; compact system payload omits both;
- targeted kernel `init/graos_boot.o` build through generated.mak: PASS.

A complete kernel/boot image link cannot finish in the current build environment
because NASM is not installed.  Top-level `make -j2` reaches the assembler and
stops at `core/asm/aslib.o` with `nasm: No such file or directory`; no GraOS C or
ELF32 client compilation error precedes that failure.  QEMU is also unavailable,
so final runtime boot testing should be done on the user's normal JTMOS/QEMU setup.

## Suggested runtime retest

1. Boot GraOS and open Terminal, then exit the shell: the terminal window should
   close/reap cleanly.
2. Open Launcher on the compact root image: CD-only applications should not have
   dead buttons.
3. In Filer, open a text file: a visible editor terminal should appear while Filer
   remains responsive.
4. Run an executable from Filer: Filer should remain responsive.
5. From utilities/CD media, run Picture: a key or the close button should exit it.
6. Run the BGI demo: keyboard/close input should be handled by its GraOS window.
7. Open/close several GraOS windows rapidly to exercise per-window event routing.
