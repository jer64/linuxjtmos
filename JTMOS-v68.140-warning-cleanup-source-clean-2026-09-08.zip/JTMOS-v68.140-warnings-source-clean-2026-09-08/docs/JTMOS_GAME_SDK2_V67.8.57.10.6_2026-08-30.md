# JTMOS V67.8.57.10.6 — Game SDK 2

Date: 2026-08-30
Base: JTMOS V67.8.57.10.5 Turbo C / GraOS Game SDK

## Goal

Game SDK 2 makes small 2D games practical without exposing GraOS IPC, window-manager internals, or the kernel audio FIFO to game code. The API remains deliberately small and Turbo-C-like while using JTMOS's 32-bit flat address space and GraOS framebuffer windows.

## Mouse

GraOS protocol command `GRAOS_GSID_GETMOUSESTATE` returns mouse coordinates relative to the requesting window's framebuffer, button state, and whether the pointer is inside the client area. `jtgame.h` exposes current state plus pressed/released edge detection. A small `mouse.h` compatibility layer provides Turbo-C-style polling calls.

## Sprites

`jtsprite.h` adds sprite sheets, frame selection, timed animation, looping, horizontal/vertical flips, integer scaling, transparent color keys, alpha-zero transparency, clipping, RAW RGBA32 loading, indexed VGA/MCGA RAW loading, point testing, and AABB collision testing. Rendering goes directly to the `jtgame` framebuffer and is presented once per game frame.

## Sound

`jtsound.h` adds an eight-voice software mixer over the existing JTMOS generic audio API. It supports unsigned 8-bit RAW samples, PCM WAV loading (8/16-bit, mono/stereo), per-voice volume, looping, generated square-wave tones, and integer source-rate conversion into the selected output rate. The default output rate is 11025 Hz. Mixer buffering uses 256-byte blocks and a 512-byte target to keep interactive game sound latency modest while retaining FIFO headroom.

`jtgame_present()` automatically services the sound mixer, so a normal game loop does not need an extra audio pump call. `jtsound_update()` remains available for loops that spend long periods between presents.

## Example

`libc/examples/turboc/game_sdk2.c` demonstrates keyboard movement, mouse click positioning, mouse button edges, a generated animated sprite sheet, collision-friendly sprite state, a software cursor, and tones.

## Build and validation

The libc header smoke test covers `mouse.h`, `jtsprite.h`, and `jtsound.h`. `make -j2 test-game-sdk` builds the original BGI example, the simple `jtgame` example, and the Game SDK 2 example and validates them as ELF32/i386 JTMOS executables with entry point `0x80004000`.

The complete `libc/apps` validation was also run after the GraOS protocol change and passed for the existing application set and external GraOS clients.

## Runtime status

Compile-time, link-time, ABI/static executable, patch-application, and existing-app regression checks pass. The new Game SDK 2 demo has not been boot-run in QEMU/JTMOS in this build environment, so mouse feel, real SB/GUS playback latency, and physical/virtual audio device behavior should be verified in the next live JTMOS test.
