# JTMOS V67.8.57.2 — 1 MiB JTMFS kernel reservation

## Goal

Make the 1 MiB boot-kernel limit a filesystem/install contract rather than only
a boot32pm limit.  Bootable JTMFS disks, root installation, the userspace
`mkfs` command and the separate root-disk build now agree on the same layout.

## JTMFS layout

For BIOS IDE disks formatted by current `mkfs`:

- bytes 0..16383: boot-loader/system boot section
- bytes 16384..1064959: 1 MiB kernel payload reservation
- FAT begins only after that complete reservation
- `JTMFAT_INFOBLOCK.kernel_offs` points at 16 KiB
- `res3` contains `JTMFS_BOOT_LAYOUT_TAG`
- `res4` contains the kernel reservation in bytes (1048576)
- `res5` contains the boot-layout version

Old JTMFS disks remain readable.  Kernel installation refuses to write if the
actual geometry leaves less than 1 MiB before the FAT, preventing an old
512/576 KiB layout from being overwritten.

## rootinstall / root disk

`CopyKernel()` no longer allocates a contiguous 1 MiB kernel buffer.  It copies
and verifies the exact 1 MiB payload in 64 KiB chunks.  This reduces pressure on
the kernel heap and matches the chunk-oriented boot32pm design.

The separate B: root medium remains kernel-independent.  `make rootdisk` is now
a first-class target producing `rootdisk.img`; `buildroot` validates that the
release uses the 1 MiB JTMFS kernel contract.  The kernel itself remains on the
A: boot medium, so increasing the kernel limit does not consume root-media
payload space.

## mkfs

The userspace `formatDrive("hda")` path now passes the device name to
`SYS_mkfs`, allowing the kernel's high-level `mkfs(path)` policy to run.
Previously the modern libc converted the name to a DNR first, which selected
the low-level formatter and could skip automatic boot-kernel installation.

`mkfs hda` therefore now means:

1. format JTMFS;
2. reserve a full 1 MiB kernel payload before the FAT;
3. install the current boot loader;
4. copy the A: kernel payload in 64 KiB chunks;
5. read the full payload back and verify it;
6. publish the raw-kernel checksum only after verification succeeds.
