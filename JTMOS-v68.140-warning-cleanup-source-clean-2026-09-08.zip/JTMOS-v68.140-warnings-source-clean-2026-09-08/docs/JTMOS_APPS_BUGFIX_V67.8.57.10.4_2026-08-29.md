# JTMOS V67.8.57.10.4 — libc/apps bug-fix release

Date: 2026-08-29

This source-only maintenance release corrects programming and build errors in
`libc/apps`.  It is based on V67.8.57.10.3.

## Corrected defects

- Serialized the shared application-libc prerequisite before parallel
  per-application submakes.  `make -j 2` no longer launches concurrent writes
  to the same libc objects/archive.
- Extended the root `check` target to validate the GraOS server and all eight
  external GUI clients, and selected an explicit no-executable-stack linker
  policy for application links.
- Bounded audio file reads and playback chunks in `aud` and `rawplay`;
  handled allocation, empty-file and I/O failures without leaks or
  out-of-bounds reads/writes.
- Corrected unchecked I/O, process, formatting and directory errors in
  `performance`, `writing`, `talk`, `setup`, `mkfs`, `net` and `rt`.
- Reworked `d642zip` input/output validation, bounded output names, sector-map
  checks and write-error propagation.
- Repaired `lar` directory bounds, reserved-slot protection, CP/M name
  conversion, exact-capacity reorganization, temporary-path construction,
  stream cleanup and failed-replacement recovery.
- Corrected the missing braces in `sqsh` pipeline cleanup.  The old `else`
  bound to the inner PID test instead of the pipeline result, so successful
  pipelines were not reliably waited for.
- Prevented the snake from colliding with the tail cell that moves away on the
  same tick; made food placement terminate and report a full-board win.
- Hardened the baseline JPEG decoder against oversubscribed Huffman tables,
  duplicate components, invalid sampling ratios, out-of-order scan components,
  overflowing zero runs and corrupt DC predictors.
- Prevented GraOS clients from closing a stale numeric window ID after the
  server had already sent EXIT or disappeared.
- Added GraOS clipping, stride and window-size validation so oversized or
  off-screen surfaces cannot address outside the compositor framebuffer.
- Added missing terminal-call declarations and removed ambiguous GUI control
  flow identified by the compiler analyzer.
- Replaced unbounded `gets` calls and uninitialized test values in auxiliary
  application tests; added allocation and pointer-format checks.
- Replaced the obsolete Linux/SDL2 build instructions with the native ELF32
  build and validation commands used by this tree.

## Validation

- Clean native build: `make -C libc/apps -j 2 check`
  - 50 release CLI applications
  - one GraOS server
  - eight external GraOS clients
  - ELF32/i386 entry address validation passed
- GCC `-fanalyzer` build with strict format, bounds and string warnings:
  no application-source diagnostics.
- Host ASan/UBSan regressions:
  - `lar` create, full-directory reorganization, list and byte-identical
    extraction
  - `d642zip` WHOLE, VARIABLE, NONE and short-input error paths
  - two valid baseline JPEGs and 10,000 deterministic malformed inputs

The validation did not boot the binaries inside JTMOS hardware or an emulator;
runtime GUI, audio and direct-disk behavior should still be exercised on the
target system.
