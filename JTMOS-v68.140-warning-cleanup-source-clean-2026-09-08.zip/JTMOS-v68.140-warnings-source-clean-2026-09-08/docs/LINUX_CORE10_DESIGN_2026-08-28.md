# JTMOS V67.8.57.0 — Linux Core10

This branch adds ten Linux/POSIX-style facilities while preserving the JTMOS
32-bit i486 kernel, plain PID model, JTMFS storage and existing scheduler.
It is a compatibility layer, not an attempt to turn JTMOS into Linux.

## The ten facilities

1. **Process ancestry (`getppid`)** — every newly created process receives a
   parent PID; `fork()` preserves the relationship.
2. **Child reaping (`waitpid`, `wait`, `WNOHANG`)** — normal exit codes and
   signal termination status are recorded in POSIX wait-status form. A dead
   `fork()` child's numeric PID is held from reuse while a living parent has not
   reaped it; orphaned children are auto-released because JTMOS has no PID1 reaper.
3. **Signals v1 (`kill`, `signal`, `raise`)** — kernel-native default actions
   for SIGINT/SIGTERM/SIGKILL and ignore dispositions. Ctrl+C now sends SIGINT.
   User handlers are first-generation/cooperative: `raise()` dispatches a local
   handler directly; cross-process custom-handler delivery is queued by the
   kernel but does not yet inject a userspace signal frame.
4. **Nice priorities (`nice`, `getpriority`, `setpriority`)** — nice values
   -20..19 map onto JTMOS scheduler classes without removing the scheduler's
   responsive I/O reward policy.
5. **Anonymous pipes (`pipe`)** — 4096-byte bounded kernel pipe buffer with
   blocking read/write, EOF, EPIPE and correct read/write endpoint counts.
6. **I/O readiness (`poll`)** — timeout-based readiness for pipes plus regular
   files and pseudo devices; POLLIN/POLLOUT/POLLHUP/POLLERR/POLLNVAL.
7. **proc-style process/system view** — readable `/proc/uptime`,
   `/proc/loadavg`, `/proc/meminfo`, `/proc/version`, `/proc/cpuinfo`,
   `/proc/self/status`, and `/proc/<pid>/status`.
8. **Unix pseudo devices** — `/dev/null`, `/dev/zero`, `/dev/random` and
   `/dev/urandom` through the JTMFS direct-file API interception layer. The
   random source is a compatibility PRNG in this release, **not cryptographic
   entropy** and must not be used for keys, passwords or security tokens.
9. **System identity (`uname`)** — JTMOS release, machine and compatibility
   branch information through `<sys/utsname.h>`.
10. **System statistics (`sysinfo`)** — uptime, load averages, memory totals,
    free memory and process count through `<sys/sysinfo.h>`.

## Supporting kernel change: shared descriptor lifetime

The historical JTMOS FD database is kernel-global. Linux Core10 adds a
per-descriptor process-owner bitmap and reference count. `fork()` adds the
child as another owner rather than duplicating or invalidating the descriptor.
Closing a descriptor removes only the caller's reference; the FILEDES object is
retired on the final close. Pipe endpoint counts are driven by the same owner
hooks. This also gives regular files Linux-like shared open-file offsets after
`fork()`.

The numeric descriptor namespace remains globally allocated in this release;
new descriptors are therefore unique system-wide rather than independently
reusing the lowest number in each process. Moving to a true per-process FD
number table is a later ABI migration.

## New syscall ABI

| No. | Name | Purpose |
|---:|---|---|
| 128 | `SYS_getppid` | parent PID |
| 129 | `SYS_waitpid` | wait/reap child |
| 130 | `SYS_kill` | POSIX signal send |
| 131 | `SYS_sigdisp` | signal disposition |
| 132 | `SYS_pipe` | create pipe pair |
| 133 | `SYS_poll` | readiness polling |
| 134 | `SYS_nice` | change caller nice value |
| 135 | `SYS_getpriority` | query nice value |
| 136 | `SYS_setpriority` | set nice value |
| 137 | `SYS_uname` | system identity |
| 138 | `SYS_sysinfo` | system statistics |

Nice values are encoded as `nice + 20` across the raw syscall ABI so negative
valid nice values cannot collide with JTMOS's negative-errno convention.

## VFS integration

`directfileaccess.c` checks the Linux Core10 virtual path/descriptor layer
before falling through to normal JTMFS. Real files are therefore unchanged.
Pseudo paths use ordinary libc `open/read/write/lseek/close`, so tools such as
`cat` can consume proc data without a separate proc command API.

## Validation application

`libc/apps/linuxcore10.c` is an opt-in self-test (not added to the release app
payload to avoid consuming system-image space). Build it with:

    make -C libc/apps -f linuxcore10.mak

It tests uname/sysinfo, PPID/nice, ignored signals, `/proc/uptime`, `/dev/zero`,
and the combined `pipe + fork + poll + waitpid(exit status)` path.

## Follow-up work

The next Linux compatibility layer should add real per-process FD number tables,
userspace signal-frame injection / EINTR, credentials (`uid/gid`), permission
bits, directory-level procfs enumeration, socket readiness in `poll`, and a
unified path namespace/mount tree.
