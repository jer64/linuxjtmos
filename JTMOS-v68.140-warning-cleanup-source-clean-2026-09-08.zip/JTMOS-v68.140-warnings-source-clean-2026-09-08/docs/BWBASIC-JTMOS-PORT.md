# JTMOS V68.8.57.10.18.16.97 — Bywater BASIC 2.20pl2 native port

This release restores Bywater BASIC, one of the historically early substantial
JTMOS application ports, to the modern ELF32 Ring3 application environment.

## Architecture

The interpreter is deliberately independent of any particular video card.
Text mode uses JTMOS console calls. Graphics use the existing BGI-compatible
`graphics.h` implementation on GraOS. Therefore a future NVIDIA GeForce 6150SE
linear-framebuffer driver belongs underneath GraOS/display handling; BASIC code
does not access NVIDIA MMIO, PCI BARs or mode registers directly.

Simple audio uses the generic `jtsound` userspace API and remains optional on
headless builds. `SOUND` and `BEEP` synchronously pump `jtsound_update()` while
the tone plays, so the commands produce real mixer output instead of merely
allocating a tone voice.

## Added BASIC-facing functionality

Text: `CLS`, `COLOR`, `LOCATE`, `INKEY$`.

Graphics: `SCREEN 0|1`, `PSET`, `GLINE`, `RECT`, `CIRCLE`, `GCLEAR`,
`GPRESENT`.

Audio: `BEEP`, `SOUND frequency_hz,milliseconds[,volume]`.

`SCREEN 1` opens the standard GraOS/BGI graphics backend. `SCREEN 0` closes it.
Colors use the classic 0..15 BGI palette.

## Upstream source

The source tree in `libc/apps/bwbasic/upstream/` is Bywater BASIC 2.20 with the
official patch-level 1 and patch-level 2 replacement files applied. Original
GPL COPYING, README, documentation and patch release notes are retained.

## JTMOS compatibility work

- modern Ring3 ELF32 build via `libc/apps/bwbasic.mak`;
- JTMOS console/GraOS/audio backend `bwx_jtmos.c`;
- JTMOS RTC compatibility for `DATE$`, `TIME$` and `TIMER`;
- GCC builtin non-local jump shim for the interactive error prompt;
- runtime initialization of `stderr` because modern JTMOS FILE handles are not
  compile-time constants;
- two upstream MKI$/MKD$ temporary buffers enlarged by one byte to remove real
  terminator overruns;
- destructive `RMDIR` is intentionally unsupported until JTMOS exposes a
  proper Ring3 rmdir API.
