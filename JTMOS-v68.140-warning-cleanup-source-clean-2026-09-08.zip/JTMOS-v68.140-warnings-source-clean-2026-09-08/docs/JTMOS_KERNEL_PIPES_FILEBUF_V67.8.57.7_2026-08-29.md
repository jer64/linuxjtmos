# JTMOS V67.8.57.7 — kernel pipes and kernel-owned file buffering

## Goal

Make `|` a real kernel stream primitive in both SMSH and SQSH.  Pipeline data is
not copied through a shell or libc emulation buffer.  The kernel owns the pipe
ring buffer, descriptor lifetime and stdio/file buffering state.

## Kernel pipe layer

`SYS_pipe` keeps its existing ABI number 132.  `LinuxPipeCreate()` creates two
kernel FILEDES endpoints backed by the 4 KiB `JTMOS_PIPE` ring.  Reader/writer
counts follow process fd ownership, so EOF is produced only after the final
writer reference closes.  Blocking read/write yield with `SwitchToThread()`.

Process-local stdin/stdout/stderr routes now allow descriptors 0, 1 and 2 to
refer to a kernel descriptor.  `SYS_dup2` (145) exposes this routing to Ring3.
`SYS_cexec_stdio` (146) starts a process with explicit stdin/stdout/stderr
routes; normal `cexec()` inherits the caller's routes.

## Kernel-owned filebuf

The active Ring3 stdio implementation used to keep its fread/fwrite data buffer
inside `libc/libc/modern/stdio.c`.  V67.8.57.7 moves persistent stream buffering
to `kernel32/fs/filebuf.c` / `tools/kernel32/fs/filebuf.c`.

New syscalls:

- 139 `SYS_filebuf_read`
- 140 `SYS_filebuf_write`
- 141 `SYS_filebuf_flush`
- 142 `SYS_filebuf_set`
- 143 `SYS_filebuf_seek`
- 144 `SYS_filebuf_tell`
- 145 `SYS_dup2`
- 146 `SYS_cexec_stdio`

Libc `modern/filebuf.c` is only a syscall facade.  `modern/stdio.c` keeps FILE
metadata and one-character `ungetc()` state, but no BUFSIZ data cache.  Regular
files default to a 4 KiB kernel buffer.  Pipes default to `_IONBF`, because the
pipe itself already has a kernel ring buffer; a second userspace-style buffer
would add latency and create avoidable deadlock/flush corner cases.

The historical native-kernel FILE implementation in `kernel32/fs/filebuf.c`
also avoids seeking or pre-reading a pipe.

## Shell pipelines

SMSH recognizes unquoted/unescaped `|`, creates up to 15 kernel pipes for 16
stages, launches all stages concurrently with `centralprocess_exec_stdio()`,
closes the parent's copies, then waits for children.

SQSH uses the same kernel primitives through Ring3 syscalls.  Each stage runs as
a no-banner SQSH worker so SQSH builtins and external commands both receive the
same redirected fd 0/1/2.  External grandchildren inherit the worker's stdio
routes through normal `cexec()`.

Examples:

    ls | cat
    cat file.txt | cat
    ps | cat
    cat file.txt | cat | cat

`cat` with no arguments (or `-`) reads stdin, making it a normal pipeline
consumer.

## Compatibility

No JTMFS on-disk layout changes are introduced.  Existing `SYS_pipe=132` stays
stable; the new ABI is appended at syscall numbers 139..146.  The implementation
remains 32-bit i486 compatible and keeps the top-level `make -j2` build policy.
