# JTMOS V67.8.57.10.3 — GraOS windowed demos and startup fixes

## Goal

Move the historical 320x200 graphics demos away from global VGA mode changes
and make the normal GraOS startup/demo set usable from the standard B: root
installation.

## Windowed framebuffer contract

`libc/apps/graos_demo.h` is the small shared client-side helper used by
`picture`, `plasma`, `plasma2`, `snake` and `vgaplasma`.

Each program now:

- connects to the running GraOS server;
- allocates a private 320x200 RGBA32 framebuffer;
- creates a normal GraOS window;
- attaches the buffer with `addFrameBuffer(..., GRAOS_SURFACE_BITMAP, ...)`;
- updates the client area with `refreshWindow()`;
- receives close/focus/key events through the window event queue;
- pauses animation while blurred or minimized;
- never changes the machine-wide VGA/VESA video mode or palette.

`sqfam.raw` is data, not an executable.  It is installed in `/bin` beside
`picture.bin`, which displays it in a GraOS framebuffer window.

## Startup/application fixes

- Terminal and command-prompt launch paths use `/bin/sqsh.bin` explicitly.
- SQSH startup command storage is one checked contiguous arena instead of more
  than two hundred unchecked small allocations.
- Pipeline SQSH workers also use the absolute `/bin/sqsh.bin` path.
- Welcome-screen `DISCOVER JTMOS` actually starts `/bin/launcher.bin`.
- Welcome/control-panel actions use absolute `/bin` paths for Filer, Editor,
  Task Manager and Control Panel.
- Launcher exposes Squirrel Shell, Snake, Plasma, Plasma II, VGA Plasma,
  Squirrel Family and the Label/Bitmap/TextBox demos when their executables are
  present.

## Root-media packaging

The windowed demos and intro/widget demos are no longer classified as
utilities-CD-only.  The tested system payload is approximately 1.13 MiB, below
the 1.44 MiB B: root-medium limit, while larger media/self-test applications
remain on `utilities.iso`.

## Validation

`tools/check_graos_windowed_demos.sh` rejects accidental reintroduction of
`setmode`, `setvmode`, `drawframe` or `waitretrace` into the converted demos,
checks the common framebuffer/event path and verifies that the core demos are
not classified as CD-only.
