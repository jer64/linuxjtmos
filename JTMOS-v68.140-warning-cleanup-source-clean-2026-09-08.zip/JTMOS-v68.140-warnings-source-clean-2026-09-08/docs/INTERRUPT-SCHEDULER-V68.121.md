# JTMOS V68.121 interrupt, idle and scheduler design

## Architecture basis

This change follows the architectural behavior documented by Intel and AMD:

* `HLT` (`F4`) is a privileged CPL0 instruction in protected mode. It halts the
  executing logical processor until a permitted wake event occurs. An enabled
  interrupt resumes at the instruction after HLT.
* `STI` (`FB`) delays recognition of external maskable interrupts through the
  following instruction when IF was previously zero. Therefore the safe idle
  sequence is `CLI -> recheck runnable work -> STI; HLT`.
* `PAUSE` (`F3 90`) is the spin-loop hint. Intel recommends it in spin-wait
  loops; on older IA-32 CPUs it is backward-compatible and behaves as NOP.
* AMD documents legacy hardware task switching but notes that modern operating
  systems normally manage task switching in software. JTMOS V68.121 takes a
  hybrid migration step: interrupt gates handle timer/yield entry and the old
  per-process TSS transfer is performed only if the selected PID changes.

## JTMOS implementation

### IRQ0

Steady-state PIT IRQ0 is now a 32-bit interrupt gate. The ISR saves registers,
runs timer accounting and scheduler selection, acknowledges the 8259A, and
returns immediately by IRET when the same task keeps the CPU.

A far TSS JMP is issued only if scheduler selection actually changes PID. This
removes the historical current-task -> PIT-scheduler-TSS -> next-task double
hardware task-switch path from ordinary timer ticks.

Storage-safe mode still swaps IRQ0 temporarily to the existing tick-only
interrupt gate and restores the scheduler interrupt gate afterwards.

### Voluntary yield

`INT 0x7E` is now a DPL3 interrupt gate instead of a scheduler task gate. It
performs the same conditional process transfer as IRQ0. The dedicated 0x58 and
0x60 scheduler TSS allocations are skipped in the default configuration.

`#DF` deliberately remains an independent task-gate/TSS emergency path. That
is a reliability mechanism rather than a scheduling mechanism.

### Idle / HLT

The idle task calls `SchedulerIdleWait()`:

    CLI
    check for runnable non-idle tasks
    if work exists: STI and yield
    otherwise: STI; HLT

The runnable test is made while IF=0. `STI; HLT` is emitted in one compiler
barrier asm block. This closes the classic lost-wakeup window in which work
could become runnable after a check but before a standalone HLT.

Fatal-stop paths continue to use `CLI; HLT` loops intentionally: those paths
must not resume normal execution.

### Spin waits

Short lock backoff loops use `PAUSE` encoded as `F3 90`. The kernel still
builds with `-march=i486`; original i486/Pentium/P6-class processors simply
execute the encoding compatibly while Pentium 4 and later can use the spin
hint.

### PIT rate

CPU family detection is already performed safely before scheduler startup.
V68.121 selects:

* CPUID family >= 5 (Pentium-family and newer): divisor 0x0800, about 582.6 Hz.
* i486/no-CPUID fallback: divisor 0x2000, about 145.7 Hz.

At ~582.6 Hz the existing scheduler quanta {3,4,6,10} are approximately
{5.1,6.9,10.3,17.2} ms. The higher tick rate is practical because same-task
IRQ0 ticks no longer invoke a hardware task switch.

### PIC critical sections

`disable()`/`enable()` are compiler memory barriers as well as CLI/STI. PIC
mask updates save EFLAGS, disable interrupts, update `irq_mask` and both 8259A
IMRs as one critical section, then restore the original EFLAGS.

C IRQ handlers use `pic_send_eoi()` so slave-before-master EOI order is
centralized.

### Forced switching

`SwitchToThreadEx()` publishes its target and enters `INT 0x7E` with IRQs
blocked, preventing IRQ0 from consuming a half-published one-shot target.
The forced PID and return-PID sentinels are -1, making PID 0 a valid target.

## Diagnostics

The existing `sched` SMSH command now includes counters for timer interrupt
entries, same-task fast returns, real timer switches, voluntary yields, idle
HLTs and idle runnable rechecks. A healthy mostly-idle system should show many
`same` timer events relative to actual `switch` events.

## Next migration step

V68.121 intentionally does not replace the per-process TSS format yet. Once the
interrupt-gate path has been validated on QEMU and physical i486/Pentium/AMD
systems, the next logical step is a software context switch that saves only the
register/stack state JTMOS needs. That would remove hardware task switching
from normal scheduling entirely while retaining one TSS per CPU for privilege
stack/I/O-map purposes and the dedicated double-fault emergency mechanism.
