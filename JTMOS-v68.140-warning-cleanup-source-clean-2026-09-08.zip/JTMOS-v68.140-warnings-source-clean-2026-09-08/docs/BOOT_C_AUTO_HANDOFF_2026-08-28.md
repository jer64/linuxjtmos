# JTMOS V67.8.57.3 - boot: c automatic kernel handoff

## Symptom

Hard-disk boot reached:

    Ready: Kernel loaded, checksum OK.

and then appeared to freeze.

## Root cause

`boot32/bootmod.inc:loaded_fine` contained a historical BIOS keyboard wait
(`INT 16h`) whenever `bootdrv != 0`.  Therefore A: continued automatically,
while C: (0x80) always waited for a key before entering the protected-mode
kernel handoff.

The message was also inaccurate for the nzip path: the compressed stream has
been loaded at this point, but the raw kernel checksum is verified only after
protected-mode decompression.

## Fix

* remove the boot-drive-dependent key wait from `loaded_fine`;
* continue immediately to `past` and `boot.asm:start`;
* change the status line to `Ready: Kernel image loaded. Starting kernel...`;
* add a regression assertion to `tools/check_boot32_hd_nzip.sh` which rejects
  an `INT 16h` inside the `loaded_fine` handoff block.

This keeps interactive boot waits controlled only by explicit diagnostics, not
by whether the machine was booted from floppy or hard disk.
