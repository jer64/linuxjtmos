# JTMOS native NVIDIA GeForce 6150SE / MCP61 display provider

Target: eMachines systems using NVIDIA GeForce 6150SE nForce 430 / MCP61,
PCI ID `10DE:03D0`.

## Policy

A successful boot32 VBE handoff always wins.  The native provider is only
prepared when VBE is unavailable.  Preparation probes PCI BAR0/BAR1 and makes
BAR1 available to the existing JTMOS LFB paging contract, but it leaves VGA
text mode untouched.  Native CRTC/RAMDAC/PLL programming happens only when
GraOS explicitly requests graphics after paging is active.

Supported native modes in the first implementation:

* 1024x768x32 @ 60 Hz (GraOS)
* 640x480x32 @ 60 Hz (recovery)

The driver intentionally preserves the BIOS-selected analog output routing.
It does not implement acceleration, HDMI/TV/LVDS routing, EDID/DDC or dual-head
configuration yet.

## Recovery

If experimental native PLL programming gives a black screen on a particular
6150SE board, reboot (the driver does not touch the display before GraOS is
started) and build with `NV6150_NATIVE_PLL=0` in `nv6150.h`.  Probe/LFB mapping
will remain available while native mode-setting is refused safely.

Expected boot log when VBE is unavailable:

    NV6150: GeForce 6150SE/MCP61 at ... BAR0=... BAR1/LFB=...
    NV6150: GraOS BAR1 LFB prepared ... VGA text retained.

Expected GraOS transition log:

    NV6150: VPLL target=65000 kHz ...
    NV6150: native mode 1024x768x32 ...
    GraOS graphics: 1024x768x32 activated through NV6150/MCP61.

## Register references used for the port

The user-provided modern NVIDIA modeset source was used as architectural
context, but MCP61 is old Curie/NV4x hardware.  The concrete legacy register
programming is therefore based primarily on the Linux Nouveau NV04/Curie CRTC
path (`drivers/gpu/drm/nouveau/dispnv04/crtc.c` and `nvreg.h`) and the legacy
NVIDIA framebuffer driver's C61-specific PLL/FIFO calculations
(`drivers/video/fbdev/nvidia/nv_hw.c`).
