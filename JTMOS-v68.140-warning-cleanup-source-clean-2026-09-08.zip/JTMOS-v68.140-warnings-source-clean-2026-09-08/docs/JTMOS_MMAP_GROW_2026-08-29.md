# JTMOS V67.8.57.8 mmap-backed libc heap growth

`SYSMEMREQ` is now the initial ELF32 heap reservation, not a hard malloc ceiling.
The bounded `sbrk()` arena remains below the guard page and 256 KiB stack. When it
fills, libc `malloc()` requests a new RW anonymous process mapping through
`SYS_mem_grow`. The syscall is implemented on top of the existing 16 MiB per-PID
page-table window and sparse physical-page allocator.

New syscall ABI: `SYS_mmap=147`, `SYS_munmap=148`, `SYS_mem_grow=149`. User mmap
addresses live outside the primary `thread_base`/`thread_memkb` range. A kernel
VM registry therefore translates those addresses for syscall copyin/copyout.
Mappings are freed at process exit and copied privately by `fork()`.

`kmalloc()` remains a kernel implementation detail; user payload pages are owned
by the process MM and mapped explicitly into Ring3.
