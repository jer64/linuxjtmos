# JTMOS V67.8.57.10 editor redraw and cursor fix

The editor no longer repaints the complete screen for every key. Text mutations mark only the affected logical line dirty; viewport scrolling and line insertion/removal request a full text-area repaint. Menu/status rows are separate from the text viewport.

During paint, `_setcursortype(_NOCURSOR)` disables the terminal cursor through `SYS_setcursortype`. The kernel keeps logical cursor coordinates but EGA/VESA only render the cursor for the visible terminal that owns keyboard input. After painting, the editor places the logical cursor at the insertion point and enables it once.

Editor fixes include real insert/overwrite behavior, Delete, Backspace, Enter line splitting, 8-column Tab stops, CRLF-aware loading, file-tab expansion, correct Home/End handling, an 81-byte line buffer for 80 visible characters plus NUL, and a small DOS-style menu/status bar.
