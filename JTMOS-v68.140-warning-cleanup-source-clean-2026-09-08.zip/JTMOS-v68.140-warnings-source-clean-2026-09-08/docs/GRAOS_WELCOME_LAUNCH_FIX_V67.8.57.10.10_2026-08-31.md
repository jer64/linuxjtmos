# JTMOS V67.8.57.10.10 — GraOS Welcome launch hardening

Date: 2026-08-31

## Symptom

After GraOS displayed **Welcome to JTMOS**, all four desktop actions could fail:

- Discover JTMOS: `Application launcher failed`
- Open Terminal: `Terminal launch failed`
- Explore Files: `File Manager launch failed`
- System Tools: `Control Panel launch failed`

The boot installer already verifies the core binaries before starting GraOS, so a
simultaneous failure of all four actions points to their shared runtime launch
path rather than four missing applications.

## Design

The system desktop payload physically lives on the RAM JTMFS device under
`ram:/bin`.  `/bin` is retained as the historical namespace-absolute spelling.
Core desktop launching must therefore work even when a process CWD or a
namespace-root transition makes that compatibility spelling unsuitable.

A shared `guiLaunchCompat.h` layer now implements the policy:

1. try the requested command in the caller's current working directory;
2. retry it with `/` as the working directory;
3. for commands whose executable starts with `/bin/`, retry the executable as
   `ram:/bin/...` with `ram:/bin` and `ram:/` as explicit working directories.

This keeps normal `/bin` behavior first while giving boot desktop applications a
stable device-explicit recovery path.

## Changes

- GraOS internal terminal/background launchers use the shared fallback layer.
- Terminal's executable preflight checks `/bin/...` and `ram:/bin/...`.
- Welcome **System Tools** opens the already-resident internal GraOS Control
  Panel, eliminating an unnecessary process launch from this critical path.
- Start-menu System Tools uses the same internal Control Panel.
- External Launcher, Control Panel and Terminal use the shared launch policy.
- Legacy Taskbar and Filer use the same policy, including editor/executable
  launches from Filer.
- `tools/check_graos_welcome_launch.sh` guards all four Welcome launch paths and
  the fallback implementation.
- The existing GraOS application checker was updated for the shared launcher
  and for the current conio/BGI input routing.

## Validation

- `check_graos_welcome_launch.sh`: PASS
- `check_graos_apps.sh`: PASS
- `graos.bin`, `launcher.bin`, `controlpanel.bin`, `terminal.bin`, `filer.bin`,
  `taskbar.bin`: built as statically linked ELF32 Intel i386 applications
- Embedded `ram:/bin` fallback verified in all six affected binaries
- Full `make -j2`: PASS using NASM 3.02rc13
- Generated boot/root media:
  - `jtm32.img`: 1.44 MiB boot image
  - `root1440.img`: 1.44 MiB root/system image
  - `utilities.iso`: ATAPI utilities/demo image
- Full `make -j2 check` progresses through the GraOS and several kernel checks,
  then stops on the pre-existing unrelated `check_edit_cursor: public cursor
  constants missing` regression check.
- QEMU runtime interaction was not executed because `qemu-system-i386` is not
  available in this build environment.
