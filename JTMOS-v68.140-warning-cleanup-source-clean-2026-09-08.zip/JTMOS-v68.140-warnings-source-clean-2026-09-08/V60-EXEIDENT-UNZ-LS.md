JTMOS V60 - executable identification, ELF32 launch and ls fixes
================================================================
Date: 2026-08-21

* Modern libc crt0 embeds both historical JTMOS executable-identification strings.
* The ELF32 linker retains those markers in the executable image.
* isExeBinary() keeps the 200-byte first-marker rule for legacy flat binaries, but
  scans the full file for ELF32 because ELF headers precede the first PT_LOAD at
  file offset 0x1000. Both markers are still mandatory.
* isExeBinary()/getExeMemReq() are now length-bounded.
* The active core/cp LaunchApp path now dispatches valid ELF32/i386 ET_EXEC images
  to the existing PT_LOAD/page-mapping implementation while preserving the old
  flat-binary loader for historical applications.
* SMSH `ls` with no arguments lists the current directory.
* libc/apps/ls.c no longer dereferences argv[argc] when argc==1.
* Rebuild installer/sys images so sqa sys installs the corrected unz.bin.
