#!/bin/sh
# JTMOS V67.8.57.10.18.16.18 SATA/AHCI QEMU launcher
# A: boot-only floppy (boot32pm + kernel)
# B: root/system SQARC floppy (preferred sys: backend)
# CD-ROM: same root/system SQARC payload (legacy ATAPI fallback)
# HDA: attached to an explicit ICH9 AHCI controller so the native SATA path is tested.
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BOOT_FLOPPY=${JTMOS_FLOPPY:-${1:-$SCRIPT_DIR/jtm32.img}}
HDD=${JTMOS_HDD:-${2:-$SCRIPT_DIR/hd_jtmos.img}}
ROOT_FLOPPY=${JTMOS_ROOT_FLOPPY:-${3:-$SCRIPT_DIR/root1440.img}}
ROOT_CDROM=${JTMOS_ROOT_CDROM:-${4:-$SCRIPT_DIR/utilities.iso}}
RUNTIME=${JTMOS_SLIP_RUNTIME:-${XDG_RUNTIME_DIR:-/tmp}/jtmos-slip}
SLIP_PIPE=${JTMOS_SLIP_PIPE:-$RUNTIME/jtmos-slip}
SERIAL_LOG=${JTMOS_SERIAL_LOG:-$SCRIPT_DIR/serial_output.log}
USB_INPUT=${JTMOS_USB_INPUT:-ohci}
NET_MODE=${JTMOS_NET_MODE:-user}
HTTP_HOST_ADDR=${JTMOS_HTTP_HOST_ADDR:-127.0.0.1}
HTTP_HOST_PORT=${JTMOS_HTTP_HOST_PORT:-8080}
TELNET_HOST_ADDR=${JTMOS_TELNET_HOST_ADDR:-127.0.0.1}
TELNET_HOST_PORT=${JTMOS_TELNET_HOST_PORT:-2323}
DISPLAY_MODE=${JTMOS_DISPLAY:-default}
BRIDGE=${JTMOS_BRIDGE:-br0}
TAP_IF=${JTMOS_TAP_IF:-tap0}

command -v qemu-system-i386 >/dev/null 2>&1 || { echo "qemu-system-i386 not found in PATH." >&2; exit 127; }
case "$USB_INPUT" in
  ohci)
    if ! qemu-system-i386 -device help 2>&1 | grep -q 'pci-ohci' ||
       ! qemu-system-i386 -device help 2>&1 | grep -q 'usb-kbd' ||
       ! qemu-system-i386 -device help 2>&1 | grep -q 'usb-mouse'; then
      echo "QEMU does not provide pci-ohci + usb-kbd + usb-mouse required by the JTMOS OHCI HID test." >&2
      echo "Check with: qemu-system-i386 -device help | grep -E 'pci-ohci|usb-kbd|usb-mouse'" >&2
      echo "Use JTMOS_USB_INPUT=off only when you intentionally want PS/2-only testing." >&2
      exit 1
    fi
    ;;
  off) ;;
  *) echo "Invalid JTMOS_USB_INPUT=$USB_INPUT (expected: ohci or off)." >&2; exit 2 ;;
esac
case "$NET_MODE" in
  user)
    NETDEV_SPEC="user,id=jtmosnet"
    case "$HTTP_HOST_PORT" in
      off|none) ;;
      *[!0-9]*|'') echo "Invalid JTMOS_HTTP_HOST_PORT=$HTTP_HOST_PORT (expected number, off or none)." >&2; exit 2 ;;
      *) NETDEV_SPEC="$NETDEV_SPEC,hostfwd=tcp:${HTTP_HOST_ADDR}:${HTTP_HOST_PORT}-:8080" ;;
    esac
    case "$TELNET_HOST_PORT" in
      off|none) ;;
      *[!0-9]*|'') echo "Invalid JTMOS_TELNET_HOST_PORT=$TELNET_HOST_PORT (expected number, off or none)." >&2; exit 2 ;;
      *) NETDEV_SPEC="$NETDEV_SPEC,hostfwd=tcp:${TELNET_HOST_ADDR}:${TELNET_HOST_PORT}-:2323" ;;
    esac
    ;;
  bridge) NETDEV_SPEC="bridge,id=jtmosnet,br=$BRIDGE" ;;
  tap) NETDEV_SPEC="tap,id=jtmosnet,ifname=$TAP_IF,script=no,downscript=no" ;;
  *) echo "Invalid JTMOS_NET_MODE=$NET_MODE (expected: user, bridge or tap)." >&2; exit 2 ;;
esac

[ -f "$BOOT_FLOPPY" ] || { echo "JTMOS boot floppy not found: $BOOT_FLOPPY" >&2; exit 1; }
if [ "$ROOT_FLOPPY" != none ] && [ ! -f "$ROOT_FLOPPY" ]; then
  echo "JTMOS B: root floppy not found: $ROOT_FLOPPY" >&2; exit 1
fi
if [ "$ROOT_CDROM" != none ] && [ ! -f "$ROOT_CDROM" ]; then
  echo "JTMOS ATAPI root image not found: $ROOT_CDROM" >&2; exit 1
fi
if [ "$ROOT_FLOPPY" = none ] && [ "$ROOT_CDROM" = none ]; then
  echo "No root medium selected; use B: root1440.img or utilities.iso." >&2; exit 1
fi
if [ ! -f "$HDD" ]; then "$SCRIPT_DIR/make_hd_jtmos.sh" "$HDD"; fi
if [ ! -p "$SLIP_PIPE.in" ] || [ ! -p "$SLIP_PIPE.out" ]; then
  echo "JTMOS SLIP FIFOs are not ready; run ubuntu-slip/slip-up.sh" >&2; exit 1
fi

echo "JTMOS QEMU configuration:"
echo "  floppy A / boot: $BOOT_FLOPPY"
echo "  floppy B / root: $ROOT_FLOPPY"
echo "  ATAPI root:      $ROOT_CDROM"
echo "  SATA/AHCI HDA:   $HDD"
if [ "$USB_INPUT" = ohci ]; then
  echo "  USB input:       OHCI + usb-kbd + usb-mouse (USB preferred, PS/2 fallback in JTMOS)"
else
  echo "  USB input:       off (PS/2-only test)"
fi
echo "  network backend: $NET_MODE"
echo "  display:         $DISPLAY_MODE"
if [ "$NET_MODE" = user ]; then
  if [ "$HTTP_HOST_PORT" = off ] || [ "$HTTP_HOST_PORT" = none ]; then
    echo "  inbound HTTP:    disabled by QEMU user-mode NAT"
  else
    echo "  inbound HTTP:    http://${HTTP_HOST_ADDR}:${HTTP_HOST_PORT}/ -> guest TCP/8080"
  fi
  if [ "$TELNET_HOST_PORT" = off ] || [ "$TELNET_HOST_PORT" = none ]; then
    echo "  inbound TELNET:  disabled by QEMU user-mode NAT"
  else
    echo "  inbound TELNET:  ${TELNET_HOST_ADDR}:${TELNET_HOST_PORT} -> guest TCP/2323"
  fi
  echo "  inbound ICMP:    unavailable with QEMU user-mode networking; use JTMOS_NET_MODE=bridge or tap"
elif [ "$NET_MODE" = bridge ]; then
  echo "  bridge:           $BRIDGE (guest is directly reachable if bridge/DHCP/firewall permit)"
else
  echo "  TAP interface:    $TAP_IF (must already be configured/bridged by the host)"
fi

set -- qemu-system-i386 -machine pc,usb=off -m 512 -vga std \
  -drive "file=$BOOT_FLOPPY,format=raw,if=floppy,index=0" \
  -device ich9-ahci,id=jtmosahci \
  -drive "file=$HDD,format=raw,if=none,id=jtmosdisk,cache=writethrough" \
  -device ide-hd,drive=jtmosdisk,bus=jtmosahci.0
if [ "$ROOT_FLOPPY" != none ]; then
  set -- "$@" -drive "file=$ROOT_FLOPPY,format=raw,if=floppy,index=1"
fi
if [ "$ROOT_CDROM" != none ]; then
  set -- "$@" -cdrom "$ROOT_CDROM"
fi
if [ "$USB_INPUT" = ohci ]; then
  # Deliberately use an explicit PCI OHCI controller instead of legacy -usb.
  # The controller id 'usb' creates bus usb.0; pin the HID devices to it so
  # QEMU cannot silently attach them to an unrelated/default USB controller.
  set -- "$@" \
    -device pci-ohci,id=usb,bus=pci.0 \
    -device usb-kbd,id=jtmos-usb-kbd,bus=usb.0,port=1 \
    -device usb-mouse,id=jtmos-usb-mouse,bus=usb.0,port=2
fi
set -- "$@" \
  -device gus,irq=5 \
  -netdev "$NETDEV_SPEC" \
  -device ne2k_isa,netdev=jtmosnet,iobase=0x300,irq=9 \
  -serial "file:$SERIAL_LOG" \
  -serial "pipe:$SLIP_PIPE" \
  -boot a
case "$DISPLAY_MODE" in
  default|auto) ;;
  curses) set -- "$@" -display curses ;;
  gtk|sdl|none) set -- "$@" -display "$DISPLAY_MODE" ;;
  *) echo "Invalid JTMOS_DISPLAY=$DISPLAY_MODE (expected default, curses, gtk, sdl or none)." >&2; exit 2 ;;
esac
exec "$@"
