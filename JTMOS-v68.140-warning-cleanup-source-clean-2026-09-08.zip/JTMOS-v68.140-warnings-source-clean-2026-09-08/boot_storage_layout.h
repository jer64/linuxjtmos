#ifndef JTMOS_BOOT_STORAGE_LAYOUT_H
#define JTMOS_BOOT_STORAGE_LAYOUT_H

/*
 * JTMOS boot-storage layout contract.
 *
 * Keep the transport image, partitioned-HDD boot area and filesystem layout
 * separate. jtm32.img is a 1.44 MiB source/transport image; rootinstall maps
 * its loader/kernel into the reserved pre-partition area on an HDD.
 */
#define JTMOS_BOOT_SECTOR_BYTES             512UL

/* 1.44 MiB jtm32.img source layout. */
#define JTMOS_FLOPPY_LOADER_SECTORS         36UL
#define JTMOS_FLOPPY_KERNEL_LBA             36UL

/* Partitioned HDD pre-partition boot layout. */
#define JTMOS_HDD_LOADER_SECTORS            36UL
#define JTMOS_HDD_KERNEL_LBA                64UL
#define JTMOS_HDD_KERNEL_SECTORS            2048UL  /* 1 MiB */
#define JTMOS_HDD_KERNEL_END_LBA             (JTMOS_HDD_KERNEL_LBA + JTMOS_HDD_KERNEL_SECTORS)

/* partition hda auto reserves the first 2 MiB (LBA 0..4095) for JTMOS boot
 * code, kernel and future boot/system expansion. rootinstall intentionally
 * rejects partitioned targets whose first partition begins before this. */
#define JTMOS_HDD_FIRST_PARTITION_LBA       4096UL
#define JTMOS_HDD_BOOT_RESERVED_SECTORS     JTMOS_HDD_FIRST_PARTITION_LBA

#if JTMOS_FLOPPY_LOADER_SECTORS != JTMOS_HDD_LOADER_SECTORS
#error "jtm32.img loader size and partitioned-HDD loader size must match"
#endif
#if JTMOS_FLOPPY_KERNEL_LBA < JTMOS_FLOPPY_LOADER_SECTORS
#error "floppy kernel overlaps floppy loader"
#endif
#if JTMOS_HDD_KERNEL_LBA < JTMOS_HDD_LOADER_SECTORS
#error "HDD kernel overlaps HDD loader"
#endif
#if JTMOS_HDD_KERNEL_END_LBA > JTMOS_HDD_FIRST_PARTITION_LBA
#error "HDD boot kernel overlaps the default first partition"
#endif

#endif
