# JTMOS V67.8.57.10.18.16.9 — Snake + userspace free

## Snake

`libc/apps/snake.c` now uses the common `jtgame` GraOS runtime instead of the
older local `graos_demo.h` loop.  This centralizes window/event/framebuffer
handling with the current GraOS client code.

Snake now requests 1024 KiB with `SYSMEMREQ(APPRAM_1024K)`.  The application
owns a 320x200 RGBA framebuffer (256000 bytes); 512 KiB process space left too
little initial heap after the fixed 256 KiB stack, guard page and ELF image.
The 1 MiB request gives the game a comfortably sized initial heap and avoids a
large heap-growth request at startup.

## free

A new `/bin/free.bin` userspace application was added to `libc/apps` and the
release application list.  It uses the Linux-compatible JTMOS `sysinfo()` ABI
and supports:

- default KiB output
- `-b` / `--bytes`
- `-k`
- `-m`
- `-g`
- `-h` / `--human`
- `--help`

The output follows the familiar Linux columns: total, used, free, shared,
buff/cache and available, plus Swap (currently zero on JTMOS).

`LinuxSysinfo()` now reports reclaimable JTMOS cache bytes in `bufferram` using
DirDB, FlexFAT and the HD cache. `/proc/meminfo` also reports `Cached:` and uses
free+cache for `MemAvailable`.
