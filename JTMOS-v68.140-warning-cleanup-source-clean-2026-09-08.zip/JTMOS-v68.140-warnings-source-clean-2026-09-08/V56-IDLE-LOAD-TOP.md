JTMOS V56 - Idle thread, CPU/load accounting and top
====================================================
Date: 2026-08-21

Kernel scheduler
----------------
* CPU_IDLE is now a true STI;HLT idle thread. It consumes no busy-spin loop.
* CPU_IDLE is excluded from normal round-robin selection and is selected only
  when one full scheduler scan finds no runnable non-idle task.
* PIT preemption no longer forces every interrupted task into an artificial
  four-turn sleep. Voluntary SwitchToThread() keeps its short yield sleep.
* The historical priority divisor is now honored while selecting runnable tasks.

CPU accounting
--------------
* SchedulerCpuTick() records idle and total PIT ticks.
* One-second busy/idle percentages are exported as per-mille (0..1000).
* A/B/C load averages are 1/5/15 minute exponential moving averages, exported
  multiplied by 1000. The runnable count excludes CPU_IDLE and sleeping/yielded
  threads.
* New SYS_getcpustats (105) returns JTMOS_CPU_STATS to applications.

LIBC/top
--------
* Added GetCPUStats() to legacy and 2026 libc interfaces.
* top now shows uptime, task/runnable counts, busy%, idle/free%, PIT Hz and
  A/B/C load averages.
* Per-process CPU% is calculated from scheduler tick deltas between refreshes.
* Fixed the old out-of-bounds sorting bug (sorted.p[i+1] at the last element).
* Removed 256 small heap allocations from top; process rows are static.
* Fixed the old getch1() loop bug: -1 means "no key" and no longer exits top.
* top.mak is enabled in libc/apps/Makefile.

Runtime note
------------
Build/static validation can be done here, but a booted JTMOS/QEMU/VirtualBox
runtime measurement is still required to validate the actual percentages and
load convergence on target hardware.
