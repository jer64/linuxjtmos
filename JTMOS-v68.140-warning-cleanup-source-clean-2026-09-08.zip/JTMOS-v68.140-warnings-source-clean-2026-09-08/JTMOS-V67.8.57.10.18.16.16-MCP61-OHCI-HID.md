# JTMOS V67.8.57.10.18.16.16 — MCP61 native USB OHCI HID

Target hardware: eMachines EL1352 / NVIDIA MCP61.

This release replaces the USB-input scaffold-only behavior with a minimal native
OHCI USB 1.1 HID transport.  It is intentionally not a complete USB stack.

Implemented:

- PCI OHCI discovery, preferring NVIDIA MCP61 10de:03f1.
- MCP61 EHCI 10de:03f2 companion-port handoff when OHCI initially sees no
  connected root-port devices.
- OHCI controller reset/operational state, HCCA and DMA ED/TD structures.
- Root-hub power, connect detection and port reset.
- USB device descriptor, address, configuration descriptor and SET_CONFIGURATION.
- HID boot-subclass interface parsing for keyboard (protocol 1) and mouse
  (protocol 2), plus SET_PROTOCOL(Boot).
- Periodic interrupt-IN EDs for up to eight root-port HID interfaces.
- Reports feed the existing usb_hid_boot_keyboard_report() and
  usb_hid_boot_mouse_report() upper half.
- usbkbd:, usbmouse: and ohci0: DEVDB entries are created only after the
  corresponding native controller/device is actually present.
- USB is attempted before PS/2 mouse fallback.  One logical keyboard and mouse
  backend remain active according to the USB-first input policy.

Current limitations:

- no external USB hubs
- no hot-plug enumeration after boot
- no general EHCI high-speed transfer engine
- no UHCI/xHCI transport
- polling completion instead of OHCI interrupts
- only HID boot keyboard/mouse interfaces are consumed

Useful diagnostics:

    usbinfo
    lsdev

Expected MCP61 boot diagnostics include PCI functions 10de:03f1 (OHCI) and
10de:03f2 (EHCI), root-port status lines, USB VID:PID/interface/endpoint lines,
and finally usbkbd:/usbmouse: in lsdev when those devices enumerate.
