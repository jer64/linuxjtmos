////////////////////////////////////////////////////////////////////////////////////////////
// hdService.c
// IDE hard disk driver service.
// (C) 2004 Jari Tuominen.
////////////////////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <jtmos/dcpacket.h>
#include "hd.h"
#include "hdService.h"
#include "../sata/ahci.h"
#include "../sata/mcp61.h"

////////////////////////////////////////////////////////////////////////////////////////////
//
static char hdReady=FALSE;

//
// int hdDeviceCall(int n_call,
//        int p1,int p2,int p3,int p4,
//        void *po1,void *po2)

//
#ifdef JTMOSKERNEL
////////////////////////////////////////////////////////////////////////////////////////////
//
int hd_init(void)
{
	hdReady = FALSE;

	/* Preserve the historical ATA/IDE path first.  On the EL1352 the BIOS
	 * advertises an IDE-compatible environment, so let it prove itself with
	 * a real sector read. Only a failed probe/sanity check enables SATA rescue. */
	if( hw_hd_init() )
	{
		if(hd_register_device()==0)
			printk("IDE: hda registered after sector sanity (%s, %d blocks of %d bytes).\n",
			       chd->lbaMode ? "LBA28" : "CHS",
			       chd->n_blocks/chd->units, chd->blocksize*chd->units);
		else
			printk("IDE: ATA disk identified, but hda device registration failed.\n");
	}
#if JTMOS_MOD_PCI
	else if(mcp61_sata_init_hda()==1)
	{
		printk("HD: hda physical backend = NVIDIA MCP61 SATA rescue PIO.\n");
	}
	else if(ahci_init_hda()==1)
	{
		printk("HD: hda physical backend = SATA/AHCI fallback.\n");
	}
#endif
	else
		printk("HD: no usable legacy IDE, MCP61 SATA or AHCI disk detected.\n");

	hdReady = TRUE;
	return 0;
}
#endif

