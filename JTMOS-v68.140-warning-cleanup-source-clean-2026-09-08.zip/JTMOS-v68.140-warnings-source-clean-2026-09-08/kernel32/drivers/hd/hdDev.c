// =========================================================================
// hdDev.c - IDE HD device access interface
// V67.8.53: true multi-block PIO commands.
// (C) 2002-2026 by Jari Tuominen
// =========================================================================
#include <stdio.h>
#include <jtmos/dcpacket.h>
#include "hd.h"
#include "hdDev.h"

int dhd_dev_mounted=1;
static int hdLock=0;

static int hd_transfer_blocks(int first,int count,BYTE *buf,int rw)
{
    DWORD logical_size,sector,remaining,chunk;
    int units,i,j,r,block_bytes;
    BYTE *p;

    if(chd==NULL || buf==NULL || count<=0 || first<0) return 1;
    units=chd->units;
    if(units<=0) units=1;
    logical_size=(DWORD)chd->n_blocks/(DWORD)units;
    if((DWORD)first>=logical_size || (DWORD)count>logical_size-(DWORD)first) return 1;
    block_bytes=units*512;

    if(chd->lbaMode) {
        sector=(DWORD)first*(DWORD)units;
        remaining=(DWORD)count*(DWORD)units;
        p=buf;
        while(remaining) {
            chunk=remaining>255U ? 255U : remaining;
            r=hdSectorRW_LBA(chd,p,(int)(chunk*512U),sector,chd->slave,rw,(int)chunk);
            if(r) return r;
            p+=chunk*512U;
            sector+=chunk;
            remaining-=chunk;
        }
        return 0;
    }

    /* CHS fallback: still one DEVAPI request, although the old hardware path
     * must issue individual sectors. */
    p=buf;
    for(i=0;i<count;i++) {
        for(j=0;j<units;j++) {
            r=hdBlockRW(chd,p+j*512,512,(first+i)*units+j,0,rw);
            if(r) return r;
        }
        p+=block_bytes;
    }
    return 0;
}

int hd_device_call(DEVICE_CALL_PARS)
{
    DWORD *size;
    int sz,r=0;

    if(n_call!=DEVICE_CMD_MOUNT && !dhd_dev_mounted) return 1;

    switch(n_call)
    {
        case DEVICE_CMD_MOUNT:
            dhd_dev_mounted=1;
            break;
        case DEVICE_CMD_UNMOUNT:
            dhd_dev_mounted=0;
            break;
        case DEVICE_CMD_INIT:
            break;
        case DEVICE_CMD_SHUTDOWN:
#ifdef USE_HD_CACHE
            hdFlushWriteBack();
#endif
            r=hdFlushDeviceCache(chd);
            if(r) return r;
            break;

        case DEVICE_CMD_READBLOCK:
            return hd_transfer_blocks(p1,1,(BYTE *)po1,READ);
        case DEVICE_CMD_WRITEBLOCK:
            return hd_transfer_blocks(p1,1,(BYTE *)po1,WRITE);
        case DEVICE_CMD_READBLOCKS:
            return hd_transfer_blocks(p1,p2,(BYTE *)po1,READ);
        case DEVICE_CMD_WRITEBLOCKS:
            return hd_transfer_blocks(p1,p2,(BYTE *)po1,WRITE);

        case DEVICE_CMD_GETSIZE:
            if(po1==NULL || chd==NULL) return 1;
            size=(DWORD *)po1;
            sz=chd->n_blocks/(chd->units>0 ? chd->units : 1);
            *size=(DWORD)sz;
            break;
        case DEVICE_CMD_GETBLOCKSIZE:
            if(po1==NULL || chd==NULL) return 1;
            size=(DWORD *)po1;
            sz=chd->blocksize*(chd->units>0 ? chd->units : 1);
            *size=(DWORD)sz;
            break;
        case DEVICE_CMD_FLUSH:
#ifdef USE_HD_CACHE
            hdFlushWriteBack();
#endif
            r=hdFlushDeviceCache(chd);
            if(r) return r;
            break;
        default:
            break;
    }

    hdLock=0;
    return 0;
}

int hd_register_device(void)
{
    int dnr;
    if(driver_getdevicebyname("hda")) {
        printk("cannot register device hda: device already registered\n");
        return 1;
    }
    dnr=driver_register_new_device("hda",hd_device_call,
                                   DEVICE_TYPE_BLOCK|DEVICE_TYPE_MULTIBLOCK);
    if(dnr<0) {
        printk("cannot register device hda: DEVDB returned %d\n",dnr);
        return 1;
    }
    /* V67.8.57.10.9: restore the generic HDA cache.  Small sequential writes
     * are accumulated as dirty 512-byte blocks and cache flush sorts them into
     * contiguous writeblocks1() runs.  Large writeblocks() calls still bypass
     * the tiny cache and go directly as one multi-sector ATA request.
     *
     * Durability remains explicit: syncdev()/close() -> driver_FlushDrive()
     * drains this cache and issues ATA FLUSH CACHE; FlexFAT additionally does
     * a direct media readback before declaring FAT metadata clean. */
    driver_enableDAPIReadCache(dnr);
    driver_enableDAPIWriteBackCache(dnr);
    printk("IDE: hda DAPI cache enabled (read cache + write-combining write-back).\n");
    return 0;
}
