//
#ifndef __INCLUDED_DEVAPI_RW_H__
#define __INCLUDED_DEVAPI_RW_H__

#define ENABLE_DEVAPI_HDLED

int _writeblock(int dnr, int b, BYTE *buf);
int _readblock(int dnr, int b, BYTE *buf);
int readblock(int dnr, int b, BYTE *buf);
int writeblock(int dnr, int b, BYTE *buf);

/* Multi-block API.  Return the number of complete blocks transferred. */
int readblocks(long device_nr,long block_nr,BYTE *buf,int count);
int writeblocks(long device_nr,long block_nr,BYTE *buf,int count);

/* Direct, uncached back end used by device-cache flush and Kyber dispatch. */
int readblock1(long device_nr,long block_nr,BYTE *buf);
int writeblock1(long device_nr,long block_nr,BYTE *buf);
int readblocks1(long device_nr,long block_nr,BYTE *buf,int count);
int writeblocks1(long device_nr,long block_nr,BYTE *buf,int count);

/* Historical names now map to the real generic cache. */
int readblockCached(long device_nr,long block_nr,BYTE *buf);
int writeblockCached(long device_nr,long block_nr,BYTE *buf);

/* Device API L2 cache control. */
int driver_block_cache_flush(int dnr);       /* dnr < 0 => all devices */
void driver_block_cache_invalidate(int dnr); /* drop entries; flush first if dirty data matters */
void driver_block_cache_stats(void);

void HDLED(int c);

#endif
