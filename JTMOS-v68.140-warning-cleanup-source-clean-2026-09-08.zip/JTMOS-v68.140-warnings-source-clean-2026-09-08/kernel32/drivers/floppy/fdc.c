/*
 * fdc.c - Floppy Disk Drive Low Level Functions
 * 
 * Copyright	(C) 1998 Fabian Nunez.
 *		(C) 2002-2004,2014 Jari Tuominen.
 * Ported to JTMOS & performance modifications by Jari Tuominen.
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * The author can be reached by email at: fabian@cs.uct.ac.za
 * 
 * or by airmail at: Fabian Nunez
 *                   10 Eastbrooke
 *                   Highstead Road
 *                   Rondebosch 7700
 *                   South Africa
 */
#include "basdef.h"
#include "kernel32.h"
#include "threads.h"
#include "fdc.h"
#include "fdcCache.h"
#include "fdc_dev.h"
#include "fdc2_dev.h"
#include "driver_api.h"
#include "driver_sys.h"
#include "syssh.h"
#include "dma.h"
#include "userhw.h"

//
#define ddprintk dprintk

/* Per-call floppy tracing used to print a line on every low-level operation.
 * Raw-device consumers such as SMSH "sqa floppy" can execute thousands of
 * these calls and force the text terminal to scroll continuously.  Keep error
 * diagnostics, but make the high-frequency WHERE trace opt-in. */
#ifdef FDC_TRACE_CALLS
#define WHERE dprintk("%s/%d\n", __FUNCTION__, __LINE__);
#else
#define WHERE do { } while(0);
#endif

//
FDC fdc;

// Currently selected drive.
// 0=A:, 1=B:, ... (0-3)
int fdc_drive=0;

// FDC controller version number (init needs this).
// Defaults to "version yet unknown".
int fdc_version = -1;

/* globals */
static volatile BOOL done = FALSE;
static BOOL dchange[2] = { FALSE, FALSE };
static BOOL motor = FALSE;
static DWORD mtick = 0;
static volatile int tmout = 0;
static BYTE status[7] = { 0 };
static BYTE statsz = 0;
static BYTE sr0 = 0;
static BYTE fdc_track = 0xff;
static DrvGeom geometry = { DG144_HEADS,DG144_TRACKS,DG144_SPT };
extern void fdc_asmirqhandler6(void);

/* Dedicated ISA DMA bounce buffer.
 *
 * Do not use a fixed low-memory address: the V65 kernel has grown across the
 * historical 0x80000 area.  The buffer is allocated from physical RAM below
 * 16 MiB and the allocator guarantees that it does not cross an ISA-DMA
 * 64 KiB boundary.  32 KiB is sufficient for the largest supported cylinder
 * transfer (1.68M: 21 sectors * 2 heads * 512 bytes = 21504 bytes).
 */
#define FDC_DMA_BUFFER_SIZE 0x00008000UL
static BYTE *tbaddr = NULL;
static DWORD tbphys = 0;

// Setup default delay values
void defaultDelays(FDCDELAY *d)
{
	// delay 500ms for motor to spin up
	d->motorOn=		500;
	// now let head settle for 15ms
	d->seek=		15;
	// The actual WAITFDC most used TIME-OUT VALUE
	d->fdcWait=		1000;
	//
	d->sendByte=		1000; // 128
	d->getByte=		1000; // 128

	// These values below are always same:
	d->maxTries=		3;
	d->safeMode=		1;	// Triggers safe mode on 2nd try

	// Delay 3000 milliseconds (3 seconds), then
	// turn floppy motor off(idle enough => motor off).
	d->floppyMotorOff=	3000;
}

// Setup safe delay values
void safeDelays(FDCDELAY *d)
{
	// delay 500ms for motor to spin up
	d->motorOn=		1000;
	// now let head settle for 15ms
	d->seek=		30;
	// The actual WAITFDC most used TIME-OUT VALUE
	d->fdcWait=		1000;
	//
	d->sendByte=		1000; // 128
	d->getByte=		1000; // 128

	// These values below are always same:
	d->maxTries=		3;
	d->safeMode=		1;	// Triggers safe mode on 2nd try

	// Delay 3000 milliseconds (3 seconds), then
	// turn floppy motor off(idle enough => motor off).
	d->floppyMotorOff=	3000;
}

// This function is called upon disk change.
//
// IMPORTANT: this function is also called from IRQ6.  Therefore it must stay
// strictly IRQ-safe.  In particular, do NOT call diskchangednr()/jtmfat_chdev()
// here: those functions flush and reload JTMFS state and may perform block I/O.
// Re-entering the filesystem while an FDC request is waiting for IRQ6 deadlocks
// the request (for example SMSH "sqa floppy2").
//
// The low-level driver only invalidates the selected drive cache and records
// the media-change state.  Filesystem-level refresh remains a process-context
// operation (explicit diskchange/mount paths).
void FDC_DISKCHANGE(void)
{
	int drive;

	WHERE
	drive = fdc_drive & 3;
	if(drive > 1)
		return;

	dchange[drive] = TRUE;
#ifdef DISKCHANGE_AFFECTS_FDC_BUFFERS
	/* Cache and media-change state are drive specific.  Do not flush dirty
	 * data from IRQ context; simply invalidate the cached read window. */
	fdc.ent[drive].isfree = 1;
	fdc.ent[drive].writeback = 0;
#endif
}

// Select FDC unit 0=A:, 1=B:.  Switching drives invalidates the cached seek
// position and explicitly stops the old motor so the next motor-on programs
// the DOR for the new unit.
void fd_selectdrive(int which)
{
	int next;

	WHERE
	if(which < 0 || which > 3)
		return;

	next = which & 3;
	if(next != fdc_drive)
	{
		if(motor)
		{
			outportb(FDC_DOR, 0x0c | (fdc_drive & 3));
			motor = FALSE;
		}
		mtick = 0;
		fdc_drive = next;
		fdc_track = 0xff;
	}
}

//
void fd_sleep(int waitAmount_ms)
{
	DWORD usec;

	WHERE
	if(waitAmount_ms <= 0)
		return;

	/* FDC delays are now real elapsed-time waits.  UsecSleep() yields when the
	 * scheduler is active and HLTs in the boot/storage-safe path, so a 500 ms
	 * motor spin-up is 500 ms without consuming 500 ms of CPU. */
	usec = (DWORD)waitAmount_ms * 1000UL;
	if(UsecSleep(usec) != 0)
	{
		/* Fallback for a caller that entered with IF clear.  FDC operations
		 * normally run with IRQs enabled, but preserve forward progress. */
		DWORD start = GetTickCount();
		enable();
		while((DWORD)(GetTickCount() - start) < (DWORD)waitAmount_ms)
		{
			if(Multitasking && !PitStorageSafeActive()) SwitchToThread();
			else cpu_halt();
		}
	}
}

//
void __fd_sleep(int waitAmount_ms)
{
	int i,i2,i3,i4;
	enable();
	WHERE
	for(i=GetTickCount(); (GetTickCount()-i)<waitAmount_ms; )
	{
		printk("%d < %d   \r",
			(GetTickCount()-i), waitAmount_ms );
		SCHEDULE();
	}
}

//
void _______fd_sleep(int ms)
{
	int i,i2,t;

	//
	ms=ms/1000;
	if(!ms)ms++;
	for(t=GetSeconds(); (GetSeconds()-t)<ms; )
		idle_moment();
}

/* Reserve the FDC DMA window as soon as physical memory management is ready.
 * Normal kmalloc() walks physical pages from low to high, starting at 10 MiB.
 * Waiting until the late storage-driver init can therefore exhaust/fragment the
 * small ISA-DMA addressable window below 16 MiB. */
int fdc_prepare_dma(void)
{
	if(tbaddr != NULL)
		return 0;

	tbaddr = (BYTE *)userhw_dma_alloc_kernel(FDC_DMA_BUFFER_SIZE, &tbphys);
	if(tbaddr == NULL)
	{
		tbphys = 0;
		return -1;
	}
	return 0;
}

// ==========================================================
// FDC driver main init function 
// ==========================================================
void fdc_init(void)
{
	WHERE
	//
	printk("3.5\" 1.44M disk device driver 1.0\n");

	// Structure init
	memset(&fdc, 0, sizeof(FDC));

	// Setup delays
	defaultDelays(&fdelay);

	/* Allocate one two-track cache for each physical floppy unit.
	 * fdc.ent[0] = A:/floppy, fdc.ent[1] = B:/floppy2. */
	fdc.ent[0].buf = malloc(512*18*2);
	fdc.ent[1].buf = malloc(512*18*2);
	if(fdc.ent[0].buf == NULL)
	{
		printk("FDC: cannot allocate primary-drive cache; driver disabled.\n");
		return;
	}
	ChangeChunkOwner(fdc.ent[0].buf, 0);
	fdc.ent[0].isfree = 1;
	fdc.ent[0].writeback = 0;

	if(fdc.ent[1].buf != NULL)
	{
		ChangeChunkOwner(fdc.ent[1].buf, 0);
		fdc.ent[1].isfree = 1;
		fdc.ent[1].writeback = 0;
	}
	else
	{
		printk("FDC: warning: cannot allocate B: cache; floppy2 disabled.\n");
	}

	/* V65: reserve a real ISA-DMA-safe bounce window from the MM bitmap.
	 * The old fixed 0x80000 window overlaps the growing kernel image.  The
	 * normal path pre-reserves this immediately after mmInit(); retry here so
	 * alternate init paths still work. */
	if(fdc_prepare_dma() != 0)
	{
		printk("FDC: no safe <16 MiB DMA bounce buffer; driver disabled.\n");
		printk("FDC: reserve DMA before general kernel allocations (need %u bytes).\n",
			(unsigned int)FDC_DMA_BUFFER_SIZE);
		return;
	}
	printk("FDC: DMA bounce phys=0x%x map=0x%x size=%u.\n",
		tbphys, tbaddr, (unsigned int)FDC_DMA_BUFFER_SIZE);

	// HW init
	fd_init();

	//
	floppy_register_device();
	if(fdc.ent[1].buf != NULL)
	{
		floppy2_register_device();
		printk("FDC: registered floppy=A: and floppy2=B:.\n");
	}
}

/* helper functions */
/* init driver */
void fd_init(void)
{
	int i,i2;

	WHERE
	//
	ddprintk("\rfdc.c: Floppy driver initialising ...                    \r");
   
	/* install IRQ6 handler */
	setint(M_VEC+6,
		fdc_asmirqhandler6,
		GIMMIE_CS(),
		D_PRESENT + D_INT);
	enable_irq(6);

	//
	ddprintk("\rfdc.c: Determining HW version                    \r");
	/* get floppy controller version */
	for(i2=0,i=-1; i2<32 && i==-1; i2++)
	{
		fd_sendbyte(CMD_VERSION);
		i = fd_getbyte();
	}
	fdc_version = i;

	//
	if(i==-1)
	{
		printk("fdc.c: Could not receive controller version.\n");
	}
	else
	if(i == VER_OLDNECFDC)
	{
		// Old!
		printk("fdc.c: NEC765 controller found. Not fully supported.     \n");
	}
	else
	{
		// Modern.
		printk("fdc.c: Enhanced controller found(0x%x).                  \n", i);
	}

	//
	fd_reset();
}

/* deinit driver */
void fd_deinit(void)
{
	WHERE
	/* stop motor forcefully */
	outportb(FDC_DOR,0x0c|(fdc_drive & 3));
}

/* fd_sendbyte() routine from intel manual */
void fd_sendbyte(int byte)
{
	volatile int msr;
	int tmo;

	WHERE
	for (tmo=0; tmo<fdelay.sendByte; tmo++)
	{
		msr = inportb(FDC_MSR);
		if( (msr & 0xc0)==0x80 )
		{
			outportb(FDC_DATA,byte);
			return;
		}

		inportb(0x80);   /* delay */
	}
}

/* fd_getbyte() routine from intel manual */
int fd_getbyte()
{
	volatile int msr;
	int tmo;

	WHERE
	for (tmo=0; tmo<fdelay.getByte; tmo++)
	{
		msr = inportb(FDC_MSR);
		if ((msr & 0xd0) == 0xd0)
		{
			return inportb(FDC_DATA);
		}
		inportb(0x80);   /* delay */
	}

	return -1;   /* read timeout */
}

/* this waits for FDC command to complete */
BOOL fd_waitfdc(BOOL sensei)
{
	DWORD start;
	BOOL completed;
	DWORD flags;

	tmout = fdelay.fdcWait;
	start = GetTickCount();

	WHERE
	/* Wait for IRQ6, not for a coarse CMOS-second transition.  CMOS is a
	 * wall clock and the old rtc_getseconds() loop could add nearly a second
	 * of jitter (and behaved badly across midnight).  GetTickCount() is now
	 * derived from the exact PIT divisor. */
	while(!done && (DWORD)(GetTickCount() - start) < (DWORD)fdelay.fdcWait)
	{
		if(Multitasking && !PitStorageSafeActive())
		{
			SwitchToThread();
		}
		else
		{
			/* During boot/storage-safe mode no scheduler is available.  HLT
			 * lets IRQ6 wake us immediately; IRQ0 provides the timeout clock. */
			flags = get_eflags();
			if(flags & 0x200)
				cpu_halt();
		}
	}

	completed = done;
	done = FALSE;
	tmout = 0;

	if(!completed)
	{
		/* A command timeout is not itself a media change.  Only the FDC DIR
		 * change-line bit may mark the selected drive changed. */
		if(inportb(FDC_DIR) & 0x80)
			FDC_DISKCHANGE();
		return FALSE;
	}

	/* read in command result bytes */
	statsz = 0;
	while ((statsz < 7) && (inportb(FDC_MSR) & (1<<4)))
	{
		status[statsz++] = fd_getbyte();
	}

	if (sensei)
	{
		fd_sendbyte(CMD_SENSEI);
		sr0 = fd_getbyte();
		fdc_track = fd_getbyte();
	}

	return TRUE;
}

/* This is the IRQ6 handler */
void fdc_irqhandler6(void)
{
	/* Check for disk change - Added by Jari. */
	if(inportb(FDC_DIR) & 0x80)
	{
		/* IRQ context: only mark/invalidate.  Never enter JTMFS here. */
		FDC_DISKCHANGE();
		WHERE
	}

	/* signal operation finished */
	done = TRUE;

	/* EOI the PIC */
	pic_send_eoi(6);
}

/* This is the timer (int 0x1C) handler */
void fd_int1c(void)
{
	//
	if (tmout) --tmout;     /* bump timeout */
   
	// Turn off the motor after the configured idle interval.
	if( (mtick>0 && (DWORD)(GetTickCount()-mtick) >=
	     (DWORD)fdelay.floppyMotorOff) && motor )
	{
		//
		WHERE
		outportb(FDC_DOR,0x0c|(fdc_drive & 3));  /* turn off floppy motor */
		motor = FALSE;
	}
}

/*
 * converts linear block address to head/track/sector
 * 
 * blocks are numbered 0..heads*tracks*spt-1
 * blocks 0..spt-1 are serviced by head #0
 * blocks spt..spt*2-1 are serviced by head 1
 * 
 * WARNING: garbage in == garbage out
 */
void fd_block2hts(int block,int *head,int *track,int *sector)
{
	*head = (block % (geometry.spt * geometry.heads)) / (geometry.spt);
	*track = block / (geometry.spt * geometry.heads);
	*sector = block % geometry.spt + 1;
}

/**** disk operations ****/

// This gets the FDC to a known state.
// BUG: Only works with newer FDC controllers.
void fd_reset(void)
{
	int i;

	WHERE
	if(fdc_version==-1)
		return;

	/* Assert controller reset with motors off, then release reset and enable
	 * DMA/IRQ.  DOR bit 2 is nRESET and bit 3 enables DMA/IRQ.  The old
	 * enhanced-controller value 0x1A left bit 2 clear and could keep the FDC
	 * in reset after the now-fixed VERSION probe. */
	done = FALSE;
	outportb(FDC_DOR, (fdc_drive & 3));
	inportb(0x80); inportb(0x80); inportb(0x80); inportb(0x80);

	/* 500 kbit/s data rate for 1.44 MB media. */
	outportb(FDC_DRS,0);
	outportb(FDC_DOR, 0x0c | (fdc_drive & 3));
	motor = FALSE;
	mtick = GetTickCount();

	/* Releasing reset raises IRQ6.  Wait for it without burning CPU. */
	if(!fd_waitfdc(FALSE))
	{
		ddprintk("%s: controller reset IRQ timeout\n", __FUNCTION__);
		return;
	}

	/* A 765-compatible controller reports one pending interrupt condition for
	 * each drive after reset.  Drain all four so the first real seek cannot
	 * inherit stale reset status. */
	for(i=0; i<4; i++)
	{
		fd_sendbyte(CMD_SENSEI);
		sr0 = fd_getbyte();
		fdc_track = fd_getbyte();
	}
	fdc_track = 0xff;

	/* Specify conservative 1.44 MB drive timings. */
	fd_sendbyte(CMD_SPECIFY);
	fd_sendbyte(0xDF);  /* SRT = 3ms, HUT = 240ms */
	if(fdc_version != VER_OLDNECFDC)
		fd_sendbyte(0x06);  /* HLT ~= 12ms, DMA enabled */
	else
		fd_sendbyte(0x02);  /* HLT = 16ms, DMA enabled */

	/* Clear disk-change status and establish cylinder 0. */
	fd_seek(1);
	fd_recalibrate();
	if((fdc_drive & 3) <= 1)
		dchange[fdc_drive & 3] = FALSE;
}

/* this returns whether there was a disk change on the selected drive */
BOOL fd_diskchange(void)
{
	int drive = fdc_drive & 3;
	if(drive > 1)
		return FALSE;
	return dchange[drive];
}

/* this turns the motor on */
void fd_motoron(void)
{
	WHERE

	//
	if(!motor)
	{
		//
		mtick = 0;      /* stop motor kill countdown */
		outportb(FDC_DOR, 0x0c | (fdc_drive & 3) | (0x10 << (fdc_drive & 3)));
		fd_sleep(fdelay.motorOn); /* delay 500ms for motor to spin up */
		motor = TRUE;
	}
}

/* this turns the motor off */
void fd_motoroff(void)
{
	WHERE

	if (motor)
		/* Keep the spindle alive across nearby requests; this avoids paying
		 * another 500 ms spin-up on normal filesystem bursts. */
		mtick = GetTickCount();
}

/* recalibrate the drive */
void fd_recalibrate(void)
{
	WHERE

	/* turn the motor on */
	fd_motoron();
   
	/* send actual command bytes */
	fd_sendbyte(CMD_RECAL);
	fd_sendbyte(fdc_drive & 3);

	/* wait until seek finished */
	fd_waitfdc(TRUE);
   
	/* turn the motor off */
	fd_motoroff();
}

/* seek to track */
BOOL fd_seek(int track)
{
	WHERE

	if (fdc_track == track)  /* already there? */
		return TRUE;
   
	fd_motoron();
   
	/* send actual command bytes */
	fd_sendbyte(CMD_SEEK);
	fd_sendbyte(fdc_drive & 3);
	fd_sendbyte(track);

	/* wait until seek finished */
	if (!fd_waitfdc(TRUE))
		return FALSE;     /* timeout! */

	/* now let head settle for 15ms */
	fd_sleep(fdelay.seek);
   
	fd_motoroff();
   
	/* check that seek worked */
	if (((sr0 & 0xfc) != 0x20) || (fdc_track != track))
		return FALSE;
	else
		return TRUE;
}

/* checks drive geometry - call this after any disk change */
BOOL log_disk(DrvGeom *g)
{
	WHERE

	/* get drive in a known status before we do anything */
	fd_reset();

	/* assume disk is 1.68M and try and read block #21 on first track */
	geometry.heads = DG168_HEADS;
	geometry.tracks = DG168_TRACKS;
	geometry.spt = DG168_SPT;

	if(fd_read_block(20,NULL))
	{
		/* disk is a 1.68M disk */
		if(g)
		{
			g->heads = geometry.heads;
			g->tracks = geometry.tracks;
			g->spt = geometry.spt;
		}
		return TRUE;             
	}
   
	/* OK, not 1.68M - try again for 1.44M reading block #18 on first track */
	geometry.heads = DG144_HEADS;
	geometry.tracks = DG144_TRACKS;
	geometry.spt = DG144_SPT;

	if(fd_read_block(17,NULL))
	{
		/* disk is a 1.44M disk */
		if(g)
		{
			g->heads = geometry.heads;
			g->tracks = geometry.tracks;
			g->spt = geometry.spt;
		}
		return TRUE;
	}
   
	/* it's not 1.44M or 1.68M - we don't support it */
	return FALSE;
}

/* write blocks */
BOOL fd_write_blocks(int block, BYTE *blockbuff, int amount)
{
	int rv;
	int tries;

	WHERE

	//
	defaultDelays(&fdelay);
	//
	for(tries=0; tries<fdelay.maxTries; tries++)
	{
		rv = fdc_rw(block,blockbuff,FALSE, amount);
		if(rv==TRUE)
			break;

		ddprintk("%s: Write blocks failed on block %d, try=%d\n",
			__FUNCTION__, block, tries+1);
		if(tries==0)
			fd_recalibrate();
		else if(tries==fdelay.safeMode)
		{
			fd_reset();
			safeDelays(&fdelay);
		}
	}

	//
	return rv;
}

/* read blocks */
BOOL fd_read_blocks(int block, BYTE *blockbuff, int amount)
{
	int rv,tries;
	tries=0;

	WHERE

	defaultDelays(&fdelay);
	for(tries=0; tries<fdelay.maxTries; tries++)
	{
		if(tries)
			ddprintk("%s: Retrying read block %d, try=%d\n",
				__FUNCTION__,
				block, tries);
	
		rv = fdc_rw(block,blockbuff,TRUE, amount);
		if(rv==TRUE)
		{
			// Read OK
			break;
		}
		else
		{
			/* One low-level command per outer retry.  The historical code
			 * nested another maxTries loop in fdc_rw(), producing as many
			 * as 16 one-second attempts for one failed request. */
			if(tries==0)
				fd_recalibrate();
			else if(tries==fdelay.safeMode)
			{
				fd_reset();
				safeDelays(&fdelay);
				ddprintk("%s: Trying safe parameters\n",
					__FUNCTION__);
			}
		}
	}

	// If eventually failed, do tell about it:
	if(rv==FALSE)
	{
		ddprintk("%s: fd_read_block READ FAILURE after %d tries\n",
			__FUNCTION__, tries);
	}
	return rv;
}

/*
 * since reads and writes differ only by a few lines, this handles both.  This
 * function is called by fd_read_block() and write_block()
 */
// TODO - Make it load whole track at once.
BOOL fdc_rw(int block,BYTE *blockbuff,BOOL read, int amount)
{
	int head,track,sector;

	WHERE

	if(amount <= 0 || amount > (geometry.spt * geometry.heads))
		return FALSE;
	if((DWORD)amount > (FDC_DMA_BUFFER_SIZE / 512UL))
		return FALSE;

	/* convert logical address into physical address */
	fd_block2hts(block,&head,&track,&sector);
	ddprintk("block %d = %d:%d:%d\n",block,head,track,sector);

	/* spin up the disk only when necessary; subsequent cached requests keep
	 * the motor alive for fdelay.floppyMotorOff milliseconds. */
	fd_motoron();

	if (!read && blockbuff)
		memcpy(tbaddr, blockbuff, 512*amount);

	if(inportb(FDC_DIR) & 0x80)
	{
		FDC_DISKCHANGE();
		fd_seek(1);
		fd_recalibrate();
		fd_motoroff();
		return FALSE;
	}

	if(!fd_seek(track))
	{
		ddprintk("%s: Seek time-out\n", __FUNCTION__);
		fd_motoroff();
		return FALSE;
	}

	/* 1.44 MB 3.5-inch media use 500 kbit/s MFM. */
	outportb(FDC_CCR,0);

	if(read)
	{
		dma_xfer(FDC_DMA,tbphys,512*amount,FALSE);
		fd_sendbyte(CMD_READ);
	}
	else
	{
		dma_xfer(FDC_DMA,tbphys,512*amount,TRUE);
		fd_sendbyte(CMD_WRITE);
	}

	fd_sendbyte((head << 2) | (fdc_drive & 3));
	fd_sendbyte(track);
	fd_sendbyte(head);
	fd_sendbyte(sector);
	fd_sendbyte(2);               /* 512 bytes/sector */
	fd_sendbyte(geometry.spt);
	fd_sendbyte((geometry.spt == DG144_SPT) ? DG144_GAP3RW : DG168_GAP3RW);
	fd_sendbyte(0xff);            /* DTL = unused */

	if(!fd_waitfdc(FALSE))
	{
		ddprintk("%s: Operation(R/W) time-out error\n", __FUNCTION__);
		fd_motoroff();
		return FALSE;
	}

	if((status[0] & 0xc0) != 0)
	{
		fd_motoroff();
		return FALSE;
	}

	fd_motoroff();

	if(read && blockbuff)
		memcpy(blockbuff, tbaddr, 512*amount);

	return TRUE;
}

/* this formats a track, given a certain geometry */
BOOL format_track(BYTE track,DrvGeom *g)
{
	int i,h,r,r_id,split;
	static BYTE tmpbuff[256];

	WHERE

	/* check geometry */
	if (g->spt != DG144_SPT && g->spt != DG168_SPT)
		return FALSE;
   
	/* spin up the disk */
	fd_motoron();

	/* program data rate (500K/s) */
	outportb(FDC_CCR,0);

	fd_seek(track);  /* seek to track */

	/* precalc some constants for interleave calculation */
	split = g->spt / 2;
	if (g->spt & 1) split++;
   
	for (h = 0;h < g->heads;h++)
	{
		/* for each head... */
      
		/* check for diskchange */
		if (inportb(FDC_DIR) & 0x80)
		{
			FDC_DISKCHANGE();
			fd_seek(1);  /* clear "disk change" status */
			fd_recalibrate();
			fd_motoroff();
			return FALSE;
		}

		i = 0;   /* reset buffer index */
		for (r = 0;r < g->spt;r++)
		{
			/* for each sector... */

			/* calculate 1:2 interleave (seems optimal in my system) */
			r_id = r / 2 + 1;
			if (r & 1) r_id += split;
	 
			/* add some head skew (2 sectors should be enough) */
			if (h & 1)	
			{
				r_id -= 2;
				if (r_id < 1) r_id += g->spt;
			}
      
			/* add some track skew (1/2 a revolution) */
			if (track & 1)
			{
				r_id -= g->spt / 2;
				if (r_id < 1) r_id += g->spt;
			}
	 
			/**** interleave now calculated - sector ID is stored in r_id ****/

			/* fill in sector ID's */
			tmpbuff[i++] = track;
			tmpbuff[i++] = h;
			tmpbuff[i++] = r_id;
			tmpbuff[i++] = 2;
		}

		/* copy sector ID's to track buffer */
		memcpy(tbaddr, tmpbuff, i);
//		movedata(_my_ds(),(long)tmpbuff,_dos_ds,tbaddr,i);
      
		/* start dma xfer */
		dma_xfer(FDC_DMA,tbphys,i,TRUE);
      
		/* prepare "format track" command */
		fd_sendbyte(CMD_FORMAT);
		fd_sendbyte((h << 2) | (fdc_drive & 3));
		fd_sendbyte(2);
		fd_sendbyte(g->spt);
		if (g->spt == DG144_SPT)      
			fd_sendbyte(DG144_GAP3FMT);    /* gap3 size for 1.44M format */
		else
			fd_sendbyte(DG168_GAP3FMT);    /* gap3 size for 1.68M format */
		fd_sendbyte(0);     /* filler byte */
	 
		/* wait for command to finish */
		if(!fd_waitfdc(FALSE))
			return FALSE;
      
		if(status[0] & 0xc0)
		{
			fd_motoroff();
			return FALSE;
		}
	}
   
	fd_motoroff();
	return TRUE;
}

