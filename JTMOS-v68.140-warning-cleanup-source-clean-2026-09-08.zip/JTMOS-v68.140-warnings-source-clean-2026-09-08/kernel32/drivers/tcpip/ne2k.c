/* NE2000 ISA polling driver. QEMU defaults: io=0x300, irq=9. */
#include "kernel32.h"
#include "ne2k.h"
#define CR 0x00
#define PSTART 0x01
#define PSTOP 0x02
#define BNRY 0x03
#define TPSR 0x04
#define TBCR0 0x05
#define TBCR1 0x06
#define ISR 0x07
#define RSAR0 0x08
#define RSAR1 0x09
#define RBCR0 0x0a
#define RBCR1 0x0b
#define RCR 0x0c
#define TCR 0x0d
#define DCR 0x0e
#define IMR 0x0f
#define DATA 0x10
#define RESET 0x1f
/* NE2000 (16 KiB packet RAM base): pages 0x40..0x7f.
 * Reserve six 256-byte pages (1536 bytes) for the largest Ethernet TX frame
 * and start the receive ring immediately after it.  Page 0x20 belongs to the
 * NE1000 memory layout and is not writable packet RAM on QEMU's NE2000. */
#define TX_PAGE 0x40
#define TX_PAGES 6
#define RX_START (TX_PAGE + TX_PAGES)
#define RX_STOP 0x80
static unsigned short base;
static int found;
static unsigned char macaddr[6];
static BYTE txbuf[1518];
static void regw(int r,int v){outportb(base+r,(BYTE)v);}
static int regr(int r){return inportb(base+r);}
static int wait_rdc(void){DWORD s=GetTickCount();while(!(regr(ISR)&0x40)){if((DWORD)(GetTickCount()-s)>100)return -1;}regw(ISR,0x40);return 0;}
static int dma_read(int addr,void *dst,int len){int i;BYTE *p=dst;regw(CR,0x22);regw(RBCR0,len);regw(RBCR1,len>>8);regw(RSAR0,addr);regw(RSAR1,addr>>8);regw(CR,0x0a);for(i=0;i<len;i++)p[i]=inportb(base+DATA);return wait_rdc();}
static int dma_write(int addr,const void *src,int len){int i;const BYTE *p=src;regw(CR,0x22);regw(RBCR0,len);regw(RBCR1,len>>8);regw(RSAR0,addr);regw(RSAR1,addr>>8);regw(CR,0x12);for(i=0;i<len;i++)outportb(base+DATA,p[i]);return wait_rdc();}
static int ring_read(int addr,void *dst,int len){int end=RX_STOP<<8,first;if(addr+len<=end)return dma_read(addr,dst,len);first=end-addr;if(dma_read(addr,dst,first)<0)return -1;return dma_read(RX_START<<8,(BYTE*)dst+first,len-first);}
int ne2k_init(unsigned short io,int irq){BYTE prom[32];int i;BYTE rst;base=io;found=0;rst=inportb(base+RESET);outportb(base+RESET,rst);for(i=0;i<32;i++)inportb(0x80);regw(CR,0x21);regw(DCR,0x48);regw(RBCR0,0);regw(RBCR1,0);regw(RCR,0x20);regw(TCR,0x02);regw(PSTART,RX_START);regw(PSTOP,RX_STOP);regw(BNRY,RX_START);regw(ISR,0xff);regw(IMR,0);if(dma_read(0,prom,32)<0)return -1;for(i=0;i<6;i++)macaddr[i]=prom[i*2];if((macaddr[0]==0xff&&macaddr[1]==0xff)||(macaddr[0]==0&&macaddr[1]==0))return -1;regw(CR,0x61);for(i=0;i<6;i++)regw(1+i,macaddr[i]);regw(7,RX_START+1);for(i=8;i<16;i++)regw(i,0xff);regw(CR,0x21);regw(RCR,0x04);regw(TCR,0);regw(ISR,0xff);regw(CR,0x22);found=1;printk("NE2K: io=0x%x irq=%d mac=%x:%x:%x:%x:%x:%x (polling)\n",base,irq,macaddr[0],macaddr[1],macaddr[2],macaddr[3],macaddr[4],macaddr[5]);return 0;}
int ne2k_present(void){return found;}
const unsigned char *ne2k_mac(void){return macaddr;}
int ne2k_send(const void *buf,int len)
{
    int n=len,isr;
    DWORD start;
    if(!found||!buf||len<=0||len>1518)return -1;
    if(n<60)n=60;
    memcpy(txbuf,buf,len);
    if(n>len)memset(txbuf+len,0,n-len);

    /* TX_PAGE is in real NE2000 packet RAM (0x4000+).  The previous 0x20
     * page silently discarded remote-DMA writes in QEMU, so DHCP and ARP
     * frames never contained the packet JTMOS had constructed. */
    if(dma_write(TX_PAGE<<8,txbuf,n)<0)return -2;
    regw(TPSR,TX_PAGE);
    regw(TBCR0,n);
    regw(TBCR1,n>>8);
    regw(ISR,0x0a);             /* clear PTX/TXE from an earlier frame */
    regw(CR,0x26);              /* start + no remote DMA + transmit */

    /* Poll completion because this driver intentionally runs without a NIC
     * IRQ handler.  Do not report success merely because DMA completed. */
    start=GetTickCount();
    for(;;)
    {
        isr=regr(ISR);
        if(isr&0x08){regw(ISR,0x08);return -3;}
        if(isr&0x02){regw(ISR,0x02);return n;}
        if((DWORD)(GetTickCount()-start)>100)return -4;
        SwitchToThread();
    }
}
int ne2k_receive(void *buf,int maxlen){BYTE h[4];int boundary,current,next,len;if(!found||!buf)return 0;regw(CR,0x62);current=regr(7);regw(CR,0x22);boundary=regr(BNRY);next=boundary+1;if(next>=RX_STOP)next=RX_START;if(next==current)return 0;if(dma_read(next<<8,h,4)<0)return -1;len=(h[2]|(h[3]<<8))-4;if(len<14||len>1518||len>maxlen){regw(BNRY,h[1]==RX_START?RX_STOP-1:h[1]-1);return -1;}if(ring_read((next<<8)+4,buf,len)<0)return -1;regw(BNRY,h[1]==RX_START?RX_STOP-1:h[1]-1);regw(ISR,0xff);return len;}
