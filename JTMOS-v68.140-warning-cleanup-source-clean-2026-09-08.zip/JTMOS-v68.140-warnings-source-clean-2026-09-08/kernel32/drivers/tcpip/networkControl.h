#ifndef JTMOS_NETWORK_CONTROL_H
#define JTMOS_NETWORK_CONTROL_H

#define JTMOS_INET_OFFLINE   0
#define JTMOS_INET_STARTING  1
#define JTMOS_INET_ONLINE    2
#define JTMOS_INET_STOPPING  3

int JtInternetStart(int com_port, int bps);
int JtInternetStop(void);
int JtInternetRestart(void);
int JtInternetState(void);
int JtInternetSlipPID(void);
int JtInternetStackPID(void);
int JtInternetComPort(void);
int JtInternetBPS(void);
const char *JtInternetStackName(void);
int JtInternetStopRequested(void);
void JtInternetThreadExited(int which);

#endif
