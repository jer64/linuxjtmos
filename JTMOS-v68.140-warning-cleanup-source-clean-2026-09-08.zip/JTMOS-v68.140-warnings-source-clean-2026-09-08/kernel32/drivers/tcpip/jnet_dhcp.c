/* DHCPv4 packet codec for JNET.  This file deliberately has no dependency on
 * JTMOS scheduler/device state so it can be host-unit-tested byte for byte. */
#ifdef JTMOS
#include "kernel32.h"
#else
#include <string.h>
#endif
#include "jnet_dhcp.h"

static unsigned int rd16(const unsigned char *p)
{
    return ((unsigned int)p[0]<<8) | (unsigned int)p[1];
}

static unsigned int rd32(const unsigned char *p)
{
    return ((unsigned int)p[0]<<24) | ((unsigned int)p[1]<<16) |
           ((unsigned int)p[2]<<8) | (unsigned int)p[3];
}

static void wr16(unsigned char *p,unsigned int v)
{
    p[0]=(unsigned char)(v>>8); p[1]=(unsigned char)v;
}

static void wr32(unsigned char *p,unsigned int v)
{
    p[0]=(unsigned char)(v>>24); p[1]=(unsigned char)(v>>16);
    p[2]=(unsigned char)(v>>8); p[3]=(unsigned char)v;
}

static unsigned int ip_checksum(const unsigned char *p,int n)
{
    unsigned int sum=0;
    while(n>1) { sum+=rd16(p); p+=2; n-=2; }
    if(n) sum+=((unsigned int)*p)<<8;
    while(sum>>16) sum=(sum&0xffffU)+(sum>>16);
    return (~sum)&0xffffU;
}

static int is_zero4(const unsigned char a[4])
{
    return a[0]==0 && a[1]==0 && a[2]==0 && a[3]==0;
}

static int put_option(unsigned char **op,unsigned char *end,int tag,int n,const unsigned char *data)
{
    unsigned char *o=*op;
    if(n<0 || o+2+n>end) return -1;
    *o++=(unsigned char)tag; *o++=(unsigned char)n;
    if(n && data) memcpy(o,data,n);
    o+=n; *op=o;
    return 0;
}

int jnet_dhcp_build_frame(unsigned char *frame,int maxlen,const JNET_DHCP_BUILD *b)
{
    static const unsigned char broadcast_mac[6]={255,255,255,255,255,255};
    static const unsigned char broadcast_ip[4]={255,255,255,255};
    static const unsigned char zero_ip[4]={0,0,0,0};
    static const unsigned char prl[6]={1,3,6,51,58,59};
    static const unsigned char hostname[5]={'J','T','M','O','S'};
    unsigned char client_id[7],maxmsg[2];
    unsigned char *ip,*udp,*d,*o,*end;
    const unsigned char *dstmac,*srcip,*dstip;
    int i,n;

    if(!frame || !b || maxlen<320) return -1;
    if(b->message_type<1 || b->message_type>8) return -2;

    memset(frame,0,maxlen);
    dstmac=b->ethernet_dest;
    if(dstmac[0]==0 && dstmac[1]==0 && dstmac[2]==0 &&
       dstmac[3]==0 && dstmac[4]==0 && dstmac[5]==0)
        dstmac=broadcast_mac;
    srcip=is_zero4(b->source_ip)?zero_ip:b->source_ip;
    dstip=is_zero4(b->destination_ip)?broadcast_ip:b->destination_ip;

    for(i=0;i<6;i++) { frame[i]=dstmac[i]; frame[6+i]=b->client_mac[i]; }
    wr16(frame+12,0x0800);

    ip=frame+14; udp=ip+20; d=udp+8; o=d+240; end=frame+maxlen;
    ip[0]=0x45; ip[8]=64; ip[9]=17;
    wr16(ip+4,b->xid&0xffffU);
    memcpy(ip+12,srcip,4); memcpy(ip+16,dstip,4);
    wr16(udp,68); wr16(udp+2,67);

    d[0]=1; d[1]=1; d[2]=6; d[3]=0;
    wr32(d+4,b->xid); wr16(d+8,b->secs);
    if(b->broadcast) wr16(d+10,0x8000);
    memcpy(d+12,b->ciaddr,4);
    memcpy(d+28,b->client_mac,6);
    d[236]=99; d[237]=130; d[238]=83; d[239]=99;

    {
        unsigned char mt=(unsigned char)b->message_type;
        if(put_option(&o,end,53,1,&mt)<0) return -3;
    }
    client_id[0]=1; memcpy(client_id+1,b->client_mac,6);
    if(put_option(&o,end,61,7,client_id)<0) return -3;
    if(b->include_requested_ip && put_option(&o,end,50,4,b->requested_ip)<0) return -3;
    if(b->include_server_id && put_option(&o,end,54,4,b->server_id)<0) return -3;
    maxmsg[0]=0x02; maxmsg[1]=0x40; /* 576 bytes, RFC2131 minimum reassembly size */
    if(put_option(&o,end,57,2,maxmsg)<0) return -3;
    if(put_option(&o,end,55,6,prl)<0) return -3;
    if(put_option(&o,end,12,5,hostname)<0) return -3;
    if(o>=end) return -3;
    *o++=255;
    /* RFC2131-compatible BOOTP/DHCP clients traditionally transmit at least
     * 300 octets of DHCP payload.  Zero PAD bytes after END are legal and
     * improve interoperability with old relay/server implementations. */
    while((int)(o-d)<300)
    {
        if(o>=end) return -3;
        *o++=0;
    }

    n=(int)(o-d);
    wr16(udp+4,n+8);
    wr16(ip+2,n+28);
    wr16(ip+10,ip_checksum(ip,20));
    return n+42;
}

static int parse_options(const unsigned char *o,const unsigned char *end,JNET_DHCP_REPLY *out,int *msg,int *overload)
{
    while(o<end)
    {
        int tag,n;
        tag=*o++;
        if(tag==255)break;
        if(tag==0)continue;
        if(o>=end)return -1;
        n=*o++;
        if(o+n>end)return -1;
        switch(tag)
        {
            case 53:
                if(n==1)*msg=o[0];
                break;
            case 52:
                if(n==1 && overload)*overload|=(o[0]&3);
                break;
            case 54:
                if(n==4){memcpy(out->server,o,4);out->have_server=1;}
                break;
            case 1:
                if(n==4){memcpy(out->mask,o,4);out->have_mask=1;}
                break;
            case 3:
                if(n>=4){memcpy(out->gateway,o,4);out->have_gateway=1;}
                break;
            case 6:
                if(n>=4){memcpy(out->dns,o,4);out->have_dns=1;}
                break;
            case 51:
                if(n==4){out->lease_seconds=rd32(o);out->have_lease=1;}
                break;
            case 58:
                if(n==4){out->t1_seconds=rd32(o);out->have_t1=1;}
                break;
            case 59:
                if(n==4){out->t2_seconds=rd32(o);out->have_t2=1;}
                break;
        }
        o+=n;
    }
    return 0;
}

int jnet_dhcp_parse_reply(const unsigned char *frame,int len,unsigned int xid,
                          const unsigned char client_mac[6],JNET_DHCP_REPLY *out)
{
    const unsigned char *ip,*udp,*d,*o,*end;
    unsigned int ihl,total,frag,ulen;
    int msg=0,overload=0;

    if(!frame || !client_mac || !out) return -1;
    memset(out,0,sizeof(*out));
    if(len<14+20+8+240) return -2;
    if(rd16(frame+12)!=0x0800) return -3;

    ip=frame+14;
    if((ip[0]>>4)!=4) return -4;
    ihl=(unsigned int)(ip[0]&15U)*4U;
    if(ihl<20 || ihl>60 || 14U+ihl+8U+240U>(unsigned int)len) return -4;
    total=rd16(ip+2);
    if(total<ihl+8U+240U || total>(unsigned int)(len-14)) return -5;
    frag=rd16(ip+6);
    if(frag&0x3fffU) return -6; /* reject MF or nonzero fragment offset */
    if(ip[9]!=17) return -7;
    if(ip_checksum(ip,(int)ihl)!=0) return -8;

    udp=ip+ihl;
    if(rd16(udp)!=67 || rd16(udp+2)!=68) return -9;
    ulen=rd16(udp+4);
    if(ulen<8U+240U || ulen>total-ihl) return -10;
    d=udp+8;
    if(d[0]!=2 || d[1]!=1 || d[2]!=6) return -11;
    if(rd32(d+4)!=xid) return -12;
    if(memcmp(d+28,client_mac,6)!=0) return -13;
    if(d[236]!=99 || d[237]!=130 || d[238]!=83 || d[239]!=99) return -14;

    memcpy(out->yiaddr,d+16,4);
    o=d+240;end=udp+ulen;
    if(parse_options(o,end,out,&msg,&overload)<0)return -15;
    /* RFC2132 option 52 permits options in BOOTP file (128 bytes) and sname
     * (64 bytes). Parse those fixed fields only when explicitly overloaded. */
    if((overload&1) && parse_options(d+108,d+236,out,&msg,NULL)<0)return -15;
    if((overload&2) && parse_options(d+44,d+108,out,&msg,NULL)<0)return -15;
    if(msg<1 || msg>8) return -16;
    out->message_type=msg;
    if(!out->have_server)
    {
        memcpy(out->server,ip+12,4);
        out->have_server=!is_zero4(out->server);
    }
    return msg;
}
