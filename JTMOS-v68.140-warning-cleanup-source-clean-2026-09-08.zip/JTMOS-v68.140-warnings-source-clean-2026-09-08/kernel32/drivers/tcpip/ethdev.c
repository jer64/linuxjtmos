/* Generic Ethernet backend selector for uIP/JNet.
 * Native PCI Ethernet is preferred; NE2000 remains the QEMU/ISA fallback.
 *
 * V16.50 adds carrier/error accounting and rate-limited PHY polling on top of
 * the V16.49 cooperative serialization.  The lock is still a single-CPU
 * cooperative guard, not an SMP spinlock. */
#include "kernel32.h"
#include "ethdev.h"
#include "nforce.h"
#include "ne2k.h"

#define ETHDEV_LOCK_SPIN_LIMIT 1000000UL
#define ETHDEV_LINK_POLL_MS 500UL

static int backend;
static volatile int io_owner=-1;
static volatile unsigned long io_depth;
static ETHDEV_STATS estats;
static DWORD link_poll_tick;
static int carrier=-1;

static void ethdev_lock(void)
{
    int flags,pid;unsigned long spins=0;
    if(!Multitasking)return;
    pid=GetCurrentThread();flags=get_eflags();disable();
    while(io_owner!=-1 && io_owner!=pid)
    {
        set_eflags(flags);
        if(Multitasking && !PitStorageSafeActive() && (flags&0x200))SwitchToThread();
        else {volatile unsigned long i;for(i=0;i<128;i++){} }
        disable();
        if(++spins>=ETHDEV_LOCK_SPIN_LIMIT)
        {
            set_eflags(flags);printk("ethdev: lock contention owner=%d caller=%d; retrying.\n",io_owner,pid);spins=0;disable();
        }
    }
    if(io_owner==pid)io_depth++;else {io_owner=pid;io_depth=1;}
    set_eflags(flags);
}

static void ethdev_unlock(void)
{
    int flags,pid;if(!Multitasking)return;pid=GetCurrentThread();flags=get_eflags();disable();
    if(io_owner==pid&&io_depth){io_depth--;if(!io_depth)io_owner=-1;}
    set_eflags(flags);
}

static int valid_mac(const unsigned char *m)
{
    int i,all0=1,allf=1;
    if(!m)return 0;
    for(i=0;i<6;i++){if(m[i])all0=0;if(m[i]!=0xff)allf=0;}
    return !all0&&!allf&&!(m[0]&1);
}

/* Must be called while ethdev_lock is held. */
static int refresh_link_locked(int force)
{
    DWORD now=GetTickCount();int next;
    if(backend==ETHDEV_NONE){next=0;}
    else if(backend==ETHDEV_NE2K){next=1;}
    else
    {
        if(!force && carrier>=0 && (DWORD)(now-link_poll_tick)<ETHDEV_LINK_POLL_MS)
            return carrier;
        next=nforce_link_up()?1:0;
    }
    link_poll_tick=now;
    if(carrier>=0 && next!=carrier)
    {
        estats.link_changes++;
        printk("Ethernet: %s carrier %s.\n",ethdev_name(),next?"up":"down");
    }
    carrier=next;estats.link_up=next;
    return next;
}

int ethdev_init(void)
{
    int rv=ETHDEV_ERR_NO_DEVICE;
    const unsigned char *m;
    ethdev_lock();
    if(backend){rv=0;goto out;}
    memset(&estats,0,sizeof(estats));carrier=-1;link_poll_tick=0;
    if(nforce_init()==0 && nforce_present())
    {
        m=nforce_mac();
        if(valid_mac(m))
        {
            backend=ETHDEV_NFORCE;printk("Ethernet: selected NVIDIA nForce backend (%s).\n",nforce_pci_name());rv=0;goto selected;
        }
        printk("Ethernet: nForce backend rejected because MAC address is invalid.\n");
    }
    if(ne2k_present() || ne2k_init(NE2K_DEFAULT_IO,NE2K_DEFAULT_IRQ)==0)
    {
        if(ne2k_present())
        {
            m=ne2k_mac();
            if(valid_mac(m))
            {
                backend=ETHDEV_NE2K;printk("Ethernet: selected NE2000 backend.\n");rv=0;goto selected;
            }
            printk("Ethernet: NE2000 backend rejected because MAC address is invalid.\n");
        }
    }
    estats.last_error=ETHDEV_ERR_NO_DEVICE;
    goto out;
selected:
    estats.last_error=0;
    (void)refresh_link_locked(1);
out:
    ethdev_unlock();return rv;
}

int ethdev_restart(void)
{
    int rv;

    ethdev_lock();
    if(backend==ETHDEV_NFORCE) rv=nforce_restart();
    else if(backend==ETHDEV_NE2K) rv=ne2k_init(NE2K_DEFAULT_IO,NE2K_DEFAULT_IRQ);
    else
    {
        ethdev_unlock();
        return ethdev_init();
    }

    if(rv==0)
    {
        memset(&estats,0,sizeof(estats));
        carrier=-1;
        link_poll_tick=0;
        estats.last_error=0;
        (void)refresh_link_locked(1);
    }
    else estats.last_error=ETHDEV_ERR_IO;
    ethdev_unlock();
    return rv==0?0:ETHDEV_ERR_IO;
}

int ethdev_present(void){return backend!=ETHDEV_NONE;}
int ethdev_backend(void){return backend;}

int ethdev_receive(void *b,int n)
{
    int rv;
    if(!b||n<14){estats.last_error=ETHDEV_ERR_INVALID;return ETHDEV_ERR_INVALID;}
    ethdev_lock();
    if(backend==ETHDEV_NONE){rv=0;goto out;}
    if(!refresh_link_locked(0)){rv=0;goto out;}
    if(backend==ETHDEV_NFORCE)rv=nforce_receive(b,n);
    else if(backend==ETHDEV_NE2K)rv=ne2k_receive(b,n);
    else rv=0;
    if(rv<0){estats.rx_errors++;estats.last_error=ETHDEV_ERR_IO;rv=ETHDEV_ERR_IO;}
    else if(rv>0){estats.rx_packets++;estats.rx_bytes+=(unsigned long)rv;estats.last_error=0;}
out:
    ethdev_unlock();return rv;
}

int ethdev_send(const void *b,int n)
{
    int rv;
    if(!b||n<14||n>1518){estats.last_error=ETHDEV_ERR_INVALID;return ETHDEV_ERR_INVALID;}
    ethdev_lock();
    if(backend==ETHDEV_NONE){estats.tx_errors++;estats.last_error=ETHDEV_ERR_NO_DEVICE;rv=ETHDEV_ERR_NO_DEVICE;goto out;}
    if(!refresh_link_locked(0)){estats.tx_errors++;estats.last_error=ETHDEV_ERR_LINK_DOWN;rv=ETHDEV_ERR_LINK_DOWN;goto out;}
    if(backend==ETHDEV_NFORCE)rv=nforce_send(b,n);
    else if(backend==ETHDEV_NE2K)rv=ne2k_send(b,n);
    else rv=-1;
    if(rv<0){estats.tx_errors++;estats.last_error=ETHDEV_ERR_IO;rv=ETHDEV_ERR_IO;}
    else {estats.tx_packets++;estats.tx_bytes+=(unsigned long)rv;estats.last_error=0;}
out:
    ethdev_unlock();return rv;
}

const unsigned char *ethdev_mac(void)
{
    if(backend==ETHDEV_NFORCE)return nforce_mac();if(backend==ETHDEV_NE2K)return ne2k_mac();return NULL;
}
const char *ethdev_name(void){if(backend==ETHDEV_NFORCE)return "nForce/MCP61";if(backend==ETHDEV_NE2K)return "NE2000";return "none";}

int ethdev_link_up(void)
{
    int rv;ethdev_lock();rv=refresh_link_locked(0);ethdev_unlock();return rv;
}

void ethdev_get_stats(ETHDEV_STATS *out)
{
    if(!out)return;
    ethdev_lock();
    memcpy(out,&estats,sizeof(*out));
    ethdev_unlock();
}

void ethdev_reset_stats(void)
{
    int live_link,last;
    ethdev_lock();
    live_link=estats.link_up;
    last=estats.last_error;
    memset(&estats,0,sizeof(estats));
    estats.link_up=live_link;
    estats.last_error=last;
    ethdev_unlock();
}
