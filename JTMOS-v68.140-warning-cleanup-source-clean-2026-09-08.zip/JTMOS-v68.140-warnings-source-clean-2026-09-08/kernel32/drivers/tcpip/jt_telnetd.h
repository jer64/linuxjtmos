#ifndef JTMOS_JT_TELNETD_H
#define JTMOS_JT_TELNETD_H

int JtTelnetdRequest(int port);
void JtTelnetdDisable(void);
int JtTelnetdRequested(void);
int JtTelnetdIsListening(void);
int JtTelnetdPort(void);
int JtTelnetdAutoEnabled(void);
int JtTelnetdSetAuto(int enabled,int port);
int JtTelnetdPasswordReady(void);
void JtTelnetdDhcpLease(int active,const unsigned char ip[4]);
void JtTelnetdNetworkReset(void);
void JtTelnetdNetworkStop(void);
void JtTelnetdSync(void);
void JtTelnetdAppCall(void);

#endif
