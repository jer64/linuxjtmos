#ifndef JTMOS_JNET_H
#define JTMOS_JNET_H
#define JNET_AF_INET 2
#define JNET_SOCK_STREAM 1
#define JNET_SOCK_DGRAM 2
#define JNET_CFG_NONE 0
#define JNET_CFG_DHCP 1
#define JNET_CFG_QEMU_USER_STATIC 2
#define JNET_CFG_STATIC 3
#define JNET_CFG_NFORCE_DIRECT 4

#define JNET_DHCP_OFF        0
#define JNET_DHCP_SELECTING  1
#define JNET_DHCP_REQUESTING 2
#define JNET_DHCP_BOUND      3
#define JNET_DHCP_RENEWING   4
#define JNET_DHCP_REBINDING  5
#define JNET_DHCP_EXPIRED    6
#define JNET_DHCP_FAILED     7

/* Negative errno-shaped results used by the compact JNet control API. */
#define JNET_EINTR (-4)
#define JNET_EIO (-5)
#define JNET_EAGAIN (-11)
#define JNET_EBUSY (-16)
#define JNET_EINVAL (-22)
#define JNET_ENETDOWN (-100)
#define JNET_ENETUNREACH (-101)
#define JNET_ETIMEDOUT (-110)
#define JNET_EHOSTUNREACH (-113)

typedef unsigned int jnet_socklen_t;
struct jnet_in_addr { unsigned int s_addr; };
struct jnet_sockaddr { unsigned short sa_family; char sa_data[14]; };
struct jnet_sockaddr_in { unsigned short sin_family,sin_port;struct jnet_in_addr sin_addr;unsigned char sin_zero[8]; };

typedef struct {
    unsigned char ip[4],mask[4],gateway[4],server[4],dns[4];
    unsigned long lease_seconds;
    unsigned long t1_seconds;
    unsigned long t2_seconds;
    unsigned long lease_acquired_tick;
    int configured;
    int config_method;
    int dhcp_state;
    int dhcp_last_error;
} JNET_CONFIG;

typedef struct {
    unsigned long dhcp_discovers;
    unsigned long dhcp_requests;
    unsigned long dhcp_offers;
    unsigned long dhcp_acks;
    unsigned long dhcp_naks;
    unsigned long dhcp_timeouts;
    unsigned long dhcp_renewals;
    unsigned long dhcp_rebinds;
    unsigned long dhcp_link_losses;
    unsigned long dhcp_link_recoveries;
    unsigned long dhcp_fallback_probes;
    unsigned long arp_requests;
    unsigned long arp_hits;
    unsigned long arp_timeouts;
    unsigned long ping_requests;
    unsigned long ping_replies;
    unsigned long dns_requests;
    unsigned long dns_replies;
    unsigned long udp_rx_queued;
    unsigned long udp_rx_dropped;
    unsigned long owner_forwarded;
} JNET_STATS;

typedef struct { int count; unsigned char addr[8][4]; } JNET_HOST_RESULT;

int jnet_init_ne2k(void); /* compatibility alias */
int jnet_init_ethernet(void);
void jnet_reset_runtime(void);
int jnet_dhcp(void);
void jnet_owner_attach(void);
void jnet_owner_detach(void);
void jnet_maintenance(void);
const char *jnet_dhcp_state_name(int state);
unsigned long jnet_lease_remaining_seconds(void);
void jnet_get_stats(JNET_STATS *out);
void jnet_reset_stats(void);
int jnet_configure_qemu_user_fallback(void);
int jnet_configure_nforce_direct_fallback(void);
int jnet_configure_static(const unsigned char ip[4],const unsigned char mask[4],const unsigned char gateway[4],const unsigned char dns[4]);
const JNET_CONFIG *jnet_config(void);
void jnet_get_config(JNET_CONFIG *out);
int jnet_inet_pton(int af,const char *src,void *dst);
const char *jnet_inet_ntop(int af,const void *src,char *dst,jnet_socklen_t size);
int jnet_socket(int domain,int type,int protocol);
int jnet_close(int fd);
int jnet_connect(int fd,const struct jnet_sockaddr *addr,jnet_socklen_t len);
int jnet_send(int fd,const void *buf,unsigned int len,int flags);
int jnet_recv(int fd,void *buf,unsigned int len,int flags);
int jnet_ping_request(const unsigned char ip[4],unsigned long timeout_ms,unsigned long *rtt_ms);
int jnet_ping_request_ex(const unsigned char ip[4],unsigned long timeout_ms,unsigned short sequence,unsigned long *rtt_ms,unsigned char *ttl);
void jnet_service_requests(void);
int jnet_host_request(const char *name,unsigned long timeout_ms,JNET_HOST_RESULT *result);
/* Called only by the network owner thread before uIP sees an Ethernet frame.
 * Returns non-zero when the frame was consumed by a JNET UDP socket. */
int jnet_input_ethernet(const unsigned char *frame,int len);

#endif
