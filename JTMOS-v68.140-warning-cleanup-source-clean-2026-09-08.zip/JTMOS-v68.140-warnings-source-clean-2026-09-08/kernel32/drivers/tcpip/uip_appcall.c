/* JTMOS uIP application dispatcher. */
#include "kernel32.h"
#include "jt_http_client.h"
#include "jt_usersock.h"
#include "jt_httpd.h"
#include "jt_telnetd.h"

void UIP_APPCALL(void)
{
    JtHttpClientAppCall();
    if(JtUserSocketAppCall()) return;
    JtHttpdAppCall();
    JtTelnetdAppCall();
}
