#ifndef JTMOS_JT_USERSOCK_H
#define JTMOS_JT_USERSOCK_H

/* Generic userspace TCP stream bridge backed by the single-owner uIP stack.
 * System calls only enqueue/dequeue bytes.  All uIP API calls stay in the uIP
 * owner thread through Service/AppCall. */
int JtUserSocketOpen(unsigned long ipaddr,int port,int owner_pid);
int JtUserSocketClose(int handle,int owner_pid);
int JtUserSocketRead(int handle,void *buffer,int maxlen,int owner_pid);
int JtUserSocketWrite(int handle,const void *buffer,int len,int owner_pid);
void JtUserSocketService(void);
int JtUserSocketAppCall(void);
void JtUserSocketNetworkReset(void);

#endif
