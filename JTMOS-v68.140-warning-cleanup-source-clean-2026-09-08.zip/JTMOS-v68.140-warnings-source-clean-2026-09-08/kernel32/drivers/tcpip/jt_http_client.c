/*
 * jt_http_client.c - single-stream active-open TCP client for JTMOS uIP.
 *
 * The current JNET POSIX-shaped socket facade is intentionally UDP-only.
 * HTTP therefore uses uIP's maintained active TCP-open path directly while
 * preserving UipProcess as the sole Ethernet RX/TCP owner.
 */
#include "kernel32.h"
#include "uip.h"
#include "networkControl.h"
#include "jt_http_client.h"

#define JT_HTTP_CLIENT_REQUEST_MAX 1536
#define JT_HTTP_CLIENT_RX_SIZE     32768
/* Keep several MSS-sized slots in reserve.  When the queue reaches the high
 * watermark uIP advertises a zero receive window; it is reopened only after
 * the consumer has drained the queue below the low watermark. */
#define JT_HTTP_CLIENT_RX_RESERVE  (UIP_TCP_MSS * 4U)
#define JT_HTTP_CLIENT_RX_HIGH     (JT_HTTP_CLIENT_RX_SIZE - JT_HTTP_CLIENT_RX_RESERVE)
#define JT_HTTP_CLIENT_RX_LOW      (JT_HTTP_CLIENT_RX_SIZE / 2U)
#define JT_HTTP_CLIENT_IDLE_MS     30000UL

static volatile int client_pending;
static volatile int client_active;
static volatile int client_done;
static volatile int client_result;
static volatile int client_cancel;
static volatile int client_cancel_result;
static unsigned char client_ip[4];
static int client_port;
static char client_request[JT_HTTP_CLIENT_REQUEST_MAX];
static unsigned int client_request_len;

static struct uip_conn *client_conn;
static unsigned int client_tx_off;
static unsigned int client_tx_last;
static unsigned long client_last_activity;

static unsigned char client_rx[JT_HTTP_CLIENT_RX_SIZE];
static unsigned int client_rx_head;
static unsigned int client_rx_tail;
static unsigned int client_rx_count;
static volatile int client_resume_pending;
static JT_HTTP_CLIENT_STATS client_stats;

static void client_finish(int result)
{
    int f=get_eflags();
    disable();
    client_result=result;
    client_done=1;
    client_active=0;
    client_pending=0;
    client_cancel=0;
    client_cancel_result=0;
    client_resume_pending=0;
    client_conn=NULL;
    set_eflags(f);
}

static void client_queue_reset(void)
{
    client_rx_head=0;
    client_rx_tail=0;
    client_rx_count=0;
}

void JtHttpClientGetStats(JT_HTTP_CLIENT_STATS *out)
{
    int f;
    if(!out) return;
    f=get_eflags();
    disable();
    memcpy(out,&client_stats,sizeof(*out));
    set_eflags(f);
}

void JtHttpClientResetStats(void)
{
    int f=get_eflags();
    disable();
    memset(&client_stats,0,sizeof(client_stats));
    client_stats.rx_peak_buffered=client_rx_count;
    set_eflags(f);
}

void JtHttpClientNetworkReset(void)
{
    int f=get_eflags();
    disable();
    client_pending=0;
    client_active=0;
    client_done=1;
    client_result=JT_HTTP_CLIENT_ENETDOWN;
    client_cancel=0;
    client_cancel_result=0;
    client_resume_pending=0;
    client_conn=NULL;
    client_tx_off=0;
    client_tx_last=0;
    client_request_len=0;
    client_queue_reset();
    set_eflags(f);
}

int JtHttpClientStart(const unsigned char ip[4],int port,const char *request)
{
    unsigned int n;
    int f;

    if(!ip || !request || port<=0 || port>65535)
        return JT_HTTP_CLIENT_EINVAL;
    n=(unsigned int)strlen(request);
    if(n==0 || n>=sizeof(client_request))
        return JT_HTTP_CLIENT_EINVAL;
    if(JtInternetState()!=JTMOS_INET_ONLINE)
        return JT_HTTP_CLIENT_ENETDOWN;

    f=get_eflags();
    disable();
    if(client_pending || client_active)
    {
        set_eflags(f);
        return JT_HTTP_CLIENT_EBUSY;
    }
    memcpy(client_ip,ip,4);
    client_port=port;
    memcpy(client_request,request,n+1);
    client_request_len=n;
    client_tx_off=0;
    client_tx_last=0;
    client_conn=NULL;
    client_queue_reset();
    client_result=0;
    client_done=0;
    client_cancel=0;
    client_cancel_result=0;
    client_resume_pending=0;
    client_pending=1;
    client_last_activity=GetTickCount();
    set_eflags(f);
    return 0;
}

int JtHttpClientRead(void *buffer,int maxlen)
{
    unsigned char *out=(unsigned char *)buffer;
    int f,n,i;
    if(!buffer || maxlen<=0) return JT_HTTP_CLIENT_EINVAL;

    f=get_eflags();
    disable();
    n=(int)client_rx_count;
    if(n>maxlen) n=maxlen;
    for(i=0;i<n;i++)
    {
        out[i]=client_rx[client_rx_tail];
        client_rx_tail++;
        if(client_rx_tail>=JT_HTTP_CLIENT_RX_SIZE) client_rx_tail=0;
    }
    client_rx_count-=(unsigned int)n;
    client_stats.rx_consumed_bytes+=(DWORD)n;
    if(client_active && client_rx_count<=JT_HTTP_CLIENT_RX_LOW)
        client_resume_pending=1;
    set_eflags(f);
    return n;
}

int JtHttpClientDone(void) { return client_done; }
int JtHttpClientResult(void) { return client_result; }

void JtHttpClientCancel(void)
{
    int f=get_eflags();
    disable();
    if(client_pending && !client_active)
    {
        client_pending=0;
        client_result=JT_HTTP_CLIENT_EINTR;
        client_done=1;
    }
    else if(client_active)
    {
        client_cancel=1;
        client_cancel_result=JT_HTTP_CLIENT_EINTR;
    }
    set_eflags(f);
}

static int client_rx_push(const unsigned char *data,unsigned int len)
{
    unsigned int i;
    int stop_now=0;
    int f=get_eflags();
    disable();
    if(len > JT_HTTP_CLIENT_RX_SIZE-client_rx_count)
    {
        client_stats.overflow_errors++;
        set_eflags(f);
        return -1;
    }
    for(i=0;i<len;i++)
    {
        client_rx[client_rx_head]=data[i];
        client_rx_head++;
        if(client_rx_head>=JT_HTTP_CLIENT_RX_SIZE) client_rx_head=0;
    }
    client_rx_count+=len;
    client_stats.rx_queued_bytes+=(DWORD)len;
    if(client_rx_count>client_stats.rx_peak_buffered)
        client_stats.rx_peak_buffered=client_rx_count;
    if(client_rx_count>=JT_HTTP_CLIENT_RX_HIGH)
        stop_now=1;
    set_eflags(f);
    return stop_now;
}

static void client_send_segment(int retransmit)
{
    unsigned int left,n;
    if(!client_conn || client_tx_off>=client_request_len) return;

    if(retransmit && client_tx_last)
    {
        uip_send((unsigned char *)client_request+client_tx_off,(int)client_tx_last);
        return;
    }

    left=client_request_len-client_tx_off;
    n=left;
    if(n>(unsigned int)uip_mss()) n=(unsigned int)uip_mss();
    if(n==0) return;
    client_tx_last=n;
    uip_send((unsigned char *)client_request+client_tx_off,(int)n);
}

void JtHttpClientService(void)
{
    u16_t addr[2];
    int f,do_start=0;
    unsigned long now=GetTickCount();

    f=get_eflags();
    disable();
    if(client_pending && !client_active)
    {
        client_pending=0;
        client_active=1;
        client_last_activity=now;
        do_start=1;
    }
    else if(client_active && !client_cancel &&
            (unsigned long)(now-client_last_activity)>=JT_HTTP_CLIENT_IDLE_MS)
    {
        client_cancel=1;
        client_cancel_result=JT_HTTP_CLIENT_ETIMEDOUT;
    }
    if(client_active && JtInternetStopRequested() && !client_cancel)
    {
        client_cancel=1;
        client_cancel_result=JT_HTTP_CLIENT_ENETDOWN;
    }
    set_eflags(f);

    if(!do_start) return;

    uip_ipaddr(addr,client_ip[0],client_ip[1],client_ip[2],client_ip[3]);
    client_conn=uip_connect(addr,(u16_t)client_port);
    if(client_conn==NULL)
    {
        client_finish(JT_HTTP_CLIENT_ECONN);
        return;
    }
}

void JtHttpClientAppCall(void)
{
    int cancel_result;
    unsigned int incoming_len=0;

    if(!client_active || client_conn==NULL || uip_conn!=client_conn)
        return;

    /* The reader runs in the shell thread.  It only requests a resume; the
     * uIP owner performs uip_restart() here so global uIP state never crosses
     * thread ownership.  uip_restart() deliberately causes a pure ACK/window
     * update on this callback. */
    if(client_resume_pending)
    {
        int f=get_eflags();
        disable();
        client_resume_pending=0;
        set_eflags(f);
        if(uip_stopped())
        {
            uip_restart();
            client_stats.flow_restarts++;
        }
    }

    /* Poll callbacks are local scheduler activity, not peer progress.  Only
     * real TCP progress refreshes the 30-second idle timeout. */
    if(uip_connected() || uip_newdata() || uip_acked())
        client_last_activity=GetTickCount();

    /* uip_send() reuses uip_len for outgoing data.  Always consume incoming
     * payload first, including payload piggy-backed with the peer's FIN. */
    if(uip_newdata() && uip_datalen()>0)
    {
        incoming_len=(unsigned int)uip_datalen();
        {
            int push_rv=client_rx_push((const unsigned char *)uip_appdata,incoming_len);
            if(push_rv<0)
            {
                client_finish(JT_HTTP_CLIENT_EOVERFLOW);
                uip_abort();
                return;
            }
            if(push_rv>0 && !uip_stopped())
            {
                uip_stop();
                client_stats.flow_stops++;
            }
        }
        /* In uIP, uip_len is both incoming payload length and outgoing length.
         * We consumed the response; do not accidentally echo it back or move
         * the local send sequence number by the received byte count. */
        uip_len=0;
    }

    if(client_cancel)
    {
        cancel_result=client_cancel_result?client_cancel_result:JT_HTTP_CLIENT_EINTR;
        client_finish(cancel_result);
        uip_abort();
        return;
    }

    if(uip_aborted())
    {
        client_finish(JT_HTTP_CLIENT_ECONN);
        return;
    }
    if(uip_timedout())
    {
        client_finish(JT_HTTP_CLIENT_ETIMEDOUT);
        return;
    }
    if(uip_closed())
    {
        client_finish(0);
        return;
    }

    if(uip_connected())
    {
        client_tx_off=0;
        client_tx_last=0;
        client_send_segment(0);
    }
    else if(uip_rexmit() && client_tx_last)
    {
        client_send_segment(1);
    }
    else if(uip_acked() && client_tx_last)
    {
        client_tx_off+=client_tx_last;
        client_tx_last=0;
        if(client_tx_off<client_request_len)
            client_send_segment(0);
    }
    else if(uip_poll() && client_tx_off<client_request_len && client_tx_last==0)
    {
        client_send_segment(0);
    }
}
