/*
 * jt_telnetd.c - deliberately small authenticated Telnet/SQSH bridge.
 *
 * This is a development console, not an SSH replacement.  Telnet carries the
 * password and session in clear text, so public deployments should firewall
 * the port or tunnel it.  There is deliberately no built-in password: the
 * listener refuses to start until TELNETD_PASSWORD is set globally.
 */
#include "kernel32.h"
#include "uip.h"
#include "jt_telnetd.h"
#include "centralprocess.h"
#include "term.h"
#include "threads.h"

#define JT_TELNET_DEFAULT_PORT 2323
#define JT_TELNET_MAGIC 0x54454c4eUL /* "TELN" */
#define JT_TELNET_PASSWORD_MAX 63
#define JT_TELNET_CAPTURE_BYTES 32768
#define JT_TELNET_MAX_FAILURES 3
#define JT_TELNET_MAX_SESSIONS 2

#define JT_TELNET_PHASE_AUTH 0
#define JT_TELNET_PHASE_SHELL 1
#define JT_TELNET_PHASE_CLOSE 2

#define TEL_IAC 255
#define TEL_WILL 251
#define TEL_WONT 252
#define TEL_DO 253
#define TEL_DONT 254
#define TEL_ECHO 1
#define TEL_SGA 3

typedef struct JT_TELNET_STATE {
    DWORD magic;
    BYTE phase;
    BYTE auth_len;
    BYTE failures;
    BYTE last_cr;
    BYTE iac_state;
    BYTE negotiation_outstanding;
    WORD last_src_len;
    int terminal;
    int shell_pid;
    int out_len;
    char *outbuf;
    char auth[JT_TELNET_PASSWORD_MAX+1];
} JT_TELNET_STATE;
typedef char jt_telnet_appstate_fits[(sizeof(JT_TELNET_STATE)<=UIP_APPSTATE_SIZE)?1:-1];

static volatile int telnet_requested=0;
static volatile int telnet_requested_port=JT_TELNET_DEFAULT_PORT;
static volatile int telnet_auto_enabled=0;
static volatile int telnet_auto_owned=0;
static volatile int telnet_dhcp_active=0;
static int telnet_listening_port=0;
static BYTE telnet_dhcp_ip[4];
static BYTE telnet_tx[UIP_TCP_MSS];

static int telnet_password(char *out,int cap)
{
    int n;
    if(!out || cap<2) return 0;
    out[0]=0;
    if(kgetglobalenv("TELNETD_PASSWORD",out,(unsigned int)cap)<0) return 0;
    n=(int)strlen(out);
    if(n<8 || n>JT_TELNET_PASSWORD_MAX) { out[0]=0; return 0; }
    return n;
}

int JtTelnetdPasswordReady(void)
{
    char p[JT_TELNET_PASSWORD_MAX+1];
    return telnet_password(p,sizeof(p))>0;
}

static int telnet_password_equal(const char *a,const char *b)
{
    unsigned int i,la,lb,n,diff;
    if(!a || !b) return 0;
    la=(unsigned int)strlen(a); lb=(unsigned int)strlen(b);
    n=la>lb?la:lb; diff=la^lb;
    for(i=0;i<n;i++) {
        unsigned int ca=i<la?(unsigned char)a[i]:0;
        unsigned int cb=i<lb?(unsigned char)b[i]:0;
        diff|=ca^cb;
    }
    return diff==0;
}

static int telnet_output_length(JT_TELNET_STATE *st)
{
    if(!st) return 0;
    if(st->terminal>=0 && st->terminal<N_MAX_SCREENS &&
       !screens[st->terminal].isFree && screens[st->terminal].cap.buf==st->outbuf)
        return screens[st->terminal].cap.offs;
    return st->out_len;
}

static void telnet_set_output_length(JT_TELNET_STATE *st,int len)
{
    if(!st) return;
    if(len<0) len=0;
    if(len>JT_TELNET_CAPTURE_BYTES-1) len=JT_TELNET_CAPTURE_BYTES-1;
    st->out_len=len;
    if(st->terminal>=0 && st->terminal<N_MAX_SCREENS &&
       !screens[st->terminal].isFree && screens[st->terminal].cap.buf==st->outbuf)
        screens[st->terminal].cap.offs=len;
    if(st->outbuf) st->outbuf[len]=0;
}

static void telnet_queue(JT_TELNET_STATE *st,const char *text)
{
    int old,n,room,flags;
    if(!st || !st->outbuf || !text) return;
    n=(int)strlen(text); if(n<=0) return;
    flags=get_eflags(); disable();
    old=telnet_output_length(st);
    room=JT_TELNET_CAPTURE_BYTES-1-old;
    if(n>room) n=room;
    if(n>0) {
        memcpy(st->outbuf+old,text,n);
        telnet_set_output_length(st,old+n);
    }
    set_eflags(flags);
}

static void telnet_consume_output(JT_TELNET_STATE *st,int bytes)
{
    int have,flags;
    if(!st || !st->outbuf || bytes<=0) return;
    flags=get_eflags(); disable();
    have=telnet_output_length(st);
    if(bytes>have) bytes=have;
    if(bytes<have) memmove(st->outbuf,st->outbuf+bytes,have-bytes);
    telnet_set_output_length(st,have-bytes);
    set_eflags(flags);
}

static void telnet_detach_shell(JT_TELNET_STATE *st)
{
    int ter,pid;
    if(!st) return;
    ter=st->terminal; pid=st->shell_pid;
    if(ter>=0 && ter<N_MAX_SCREENS && !screens[ter].isFree)
        SetTerCapture(ter,NULL,0);
    st->terminal=-1; st->shell_pid=0;
    if(pid>0 && GetThreadPriority((DWORD)pid)!=0) KillThread(pid);
    if(ter>=10 && ter<N_MAX_SCREENS && !screens[ter].isFree) FreeTerminal(ter);
}

static void telnet_cleanup(JT_TELNET_STATE *st)
{
    if(!st || st->magic!=JT_TELNET_MAGIC) return;
    telnet_detach_shell(st);
    if(st->outbuf) free(st->outbuf);
    memset(st,0,sizeof(*st));
}

static int telnet_launch_sqsh(JT_TELNET_STATE *st)
{
    int ter,pid;
    if(!st || !st->outbuf) return -1;
    ter=NewTerminal();
    if(ter<0) return -2;
    st->terminal=ter;
    SetTerCapture(ter,st->outbuf,JT_TELNET_CAPTURE_BYTES);
    screens[ter].cap.offs=st->out_len;
    pid=centralprocess_exec("sqsh.bin","sqsh.bin",GetCurrentDNR(),GetCurrentDB(),"/",ter);
    if(pid<=0) {
        SetTerCapture(ter,NULL,0); FreeTerminal(ter); st->terminal=-1;
        return -3;
    }
    st->shell_pid=pid;
    SetTerminalOwner(ter,pid);
    return 0;
}

static void telnet_auth_submit(JT_TELNET_STATE *st)
{
    char pass[JT_TELNET_PASSWORD_MAX+1];
    int ok,rv;
    if(!st) return;
    st->auth[st->auth_len]=0;
    ok=telnet_password(pass,sizeof(pass))>0 && telnet_password_equal(st->auth,pass);
    memset(pass,0,sizeof(pass));
    memset(st->auth,0,sizeof(st->auth)); st->auth_len=0;
    if(!ok) {
        st->failures++;
        if(st->failures>=JT_TELNET_MAX_FAILURES) {
            telnet_queue(st,"\r\nAccess denied.\r\n"); st->phase=JT_TELNET_PHASE_CLOSE;
        } else telnet_queue(st,"\r\nWrong password.\r\nPassword: ");
        return;
    }
    telnet_queue(st,"\r\nAuthenticated. Starting /bin/sqsh.bin ...\r\n");
    rv=telnet_launch_sqsh(st);
    if(rv<0) {
        telnet_queue(st,"telnetd: unable to launch sqsh.bin. Is /bin installed?\r\n");
        st->phase=JT_TELNET_PHASE_CLOSE;
        return;
    }
    st->phase=JT_TELNET_PHASE_SHELL;
}

static void telnet_input_byte(JT_TELNET_STATE *st,BYTE ch)
{
    if(!st) return;
    /* Minimal TELNET command stripping.  We advertise server echo/SGA once;
     * client DO/DONT/WILL/WONT replies are simply consumed. */
    if(st->iac_state==1) {
        if(ch==TEL_IAC) st->iac_state=0;
        else if(ch==TEL_WILL || ch==TEL_WONT || ch==TEL_DO || ch==TEL_DONT) st->iac_state=2;
        else st->iac_state=0;
        return;
    }
    if(st->iac_state==2) { st->iac_state=0; return; }
    if(ch==TEL_IAC) { st->iac_state=1; return; }

    if(st->last_cr && (ch=='\n' || ch==0)) { st->last_cr=0; return; }

    if(st->phase==JT_TELNET_PHASE_AUTH) {
        if(ch=='\r' || ch=='\n') { st->last_cr=(ch=='\r'); telnet_auth_submit(st); return; }
        if(ch==8 || ch==127) { if(st->auth_len) st->auth_len--; return; }
        if(ch>=32 && ch<127 && st->auth_len<JT_TELNET_PASSWORD_MAX)
            st->auth[st->auth_len++]=(char)ch;
        return;
    }

    if(st->phase==JT_TELNET_PHASE_SHELL && st->terminal>=0) {
        if(ch=='\r' || ch=='\n') { st->last_cr=(ch=='\r'); OutTermKey(st->terminal,'\n'); }
        else OutTermKey(st->terminal,(int)ch);
    }
}

/* Build one TELNET text segment.  JTMOS terminals normally emit LF only;
 * translate it to the network virtual-terminal CRLF form and quote IAC. */
static int telnet_build_segment(JT_TELNET_STATE *st,int maxsrc,int *srcused)
{
    int have,i,o=0,limit;
    BYTE ch;
    if(srcused) *srcused=0;
    if(!st || !st->outbuf) return 0;
    have=telnet_output_length(st); if(have<=0) return 0;
    limit=maxsrc>0 && maxsrc<have?maxsrc:have;
    for(i=0;i<limit;i++) {
        ch=(BYTE)st->outbuf[i];
        if(ch=='\n') {
            if(o+2>UIP_TCP_MSS) break;
            telnet_tx[o++]='\r'; telnet_tx[o++]='\n';
        } else if(ch==TEL_IAC) {
            if(o+2>UIP_TCP_MSS) break;
            telnet_tx[o++]=TEL_IAC; telnet_tx[o++]=TEL_IAC;
        } else {
            if(o+1>UIP_TCP_MSS) break;
            telnet_tx[o++]=ch;
        }
    }
    if(srcused) *srcused=i;
    return o;
}

static void telnet_send_next(JT_TELNET_STATE *st)
{
    int src=0,n;
    if(!st || st->last_src_len) return;
    n=telnet_build_segment(st,0,&src);
    if(n>0 && src>0) { st->last_src_len=(WORD)src; uip_send(telnet_tx,n); }
}

int JtTelnetdRequest(int port)
{
    int flags;
    if(port<=0 || port>65535) return -1;
    if(!JtTelnetdPasswordReady()) return -2;
    flags=get_eflags(); disable();
    telnet_requested_port=port; telnet_requested=1; telnet_auto_owned=0;
    set_eflags(flags); return 0;
}

void JtTelnetdDisable(void)
{
    int flags=get_eflags(); disable(); telnet_requested=0; telnet_auto_owned=0; set_eflags(flags);
}
int JtTelnetdRequested(void){return telnet_requested;}
int JtTelnetdIsListening(void){return telnet_listening_port!=0;}
int JtTelnetdPort(void){return telnet_requested_port;}
int JtTelnetdAutoEnabled(void){return telnet_auto_enabled;}

int JtTelnetdSetAuto(int enabled,int port)
{
    int flags;
    if(port<=0 || port>65535) return -1;
    if(enabled && !JtTelnetdPasswordReady()) return -2;
    flags=get_eflags(); disable();
    telnet_auto_enabled=enabled?1:0; telnet_requested_port=port;
    if(!telnet_auto_enabled && telnet_auto_owned) { telnet_requested=0; telnet_auto_owned=0; }
    if(telnet_auto_enabled && telnet_dhcp_active) { telnet_requested=1; telnet_auto_owned=1; }
    set_eflags(flags); return 0;
}

void JtTelnetdDhcpLease(int active,const unsigned char ip[4])
{
    int ready=JtTelnetdPasswordReady();
    int flags=get_eflags(); disable();
    telnet_dhcp_active=active?1:0;
    if(active && ip) memcpy(telnet_dhcp_ip,ip,sizeof(telnet_dhcp_ip)); else memset(telnet_dhcp_ip,0,sizeof(telnet_dhcp_ip));
    if(telnet_dhcp_active && telnet_auto_enabled && ready) {
        telnet_requested=1; telnet_auto_owned=1;
    } else if(telnet_auto_owned) { telnet_requested=0; telnet_auto_owned=0; }
    set_eflags(flags);
}

static int telnet_active_sessions(void)
{
    int i,n=0;
    for(i=0;i<UIP_CONNS;i++) {
        JT_TELNET_STATE *st=(JT_TELNET_STATE *)uip_conns[i].appstate;
        if(st->magic==JT_TELNET_MAGIC) n++;
    }
    return n;
}

static void telnet_cleanup_all(void)
{
    int i;
    for(i=0;i<UIP_CONNS;i++) {
        JT_TELNET_STATE *st=(JT_TELNET_STATE *)uip_conns[i].appstate;
        if(st->magic==JT_TELNET_MAGIC) telnet_cleanup(st);
    }
}

void JtTelnetdNetworkReset(void)
{
    telnet_cleanup_all(); telnet_listening_port=0; JtTelnetdDhcpLease(0,NULL);
}
void JtTelnetdNetworkStop(void)
{
    telnet_cleanup_all(); telnet_requested=0; telnet_auto_owned=0; telnet_dhcp_active=0;
    telnet_listening_port=0; memset(telnet_dhcp_ip,0,sizeof(telnet_dhcp_ip));
}

void JtTelnetdSync(void)
{
    if(telnet_listening_port && !JtTelnetdPasswordReady()) {
        uip_unlisten((u16_t)telnet_listening_port);
        printk("TELNETD: password removed/invalid; listener stopped.\n");
        telnet_listening_port=0; telnet_requested=0; telnet_auto_owned=0;
    }
    if(telnet_listening_port && (!telnet_requested || telnet_listening_port!=telnet_requested_port)) {
        uip_unlisten((u16_t)telnet_listening_port);
        printk("TELNETD: stopped TCP port %d.\n",telnet_listening_port);
        telnet_listening_port=0;
    }
    if(telnet_requested && !telnet_listening_port) {
        if(!JtTelnetdPasswordReady()) { telnet_requested=0; telnet_auto_owned=0; return; }
        if(uip_is_listening((u16_t)telnet_requested_port)) {
            printk("TELNETD: TCP port %d already belongs to another listener.\n",telnet_requested_port);
            telnet_requested=0; telnet_auto_owned=0; return;
        }
        uip_listen((u16_t)telnet_requested_port); telnet_listening_port=telnet_requested_port;
        if(telnet_dhcp_active)
            printk("TELNETD: SQSH development login listening on %d.%d.%d.%d:%d.\n",telnet_dhcp_ip[0],telnet_dhcp_ip[1],telnet_dhcp_ip[2],telnet_dhcp_ip[3],telnet_listening_port);
        else printk("TELNETD: SQSH development login listening on TCP port %d.\n",telnet_listening_port);
    }
}

void JtTelnetdAppCall(void)
{
    JT_TELNET_STATE *st;
    int i,n,src;
    static const BYTE negotiation[]={TEL_IAC,TEL_WILL,TEL_ECHO,TEL_IAC,TEL_WILL,TEL_SGA};
    if(!telnet_requested || !telnet_listening_port || !uip_conn) return;
    if(uip_conn->lport!=htons((u16_t)telnet_listening_port)) return;
    st=(JT_TELNET_STATE *)uip_conn->appstate;

    if(uip_connected()) {
        if(telnet_active_sessions()>=JT_TELNET_MAX_SESSIONS) {
            uip_abort();
            return;
        }
        memset(st,0,sizeof(*st)); st->magic=JT_TELNET_MAGIC; st->phase=JT_TELNET_PHASE_AUTH;
        st->terminal=-1; st->outbuf=(char *)malloc(JT_TELNET_CAPTURE_BYTES);
        if(!st->outbuf) { st->phase=JT_TELNET_PHASE_CLOSE; uip_abort(); return; }
        st->outbuf[0]=0; st->negotiation_outstanding=1;
        uip_send(negotiation,sizeof(negotiation)); return;
    }
    if(st->magic!=JT_TELNET_MAGIC) return;
    if(uip_aborted() || uip_timedout() || uip_closed()) { telnet_cleanup(st); return; }

    if(st->negotiation_outstanding) {
        if(uip_rexmit()) { uip_send(negotiation,sizeof(negotiation)); return; }
        if(uip_acked()) {
            st->negotiation_outstanding=0;
            telnet_queue(st,"JTMOS remote development console\r\nPassword: ");
        }
    } else if(uip_acked() && st->last_src_len) {
        telnet_consume_output(st,(int)st->last_src_len); st->last_src_len=0;
    }

    if(uip_newdata()) {
        n=(int)uip_datalen();
        for(i=0;i<n;i++) telnet_input_byte(st,((BYTE *)uip_appdata)[i]);
        uip_len=0;
    }

    if(st->phase==JT_TELNET_PHASE_SHELL && st->shell_pid>0 && GetThreadPriority((DWORD)st->shell_pid)==0) {
        st->shell_pid=0; telnet_queue(st,"\r\n[telnetd: sqsh exited]\r\n"); st->phase=JT_TELNET_PHASE_CLOSE;
    }

    if(st->negotiation_outstanding) return;
    if(uip_rexmit() && st->last_src_len) {
        n=telnet_build_segment(st,(int)st->last_src_len,&src);
        if(n>0) uip_send(telnet_tx,n);
        return;
    }
    if(!st->last_src_len && telnet_output_length(st)>0 && (uip_newdata() || uip_acked() || uip_poll())) {
        telnet_send_next(st); return;
    }
    if(st->phase==JT_TELNET_PHASE_CLOSE && !st->last_src_len && telnet_output_length(st)==0) {
        telnet_detach_shell(st); uip_close();
    }
}
