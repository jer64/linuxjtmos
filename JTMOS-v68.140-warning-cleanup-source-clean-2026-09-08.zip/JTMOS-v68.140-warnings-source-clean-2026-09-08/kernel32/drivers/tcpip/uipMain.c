/*
 * JTMOS uIP owner process for native Ethernet and RFC1055 SLIP.
 * Restored from the 2006 architecture and adapted to the 2026 network paths.
 */
#include "kernel32.h"
#include "slip.h"
#include "slipLogin.h"
#include "slipStack.h"
#include "uip.h"
#include "uipMain.h"
#include "networkControl.h"
#include "jt_httpd.h"
#include "jt_telnetd.h"
#include "jt_http_client.h"
#include "jt_usersock.h"
#include "uip_arp.h"
#include "ethdev.h"
#include "jnet.h"

#define UIP_PERIODIC_MS 500
#define UIP_RX_BUDGET 8
#define UIP_MAX_TIMER_CATCHUP 4

/*
 * The network owner is polling based (MCP61 deliberately runs with NIC IRQs
 * masked, and the NE2000 backend also exposes a receive poll API).  A plain
 * SwitchToThread() at the bottom of this loop can therefore immediately pick
 * the uIP task again and consume an entire host CPU while the network is idle.
 *
 * Use scheduler deadline sleeps to make idle polling cheap.  Scheduler sleep
 * selects CPU_IDLE when no real work is runnable; CPU_IDLE executes sti; hlt,
 * so the physical/virtual CPU stops until the next interrupt instead of busy
 * spinning.  Keep the first idle sleeps short for interactive HTTP latency,
 * then back off to 5 ms after sustained inactivity.
 */
#define UIP_IDLE_SLEEP_FAST_US   1000UL
#define UIP_IDLE_SLEEP_MEDIUM_US 2000UL
#define UIP_IDLE_SLEEP_MAX_US    5000UL
#define UIP_IDLE_MEDIUM_AFTER    4UL
#define UIP_IDLE_MAX_AFTER       32UL

static JT_UIP_DRIVER_STATS uip_driver_stats;

static void uip_idle_sleep(DWORD idle_rounds)
{
    DWORD usec;

    if(idle_rounds>=UIP_IDLE_MAX_AFTER)
        usec=UIP_IDLE_SLEEP_MAX_US;
    else if(idle_rounds>=UIP_IDLE_MEDIUM_AFTER)
        usec=UIP_IDLE_SLEEP_MEDIUM_US;
    else
        usec=UIP_IDLE_SLEEP_FAST_US;

    uip_driver_stats.idle_sleep_calls++;
    uip_driver_stats.idle_sleep_ms+=usec/1000UL;
    if(usec==UIP_IDLE_SLEEP_FAST_US) uip_driver_stats.idle_sleep_fast++;
    else if(usec==UIP_IDLE_SLEEP_MEDIUM_US) uip_driver_stats.idle_sleep_medium++;
    else uip_driver_stats.idle_sleep_max++;

    /* In normal multitasking UsecSleep() blocks this task in the scheduler.
     * If the scheduler sleep is unavailable for an unusual early-boot state,
     * retain the old cooperative behaviour instead of hard failing. */
    if(UsecSleep(usec)!=0)
        SwitchToThread();
}

/* Ethernet may pad a short frame to the 60-byte wire minimum.  uIP expects
 * uip_len to be the IPv4 total length, not the padded Ethernet payload length;
 * without this trim a minimum-size TCP SYN/ACK is rejected and port 8080 cannot
 * accept connections on ordinary Ethernet. */
static int uip_ethernet_ipv4_length(const unsigned char *frame,int frame_len)
{
    const unsigned char *ip;
    int total;

    if(!frame || frame_len<14+20 || frame[12]!=0x08 || frame[13]!=0x00)
        return -1;
    ip=frame+UIP_LLH_LEN;
    if(ip[0]!=0x45)
        return -1;
    total=((int)ip[2]<<8)|ip[3];
    if(total<20 || total>frame_len-UIP_LLH_LEN || total>UIP_BUFSIZE-UIP_LLH_LEN)
        return -1;
    return total;
}

/* ARP learning must never happen before the IPv4 envelope has been proved to
 * belong to this host.  The old receive path updated the ARP cache before uIP
 * checked destination, fragmentation and the IP checksum, so a malformed or
 * off-target frame could still alter next-hop state. */
static int uip_ethernet_ipv4_safe_to_learn(const unsigned char *frame,int iplen)
{
    const unsigned char *ip,*localmac;
    int n,nonzero=0;
    u16_t d0,d1;
    if(!frame || iplen<20) return 0;
    localmac=ethdev_mac();
    if(localmac) for(n=0;n<6;++n) if(frame[n]!=localmac[n]) return 0;
    if(frame[6]&1) return 0;
    for(n=0;n<6;++n) if(frame[6+n]!=0) nonzero=1;
    if(!nonzero) return 0;
    ip=frame+UIP_LLH_LEN;
    if(ip[0]!=0x45) return 0;
    if((ip[6]&0x3f)!=0 || ip[7]!=0) return 0;
    d0=htons((u16_t)(((u16_t)ip[16]<<8)|ip[17]));
    d1=htons((u16_t)(((u16_t)ip[18]<<8)|ip[19]));
    if(d0!=uip_hostaddr[0] || d1!=uip_hostaddr[1]) return 0;
    if(uip_ipchksum()!=0xffff) return 0;
    /* Never create an ARP entry from an unspecified or multicast IPv4 source. */
    if((ip[12]|ip[13]|ip[14]|ip[15])==0 || ip[12]>=224) return 0;
    return 1;
}

void JtUipGetDriverStats(JT_UIP_DRIVER_STATS *out)
{
    int flags;
    if(!out) return;
    flags=get_eflags();disable();
    memcpy(out, &uip_driver_stats, sizeof(*out));
    set_eflags(flags);
}

void JtUipResetDriverStats(void)
{
    int flags=get_eflags();
    disable();
    memset(&uip_driver_stats, 0, sizeof(uip_driver_stats));
    uip_driver_stats.reset_tick=GetTickCount();
    uip_reset_stats();
    set_eflags(flags);
}

static void uip_rx_accept(DWORD *kind)
{
    uip_driver_stats.rx_frames_accepted++;
    if(kind) (*kind)++;
}

static void uip_rx_reject(DWORD *reason)
{
    uip_driver_stats.rx_frames_rejected++;
    if(reason) (*reason)++;
}

/* uip_send() intentionally permits an application-owned payload buffer by
 * setting uip_appdata to that buffer.  uip_tcpchksum() also checksums that
 * external buffer.  Our Ethernet and SLIP drivers, however, transmit one
 * contiguous uip_buf frame.  The old wrapper never copied external payload
 * bytes into uip_buf, so SYN/SYN-ACK and ICMP worked while HTTP GET/replies
 * left the machine with a checksum for one payload and different bytes on the
 * wire.  Linearize the application payload after uip_process() has calculated
 * checksums but before ARP/L2 transmission. */
static int uip_linearize_output_payload(void)
{
    unsigned int iplen=(unsigned int)uip_len;
    unsigned int tcphlen,bytes;
    unsigned char *ip=uip_buf+UIP_LLH_LEN;
    unsigned char *dst;

    /* Only TCP application payload can live outside uip_buf.  ICMP payload and
     * TCP SYN options are already inline and must never be mistaken for app
     * data merely because the IPv4 packet is longer than 40 bytes. */
    if(iplen<20U || ip[9]!=6) return 0;
    if(iplen>(unsigned int)(UIP_BUFSIZE-UIP_LLH_LEN))
        goto invalid;
    tcphlen=(unsigned int)((uip_buf[UIP_LLH_LEN+20+12]>>4)&15U)*4U;
    if(tcphlen<20U || 20U+tcphlen>iplen)
        goto invalid;
    bytes=iplen-20U-tcphlen;
    if(bytes==0U) return 0;
    dst=uip_buf+UIP_LLH_LEN+20U+tcphlen;
    if(bytes>(unsigned int)(UIP_BUFSIZE-(dst-uip_buf)))
        goto invalid;

    if((const unsigned char *)uip_appdata!=dst)
    {
        if(uip_appdata==NULL) goto invalid;
        memmove(dst,(const void *)uip_appdata,bytes);
        uip_appdata=dst;
        uip_driver_stats.tx_appdata_linearized++;
        uip_driver_stats.tx_appdata_bytes+=bytes;
    }
    return 0;

invalid:
    uip_driver_stats.tx_appdata_invalid++;
    uip_driver_stats.tx_dropped++;
    return -1;
}

static void uip_send_pending(void)
{
    SLPACKET packet;

    if(uip_len>0)
    {
        if(uip_linearize_output_payload()<0)
        {
            uip_len=0;
            return;
        }
        if(ethdev_present())
        {
            uip_arp_out();
            if(ethdev_send(uip_buf,uip_len)>=0){uip_driver_stats.tx_packets++;uip_driver_stats.tx_bytes+=uip_len;}else uip_driver_stats.tx_dropped++;
            uip_len=0;
            return;
        }
        packet.buf = uip_buf + UIP_LLH_LEN;
        packet.len = uip_len;
        packet.l_buf = uip_len;
        if(slipStack_SendPacket(&packet)==0)
        {
            uip_driver_stats.tx_packets++;
            uip_driver_stats.tx_bytes += uip_len;
        }
        else
            uip_driver_stats.tx_dropped++;
        uip_len = 0;
    }
}

/* Bounded JNet control operations (DHCP, ARP, ping and DNS) execute in this
 * same owner thread.  They may receive an unrelated TCP/ARP frame while they
 * wait for their reply.  Feed that frame through uIP here instead of silently
 * dropping HTTP traffic for the duration of every control transaction. */
int JtUipServiceEthernetFrame(const unsigned char *frame,int len)
{
    int type,txlen,iplen;

    if(!ethdev_present() || !frame || len<=0)
        return 0;
    uip_driver_stats.rx_frames_seen++;
    if(len<14)
    {
        uip_driver_stats.rx_invalid++;
        uip_rx_reject(&uip_driver_stats.rx_reject_short);
        return 1;
    }
    if(len>UIP_BUFSIZE)
    {
        uip_driver_stats.rx_oversize++;
        uip_rx_reject(&uip_driver_stats.rx_reject_oversize);
        return 1;
    }
    if(frame!=uip_buf)
        memcpy(uip_buf,frame,len);

    type=((int)uip_buf[12]<<8)|uip_buf[13];
    if(type==0x0806)
    {
        uip_rx_accept(&uip_driver_stats.rx_arp_accepted);
        uip_len=len;
        uip_arp_arpin();
        txlen=(int)uip_len;
        if(txlen>0)
        {
            if(ethdev_send(uip_buf,txlen)>=0)
            {
                uip_driver_stats.tx_packets++;
                uip_driver_stats.tx_bytes+=(DWORD)txlen;
            }
            else uip_driver_stats.tx_dropped++;
        }
        uip_len=0;
        return 1;
    }
    if(type!=0x0800)
    {
        uip_rx_reject(&uip_driver_stats.rx_reject_ethertype);
        return 1;
    }

    iplen=uip_ethernet_ipv4_length(uip_buf,len);
    if(iplen<0)
    {
        uip_driver_stats.rx_invalid++;
        uip_rx_reject(&uip_driver_stats.rx_reject_ipv4);
        uip_len=0;
        return 1;
    }
    uip_rx_accept(&uip_driver_stats.rx_ipv4_accepted);
    if(uip_ethernet_ipv4_safe_to_learn(uip_buf,iplen))
        uip_arp_ipin();
    uip_len=(u16_t)iplen;
    uip_driver_stats.rx_packets++;
    uip_driver_stats.rx_bytes+=(DWORD)uip_len;
    uip_process(UIP_DATA);
    uip_send_pending();
    return 1;
}

static void uip_sync_ipv4_services(void)
{
    const JNET_CONFIG *nc=jnet_config();
    int network_active=0;

    /* Passive TCP services need a usable local IPv4 address, not specifically
     * a DHCP lease.  QEMU user networking deliberately has a deterministic
     * static fallback (10.0.2.15/24) when DHCP fails; outbound clients such as
     * nutget work in that mode, so keeping HTTP/telnet stopped made the network
     * look half-working.  Start automatic listeners for every configured IPv4
     * method while the Ethernet link is up. */
    if(ethdev_present() && nc && nc->configured && ethdev_link_up())
        network_active=1;

    JtHttpdDhcpLease(network_active,network_active?nc->ip:NULL);
    JtTelnetdDhcpLease(network_active,network_active?nc->ip:NULL);
}

static int uip_receive_one(void)
{
    SLPACKET *packet;
    int len;

    if(ethdev_present())
    {
        len=ethdev_receive(uip_buf,UIP_BUFSIZE);
        if(len<0){uip_driver_stats.rx_invalid++;return -1;}
        if(len==0)return 0;
        uip_driver_stats.rx_frames_seen++;
        if(len<14)
        {
            uip_driver_stats.rx_invalid++;
            uip_rx_reject(&uip_driver_stats.rx_reject_short);
            return -1;
        }
        /* JNET owns its UDP socket demultiplexing, but never reads the NIC
         * directly.  Give it first refusal before the TCP-only uIP core. */
        if(jnet_input_ethernet(uip_buf,len))
        {
            uip_rx_accept(&uip_driver_stats.rx_jnet_accepted);
            uip_driver_stats.rx_packets++;
            uip_driver_stats.rx_bytes+=len-UIP_LLH_LEN;
            return -1;
        }
        if(uip_buf[12]==0x08&&uip_buf[13]==0x06)
        {
            uip_rx_accept(&uip_driver_stats.rx_arp_accepted);
            uip_len=len;uip_arp_arpin();if(uip_len)ethdev_send(uip_buf,uip_len);uip_len=0;return -1;
        }
        if(uip_buf[12]!=0x08||uip_buf[13]!=0x00)
        {
            uip_rx_reject(&uip_driver_stats.rx_reject_ethertype);
            return -1;
        }
        len=uip_ethernet_ipv4_length(uip_buf,len);
        if(len<0)
        {
            uip_driver_stats.rx_invalid++;
            uip_rx_reject(&uip_driver_stats.rx_reject_ipv4);
            return -1;
        }
        uip_rx_accept(&uip_driver_stats.rx_ipv4_accepted);
        if(uip_ethernet_ipv4_safe_to_learn(uip_buf,len))
            uip_arp_ipin();
        uip_driver_stats.rx_packets++;uip_driver_stats.rx_bytes+=len;
        return len;
    }
    packet = slipStack_ReceivePacket();
    if(packet==NULL)
        return 0;

    len = packet->len;
    uip_driver_stats.rx_frames_seen++;
    if(len > UIP_BUFSIZE)
    {
        uip_driver_stats.rx_oversize++;
        uip_rx_reject(&uip_driver_stats.rx_reject_oversize);
        packet->isfree = TRUE;
        return -1;
    }
    /* RFC1055 carries IPv4 directly. Validate framing before uIP reads it. */
    if(len < 20 || (packet->buf[0] >> 4) != 4 ||
       (packet->buf[0] & 15) < 5 || ((packet->buf[0] & 15) * 4) > len ||
       (((int)packet->buf[2] << 8) | packet->buf[3]) < 20 ||
       (((int)packet->buf[2] << 8) | packet->buf[3]) > len)
    {
        uip_driver_stats.rx_invalid++;
        uip_rx_reject(&uip_driver_stats.rx_reject_ipv4);
        packet->isfree = TRUE;
        return -1;
    }
    uip_rx_accept(&uip_driver_stats.rx_ipv4_accepted);
    len = ((int)packet->buf[2] << 8) | packet->buf[3];
    memcpy(uip_buf + UIP_LLH_LEN, packet->buf, len);
    packet->isfree = TRUE;
    uip_driver_stats.rx_packets++;
    uip_driver_stats.rx_bytes += len;
    return len;
}

int UipProcess(void)
{
    DWORD last_periodic,last_jnet_maintenance,last_arp_timer;
    DWORD idle_rounds=0;
    int i, len, budget, catchups;
    int did_work;

    IdentifyThread(GetCurrentThread(), "uip");
    while(!ethdev_present() && (!slipOnline || !slipStackReady) && !JtInternetStopRequested())
        uip_idle_sleep(UIP_IDLE_MAX_AFTER);

    if(JtInternetStopRequested())
    {
        JtInternetThreadExited(1);
        ExitThread(0);
    }

    if(ethdev_present())
        printk("uIP: JTMOS stack starting over %s Ethernet.\n",ethdev_name());
    else
        printk("uIP: JTMOS stack starting over COM%d RFC1055 SLIP (IP 10.0.0.5).\n",
            slip.port+1);
    uip_init();
    jnet_owner_attach();
    if(ethdev_present())
    {
        uip_arp_setethaddr(ethdev_mac());uip_arp_init();
        {
            int dhcp_rv=jnet_dhcp();
            if(dhcp_rv<0)
            {
                printk("DHCP: failed (%d).\n",dhcp_rv);
                /* QEMU user networking has a deterministic documented static
                 * fallback.  Real MCP61 hardware does not: inventing
                 * 192.168.50.2/24 with no router made failed DHCP look like a
                 * configured network and `ping` loop forever with "no default
                 * gateway".  On physical Ethernet leave DHCP failed visibly. */
                if(!jnet_config()->configured &&
                   jnet_configure_qemu_user_fallback()<0)
                    printk("IPv4: Ethernet present but DHCP failed; no address/default route configured.\n");
            }
        }
    }
    JtUipResetDriverStats();
    JtHttpdNetworkReset();
    JtTelnetdNetworkReset();
    JtHttpClientNetworkReset();
    JtUserSocketNetworkReset();
    uip_sync_ipv4_services();
    JtHttpdSync();
    JtTelnetdSync();
    last_periodic = GetTickCount();
    last_jnet_maintenance = last_periodic;
    last_arp_timer = last_periodic;

    while(!JtInternetStopRequested())
    {
        did_work=0;
        if((DWORD)(GetTickCount()-last_jnet_maintenance)>=250UL)
        {
            last_jnet_maintenance=GetTickCount();
            jnet_maintenance();
            did_work=1;
        }
        /* uIP's ARP age counter is defined in ten-second units.  This timer
         * existed in the stack but was never driven by the JTMOS owner loop,
         * leaving stale MAC mappings resident forever. */
        if(ethdev_present() && (DWORD)(GetTickCount()-last_arp_timer)>=10000UL)
        {
            last_arp_timer=GetTickCount();
            uip_arp_timer();
            did_work=1;
        }
        /* Listener policy follows the post-maintenance IPv4 state.  DHCP, QEMU
         * user fallback and explicit static configuration can all host passive
         * TCP services; link loss or address removal stops auto-owned listeners. */
        uip_sync_ipv4_services();
        JtHttpdSync();
        JtTelnetdSync();
        jnet_service_requests();
        JtHttpClientService();
        JtUserSocketService();

        for(budget=0; budget<UIP_RX_BUDGET; budget++)
        {
            len = uip_receive_one();
            if(len==0) break;
            did_work=1;
            if(len>0)
            {
                uip_len = len;
                uip_process(UIP_DATA);
                uip_send_pending();
            }
        }

        catchups = 0;
        while((DWORD)(GetTickCount()-last_periodic) >= UIP_PERIODIC_MS &&
              catchups < UIP_MAX_TIMER_CATCHUP)
        {
            last_periodic += UIP_PERIODIC_MS;
            for(i=0; i<UIP_CONNS; i++)
            {
                uip_periodic(i);
                uip_send_pending();
            }
            catchups++;
        }
        if(catchups>0) did_work=1;
        if(catchups>1) uip_driver_stats.timer_catchups += catchups-1;
        if((DWORD)(GetTickCount()-last_periodic) >= UIP_PERIODIC_MS)
        {
            last_periodic = GetTickCount();
            uip_driver_stats.timer_catchups++;
        }

        if(did_work)
        {
            idle_rounds=0;
            /* Let another runnable task use the CPU after actual network work. */
            SwitchToThread();
        }
        else
        {
            if(idle_rounds<0xffffffffUL) idle_rounds++;
            uip_idle_sleep(idle_rounds);
        }
    }

    JtHttpClientNetworkReset();
    JtUserSocketNetworkReset();
    JtHttpdNetworkReset();
    jnet_owner_detach();
    JtInternetThreadExited(1);
    ExitThread(0);
    return 0;
}
