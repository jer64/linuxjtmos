#ifndef JTMOS_JT_HTTPD_H
#define JTMOS_JT_HTTPD_H

int JtHttpdEnable(int port);
int JtHttpdDisable(void);
int JtHttpdRequested(void);
int JtHttpdPort(void);
int JtHttpdIsListening(void);
int JtHttpdAutoEnabled(void);
int JtHttpdSetAuto(int enabled);
void JtHttpdDhcpLease(int active,const unsigned char ip[4]);
void JtHttpdNetworkReset(void);
void JtHttpdNetworkStop(void);
void JtHttpdSync(void);
void JtHttpdAppCall(void);

#endif
