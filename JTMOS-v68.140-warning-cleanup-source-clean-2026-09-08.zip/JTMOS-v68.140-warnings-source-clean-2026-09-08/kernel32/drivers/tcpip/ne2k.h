#ifndef JTMOS_NE2K_H
#define JTMOS_NE2K_H
#define NE2K_DEFAULT_IO 0x300
#define NE2K_DEFAULT_IRQ 9
int ne2k_init(unsigned short io, int irq);
int ne2k_present(void);
int ne2k_receive(void *buf, int maxlen);
int ne2k_send(const void *buf, int len);
const unsigned char *ne2k_mac(void);
#endif
