/*
 * jt_httpd.c - small static HTTP/1.0 service for uIP over Ethernet/SLIP.
 *
 * JTMOS V68.8.57.10.18.16.94 serves site assets from the system-global
 * WWW_ROOT environment variable first (default cdrom:/), with the embedded
 * release site as a boot-safe fallback.  The V16.63 multi-segment transport
 * remains: assets from root www/ are also embedded at release time by
 * tools/gen_jt_httpd_site.py.  V16.94 also canonicalizes Facebook/social URLs by discarding query tracking data while it arrives and safely maps arbitrary static paths under WWW_ROOT.  Every uip_send() is
 * capped to the negotiated MSS and a segment is advanced only after ACK, so
 * pages larger than UIP_TCP_MSS are safe and retransmittable.
 */
#include "kernel32.h"
#include "uip.h"
#include "jt_httpd.h"

#define JT_HTTP_DEFAULT_PORT 8080
#define JT_HTTP_STAGE_HEADER 0
#define JT_HTTP_STAGE_BODY   1
#define JT_HTTP_STAGE_DONE   2
#define JT_HTTP_SOURCE_EMBED 0
#define JT_HTTP_SOURCE_FILE  1
#define JT_HTTP_REQUEST_LINE_MAX 160

#define JT_RES_INDEX      0
#define JT_RES_INDEX_EN   1
#define JT_RES_INVEST     2
#define JT_RES_INVEST_EN  3
#define JT_RES_CSS        4
#define JT_RES_JS         5
#define JT_RES_404        6
#define JT_RES_405        7
#define JT_RES_400        8
#define JT_RES_FILE_HTML  9
#define JT_RES_FILE_CSS   10
#define JT_RES_FILE_JS    11
#define JT_RES_FILE_TEXT  12
#define JT_RES_FILE_PNG   13
#define JT_RES_FILE_JPEG  14
#define JT_RES_FILE_GIF   15
#define JT_RES_FILE_SVG   16
#define JT_RES_FILE_ICO   17
#define JT_RES_FILE_BIN   18

typedef struct JT_HTTP_CONN_STATE {
    BYTE phase;
    BYTE resource;
    BYTE stage;
    BYTE source;
    DWORD offset;
    DWORD body_len;
    WORD last_len;
    WORD request_len;
    int file_fd;
    BYTE request_target_started;
    BYTE request_skip_query;
    BYTE request_target_done;
    BYTE head_only;
    BYTE request_line[JT_HTTP_REQUEST_LINE_MAX];
} JT_HTTP_CONN_STATE;

static volatile int httpd_requested = 0;
static volatile int httpd_requested_port = JT_HTTP_DEFAULT_PORT;
static volatile int httpd_auto_enabled = 1;
static volatile int httpd_auto_owned = 0;
static volatile int httpd_dhcp_active = 0;
static BYTE httpd_dhcp_ip[4];
static int httpd_listening_port = 0;

#include "jt_httpd_site.inc"

static BYTE http_file_chunk[UIP_TCP_MSS];

static const BYTE http_404_body[] =
    "<!doctype html><html><head><meta charset=\"utf-8\"><title>404 - JTMOS Corporation</title>"
    "<style>body{font-family:system-ui;background:#07111d;color:#fff;padding:8vw}a{color:#b7ff4a}</style>"
    "</head><body><h1>404</h1><p>Sivua ei löytynyt.</p><p><a href=\"/\">JTMOS Corporation →</a></p></body></html>";
static const BYTE http_405_body[] = "405 Method Not Allowed\r\n";
static const BYTE http_400_body[] = "400 Bad Request\r\n";

static const BYTE http_header_html[] =
    "HTTP/1.0 200 OK\r\nServer: JTMOS-V68\r\nContent-Type: text/html; charset=utf-8\r\n"
    "Connection: close\r\nCache-Control: no-store\r\n\r\n";
static const BYTE http_header_css[] =
    "HTTP/1.0 200 OK\r\nServer: JTMOS-V68\r\nContent-Type: text/css; charset=utf-8\r\n"
    "Connection: close\r\nCache-Control: public, max-age=3600\r\n\r\n";
static const BYTE http_header_js[] =
    "HTTP/1.0 200 OK\r\nServer: JTMOS-V68\r\nContent-Type: application/javascript; charset=utf-8\r\n"
    "Connection: close\r\nCache-Control: public, max-age=3600\r\n\r\n";
static const BYTE http_header_404[] =
    "HTTP/1.0 404 Not Found\r\nServer: JTMOS-V68\r\nContent-Type: text/html; charset=utf-8\r\n"
    "Connection: close\r\nCache-Control: no-store\r\n\r\n";
static const BYTE http_header_405[] =
    "HTTP/1.0 405 Method Not Allowed\r\nServer: JTMOS-V68\r\nAllow: GET, HEAD\r\n"
    "Content-Type: text/plain; charset=utf-8\r\nConnection: close\r\n\r\n";
static const BYTE http_header_400[] =
    "HTTP/1.0 400 Bad Request\r\nServer: JTMOS-V68\r\n"
    "Content-Type: text/plain; charset=utf-8\r\nConnection: close\r\n\r\n";
static const BYTE http_header_text[] =
    "HTTP/1.0 200 OK\r\nServer: JTMOS-V68\r\nContent-Type: text/plain; charset=utf-8\r\n"
    "Connection: close\r\nCache-Control: no-store\r\n\r\n";
static const BYTE http_header_png[] =
    "HTTP/1.0 200 OK\r\nServer: JTMOS-V68\r\nContent-Type: image/png\r\n"
    "Connection: close\r\nCache-Control: public, max-age=3600\r\n\r\n";
static const BYTE http_header_jpeg[] =
    "HTTP/1.0 200 OK\r\nServer: JTMOS-V68\r\nContent-Type: image/jpeg\r\n"
    "Connection: close\r\nCache-Control: public, max-age=3600\r\n\r\n";
static const BYTE http_header_gif[] =
    "HTTP/1.0 200 OK\r\nServer: JTMOS-V68\r\nContent-Type: image/gif\r\n"
    "Connection: close\r\nCache-Control: public, max-age=3600\r\n\r\n";
static const BYTE http_header_svg[] =
    "HTTP/1.0 200 OK\r\nServer: JTMOS-V68\r\nContent-Type: image/svg+xml\r\n"
    "Connection: close\r\nCache-Control: public, max-age=3600\r\n\r\n";
static const BYTE http_header_ico[] =
    "HTTP/1.0 200 OK\r\nServer: JTMOS-V68\r\nContent-Type: image/x-icon\r\n"
    "Connection: close\r\nCache-Control: public, max-age=3600\r\n\r\n";
static const BYTE http_header_bin[] =
    "HTTP/1.0 200 OK\r\nServer: JTMOS-V68\r\nContent-Type: application/octet-stream\r\n"
    "Connection: close\r\nCache-Control: public, max-age=3600\r\n\r\n";

static int begins_with(const BYTE *p, int len, const char *prefix)
{
    int i;
    int n=(int)strlen(prefix);
    if(p==NULL || len<n) return 0;
    for(i=0;i<n;i++) if(p[i]!=(BYTE)prefix[i]) return 0;
    return 1;
}

static int path_equals(const BYTE *p,int len,const char *name)
{
    int n=(int)strlen(name);
    int i;
    if(len!=n) return 0;
    for(i=0;i<n;i++) if(p[i]!=(BYTE)name[i]) return 0;
    return 1;
}

static BYTE request_resource(const BYTE *p,int len,int *head_only)
{
    const BYTE *path;
    int route_n;
    if(head_only) *head_only=0;
    if(p==NULL || len<=0) return JT_RES_400;
    if(begins_with(p,len,"GET ")) { path=p+4; len-=4; }
    else if(begins_with(p,len,"HEAD ")) {
        path=p+5; len-=5;
        if(head_only) *head_only=1;
    } else return JT_RES_405;
    if(len<=0) return JT_RES_400;
    route_n=len;
    if(path_equals(path,route_n,"/") || path_equals(path,route_n,"/index.html") ||
       path_equals(path,route_n,"/fi") || path_equals(path,route_n,"/fi/")) return JT_RES_INDEX;
    if(path_equals(path,route_n,"/en") || path_equals(path,route_n,"/en/") ||
       path_equals(path,route_n,"/index-en.html") || path_equals(path,route_n,"/en/index.html")) return JT_RES_INDEX_EN;
    if(path_equals(path,route_n,"/invest") || path_equals(path,route_n,"/invest.html")) return JT_RES_INVEST;
    if(path_equals(path,route_n,"/invest-en.html") || path_equals(path,route_n,"/en/invest") ||
       path_equals(path,route_n,"/en/invest.html")) return JT_RES_INVEST_EN;
    if(path_equals(path,route_n,"/jtmos.css")) return JT_RES_CSS;
    if(path_equals(path,route_n,"/jtmos.js")) return JT_RES_JS;
    return JT_RES_404;
}

/* Keep only METHOD + the essential request target.  Facebook and other social
 * sites append long tracking query strings (for example ?fbclid=...).  Those
 * bytes are deliberately discarded while they arrive instead of consuming the
 * small per-connection uIP appstate buffer.  The HTTP version and remaining
 * request-line bytes are also ignored once the target's separating space has
 * been seen. */
static int http_collect_request_line(JT_HTTP_CONN_STATE *st,const BYTE *p,int len)
{
    int i;
    if(st==NULL || p==NULL || len<0) return -1;
    for(i=0;i<len;++i) {
        BYTE ch=p[i];
        if(ch==0) return -1;
        if(ch=='\n') return st->request_target_done ? 1 : -1;
        if(ch=='\r') {
            if(st->request_target_done) continue;
            return -1;
        }
        if(st->request_target_done) continue;
        if(!st->request_target_started) {
            if(st->request_len>=JT_HTTP_REQUEST_LINE_MAX) return -1;
            st->request_line[st->request_len++]=ch;
            if(ch==' ') st->request_target_started=1;
            continue;
        }
        if(st->request_skip_query) {
            if(ch==' ') {
                st->request_skip_query=0;
                st->request_target_done=1;
            }
            continue;
        }
        if(ch=='?' || ch=='#') {
            st->request_skip_query=1;
            continue;
        }
        if(ch==' ') {
            st->request_target_done=1;
            continue;
        }
        if(st->request_len>=JT_HTTP_REQUEST_LINE_MAX) return -1;
        st->request_line[st->request_len++]=ch;
    }
    return 0;
}

static int http_hex_value(BYTE ch)
{
    if(ch>='0' && ch<='9') return (int)(ch-'0');
    if(ch>='a' && ch<='f') return (int)(ch-'a')+10;
    if(ch>='A' && ch<='F') return (int)(ch-'A')+10;
    return -1;
}

static int http_path_segment_safe(const char *path)
{
    const char *p=path;
    const char *start;
    int n;
    if(path==NULL || path[0]!='/') return 0;
    while(*p) {
        while(*p=='/') ++p;
        start=p;
        while(*p && *p!='/') ++p;
        n=(int)(p-start);
        if((n==1 && start[0]=='.') || (n==2 && start[0]=='.' && start[1]=='.')) return 0;
    }
    return 1;
}

/* Extract a safe WWW_ROOT-relative path from origin-form or absolute-form
 * HTTP targets.  Query/fragment data is ignored even if this helper is called
 * with an uncanonicalized request line. */
static int http_extract_target_path(const BYTE *p,int len,char *out,unsigned int capacity)
{
    const BYTE *target;
    int target_len,i,hi,lo;
    unsigned int o=0;
    if(p==NULL || out==NULL || capacity<2U) return -1;
    if(begins_with(p,len,"GET ")) { target=p+4; target_len=len-4; }
    else if(begins_with(p,len,"HEAD ")) { target=p+5; target_len=len-5; }
    else return -1;
    if(target_len<=0) return -1;

    if(begins_with(target,target_len,"http://") || begins_with(target,target_len,"https://")) {
        i=begins_with(target,target_len,"https://") ? 8 : 7;
        while(i<target_len && target[i]!='/' && target[i]!='?' && target[i]!='#') ++i;
        if(i>=target_len || target[i]!='/' ) {
            if(capacity<2U) return -1;
            out[0]='/'; out[1]=0;
            return 1;
        }
        target+=i; target_len-=i;
    }
    if(target[0]!='/') return -1;

    for(i=0;i<target_len;++i) {
        BYTE ch=target[i];
        if(ch=='?' || ch=='#' || ch==' ') break;
        if(ch=='%') {
            if(i+2>=target_len) return -1;
            hi=http_hex_value(target[i+1]); lo=http_hex_value(target[i+2]);
            if(hi<0 || lo<0) return -1;
            ch=(BYTE)((hi<<4)|lo);
            i+=2;
        }
        if(ch==0 || ch<' ' || ch=='\\' || ch==':') return -1;
        if(o+1U>=capacity) return -1;
        if(ch=='/' && o>0 && out[o-1]=='/') continue;
        out[o++]=(char)ch;
    }
    if(o==0) out[o++]='/';
    out[o]=0;
    if(!http_path_segment_safe(out)) return -1;
    if(out[o-1]=='/') {
        static const char index_name[]="index.html";
        unsigned int j;
        for(j=0;index_name[j];++j) {
            if(o+1U>=capacity) return -1;
            out[o++]=index_name[j];
        }
        out[o]=0;
    }
    return (int)o;
}

static int http_ends_with_ci(const char *name,const char *suffix)
{
    int nl,sl,i;
    BYTE a,b;
    if(name==NULL || suffix==NULL) return 0;
    nl=(int)strlen(name); sl=(int)strlen(suffix);
    if(sl>nl) return 0;
    for(i=0;i<sl;++i) {
        a=(BYTE)name[nl-sl+i]; b=(BYTE)suffix[i];
        if(a>='A' && a<='Z') a=(BYTE)(a-'A'+'a');
        if(b>='A' && b<='Z') b=(BYTE)(b-'A'+'a');
        if(a!=b) return 0;
    }
    return 1;
}

static BYTE http_dynamic_resource_type(const char *path)
{
    if(http_ends_with_ci(path,".html") || http_ends_with_ci(path,".htm")) return JT_RES_FILE_HTML;
    if(http_ends_with_ci(path,".css")) return JT_RES_FILE_CSS;
    if(http_ends_with_ci(path,".js")) return JT_RES_FILE_JS;
    if(http_ends_with_ci(path,".txt") || http_ends_with_ci(path,".xml")) return JT_RES_FILE_TEXT;
    if(http_ends_with_ci(path,".png")) return JT_RES_FILE_PNG;
    if(http_ends_with_ci(path,".jpg") || http_ends_with_ci(path,".jpeg")) return JT_RES_FILE_JPEG;
    if(http_ends_with_ci(path,".gif")) return JT_RES_FILE_GIF;
    if(http_ends_with_ci(path,".svg")) return JT_RES_FILE_SVG;
    if(http_ends_with_ci(path,".ico")) return JT_RES_FILE_ICO;
    return JT_RES_FILE_BIN;
}

static const char *resource_name(BYTE resource)
{
    switch(resource) {
    case JT_RES_INDEX: return "index.html";
    case JT_RES_INDEX_EN: return "index-en.html";
    case JT_RES_INVEST: return "invest.html";
    case JT_RES_INVEST_EN: return "invest-en.html";
    case JT_RES_CSS: return "jtmos.css";
    case JT_RES_JS: return "jtmos.js";
    case JT_RES_405: return "(method)";
    case JT_RES_400: return "(bad-request)";
    case JT_RES_FILE_HTML: return "(www-html)";
    case JT_RES_FILE_CSS: return "(www-css)";
    case JT_RES_FILE_JS: return "(www-js)";
    case JT_RES_FILE_TEXT: return "(www-text)";
    default: return "(www-file)";
    }
}

static const char *resource_uri(BYTE resource)
{
    switch(resource) {
    case JT_RES_INDEX: return "/index.html";
    case JT_RES_INDEX_EN: return "/index-en.html";
    case JT_RES_INVEST: return "/invest.html";
    case JT_RES_INVEST_EN: return "/invest-en.html";
    case JT_RES_CSS: return "/jtmos.css";
    case JT_RES_JS: return "/jtmos.js";
    case JT_RES_405: return "(non-GET/HEAD)";
    case JT_RES_400: return "(bad-request)";
    case JT_RES_FILE_HTML: return "(WWW_ROOT html)";
    case JT_RES_FILE_CSS: return "(WWW_ROOT css)";
    case JT_RES_FILE_JS: return "(WWW_ROOT js)";
    case JT_RES_FILE_TEXT: return "(WWW_ROOT text)";
    case JT_RES_FILE_PNG: return "(WWW_ROOT png)";
    case JT_RES_FILE_JPEG: return "(WWW_ROOT jpeg)";
    case JT_RES_FILE_GIF: return "(WWW_ROOT gif)";
    case JT_RES_FILE_SVG: return "(WWW_ROOT svg)";
    case JT_RES_FILE_ICO: return "(WWW_ROOT ico)";
    case JT_RES_FILE_BIN: return "(WWW_ROOT file)";
    default: return "(unknown)";
    }
}

static int resource_status(BYTE resource)
{
    if(resource==JT_RES_404) return 404;
    if(resource==JT_RES_405) return 405;
    if(resource==JT_RES_400) return 400;
    return 200;
}

static int http_build_www_path(BYTE resource,char *path,unsigned int capacity)
{
    char root[512];
    const char *name;
    unsigned int rl,nl;
    if(path==NULL || capacity<4) return -1;
    name=resource_name(resource);
    if(resource>JT_RES_JS) return -1;
    if(kgetglobalenv("WWW_ROOT",root,sizeof(root))<0 || !root[0])
        strcpy(root,"cdrom:/");
    rl=(unsigned int)strlen(root); nl=(unsigned int)strlen(name);
    if(rl+nl+2U>capacity) return -1;
    strcpy(path,root);
    if(rl && path[rl-1]!='/' && path[rl-1]!='\\') { path[rl++]='/'; path[rl]=0; }
    strcat(path,name);
    return 0;
}

/* Prefer the filesystem selected by system-global WWW_ROOT.  The release
 * embeds identical assets as a fallback so early boot or a missing utils.iso
 * still leaves a useful diagnostic page on the configured HTTP port. */
static int http_open_www_resource(JT_HTTP_CONN_STATE *st)
{
    char path[768];
    int fd,end;
    if(st==NULL || st->resource>JT_RES_JS) return 0;
    if(http_build_www_path(st->resource,path,sizeof(path))<0) return 0;
    fd=open(path,O_RDONLY);
    if(fd<0) return 0;
    end=lseek(fd,0,SEEK_END);
    if(end<0 || lseek(fd,0,SEEK_SET)<0) { close(fd); return 0; }
    st->source=JT_HTTP_SOURCE_FILE;
    st->file_fd=fd;
    st->body_len=(DWORD)end;
    return 1;
}

static int http_open_request_path(JT_HTTP_CONN_STATE *st,const BYTE *request,int request_len)
{
    char root[512];
    char route[256];
    char path[768];
    unsigned int rl,pl;
    int fd,end;
    if(st==NULL || request==NULL) return -1;
    if(http_extract_target_path(request,request_len,route,sizeof(route))<0) return -1;
    if(kgetglobalenv("WWW_ROOT",root,sizeof(root))<0 || !root[0]) strcpy(root,"cdrom:/");
    rl=(unsigned int)strlen(root);
    pl=(unsigned int)strlen(route);
    if(rl+pl+2U>sizeof(path)) return -1;
    strcpy(path,root);
    if(rl && path[rl-1]!='/' && path[rl-1]!='\\') { path[rl++]='/'; path[rl]=0; }
    strcat(path,route[0]=='/' ? route+1 : route);
    fd=open(path,O_RDONLY);
    if(fd<0) return 0;
    end=lseek(fd,0,SEEK_END);
    if(end<0 || lseek(fd,0,SEEK_SET)<0) { close(fd); return 0; }
    st->resource=http_dynamic_resource_type(route);
    st->source=JT_HTTP_SOURCE_FILE;
    st->file_fd=fd;
    st->body_len=(DWORD)end;
    return 1;
}

static void http_close_www_resource(JT_HTTP_CONN_STATE *st)
{
    if(st!=NULL && st->file_fd>=0) { close(st->file_fd); st->file_fd=-1; }
}

static void http_log_request(const JT_HTTP_CONN_STATE *st)
{
    char line[256];
    const char *source;
    int status;
    if(st==NULL) return;
    status=resource_status(st->resource);
    source=(st->source==JT_HTTP_SOURCE_FILE) ? "WWW_ROOT" : "embedded";
    sprintf(line,"HTTP request %s status=%d source=%s bytes=%lu",
            resource_uri(st->resource),status,source,(unsigned long)st->body_len);
    WriteWWWLog(line);
}

static const BYTE *resource_header(BYTE resource,DWORD *len)
{
    switch(resource) {
    case JT_RES_CSS: *len=(DWORD)(sizeof(http_header_css)-1); return http_header_css;
    case JT_RES_JS: *len=(DWORD)(sizeof(http_header_js)-1); return http_header_js;
    case JT_RES_404: *len=(DWORD)(sizeof(http_header_404)-1); return http_header_404;
    case JT_RES_405: *len=(DWORD)(sizeof(http_header_405)-1); return http_header_405;
    case JT_RES_400: *len=(DWORD)(sizeof(http_header_400)-1); return http_header_400;
    case JT_RES_FILE_CSS: *len=(DWORD)(sizeof(http_header_css)-1); return http_header_css;
    case JT_RES_FILE_JS: *len=(DWORD)(sizeof(http_header_js)-1); return http_header_js;
    case JT_RES_FILE_TEXT: *len=(DWORD)(sizeof(http_header_text)-1); return http_header_text;
    case JT_RES_FILE_PNG: *len=(DWORD)(sizeof(http_header_png)-1); return http_header_png;
    case JT_RES_FILE_JPEG: *len=(DWORD)(sizeof(http_header_jpeg)-1); return http_header_jpeg;
    case JT_RES_FILE_GIF: *len=(DWORD)(sizeof(http_header_gif)-1); return http_header_gif;
    case JT_RES_FILE_SVG: *len=(DWORD)(sizeof(http_header_svg)-1); return http_header_svg;
    case JT_RES_FILE_ICO: *len=(DWORD)(sizeof(http_header_ico)-1); return http_header_ico;
    case JT_RES_FILE_BIN: *len=(DWORD)(sizeof(http_header_bin)-1); return http_header_bin;
    default: *len=(DWORD)(sizeof(http_header_html)-1); return http_header_html;
    }
}

static const BYTE *resource_body(BYTE resource,DWORD *len)
{
    switch(resource) {
    case JT_RES_INDEX: *len=JT_SITE_INDEX_HTML_LEN; return jt_site_index_html;
    case JT_RES_INDEX_EN: *len=JT_SITE_INDEX_EN_HTML_LEN; return jt_site_index_en_html;
    case JT_RES_INVEST: *len=JT_SITE_INVEST_HTML_LEN; return jt_site_invest_html;
    case JT_RES_INVEST_EN: *len=JT_SITE_INVEST_EN_HTML_LEN; return jt_site_invest_en_html;
    case JT_RES_CSS: *len=JT_SITE_JTMOS_CSS_LEN; return jt_site_jtmos_css;
    case JT_RES_JS: *len=JT_SITE_JTMOS_JS_LEN; return jt_site_jtmos_js;
    case JT_RES_405: *len=(DWORD)(sizeof(http_405_body)-1); return http_405_body;
    case JT_RES_400: *len=(DWORD)(sizeof(http_400_body)-1); return http_400_body;
    default: *len=(DWORD)(sizeof(http_404_body)-1); return http_404_body;
    }
}

static DWORD stage_length(const JT_HTTP_CONN_STATE *st)
{
    DWORD len=0;
    if(st->stage==JT_HTTP_STAGE_HEADER) { (void)resource_header(st->resource,&len); return len; }
    if(st->stage==JT_HTTP_STAGE_BODY) return st->body_len;
    return 0;
}

/* Move from an exhausted header into the body, and from an exhausted body to
 * DONE.  offset is always relative to the current stage. */
static int normalize_stage(JT_HTTP_CONN_STATE *st)
{
    DWORD len;
    while(st->stage<JT_HTTP_STAGE_DONE) {
        len=stage_length(st);
        if(st->offset<len) return 0;
        st->stage++;
        st->offset=0;
    }
    http_close_www_resource(st);
    return 1;
}

static int send_current_segment(JT_HTTP_CONN_STATE *st)
{
    const BYTE *p=NULL;
    DWORD len,remain;
    WORD chunk,mss;
    int got;
    if(normalize_stage(st)) return 1;
    len=stage_length(st);
    if(st->offset>=len) return 1;
    remain=len-st->offset;
    mss=(WORD)uip_mss();
    if(mss==0 || mss>UIP_TCP_MSS) mss=UIP_TCP_MSS;
    chunk=(WORD)(remain>(DWORD)mss ? mss : remain);

    if(st->stage==JT_HTTP_STAGE_HEADER) {
        p=resource_header(st->resource,&len);
        uip_send((BYTE *)(p+st->offset),(int)chunk);
    } else if(st->source==JT_HTTP_SOURCE_FILE && st->file_fd>=0) {
        if(lseek(st->file_fd,(int)st->offset,SEEK_SET)<0) return -1;
        got=read(st->file_fd,http_file_chunk,(int)chunk);
        if(got<=0) return -1;
        chunk=(WORD)got;
        uip_send(http_file_chunk,(int)chunk);
    } else {
        p=resource_body(st->resource,&len);
        if(p==NULL || st->offset>=len) return -1;
        uip_send((BYTE *)(p+st->offset),(int)chunk);
    }
    st->last_len=chunk;
    return 0;
}

int JtHttpdEnable(int port)
{
    int flags;
    if(port<=0) port=JT_HTTP_DEFAULT_PORT;
    if(port>65535) return -1;
    flags=get_eflags();disable();
    httpd_requested_port=port;
    httpd_requested=1;
    httpd_auto_owned=0;
    set_eflags(flags);
    return 0;
}

int JtHttpdDisable(void)
{
    int flags=get_eflags();disable();
    httpd_requested=0;
    httpd_auto_enabled=0;
    httpd_auto_owned=0;
    set_eflags(flags);
    return 0;
}

int JtHttpdRequested(void) { return httpd_requested; }
int JtHttpdPort(void) { return httpd_requested_port; }
int JtHttpdIsListening(void) { return httpd_listening_port!=0; }
int JtHttpdAutoEnabled(void) { return httpd_auto_enabled; }

int JtHttpdSetAuto(int enabled)
{
    int flags=get_eflags();disable();
    httpd_auto_enabled=enabled?1:0;
    if(httpd_auto_enabled && httpd_dhcp_active) {
        httpd_requested_port=JT_HTTP_DEFAULT_PORT;
        httpd_requested=1;
        httpd_auto_owned=1;
    } else if(!httpd_auto_enabled && httpd_auto_owned) {
        httpd_requested=0;
        httpd_auto_owned=0;
    }
    set_eflags(flags);
    return 0;
}

void JtHttpdDhcpLease(int active,const unsigned char ip[4])
{
    int flags=get_eflags();disable();
    httpd_dhcp_active=active?1:0;
    if(active && ip) memcpy(httpd_dhcp_ip,ip,sizeof(httpd_dhcp_ip));
    else memset(httpd_dhcp_ip,0,sizeof(httpd_dhcp_ip));
    if(httpd_dhcp_active && httpd_auto_enabled) {
        if(!httpd_requested || httpd_auto_owned) {
            httpd_requested_port=JT_HTTP_DEFAULT_PORT;
            httpd_requested=1;
            httpd_auto_owned=1;
        }
    } else if(httpd_auto_owned) {
        httpd_requested=0;
        httpd_auto_owned=0;
    }
    set_eflags(flags);
}

void JtHttpdNetworkReset(void)
{
    httpd_listening_port=0;
    JtHttpdDhcpLease(0,NULL);
}

void JtHttpdNetworkStop(void)
{
    int flags=get_eflags();disable();
    httpd_requested=0;
    httpd_auto_owned=0;
    httpd_dhcp_active=0;
    memset(httpd_dhcp_ip,0,sizeof(httpd_dhcp_ip));
    httpd_listening_port=0;
    set_eflags(flags);
}

void JtHttpdSync(void)
{
    if(httpd_listening_port!=0 && (!httpd_requested || httpd_listening_port!=httpd_requested_port)) {
        uip_unlisten((u16_t)httpd_listening_port);
        printk("WWW: stopped listening on TCP port %d.\n",httpd_listening_port);
        httpd_listening_port=0;
    }
    if(httpd_requested && httpd_listening_port==0) {
        uip_listen((u16_t)httpd_requested_port);
        httpd_listening_port=httpd_requested_port;
        if(httpd_dhcp_active)
            printk("WWW: JTMOS Corporation site listening on %d.%d.%d.%d:%d.\n",
                httpd_dhcp_ip[0],httpd_dhcp_ip[1],httpd_dhcp_ip[2],httpd_dhcp_ip[3],httpd_listening_port);
        else
            printk("WWW: JTMOS Corporation HTTP/1.0 site listening on TCP port %d.\n",httpd_listening_port);
    }
}

void JtHttpdAppCall(void)
{
    JT_HTTP_CONN_STATE *st;
    DWORD embedded_len;
    int data_len,sendrc;
    if(!httpd_requested || httpd_listening_port==0 || uip_conn==NULL) return;
    if(uip_conn->lport!=htons((u16_t)httpd_listening_port)) return;
    st=(JT_HTTP_CONN_STATE *)uip_conn->appstate;
    if(uip_connected()) { memset(st,0,sizeof(*st)); st->file_fd=-1; }
    if(uip_aborted() || uip_timedout() || uip_closed()) {
        http_close_www_resource(st);
        return;
    }

    if(uip_newdata() && st->phase==0) {
        int line_rc;
        data_len=(int)uip_datalen();
        line_rc=http_collect_request_line(st,(const BYTE *)uip_appdata,data_len);
        if(line_rc==0) {
            /* TCP consumed this fragment; send only the protocol ACK and wait
             * for the rest of the HTTP request line. */
            uip_len=0;
            return;
        }
        if(line_rc<0) {
            st->resource=JT_RES_400;
            st->head_only=0;
        } else {
            int head_only=0;
            st->resource=request_resource(st->request_line,(int)st->request_len,&head_only);
            st->head_only=head_only?1:0;
        }
        st->stage=JT_HTTP_STAGE_HEADER;
        st->offset=0;
        st->last_len=0;
        st->source=JT_HTTP_SOURCE_EMBED;
        st->file_fd=-1;
        (void)resource_body(st->resource,&embedded_len);
        st->body_len=embedded_len;
        if(st->resource<=JT_RES_JS) {
            (void)http_open_www_resource(st);
        } else if(st->resource==JT_RES_404) {
            int open_rc=http_open_request_path(st,st->request_line,(int)st->request_len);
            if(open_rc<0) {
                st->resource=JT_RES_400;
                (void)resource_body(st->resource,&embedded_len);
                st->body_len=embedded_len;
            }
        }
        if(st->head_only) st->body_len=0;
        st->phase=1;
        http_log_request(st);
    }

    if(st->phase!=1) return;

    if(uip_acked() && st->last_len!=0) {
        st->offset+=(DWORD)st->last_len;
        st->last_len=0;
        if(normalize_stage(st)) {
            st->phase=2;
            uip_close();
            return;
        }
    }

    if(uip_rexmit()) {
        sendrc=send_current_segment(st);
        if(sendrc<0) { http_close_www_resource(st); st->phase=2; uip_abort(); }
        return;
    }

    /* Only one segment may be outstanding.  ACK advances offset; a poll while
     * waiting for that ACK must not duplicate application data. */
    if(st->last_len==0 && (uip_newdata() || uip_acked() || uip_poll())) {
        sendrc=send_current_segment(st);
        if(sendrc>0) { st->phase=2; uip_close(); }
        else if(sendrc<0) { http_close_www_resource(st); st->phase=2; uip_abort(); }
    }
}

