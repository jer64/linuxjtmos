#ifndef JTMOS_JT_HTTP_CLIENT_H
#define JTMOS_JT_HTTP_CLIENT_H

#define JT_HTTP_CLIENT_EBUSY       (-16)
#define JT_HTTP_CLIENT_EINVAL      (-22)
#define JT_HTTP_CLIENT_ENETDOWN    (-100)
#define JT_HTTP_CLIENT_ETIMEDOUT   (-110)
#define JT_HTTP_CLIENT_EINTR       (-4)
#define JT_HTTP_CLIENT_EOVERFLOW   (-75)
#define JT_HTTP_CLIENT_ECONN       (-111)

/* One bounded HTTP/TCP client stream. The caller supplies an already-resolved
 * IPv4 address and a complete HTTP request. uIP ownership remains in the
 * network worker; callers only submit/drain/cancel the transfer. */
int JtHttpClientStart(const unsigned char ip[4],int port,const char *request);
int JtHttpClientRead(void *buffer,int maxlen);
int JtHttpClientDone(void);
int JtHttpClientResult(void);
void JtHttpClientCancel(void);

typedef struct {
    DWORD rx_queued_bytes;
    DWORD rx_consumed_bytes;
    DWORD rx_peak_buffered;
    DWORD flow_stops;
    DWORD flow_restarts;
    DWORD overflow_errors;
} JT_HTTP_CLIENT_STATS;

void JtHttpClientGetStats(JT_HTTP_CLIENT_STATS *out);
void JtHttpClientResetStats(void);

/* Called only from the uIP owner/lifecycle paths. */
void JtHttpClientService(void);
void JtHttpClientAppCall(void);
void JtHttpClientNetworkReset(void);

#endif
