#ifndef _JTMOS_UIP_MAIN_H
#define _JTMOS_UIP_MAIN_H
int UipProcess(void);
typedef struct {
    DWORD rx_packets, rx_bytes, tx_packets, tx_bytes;
    DWORD rx_invalid, rx_oversize, tx_dropped, timer_catchups;
    /* uIP applications may point uip_appdata at application-owned memory.
     * Ethernet/SLIP transmitters send the linear uip_buf frame, so the owner
     * must copy that payload into uip_buf before handing it to the device. */
    DWORD tx_appdata_linearized, tx_appdata_bytes, tx_appdata_invalid;
    /* Layer-2/ingress accounting.  These counters are deliberately separate
     * from uip_stat: accepted here means the frame was accepted by the JTMOS
     * dispatcher (ARP/JNET/valid IPv4).  uip_stat below then tells whether a
     * valid IPv4/TCP/ICMP packet was accepted or rejected by the protocol
     * core. */
    DWORD rx_frames_seen, rx_frames_accepted, rx_frames_rejected;
    DWORD rx_arp_accepted, rx_ipv4_accepted, rx_jnet_accepted;
    DWORD rx_reject_short, rx_reject_oversize;
    DWORD rx_reject_ethertype, rx_reject_ipv4;
    DWORD reset_tick;
    /* Polling-owner CPU-idle accounting.  Kept at the tail so older fields
     * retain their layout.  idle_sleep_ms is requested sleep time in milliseconds, not a
     * claim about exact wall-clock sleep duration under scheduler load. */
    DWORD idle_sleep_calls, idle_sleep_ms;
    DWORD idle_sleep_fast, idle_sleep_medium, idle_sleep_max;
} JT_UIP_DRIVER_STATS;
void JtUipGetDriverStats(JT_UIP_DRIVER_STATS *out);
void JtUipResetDriverStats(void);
/* Network-owner ingress used while a bounded JNet DHCP/ARP/ICMP/DNS
 * transaction is waiting.  The caller must already have offered the frame to
 * jnet_input_ethernet(). */
int JtUipServiceEthernetFrame(const unsigned char *frame,int len);
#endif
