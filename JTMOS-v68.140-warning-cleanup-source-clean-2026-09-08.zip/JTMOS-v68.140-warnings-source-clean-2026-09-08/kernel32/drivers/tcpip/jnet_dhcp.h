#ifndef JTMOS_JNET_DHCP_H
#define JTMOS_JNET_DHCP_H

/* Small DHCPv4 Ethernet/IPv4/UDP codec shared by JNET and host regressions.
 * Keep this header independent of kernel types so the exact packet codec can
 * be compiled and tested on the development host. */
#define JNET_DHCP_DISCOVER 1
#define JNET_DHCP_OFFER    2
#define JNET_DHCP_REQUEST  3
#define JNET_DHCP_DECLINE  4
#define JNET_DHCP_ACK      5
#define JNET_DHCP_NAK      6
#define JNET_DHCP_RELEASE  7
#define JNET_DHCP_INFORM   8

#define JNET_DHCP_FRAME_MAX 1600

typedef struct {
    int message_type;
    unsigned int xid;
    unsigned short secs;
    int broadcast;
    unsigned char client_mac[6];
    unsigned char ethernet_dest[6];
    unsigned char source_ip[4];
    unsigned char destination_ip[4];
    unsigned char ciaddr[4];
    unsigned char requested_ip[4];
    unsigned char server_id[4];
    int include_requested_ip;
    int include_server_id;
} JNET_DHCP_BUILD;

typedef struct {
    int message_type;
    unsigned char yiaddr[4];
    unsigned char server[4];
    unsigned char mask[4];
    unsigned char gateway[4];
    unsigned char dns[4];
    unsigned int lease_seconds;
    unsigned int t1_seconds;
    unsigned int t2_seconds;
    int have_server;
    int have_mask;
    int have_gateway;
    int have_dns;
    int have_lease;
    int have_t1;
    int have_t2;
} JNET_DHCP_REPLY;

int jnet_dhcp_build_frame(unsigned char *frame,int maxlen,const JNET_DHCP_BUILD *b);
int jnet_dhcp_parse_reply(const unsigned char *frame,int len,unsigned int xid,
                          const unsigned char client_mac[6],JNET_DHCP_REPLY *out);

#endif
