#ifndef __JTMOS_HDA_H__
#define __JTMOS_HDA_H__

/* Minimal polling HD-Audio backend for NVIDIA MCP61 + Realtek ALC662.
 * The generic audio API remains U8 mono; this backend converts to 48 kHz,
 * signed 16-bit stereo for the HDA DMA engine. */
int hda_init(void);
int hda_is_ready(void);
void hda_kick(void);
void hda_stop(void);
int hda_active_bytes(void);

#endif
