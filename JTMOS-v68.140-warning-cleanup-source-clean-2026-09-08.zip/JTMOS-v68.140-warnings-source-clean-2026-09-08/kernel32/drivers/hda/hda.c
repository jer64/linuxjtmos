/* ========================================================================
 * JTMOS High Definition Audio - first physical-machine backend
 * Target: NVIDIA MCP61 HDA (10de:03f0) + Realtek ALC662 (10ec:0662)
 *
 * V1 is intentionally simple and debuggable:
 *   - PCI class 04/03 discovery through JTMOS PCI core
 *   - BAR0 MMIO mapping, controller reset, Immediate Command verbs
 *   - ALC662 front DAC/mixer/pin routing (0x02 -> 0x0c -> 0x14)
 *   - headphone pin 0x1b enabled as a secondary output
 *   - one output stream, two-entry BDL, polling completion
 *   - U8 mono JTMOS audio is software-resampled to 48 kHz S16 stereo
 *
 * The synchronous/polling transfer is a bring-up implementation.  It avoids
 * IRQ routing/APIC uncertainty on the EL1352; a later revision can replace
 * hda_play_buffer() with a double-buffered IRQ engine without changing audio.c.
 * ======================================================================== */
#include "kernel32.h"
#include "sysmem.h"
#include "paging.h"
#include "pit.h"
#include "userhw.h"
#include "pci.h"
#include "audio.h"
#include "hda.h"

#define HDA_MMIO_BYTES          0x1000UL
#define HDA_GCAP                0x00
#define HDA_GCTL                0x08
#define HDA_STATESTS            0x0e
#define HDA_INTCTL              0x20
#define HDA_ICOI                0x60
#define HDA_ICII                0x64
#define HDA_ICIS                0x68
#define HDA_STREAM_BASE         0x80
#define HDA_STREAM_STRIDE       0x20

#define HDA_GCTL_CRST           0x00000001UL
#define HDA_ICIS_ICB            0x0001
#define HDA_ICIS_IRV            0x0002

#define SD_CTL                  0x00
#define SD_STS                  0x03
#define SD_LPIB                 0x04
#define SD_CBL                  0x08
#define SD_LVI                  0x0c
#define SD_FMT                  0x12
#define SD_BDPL                 0x18
#define SD_BDPU                 0x1c
#define SD_CTL_SRST             0x01
#define SD_CTL_RUN              0x02
#define SD_STS_BCIS             0x04
#define SD_STS_FIFOE            0x08
#define SD_STS_DESE             0x10

#define HDA_FMT_48K_S16_STEREO  0x0011
#define HDA_STREAM_TAG          1
#define HDA_DMA_BYTES           32768UL
#define HDA_SRC_BYTES           8192
#define HDA_TIMEOUT_MS          3000UL
#define HDA_SPIN_LIMIT          100000000UL

#define HDA_VERB_GET_PARAMETER  0xf00
#define HDA_VERB_GET_CONFIG      0xf1c
#define HDA_VERB_SET_CONN       0x701
#define HDA_VERB_SET_POWER      0x705
#define HDA_VERB_SET_STREAM     0x706
#define HDA_VERB_SET_PINCTL     0x707
#define HDA_VERB_SET_EAPD       0x70c
#define HDA_PARAM_VENDOR_ID     0x00
#define HDA_PARAM_NODE_COUNT    0x04
#define HDA_PARAM_FG_TYPE       0x05
#define HDA_PARAM_IN_AMP_CAP    0x0d
#define HDA_PARAM_OUT_AMP_CAP   0x12

#define NVIDIA_VENDOR           0x10de
#define MCP61_HDA_DEVICE         0x03f0
#define REALTEK_VENDOR          0x10ec
#define ALC662_DEVICE           0x0662
#define ALC662_DAC_FRONT        0x02
#define ALC662_MIX_FRONT        0x0c
#define ALC662_PIN_LINEOUT      0x14
#define ALC662_PIN_SPEAKER      0x15
#define ALC662_PIN_HEADPHONE    0x1b

typedef struct {
    DWORD addr_lo;
    DWORD addr_hi;
    DWORD length;
    DWORD flags;
} HDA_BDL;

typedef char hda_bdl_size_check[(sizeof(HDA_BDL)==16)?1:-1];

typedef struct {
    int probed;
    int ready;
    int busy;
    BYTE bus,dev,fun;
    BYTE codec;
    BYTE afg;
    BYTE stream_index;
    DWORD codec_id;
    DWORD mmio_phys;
    DWORD mmio_map;
    volatile BYTE *mmio;
    volatile BYTE *sd;
    BYTE *dma;
    DWORD dma_phys;
    HDA_BDL *bdl;
    DWORD bdl_phys;
    BYTE *src;
    int active_bytes;
} HDA_STATE;

static HDA_STATE hdac;

static BYTE hda_r8(DWORD o) { return *(volatile BYTE *)(hdac.mmio+o); }
static WORD hda_r16(DWORD o) { return *(volatile WORD *)(hdac.mmio+o); }
static DWORD hda_r32(DWORD o) { return *(volatile DWORD *)(hdac.mmio+o); }
static void hda_w8(DWORD o,BYTE v) { *(volatile BYTE *)(hdac.mmio+o)=v; }
static void hda_w16(DWORD o,WORD v) { *(volatile WORD *)(hdac.mmio+o)=v; }
static void hda_w32(DWORD o,DWORD v) { *(volatile DWORD *)(hdac.mmio+o)=v; }
static BYTE sd_r8(DWORD o) { return *(volatile BYTE *)(hdac.sd+o); }
static DWORD sd_r32(DWORD o) { return *(volatile DWORD *)(hdac.sd+o); }
static void sd_w8(DWORD o,BYTE v) { *(volatile BYTE *)(hdac.sd+o)=v; }
static void sd_w16(DWORD o,WORD v) { *(volatile WORD *)(hdac.sd+o)=v; }
static void sd_w32(DWORD o,DWORD v) { *(volatile DWORD *)(hdac.sd+o)=v; }

static int hda_timed_out(DWORD start,DWORD *spins)
{
    if((DWORD)(GetTickCount()-start)>=HDA_TIMEOUT_MS) return 1;
    if(++(*spins)>=HDA_SPIN_LIMIT) return 1;
    return 0;
}

static void hda_delay_1ms(void)
{
    DWORD start=GetTickCount(),spins=0;
    /* Intel HDA requires CRST to remain deasserted for >=100 us.  A full
     * millisecond is conservative; the spin limit also makes early bring-up
     * progress if the PIT tick happens not to advance yet. */
    while((DWORD)(GetTickCount()-start)<1UL && spins<2000000UL) {
        __asm__ __volatile__("nop");
        spins++;
    }
}

static int hda_reset_controller(void)
{
    DWORD start,spins;
    hda_w32(HDA_INTCTL,0);
    hda_w32(HDA_GCTL,hda_r32(HDA_GCTL)&~HDA_GCTL_CRST);
    start=GetTickCount(); spins=0;
    while(hda_r32(HDA_GCTL)&HDA_GCTL_CRST)
        if(hda_timed_out(start,&spins)) return 1;
    hda_delay_1ms();
    hda_w32(HDA_GCTL,hda_r32(HDA_GCTL)|HDA_GCTL_CRST);
    start=GetTickCount(); spins=0;
    while(!(hda_r32(HDA_GCTL)&HDA_GCTL_CRST))
        if(hda_timed_out(start,&spins)) return 1;
    hda_delay_1ms();
    return 0;
}

static int hda_immediate(DWORD verb,DWORD *reply)
{
    DWORD start,spins;
    WORD st;
    start=GetTickCount(); spins=0;
    while(hda_r16(HDA_ICIS)&HDA_ICIS_ICB)
        if(hda_timed_out(start,&spins)) return 1;
    /* IRV is write-1-to-clear. */
    hda_w16(HDA_ICIS,HDA_ICIS_IRV);
    hda_w32(HDA_ICOI,verb);
    hda_w16(HDA_ICIS,HDA_ICIS_ICB);
    start=GetTickCount(); spins=0;
    for(;;) {
        st=hda_r16(HDA_ICIS);
        if(!(st&HDA_ICIS_ICB) && (st&HDA_ICIS_IRV)) break;
        if(hda_timed_out(start,&spins)) return 1;
    }
    if(reply) *reply=hda_r32(HDA_ICII);
    hda_w16(HDA_ICIS,HDA_ICIS_IRV);
    return 0;
}

static int hda_verb12(BYTE nid,WORD verb,BYTE payload,DWORD *reply)
{
    DWORD cmd=((DWORD)hdac.codec<<28)|((DWORD)nid<<20)|
              ((DWORD)(verb&0x0fff)<<8)|(DWORD)payload;
    return hda_immediate(cmd,reply);
}

static int hda_verb4(BYTE nid,BYTE verb,WORD payload,DWORD *reply)
{
    DWORD cmd=((DWORD)hdac.codec<<28)|((DWORD)nid<<20)|
              ((DWORD)(verb&0x0f)<<16)|(DWORD)payload;
    return hda_immediate(cmd,reply);
}

static DWORD hda_get_param(BYTE nid,BYTE param)
{
    DWORD r=0;
    if(hda_verb12(nid,HDA_VERB_GET_PARAMETER,param,&r)) return 0;
    return r;
}

static void hda_amp_0db(BYTE nid,int output,int index)
{
    DWORD caps;
    WORD payload;
    int gain;
    caps=hda_get_param(nid,output ? HDA_PARAM_OUT_AMP_CAP : HDA_PARAM_IN_AMP_CAP);
    if(!caps || caps==0xffffffffUL) return;
    gain=(int)(caps&0x7f); /* offset encodes the 0 dB step */
    if(gain>0x7f) gain=0x7f;
    payload=(WORD)((output?0x8000:0x4000) | 0x3000 | ((index&0x0f)<<8) | gain);
    (void)hda_verb4(nid,0x3,payload,NULL);
}

static int hda_find_codec(void)
{
    WORD state;
    int c;
    DWORD id,start,spins;
    start=GetTickCount(); spins=0;
    do {
        state=hda_r16(HDA_STATESTS);
        if(state) break;
    } while(!hda_timed_out(start,&spins));
    printk("HDA: STATESTS=0x%x.\n",state);
    for(c=0;c<15;c++) {
        if(!(state&(1U<<c))) continue;
        hdac.codec=(BYTE)c;
        id=hda_get_param(0,HDA_PARAM_VENDOR_ID);
        if(!id || id==0xffffffffUL) continue;
        printk("HDA: codec %d vendor/device=%04x:%04x.\n",c,
               (unsigned)(id>>16),(unsigned)(id&0xffff));
        if((WORD)(id>>16)==REALTEK_VENDOR && (WORD)id==ALC662_DEVICE) {
            hdac.codec_id=id;
            return 0;
        }
    }
    return 1;
}

static int hda_find_afg(void)
{
    DWORD n;
    int start,count,i;
    n=hda_get_param(0,HDA_PARAM_NODE_COUNT);
    start=(int)((n>>16)&0xff);
    count=(int)(n&0xff);
    for(i=0;i<count;i++) {
        DWORD t=hda_get_param((BYTE)(start+i),HDA_PARAM_FG_TYPE);
        if((t&0xff)==1) { hdac.afg=(BYTE)(start+i); return 0; }
    }
    return 1;
}

static DWORD hda_get_config_default(BYTE nid)
{
    DWORD r=0;
    if(hda_verb12(nid,HDA_VERB_GET_CONFIG,0,&r)) return 0xffffffffUL;
    return r;
}

static int hda_pin_is_output(DWORD cfg)
{
    int connectivity,device;
    if(cfg==0xffffffffUL) return 1; /* keep the known ALC662 fallback */
    connectivity=(int)((cfg>>30)&3);
    device=(int)((cfg>>20)&15);
    if(connectivity==1) return 0;   /* explicitly no physical connection */
    return device==0 || device==1 || device==2; /* line out/speaker/headphone */
}

static void hda_setup_output_pin(BYTE nid,int headphone)
{
    DWORD cfg=hda_get_config_default(nid);
    if(!hda_pin_is_output(cfg)) {
        printk("HDA: pin 0x%x cfg=0x%x is not an output; skipped.\n",nid,cfg);
        return;
    }
    printk("HDA: enabling output pin 0x%x cfg=0x%x%s.\n",nid,cfg,
           headphone ? " (headphone)" : "");
    (void)hda_verb12(nid,HDA_VERB_SET_POWER,0,NULL);
    /* ALC662 output pins expose the front mixer as connection #0. */
    (void)hda_verb12(nid,HDA_VERB_SET_CONN,0,NULL);
    hda_amp_0db(nid,1,0);
    (void)hda_verb12(nid,HDA_VERB_SET_PINCTL,headphone ? 0xc0 : 0x40,NULL);
    /* Harmless on a pin without EAPD; essential on many desktop speaker paths. */
    (void)hda_verb12(nid,HDA_VERB_SET_EAPD,0x02,NULL);
}

static int hda_setup_alc662(void)
{
    /* Keep the stable ALC662 front-DAC path, but honor the codec's default
     * pin configuration so an EL1352 rear line-out/fixed speaker/headphone
     * output can all be enabled without an application knowing HDA details. */
    if(!hdac.afg) return 1;
    (void)hda_verb12(hdac.afg,HDA_VERB_SET_POWER,0,NULL);
    (void)hda_verb12(ALC662_DAC_FRONT,HDA_VERB_SET_POWER,0,NULL);
    (void)hda_verb12(ALC662_MIX_FRONT,HDA_VERB_SET_POWER,0,NULL);
    hda_amp_0db(ALC662_DAC_FRONT,1,0);
    hda_amp_0db(ALC662_MIX_FRONT,0,0);

    hda_setup_output_pin(ALC662_PIN_LINEOUT,0);
    hda_setup_output_pin(ALC662_PIN_SPEAKER,0);
    hda_setup_output_pin(ALC662_PIN_HEADPHONE,1);

    (void)hda_verb4(ALC662_DAC_FRONT,0x2,HDA_FMT_48K_S16_STEREO,NULL);
    (void)hda_verb12(ALC662_DAC_FRONT,HDA_VERB_SET_STREAM,
                     (BYTE)(HDA_STREAM_TAG<<4),NULL);
    return 0;
}

static int hda_stream_reset(void)
{
    DWORD start,spins;
    sd_w8(SD_CTL,(BYTE)(sd_r8(SD_CTL)&~SD_CTL_RUN));
    sd_w8(SD_CTL,(BYTE)(sd_r8(SD_CTL)|SD_CTL_SRST));
    start=GetTickCount(); spins=0;
    while(!(sd_r8(SD_CTL)&SD_CTL_SRST))
        if(hda_timed_out(start,&spins)) return 1;
    sd_w8(SD_CTL,(BYTE)(sd_r8(SD_CTL)&~SD_CTL_SRST));
    start=GetTickCount(); spins=0;
    while(sd_r8(SD_CTL)&SD_CTL_SRST)
        if(hda_timed_out(start,&spins)) return 1;
    return 0;
}

static int hda_play_buffer(DWORD bytes)
{
    DWORD half,start,spins;
    BYTE sts;
    if(bytes<128 || bytes>HDA_DMA_BYTES) return 1;
    bytes&=~3UL;
    if(bytes<128) return 1;
    half=(bytes/2)&~127UL;
    if(half<128) half=128;
    if(half>=bytes) half=bytes/2;

    if(hda_stream_reset()) return 1;
    memset(hdac.bdl,0,4096);
    hdac.bdl[0].addr_lo=hdac.dma_phys;
    hdac.bdl[0].length=half;
    hdac.bdl[0].flags=0;
    hdac.bdl[1].addr_lo=hdac.dma_phys+half;
    hdac.bdl[1].length=bytes-half;
    hdac.bdl[1].flags=1; /* IOC on the final descriptor */

    sd_w8(SD_STS,SD_STS_BCIS|SD_STS_FIFOE|SD_STS_DESE);
    sd_w32(SD_BDPL,hdac.bdl_phys);
    sd_w32(SD_BDPU,0);
    sd_w32(SD_CBL,bytes);
    sd_w16(SD_LVI,1);
    sd_w16(SD_FMT,HDA_FMT_48K_S16_STEREO);
    sd_w8(2,(BYTE)((sd_r8(2)&0x0f)|(HDA_STREAM_TAG<<4)));
    __asm__ __volatile__("" : : : "memory");

    hdac.busy=1; hdac.active_bytes=(int)bytes;
    sd_w8(SD_CTL,(BYTE)(sd_r8(SD_CTL)|SD_CTL_RUN));
    start=GetTickCount(); spins=0;
    for(;;) {
        sts=sd_r8(SD_STS);
        if(sts&(SD_STS_FIFOE|SD_STS_DESE)) {
            printk("HDA: stream DMA error sts=0x%x lpib=%u/%u.\n",
                   sts,(unsigned)sd_r32(SD_LPIB),(unsigned)bytes);
            break;
        }
        if(sts&SD_STS_BCIS) {
            sd_w8(SD_CTL,(BYTE)(sd_r8(SD_CTL)&~SD_CTL_RUN));
            sd_w8(SD_STS,SD_STS_BCIS);
            hdac.busy=0; hdac.active_bytes=0;
            return 0;
        }
        if(hda_timed_out(start,&spins)) {
            printk("HDA: stream timeout lpib=%u/%u sts=0x%x.\n",
                   (unsigned)sd_r32(SD_LPIB),(unsigned)bytes,sts);
            break;
        }
    }
    sd_w8(SD_CTL,(BYTE)(sd_r8(SD_CTL)&~SD_CTL_RUN));
    sd_w8(SD_STS,SD_STS_BCIS|SD_STS_FIFOE|SD_STS_DESE);
    hdac.busy=0; hdac.active_bytes=0;
    return 1;
}

static DWORD hda_convert_u8_mono(int n,int rate)
{
    DWORD frames,j,idx;
    int s;
    signed short *dst=(signed short *)hdac.dma;
    if(n<=0 || rate<4000) return 0;
    frames=((DWORD)n*48000UL)/(DWORD)rate;
    if(frames>HDA_DMA_BYTES/4) frames=HDA_DMA_BYTES/4;
    for(j=0;j<frames;j++) {
        idx=(j*(DWORD)rate)/48000UL;
        if(idx>=(DWORD)n) idx=(DWORD)n-1;
        s=((int)hdac.src[idx]-128)<<8;
        dst[j*2]=(signed short)s;
        dst[j*2+1]=(signed short)s;
    }
    return frames*4UL;
}

void hda_kick(void)
{
    int rate,maxsrc,n;
    DWORD bytes;
    if(!hdac.ready || hdac.busy) return;
    rate=audio.frequency ? audio.frequency : 11025;
    if(rate<4000) rate=4000;
    maxsrc=(int)(((HDA_DMA_BYTES/4)*((DWORD)rate))/48000UL);
    if(maxsrc<1) maxsrc=1;
    if(maxsrc>HDA_SRC_BYTES) maxsrc=HDA_SRC_BYTES;

    /* Bring-up version drains synchronously. This guarantees progress even
     * before IRQ routing is trusted on the physical MCP61 board. */
    while((n=audio_fifo_read(hdac.src,maxsrc))>0) {
        bytes=hda_convert_u8_mono(n,rate);
        if(!bytes || hda_play_buffer(bytes)) {
            audio_notify_underrun();
            break;
        }
        audio_notify_played(n);
    }
}

void hda_stop(void)
{
    if(!hdac.mmio || !hdac.sd) return;
    sd_w8(SD_CTL,(BYTE)(sd_r8(SD_CTL)&~SD_CTL_RUN));
    hdac.busy=0; hdac.active_bytes=0;
}

int hda_active_bytes(void)
{
    return hdac.active_bytes;
}

int hda_is_ready(void)
{
    return hdac.ready;
}

int hda_init(void)
{
    const PCIDEVICE *d;
    PCIBAR bar;
    DWORD pagebase,offset,map,gcap;
    int pages,iss,oss;
    if(hdac.ready) return 0;
    if(hdac.probed) return 1;
    memset(&hdac,0,sizeof(hdac));
    hdac.probed=1;

    pci_init();
    d=NULL;
    {
        int i;
        const PCIDEVICE *cand;
        for(i=0;i<pci_get_device_count();i++) {
            cand=pci_get_device(i);
            if(cand && cand->vendor_id==NVIDIA_VENDOR &&
               cand->device_id==MCP61_HDA_DEVICE &&
               cand->class_code==0x04 && cand->subclass==0x03) {
                d=cand;
                break;
            }
        }
    }
    if(!d) {
        printk("HDA: NVIDIA MCP61 10de:03f0 controller not found.\n");
        return 1;
    }
    if(pci_get_bar(d,0,&bar)!=0 || !bar.valid || bar.io || bar.is64 || !bar.base_low) {
        printk("HDA: audio controller has unusable BAR0.\n");
        return 1;
    }
    if(pci_enable_device(d,PCI_ENABLE_MEMORY|PCI_ENABLE_MASTER)!=0) return 1;
    pagebase=bar.base_low&~(PAGESIZE-1UL);
    offset=bar.base_low-pagebase;
    pages=(int)((offset+HDA_MMIO_BYTES+PAGESIZE-1UL)/PAGESIZE);
    map=pg_mapio((int)(pagebase/PAGESIZE),pages);
    if(!map) return 1;
    hdac.bus=d->bus; hdac.dev=d->device; hdac.fun=d->function;
    hdac.mmio_phys=bar.base_low; hdac.mmio_map=map;
    hdac.mmio=(volatile BYTE *)(map+offset);

    printk("HDA: controller PCI %d:%d.%d vendor=%04x device=%04x BAR0=0x%x.\n",
           d->bus,d->device,d->function,d->vendor_id,d->device_id,bar.base_low);
    if(hda_reset_controller()) {
        printk("HDA: controller reset failed.\n");
        return 1;
    }
    if(hda_find_codec()) {
        printk("HDA: no supported Realtek ALC662 codec found.\n");
        return 1;
    }
    if(hda_find_afg()) {
        printk("HDA: ALC662 audio function group not found.\n");
        return 1;
    }

    gcap=hda_r16(HDA_GCAP);
    iss=(int)((gcap>>8)&0x0f);
    oss=(int)((gcap>>12)&0x0f);
    if(oss<1) {
        printk("HDA: controller reports no output streams.\n");
        return 1;
    }
    hdac.stream_index=(BYTE)iss;
    hdac.sd=hdac.mmio+HDA_STREAM_BASE+(DWORD)iss*HDA_STREAM_STRIDE;
    hdac.bdl=(HDA_BDL *)userhw_dma_alloc_kernel32(4096,&hdac.bdl_phys);
    hdac.dma=(BYTE *)userhw_dma_alloc_kernel32(HDA_DMA_BYTES,&hdac.dma_phys);
    hdac.src=(BYTE *)malloc(HDA_SRC_BYTES);
    if(!hdac.bdl || !hdac.dma || !hdac.src) {
        printk("HDA: DMA/staging allocation failed.\n");
        return 1;
    }
    if(hda_setup_alc662()) return 1;
    hdac.ready=1;
    printk("HDA: MCP61/ALC662 ready, output SD=%d, polling 48kHz S16 stereo.\n",
           (int)hdac.stream_index);
    return 0;
}
