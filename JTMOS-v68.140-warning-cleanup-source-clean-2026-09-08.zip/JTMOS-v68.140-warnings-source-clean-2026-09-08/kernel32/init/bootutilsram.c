/* DOSBOOT persistent UTILS.ISO RAM-bank support. */
#include "kernel32.h"
#include "paging.h"
#include "bootutilsram.h"

extern volatile DWORD boot_utils_signature_early;
extern volatile DWORD boot_utils_version_early;
extern volatile DWORD boot_utils_phys_early;
extern volatile DWORD boot_utils_size_early;
extern volatile DWORD boot_utils_capacity_early;

static DWORD bootutils_kmap;
static DWORD bootutils_size;
static DWORD bootutils_phys;
static DWORD bootutils_pages;
static int bootutils_ready;

void BootUtilsRamInit(void)
{
    DWORD phys,size,capacity,reserved_bytes,end;

    bootutils_ready=0;
    bootutils_kmap=0;
    bootutils_size=0;
    bootutils_phys=0;
    bootutils_pages=0;

    if(boot_utils_signature_early!=JTMOS_BOOT_UTILS_HANDOFF_SIGNATURE ||
       boot_utils_version_early!=JTMOS_BOOT_UTILS_HANDOFF_VERSION)
    {
        printk("DOSBOOT utils RAM: no valid handoff.\n");
        return;
    }

    phys=boot_utils_phys_early;
    size=boot_utils_size_early;
    capacity=boot_utils_capacity_early;
    if(phys!=JTMOS_BOOT_UTILS_RAM_PHYS ||
       capacity!=JTMOS_BOOT_UTILS_RAM_BYTES ||
       size==0 || size>capacity ||
       phys+capacity<phys)
    {
        printk("DOSBOOT utils RAM: invalid metadata phys=0x%x size=%u cap=%u.\n",
               phys,(unsigned)size,(unsigned)capacity);
        return;
    }
    /* JTMOS_BOOT_UTILS_RAM_BYTES is a transport ceiling, not memory that must
     * remain permanently unavailable.  Reserve/map only the page-rounded bytes
     * actually occupied by this boot's utilities image. */
    if(size>0xffffffffUL-(PAGESIZE-1UL))
    {
        printk("DOSBOOT utils RAM: size alignment overflow.\n");
        return;
    }
    reserved_bytes=(size+(PAGESIZE-1UL)) & ~(PAGESIZE-1UL);
    if(reserved_bytes==0 || reserved_bytes>capacity ||
       phys>0xffffffffUL-reserved_bytes)
    {
        printk("DOSBOOT utils RAM: invalid reserved size=%u cap=%u.\n",
               (unsigned)reserved_bytes,(unsigned)capacity);
        return;
    }
    end=phys+reserved_bytes;
    if(phys<(DWORD)phMSTART || end>(DWORD)phMEND)
    {
        printk("DOSBOOT utils RAM: 0x%x..0x%x is outside managed RAM 0x%x..0x%x.\n",
               phys,end,phMSTART,phMEND);
        return;
    }

    if(mmReserveRegionAD((char *)phys,(char *)end)!=0)
    {
        printk("DOSBOOT utils RAM: allocator reservation failed.\n");
        return;
    }

    bootutils_pages=reserved_bytes/PAGESIZE;
    bootutils_kmap=pg_mapmemory((int)(phys/PAGESIZE),(int)bootutils_pages);
    if(!bootutils_kmap)
    {
        mmFreeRegionAD((char *)phys,(char *)end);
        bootutils_pages=0;
        printk("DOSBOOT utils RAM: kernel mapping failed.\n");
        return;
    }

    bootutils_phys=phys;
    bootutils_size=size;
    bootutils_ready=1;
    printk("DOSBOOT utils RAM: UTILS.ISO %u bytes at phys=0x%x, reserved=%u KiB (max=%u KiB).\n",
           (unsigned)size,phys,(unsigned)(reserved_bytes/1024UL),
           (unsigned)(capacity/1024UL));
}

DWORD BootUtilsRamSize(void)
{
    return bootutils_ready ? bootutils_size : 0;
}

int BootUtilsRamRead(DWORD offset, void *dst, DWORD length)
{
    DWORD remain;
    if(!bootutils_ready || dst==NULL) return -1;
    if(offset>bootutils_size) return -1;
    remain=bootutils_size-offset;
    if(length>remain) length=remain;
    if(length==0) return 0;
    memcpy(dst,(const void *)(bootutils_kmap+offset),length);
    return (int)length;
}
