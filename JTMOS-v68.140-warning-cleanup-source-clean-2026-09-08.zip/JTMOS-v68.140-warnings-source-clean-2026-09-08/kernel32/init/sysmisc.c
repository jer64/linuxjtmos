/*** System Miscellaneous Routines ***/
#include "sysmisc.h"
void halt(void)
{
    for(;;) { }
}
