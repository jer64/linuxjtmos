#ifndef JTMOS_BOOTUTILSRAM_H
#define JTMOS_BOOTUTILSRAM_H
#include "basdef.h"
#define JTMOS_BOOT_UTILS_HANDOFF_SIGNATURE 0x534C5455UL
#define JTMOS_BOOT_UTILS_HANDOFF_VERSION   1UL
void BootUtilsRamInit(void);
DWORD BootUtilsRamSize(void);
int BootUtilsRamRead(DWORD offset, void *dst, DWORD length);
#endif
