/*
 * JTMOS runtime x86 CPU feature detection.
 *
 * The kernel itself is compiled for i486.  Optional accelerators are selected
 * only after this file has proved CPUID availability and the required feature
 * bits.  This lets the same kernel boot on old i486-class hardware while using
 * SSE3 on newer x86 CPUs.
 */
#include "kernel32.h"

JTMOS_CPU_INFO_K jtmos_cpu_info;

static unsigned long cpu_read_eflags(void)
{
    unsigned long f;
    __asm__ __volatile__("pushfl; popl %0" : "=r"(f));
    return f;
}

static void cpu_write_eflags(unsigned long f)
{
    __asm__ __volatile__("pushl %0; popfl" : : "r"(f) : "cc", "memory");
}

static int cpu_instruction_cpuid_available(void)
{
    const unsigned long id = (1UL << 21);
    unsigned long oldf, newf, testf;

    oldf = cpu_read_eflags();
    testf = oldf ^ id;
    cpu_write_eflags(testf);
    newf = cpu_read_eflags();
    cpu_write_eflags(oldf);
    return ((newf ^ oldf) & id) != 0;
}

static void cpu_cpuid(unsigned long leaf, unsigned long subleaf,
    unsigned long *a, unsigned long *b, unsigned long *c, unsigned long *d)
{
    unsigned long ra, rb, rc, rd;
    __asm__ __volatile__("cpuid"
        : "=a"(ra), "=b"(rb), "=c"(rc), "=d"(rd)
        : "a"(leaf), "c"(subleaf)
        : "memory");
    if(a) *a=ra; if(b) *b=rb; if(c) *c=rc; if(d) *d=rd;
}

static void cpu_enable_sse_os_support(void)
{
    unsigned long cr0, cr4;

    /* Only called on CPUs that advertised SSE+FXSR, hence CR4 and these bits
     * are architecturally available.  Keep the x87 MP policy enabled, clear
     * EM/TS, then permit FXSAVE/XMM state and SIMD exceptions. */
    __asm__ __volatile__("movl %%cr0,%0" : "=r"(cr0));
    cr0 |= (1UL << 1);           /* MP */
    cr0 &= ~(1UL << 2);          /* !EM */
    cr0 &= ~(1UL << 3);          /* !TS during early kernel */
    __asm__ __volatile__("movl %0,%%cr0" : : "r"(cr0) : "memory");

    __asm__ __volatile__("movl %%cr4,%0" : "=r"(cr4));
    cr4 |= (1UL << 9);           /* OSFXSR */
    cr4 |= (1UL << 10);          /* OSXMMEXCPT */
    __asm__ __volatile__("movl %0,%%cr4" : : "r"(cr4) : "memory");
    __asm__ __volatile__("clts" : : : "memory");

    jtmos_cpu_info.features |= JTMOS_CPUF_SSE_OS;
}

void cpuEarlyInit(void)
{
    unsigned long a,b,c,d;
    unsigned long base_family, ext_family, base_model, ext_model;
    char *v;
    int i;

    /* No libc memset here: this function deliberately initializes the state
     * before optimized memset/memcpy are allowed to dispatch. */
    v=(char *)&jtmos_cpu_info;
    for(i=0;i<(int)sizeof(jtmos_cpu_info);i++) v[i]=0;
    jtmos_cpu_info.vendor[0]='i'; jtmos_cpu_info.vendor[1]='4';
    jtmos_cpu_info.vendor[2]='8'; jtmos_cpu_info.vendor[3]='6';
    jtmos_cpu_info.vendor[4]=0;

    if(!cpu_instruction_cpuid_available())
    {
        DebugSerialWrite("[CPU] CPUID unavailable; generic i486 path selected.\n");
        return;
    }

    jtmos_cpu_info.features |= JTMOS_CPUF_CPUID;
    cpu_cpuid(0,0,&a,&b,&c,&d);
    jtmos_cpu_info.max_basic_leaf=a;
    ((unsigned long *)jtmos_cpu_info.vendor)[0]=b;
    ((unsigned long *)jtmos_cpu_info.vendor)[1]=d;
    ((unsigned long *)jtmos_cpu_info.vendor)[2]=c;
    jtmos_cpu_info.vendor[12]=0;

    if(a<1)
    {
        DebugSerialWrite("[CPU] CPUID leaf 1 unavailable; generic i486 path selected.\n");
        return;
    }

    cpu_cpuid(1,0,&a,&b,&c,&d);
    jtmos_cpu_info.signature=a;
    base_family=(a>>8)&0x0f;
    ext_family=(a>>20)&0xff;
    base_model=(a>>4)&0x0f;
    ext_model=(a>>16)&0x0f;
    if(base_family==0x0f) base_family+=ext_family;
    if(base_family==0x06 || base_family==0x0f) base_model+=(ext_model<<4);
    jtmos_cpu_info.family=(unsigned char)base_family;
    jtmos_cpu_info.model=(unsigned char)base_model;
    jtmos_cpu_info.stepping=(unsigned char)(a&0x0f);

    if(d&(1UL<<0))  jtmos_cpu_info.features|=JTMOS_CPUF_FPU;
    if(d&(1UL<<24)) jtmos_cpu_info.features|=JTMOS_CPUF_FXSR;
    if(d&(1UL<<25)) jtmos_cpu_info.features|=JTMOS_CPUF_SSE;
    if(d&(1UL<<26)) jtmos_cpu_info.features|=JTMOS_CPUF_SSE2;
    if(c&(1UL<<0))  jtmos_cpu_info.features|=JTMOS_CPUF_SSE3;

    if((jtmos_cpu_info.features & (JTMOS_CPUF_FXSR|JTMOS_CPUF_SSE|JTMOS_CPUF_SSE2)) ==
       (JTMOS_CPUF_FXSR|JTMOS_CPUF_SSE|JTMOS_CPUF_SSE2))
        cpu_enable_sse_os_support();

    if(ENABLE_SSE3_ACCEL &&
       (jtmos_cpu_info.features&(JTMOS_CPUF_SSE3|JTMOS_CPUF_SSE_OS)) ==
       (JTMOS_CPUF_SSE3|JTMOS_CPUF_SSE_OS))
        jtmos_cpu_info.features|=JTMOS_CPUF_SSE3_ACCEL;

    DebugSerialWrite("[CPU] CPUID detected; runtime feature dispatch initialized.\n");
}

void cpuPrintInfo(void)
{
    printk("CPU: vendor=%s family=%u model=%u stepping=%u features=0x%x\n",
        jtmos_cpu_info.vendor,
        (unsigned)jtmos_cpu_info.family,
        (unsigned)jtmos_cpu_info.model,
        (unsigned)jtmos_cpu_info.stepping,
        (unsigned)jtmos_cpu_info.features);
    if(cpuSSE3AccelerationEnabled())
        printk("CPU: SSE3 runtime acceleration enabled (generic i486 fallback retained).\n");
    else
        printk("CPU: generic i486 memory/pixel path active.\n");
}

unsigned long cpuFeatureMask(void) { return jtmos_cpu_info.features; }
int cpuHasFeature(unsigned long f) { return (jtmos_cpu_info.features&f)==f; }
int cpuSSE3AccelerationEnabled(void)
{
    return cpuHasFeature(JTMOS_CPUF_SSE3_ACCEL);
}
