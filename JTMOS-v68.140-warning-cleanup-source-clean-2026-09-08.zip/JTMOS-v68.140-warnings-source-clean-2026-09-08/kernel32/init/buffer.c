//============================================================
// FIFO buffer functions.
// (C) 2003-2005 by Jari Tuominen.
//============================================================
#include "kernel32.h"
#include "buffer.h"

// Initialize buffer
void InitBuffer(FBUF *b)
{
	// Define head & tail.
	b->head=	0; // used for WRITING
	b->tail=	0; // used for READING	
	// Define buffered count.
	b->count=	0;
	// Total count.
	b->total=	0;
	// Set magic.
	b->magic=	FIFOBUF_MAGIC;
}

// Create a new buffer
void CreateBuffer(FBUF *b, int len)
{
	static BYTE tmp[8192];

	//
	if(mallocOK)
	{
		// Define allocation amount and allocate
		b->l_buf =	len;
		b->buf =	malloc(b->l_buf);
		// Initialize buffer
		InitBuffer(b);
	}
	else
	{
		//
		memset(b, 0, sizeof(FBUF));
	}
}

// For buffer reading.
int TailForward(FBUF *b)
{
	//
	if(b->count)
	{
		//
		b->count--;
		b->tail++;

		//
		if(b->tail >= b->l_buf)
			// Loop at beginning.
			b->tail=0;
		return 0;
	}
		// Nothing there to get
	else	return 1;
}

// For buffer writing.
int HeadForward(FBUF *b)
{
	//
	if(b->count<b->l_buf)
	{
		//
		b->count++;
		b->head++;
		if(b->head >= b->l_buf)
			// Loop at beginning.
			b->head=0;
		return 0;
	}
		// Buffer already full
	else	return 1;
}

//------------------------------------------------------------
int PushBuffer(FBUF *b, BYTE byte1)
{
	//
	if(b==NULL || b->buf==NULL || b->magic != FIFOBUF_MAGIC)
		return 2;

	//
	if(b->magic!=0xFCE2E37B)
		// Magic mistach(error!)
		return 1;
	if( !HeadForward(b) )
		{
			//
			b->buf[b->head % b->l_buf] = byte1;
			// Increase total
			b->total++;
			return 0; // push ok
		}
		else	return 1; // buffer full
}

//------------------------------------------------------------
int PopBuffer(FBUF *b)
{
	static char str[8192];

	//
	if(b==NULL || b->buf==NULL || b->magic != FIFOBUF_MAGIC)
		return -2;

	//
	if( !TailForward(b) )
	{
		//
	/*	sprintf(str, "[POPBUFFER-%s-%c]\n",
			thread_name[nr_curthread],
			b->buf[b->tail % b->l_buf]);
		writetext(&screens[0], str);*/
		// Increase total.
		b->total++;
		// pop ok
		return b->buf[b->tail % b->l_buf];
	}
	else
		// buffer empty
		return -1;
}


//------------------------------------------------------------
//
// Quick access...
//

//
int GetBuffer(FBUF *b)
{
	int flags,input_byte;

	//
	flags = get_eflags();
	disable();
	input_byte = PopBuffer(b);
	set_eflags(flags);
	return input_byte;
}

//
int PutBuffer(FBUF *b, int output_byte)
{
	int v,flags;

	//
	flags = get_eflags();
	disable();
	v = PushBuffer(b, output_byte);
	set_eflags(flags);
	return v;
}

// Push a WORD into buffer atomically.
//
// Keyboard and terminal FIFOs store one logical key as two bytes.  The old
// implementation could enqueue the low byte when only one byte of capacity
// remained and then fail on the high byte.  Every later PopBufferW() was then
// byte-shifted, effectively destroying the complete keyboard stream.
int PushBufferW(FBUF *b, WORD w)
{
	int flags,rv=0;

	if(b==NULL || b->buf==NULL || b->magic!=FIFOBUF_MAGIC)
		return 2;

	flags=get_eflags();
	disable();
	/* Recover a FIFO left with one orphan byte by an older non-atomic
	 * PushBufferW().  The orphan was appended at head, so rolling head back
	 * preserves every complete WORD already queued ahead of it. */
	if(b->count&1) {
		b->head--;
		if(b->head<0) b->head=b->l_buf-1;
		b->count--;
	}
	if(b->l_buf-b->count < 2)
		rv=1;
	else {
		rv=PushBuffer(b,w&255);
		if(!rv) rv=PushBuffer(b,(w>>8)&255);
	}
	set_eflags(flags);
	return rv;
}

// Pop one complete WORD atomically.  Never consume a half key.
int PopBufferW(FBUF *b)
{
	int flags,w,bit;

	if(b==NULL || b->buf==NULL || b->magic!=FIFOBUF_MAGIC)
		return -2;

	flags=get_eflags();
	disable();
	if(b->count < 2) {
		set_eflags(flags);
		return -1;
	}
	w=PopBuffer(b);
	bit=PopBuffer(b);
	set_eflags(flags);
	if(w<0 || bit<0) return -1;
	return w|(bit<<8);
}

// Returns amount of bytes wrote.
int ReadBuffer(FBUF *b, BYTE *buf, int len)
{
	int i,d;

	// Loop through
	for(i=0; i<len; i++)
	{
		if( (d=PopBuffer(b))==-1 )
			// Out of space
			break;
		buf[i]=d;
	}

	// Return amount of bytes read.
	return i;
}

// Returns amount of bytes read
int WriteBuffer(FBUF *b, BYTE *buf, int len)
{
	int i,d;

	// Loop through
	for(i=0; i<len; i++)
	{
		if( PushBuffer(b, buf[i]) )
			// Out of data
			break;
	}

	// Return amount of bytes written.
	return i;
}

//
