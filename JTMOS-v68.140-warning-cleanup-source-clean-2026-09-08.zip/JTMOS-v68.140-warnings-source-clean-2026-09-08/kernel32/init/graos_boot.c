/*
 * GraOS self-contained boot test support, 2026.
 *
 * The legacy boot loader can safely load only the native kernel below the
 * 640K conventional-memory boundary.  GraOS files therefore live in a small
 * package after the fixed kernel area on the boot floppy.  Once the floppy
 * and RAM-disk drivers exist, this code copies that package into a freshly
 * formatted RAM JTMFS and launches /bin/graos.bin through centralprocess.
 */
#include "kernel32.h"
#include "jtmfs.h"
#include "jtmfat.h"
#include "root.h"
#include "directfileaccess.h"
#include "centralprocess.h"
#include "driver_rw.h"
#include "driver_api.h"
#include "graos_boot.h"
#include "vesa.h"
#include "sqa.h"
#include "nzip.h"
#include "ps2mouse.h"
#include "keropt.h"

#define GRAOS_PACKAGE_SECTOR 1044
#define GRAOS_PACKAGE_MAGIC  "GRAOSPK1"
#define GRAOS_PACKAGE_COUNT_MAX 8
#define GRAOS_ENTRY_OFFSET   16
#define GRAOS_ENTRY_SIZE     40
#define GRAOS_NAME_SIZE      32
#define GRAOS_BLOCK_SIZE     512

static int graos_boot_started = 0;

static unsigned long graos_rd32(const unsigned char *p)
{
    return ((unsigned long)p[0]) |
           ((unsigned long)p[1] << 8) |
           ((unsigned long)p[2] << 16) |
           ((unsigned long)p[3] << 24);
}

static int install_package_file(int floppy, const char *name,
                                unsigned long rel_sector,
                                unsigned long bytes)
{
    unsigned char block[GRAOS_BLOCK_SIZE];
    char path[48];
    unsigned long done = 0;
    int chunk, r;

    if(!name[0] || strchr(name, '/') || strchr(name, '\\')) return 1;
    sprintf(path, "/bin/%s", name);

    if(exist(path)) unlink(path);
    r = createfile(path);
    if(r) return 2;

    while(done < bytes)
    {
        r = readblock(floppy,
                      GRAOS_PACKAGE_SECTOR + (int)rel_sector +
                      (int)(done / GRAOS_BLOCK_SIZE), block);
        if(r) return 10 + r;

        chunk = (int)(bytes - done);
        if(chunk > GRAOS_BLOCK_SIZE) chunk = GRAOS_BLOCK_SIZE;
        r = writefile(path, (char *)block, (int)done, chunk);
        if(r) return 20 + r;
        done += chunk;
    }

    r = setsize(path, (int)bytes);
    if(r) return 30 + r;
    return 0;
}


int GraOSBootReady(void)
{
    /*
     * Graphics no longer has to be ACTIVE during kernel boot.  A prepared
     * VBox/BGA LFB is sufficient; graos.bin performs the actual mode switch
     * through SYS_graosgraphics after it starts.
     */
    if(!VesaGraOSAvailable())
    {
        printk("GraOS boot: no 1024x768x32 graphics provider is available; GUI will not start.\n");
        return 0;
    }
    return 1;
}

static int GraOSBootInstallLegacyPackage(void)
{
    if(!GraOSBootReady()) return 100;
    unsigned char header[GRAOS_BLOCK_SIZE];
    char name[GRAOS_NAME_SIZE + 1];
    unsigned long count, rel_sector, bytes;
    int floppy, ram, rootdb, i, j, r;

    printk("GraOS boot: reading boot package from floppy...\n");
    floppy = driver_getdevicenrbyname("floppy");
    if(floppy < 0) return 10;
    if(getblocksize(floppy) != GRAOS_BLOCK_SIZE) return 11;

    r = readblock(floppy, GRAOS_PACKAGE_SECTOR, header);
    if(r) return 20 + r;
    if(memcmp(header, GRAOS_PACKAGE_MAGIC, 8)) return 30;

    count = graos_rd32(header + 8);
    if(count == 0 || count > GRAOS_PACKAGE_COUNT_MAX) return 31;

    printk("GraOS boot: creating RAM filesystem (%d files)...\n", (int)count);
    ram = driver_getdevicenrbyname("ram");
    if(ram < 0) return 40;

    r = jtmfs_formatdrive(ram);
    if(r) return 50 + r;

    mount_root(ram);
    rootdb = jtmfat_getrootdir(ram);
    SetThreadDNR(GetCurrentThread(), ram);
    SetThreadDB(GetCurrentThread(), rootdb);

    if(!exist("/bin"))
    {
        r = createdirectory("/bin");
        if(r) return 60 + r;
    }

    for(i = 0; i < (int)count; i++)
    {
        int e = GRAOS_ENTRY_OFFSET + i * GRAOS_ENTRY_SIZE;
        for(j = 0; j < GRAOS_NAME_SIZE; j++)
        {
            name[j] = (char)header[e + j];
            if(!name[j]) break;
        }
        name[GRAOS_NAME_SIZE] = 0;
        if(j == GRAOS_NAME_SIZE) name[GRAOS_NAME_SIZE] = 0;

        rel_sector = graos_rd32(header + e + 32);
        bytes      = graos_rd32(header + e + 36);
        if(rel_sector < 1 || bytes == 0) return 70;

        printk("GraOS boot: installing %s (%d bytes)\n", name, (int)bytes);
        r = install_package_file(floppy, name, rel_sector, bytes);
        if(r)
        {
            printk("GraOS boot: install failed: %s (%d)\n", name, r);
            return 80 + r;
        }
    }

    if(sync()!=0)
        return 95;
    printk("GraOS boot: legacy RAM filesystem ready.\n");
    return 0;
}

static int graos_boot_core_files_ready(void)
{
    static const char *required[]={
        "/bin/graos.bin",
        "/bin/terminal.bin",
        "/bin/sqsh.bin",
        "/bin/filer.bin",
        "/bin/controlpanel.bin",
        "/bin/launcher.bin",
        "/bin/edit.bin",
        "/bin/top.bin",
        NULL
    };
    int i;
    for(i=0;required[i]!=NULL;i++)
        if(!exist(required[i]))
        {
            printk("GraOS boot: required startup file missing: %s\n",required[i]);
            return 0;
        }
    return 1;
}

static int GraOSBootInstallSystemPayload(void)
{
    char *outer_argv[]={"sqa","sys","-q","-o","/bin"};
    char *inner_argv[]={"sqa","/bin/install.img","-q","-o","/bin"};
    int ram,sys,rootdb,r;

    sys=driver_getdevicenrbyname("sys");
    if(sys<0) return 10;
    ram=driver_getdevicenrbyname("ram");
    if(ram<0) return 11;

    printk("GraOS boot: creating RAM JTMFS for system utilities ...\n");
    r=jtmfs_formatdrive(ram);
    if(r) return 20+r;
    mount_root(ram);
    rootdb=jtmfat_getrootdir(ram);
    if(rootdb<=0) return 30;
    SetThreadDNR(GetCurrentThread(),ram);
    SetThreadDB(GetCurrentThread(),rootdb);

    if(!exist("/bin"))
    {
        r=createdirectory("/bin");
        if(r) return 31;
    }

    /* sys: aliases the separate root/system medium (B: preferred, ATAPI
     * fallback). First extract install.img.nz, then decode/extract the inner
     * system SQA into the RAM root.  The boot floppy itself contains no sys:
     * partition. */
    printk("GraOS boot: extracting root-media bootstrap from sys: to /bin ...\n");
    r=sqa_main(5,outer_argv);
    if(r) return 40+r;
    if(!exist("/bin/install.img.nz")) return 50;

    printk("GraOS boot: decompressing core desktop payload ...\n");
    r=nzip_uncompress("/bin/install.img.nz","/bin/install.img");
    if(r) return 60+r;

    printk("GraOS boot: installing core applications ...\n");
    r=sqa_main(5,inner_argv);
    if(r) return 70+r;

    (void)deletefile("/bin/install.img");
    (void)deletefile("/bin/install.img.nz");

    if(!graos_boot_core_files_ready()) return 80;

    /* Persist the RAM filesystem's own directory/FAT state as well.  This is
     * needed even for ram:, because DIRDB entries may later be evicted. */
    if(syncdev(ram)!=0) return 90;
    printk("GraOS boot: sys: core desktop installed into RAM /bin.\n");
    return 0;
}

int GraOSBootInstall(void)
{
    int r;
    if(!GraOSBootReady()) return 100;

    r=GraOSBootInstallSystemPayload();
    if(r==0) return 0;

    printk("GraOS boot: sys: bootstrap failed (%d); trying legacy GRAOSPK1 package.\n",r);
    return GraOSBootInstallLegacyPackage();
}

int GraOSBootStarted(void)
{
    return graos_boot_started;
}

int GraOSBootStart(void)
{
    int ram,rootdb,pid,ter;

    graos_boot_started = 0;

    if(!GraOSBootReady()) return 100;

    /* AUX was deliberately kept disabled while SMSH was the rescue console.
     * Attach the shared-controller mouse only when the GUI actually needs it. */
    if(PS2MOUSE_ENABLED)
    {
        printk("GraOS boot: preparing deferred PS/2 mouse.\n");
        if(ps2mouse_prepare_graos())
            printk("GraOS boot: PS/2 mouse attach failed; continuing keyboard-only.\n");
    }
    ram = driver_getdevicenrbyname("ram");
    rootdb = jtmfat_getrootdir(ram);

    ter=NewTerminal();
    if(ter<0) {
        printk("GraOS boot: cannot allocate keyboard terminal.\n");
        StartShellProcess();
        return 1;
    }

    printk("GraOS boot: launching /bin/graos.bin on input terminal %d ...\n",ter);
    pid = centralprocess_exec("/bin/graos.bin", "/bin/graos.bin",
                              ram, rootdb, "/bin", ter);
    if(!pid)
    {
        FreeTerminal(ter);
        printk("GraOS boot: GUI launch failed; starting recovery shell.\n");
        StartShellProcess();
        return 1;
    }
    /* Kernel-owned capability bit: process names are user-controlled and
     * therefore must never authorize cross-process framebuffer access. */
    SetThreadType(pid,GetThreadType(pid)|THREAD_TYPE_SERVICE);
    SetTerminalOwner(ter,pid);
    if(SwitchUserTerminal(ter))
        printk("GraOS boot: warning: cannot focus GUI terminal %d.\n",ter);
    graos_boot_started = 1;
    printk("GraOS boot: GUI process PID=%d, keyboard terminal=%d.\n", pid,ter);
    return 0;
}
