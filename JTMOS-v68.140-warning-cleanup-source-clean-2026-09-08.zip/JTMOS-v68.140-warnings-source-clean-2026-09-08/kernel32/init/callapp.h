#ifndef __INCLUDED_CALLAPP_H__
#define __INCLUDED_CALLAPP_H__

void
    callapp(void *appcode);

void
    callapp1(void *appcode, char waitUntilExits);
void callappex(void *appcode, char waitUntilExits, char term);

//
void ps(void);

#endif

