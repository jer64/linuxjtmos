//////////////////////////////////////////////////////////////////////////////////
// vesa.c
// VESA / shared Linear Frame Buffer Support.
// (C) 2008 by Jari Tuominen.
// Boot/paging integration fixes 2026.
//////////////////////////////////////////////////////////////////////////////////
#include "kernel32.h"
#include "paging.h"
#include "initsystem.h"
#ifdef GRAOS
#include "graos.h"
#include "directdraw.h"
#endif
#include "vesa.h"
#include "sysvga.h"
#include "vga.h"
#include "vboxbga.h"
#include "nv6150.h"

/* Legacy colour numbers are resolved through mcga_color_to_rgba(). */

BYTE *vesa_frame_buf = NULL;
DWORD vesa_frame_buf_bytes = 0;
int vesa_enabled = FALSE;
int vesa_boot_graphics = FALSE;
int vesa_width = 0;
int vesa_height = 0;
int vesa_bpp = 0;
int vesa_pitch = 0;
int vesa_text_console_enabled = FALSE;
static int vesa_text_gfx_provider = VESA_TEXT_GFX_NONE;
WORD vesa_mode_attributes = 0;
BYTE *vb = NULL;
BYTE *vesainfo = (BYTE *)0x4000;
int vesa_red_mask_size=8,vesa_red_field_pos=16;
int vesa_green_mask_size=8,vesa_green_field_pos=8;
int vesa_blue_mask_size=8,vesa_blue_field_pos=0;
int vesa_alpha_mask_size=8,vesa_alpha_field_pos=24;

static WORD vesa_u16(int off)
{
    BYTE *m;
    m = (BYTE *)0x4000;
    return (WORD)((WORD)m[off] | ((WORD)m[off+1] << 8));
}

static DWORD vesa_u32(int off)
{
    BYTE *m;
    m = (BYTE *)0x4000;
    return (DWORD)m[off] |
           ((DWORD)m[off+1] << 8) |
           ((DWORD)m[off+2] << 16) |
           ((DWORD)m[off+3] << 24);
}

//---------------------------------------------------------------------------------------
/*
 * VESA text console
 * -----------------
 * The traditional JTMOS terminal remains an 80x25 array of VGA/EGA character
 * cells (character byte + attribute byte).  In graphics mode that logical
 * B8000-style screen is RAM backed and rendered into the linear framebuffer.
 *
 * 80 * 8  = 640 pixels
 * 25 * 16 = 400 pixels
 *
 * The legacy 80x25 terminal is centred inside the active indexed LFB.  At the
 * 1024x768 default this leaves generous borders; the 640x480 recovery mode is
 * also large enough.  No BIOS or VGA text-mode register access is required
 * after VESA activation.
 */
#define VESA_TEXT_COLS       80
#define VESA_TEXT_ROWS       25
#define VESA_TEXT_CHAR_W      8
#define VESA_TEXT_CHAR_H     16
#define VESA_TEXT_WIDTH      (VESA_TEXT_COLS * VESA_TEXT_CHAR_W)
#define VESA_TEXT_HEIGHT     (VESA_TEXT_ROWS * VESA_TEXT_CHAR_H)

static SCREEN *vesa_last_cursor_screen = NULL;
static int vesa_last_cursor_cell = -1;

/* Boot-time VESA hourglass overlay.  The logical 80x25 console remains the
 * authoritative backing store; this is only a small LFB overlay drawn on top
 * of it while the kernel/SMSH bootstrap is running.  GraOS permanently stops
 * the overlay before taking ownership of the framebuffer. */
#define VESA_HOURGLASS_W  40
#define VESA_HOURGLASS_H  56
static int vesa_boot_hourglass_enabled = FALSE;
static int vesa_boot_hourglass_finished = FALSE;
static unsigned int vesa_boot_hourglass_phase = 0;
static unsigned int vesa_boot_hourglass_activity = 0;
static int vesa_hourglass_cell_overlap(int cell);
static void vesa_text_draw_cell(SCREEN *s, int cell, int cursor_override);

static DWORD vesa_chan(BYTE v,int size,int pos)
{
    DWORD maxv;
    if(size<=0 || pos<0 || pos>31) return 0;
    if(size>=8) maxv=255; else maxv=(1UL<<size)-1UL;
    return (((DWORD)v*maxv+127UL)/255UL)<<pos;
}

static DWORD vesa_native_rgb(BYTE r,BYTE g,BYTE b)
{
    DWORD p=vesa_chan(r,vesa_red_mask_size,vesa_red_field_pos) |
            vesa_chan(g,vesa_green_mask_size,vesa_green_field_pos) |
            vesa_chan(b,vesa_blue_mask_size,vesa_blue_field_pos);
    if(vesa_alpha_mask_size>0) {
        DWORD amax=(vesa_alpha_mask_size>=8)?255UL:((1UL<<vesa_alpha_mask_size)-1UL);
        p|=amax<<vesa_alpha_field_pos;
    }
    return p;
}


/* Fast presentation path for the overwhelmingly common 32-bit BGR(A/X) LFB.
 * GraOS stores DWORD pixels as little-endian R,G,B,A, while VBox/Bochs BGA and
 * standard VBE 8:8:8 modes normally expose B,G,R,X/A bytes.  The old generic
 * path called vesa_chan() three times per pixel, including integer division;
 * at 1024x768 and an animated intro that meant millions of divisions/frame. */
static int vesa_is_bgra8888(void)
{
    return vesa_red_mask_size==8 && vesa_red_field_pos==16 &&
           vesa_green_mask_size==8 && vesa_green_field_pos==8 &&
           vesa_blue_mask_size==8 && vesa_blue_field_pos==0 &&
           (vesa_alpha_mask_size==0 ||
            (vesa_alpha_mask_size==8 && vesa_alpha_field_pos==24));
}

static DWORD vesa_rgba_to_bgra8888(DWORD p)
{
    DWORD q;
    q=((p & 0x000000ffUL)<<16) |
      ( p & 0x0000ff00UL)      |
      ((p & 0x00ff0000UL)>>16);
    if(vesa_alpha_mask_size==8) q|=(p & 0xff000000UL);
    return q;
}

static DWORD vesa_mcga_color(int c)
{
    DWORD rgba=mcga_color_to_rgba(c);
    BYTE r=(BYTE)(rgba&255U);
    BYTE g=(BYTE)((rgba>>8)&255U);
    BYTE b=(BYTE)((rgba>>16)&255U);
    return vesa_native_rgb(r,g,b);
}

static int vesa_text_ready(void)
{
    return vesa_text_console_enabled && vesa_enabled &&
           vesa_frame_buf != NULL && vesa_bpp == 32 &&
           vesa_pitch >= VESA_TEXT_WIDTH*4 &&
           vesa_width >= VESA_TEXT_WIDTH &&
           vesa_height >= VESA_TEXT_HEIGHT;
}

static void vesa_clear_native(DWORD color)
{
    int x,y;
    if(!vesa_frame_buf || vesa_width<=0 || vesa_height<=0 || vesa_pitch<vesa_width*4) return;
    for(y=0;y<vesa_height;y++) {
        DWORD *d=(DWORD*)(vesa_frame_buf+y*vesa_pitch);
        for(x=0;x<vesa_width;x++) d[x]=color;
    }
}

static void vesa_fill_rect_native(int x,int y,int w,int h,DWORD color)
{
    int xx,yy;
    if(!vesa_frame_buf || w<=0 || h<=0) return;
    if(x<0) { w+=x; x=0; }
    if(y<0) { h+=y; y=0; }
    if(x+w>vesa_width) w=vesa_width-x;
    if(y+h>vesa_height) h=vesa_height-y;
    if(w<=0 || h<=0) return;
    for(yy=0;yy<h;yy++) {
        DWORD *d=(DWORD*)(vesa_frame_buf+(y+yy)*vesa_pitch+x*4);
        for(xx=0;xx<w;xx++) d[xx]=color;
    }
}

static void vesa_put_native_pixel(int x,int y,DWORD color)
{
    DWORD *d;
    if(!vesa_frame_buf || x<0 || y<0 || x>=vesa_width || y>=vesa_height) return;
    d=(DWORD*)(vesa_frame_buf+y*vesa_pitch+x*4);
    *d=color;
}

static int vesa_hourglass_bounds(int *px,int *py)
{
    if(!vesa_text_ready()) return FALSE;
    if(px) *px=(vesa_width-VESA_HOURGLASS_W)/2;
    if(py) *py=(vesa_height-VESA_HOURGLASS_H)/2;
    return TRUE;
}

static void vesa_boot_hourglass_restore_background(void)
{
    SCREEN *scr; int cell;
    if(!vesa_text_ready() || visible_terminal<0 || visible_terminal>=N_MAX_SCREENS) return;
    scr=&screens[visible_terminal];
    if(scr->buf==NULL) return;
    for(cell=0;cell<VESA_TEXT_COLS*VESA_TEXT_ROWS;cell++)
        if(vesa_hourglass_cell_overlap(cell)) vesa_text_draw_cell(scr,cell,-1);
}

static void vesa_boot_hourglass_draw(void)
{
    int px,py,ix,iy,y,left,right,x;
    int top_start,bottom_start;
    DWORD edge,shine,sand,shadow;

    if(!vesa_boot_hourglass_enabled || !vesa_text_ready()) return;
    if(!vesa_hourglass_bounds(&px,&py)) return;

    /* True transparency: first restore the backing 80x25 text cells.  The
     * hourglass itself never paints an opaque rectangle. */
    vesa_boot_hourglass_restore_background();

    edge=vesa_native_rgb(12,12,12);
    shine=vesa_native_rgb(245,245,245);
    shadow=vesa_native_rgb(96,96,96);
    sand=vesa_native_rgb(232,176,32);
    ix=px+4; iy=py+4;

    /* AmigaOS/Workbench-inspired pointer-sized hourglass. */
    vesa_fill_rect_native(ix+1,iy+1,31,2,shadow);
    vesa_fill_rect_native(ix,iy,31,2,edge);
    vesa_fill_rect_native(ix+2,iy+2,27,1,shine);
    vesa_fill_rect_native(ix+1,iy+45,31,2,shadow);
    vesa_fill_rect_native(ix,iy+44,31,2,edge);
    vesa_fill_rect_native(ix+2,iy+43,27,1,shine);

    for(y=0;y<19;y++) {
        int inset=(y*12)/18;
        left=ix+3+inset; right=ix+27-inset;
        vesa_put_native_pixel(left,iy+3+y,edge);
        vesa_put_native_pixel(right,iy+3+y,edge);
        if(left+1<right) vesa_put_native_pixel(left+1,iy+3+y,shine);
    }
    for(y=0;y<20;y++) {
        int inset=((19-y)*12)/19;
        left=ix+3+inset; right=ix+27-inset;
        vesa_put_native_pixel(left,iy+23+y,edge);
        vesa_put_native_pixel(right,iy+23+y,edge);
        if(left+1<right) vesa_put_native_pixel(left+1,iy+23+y,shine);
    }
    vesa_put_native_pixel(ix+15,iy+22,edge);
    vesa_put_native_pixel(ix+16,iy+22,edge);

    top_start=7+(int)vesa_boot_hourglass_phase*3;
    if(top_start>17) top_start=17;
    for(y=top_start;y<=18;y++) {
        int inset=((y-3)*12)/18;
        left=ix+4+inset; right=ix+26-inset;
        for(x=left;x<=right;x++) vesa_put_native_pixel(x,iy+y,sand);
    }
    bottom_start=41-(int)vesa_boot_hourglass_phase*4;
    if(bottom_start<26) bottom_start=26;
    for(y=bottom_start;y<=41;y++) {
        int inset=((42-y)*12)/19;
        left=ix+4+inset; right=ix+26-inset;
        for(x=left;x<=right;x++) vesa_put_native_pixel(x,iy+y,sand);
    }
    if(vesa_boot_hourglass_phase<3) {
        vesa_put_native_pixel(ix+15,iy+24,sand);
        if(vesa_boot_hourglass_phase&1) vesa_put_native_pixel(ix+15,iy+26,sand);
    }
}

static int vesa_hourglass_cell_overlap(int cell)
{
    int col,row,cx,cy,px,py;
    if(cell<0 || cell>=VESA_TEXT_COLS*VESA_TEXT_ROWS) return FALSE;
    col=cell%VESA_TEXT_COLS; row=cell/VESA_TEXT_COLS;
    cx=(vesa_width-VESA_TEXT_WIDTH)/2+col*VESA_TEXT_CHAR_W;
    cy=(vesa_height-VESA_TEXT_HEIGHT)/2+row*VESA_TEXT_CHAR_H;
    px=(vesa_width-VESA_HOURGLASS_W)/2;
    py=(vesa_height-VESA_HOURGLASS_H)/2;
    return cx < px+VESA_HOURGLASS_W && cx+VESA_TEXT_CHAR_W > px &&
           cy < py+VESA_HOURGLASS_H && cy+VESA_TEXT_CHAR_H > py;
}

static void vesa_boot_hourglass_pulse(int cell)
{
    unsigned int oldphase;
    if(!vesa_boot_hourglass_enabled || !vesa_text_ready()) return;
    oldphase=vesa_boot_hourglass_phase;
    vesa_boot_hourglass_activity++;
    if((vesa_boot_hourglass_activity & 31U)==0)
        vesa_boot_hourglass_phase=(vesa_boot_hourglass_phase+1U)&3U;
    if(oldphase!=vesa_boot_hourglass_phase || vesa_hourglass_cell_overlap(cell))
        vesa_boot_hourglass_draw();
}

void VesaBootHourglassEnable(int enabled)
{
    if(enabled) {
        if(vesa_boot_hourglass_finished) return;
        vesa_boot_hourglass_enabled=TRUE;
        vesa_boot_hourglass_draw();
    } else {
        vesa_boot_hourglass_enabled=FALSE;
        if(vesa_text_ready()) VesaTextConsoleRefresh();
    }
}

void VesaBootHourglassStop(void)
{
    vesa_boot_hourglass_enabled=FALSE;
    vesa_boot_hourglass_finished=TRUE;
    if(vesa_text_ready()) VesaTextConsoleRefresh();
}

static void vesa_text_draw_cell(SCREEN *s, int cell, int cursor_override)
{
    const BYTE *font,*glyph;
    DWORD *dst,fg,bg;
    BYTE ch,attr,bits;
    int col,row,px,py,gx,gy,cursor;
    if(!vesa_text_ready() || s==NULL || s->buf==NULL) return;
    if(cell<0 || cell>=VESA_TEXT_COLS*VESA_TEXT_ROWS) return;
    col=cell%VESA_TEXT_COLS; row=cell/VESA_TEXT_COLS;
    px=(vesa_width-VESA_TEXT_WIDTH)/2+col*VESA_TEXT_CHAR_W;
    py=(vesa_height-VESA_TEXT_HEIGHT)/2+row*VESA_TEXT_CHAR_H;
    ch=(BYTE)s->buf[cell*2]; attr=(BYTE)s->buf[cell*2+1];
    fg=vesa_mcga_color(attr&0x0f); bg=vesa_mcga_color((attr>>4)&0x07);
    font=sysvga_get_system_font(); if(font==NULL)return;
    glyph=font+((DWORD)ch*VESA_TEXT_CHAR_H);
    cursor=(cursor_override>=0)?cursor_override:(s->updcur && s==&screens[visible_terminal] && s->id==GetInputTerminal() && col==s->curx && row==s->cury);
    for(gy=0;gy<VESA_TEXT_CHAR_H;gy++) {
        bits=glyph[gy]; dst=(DWORD*)(vesa_frame_buf+(py+gy)*vesa_pitch+px*4);
        for(gx=0;gx<VESA_TEXT_CHAR_W;gx++) dst[gx]=(bits&(0x80>>gx))?fg:bg;
    }
    if(cursor) for(gy=VESA_TEXT_CHAR_H-2;gy<VESA_TEXT_CHAR_H;gy++) {
        dst=(DWORD*)(vesa_frame_buf+(py+gy)*vesa_pitch+px*4);
        for(gx=0;gx<VESA_TEXT_CHAR_W;gx++) dst[gx]=fg;
    }
}

void VesaTextConsoleEnable(int enabled)
{
    vesa_text_console_enabled = enabled ? TRUE : FALSE;
    if(vesa_text_console_enabled)
        VesaTextConsoleRefresh();
}

void VesaTextConsoleRefresh(void)
{
    SCREEN *s;
    int cell;

    if(!vesa_text_ready())
        return;
    if(visible_terminal < 0 || visible_terminal >= N_MAX_SCREENS)
        return;

    s = &screens[visible_terminal];
    if(s->buf == NULL)
        return;

    /* Black border around the 640x400 text surface. */
    vesa_clear_native(vesa_mcga_color(BLACK));
    for(cell=0; cell<VESA_TEXT_COLS*VESA_TEXT_ROWS; cell++)
        vesa_text_draw_cell(s, cell, -1);

    vesa_last_cursor_screen = s;
    if(s->updcur && s->id==GetInputTerminal() && s->curx >= 0 && s->curx < VESA_TEXT_COLS &&
       s->cury >= 0 && s->cury < VESA_TEXT_ROWS)
        vesa_last_cursor_cell = s->cury*VESA_TEXT_COLS+s->curx;
    else
        vesa_last_cursor_cell = -1;

    vesa_boot_hourglass_draw();
}

void VesaTextConsoleCellChanged(SCREEN *s, long byte_offset)
{
    int cell;

    if(!vesa_text_ready() || s == NULL || s != &screens[visible_terminal])
        return;
    if(byte_offset < 0 || byte_offset >= VESA_TEXT_COLS*VESA_TEXT_ROWS*2)
        return;

    cell = (int)(byte_offset >> 1);
    vesa_text_draw_cell(s, cell, -1);
    vesa_boot_hourglass_pulse(cell);
}

void VesaTextConsoleCursorChanged(SCREEN *s)
{
    int cell;

    if(!vesa_text_ready() || s == NULL || s != &screens[visible_terminal])
        return;

    if(vesa_last_cursor_screen == s && vesa_last_cursor_cell >= 0)
        vesa_text_draw_cell(s, vesa_last_cursor_cell, FALSE);

    if(s->updcur && s->id==GetInputTerminal() && s->curx >= 0 && s->curx < VESA_TEXT_COLS &&
       s->cury >= 0 && s->cury < VESA_TEXT_ROWS)
    {
        cell = s->cury*VESA_TEXT_COLS+s->curx;
        vesa_text_draw_cell(s, cell, TRUE);
        vesa_last_cursor_cell = cell;
    }
    else
        vesa_last_cursor_cell = -1;

    vesa_last_cursor_screen = s;
}

void BlitCurrentTerminalToVesa(void)
{
    VesaTextConsoleRefresh();
}

// Legacy diagnostics retained, but never used by the early boot path.
static void flash(void)
{
    if(!vesa_enabled || vesa_frame_buf == NULL)
        return;
    sleep(1);
    vesa_clear_native(vesa_mcga_color(RED));
    sleep(1);
    vesa_clear_native(vesa_mcga_color(GREEN));
    sleep(1);
    vesa_clear_native(vesa_mcga_color(BLUE));
    sleep(1);
}

void flashy(DWORD ad)
{
    DWORD n;

    if(!vesa_enabled || vesa_frame_buf == NULL || ad >= vesa_frame_buf_bytes)
        return;
    n = (DWORD)vesa_pitch * 8;
    if(n > vesa_frame_buf_bytes-ad)
        n = vesa_frame_buf_bytes-ad;

    (void)n;
    if((ad&3)==0 && ad+4<=vesa_frame_buf_bytes) {
        DWORD *p=(DWORD*)(vesa_frame_buf+ad);
        *p=vesa_mcga_color(RED); *p=vesa_mcga_color(GREEN); *p=vesa_mcga_color(BLUE);
    }
}

//---------------------------------------------------------------------------------------
// Read and validate the 256-byte VBE ModeInfoBlock that boot32/boot.asm places
// at physical 0x4000.  This routine deliberately does NOT touch PhysBasePtr;
// pg_init() must first map the physical LFB into the active page tables.
int VesaBootHandoffPresent(void)
{
    volatile DWORD *sig = (volatile DWORD *)VESA_BOOT_HANDOFF_ADDR;
    return (*sig == VESA_BOOT_HANDOFF_SIGNATURE) ? TRUE : FALSE;
}

int VesaProbe(void)
{
    DWORD phys;
    DWORD bytes;
    WORD bank_pitch;
    WORD linear_pitch;
    int planes;
    int memory_model;

    vesa_enabled = FALSE;
    vesa_text_console_enabled = FALSE;
    vesa_boot_graphics = FALSE;
    vesa_frame_buf = NULL;
    vesa_frame_buf_bytes = 0;
    vb = NULL;

    if(!VesaBootHandoffPresent())
    {
        printk("VESA probe: boot32 handoff signature not present.\n");
        return FALSE;
    }

    vesa_mode_attributes = vesa_u16(0x00);
    bank_pitch = vesa_u16(0x10);
    vesa_width = (int)vesa_u16(0x12);
    vesa_height = (int)vesa_u16(0x14);
    planes = (int)vesainfo[0x18];
    vesa_bpp = (int)vesainfo[0x19];
    memory_model = (int)vesainfo[0x1b];
    phys = vesa_u32(0x28);
    linear_pitch = vesa_u16(0x32);
    vesa_pitch = linear_pitch ? (int)linear_pitch : (int)bank_pitch;
    vesa_red_mask_size=(int)vesainfo[0x1f]; vesa_red_field_pos=(int)vesainfo[0x20];
    vesa_green_mask_size=(int)vesainfo[0x21]; vesa_green_field_pos=(int)vesainfo[0x22];
    vesa_blue_mask_size=(int)vesainfo[0x23]; vesa_blue_field_pos=(int)vesainfo[0x24];
    vesa_alpha_mask_size=(int)vesainfo[0x25]; vesa_alpha_field_pos=(int)vesainfo[0x26];

    /* ModeAttributes D0: supported, D4: graphics, D7: linear framebuffer. */
    if((vesa_mode_attributes & 0x0091) != 0x0091)
    {
        printk("VESA probe: no supported graphics LFB (attrs=0x%x).\n",
            vesa_mode_attributes);
        return FALSE;
    }
    if(phys == 0 || vesa_width <= 0 || vesa_height <= 0 || vesa_pitch <= 0)
    {
        printk("VESA probe: invalid ModeInfoBlock.\n");
        return FALSE;
    }

    /* GraOS accepts direct-color 32 bpp only.  A 640x480x32 mode may be
     * used by the kernel text mirror for recovery, but Ring3 GraOS requires
     * the full 1024x768x32 geometry. */
    if(vesa_bpp != GRAOS_VESA_BPP ||
       vesa_pitch < vesa_width*4 ||
       planes != 1 || memory_model != 6 ||
       vesa_red_mask_size<=0 || vesa_green_mask_size<=0 || vesa_blue_mask_size<=0 ||
       !((vesa_width == GRAOS_VESA_WIDTH &&
          vesa_height == GRAOS_VESA_HEIGHT) ||
         (vesa_width == GRAOS_VESA_FALLBACK_WIDTH &&
          vesa_height == GRAOS_VESA_FALLBACK_HEIGHT)))
    {
        printk("VESA probe: unsupported direct-color mode %dx%dx%d pitch=%d planes=%d model=%d.\n",
            vesa_width, vesa_height, vesa_bpp, vesa_pitch, planes, memory_model);
        return FALSE;
    }
    if(vesa_width != GRAOS_VESA_WIDTH || vesa_height != GRAOS_VESA_HEIGHT)
        printk("VESA probe: using 640x480x32 recovery fallback; GraOS requires 1024x768x32.\n");

    if((DWORD)vesa_pitch > 0xffffffffUL/(DWORD)vesa_height)
    {
        printk("VESA probe: framebuffer size overflow.\n");
        return FALSE;
    }
    bytes = (DWORD)vesa_pitch * (DWORD)vesa_height;
    if(bytes == 0 || bytes > 16*1024*1024UL)
    {
        printk("VESA probe: unreasonable framebuffer size 0x%x.\n", bytes);
        return FALSE;
    }

    /* From this point onward the machine is known to be in a VBE graphics
     * mode selected by boot32.  Legacy B8000/CRTC text-console accesses must
     * stay disabled even though LFB rendering itself is not activated yet. */
    vesa_boot_graphics = TRUE;
    vb = (BYTE *)phys;
    vesa_frame_buf = vb;
    vesa_frame_buf_bytes = bytes;

    printk("VESA probe: %dx%dx%d pitch=%d LFB=0x%x bytes=0x%x attrs=0x%x.\n",
        vesa_width, vesa_height, vesa_bpp, vesa_pitch,
        vesa_frame_buf, vesa_frame_buf_bytes, vesa_mode_attributes);
    return TRUE;
}

/*
 * If a special boot32 build has already selected a VBE graphics mode, never
 * leave the machine on a black LFB while kernel text goes only to serial.
 * Paging is still disabled here, so the flat protected-mode address is the
 * physical LFB address supplied by VBE and can be rendered directly.
 */
int VesaEarlyTextActivate(void)
{
    if(!vesa_boot_graphics || vesa_frame_buf == NULL ||
       vesa_frame_buf_bytes == 0 || vesa_bpp != 32)
        return FALSE;

    vesa_clear_native(vesa_native_rgb(0,0,0));
    vesa_enabled = TRUE;
    vesa_early_serial_only = FALSE;
    vesa_text_console_enabled = TRUE;
    if(!vesa_boot_hourglass_finished) vesa_boot_hourglass_enabled=TRUE;
    VesaTextConsoleRefresh();
    DebugSerialWrite("[VESA] boot graphics active: text console mirrored to LFB.\n");
    return TRUE;
}

// Activate screen writes only after pg_init() has installed the LFB mapping.
int VesaActivate(void)
{

    if(vesa_frame_buf == NULL || vesa_frame_buf_bytes == 0)
        return FALSE;
    if(!paging_enabled)
    {
        printk("VESA activate: deferred until paging is enabled.\n");
        return FALSE;
    }

    /* 32-bpp direct colour: no VGA DAC palette is involved. */
    vesa_clear_native(vesa_native_rgb(0,0,0));
    vesa_enabled = TRUE;
    vesa_early_serial_only = FALSE;
    vesa_text_console_enabled = TRUE;
    if(!vesa_boot_hourglass_finished) vesa_boot_hourglass_enabled=TRUE;

    /* A VBE LFB is not the VGA text buffer.  Do not enable the legacy
     * 0xB8000 mirror here.  The terminal backing store stays in RAM and an
     * LFB renderer may blit it explicitly. */
    /* Do not call VisibleTerminals_SetHWCopy(FALSE) here: the historical
     * helper refreshes all VGA text windows even while disabling HWCopy. */
    /* Render the logical EGA terminal immediately.  At this early point VT1
     * is the RAM-backed bootstrap console; after VirtualTerminalInit() the
     * same renderer follows the normal terminal buffer automatically. */
    VesaTextConsoleRefresh();
    printk("VESA ENABLED: LFB=0x%x size=0x%x, text console mirror active.\n",
        vesa_frame_buf, vesa_frame_buf_bytes);
    return TRUE;
}

// Compatibility entry point for code that expects the historical VesaSetup().
int VesaSetup(void)
{
    if(!VesaProbe())
        return FALSE;
    return VesaActivate();
}

//---------------------------------------------------------------------------------------
/*
 * "Available" is intentionally weaker than "Ready".  On normal boots the
 * VBox/Bochs BGA framebuffer is discovered and mapped while VGA text mode is
 * still visible.  GraOS may therefore be launchable before graphics is active.
 */
int VesaGraOSAvailable(void)
{
    if(VesaGraOSReady())
        return TRUE;
    if(Nv6150IsPrepared() && vesa_frame_buf != NULL &&
       vesa_frame_buf_bytes >= GRAOS_VESA_FRAME_BYTES)
        return TRUE;
    if(VBoxBgaIsPrepared() && vesa_frame_buf != NULL &&
       vesa_frame_buf_bytes >= GRAOS_VESA_FRAME_BYTES)
        return TRUE;
    return FALSE;
}

/*
 * Enter a framebuffer-backed text-console mode on demand.
 *
 * This is intentionally distinct from VesaStartGraOSGraphics(): `gfx` is a
 * console operation, not ownership transfer to the GraOS compositor.  The
 * video provider is selected from hardware that was discovered before
 * paging, so every MMIO/LFB range used here is already mapped safely.
 *
 * Provider priority is real eMachines hardware first (NV6150/MCP61), then
 * VirtualBox/Bochs VM VGA/BGA, then an already active boot32 VESA handoff.
 * Re-running `gfx` is useful after a framebuffer client disabled the terminal
 * mirror: it always re-enables and redraws the current virtual terminal.
 */
int VesaTextGraphicsProvider(void)
{
    if(vesa_text_gfx_provider!=VESA_TEXT_GFX_NONE)
        return vesa_text_gfx_provider;
    if(Nv6150IsActive()) return VESA_TEXT_GFX_NV6150;
    if(VBoxBgaIsActive()) return VESA_TEXT_GFX_VM_VGA;
    if(vesa_enabled && vesa_boot_graphics) return VESA_TEXT_GFX_BOOT_VESA;
    return VESA_TEXT_GFX_NONE;
}

/*
 * Select a protected-mode LFB provider and console geometry.
 *
 * 640x480x32 is intentionally the normal text-console mode: the logical
 * 80x25 terminal occupies exactly 640x400 pixels, leaving a small vertical
 * border and touching far fewer framebuffer pixels than 1024x768.
 * 1024x768x32 remains available for GraOS and for users who explicitly want
 * the larger framebuffer console.
 *
 * BOOT_VESA cannot be reprogrammed from ordinary protected mode; it is
 * accepted only when the bootloader has already selected the requested
 * geometry. GeForce and VM-VGA/BGA are fully mode-switchable here.
 */
int VesaSetTextGraphics(int provider, int width, int height)
{
    int selected=provider;
    int mode_ok=FALSE;

    if(!paging_enabled)
    {
        printk("gfx: paging is not active yet.\n");
        return VESA_TEXT_GFX_NONE;
    }
    if(!((width==640 && height==480) ||
         (width==GRAOS_VESA_WIDTH && height==GRAOS_VESA_HEIGHT)))
    {
        printk("gfx: supported modes are 640x480 and 1024x768 (32 bpp).\n");
        return VESA_TEXT_GFX_NONE;
    }

    VesaBootHourglassStop();

    if(selected==VESA_TEXT_GFX_AUTO || selected==VESA_TEXT_GFX_NONE)
    {
        if(Nv6150IsPrepared() || Nv6150IsActive())
            selected=VESA_TEXT_GFX_NV6150;
        else if(VBoxBgaIsPrepared() || VBoxBgaIsActive())
            selected=VESA_TEXT_GFX_VM_VGA;
        else if(vesa_boot_graphics && vesa_frame_buf!=NULL &&
                vesa_frame_buf_bytes!=0 && vesa_bpp==32)
            selected=VESA_TEXT_GFX_BOOT_VESA;
        else
            selected=VESA_TEXT_GFX_NONE;
    }

    if(selected==VESA_TEXT_GFX_NV6150)
    {
        if(!Nv6150IsPrepared() && !Nv6150IsActive())
        {
            printk("gfx: GeForce 6150SE/MCP61 provider is not prepared.\n");
            return VESA_TEXT_GFX_NONE;
        }
        if(Nv6150IsActive() && vesa_width==width && vesa_height==height &&
           vesa_bpp==32)
            mode_ok=TRUE;
        else
            mode_ok=Nv6150SetMode(width,height,32);
        if(!mode_ok)
        {
            printk("gfx: GeForce mode %dx%dx32 failed.\n",width,height);
            return VESA_TEXT_GFX_NONE;
        }
    }
    else if(selected==VESA_TEXT_GFX_VM_VGA)
    {
        if(!VBoxBgaIsPrepared() && !VBoxBgaIsActive())
        {
            printk("gfx: VM VGA/BGA provider is not prepared.\n");
            return VESA_TEXT_GFX_NONE;
        }
        if(VBoxBgaIsActive() && vesa_width==width && vesa_height==height &&
           vesa_bpp==32)
            mode_ok=TRUE;
        else
            mode_ok=VBoxBgaSetMode(width,height,32);
        if(!mode_ok)
        {
            printk("gfx: VM VGA/BGA mode %dx%dx32 failed.\n",width,height);
            return VESA_TEXT_GFX_NONE;
        }
    }
    else if(selected==VESA_TEXT_GFX_BOOT_VESA)
    {
        if(!vesa_boot_graphics || vesa_frame_buf==NULL ||
           vesa_frame_buf_bytes==0 || vesa_bpp!=32)
        {
            printk("gfx: boot VESA/LFB provider is not available.\n");
            return VESA_TEXT_GFX_NONE;
        }
        if(vesa_width!=width || vesa_height!=height)
        {
            printk("gfx: boot VESA is fixed at %dx%d; protected-mode mode switch unavailable.\n",
                   vesa_width,vesa_height);
            return VESA_TEXT_GFX_NONE;
        }
        mode_ok=TRUE;
    }
    else
    {
        printk("gfx: no pre-paging GeForce/VM-VGA/VESA graphics provider is available.\n");
        return VESA_TEXT_GFX_NONE;
    }

    if(!vesa_enabled)
    {
        if(!VesaActivate())
        {
            printk("gfx: framebuffer activation failed.\n");
            return VESA_TEXT_GFX_NONE;
        }
    }

    vesa_text_gfx_provider=selected;

    /* Graphics mode uses the RAM-backed SCREEN buffers as the source of
     * truth. Never write the legacy B8000 mirror after activation. */
    VisibleTerminals_SetHWCopy(FALSE);
    VesaTextConsoleEnable(TRUE);
    VesaTextConsoleRefresh();
    return selected;
}

int VesaStartTextGraphics(void)
{
    /* Prefer the compact 640x480 console on programmable providers.  A pure
     * boot-VESA handoff cannot change geometry after protected-mode entry, so
     * preserve its already active 640x480 or 1024x768 mode instead. */
    if(Nv6150IsPrepared() || Nv6150IsActive() ||
       VBoxBgaIsPrepared() || VBoxBgaIsActive())
        return VesaSetTextGraphics(VESA_TEXT_GFX_AUTO,
                                   VESA_TEXT_GFX_DEFAULT_WIDTH,
                                   VESA_TEXT_GFX_DEFAULT_HEIGHT);
    if(vesa_boot_graphics && vesa_frame_buf!=NULL && vesa_bpp==32)
        return VesaSetTextGraphics(VESA_TEXT_GFX_BOOT_VESA,
                                   vesa_width,vesa_height);
    return VESA_TEXT_GFX_NONE;
}

/*
 * Enter the GraOS graphics mode on demand.  This function is called from a
 * userspace syscall made by GraOS, never from the normal kernel boot path.
 * The protected-mode VBox/Bochs BGA driver is used because a generic VBE BIOS
 * INT 10h mode set cannot safely be issued from ordinary ring0 protected-mode
 * code without a real-mode/vm86 trampoline.
 */
int VesaStartGraOSGraphics(void)
{
    /* GraOS owns the framebuffer from this point onward.  Permanently remove
     * the boot hourglass and restore the covered text cells before the first
     * GUI frame is presented. */
    VesaBootHourglassStop();
    if(VesaGraOSReady())
        return TRUE;
    if(!paging_enabled)
        return FALSE;

    if(Nv6150IsPrepared())
    {
        if(!Nv6150SetMode(GRAOS_VESA_WIDTH, GRAOS_VESA_HEIGHT,
                          GRAOS_VESA_BPP))
        {
            printk("GraOS graphics: NV6150 1024x768x32 mode set failed.\n");
            return FALSE;
        }
        if(!VesaActivate())
        {
            printk("GraOS graphics: NV6150 LFB activation failed.\n");
            return FALSE;
        }
        vesa_text_gfx_provider=VESA_TEXT_GFX_NV6150;
        VesaTextConsoleEnable(TRUE);
        printk("GraOS graphics: 1024x768x32 activated through NV6150/MCP61.\n");
        return VesaGraOSReady();
    }

    if(VBoxBgaIsPrepared())
    {
        if(!VBoxBgaSetMode(GRAOS_VESA_WIDTH, GRAOS_VESA_HEIGHT,
                           GRAOS_VESA_BPP))
        {
            printk("GraOS graphics: VBox/BGA 1024x768x32 mode set failed.\n");
            return FALSE;
        }
        if(!VesaActivate())
        {
            printk("GraOS graphics: LFB activation failed.\n");
            return FALSE;
        }
        /* Keep the current terminal readable until GraOS presents its first
         * full frame. VesaDrawFrame() then disables the text mirror. */
        vesa_text_gfx_provider=VESA_TEXT_GFX_VM_VGA;
        VesaTextConsoleEnable(TRUE);
        printk("GraOS graphics: 1024x768x32 activated on demand.\n");
        return VesaGraOSReady();
    }

    printk("GraOS graphics: no protected-mode graphics provider prepared.\n");
    return FALSE;
}

//---------------------------------------------------------------------------------------
// GraOS consumes a 32-bpp 1024x768 RGBA software framebuffer. The provider may
// be the BIOS-enumerated boot32 VBE LFB or the protected-mode VBox/Bochs BGA driver.
int VesaGraOSReady(void)
{
    return vesa_enabled &&
           vesa_boot_graphics &&
           vesa_frame_buf != NULL &&
           vesa_width == GRAOS_VESA_WIDTH &&
           vesa_height == GRAOS_VESA_HEIGHT &&
           vesa_bpp == GRAOS_VESA_BPP &&
           vesa_pitch >= GRAOS_VESA_WIDTH*4 &&
           vesa_frame_buf_bytes >= (DWORD)vesa_pitch * GRAOS_VESA_HEIGHT;
}

// Copy one complete packed 1024x768x32 GraOS frame to the physical VESA LFB.
// The application surface never contains hardware pitch padding.
int VesaDrawFrame(const void *src, DWORD bytes)
{
    const BYTE *s;
    int x,y;
    if(!VesaGraOSReady() || src==NULL || bytes!=GRAOS_VESA_FRAME_BYTES) return FALSE;
    vesa_text_console_enabled=FALSE;
    s=(const BYTE*)src;

    /* Fast 8:8:8 path: swap R/B with masks and shifts only.  Four-way
     * unrolling also reduces loop/branch overhead on i486-class fallback CPUs.
     * This is the normal VirtualBox/Bochs BGA path. */
    if(vesa_is_bgra8888()) {
        const DWORD *sp=(const DWORD*)src;
        for(y=0;y<GRAOS_VESA_HEIGHT;y++) {
            DWORD *d=(DWORD*)(vesa_frame_buf+y*vesa_pitch);
            const DWORD *row=sp+(DWORD)y*GRAOS_VESA_WIDTH;
            for(x=0;x<=GRAOS_VESA_WIDTH-4;x+=4) {
                d[x]  =vesa_rgba_to_bgra8888(row[x]);
                d[x+1]=vesa_rgba_to_bgra8888(row[x+1]);
                d[x+2]=vesa_rgba_to_bgra8888(row[x+2]);
                d[x+3]=vesa_rgba_to_bgra8888(row[x+3]);
            }
            for(;x<GRAOS_VESA_WIDTH;x++) d[x]=vesa_rgba_to_bgra8888(row[x]);
        }
        return TRUE;
    }

    /* Generic unusual-mask fallback.  Keep this for real VBE hardware whose
     * channel sizes/positions differ from the common BGRA8888 layout. */
    for(y=0;y<GRAOS_VESA_HEIGHT;y++) {
        DWORD *d=(DWORD*)(vesa_frame_buf+y*vesa_pitch);
        const BYTE *row=s+(DWORD)y*GRAOS_VESA_WIDTH*4UL;
        for(x=0;x<GRAOS_VESA_WIDTH;x++) {
            const BYTE *p=row+x*4;
            d[x]=vesa_native_rgb(p[0],p[1],p[2]);
        }
    }
    return TRUE;
}
