/**** JTMOS KERNEL - (C) 1999-2008 by Jari Tuominen. ***
 *
 *  KERNEL FIRST ROUTINE
 *
 */

// Required includes
#include "kernel32.h"	// Preferences for kernel32(init)
#include "keropt.h"	// Not included in kernel32.h !

//
static WORD *buf = (WORD *)0x000B8000UL;

/* Snapshot of the real-mode loader handoff at physical 0x1000..0x1005.
 * Copy it immediately after BSS clear so later low-memory users cannot alter
 * the evidence used by the kernel checksum/boot-drive checks. */
volatile WORD boot_kernel_checksum_expected_early;
volatile WORD boot_kernel_checksum_measured_early;
volatile WORD boot_drive_early;
volatile DWORD boot_utils_signature_early;
volatile DWORD boot_utils_version_early;
volatile DWORD boot_utils_phys_early;
volatile DWORD boot_utils_size_early;
volatile DWORD boot_utils_capacity_early;

/* The linker places kernel BSS at JTMOS_KERNEL_BSS_BASE.._ebss.  Clear it exactly once,
 * before any C subsystem stores persistent state there.  Do not call memset()
 * here: CPU dispatch state itself lives in BSS and has not been initialized. */
extern BYTE _sbss;
extern BYTE _ebss;

static void KernelClearBSS(void)
{
    volatile BYTE *p=(volatile BYTE *)&_sbss;
    volatile BYTE *end=(volatile BYTE *)&_ebss;

    while(p<end)
        *p++=0;
}

// ^^================ BOOT UP =================================^^
// NOTICE: Keep this function on top of the code.
// it has to be in top of the file when Boot sector calls it.
// boot_up = int/llint.asm boot_up subroutine,
// which'll call up this C function.
/*
 * boot32pm relocates the staged raw kernel and enters it at JTMOS_KERNEL_LOAD_PHYS after it has already
 * established flat protected-mode segments.  The loader stack lives in the
 * boot-sector/BIOS scratch region, so switch immediately to the kernel-reserved
 * early stack before any C code can grow it.
 *
 * Keep this entry naked only so GCC cannot emit a prologue before we have
 * normalised EFLAGS.  _boot_up_c() is noreturn, so a jump is intentional.
 */
__attribute__((naked,noreturn,section(".boot.entry"),used)) void _boot_up(void)
{
    __asm__ __volatile__(
        "cli\n\t"
        "cld\n\t"
        /* Move away from the real-mode boot sector/BIOS scratch area before
         * the first C push.  The canonical early-stack region is reserved by the kernel
         * memory map as the early/zero-process stack and the linker asserts
         * that kernel BSS ends below it. */
        "movl $" JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP_ASM ", %esp\n\t"
        "xorl %ebp, %ebp\n\t"
        /* Start C code with a clean EFLAGS image: reserved bit 1 set,
         * IF/DF/NT clear. */
        "pushl $0x00000002\n\t"
        "popfl\n\t"
        "cld\n\t"
        "jmp _boot_up_c\n\t"
    );
}


/*
 * Do not trust the old 8042-only A20 sequence blindly.  In particular, if
 * A20 stays closed then the first paging memset above physical 0x00100000 aliases
 * low memory and destroys the running system.  Force the fast A20 gate and
 * verify it before KernelInit() touches any fixed structures above 1 MiB.
 */
static void KernelFastA20Enable(void)
{
    BYTE v;
    __asm__ __volatile__("inb $0x92,%0" : "=a" (v));
    v |= 0x02;          /* A20 enable */
    v &= (BYTE)~0x01;   /* never request fast reset */
    __asm__ __volatile__("outb %0,$0x92" : : "a" (v));
    __asm__ __volatile__("jmp 1f\n1: jmp 1f\n1:" : : : "memory");
}

static int KernelA20Enabled(void)
{
    /* With the kernel itself linked at 1 MiB, the historical 0x00100500
     * probe address lies inside live .text/.data.  Use the equally valid
     * 2 MiB/3 MiB pair instead: they differ by exactly A20 and both are
     * scratch/reserved at this pre-paging point. */
    volatile BYTE *low  = (volatile BYTE *)(JTMOS_KERNEL_BSS_BASE + 0x00000500UL);
    volatile BYTE *high = (volatile BYTE *)(JTMOS_KERNEL_BSS_BASE + 0x00100500UL);
    BYTE low_old, high_old;
    int enabled;

    low_old = *low;
    high_old = *high;

    *low = 0x00;
    *high = 0xFF;
    __asm__ __volatile__("" : : : "memory");
    enabled = (*low == 0x00);

    /* Restore in this order; it is safe even when high aliases low. */
    *high = high_old;
    *low = low_old;
    __asm__ __volatile__("" : : : "memory");
    return enabled;
}

static void KernelEnsureA20(void)
{
    KernelFastA20Enable();
    if(!KernelA20Enabled())
    {
        DebugSerialWrite("[A20] FATAL: A20 gate is still disabled; halting before high-memory writes.\n");
        for(;;)
            __asm__ __volatile__("cli; hlt");
    }
    DebugSerialWrite("[A20] verified: addresses above 1 MiB do not alias low memory.\n");
}

__attribute__ ((__noreturn__)) void _boot_up_c(void)
{
    /* BSS starts above 1 MiB, so A20 must be open before clearing it.  Perform
     * this verification without relying on any BSS-backed runtime state. */
    KernelFastA20Enable();
    if(!KernelA20Enabled())
        for(;;)
            __asm__ __volatile__("cli; hlt");

    KernelClearBSS();

    boot_kernel_checksum_expected_early = *(volatile WORD *)0x00001000UL;
    boot_kernel_checksum_measured_early = *(volatile WORD *)0x00001002UL;
    boot_drive_early = *(volatile WORD *)0x00001004UL;
    boot_utils_signature_early = *(volatile DWORD *)0x00001010UL;
    boot_utils_version_early = *(volatile DWORD *)0x00001014UL;
    boot_utils_phys_early = *(volatile DWORD *)0x00001018UL;
    boot_utils_size_early = *(volatile DWORD *)0x0000101CUL;
    boot_utils_capacity_early = *(volatile DWORD *)0x00001020UL;

    EGASAFE = TRUE;
    KINIT = FALSE;
    KernelInitPassed = FALSE;
    mallocOK = FALSE;
    screens[0].buf = (char *)0xB8000;

    DebugSerialEarlyInit();
    DebugSerialWrite("\n[JTMOS V18] debug active; C entry uses kernel emergency stack, ESP=");
    DebugSerialWriteHex32(GETESP());
    DebugSerialWrite("\n");
    DebugSerialWrite("[A20] verified: addresses above 1 MiB do not alias low memory.\n");
    DebugSerialWrite("[BOOT] checksum handoff expected=");
    DebugSerialWriteHex32((DWORD)boot_kernel_checksum_expected_early);
    DebugSerialWrite(" measured=");
    DebugSerialWriteHex32((DWORD)boot_kernel_checksum_measured_early);
    DebugSerialWrite(" drive=");
    DebugSerialWriteHex32((DWORD)boot_drive_early);
    DebugSerialWrite("\n");
    cpuEarlyInit();

    KernelInit();
    halt();
}
