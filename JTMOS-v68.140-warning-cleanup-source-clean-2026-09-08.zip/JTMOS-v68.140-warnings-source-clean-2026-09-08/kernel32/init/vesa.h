#ifndef __INCLUDED_VESA_H__
#define __INCLUDED_VESA_H__

/* GraOS packed-LFB contract.  The mode may be supplied by boot32 VESA or by
 * the protected-mode VirtualBox/Bochs BGA driver. */
#define GRAOS_VESA_WIDTH       1024
#define GRAOS_VESA_HEIGHT      768
#define GRAOS_VESA_FALLBACK_WIDTH  640
#define GRAOS_VESA_FALLBACK_HEIGHT 480
#define GRAOS_VESA_BPP         32
#define GRAOS_VESA_BYTES_PER_PIXEL 4
#define GRAOS_VESA_FRAME_BYTES (GRAOS_VESA_WIDTH * GRAOS_VESA_HEIGHT * GRAOS_VESA_BYTES_PER_PIXEL)

/* boot32/boot32pm writes this at physical 0x4100 only after a successful
 * VBE mode set. V67.8.57.10.18.16.5 enables this graphical handoff by default. */
#define VESA_BOOT_HANDOFF_ADDR      0x00004100UL
#define VESA_BOOT_HANDOFF_SIGNATURE 0x41534556UL /* "VESA" little endian */

extern BYTE *vesa_frame_buf;
extern DWORD vesa_frame_buf_bytes;
extern int vesa_enabled;
/* TRUE as soon as boot32 has successfully selected a VBE graphics mode.
 * Unlike vesa_enabled, this becomes true before paging/LFB activation and is
 * used to keep the legacy VGA text hardware completely untouched. */
extern int vesa_boot_graphics;
extern int vesa_width;
extern int vesa_height;
extern int vesa_bpp;
extern int vesa_pitch;
extern int vesa_red_mask_size,vesa_red_field_pos;
extern int vesa_green_mask_size,vesa_green_field_pos;
extern int vesa_blue_mask_size,vesa_blue_field_pos;
extern int vesa_alpha_mask_size,vesa_alpha_field_pos;
extern int vesa_text_console_enabled;
extern WORD vesa_mode_attributes;
extern BYTE *vb,*vesainfo;
extern BYTE egapal[];

int VesaBootHandoffPresent(void);
int VesaProbe(void);
int VesaEarlyTextActivate(void);
int VesaActivate(void);
int VesaSetup(void);
int VesaGraOSReady(void);
int VesaGraOSAvailable(void);
int VesaStartGraOSGraphics(void);

/* Protected-mode graphics console used by the SMSH/SQSH `gfx` builtin.
 * Return value identifies the active provider, or zero on failure. */
#define VESA_TEXT_GFX_NONE       0
#define VESA_TEXT_GFX_BOOT_VESA  1
#define VESA_TEXT_GFX_NV6150     2
#define VESA_TEXT_GFX_VM_VGA     3
#define VESA_TEXT_GFX_AUTO       4
#define VESA_TEXT_GFX_DEFAULT_WIDTH  640
#define VESA_TEXT_GFX_DEFAULT_HEIGHT 480
int VesaStartTextGraphics(void);
int VesaSetTextGraphics(int provider, int width, int height);
int VesaTextGraphicsProvider(void);
int VesaDrawFrame(const void *src, DWORD bytes);
void BlitCurrentTerminalToVesa(void);
void VesaTextConsoleEnable(int enabled);
void VesaTextConsoleRefresh(void);
void VesaTextConsoleCellChanged(SCREEN *s, long byte_offset);
void VesaTextConsoleCursorChanged(SCREEN *s);
void VesaBootHourglassEnable(int enabled);
void VesaBootHourglassStop(void);
void flashy(DWORD ad);

#endif
