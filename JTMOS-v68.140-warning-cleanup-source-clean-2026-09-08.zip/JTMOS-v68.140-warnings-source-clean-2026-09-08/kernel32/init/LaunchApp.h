#ifndef __INCLUDED_LAUNCHAPP_H__
#define __INCLUDED_LAUNCHAPP_H__

/* JTMOS process virtual layout.  Keep this header dependency-light because
 * threads.h includes it very early while kernel32.h is still being assembled. */
#define RTBASE               0x80000000UL
#define RTCODE               (RTBASE + 0x00004000UL)
#define APP_STACK_SIZE       (256UL * 1024UL)
#define APP_GUARD_SIZE       4096UL
#define APP_MIN_HEAP_SIZE    (64UL * 1024UL)
#define APPLICATION_START_AD RTCODE
#define DEF_APP_SPACE_K      4096

#define LAUNCHAPP_ELF_OK                 0
#define LAUNCHAPP_ELF_BAD_ARGUMENT      -1
#define LAUNCHAPP_ELF_BAD_MAGIC         -2
#define LAUNCHAPP_ELF_UNSUPPORTED       -3
#define LAUNCHAPP_ELF_BAD_HEADER        -4
#define LAUNCHAPP_ELF_BAD_SEGMENT       -5
#define LAUNCHAPP_ELF_BAD_ENTRY         -6
#define LAUNCHAPP_ELF_NO_MEMORY         -7
#define LAUNCHAPP_ELF_CREATE_FAILED     -8
#define LAUNCHAPP_ELF_MAP_FAILED        -9

/* Immutable origin/run context for one exec request.  callerDNR/callerDB are
 * the values captured at the original cexec syscall entry.  runDNR/runDB are
 * either that exact snapshot (empty workDir) or a path resolved relative to
 * that snapshot.  LaunchApp must never derive child cwd from the Central
 * Process service thread. */
typedef struct
{
    int callerPID;
    int callerDNR;
    int callerDB;
    int runDNR;
    int runDB;
} LAUNCHAPP_CONTEXT;

int LaunchApp(BYTE *abin, int length);
int LaunchAppEx(BYTE *abin, int length, int memkb, int dnr, int db);
int LaunchAppExContext(BYTE *abin, int length, int memkb,
                       const LAUNCHAPP_CONTEXT *ctx);
int LaunchAppValidateImage(const BYTE *abin, int length, int *format_out);
int LaunchAppIsELF32(const BYTE *abin, int length);
void AdaptAppPages(int pid, DWORD srcOffset);

extern DWORD launchapp_cleartogo;

/* Detailed failures reported through centralprocess.launch_detail. */
#define LAUNCHAPP_DETAIL_LAYOUT        -20
#define LAUNCHAPP_DETAIL_ALLOC         -21
#define LAUNCHAPP_DETAIL_COPY          -22
#define LAUNCHAPP_DETAIL_THREAD        -23
#define LAUNCHAPP_DETAIL_MAP           -24
#define LAUNCHAPP_DETAIL_ARGUMENT      -25
#define LAUNCHAPP_DETAIL_IDENTITY      -26
#define LAUNCHAPP_DETAIL_FORMAT        -27
#define LAUNCHAPP_DETAIL_CONTEXT       -28

#endif
