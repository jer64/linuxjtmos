/*** System Miscellaneous Routines ***/  
#ifndef _SYSMISC_H_
#define _SYSMISC_H_
void halt(void) __attribute__((noreturn));

#endif	/* 
 */
