//////////////////////////////////////////////////////////////////////////////////
// InitSystem.c
// Memory initialization, etc. Very low level stuff.
// (C) 2002-2008,2017-2020 Jari Tuominen (jari.t.tuominen@gmail.com).
//////////////////////////////////////////////////////////////////////////////////
#include "kernel32.h"
#include "paging.h" // memory paging
#include "fdc.h"    // early ISA-DMA reservation for floppy
#include "initsystem.h"
#include "pit.h"    // storage-safe tick clock required by early USB delays
#include "vboxbga.h"
#include "nv6150.h"
#include "input_policy.h"
#if JTMOS_MOD_AUDIO_DRIVERS
#include "audio.h"
#endif
#if JTMOS_MOD_PCI
#include "usb_input.h"
#endif
#ifdef GRAOS
#include "graos.h"
#endif

//
static WORD *ega_scr = (WORD *)0x000B8000UL;
static BYTE term_buf[80*50*2];

//---------------------------------------------------------------
void Bingoo(void)
{
	int i,ii;
	char *scr;

	//
	scr = (char *)0x000B8000UL;

	//
	for(ii=0; ; ii++)
	{
		for(i=0; i<(80*1*2); i++) { scr[i] = i+ii; }
	}
}

//---------------------------------------------------------------
// Initializes the system entirely (boot up).

extern volatile WORD boot_kernel_checksum_expected_early;
extern volatile WORD boot_kernel_checksum_measured_early;
extern volatile WORD boot_drive_early;
extern volatile DWORD boot_utils_signature_early;
extern volatile DWORD boot_utils_version_early;
extern volatile DWORD boot_utils_phys_early;
extern volatile DWORD boot_utils_size_early;
extern volatile DWORD boot_utils_capacity_early;
void BootUtilsRamInit(void);

int InitSystem(void)
{
	void *biosinfo;
	LDR *l;
	static char bootstr[20];
	DWORD ad,ad2;
	BYTE *vesainfo;
	static BYTE *vb,*p;
	DWORD *ptr;
	int i,i2,i3,i4,
		x,y;

	// Point at boot loader start in memory.
	l = 0x7C00;
	/* boot32 handoff was snapshotted in _boot_up_c(). */
	/* Minimal pre-malloc console.  The full terminal initializer allocates a
	 * keyboard buffer and therefore cannot be used before mmInit(). */
	xmemset(term_buf, 0, sizeof(term_buf));
	xmemset((char *)&screens[ID_VIRTUAL_TERMINAL_1], 0, sizeof(SCREEN));
	screens[ID_VIRTUAL_TERMINAL_1].buf = (char *)term_buf;
	screens[ID_VIRTUAL_TERMINAL_1].copy = (char *)0xB8000;
	screens[ID_VIRTUAL_TERMINAL_1].width = 80;
	screens[ID_VIRTUAL_TERMINAL_1].height = 25;
	screens[ID_VIRTUAL_TERMINAL_1].window.x1 = 0;
	screens[ID_VIRTUAL_TERMINAL_1].window.y1 = 0;
	screens[ID_VIRTUAL_TERMINAL_1].window.x2 = 79;
	screens[ID_VIRTUAL_TERMINAL_1].window.y2 = 24;
	screens[ID_VIRTUAL_TERMINAL_1].tc = 0x07;
	screens[ID_VIRTUAL_TERMINAL_1].supallow = 1;
	screens[ID_VIRTUAL_TERMINAL_1].updcur = 0;

	/* Install the safe exception table only after its backing console is sane. */
	init_safe_idt();
	DebugSerialWrite("[BOOT] safe IDT installed.\n");
	clrscr();
	printk("%s 1.0.%x(%s) \n\n",
		JTMOSBETANAME, BUILD_NR, BUILD_DATE);
	printk("\n");
        printk("   __ ______ _   _ _____ _____\n");
        printk("   __   __   __ __ __ __ __ __\n");
	printk("   __   __   _____ __ __ ___  \n");
	printk("__ __   __   __ __ __ __   ___\n");
	printk("__ __   __   __ __ __ __ __ __\n");
	printk("_____   __   __ __ _____ _____\n");
	printk("\n");
	printk("O P E R A T I N G  S Y S T E M\n");
	printk("\n");
	printk("(C) 1997-2020 by Jari Tuominen (jari.t.tuominen@gmail.com).\n");
	printk("\n");
	/* No sleep() here: RTC/timer/multitasking are not initialized yet. */
	//

	// Store BIOS boot drive setting.
	SetBiosBootDrive(boot_drive_early);

	/*
	 * V67.8.57.10.18.16.5 graphics policy:
	 *   - boot32pm normally enters a BIOS-enumerated 1024x768x32 VBE LFB;
	 *   - honour that handoff immediately and mirror boot text into its LFB;
	 *   - if BIOS VBE was unavailable, DISCOVER VBox/Bochs BGA as the delayed
	 *     protected-mode provider and let GraOS request the transition later.
	 */
	i = FALSE;
	if(VesaBootHandoffPresent())
	{
		DebugSerialWrite("[BOOT] boot32 VESA handoff present\n");
		printk("boot32 VESA handoff detected; probing active mode info.\n");
		i = VesaProbe();
	}

	if(!i)
	{
		DebugSerialWrite("[BOOT] preparing delayed native/BGA graphics provider\n");
		if(Nv6150PrepareGraOS())
			printk("NV6150/MCP61 graphics provider prepared; VGA text mode remains active.\n");
		else if(VBoxBgaPrepareGraOS())
			printk("VBox/BGA graphics provider prepared; VGA text mode remains active.\n");
		else
			printk("No delayed protected-mode graphics provider detected.\n");

		vesa_boot_graphics = FALSE;
		vesa_enabled = FALSE;
		vesa_early_serial_only = FALSE;
		printk("Graphics boot inactive; using native text console.\n");
	}
	DebugSerialWrite("[BOOT] graphics pre-paging preparation complete\n");

	/* EARLY CONSOLE RULE:
	 * If boot32 selected VESA graphics, NEVER rebind the early console to
	 * 0xB8000 and NEVER poke VGA CRTC registers.  V13 called EGASafeMode()
	 * here, which reinitialized screens[0], changed its buffer from term_buf
	 * back to 0xB8000 and enabled the hardware text cursor.  That is valid in
	 * mode 3, but not as a generic console in VBE graphics mode.
	 *
	 * Keep the manually prepared RAM-backed terminal until mm/paging are up.
	 * Serial mirroring remains available, so all early printk output is visible.
	 */
	if(vesa_boot_graphics)
	{
		visible_terminal = 0;
		screens[ID_VIRTUAL_TERMINAL_1].buf = (char *)term_buf;
		screens[ID_VIRTUAL_TERMINAL_1].copy = (char *)0xB8000;
		screens[ID_VIRTUAL_TERMINAL_1].HWCopy = FALSE;
		screens[ID_VIRTUAL_TERMINAL_1].updcur = FALSE;
		/* A diagnostic bootloader may already have selected graphics.  In that
		 * case the LFB must immediately show the logical text console instead of
		 * going black until paging/GraOS startup. */
		if(!VesaEarlyTextActivate())
			DebugSerialWrite("[VESA] warning: active boot graphics could not mirror text.\n");
	}
	else
	{
		EGASafeMode();
		SetVisibleTerminal(0);
	}
	EGASAFE=1;

	//
#ifdef GRAOS
	/* V14: no pre-paging LFB write: DirectDrawText(vesa_frame_buf,vesa_width,vesa_height, "Kernel info      ", 0,0); */
#endif
	textcolor(WHITE); textbackground(BLACK);
	clrscr();
	printk("\n");
	printk("  Kernel (%x) initialization in progress. \n", BUILD_NR);
	printk("\n");
	textcolor(CYAN);

	// Check boot loader signature.
	if(l->signature!=0xAA55 && l->signature!=0x55AA)
	{
		//
		printk("Logic check failed:\n");
		printk("  Boot loader signature is invalid.\n");
		printk("  Proceed with caution.\n");
		sleep(10);
	}

	// IMPORTANT NOTE: I noticed that there is a huge need
	//		for initing malloc before most of the things,
	//		of course, before initing malloc here,
	//		we detect the amount of memory available..
#ifdef GRAOS
	/* V14: no pre-paging LFB write: DirectDrawText(vesa_frame_buf,vesa_width,vesa_height, "scanmem      ", 0,0); */
#endif
	DebugSerialWrite("[BOOT] before RAM-probe printk\n");
	printk("Detecting RAM from bootloader BIOS memory map (scanmem).\n");
	DebugSerialWrite("[BOOT] RAM-probe printk returned\n");
	DebugSerialWrite("[BOOT] entering scanmem()\n");
	scanmem();
	DebugSerialWrite("[BOOT] scanmem() returned\n");

	// V67.8.36 experimental +1 MiB fixed layout.  The executable constants
	// come from memory_layout.h/paging.h; this comment is only a readable map.
	// 100000-1FFFFF: relocated kernel text/data window (file <= 576 KiB here)
	// 200000-2DFFFF: kernel BSS/data reserve
	// 2E0000-2EFFFF: early/zero-process stack
	// 2F0000-2FEFFF: IDT reserve
	// 2FF000-2FFFFF: kernel page directory
	// 300000-6FFFFF: kernel page tables (4 MiB)
	// 700000-AFFFFF: per-process page tables (4 MiB; 256 x 16 KiB)
	// B00000-XXXXXX: dynamically allocatable physical memory

	//printk("Setup temporary safe IDT/exception handlers:\n");
	//printk("Done.\n");

	//
#ifdef GRAOS
	/* V14: no pre-paging LFB write: DirectDrawText(vesa_frame_buf,vesa_width,vesa_height, "mmInit      ", 0,0); */
#endif
	printk("mmInit:\n");
	ad = PG_STRUCTURES_PHYS_END;
	if(ad != JTMOS_KERNEL_DYNAMIC_PHYS_START)
		KERNEL_FATAL("InitSystem: paging/MM fixed layout drifted from canonical dynamic-memory boundary");
	mmInit(ad, ms.amount-ad); // paging and dynamic memory allocation will be enabled...

    /* DOSBOOT may have staged UTILS.ISO in persistent high RAM. Reserve and
     * map it before any normal allocator client can consume those pages. */
    BootUtilsRamInit();

	/* Reserve the floppy ISA-DMA bounce buffer before normal kernel malloc()
	 * activity can consume the <16 MiB DMA-addressable physical window. */
	if(fdc_prepare_dma() != 0)
		printk("FDC: early DMA reservation failed; fdc_init will retry later.\n");

	/* pg_init() has now installed the identity mapping for the exact LFB
	 * range supplied by VBox/BGA or boot32 VESA.  Screen writes are safe
	 * from this point onward. */
	if(vesa_boot_graphics && vesa_frame_buf != NULL)
	{
		printk("VESA post-paging activate:\n");
		VesaActivate();
	}
	else if(vesa_frame_buf != NULL)
		printk("Graphics LFB mapped but inactive; waiting for GraOS.\n");

#ifdef GRAOS
	if(vesa_enabled) DirectDrawText(vesa_frame_buf,vesa_width,vesa_height, "VirtualTerminalInit      ", 0,0);
#endif
	//serial_init();
	printk("VirtualTerminalInit\n");
	// PRIMITIVE LEGACY SERIAL PORTS INIT
	// Define port addresses (not real serial init,
	// but makes possible to poke serial ports at primitive level,
	// presuming the default settings are there).
	VirtualTerminalInit();
#ifdef GRAOS
	if(vesa_enabled) DirectDrawText(vesa_frame_buf,vesa_width,vesa_height, "EgaConsolelInit      ", 0,0);
#endif
	printk("EgaConsoleInit\n");
	EgaConsoleInit();
#ifdef GRAOS
	if(vesa_enabled) DirectDrawText(vesa_frame_buf,vesa_width,vesa_height, "EgaConsolelInit OK   ", 0,0);
#endif
	printk("EgaConsoleInit OK\n");

	// Memory requirement test..
	printk("GetRamAmount\n");
	if( GetRamAmount()<(1024*1024*16) )
	{
		KERNEL_FATAL("Oops! JTMOS operating system requires atleast 16M of RAM. This may change in future versions of the operating system.");
	}

	//------------------------------------------------------------------------------------------------------
	// Init environmental variable database system.
	// (this is good to be done slightly after mm is initialized)
#ifdef GRAOS
	if(vesa_enabled) DirectDrawText(vesa_frame_buf,vesa_width,vesa_height, "initEnvDataBase      ", 0,0);
#endif
	printk("initEnvDataBase\n");
	initEnvDatabase();

	// Start system log (memory based).
	printk("initSystemLog\n");
	initSystemLog(); // logging.c
	printk("initSystemLog OK\n");

	//--------------------------------------------------------
	// From here on the system log is functional ...
	//--------------------------------------------------------

	//
	biosinfo=(DWORD)0x1010;

	// Clear the global variables structure
	xmemset( ((void*)&glvar), 0, sizeof(GLVAR));
	// debug
	glvar.debugMsg = jtmos_debug;

	// Copy biosinfo
	memcpy(&glvar.biosinfo, biosinfo, 0x100);
 
	// -- Init text screen console
	EGASAFE=0;
	//printk("VesaSetup\n");
	//VesaSetup();
	//printk("VesaSetup OK\n");

	// -- Make cursor alive
	CursorState(&screens[0], 1);

	// -- Initialize VMODE module
	// This is a mandatory job to do.
	// Otherwise the display administration won't
	// get the current video mode.
	printk("screen reset\n");
	/* A prepared-but-inactive LFB must not suppress VGA text maintenance.
	 * V67.8.13 keeps vesa_frame_buf populated so paging can map the future
	 * GraOS framebuffer while mode 3 is still visible. */
	if(!vesa_enabled)
	{
		FixEgaMemory();
		//setvmode(3);
	}
	clrscr();

	// Set textcolor/background & clear screen
	window(0,0, 79,24);
	textcolor(7); textbackground(BLUE); clrscr();
	printk("\n");
	printk("  %s 1.0.%x(%s) \n\n",
		JTMOSBETANAME, BUILD_NR, BUILD_DATE);

	printk("some info\n");
	cpuPrintInfo();

	// KERNEL CHECKSUM CHECK
	if(boot_drive_early<=1)
	{
		printk("%x/%x: ", boot_kernel_checksum_expected_early, boot_kernel_checksum_measured_early);
		if(boot_kernel_checksum_expected_early!=boot_kernel_checksum_measured_early)
		{
			if(boot_drive_early<=1)
			{
				printk("Warning: Kernel checksum failure detected.\n");
				sleep(10);
			}
		}
		else
		{
			printk("Kernel checksum OK.\n");
		}
	}

	//
	printk("Initializing kernel ...\n");
	printk("BuildNR: %x(%s), 10000 - %x\n", BUILD_NR,BUILD_DATE,&kernelend);

	// We call devsys so devices can register in the system properly.
	driver_sys_init();
	// Here we init the buffering system, and api(not much to do, just init the structure).
	driver_init();

	// Register Devices!
	// Init the ega/vga(doesn't touch the video itself, just detection,
	// and device registration into the device management system).

	//
	printk("Initializing drivers :  ");
	// EGA text features support + terminal support
	printk("*EGA ");
	ega_init();
	// VGA init must be called only after EGA init
	printk("*VGA ");
	vga_init();
	// Init some other devices
	printk("*NULL ");
	null_init();
	printk("*ZERO ");
	zero_init();
	printk("\n");

	// Most of these functions require malloc, remember that.
	// Malloc must be inited before all this!
	//
	printk("Initializing Global Descriptor Table (GDT).\n");
	init_gdt();
	printk("Initializing Intel Programmable Interrupt Controller 8259.\n");
	Init8259();
	printk("Initializing Interrupt Decriptor Table (IDT).\n");
	init_idt();
	printk("System timer system init.\n");
	InitTimer();
	printk("Initializing dynamic Global Descriptor Table (GDT) allocation system.\n");
	InitGDTEntryAllocationSystem();
	printk("\n");
	// Remark this line if syscalls are causing problems(e.g. putch)
	printk("Initializing System Calls.\n");
	scall_init();
	printk("System Call initialization returned safely.\n");
	// Init thread management (will init TSS too).
	printk("Initializing Multitasking (Threads).\n");
	init_threads();
	// Define this process as init
	printk("Naming current process as \"init\".\n");
	IdentifyThread(GetCurrentThread(), "init");

	//
	switch(GetBiosBootDrive())
	{
		case 0:
		strcpy(bootstr, "floppy");
		break;
		case 1:
		strcpy(bootstr, "floppy2");
		break;
		case 0x80:
		strcpy(bootstr, "hda");
		break;
		case 0x81:
		strcpy(bootstr, "hdb");
		break;
		case 0x82:
		strcpy(bootstr, "hdc");
		break;
		case 0x83:
		strcpy(bootstr, "hdd");
		break;
		default:
		strcpy(bootstr, "UNKNOWN");
		break;
	}
	printk("System is using boot drive %s:.\n",
		bootstr);

//===============================================================
	// From here on threads, terminals, etc. work:

//===============================================================
	/* Single-seat input policy: prepare the higher-priority USB upper half
	 * before attaching PS/2/BIOS-legacy fallbacks.  The USB scaffold does not
	 * claim a keyboard/mouse merely because a controller exists; only a real
	 * HID report promotes that class to USB. */
	input_policy_init();
#if JTMOS_MOD_PCI
	if(PCI_ENABLED)
	{
		printk("Input probe: trying USB HID path before PS/2 fallbacks.\n");
		usb_input_init();
	}
#endif

	//
	if(CMOS_ENABLED)
	{
		printk("Initializing real-time clock (CMOS).\n");
		cmos_init();
	}

	//
	if(KEYBOARD_ENABLED)
	{
		printk("Initializing keyboard.\n");
		InitKeyboard();
	}

	/* Native USB probing is completed after interrupts + DEVDB are live.
	 * PS/2 mouse attach is intentionally delayed until then so an enumerated
	 * USB HID mouse can claim the single logical pointer first. */

//===============================================================

	//
	printk("Running Serial Port UART System Reset Before Interrupts Can Occur.\n");
	serial_init();
	printk("Done.\n");
	//
	printk("Enabling interrupts.\n");
	//	IRQStatusCritical();
	enable();
	printk("Interrupts enabled.\n");

	/* USB OHCI initialization below uses millisecond delays for controller
	 * reset, root-port reset and SET_ADDRESS settling.  MilSleep() cannot
	 * advance here unless IRQ0 is already unmasked.  Previously the
	 * storage-safe PIT was enabled only after InitSystem() returned, so the
	 * first delay(1) inside OHCI could sleep forever.  Start the tick-only
	 * clock now; KernelInit() may safely call PitStorageSafeBegin() again
	 * because the operation is idempotent. */
	printk("PIT: enabling storage-safe tick-only IRQ0 before USB enumeration.\n");
	PitStorageSafeBegin();
	printk("PIT: early USB timing clock active.\n");

#if JTMOS_MOD_PCI
	/* Native USB requires working PIT delays, allocated keyboard buffers and a
	 * live DEVDB.  Probe it here, then attach PS/2 only when USB did not claim
	 * the corresponding logical input class. */
	if(PCI_ENABLED && usb_input.controller_count>0)
	{
		int usbrv;
		printk("USB input: starting native OHCI transport before PS/2 mouse fallback.\n");
		usbrv=usb_input_transport_init();
		if(usbrv)
			printk("USB input: OHCI transport unavailable (%d); PS/2/BIOS fallback remains enabled.\n",usbrv);
	}
#endif
	if(PS2MOUSE_ENABLED && input_policy_mouse_backend()!=INPUT_BACKEND_USB)
	{
		printk("Initializing PS/2 mouse fallback after USB probe.\n");
		ps2mouse_init();
		mouse_hidecursor();
	}

	//
	/* Restore the original JTMOS boot ordering: storage drivers use the PIT
	 * millisecond counters during initialization (fd_sleep(), IDE timeouts,
	 * motor-off timer, etc.).  init_threads() has already installed the PIT
	 * task gate at this point, so IRQ0 must be unmasked before InitSystem()
	 * returns to jtmfat/fdc/hd initialization.  InitSystem() later returns
	 * with IF clear, but individual driver waits may STI; the PIC mask must
	 * therefore already allow IRQ0. */
	/* Do not expose the TSS task-gate scheduler to storage initialization.
	 * init.c installs a tick-only IRQ0 gate immediately after InitSystem()
	 * returns, before floppy/IDE code runs. */
	printk("PIT: storage-safe tick-only IRQ0 remains active for storage initialization.\n");
//===============================================================

	// Determine CPU power
//	if(CPU_SPEED_TEST_ENABLED)	CPUTest();

	// Install generic audio driver when included in this kernel profile.
#if JTMOS_MOD_AUDIO_DRIVERS
	/* Register the stable logical `audio` device now, but do not touch hardware.
	 * The first playback request selects HDA -> SB -> GUS automatically. */
	audio_init();
	printk("Audio: generic audio device ready; hardware backend deferred until playback.\n");
#else
	printk("Audio drivers disabled in this kernel build.\n");
#endif

	// -----------------------------------------------------------------
	// End of device detection and registration.
	//

	// -----------------------------------------------------------------
	// From now on we can normally access the devices:

	// Call CPU idler.....
//	if(XON_IDLE)
//		syssh_callappex(IdleThreadProgram, 0, GetCurrentTerminal());

	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	//
	disable();
	textcolor(14);

	//
	printk("End of kernel init pass 1.\n");

/*	printk("KEY ... ");
	enable();
	getch();
	printk("Thanks ...\n");*/

	//
	return 0;
}
