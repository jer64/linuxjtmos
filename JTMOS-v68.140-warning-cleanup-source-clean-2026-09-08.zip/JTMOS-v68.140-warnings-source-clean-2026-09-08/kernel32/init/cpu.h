/*** JTMOS x86 CPU feature detection and runtime dispatch. ***/
#ifndef __INCLUDED_CPU_H__
#define __INCLUDED_CPU_H__

#define disable() __asm__ __volatile__("cli" ::: "memory")
#define enable()  __asm__ __volatile__("sti" ::: "memory")
#define nop()     __asm__ __volatile__("nop")

/*
 * IA-32 wait primitives.
 *
 * PAUSE is encoded as F3 90 so the kernel stays buildable with an i486
 * compiler target. Intel documents this encoding as backward compatible:
 * pre-Pentium-4 IA-32 CPUs execute it as an ordinary NOP.
 *
 * cpu_sti_hlt() is deliberately one asm block. If IF was clear, STI delays
 * maskable-interrupt recognition until after the following instruction, so
 * HLT is entered before a pending IRQ can be dispatched.
 */
static __inline__ void cpu_relax(void)
{
    __asm__ __volatile__(".byte 0xf3,0x90" ::: "memory");
}

static __inline__ void cpu_halt(void)
{
    __asm__ __volatile__("hlt" ::: "memory");
}

static __inline__ void cpu_sti_hlt(void)
{
    __asm__ __volatile__("sti\n\thlt" ::: "memory");
}

/* Public feature-mask ABI.  Keep these values synchronized with
 * libc/include/jtmos/cpu_features.h. */
#define JTMOS_CPUF_CPUID       0x00000001UL
#define JTMOS_CPUF_FPU         0x00000002UL
#define JTMOS_CPUF_FXSR        0x00000004UL
#define JTMOS_CPUF_SSE         0x00000008UL
#define JTMOS_CPUF_SSE2        0x00000010UL
#define JTMOS_CPUF_SSE3        0x00000020UL
#define JTMOS_CPUF_SSE_OS      0x00000040UL
#define JTMOS_CPUF_SSE3_ACCEL  0x00000080UL

/* This structure contains no pointers and is initialized before mmInit(). */
typedef struct JTMOS_CPU_INFO_K {
    unsigned long features;
    unsigned long signature;
    unsigned long max_basic_leaf;
    unsigned char family;
    unsigned char model;
    unsigned char stepping;
    unsigned char reserved;
    char vendor[13];
} JTMOS_CPU_INFO_K;

extern JTMOS_CPU_INFO_K jtmos_cpu_info;

/* Called from the earliest C boot path.  Safe on an original i486: CPUID is
 * tested by toggling EFLAGS.ID before the instruction is ever executed. */
void cpuEarlyInit(void);
void cpuPrintInfo(void);
unsigned long cpuFeatureMask(void);
int cpuHasFeature(unsigned long feature);
int cpuSSE3AccelerationEnabled(void);

#endif
