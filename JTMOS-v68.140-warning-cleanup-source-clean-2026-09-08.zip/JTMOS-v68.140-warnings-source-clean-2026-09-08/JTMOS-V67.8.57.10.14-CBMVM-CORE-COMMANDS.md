# JTMOS V67.8.57.10.14 — CBMVM 0.6 core BASIC commands

CBMVM under `sdl2/cbmvm/` now contains the mandatory program-runtime layer for
ordinary tokenized Commodore BASIC plus the essential C128 BASIC 7 structured
control commands. The same engine is used by Linux/SDL2 and JTMOS/GraOS.

Implemented in this revision: DIM arrays, DATA/READ/RESTORE, INPUT/GET/GETKEY,
ON GOTO/GOSUB, WAIT, ELSE, DEF FN/FN, DO/LOOP/WHILE/UNTIL/EXIT, and the standard
math/string function set. Input and WAIT are cooperative and return YIELDED when
the host cannot complete them immediately.

Device/editor commands are intentionally not faked: channel/file I/O, LOAD/SAVE,
SYS/USR, direct-mode editor commands and sound/disk services require a later
explicit host-device API.
