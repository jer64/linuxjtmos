# JTMOS V67.8.57.10.18.16 — eMachines EL1352 MCP61 storage/audio bring-up

Target machine: Acer/eMachines EL1352-class nForce 430/MCP61 system.

## Storage: ATA sanity -> MCP61 SATA rescue -> AHCI

Boot storage selection is now deliberately conservative:

1. historical primary ATA/IDE driver (`0x1f0` path);
2. after IDENTIFY, **read sector 0 twice and compare the 512-byte results**;
3. if IDENTIFY or the real-sector sanity gate fails, probe NVIDIA MCP61 SATA
   (`10de:03e7`, `10de:03f6`, `10de:03f7`) as PCI native IDE/SATA;
4. only if MCP61 rescue also fails, try the existing generic PCI AHCI backend.

This matters on MCP61 because the SATA controller can present itself as an IDE-class
PCI function instead of standard AHCI.  The rescue backend therefore reads the actual
PCI BAR0..BAR3 task-file/control addresses instead of assuming `0x1f0`.

The MCP61 rescue implementation starts with polling PIO on purpose.  It supports:

- IDENTIFY DEVICE and LBA capability validation;
- LBA28 and LBA48 PIO reads/writes;
- ATA FLUSH CACHE / FLUSH CACHE EXT;
- two-read sector-0 sanity before it is allowed to register `hda`;
- existing JTMOS multi-block device API plus DAPI read/write-back caches.

Useful boot messages:

```text
IDE: sector-0 repeat-read sanity passed.
```

or, when rescue is needed:

```text
IDE: IDENTIFY succeeded but sector-read sanity failed; trying SATA rescue.
SATA rescue: found NVIDIA MCP61 SATA 03f6 at PCI ...
SATA rescue: MCP61 PCI ... taskfile=... ctrl=...
SATA rescue: IDENTIFY succeeded ...
SATA rescue: hda registered MCP61 PIO/LBA48 ...
HD: hda physical backend = NVIDIA MCP61 SATA rescue PIO.
```

## Audio: NVIDIA MCP61 HDA + Realtek ALC662

Added `kernel32/drivers/hda/hda.c` and `AUDIO_BACKEND_HDA` (`3`).
The first hardware backend is intentionally targeted to the EL1352 pair:

- HDA controller `10de:03f0`;
- codec `10ec:0662` (Realtek ALC662).

Bring-up path:

- exact MCP61 HDA PCI detection and BAR0 MMIO mapping;
- HDA controller reset with reset timing guard;
- codec discovery through the Immediate Command interface;
- Audio Function Group discovery;
- ALC662 front route `DAC 0x02 -> mixer 0x0c -> line-out pin 0x14`;
- headphone pin `0x1b` enabled as a secondary output;
- amplifier unmute/0 dB programming, including distinct input/output amp selects;
- one output stream, two-entry Buffer Descriptor List;
- fixed hardware format 48 kHz, signed 16-bit stereo;
- software conversion/resampling from the existing JTMOS U8 mono audio API;
- polling completion, so first physical-machine testing does not depend on IRQ/APIC
  routing yet.

AUTO audio selection now tries HDA first, then the historical SB16 and GUS backends.
If the kernel is built with `PCI=0`, HDA is compiled out cleanly and AUTO falls back
without unresolved HDA symbols.

Expected first successful audio detection:

```text
HDA: controller PCI 0:5.0 vendor=10de device=03f0 BAR0=...
HDA: STATESTS=...
HDA: codec 0 vendor/device=10ec:0662.
HDA: MCP61/ALC662 ready, output SD=..., polling 48kHz S16 stereo.
```

For an audible test, use an existing JTMOS player with **11025 Hz, unsigned 8-bit,
mono raw PCM**, for example:

```text
aud test.raw
```

`rawplay test.raw` exercises the same generic audio API.  AUTO should select HDA on
the EL1352 when `10de:03f0` + `10ec:0662` are detected.

## Validation in the build workspace

- all changed/new kernel C translation units compile successfully with the JTMOS
  i486 freestanding flags using `make -j2`;
- a second autogen test with `PCI=0` verifies that `drivers/hda/hda.o` is omitted and
  `drivers/audio/audio.c` still compiles;
- full kernel assembly/link was attempted, but the current build container has no
  NASM executable.  The failure occurs at the first NASM invocation before these
  driver changes are linked, so physical EL1352 boot testing remains required.
