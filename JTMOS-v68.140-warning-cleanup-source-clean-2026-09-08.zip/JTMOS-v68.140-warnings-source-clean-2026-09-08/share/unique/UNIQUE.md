# Unique 2.1 (.uni) for JTMOS

Unique is the native system scripting language of JTMOS.  Version 2.x replaces
the historical 2004 C++ `CUniScript` implementation with a freestanding C
runtime built around explicit structs (`UniContext`, `UniVariable`, `UniArray`,
`UniHash`, `UniFunction`, and `UniParser`).  No C++ ABI or libstdc++ is needed.

## Compatibility

The basic historical syntax remains valid:

```text
sub GameInit {
    $credits = 0;
    if ($credits == 0) { print "ready\n"; }
}
GameInit();
```

## Perl-like additions

```text
my $name = "JTMOS";
my @products = ("JTMOS", "Altse", "Vunet");
my %meta = ("language" => "Unique", "version" => 2);

sub greet($who) { say "hello $who"; }

foreach $product (@products) {
    say "product=$product";
}

if ($name eq "JTMOS") {
    say $meta{"language"};
} elsif ($name ne "") {
    warn "unexpected name";
} else {
    die "missing name";
}
```

Supported core constructs include `$scalar`, `@array`, `%hash`, indexing,
real block-scoped `my`, package/global `our`, `sub`, parameters plus `@_`, `if/elsif/else`, `while`, `foreach`,
`last`, `next`, `return`, `print`, `say`, numeric operators, string `.`
concatenation, numeric comparisons and Perl string comparisons (`eq/ne/lt/le/gt/ge`).
Double-quoted strings interpolate `$scalars`; single-quoted strings do not.

## JTMOS integration

`run("...")` first invokes the restricted SMSH builtin bridge; if the command
is not a kernel builtin it launches it through JTMOS `cexec`.  `kernel("...")`
requires the command to be a whitelisted SMSH builtin.  This lets `.uni` files
serve as boot/service/installation scripts without putting the interpreter in
ring 0.

Environment access is available with `getenv`, `setenv`, and `$ENV{"NAME"}`.
`@ARGV` contains script arguments and `$0` contains the script name.

## CLI

```text
unique script.uni arg1 arg2
unique -e 'say "hello";'
unique -c script.uni
unique --version
```


## `my` and `our`

`my` creates lexical storage in the current block/call frame.  It shadows an
outer variable of the same name and is destroyed when that lexical block ends.
This applies to scalars, arrays and hashes.

```text
our $name = "global";
{
    my $name = "local";
    say $name;          # local
}
say $name;              # global
```

An uninitialized declaration is valid: `my $x;`, `my @items;`, `my %meta;`.
`foreach my $item (...) { ... }` creates a loop lexical that disappears after
the loop.

`our` creates a lexical *binding* to package/global storage; it does not create
a second value.  Therefore an inner `our` can deliberately reach the package
variable even if an outer `my` shadows it.

```text
our $counter = 1;
{
    my $counter = 100;
    {
        our $counter;
        $counter += 1;  # changes package/global $counter
    }
    say $counter;       # 100
}
say $counter;           # 2
```

Subroutine parameters and `@_` belong to the called lexical frame.  A subroutine
does not dynamically see the caller's `my` variables.  File-scope `my` values
remain available to named subs as file lexicals.
