# 2004 UniScript C++ -> Unique 2.0 C port

The uploaded interpreter used a single C++ `CUniScript` class plus many static
class members (`uvar`, function tables, call stack, condition state and loaded
script state) and Win32 headers/types.  JTMOS Unique 2.0 deliberately removes
that model instead of emulating a C++ ABI inside the operating system.

The runtime state is now explicit C data:

- `UniContext`: one complete interpreter instance;
- `UniToken`: lexer output with source line information;
- `UniVariable`: scalar/array/hash symbol with lexical scope number;
- `UniArray` and `UniHash`: dynamic Perl-style collections;
- `UniFunction`: `sub` metadata and token range;
- `UniParser`: one execution frame/range.

This means multiple Unique interpreters can run concurrently without sharing
the old global/static variable database.  It also eliminates `windows.h`, C++
constructors, classes, default arguments, `static_cast`, `new/delete` and the
need for libstdc++.

The old game-specific callback API (for example `GlobalPalette`,
`NewAlphaBitmap`, `LoadSCN`) is intentionally not built into the JTMOS system
interpreter.  Those names belonged to the game embedding layer rather than the
language itself.  The supplied historical `.uni` files remain useful parser
examples; a future game can expose equivalent native functions through a small
C embedding adapter without changing the language core.
