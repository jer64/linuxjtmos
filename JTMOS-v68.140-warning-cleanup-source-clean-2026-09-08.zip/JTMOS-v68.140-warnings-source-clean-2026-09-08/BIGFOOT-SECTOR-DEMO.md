# JTMOS Bigfoot Sector Demo V1

Bigfoot keeps the public JTMOS `hda` logical sector size at 512 bytes. It only
changes how many adjacent logical sectors the SATA/AHCI backend submits in one
DMA command.

Capacity profile (512-byte logical sectors):

- <= 8 GiB: 4 KiB maximum transfer footprint
- <= 32 GiB: 16 KiB
- <= 128 GiB: 32 KiB
- <= 256 GiB: 64 KiB
- > 256 GiB: 128 KiB

A 500 GB disk therefore selects the 128 KiB profile. Smaller requests remain
smaller; the profile is a ceiling, not a forced physical sector size.

The DAPI write-back cache has 256 entries in V1, so a stream of 256 legacy
single-sector writes can be emitted as one 128 KiB multi-block request. Large
caller-supplied `writeblocks()` requests go directly to the SATA backend and
are split only at the selected Bigfoot ceiling.

`bigfoot.bin` is a read-only demo. It benchmarks 4, 16, 32, 64 and 128 KiB
request sizes over five separate 3 MiB windows beginning at LBA 2048. It never
calls `writeblock()` or `writeblocks()`.

This is deliberately a transfer/coalescing experiment. It does not change
FAT/JTMFS on-disk layout, MBR sector numbering, boot sectors, or the 512-byte
DEVAPI logical block contract.
