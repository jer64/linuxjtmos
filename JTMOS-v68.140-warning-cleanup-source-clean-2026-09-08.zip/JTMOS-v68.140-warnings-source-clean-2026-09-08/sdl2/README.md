# JTMOS SDL2 ports

`./sdl2/` is the common home/entry point for Linux SDL2 ports of JTMOS software.

* `cbmvm/` — CBMVM Linux/SDL2 host. The canonical BASIC/6502/VIC-II core and native GraOS
  utility now live under `libc/apps/cbmvm`.
* `graos/` — root-level entry point to the existing GraOS Linux/SDL2 host tree.

Build with the requested dual-core policy:

    make -C sdl2 -j2
    make -C sdl2/cbmvm -j2 test
    make -C libc/apps/cbmvm -j2

Linux CBMVM needs SDL 2.x development headers/libraries (`pkg-config sdl2` or
`sdl2-config`). Native JTMOS CBMVM does not link SDL; it uses the GraOS client
ABI and a 32-bit RGBA framebuffer window.
