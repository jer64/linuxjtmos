# CBMVM Linux/SDL2 host

This directory is now only the optional Linux/SDL2 frontend.  The canonical VM
core and native JTMOS/GraOS application live in `libc/apps/cbmvm`.

    make -C sdl2/cbmvm -j2       # Linux SDL2 host
    make -C sdl2/cbmvm test-core # host-side core regressions
    make -C sdl2/cbmvm jtmos     # canonical libc/apps/cbmvm.bin

This avoids maintaining two copies of the BASIC/6502/VIC-II core.
