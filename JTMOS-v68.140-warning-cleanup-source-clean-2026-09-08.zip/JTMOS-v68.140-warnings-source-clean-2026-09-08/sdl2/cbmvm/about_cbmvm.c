#include <stdio.h>
#include "about_cbmvm.h"
int about_cbmvm(void)
{
    printf("CBMVM 0.7 - Linux/SDL2 host for the canonical JTMOS CBMVM core.\n");
    printf("Usage: cbmvm program.prg\n");
    return 0;
}
