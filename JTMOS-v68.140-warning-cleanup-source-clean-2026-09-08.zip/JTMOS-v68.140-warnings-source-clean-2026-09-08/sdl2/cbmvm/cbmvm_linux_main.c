#include "about_cbmvm.h"
#include "cbmvm_sdl2.h"
int main(int argc, char **argv)
{
    if (argc < 2) { about_cbmvm(); return 0; }
    return cbmvm_sdl2_run_program(argc, argv);
}
