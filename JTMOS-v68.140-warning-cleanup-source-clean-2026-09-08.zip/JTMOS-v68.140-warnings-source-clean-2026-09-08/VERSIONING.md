# JTMOS versioning

JTMOS public releases use the compact **MAJOR.RELEASE** format.

- `68` is the current JTMOS major generation.
- The second component is a monotonically increasing release number.
- Current release: **V68.135**.
- Current normal release: **V68.140**.

The older multi-component version strings are historical lineage identifiers,
not new public version numbers.  V68.100 corresponds to the old lineage
`68.8.57.10.18.16.100`; V68.101 is the first maintenance/restoration release
after that public renumbering.

Build scripts should read the public version from the root `VERSION` file rather
than hard-code it in multiple places.
