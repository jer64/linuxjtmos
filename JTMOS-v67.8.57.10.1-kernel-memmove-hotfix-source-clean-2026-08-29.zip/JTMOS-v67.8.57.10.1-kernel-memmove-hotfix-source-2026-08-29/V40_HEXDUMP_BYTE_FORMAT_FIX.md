# JTMOS V40 - SMSH hexadecimal byte formatting fix

## Problem
SMSH `m` / `kmed` displayed bytes as single hexadecimal nibbles, for example:

    C0000: 5 A 4 E E 5 ...

instead of fixed-width byte values:

    C0000: 05 0A 04 EE E5 ...

## Root cause
The V39 memory dump used `printf("%c%c", high_nibble, low_nibble)`. JTMOS's internal `svprintf()` and `_vsprintf()` fetched `%c` arguments with `va_arg(arg, char)`. C default argument promotions pass a `char` as an `int` in a variadic call, so the fetch type was invalid.

## Fixes
1. `svprintf()` and `_vsprintf()` now use `(char)va_arg(arg, int)` for `%c`.
2. SMSH `smsh_print_hex_byte()` constructs a 3-byte string (`XX\\0`) and emits it with `%s`, making the memory dumper independent of single-character vararg handling.
3. Canonical sources and retained `tools/kernel32` / `graos-host` mirrors are synchronized.

Expected output now contains exactly two hexadecimal digits per byte, including leading zeroes.
