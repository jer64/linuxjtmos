;=================================================================================
; System loader for the 32-bit JTMOS operating system
; ---------------------------------------------------
;
; 3.5" 1.44M disk / IDE hard disk versions.
; Variable bootdrv specifies which boot drive is being used.
;
; (C) 2002-2018 by Jari Tuominen (jari.t.tuominen@gmail.com).
; Radically modified and converted from double segment version to COM stylish
; single segment executable.
; Special thanks to NASM tutorial for providing information:
; "The Netwide Assembler: NASM - Chapter 10: Troubleshooting"
; http://home.comcast.net/~fbkotler/nasmdo10.html
;=================================================================================
;
;	I decided to modify the bootloader so that it automatically
;	boots up the kernel(without asking to press a key to start it).
;	This makes possible to test it without keyboard f.e.
;	Set WAIT_KEY to 1 if you want to it to ask a key press.
;
[bits 16]
org 0x100 ; 'COM file' start address (Yes, this is [.COM] file actually).
; V67.8.13: stay in BIOS/VGA text mode during boot by default.
; Set BOOT_VESA_GRAPHICS to 1 only for a special diagnostic build.  When that
; option is used, kernel32 mirrors the logical 80x25 console into the LFB from
; the beginning instead of leaving a black graphics screen.
%define BOOT_VESA_GRAPHICS 0
%define GRAOS_VESA_MODE 0x0118 ; candidate VBE 1024x768 direct-color mode; validated as 32 bpp
%define GRAOS_VESA_FALLBACK_MODE 0x0112 ; candidate recovery 640x480 direct-color mode; validated as 32 bpp
%define VESA_BOOT_HANDOFF_SIGNATURE 0x41534556 ; "VESA", physical 0x4100
%ifdef BOOT32PM_CANDIDATE
%define BOOT_IMAGE_SEGMENT 0x07B0
%define BOOT_IMAGE_BASE    0x00007B00
%define BOOT_REBASE(x)     (BOOT_IMAGE_BASE + (x))
%endif
;
%include "../kernel32/include/memory_layout.inc"
%ifndef BOOT32PM_CANDIDATE
%if JTMOS_KERNEL_LOAD_PHYS != 0x00010000
    %error "Relocated JTMOS kernels require the protected-mode candidate entry path"
%endif
%endif
%include "bios.mac" ;;;; (puts,putchar)
%include "bootmod.inc" ;;;; Boot Module (Calls BIOS to read rest of boot+krn)
jmp start ; Jump to PMODE initialization code.

%include "header.inc" ;;;; Bootsector header
;%include "bloche.inc" ; obsolete

%include "seg.mac" ;;;; Segment Descriptor Macros
%include "text.inc" ;;;; Any text things bootsector code needs
; moved text.inc to bootmod.inc
%include "a20.inc" ;;;; A20 line setup code
%include "detection.inc" ;;;; Detects drives.
%include "e820.inc" ;;;; BIOS E820 memory-map handoff for kernel32.
;
WAIT_KEY equ 0
;----------------------------------------------------------------------------
code16  dw 0
;----------------------------------------------------------------------------
; main procedure, this is the entry point to the kernel
start:
        ; Stop floppy motor.
        mov dx,0x3F2
        mov al,0
        out dx,al
	; Fix keyboard buffer(empty it).
	mov cx,2000
	mov dx,0x60
indeed:
	in al,dx
	dec cx
	jnz indeed

        ; Begin protected mode setup code ...
	mov	ax,cs		; load code-segment into DS and ES
	mov	ds,ax
	mov	es,ax

        mov     ax,cs           ; get '32-bit' code segment into AX
	movzx	eax,ax		; clear high word
	shl	eax,4		; make a physical address
        add     eax,dummy_descriptor ; calculate physical address of GDT
        mov     dword [ds:gdt_start+2],eax

        mov     ax,cs           ; get '32-bit' code segment into AX
	movzx	eax,ax		; clear high word
	shl	eax,4		; make a physical address
        add     eax,interrupt_0  ; calculate physical address of IDT
        mov     dword [ds:idt_start+2],eax


        ; Wait A key
	mov ax,WAIT_KEY
	cmp ax,0
	je dont_wait_key
        puts str_key
        mov ax,0
        int 0x16
dont_wait_key:

	; Capture the BIOS physical-memory map while INT 15h services are still
	; available. kernel32 consumes this after entering protected mode.
	call detect_e820

	; Clear the explicit VESA handoff marker first.  The kernel will not trust
	; stale bytes in the low-memory ModeInfoBlock unless this marker is set.
	push es
	mov ax,0x0400
	mov es,ax
	mov dword [es:0x0100],0
	pop es

	; -- VESA job. --
	; 0x100	640x400x8	graphics	yes
	; 0x102	800x600x4	graphics	no
	; 0x103	800x600x8	graphics	yes	
	; 0x112	640x480 direct-color candidate	graphics	yes

%if BOOT_VESA_GRAPHICS
    ; Try only direct-color candidates. try_vesa_mode rejects every mode unless
    ; its ModeInfoBlock explicitly reports 32 bpp direct color.
    mov cx,GRAOS_VESA_MODE
    call try_vesa_mode
    jnc vesa_okay

    mov cx,GRAOS_VESA_FALLBACK_MODE
    call try_vesa_mode
    jnc vesa_okay

vesa_error:
    puts str_bad_vesa
    jmp $
vesa_okay:
    ; ModeInfoBlock is at physical 0x4000.  Write a separate success marker
    ; at 0x4100 so kernel32 can safely detect that boot32 really selected VESA.
    mov ax,0x0400
    mov es,ax
    mov dword [es:0x0100],VESA_BOOT_HANDOFF_SIGNATURE
%endif

	; Default path deliberately does not issue VBE 4F02.  The mode-info marker
	; remains zero and GraOS will request graphics later through kernel32.
	; ^^VESA job done.^^

	; Max. keyboard repeat rate.
	mov	ax,0x0305
	xor	bx,bx
	int	0x16

	; Disable NMI.
	mov al,0x80
	mov dx,0x70
	out dx,al

	; A20 setup.
        call a20

        ; -------- Let's go to the kernel.
	; Disable interrupts.
        cli
        ; Load descriptor tables.
        lgdt    [dword global_descriptor_table]
        lidt    [dword interrupt_descriptor_table]

%ifdef BOOT32PM_CANDIDATE
	; Candidate-only smoke test: enter 32-bit protected mode, return through
	; the 16-bit protected selector to real mode, then enter PM for real.
	call pmode_roundtrip
	cmp byte [cs:pmode_probe_ok],1
	jne pmode_probe_failed
	lgdt [dword global_descriptor_table]
	lidt [dword interrupt_descriptor_table]
	; pmode_on performs the mandatory far jump immediately after CR0.PE is
	; changed.  It must not return through a real-mode CS cache.
	jmp pmode_on
pmode_probe_failed:
	puts str_pmode_failed
	jmp $
%else
        ; Enter protected mode.
        mov     eax,cr0
        or      al,1
        mov     cr0,eax

	; Make mandatory jump.
        jmp shortjump0
shortjump0:

        ;
        ;***************************************************
        ; ENTER KERNEL32
        ; 
        ; Setup protected mode stack in the kernel-reserved 0x1E0000..0x1EFFFF area.
        mov esp,JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP
        mov ax,0x18
        mov ss,ax
        ; Also define rest of the segments, just to prevent
        ; additional errors occuring.
        mov ds,ax
        mov es,ax
        mov fs,ax
        mov gs,ax

	; Make another jump.
        jmp shortjump1
shortjump1:

	; Jump at linear address 0x10000.
	; Jump ssss:oooooooo, 16:32, segment:offset.
	db 0x66,0xEA
	dd 0x00010000
	dw code32_idx
;	db	0xEA            ; opcode for far jump (to set CS correctly)
;	dw	0x10000,code32_idx
%endif

%ifdef BOOT32PM_CANDIDATE
; ---------------------------------------------------------------------------
; boot32pm protected-mode candidate.
; The GDT has base-zero 32-bit and 16-bit code/data selectors. BOOT_REBASE()
; converts this COM image's ORG-relative labels to their physical addresses.
pmode_on:
	cli
	mov eax,cr0
	or eax,1
	mov cr0,eax
	jmp dword code32_idx:BOOT_REBASE(pmode_kernel_entry32)

; Call only while executing through the 16-bit protected-mode selector.
pmode_off:
	mov eax,cr0
	and eax,0xFFFFFFFE
	mov cr0,eax
	; Reload CS immediately after leaving protected mode.  A near RET here is
	; invalid because CS still has the protected-mode descriptor cache.
	jmp word BOOT_IMAGE_SEGMENT:pmode_real_return

pmode_roundtrip:
	cli
	mov byte [cs:pmode_probe_ok],0
	mov eax,cr0
	or eax,1
	mov cr0,eax
	jmp dword code32_idx:BOOT_REBASE(pmode_probe32)

[bits 32]
pmode_probe32:
	mov ax,data32_idx
	mov ds,ax
	mov es,ax
	mov fs,ax
	mov gs,ax
	mov byte [BOOT_REBASE(pmode_probe_ok)],1
	jmp word code16_idx:BOOT_REBASE(pmode_probe16)

[bits 16]
pmode_probe16:
	mov ax,data16_idx
	mov ds,ax
	mov es,ax
	mov fs,ax
	mov gs,ax
	jmp pmode_off

pmode_real_return:
	mov ax,cs
	mov ds,ax
	mov es,ax
	lidt [cs:real_mode_idtr]
	ret

%ifdef BOOT32PM_STREAM_KERNEL
; Real-mode callable high-memory copy. The caller has already filled the
; 64 KiB bounce window and stored destination/count in stream_* variables.
; No stack accesses occur while SS still carries its real-mode descriptor
; cache; this keeps the PM round-trip independent of a protected-mode stack.
pmode_stream_copy:
	cli
	mov ax,cs
	mov ds,ax
	mov es,ax
	lgdt [dword global_descriptor_table]
	mov eax,cr0
	or eax,1
	mov cr0,eax
	jmp dword code32_idx:BOOT_REBASE(pmode_stream_copy32)

[bits 32]
pmode_stream_copy32:
	mov ax,data32_idx
	mov ds,ax
	mov es,ax
	mov fs,ax
	mov gs,ax
	mov esi,0x00010000
	mov edi,dword [BOOT_REBASE(stream_high_dest)]
	mov ecx,dword [BOOT_REBASE(stream_chunk_bytes)]
	mov edx,ecx
	shr ecx,2
	cld
	rep movsd
	mov ecx,edx
	and ecx,3
	rep movsb
	jmp word code16_idx:BOOT_REBASE(pmode_stream_copy16)

[bits 16]
pmode_stream_copy16:
	mov ax,data16_idx
	mov ds,ax
	mov es,ax
	mov fs,ax
	mov gs,ax
	mov eax,cr0
	and eax,0xFFFFFFFE
	mov cr0,eax
	jmp word BOOT_IMAGE_SEGMENT:pmode_stream_real_return

pmode_stream_real_return:
	mov ax,cs
	mov ds,ax
	mov es,ax
	lidt [cs:real_mode_idtr]
	sti
	ret
%endif

[bits 32]
pmode_kernel_entry32:
	mov ax,core32_idx
	mov ss,ax
	mov ds,ax
	mov es,ax
	mov fs,ax
	mov gs,ax
	mov esp,JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP
%ifdef BOOT32PM_NZIP_KERNEL
	; V67.8.57.1 path. BIOS/PMODE streaming staged kernel32.bin.nz in
	; the 16 MiB boot scratch window. Expand it into the linked 1 MiB kernel
	; address. The decoder also computes the checksum over exactly raw_bytes.
	call nzip_decompress_kernel32
	test eax,eax
	jnz pmode_nzip_failed32
	jmp dword code32_idx:JTMOS_KERNEL_LOAD_PHYS
pmode_nzip_failed32:
	; Preserve a machine-readable failure code and a tiny VGA diagnostic. No
	; BIOS calls are legal here because we are already in protected mode.
	mov dword [0x00001008],eax
	mov word [0x000B8000],0x4F4E ; N
	mov word [0x000B8002],0x4F5A ; Z
	mov word [0x000B8004],0x4F21 ; !
	cli
.halt_nzip:
	hlt
	jmp .halt_nzip
%else
%ifdef BOOT32_RAW_RELOCATE_KERNEL_1M
	; Legacy boot32 comparison path: stage raw kernel32.bin below 1 MiB, then
	; copy only the actual file bytes to the linked address.
	cld
	mov esi,0x00010000
	mov edi,JTMOS_KERNEL_LOAD_PHYS
	mov ecx,kernel_raw_bytes
	mov edx,ecx
	shr ecx,2
	rep movsd
	mov ecx,edx
	and ecx,3
	rep movsb
	jmp dword code32_idx:JTMOS_KERNEL_LOAD_PHYS
%else
	jmp dword code32_idx:0x00010000
%endif
%endif

%ifdef BOOT32PM_NZIP_KERNEL
; ---------------------------------------------------------------------------
; Tiny protected-mode decoder for the historical nzip legacy stream.
;
; Supported records (little endian):
;   E3 FC, len16, byte      RLE
;   E4 FC, len16, off32     absolute non-overlapping back-reference
;   EF FC, byte, byte       escaped literal marker-looking pair
;   EE FC                   end
;
; kernel32.bin.nz is deliberately produced with `nzip --legacy`; an E5 FC BWT
; record is rejected instead of pulling the large BWT inverse transform into
; the 9 KiB boot track.
;
; Input : JTMOS_BOOT_NZIP_STAGING_PHYS .. +kernel_nz_bytes
; Output: JTMOS_KERNEL_LOAD_PHYS .. +kernel_raw_bytes
; Return: EAX=0 success, nonzero compact error code.
nzip_decompress_kernel32:
	cld
	mov esi,JTMOS_BOOT_NZIP_STAGING_PHYS
	mov edi,JTMOS_KERNEL_LOAD_PHYS
	mov edx,(JTMOS_BOOT_NZIP_STAGING_PHYS + kernel_nz_bytes)
	mov ebp,(JTMOS_KERNEL_LOAD_PHYS + kernel_raw_bytes)

.nz_next:
	cmp esi,edx
	jae .nz_err_truncated
	movzx eax,byte [esi]
	inc esi
	cmp al,0xE3
	je .nz_marker
	cmp al,0xE4
	je .nz_marker
	cmp al,0xE5
	je .nz_marker
	cmp al,0xEE
	je .nz_marker
	cmp al,0xEF
	je .nz_marker

.nz_literal:
	cmp edi,ebp
	jae .nz_err_output
	mov byte [edi],al
	inc edi
	jmp .nz_next

.nz_marker:
	cmp esi,edx
	jae .nz_err_truncated
	movzx ebx,byte [esi]
	inc esi
	cmp bl,0xFC
	jne .nz_not_control
	cmp al,0xEE
	je .nz_end
	cmp al,0xEF
	je .nz_fix
	cmp al,0xE3
	je .nz_rle
	cmp al,0xE4
	je .nz_backref
	cmp al,0xE5
	je .nz_err_bwt
	jmp .nz_err_format

.nz_not_control:
	; b0 was literal; reprocess b1 because it may itself begin a marker.
	cmp edi,ebp
	jae .nz_err_output
	mov byte [edi],al
	inc edi
	dec esi
	jmp .nz_next

.nz_fix:
	lea ebx,[esi+2]
	cmp ebx,edx
	ja .nz_err_truncated
	lea ebx,[edi+2]
	cmp ebx,ebp
	ja .nz_err_output
	mov ax,word [esi]
	mov word [edi],ax
	add esi,2
	add edi,2
	jmp .nz_next

.nz_rle:
	lea ebx,[esi+3]
	cmp ebx,edx
	ja .nz_err_truncated
	movzx ecx,word [esi]
	add esi,2
	test ecx,ecx
	jz .nz_err_format
	mov al,byte [esi]
	inc esi
	mov ebx,edi
	add ebx,ecx
	jc .nz_err_output
	cmp ebx,ebp
	ja .nz_err_output
	rep stosb
	jmp .nz_next

.nz_backref:
	lea ebx,[esi+6]
	cmp ebx,edx
	ja .nz_err_truncated
	movzx ecx,word [esi]
	add esi,2
	mov eax,dword [esi]
	add esi,4
	test ecx,ecx
	jz .nz_err_format
	; offset must name already-produced output and legacy nzip forbids overlap.
	mov ebx,edi
	sub ebx,JTMOS_KERNEL_LOAD_PHYS
	cmp eax,ebx
	jae .nz_err_backref
	sub ebx,eax
	cmp ecx,ebx
	ja .nz_err_backref
	mov ebx,edi
	add ebx,ecx
	jc .nz_err_output
	cmp ebx,ebp
	ja .nz_err_output
	push esi
	mov esi,JTMOS_KERNEL_LOAD_PHYS
	add esi,eax
	rep movsb
	pop esi
	jmp .nz_next

.nz_end:
	cmp edi,ebp
	jne .nz_err_size
	; Exact uncompressed checksum handoff expected by kernel32/init/start.c.
	mov esi,JTMOS_KERNEL_LOAD_PHYS
	mov ecx,kernel_raw_bytes
	xor eax,eax
.nz_sum:
	test ecx,ecx
	jz .nz_sum_done
	movzx ebx,byte [esi]
	add ax,bx
	inc esi
	dec ecx
	jmp .nz_sum
.nz_sum_done:
	mov word [0x00001002],ax
	cmp ax,word [0x00001000]
	jne .nz_err_checksum
	xor eax,eax
	ret

.nz_err_truncated: mov eax,1
	ret
.nz_err_output:    mov eax,2
	ret
.nz_err_format:    mov eax,3
	ret
.nz_err_backref:   mov eax,4
	ret
.nz_err_bwt:       mov eax,5
	ret
.nz_err_size:      mov eax,6
	ret
.nz_err_checksum:  mov eax,7
	ret
%endif

[bits 16]
real_mode_idtr:
	dw 0x03FF
	dd 0x00000000
pmode_probe_ok db 0
str_pmode_failed db 13,10,"boot32pm: protected-mode roundtrip failed.",13,10,0
%endif



;----------------------------------------------------------------------------
; Input: CX = VBE mode number.  Output: CF=0 success, CF=1 failure.
; Refreshes the 256-byte ModeInfoBlock at physical 0x4000 for the selected
; mode and requests a linear framebuffer via VBE bit 14.
try_vesa_mode:
    push cx
    mov ax,0x0400
    mov es,ax
    xor di,di
    mov ax,0x4F01
    int 0x10
    pop cx
    cmp ax,0x004F
    jne try_vesa_mode_fail
    cmp byte [es:di+0x19],32       ; BitsPerPixel
    jne try_vesa_mode_fail
    cmp byte [es:di+0x1B],6        ; Direct Color memory model
    jne try_vesa_mode_fail

    push cx
    mov bx,cx
    or bx,0x4000
    mov ax,0x4F02
    int 0x10
    pop cx
    cmp ax,0x004F
    jne try_vesa_mode_fail
    clc
    ret
try_vesa_mode_fail:
    stc
    ret

no_vesa:
	pushad
	push ds
	mov bp,0x400
	mov ds,bp
	mov bp,0x28
	mov word [ds:bp+0],ax
	mov word [ds:bp+2],ax
	pop ds
	popad
	ret
;----------------------------------------------------------------------------
storeinfo:
	pushf
	; Push info
	push ax
	mov ax,0
	mov ds,ax
	pop ax

	; Pull info to location
	mov word [ds:bp],ax
	add bp,2
	mov word [ds:bp],bx
	add bp,2
	mov word [ds:bp],cx
	add bp,2
	mov word [ds:bp],dx
	add bp,2
	mov ax,es
	mov word [ds:bp],ax
	add bp,2
	mov ax,di
	mov word [ds:bp],ax
	add bp,2

	popf
	jc  case1
	mov ax,0
	jmp ncase1
case1:
	mov ax,1
ncase1:
	mov word [ds:bp],ax
	ret
;----------------------------------------------------------------------------
global_descriptor_table:     ; here begins the GDT
;
gdt_start:        dw                 gdt_size,0,0            ; val for GDT reg
;
gdtoff:
segdes dummy_descriptor,0xFFFF,0,0,0x9A,0xCF,0
segdes code32_descriptor,0xFFFF,0,0,0x9A,0xCF,0
segdes data32_descriptor,0xFFFF,0,0,0x92,0xCF,0
segdes core32_descriptor,0xFFFF,0,0,0x92,0xCF,0
segdes code16_descriptor,0xFFFF,0,0,0x9A,0,0
segdes data16_descriptor,0xFFFF,0,0,0x92,0,0

gdt_size equ $-(dummy_descriptor)

code32_idx      equ   0x08              ; offset of 32-bit code segment in GDT
data32_idx      equ   0x10              ; offset of 32-bit data segment in GDT
core32_idx      equ   0x18              ; offset of 32-bit core segment in GDT
code16_idx      equ   0x20              ; 16-bit protected-mode code
data16_idx      equ   0x28              ; 16-bit protected-mode data

interrupt_descriptor_table: ;*** here begins the IDT ***;

idt_start:      dw                      idt_size,0,0
intdes interrupt_0,demo_int,code32_idx,0,0x8E,0

idt_size equ $-(interrupt_0)
;----------------------------------------------------------------------------
demo_int:
	iretd
;----------------------------------------------------------------------------
