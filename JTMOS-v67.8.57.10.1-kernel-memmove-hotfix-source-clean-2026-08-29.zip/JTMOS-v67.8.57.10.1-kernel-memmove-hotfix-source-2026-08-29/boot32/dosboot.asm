;=================================================================================
; JTMOS protected-mode starter for MS-DOS
; ---------------------------------------
;
; V67.8.57.9 DOS path:
;   DOS INT 21h reads KERNEL32.NZ through a 64 KiB conventional-memory bounce
;   area.  Because AH=3Fh has a 16-bit byte count, each full 64 KiB chunk is
;   filled by two 32 KiB reads.  The completed chunk is copied in protected
;   mode to JTMOS_BOOT_NZIP_STAGING_PHYS (16 MiB), exactly like the BIOS
;   HDD/floppy boot32pm path.  After the compressed stream has been staged,
;   the loader enters protected mode permanently and expands it directly to
;   JTMOS_KERNEL_LOAD_PHYS (0x00100000).
;
; The compressed input is deliberately kept separate from the 1 MiB raw-kernel
; destination.  Forward in-place decompression at 0x00100000 would overwrite
; unread nzip input.
;
; (C) 2006-2026 by Jari Tuominen.
;=================================================================================

[bits 16]
org 0x100

%define BOOT_VESA_GRAPHICS 0
%define VESA_BOOT_HANDOFF_SIGNATURE 0x41534556
%define DOS_READ_HALF_CHUNK 0x8000
%define DOS_CHUNK_BYTES     0x10000
%define DOS_BOUNCE_PARAS    0x1000

%include "../kernel32/include/memory_layout.inc"
%include "doskernelmeta.inc"
%include "seg.mac"
%include "a20.inc"
%include "e820.inc"

%if kernel_raw_bytes > 1048576
    %error "dosboot: raw kernel exceeds the 1 MiB linked kernel window"
%endif
%if kernel_nz_bytes > JTMOS_BOOT_NZIP_STAGING_BYTES
    %error "dosboot: compressed kernel exceeds the 1 MiB nzip staging window"
%endif

; The selector values intentionally match boot32pm for the selectors inherited
; by kernel32.  code32 is temporarily rebased to the DOS COM image while the
; loader runs, then restored to flat base zero immediately before kernel entry.
code32_idx          equ 0x08
data32_idx          equ 0x10
core32_idx          equ 0x18
code16_idx          equ 0x20
data16_idx          equ 0x28
loader_data32_idx   equ 0x30

begin:
        jmp start

;------------------------------------------------------------------------------
; DOS entry. CS=DS=ES=SS=PSP for a normal .COM launch.
;------------------------------------------------------------------------------
start:
        cli
        mov ax,cs
        mov ds,ax
        mov es,ax
        mov ss,ax
        mov sp,dos_stack_top
        sti
        cld

        mov [program_segment],ax

        mov dx,msg_banner
        call dos_puts

        ; Direct CR0/GDT transitions require genuine real mode.  EMM386,
        ; Windows Enhanced Mode and similar hosts run DOS applications in V86;
        ; touching CR0 there would fault instead of booting JTMOS.
        pushfd
        pop eax
        test eax,0x00020000
        jnz dos_v86_unsupported

        ; DOS current drive is 0=A:, 1=B:, 2=C: ... and is the closest useful
        ; equivalent of the BIOS boot-drive handoff for a DOS-launched kernel.
        mov ah,0x19
        int 0x21
        xor ah,ah
        mov [boot_drive_word],ax

        call prepare_bounce_area
        jc dos_not_enough_memory
        call init_loader_tables

        mov dx,kernel_filename
        mov ax,0x3D00                 ; DOS open read-only
        int 0x21
        jc dos_open_failed
        mov [dos_handle],ax

        mov dx,msg_loading
        call dos_puts

        ; High-memory PM copies require A20.  a20() deliberately CLI's while it
        ; talks to the 8042, so explicitly re-enable interrupts before DOS I/O.
        call a20
        sti

        mov dword [stream_high_dest],JTMOS_BOOT_NZIP_STAGING_PHYS
        mov dword [stream_remaining],kernel_nz_bytes

.dos_chunk_loop:
        mov eax,dword [stream_remaining]
        test eax,eax
        jz .dos_stream_done
        cmp eax,DOS_CHUNK_BYTES
        jbe .dos_chunk_size_ready
        mov eax,DOS_CHUNK_BYTES
.dos_chunk_size_ready:
        mov dword [stream_chunk_bytes],eax

        ; First half: min(chunk, 32 KiB) -> bounce:0000.
        mov ecx,eax
        cmp ecx,DOS_READ_HALF_CHUNK
        jbe .dos_first_count_ready
        mov ecx,DOS_READ_HALF_CHUNK
.dos_first_count_ready:
        mov si,cx
        mov ax,[bounce_segment]
        mov ds,ax
        xor dx,dx
        mov bx,[cs:dos_handle]
        mov ah,0x3F
        int 0x21
        jc .dos_read_error_ds_bounce
        cmp ax,si
        jne .dos_short_read_ds_bounce

        ; Full chunks and final chunks larger than 32 KiB use a second DOS read
        ; into the upper half of the SAME 64 KiB bounce window.
        mov eax,dword [cs:stream_chunk_bytes]
        cmp eax,DOS_READ_HALF_CHUNK
        jbe .dos_chunk_filled
        sub eax,DOS_READ_HALF_CHUNK
        mov cx,ax                      ; remaining part is <= 0x8000
        mov si,cx
        mov dx,DOS_READ_HALF_CHUNK
        mov bx,[cs:dos_handle]
        mov ah,0x3F
        int 0x21
        jc .dos_read_error_ds_bounce
        cmp ax,si
        jne .dos_short_read_ds_bounce

.dos_chunk_filled:
        push cs
        pop ds

        ; One PM round-trip per completed <=64 KiB chunk.  pmode_stream_copy32
        ; sees a flat source physical address and copies into the 16 MiB nzip
        ; staging area; it never writes the raw 1 MiB kernel destination.
        call pmode_stream_copy

        mov eax,dword [stream_chunk_bytes]
        add dword [stream_high_dest],eax
        sub dword [stream_remaining],eax
        jmp .dos_chunk_loop

.dos_read_error_ds_bounce:
        push cs
        pop ds
        jmp dos_read_failed

.dos_short_read_ds_bounce:
        push cs
        pop ds
        jmp dos_short_read

.dos_stream_done:
        mov bx,[dos_handle]
        mov ah,0x3E
        int 0x21                       ; close before abandoning DOS

        mov dx,msg_loaded
        call dos_puts

        ; Do not touch the historical JTMOS low-memory handoff locations while
        ; DOS file services are still needed: 0x1000/0x4200/0x7C00 may overlap
        ; DOS-owned low memory.  Publish them only after the file is closed and
        ; there will be no further INT 21h calls.
        call detect_e820
        push es
        mov ax,0x0400
        mov es,ax
        mov dword [es:0x0100],0
        pop es
        call prepare_low_handoff

        ; Disable NMI during the final mode transition, matching boot32.
        mov al,0x80
        out 0x70,al

        cli
        lgdt [global_descriptor_table]
        lidt [interrupt_descriptor_table]
        mov eax,cr0
        or eax,1
        mov cr0,eax
        jmp dword code32_idx:pmode_kernel_entry32

;------------------------------------------------------------------------------
; Prepare conventional-memory 64 KiB bounce area immediately after this COM
; image.  The dedicated loader stack is inside the image, so the bounce region
; cannot overwrite the active DOS stack.  PSP:0002 contains the segment just
; beyond the memory block DOS owns for this process.
; Return CF=1 if a full additional 64 KiB does not fit.
;------------------------------------------------------------------------------
prepare_bounce_area:
        mov ax,cs
        add ax,DOS_PROGRAM_PARAS
        mov [bounce_segment],ax
        mov dx,ax
        add dx,DOS_BOUNCE_PARAS
        jc .no_room
        cmp dx,[cs:0x0002]
        ja .no_room
        movzx eax,word [bounce_segment]
        shl eax,4
        mov dword [stream_bounce_phys],eax
        clc
        ret
.no_room:
        stc
        ret

;------------------------------------------------------------------------------
; Publish the same low-memory contract as boot32pm.
; 1000 expected raw checksum
; 1002 measured raw checksum (filled by nzip decoder)
; 1004 DOS current drive
; Also provide the legacy boot-sector signature/drive bytes inspected later by
; InitSystem() so DOS boot does not produce a false "invalid loader" warning.
;------------------------------------------------------------------------------
prepare_low_handoff:
        push ax
        push es
        xor ax,ax
        mov es,ax
        mov word [es:0x1000],kchecksum
        mov word [es:0x1002],0
        mov ax,[cs:boot_drive_word]
        mov word [es:0x1004],ax
        mov byte [es:0x7DFD],al
        mov word [es:0x7DFE],0xAA55
        pop es
        pop ax
        ret

;------------------------------------------------------------------------------
; Build a GDT whose loader code/data selectors are based at the runtime COM
; segment, while the kernel data selectors are already flat.  This lets a DOS
; program loaded at ANY conventional-memory segment execute temporary PM code.
;------------------------------------------------------------------------------
init_loader_tables:
        pushad
        mov ax,cs
        mov [pmode_stream_real_segment],ax
        movzx eax,ax
        shl eax,4
        mov dword [loader_phys_base],eax

        mov ebx,eax
        add ebx,dummy_descriptor
        mov dword [gdt_start+2],ebx
        mov ebx,eax
        add ebx,interrupt_0
        mov dword [idt_start+2],ebx

        mov edx,eax
        mov word [code32_descriptor+2],dx
        shr edx,16
        mov byte [code32_descriptor+4],dl
        mov byte [code32_descriptor+7],dh

        mov edx,eax
        mov word [code16_descriptor+2],dx
        shr edx,16
        mov byte [code16_descriptor+4],dl
        mov byte [code16_descriptor+7],dh

        mov edx,eax
        mov word [data16_descriptor+2],dx
        shr edx,16
        mov byte [data16_descriptor+4],dl
        mov byte [data16_descriptor+7],dh

        mov edx,eax
        mov word [loader_data32_descriptor+2],dx
        shr edx,16
        mov byte [loader_data32_descriptor+4],dl
        mov byte [loader_data32_descriptor+7],dh
        popad
        ret

;------------------------------------------------------------------------------
; Real-mode callable <=64 KiB bounce -> high-memory copy.
; DOS has filled bounce_segment:0000.  No stack operations are performed after
; PE is enabled, so the DOS real-mode SS cache does not become a PM dependency.
;------------------------------------------------------------------------------
pmode_stream_copy:
        cli
        lgdt [global_descriptor_table]
        lidt [interrupt_descriptor_table]
        mov eax,cr0
        or eax,1
        mov cr0,eax
        jmp dword code32_idx:pmode_stream_copy32

[bits 32]
pmode_stream_copy32:
        mov ax,data32_idx
        mov ds,ax
        mov es,ax
        mov gs,ax
        mov ax,loader_data32_idx
        mov fs,ax

        mov esi,dword [fs:stream_bounce_phys]
        mov edi,dword [fs:stream_high_dest]
        mov ecx,dword [fs:stream_chunk_bytes]
        mov edx,ecx
        shr ecx,2
        cld
        rep movsd
        mov ecx,edx
        and ecx,3
        rep movsb
        jmp word code16_idx:pmode_stream_copy16

[bits 16]
pmode_stream_copy16:
        mov ax,data16_idx
        mov ds,ax
        mov es,ax
        mov fs,ax
        mov gs,ax
        mov eax,cr0
        and eax,0xFFFFFFFE
        mov cr0,eax
        ; Immediate far jump is self-patched with the original DOS CS.
pmode_stream_real_jump:
        db 0xEA
        dw pmode_stream_real_return
pmode_stream_real_segment:
        dw 0

pmode_stream_real_return:
        mov ax,cs
        mov ds,ax
        mov es,ax
        mov fs,ax
        mov gs,ax
        lidt [real_mode_idtr]
        sti
        ret

;------------------------------------------------------------------------------
; Final protected-mode entry.  The nzip decoder consumes the high staging copy
; and writes the exact raw image to 0x00100000.  After successful verification,
; code32's descriptor base is changed from the DOS COM base to zero and the far
; jump reloads CS with the same flat selector used by boot32pm/kernel32.
;------------------------------------------------------------------------------
[bits 32]
pmode_kernel_entry32:
        mov ax,core32_idx
        mov ss,ax
        mov ds,ax
        mov es,ax
        mov gs,ax
        mov esp,JTMOS_KERNEL_EARLY_STACK_INITIAL_ESP
        mov ax,loader_data32_idx
        mov fs,ax

        call nzip_decompress_kernel32
        test eax,eax
        jnz pmode_nzip_failed32

        ; Current CS keeps its cached DOS-COM base until the far jump below.
        ; Only the descriptor TABLE entry is flattened here.
        mov word [fs:code32_descriptor+2],0
        mov byte [fs:code32_descriptor+4],0
        mov byte [fs:code32_descriptor+7],0
        mov ax,core32_idx
        mov fs,ax
        jmp dword code32_idx:JTMOS_KERNEL_LOAD_PHYS

pmode_nzip_failed32:
        mov dword [0x00001008],eax
        mov word [0x000B8000],0x4F44   ; D
        mov word [0x000B8002],0x4F4F   ; O
        mov word [0x000B8004],0x4F53   ; S
        mov word [0x000B8006],0x4F4E   ; N
        mov word [0x000B8008],0x4F5A   ; Z
        mov word [0x000B800A],0x4F21   ; !
        cli
.halt:
        hlt
        jmp .halt

;------------------------------------------------------------------------------
; Tiny protected-mode nzip legacy decoder.  This intentionally matches the
; boot32pm decoder and accepts only the boot-safe --legacy record set.
;------------------------------------------------------------------------------
nzip_decompress_kernel32:
        cld
        mov esi,JTMOS_BOOT_NZIP_STAGING_PHYS
        mov edi,JTMOS_KERNEL_LOAD_PHYS
        mov edx,(JTMOS_BOOT_NZIP_STAGING_PHYS + kernel_nz_bytes)
        mov ebp,(JTMOS_KERNEL_LOAD_PHYS + kernel_raw_bytes)

.nz_next:
        cmp esi,edx
        jae .nz_err_truncated
        movzx eax,byte [esi]
        inc esi
        cmp al,0xE3
        je .nz_marker
        cmp al,0xE4
        je .nz_marker
        cmp al,0xE5
        je .nz_marker
        cmp al,0xEE
        je .nz_marker
        cmp al,0xEF
        je .nz_marker

.nz_literal:
        cmp edi,ebp
        jae .nz_err_output
        mov byte [edi],al
        inc edi
        jmp .nz_next

.nz_marker:
        cmp esi,edx
        jae .nz_err_truncated
        movzx ebx,byte [esi]
        inc esi
        cmp bl,0xFC
        jne .nz_not_control
        cmp al,0xEE
        je .nz_end
        cmp al,0xEF
        je .nz_fix
        cmp al,0xE3
        je .nz_rle
        cmp al,0xE4
        je .nz_backref
        cmp al,0xE5
        je .nz_err_bwt
        jmp .nz_err_format

.nz_not_control:
        cmp edi,ebp
        jae .nz_err_output
        mov byte [edi],al
        inc edi
        dec esi
        jmp .nz_next

.nz_fix:
        lea ebx,[esi+2]
        cmp ebx,edx
        ja .nz_err_truncated
        lea ebx,[edi+2]
        cmp ebx,ebp
        ja .nz_err_output
        mov ax,word [esi]
        mov word [edi],ax
        add esi,2
        add edi,2
        jmp .nz_next

.nz_rle:
        lea ebx,[esi+3]
        cmp ebx,edx
        ja .nz_err_truncated
        movzx ecx,word [esi]
        add esi,2
        test ecx,ecx
        jz .nz_err_format
        mov al,byte [esi]
        inc esi
        mov ebx,edi
        add ebx,ecx
        jc .nz_err_output
        cmp ebx,ebp
        ja .nz_err_output
        rep stosb
        jmp .nz_next

.nz_backref:
        lea ebx,[esi+6]
        cmp ebx,edx
        ja .nz_err_truncated
        movzx ecx,word [esi]
        add esi,2
        mov eax,dword [esi]
        add esi,4
        test ecx,ecx
        jz .nz_err_format
        mov ebx,edi
        sub ebx,JTMOS_KERNEL_LOAD_PHYS
        cmp eax,ebx
        jae .nz_err_backref
        sub ebx,eax
        cmp ecx,ebx
        ja .nz_err_backref
        mov ebx,edi
        add ebx,ecx
        jc .nz_err_output
        cmp ebx,ebp
        ja .nz_err_output
        push esi
        mov esi,JTMOS_KERNEL_LOAD_PHYS
        add esi,eax
        rep movsb
        pop esi
        jmp .nz_next

.nz_end:
        cmp edi,ebp
        jne .nz_err_size
        mov esi,JTMOS_KERNEL_LOAD_PHYS
        mov ecx,kernel_raw_bytes
        xor eax,eax
.nz_sum:
        test ecx,ecx
        jz .nz_sum_done
        movzx ebx,byte [esi]
        add ax,bx
        inc esi
        dec ecx
        jmp .nz_sum
.nz_sum_done:
        mov word [0x00001002],ax
        cmp ax,word [0x00001000]
        jne .nz_err_checksum
        xor eax,eax
        ret

.nz_err_truncated: mov eax,1
        ret
.nz_err_output:    mov eax,2
        ret
.nz_err_format:    mov eax,3
        ret
.nz_err_backref:   mov eax,4
        ret
.nz_err_bwt:       mov eax,5
        ret
.nz_err_size:      mov eax,6
        ret
.nz_err_checksum:  mov eax,7
        ret

[bits 16]
;------------------------------------------------------------------------------
; DOS diagnostics / fatal exits.
;------------------------------------------------------------------------------
dos_puts:
        mov ah,0x09
        int 0x21
        ret

dos_open_failed:
        mov dx,msg_open_failed
        jmp dos_fatal

dos_read_failed:
        mov dx,msg_read_failed
        jmp dos_fatal_close

dos_short_read:
        mov dx,msg_short_read
        jmp dos_fatal_close

dos_not_enough_memory:
        mov dx,msg_memory_failed
        jmp dos_fatal

dos_fatal_close:
        push dx
        mov bx,[dos_handle]
        mov ah,0x3E
        int 0x21
        pop dx
dos_fatal:
        mov ax,cs
        mov ds,ax
        call dos_puts
        mov ax,0x4C01
        int 0x21

;------------------------------------------------------------------------------
; Descriptor tables.  The pseudo-descriptor bases and four loader-relative
; descriptor bases are patched at runtime by init_loader_tables().
;------------------------------------------------------------------------------
global_descriptor_table:
gdt_start:
        dw gdt_size-1,0,0

gdtoff:
dummy_descriptor:
        dw 0,0
        db 0,0,0,0
code32_descriptor:
        dw 0xFFFF,0
        db 0,0x9A,0xCF,0
data32_descriptor:
        dw 0xFFFF,0
        db 0,0x92,0xCF,0
core32_descriptor:
        dw 0xFFFF,0
        db 0,0x92,0xCF,0
code16_descriptor:
        dw 0xFFFF,0
        db 0,0x9A,0x00,0
data16_descriptor:
        dw 0xFFFF,0
        db 0,0x92,0x00,0
loader_data32_descriptor:
        dw 0xFFFF,0
        db 0,0x92,0xCF,0

gdt_size equ $-dummy_descriptor

interrupt_descriptor_table:
idt_start:
        dw idt_size-1,0,0
interrupt_0:
        dw demo_int
        dw code32_idx
        db 0
        db 0x8E
        dw 0
idt_size equ $-interrupt_0

[bits 32]
demo_int:
        iretd

[bits 16]
real_mode_idtr:
        dw 0x03FF
        dd 0

program_segment      dw 0
boot_drive_word      dw 0
dos_handle           dw 0
bounce_segment       dw 0
loader_phys_base     dd 0
stream_bounce_phys   dd 0
stream_high_dest     dd JTMOS_BOOT_NZIP_STAGING_PHYS
stream_chunk_bytes   dd 0
stream_remaining     dd 0

kernel_filename      db 'KERNEL32.NZ',0
msg_banner           db 13,10,'JTMOS DOS nzip loader: 64 KiB protected-mode streaming',13,10,'$'
msg_loading          db 'Loading KERNEL32.NZ ...',13,10,'$'
msg_loaded           db 'Compressed kernel staged; expanding at 0x00100000 ...',13,10,'$'
msg_open_failed      db 'dosboot: cannot open KERNEL32.NZ',13,10,'$'
msg_read_failed      db 'dosboot: DOS read failed',13,10,'$'
msg_short_read       db 'dosboot: KERNEL32.NZ is shorter than build metadata',13,10,'$'
msg_memory_failed    db 'dosboot: not enough DOS conventional memory for 64 KiB bounce area',13,10,'$'
msg_v86_failed       db 'dosboot: V86/EMM386 host unsupported; boot from plain real-mode DOS',13,10,'$'

; Keep the active stack inside the COM image.  This is essential: the 64 KiB
; bounce segment begins immediately after program_end and would overlap the
; traditional COM stack near CS:FFFE if we left DOS's default SP in use.
align 16
dos_stack:
        times 4096 db 0
dos_stack_top:
program_end:

DOS_PROGRAM_PARAS equ ((program_end + 15) >> 4)
