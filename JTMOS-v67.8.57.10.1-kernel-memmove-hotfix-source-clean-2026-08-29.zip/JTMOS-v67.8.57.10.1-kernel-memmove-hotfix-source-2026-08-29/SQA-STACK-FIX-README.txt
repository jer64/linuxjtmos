JTMOS V28 - SMSH SQA stack corruption fix
==========================================
Date: 2026-08-20

Observed runtime failure
------------------------
SMSH commands such as:

    sqa floppy
    sqa ram

could crash PID 5 (shell) and then corrupt enough kernel state that PID 0
(init) also page-faulted.

Root cause
----------
StartShellProcess() deliberately gives SMSH a 32 KiB thread stack.
The old sh/sqa.c used two 64 KiB local arrays:

    checksum_fd():      BYTE buffer[65536]
    copy_entry_data():  BYTE buffer[65536]

The V27 sh/sqa.o confirms each function generated:

    sub esp, 0x1002c

which is 65,580 bytes of stack in one function -- already more than twice
the complete SMSH stack before caller frames are counted.

The user's first EIP 0x2ff2c maps to drivers/term/term.c:copyline()+0x5c in
the V27 image.  That is consistent with already-corrupted shell state being
exposed while the floppy trace forces terminal scrolling.  The later PID 0
EIP 0x13b18 is idle_moment's RET instruction, consistent with return/stack
state having been corrupted after the shell overflow.

Fix
---
* sh/sqa.c no longer uses bulk I/O arrays on the thread stack.
* SQA transfer I/O now uses an 8 KiB malloc() buffer, freed on every exit.
* SMSH remains on the original 32 KiB stack on purpose.  This fixes the
  internal command instead of hiding the bug by simply enlarging the stack.
* drivers/floppy/fdc.c high-frequency WHERE tracing is now opt-in with
  FDC_TRACE_CALLS.  Error/retry diagnostics remain enabled.
* The legacy irq/floppy/fdc.c mirror received the same trace setting.

Validation
----------
* JTMOS sh/sqa.c compiled with the V27/V28 32-bit freestanding flags: PASS
* drivers/floppy/fdc.c compiled: PASS
* Full kernel link: PASS
* Fixed sh/sqa.o largest single SUB ESP allocation: 0x103c (4,156 bytes)
* Other active SMSH object max single stack-frame allocations audited:
    sh/sqarc.o  860 bytes
    sh/sh.o     812 bytes
* Host SQARC520 regression archive: 128,000-byte extraction + checksum PASS
* Boot image embeds the exact new kernel at floppy offset 0x2400: PASS
* Kernel checksum in boot sector: 0x9418

Recommended runtime tests
-------------------------
At the SMSH prompt:

    sqa floppy
    sqa ram

The old repeated fd_selectdrive/135 trace should be absent unless the kernel
is explicitly compiled with -DFDC_TRACE_CALLS.

Also retest normal internal commands and LaunchApp:

    ls
    dir
    sqa floppy
    sqa ram
    :install

If SQA still fails, capture the complete serial output beginning with the
first SQA message.  A new failure should now be in the block/file-system path,
not a deterministic 64 KiB shell-stack overwrite.
