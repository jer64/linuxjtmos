# JTMOS V20 - serial, serial mouse and PS/2 mouse receive-safety repair

Date: 2026-08-19
Base: JTMOS V19 COM2/SLIP/uIP tree

## Main fault found

`serial_init()` was executed once from `InitSystem()` and again from the historical
`hwdet()` path because the serial driver's re-entry guard had been commented out.
The second pass reprogrammed the 16550 FIFO control register (including RX/TX FIFO
clear bits), allocated fresh software FIFOs and started another serial flusher
thread. This could destroy bytes that had already arrived or were queued.

V20 restores strict idempotent serial initialization and also prevents `hwdet()`
from making the redundant call when the UART driver is already initialized.

## UART receive ownership

After `serial_init()` the UART receiver register is read by the IRQ handler only.
COM1/COM3 share IRQ4 and COM2/COM4 share IRQ3. Each IRQ handler drains every
present UART on its IRQ into a per-port software FIFO.

The driver now has explicit line owners:

- DEBUG
- SLIP
- serial mouse
- kernel
- user

SLIP and serial mouse use owner-aware FIFO calls. Generic system-call / terminal
serial reads cannot drain a claimed line. `serial_get1()` is early-boot-only once
the managed driver is active.

COM ports are probed before being put on a shared IRQ service list. A floating or
missing UART returning 0xff from LSR is never drained. This is important for the
common COM2/COM4 IRQ3 pair: an absent COM4 must not cause hundreds of phantom
reads while COM2 is waiting for service.

RX software buffers are 64 KiB. The serial TX thread now services COM1..COM4,
not only COM1 and COM2.

Diagnostic counters:

- `serial_rx_dropped[4]` - software FIFO full
- `serial_hw_overrun[4]` - UART overrun
- `serial_hw_framing[4]` - framing errors
- `serial_hw_parity[4]` - parity errors
- `serial_hw_break[4]` - break indications

## Serial mouse

The serial mouse no longer owns a separate UART IRQ reader. The common serial IRQ
handler is the only RBR reader and the mouse task consumes its claimed software
FIFO.

The driver now:

- obeys ENABLE_MOUSE_COM1 / ENABLE_MOUSE_COM2;
- claims the UART exclusively;
- resolves a debug-UART conflict explicitly;
- programs the selected mouse UART to 1200 bps;
- parses Microsoft 3-byte packet synchronization correctly;
- treats bit 6 as synchronization, not a third-button bit;
- does not compete with SLIP for the same COM FIFO.

## PS/2 / i8042 mouse

The old IRQ12 handler read port 0x60 three times for every interrupt. V20 reads
exactly one AUX byte per IRQ and assembles three-byte mouse packets in software.

Keyboard IRQ1 checks the i8042 AUX/source status bit before reading port 0x60, so
it leaves mouse bytes for IRQ12. `InitKeyboard()` no longer performs 1000 blind
reads from 0x60, and the legacy `kbread()` helper refuses AUX bytes.

Mouse commands now use the i8042 AUX prefix (0xD4) for every byte, including
command parameters, and synchronously consume ACK/RESEND responses. Pending AUX
movement is drained through the normal mouse packet assembler before a command
exchange. ACK/RESEND values are never accepted as movement packet bytes.

The old GPF/TSS/IDT debugging paths that polled port 0x60 directly for ESC were
removed from active C callers. The `waitpesc` assembly source is retained as an
ABI symbol but changed to a no-op for future NASM rebuilds.

## Validation

The changed C objects compile under the existing JTMOS 32-bit freestanding GCC
flags and the full NETWORK/uIP kernel links successfully. A static ownership and
raw-I/O audit is provided at `scripts/test_serial_mouse_static.py`.

Runtime validation on real hardware or QEMU with a real COM2 peer is still
required. During a SLIP stress test, inspect the four serial error-counter arrays:
all should remain zero. If `serial_hw_overrun[1]` increases, IRQ3 latency remains
too high; if only `serial_rx_dropped[1]` increases, the consumer is not draining
the software FIFO fast enough.
