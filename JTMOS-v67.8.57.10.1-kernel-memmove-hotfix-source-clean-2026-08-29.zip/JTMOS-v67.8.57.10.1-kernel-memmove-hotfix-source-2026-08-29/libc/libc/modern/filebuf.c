/* Ring3 facade for kernel-owned stdio/file buffering. */
#include <jtmos/filebuf.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>
#include <errno.h>
#include <stdint.h>

static long filebuf_result(long r, int fallback)
{
    if(r>=0) return r;
    if(r<=-2 && r>=-255) errno=(int)-r;
    else errno=fallback;
    return -1;
}

ssize_t __jtmos_filebuf_read(int fd, void *buf, size_t count)
{
    if(!buf && count) { errno=EFAULT; return -1; }
    return (ssize_t)filebuf_result(jtmos_syscall7(SYS_filebuf_read,(uintptr_t)fd,
        (uintptr_t)buf,(uintptr_t)count,0,0,0),EIO);
}
ssize_t __jtmos_filebuf_write(int fd, const void *buf, size_t count)
{
    if(!buf && count) { errno=EFAULT; return -1; }
    return (ssize_t)filebuf_result(jtmos_syscall7(SYS_filebuf_write,(uintptr_t)fd,
        (uintptr_t)buf,(uintptr_t)count,0,0,0),EIO);
}
int __jtmos_filebuf_flush(int fd)
{
    return (int)filebuf_result(jtmos_syscall7(SYS_filebuf_flush,(uintptr_t)fd,0,0,0,0,0),EIO);
}
int __jtmos_filebuf_set(int fd, int mode, size_t size)
{
    return (int)filebuf_result(jtmos_syscall7(SYS_filebuf_set,(uintptr_t)fd,
        (uintptr_t)mode,(uintptr_t)size,0,0,0),EINVAL);
}
off_t __jtmos_filebuf_seek(int fd, off_t offset, int whence)
{
    return (off_t)filebuf_result(jtmos_syscall7(SYS_filebuf_seek,(uintptr_t)fd,
        (uintptr_t)offset,(uintptr_t)whence,0,0,0),ESPIPE);
}
off_t __jtmos_filebuf_tell(int fd)
{
    return (off_t)filebuf_result(jtmos_syscall7(SYS_filebuf_tell,(uintptr_t)fd,0,0,0,0,0),ESPIPE);
}
