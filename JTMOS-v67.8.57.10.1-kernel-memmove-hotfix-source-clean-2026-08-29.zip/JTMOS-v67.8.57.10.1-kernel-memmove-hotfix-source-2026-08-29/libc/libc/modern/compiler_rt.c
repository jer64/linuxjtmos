/* Minimal GCC compiler-runtime helpers required by freestanding i386 apps. */
typedef unsigned long long UDI;
typedef signed long long DI;

static UDI jt_udivmod64(UDI numerator, UDI denominator, UDI *remainder)
{
    UDI quotient = 0ULL;
    UDI bit = 1ULL;
    UDI divisor;

    if(denominator == 0ULL) {
        if(remainder) *remainder = numerator;
        return 0ULL;
    }
    divisor = denominator;
    while(divisor <= numerator && (divisor & (1ULL << 63)) == 0ULL) {
        UDI next = divisor << 1;
        if(next > numerator || next < divisor) break;
        divisor = next;
        bit <<= 1;
    }
    while(bit != 0ULL) {
        if(numerator >= divisor) {
            numerator -= divisor;
            quotient |= bit;
        }
        divisor >>= 1;
        bit >>= 1;
    }
    if(remainder) *remainder = numerator;
    return quotient;
}

UDI __udivdi3(UDI a, UDI b) { return jt_udivmod64(a,b,0); }
UDI __umoddi3(UDI a, UDI b) { UDI r; (void)jt_udivmod64(a,b,&r); return r; }
UDI __udivmoddi4(UDI a, UDI b, UDI *r) { return jt_udivmod64(a,b,r); }

DI __divdi3(DI a, DI b)
{
    int neg = (a < 0) != (b < 0);
    UDI ua = a < 0 ? 0ULL - (UDI)a : (UDI)a;
    UDI ub = b < 0 ? 0ULL - (UDI)b : (UDI)b;
    UDI q = jt_udivmod64(ua,ub,0);
    return neg ? (DI)(0ULL-q) : (DI)q;
}

DI __moddi3(DI a, DI b)
{
    UDI r;
    UDI ua = a < 0 ? 0ULL - (UDI)a : (UDI)a;
    UDI ub = b < 0 ? 0ULL - (UDI)b : (UDI)b;
    (void)jt_udivmod64(ua,ub,&r);
    return a < 0 ? (DI)(0ULL-r) : (DI)r;
}
