#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>

/* Small freestanding printf core.  It deliberately avoids host libc helpers
 * while implementing the integer/string subset used by JTMOS plus basic %f. */
typedef struct out_ctx {
    char *buffer;
    size_t capacity;
    size_t position;
    FILE *stream;
    int failed;
} out_ctx;

static void out_char(out_ctx *out, char c)
{
    if(out->stream != NULL && !out->failed) {
        if(fputc((unsigned char)c,out->stream)==EOF) out->failed=1;
    }
    if(out->buffer != NULL && out->capacity != 0U && out->position + 1U < out->capacity)
        out->buffer[out->position]=c;
    out->position++;
}

static void out_repeat(out_ctx *out,char c,int count){while(count-->0)out_char(out,c);}
static void out_bytes(out_ctx *out,const char *s,size_t n){size_t i;for(i=0U;i<n;i++)out_char(out,s[i]);}

static size_t format_unsigned(char *dst,unsigned long long value,unsigned base,int upper)
{
    char tmp[32];size_t n=0U,i;const char *digits=upper?"0123456789ABCDEF":"0123456789abcdef";
    do{tmp[n++]=digits[(unsigned)(value%base)];value/=base;}while(value!=0U&&n<sizeof(tmp));
    for(i=0U;i<n;i++)
        dst[i]=tmp[n-1U-i];
    return n;
}

static unsigned long long signed_magnitude(long long value,int *negative)
{
    if(value<0){*negative=1;return (unsigned long long)(-(value+1LL))+1ULL;}
    *negative=0;return(unsigned long long)value;
}

static size_t format_fixed(char *dst,double value,int precision,int *negative)
{
    unsigned long long whole,frac,scale=1ULL;double fraction;size_t n=0U,i;
    if(precision<0) precision=6;
    if(precision>9) precision=9;
    *negative=value<0.0;if(*negative)value=-value;
    for(i=0U;i<(size_t)precision;i++)scale*=10ULL;
    value+=0.5/(double)scale;whole=(unsigned long long)value;fraction=value-(double)whole;
    frac=(unsigned long long)(fraction*(double)scale);
    n=format_unsigned(dst,whole,10U,0);
    if(precision>0){dst[n++]='.';for(i=0U;i<(size_t)precision;i++){unsigned long long div=1ULL;size_t j;for(j=i+1U;j<(size_t)precision;j++)div*=10ULL;dst[n++]=(char)('0'+(frac/div)%10ULL);}}
    return n;
}

enum length_kind { LEN_DEFAULT, LEN_HH, LEN_H, LEN_L, LEN_LL, LEN_Z, LEN_T };

static int format_core(out_ctx *out,const char *format,va_list args)
{
    const char *f=format;
    while(f!=NULL&&*f){
        int left=0,plus=0,space=0,alt=0,zero=0,width=0,precision=-1;
        enum length_kind length=LEN_DEFAULT;
        char num[96];const char *text=num;size_t textlen=0U;char sign=0;char prefix[2];int prefixlen=0;int is_numeric=0;
        if(*f!='%'){out_char(out,*f++);continue;}f++;
        if(*f=='%'){out_char(out,'%');f++;continue;}
        for(;;){if(*f=='-')left=1;else if(*f=='+')plus=1;else if(*f==' ')space=1;else if(*f=='#')alt=1;else if(*f=='0')zero=1;else break;f++;}
        if(*f=='*'){width=va_arg(args,int);if(width<0){left=1;width=-width;}f++;}else while(*f>='0'&&*f<='9'){width=width*10+(*f-'0');f++;}
        if(*f=='.'){f++;precision=0;if(*f=='*'){precision=va_arg(args,int);if(precision<0)precision=-1;f++;}else while(*f>='0'&&*f<='9'){precision=precision*10+(*f-'0');f++;}}
        if(*f=='h'){f++;length=LEN_H;if(*f=='h'){length=LEN_HH;f++;}}
        else if(*f=='l'){f++;length=LEN_L;if(*f=='l'){length=LEN_LL;f++;}}
        else if(*f=='z'){length=LEN_Z;f++;}
        else if(*f=='t'){length=LEN_T;f++;}
        switch(*f){
            case 'c': num[0]=(char)va_arg(args,int);textlen=1U;break;
            case 's': text=va_arg(args,const char*);if(text==NULL)text="(null)";textlen=strlen(text);if(precision>=0&&textlen>(size_t)precision)textlen=(size_t)precision;break;
            case 'd':case 'i':{
                long long v;int neg;unsigned long long u;is_numeric=1;
                if(length==LEN_LL)v=va_arg(args,long long);else if(length==LEN_L)v=va_arg(args,long);else if(length==LEN_Z||length==LEN_T)v=(long long)va_arg(args,ptrdiff_t);else v=va_arg(args,int);
                u=signed_magnitude(v,&neg);if(neg)sign='-';else if(plus)sign='+';else if(space)sign=' ';
                if(precision==0&&u==0ULL)textlen=0U;else textlen=format_unsigned(num,u,10U,0);break;}
            case 'u':case 'x':case 'X':case 'o':{
                unsigned base=*f=='o'?8U:(*f=='u'?10U:16U);unsigned long long u;is_numeric=1;
                if(length==LEN_LL)u=va_arg(args,unsigned long long);else if(length==LEN_L)u=va_arg(args,unsigned long);else if(length==LEN_Z)u=(unsigned long long)va_arg(args,size_t);else if(length==LEN_T)u=(unsigned long long)va_arg(args,ptrdiff_t);else u=va_arg(args,unsigned int);
                if(precision==0&&u==0ULL)textlen=0U;else textlen=format_unsigned(num,u,base,*f=='X');
                if(alt&&u!=0ULL&&(*f=='x'||*f=='X')){prefix[0]='0';prefix[1]=*f;prefixlen=2;}else if(alt&&*f=='o'&&(textlen==0U||num[0]!='0')){prefix[0]='0';prefixlen=1;}break;}
            case 'p':{uintptr_t u=(uintptr_t)va_arg(args,void*);is_numeric=1;prefix[0]='0';prefix[1]='x';prefixlen=2;textlen=format_unsigned(num,(unsigned long long)u,16U,0);break;}
            case 'f':case 'F':{double d=va_arg(args,double);int neg;is_numeric=1;textlen=format_fixed(num,d,precision,&neg);if(neg)sign='-';else if(plus)sign='+';else if(space)sign=' ';break;}
            case 'n':{int *nptr=va_arg(args,int*);if(nptr)*nptr=(int)out->position;f++;continue;}
            case '\0': f--; out_char(out,'%'); continue;
            default: out_char(out,'%');out_char(out,*f);f++;continue;
        }
        if(is_numeric&&precision>=0)zero=0;
        {
            int zeroes=0;int pad;size_t core;
            if(is_numeric&&precision>(int)textlen)zeroes=precision-(int)textlen;
            core=textlen+(size_t)zeroes+(sign?1U:0U)+(size_t)prefixlen;
            pad=width>(int)core?width-(int)core:0;
            if(!left&&!zero)out_repeat(out,' ',pad);
            if(sign)out_char(out,sign);
            if(prefixlen)out_bytes(out,prefix,(size_t)prefixlen);
            if(!left&&zero)out_repeat(out,'0',pad);
            out_repeat(out,'0',zeroes);
            out_bytes(out,text,textlen);
            if(left)out_repeat(out,' ',pad);
        }
        f++;
    }
    if(out->buffer!=NULL&&out->capacity!=0U)out->buffer[out->position<out->capacity?out->position:out->capacity-1U]='\0';
    return out->failed?EOF:(int)out->position;
}

int vfprintf(FILE *stream,const char *format,va_list args){out_ctx out={NULL,0U,0U,stream,0};va_list copy;va_copy(copy,args);{int r=format_core(&out,format,copy);va_end(copy);return r;}}
int fprintf(FILE *stream,const char *format,...){va_list args;int r;va_start(args,format);r=vfprintf(stream,format,args);va_end(args);return r;}
int vprintf(const char *format,va_list args){return vfprintf(stdout,format,args);}int printf(const char *format,...){va_list args;int r;va_start(args,format);r=vprintf(format,args);va_end(args);return r;}
int vsnprintf(char *buffer,size_t capacity,const char *format,va_list args){out_ctx out={buffer,capacity,0U,NULL,0};va_list copy;va_copy(copy,args);{int r=format_core(&out,format,copy);va_end(copy);return r;}}
int snprintf(char *buffer,size_t capacity,const char *format,...){va_list args;int r;va_start(args,format);r=vsnprintf(buffer,capacity,format,args);va_end(args);return r;}
int vsprintf(char *buffer,const char *format,va_list args){return vsnprintf(buffer,(size_t)-1,format,args);}int sprintf(char *buffer,const char *format,...){va_list args;int r;va_start(args,format);r=vsprintf(buffer,format,args);va_end(args);return r;}
