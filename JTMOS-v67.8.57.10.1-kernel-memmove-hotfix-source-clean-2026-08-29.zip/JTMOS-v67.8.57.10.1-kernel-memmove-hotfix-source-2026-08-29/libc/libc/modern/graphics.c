#include <graphics.h>
#include <jtmos/graos.h>
#include <jtmos/process.h>
#include <stdlib.h>
#include <string.h>

#define BGI_W 600
#define BGI_H 400
static GRAOS_PIXEL *fb;
static int wid=-1,err=grNoInitGraph,fg=WHITE,bg=BLACK,cx,cy;
static int fillpat=SOLID_FILL,fillcol=WHITE,linestyle=SOLID_LINE,linethick=NORM_WIDTH;
static int vp_l,vp_t,vp_r=BGI_W-1,vp_b=BGI_H-1;
static int text_h=LEFT_TEXT,text_v=TOP_TEXT;
static GRAOS_PIXEL bgi_color(int c){return JtmosMCGAColorToRGBA(c);}
static int bgi_index(GRAOS_PIXEL p){int i;for(i=0;i<256;i++)if(JtmosMCGAColorToRGBA(i)==p)return i;return 0;}
static int inside(int x,int y){return fb&&x>=vp_l&&x<=vp_r&&y>=vp_t&&y<=vp_b&&x>=0&&x<BGI_W&&y>=0&&y<BGI_H;}
static void present(void){if(wid>=0)refreshWindow(wid);}
void initgraph(int *gd,int *gm,const char *path){int i;(void)path;if(gd)*gd=VGA;if(gm)*gm=VGAHI;if(fb)return;if(connectGraos()<0){err=grNotDetected;return;}fb=(GRAOS_PIXEL*)malloc(BGI_W*BGI_H*sizeof(GRAOS_PIXEL));if(!fb){err=grNoInitGraph;return;}for(i=0;i<BGI_W*BGI_H;i++)fb[i]=bgi_color(bg);wid=createWindow(18,22,BGI_W,BGI_H+20,"JTMOS Turbo C BGI",GRAOS_WINDOW_STANDARD);if(wid<0){free(fb);fb=0;err=grNotDetected;return;}if(addFrameBuffer(wid,fb,0,0,BGI_W,BGI_H,GRAOS_BPP,GRAOS_SURFACE_BITMAP,0)<0){closeWindow(wid);wid=-1;free(fb);fb=0;err=grNotDetected;return;}err=grOk;present();}
void closegraph(void){if(wid>=0)closeWindow(wid);wid=-1;if(fb)free(fb);fb=0;err=grNoInitGraph;}
int jtmos_graph_getch(void){GUICMD ev;int r;if(wid<0)return -1;for(;;){while((r=JtmosGraOSPollEvent(wid,&ev))>0){if(ev.id==GRAOS_GSID_KEYPRESSED)return ev.v[0];if(ev.id==GRAOS_GSID_EXIT){wid=-1;return 27;}}SwitchToThread();Sleep(10);}}
int graphresult(void){return err;} char *grapherrormsg(int e){if(e==grOk)return"No error";if(e==grNotDetected)return"GraOS graphics server not detected";if(e==grInvalidMode)return"Invalid graphics mode";return"Graphics not initialized";}
int getmaxx(void){return BGI_W-1;}int getmaxy(void){return BGI_H-1;}void setcolor(int c){fg=c&255;}int getcolor(void){return fg;}void setbkcolor(int c){bg=c&255;}int getbkcolor(void){return bg;}
void cleardevice(void){int i;if(fb){for(i=0;i<BGI_W*BGI_H;i++)fb[i]=bgi_color(bg);cx=cy=0;present();}}void clearviewport(void){int y,x;if(!fb)return;for(y=vp_t;y<=vp_b;y++)for(x=vp_l;x<=vp_r;x++)fb[y*BGI_W+x]=bgi_color(bg);present();}
void putpixel(int x,int y,int c){if(inside(x,y))fb[y*BGI_W+x]=bgi_color(c);}int getpixel(int x,int y){return inside(x,y)?bgi_index(fb[y*BGI_W+x]):0;}
void moveto(int x,int y){cx=x;cy=y;}void moverel(int dx,int dy){cx+=dx;cy+=dy;}int getx(void){return cx;}int gety(void){return cy;}
static void rawline(int x0,int y0,int x1,int y1,int c){int dx=abs(x1-x0),sx=x0<x1?1:-1,dy=-abs(y1-y0),sy=y0<y1?1:-1,e=dx+dy,e2,n=0,t;for(;;){if(linestyle!=DOTTED_LINE||(n++&1)==0){for(t=0;t<linethick;t++){putpixel(x0,y0+t,c);if(t)putpixel(x0+t,y0,c);}}if(x0==x1&&y0==y1)break;e2=2*e;if(e2>=dy){e+=dy;x0+=sx;}if(e2<=dx){e+=dx;y0+=sy;}}}
void line(int x1,int y1,int x2,int y2){rawline(x1,y1,x2,y2,fg);cx=x2;cy=y2;present();}void lineto(int x,int y){line(cx,cy,x,y);}void linerel(int dx,int dy){line(cx,cy,cx+dx,cy+dy);}
void rectangle(int l,int t,int r,int b){rawline(l,t,r,t,fg);rawline(r,t,r,b,fg);rawline(r,b,l,b,fg);rawline(l,b,l,t,fg);present();}
void bar(int l,int t,int r,int b){int x,y,c=fillcol;if(l>r){x=l;l=r;r=x;}if(t>b){y=t;t=b;b=y;}for(y=t;y<=b;y++)for(x=l;x<=r;x++)if(fillpat!=EMPTY_FILL)putpixel(x,y,c);present();}
void bar3d(int l,int t,int r,int b,int d,int top){bar(l,t,r,b);rawline(r,t,r+d,t-d,fg);rawline(r+d,t-d,r+d,b-d,fg);rawline(r+d,b-d,r,b,fg);if(top){rawline(l,t,l+d,t-d,fg);rawline(l+d,t-d,r+d,t-d,fg);}present();}
static int isin(int a,int s,int e){a%=360;if(a<0)a+=360;s%=360;if(s<0)s+=360;e%=360;if(e<0)e+=360;return s<=e?(a>=s&&a<=e):(a>=s||a<=e);} 
static const short sintab[]={0,18,36,54,71,89,107,125,142,160,178,195,213,230,248,265,282,299,316,333,350,367,384,400,416,433,449,465,481,496,512,527,543,558,573,588,603,618,632,647,661,675,689,703,717,730,743,756,769,782,794,806,818,830,842,853,865,876,886,897,907,917,927,937,946,955,964,973,981,989,997,1004,1011,1018,1024,1030,1036,1041,1046,1051,1055,1059,1063,1066,1069,1072,1074,1076,1077,1078,1079,1080};
static int fsin(int a){int q;a%=360;if(a<0)a+=360;q=a/90;a%=90;if(q==0)return sintab[a];if(q==1)return sintab[90-a];if(q==2)return-sintab[a];return-sintab[90-a];}
static int fcos(int a){return fsin(a+90);} 
void ellipse(int x,int y,int st,int en,int xr,int yr){int a,px=x+(xr*fcos(st))/1080,py=y-(yr*fsin(st))/1080,nx,ny;for(a=st+1;a<=st+360;a++){int aa=a%360;if(!isin(aa,st,en))continue;nx=x+(xr*fcos(aa))/1080;ny=y-(yr*fsin(aa))/1080;rawline(px,py,nx,ny,fg);px=nx;py=ny;if(aa==en%360)break;}present();}
void circle(int x,int y,int r){ellipse(x,y,0,359,r,r);}void arc(int x,int y,int st,int en,int r){ellipse(x,y,st,en,r,r);}void pieslice(int x,int y,int st,int en,int r){arc(x,y,st,en,r);rawline(x,y,x+(r*fcos(st))/1080,y-(r*fsin(st))/1080,fg);rawline(x,y,x+(r*fcos(en))/1080,y-(r*fsin(en))/1080,fg);present();}void sector(int x,int y,int st,int en,int xr,int yr){ellipse(x,y,st,en,xr,yr);rawline(x,y,x+(xr*fcos(st))/1080,y-(yr*fsin(st))/1080,fg);rawline(x,y,x+(xr*fcos(en))/1080,y-(yr*fsin(en))/1080,fg);present();}
void setfillstyle(int p,int c){fillpat=p;fillcol=c&255;}void getfillsettings(struct fillsettingstype*f){if(f){f->pattern=fillpat;f->color=fillcol;}}void setlinestyle(int s,unsigned p,int t){(void)p;linestyle=s;linethick=t>0?t:1;}void getlinesettings(struct linesettingstype*l){if(l){l->linestyle=linestyle;l->upattern=0xffff;l->thickness=linethick;}}
void floodfill(int x,int y,int border){int old=getpixel(x,y),xx;if(!inside(x,y)||old==border||old==fillcol)return;/* bounded scanline fill */for(xx=x;xx>=vp_l&&getpixel(xx,y)!=border;xx--)putpixel(xx,y,fillcol);for(xx=x+1;xx<=vp_r&&getpixel(xx,y)!=border;xx++)putpixel(xx,y,fillcol);present();}
static unsigned char grow(unsigned char ch,int row){/* compact deterministic 5x7 fallback */unsigned v=(unsigned)ch*1103515245u+(unsigned)row*12345u;return(unsigned char)(((v>>27)&31u)|((row==0||row==6)?14u:0u));}
static void drawch(int x,int y,unsigned char ch){int r,c;for(r=0;r<7;r++){unsigned char bits=grow(ch,r);for(c=0;c<5;c++)if(bits&(1u<<(4-c)))putpixel(x+c,y+r,fg);}}
void outtextxy(int x,int y,const char*s){int i,n;if(!s)return;n=(int)strlen(s);if(text_h==CENTER_TEXT)x-=n*3;else if(text_h==RIGHT_TEXT)x-=n*6;if(text_v==BOTTOM_TEXT)y-=7;for(i=0;s[i];i++){drawch(x+i*6,y,(unsigned char)s[i]);}cx=x+n*6;cy=y;present();}void outtext(const char*s){outtextxy(cx,cy,s);}int textwidth(const char*s){return s?(int)strlen(s)*6:0;}int textheight(const char*s){(void)s;return 7;}void settextjustify(int h,int v){text_h=h;text_v=v;}void settextstyle(int f,int d,int sz){(void)f;(void)d;(void)sz;}
void setviewport(int l,int t,int r,int b,int clip){(void)clip;if(l<0)l=0;if(t<0)t=0;if(r>=BGI_W)r=BGI_W-1;if(b>=BGI_H)b=BGI_H-1;if(l<=r&&t<=b){vp_l=l;vp_t=t;vp_r=r;vp_b=b;cx=l;cy=t;}}void getviewsettings(void*v){(void)v;}void graphdefaults(void){fg=WHITE;bg=BLACK;fillpat=SOLID_FILL;fillcol=WHITE;linestyle=SOLID_LINE;linethick=1;vp_l=vp_t=0;vp_r=BGI_W-1;vp_b=BGI_H-1;cx=cy=0;text_h=LEFT_TEXT;text_v=TOP_TEXT;}
