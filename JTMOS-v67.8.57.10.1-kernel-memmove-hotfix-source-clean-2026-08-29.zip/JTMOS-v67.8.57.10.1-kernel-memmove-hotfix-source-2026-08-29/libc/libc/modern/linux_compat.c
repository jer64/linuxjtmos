/* JTMOS V67.8.57.1 Linux/POSIX core compatibility wrappers. */
#include <unistd.h>
#include <signal.h>
#include <poll.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/sysinfo.h>
#include <sys/resource.h>
#include <errno.h>
#include <stdint.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>

#define JTMOS_SIG_DFL_TOKEN 0
#define JTMOS_SIG_IGN_TOKEN 1
#define JTMOS_SIG_USER_TOKEN 2
#define JTMOS_NSIG 32

static sighandler_t jtmos_handlers[JTMOS_NSIG];

static long linux_syscall_result(long result, int fallback_errno)
{
    if(result >= 0) return result;
    if(result <= -2 && result >= -255) errno=(int)-result;
    else errno=fallback_errno;
    return -1;
}

pid_t getppid(void)
{
    return (pid_t)linux_syscall_result(jtmos_syscall7(SYS_getppid,0,0,0,0,0,0),ESRCH);
}

pid_t waitpid(pid_t pid, int *status, int options)
{
    return (pid_t)linux_syscall_result(jtmos_syscall7(SYS_waitpid,(uintptr_t)pid,
        (uintptr_t)status,(uintptr_t)options,0,0,0),ECHILD);
}

pid_t wait(int *status)
{
    return waitpid(-1,status,0);
}

int pipe(int fds[2])
{
    if(!fds) { errno=EFAULT; return -1; }
    return (int)linux_syscall_result(jtmos_syscall7(SYS_pipe,(uintptr_t)fds,0,0,0,0,0),EMFILE);
}

int dup2(int oldfd, int newfd)
{
    return (int)linux_syscall_result(jtmos_syscall7(SYS_dup2,(uintptr_t)oldfd,
        (uintptr_t)newfd,0,0,0,0),EBADF);
}

int poll(struct pollfd *fds, nfds_t nfds, int timeout)
{
    if(nfds && !fds) { errno=EFAULT; return -1; }
    return (int)linux_syscall_result(jtmos_syscall7(SYS_poll,(uintptr_t)fds,
        (uintptr_t)nfds,(uintptr_t)timeout,0,0,0),EINVAL);
}

int nice(int increment)
{
    long r=linux_syscall_result(jtmos_syscall7(SYS_nice,(uintptr_t)increment,0,0,0,0,0),EINVAL);
    return r<0 ? -1 : (int)r-20;
}

int getpriority(int which, id_t who)
{
    long r=linux_syscall_result(jtmos_syscall7(SYS_getpriority,(uintptr_t)which,
        (uintptr_t)who,0,0,0,0),EINVAL);
    return r<0 ? -1 : (int)r-20;
}

int setpriority(int which, id_t who, int prio)
{
    return (int)linux_syscall_result(jtmos_syscall7(SYS_setpriority,(uintptr_t)which,
        (uintptr_t)who,(uintptr_t)prio,0,0,0),EINVAL);
}

int uname(struct utsname *buf)
{
    if(!buf) { errno=EFAULT; return -1; }
    return (int)linux_syscall_result(jtmos_syscall7(SYS_uname,(uintptr_t)buf,0,0,0,0,0),EFAULT);
}

int sysinfo(struct sysinfo *info)
{
    if(!info) { errno=EFAULT; return -1; }
    return (int)linux_syscall_result(jtmos_syscall7(SYS_sysinfo,(uintptr_t)info,0,0,0,0,0),EFAULT);
}

int kill(pid_t pid, int sig)
{
    return (int)linux_syscall_result(jtmos_syscall7(SYS_kill,(uintptr_t)pid,
        (uintptr_t)sig,0,0,0,0),ESRCH);
}

sighandler_t signal(int sig, sighandler_t handler)
{
    int token,old;
    sighandler_t previous;
    if(sig<=0 || sig>=JTMOS_NSIG || sig==SIGKILL) { errno=EINVAL; return SIG_ERR; }
    if(handler==SIG_DFL) token=JTMOS_SIG_DFL_TOKEN;
    else if(handler==SIG_IGN) token=JTMOS_SIG_IGN_TOKEN;
    else token=JTMOS_SIG_USER_TOKEN;
    old=(int)linux_syscall_result(jtmos_syscall7(SYS_sigdisp,(uintptr_t)sig,
        (uintptr_t)token,0,0,0,0),EINVAL);
    if(old<0) return SIG_ERR;
    if(old==JTMOS_SIG_DFL_TOKEN) previous=SIG_DFL;
    else if(old==JTMOS_SIG_IGN_TOKEN) previous=SIG_IGN;
    else previous=jtmos_handlers[sig] ? jtmos_handlers[sig] : SIG_DFL;
    jtmos_handlers[sig]=handler;
    return previous;
}

int raise(int sig)
{
    sighandler_t h;
    if(sig<=0 || sig>=JTMOS_NSIG) { errno=EINVAL; return -1; }
    h=jtmos_handlers[sig];
    if(h && h!=SIG_IGN && h!=SIG_DFL) { h(sig); return 0; }
    return kill(getpid(),sig);
}
