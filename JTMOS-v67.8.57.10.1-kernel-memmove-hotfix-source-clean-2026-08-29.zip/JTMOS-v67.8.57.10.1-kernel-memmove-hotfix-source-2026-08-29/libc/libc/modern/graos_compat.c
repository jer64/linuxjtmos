#include <jtmos/graos.h>
#include <jtmos/process.h>
#include <jtmos/msgbox.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>

#define GRAOS_PROTOCOL 99436111

static int graos_pid=-1;
#define GRAOS_CLIENT_EVENTQ 32
static GUICMD event_q[GRAOS_CLIENT_EVENTQ];
static int event_count=0;

/* Async GraOS messages can arrive while a synchronous request is waiting for
 * its response.  Keep them instead of dropping them, but preserve the window
 * association: a process that owns two windows must never receive window B's
 * close/key event while polling window A. */
static void stash_event(const GUICMD *c)
{
    if(!c) return;
    if(event_count>=GRAOS_CLIENT_EVENTQ) {
        memmove(&event_q[0],&event_q[1],
                (GRAOS_CLIENT_EVENTQ-1)*sizeof(event_q[0]));
        event_count=GRAOS_CLIENT_EVENTQ-1;
    }
    event_q[event_count++]=*c;
}

static int event_matches_window(const GUICMD *c,int wid)
{
    if(!c) return 0;
    return wid<0 || c->wid==wid || c->wid<0;
}

static int pop_event_for_window(int wid,GUICMD *c)
{
    int i;
    if(!c || event_count<=0) return 0;
    for(i=0;i<event_count;i++) {
        if(!event_matches_window(&event_q[i],wid)) continue;
        *c=event_q[i];
        if(i+1<event_count)
            memmove(&event_q[i],&event_q[i+1],
                    (event_count-i-1)*sizeof(event_q[0]));
        event_count--;
        return 1;
    }
    return 0;
}
static void init_request(MSG *m,GUICMD **cmd,int id)
{
    memset(m,0,sizeof(*m));
    m->protocol=GRAOS_PROTOCOL;
    m->amount=sizeof(GUICMD);
    *cmd=(GUICMD*)m->buf;
    (*cmd)->magic=GRAOS_CMD_MAGIC;
    (*cmd)->id=id;
}
static int wait_response(GUICMD *copy)
{
    MSG m; GUICMD *cmd;
    for(;;) {
        if(receiveMessage(&m)) {
            if(m.protocol!=GRAOS_PROTOCOL) continue;
            cmd=(GUICMD*)m.buf;
            if(cmd->magic!=GRAOS_CMD_MAGIC) continue;
            if(cmd->id!=GRAOS_GSID_RESPONSE) { stash_event(cmd); continue; }
            if(copy) memcpy(copy,cmd,sizeof(*copy));
            return (int)cmd->rval;
        }
        SwitchToThread();
    }
}
int getGraosPID(void)
{
    /* PID slots are reusable.  Re-resolve the well-known server name so a
     * restarted GraOS cannot leave long-lived clients talking to a stale PID. */
    graos_pid=GetThreadPID(GRAOS_SERVER_PID_NAME);
    if(graos_pid<=0) graos_pid=-1;
    return graos_pid;
}
int connectGraos(void)
{
    if(getGraosPID()<=0) return -ENODEV;
    startMessageBox();
    return 0;
}
int waitGraosAnswer(void){return wait_response(NULL);}
static int request_simple(int id,int v0,int v1,int v2,int v3,GUICMD *reply)
{
    MSG m; GUICMD *c;
    if(getGraosPID()<=0) return -ENODEV;
    init_request(&m,&c,id);
    c->v[0]=v0;c->v[1]=v1;c->v[2]=v2;c->v[3]=v3;
    if(sendMessage(&m,graos_pid)!=0) return -EIO;
    return wait_response(reply);
}
int refreshWindow(int wid){return request_simple(GRAOS_GSID_REQUESTREFRESH,wid,0,0,0,NULL);}
int closeWindow(int wid){return request_simple(GRAOS_GSID_CLOSEWINDOW,wid,0,0,0,NULL);}
int createWindow(int x,int y,int w,int h,const char *caption,...)
{
    MSG m;GUICMD*c;va_list ap;int type=GRAOS_WINDOW_STANDARD;
    if(getGraosPID()<=0)return-ENODEV;
    va_start(ap,caption);type=va_arg(ap,int);va_end(ap);
    init_request(&m,&c,GRAOS_GSID_OPENWINDOW);
    c->v[0]=x;c->v[1]=y;c->v[2]=w;c->v[3]=h;c->v[4]=type;
    if(caption){strncpy(c->str,caption,255);c->str[255]=0;}
    if(sendMessage(&m,graos_pid)!=0)return-EIO;
    return wait_response(NULL);
}
int addFrameBuffer(int wid,void *buf,...)
{
    MSG m;GUICMD*c;va_list ap;int x,y,w,h,bpp,type,ter;
    if(getGraosPID()<=0)return-ENODEV;
    va_start(ap,buf);x=va_arg(ap,int);y=va_arg(ap,int);w=va_arg(ap,int);h=va_arg(ap,int);bpp=va_arg(ap,int);type=va_arg(ap,int);ter=va_arg(ap,int);va_end(ap);
    /* GRAOS_SURFACE_TERMINAL intentionally has no userspace pixel buffer. */
    if(type!=GRAOS_SURFACE_TERMINAL && !buf)return-EINVAL;
    init_request(&m,&c,GRAOS_GSID_ADDFRAMEBUFFER);
    c->v[0]=wid;c->v[1]=x;c->v[2]=y;c->v[3]=w;c->v[4]=h;c->v[5]=bpp;c->v[6]=type;c->v[7]=ter;c->ptr[0]=buf;
    if(sendMessage(&m,graos_pid)!=0)return-EIO;
    return wait_response(NULL);
}
int createButton(int wid,int x1,int y1,int x2,int y2,int id,const char *caption)
{
    MSG m;GUICMD*c;
    if(getGraosPID()<=0)return-ENODEV;
    init_request(&m,&c,GRAOS_GSID_CREATEBUTTON);
    c->v[0]=wid;c->v[1]=x1;c->v[2]=y1;c->v[3]=x2;c->v[4]=y2;c->v[5]=id;
    if(caption){strncpy(c->str,caption,255);c->str[255]=0;}
    if(sendMessage(&m,graos_pid)!=0)return-EIO;
    return wait_response(NULL);
}
int createLabel(int wid,int x,int y,int width,int height,int id,int fg,int bg,int align,const char *text)
{
    MSG m;GUICMD*c;
    if(getGraosPID()<=0)return-ENODEV;
    init_request(&m,&c,GRAOS_GSID_CREATELABEL);
    c->v[0]=wid;c->v[1]=x;c->v[2]=y;c->v[3]=width;c->v[4]=height;
    c->v[5]=id;c->v[6]=fg;c->v[7]=bg;c->v[8]=align;
    if(text){strncpy(c->str,text,255);c->str[255]=0;}
    if(sendMessage(&m,graos_pid)!=0)return-EIO;
    return wait_response(NULL);
}
int setLabelText(int wid,int id,const char *text)
{
    MSG m;GUICMD*c;
    if(getGraosPID()<=0)return-ENODEV;
    init_request(&m,&c,GRAOS_GSID_SETLABELTEXT);
    c->v[0]=wid;c->v[1]=id;
    if(text){strncpy(c->str,text,255);c->str[255]=0;}
    if(sendMessage(&m,graos_pid)!=0)return-EIO;
    return wait_response(NULL);
}
int setLabelStyle(int wid,int id,int fg,int bg,int align)
{
    MSG m;GUICMD*c;
    if(getGraosPID()<=0)return-ENODEV;
    init_request(&m,&c,GRAOS_GSID_SETLABELSTYLE);
    c->v[0]=wid;c->v[1]=id;c->v[2]=fg;c->v[3]=bg;c->v[4]=align;
    if(sendMessage(&m,graos_pid)!=0)return-EIO;
    return wait_response(NULL);
}
int removeLabel(int wid,int id)
{
    return request_simple(GRAOS_GSID_REMOVELABEL,wid,id,0,0,NULL);
}

int createBitmap(int wid,int x,int y,int width,int height,int id,const GRAOS_PIXEL *pixels,int transparent)
{
    MSG m;GUICMD*c;
    if(getGraosPID()<=0)return-ENODEV;
    if(!pixels || width<=0 || height<=0)return-EINVAL;
    init_request(&m,&c,GRAOS_GSID_CREATEBITMAP);
    c->v[0]=wid;c->v[1]=x;c->v[2]=y;c->v[3]=width;c->v[4]=height;c->v[5]=id;c->v[6]=transparent;
    c->ptr[0]=(BYTE*)pixels;
    if(sendMessage(&m,graos_pid)!=0)return-EIO;
    return wait_response(NULL);
}
int setBitmapData(int wid,int id,const GRAOS_PIXEL *pixels,int bytes)
{
    MSG m;GUICMD*c;
    if(getGraosPID()<=0)return-ENODEV;
    if(!pixels || bytes<=0)return-EINVAL;
    init_request(&m,&c,GRAOS_GSID_SETBITMAPDATA);
    c->v[0]=wid;c->v[1]=id;c->v[2]=bytes;c->ptr[0]=(BYTE*)pixels;
    if(sendMessage(&m,graos_pid)!=0)return-EIO;
    return wait_response(NULL);
}
int removeBitmap(int wid,int id){return request_simple(GRAOS_GSID_REMOVEBITMAP,wid,id,0,0,NULL);}

int JtmosGraOSPollEvent(int wid,GUICMD *event)
{
    MSG m; GUICMD *c; GUICMD r; int rv;
    if(!event) return -EINVAL;
    if(pop_event_for_window(wid,event)) return 1;
    /* Preserve asynchronous EXIT/key messages even when the application is
     * otherwise using the reliable server-side button queue.  Events for a
     * sibling window are queued until that exact window polls them. */
    while(receiveMessage(&m)) {
        if(m.protocol!=GRAOS_PROTOCOL) continue;
        c=(GUICMD*)m.buf;
        if(c->magic!=GRAOS_CMD_MAGIC || c->id==GRAOS_GSID_RESPONSE) continue;
        if(event_matches_window(c,wid)) { *event=*c; return 1; }
        stash_event(c);
    }
    rv=request_simple(GRAOS_GSID_POLLEVENT,wid,0,0,0,&r);
    if(rv<=0) return rv;
    memset(event,0,sizeof(*event));
    event->magic=GRAOS_CMD_MAGIC; event->wid=wid;
    event->id=r.v[0]; event->v[0]=r.v[1]; event->v[1]=r.v[2]; event->v[2]=r.v[3];
    return 1;
}

int createTextBox(int wid,int x,int y,int width,int height,int id,int maxlen,const char *text)
{
    MSG m;GUICMD*c;
    if(getGraosPID()<=0)return-ENODEV;
    init_request(&m,&c,GRAOS_GSID_CREATETEXTBOX);
    c->v[0]=wid;c->v[1]=x;c->v[2]=y;c->v[3]=width;c->v[4]=height;c->v[5]=id;c->v[6]=maxlen;
    if(text){strncpy(c->str,text,255);c->str[255]=0;}
    if(sendMessage(&m,graos_pid)!=0)return-EIO;
    return wait_response(NULL);
}
int setTextBoxText(int wid,int id,const char *text)
{
    MSG m;GUICMD*c;
    if(getGraosPID()<=0)return-ENODEV;
    init_request(&m,&c,GRAOS_GSID_SETTEXTBOXTEXT);c->v[0]=wid;c->v[1]=id;
    if(text){strncpy(c->str,text,255);c->str[255]=0;}
    if(sendMessage(&m,graos_pid)!=0)return-EIO;
    return wait_response(NULL);
}
int getTextBoxText(int wid,int id,char *text,int cap)
{
    GUICMD r;int rv;
    if(!text || cap<=0)return-EINVAL;
    rv=request_simple(GRAOS_GSID_GETTEXTBOXTEXT,wid,id,0,0,&r);
    if(rv<0){text[0]=0;return rv;}
    strncpy(text,r.str,(size_t)cap-1);text[cap-1]=0;return 0;
}
int removeTextBox(int wid,int id){return request_simple(GRAOS_GSID_REMOVETEXTBOX,wid,id,0,0,NULL);}

int JtmosGraOSSetGray16Palette(void)
{
    int i,level,rv;
    for(i=0;i<GRAOS_GRAY16_COLORS;i++) {
        level=(i*63+7)/15;
        rv=JtmosGraOSSetPalette(GRAOS_GRAY16_BASE+i,level,level,level);
        if(rv<0) return rv;
    }
    return 0;
}

int JtmosGraOSFreeTerminal(int t)
{
    /* Dynamic terminal storage is released by the kernel when its owner PID
     * exits.  This call remains ABI-compatible and gives the server a chance
     * to detach any terminal surface before process teardown. */
    return request_simple(GRAOS_GSID_FREETERMINAL,t,0,0,0,NULL);
}
int JtmosGraOSPing(void){return request_simple(GRAOS_GSID_PING,0,0,0,0,NULL);}
int JtmosGraOSGetStats(int *windows,int *terminals,int *focus,unsigned long *frames)
{
    GUICMD r; int rv=request_simple(GRAOS_GSID_GETSTATS,0,0,0,0,&r);
    if(rv<0)return rv;
    if(windows) *windows=r.v[0];
    if(terminals) *terminals=r.v[1];
    if(focus) *focus=r.v[2];
    if(frames) *frames=(unsigned long)r.v[3];
    return rv;
}
int JtmosGraOSGetScreenInfo(int *width,int *height,int *bpp,int *panel_height)
{
    GUICMD r; int rv=request_simple(GRAOS_GSID_GETSCREENINFO,0,0,0,0,&r);
    if(rv<0)return rv;
    if(width) *width=r.v[0];
    if(height) *height=r.v[1];
    if(bpp) *bpp=r.v[2];
    if(panel_height) *panel_height=r.v[3];
    return rv;
}
int JtmosGraOSGetScreenSize(int *width,int *height)
{
    return JtmosGraOSGetScreenInfo(width,height,NULL,NULL);
}
int JtmosGraOSShutdown(void){return request_simple(GRAOS_GSID_SHUTDOWN,0,0,0,0,NULL);}
int JtmosGraOSSetDesktopColor(int color){return request_simple(GRAOS_GSID_SETDESKTOPCOLOR,color,0,0,0,NULL);}
int JtmosGraOSSetPalette(int index,int r,int g,int b){return request_simple(GRAOS_GSID_SETPALETTE,index,r,g,b,NULL);}
int JtmosGraOSRestorePalette(void){return request_simple(GRAOS_GSID_SETPALETTE,-1,0,0,0,NULL);}
int MessageBox(void*a,const char*b,const char*c,unsigned d){(void)a;(void)b;(void)c;(void)d;return-ENOSYS;}

int JtmosGraOSMinimizeWindow(int wid){return request_simple(GRAOS_GSID_MINIMIZEWINDOW,wid,0,0,0,NULL);}
int JtmosGraOSRestoreWindow(int wid){return request_simple(GRAOS_GSID_RESTOREWINDOW,wid,0,0,0,NULL);}
