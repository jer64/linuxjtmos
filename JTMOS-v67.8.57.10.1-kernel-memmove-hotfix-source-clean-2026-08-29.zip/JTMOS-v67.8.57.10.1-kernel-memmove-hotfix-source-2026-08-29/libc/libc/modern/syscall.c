#include <jtmos/syscall.h>
#include <errno.h>
#ifdef JTMOS_KERNEL32
__attribute__((weak)) long jtmos_kernel_syscall7(DWORD eax, uintptr_t ebx, uintptr_t ecx, uintptr_t edx,
                                                  uintptr_t esi, uintptr_t edi, uintptr_t ebp)
{
    (void)eax; (void)ebx; (void)ecx; (void)edx; (void)esi; (void)edi; (void)ebp;
    return -ENOSYS;
}
long jtmos_syscall7(DWORD eax, uintptr_t ebx, uintptr_t ecx, uintptr_t edx,
                    uintptr_t esi, uintptr_t edi, uintptr_t ebp)
{
    return jtmos_kernel_syscall7(eax, ebx, ecx, edx, esi, edi, ebp);
}
#endif
