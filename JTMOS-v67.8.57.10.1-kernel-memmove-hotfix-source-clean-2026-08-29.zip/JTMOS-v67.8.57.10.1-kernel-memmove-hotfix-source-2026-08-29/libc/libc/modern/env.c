#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define ENV_MAX 64
static char *env_table[ENV_MAX];

static int valid_name(const char *name)
{
    return name != NULL && name[0] != '\0' && strchr(name,'=') == NULL;
}

static int find_name(const char *name, size_t name_len)
{
    int i;
    for(i=0;i<ENV_MAX;i++) if(env_table[i]!=NULL) {
        if(strncmp(env_table[i],name,name_len)==0 && env_table[i][name_len]=='=') return i;
    }
    return -1;
}

char *getenv(const char *name)
{
    int i;
    size_t n;
    if(!valid_name(name)) return NULL;
    n=strlen(name);i=find_name(name,n);
    return i>=0?env_table[i]+n+1U:NULL;
}

int setenv(const char *name,const char *value,int overwrite)
{
    size_t nl,vl,total;
    int i,slot=-1;
    char *entry;
    if(!valid_name(name)||value==NULL){errno=EINVAL;return-1;}
    nl=strlen(name);vl=strlen(value);
    i=find_name(name,nl);
    if(i>=0&&!overwrite)return 0;
    if(i<0){for(i=0;i<ENV_MAX;i++)if(env_table[i]==NULL){slot=i;break;}if(slot<0){errno=ENOMEM;return-1;}}else slot=i;
    if(nl>(size_t)-1-vl-2U){errno=ENOMEM;return-1;}total=nl+1U+vl+1U;
    entry=malloc(total);if(!entry)return-1;
    memcpy(entry,name,nl);entry[nl]='=';memcpy(entry+nl+1U,value,vl+1U);
    if(env_table[slot])
        free(env_table[slot]);
    env_table[slot]=entry;
    return 0;
}

int unsetenv(const char *name)
{
    int i;size_t n;
    if(!valid_name(name)){errno=EINVAL;return-1;}
    n=strlen(name);i=find_name(name,n);if(i>=0){free(env_table[i]);env_table[i]=NULL;}return 0;
}

int putenv(char *string)
{
    char *eq;size_t n;char name[128];
    if(string==NULL){errno=EINVAL;return-1;}eq=strchr(string,'=');if(eq==NULL){return unsetenv(string);}
    n=(size_t)(eq-string);if(n==0U||n>=sizeof(name)){errno=EINVAL;return-1;}
    memcpy(name,string,n);name[n]='\0';return setenv(name,eq+1,1);
}
