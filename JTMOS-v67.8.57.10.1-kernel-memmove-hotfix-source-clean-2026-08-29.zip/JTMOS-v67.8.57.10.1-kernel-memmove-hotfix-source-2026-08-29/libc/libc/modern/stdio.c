/*
 * JTMOS modern stdio.
 * V67.8.57.7: buffering lives in kernel32/fs/filebuf.c.  Ring3 FILE keeps
 * only stream metadata; fread/fwrite/fflush/fseek/ftell delegate through
 * dedicated filebuf system calls.  This also makes pipes real kernel streams
 * instead of duplicating pipe-like buffers inside libc.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>
#include <jtmos/filebuf.h>

#define FILE_OP_NONE  0
#define FILE_OP_READ  1
#define FILE_OP_WRITE 2

static FILE fin  = {0,1,0,0,-1,NULL,1,NULL,0,0,0,_IONBF,0,FILE_OP_NONE,NULL};
static FILE fout = {1,2,0,0,-1,NULL,0,NULL,0,0,0,_IONBF,0,FILE_OP_NONE,NULL};
static FILE ferr = {2,2,0,0,-1,NULL,0,NULL,0,0,0,_IONBF,0,FILE_OP_NONE,NULL};
FILE *stdin=&fin,*stdout=&fout,*stderr=&ferr;
static FILE *open_streams;

static int mode_flags(const char *mode, int *readonly)
{
    int flags,plus,exclusive;
    if(mode==NULL || mode[0]=='\0') { errno=EINVAL; return -1; }
    plus=strchr(mode,'+')!=NULL;
    exclusive=strchr(mode,'x')!=NULL;
    switch(mode[0]) {
        case 'r': flags=plus?O_RDWR:O_RDONLY; break;
        case 'w': flags=(plus?O_RDWR:O_WRONLY)|O_CREAT|O_TRUNC; break;
        case 'a': flags=(plus?O_RDWR:O_WRONLY)|O_CREAT|O_APPEND; break;
        default: errno=EINVAL; return -1;
    }
    if(exclusive) flags|=O_EXCL;
    if(readonly) *readonly=(!plus && mode[0]=='r');
    return flags;
}

static void stream_reset(FILE *s)
{
    if(!s) return;
    s->eof=0; s->err=0; s->ungot=-1;
    s->buffer=NULL; s->buffer_capacity=0U; s->buffer_pos=0U; s->buffer_len=0U;
    s->buffer_owned=0; s->last_op=FILE_OP_NONE;
}

static void link_stream(FILE *stream)
{
    stream->next=open_streams;
    open_streams=stream;
}

static void unlink_stream(FILE *stream)
{
    FILE **cursor=&open_streams;
    while(*cursor) {
        if(*cursor==stream) { *cursor=stream->next; return; }
        cursor=&(*cursor)->next;
    }
}

FILE *fopen(const char *path, const char *mode)
{
    FILE *stream;
    int readonly,flags,fd;
    if(path==NULL) { errno=EFAULT; return NULL; }
    flags=mode_flags(mode,&readonly);
    if(flags<0) return NULL;
    fd=open(path,flags,0666);
    if(fd<0) return NULL;
    stream=(FILE *)calloc(1U,sizeof(*stream));
    if(!stream) { (void)close(fd); return NULL; }
    stream->fd=fd;
    stream->readonly=readonly;
    stream->buffer_mode=_IOFBF;
    stream_reset(stream);
    stream->readonly=readonly;
    stream->buffer_mode=_IOFBF;
    if(__jtmos_filebuf_set(fd,_IOFBF,BUFSIZ)<0) {
        (void)close(fd); free(stream); return NULL;
    }
    if(mode[0]=='a') (void)__jtmos_filebuf_seek(fd,0,SEEK_END);
    link_stream(stream);
    return stream;
}

FILE *freopen(const char *path, const char *mode, FILE *stream)
{
    int readonly,flags,fd;
    if(!stream || !path) { errno=EINVAL; return NULL; }
    flags=mode_flags(mode,&readonly);
    if(flags<0) return NULL;
    (void)fflush(stream);
    if(stream->fd>2) (void)close(stream->fd);
    fd=open(path,flags,0666);
    if(fd<0) return NULL;
    stream->fd=fd;
    stream_reset(stream);
    stream->readonly=readonly;
    stream->buffer_mode=_IOFBF;
    if(__jtmos_filebuf_set(fd,_IOFBF,BUFSIZ)<0) { (void)close(fd); return NULL; }
    if(mode[0]=='a') (void)__jtmos_filebuf_seek(fd,0,SEEK_END);
    return stream;
}

int fflush(FILE *stream)
{
    int result=0;
    FILE *cur;
    if(stream==NULL) {
        if(__jtmos_filebuf_flush(stdout->fd)<0) result=EOF;
        if(__jtmos_filebuf_flush(stderr->fd)<0) result=EOF;
        for(cur=open_streams;cur;cur=cur->next)
            if(__jtmos_filebuf_flush(cur->fd)<0) { cur->err=1; result=EOF; }
        return result;
    }
    if(__jtmos_filebuf_flush(stream->fd)<0) { stream->err=1; return EOF; }
    return 0;
}

int fclose(FILE *stream)
{
    int result=0;
    if(!stream) { errno=EINVAL; return EOF; }
    if(fflush(stream)==EOF) result=EOF;
    if(stream->fd>2 && close(stream->fd)<0) result=EOF;
    if(stream!=stdin && stream!=stdout && stream!=stderr) {
        unlink_stream(stream);
        free(stream);
    }
    return result;
}

size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream)
{
    const unsigned char *data=(const unsigned char *)ptr;
    size_t total,done=0U;
    if(!stream || (!ptr && size!=0U && nmemb!=0U)) { errno=EINVAL; return 0U; }
    if(size==0U || nmemb==0U) return 0U;
    if(nmemb>(size_t)-1/size) { errno=EFBIG; stream->err=1; return 0U; }
    if(stream->readonly) { errno=EBADF; stream->err=1; return 0U; }
    total=size*nmemb;
    stream->last_op=FILE_OP_WRITE;
    stream->eof=0;
    while(done<total) {
        size_t left=total-done;
        size_t chunk=left>65536U?65536U:left;
        ssize_t rc=__jtmos_filebuf_write(stream->fd,data+done,chunk);
        if(rc<0) { stream->err=1; break; }
        if(rc==0) { errno=EIO; stream->err=1; break; }
        done+=(size_t)rc;
    }
    return done/size;
}

size_t fread(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
    unsigned char *out=(unsigned char *)ptr;
    size_t total,done=0U;
    if(!stream || (!ptr && size!=0U && nmemb!=0U)) { errno=EINVAL; return 0U; }
    if(size==0U || nmemb==0U) return 0U;
    if(nmemb>(size_t)-1/size) { errno=EFBIG; stream->err=1; return 0U; }
    total=size*nmemb;
    stream->last_op=FILE_OP_READ;
    if(stream->ungot>=0 && done<total) {
        out[done++]=(unsigned char)stream->ungot;
        stream->ungot=-1;
    }
    while(done<total) {
        size_t left=total-done;
        size_t chunk=left>65536U?65536U:left;
        ssize_t rc=__jtmos_filebuf_read(stream->fd,out+done,chunk);
        if(rc<0) { stream->err=1; break; }
        if(rc==0) { stream->eof=1; break; }
        stream->eof=0;
        done+=(size_t)rc;
    }
    return done/size;
}

int fgetc(FILE *stream)
{
    unsigned char c;
    return fread(&c,1U,1U,stream)==1U?(int)c:EOF;
}
int getc(FILE *stream){return fgetc(stream);}
int getchar(void){return fgetc(stdin);}
int ungetc(int c,FILE *stream)
{
    if(!stream || c==EOF || stream->ungot>=0) return EOF;
    stream->ungot=(unsigned char)c; stream->eof=0; return (unsigned char)c;
}
int fputc(int c,FILE *stream)
{
    unsigned char x=(unsigned char)c;
    return fwrite(&x,1U,1U,stream)==1U?(int)x:EOF;
}
int putc(int c,FILE *stream){return fputc(c,stream);}
int putchar(int c){return fputc(c,stdout);}
int fputs(const char *s,FILE *stream)
{
    size_t n;
    if(!s) { errno=EINVAL; return EOF; }
    n=strlen(s);
    return fwrite(s,1U,n,stream)==n?0:EOF;
}
int puts(const char *s)
{
    if(fputs(s,stdout)==EOF || fputc('\n',stdout)==EOF) return EOF;
    return 0;
}

char *fgets(char *s,int n,FILE *stream)
{
    int i=0,c=EOF;
    if(!s || !stream || n<=0) { errno=EINVAL; return NULL; }
    if(n==1) { s[0]='\0'; return s; }
    while(i<n-1 && (c=fgetc(stream))!=EOF) { s[i++]=(char)c; if(c=='\n') break; }
    if(i==0 && c==EOF) return NULL;
    s[i]='\0'; return s;
}

char *gets(char *s)
{
    int c; char *p=s;
    if(!s) { errno=EINVAL; return NULL; }
    while((c=getchar())!=EOF && c!='\n' && c!='\r') *p++=(char)c;
    *p='\0'; return s;
}

int fseek(FILE *stream,long offset,int whence)
{
    if(!stream) { errno=EINVAL; return -1; }
    if(__jtmos_filebuf_seek(stream->fd,(off_t)offset,whence)<0) { stream->err=1; return -1; }
    stream->eof=0; stream->ungot=-1; stream->last_op=FILE_OP_NONE;
    return 0;
}

long ftell(FILE *stream)
{
    off_t pos;
    if(!stream) { errno=EINVAL; return -1L; }
    pos=__jtmos_filebuf_tell(stream->fd);
    if(pos<0) { stream->err=1; return -1L; }
    return (long)pos;
}

void rewind(FILE *stream){if(stream){(void)fseek(stream,0L,SEEK_SET);clearerr(stream);}}
int feof(FILE *stream){return stream?stream->eof:0;}
int ferror(FILE *stream){return stream?stream->err:1;}
void clearerr(FILE *stream){if(stream){stream->eof=0;stream->err=0;}}
int fileno(FILE *stream){if(!stream){errno=EINVAL;return-1;}return stream->fd;}
int remove(const char *path){return unlink(path);}
int rename(const char *oldpath,const char *newpath)
{
    long r;
    if(!oldpath||!newpath){errno=EFAULT;return-1;}
    r=jtmos_syscall7(SYS_rename,(uintptr_t)oldpath,(uintptr_t)newpath,0,0,0,0);
    if(r<0){errno=EIO;return-1;} return (int)r;
}
void perror(const char *s)
{
    if(s&&*s){fputs(s,stderr);fputs(": ",stderr);}
    fputs(strerror(errno),stderr);fputc('\n',stderr);
}

int setvbuf(FILE *stream,char *buffer,int mode,size_t size)
{
    (void)buffer; /* Buffer storage is kernel-owned in V67.8.57.7. */
    if(!stream || (mode!=_IOFBF&&mode!=_IOLBF&&mode!=_IONBF)) { errno=EINVAL; return -1; }
    if(size==0U) size=BUFSIZ;
    if(__jtmos_filebuf_set(stream->fd,mode,size)<0) { stream->err=1; return -1; }
    stream->buffer=NULL; stream->buffer_capacity=0U; stream->buffer_pos=0U; stream->buffer_len=0U;
    stream->buffer_owned=0; stream->buffer_mode=mode; stream->last_op=FILE_OP_NONE;
    return 0;
}
void setbuf(FILE *stream,char *buffer){(void)setvbuf(stream,buffer,buffer?_IOFBF:_IONBF,BUFSIZ);}
