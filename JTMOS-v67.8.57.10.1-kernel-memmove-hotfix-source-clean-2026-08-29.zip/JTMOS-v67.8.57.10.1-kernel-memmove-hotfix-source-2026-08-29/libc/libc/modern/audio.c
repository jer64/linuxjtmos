#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>
#include <jtmos/audio.h>
#include <unistd.h>
#include <stdint.h>

int AudioInit(void)
{
    return (int)jtmos_syscall7(SYS_audioinit, AUDIO_BACKEND_AUTO, 0, 0, 0, 0, 0);
}

int AudioSelectBackend(int backend)
{
    int r = (int)jtmos_syscall7(SYS_audioselect, (uintptr_t)backend, 0, 0, 0, 0, 0);
    if(r < 0) return r;
    return (int)jtmos_syscall7(SYS_audioinit, (uintptr_t)backend, 0, 0, 0, 0, 0);
}

int AudioWrite(const void *buf, int len, int type, int freq)
{
    if(!buf || len <= 0) return 0;
    return (int)jtmos_syscall7(SYS_audiowrite, (uintptr_t)buf, (uintptr_t)len,
                              (uintptr_t)type, (uintptr_t)freq, 0, 0);
}

int AudioStop(void)
{
    return (int)jtmos_syscall7(SYS_audiostop, 0, 0, 0, 0, 0, 0);
}

int AudioGetInfo(JTMOS_AUDIO_INFO *info)
{
    if(!info) return -1;
    return (int)jtmos_syscall7(SYS_audioinfo, (uintptr_t)info,
                              (uintptr_t)sizeof(*info), 0, 0, 0, 0);
}

void InitAudio(void)
{
    (void)AudioInit();
}

DWORD GetAudioPosition(void)
{
    return (DWORD)jtmos_syscall7(SYS_audioposition, 0, 0, 0, 0, 0, 0);
}

void SendAudio(const void *buf, int len, int type, int freq)
{
    const unsigned char *p = (const unsigned char *)buf;
    int done = 0;
    while(done < len)
    {
        int n = AudioWrite(p + done, len - done, type, freq);
        if(n < 0) return;
        if(n == 0) { usleep(1000); continue; }
        done += n;
    }
}
