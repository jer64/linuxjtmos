#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>

int errno;

static int digit_value(unsigned char c)
{
    if(c>='0'&&c<='9')return(int)(c-'0');
    if(c>='a'&&c<='z')return(int)(c-'a')+10;
    if(c>='A'&&c<='Z')return(int)(c-'A')+10;
    return -1;
}

unsigned long strtoul(const char *s,char **endptr,int base)
{
    const char *p=s,*start;
    unsigned long value=0UL,cutoff;
    int cutlim,neg=0,any=0;
    if(s==NULL){errno=EINVAL;if(endptr)*endptr=(char*)s;return 0UL;}
    while(isspace((unsigned char)*p))p++;
    if(*p=='+'||*p=='-'){neg=*p=='-';p++;}
    if(base==0){if(p[0]=='0'&&(p[1]=='x'||p[1]=='X')){base=16;p+=2;}else if(p[0]=='0'){base=8;}else base=10;}
    else if(base==16&&p[0]=='0'&&(p[1]=='x'||p[1]=='X'))p+=2;
    if(base<2||base>36){errno=EINVAL;if(endptr)*endptr=(char*)s;return 0UL;}
    start=p;cutoff=ULONG_MAX/(unsigned long)base;cutlim=(int)(ULONG_MAX%(unsigned long)base);
    for(;;p++){
        int d=digit_value((unsigned char)*p);if(d<0||d>=base)break;
        if(value>cutoff||(value==cutoff&&d>cutlim)){errno=ERANGE;value=ULONG_MAX;any=-1;}
        else if(any>=0){value=value*(unsigned long)base+(unsigned long)d;any=1;}
    }
    if(endptr)*endptr=(char*)(p==start?s:p);
    if(!any)return 0UL;
    return neg?(unsigned long)(0UL-value):value;
}

long strtol(const char *s,char **endptr,int base)
{
    const char *p=s,*start;
    unsigned long value=0UL,limit,cutoff;
    int cutlim,neg=0,any=0;
    if(s==NULL){errno=EINVAL;if(endptr)*endptr=(char*)s;return 0L;}
    while(isspace((unsigned char)*p))p++;
    if(*p=='+'||*p=='-'){neg=*p=='-';p++;}
    if(base==0){if(p[0]=='0'&&(p[1]=='x'||p[1]=='X')){base=16;p+=2;}else if(p[0]=='0')base=8;else base=10;}
    else if(base==16&&p[0]=='0'&&(p[1]=='x'||p[1]=='X'))p+=2;
    if(base<2||base>36){errno=EINVAL;if(endptr)*endptr=(char*)s;return 0L;}
    start=p;limit=neg?(unsigned long)LONG_MAX+1UL:(unsigned long)LONG_MAX;cutoff=limit/(unsigned long)base;cutlim=(int)(limit%(unsigned long)base);
    for(;;p++){
        int d=digit_value((unsigned char)*p);if(d<0||d>=base)break;
        if(value>cutoff||(value==cutoff&&d>cutlim)){errno=ERANGE;value=limit;any=-1;}
        else if(any>=0){value=value*(unsigned long)base+(unsigned long)d;any=1;}
    }
    if(endptr)*endptr=(char*)(p==start?s:p);
    if(!any)return 0L;
    if(any<0)return neg?LONG_MIN:LONG_MAX;
    if(neg&&value==(unsigned long)LONG_MAX+1UL)return LONG_MIN;
    return neg?-(long)value:(long)value;
}

int atoi(const char*s){return(int)strtol(s,NULL,10);} long atol(const char*s){return strtol(s,NULL,10);}
double atof(const char*s){int neg=0,expneg=0,exp=0;double v=0.0,scale=1.0;if(!s)return 0.0;while(isspace((unsigned char)*s))s++;if(*s=='-'||*s=='+')neg=*s++=='-';while(isdigit((unsigned char)*s))v=v*10.0+(double)(*s++-'0');if(*s=='.'){s++;while(isdigit((unsigned char)*s)){scale*=0.1;v+=(double)(*s++-'0')*scale;}}if(*s=='e'||*s=='E'){s++;if(*s=='-'||*s=='+')expneg=*s++=='-';while(isdigit((unsigned char)*s))exp=exp*10+(*s++-'0');while(exp-->0)v*=expneg?0.1:10.0;}return neg?-v:v;}
int abs(int x){return x<0?-x:x;} long labs(long x){return x<0?-x:x;}
static unsigned rng=1U;void srand(unsigned s){rng=s?s:1U;}int rand(void){rng=rng*1103515245U+12345U;return(int)((rng>>16)&RAND_MAX);}void srandom(unsigned s){srand(s);}long random(void){return(long)rand();}__attribute__((weak))void randomize(void){srand((unsigned)jtmos_syscall7(SYS_GETTICKCOUNT,0,0,0,0,0,0));}

static void byte_swap(unsigned char*a,unsigned char*b,size_t n){while(n--){unsigned char t=*a;*a++=*b;*b++=t;}}
static void sift_down(unsigned char *base,size_t start,size_t count,size_t size,int(*cmp)(const void*,const void*))
{
    size_t root=start;
    while(root < count && root <= (count - 1U) / 2U && root * 2U + 1U < count){
        size_t child=root*2U+1U,swapidx=root;
        if(cmp(base+swapidx*size,base+child*size)<0)swapidx=child;
        if(child+1U<count&&cmp(base+swapidx*size,base+(child+1U)*size)<0)swapidx=child+1U;
        if(swapidx==root)return;
        byte_swap(base+root*size,base+swapidx*size,size);root=swapidx;
    }
}
void qsort(void *base,size_t count,size_t size,int(*cmp)(const void*,const void*))
{
    unsigned char *p=(unsigned char*)base;size_t start,end;
    if(!base||!cmp||size==0U||count<2U)return;
    start=(count-2U)/2U+1U;while(start>0U){--start;sift_down(p,start,count,size,cmp);}
    end=count-1U;while(end>0U){byte_swap(p,p+end*size,size);sift_down(p,0U,end,size,cmp);--end;}
}
void *bsearch(const void*k,const void*b,size_t n,size_t z,int(*c)(const void*,const void*)){const unsigned char*p=b;size_t l=0,r=n;if(!k||!b||!c||z==0U)return NULL;while(l<r){size_t m=l+(r-l)/2U;int x=c(k,p+m*z);if(!x)return(void*)(p+m*z);if(x<0)r=m;else l=m+1U;}return NULL;}

#define ATEXIT_MAX 32
static void (*exit_handlers[ATEXIT_MAX])(void);
static unsigned exit_handler_count;
static int exiting;
int atexit(void(*fn)(void)){if(fn==NULL||exit_handler_count>=ATEXIT_MAX){errno=ENOMEM;return-1;}exit_handlers[exit_handler_count++]=fn;return 0;}
void exit(int code){if(!exiting){exiting=1;while(exit_handler_count>0U){void(*fn)(void)=exit_handlers[--exit_handler_count];if(fn)fn();}(void)fflush(NULL);} (void)jtmos_syscall7(SYS_EXIT,(uintptr_t)code,0,0,0,0,0);for(;;)(void)jtmos_syscall7(SYS_IDLE,0,0,0,0,0,0);}
void abort(void){exit(134);}int system(const char*s){(void)s;errno=ENOSYS;return -1;}
