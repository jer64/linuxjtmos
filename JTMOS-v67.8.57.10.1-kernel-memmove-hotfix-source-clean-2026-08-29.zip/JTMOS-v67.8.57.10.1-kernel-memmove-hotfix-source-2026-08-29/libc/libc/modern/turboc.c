#include <jtmos/turboc.h>
#include <jtmos/console.h>
#include <jtmos/process.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

void randomize(void){srand((unsigned)(GetTickCount() ^ ((unsigned)GetSeconds()<<16)));}
int kbhit(void){int c=getch1();if(c<0)return 0;/* JTMOS has no ungetch yet; put key back into current terminal. */OutputTerminalKeyboardBuffer(GetCurrentTerminal(),c);return 1;}
int getche(void){int c=getch();if(c>=0)putch(c);return c;}
void clreol(void){struct text_info ti;int x=wherex(),y=wherey(),i,width;gettextinfo(&ti);if(x<1)x=1;width=(int)ti.winright-(int)ti.winleft+1;if(width<1)width=80;for(i=x;i<=width;i++)putch(' ');gotoxy(x,y);}
void delline(void){/* Conservative compatibility implementation: clear current line. */int x=wherex(),y=wherey();gotoxy(1,y);clreol();gotoxy(x,y);}
void insline(void){int x=wherex(),y=wherey();gotoxy(1,y);clreol();gotoxy(x,y);}
int puttext(int l,int t,int r,int b,void *src){(void)l;(void)t;(void)r;(void)b;(void)src;return 0;}
int gettext(int l,int t,int r,int b,void *dst){(void)l;(void)t;(void)r;(void)b;(void)dst;return 0;}
