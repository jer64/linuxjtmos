#include <sys/mman.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>

/* Linux-style pointer syscalls use the top 4095 DWORD values for -errno. */
static int mmap_raw_error(uintptr_t raw)
{
    return raw >= (uintptr_t)0xfffff001UL;
}

static void *mmap_anon_syscall(void *addr,size_t length,int prot,int flags)
{
    uintptr_t raw;
    long call;
    call=jtmos_syscall7(SYS_mmap,(uintptr_t)addr,(uintptr_t)length,
                        (uintptr_t)prot,(uintptr_t)flags,
                        (uintptr_t)-1,0);
    raw=(uintptr_t)call;
    if(mmap_raw_error(raw)) {
        errno=-(int32_t)(uint32_t)raw;
        return MAP_FAILED;
    }
    return (void *)raw;
}

void *jtmos_mem_grow(size_t length)
{
    uintptr_t raw;
    long call;
    if(length==0U){errno=EINVAL;return MAP_FAILED;}
    call=jtmos_syscall7(SYS_mem_grow,(uintptr_t)length,0,0,0,0,0);
    raw=(uintptr_t)call;
    if(mmap_raw_error(raw)) {
        errno=-(int32_t)(uint32_t)raw;
        return MAP_FAILED;
    }
    return (void *)raw;
}

void *mmap(void *addr,size_t length,int prot,int flags,int fd,off_t offset)
{
    void *p;
    int anonymous;
    int kernel_flags;

    if(length==0U || offset<0){errno=EINVAL;return MAP_FAILED;}
    if((flags&MAP_SHARED) || !(flags&MAP_PRIVATE)){errno=ENOSYS;return MAP_FAILED;}
    anonymous=(flags&MAP_ANONYMOUS)!=0;

    /* Kernel VM only needs to know that backing is private anonymous memory.
     * A file-backed MAP_PRIVATE mapping is populated below as a snapshot. */
    kernel_flags=(flags&(MAP_FIXED|MAP_FIXED_NOREPLACE))|MAP_PRIVATE|MAP_ANONYMOUS;
    p=mmap_anon_syscall(addr,length,prot,kernel_flags);
    if(p==MAP_FAILED)return MAP_FAILED;
    if(anonymous)return p;

    if(fd<0){(void)munmap(p,length);errno=EBADF;return MAP_FAILED;}
    {
        off_t cur=lseek(fd,0,SEEK_CUR);
        size_t done=0U;
        if(lseek(fd,offset,SEEK_SET)<0){(void)munmap(p,length);return MAP_FAILED;}
        while(done<length){
            ssize_t r=read(fd,(char*)p+done,length-done);
            if(r<0){if(cur>=0)(void)lseek(fd,cur,SEEK_SET);(void)munmap(p,length);return MAP_FAILED;}
            if(r==0)break;
            done+=(size_t)r;
        }
        if(done<length)memset((char*)p+done,0,length-done);
        if(cur>=0)(void)lseek(fd,cur,SEEK_SET);
    }
    return p;
}

int munmap(void *addr,size_t length)
{
    long rc;
    if(!addr || addr==MAP_FAILED || !length){errno=EINVAL;return -1;}
    rc=jtmos_syscall7(SYS_munmap,(uintptr_t)addr,(uintptr_t)length,0,0,0,0);
    if(rc<0){errno=(int)-rc;return -1;}
    return 0;
}
