#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <unistd.h>
#include <sys/mman.h>
#include <jtmos/config.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>

size_t __jtmos_allocated_bytes;

#ifdef JTMOS_APPLICATION

typedef struct jtmos_heap_block {
    size_t size;
    struct jtmos_heap_block *next_phys;
    struct jtmos_heap_block *prev_free;
    struct jtmos_heap_block *next_free;
    uint32_t magic;
    uint32_t free;
} heap_block;

#define HEAP_MAGIC       0x4a54484dU /* JTHM */
#define HEAP_MIN_SPLIT   32U
#define HEAP_GROW_MIN    (64U * 1024U)
#define HEAP_BIN_COUNT   16U

/* V67.4 segregated free lists.  Physical ordering is kept separately so
 * adjacent chunks can still be coalesced. */
static heap_block *heap_bins[HEAP_BIN_COUNT];
static heap_block *heap_first;
static heap_block *heap_last;
static size_t heap_mmap_next = HEAP_GROW_MIN;

static size_t align_up_size(size_t value)
{
    const size_t a = (size_t)JTMOS_HEAP_ALIGNMENT;
    if(value > (size_t)-1 - (a - 1U)) return 0U;
    return (value + a - 1U) & ~(a - 1U);
}

static unsigned bin_index(size_t size)
{
    unsigned index = 0U;
    size_t bound = 32U;
    while(index + 1U < HEAP_BIN_COUNT && size > bound) {
        bound <<= 1;
        ++index;
    }
    return index;
}

static int valid_block(const heap_block *block)
{
    return block != NULL && block->magic == HEAP_MAGIC;
}

static void bin_remove(heap_block *block)
{
    unsigned index;
    if(!valid_block(block) || !block->free) return;
    index = bin_index(block->size);
    if(block->prev_free) block->prev_free->next_free = block->next_free;
    else if(heap_bins[index] == block) heap_bins[index] = block->next_free;
    if(block->next_free) block->next_free->prev_free = block->prev_free;
    block->prev_free = NULL;
    block->next_free = NULL;
}

static void bin_insert(heap_block *block)
{
    unsigned index;
    if(!valid_block(block)) return;
    block->free = 1U;
    index = bin_index(block->size);
    block->prev_free = NULL;
    block->next_free = heap_bins[index];
    if(heap_bins[index]) heap_bins[index]->prev_free = block;
    heap_bins[index] = block;
}

static int blocks_adjacent(const heap_block *a, const heap_block *b)
{
    const unsigned char *end;
    if(!valid_block(a) || !valid_block(b)) return 0;
    end = (const unsigned char *)(a + 1) + a->size;
    return end == (const unsigned char *)b;
}

static heap_block *find_prev_phys(heap_block *block)
{
    heap_block *p;
    if(block == heap_first) return NULL;
    for(p = heap_first; p != NULL && p->next_phys != block; p = p->next_phys) {}
    return p;
}

static void phys_insert(heap_block *block)
{
    heap_block *p;
    heap_block *prev;
    if(heap_first==NULL) {
        heap_first=heap_last=block;
        block->next_phys=NULL;
        return;
    }
    prev=NULL;
    for(p=heap_first; p!=NULL && (uintptr_t)p<(uintptr_t)block; p=p->next_phys)
        prev=p;
    if(prev==NULL) {
        block->next_phys=heap_first;
        heap_first=block;
    } else {
        block->next_phys=prev->next_phys;
        prev->next_phys=block;
    }
    if(block->next_phys==NULL) heap_last=block;
}

static void split_allocated_block(heap_block *block, size_t wanted)
{
    size_t remain;
    heap_block *tail;

    if(block->size < wanted) return;
    remain = block->size - wanted;
    if(remain < sizeof(heap_block) + HEAP_MIN_SPLIT) return;

    tail = (heap_block *)((unsigned char *)(block + 1) + wanted);
    tail->size = remain - sizeof(heap_block);
    tail->next_phys = block->next_phys;
    tail->prev_free = NULL;
    tail->next_free = NULL;
    tail->magic = HEAP_MAGIC;
    tail->free = 1U;
    block->size = wanted;
    block->next_phys = tail;
    if(heap_last == block) heap_last = tail;
    bin_insert(tail);
}

static heap_block *coalesce_block(heap_block *block)
{
    heap_block *next;
    heap_block *prev;

    if(!valid_block(block)) return block;

    next = block->next_phys;
    if(valid_block(next) && next->free && blocks_adjacent(block, next)) {
        bin_remove(next);
        block->size += sizeof(heap_block) + next->size;
        block->next_phys = next->next_phys;
        if(heap_last == next) heap_last = block;
        next->magic = 0U;
    }

    prev = find_prev_phys(block);
    if(valid_block(prev) && prev->free && blocks_adjacent(prev, block)) {
        bin_remove(prev);
        prev->size += sizeof(heap_block) + block->size;
        prev->next_phys = block->next_phys;
        if(heap_last == block) heap_last = prev;
        block->magic = 0U;
        block = prev;
    }
    return block;
}

static int grow_heap(size_t wanted)
{
    size_t payload;
    size_t total;
    size_t request;
    void *raw;
    heap_block *block;

    payload=wanted;
    if(payload<HEAP_GROW_MIN-sizeof(heap_block))
        payload=HEAP_GROW_MIN-sizeof(heap_block);
    payload=align_up_size(payload);
    if(payload==0U || payload>(size_t)-1-sizeof(heap_block)) {
        errno=ENOMEM;
        return -1;
    }
    total=align_up_size(payload+sizeof(heap_block));
    if(total==0U || total>(size_t)0x7fffffffU) {
        errno=ENOMEM;
        return -1;
    }

    /* First consume the original SYSMEMREQ heap. sbrk() is intentionally
     * bounded below the guard page and process stack. */
    raw=sbrk(0);
    if(raw!=(void *)-1) {
        uintptr_t current=(uintptr_t)raw;
        uintptr_t aligned=(current+JTMOS_HEAP_ALIGNMENT-1U)&
                          ~(uintptr_t)(JTMOS_HEAP_ALIGNMENT-1U);
        if(aligned==current ||
           sbrk((intptr_t)(aligned-current))!=(void *)-1)
            raw=sbrk((intptr_t)total);
        else
            raw=(void *)-1;
    }

    /* Once that fixed arena is full, grow with a real process mapping.  Grow
     * geometrically so a long-running process does not need hundreds of 64 KiB
     * VM descriptors, while preserving 64 KiB as the minimum increment. */
    if(raw==(void *)-1) {
        request=total;
        if(request<heap_mmap_next) request=heap_mmap_next;
        if(request>(size_t)0x7ffff000U){errno=ENOMEM;return -1;}
        request=(request+4095U)&~(size_t)4095U;
        raw=jtmos_mem_grow(request);
        if(raw==MAP_FAILED) return -1;
        total=request;
        if(heap_mmap_next<4U*1024U*1024U) {
            size_t next=request<<1;
            if(next>4U*1024U*1024U || next<request) next=4U*1024U*1024U;
            heap_mmap_next=next;
        }
    }

    block=(heap_block *)raw;
    block->size=total-sizeof(heap_block);
    block->next_phys=NULL;
    block->prev_free=NULL;
    block->next_free=NULL;
    block->magic=HEAP_MAGIC;
    block->free=1U;

    phys_insert(block);
    block=coalesce_block(block);
    bin_insert(block);
    return 0;
}

static heap_block *find_fit(size_t wanted)
{
    unsigned index = bin_index(wanted);
    for(; index < HEAP_BIN_COUNT; ++index) {
        heap_block *block;
        for(block = heap_bins[index]; block != NULL; block = block->next_free) {
            if(valid_block(block) && block->free && block->size >= wanted)
                return block;
        }
    }
    return NULL;
}

void *malloc(size_t size)
{
    heap_block *block;
    size_t wanted;

    if(size == 0U) size = 1U;
    wanted = align_up_size(size);
    if(wanted == 0U) { errno = ENOMEM; return NULL; }

    block = find_fit(wanted);
    if(block == NULL) {
        if(grow_heap(wanted) != 0) return NULL;
        block = find_fit(wanted);
        if(block == NULL) { errno = ENOMEM; return NULL; }
    }

    bin_remove(block);
    block->free = 0U;
    split_allocated_block(block, wanted);
    __jtmos_allocated_bytes += block->size;
    return (void *)(block + 1);
}

void free(void *ptr)
{
    heap_block *block;

    if(ptr == NULL) return;
    block = ((heap_block *)ptr) - 1;
    if(!valid_block(block) || block->free) { errno = EINVAL; return; }

    if(__jtmos_allocated_bytes >= block->size)
        __jtmos_allocated_bytes -= block->size;
    else
        __jtmos_allocated_bytes = 0U;

    block->free = 1U;
    block = coalesce_block(block);
    bin_insert(block);
}

void *calloc(size_t count, size_t size)
{
    size_t total;
    void *ptr;
    if(count != 0U && size > (size_t)-1 / count) { errno = ENOMEM; return NULL; }
    total = count * size;
    ptr = malloc(total);
    if(ptr != NULL) memset(ptr, 0, total);
    return ptr;
}

void *realloc(void *ptr, size_t size)
{
    heap_block *block;
    heap_block *next;
    size_t wanted;
    size_t old;
    void *newptr;

    if(ptr == NULL) return malloc(size);
    if(size == 0U) { free(ptr); return NULL; }
    wanted = align_up_size(size);
    if(wanted == 0U) { errno = ENOMEM; return NULL; }

    block = ((heap_block *)ptr) - 1;
    if(!valid_block(block) || block->free) { errno = EINVAL; return NULL; }
    old = block->size;

    if(block->size >= wanted) {
        split_allocated_block(block, wanted);
        if(old > block->size && __jtmos_allocated_bytes >= old - block->size)
            __jtmos_allocated_bytes -= old - block->size;
        return ptr;
    }

    next = block->next_phys;
    if(valid_block(next) && next->free && blocks_adjacent(block, next) &&
       block->size + sizeof(heap_block) + next->size >= wanted) {
        bin_remove(next);
        block->size += sizeof(heap_block) + next->size;
        block->next_phys = next->next_phys;
        if(heap_last == next) heap_last = block;
        next->magic = 0U;
        split_allocated_block(block, wanted);
        __jtmos_allocated_bytes += block->size - old;
        return ptr;
    }

    newptr = malloc(size);
    if(newptr == NULL) return NULL;
    memcpy(newptr, ptr, old < size ? old : size);
    free(ptr);
    return newptr;
}

void *reallocarray(void *ptr, size_t count, size_t size)
{
    if(count != 0U && size > (size_t)-1 / count) { errno = ENOMEM; return NULL; }
    return realloc(ptr, count * size);
}

size_t __jtmos_heap_free_bytes(void)
{
    size_t total = 0U;
    unsigned i;
    for(i = 0U; i < HEAP_BIN_COUNT; ++i) {
        heap_block *block;
        for(block = heap_bins[i]; block != NULL; block = block->next_free)
            if(valid_block(block) && block->free) total += block->size;
    }
    return total;
}

#else /* JTMOS_KERNEL32 */

typedef struct kernel_alloc_header { size_t size; } kernel_alloc_header;

void *malloc(size_t size)
{
    long raw;
    kernel_alloc_header *header;
    if(size == 0U) size = 1U;
    if(size > (size_t)-1 - sizeof(*header)) { errno = ENOMEM; return NULL; }
    raw = jtmos_syscall7(SYS_kmalloc,size + sizeof(*header),0,0,0,0,0);
    if(raw <= 0) { errno = ENOMEM; return NULL; }
    header = (kernel_alloc_header *)(uintptr_t)raw;
    header->size = size;
    __jtmos_allocated_bytes += size;
    return header + 1;
}
void free(void *ptr)
{
    kernel_alloc_header *header;
    if(ptr == NULL) return;
    header = ((kernel_alloc_header *)ptr) - 1;
    if(__jtmos_allocated_bytes >= header->size) __jtmos_allocated_bytes -= header->size;
    (void)jtmos_syscall7(SYS_kfree,(uintptr_t)header,0,0,0,0,0);
}
void *calloc(size_t count,size_t size)
{
    size_t total;
    void *ptr;
    if(count && size > (size_t)-1/count) { errno=ENOMEM; return NULL; }
    total=count*size; ptr=malloc(total); if(ptr) memset(ptr,0,total); return ptr;
}
void *realloc(void *ptr,size_t size)
{
    kernel_alloc_header *header;
    void *newptr;
    size_t old;
    if(!ptr) return malloc(size);
    if(!size){free(ptr);return NULL;}
    header=((kernel_alloc_header *)ptr)-1; old=header->size;
    newptr=malloc(size); if(!newptr)return NULL;
    memcpy(newptr,ptr,old<size?old:size); free(ptr); return newptr;
}
void *reallocarray(void *ptr,size_t count,size_t size)
{
    if(count && size > (size_t)-1/count){errno=ENOMEM;return NULL;}
    return realloc(ptr,count*size);
}
size_t __jtmos_heap_free_bytes(void){return 0U;}
#endif
