#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>

extern int main(int,char**);
extern void __jtmos_cpu_runtime_init(void);

int __jtmos_libc_start(void)
{
    __jtmos_cpu_runtime_init();
#ifdef JTMOS_APPLICATION
    enum { MAX_ARGC = 64, MAX_ARG_LEN = 256 };
    static char argbuf[MAX_ARGC][MAX_ARG_LEN];
    static char *argv[MAX_ARGC + 1];
    long raw_argc;
    int argc;
    int i;

    raw_argc = jtmos_syscall7(SYS_GETARGC,0,0,0,0,0,0);
    if(raw_argc < 0) argc = 0;
    else if(raw_argc > MAX_ARGC) argc = MAX_ARGC;
    else argc = (int)raw_argc;

    for(i = 0; i < argc; ++i) {
        long rc;
        argbuf[i][0] = '\0';
        rc = jtmos_syscall7(SYS_GETARGV,(uintptr_t)i,(uintptr_t)argbuf[i],0,0,0,0);
        if(rc < 0) argbuf[i][0] = '\0';
        argbuf[i][MAX_ARG_LEN - 1] = '\0';
        argv[i] = argbuf[i];
    }
    argv[argc] = NULL;
    return main(argc, argv);
#else
    return main(0, (char **)0);
#endif
}
