#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <stdarg.h>
#include <stdint.h>
#include <errno.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>

static long syscall_result(long result, int fallback_errno)
{
    if(result >= 0) return result;
    if(result <= -2 && result >= -255) errno = (int)-result;
    else errno = fallback_errno;
    return -1;
}

int open(const char *path, int flags, ...)
{
    uintptr_t mode = 0;
    long result;
    if(path == NULL) { errno = EFAULT; return -1; }
    if(flags & O_CREAT) {
        va_list args;
        va_start(args, flags);
        mode = (uintptr_t)va_arg(args, unsigned int);
        va_end(args);
    }
    result = jtmos_syscall7(SYS_open,(uintptr_t)path,(uintptr_t)flags,mode,0,0,0);
    return (int)syscall_result(result, ENOENT);
}

int close(int fd)
{
    return (int)syscall_result(jtmos_syscall7(SYS_close,(uintptr_t)fd,0,0,0,0,0), EBADF);
}

ssize_t read(int fd, void *buffer, size_t count)
{
    long result;
    if(buffer == NULL && count != 0U) { errno = EFAULT; return -1; }
    result = jtmos_syscall7(SYS_read,(uintptr_t)fd,(uintptr_t)buffer,(uintptr_t)count,0,0,0);
    return (ssize_t)syscall_result(result, EIO);
}

ssize_t write(int fd, const void *buffer, size_t count)
{
    long result;
    if(buffer == NULL && count != 0U) { errno = EFAULT; return -1; }
    result = jtmos_syscall7(SYS_write,(uintptr_t)fd,(uintptr_t)buffer,(uintptr_t)count,0,0,0);
    return (ssize_t)syscall_result(result, EIO);
}

off_t lseek(int fd, off_t offset, int whence)
{
    return (off_t)syscall_result(jtmos_syscall7(SYS_lseek,(uintptr_t)fd,(uintptr_t)offset,(uintptr_t)whence,0,0,0), EINVAL);
}

int unlink(const char *path)
{
    if(path == NULL) { errno = EFAULT; return -1; }
    return (int)syscall_result(jtmos_syscall7(SYS_remove,(uintptr_t)path,0,0,0,0,0), ENOENT);
}

int chdir(const char *path)
{
    if(path == NULL) { errno = EFAULT; return -1; }
    return (int)syscall_result(jtmos_syscall7(SYS_chdir,(uintptr_t)path,0,0,0,0,0), ENOENT);
}

char *getcwd(char *buffer, size_t size)
{
    long result;
    if(buffer == NULL || size == 0U) { errno = EINVAL; return NULL; }
    result = jtmos_syscall7(SYS_getcwd,(uintptr_t)buffer,(uintptr_t)size,0,0,0,0);
    if(syscall_result(result, ERANGE) < 0) return NULL;
    buffer[size - 1U] = '\0';
    return buffer;
}

int mkdir(const char *path, mode_t mode)
{
    (void)mode;
    if(path == NULL) { errno = EFAULT; return -1; }
    return (int)syscall_result(jtmos_syscall7(SYS_mkdir,(uintptr_t)path,0,0,0,0,0), EIO);
}

int stat(const char *path, struct stat *status)
{
    if(path == NULL || status == NULL) { errno = EFAULT; return -1; }
    return (int)syscall_result(jtmos_syscall7(SYS_stat,(uintptr_t)path,(uintptr_t)status,0,0,0,0), ENOENT);
}

int fstat(int fd, struct stat *status)
{
    if(status == NULL) { errno = EFAULT; return -1; }
    return (int)syscall_result(jtmos_syscall7(SYS_fstat,(uintptr_t)fd,(uintptr_t)status,0,0,0,0), EBADF);
}

unsigned sleep(unsigned seconds)
{
    unsigned i;
    for(i = 0U; i < seconds; ++i)
        (void)jtmos_syscall7(SYS_milsleep,1000U,0,0,0,0,0);
    return 0U;
}

int usleep(useconds_t usec)
{
    return (int)syscall_result(jtmos_syscall7(SYS_usleep,(uintptr_t)usec,0,0,0,0,0), EINVAL);
}

int link(const char *oldpath, const char *newpath)
{
    (void)oldpath; (void)newpath;
    errno = ENOSYS;
    return -1;
}
