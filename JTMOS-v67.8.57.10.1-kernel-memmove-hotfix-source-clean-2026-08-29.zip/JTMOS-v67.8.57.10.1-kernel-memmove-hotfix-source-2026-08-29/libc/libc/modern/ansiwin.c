#include <jtmos/console.h>
#include <stdio.h>
void DrawAnsiWindow(int x1,int y1,int x2,int y2,int type,char *headline,int fill){
    int x,y; int t=type&127;
    if(x2<x1||y2<y1)return;
    if(fill){ for(y=y1;y<=y2;y++){ gotoxy(x1,y); for(x=x1;x<=x2;x++) putch(' '); } }
    /* CP437-compatible borders used by historical JTMOS text mode. */
    if(t==1||t==3){
        gotoxy(x1,y1);putch(0xc9); gotoxy(x2,y1);putch(0xbb);
        gotoxy(x1,y2);putch(0xc8); gotoxy(x2,y2);putch(0xbc);
        for(x=x1+1;x<x2;x++){gotoxy(x,y1);putch(0xcd);gotoxy(x,y2);putch(0xcd);}
        for(y=y1+1;y<y2;y++){gotoxy(x1,y);putch(0xba);gotoxy(x2,y);putch(0xba);}
    }else{
        gotoxy(x1,y1);putch(0xda); gotoxy(x2,y1);putch(0xbf);
        gotoxy(x1,y2);putch(0xc0); gotoxy(x2,y2);putch(0xd9);
        for(x=x1+1;x<x2;x++){gotoxy(x,y1);putch(0xc4);gotoxy(x,y2);putch(0xc4);}
        for(y=y1+1;y<y2;y++){gotoxy(x1,y);putch(0xb3);gotoxy(x2,y);putch(0xb3);}
    }
    if((t==2||t==3) && headline){gotoxy(x1+1,y1+1);printf("%s",headline);}
    gotoxy(x1+1,(t==2||t==3)?y1+3:y1+1);
}
