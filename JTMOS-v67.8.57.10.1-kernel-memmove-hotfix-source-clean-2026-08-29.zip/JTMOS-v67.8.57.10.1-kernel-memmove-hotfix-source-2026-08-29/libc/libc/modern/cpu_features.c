#include <jtmos/cpu_features.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>

static unsigned long cached_features;
static int cached_valid;

void __jtmos_cpu_runtime_init(void)
{
#ifdef JTMOS_APPLICATION
    long v=jtmos_syscall7(SYS_getcpufeatures,0,0,0,0,0,0);
    cached_features=(v<0)?0UL:(unsigned long)v;
#else
    cached_features=0;
#endif
    cached_valid=1;
}

unsigned long jtmos_cpu_features(void)
{
    if(!cached_valid)__jtmos_cpu_runtime_init();
    return cached_features;
}

int jtmos_cpu_has(unsigned long mask)
{
    return (jtmos_cpu_features()&mask)==mask;
}

int __jtmos_sse3_runtime_enabled(void)
{
    return jtmos_cpu_has(JTMOS_CPUF_SSE3_ACCEL);
}
