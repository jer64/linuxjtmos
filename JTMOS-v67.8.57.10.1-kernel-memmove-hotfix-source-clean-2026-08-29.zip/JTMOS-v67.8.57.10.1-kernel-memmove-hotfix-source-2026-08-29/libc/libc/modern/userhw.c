#include <jtmos/irq.h>
#include <jtmos/dma.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>
#include <stdint.h>
#include <errno.h>
#include <dpmi.h>
#include <go32.h>

int jtmos_irq_subscribe(int irq, unsigned long flags)
{
    return (int)jtmos_syscall7(SYS_irqsubscribe,(uintptr_t)irq,flags,0,0,0,0);
}
int jtmos_irq_unsubscribe(unsigned long handle)
{
    return (int)jtmos_syscall7(SYS_irqunsubscribe,handle,0,0,0,0,0);
}
int jtmos_irq_wait(unsigned long handle, unsigned long timeout_ms)
{
    return (int)jtmos_syscall7(SYS_irqwait,handle,timeout_ms,0,0,0,0);
}
int jtmos_dma_alloc(size_t bytes, unsigned long flags, jtmos_dma_buffer *out)
{
    if(!out || !bytes) { errno=EINVAL; return -1; }
    return (int)jtmos_syscall7(SYS_dmaalloc,(uintptr_t)bytes,flags,(uintptr_t)out,0,0,0);
}
int jtmos_dma_free(unsigned long handle)
{
    return (int)jtmos_syscall7(SYS_dmafree,handle,0,0,0,0,0);
}
int jtmos_dma_program(unsigned long handle, int channel, size_t length, int direction)
{
    return (int)jtmos_syscall7(SYS_dmaprogram,handle,(uintptr_t)channel,
        (uintptr_t)length,(uintptr_t)direction,0,0);
}
int jtmos_dma_stop(unsigned long handle, int channel)
{
    return (int)jtmos_syscall7(SYS_dmastop,handle,(uintptr_t)channel,0,0,0,0);
}

int _go32_dpmi_lock_code(void *address, unsigned long length)
{
    (void)address; (void)length;
    return 0;
}
int _go32_dpmi_lock_data(void *address, unsigned long length)
{
    (void)address; (void)length;
    return 0;
}

static int dpmi_direct_isr_unsupported(void)
{
    errno=ENOTSUP;
    return -1;
}
int _go32_dpmi_get_protected_mode_interrupt_vector(int vector, _go32_dpmi_seginfo *info)
{
    (void)vector;
    if(info) {
        info->pm_offset=0; info->pm_selector=0;
        info->rm_segment=0; info->rm_offset=0;
    }
    return dpmi_direct_isr_unsupported();
}
int _go32_dpmi_set_protected_mode_interrupt_vector(int vector, _go32_dpmi_seginfo *info)
{
    (void)vector; (void)info;
    return dpmi_direct_isr_unsupported();
}
int _go32_dpmi_chain_protected_mode_interrupt_vector(int vector, _go32_dpmi_seginfo *info)
{
    (void)vector; (void)info;
    return dpmi_direct_isr_unsupported();
}
int _go32_dpmi_allocate_iret_wrapper(_go32_dpmi_seginfo *info)
{
    (void)info;
    return dpmi_direct_isr_unsupported();
}
int _go32_dpmi_free_iret_wrapper(_go32_dpmi_seginfo *info)
{
    (void)info;
    return 0;
}

int _go32_dpmi_jtmos_irq_subscribe(int irq) { return jtmos_irq_subscribe(irq,0); }
int _go32_dpmi_jtmos_irq_wait(int handle, unsigned long timeout_ms)
{ return jtmos_irq_wait((unsigned long)handle,timeout_ms); }
int _go32_dpmi_jtmos_irq_unsubscribe(int handle)
{ return jtmos_irq_unsubscribe((unsigned long)handle); }
int _go32_dpmi_jtmos_dma_alloc(unsigned long bytes, jtmos_dma_buffer *out)
{ return jtmos_dma_alloc((size_t)bytes,0,out); }
int _go32_dpmi_jtmos_dma_free(unsigned long handle) { return jtmos_dma_free(handle); }

__Go32_Info_Block _go32_info_block = {
    sizeof(_go32_info_block),0,0,0,0,0,0x68,0x70,0,0,0,0,0
};

#if defined(__i386__)
static int go32_read_seg(const char *which)
{
    unsigned short v=0;
    if(which[0]=='c') __asm__ volatile("movw %%cs,%0":"=rm"(v));
    else if(which[0]=='d') __asm__ volatile("movw %%ds,%0":"=rm"(v));
    else if(which[0]=='s') __asm__ volatile("movw %%ss,%0":"=rm"(v));
    else __asm__ volatile("movw %%es,%0":"=rm"(v));
    return (int)v;
}
#else
static int go32_read_seg(const char *which) { (void)which; return 0; }
#endif
int _go32_my_cs(void){return go32_read_seg("c");}
int _go32_my_ds(void){return go32_read_seg("d");}
int _go32_my_ss(void){return go32_read_seg("s");}
int _go32_my_es(void){return go32_read_seg("e");}


/* Legacy JTMOS mouse API used by the standalone GraOS server.  These calls
 * stay in normal application context and use the existing syscall ABI. */
int SetMouseRect(int x1,int y1,int x2,int y2)
{
    return (int)jtmos_syscall7(SYS_setmouserect,(uintptr_t)x1,(uintptr_t)y1,
        (uintptr_t)x2,(uintptr_t)y2,0,0);
}
int GetMouseX(void)
{
    return (int)jtmos_syscall7(SYS_inputmouse,0,0,0,0,0,0);
}
int GetMouseY(void)
{
    return (int)jtmos_syscall7(SYS_inputmouse,1,0,0,0,0,0);
}
int GetMouseButtons(void)
{
    return (int)jtmos_syscall7(SYS_inputmouse,2,0,0,0,0,0);
}
unsigned long GetMouseIRQCount(void)
{
    return (unsigned long)jtmos_syscall7(SYS_inputmouse,3,0,0,0,0,0);
}
unsigned long GetMouseByteCount(void)
{
    return (unsigned long)jtmos_syscall7(SYS_inputmouse,4,0,0,0,0,0);
}
unsigned long GetMousePacketCount(void)
{
    return (unsigned long)jtmos_syscall7(SYS_inputmouse,5,0,0,0,0,0);
}
int GetMouseStreamStatus(void)
{
    return (int)jtmos_syscall7(SYS_inputmouse,6,0,0,0,0,0);
}
