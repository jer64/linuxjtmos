#include <string.h>
#include <stdlib.h>
#include <errno.h>

extern int __jtmos_sse3_runtime_enabled(void);

#if defined(__GNUC__)
#define SSE3_FN __attribute__((target("sse3"),noinline))
#else
#define SSE3_FN
#endif

static void *memcpy_i486(void *d,const void *s,size_t n)
{
    unsigned char *D=(unsigned char *)d;
    const unsigned char *S=(const unsigned char *)s;
    size_t i;
    for(i=0;i<n;i++)D[i]=S[i];
    return d;
}

static void *memset_i486(void *d,int c,size_t n)
{
    unsigned char *D=(unsigned char *)d;
    size_t i;
    for(i=0;i<n;i++)D[i]=(unsigned char)c;
    return d;
}

SSE3_FN static void *memcpy_sse3(void *d,const void *s,size_t n)
{
    unsigned char *D=(unsigned char *)d;
    const unsigned char *S=(const unsigned char *)s;
    void *ret=d;
    while(n>=64){
        __asm__ __volatile__(
            "lddqu 0(%0),%%xmm0\n\tlddqu 16(%0),%%xmm1\n\t"
            "lddqu 32(%0),%%xmm2\n\tlddqu 48(%0),%%xmm3\n\t"
            "movdqu %%xmm0,0(%1)\n\tmovdqu %%xmm1,16(%1)\n\t"
            "movdqu %%xmm2,32(%1)\n\tmovdqu %%xmm3,48(%1)"
            : : "r"(S),"r"(D) : "xmm0","xmm1","xmm2","xmm3","memory");
        S+=64;D+=64;n-=64;
    }
    while(n--)*D++=*S++;
    return ret;
}

SSE3_FN static void *memset_sse3(void *d,int c,size_t n)
{
    unsigned char *D=(unsigned char *)d;
    void *ret=d;
    unsigned long pattern=(unsigned char)c;
    pattern|=pattern<<8; pattern|=pattern<<16;
    __asm__ __volatile__("movd %0,%%xmm0\n\tpshufd $0,%%xmm0,%%xmm0"
                         : : "r"(pattern) : "xmm0");
    while(n>=64){
        __asm__ __volatile__(
            "movdqu %%xmm0,0(%0)\n\tmovdqu %%xmm0,16(%0)\n\t"
            "movdqu %%xmm0,32(%0)\n\tmovdqu %%xmm0,48(%0)"
            : : "r"(D) : "memory");
        D+=64;n-=64;
    }
    while(n--)*D++=(unsigned char)c;
    return ret;
}

void *memcpy(void *restrict d,const void *restrict s,size_t n)
{
    if(n>=128 && __jtmos_sse3_runtime_enabled())return memcpy_sse3(d,s,n);
    return memcpy_i486(d,s,n);
}

void *memmove(void*d,const void*s,size_t n)
{
    unsigned char*D=(unsigned char*)d;const unsigned char*S=(const unsigned char*)s;size_t i;
    if(D==S||n==0)return d;
    /* Non-overlapping moves can use the same runtime SSE3 memcpy path. */
    if(D+n<=S || S+n<=D)return memcpy(d,s,n);
    if(D<S){for(i=0;i<n;i++)D[i]=S[i];}
    else {for(i=n;i!=0;i--)D[i-1]=S[i-1];}
    return d;
}

void *memset(void*d,int c,size_t n)
{
    if(n>=128 && __jtmos_sse3_runtime_enabled())return memset_sse3(d,c,n);
    return memset_i486(d,c,n);
}
int memcmp(const void*a,const void*b,size_t n){const unsigned char*A=a,*B=b;size_t i;for(i=0;i<n;i++)if(A[i]!=B[i])return A[i]<B[i]?-1:1;return 0;}
void *memchr(const void*s,int c,size_t n){const unsigned char*S=s;size_t i;for(i=0;i<n;i++)if(S[i]==(unsigned char)c)return(void*)(S+i);return NULL;}
size_t strlen(const char*s){size_t n=0;if(!s)return 0;while(s[n])n++;return n;}
size_t strnlen(const char*s,size_t m){size_t n=0;if(!s)return 0;while(n<m&&s[n])n++;return n;}
char *strcpy(char*d,const char*s){char*r=d;while((*d++=*s++));return r;}
char *strncpy(char*d,const char*s,size_t n){size_t i=0;for(;i<n&&s[i];i++)d[i]=s[i];for(;i<n;i++)d[i]=0;return d;}
char *strcat(char*d,const char*s){strcpy(d+strlen(d),s);return d;}
char *strncat(char*d,const char*s,size_t n){char*p=d+strlen(d);size_t i=0;while(i<n&&s[i]){p[i]=s[i];i++;}p[i]=0;return d;}
int strcmp(const char*a,const char*b){while(*a&&*a==*b){a++;b++;}return(unsigned char)*a-(unsigned char)*b;}
int strncmp(const char*a,const char*b,size_t n){size_t i;for(i=0;i<n;i++){unsigned char A=a[i],B=b[i];if(A!=B)return A-B;if(!A)return 0;}return 0;}
char *strchr(const char*s,int c){do{if(*s==(char)c)return(char*)s;}while(*s++);return NULL;}
char *strrchr(const char*s,int c){const char*r=NULL;do{if(*s==(char)c)r=s;}while(*s++);return(char*)r;}
char *strstr(const char*h,const char*n){size_t nl;if(!*n)return(char*)h;nl=strlen(n);for(;*h;h++)if(*h==*n&&strncmp(h,n,nl)==0)return(char*)h;return NULL;}
char *strpbrk(const char*s,const char*a){for(;*s;s++)if(strchr(a,*s))return(char*)s;return NULL;}
size_t strspn(const char*s,const char*a){size_t n=0;while(s[n]&&strchr(a,s[n]))n++;return n;}
size_t strcspn(const char*s,const char*r){size_t n=0;while(s[n]&&!strchr(r,s[n]))n++;return n;}
char *strdup(const char*s){size_t n;char*p;if(!s){errno=EINVAL;return NULL;}n=strlen(s)+1U;p=malloc(n);if(p)memcpy(p,s,n);return p;}
char *strndup(const char*s,size_t maxlen){size_t n;char*p;if(!s){errno=EINVAL;return NULL;}n=strnlen(s,maxlen);p=malloc(n+1U);if(!p)return NULL;memcpy(p,s,n);p[n]='\0';return p;}
char *strerror(int e){switch(e){case 0:return"Success";case EPERM:return"Operation not permitted";case ENOENT:return"No such file or directory";case EINTR:return"Interrupted system call";case EIO:return"I/O error";case EBADF:return"Bad file descriptor";case ENOMEM:return"Out of memory";case EACCES:return"Permission denied";case EFAULT:return"Bad address";case EEXIST:return"File exists";case ENODEV:return"No such device";case ENOTDIR:return"Not a directory";case EISDIR:return"Is a directory";case EINVAL:return"Invalid argument";case ENOSPC:return"No space left on device";case EFBIG:return"File too large";case ENAMETOOLONG:return"File name too long";case ENOSYS:return"Function not implemented";case ENOTSUP:return"Operation not supported";default:return"Unknown error";}}
void bzero(void*s,size_t n){memset(s,0,n);}void bcopy(const void*s,void*d,size_t n){memmove(d,s,n);}
void sptstr(char*dst,const char*src,char split,long item,long maxlen){size_t i=0,o=0;long cur=0;if(!dst)return;if(!src){dst[0]=0;return;}while(src[i]){if(cur==item){while(src[i]&&src[i]!=split){if(maxlen<=0||(long)o<maxlen)dst[o++]=src[i];i++;}break;}while(src[i]&&src[i]!=split)i++;if(src[i]==split){i++;cur++;}}dst[o]=0;}
