#ifndef _JTMOS_CONFIG_H
#define _JTMOS_CONFIG_H
#if defined(JTMOS_KERNEL32) && defined(JTMOS_APPLICATION)
#error "select only one JTMOS execution mode"
#endif
#if !defined(JTMOS_KERNEL32) && !defined(JTMOS_APPLICATION)
#define JTMOS_APPLICATION 1
#endif
#define JTMOS_LIBC_VERSION 0x02060000UL
#define JTMOS_LIBC_VERSION_STRING "JTMOS libc GCC freestanding 2026.08"
#endif
