#ifndef _JTMOS_SYS_STAT_H
#define _JTMOS_SYS_STAT_H
#include <sys/types.h>
struct stat { unsigned long st_size; unsigned long st_mode; unsigned long st_mtime; unsigned long st_reserved[8]; };
int stat(const char*,struct stat*); int fstat(int,struct stat*); int mkdir(const char*, mode_t);
#endif
