#ifndef _JTMOS_STDIO_H
#define _JTMOS_STDIO_H
#include <stddef.h>
#include <stdarg.h>
#include <sys/types.h>
#include <jtmos/types.h>
#include <jtmos/process.h>
#include <jtmos/console.h>
#include <jtmos/video.h>
#include <jtmos/audio.h>
#include <jtmos/file.h>
#include <jtmos/filefind.h>
#define EOF (-1)
#define BUFSIZ 512
#define FILENAME_MAX 1024
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
typedef struct __jtmos_FILE { int fd; unsigned flags; int eof; int err; int ungot; char *tmpfname; int readonly; } FILE;
extern FILE *stdin,*stdout,*stderr;
int printf(const char*,...); int vprintf(const char*,va_list); int fprintf(FILE*,const char*,...); int vfprintf(FILE*,const char*,va_list);
int sprintf(char*,const char*,...); int vsprintf(char*,const char*,va_list); int snprintf(char*,size_t,const char*,...); int vsnprintf(char*,size_t,const char*,va_list);
int puts(const char*); int putchar(int); int putc(int,FILE*); int fputc(int,FILE*); int fputs(const char*,FILE*);
int getchar(void); int getc(FILE*); int fgetc(FILE*); char *gets(char*); char *fgets(char*,int,FILE*); int ungetc(int,FILE*);
FILE *fopen(const char*,const char*); FILE *freopen(const char*,const char*,FILE*); int fclose(FILE*); int fflush(FILE*);
size_t fread(void*,size_t,size_t,FILE*); size_t fwrite(const void*,size_t,size_t,FILE*); int fseek(FILE*,long,int); long ftell(FILE*); void rewind(FILE*);
int feof(FILE*); int ferror(FILE*); void clearerr(FILE*); int fileno(FILE*); int remove(const char*); int rename(const char*,const char*); void perror(const char*);
int scanf(const char*,...); int fscanf(FILE*,const char*,...); int sscanf(const char*,const char*,...); int vsscanf(const char*,const char*,va_list);
#endif
