// JTMOS V56 scheduler CPU/load statistics libc wrapper.
#include <jtmos/process.h>

int GetCPUStats(JTMOS_CPU_STATS *stats)
{
    if(!stats) return -1;
    return (int)scall(SYS_getcpustats, (DWORD)stats, (DWORD)sizeof(*stats), 0, 0, 0, 0);
}
