#ifndef __INCLUDED_MM_H__
#define __INCLUDED_MM_H__

// Virtual address where the allocation database is mapped.
#define MAPAD_MM_DB             0xF2000000

#include <stdio.h>

// To debug or not to debug
//#define MMPRINT               printk
#define MMPRINT                 //

// Page size for IA-32 JTMOS.
#define PAGESIZE                4096

// Allocation database backing store. The database contains the descriptor
// pointer array, descriptors themselves and a 4 GB / 4 KB free-page bitmap.
#define ALLOCATION_DATABASE_SIZE    (1024*1024*1)
#define MM_BITMAP_PAGES             (1024*1024)
#define MM_BITMAP_BYTES             (MM_BITMAP_PAGES/8)

// Virtual allocation-database mapping bounds (legacy exported names).
extern char *MSTART,*MEND,*REND;

// Memory Descriptor (MD)
typedef struct
{
    // INFO REGION
    // Physical beginning of the region.
    char *p;
    // Process ID of the process which owns this memory region.
    int PID;
    // Physical start page for the region.
    int page;
    // Length of the region in pages.
    int pages;
    // Allocated length of the region in bytes (page rounded).
    int bytes;
    // 1 = descriptor slot is free, 0 = descriptor is in use.
    int isFree;

    // Linear address where the memory is mapped.
    DWORD mapad;

    // DEBUG REGION
    char name[20];
} MD;

typedef struct
{
    // PTRs to the descriptors of allocated/free descriptor slots.
    MD **allocated;
    // High-water mark: number of descriptor slots introduced into the table.
    int n_allocated;
    // Maximum number of descriptor slots available in the DB.
    int max_allocated;
    // Physical free-page bitmap; one bit represents one 4 KB page.
    BYTE *bitmap;
    int l_bitmap;
} MM;
extern MM *p_mm;

extern int mallocOK;
extern int mm_debug;

// Core functions.
void mmInit(void *region, int length);
void mm_Diagnostics(void);
void ShowPageMap(void);
void MMPANIC(const char *msg);

#include "mmBit.h"
#include "mmEntry.h"
#include "paging.h"


/* ------------------------------------------------------------------
 * ELF32 application address-space helpers.
 * One application owns a 16 MiB window beginning at 0x80000000.
 * ------------------------------------------------------------------ */
#define MM_PAGE_SIZE       PAGESIZE
#define MM_USER_BASE       0x80000000UL
#define MM_USER_PAGES      4096UL
#define MM_USER_SIZE       (MM_USER_PAGES * PAGESIZE)
#define MM_USER_TOP        (MM_USER_BASE + MM_USER_SIZE)
#define MM_PAGE_MASK       (PAGESIZE - 1UL)

/* Each process owns one 16 MiB / 4096-entry PTE array. On IA-32 a PTE is
 * exactly four bytes. Four MiB at 0x00600000 therefore provides 256 slots,
 * enough for the kernel's N_MAX_THREADS=250 configuration. */
#define MM_IA32_PTE_BYTES              4UL
#define MM_PROCESS_PAGE_TABLE_BYTES    (MM_USER_PAGES * MM_IA32_PTE_BYTES)
#define MM_PROCESS_PAGE_TABLE_CAPACITY (PG_USER_PAGE_TABLES_BYTES / MM_PROCESS_PAGE_TABLE_BYTES)

DWORD mm_page_align_down(DWORD value);
DWORD mm_page_align_up(DWORD value);
void mm_clear_process_space(int pid);
int mm_map_process_range(int pid, DWORD virtual_address,
                         void *kernel_address, DWORD length, int prot);
int mm_protect_process_range(int pid, DWORD virtual_address,
                             DWORD length, int prot);
int mm_unmap_process_range(int pid, DWORD virtual_address, DWORD length);

#endif
