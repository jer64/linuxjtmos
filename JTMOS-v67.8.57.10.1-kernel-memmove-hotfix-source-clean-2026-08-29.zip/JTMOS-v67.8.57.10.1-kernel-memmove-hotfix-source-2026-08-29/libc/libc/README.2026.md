# JTMOS libc GCC-freestanding 2026 refresh

This tree keeps the historical JTMOS libc sources for reference, but the default Makefile now builds a self-contained modernized C library from `modern/` and public headers from `include/`.

## ABI profiles

* `make application` -> `libcjtmos.a`, compiled for 32-bit i386 application modules. System services use the existing `int 0x7f` ABI. `crt0` obtains `argc/argv` through `SYS_GETARGC` / `SYS_GETARGV`.
* `make kernel` -> `libcjtmos-kernel.a`, compiled with `JTMOS_KERNEL32`. System services call `jtmos_kernel_syscall7()`. The archive contains a weak `-ENOSYS` fallback; kernel32 should provide a strong dispatcher with the same prototype.
* `make both` builds both archives.

The ABI intentionally uses `-m32 -ffreestanding -fno-pie -fno-pic -fno-stack-protector`, matching the ELF32 loader and static-link goal. `stdarg.h` uses GCC compiler built-ins instead of the old hand-written i386 varargs implementation. Standard integer and size types use compiler-provided ABI types.

## Static ELF application

Example:

    gcc -m32 -std=gnu11 -ffreestanding -fno-pie -fno-pic -fno-stack-protector \
        -nostdinc -Ilibc/include -c hello.c -o hello.o
    ld -m elf_i386 -static -T libc/jtmos_elf32.ld \
        libc/build/application/crt0.o hello.o libc/libcjtmos.a -o hello.elf

The linker script is compatible with the JTMOS ELF32 loader profile at virtual address `0x80004000`.

## Kernel integration

Provide a strong function from kernel32:

    long jtmos_kernel_syscall7(DWORD nr, uintptr_t b, uintptr_t c,
                               uintptr_t d, uintptr_t s, uintptr_t di,
                               uintptr_t bp);

It should dispatch directly to the same services used by the `int 0x7f` user ABI. This avoids executing a user-facing interrupt from inside the kernel while keeping one libc implementation.

## Notes

The original tree had several broken symlinks into an external kernel source tree (`filedef.h`, Postman headers, fapi files, syscall headers). The 2026 default build no longer depends on those broken links. Historical files are retained and the original Makefile is saved as `Makefile.legacy`.

## Legacy application build profile

Historical apps from `apps.zip` are compiled with GNU89 source compatibility while the libc itself is compiled as GNU11. Use `make app SRC=../apps/hello.c OUT=hello.elf` for a single-source program, or include the flags from `mk/jtmos-app.mk` in multi-source application makefiles. The application profile explicitly undefines host Linux macros so conditional host-only code is not accidentally selected.

`include/` is now the real public include tree. `include2026` is retained only as a relative compatibility symlink.

`mmap()`/`munmap()` are provided for source compatibility. Because the current application syscall table has no VM mapping syscall, the application backend supports anonymous and file-backed `MAP_PRIVATE` mappings using libc allocation; `MAP_SHARED` and fixed-address mappings return `ENOSYS`. A future kernel VM hook can replace this without changing the public header.

## Regression tests

`make check` performs strict header tests plus application and kernel link smoke tests.

For the historical app tree:

    make test-apps APPS_DIR=/path/to/apps

runs the raw-source test. In the supplied `apps.zip`, `mdir.c` fails because its own `msdos.h` has two struct members named `totalSectors`. The minimal correction is in `compat/apps_2026_source_fix.patch`; `make test-apps-fixed APPS_DIR=/path/to/apps` tests a temporary corrected copy without modifying the original directory. See `TEST_RESULTS_2026.txt` for the recorded results.
