// ======================================================
// JTMOS libc audio syscall wrappers - V58
// ======================================================
#include "scall.h"
#include "syscallcodes.h"
#include "basdef.h"
#include "audio.h"

int AudioInit(void)
{
    return scall(SYS_audioinit, AUDIO_BACKEND_AUTO,0,0,0,0,0);
}
int AudioSelectBackend(int backend)
{
    int r=scall(SYS_audioselect,backend,0,0,0,0,0);
    if(r<0)return r;
    return scall(SYS_audioinit,backend,0,0,0,0,0);
}
int AudioWrite(const void *buf,int len,int type,int freq)
{
    return scall(SYS_audiowrite,(DWORD)buf,len,type,freq,0,0);
}
int AudioStop(void)
{
    return scall(SYS_audiostop,0,0,0,0,0,0);
}
int AudioGetInfo(JTMOS_AUDIO_INFO *info)
{
    return scall(SYS_audioinfo,(DWORD)info,sizeof(*info),0,0,0,0);
}
void InitAudio(void){ (void)AudioInit(); }
DWORD GetAudioPosition(void){ return scall(SYS_audioposition,0,0,0,0,0,0); }
void SendAudio(const void *buf,int len,int type,int freq)
{
    const BYTE *p=buf; int off=0,n;
    while(off<len)
    {
        n=AudioWrite(p+off,len-off,type,freq);
        if(n<0)return;
        if(n==0){ scall(SYS_switchtothread,0,0,0,0,0,0); continue; }
        off+=n;
    }
}
