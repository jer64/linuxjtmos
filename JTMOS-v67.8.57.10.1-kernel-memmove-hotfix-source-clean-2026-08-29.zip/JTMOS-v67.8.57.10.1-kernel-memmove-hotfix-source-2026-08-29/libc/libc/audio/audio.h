#ifndef __INCLUDED_LIBC_AUDIO_LOCAL_H__
#define __INCLUDED_LIBC_AUDIO_LOCAL_H__
#include <jtmos/audio.h>
#endif
