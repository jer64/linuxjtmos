# JTMOS libc 2026 changes

- Replaced the default build with a self-contained GCC freestanding i386 libc under `modern/`.
- Preserved the historical sources and original build as `Makefile.legacy` for reference.
- Rebuilt the public header tree under a real `include/` directory; no kernel-tree symlinks are required by the default build.
- Added GCC builtin-based `stdarg.h`, compiler-ABI `size_t`/`ptrdiff_t`, fixed-width integer headers, C/POSIX-style file and memory APIs, and JTMOS compatibility headers.
- Added application and kernel execution profiles (`JTMOS_APPLICATION`, `JTMOS_KERNEL32`).
- Application syscalls use the established i386 `int 0x7f` ABI.
- Kernel libc calls a strong-overridable `jtmos_kernel_syscall7()` bridge instead of issuing the user interrupt.
- Added malloc/calloc/realloc/reallocarray, string/ctype, stdio/printf/scanf, file I/O, process/console, math, hardware compatibility and JTMOS service wrappers.
- Added `mmap()`/`munmap()` source compatibility with a private-allocation fallback where no VM syscall exists.
- Added a separate `crt0.o`; application startup retrieves argc/argv using JTMOS syscalls 17/18.
- Added `jtmos_elf32.ld` for fixed-address static ELF32 ET_EXEC applications at `0x80004000`.
- Added reusable `mk/jtmos-app.mk`, `make app`, header/link smoke tests and an apps.zip regression test script.
- Added a minimal patch for the unrelated duplicate-member error in apps.zip `msdos.h`.
