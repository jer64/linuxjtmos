# JTMOS GCC 2026 static ELF32 application profile
JTMOS_LIBC ?= ../libc
JTMOS_CC ?= gcc
JTMOS_LD ?= ld
JTMOS_APP_CFLAGS = -m32 -march=i486 -std=gnu89 -O2 -ffreestanding -fno-builtin \
  -fno-stack-protector -fno-pie -fno-pic -fno-unwind-tables \
  -fno-asynchronous-unwind-tables -nostdinc \
  -Ulinux -U__linux -U__linux__ \
  -DJTMOS=1 -DJTMOS_APPLICATION=1 -DJTMOS_LEGACY_SOURCE=1 -DCPU=i486 \
  -I$(JTMOS_LIBC)/include
JTMOS_APP_LDFLAGS = -m elf_i386 -static -T $(JTMOS_LIBC)/jtmos_elf32.ld
JTMOS_CRT0 = $(JTMOS_LIBC)/build/application/crt0.o
JTMOS_LIB = $(JTMOS_LIBC)/libcjtmos.a
