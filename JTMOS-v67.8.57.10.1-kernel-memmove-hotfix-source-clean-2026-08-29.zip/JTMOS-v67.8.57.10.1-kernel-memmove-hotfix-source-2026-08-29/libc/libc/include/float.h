#ifndef _JTMOS_FLOAT_H
#define _JTMOS_FLOAT_H
#define FLT_RADIX __FLT_RADIX__
#define FLT_MANT_DIG __FLT_MANT_DIG__
#define DBL_MANT_DIG __DBL_MANT_DIG__
#define FLT_DIG __FLT_DIG__
#define DBL_DIG __DBL_DIG__
#define FLT_MIN __FLT_MIN__
#define FLT_MAX __FLT_MAX__
#define DBL_MIN __DBL_MIN__
#define DBL_MAX __DBL_MAX__
#define FLT_EPSILON __FLT_EPSILON__
#define DBL_EPSILON __DBL_EPSILON__
#endif
