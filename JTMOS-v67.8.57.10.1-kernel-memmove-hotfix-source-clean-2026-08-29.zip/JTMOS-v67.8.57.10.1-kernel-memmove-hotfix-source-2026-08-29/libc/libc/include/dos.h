#ifndef _JTMOS_DOS_H
#define _JTMOS_DOS_H
#include <jtmos/types.h>
#define far
#define near
#define interrupt
#define _DISK_READ 2
#define _DISK_WRITE 3
#define MK_FP(seg,ofs) ((void *)(uintptr_t)((((uint32_t)(seg))<<4)+(uint16_t)(ofs)))
int inp(unsigned); int outp(unsigned,int); unsigned char inportb(unsigned); void outportb(unsigned,unsigned char); unsigned short inportw(unsigned); void outportw(unsigned,unsigned short); void delay(unsigned); void *getvect(int); void setvect(int,void*); int biosdisk(int,int,int,int,int,int,void*);
#endif
