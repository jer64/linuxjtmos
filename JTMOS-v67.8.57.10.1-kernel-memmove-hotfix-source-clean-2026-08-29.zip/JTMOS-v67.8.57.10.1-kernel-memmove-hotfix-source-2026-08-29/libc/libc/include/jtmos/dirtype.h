#ifndef _JTMOS_DIRTYPE_H
#define _JTMOS_DIRTYPE_H

/*
 * JTMFS on-disk entry classification.
 *
 * The low six bits are attributes and the high two bits of the low byte are
 * the entry class.  This preserves the historical on-disk ABI while allowing
 * attributes to be combined with files/directories safely.
 */
#define JTMFS_ATTR_READONLY      0x01U
#define JTMFS_ATTR_SYSTEM        0x02U
#define JTMFS_ATTR_DEVICE        0x04U
#define JTMFS_ATTR_ARCHIVE       0x08U
#define JTMFS_ATTR_EXECUTABLE    0x10U
#define JTMFS_ATTR_HIDDEN        0x20U
#define JTMFS_ATTR_MASK          0x3FU

#define JTMFS_CLASS_FILE         0x00U
#define JTMFS_CLASS_DIRNAME      0x40U  /* internal directory-name metadata */
#define JTMFS_CLASS_DIRECTORY    0x80U
#define JTMFS_CLASS_RESERVED     0xC0U
#define JTMFS_CLASS_MASK         0xC0U
#define JTMFS_TYPE_KNOWN_MASK    0xFFU

#define JTMFS_TYPE_CLASS(t) \
    ((unsigned int)(t) & JTMFS_CLASS_MASK)
#define JTMFS_TYPE_ATTRS(t) \
    ((unsigned int)(t) & JTMFS_ATTR_MASK)
#define JTMFS_TYPE_UNKNOWN_BITS(t) \
    ((unsigned int)(t) & ~JTMFS_TYPE_KNOWN_MASK)
#define JTMFS_TYPE_BUILD(c,a) \
    (((unsigned int)(c) & JTMFS_CLASS_MASK) | \
     ((unsigned int)(a) & JTMFS_ATTR_MASK))

#define JTMFS_TYPE_IS_FILE(t) \
    (JTMFS_TYPE_CLASS(t) == JTMFS_CLASS_FILE)
#define JTMFS_TYPE_IS_DIRNAME(t) \
    (JTMFS_TYPE_CLASS(t) == JTMFS_CLASS_DIRNAME)
#define JTMFS_TYPE_IS_DIRECTORY(t) \
    (JTMFS_TYPE_CLASS(t) == JTMFS_CLASS_DIRECTORY)
#define JTMFS_TYPE_IS_RESERVED(t) \
    (JTMFS_TYPE_CLASS(t) == JTMFS_CLASS_RESERVED)
#define JTMFS_TYPE_HAS_ATTR(t,a) \
    ((((unsigned int)(t)) & ((unsigned int)(a) & JTMFS_ATTR_MASK)) != 0U)
#define JTMFS_TYPE_IS_VALID(t) \
    (JTMFS_TYPE_UNKNOWN_BITS(t) == 0U && !JTMFS_TYPE_IS_RESERVED(t))

/* Historical public names.  Keep these values stable for old disks/apps. */
#define JTMFS_ID_READONLY       JTMFS_ATTR_READONLY
/* WRITEONLY was the historical spelling of bit 0x01.  The DOS compatibility
 * layer and old UI code use it as READONLY, so retain it only as an alias. */
#define JTMFS_ID_WRITEONLY      JTMFS_ATTR_READONLY
#define JTMFS_ID_SYSTEM         JTMFS_ATTR_SYSTEM
#define JTMFS_ID_DEVICE         JTMFS_ATTR_DEVICE
#define JTMFS_ID_ARCHIVE        JTMFS_ATTR_ARCHIVE
#define JTMFS_ID_EXECUTABLE     JTMFS_ATTR_EXECUTABLE
#define JTMFS_ID_HIDDEN         JTMFS_ATTR_HIDDEN
#define JTMFS_ID_FILE           JTMFS_CLASS_FILE
#define JTMFS_ID_DIRNAME        JTMFS_CLASS_DIRNAME
#define JTMFS_ID_DIRECTORY      JTMFS_CLASS_DIRECTORY

#endif
