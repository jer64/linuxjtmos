#ifndef _JTMOS_IRQ_H
#define _JTMOS_IRQ_H
#include <stdint.h>

#define JTMOS_IRQ_WAIT_FOREVER 0xffffffffUL

/* Subscribe to a free PC IRQ line (0..15). IRQ0 and IRQ2 are reserved.
 * The returned handle belongs to the calling process. No application code is
 * ever invoked in hardware interrupt context. */
int jtmos_irq_subscribe(int irq, unsigned long flags);
int jtmos_irq_unsubscribe(unsigned long handle);
/* 0 = timeout/no event, >0 = event consumed (value includes queued depth), <0 error. */
int jtmos_irq_wait(unsigned long handle, unsigned long timeout_ms);
static inline int jtmos_irq_poll(unsigned long handle)
{
    return jtmos_irq_wait(handle,0);
}
#endif
