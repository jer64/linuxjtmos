#ifndef _JTMOS_DPI_H
#define _JTMOS_DPI_H
int getdevicename(int dnr, char *name);
int getdevicenrbyname(const char *name);
int getdevnrbyname(const char *name);
#endif
