#ifndef _JTMOS_DIRECTDISK_H
#define _JTMOS_DIRECTDISK_H
#include <jtmos/types.h>
int getdevnrbyname(const char*); int getdevicenrbyname(const char*); int readblock(int,DWORD,void*); int writeblock(int,DWORD,const void*); int readblocks(int,DWORD,void*,int); int writeblocks(int,DWORD,const void*,int); int diskChange(int); int formatDrive(const char*);
#endif
