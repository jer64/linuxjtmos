#ifndef _JTMOS_CONFIG_H
#define _JTMOS_CONFIG_H
#if defined(JTMOS_KERNEL32) && defined(JTMOS_APPLICATION)
#error "select only one JTMOS execution mode"
#endif
#if !defined(JTMOS_KERNEL32) && !defined(JTMOS_APPLICATION)
#define JTMOS_APPLICATION 1
#endif

#define JTMOS_LIBC_VERSION 0x02060822UL
#define JTMOS_LIBC_VERSION_STRING "JTMOS libc userspace 2026.08.22"

/* ELF32 application virtual layout shared with kernel32/core/cp/LaunchApp.h. */
#define JTMOS_USER_BASE       0x80000000UL
#define JTMOS_USER_SIZE       (16UL * 1024UL * 1024UL)
#define JTMOS_PAGE_SIZE       4096UL
#define JTMOS_APP_STACK_SIZE  (256UL * 1024UL)
#define JTMOS_APP_GUARD_SIZE  JTMOS_PAGE_SIZE
#define JTMOS_HEAP_ALIGNMENT  16UL

#endif
