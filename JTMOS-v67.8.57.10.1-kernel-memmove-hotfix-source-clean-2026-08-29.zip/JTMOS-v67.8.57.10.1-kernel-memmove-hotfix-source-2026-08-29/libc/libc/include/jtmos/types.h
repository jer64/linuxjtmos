#ifndef _JTMOS_TYPES_H
#define _JTMOS_TYPES_H
#include <stdint.h>
#include <stddef.h>

/* JTMOS is an i386/ILP32 ABI. Keep historical spellings source-compatible. */
typedef unsigned char jtmos_BYTE;
typedef unsigned short jtmos_WORD;
typedef unsigned long jtmos_DWORD;
typedef int BOOL;

#ifndef BYTE
#define BYTE jtmos_BYTE
#endif
#ifndef WORD
#define WORD jtmos_WORD
#endif
#ifndef DWORD
#define DWORD jtmos_DWORD
#endif

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201112L
_Static_assert(sizeof(BYTE) == 1, "JTMOS BYTE must be 8 bits");
_Static_assert(sizeof(WORD) == 2, "JTMOS WORD must be 16 bits");
_Static_assert(sizeof(DWORD) == 4, "JTMOS DWORD must be 32 bits");
#endif

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif
#endif
