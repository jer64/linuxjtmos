#ifndef _JTMOS_TURBOC_H
#define _JTMOS_TURBOC_H
#include <conio.h>
#include <dos.h>
#include <stdlib.h>
/* Borland/Turbo C compatibility helpers. Console coordinates are 1-based. */
#ifndef random
#define random(n) ((n)>0 ? (rand()%(n)) : 0)
#endif
void randomize(void);
int kbhit(void);
int getche(void);
void delline(void);
void insline(void);
void clreol(void);
int puttext(int left,int top,int right,int bottom,void *source);
int gettext(int left,int top,int right,int bottom,void *dest);
#endif
