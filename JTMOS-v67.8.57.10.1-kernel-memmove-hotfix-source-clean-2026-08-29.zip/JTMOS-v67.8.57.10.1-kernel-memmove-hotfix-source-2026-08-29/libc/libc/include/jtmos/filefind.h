#ifndef _JTMOS_FILEFIND_H
#define _JTMOS_FILEFIND_H

#include <jtmos/types.h>
#include <jtmos/dirtype.h>
#include <stddef.h>

/*
 * SYS_findfirst / SYS_findnext ABI structure.
 *
 * This layout is shared with kernel32/fs/jtmfs/fsdos.h.  Do not reorder or
 * shrink it: the kernel copies these fields directly to userspace.
 * Historical modern-libc snapshots accidentally used
 *     { char ff_name[256]; int ff_fsize; int ff_attrib; }
 * which made ff_name point at the kernel's reserved bytes and made the
 * kernel write 32 bytes past the userspace object.
 */
typedef struct
{
    DWORD _ff_reserved[5];
    DWORD ff_attrib;
    DWORD ff_ftime;
    DWORD ff_fdate;
    DWORD ff_fsize;
    char  ff_name[260];
} FFBLK;

typedef FFBLK FILEFIND;

/* Valid in both the gnu89 application build and the gnu17 libc build. */
typedef char jtmos_ffblk_size_must_be_296[(sizeof(FFBLK) == 296) ? 1 : -1];
typedef char jtmos_ffblk_name_offset_must_be_36[(offsetof(FFBLK, ff_name) == 36) ? 1 : -1];

int findfirst(const char *path, FFBLK *ff);
int findnext(int fd, FFBLK *ff);

#endif
