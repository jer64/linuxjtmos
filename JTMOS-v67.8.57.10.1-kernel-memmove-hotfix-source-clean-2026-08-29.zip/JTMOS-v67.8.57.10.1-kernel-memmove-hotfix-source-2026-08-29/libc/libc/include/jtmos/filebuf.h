#ifndef _JTMOS_FILEBUF_SYSCALL_H
#define _JTMOS_FILEBUF_SYSCALL_H
#include <stddef.h>
#include <sys/types.h>
ssize_t __jtmos_filebuf_read(int fd, void *buf, size_t count);
ssize_t __jtmos_filebuf_write(int fd, const void *buf, size_t count);
int __jtmos_filebuf_flush(int fd);
int __jtmos_filebuf_set(int fd, int mode, size_t size);
off_t __jtmos_filebuf_seek(int fd, off_t offset, int whence);
off_t __jtmos_filebuf_tell(int fd);
#endif
