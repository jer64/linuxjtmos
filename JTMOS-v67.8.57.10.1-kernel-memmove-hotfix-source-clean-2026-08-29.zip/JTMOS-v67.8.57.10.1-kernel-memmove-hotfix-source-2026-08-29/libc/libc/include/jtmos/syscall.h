#ifndef _JTMOS_SYSCALL_H
#define _JTMOS_SYSCALL_H
#include <jtmos/types.h>
#include <jtmos/config.h>
long jtmos_syscall7(DWORD eax, uintptr_t ebx, uintptr_t ecx, uintptr_t edx,
                    uintptr_t esi, uintptr_t edi, uintptr_t ebp);
/* Legacy ABI name retained. */
static inline DWORD scall(DWORD eax,DWORD ebx,DWORD ecx,DWORD edx,DWORD esi,DWORD edi,DWORD ebp) {
    return (DWORD)jtmos_syscall7(eax, ebx, ecx, edx, esi, edi, ebp);
}
#ifdef JTMOS_KERNEL32
/* Kernel supplies a strong version. The libc weak fallback returns -ENOSYS. */
long jtmos_kernel_syscall7(DWORD eax, uintptr_t ebx, uintptr_t ecx, uintptr_t edx,
                           uintptr_t esi, uintptr_t edi, uintptr_t ebp);
#endif
#endif
