#ifndef _JTMOS_NETWORK_H
#define _JTMOS_NETWORK_H
#include <jtmos/types.h>
#define IP_PROTO_ICMP 1
#define IP_PROTO_TCP 6
#define IP_PROTO_UDP 17
typedef struct __attribute__((packed)) { unsigned ihl:4,version:4; BYTE tos; WORD len; WORD ipid; WORD ipoffset; BYTE ttl; BYTE proto; WORD chksum; DWORD srcip; DWORD dstip; } IPHDR;
typedef struct __attribute__((packed)) { WORD srcport,dstport; DWORD seqno,ackno; unsigned reserved:4,doff:4; unsigned fin:1,syn:1,rst:1,psh:1,ack:1,urg:1,ece:1,cwr:1; WORD window,chksum,urgp; } TCPHDR;
int opensocket(unsigned long,int); int closesocket(int); int readsocket(int,void*,int); int writesocket(int,const void*,int);
int OpenSocket(DWORD,int); int CloseSocket(int); int ReadSocket(int,BYTE*); int WriteSocket(int,BYTE*,int); int ReceiveRawPacket(int,BYTE*); int TransmitRawPacket(int,BYTE*,int); int htons(int);
#define ntohs(x) htons(x)
#endif
