#ifndef _JTMOS_FILE_H
#define _JTMOS_FILE_H
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
int fexist(const char*); int fsizeof(const char*);
#endif
