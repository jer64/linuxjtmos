#ifndef _JTMOS_CONSOLE_H
#define _JTMOS_CONSOLE_H
#include <jtmos/types.h>
#define BLACK 0
#define BLUE 1
#define GREEN 2
#define CYAN 3
#define RED 4
#define MAGENTA 5
#define BROWN 6
#define LIGHTGRAY 7
#define DARKGRAY 8
#define LIGHTBLUE 9
#define LIGHTGREEN 10
#define LIGHTCYAN 11
#define LIGHTRED 12
#define LIGHTMAGENTA 13
#define YELLOW 14
#define WHITE 15
#define _NOCURSOR 0
#define _NORMALCURSOR 1
#define _SOLIDCURSOR 2
#define JKEY_BACKSPACE 8
#define JKEY_ESC 27
#define JKEY_CURSOR_UP 0x4800
#define JKEY_CURSOR_DOWN 0x5000
#define JKEY_CURSOR_LEFT 0x4b00
#define JKEY_CURSOR_RIGHT 0x4d00
#define JKEY_HOME 0x4700
#define JKEY_END 0x4f00
#define JKEY_PAGE_UP 0x4900
#define JKEY_PAGE_DOWN 0x5100
#define JKEY_INSERT 0x5200
#define JKEY_DELETE 0x5300
#define JKEY_F1 0x3b00
#define JKEY_F2 0x3c00
#define JKEY_F3 0x3d00
#define JKEY_F4 0x3e00
#define JKEY_F5 0x3f00
#define JKEY_F6 0x4000
#define JKEY_F7 0x4100
#define JKEY_F8 0x4200
#define JKEY_F9 0x4300
#define JKEY_F10 0x4400
struct text_info { BYTE winleft,wintop,winright,winbottom,attribute,normattr,currmode,screenheight,screenwidth,curx,cury; };
void gettextinfo(struct text_info*);
void textcolor(int);
void textbackground(int);
int wherex(void);
int wherey(void);
void gotoxy(int,int);
int window(int,int,int,int);
void clrscr(void);
int getch(void);
int getch1(void);
int wgetch(void);
int putch(int);
int cprintf(const char*,...);
#ifdef JTMOS_LEGACY_SOURCE
int print();
#else
int print(const char*);
#endif
void StretchPrint(const char*,int);
int getctrl(void);
int getalt(void);
int GetCTRL(void);
int GetALT(void);
void _setcursortype(int);
void DrawAnsiWindow(int,int,int,int,int,char*,int);
#endif
