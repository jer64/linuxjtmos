#ifndef _JTMOS_DMA_H
#define _JTMOS_DMA_H
#include <stddef.h>
#include <stdint.h>

#define JTMOS_DMA_MAX_BYTES   65536UL
#define JTMOS_DMA_FROM_DEVICE 0
#define JTMOS_DMA_TO_DEVICE   1

typedef struct jtmos_dma_buffer {
    unsigned long handle;
    void *address;
    unsigned long physical_address;
    unsigned long size;
} jtmos_dma_buffer;

/* V65 first-generation ISA DMA service. The allocation is physically
 * contiguous, below 16 MiB and does not cross a 64 KiB 8237 boundary.
 * Channels 0..3 are supported; channel 4 is the cascade channel. */
int jtmos_dma_alloc(size_t bytes, unsigned long flags, jtmos_dma_buffer *out);
int jtmos_dma_free(unsigned long handle);
int jtmos_dma_program(unsigned long handle, int channel, size_t length, int direction);
int jtmos_dma_stop(unsigned long handle, int channel);
#endif
