#ifndef JTMOS_CPU_FEATURES_H
#define JTMOS_CPU_FEATURES_H
#include <stdint.h>
#define JTMOS_CPUF_CPUID       0x00000001UL
#define JTMOS_CPUF_FPU         0x00000002UL
#define JTMOS_CPUF_FXSR        0x00000004UL
#define JTMOS_CPUF_SSE         0x00000008UL
#define JTMOS_CPUF_SSE2        0x00000010UL
#define JTMOS_CPUF_SSE3        0x00000020UL
#define JTMOS_CPUF_SSE_OS      0x00000040UL
#define JTMOS_CPUF_SSE3_ACCEL  0x00000080UL
unsigned long jtmos_cpu_features(void);
int jtmos_cpu_has(unsigned long feature_mask);
#endif
