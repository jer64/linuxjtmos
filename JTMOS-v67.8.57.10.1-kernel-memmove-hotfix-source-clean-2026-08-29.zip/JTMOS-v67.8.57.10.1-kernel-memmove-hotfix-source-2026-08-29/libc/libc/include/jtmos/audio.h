#ifndef _JTMOS_AUDIO_H
#define _JTMOS_AUDIO_H
#include <jtmos/types.h>

#define AUDIO_FORMAT_U8_MONO 0
#define AUDIO_BACKEND_AUTO 0
#define AUDIO_BACKEND_SB   1
#define AUDIO_BACKEND_GUS  2

typedef struct {
    DWORD size;
    DWORD backend;
    DWORD initialized;
    DWORD playing;
    DWORD sample_rate;
    DWORD format;
    DWORD queued_bytes;
    DWORD active_bytes;
    DWORD played_bytes;
    DWORD underruns;
} JTMOS_AUDIO_INFO;

int AudioInit(void);
int AudioSelectBackend(int backend);
int AudioWrite(const void *audioBuf, int audioLength, int audioType, int audioFreq);
int AudioStop(void);
int AudioGetInfo(JTMOS_AUDIO_INFO *info);
void InitAudio(void);
DWORD GetAudioPosition(void);
void SendAudio(const void *audioBuf, int audioLength, int audioType, int audioFreq);

#endif
