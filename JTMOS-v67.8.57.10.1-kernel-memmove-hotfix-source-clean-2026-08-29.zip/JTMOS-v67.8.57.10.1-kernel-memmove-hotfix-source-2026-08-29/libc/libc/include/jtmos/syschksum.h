#ifndef _JTMOS_SYSCHKSUM_H
#define _JTMOS_SYSCHKSUM_H
#include <jtmos/types.h>
DWORD syschksum(const void *buffer,int length);
#endif
