#ifndef _JTMOS_GRAOS_H
#define _JTMOS_GRAOS_H
#include <jtmos/types.h>
#include <jtmos/msgbox.h>
#include <jtmos/graosprotocol.h>
#define GRAOS_SERVER_PID_NAME "guiserver"
typedef DWORD GRAOS_PIXEL;
#define GRAOS_RGBA(r,g,b,a) ((GRAOS_PIXEL)(((DWORD)((r)&255))|((DWORD)((g)&255)<<8)|((DWORD)((b)&255)<<16)|((DWORD)((a)&255)<<24)))
#define GRAOS_RGB(r,g,b) GRAOS_RGBA((r),(g),(b),255)
#define GRAOS_BPP 32

/* Legacy MCGA/VGA colour-index compatibility on the RGBA32 renderer. */
GRAOS_PIXEL JtmosMCGAColorToRGBA(int color);
GRAOS_PIXEL JtmosMCGAColorToBGRX(int color);

int getGraosPID(void);
int connectGraos(void);
int waitGraosAnswer(void);
int createWindow(int,int,int,int,const char*,...);
int closeWindow(int);
int refreshWindow(int);
int addFrameBuffer(int,void*,...);
int createButton(int,int,int,int,int,int,const char*);
int createLabel(int,int,int,int,int,int,int,int,int,const char*);
int setLabelText(int,int,const char*);
int setLabelStyle(int,int,int,int,int);
int removeLabel(int,int);
int createBitmap(int,int,int,int,int,int,const GRAOS_PIXEL*,int);
int setBitmapData(int,int,const GRAOS_PIXEL*,int);
int removeBitmap(int,int);
int createTextBox(int,int,int,int,int,int,int,const char*);
int setTextBoxText(int,int,const char*);
int getTextBoxText(int,int,char*,int);
int removeTextBox(int,int);
int JtmosGraOSPollEvent(int,GUICMD*);
int JtmosGraOSSetGray16Palette(void);
int CreateTerminal(void);
int JtmosGraOSFreeTerminal(int);
int JtmosGraOSPing(void);
int JtmosGraOSGetStats(int *windows,int *terminals,int *focus,unsigned long *frames);
int JtmosGraOSGetScreenInfo(int *width,int *height,int *bpp,int *panel_height);
int JtmosGraOSGetScreenSize(int *width,int *height);
int JtmosGraOSShutdown(void);
int JtmosGraOSSetDesktopColor(int color);
int JtmosGraOSSetPalette(int index,int r,int g,int b);
int JtmosGraOSRestorePalette(void);
int JtmosGraOSMinimizeWindow(int wid);
int JtmosGraOSRestoreWindow(int wid);
#endif
