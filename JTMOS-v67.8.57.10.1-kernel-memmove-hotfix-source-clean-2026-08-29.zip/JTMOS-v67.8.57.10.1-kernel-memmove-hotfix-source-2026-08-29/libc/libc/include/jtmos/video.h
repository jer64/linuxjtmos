#ifndef _JTMOS_VIDEO_H
#define _JTMOS_VIDEO_H
#include <jtmos/types.h>
int drawframe(const void *buf, ...); int drawframe1(const void *buf,...); void waitretrace(void); int setpalettemap(int offs,...); int setpalette(int which,int r,int g,int b); int setvmode(int); int setmode(int); int vgaselectplane(int);
#endif
