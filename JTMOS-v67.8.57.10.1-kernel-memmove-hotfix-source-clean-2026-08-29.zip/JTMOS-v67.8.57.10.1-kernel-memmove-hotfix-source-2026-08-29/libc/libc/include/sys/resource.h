#ifndef _JTMOS_SYS_RESOURCE_H
#define _JTMOS_SYS_RESOURCE_H
#include <sys/types.h>
#define PRIO_PROCESS 0
int getpriority(int which, id_t who);
int setpriority(int which, id_t who, int prio);
#endif
