#ifndef _JTMOS_SYS_STAT_H
#define _JTMOS_SYS_STAT_H
#include <sys/types.h>

struct stat {
    unsigned long st_size;
    unsigned long st_mode;
    unsigned long st_mtime;
    unsigned long st_reserved[8];
};

/* POSIX-compatible file type bits used by JTMOS SYS_stat. */
#define S_IFMT   00170000
#define S_IFSOCK 0140000
#define S_IFLNK  0120000
#define S_IFREG  0100000
#define S_IFBLK  0060000
#define S_IFDIR  0040000
#define S_IFCHR  0020000
#define S_IFIFO  0010000
#define S_ISLNK(m)  (((m) & S_IFMT) == S_IFLNK)
#define S_ISREG(m)  (((m) & S_IFMT) == S_IFREG)
#define S_ISDIR(m)  (((m) & S_IFMT) == S_IFDIR)
#define S_ISCHR(m)  (((m) & S_IFMT) == S_IFCHR)
#define S_ISBLK(m)  (((m) & S_IFMT) == S_IFBLK)
#define S_ISFIFO(m) (((m) & S_IFMT) == S_IFIFO)
#define S_ISSOCK(m) (((m) & S_IFMT) == S_IFSOCK)

int stat(const char*,struct stat*);
int fstat(int,struct stat*);
int mkdir(const char*, mode_t);
#endif
