#ifndef _JTMOS_STDINT_H
#define _JTMOS_STDINT_H
typedef signed char int8_t; typedef unsigned char uint8_t;
typedef short int16_t; typedef unsigned short uint16_t;
typedef int int32_t; typedef unsigned int uint32_t;
typedef long long int64_t; typedef unsigned long long uint64_t;
typedef int intptr_t; typedef unsigned int uintptr_t;
typedef int32_t int_fast32_t; typedef uint32_t uint_fast32_t;
#define INT8_MIN (-128) 
#define INT8_MAX 127
#define UINT8_MAX 255U
#define INT16_MIN (-32767-1)
#define INT16_MAX 32767
#define UINT16_MAX 65535U
#define INT32_MIN (-2147483647-1)
#define INT32_MAX 2147483647
#define UINT32_MAX 4294967295U
#define INT64_MAX 9223372036854775807LL
#define UINT64_MAX 18446744073709551615ULL
#define UINTPTR_MAX UINT32_MAX
#endif
