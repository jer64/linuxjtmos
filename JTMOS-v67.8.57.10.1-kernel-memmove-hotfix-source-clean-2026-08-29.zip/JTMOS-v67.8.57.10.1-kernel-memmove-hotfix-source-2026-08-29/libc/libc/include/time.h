#ifndef _JTMOS_TIME_H
#define _JTMOS_TIME_H
#include <sys/types.h>
typedef unsigned long clock_t;
struct tm { int tm_sec,tm_min,tm_hour,tm_mday,tm_mon,tm_year,tm_wday,tm_yday,tm_isdst; };
#define CLOCKS_PER_SEC 1000UL
clock_t clock(void); time_t time(time_t*);
#endif
