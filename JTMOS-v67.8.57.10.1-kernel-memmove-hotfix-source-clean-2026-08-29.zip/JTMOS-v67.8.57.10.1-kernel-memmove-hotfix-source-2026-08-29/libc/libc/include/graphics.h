#ifndef _JTMOS_GRAPHICS_H
#define _JTMOS_GRAPHICS_H
#define DETECT 0
#define CGA 1
#define MCGA 2
#define EGA 3
#define EGA64 4
#define EGAMONO 5
#define IBM8514 6
#define HERCMONO 7
#define ATT400 8
#define VGA 9
#define PC3270 10
#define VGAHI 2
#define grOk 0
#define grNoInitGraph -1
#define grNotDetected -2
#define grInvalidMode -3
#define SOLID_FILL 1
#define EMPTY_FILL 0
#define NORM_WIDTH 1
#define THICK_WIDTH 3
#define SOLID_LINE 0
#define DOTTED_LINE 1
#define CENTER_TEXT 1
#define LEFT_TEXT 0
#define RIGHT_TEXT 2
#define TOP_TEXT 2
#define BOTTOM_TEXT 0
#define HORIZ_DIR 0
#define VERT_DIR 1
#ifndef BLACK
#define BLACK 0
#define BLUE 1
#define GREEN 2
#define CYAN 3
#define RED 4
#define MAGENTA 5
#define BROWN 6
#define LIGHTGRAY 7
#define DARKGRAY 8
#define LIGHTBLUE 9
#define LIGHTGREEN 10
#define LIGHTCYAN 11
#define LIGHTRED 12
#define LIGHTMAGENTA 13
#define YELLOW 14
#define WHITE 15
#endif
struct fillsettingstype { int pattern; int color; };
struct linesettingstype { int linestyle; unsigned upattern; int thickness; };
void initgraph(int*,int*,const char*);
void closegraph(void);
int jtmos_graph_getch(void);
int graphresult(void);
char *grapherrormsg(int);
int getmaxx(void); int getmaxy(void);
void setcolor(int); int getcolor(void); void setbkcolor(int); int getbkcolor(void);
void cleardevice(void); void clearviewport(void);
void putpixel(int,int,int); int getpixel(int,int);
void moveto(int,int); void moverel(int,int); int getx(void); int gety(void);
void line(int,int,int,int); void lineto(int,int); void linerel(int,int);
void rectangle(int,int,int,int); void bar(int,int,int,int); void bar3d(int,int,int,int,int,int);
void circle(int,int,int); void ellipse(int,int,int,int,int,int); void arc(int,int,int,int,int);
void pieslice(int,int,int,int,int); void sector(int,int,int,int,int,int);
void setfillstyle(int,int); void getfillsettings(struct fillsettingstype*);
void setlinestyle(int,unsigned,int); void getlinesettings(struct linesettingstype*);
void floodfill(int,int,int);
void outtextxy(int,int,const char*); void outtext(const char*);
int textwidth(const char*); int textheight(const char*);
void settextjustify(int,int); void settextstyle(int,int,int);
void setviewport(int,int,int,int,int); void getviewsettings(void*);
void graphdefaults(void);
#endif
