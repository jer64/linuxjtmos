#ifndef _JTMOS_WINDOWS_H
#define _JTMOS_WINDOWS_H
#include <jtmos/types.h>
typedef void *HANDLE; typedef unsigned long DWORD_PTR; typedef int BOOL;
#define WINAPI
#endif
