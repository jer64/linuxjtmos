#ifndef _JTMOS_DPMI_H
#define _JTMOS_DPMI_H
/* DJGPP-facing compatibility subset for JTMOS V65.
 *
 * JTMOS is not a DOS/DPMI host. Functions whose DJGPP semantics would install
 * a userspace interrupt gate are intentionally rejected; use the safe JTMOS
 * IRQ event broker below. Lock calls succeed because JTMOS does not page ELF32
 * application code/data to disk. */
#include <stddef.h>
#include <jtmos/irq.h>
#include <jtmos/dma.h>

typedef struct _go32_dpmi_seginfo {
    unsigned long size;
    unsigned long address;
    unsigned long pm_offset;
    unsigned short pm_selector;
    unsigned short rm_segment;
    unsigned short rm_offset;
} _go32_dpmi_seginfo;

int _go32_dpmi_lock_code(void *address, unsigned long length);
int _go32_dpmi_lock_data(void *address, unsigned long length);
int _go32_dpmi_get_protected_mode_interrupt_vector(int vector, _go32_dpmi_seginfo *info);
int _go32_dpmi_set_protected_mode_interrupt_vector(int vector, _go32_dpmi_seginfo *info);
int _go32_dpmi_chain_protected_mode_interrupt_vector(int vector, _go32_dpmi_seginfo *info);
int _go32_dpmi_allocate_iret_wrapper(_go32_dpmi_seginfo *info);
int _go32_dpmi_free_iret_wrapper(_go32_dpmi_seginfo *info);

/* JTMOS safe equivalents for DJGPP-style hardware-driver ports. */
int _go32_dpmi_jtmos_irq_subscribe(int irq);
int _go32_dpmi_jtmos_irq_wait(int handle, unsigned long timeout_ms);
int _go32_dpmi_jtmos_irq_unsubscribe(int handle);
int _go32_dpmi_jtmos_dma_alloc(unsigned long bytes, jtmos_dma_buffer *out);
int _go32_dpmi_jtmos_dma_free(unsigned long handle);
#endif
