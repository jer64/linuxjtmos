#ifndef _JTMOS_GO32_H
#define _JTMOS_GO32_H
#include <dpmi.h>

/* DJGPP-compatible information block layout. JTMOS fills the PIC bases with
 * its protected-mode remap (0x68/0x70); DOS transfer-buffer fields are zero. */
typedef struct {
    unsigned long size_of_this_structure_in_bytes;
    unsigned long linear_address_of_primary_screen;
    unsigned long linear_address_of_secondary_screen;
    unsigned long linear_address_of_transfer_buffer;
    unsigned long size_of_transfer_buffer;
    unsigned long pid;
    unsigned char master_interrupt_controller_base;
    unsigned char slave_interrupt_controller_base;
    unsigned short selector_for_linear_memory;
    unsigned long linear_address_of_stub_info_structure;
    unsigned long linear_address_of_original_psp;
    unsigned short run_mode;
    unsigned short run_mode_info;
} Go32_Info_Block;
typedef Go32_Info_Block __Go32_Info_Block;

extern __Go32_Info_Block _go32_info_block;
#define _dos_ds   (_go32_info_block.selector_for_linear_memory)
#define __tb      (_go32_info_block.linear_address_of_transfer_buffer)
#define __tb_size (_go32_info_block.size_of_transfer_buffer)

#define _GO32_RUN_MODE_UNDEF 0
#define _GO32_RUN_MODE_RAW   1
#define _GO32_RUN_MODE_XMS   2
#define _GO32_RUN_MODE_VCPI  3
#define _GO32_RUN_MODE_DPMI  4

int _go32_my_cs(void);
int _go32_my_ds(void);
int _go32_my_ss(void);
int _go32_my_es(void);
#endif
