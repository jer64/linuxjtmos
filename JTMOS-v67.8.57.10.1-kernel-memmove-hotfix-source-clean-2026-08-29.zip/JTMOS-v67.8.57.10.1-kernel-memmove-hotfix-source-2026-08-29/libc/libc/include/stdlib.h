#ifndef _JTMOS_STDLIB_H
#define _JTMOS_STDLIB_H
#include <stddef.h>
#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1
#define RAND_MAX 32767
void *malloc(size_t); void free(void*); void *calloc(size_t,size_t); void *realloc(void*,size_t); void *reallocarray(void*,size_t,size_t);
int atoi(const char*); long atol(const char*); double atof(const char*); long strtol(const char*,char**,int); unsigned long strtoul(const char*,char**,int);
void qsort(void*,size_t,size_t,int (*)(const void*,const void*)); void *bsearch(const void*,const void*,size_t,size_t,int(*)(const void*,const void*));
void abort(void); void exit(int); int atexit(void (*)(void)); int system(const char*);
int abs(int); long labs(long); int rand(void); void srand(unsigned); long random(void); void srandom(unsigned); void randomize(void);
char *getenv(const char *); int setenv(const char *,const char *,int); int putenv(char *); int unsetenv(const char *);
#endif
