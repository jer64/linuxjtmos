#ifndef _JTMOS_MATH_H
#define _JTMOS_MATH_H
#define M_E 2.71828182845904523536
#define M_PI 3.14159265358979323846
#define M_PI_2 1.57079632679489661923
#define HUGE_VAL (__builtin_huge_val())
#define NAN (__builtin_nan(""))
double fabs(double); double floor(double); double ceil(double); double sqrt(double); double sin(double); double cos(double); double tan(double);
double atan(double); double asin(double); double acos(double); double exp(double); double log(double); double log10(double); double pow(double,double); double fmod(double,double); double modf(double,double*);
#endif
