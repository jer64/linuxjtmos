#ifndef _JTMOS_DJGPP_PC_H
#define _JTMOS_DJGPP_PC_H
#include <dos.h>
/* inp/outp/inportb/outportb/inportw/outportw are declared by dos.h.
 * No userspace cli/sti compatibility is provided: IRQ ownership belongs to
 * the V65 kernel broker so a driver cannot freeze the scheduler accidentally. */
#endif
