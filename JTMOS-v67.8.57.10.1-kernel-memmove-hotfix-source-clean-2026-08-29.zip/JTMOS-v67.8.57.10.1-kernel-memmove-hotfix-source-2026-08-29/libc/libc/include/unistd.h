#ifndef _JTMOS_UNISTD_H
#define _JTMOS_UNISTD_H
#include <sys/types.h>
#include <stdint.h>
#include <stddef.h>
int close(int); ssize_t read(int,void*,size_t); ssize_t write(int,const void*,size_t);
off_t lseek(int,off_t,int); int unlink(const char*); int link(const char*,const char*); int chdir(const char*); char *getcwd(char*,size_t);
unsigned sleep(unsigned); int usleep(useconds_t);
pid_t getpid(void); pid_t getppid(void);
pid_t fork(void);
int pipe(int fds[2]);
int dup2(int oldfd, int newfd);
int nice(int increment);
/* JTMOS/x86 extension: current CPU privilege ring (0..3). */
int getringlevel(void);
#define STDIN_FILENO 0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#endif

void *sbrk(intptr_t increment);
int brk(void *addr);
