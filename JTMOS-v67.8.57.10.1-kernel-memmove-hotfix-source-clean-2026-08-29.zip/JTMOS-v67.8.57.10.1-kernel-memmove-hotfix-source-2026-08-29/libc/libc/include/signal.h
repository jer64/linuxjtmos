#ifndef _JTMOS_SIGNAL_H
#define _JTMOS_SIGNAL_H
#include <sys/types.h>
typedef int sig_atomic_t;
typedef void (*sighandler_t)(int);
#define SIG_DFL ((sighandler_t)0)
#define SIG_IGN ((sighandler_t)1)
#define SIG_ERR ((sighandler_t)-1)
#define SIGHUP 1
#define SIGINT 2
#define SIGABRT 6
#define SIGKILL 9
#define SIGTERM 15
sighandler_t signal(int sig, sighandler_t handler);
int raise(int sig);
int kill(pid_t pid, int sig);
#endif
