Vunet / Altse mobile5 hotfix - 2026-08-21
===========================================

Changes:
- ViewArticle no longer uses ifbar2.pl.
- ViewArticle main 750/525/512 px table layout replaced with flex containers.
- Article body and sidebar stack automatically on narrow screens.
- MenuSystem*.pm contains no inline style="..." attributes.
- ViewArticle.pm, ViewArticleLib.pm and RenderArticle.pm contain no inline style="..." attributes.
- Menu major headings use wine red (#8a1c2b), normal menu uses slate blue (#243447).
- User-provided uutiset.css is the base; mobile5 layout classes are appended to it.
- Updated CSS is included both as cgi/uutiset.css and images/uutiset.css.
- CSS links use ?v=20260821-mobile5 to avoid stale mobile browser cache.

Deployment note:
The live templates request /images/uutiset.css, so deploy images/uutiset.css to that path.
