# Mobile29 – Suosittele / recommendation fix

- Fixed Top 20 recommendation buttons so they submit without reloading the Top page.
- Modern browsers use fetch() and show “Suositeltu” / “Suositeltu jo” feedback.
- No-JavaScript fallback posts into a hidden iframe.
- Rewrote cgi/imgathumb.pl as a small standalone UTF-8 CGI endpoint.
- Recommendation files are now written under DOCUMENT_ROOT/articles (with legacy fallbacks).
- Fixed old t1,IP duplicate detection and added file locking to prevent concurrent write loss.
- Missing Referer is accepted; explicitly foreign Referer values are rejected.
- Legacy image/GIF mode remains compatible with ViewArticle and older callers.
