# Vunet Mobile21 - NaytaUutisotsikot + ingress

Changes:
- Rebuilt NaytaUutisotsikot, NaytaUutisotsikotBlack and NaytaUutisotsikotBronze around one DIV/card renderer.
- Added compatibility wrappers NaytaUutisotsikotSilver and NaytaUutisotsikot2.
- Removed legacy emulated TABLE/TR/TD markup from NaytaUutisotsikot.pm.
- Replaced the old `i2 < 1000` loop with a bounded backwards scan that never runs below array index 0.
- Removed `skipped ...` debug output from rendered HTML/stdout.
- Preserved old section URLs and public function signatures.
- Increased article ingress typography and replaced invalid H2/DIV/FONT nesting in RenderArticle with one `.ingressi` block.
- Updated all HTML template CSS cache keys to `20260822-mobile21`.
