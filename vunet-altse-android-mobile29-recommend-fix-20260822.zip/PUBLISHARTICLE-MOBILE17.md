# PublishArticle Mobile17

- Restored section loading based on the legacy `$DB/cfg/seclst.txt` behavior.
- Added fallbacks for CGI working-directory differences.
- The exact legacy section set is retained as a final fallback.
- Replaced TABLE/TR/TD publishing-form layout with responsive semantic markup.
- Preserved `/cgi/publish.pl` and the legacy POST field names.
- Added mobile publishing-form styles to `images/uutiset.css`.
- `webindex2.html` now requests the `mobile17` CSS version.
