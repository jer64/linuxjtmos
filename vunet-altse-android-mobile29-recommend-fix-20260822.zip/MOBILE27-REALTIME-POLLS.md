# Vunet Mobile27 – realtime poll embeds

Mobile27 adds two compatible ways to embed the existing `poll.pl` voting system
without reloading the host article page.

## 1. JavaScript poll (`cgi/jspoll.pl`) – preferred

The simplest JavaScript-only embed is:

```html
<script src="/cgi/jspoll.pl?POLL=29"></script>
```

`jspoll.pl` creates a compact poll at the script location, loads the poll form
from `/poll.pl` with `fetch()`, posts the vote asynchronously and replaces only
the poll component. After results are shown, they refresh every 15 seconds.

For progressive enhancement, use an explicit `data-vn-js-poll` container and a
`<noscript>` iframe fallback. `PollEmbedHTML()` in `PollSystem.pm` creates this
form automatically and is what ViewArticle uses.

## 2. iframe poll (`cgi/ifpoll.pl`) – fallback / standalone embed

```html
<iframe class="vn-ifpoll-frame"
        src="/cgi/ifpoll.pl?POLL=29"
        title="Vunet.net – Äänestys"
        loading="lazy"></iframe>
```

The form submits inside the iframe, so the parent page is not reloaded. Results
refresh every 15 seconds. When JavaScript is available, the iframe also reports
its content height to the parent with `postMessage()`.

## ViewArticle integration

`ViewArticleLib.pm::ViewVoteForm()` now calls `PollEmbedHTML()`. `ViewArticle.pm`
prints the component directly into the article sidebar. The old commented
`Javascript:NaytaAanestys()` widget has been removed.

The JavaScript poll is preferred because it avoids iframe focus/scroll quirks
and integrates naturally with the article. `ifpoll.pl` is intentionally kept as
a no-JavaScript fallback and as a simple reusable iframe endpoint.

All new Perl files use `use utf8;` and output UTF-8.
