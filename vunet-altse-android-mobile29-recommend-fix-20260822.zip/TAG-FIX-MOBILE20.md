# Mobile20: stale article tag leak fix

`ParseOptions()` now clears the article-scoped `tags` field before reading each
`*_options.txt` file. This prevents a manual tag from a previous article (for
example `Nato`) from appearing on every following news card.

No URL format or tag URL was changed. `/q/Nato/` and the other legacy tag URLs
remain unchanged when the tag genuinely belongs to the article.
