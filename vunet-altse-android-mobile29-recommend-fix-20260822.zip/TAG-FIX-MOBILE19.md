# Vunet Mobile19 – news tag fix

- DetectCountries.pm deduplicates tags across cfg/maat.txt and cfg/talous.txt.
- @gl_tags is scoped to the current article detection pass.
- nw/ViewHL and top-pick views use a dedicated `.vn-news-tags` flex component.
- ViewTopPickFrom.pm no longer nests tag <a> elements inside the article <a>.
- tag :link/:visited colours are identical and high contrast.
- publisharticle.pl has an optional Tagit field.
- publish.pl normalizes/deduplicates manually entered tags and stores them in the article `_options.txt` as `tags=tag1|tag2|...`.
- ParseOptions clears stale tag state before loading another article.
- manually stored tags are merged with automatic country/economy detection.
- CSS cache version: 20260822-mobile19.
