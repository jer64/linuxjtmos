VUNET MOBILE11 - DIV / FRONT PAGE / ARTICLE UPDATE
Date: 2026-08-21

Changes:
- Removed the Finnish front-page Uutissahkeet window from FinnishFP.pm.
- Converted TABLE/TR/TD layout tags to DIV markup throughout cgi/modules/*.pm.
  Generated layout DIVs use data-vn-table, data-vn-row and data-vn-cell.
- CSS layout is centralized in /images/uutiset.css (also mirrored as cgi/uutiset.css).
- Updated requested front pages: ChineseFP.pm, EnglishFP.pm, FinnishFP.pm,
  FinnishFP.pm~, FolkFP.pm, GoldenChinaTVFP.pm, _OldEnglishFP.pm,
  OldEnglishFP.pm, RussianFP.pm and SwedishFP.pm.
- Updated ViewArticle.pm, ViewArticleLib.pm, RenderArticle.pm,
  NaytaUutisotsikot.pm and ViewHL.pm to DIV layout.
- ViewArticle outer maximum remains 1200px, article card is max 820px,
  and readable article text measure is max 760px.
- Larger news headlines are defined in uutiset.css; MenuSystem sizing is untouched.
- Old front-page percentage/numeric cell proportions are interpreted by CSS on desktop;
  rows stack vertically on narrow screens.
- CSS cache key updated to 20260821-mobile11 in the front-page/index templates.
- nw.pl, viewarticle.pl and MenuSystem.pm routes/code were not rewritten in this pass.

Compatibility:
- Existing CGI/article URLs remain in use.
- Table-specific presentational attributes that remain on generated divs are harmless;
  actual layout is controlled by uutiset.css.
