# Vunet Mobile9 / WordPress-style ulkoasu — URL-yhteensopivuus

Mobile9 on ulkoasu- ja responsiivisuusuudistus. Se ei ole URL-migraatio.

Säilytettyjä vanhoja osoitemuotoja ovat muun muassa:

- `/nw/?FP_SECTION=finnish`
- `/nw/?FP_SECTION=finnish&section=kotimaa&maxts=4000`
- `/nw/?FP_SECTION=finnish&section=ulkomaat&maxts=4000`
- `/nw/?FP_SECTION=finnish&section=talous&maxts=4000`
- `/cgi/viewarticle.pl?article=<osasto>/<tiedosto>`
- `/kotimaa/`
- `/ulkomaat/`
- `/politiikka/`
- `/tiede/`
- `/kulttuuri/`
- `/talous/`
- `/top/`
- `/TopTen/`
- `/searchtop/`
- `/altse/`
- `/picks/`
- `/browserfeeds/`

`MenuSystem.pm`- ja `QuickNavMenu.pm`-osoitelistoihin ei ole tehty Mobile8 -> Mobile9 -muutoksessa URL-muutoksia.
`NiceArticleURL()`-osoitteet toimivat kuten ennen, ja vanha `/cgi/viewarticle.pl?article=...`-muoto säilyy lähdekoodissa yhteensopivana.

## Ulkoasumuutokset

- WordPress-henkinen vaalea sivutausta ja valkoiset sisältökortit.
- Etusivun pääjutut artikkelikortteina: kuva, otsikko, metadata ja ingressi.
- Sivupalkin sisältö widget-tyylisinä lohkoina.
- Yläpalkki säilyy vaakasuorana ja vanhoilla linkeillä.
- Pikavalikko on vaakasuunnassa vieritettävä kategoriapalkki.
- Yksittäinen artikkeli näyttää yhden jutun WordPress-tyyliseltä sisältösivulta.
- Etusivun ja ViewArticle-sivun X-suunnan maksimileveys säilyy 1200 px:nä.
- Androidilla kaikki sisältö flexaa käytettävissä olevaan leveyteen.
