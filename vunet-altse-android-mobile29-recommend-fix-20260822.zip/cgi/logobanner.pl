#!/usr/bin/perl
use utf8;
# logobanner.pl - for coolpages.tk content management system
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: image/jpeg\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

###########################################################################################################
#
sub main
{
	#
	if($so{'shadow'} eq "")
	{
		$so{'shadow'} = "blue";
	}
	if($so{'color'} eq "")
	{
		$so{'color'} = "white";
	}

	#
	$so{'t'} =~ s/_/ /g;
	$so{'face'} =~ s/[^0-9a-zA-ZäöåÄÖÅ \!\?\+\-\.]//g;
	$so{'t'} =~ s/[^0-9a-zA-ZäöåÄÖÅ \!\?\+\-\.]//g;
	$so{'sz'} =~ s/[^0-9]//g;
	if($so{'t'} ne "")
	{
		if($so{'sz'} > 200 || $so{'sz'} < 4) { $so{'sz'} = 48; }
		if($so{'face'} eq "") { $so{'face'} = "Times"; }
		$w = 1300;
		$h = 80;
		$dim = sprintf "%dx%d", $w, $h;
		$x = 20;
		$y = 50;
		$x2 = $x+($so{'sz'}/13);
		$y2 = $y+($so{'sz'}/13);
		system("convert -size $dim \\
-fill white \\
-font $so{'face'} -pointsize $so{'sz'} \\
-antialias \\
-blur 0x2 \\
-fill $so{'shadow'} -stroke $so{'shadow'} -annotate 0x0+$x2+$y2 \"$so{'t'}\" \\
-channel RGBA -blur 0x1 \\
-blur 0x0 -fill $so{'color'} -stroke $so{'color'}  -annotate 0x0+$x+$y \"$so{'t'}\" \\
-format jpg xc:black \\
/home/vai/altse/html/uutiset/white.gif jpg:-");
	}

	#
}


