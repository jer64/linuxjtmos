#!/usr/bin/perl
use utf8;
#
# SHOW A BRIEF VIEW OF NEWS FROM SELECTED SECTION
# jsbriefly.pl
# Called by jsheadlines at nw.pl.
#
################################################################################################################

#
use Socket;
use Net::DNS;
use Net::hostent;
use POSIX;
require "tools.pl";

#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

#
sub GenThumbHtml
{
        my (@art,$cap,$url,$urlcap,$f,$imgurl,$url,
                $str,$str2,$lim,$pm,$goo,$fn_counter,@ips,$score,
                $alt,$ifn,$i,$i2,@thu,@ips,$thumbs,
                $fn_thumbs,@lst);

        #
        $fn_thumbs = $_[0];
        $fn_thumbs =~ s/\.txt$/.txt_thumbs.txt/;
        if(-e $fn_thumbs) { @lst = LoadList("$fn_thumbs"); @thu = split(/\ /, $lst[0]); }
        for($thumbs="",$i=0; $i<($#thu+1); $i++)
        {
                $thumbs = ("$thumbs<IMG SRC=\"$IMAGES_BASE/thumb_up_c.gif\" border=0>");
        }

        #
        return $thumbs;
}

################################################################################
#
sub ViewHL
{
        my (@art,$cap,$url,$urlcap,$f,$imgurl,$url,
		$str,$str2,$lim,$pm,$goo,$fn_counter,@ips,$score,
		$alt,$ifn,$i,$i2,@thu,@ips,
		$first);

	#
	$first = $_[0];
	$first =~ s/\!\!$//;

	#
	$lim = $_[2];
	if($lim eq "") { $lim=500; }

	#
	$url = "/$first";
	$url = UrlFix($url);

        # If article text file exists...
	if(-e $first)
	{
		$fn_counter = $first;
		$fn_counter =~ s/\.txt$/.counter/;
		$fn_thumbs = $first;
		$fn_thumbs =~ s/\.txt$/.txt_thumbs.txt/;
		$fn_com = $first;
		$fn_com =~ s/\.txt$/.txt_comindex.txt/;
	        @art = LoadList("$first");
		@ips = ();
	        if(-e $fn_counter) { @ips = LoadList("$fn_counter"); }
		$thumbs = GenThumbHtml($first);
		@kom = ();
		$comments="";
		if(-e $fn_com)
		{
			@kom = LoadList($fn_com);
			$i = $#kom+1;
			if($i != 0)
			{
				if( $ENV{'NW_LANGUAGE'} eq "fi" )
				{
					$comments = "($i kommenttia)";
				}
				else
				{
					$comments = "($i comments)";
				}
			}
		}
	}
	else
	{
		return "";
	}

	#
	$score = sprintf "%d", ($#ips+1)/2;
	if($score>99) { $score="medal.gif"; $alt="very popular article"; }
	if($score>7 && $score<100) { $score="7_beyond"; $alt="popular article"; }
	if($score<0) { $score=0; $alt="article($score)"; }

	#
	$cap = $art[0];
        $cap =~ s/<br>//ig;
	if($cap eq "") { return ""; }
	$cap =~ s/(\S{20})/$1 /g;
	$cap =~ s/^(.{$lim}).*$/$1.../;
	if(length($cap)>160)
	{
		# TOO LONG TITLE!
		return "";
	}
#	$goo = Googler($cap);

	#
	ParseOptions("$first\_options.txt");

	#########################################################
	#
	# CREATE HTML CODE
	#
	$str = "";

        #
	$str = ("$str
		<TABLE width=100% height=2 cellpadding=0 cellspacing=0>
		<TR>
		<TD>
		</TD>
		</TR>
		</TABLE>


		<table cellpadding=0 cellspacing=0 width=100%>
		<tr>

		<TD valign=top width=32>");

	#
	$url = CapUrl($url, $cap);
	$VIEWHL_URL = $url;

	#
	$z = $_[0];
	$z =~ s/^([a-z]*)\/.*$/$1/;
	if( isAutoSection($z)==1 )
	{
		$so{'imageurl'} = AutoDetermineImage($cap);
	}

	#
	if($so{'imageurl'} eq "")
	{
		$so{'imageurl'} = "$IMAGES_BASE/document.gif";
		if($url=~/software/)
		{
			$so{'imageurl'} = "$IMAGES_BASE/software.gif";
		}
	}
	else
	{
		$so{'imageurl'} =~ s/^(.*[\/])([a-z0-9\-\_\!]*)\.([a-z])*$/$1thumb2\/th_$2.png/i;
	}
	$url = "Javascript:parent.window.location='$url';";
	if($so{'imageurl'} ne "")
	{
		$str = ("$str
			<!---- ARTICLE IMAGE ---->
			<A HREF=\"$url\" class=news1>
			<IMG SRC=\"$so{'imageurl'}\" border=0>
			</A>
			");
	}
	else
	{
	}
	$str = ("$str </TD>");

	$t = (stat($first))[9];
	$ct = time;
	$age = $ct-$t;
	#
	$headline_class = "news5";
	if($age < ($UUSI_IKA/3))
	{
		$headline_class = "news6";
	}
	$headline_class2 = "news_title_old";
	if($age < ($UUSI_IKA/3))
	{
		$headline_class2 = "news_title_new";
	}

	#
	$str = ("$str
		<TD width=4>
		</TD>

		<TD valign=top width=250>
                <div>
		<font size=2 face=Times Roman>
		");
	if( !($_[0]=~/\!\!$/) )
	{
		$str = ("$str
			<a href=\"$url\" class=$headline_class>
	                $cap
			$thumbs</a>
			$comments
			");
	}
	else
	{
		$str = ("$str
	                <FONT CLASS=$headline_class2>$cap</FONT>
			$thumbs
			$comments
			");
	}
	$pm = POSIX::strftime("%d.%m.%Y", localtime($t));
	$str = ("$str <font size=1 color=\"#808080\">- $pm</font>");
	#AnyComments($first, "news3");
	#
	if($score=~/\./)
	{
		$ifn = $score;
	}
	else
	{
		$ifn = "meter$score.gif";
	}

	$good_sec = 1;
	if(	$_[0]=~/ostetaan/ ||
		$_[0]=~/myydaan/ ||
		$_[0]=~/valokuvaus/ ||
		$_[0]=~/bush/ ||
		$_[0]=~/progressive/ ||
		$_[0]=~/huumori/ ||
		$_[0]=~/ruokailu/ ||
		$_[0]=~/tyopaikat/ ||
		$_[0]=~/asunnot/ )
	{
#		$good_sec = 0;
	}

	if($age < ($UUSI_IKA) && $good_sec)
	{
                   if( $ENV{'NW_LANGUAGE'} eq "fi")
                   {
                           $ifn = "uusi1.gif";
                   }
                   else
                   {
                           $ifn = "new1.gif";
                   }
	}

	#
	$str = ("$str
		</font>
                </div>
		</TD>

		<TD width=24>
		<!---- ARTICLE RANKING ---->
		<IMG SRC=\"$IMAGES_BASE/$ifn\" alt=\"$alt\" title=\"$alt\">
		</TD>


		</tr>
		</table>

		<TABLE width=100% height=2 cellpadding=0 cellspacing=0>
		<TR>
		<TD>
		</TD>
		</TR>
		</TABLE>

                ");

	#
	return $str;
}

################################################################################################################
#
sub ViewSection
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,@lst,$fn,$sec,$offs);

	#
	@lst = LoadList("$SECTION/fileindex.txt");
	@lst = reverse @lst;

	#
	$str = "";

	#
	if($so{'page'} eq "") { $so{'page'} = 0; }
	#
	$cp = $so{'page'}+1;
	$str = ("$str
<TABLE width=40 height=8 cellspacing=0 cellpadding=0>
<TR>
<TD>
<DIV ALIGN=RIGHT>
<font size=1 color=#C0C0C0>page $cp</font>
</DIV>
</TD>
</TR>
</TABLE>
");

	#
	$max_to_show = 10;
	$offs = ($so{'page'} % 10)*$max_to_show;
	for($i=0,$i2=0,$i3=0; $i<($#lst+1) && $i2<$max_to_show; $i++)
	{
		$lst[$i] =~ s/^\.\.\///;
		if($lst[$i]=~/\//)
		{
			$sec = $lst[$i];
			$sec = s/^([a-z]*)\/.*$/$1/;
		}
		else
		{
			$sec = $SECTION;
			$lst[$i] = "$SECTION/$lst[$i]";
		}

		if($SECTION eq "kaikki" && $lst[$i]=~/videos/i) { goto skip; }

		$i3++;
		if($i3<$offs) { goto skip; }

		$str2 = ViewHL($lst[$i]);
		$str = "$str $str2 ";
		$i2++;
skip:
	}

	#
	$lp = $so{'page'}-1;
	$np = $so{'page'}+1;
	if($lp>=0) { $str = "$str <A HREF=\"/ifbriefly.pl?page=$lp&s=$so{'s'}\"><<</A> "; }
	$str = "$str <A HREF=\"/ifbriefly.pl?page=$np&s=$so{'s'}\">>></A> ";

	#
	return $str;
}

################################################################################################################
#
sub GenPage1
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,@lst,$fn);

	#
	$str = ("
<HEAD>
<link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_BASE/search.ico\">
</HEAD>

<BODY>

<TABLE width=100% height=100% bgcolor=#FFFFFF>
<TR valign=top>
<TD>
");

	#
	$SECTION = $so{'s'};
	if($SECTION eq "")
	{
		$SECTION = "poimitut";
	}

	#
	$str = ("$str
		<!--- START OF BRIEFLY SECTION: --->
");

	#
	$str2 = ViewSection($SECTION);
	$str = "$str $str2 ";

	#
	$str = ("$str

<!--- END OF BRIEFLY SECTION --->
");

        #
        $str = ("$str
</TD>
</TR>
</TABLE>

</BODY>
");

	#
	return $str;
}

################################################################################################################
#
sub GenPage
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,@lst,$fn);

	#
	$fn = "cache/briefly_$so{'s'}_$so{'page'}.txt";

	#
	if(-e $fn && FileAge($fn)<(60*2))
	{
		@lst = LoadList($fn);
		for($i=0,$str=""; $i<($#lst+1); $i++)
		{
			$str = "$str$lst[$i]\n";
		}
		return "$str";
	}
	else
	{
		$str = GenPage1();
		open($f, ">$fn") || die "can't write cache $fn\n";
		print $f "$str";
		close($f);
		return "$str";
	}

	#
}

################################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,$str3,$str4,@lst,$fn);

	#
	$so{'page'} =~ s/[^0-9]//g;
	$so{'page'} = sprintf "%d", $so{'page'};
	$so{'s'} =~ s/[^a-z]//g;

	#
	$str = GenPage();
	$str =~ s/\"/\\\"/g;
	$str =~ s/\'/\\\'/g;

	#
	@lst = split(/\n/, $str);

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		if($lst[$i] ne "")
		{
			print "document.write(\"$lst[$i]\");\n";
		}
	}

	#
}


