#!/usr/bin/perl
##############################################################################
#
# jsnw.pl - JS embed: specific Vunet news section browser/search widget
#
# Embed example:
#   <script src="/cgi/jsnw.pl?section=talous&maxts=10&FP_SECTION=Finnish"></script>
#
# Query string params:
#   maxts=MAXIMUM RESULTS COUNT TO SHOW
#   section=current news section in Vunet
#   FP_SECTION=English or Finnish (default: Finnish)
#
# No CGI.pm used.
#
##############################################################################

#use strict;
#use warnings;
use utf8;
use feature 'fc';

use POSIX qw(strftime);
use HTML::Entities qw(encode_entities);
use URI::Escape qw(uri_unescape);

print "Content-type: text/javascript; charset=UTF-8\n\n";
open(STDERR, '>&STDOUT');
$| = 1;

##############################################################################
# Legacy project layout
##############################################################################
require "./tools.pl";
require "./modules/ViewArticleLib.pm";
require "./modules/sql.pm";

AltseSQLConnect();

our $DONT_AFFECT_DB = 1;

##############################################################################
# Global defaults / compatibility knobs
##############################################################################
our $CACHE_PATH = "./cache";
our $M_CAGE     = 60 * 5;      # 5 min cache
our $ARTROOT    = $ENV{'ARTROOT'} // "/home/vai/articles";

# Preserve old globals if other Vunet modules expect them
our %so;
our $NW_MAX_SEARCH_RES = 25;

##############################################################################
# Query string parsing (NO CGI.pm)
##############################################################################
sub parse_query_string {
        my $qs = $ENV{'QUERY_STRING'} // '';
        my %p;

        for my $pair (split /&/, $qs) {
                next if $pair eq '';
                my ($k, $v) = split(/=/, $pair, 2);
                $k //= '';
                $v //= '';

                $k =~ tr/+/ /;
                $v =~ tr/+/ /;

                $k = uri_unescape($k);
                $v = uri_unescape($v);

                $p{$k} = $v;
        }

        return %p;
}

%so = parse_query_string();

$so{'maxts'}      = 10 if !defined($so{'maxts'}) || $so{'maxts'} eq '';
$so{'FP_SECTION'} = 'Finnish' if !defined($so{'FP_SECTION'}) || $so{'FP_SECTION'} eq '';
$so{'section'}    = '' if !defined($so{'section'});

$so{'maxts'} =~ s/[^0-9]//g;
$so{'maxts'} = int($so{'maxts'});
$so{'maxts'} = 10 if $so{'maxts'} <= 0;
$so{'maxts'} = 100 if $so{'maxts'} > 100;

$so{'page'} = 0 if !defined($so{'page'}) || $so{'page'} eq '';
$so{'page'} =~ s/[^0-9]//g;
$so{'page'} = int($so{'page'});

$so{'section'} =~ s/[^a-zA-Z0-9_\-\&]//g;
$so{'FP_SECTION'} =~ s/[^a-zA-Z]//g;

##############################################################################
# Cache file
##############################################################################
my $cache_key = join("_",
        ($so{'section'}    || 'nosection'),
        ($so{'maxts'}      || '10'),
        ($so{'FP_SECTION'} || 'Finnish'),
        ($so{'page'}       || '0'),
        (defined $so{'q'} ? $so{'q'} : '')
);

$cache_key =~ s/[^a-zA-Z0-9_\-]/_/g;
my $cache_fn = "$CACHE_PATH/jsnw_$cache_key.js";

if (-e $cache_fn) {
        my $age = FileAge($cache_fn);
        if (defined $age && $age >= 0 && $age < $M_CAGE) {
                if (open(my $cfh, "<:encoding(UTF-8)", $cache_fn)) {
                        while (my $l = <$cfh>) { print $l; }
                        close($cfh);
                        exit 0;
                }
        }
}

##############################################################################
# Helpers
##############################################################################
sub js_escape {
        my ($s) = @_;
        $s //= '';
        $s =~ s/\\/\\\\/g;
        $s =~ s/'/\\'/g;
        $s =~ s/\r//g;
        $s =~ s/\n/\\n/g;
#        $s =~ s!</!</g;   # avoid accidental </script>
        return $s;
}

sub html_escape {
        my ($s) = @_;
        $s //= '';
        return encode_entities($s, q{<>&"'});
}

sub normalize_fp_section {
        my ($v) = @_;
        $v //= 'Finnish';

        return 'English' if lc($v) eq 'english';
        return 'Finnish';
}

sub section_title {
        my ($section_name, $fp_section) = @_;
        $section_name //= '';

        if ($section_name eq '') {
                return ($fp_section eq 'English') ? 'Latest news' : 'Uusimmat uutiset';
        }

        # If legacy Headline() exists and returns text, use it.
        my $txt = '';
        eval {
                local *STDOUT;
                open(STDOUT, '>', \my $buf);
                Headline($section_name);
                close(STDOUT);
                $txt = $buf;
        };

        $txt =~ s/<[^>]*>//g if defined $txt;
        $txt =~ s/^\s+|\s+$//g if defined $txt;

        if (defined $txt && $txt ne '') {
                return $txt;
        }

        return $section_name;
}

sub read_article_title {
        my ($fullpath) = @_;
        return '' if !defined $fullpath || $fullpath eq '' || !-e $fullpath;

        my @lst = LoadList($fullpath);
        return '' if !@lst;

        my $t = $lst[0] // '';
        $t =~ s/<[^>]*>//g;
        $t =~ s/\r|\n//g;
        $t =~ s/^\s+|\s+$//g;
        $t =~ s/\s{2,}/ /g;
        return $t;
}

sub read_article_intro {
        my ($fullpath) = @_;
        return '' if !defined $fullpath || $fullpath eq '' || !-e $fullpath;

        my @lst = LoadList($fullpath);
        return '' if $#lst < 1;

        my $txt = '';
        for (my $i = 1; $i < @lst && $i < 12; $i++) {
                my $line = $lst[$i] // '';
                $line =~ s/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>//gi;
                $line =~ s/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>//gi;
                $line =~ s/<[^>]*>//g;
                $line =~ s/\r|\n/ /g;
                $line =~ s/\s+/ /g;
                $line =~ s/^\s+|\s+$//g;
                next if $line eq '';
                $txt = $line;
                last;
        }

        if (length($txt) > 220) {
                $txt = substr($txt, 0, 217) . "...";
        }

        return $txt;
}

sub make_view_url {
        my ($section_name, $file_name) = @_;
        $section_name //= '';
        $file_name    //= '';

        my $story = "$section_name/$file_name";
        $story =~ s/\/+/\//g;

#        if ($story =~ /\.txt$/i) {
#                $story =~ s/pub_artikkeli([0-9]+)\.txt$/story-$1.html/i;
#        }

        my $url = "/viewarticle/?article=$story";
        return $url;
}

sub get_section_entries {
        my ($section_name) = @_;
        my @entries;

        return @entries if !defined $section_name || $section_name eq '';
        return @entries if $section_name =~ /\&/;

        my $idx = "$ARTBASE/$section_name/fileindex.txt";
        return @entries if !-e $idx;

        @entries = LoadList($idx);
        @entries = grep { defined($_) && $_ ne '' } @entries;

        return @entries;
}

##############################################################################
# Pure HTML builder that acts as the JS payload source
##############################################################################
sub SpecificSection2 {
        my ($section_name) = @_;

        my $fp_section = normalize_fp_section($so{'FP_SECTION'});
        my $maxts      = $so{'maxts'} || 10;
        my $page       = $so{'page'} || 0;

        my @fileindex = get_section_entries($section_name);

        my $headline   = section_title($section_name, $fp_section);
        my $item_word  = ($fp_section eq 'English') ? 'articles' : 'artikkelit';
        my $updated    = strftime("%d.%m.%Y %H:%M", localtime(time));
        my $empty_text = ($fp_section eq 'English')
                ? 'No results from this section.'
                : 'Ei tuloksia tästä osastosta.';

        my $html = "";
        $html .= "<div class=\"jsnw-widget\" style=\"margin:10px 0;padding:10px;border:1px solid #ddd;background:#fff;\">";
        $html .= "<div style=\"font-weight:bold;font-size:18px;margin-bottom:6px;\">" . html_escape($headline) . "</div>";
        $html .= "<div style=\"font-size:12px;color:#666;margin-bottom:10px;\">"
              . scalar(@fileindex) . " " . html_escape($item_word) . "</div>";

        if ($#fileindex < 0) {
                $html .= "<div>" . html_escape($empty_text) . "</div>";
                $html .= "</div>";
                return $html;
        }

        $html .= "<div class=\"jsnw-results\">";

        my $start = $#fileindex - $page;
        my $shown = 0;

        for (my $i = $start; $i >= 0 && $shown < $maxts; $i--) {
                my $fn = $fileindex[$i];
                next if !defined $fn || $fn eq '';

                my $fullpath = "$ARTBASE/$section_name/$fn";
                next if !-e $fullpath;

                my $title = read_article_title($fullpath);
                my $intro = read_article_intro($fullpath);
                my $url   = make_view_url($section_name, $fn);

                $title = $fn if !defined($title) || $title eq '';

                $html .= "<div class=\"jsnw-item\" style=\"margin:0 0 14px 0;padding:0 0 10px 0;border-bottom:1px solid #eee;\">";
                $html .= "<div style=\"font-weight:bold;font-size:16px;line-height:1.3;margin-bottom:4px;\">"
                      . "<a class=\"dark\" href=\"" . html_escape($url) . "\">" . html_escape($title) . "</a></div>";

                if (defined $intro && $intro ne '') {
                        $html .= "<div style=\"font-size:13px;line-height:1.45;color:#333;\">"
                              . html_escape($intro) . "</div>";
                }

                $html .= "</div>";
                $shown++;
        }

        if ($shown == 0) {
                $html .= "<div>" . html_escape($empty_text) . "</div>";
        }

        $html .= "</div>";
        $html .= "<div style=\"margin-top:8px;font-size:11px;color:#666;\">Päivitetty: " . html_escape($updated) . "</div>";
        $html .= "</div>";

        return $html;
}

##############################################################################
# Build JS output
##############################################################################
my $section_name = $so{'section'} || '';
my $html = SpecificSection2($section_name);

my $js = "";
$js .= "/* jsnw.pl: specific section widget */\n";
$js .= "(function(){\n";
$js .= "  try {\n";
$js .= "    document.write('" . js_escape($html) . "');\n";
$js .= "  } catch(e) {}\n";
$js .= "})();\n";

# Save cache (best effort)
if (-d $CACHE_PATH) {
        if (open(my $ofh, ">:encoding(UTF-8)", $cache_fn)) {
                print $ofh $js;
                close($ofh);
        }
}

print $js;
exit 0;
