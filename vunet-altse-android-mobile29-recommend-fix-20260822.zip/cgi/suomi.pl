#!/usr/bin/perl
use utf8;
#############################################################################
# SUOMI.EXPRESS
# top20.pl - ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);
use DateTime;
use Time::Moment;
use Time::Piece;

#
require "./modules/AltseOpenConfig.pm";
#require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
#require "./modules/SearchSubModule.pm";
#require "./modules/DirectorySubModule.pm";
require "./modules/OpenHTMLDocument.pm";
require "./modules/AltseMenu.pm";
#
print "Content-Type: text/html; charset=UTF-8\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
if($so{'q'} eq "")
{
 $so{'q'} = "Punakaartien keskusjärjestö - Конфедерация красногвардейцев";
}

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# https://ww&#128513;w.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();

# MENU.
#print("
#<DIV ALIGN=\"center\">
#        <iframe width=\"100%\" height=\"32\" src=\"/menu/\"
#                frameborder=\"0\"  onload=\"resizeIframe(this)\"/
#                loading=\"lazy\”>
#        </iframe>
#</DIV>
#");

# Call the main function.
SuomiPortal();


#############################################
# THE END OF THE HTML DOCUMENT.
#############################################

#
CloseHTMLDocument();


#####################################################################################################
# ISTRUMP.LIFE CGI CODE.
# (C) Jari Tapio Tuominen (jari.t.tuominen@gmail.com);
sub SuomiPortal
{
        #
        my $HTML_MENU = AltseMenu();


        #
        print("
$HTML_MENU
	");
	
	#
	print("
       <iframe width=\"100%\" height=\"1000\" src=\"https://punakaarti.blogspot.com/\"
                frameborder=\"0\"  onload=\"resizeIframe(this)\"
               loading=\"normal\"/>
</iframe>
	
	");
	
	#
#	print("
#</TD>
#</TR>
#</TABLE>
#	");
}


1;
