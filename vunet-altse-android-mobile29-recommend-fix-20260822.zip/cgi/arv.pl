#!/usr/bin/perl
use utf8;
#######################################################
# arv.pl
# Newswire Publishing System.
# (C) 2004-2005 by Jari Tuominen.
#######################################################

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "tools.pl";

#
use Socket;
use Net::DNS;
use Net::hostent;
use POSIX;
#
$ADMPATH = "$NEBASECGI/admin";
$ARTVIEWER = "/article/";
#
$ARTCAP = "NONE";

#######################################################
# PREFERENCES
#
$PROGRAM_NAME = "Vunet Information System";
$so{'COMMENTS_ENABLED'} = 1;
$so{'AUTO_FIX_LINES'} = 1;
$WEBINDEX = "webindex.html";

#######################################################
# Go to main loop.
#
main();

##########################################################
sub PROCAP
{
	my ($cap);

	#
	$cap = $_[0];
        $cap =~ s/<br>//ig;
        $cap =~ s/(\S{15})/$1 /g;
	return $cap;
}

##########################################################
sub ViewArticleFileHeadline
{
	my ($i,$i2,$i3,$i4,$cap,$url);

	#
	if( !(-e $_[0]) ) { return(); }

	#
	$url = UrlFix($_[0]);

	#
	open(f, "$_[0]");
	$cap = <f>;
	close(f);

	#
	$cap = PROCAP($cap);

	#
	print("
		<table width=100% cellpadding=0 cellspacing=0>
		<tr>
		<td>
		<a href=\"$ARTVIEWER$url\" class=dark>
		<font size=1>
		<li><b>$cap</b></li>
		</font>
		</a>
		</td>
		</tr>
		</table>
		");
}

##########################################################
sub ViewComment
{
	my ($i,$i2,$str,$tt,$pm,$Second,$Minute,$Hour,
		$Day,$Month,$Year,$WeekDay,$DayOfYear,$IsDST,$fzz,$ii,
		$SMILE,@spt);

	#
	if(!-e $_[0]) { print "$_[0]?<br>"; return; }

	#
	@txt = LoadList($_[0]);
	if($#SMILES<0)
	{
		@SMILES = LoadList("smiles.txt");
	}

	#
	@spt = split("\&", $txt[0]);
	if($spt[1] ne "")
	{
		$SMILE = "<img src=\"$SMILES[$spt[1]]\" align=center>";
	}

	#
	$ii = $_[1]+1;
	print("
		<table cellpadding=4 cellspacing=0 width=100%
			bgcolor=\"#C0FFC0\">
		<tr valign=top>

		<td width=50%>
		<font size=\"4\" class=caps>$SMILE kommentti $ii</font>
		</td>

		<td width=25%>
		<div align=right class=CAPS>
		<font size=2>
		$spt[2]
		</font>
		</div>
		</td>

		<td bgcolor=\"#FFEEDD\" width=25%>
		");

	#
	$t = (stat($_[0]))[9];
	$pm = POSIX::strftime("%d.%m.%Y", localtime($t));
	print("
		<div align=center>
		$pm
		</div>
		");

	#
	print("
		</td>
		</tr>
		</table>
		");

	#
	roll: for($i=0; $i<($#txt+1); $i++)
	{
		# Prevent printing of user ID in non-admin mode.
		if(!($txt[$i] =~ /intlfox/))
		{
			if(!$i) { print "<br>"; }
			$str = $txt[$i];
			$str =~ s/<.*?>//g;
			print "$str<br>";
		}
		else
		{
			#
			$ASIAKAS = "";
			$str = $txt[$i];
			$str =~ s/intlfox\ userid\ \=//;
			$str =~ s/<.*?>//g;
			$str =~ s/\.//g;
			$str =~ s/\ //g;
			$str =~ s/(....)/$1 /g;
		}
	}

	#
	LoadProfile(GetUserID());
}

##########################################################
#
# View comments.
#
sub ViewComments
{
	my ($i,$f,$artk);

	#
	$comindex = "$_[0]\_comindex.txt";
	open($f, $comindex);
	@ind = <$f>;
	close($f);
	#
	for($i=0; $i<($#ind+1); $i++) { chomp $ind[$i]; }

	#
	print "<a name=\"comments\"></a>\n";

	#
	for($i=0; $i<($#ind+1); $i++)
	{
		#
		$artk = $ind[$i];
		ViewComment($artk, $i);

		#
		if( NoTracking() )
		{
			print "<br><a href=\"$ADMPATH/remcom.pl?$artk&RETURL=/article/$_[0]\">";
			print "<img src=\"$IMAGES_BASE/kori.gif\" align=center border=0 vspace=4 hspace=4>";
			print "poista kommentti\n";
			print "</a><br>\n";
			print "<a href=\"$ADMPATH/editart.pl?FILE=$artk&RETURL=/article/$_[0]\">";
			print "<img src=\"$IMAGES_BASE/editor.gif\" align=center border=0 vspace=4 hspace=4>";
			print "muokkaa kommenttia\n";
			print "</a><br>\n";
		}

		# Soft seperator xxxx.
		print "<hr color=\"D0F0D0\">\n";
	}
}

#
sub tracker
{
	#
	print("
<!-- Begin Nedstat Basic code -->
<!-- Title: Tracker 2. Alternative News Agency, VAI. -->
<!-- URL: https://vunet.net/~vai/cgi/newswire.pl -->
<script language=\"JavaScript\" type=\"text/javascript\" src=\"https://m1.nedstatbasic.net/basic.js\">
</script>
<script language=\"JavaScript\" type=\"text/javascript\" >
<!--
  nedstatbasic(\"AC6yqg1xZ/pjihtneK5JpNbDN41w\", 0);
// -->
</script>
<noscript>
<a target=\"_blank\" href=\"https://www.nedstatbasic.net/stats?AC6yqg1xZ/pjihtneK5JpNbDN41w\"><img
src=\"https://m1.nedstatbasic.net/n?id=AC6yqg1xZ/pjihtneK5JpNbDN41w\"
border=\"0\" width=\"18\" height=\"18\"
alt=\"Nedstat Basic - Free web site statistics
Personal homepage website counter\"></a><br>
<a target=\"_blank\" href=\"https://www.nedstatbasic.net/\">Free counter</a>
</noscript>
<!-- End Nedstat Basic code -->



		");

}

##########################################################
#
sub Muunna
{
	my ($i,$i2,$str,$str2,$str3,$str4,$rep,$con,$tmp,@sp);

        #
        if($#TR_SMILES<2)
        {
                @TR_SMILES = LoadList("tr_smiles.txt");
        }

	#
	$str = $_[0];

	#
	for($i=0; $i<($#TR_SMILES+1); $i++)
	{
		#
		$str2 = $TR_SMILES[$i];
		@sp = split(" ", $str2);
		$sp[1] =~ s/\s//g;

		#
		if($sp[1] ne "")
		{
			$str =~ s/$sp[1]/<img src=\"$sp[0]\">/;
		}
	}

	#
#	print "mli = $#mli<br>\n";

	#
	if($str =~ /a href=/) { return $str; }
	loop: for($i=0; $i<($#mli+2); $i+=2)
	{
		#
		if(tyhja($mli[$i+0])) { goto past; }
		$rep = $mli[$i+0];
		$rep =~ s/\:/\\\:/;
		$rep =~ s/\//\\\//;
		$rep =~ s/\_/\\\_/;
		$con = "\<a href\=\"$mli[$i+1]\" target\=\"_blank\"\ class=\"news1\">$rep\<\/a\>";
		$str =~ s/$rep/$con/ig;
past:
	}

	#
	$str2 = $str;
	$str2 =~ s/<.*?>//g;
	$str2 =~ s/\s//g;
	$str3 = $_[1];
	$str3 =~ s/<.*?>//g;
	$str3 =~ s/\s//g;
	$str4 = $_[3];
	$str4 =~ s/<.*?>//g;
	$str4 =~ s/\s//g;

	#
	if($str =~ /http:\/\// && !($str =~ /<a href/)
		&& ($str=~/^http:\/\// || $str=~/\shttp:\/\//)
		&& !($str=~/\.jpg|\.gif/) )
	{
		$tmp = $str;
		$tmp =~ s/^.*(http:\/\/.*)\s.*$/$1/;
		$tmp =~ s/(http:\/\/.*)<br>/$1/;
		if( !($tmp =~ /<.*?>/) )
		{
			$str =~ s/(http:\/\/.*)<br>/$1/;
			$str2 = $str; $str2 =~ s/(\S{40})/$1 /g;
$str =~ s/(http:\/\/.*)/<i><a href=\"\/\?to\=$1\" class=news3 target=_blank>$str2<\/a><\/i> /;
		}
	}

	#
	if( length($str2) < 70 && ($_[1]=~/<br>/i) && length($_[1])<6 && length($_[2])<10
		&& ((!($str2 =~ /^.*\.$/) && !($str2 =~ /^.*\.$/)) || ($str3 eq "" && $str4 eq ""))
		&& !($str =~ /^-\ /) && !($str =~ /^·\ /)
		&& !($str =~ /^\*\ /) && !($str =~ /^\*\ /) )
	{
		$str = "<b>$str</b>";
	}

	#
	$str =~ s/\<xembed /\<embed /i;
	if($str =~ /embed\ssrc/)
	{
		$str2 = $str;
		$str2 =~ s/^.*src=\"(.*?)\".*$/$1/i;
	#	$str2 =~ s/^(.*)\".*$/$1/;
		$str = "<table cellpadding=0 cellspacing=0><tr><td>$str</td></tr> <tr><td><a href=\"$str2\">DOWNLOAD VIDEO</a></td></tr></table><br>";
	}

	#
	$str =~ s/==/ /g;

	#
	return $str;
}

##########################################################
sub dummy
{
}

##########################################################
#
sub DetectAuthor
{
	my ($i,$i2,$author);

	#
	for($i=0; $i<($#lines+1); $i++)
	{
		#
		if($lines[$i] =~ /Vaihtoehtouutiset/)
		{
			$author = "VU";
		}
		if($lines[$i] =~ /KOMINFORM/)
		{
			$author = "kominform";
		}
		if($lines[$i] =~ /Hannu Rainesto/i)
		{
			$author = "rainesto";
		}
	}
	return $author;
}

##########################################################
#
sub Arvottu
{
	my ($i,$i2,$i3,$i4,@arv,$str,$str2);

	#
	EXPRESS("arvottu", "", "center");

	#
	OPENTABLE($TABCOL);

	#
	@arv = LoadList("poimitut/fileindex.txt");

	#
	srand(time);
	$i = sprintf("%d", rand($#arv));
	print("
			<table cellpadding=4 cellspacing=0>
			<tr>
			<td>

			<font size=1>
			");

	#
	$str = $arv[$i];
	$str =~ s/\.\.\///;
	ViewArticleFileHeadline($str);

	#
	print("
			</font>

			</td>
			</tr>
			</table>
			");

	#
	CLOSETABLE($TABCOL);

	#
	print("<br>");
}

##########################################################
#
sub LinksEmbedded
{
		my ($i,$f,$ff,@ql,$quoteit,$tep,$author,$cap,$str,$str2,$u);

		#
		if( open($ff, "$_[0]\_links.txt") )
		{
			close($ff);
			@lnk = LoadList("$_[0]\_links.txt");
			for($i=0; $i<$#lnk; $i+=2)
			{
				#
				if(
						$links[$i+1] =~ /vunet\.org/i
						||
						$links[$i+1] =~ /^\// )
					{
						$str="";
					}
					else
					{
						$str = "target=\"_blank\"";
					}
				#
				$u = PURL($lnk[$i+1]);
				$u = "/?to=$u";
				print("
					<br>
					<a href=\"$u\" class=news1 $str>
					<li>$lnk[0+$i]");
				if($so{'printable'})
				{
					$str = PROCAP($u);
					print("<br>$str");
				}
				print("</li>
					</a>
					");
			}
		}
}

##########################################################
#
sub Lahteet
{
			my ($i,$f,@ql,$quoteit,$tep,$author,$cap,$str,$str2,$urli);

			#
			if( open($f, "$_[0]\_links.txt") )
			{
				#
				close($f);

				#
				@links = LoadList("$_[0]\_links.txt");
				EXPRESS("lähteet", "", "center");
				OPENTABLE($TABCOL);
				print("
					<table cellpadding=4 cellspacing=0><tr><td>
					");

				#
				for($i=0; $i<($#links); $i+=2)
				{
					#
					$links[$i+0] =~ s/<br>//ig;
					$cap = PROCAP($links[$i+0]);
					if(
						$links[$i+1] =~ /vunet\.org/i
						||
						$links[$i+1] =~ /^\// )
					{
						$str="";
					}
					else
					{
						$str = "target=\"_blank\"";
					}

					#
					$urli = "$links[$i+1]";
					$urli = "/?to=$urli";
					print("
						<a href=\"$urli\" class=dark $str>
						<li>
						<font size=2>
						$cap
						</font>
						</li>
						</a>

						<table cellpadding=0 cellspacing=0 height=4 width=100%>
						<tr><td>
						</td></tr>
						</table>
						");
				}
				#
				print("
					</td></tr></table>
					");
				#
				if( NoTracking() )
				{
					#
					print("
				<br>
		<center>
		<a href=\"https://vunet.net/admin/editart.pl?FILE=$_[0]\_links.txt&RETURL=/article/$_[0]\" class=dark>
		<img src=\"$IMAGES_BASE/editor.gif\" align=center border=0>
		<font size=2>
		muokkaa linkkejä
		</font>
		</a>
		</center>
						
						");
				}

				#
				CLOSETABLE($TABCOL);

				#
				print("<br>\n");

			}
}

##########################################################
#
sub ViewTextOnly
{
	my ($i,$i2);

	#
	print("<font face=\"Lucida Console\">");
	print("<table width=100%><tr><td valign=top>");
	print("Vaihtoehtouutiset - https://vunet.net<br>");
	print("__________________________________________________________________________<br><br>\n");

	#######################################################################
	#
	for($i=0; $i<($#lines+1); $i++)
	{
		$lines[$i] =~ s/<.*?>//g;
		$lines[$i] =~ s/^\s//g;
	}

	#######################################################################
	#
	for($i=0; $i<($#lines+1); $i++)
	{
		print "$lines[$i]<br>\n";
	}

	#######################################################################
	#
	print("</td></tr></table>");
	print("</font>");
}

#############################################################################################
#
sub vulehti
{
			#
			print("	
				<div align=center>

				<a href=\"https://vunet.net/?id=3x81\"
					class=\"dark\">
				<img src=\"$IMAGES_BASE/sm_vulehti2.jpg\"><br>
				</a>

				</div>
				");
}

#############################################################################################
#
sub vinkki2
{	
	my ($i,$i2,$str,$str2,$url,$img,@lst);

	#
	@lst = LoadList("cfg/banners.txt");

	#
	$i = sprintf "%d", rand($#lst/2);
	$i *= 2;

	#
	$img = "$IMAGES_BASE/$lst[$i+0]";
	$url = $lst[$i+1];

	#
	print("
		<center>
		<font size=1>Mainos:</font><br>
		<a href=\"$url\" target=\"_blank\" class=news3>
		<img src=\"$img\">
		</a>
		</center>
		");
}

#############################################################################################
#
sub vinkki
{
	#
	if(!NoTracking()) { return; } 

	#
	print("
	<div align=center>
	<a href=\"/finnish/tyopaikat\" class=news2>
	<img src=\"$IMAGES_BASE/sm_banneri_tyopaikat.gif\" border=4>
	</a>
	</div><br>

	<div align=center>
	<table cellpadding=2 cellspacing=0
		bgcolor=\"#000000\" width=140>
	<tr>
	<td>

	<table cellpadding=0 cellspacing=0
		bgcolor=\"#FFFF00\" width=100%>
	<tr>
	<td>

	<div align=center>
	<a href=\"/hint.pl\" class=dark>
	Lähetä juttuvinkki toimitukselle !
	</a>
	</div>

	</td>
	</tr>
	</table>

	</td>
	</tr>
	</table>
	</div>
	");
}

#############################################################################################
#
sub ContentOnRight
{
		my ($i,$f,@ql,$quoteit,$tep,$author);

		#
		if($so{'printable'} <= 1 && $ENV{'FRONT_PAGE_MODE'} ne "TRUE")
		{
	#
	print("
		<table cellpadding=0 cellspacing=0 align=right width=144>
		<tr>
		<td valign=top>
		");


			#
			TopTools();

			#
			if( open($f, "current-poll.txt") )
			{
				$ENV{'POLLNR'} = sprintf("%d", <$f>);
				close($f);
			}
			else
			{
				$ENV{'POLLNR'} = 6;
			}
	
			#
			$ENV{'newswire_conset'} = "TRUE";
			$ENV{'BOUNCE_TO'} = "/article/$_[0]";
	                if( open(CAL, "./poll.pl|") )
			{
		                @cal = <CAL>;
		                close(CAL);
			}
	                print(" 
				<center>
				<table width=140 bgcolor=\"#00C0FF\" cellpadding=1 cellspacing=0>
				<tr>
				<td>

				<table width=100% bgcolor=\"#00FFFF\" cellpadding=0 cellspacing=0>
				<tr valign=top>
				<td>

				<div align=center>
				@cal
				</div>

				</td>
				</tr>
				</table>
				</td>
				</tr>
				</table>
				</center>

				<br>
				");

			#
			#### vulehti();
			vinkki2($_[0], $r);

			#
			print("
				<table width=100% cellpadding=8 cellspacing=0>
				<tr>
				<td>
				");

				#
				$author = DetectAuthor();
				#
				$so{'author_banner'} = "banner\_$author\.jpg";
				if( -e "cfg/$author\.profile" )
				{
					RollThrough("cfg/$author\.profile");
				}
				#
				if($author ne "")
				{
					print("
						<div align=center>
						<font size=1>Tämä artikkeli tulee lähteestä:</font>
						</div>
						<a href=\"https://vunet.net/?to=$so{'author_url'}\" target=\"_blank\" class=news2>
						<img src=\"$IMAGES_BASE/$so{'author_banner'}\" border=1>
						</a>
						<br>
						<br>
						");
				}

				#
				Lahteet($_[0]);
				#
				Arvottu($_[0]);

			#
			$ENV{'BAR_SECTION'} = "poimitut";
	                open(CAL, "./newsbar1.pl|");
	                @cal = <CAL>;
	                close(CAL);
	                print @cal;

			#
			print("<br> ");

			#
		#	$ENV{'BAR_SECTION'} = $ENV{'CURSEC'};
	        #        open(CAL, "./newsbar1.pl|");
	        #        @cal = <CAL>;
	        #        close(CAL);
	        #        print @cal;

			#
			print("
				</td>
				</tr>
				</table>
				");

	#
	print("
		</td>
		</tr>
		</table>
		");

		}
}

##########################################################
#
sub FixArticle
{
	my ($i,$i2,$i3,$i4);

	#
	for($i=$#lines; $i>-1; $i--)
	{
		$lines[$i+1] = $lines[$i+0];
	}
	$lines[0] = "Undefined subject<br>";
	$lines[1] = "<font color=\"#FF0000\"><blink>$lines[1]</blink></font>";
}

##########################################################
#
sub TopTools
{
		#
		print("
			<center>
			<table cellpadding=1 cellspacing=0 width=140 bgcolor=\"#000000\">
			<tr valign=top>
			<td>

			<table cellpadding=2 cellspacing=0 width=138 bgcolor=\"#00FFFF\">
			<tr valign=top>
			<td>
			<font size=2>
			");

		#
		if(NoTracking())
		{
			#
			$cap = $ARTCAP;
			$cap =~ s/\%/\\.\*/g;
			$cap =~ s/\n//g;
			$cap =~ s/\r//g;
			$cap =~ s/\"/\\\'/g;
			$cap =~ s/<br>//ig;
			print("
			<a href=\"/admin/logview.pl?SEARCH=$cap\">
			> kuka lukee?</a>
			</a>
			<br>
			<a href=\"$ADMPATH/editart.pl?FILE=$arz&BAREHTML=true&PLAIN=true\">
			> muokkaa artikkelia</a>
			<br>
				");
		}

		#
		print("

			<a href=\"#comments_form\" class=news3>
			> kommentoi tätä artikkelia
			</a><br>

			<a href=\"https://vunet.net/hint.pl\" class=news3>
			> jätä juttuvinkki tai palaute
			</a>
			");

		#
		print("
			</font>
			</td>
			</tr>
			</table>

			</td>
			</tr>
			</table>
			</center>
			<font size=1><br></font>
			");
}

##########################################################
#
sub ParseOptions
{
	my ($i,$f,@ql,$quoteit,$tep,$author,$cap,@s);

	# Got image url!
	@iminfo = LoadList("$_[0]");
	$so{'imageurl'} = $iminfo[0];
	$so{'artop'} = $iminfo[1];

	#
	@s = split("\&|,|\s", $iminfo[1]);

	#
	for($i=0; $i<($#s+1); $i++)
	{
		VarSet("$s[$i]=TRUE");
	}

	#
	for($i=1; $i<($#iminfo+1); $i++)
	{
		if($iminfo[$i]=~/\=/)
		{
			VarSet($iminfo[$i]);
		}
	}

	#
}

##########################################################
#
# The form is generated in $pr -string.
#
sub GenArticleOptionsForm
{
	my ($i,$f,@ql,$quoteit,$tep,$author,$cap,$x,$ch,$a,$rv,$s1,$s2);
	my @ol = (
			"NO_FLY_FIX","kytke pois artikkelin automaattinen lennossa korjaaminen",
			"dontembed",	"piilota kuva artikkelista",
			"full",		"näytä kuva kokonaisena",
			"ontop",	"kuva artikkelin yläpuolella",
			"!icap",	"kuvan alapuolinen teksti:",
			"!imageurl",	"kuvan www-osoite:"
			);

	# REFERENCE LINK ADDING
	$pr = ("
		<form method=get action=\"/viewarticle.pl\">
		<b>Artikkelikohtaiset asetukset</b><br>

		");

	#
	if($so{'COMMENTS_ENABLED'}==1)
	{
		$s1 = "CHECKED";
	}
	else
	{
		$s2 = "CHECKED";
	}
	
	#
	for($i=0; $i<($#ol); $i+=2)
	{
		#
		$x = "$ol[$i+1]";

		# Optional real answer (alternative for 'on')...
		$rv = "TRUE";
		if( $ol[$i+0] =~ /;/ )
		{
			$rv = $ol[$i+0];
			$rv =~ s/^.*;(.*)$/$1/;
			$ol[$i+0] =~ s/^(.*);.*$/$1/;
		}

		# Edit box.
		if( $ol[$i+0] =~ /^!/ )
		{
			$ol[$i+0] =~ s/^!(.*)$/$1/;
			$x = ("$x <input type=\"text\" name=$ol[$i+0] value=\"$so{$ol[$i+0]}\" size=40>");
			goto past;
		}

		#
		$a = "";
		$ch = "";
		$a = $so{$ol[$i+0]};

		# Default to check box buttons.
		if(!($a=~/^\s$/ || $a eq "") && $a ne "false" && $a ne "0")
		{
			$ch = "checked";
		}
		$x = ("<input type=\"checkbox\" name=\"$ol[$i+0]\" value=\"$rv\" $ch> $x");
past:
		$pr = "$pr $x<br>";
	}

	#
	$pr = ("
		$pr

		Artikkelin kommentointi sallitaan: 
		<input type=\"radio\" name=\"COMMENTS_ENABLED\" value=\"1\" $s1> kyllä
		<input type=\"radio\" name=\"COMMENTS_ENABLED\" value=\"0\" $s2> ei<br>


		<input type=\"submit\" value=\"Tallenna asetukset\">
		<input type=\"hidden\" name=\"file\" value=\"$_[0]\">
		<input type=\"hidden\" name=\"cmd\" value=\"opch\">
		</form>
		");
}

##########################################################
#
sub ReferenceLinkForm
{
	my ($i,$f,@ql,$quoteit,$tep,$author,$cap);

	# REFERENCE LINK ADDING
	print ("
		<form method=get action=\"/admin/addreflink.pl\">
		Linkin lyhyt kuvaus:<br>
		<input type=\"text\" name=\"DESCRIPTION\">
		<br>
		Linkin WWW-osoite:<br>
		<input type=\"text\" name=\"URL\" value=\"https://\">
		<br>
		<input type=\"submit\" value=\"Lisää referenssi linkki uutiseen\">
		<input type=\"hidden\" name=\"ARTICLE\" value=\"$_[0]\">
		</form>
		");
}

##########################################################
#
sub ViewArticle
{
	my ($i,$f,@ql,$quoteit,$tep,$author,$cap);

	#
	@mli = LoadList("cfg/pub_artikkeli_symbols.txt");

	# Load article lines.
	@lines = LoadList($_[0]);

	#
	$arz = $arg;
	$arz =~ s/\/poimitut\/..//;
	$arz =~ s/\/hupi\//\/kummalliset\//;

	#
	if(length($lines[0])>120)
	{
		#
		print("
			<font color=\"#FF0000\">
			Editor warning: Article TITLE is too long!
			</font><br><br>
			");
		#
		FixArticle();
	}

	#
	for($i=0; $i<($#lines+1); $i++)
	{
		$lines[$i] = ULTRAPARSE($lines[$i]);
		$lines[$i] =~ s/^\s*//;
	}

	#
	$ARTCAP = "$lines[0]";
	$ARTCAP =~ s/\n//g;
	$ARTCAP =~ s/\r//g;
	$ARTCAP =~ s/\"/\\\'/g;
	$ARTCAP =~ s/<br>//g;

	# Load quote lines.
	if( open($f, "$_[0]\.quote") )
	{
		close($f); 
		@ql = LoadList("$_[0]\.quote");
	}

	#
	$qq = $ENV{'QUERY_STRING'};
	if($qq =~ /commentsplease/i) { $so{'COMMENTS_ENABLED'} = 1; }

	##################################################
	if(!$so{'printable'} && $ENV{'FRONT_PAGE_MODE'} ne "TRUE")
	{
		#
		SectionHeadline();

		#
		print("	
			<br>
			");
	}


	#
	ContentOnRight($_[0]);

	##################################################
	# CREATE TABLE.
	# Table to contain article + actions.
	print "<table width=\"475\" hspace=\"0\" vspace=\"0\"";
	print " cellpadding=\"0\" cellspacing=\"0\">\n";

	#

	#
	if($so{'printable'})
	{
		#
		print "<tr><td bgcolor=\"#FFFFFF\" valign=top>\n";

		#
		if($so{'printable'} eq "1")
		{
			print("
				<a href=\"https://vunet.net/finnish/\" class=dark>
				<div align=center>
				<img src=\"$IMAGES_BASE/etusivulle.gif\" border=1>
				</div>
				</a>
				");
		}
	}
	else
	{
		print "<tr><td bgcolor=\"#FFFFFF\" valign=top>\n";
	}

	##################################################
	##################################################
	# Table to contain the article
	print("
		<table width=\"470\"
			cellpadding=\"0\" cellspacing=\"0\">
		<tr>
		<td width=75% valign=top>

		<font size=2>
		");

	##################################################
	#
	if($so{'textonly'})
	{
		ViewTextOnly();
		goto skip1;
	}

	##################################################
	#
	# PRINT HEADLINE
	#
	$ARTCAP =~ s/<br>//gi;
	print("
		<table width=100% cellpadding=0 cellspacing=0>
		<tr>
		<td class=\"OTSIKKO\">
		$ARTCAP</strong>
		</td>
		</tr>
		</table>
		<br>
		");

	#
	if($ENV{'FRONT_PAGE_MODE'} ne "TRUE")
	{
	$t = (stat($_[0]))[9];
#	$pm = POSIX::strftime("%Y-%m-%d %H:%M:%S", localtime());
	$pm = POSIX::strftime("%d.%m.%Y", localtime($t));
	print "$pm<br><br>";
	}

	# Internet Explorer / WORD HTML fix.
	for($i=0; $i<($#lines+1); $i++)
	{
		$lines[$i] =~ s/<!--\[/<!-- \[/;
	}

	# Print image, if any.
	if( -e "$_[0]\_imageurl.txt" )
	{
		#
		ParseOptions("$_[0]\_imageurl.txt");

		#
		if($so{'imageurl'} =~ /^\.\.\/uutiset\/.*$/)
		{
			$so{'imageurl'} =~ s/^\.\.\/uutiset\/(.*)/http\:\/\/images\.vunet\.org\/$1/;
		}

		#
		if($so{'full'} ne "")
		{
			$W = "";
			$H = "";
		}
		else
		{
			$W = 140;
			$H = 140;
		}

		#
		if($so{'dontembed'} eq "" &&
			IsImage($so{'imageurl'} )
			)
		{
			#
			$ALGN = "left";
			if($so{'dontalign'} ne "" || $so{'ontop'} ne "")
			{
				$ALGN = "";
			}
			$x = ("<img src=\"$so{'imageurl'}\" ");
			if($W ne "" && $H ne "")
			{
				$x = ("$x width=\"$W\" height=\"$H\" ");
			}
			$x = ("$x
				border=\"1\" hspace=\"0\" vspace=\"0\">\n");
			if($ALGN eq "") { $x = "$x <br>"; }

			#
			$x = ("
				<table cellpadding=8 cellspacing=0 align=$ALGN>
				<tr>
				<td>

				<table cellpadding=0 cellspacing=0>
				<tr>
				<td>
				$x
				</td>
				</tr>
				<tr>
				<td class=\"ICAP\">
				$so{'icap'}
				</td>
				</tr>
				</table>

				</td>
				</tr>
				</table>

				");

			#
			print $x;
		}
	}
	#
	#
	if($so{'NO_FLY_FIX'} ne "")
	{
		$so{'AUTO_FIX_LINES'}=0;
	}
	GenArticleOptionsForm($_[0]);

	#
	print ("
		");
#		<div align=\"justify\">\n

	#
	@tmpl = @lines;
	@lines = ("");
	for($i=1,$i2=1; $i<($#tmpl+1); $i++)
	{
		#
		$tmpl[$i] =~ s/^\s//g;

		#
		$zap = $i-1; if($zap<0) { $zap=0; }
		$tmpl[$i] = Muunna($tmpl[$i], $tmpl[$zap], $tmpl[$i+1], $tmpl[$i-2]);

		#
		if($tmpl[$i] eq "<br>" && $tmpl[$i+1] eq "<br>" && $so{'AUTO_FIX_LINES'}==1)
		{
			$tmpl[$i] =~ s/<br>//gi;
		}

		# Merge multiple brs.
		if($tmpl[$i-1] eq "<br>" && $tmpl[$i+1] eq "<br>" && !Special($tmpl[$i-1]) && !Special($tmpl[i+1])
			&& $tmpl[$i] =~ /<br>/i && $so{'AUTO_FIX_LINES'}==1)
		{
			$tmpl[$i-1] =~ s/<br>//gi;
		}
		$lines[$i2] = "$lines[$i2] $tmpl[$i]";
		if($lines[$i2] =~ /<br>/i || Special($lines[$i2])) { $i2++; }
	}

	##################################################
	#
	for($i=1,$first=1,$quoteit=1; $i<($#lines+1); $i++)
	{
		#
		if($lines[$i] =~ /intlfox userid\ \=\ /)
		{
                        $strz = $lines[$i];
                        $strz =~ s/intlfox\ userid\ \=//;
                        $strz =~ s/<br>//;
                        $strz =~ s/\.//g;
                        $strz =~ s/\ //g;
                        $strz =~ s/(....)/$1 /g;
                        print ("
                                <font size=\"2\">
                        (asiakas $strz)<br>\n
                                </font>
                                ");
		}
		else
		{
			if($first)
			{
				#
				#  LEIPÄTEKSTI
				#
				#########################################################################

				#
				$str=$lines[$i];
				# REMOVE UNICODE SPACE.
				$str =~ s/\xa0//g;
				$str =~ s/\s//g;
				if($so{'dontfix'} ne "")
				{
					$first = 0;
					print "$lines[$i]";
					goto skip1;
				}
				if( length($str)<7  &&  $str =~ /<br>/i )
				{
					# skip
				}
				else
				{
					print("<b>");
					loop: for(; $i<($#lines+1); $i++)
					{
						$str = $lines[$i+1];
						$str =~ s/<br>//gi;
						$str =~ s/\s//g;
						$str2 = $lines[$i];
						$str2 =~ s/<br>//gi;
						print "$str2\n";
						if( ($lines[$i] =~ /<br.*/i) && $str eq "" ) { last loop; }
					}
					print("</b><br>");
					$first = 0;
				}
skip1:
			}
			else
			{
				#
				#  QUOTE
				#
				#############################################################################

				#
				if( ($quoteit--)==0 && $ql[0] ne "")
				{
					#
					print("
						<table width=\"150\" align=\"right\"
							bgcolor=\"#FFFFCC\" hspace=\"2\" vspace=\"2\"
							cellspacing=\"0\" width=\"150\" border=\"0\"
							cellpadding=\"3\" align=\"RIGHT\"
							>
						<tr><td valign=top>

						<img src=\"$IMAGES_BASE/1startquote.gif\" alt=\"'\"><br>
						<font size=\"2\">
						$ql[0]
						</font><br>
						<img src=\"$IMAGES_BASE/1endquote.gif\" align=\"right\"
							alt=\"'\">

						</td></tr>

						<tr bgcolor=\"#000060\"><td valign=top>
						<font color=\"#FFFFFF\">
						$ql[1]<br>
						</font>
						</td></tr>

						</table>
						");
				}

				# HTTP URL
				if(
				# EQUALS TO:
				($lines[$i] =~ /http\:\/\//
				|| $lines[$i] =~ /https\:\/\//)
				# SHOULD NOT EQUAL TO:
				&& !($lines[$i] =~ /\<img src/i) && !($lines[$i] =~ /\"/)
				&& ($lines[$i] =~ /\.jpg/ || $lines[$i] =~ /\.gif/)
					)
				{
					#
					$str = $lines[$i];
					$str =~ s/\<.*?\>//g;
					$str =~ s/\s//g;

					# .JPG, .JPEG, or .GIF ?
					print "<img src=\"$str\" border=1 title=\"image\"><br>\n";
				}
				else
				{
					# Regular article text.
					#
					###############################################################

					#
					$te = $lines[$i];
					$t = $te;
					$str = $lines[$i];
					$str =~ s/<.*?>//g;
					$str =~ s/\s//g;
					$str2 = $lines[$i+1];
					$str2 =~ s/<.*?>//g;
					$str2 =~ s/\s//g;

					# JOIN LINES TOGETHER
					#
					# Jos seuraava rivi ei ole tyhjä ja nykyinenkään ei ole:
					if( (!tyhja($str) && !tyhja($str2) &&
						!($str =~ /^-\ /) && !($str =~ /^\* /)
						&& !($str =~ /^[0-9]*\./)
						&& $so{'AUTO_FIX_LINES'}==1)
						)
					{
 						$t =~ s/<br.*>//gi;
					}
					else
					{
						if( !($t =~ /<br>/i) )
						{
							$t = "$t<br>";
						}
					}

					#
 					if($t =~ /^-\ /  ||  $t =~ /^\*\ /)
					{
						#
						$KUV = ("<img src=\"$IMAGES_BASE/ranskalainenviiva.gif\"
								align=center border=0>
							");
						$t =~ s/[-|\*]\s//;
						$t = "$KUV $t";
					}

					#

					#
					print "$t\n";
					#
					$LL = $t;
				}


			}

			################
		}
	}

	#
	LinksEmbedded($_[0]);
skip1:

	####################################################################################
	#
	# NEWS BAR, links, and so on.
	#
	print("
		</td>
	");

	#
	print("


		</tr>
		</table>
		");

	##########################################################################################################
	#
	# ^^ Article above.
	#

	# Interrupt if in plain outfit mode.
	if($so{'plainoutfit'} eq "true")
	{
		return true;
	}

	# Soft seperator.
	if(!$so{'textonly'} && $ENV{'FRONT_PAGE_MODE'} ne "TRUE")
	{
		print "<br><br><hr color=\"D0F0D0\"><br>\n";
	}

	#
	$str = BuildQuickUrl($_[0]);
	#
	if(!$so{'printable'} && $ENV{'FRONT_PAGE_MODE'} ne "TRUE")
	{
		#
		print("
			<a href=\"https://www.metsavetoomus.fi/\" class=\"dark\" target=\"_blank\">
			<img src=\"$IMAGES_BASE/anim-www_metsavetoomus_fi.gif\" border=1>
			</a>
			<br>
			<br>
			");


		#
		$str = UrlFix($str);
		print("
			<table align=right cellpadding=0 cellspacing=4>
			<tr>
			<td>
			<a href=\"$str\" class=\"news1\">
			link the article by using this url
			</a>
			</td>
			</tr>
			</table>
			");
	}

	#
	if(!$so{'printable'} && $ENV{'FRONT_PAGE_MODE'} ne "TRUE")
	{
		#
		#GoogleAds_2();

		#
		$i = FileAge($_[0]);
		if($i>0)
		{
			$i2 = sprintf "%d", $i/(60*60*24);
			$i3 = sprintf "%d", $i/(60*60);
			$i4 = sprintf "%d", $i/60;

			#
			$str = "";
			if($i4!=0) { $str = "$i4 minuuttia"; }
			if($i3!=0) { $str = "$i3 tuntia"; }
			if($i2!=0) { $str = "$i2 päivää"; }
			if($str eq "")
			{
				$str = "[tuntematon]";
			}

			#
		#	print("
		#		Tämä artikkeli on noin $str vanha.<br>
		#		");
		}

		#
		print "<br>";
		if($bo) {
		print "<br>";
			}
	}

	#
	if($so{'printable'} && !$so{'textonly'})
	{
		#
		print "<center>\n";
		print "<img src=\"$IMAGES_BASE/mainos.jpg\"><br>\n";
		print "</center>\n";
		#
		print "<center>\n";
		print "Julkaistu Vaihtoehtouutisissa.<br>\n";
		print "<a href=\"https://vunet.net\">https://vunet.net</a>\n<br>";
		print "</center>\n";
	}

	#
	if($so{'printable'})
	{
		print("
			<table align=\"center\" cellpadding=0 cellspacing=4>
			<tr>
			<td>
			Article URL: 
			<a href=\"$str\" class=\"dark\">
			<font size=\"2\">
			https://vunet.net$str
			</font>
			</a>
			</td>
			</tr>
			</table>
			");
	}


#############################################################
skip_past1:

	#
	if(!$so{'printable'} && $ENV{'FRONT_PAGE_MODE'} ne "TRUE" &&
		$so{'COMMENTS_ENABLED'}!=0)
	{
		# Add a possibility to comment the article.
		# COMMENT FORM
		#
		print ("
			<a name=\"comments_form\"></a>
			<form method=get action=\"/comment.pl\">
			Kommentti:<br>
			<textarea rows=5 cols=50 name=\"comment\"></textarea>
			<input type=\"hidden\" name=\"AFN\" value=\"$_[0]\">
			<br>
			Nimi tai nimimerkki: <input type=\"text\" name=\"name\" value=\"Anonyymi\"><br>
			");

		#
		print("Valitse hymiö:<br>");
		@lst = LoadList("smiles.txt");
		loop123: for($i=0; $i<($#lst+1); $i++)
		{
			if($lst[$i] =~ /^\s$/) { last loop123; }
			if($i==0) { $str=" checked"; } else { $str=""; }
			print("
				<input type=\"radio\" name=\"smile\" value=\"$i\"$str>
				<img src=\"$lst[$i]\">
				");
			if(($i%5)==4)
			{
				print("<br>");
			}
		}
		print("
			<br>
			<input type=\"submit\" value=\"Lisää kommentti\">
			</form>
			");
	}


	# Make possible to add comments.
	if(!$so{'printable'} && $VIEW_COMMENTS_ENABLED && $so{'COMMENTS_ENABLED'}!=0 && $ENV{'FRONT_PAGE_MODE'} ne "TRUE")
	{
		# Soft seperator 3.
		print "<hr color=\"D0F0D0\">\n";

		# **** VIEW COMMENTS ****
		if($so{'COMMENTS_ENABLED'}!=0)
		{
			ViewComments($_[0]);
		}
	}

	# Soft seperator 2.
	if(!$so{'printable'} && $so{'COMMENTS_ENABLED'}==0 && $ENV{'FRONT_PAGE_MODE'} ne "TRUE")
	{
#		print "<hr color=\"D0F0D0\"><br>\n";
	}

	#
	if(!$so{'printable'})
	{
		#
		if($ENV{'FRONT_PAGE_MODE'} ne "TRUE")
		{
			# Printable.
			print "<a href=\"/viewarticle.pl?$arz&printable=2\" class=dark>";
			print "<img src=\"$IMAGES_BASE/print.gif\" border=\"0\" alt=\">>\">";
			print " tulosta uutinen";
			print "</a><br>";
	
			# Text only.
			print "<a href=\"/viewarticle.pl?$arz&printable=1&textonly=2\" class=dark>";
			print "<img src=\"$IMAGES_BASE/print.gif\" border=\"0\" alt=\">>\">";
			print " tekstiversio";
			print "</a><br>";
		}

              #
              if( NoTracking() )
              {
		# Soft seperator xxxx.
		if($ENV{'FRONT_PAGE_MODE'} ne "TRUE") { print "<hr color=\"D0F0D0\">\n"; }

		###########################################
		#
		#  ADMINISTRATION ONLY AREA
		#
	
	
		#
		OPENTABLE("#C04040");

		#
		print("
			<center>
			<img src=\"$IMAGES_BASE/administration.gif\">
			</center>
			<br>
			");

		#
		if(!$so{'printable'})
		{
			#
			print $pr;
			ReferenceLinkForm($_[0]);
		}


		#
		print("
			<a href=\"$ADMPATH/remart.pl?file=$arz\">
			<img src=\"$IMAGES_BASE/kori.gif\" alt=\">>\" 
			border=\"0\">
			 poista artikkeli</a><br>
			");

		#
		print("
			<a href=\"$ADMPATH/addimage.pl?$arz\">
			<img src=\"$IMAGES_BASE/paint.gif\" alt=\">>\" 
				border=\"0\">
			 lisää artikkeliin kuva</a><br>
			");
		#
		print("
			<a href=\"$ADMPATH/editart.pl?FILE=$arz\_imageurl.txt&RETURL=/article/$arz\">
			<img src=\"$IMAGES_BASE/paint.gif\" alt=\">>\" 
				border=\"0\">
			 muokkaa kuvan urlia</a><br>
			");


		#
		print("
			<a href=\"$ADMPATH/addquote.pl?$arz\">
			<img src=\"$IMAGES_BASE/editor.gif\" alt=\">>\" 
				border=\"0\">
			 lisää/poista siteeraus (teksti artikkelin oikeaan laitaan)</a><br>
			");


		#
	#	print("
	#		<a href=\"$ADMPATH/mailarticle.pl?$arz\">
	#		<img src=\"$IMAGES_BASE/mailmsg.gif\" alt=\">>\" 
	#		border=\"0\">
	#		postita artikkeli postituslistalle</a><br>
	#		");

		#
		print("
			<a href=\"$ADMPATH/editart.pl?FILE=$arz&BAREHTML=true&PLAIN=true\">
			<img src=\"$IMAGES_BASE/editor.gif\" alt=\">>\" 
				border=\"0\">
			 muokkaa artikkelia</a><br>
			");

		#
#		print("
#			<a href=\"$ADMPATH/editart.pl?FILE=$arz\">
#			<img src=\"$IMAGES_BASE/editor.gif\" alt=\">>\" 
#				border=\"0\">
#			 www-editori</a><br>
#			");

		# Add to the special view.
		#
		print("
			<a href=\"$ADMPATH/promote2.pl?$arz\">
			<img src=\"$IMAGES_BASE/picks.gif\" alt=\">>\" 
			border=\"0\">
			 lisää artikkeli <b>erityisnäkymään</b> tai poista se sieltä</a><br>
			");

		# Add to editor's picks.
		#
		print("
			<a href=\"$ADMPATH/promote.pl?file=$arz\">
			<img src=\"$IMAGES_BASE/picks.gif\" alt=\">>\" 
			border=\"0\">
			 lisää artikkeli <b>poimittuihin</b> tai poista se sieltä</a><br>
			");

		#
		print("
			<a href=\"$ADMPATH/to_frontpage.pl?pick=$arz&type=2\">
			<img src=\"$IMAGES_BASE/picks.gif\" alt=\">>\" 
			border=\"0\">
			 aseta <b>portaalin pääsivuksi</b></a><br>
			");

		# Make article the new main frontpage main article.
		#
		print("
			<a href=\"$ADMPATH/to_frontpage.pl?pick=$arz&type=1\">
			<img src=\"$IMAGES_BASE/promote.gif\" alt=\">>\" 
			border=\"0\">
			 tee artikkelista suomenkielisen etusivun <b>pääjuttu</b></a><br>
			");

		#
	#	print("
	#		<a href=\"/admin/viewarticle.pl?$arz\">
	#		<img src=\"$IMAGES_BASE/fix.gif\" alt=\">>\" border=\"0\">
	#		 hallinnon näkymä</a><br>
	#		");

		#
		print "<a href=\"$ADMPATH/fixart.pl?$arz\">";
		print "<img src=\"$IMAGES_BASE/fix.gif\" alt=\">>\" border=\"0\">";
		print " korjaa rivitys</a>";

		#
		CLOSETABLE("#C04040");		
          }
	}

	##################################################

	#
	print ("
		</div>
		");

	#
	print "</td></tr>\n";

	#
	print "</table>\n";


	##############################################################
	#### TITLE HACKING ###########################################
	#
	$temp = $lines[0];
	$temp =~ s/<br>//i;

	#
#	print("
#		<script language=\"javascript\">
#		document.title = '[VAI] $temp';
#		</script>
#	");
}

###################################################
# Monitors who reads and what.
# For advertising purposes.
###################################################
sub ArticleViewerMonitor
{
	my ($str,$str2,$i,$i2,$uid,$f,$Date);

	#
	$uid = GetUserID();

	#
	$Date = time;

	#
#	open(PIPE, "host -Q $ENV{'REMOTE_ADDR'}|"); @lst = <PIPE>; close(PIPE);
#	$hostname = $lst[0]; chomp $hostname; $hostname =~ s/name: //i;
	$ac = $ARTCAP;
	$ac =~ s/<br>//gi;
	$ac =~ s/\n//g;
	$AGENT = $ENV{'HTTP_USER_AGENT'};
	$AGENT =~ s/ /_/g;
##	$str = ("$Date: User #$uid views article '$ac'. IP=$ENV{'REMOTE_ADDR'} HOST=$hostname AGENT='$AGENT'\n");

	#
	$str = BuildQuickUrl($_[0]);

	#
	open($f, ">>avlog.txt") || die "can't write avlog.txt";
	print $f "$Date\n";
	print $f "$uid\n";
	print $f "$ac\n";
	print $f "$ENV{'REMOTE_ADDR'}\n";
	print $f "$hostname\n";
	print $f "$AGENT\n";
	print $f "$str\n"; # quick url
	print $f "\n";
	close($f);

	#
	return true;
}

#
sub BelowMenu
{
	my ($str);

	#
	WebWalkTo("-content-below-mmenu-");

        #
        $str = GetUserID();
        if( !NoTracking($str) && $ENV{'FRONT_PAGE_MODE'} ne "TRUE" )
	{
		#########################################3
		#### TRACKING FEATURES I/II
		#########################################3

		#
		print "<div align=\"center\">";
		tracker();
		print "</div>";
	}
}

#
sub ArtMon
{
	my ($str);

	#
        $str = GetUserID();
        if( !NoTracking($str) && $ENV{'FRONT_PAGE_MODE'} ne "TRUE" )
	{
		#########################################3
		#### TRACKING FEATURES I/II
		#########################################3

		#
		ArticleViewerMonitor( $arg );
	}
}

# Apply configuration newswire.pl settings.
sub ApplyConfiguration
{
        #
        if( $so{'low_graphics'} ne "true" )
        {
                $WEBINDEX = "webindex2.html";
        }
        else
        {
                $WEBINDEX = "textindex2.html";
        }
}

##########################################################
#
sub ArticleTitle
{
	my ($CAP);

	#
	$CAP = "none";
	if( open($f, $_[0]) )
	{
		$CAP = <$f>;
		$CAP =~ s/<br>//ig;
		$CAP =~ s/\s$//ig;
		close($f);
	}

	#
	print("
		<title>[VUnet.org] $CAP</title>
		");
}

##########################################################
#
sub AlterOptions
{
	my ($i,$i2,$str,$str2,$f,$fn);
	my @Keys = ("icap", "ontop", "NO_FLY_FIX", "full", "dontembed", "COMMENTS_ENABLED");

	#
	$fn = "$_[0]\_imageurl.txt";
	open($f, ">$fn") || die "can't open $fn for writing";
	print $f "$so{'imageurl'}\n";
	for($i=0; $i<($#Keys+1); $i++)
	{
		#
		print $f "$Keys[$i]=$so{$Keys[$i]}\n";
	}
	close($f);
}

##########################################################
#
sub main
{
	#
	if($ARGV[0] eq "") { return(); }

	#
	$DONT_AFFECT_DB = 1;
	ArgLineParse();

	#
	$ENV{'VIEW_THIS_ARTICLE'} = "$ARGV[0]";

	#
	if($ENV{'VIEW_THIS_ARTICLE'} eq "")
	{
		#
		$__arg = $ENV{'QUERY_STRING'};
		#
		@_arg = split("\&", $__arg);
		$arg = $_arg[0];
		$ENV{'VIEW_THIS_ARTICLE'} = $arg;
	}
	else
	{
		$arg = $ENV{'VIEW_THIS_ARTICLE'};
	}

	#
	if($so{'file'} ne "")
	{
		$arg = $so{'file'};
	}

	#
	if( $arg =~ /pub_artikkeli/ || $arg =~ /.*\..*\.txt/ )
	{
	}
	else
	{
		print "<h2>$PROGRAM_NAME error: Invalid request (2: $arg).<br>\n";
		die;
	}

	#
#	if( $arg =~ /\// || $arg =~/\\/ || $arg =~ /\.\./ )
#	{
#		print "<h2>$PROGRAM_NAME error: Invalid request.<br>\n";
#		die;
#	}

	#
	$arg = "$arg";

	# Use dontfix=true on news files.
	#
	if($arg =~ /.*\..*\.txt/)
	{
		#
		$so{'dontfix'} = "TRUE";
	}

	#
	$ENV{'CURSEC'} = PathToSection($arg);
	if($ENV{'CURSEC'} ne "english")
	{
		$ENV{'CURFPSEC'} = "finnish";
	}
	else
	{
		$ENV{'CURFPSEC'} = "english";
	}

	#
	if( $ENV{'FRONT_PAGE_MODE'} eq "TRUE" )
	{
		$ENV{'CURFPSEC'} = "portal";
	}

	#############################################################
	#
	if($so{'cmd'} eq "opch")
	{
		AlterOptions($arg);
	}

	###############################################################################
	#
	@web = OpenWebIndex($WEBINDEX);
	$wherebe = 0;

	###############################################################################
	#

	#
	WebWalkTo("CHOOSE-TITLE1");
	ArticleTitle($arg);
	SkipTo("CHOOSE-TITLE2");

        #
	if(!$so{'printable'})
	{
		WireLogo();
	}

	#
	if($so{'printable'})
	{
		print("
		  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" 
			title=\"Cool\">
		");
	}

	#
	if(!$so{'printable'})
	{
                # add main menu
                #
                if($so{'plainoutfit'} ne "true")
                {
        	        #
			HandleExternal("main-menu", "./mainmenu.pl");
			BelowMenu();
                }
                else
                {
                        WebWalkTo("menusect1001");
                        SkipTo("menusect1002");
                }
	}

	#########################################################################
        # Print until "$_[0]" is found.
	#
	if(!$so{'printable'})
	{
		loop1: for($i=$wherebe,$found=0; $i<($#web+1) && !$found; $i++)
        	{
			if($web[$i] =~ /enterhere_section/i)
			{
				$found=1;
			}
			print $web[$i];
		}
	        $wherebe=$i;
	}

	###############################################################################
	# View the article.
	#

	if(!$so{'printable'})
	{
	                print("
                        <table width=\"600\"
                        cellpadding=\"10\" cellspacing=\"2\">

                        <tr>
                        <td>
                        ");
	}

	ViewArticle( $arg );
	ArtMon( $arg );

	#
	if(!$so{'printable'})
	{
		print("
			</td>

			</tr>
			</table>
			");
	}

	###############################################################################
        # Print until end of the web text.
	#
	if(!$so{'printable'})
	{
	        #
	        WebWalkTo("ALAPALKKITAHAN");
	        #
	        print EndBar();
		#
		HandleRest();
	}

}



