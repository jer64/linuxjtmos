#! /usr/bin/perl
######################################################################
# Basic Calendar                          Version 1.01               #
# Copyright 1999 Frederic TYNDIUK (FTLS)  All Rights Reserved.       #
# E-Mail: tyndiuk@ftls.org                Script License: GPL        #
# Created  05/30/99                       Last Modified 07/15/99     #
# Scripts Archive at:                     https://www.ftls.org/cgi/   #
######################################################################
# Function :                                                         #
# calentar.cgi : print calendar of current month...                  #
# calendar.cgi?MM-YYYY : print calendar of the MM-YYYY (01-2000)     #
# You can use this Script as SSI (Server Side Include) or Not, whith #
# $SSI var.                                                          #
# Your can chose size of tabe border with $Border = Size             #
######################################################################
##################### license & copyright header #####################
#                                                                    #
#                 Copyright (c) 1999 TYNDIUK Frederic                #
#                                                                    #
#  This program is free software; you can redistribute it and/or     #
#  modify it under the terms of the GNU General Public License as    #
#  published by the Free Software Foundation; either version 2 of    #
#  the License, or (at your option) any later version.               #
#                                                                    #
#  This program is distributed in the hope that it will be useful,   #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of    #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     #
#  GNU General Public License for more details.                      #
#                                                                    #
#  You should have received a copy of the GNU General Public License #
#  along with this program in the file 'COPYING'; if not, write to   #
#  the Free Software Foundation, Inc., 59 Temple Place - Suite 330,  #
#  Boston, MA 02111-1307, USA, or contact the author:                #
#                                                                    #
#                              TYNDIUK Frederic <tyndiuk@ftls.org>   #
#                                       <https://www.ftls.org/>       #
#                                                                    #
################### end license & copyright header ###################
######################################################################
# Necessary Variables:                                               #
# The following variables should be set to define the locations      #
# and URLs of various files, as explained in the documentation.      #

# This functionality not usable prior to Perl 5.004
require 5.004;
# Import locale-handling tool set from POSIX module.
# This example uses: setlocale -- the function call
#                    LC_CTYPE -- explained below
use POSIX qw(locale_h);
# query and save the old locale
$old_locale = setlocale(LC_CTYPE);
setlocale(LC_CTYPE, "fi_FI.ISO8859-1");

	#
	$CalCMD = "/usr/bin/cal";  # En: PATH of cal.
	                           # Fr: Chemin de cal.

	$SSI = 1;  # 0 NO SSI (print <HTML><BODY>...</HTML>)
	           # 1 SSI (En: print only Calandar / Fr: N'affiche que le calendrier)

	$Border = 1; # En: Size of table Border.
	             # Fr: Taille des Tables.

	$Days = "Su Ma Ti Ke To Pe La";  # Fi: Days
	#$Days = "Su Mo Tu We Th Fr Sa";  # En: Days
	#$Days = "Di Lu Ma Me Je Ve Sa"; # Fr: Jours en Francais

# Nothing Below this line needs to be altered!                       #
######################################################################

$Query_String = $ENV{QUERY_STRING};
$Query_String =~ s/%([0-9A-F][0-9A-F])/pack("C",oct("0x$1"))/ge;
$Query_String =~ tr/+/ /;

#	print "Content-type: text/html\n\n";
	if (! $SSI) { print "<HTML><HEAD><TITLE>Calendar</TITLE></HEAD><BODY><H1>Calendar</H1>\n"; }
	print &RetCal($CalCMD, $Query_String, $Border);
	if (! $SSI) { print "<BODY></HTML>"; }


# En: Sub routine return calendar.
# Fr: Sous-routine retournant le calendrier.
sub RetCal {
	my($CalCMD, $Args, $Border) = @_;
	my($ret, @Result, $Month, $dy, $line, $no);

	if ( -x "$CalCMD" ) {

		if (($Args !~ /^\d\d?-\d\d\d\d$/) || ($Args eq "")) {
			$Args = "";
			@date = localtime(time); 
			@dt  = localtime(time); 
			($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime(time);
#			$Today = $dt[3];
			$Today = $Day;
		} else {
			$Args =~ s/-/ /g;
		}
	
		open(CAL, "$CalCMD $Args|");
		@Result = <CAL>;
		close(CAL);

		$Month1 = $Month+1;
		$Year1 = $Year + 1900;
		$Month = $Result[0]; shift(@Result);
		$Month =~ s/\s\s\s*//g;
		$ret = ("<TABLE Border=\"$Border\" bgcolor=\"#80E080\">
			<CAPTION ALIGN=\"TOP\"><font size=\"2\"><B>$Day.$Month1.$Year1</B></font></CAPTION>\n
			<TR>");

		shift(@Result);
		foreach $dy (split(/ /, $Days)) {
			$ret .= "<TH><font size=\"1\">$dy</TH>";
		}
		$ret .= "</TR>\n";

		#
		$FS = "<font size=\"1\">";

		foreach $line (@Result) {
			$line =~ s/\n//;
			$line =~ s/   /ccs/g;
			$line =~ s/  /sc/g;
			$line =~ s/ /s/g;
			$line =~ s/^s//g;
			$line =~ s/ss/s/g;
			$line =~ s/c//g;
			$ret .= "<TR>";
			foreach $no (split(/s/, $line))
		{
			# MODIFIED BY JARI TUOMINEN 18.07.2011
			#########################$LINK = "<a href=\"/cal.pl?day=$no&month=$Month1&year=$Year1\" class=\"dark\">";
			$LINK = "<a href=\"https://www.google.fi/#hl=fi&q=$no+$Month+$Year1+ulkomaat+site:vunet.net&oq=17+07+2011+site:vunet.net\" target=\"_blank\">";
			$UNLINK = "</a>";

			#
			if ($no == $Today) {
					# SHOW CURRENT DAY HIGHLIGHTED
					$ret .= "<TD>$FS$LINK<font size=\"2\" style=\"font-weight: bold;\">$no$UNLINK</font></TD>";
			} else {
					# OTHER DAY
					$ret .= "<TD>$FS$LINK$no$UNLINK</TD>";
				}
			}
			$ret .= "</TR>\n";
		}
		$ret .= "</TABLE>\n";
	} else {
		$ret = "Cannot find cal on this system.";
	}
	return $ret;
}
