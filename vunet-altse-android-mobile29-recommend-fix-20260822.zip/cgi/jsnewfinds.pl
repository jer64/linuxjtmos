#!/usr/bin/perl
use utf8;
#############################################################################
# Version Rewrite 2022.
# index.pl - ALTSE text search CGI -frontend for the Internet Search.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);
use Encode;
use DateTime;
use Time::Piece;

#
require "./modules/AltseOpenConfig.pm";
require "./modules/settings.pm";
require "./modules/Logging.pm";
require "./modules/FixScands.pm";
require "./modules/EvalScore.pm";
require "./modules/AltseMenu.pm";
require "./modules/GetDBFileFromURL.pm";
require "./modules/BuildKeywordSuggestionsHTML.pm";
require "./modules/NewContent.pm";
require "./modules/NewSearches.pm";
#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
AltseOpenConfig("1");
#
#AltseOpenConfig();
#
main();

################################################################################
#
sub main
{
	my ($str,$str2);

	#
	if($so{'q'} ne "")
	{
	}

	#
#	$IMGBASE = "$IMAGES_BASE/$GAL";
	if($so{'full'} ne "")
	{
                $str = BuildNewSearchesHTML();
	}
	else
	{
		$str = BuildNewSearchesHTMLCompact();
	}

	#
#	$str = custom_gallery();

        #
        $str =~ s/[\t\n\r\s]/ /g;
        $str =~ s/\"/\\\"/g;
        print(" document.write(\"$str\"); \n");
}

