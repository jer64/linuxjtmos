#!/usr/bin/perl
#use strict;
#use warnings;
use utf8;                       # mahdollistaa UTF-8 string-literaleissa tässä tiedostossa
use open qw(:std :encoding(UTF-8));  # STDIN/STDOUT/STDERR oletuksena UTF-8
use POSIX qw(strftime);

################################################################################
#
# rss.pl - RSS News Feed.
# (C) 2006-2008 by Jari Tuominen (jari@vunet.net).
#
################################################################################

# CGI/HTTP-output kannattaa aina lukita UTF-8:ksi
binmode(STDOUT, ":encoding(UTF-8)");
binmode(STDERR, ":encoding(UTF-8)");

# Send error messages to the user, not system log
open(STDERR, '>&', \*STDOUT) or die "Can't dup STDERR to STDOUT: $!";
$| = 1;

require "./tools.pl";
require "./modules/RSSDump.pm";

our (%so, $BASEURL, $DONT_AFFECT_DB);

print "Content-Type: application/xhtml+xml; charset=UTF-8\n\n";

$DONT_AFFECT_DB = 1;

ArgLineParse();

# Perusasetukset
if (!defined $so{'base'} || $so{'base'} eq '') {
    $BASEURL = "https://vunet.net";
} else {
    $BASEURL = $so{'base'};
}

if (!defined $so{'c'} || $so{'c'} eq '') {
    $so{'c'} = "25";
}

main();

#############################################################################
sub main {
    # Varmistus: sektion arvo voi puuttua
    my $sec = defined $so{'sec'} ? $so{'sec'} : '';
    RSSDump($sec);
}
