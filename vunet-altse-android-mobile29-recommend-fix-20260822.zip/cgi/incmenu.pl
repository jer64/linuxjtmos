#!/usr/bin/perl
use utf8;
##########################################################
# menu.pl - Main menu.
# (C) 2005-2007 Jari Tuominen.
##########################################################
#
require "tools.pl";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
MainMenu();
	
# Types in a html code of 1 pixel height line by using a table.
sub Line1
{
	my ($of);

	#
	$of = $_[0];

	#
        $con = ("$con
                        <table width=\"$_[2]\"
                        cellpadding=\"0\" cellspacing=\"0\">
                        <tr>
                        <td width=\"100%\" bgcolor=\"$_[1]\" height=\"1\">
                        </td>
                        </tr>
                        </table>
                ");
}

# [1] [2] [color scheme, default=0]
sub MenuSection
{
	my ($i,$i2,$i3,$i4,$str,$str2,
		$ac,$ac2,$ac3,$ac4,$ED,$s1,@s,$opt,$active,
		$special,
		$ii,$ii2,$of,$nr,$cs);

	#
	$of = $_[3];

	#
	$menunr++;

	#
	$special = $_[2];

	#
	$s1 = $_[0];

	#
	$ED = 0;
	if($_[0] =~ /\&/)
	{
		$ED = 1;
	}

	#
	$s1 =~ s/\&//g;


	#
	@ml = LoadList($_[1]);

	#
	@sections = LoadList("$NWPUB_CGIBASE/sections.txt");

	##############################################################
	#
	for($i=0,$instant_url=0,$nr=0; $i<($#ml+1); $i++)
	{
		#
		$str2 = "$ml[$i+0]";

		#
		if($str2 =~ /^\-\ /)
		{
			$nr=0;
			$cs = $str2;
			$cs =~ s/^\-\ //;
			if($MAJOR eq "") { $MAJOR=$cs; }
			goto skip;
		}

		# Skip empty lines.
		if($str2 eq "" || $str2=~/^\s*$/)
		{
			goto skip;
		}

		#
		if($cs ne "" && !$nr)
		{
			#
			if($cs ne $MAJOR) { $vari = "#000000"; } else { $vari = "#202020"; }

			# This is the currently selected major section?
			if($cs eq $MAJOR)
			{
				$ICON = "$IMAGES_BASE/SmallArrow.gif";
			}
			else
			{
				$ICON = "$IMAGES_BASE/icon_book.gif";
			}
			if($ENV{'NW_MAJOR'} ne "" && $cs eq $MAJOR)
			{
			 	$vari = "#C06060";
			}
			else
			{
			}

			#
			$con = ("$con
				<table cellpadding=0 cellspacing=0 bgcolor=\"$vari\" width=100%><tr>
				<td width=4%>
				</td>

				<td width=96%>
				<div align=left>
				<!--- <a href=\"/$cs.major\"> --->
				<A HREF=\"$ml[$i+1]\">
				<font size=2 color=#FFFFFF>
			<!--- MAJOR MENU SECTION --->
			<IMG src=\"$ICON\" class=bulletin border=0> $cs</font>
				</A>
				</div>
				</tr></td></table>
				");
		}

		# At this position we require a ':' -char.
		if( !($str2 =~ /[a-zäöå0-9]\:[a-zäöå0-9]/i) )
		{
			goto skip;
		}

		#
		if($cs ne $MAJOR)
		{
			$nr++;
			$i++;
			goto skip;
		}

		#
		$str = $str2;
		@s = split(/:/, $str);
		$str = $s[0];
		#$str =~ s///g;
		$opt = $s[1];
		$imgurl = $s[2];
		$imgurl =~ s/http\/\//http\:\/\//;
		if($s[3] ne "")
		{
			$instant_url = $s[3];
		}
		else
		{
			#
			$instant_url = $ml[$i+1];
		}

		#
		if($instant_url =~ /^\@/)
		{
			if(!NoTracking())
			{
				$i++;
				goto skip;
			}
		}

		#
		$active = 0;

		#
		if(!$ED && $so{'section'} ne "" && $opt ne "" && $opt eq $so{'section'})
		{
			$active = 1;
		}

		#
		if($ED && $opt ne "" && $opt eq $so{'FP_SECTION'})
		{
			$active = 2;
		}
		else
		{
		}

		#
	#	$IMC1 = "TDOVER1";
		$IMC2 = "TDOUT1";

		#
		if($special==0)
		{
			#
			$ACTIVE_COLOR = "#408040";

			if(!$active)
			{
				$ac = $ACTIVE_COLOR;
				$ac2 = "#206020";
			}
			if($active==1)
			{
				$ac = "#F02020";
				$ac2 = "#C02020";
			}
			if($active==2)
			{
				$ac = "#60C060";
				$ac2 = "#406040";
			}

			# Active color on 'onMouseover'.
			$ac3 = "#204060";
		}

		#
		if($special==1 && $s[0]=~/^\!/)
		{
			#
			$str =~ s/^!//;
			#
			$ac4 = "#F0F0F0";
			$ac5 = "#000000";

			#
			$ACTIVE_COLOR = "#404040";

			if(!$active)
			{
				$IMC1 = "";
			#	$IMC2 = "";
				$ac = $ACTIVE_COLOR;
				$ac2 = "#404040";
			}
			if($active==1)
			{
				$ac = "#404040";
				$ac2 = "#404040";
			}
			if($active==2)
			{
				$ac = "#404040";
				$ac2 = "#404040";
			}

			# Active color on 'onMouseover'.
			$ac3 = "#404040";
		}

		#
		if($special==1 && !($s[0]=~/^\!/))
		{
			#
			$ac4 = "#F0F0F0";
			$ac5 = "#000000";

			#
			$ACTIVE_COLOR = "#404040";

			if(!$active)
			{
				$IMC1 = "";
			#	$IMC2 = "";
				$ac = $ACTIVE_COLOR;
				$ac2 = "#C00000";
			}
			if($active==1)
			{
				$ac = "#FFFFFF";
				$ac2 = "#CC6060";
			}
			if($active==2)
			{
				$ac = "#C0C0C0";
				$ac2 = "#404040";
			}

			# Active color on 'onMouseover'.
			$ac3 = "#400000";
		}


		#
		if($special==2)
		{
			#
			$ac4 = "#C0C0C0";
			$ac5 = "#000000";

			#
			$ACTIVE_COLOR = "#505050";

			if(!$active)
			{
				$IMC1 = "";
			#	$IMC2 = "";
				$ac = $ACTIVE_COLOR;
				$ac2 = "#404040";
			}
			if($active==1)
			{
				$ac = "#606040";
				$ac2 = "#585830";
			}
			if($active==2)
			{
				$ac = "#808040";
				$ac2 = "#707030";
			}

			# Active color on 'onMouseover'.
			$ac3 = "#400000";
		}

		#
		if($instant_url =~ /^\@/)
		{
			$instant_url =~ s/^\@//;
		}

		#
		$nr++;
		$MenuItemName = sprintf "menu%d_%d", $menunr, $i;
		Line1($of, "#000000", "100%");
		$con = ("$con
                <TABLE style=\"position: absolute\"
			cellspacing=0 cellpadding=0>
                <tr>
		<td width=98>
		</td>
                <td id=\"$MenuItemName\" width=100>
                </td>
                </tr>
                </TABLE>

			<TABLE
			width=\"100%\"
			cellpadding=\"0\" cellspacing=\"0\">

			");

		#
		if(!$active)
		{
			# Non-active menu item.
			$con = ("$con
				<tr class=\"$IMC1\" bgcolor=\"$ac2\"
				 onMouseout=\"MouseOut1(this, '$ac2', '$ac4', '$MenuItemName', '$IMC1');\"
				 onMouseover=\"MouseOver1(this, '$ac3', '$ac4', '$MenuItemName', '$IMC2');\"
				onClick=\"Clixxor(this, '$instant_url');\">
				");
		}
		else
		{
			# Currently selected menu item.
			$con = ("$con
				<tr class=\"withLink\" bgcolor=\"$ac2\"
					onClick=\"Clixxor(this, '$instant_url');\">
				");
		}

		#
		#	<div class=\"supah\">
		#	<td width=\"12%\" bgcolor=\"$ac\" class=\"\">
		#	</td>

		#
		if($imgurl eq "")
		{
			$BULLETIN_CLASS = "tranz";
		}
		else
		{
			$BULLETIN_CLASS = "tranz2";
		}
		$con = ("$con
			<TD width=0% bgcolor=#000000>
			</TD>

			");

		#
		$con = ("$con
				<TD width=\"100%\"
					onClick=\"Clixxor(this, '$instant_url');\">

				<table cellpadding=0 cellspacing=0>
				<tr>
				<td align=bottom>
				<table cellpadding=0 cellspacing=0 width=12 height=100%
					align=left>
				<tr><td width=100%><BR>
				</td></tr>
				</table>
				");
		if($imgurl ne "")
		{
			$con = ("$con
				<a href=\"$instant_url\" class=\"linkki123\">
				<img src=\"$imgurl\" border=0 alt=\"\" align=\"center\"
					VSPACE=0 HSPACE=4>
				</a>
			");
		}
		$con = ("$con
				<a href=\"$instant_url\" class=\"linkki123\">
				<font size=\"2\" color=\"#FFFFFF\" face=\"Arial\">
				$str
				</font>
				</a>

				</TD>

				</tr>
				</table>

				</td>
			");

		#
		$con = ("$con

			</tr>
			</table>

			");

		#
		if($active==2)
		{
		}

		#
		$i++;
skip:
	}

}

#####################################################################################################
#
sub Vislog
{
        my ($f,$f2,$str,$str2,$t,$pm);

        #
        $t = time;

	#
	$pm = sprintf("%d", $t/86400);

        #
        open($f, ">>logs/vislog-$pm.txt");
	flock $f, LOCK_EX;
        print $f "$t;$ENV{'REMOTE_ADDR'};$ENV{'REMOTE_HOST'};\n";
	flock $f, LOCK_UN;
        close($f);
}

#####################################################################################################
#
sub MainMenu
{
	#
	if($so{'section'} eq "")
	{
		$so{'section'} = $ENV{'MENUSEC'};
		if($so{'MENUSEC'} eq "")
		{
			if($ENV{'CURSEC'} ne "")
			{
				$so{'section'} = $ENV{'CURSEC'};
			}
		}
	}
	$so{'FP_SECTION'} = $ENV{'MENUFPSEC'};

	#
	if( !isRobot($so{'REMOTE_HOST'}) ) { Vislog(); }
	MainMenu1();
}

#
sub TableBeg
{
	$con = ("$con
		<table	bgcolor=\"#004000\"
			cellpadding=\"0\"
			cellspacing=\"0\"
			width=\"100%\">
		<tr>
		<td>
		");
}

#
sub TableEnd
{
	$con = ("$con
		</td>
		</tr>
		</table>
		");
}

#
sub Script
{
	#
	$con = ("$con
		<script language=\"javascript\">

		var testzz=0;

		function MouseOver1(e, color, txt, menuin, CLASS)
		{
			e.className = CLASS;
		}

		function MouseOut1(e, color, txt, menuin, CLASS)
		{
			e.className = CLASS;
		}

		function Clixxor(e, url)
		{
			window.location = url;
		}

		function TextViewer1()
		{
			o = document.getElementById('CCCP');
			if(o)
			{
				o.innerHTML = 'Yahoo!'+testzz/3;
				testzz++;
			}
		}

		</script>

		");
}

#
sub SearchWikipedia
{
	#
	$con = ("$con

	<center>

	<br>

	<div class=\"bright\">
	Dictionary
	  <div>
	    <form name=\"searchform\" action=\"https://en.wikipedia.org/wiki/Special:Search\" id=\"searchform\"
			class=formx>
	      <input accesskey=\"f\" id=\"searchInput\"
		name=\"search\" type=\"text\" size=6 /><br>
	      <input value=\"Go\" type=\"submit\" name=\"go\" />&nbsp;<input value=\"Search\" type=\"submit\" name=\"fulltext\" class=\"searchButton\" />
	    </form>
	  </div>
	</div>

	</center>
		");
}

#
sub palkki
{
	$con = ("$con <div><img src=\"$IMAGES_BASE/palkki.gif\" border=0></div> ");
}

#######################################################################################
#
sub Contains
{
	my ($cs,$i,$i2,$i3,$i4,@lst,$str,@sp);

	#
	@lst = LoadList($_[0]);

	#
	for($i=0; $i<($#lst+2); $i++)
	{
		#
		$str = $lst[$i];

		#
		if($str eq "") { goto skip; }

		#
		if($str =~ /^\-\ /) { $cs=$str; $cs=~s/^\-\ //; goto skip; }

		#
		if($cs ne "" && $str =~ /[a-zäöå0-9]\:[a-zäöå0-9]/i)
		{
			if($str =~ /$_[1]/)
			{
			##	$con = "$con <font color=#FFFFFF>FOUND '$cs' <-> '$_[1]'</font><br>";
				return $cs;
			}
		}

		#
	##	$con "$con $str<br>";
		$i+=1;
skip:
	}

	#
	return "";
}

#######################################################################################
#
sub MenuMajorSection
{
	my ($cs,$i,$i2,$i3,$i4,$found,@sp);

	#
	loop: for($i=0,$found="",$cs=""; $i<($#me+1); $i++)
	{
		#
		@sp = split(" ", $me[$i]);
		if( ($cs=Contains("$_[0]/$sp[1]",$so{'section'})) ) { $found=$cs; last loop; }
	}

	#
	return $found;
}

#######################################################################
#
# BANNERS
#

######### FOREIGN NEWS WIRE #################################
#Wire();

#
sub Wire
{
	#
	$con = ("$con
	<br>
	<table>
		
	<tr><td>
	<font size=\"2\">

	<b>10 most recent foreign news:</b><br>
	<br>
	");

	#
	@l = LoadList("$NWPUB_CGIBASE/linklist.txt");
	
	$con = ("$con
	<a href=\"/addlink.pl\">
	>> add new url
	</a>
	<br>
	<a href=\"/viewall.pl\">
	>> view more news
	</a><br>
	<br>
	");
	
	
	#
	for($i=($#l-1),$co=0; $i>-1 && $co<10; $i-=2,$co++)
	{
		#
                $_tep = $l[$i+1];
                $tep = substr($_tep, 0, 75);
                if( length($_tep) > length($tep) )
                {
                        $tep = "$tep...";
		}
		$tep =~ s/(\S{10})/$1<br>/g;

		#
		$con = ("$con
			<li>
			<a href=\"$l[$i+0]\">\[^]</a>
			$tep
			</li>
			");
	}
	
	#
	
	$con = ("$con
	<center>---</center>
	");
	
	$con = ("$con
	<br>
	<a href=\"/addlink.pl\">
	>> add new url
	</a>
	");
	
	$con = ("$con
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	");

	#
	$con = ("$con

	</font>
	

	</td>
	</tr>
	</table>

	");
}


#######################################################################################
#
sub MainMenu1
{
	#
	my ($i,$i2,$i3,$i4,$pri,$lng,$str,$str2,@sp);

	#
	$con = "";

	#
	Script();

	#
	$con = ("$con
		<script language=\"Javascript\">
		function openURL()
		{
			selInd = document.selector1.select1.selectedIndex;

			goURL = document.selector1.select1.options[selInd].value;

			top.location.href = goURL; 
		}
		</script>
		");


	#######################################################################################
	#

	#
	$lng = $so{'FP_SECTION'};
	
	#
	if($lng eq "english")
	{
		$tx="&News";
	}
	if($lng eq "finnish")
	{
		$tx="&Uutiset";
	}
	if($lng eq "")
	{
		$lng = "finnish";
	}

	#
	if($lng eq "") { goto past; }

	#
	@me = LoadList("$NWPUB_CGIBASE/cfg/$lng/index.txt");

	#
	if($ENV{'NW_MAJOR'} eq "")
	{
		$MAJOR = MenuMajorSection("$NWPUB_CGIBASE/cfg/$lng");
	}
	else
	{
		$MAJOR = $ENV{'NW_MAJOR'};
	}
	if($MAJOR eq "")
	{
		#print "<font color=#FFFFFF>$lng</FONT>";
		$MAJOR = "";
		$so{'section'} = "videoz2";
	}

	#
	for($i=0; $i<($#me+1); $i++)
	{
		#
		@sp = split(" ", $me[$i]);

		# värin määritys
		MenuSection($sp[0], "$NWPUB_CGIBASE/cfg/$lng/$sp[1]", 1, stdout);
	}

	#
#	$con = "$con <BR>";
past:

	#
	$con = ("
<TABLE CELLSPACING=0 CELLPADDING=0 WIDTH=140>
<TR>
<TD>
$con


</TD>
</TR>
</TABLE>
");
	#


	#
#	$con =~ s/[\t\s]/ /g;
#	$con =~ s/  / /g;
#	$con =~ s/\"/\\\"/g;
#	$con =~ s/\'/\\\'/g;
	@lst = split(/[\n|\r]/, $con);

        #
	for($i=0; $i<($#lst+1); $i++)
	{
	        print("$lst[$i]\r\n");	
	}
}

