#!/usr/bin/perl
##############################################################################
#
# top.pl - TOP 50 CHART + "pörssi" (movers).
# rss.pl - RSS News Feed.
# (C) 2006-2012,2024-2026 by Jari Tuominen (jari@vunet.net).
#
##############################################################################

use utf8;

use Encode;
use Encode::Guess;
use HTML::Entities;
use POSIX qw(strftime);

# ---------------------------------------------------------------------------
# Requires (legacy project layout)
# ---------------------------------------------------------------------------
require "./tools.pl";
require "./modules/KeywordsAverage.pm";
require "./modules/ViewArticleLib.pm";

print "Content-Type: text/html; charset=UTF-8\n\n";

# Send error messages to the user, not system log (legacy style)
open(STDERR, '>&STDOUT');
$| = 1;

# Shell helper.
if (($ENV{'HTTP_HOST'} // '') eq '') {
        $ENV{'HTTP_HOST'} = ($ARGV[0] // '');
}

our $CACHE_PATH = "./cache";
our $CGICMD     = "/top/?";
$ENV{'CURSEC'}  = "suosituimmat";

our $fontsz    = 5;
our $fontszcap = 6;

require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/RSSDump.pm";
require "./modules/sql.pm";

AltseSQLConnect();

our $DONT_AFFECT_DB = 1;
ArgLineParse();

our $BASEURL;
if (($so{'base'} // '') eq "") {
        $BASEURL = "https://vunet.net";
} else {
        $BASEURL = $so{'base'};
}

$so{'FP_SECTION'} = "finnish";

our $INTERFACE_ENABLED = 0;
our $FP = "vunet";

if (($so{'blank'} // '') eq "") {
        $INTERFACE_ENABLED = 1;

        if (($ENV{'HTTP_HOST'} // '') =~ /vunet\.net Business/) {
                $FP = "gold";
                OpenWebIndex("./goldindex.html");
        } else {
                $FP = "vunet";
                OpenWebIndex("./webindex2.html");
        }

        WebWalkTo("CHOOSE-TITLE1");
        print JSAdminTools();
        print("<TITLE>TOP 50 - vunet.net</TITLE>");
        print(qq~
<META name="description" content="Top Articles in Vunet">
<META name="keywords" content="top,articles,top50,news,uutiset,vunet">
<META name="owner" content="LST\@vunet.net">
<meta name="author" content="Jari Tuominen, Heikki Sipil&auml;">
<meta name="robots" content="All">
<META name="revisit-after" content="5 days">

<SCRIPT>
function OpenIt(URL)  { window.open(URL, '', 'width=700,height=480'); }
function OpenIt1(URL,W,H) { window.open(URL, '', 'width='+W+',height='+H); }
</SCRIPT>
~);

        SkipTo("CHOOSE-TITLE2");

        WebWalkTo("main-menu");
        if (($ENV{'HTTP_HOST'} // '') =~ /vunet\.net Business/) {
                print inc_gold_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});
        } else {
                print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});
        }

        WebWalkTo("ENTERHERE_SECTION");
} else {
        $INTERFACE_ENABLED = 0;
        OpenWebIndex("./textindex2.html");
        WebWalkTo("ENTERHERE_SECTION");
}

# Max. cache age, in seconds.
our $M_CAGE = 60 * 15;
our $CACHE_STAT_INTERVAL = 60 * 5;

main();

if (($so{'blank'} // '') eq "") {
        WebWalkTo("ALAPALKKITAHAN");
        print EndBar();
        HandleRest();
} else {
        HandleRest();
}

# ---------------------------------------------------------------------------
# Globals used by legacy functions below
# ---------------------------------------------------------------------------
our (@s, @s2, @s3);
our (%top);
our ($AMO, $LOGO, $RSS_SEC, $COMMODITIES);
our ($fn);
our ($CON);

# "Pörssi" maps (rank movement)
our (%prev_rank, %prev_reads, %curr_rank, %curr_reads);
our (%pos1, %pos2);

# ---------------------------------------------------------------------------
# Helpers for "pörssi"
# ---------------------------------------------------------------------------

sub SnapshotFile {
        my ($tli, $fp) = @_;
        $tli = int($tli || 0);
        $fp  = ($fp // 'vunet');
        my $kind = ($fp eq 'gold') ? "gold" : "vunet";
        return "$CACHE_PATH/top50_snapshot_${kind}_${tli}.txt";
}

sub LoadSnapshot {
        my ($path) = @_;
        %prev_rank = ();
        %prev_reads = ();

        return unless $path && -e $path;

        open(my $fh, "<:encoding(UTF-8)", $path) or return;
        while (my $line = <$fh>) {
                chomp $line;
                next if $line =~ /^\s*$/;
                # rank\treads\tarticle
                my ($r, $reads, $art) = split(/\t/, $line, 3);
                next unless defined $art && $art ne "";
                $r     =~ s/\D//g;
                $reads =~ s/\D//g;
                $prev_rank{$art}  = int($r);
                $prev_reads{$art} = int($reads);
        }
        close($fh);
}

sub SaveSnapshot {
        my ($path, $ordered_articles_ref, $reads_ref) = @_;
        return unless $path;

        open(my $fh, ">:encoding(UTF-8)", $path) or return;
        my $rank = 1;
        foreach my $art (@{$ordered_articles_ref}) {
                my $reads = int($reads_ref->{$art} // 0);
                print $fh join("\t", $rank, $reads, $art) . "\n";
                $rank++;
        }
        close($fh);
}

sub ComputeMovementMaps {
        # Build curr maps
        %curr_rank  = ();
        %curr_reads = ();

        for (my $i = 0; $i < @s2; $i++) {
                my $art = $s2[$i];
                my $reads = int($s3[$i] // 0);
                next if !defined $art || $art eq "";
                $curr_rank{$art}  = $i + 1;
                $curr_reads{$art} = $reads;
        }

        # pos1/pos2 are per-article ranks (used by legacy arrow logic)
        %pos1 = ();
        %pos2 = ();
        foreach my $art (keys %curr_rank) {
                $pos1{$art} = $curr_rank{$art};
        }
        foreach my $art (keys %prev_rank) {
                $pos2{$art} = $prev_rank{$art};
        }
}

sub RenderMarketBoardHTML {
        # Buckets
        my (@up, @down, @same, @new);

        foreach my $art (sort { ($curr_rank{$a}||9999) <=> ($curr_rank{$b}||9999) } keys %curr_rank) {
                my $cr = $curr_rank{$art};
                my $pr = $prev_rank{$art};

                if (!defined $pr) {
                        push @new, $art;
                        next;
                }
                if ($cr < $pr) {
                        push @up, $art;
                } elsif ($cr > $pr) {
                        push @down, $art;
                } else {
                        push @same, $art;
                }
        }

        # Render helper: small list
        my $render_list = sub {
                my ($arr_ref, $title) = @_;
                my $out = qq~<b>$title</b><br>~;
                my $lim = 12;
                for (my $i=0; $i<@$arr_ref && $i<$lim; $i++) {
                        my $art = $arr_ref->[$i];
                        my $cr = $curr_rank{$art} // 0;
                        my $pr = $prev_rank{$art};
                        my $delta_txt;

                        if (!defined $pr) {
                                $delta_txt = "NEW";
                        } else {
                                my $d = $pr - $cr; # positive = improved
                                if ($d > 0) { $delta_txt = "+" . $d; }
                                elsif ($d < 0) { $delta_txt = $d; }
                                else { $delta_txt = "0"; }
                        }

                        # create view link
                        my $view = $art;
                        $view =~ s/^\/+//g;
                        my $niceurl = "/viewarticle/?article=" . $view;

                        $out .= qq~<div style="margin:2px 0;">
                                <span style="display:inline-block; width:38px;">#$cr</span>
                                <span style="display:inline-block; width:44px;"><i>$delta_txt</i></span>
                                <a class="dark" href="$niceurl">$view</a>
                        </div>~;
                }
                return $out;
        };

        my $ts = strftime("%d.%m.%Y %H:%M", localtime(time));
        my $scope = ($so{'TLI'} && $so{'TLI'} > 0) ? (int($so{'TLI'}/3600) . "h") : "logi";

        my $html = qq~
        <table width="800" cellspacing="0" cellpadding="8" style="border:1px solid #000; background:#fff;">
        <tr>
        <td colspan="4" style="background:#000; color:#fff;">
                <b>TOP 50 - PÖRSSI</b> <span style="color:#ccc;">($ts, ikkuna: $scope)</span>
        </td>
        </tr>
        <tr valign="top">
        <td width="25%" style="border-right:1px solid #ddd;">
                ~ . $render_list->(\@up, "📈 Nousijat") . qq~
        </td>
        <td width="25%" style="border-right:1px solid #ddd;">
                ~ . $render_list->(\@down, "📉 Laskijat") . qq~
        </td>
        <td width="25%" style="border-right:1px solid #ddd;">
                ~ . $render_list->(\@same, "⏸ Muuttumattomat") . qq~
        </td>
        <td width="25%">
                ~ . $render_list->(\@new, "✨ Tulokkaat") . qq~
        </td>
        </tr>
        </table>
        <br>
        ~;

        return $html;
}

# ---------------------------------------------------------------------------
# Existing functions (fixed where needed)
# ---------------------------------------------------------------------------

sub GetArtTitle {
        my (@lst, $ii, $IMG);

        return if !-e $_[0];

        @lst = LoadList($_[0]);

        my $optfn = ("$_[0]\_options.txt");
        $so{'imageurl'} = "";
        if (-e $optfn) {
                LoadVars($optfn);
        }

        for ($ii = 0; $ii < @lst; $ii++) {
                $lst[$ii] =~ s/<br>//gi;
        }

        $IMG = "";
        if (($so{'imageurl'} // '') ne "") {
                $IMG = $so{'imageurl'};
                $IMG =~ s/^.*\/([^\/]+)$/$1/;
                $IMG = "$IMAGES_BASE/thumb2/th_$IMG";
                $IMG =~ s/\.[a-z]+$/.png/i;
                $IMG = qq~<img src="$IMG" border=0 align=middle>~;
        }

        return ($IMG, $lst[0]);
}

sub ProduceTopTen {
        my (@lst, @srt, $i, $i2, $t, $host, $lhost,
            $url, $lurl, $t_cache,
            $str, $str2);

        my $cage = 0;

        $t_cache = int(time / $CACHE_STAT_INTERVAL);

        $fn = "cache/top50.txt";

        # Build new statistics.
        @lst = GetAvlog($so{'TLI'});

        my $lip = ""; # IMPORTANT: initialize
        for ($i = $#lst - 8, $lurl = "", $lhost = "", $i2 = 0; $i > -1; $i -= 8, $lip = $ip) {
                my $t_now = time;

                # sanity: timestamp must be numeric
                while ($i < $#lst && ( (!defined $lst[$i]) || $lst[$i] eq "" || ($lst[$i] !~ /^[0-9]+$/) )) {
                        $i++;
                }

                next if $i < 0;
                next if (($t_now - $lst[$i+0]) >= (60 * 60 * 24));

                $url  = $lst[$i+5];
                $host = $lst[$i+4];

                my @sp = split(/\:/, ($lst[$i+3] // ""));
                my $ip = $sp[0] // "";

                next if isRobot($host);

                if (
                        ($host ne "" && IsBanned($host)) ||
                        (
                                ($host ne "" && $host eq $lhost && $url eq $lurl) ||
                                ($ip ne "" && $ip eq $lip)
                        )
                ) {
                        next;
                }

                if (defined $lst[$i+6] && $lst[$i+6] =~ /\//) {

                        if (($so{'TLI'} // 0) != 0) {
                                # original logic: time-window limiter
                                if ( ($t_now - ($so{'TLI'}||0)) >= $lst[$i+0] ) {
                                        goto skip;
                                }
                        }

                        $srt[$i2] = $lst[$i+6];
                        $srt[$i2] =~ s/\/\?id=//;
                        $i2++;
                }
skip:
                $lhost = $host;
                $lurl  = $url;
        }

        @srt = sort @srt;

        %top = ();
        for ($i = 0; $i < @srt; $i++) {
                $str = $srt[$i];
                $top{$str}++;
        }

        # Produce list of quick urls strings that begin with chart position:
        # 0000000010 <id=123x123>
        @s = ();
        my $k = 0;
        foreach my $key (keys %top) {
                $s[$k++] = sprintf "%1.10d <$key>", $top{$key};
        }

        @s = sort @s;
}

sub GenTopTenHTML {
        my ($i, $i2, $lpos, $pos, $content);

        $content = "";

        # nav links (admin)
        if (NoTracking() && $INTERFACE_ENABLED) {
                my $tli_day  = 60*60*24;
                my $tli_hour = 60*60;
                my $tli_week = 60*60*24*7;

                $content .= qq~
                <div align=right><a href="$CGICMD?ilman=$so{'ilman'}&TLI=$tli_day" class=news3>> Päivän luetuimmat.</a></div>
                <div align=right><a href="$CGICMD?ilman=$so{'ilman'}&TLI=$tli_hour" class=news3>> Tunnin luetuimmat.</a></div>
                <div align=right><a href="$CGICMD?ilman=$so{'ilman'}&TLI=$tli_week" class=news3>> Viikon luetuimmat.</a></div>
                <div align=right><a href="$CGICMD?ilman=$so{'ilman'}&TLI=" class=news3>> Logihistorian luetuimmat.</a></div>
                ~;
        }

        # show/hide reads toggle (admin only)
        if (NoTracking()) {
                if (($so{'ilman'} // '') ne "ei") {
                        $content .= qq~<div align=right><a href="$CGICMD?ilman=ei&TLI=$so{'TLI'}">> Näytä lukukerrat.</a></div>~;
                } else {
                        $content .= qq~<div align=right><a href="$CGICMD?ilman=kylla&TLI=$so{'TLI'}">> Piilota lukukerrat.</a></div>~;
                }
        }

        my $cage = 0;
        if (NoTracking()) {
                $cage = FileAge($fn);
                $content .= qq~<font size="$fontsz" color="404040"><br>$cage/$CACHE_STAT_INTERVAL</font>~;
        }

        # RSS link block
        my $RSS_FEED_ORDER_HTML = qq~
        <TABLE WIDTH="700" cellspacing="0" cellpadding="4" align="right">
        <TR>
        <TD width="80%"></TD>
        <TD width="20%">
                <a href="/rss/?sec=$RSS_SEC" class=news5>
                <font size="$fontsz">
                        <IMG SRC="/images/icons2/rss_feed_icon_16x16.gif" border=0 align="middle" title="Tilaa TOP" alt=""> Tilaa
                </font>
                </a><BR>
        </TD>
        </TR>
        </TABLE>
        ~;

        $content .= "$RSS_FEED_ORDER_HTML<br>";

        # -------------------------------------------------------------------
        # "Pörssi" board goes here
        # -------------------------------------------------------------------
        $content .= RenderMarketBoardHTML();

        # Main list table
        $content .= qq~<table width="800" cellspacing="4" cellpadding="4">~;

        # write cache file (legacy)
        my $outfn;
        if ($FP eq "vunet") { $outfn = "./cache/top50.txt"; }
        else               { $outfn = "./cache/gold_top50.txt"; }

        if (!open(my $f, ">:encoding(UTF-8)", $outfn)) {
                print qq~<p>can't save cache <b>"$outfn"</b></p>~ if NoTracking();
        }

        for ($i = 0, $i2 = 0; $i2 < $AMO && $i < @s; $i++, $i2++) {
                my $arfn = "$ARTBASE/$s2[$i]";
                $arfn =~ s/([a-z]+)\/story\-([0-9]+)\.html$/$1\/pub_artikkeli$2.txt/i;

                if ($s2[$i] =~ /kummalliset/ || !(-e $arfn)) {
                        $i2--;
                        next;
                }

                # Movement icon + delta
                my $art_key = $s2[$i];
                $pos  = $pos1{$art_key} // 0;
                $lpos = $pos2{$art_key}; # may be undef

                my $indim = ($i2 + 1) . ". ";
                my $delta_txt = "";

                if (!defined $lpos) {
                        $indim = qq~<img src="$IMAGES_BASE/tulokas.gif" border=0 alt="NEW">~;
                        $delta_txt = "NEW";
                } else {
                        if ($pos < $lpos) {
                                $indim = qq~<img src="$IMAGES_BASE/nousija.gif" border=0 alt="UP">~;
                        } elsif ($pos > $lpos) {
                                $indim = qq~<img src="$IMAGES_BASE/laskija.gif" border=0 alt="DOWN">~;
                        } else {
                                # unchanged -> keep as number
                                $indim = ($i2 + 1) . ". ";
                        }

                        my $d = $lpos - $pos; # positive means improved
                        if    ($d > 0) { $delta_txt = "+" . $d; }
                        elsif ($d < 0) { $delta_txt = "" . $d; }
                        else           { $delta_txt = "0"; }
                }

                my $bgc = "#FFF";

                $content .= qq~<tr valign=top bgcolor="$bgc">~;
                $content .= qq~<td width=640 valign=top>~;

                my @comb = GetArtTitle($arfn);
                my $art_title = $comb[1] // "";
                my $art_image = $comb[0] // "";

                # write legacy cache line
                if (defined $f) {
                        my $arfn2 = "$ARTBASE/$s2[$i]";
                        $arfn2 =~ s/([a-z]+)\/story\-([0-9]+)\.html$/$1\/pub_artikkeli$2.txt/i;
                        $arfn2 =~ s/^\///g;
                        print $f sprintf("%1.10d %s\n", ($s3[$i]//0), $arfn2);
                }

                # view URL
                my $view = $s2[$i];
                $view =~ s/^\/+//g;
                $view =~ s/story\-/pub_artikkeli/;
                $view =~ s/\.html/.txt/;
                my $niceurl = "/viewarticle/?article=" . $view;

                if ($art_title ne "") {
                        my $ARTID = $view;
                        $ARTID =~ s/^.*pub_artikkeli([0-9]+).*$/$1/;

                        $so{'section'} = $view;
                        $so{'section'} =~ s/^.*([a-z]+)\/pub_[0-9]+\.[a-z]+$/$1/;
                        $so{'section'} =~ s/^([a-z]+).*$/$1/;

                        my $tex = qq~
                        <table width="110" bgcolor="#FFF" cellspacing="0" cellpadding="0" align="right">
                        <tr><td>
                        <FONT SIZE=3>
                        <div id="imgathumb3_${ARTID}_$so{'section'}">
                        <A HREF="javascript:RenderHtml('imgathumb3_${ARTID}_$so{'section'}','<img src=\\'/cgi/imgathumb.pl?t=1&id=$ARTID&section=$so{'section'}\\'>');" class="dark">
                                <IMG SRC="$IMAGES_BASE/thumb_up.gif" align="middle" border="0"><font size="2"> Suosittele</font>
                                <font size="6">+</font>
                        </A>
                        </div>
                        </td></tr></table>
                        ~;

                        my $reads_html = "";
                        if (NoTracking() && ($so{'ilman'} // '') eq "ei") {
                                $reads_html = qq~ <span style="color:#808080; font-size:12px;">($s3[$i] lukukertaa)</span>~;
                        }

                        $content .= qq~
                        <a href="$niceurl" class="dark">
                                <font size="6">$indim</font>
                                <span style="display:inline-block; width:48px; color:#606060; font-size:14px;"><i>$delta_txt</i></span>
                                $art_image
                                <font size="5">$art_title</font>
                        </a>
                        $reads_html
                        $tex
                        ~;
                }

                $content .= qq~</td></tr>~;

                if (($i2 % 10) == 9 && $i2 != 0) {
                        $content .= qq~
                        <tr><td>
                        <BR><P><div align="center"><hr></div></P><BR>
                        </td><td></td></tr>
                        ~;
                }
        }

        close($f) if defined $f;

        $content .= qq~</table>~;

        if (($so{'blank'} // '') eq "") {
                $content .= qq~
                <P><DIV ALIGN=CENTER>
                <a class="darkul" href="$CGICMD&blank=1">
                        <img border="0" alt=">>" src="/images/print.gif"> Tulostettava versio
                </a>
                </DIV></P>

                <SCRIPT src="https://vunet.net/jsadbar.pl"></SCRIPT>
                <FONT COLOR=RED><B><P>OSTA MAINOSTILAA - uniikki ja vaikutusvaltainen lukijakunta.</P></B></FONT>

                $COMMODITIES
                ~;
        }

        return $content;
}

sub main {
        my ($i, $i2, $str, $str2);

        # Defaults
        if (!defined $so{'TLI'} || $so{'TLI'} eq "") {
                $so{'TLI'} = 60*60*24;
        }

        # Window config
        if (int($so{'TLI'}) == 86400) {
                $AMO  = 20;
                $LOGO = "paivan.jpg";
        } else {
                $AMO  = 50;
                $LOGO = "top50b.jpg";
        }

        # widget
        $COMMODITIES = qq~
<BR>
<div align="center" width="210px" style="font-size:12px">
        <iframe width="210" height="120" src="https://widgets.wallstreetsurvivor.com/WidgetCommodities.aspx?type=e" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>
        <br />
        <a href="https://www.wallstreetsurvivor.com/" target="_top">Play a stock market game</a>
        <br />
        <a href="https://www.wallstreetsurvivor.com/Public/Research/Quotes.aspx?symbol=GOOG" target="_top">Get a stock quote</a>
</div>
~;

        $so{'TLI'} =~ s/[^0-9]//g;

        # Busy guard (fix precedence)
        my $running = IsRunning("top.pl");
        if (!NoTracking() && ($running > 20) && ($so{'MAGIC'} // '') ne "32785782378523758") {
                print("<p>CHART APPLICATION IS BUSY. TRY AGAIN AFTER 60-120 SECONDS.</p>");
                return;
        }

        # -------------------------------------------------------------------
        # Build top list
        # -------------------------------------------------------------------
        ProduceTopTen();

        # Resolve quick urls & read counts
        @s2 = ();
        @s3 = ();

        for ($i = 0, $i2 = 0; $i < @s; $i++, $i2++) {
                # s2 = resolved URL
                $str2 = $s[$i];
                $str2 =~ s/^.*<(.*)>/$1/g;
                $str = ResolveQuickUrl($str2);
                $s2[$i2] = $str;

                # s3 = reads
                $str2 = $s[$i];
                my @sp = split(" ", $str2);
                $s3[$i2] = $sp[0] // 0;
        }

        # reverse so highest first
        @s  = reverse @s;
        @s2 = reverse @s2;
        @s3 = reverse @s3;

        # -------------------------------------------------------------------
        # Snapshot diff for "pörssi"
        # -------------------------------------------------------------------
        my $snap = SnapshotFile($so{'TLI'}, $FP);
        LoadSnapshot($snap);
        ComputeMovementMaps();
        SaveSnapshot($snap, \@s2, \%curr_reads);

        # RSS section label
        if ($FP eq "gold") {
                $RSS_SEC = "_top20_gold&title=vunet.net - 20 SUOSITUINTA ARTIKKELIA";
        } else {
                $RSS_SEC = "_top20&title=vunet.net - 20 SUOSITUINTA ARTIKKELIA";
        }

        my $TOPHTML = GenTopTenHTML();
        my $KEYWORD_HTML = ProduceKeywordsAverageHTML("bright", "4");

        print qq~
<table cellspacing="0" cellpadding="16" width="600">
<tr><td>
        <div align=center>
        <b>
        <P><A HREF="https://$ENV{'HTTP_HOST'}">$ENV{'HTTP_HOST'}</A></P>

        <font size="$fontszcap">
                <FONT COLOR="BLACK">$AMO</FONT> <FONT COLOR=#400000>SUOSITUINTA ARTIKKELIA</FONT>
        </font>
        <br>
        </b>
        <FONT COLOR=#400000 FACE=IMPACT><P><I>Always our top stories</I><B></P></FONT>
        </div>

        <table width="550">
        <tr><td>
                <table width="550" bgcolor="#000000">
                <tr><td>
                        <font size="6" color="yellow"><b>Tagit:</b></font>
                        $KEYWORD_HTML
                </td></tr>
                </table>
        </td></tr>
        </table>

        $TOPHTML
</td></tr></table>
~;
}
