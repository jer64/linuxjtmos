#!/usr/bin/perl
use utf8;
system("/db/sdb/bin/cgi-monitor.pl");
