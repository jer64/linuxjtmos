#!/usr/bin/perl
use utf8;
###############################################################################
# onlinechat.pl - (AJAX version)
###############################################################################

require "./tools.pl";
require "./modules/chat.pm";

$SCRIPT = "/poll/";
$ENV{'CURSEC'} = "onlinechat";

# Interval for fetching a new weather data.
$MAX_DATA_AGE = (60*5);

print "Content-type: text/html; charset=UTF-8\n\n";

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  
$| = 1;

$DONT_AFFECT_DB = 1;
ArgLineParse();

########################################################################
# AJAX MODE
# If called with ?ajax=1 return only chat content
########################################################################
if ($so{'ajax'} && $so{'ajax'} eq '1') {

    print "Content-type: text/html; charset=UTF-8\n";
    print "Cache-Control: no-store, no-cache, must-revalidate, max-age=0\n";
    print "Pragma: no-cache\n\n";

    Keskustelu();
    exit;
}

########################################################################
# NORMAL PAGE LOAD
########################################################################
main();

WebWalkTo("ALAPALKKITAHAN");
print EndBar();
HandleRest();

########################################################################
sub main
{
    ArgLineParse();

    if($ENV{'HTTP_HOST'} =~ /kultakaivos.info/) {
        OpenWebIndex("./goldindex.html");
    } else {
        OpenWebIndex("./webindex2.html");
    }

    WebWalkTo("CHOOSE-TITLE1");

    print("
<TITLE>Vaihtoehtouutiset - ONLINE CHAT</TITLE>
<meta name=\"keywords\" content=\"äänestys, ääni, demokratia, kansanvalta, chat, online chat, chatti\">
");

    SkipTo("CHOOSE-TITLE2");

    ####################################################################
    # MAIN MENU
    ####################################################################
    WebWalkTo("main-menu");

    if($ENV{'HTTP_HOST'} =~ /kultakaivos.info/) {
        print inc_gold_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});
    } else {
        print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});
    }

    ####################################################################
    # CONTENT SECTION
    ####################################################################
    WebWalkTo("ENTERHERE_SECTION");

    print("
    <table width=640 cellpadding=32 cellspacing=0>
    <tr valign=top>
    <td width=80%>

    <div align=center>
        <img src=\"https://vunet.net/images/banners/onlinechat.jpg\" border=0>
    </div>

    <div id=\"chat-container\">
    ");

    Keskustelu();

    print("
    </div>

    <script>
    (function() {

        const container = document.getElementById('chat-container');

        function buildAjaxUrl() {
            let url = window.location.pathname + window.location.search;

            // remove existing ajax=1 if present
            url = url.replace(/([?&])ajax=1(&?)/, '$1').replace(/[?&]$/, '');

            if (url.indexOf('?') === -1) {
                url += '?ajax=1';
            } else {
                url += '&ajax=1';
            }

            return url;
        }

        const ajaxUrl = buildAjaxUrl();
        let inFlight = false;
        let lastHtml = '';

        async function refreshChat() {

            if (inFlight) return;
            inFlight = true;

            try {
                const res = await fetch(ajaxUrl, {
                    method: 'GET',
                    cache: 'no-store',
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });

                if (!res.ok) throw new Error('HTTP ' + res.status);

                const html = await res.text();

                if (html && html !== lastHtml) {
                    container.innerHTML = html;
                    lastHtml = html;
                }

            } catch (e) {
                // Silent fail
            } finally {
                inFlight = false;
            }
        }

        // First load immediately
        refreshChat();

        // Refresh every 3 seconds
        setInterval(refreshChat, 3000);

    })();
    </script>

    ");

    ####################################################################
    # ADS
    ####################################################################
    print("
<script type=\"text/javascript\">
google_ad_client = \"pub-4178289363390566\";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = \"468x60_as\";
google_ad_type = \"text_image\";
google_ad_channel =\"7164719729\";
google_color_border = \"FFFFFF\";
google_color_bg = \"FFFFFF\";
google_color_link = \"C00000\";
google_color_text = \"000000\";
google_color_url = \"008000\";
</script>

<script type=\"text/javascript\"
src=\"https://pagead2.googlesyndication.com/pagead/show_ads.js\">
</script>

    </td>
    <td background=$IMAGES_BASE/saapalkki.jpg>
    <br><br><br>
    </td>
    </tr>
    </table>
    ");
}