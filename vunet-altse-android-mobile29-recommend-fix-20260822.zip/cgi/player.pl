#!/usr/bin/perl
use utf8;

#
require "tools.pl";

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
HandleRest();


##################################################
sub main
{
	#
	$DONT_AFFECT_DB = 1;
        ArgLineParse();

	#
	if($so{'t'} eq "")
	{
		return;
	}

	#
	print ("

<br>
<br>

<center>
<font size=\"4\">Playing $so{'t'}<br>

<FORM name=\"player\">
<EMBED SRC=\"$so{'t'}\" width=320 height=240
	AUTOSTART=\"TRUE\">
<br>

<script>
var embed=document.embeds[0];
</script>
<INPUT type = button 
       value = \"Full Screen\" 
       name = FSBUTTON
       onclick = \"
                  embed.fullScreen();
               \">	
</FORM>
</EMBED>

<br>
<br>

		");

	#
}


