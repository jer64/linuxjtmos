#!/usr/bin/perl
use utf8;

binmode STDOUT, ':encoding(UTF-8)';

my $query = $ENV{'QUERY_STRING'} || '';
my $default_poll = 0;
if($query =~ /(?:^|&)POLL=(\d{1,6})(?:&|$)/i) {
    $default_poll = int($1);
}

print "Content-Type: application/javascript; charset=UTF-8\n";
print "Cache-Control: public, max-age=300\n";
print "X-Content-Type-Options: nosniff\n\n";

print <<"JS";
(function () {
  'use strict';

  var DEFAULT_POLL = $default_poll;
  var REFRESH_MS = 15000;
  var SCRIPT_ELEMENT = document.currentScript;

  function integerPoll(value) {
    var n = Number.parseInt(value || '', 10);
    return Number.isFinite(n) && n > 0 && n <= 999999 ? n : 0;
  }

  function withParams(url, params) {
    var target = new URL(url, window.location.href);
    Object.keys(params).forEach(function (key) {
      if (params[key] !== '' && params[key] !== null && typeof params[key] !== 'undefined') {
        target.searchParams.set(key, params[key]);
      }
    });
    return target.toString();
  }

  function sameOriginPollURL(url, endpoint) {
    try {
      var target = new URL(url, window.location.href);
      var ep = new URL(endpoint, window.location.href);
      return target.origin === window.location.origin && target.pathname === ep.pathname;
    } catch (e) {
      return false;
    }
  }

  function fallbackIframe(root, pollId) {
    var iframeEndpoint = root.dataset.ifpollEndpoint || '/cgi/ifpoll.pl';
    var src = withParams(iframeEndpoint, pollId ? {POLL: pollId} : {});
    root.classList.add('vn-js-poll--fallback');
    root.setAttribute('aria-busy', 'false');
    root.innerHTML = '';
    var iframe = document.createElement('iframe');
    iframe.className = 'vn-ifpoll-frame';
    iframe.src = src;
    iframe.title = 'Vunet.net – Äänestys';
    iframe.loading = 'lazy';
    iframe.setAttribute('referrerpolicy', 'same-origin');
    root.appendChild(iframe);
  }

  function enhance(root) {
    if (root.dataset.vnPollReady === '1') return;
    root.dataset.vnPollReady = '1';

    var endpoint = root.dataset.pollEndpoint || '/poll.pl';
    var pollId = integerPoll(root.dataset.pollId) || DEFAULT_POLL;
    var timer = 0;
    var requestSerial = 0;

    root.setAttribute('role', 'region');
    root.setAttribute('aria-live', 'polite');
    root.setAttribute('aria-busy', 'true');

    function stopLiveRefresh() {
      if (timer) {
        window.clearTimeout(timer);
        timer = 0;
      }
    }

    function scheduleLiveRefresh() {
      stopLiveRefresh();
      if (!root.querySelector('.vn-poll-results')) return;
      timer = window.setTimeout(function tick() {
        if (document.hidden) {
          timer = window.setTimeout(tick, REFRESH_MS);
          return;
        }
        var params = {VIEW: 'TRUE', embed: '1', fragment: '1'};
        if (pollId) params.POLL = pollId;
        load(withParams(endpoint, params), {silent: true});
      }, REFRESH_MS);
    }

    function replaceHTML(html, silent) {
      var update = function () {
        root.innerHTML = html;
        root.classList.add('vn-js-poll--ready');
        root.setAttribute('aria-busy', 'false');
        wireContent();
        scheduleLiveRefresh();
      };

      if (!silent && document.startViewTransition && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        document.startViewTransition(update);
      } else {
        update();
      }
    }

    function load(url, options) {
      options = options || {};
      var serial = ++requestSerial;
      if (!options.silent) root.setAttribute('aria-busy', 'true');

      var fetchOptions = {
        method: options.method || 'GET',
        credentials: 'same-origin',
        cache: 'no-store',
        headers: {
          'Accept': 'text/html',
          'X-Requested-With': 'VunetJSPoll'
        }
      };
      if (options.body) {
        fetchOptions.body = options.body;
        fetchOptions.headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
      }

      return fetch(url, fetchOptions)
        .then(function (response) {
          if (!response.ok) throw new Error('HTTP ' + response.status);
          return response.text();
        })
        .then(function (html) {
          if (serial !== requestSerial) return;
          replaceHTML(html, !!options.silent);
        })
        .catch(function () {
          if (serial !== requestSerial) return;
          stopLiveRefresh();
          fallbackIframe(root, pollId);
        });
    }

    function wireContent() {
      var fragment = root.querySelector('[data-poll-id]');
      if (fragment) pollId = integerPoll(fragment.getAttribute('data-poll-id')) || pollId;

      root.querySelectorAll('form.vn-poll-form').forEach(function (form) {
        form.addEventListener('submit', function (event) {
          event.preventDefault();
          stopLiveRefresh();
          var params = new URLSearchParams(new FormData(form));
          params.set('embed', '1');
          params.set('fragment', '1');
          if (pollId) params.set('POLL', String(pollId));
          load(endpoint, {method: 'POST', body: params.toString()});
        });
      });

      root.querySelectorAll('a[href]').forEach(function (link) {
        if (!sameOriginPollURL(link.href, endpoint)) return;
        link.addEventListener('click', function (event) {
          event.preventDefault();
          stopLiveRefresh();
          var target = new URL(link.href, window.location.href);
          target.searchParams.set('embed', '1');
          target.searchParams.set('fragment', '1');
          if (pollId) target.searchParams.set('POLL', String(pollId));
          load(target.toString());
        });
      });
    }

    var params = {embed: '1', fragment: '1'};
    if (pollId) params.POLL = pollId;
    load(withParams(endpoint, params));
  }

  function boot() {
    var roots = document.querySelectorAll('[data-vn-js-poll]');

    // A single <script src="/cgi/jspoll.pl?POLL=N"></script> is also a valid
    // embed. If no explicit container exists, create a compact one at the
    // script location. PollEmbedHTML() uses the explicit-container form so it
    // can also provide a <noscript> iframe fallback.
    if (!roots.length && SCRIPT_ELEMENT && DEFAULT_POLL) {
      var wrapper = document.createElement('section');
      wrapper.className = 'vn-poll-compact vn-poll-embed vn-poll-embed--auto';
      wrapper.setAttribute('aria-label', 'Vunet.net – Äänestys');
      var root = document.createElement('div');
      root.className = 'vn-js-poll';
      root.setAttribute('data-vn-js-poll', '');
      root.dataset.pollId = String(DEFAULT_POLL);
      root.dataset.pollEndpoint = '/poll.pl';
      root.dataset.ifpollEndpoint = '/cgi/ifpoll.pl';
      root.innerHTML = '<p class="vn-poll-loading" role="status"><span class="vn-poll-loading__dot" aria-hidden="true"></span>Ladataan äänestystä…</p>';
      wrapper.appendChild(root);
      SCRIPT_ELEMENT.parentNode.insertBefore(wrapper, SCRIPT_ELEMENT);
      roots = wrapper.querySelectorAll('[data-vn-js-poll]');
    }

    roots.forEach(enhance);
  }

  window.VunetPoll = window.VunetPoll || {};
  window.VunetPoll.boot = boot;
  window.VunetPoll.enhance = enhance;

  window.addEventListener('message', function (event) {
    if (event.origin !== window.location.origin || !event.data || event.data.type !== 'vn-ifpoll-resize') return;
    document.querySelectorAll('iframe.vn-ifpoll-frame').forEach(function (frame) {
      if (frame.contentWindow !== event.source) return;
      var height = Number.parseInt(event.data.height, 10);
      if (Number.isFinite(height) && height >= 180 && height <= 2400) {
        frame.style.height = height + 'px';
      }
    });
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, {once: true});
  } else {
    boot();
  }
}());
JS
