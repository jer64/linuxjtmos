#!/usr/bin/perl
use utf8;

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "tools.pl";

#
main();

#####################################################################################
#
sub main
{
	#
	print("
		<meta http-equiv=\"refresh\" content=\"0; url=https://kim-jong-il.vunet.net$ENV{'REQUEST_URI'}\">
		");

	#
}
