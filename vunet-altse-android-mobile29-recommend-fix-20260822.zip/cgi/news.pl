#!/usr/bin/perl
use utf8;
#############################################################################
# news.pl - HAKUMAA.ONLINE / ALTSE NEWS GRID
# Responsive/mobile version with shared AltseMenu and external CSS/JavaScript.
#############################################################################

use strict;
use warnings;
use POSIX qw(strftime);
use Encode qw(encode);

require "./modules/AltseOpenConfig.pm";
AltseOpenConfig();
require "./modules/OpenHTMLDocument.pm";
require "./modules/AltseMenu.pm";

# Existing ALTSE globals/functions.
our (%so, $DONT_AFFECT_DB);

$DONT_AFFECT_DB = 1;
ArgLineParse();

$so{'q'} = "HakuMaa.online - Ajankohtaiset uutiset";
$so{'indexnr'} = 0 if !defined($so{'indexnr'}) || $so{'indexnr'} eq "";

print "Content-type: text/html; charset=UTF-8\n\n";

# Preserve the legacy CGI behaviour: diagnostics are visible in the response.
open(STDERR, '>&STDOUT');
$| = 1;
my $oldfh = select(STDOUT); $| = 1; select $oldfh;

# OpenHTMLDocument.pm owns <!DOCTYPE>, <html>, <head> and <body>.
# It always loads /images/altse.css first. These flags add the modern
# menu/news styles and news.js after the legacy base stylesheet.
$so{'load_menu_css'} = 1;
$so{'load_news_css'} = 1;
$so{'load_news_js'}  = 1;
$so{'asset_version'} = '20260821-mobile';

OpenHTMLDocument();
News();
CloseHTMLDocument();

#############################################################################
# Helpers
#############################################################################
sub html_escape
{
    my $s = defined($_[0]) ? $_[0] : "";
    $s =~ s/&/&amp;/g;
    $s =~ s/</&lt;/g;
    $s =~ s/>/&gt;/g;
    $s =~ s/"/&quot;/g;
    $s =~ s/'/&#39;/g;
    return $s;
}


sub url_encode
{
    my $s = defined($_[0]) ? $_[0] : "";
    my $bytes = encode('UTF-8', $s);
    $bytes =~ s/([^A-Za-z0-9\-._~])/sprintf("%%%02X", ord($1))/eg;
    return $bytes;
}

#############################################################################
# HakuMaa.online news page
#############################################################################
sub News
{
    my $HTML_MENU = AltseMenu(1);

    my $current_year_month_day = strftime("%Y/%m/%d", localtime(time));
    my $current_year_month     = strftime("%Y/%m", localtime(time));

    # Default to current month. Only accept YYYY, YYYY/MM or YYYY/MM/DD.
    if(!defined($so{'d'}) || $so{'d'} eq "" || $so{'d'} !~ /^\d{4}(?:\/\d{2}(?:\/\d{2})?)?$/) {
        $so{'d'} = $current_year_month;
    }

    my $date_filter = $so{'d'};
    my $date_html   = html_escape($date_filter);

    print <<"HTML";
<a class="skip-link" href="#newsGrid">Siirry uutisiin</a>
$HTML_MENU

<main class="hakumaa-shell">
    <header class="hm-hero">
        <img class="hm-logo" src="/images/robotnews.png" width="72" height="72" alt="HakuMaa.online">
        <div class="hm-hero-copy">
            <h1>HakuMaa.online - Uutisvirta</h1>
            <p>Ajankohtaisia uutisia ja aiheita Altse-hakuindeksist&auml;. Leve&auml;ll&auml; n&auml;yt&ouml;ll&auml; 5 uutiskorttia rivill&auml;, puhelimella yksi.</p>
        </div>
    </header>

    <section class="hm-toolbar" aria-label="Uutisvirran suodattimet">
        <form class="hm-search" action="/altse/" method="get" role="search">
            <label class="sr-only" for="newsSearch">Hae uutisia</label>
            <input id="newsSearch" type="search" name="q" placeholder="Hae uutisia..." autocomplete="off" autocapitalize="none" spellcheck="false" inputmode="search" enterkeyhint="search">
            <input type="hidden" name="d" value="$date_html">
            <button class="hm-button hm-search-button" type="submit">Hae</button>
        </form>

        <nav class="hm-periods" aria-label="Ajanjakso">
            <a class="hm-button" href="/news/?d=$current_year_month_day">T&auml;n&auml;&auml;n</a>
            <a class="hm-button" href="/news/?d=$current_year_month">T&auml;m&auml; kuukausi</a>
        </nav>

        <div class="hm-filters" role="group" aria-label="Kategoriat">
            <button class="hm-filter" type="button" data-filter="all" aria-pressed="true">Kaikki</button>
            <button class="hm-filter" type="button" data-filter="finland" aria-pressed="false">Suomi</button>
            <button class="hm-filter" type="button" data-filter="world" aria-pressed="false">Maailma</button>
            <button class="hm-filter" type="button" data-filter="economy" aria-pressed="false">Talous</button>
            <button class="hm-filter" type="button" data-filter="tech" aria-pressed="false">Tekniikka</button>
            <button class="hm-filter" type="button" data-filter="geopolitics" aria-pressed="false">Geopolitiikka</button>
        </div>
    </section>

    <div class="hm-status" aria-live="polite">
        <span>Ajanjakso: $date_html</span>
        <span id="visibleCount"></span>
    </div>

    <section class="news-grid" id="newsGrid" aria-label="Uutiskortit">
HTML

    # 60 cards = 12 rows at 5 columns. First desktop row loads eagerly;
    # later frames are lazy-loaded to reduce initial mobile traffic.
    my @feeds = (
        ["Tuoreimmat",              "news",                    "world"],
        ["Suomi - uutiset",         "uutiset",                 "finland"],
        ["Yle",                     "yle.fi",                  "finland"],
        ["Helsingin Sanomat",       "hs.fi",                   "finland"],
        ["Iltalehti",               "iltalehti.fi",            "finland"],
        ["Ilta-Sanomat",            "is.fi",                   "finland"],
        ["MTV Uutiset",             "mtvuutiset.fi",           "finland"],
        ["Kauppalehti",             "kauppalehti.fi",          "economy"],
        ["Talouselama",             "talouselama.fi",          "economy"],
        ["Tekniikka & Talous",      "tekniikkatalous.fi",      "tech"],
        ["Verkkouutiset",           "verkkouutiset.fi",        "finland"],
        ["Suomen Uutiset",          "suomenuutiset.fi",        "finland"],

        ["Reuters",                  "reuters.com",              "world"],
        ["Associated Press",         "apnews.com",               "world"],
        ["BBC",                      "bbc.com",                  "world"],
        ["The Guardian",             "theguardian.com",          "world"],
        ["New York Times",           "nytimes.com",              "world"],
        ["Washington Post",          "washingtonpost.com",       "world"],
        ["Wall Street Journal",      "wsj.com",                  "economy"],
        ["Bloomberg",                "bloomberg.com",            "economy"],
        ["CNBC",                     "cnbc.com",                 "economy"],
        ["CNN",                      "cnn.com",                  "world"],
        ["Fox News",                 "foxnews.com",              "world"],
        ["New York Post",            "nypost.com",               "world"],

        ["Politico",                 "politico.com",             "geopolitics"],
        ["Axios",                    "axios.com",                "world"],
        ["Forbes",                   "forbes.com",               "economy"],
        ["Fortune",                  "fortune.com",              "economy"],
        ["Financial Times",          "ft.com",                   "economy"],
        ["Economist",                "economist.com",            "economy"],
        ["Markets",                  "stock market",             "economy"],
        ["Inflation",                "inflation",                "economy"],
        ["Interest rates",           "interest rates",           "economy"],
        ["Oil & Gas",                "oil gas",                  "economy"],
        ["Gold",                     "gold price",               "economy"],
        ["Bitcoin",                  "bitcoin",                  "economy"],

        ["Technology",               "technology",               "tech"],
        ["Artificial Intelligence",  "artificial intelligence",  "tech"],
        ["OpenAI",                   "OpenAI",                   "tech"],
        ["NVIDIA",                   "nvidia.com",               "tech"],
        ["Microsoft",                "microsoft.com",            "tech"],
        ["Google",                   "google.com",               "tech"],
        ["Apple",                    "apple.com",                "tech"],
        ["Linux",                    "Linux",                    "tech"],
        ["Cybersecurity",            "cybersecurity",            "tech"],
        ["Robotics",                 "robotics",                 "tech"],
        ["Science",                  "science",                  "tech"],
        ["Space",                    "space",                    "tech"],

        ["Donald Trump",             "Donald Trump",             "geopolitics"],
        ["Vladimir Putin",           "Vladimir Putin",           "geopolitics"],
        ["Russia",                   "Russia",                   "geopolitics"],
        ["Ukraine",                  "Ukraine",                  "geopolitics"],
        ["China",                    "China",                    "geopolitics"],
        ["European Union",           "European Union",           "geopolitics"],
        ["NATO",                     "NATO",                     "geopolitics"],
        ["Middle East",              "Middle East",              "geopolitics"],
        ["Iran",                     "Iran",                     "geopolitics"],
        ["Israel",                   "Israel",                   "geopolitics"],
        ["United Nations",           "United Nations",           "geopolitics"],
        ["World economy",            "world economy",            "economy"]
    );

    my $card_nr = 0;
    foreach my $feed (@feeds)
    {
        my ($title, $query, $category) = @$feed;
        $card_nr++;

        my $q = url_encode($query);
        my $d = url_encode($date_filter);

        my $iframe_url = "/altse/?q=$q&iframe=1&max=1&d=$d";
        my $open_url   = "/altse/?q=$q&d=$d";

        my $title_html = html_escape($title);
        my $cat_html   = html_escape($category);
        my $iframe_src = html_escape($iframe_url);
        my $open_href  = html_escape($open_url);
        my $loading    = ($card_nr <= 5) ? "eager" : "lazy";

        print <<"CARD";
        <article class="news-card" data-category="$cat_html">
            <div class="news-card-head">
                <h2 class="news-card-title" title="$title_html">$title_html</h2>
                <a class="news-card-open" href="$open_href">Avaa</a>
            </div>
            <iframe
                class="news-frame"
                src="$iframe_src"
                title="$title_html - uutiset"
                loading="$loading"
                referrerpolicy="strict-origin-when-cross-origin">
            </iframe>
        </article>
CARD
    }

    print <<"HTML";
    </section>

    <noscript>
        <p class="hm-noscript">Kategoriapainikkeiden suodatus tarvitsee JavaScriptin. Kaikki uutiskortit ovat silti luettavissa.</p>
    </noscript>
</main>
HTML
}

1;
