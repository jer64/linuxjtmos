#!/bin/bash
#
# You may add this to the crontab.
#

# vunet.net search cache build
export ALTSE_INDEXNR="4"
export ALTSE_Q="Libya"
./jsquery.pl > cache/vunet.net/libya.js
export ALTSE_Q="Laos"
./jsquery.pl > cache/vunet.net/laos.js
export ALTSE_Q="Vietnam"
./jsquery.pl > cache/vunet.net/vietnam.js
export ALTSE_Q="Kuuba"
./jsquery.pl > cache/vunet.net/kuuba.js
export ALTSE_Q="Kiina"
./jsquery.pl > cache/vunet.net/kiina.js
export ALTSE_Q="Korea"
./jsquery.pl > cache/vunet.net/korea.js
export ALTSE_Q="Fidel Castro"
./jsquery.pl > cache/vunet.net/fidel_castro.js
export ALTSE_Q="Raul Castro"
./jsquery.pl > cache/vunet.net/raul_castro.js

# vunet.net search cache build
export ALTSE_INDEXNR="3"
export ALTSE_Q="Peter SChiff"
./jsquery.pl > cache/vunet.net/peter_schiff.js
export ALTSE_Q="Jim Rogers"
./jsquery.pl > cache/vunet.net/jim_rogers.js
