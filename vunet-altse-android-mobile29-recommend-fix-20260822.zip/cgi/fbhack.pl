#!/usr/bin/perl
use utf8;
#############################################################################
# top20.pl - ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);
use DateTime;
use Time::Moment;
use Time::Piece;

#
require "./modules/AltseOpenConfig.pm";
#require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
#require "./modules/SearchSubModule.pm";
#require "./modules/DirectorySubModule.pm";
require "./modules/OpenHTMLDocument.pm";
require "./modules/AltseMenu.pm";
require "./modules/sql.pm";
#
print "Content-Type: text/html; charset=UTF-8\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# https://ww&#128513;w.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

#
main();

#
sub main
{
	@lst = LoadList("./fbhack.html");
	
	for($i=0; $i<($#lst+1); $i++)
	{
		if($lst[$i] =~/\$\$[a-z0-9]+/)
		{
			my $var = $lst[$i];
			$var =~ s/^.*\$\$([a-z0-9]+).*$/$1/;
			$content = $so{$var};
			#print "<h1>var = $var (\"$content\")</h1>\n";
			$lst[$i] =~ s/\$\$($var)/$content/g;
		}
		print $lst[$i] . "\n";
	}
}
