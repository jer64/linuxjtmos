#!/usr/bin/perl
use utf8;
#
# JAVASCRIPT TOP TEN CHART GENERATOR CGI SCRIPT.
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

###########################################################################################################
#
sub main
{
	my ($i,$i2,$str,$str2,@sp);

        #
	$str = TopTenBar();
        $str =~ s/[\t]/ /g;
        $str =~ s/  / /g;
        $str =~ s/\"/\\\"/g;

	#
	@sp = split(/\n/, $str);
	#
	for($i=0; $i<($#sp+1); $i++)
	{
		if($sp[$i] ne "")
		{
		        print(" document.write(\"$sp[$i]\"); \n");
		}
	}
}

###########################################################################################################
#
sub TopTenBar
{
	my ($i,$i2,$i3,$i4,@lst,$str,$str2,$str3,$fn,$lt,$hits);

	#
	$filter = $so{'q'};
        $xfilter = $so{'n'};
        $secfilter = $so{'s'};

	#
	$so{'t'} =~ s/_/ /g;

	#
	if($so{'c'} ne "")
	{
		$c = $so{'c'};
	}
	else
	{
		$c = 10;
	}

	#
	if($so{'t'} ne "")
	{
		$tit = $so{'t'};
	}
	else
	{
		$tit = "Most Popular Articles on Vunet.org";
	}

	#
	$str3 = ("$str3
<TABLE width=300 cellspacing=0 cellpadding=0>
<TR>
<TD>

<DIV ALIGN=CENTER>
<FONT SIZE=3>
<b>
<i>
$tit
</i>
</b>
</FONT>
</DIV>

</TD>
</TR>
</TABLE>
<BR>

		");

	#
	@lst = LoadList("topten.txt");

	# Get total hit count.
	for($i=0,$hits=0; $i<($#lst+1); $i++)
	{
		$str = $lst[$i];
		$str =~ s/^([0-9]*) .*$/$1/;
		$hits += $str;
	}

	#
	$str3 = ("$str3
<TABLE width=300 cellspacing=0 cellpadding=0>
<TR>
<TD>
<DIV align=center>
<!---Total $hits to articles so far.-->
</DIV>
</TD>
</TR>
</TABLE>

<TABLE width=300 cellspacing=0 cellpadding=0>
<TR>

<TD width=50 bgcolor=#A0A0A0>

<DIV ALIGN=CENTER>
<B>pos</B>
</DIV>
</TD>

<TD width=200 bgcolor=#A0A0A0>
article title
</TD>

<TD width=50 bgcolor=#A0A0A0>
<DIV ALIGN=CENTER>
<FONT COLOR=#FFFFFF size=2>
<B>score</B>
</FONT>
</DIV>
</TD>

</TR>
</TABLE>

		");

	#
	$lt = time;
	loop: for($i=0,$rp=0; $rp<$c && $i<($#lst+1); $i++)
	{
		#
		$t = time;
		if( ($t-$lt) >= 3 )
		{
			last loop;
		}

		#
		if($secfilter ne "" && !($lst[$i]=~/$secfilter/i))
		{
			goto past;
		}

		#
		$num = $rp+1;

		#
		$fn = $lst[$i];
		$fn =~ s/^[0-9]* //;
		$fn = "$fn.txt";

		#
		if(-e $fn)
		{
			@art = LoadList($fn);
			$cap = $art[0];
			$cap =~ s/<[^\>]*>//g;
			$score = $lst[$i];
			$score =~ s/^([0-9]*) .*$/$1/;
			$score = sprintf "%d", $score;
			$url = $fn;
			$url =~ s/pub_artikkeli/story-/;
			$url =~ s/\.txt$/.html/;
		}

		#
		if($filter ne "" && !($cap=~/$filter/i))
		{
			goto past;
		}
		#
		if($xfilter ne "" && ($cap=~/$xfilter/i))
		{
			goto past;
		}

		#
		if($rp<10)
		{
			$titbg = "#E0E0E0";
		}
		else
		{
			$titbg = "#C0C0C0";
		}

		#
		$str3 = ("$str3
<TABLE width=300 height=1 cellspacing=0 cellpadding=0 bgcolor=#000000>
<TR>
<TD>
</TD>
</TR>
</TABLE>

<TABLE width=300 cellspacing=0 cellpadding=0>
<TR>

<TD width=50 bgcolor=#FF0000>
<DIV ALIGN=CENTER>
<B>$num</B>
</DIV>
</TD>

<TD width=200 bgcolor=$titbg>

<TABLE width=100% cellpadding=4 cellspacing=0>
<TR>
<TD>
<FONT SIZE=2 face=\"Times Roman\">
<A HREF=\"https://vunet.net/$url\" class=dark>
$cap
</A>
</FONT>
</TD>
</TR>
</TABLE>

</TD>

<TD width=50 bgcolor=#0000FF>
<DIV ALIGN=CENTER>
<FONT COLOR=#C0C0C0 size=1>
<B>$score</B>
</FONT>
</DIV>
</TD>

</TR>
</TABLE>

			");

		#
		$rp++;
past:
	}

	#
	return $str3;
}


