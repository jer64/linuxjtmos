#!/usr/bin/perl
use utf8;
#############################################################
#
# Change to text version.
#
#############################################################

#
require "admin.pl";

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
main();

#################################################
sub main
{
	$so{'low_graphics'} = "true";
	SaveProfile(GetUserID());
        #
        print "<meta http-equiv=\"refresh\" content=\"0; url=newswire.pl\">\n";
}

#


