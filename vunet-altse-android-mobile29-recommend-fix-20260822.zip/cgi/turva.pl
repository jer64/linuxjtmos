#!/usr/bin/perl
use utf8;

#
require "tools.pl";

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();


########################################################################################
#
sub main
{
	#
	print("
		<table width=700 cellpadding=2 cellspacing=0 bgcolor=\"#000000\" align=center>
		<tr>
		<td>

		<table width=698 cellpadding=0 cellspacing=0 bgcolor=\"#FFFFFF\">
		<tr>
		<td>
		<img src=\"$IMAGES_BASE/turva.gif\">
		");

	#
	@lst = LoadList("turva/huomio.txt");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		print "$lst[$i]<br>\n";
	}

	#
	print("
		</td>
		</tr>
		</table>

		</td>
		</tr>
		</table>
		");
}


