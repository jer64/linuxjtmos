#!/usr/bin/perl
use utf8;

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "./admin.pl";

#
use Time::localtime;
use File::stat;

#
main();

#
sub main
{
	#
	print("
		<meta http-equiv=\"REFRESH\"
		content=\"0;url=/TopTen/\">
		");
}
