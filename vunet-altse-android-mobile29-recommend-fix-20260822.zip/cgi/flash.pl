#!/usr/bin/perl
use utf8;
###############################################################################$
#
# VUNET.org FRONT PAGE
#
###############################################################################$

#
use locale;
require "tools.pl";

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Search arguments line for options.
#$DONT_AFFECT_DB = 1;
ArgLineParse();

#
@fl = LoadList("flash.html");
print @fl;
