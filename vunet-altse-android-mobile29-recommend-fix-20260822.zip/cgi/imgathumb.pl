#!/usr/bin/perl
use utf8;
use strict;
use warnings;
use Fcntl qw(:DEFAULT :flock SEEK_SET);
use Encode qw(decode FB_DEFAULT);
use JSON::PP qw(encode_json);

# Vunet article recommendation endpoint.
# Legacy mode returns a GIF so old <img src="..."> callers keep working.
# Modern mode (?ajax=1 or POST ajax=1) returns JSON for fetch()-based buttons.

binmode STDIN;
binmode STDOUT;

sub _url_decode {
    my ($s) = @_;
    $s = '' if !defined $s;
    $s =~ tr/+/ /;
    $s =~ s/%([0-9A-Fa-f]{2})/pack('C', hex($1))/eg;
    return decode('UTF-8', $s, FB_DEFAULT);
}

sub _params {
    my $raw = '';
    if (uc($ENV{'REQUEST_METHOD'} // 'GET') eq 'POST') {
        my $len = int($ENV{'CONTENT_LENGTH'} // 0);
        $len = 0 if $len < 0;
        $len = 16384 if $len > 16384;
        read(STDIN, $raw, $len) if $len > 0;
    } else {
        $raw = $ENV{'QUERY_STRING'} // '';
    }

    my %p;
    for my $pair (split /&/, $raw) {
        next if $pair eq '';
        my ($k, $v) = split /=/, $pair, 2;
        $k = _url_decode($k);
        $v = _url_decode($v);
        $p{$k} = $v;
    }
    return %p;
}

sub _send_json {
    my ($status, $obj) = @_;
    $status ||= '200 OK';
    print "Status: $status\r\n" if $status ne '200 OK';
    print "Content-Type: application/json; charset=UTF-8\r\n";
    print "Cache-Control: no-store, max-age=0\r\n";
    print "X-Content-Type-Options: nosniff\r\n\r\n";
    print encode_json($obj);
    exit 0;
}

sub _gif_bytes {
    my @candidates = grep { defined($_) && $_ ne '' } (
        (($ENV{'DOCUMENT_ROOT'} // '') ne '' ? "$ENV{'DOCUMENT_ROOT'}/thumb_up_c.gif" : ''),
        (($ENV{'DOCUMENT_ROOT'} // '') ne '' ? "$ENV{'DOCUMENT_ROOT'}/images/thumb_up_c.gif" : ''),
        (($ENV{'DOCUMENT_ROOT'} // '') ne '' ? "$ENV{'DOCUMENT_ROOT'}/images/thumb_up.gif" : ''),
        '/home/vai/altse/html/www/thumb_up_c.gif',
        '/home/vai/altse/html/www/images/thumb_up.gif',
    );

    for my $fn (@candidates) {
        next unless -f $fn;
        if (open my $fh, '<:raw', $fn) {
            local $/;
            my $bytes = <$fh>;
            close $fh;
            return $bytes if defined $bytes && length $bytes;
        }
    }

    # Valid 1x1 transparent GIF fallback.
    return pack('H*', '47494638396101000100800000ffffff00000021f90401000000002c00000000010001000002024401003b');
}

sub _send_gif {
    print "Content-Type: image/gif\r\n";
    print "Cache-Control: no-store, max-age=0\r\n";
    print "X-Content-Type-Options: nosniff\r\n\r\n";
    print _gif_bytes();
    exit 0;
}

my %p = _params();
my $ajax = (($p{'ajax'} // '') eq '1' || ($p{'format'} // '') eq 'json') ? 1 : 0;

# Referer is an optional hint only. Privacy-conscious browsers may omit it.
my $ref = $ENV{'HTTP_REFERER'} // '';
if ($ref ne '' && $ref !~ m{^https?://(?:[^/]+\.)?(?:vunet\.net|incoronation\.com)(?::\d+)?(?:/|$)}i) {
    _send_json('403 Forbidden', { ok => JSON::PP::false, error => 'forbidden-origin' }) if $ajax;
    _send_gif();
}

my $section = lc($p{'section'} // '');
$section =~ s/[^a-z]//g;
my $id_raw = $p{'id'} // '';
$id_raw =~ s/[^0-9,]//g;
my ($article_id) = split /,/, $id_raw, 2;
my $thumb_type = ($p{'t'} // '1') =~ /^0$/ ? 0 : 1;

if ($section eq '' || !defined($article_id) || $article_id !~ /^\d+$/) {
    _send_json('400 Bad Request', { ok => JSON::PP::false, error => 'invalid-article' }) if $ajax;
    _send_gif();
}

my $ip = $ENV{'REMOTE_ADDR'} // '';
$ip =~ s/[^0-9A-Fa-f:.]//g;
$ip = '0.0.0.0' if $ip eq '';

my @article_roots;
push @article_roots, $ENV{'ARTBASE'} if ($ENV{'ARTBASE'} // '') ne '';
push @article_roots, "$ENV{'DOCUMENT_ROOT'}/articles" if ($ENV{'DOCUMENT_ROOT'} // '') ne '';
push @article_roots, '/home/vai/altse/html/www/articles';
push @article_roots, '/home/vai/public_html/articles';

my $article_root = '';
for my $root (@article_roots) {
    next unless defined $root && $root ne '';
    if (-d "$root/$section") {
        $article_root = $root;
        last;
    }
}

if ($article_root eq '') {
    _send_json('404 Not Found', { ok => JSON::PP::false, error => 'section-not-found' }) if $ajax;
    _send_gif();
}

my $fn = "$article_root/$section/pub_artikkeli$article_id.txt_thumbs.txt";

sysopen(my $fh, $fn, O_RDWR | O_CREAT, 0666) or do {
    _send_json('500 Internal Server Error', { ok => JSON::PP::false, error => 'cannot-open-votes' }) if $ajax;
    _send_gif();
};
flock($fh, LOCK_EX) or do {
    close $fh;
    _send_json('500 Internal Server Error', { ok => JSON::PP::false, error => 'cannot-lock-votes' }) if $ajax;
    _send_gif();
};

seek($fh, 0, SEEK_SET);
local $/;
my $raw = <$fh>;
$raw = '' if !defined $raw;
my @lines = split /\n/, $raw, -1;
my $opt = shift(@lines) // '';
$opt =~ s/intlfox//g;
$opt =~ s/<[^>]*>//g;
$opt =~ s/^\s+|\s+$//g;

my $already = 0;
$already = 1 if $opt =~ /(?:^|\s)userid=\Q$ip\E(?:\s|$)/;
$already = 1 if $opt =~ /(?:^|\s)t[01],\Q$ip\E(?:\s|$)/;

if (!$already) {
    my $token = "t$thumb_type,$ip";
    $opt = $opt eq '' ? $token : "$token $opt";

    seek($fh, 0, SEEK_SET);
    truncate($fh, 0);
    print {$fh} $opt, "\n";
    # Preserve legacy extra lines, but avoid adding a synthetic trailing blank line.
    while (@lines && $lines[-1] eq '') {
        pop @lines;
    }
    print {$fh} join("\n", @lines), "\n" if @lines;
}

flock($fh, LOCK_UN);
close $fh;

my $count = () = $opt =~ /(?:^|\s)t1,[^\s]+/g;

if ($ajax) {
    _send_json('200 OK', {
        ok      => JSON::PP::true,
        already => $already ? JSON::PP::true : JSON::PP::false,
        count   => 0 + $count,
        id      => 0 + $article_id,
        section => $section,
    });
}

_send_gif();
