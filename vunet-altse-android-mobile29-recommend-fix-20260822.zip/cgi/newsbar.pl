#!/usr/bin/perl
use utf8;
###################################################################
#
# Standalone News Bar.
#
###################################################################

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "tools.pl";

#
main();


##################################################
sub main
{
		#
		print("
<!doctype html>
<html>

<head>
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
</head>

<body>



<table width=640>
<tr>
<td>


			");

                ############################################################################################
                #
                # ADD NEWS HERE
                #
                open(CAL, "./newsbar1.pl|");
                @cal = <CAL>;
                close(CAL);
                print @cal;

		#
		print("

</td>
</tr>
</table>

</body>
			");
}


