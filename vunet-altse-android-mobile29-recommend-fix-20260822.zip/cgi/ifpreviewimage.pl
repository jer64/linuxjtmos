#!/usr/bin/perl
use utf8;
###############################################################################
# Weather Forecast Viewer.
###############################################################################

#
require "./tools.pl";

#
ArgLineParse();

# Interval for fetching a new weather data.
$MAX_DATA_AGE = (60*5);

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log.
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

########################################################################
#
sub main
{
	#
	if($so{'q'}=~/^www\./)
	{
		$so{'q'} = "https://$so{'q'}";
	}

	#
	print("
<A HREF=\"Javascript:window.close();\">
SULJE IKKUNA / CLOSE WINDOW
</A>
<BR>
<IMG SRC=\"$so{'q'}\" width=\"540\" height=\"400\">
");

	#
}

#
