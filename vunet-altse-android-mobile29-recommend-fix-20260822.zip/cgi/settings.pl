#!/usr/bin/perl
use utf8;
#
# settings.pl
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
print("
            <meta http-equiv=\"refresh\" content=\"0; url=https://www.coolpages.tk\">
                      ");
exit;

#
LoadUser();
#
if($so{'t'} eq "register")
{
	print("
             <meta http-equiv=\"refresh\" content=\"0; url=/register.pl\">
                       ");
	exit;
}
if($so{'t'} ne "register" && $so{'user_login_ip'} ne $ENV{'REMOTE_ADDR'})
{
	print("
             <meta http-equiv=\"refresh\" content=\"0; url=/register.pl?t=register\">
                       ");
	exit;
}

#
$fp = "english";
if($ENV{'NW_LANGUAGE'} eq "fi")
{
	$fp = "finnish";
}

#
OpenWebIndex("./webindex2.html");
WebWalkTo("main-menu");
if($so{'t'} ne "register")
{
	print inc_menu("settings", $fp);
}
else
{
	print inc_menu("register", $fp);
}

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


#####################################################################################
#
sub EnvList
{
        foreach $key (sort(keys %ENV))
        {
                print "<b>$key</b>=\"$ENV{$key}\"<br>\n";
        }
}

###########################################################################################
#
# Save user profile.
#
sub LoadUser
{
        my ($key,$pfn,$key,@lst,$i,$i2,$i3,$i4,$str,$str2);

	#
	$pfn = $so{'q'};
	if($pfn eq "") { $pfn = $so{'cookie_nick'}; }
	$pfn =~ s/[^a-zA-Z0-9\._\-\ ]/_/g;
	$pfn = "users/$pfn.profile";

	#
	if( !(-e $pfn) ) { return; }

	#
	@lst = LoadList($pfn);

        #
        for($i=0; $i<($#lst+1); $i++)
        {
		@sp = split(/\=/, $lst[$i]);
		$sp[0] =~ s/^cookie_/user_/;
		$so{$sp[0]} = $sp[1];
        }

	#
}

###########################################################################################
#
# Save user profile.
#
sub SaveUser
{
        my ($key);

        #
        $so{'lastaccessdate'} = time;

        #
        open(f, ">users/$profile\.profile") || die "error while creating user profile, please contact lst\@vunet.net\n";
        #
        foreach $key (keys %so)
        {
                if($key=~/^cookie_/)
                {
                    print f "$key=$so{$key}\n";
                }
        }
        #
        foreach $key (keys %so)
        {
                if($key=~/^user_/)
                {
                    print f "$key=$so{$key}\n";
                }
        }
        close(f);
}

###########################################################################################################
#
# You can't register newly with already existing profile.
#
sub RegCheck
{
	my ($np);

	#
	$np = $so{'set_nick'};
	$np =~ s/[^A-Za-z0-9]//g;
	if($profile eq "" && -e "users/$np.profile")
	{
		# Check failed.
		return 0;
	}

	# Checks fine.
	return 1;
}

###########################################################################################################
#
sub main
{
	@langs = ("English", "Suomi", "Svenska");
	my ($i,$i2,$str,$str2,@sp,@lst,$fn);

	#
	if($so{'done'} eq "" && $so{'cookie_nick'} ne "")
	{
		$fn = $so{'cookie_nick'};
		$fn =~ s/[^A-Za-z0-9]//g;
		LoadVars("users/$fn.profile");
	}

	#
	if( $ENV{'NW_LANGUAGE'} eq "en" )
	{
		$already_registered = "someone has already registered the profile name";
		$nick = "nickname";
		$realname = "name/family name (voluntary)";
		$email = "e-mail";
		$website = "website";
		$sex = "sex";
		$asetukset = "settings";
		$valitse_kieli = "select language";
		$valitse_kuva = "select picture";
		$tallenna = "save settings";
		$asetukset_tallennettu = "settings saved";
		$com_tip = "used in your comments";
		$registered = "you are registered, you can now view communities!";
		$register_now = "Register Now";
	}
	if( $ENV{'NW_LANGUAGE'} eq "fi" )
	{
		$already_registered = "profiilinimi on jo käytössä";
		$nick = "nimimerkki";
		$realname = "nimi/sukunimi (vapaaehtoinen)";
		$email = "sähköposti";
		$website = "webbisivut";
		$sex = "sukupuoli";
		$asetukset = "asetukset";
		$valitse_kieli = "valitse kieli";
		$valitse_kuva = "valitse kuva";
		$tallenna = "tallenna asetukset";
		$asetukset_tallennettu = "asetukset tallennettu";
		$com_tip = "käytetään kommenteissasi";
		$registered = "Olet rekisteröitynyt onnistuneesti, voit nyt katsoa yhteisösivuja!<BR>Klikkaa tästä!";
		$register_now = "Liity Vunetin yhteisöihin ilmaiseksi!";
	}
	if( $ENV{'NW_LANGUAGE'} eq "se" )
	{
		$already_registered = "someone has already registered the profile name";
		$nick = "nickname";
		$realname = "name/family name (voluntary)";
		$email = "e-mail";
		$website = "website";
		$sex = "sex";
		$asetukset = "settings";
		$valitse_kieli = "select language";
		$valitse_kuva = "select picture";
		$tallenna = "save settings";
		$asetukset_tallennettu = "settings saved";
		$com_tip = "used in your comments";
		$registered = "you are registered, you can now view communities!";
		$register_now = "Register Now";
	}
	if($so{'t'} eq "register")
	{
		$cap = $register_now;
	}
	else
	{
		$cap = $asetukset;
	}

	#
	$profile = $so{'cookie_nick'};
	$profile =~ s/[^A-Za-z0-9]//g;
	$so{'cookie_nick'} = $profile;

	#
	print("
<SCRIPT LANGUAGE=\"Javascript\">
function SetCookie(cookieName,cookieValue,nDays) {
 var today = new Date();
 var expire = new Date();
 if (nDays==null || nDays==0) nDays=1;
 expire.setTime(today.getTime() + 3600000*24*nDays);
 document.cookie = cookieName+\"=\"+escape(cookieValue)
                 + \";expires=\"+expire.toGMTString();
}
</SCRIPT>
		");

	print("
<TABLE width=100% BGCOLOR=#000000 CELLSPACING=0 CELLPADDING=0>
<TR>
<TD>
<TABLE width=640 cellspacing=0 cellpadding=32>
<TR>
<TD>
		");

	#
	if($so{'set_profile_image'} ne "")
	{
			print("
<SCRIPT LANGUAGE=\"Javascript\">
SetCookie('profile_image', '$so{'set_profile_image'}',	120);
</SCRIPT>
			");		
	                #
	                print("
	                <meta http-equiv=\"refresh\" content=\"0; url=/settings.pl?done=1\">
	                        ");
			goto past;
	}

	#
	if($so{'set_nick'} ne "")
	{
		if( RegCheck() )
		{
			print("
<SCRIPT LANGUAGE=\"Javascript\">
SetCookie('language', '$so{'set_language'}',	120);
SetCookie('nick', '$so{'set_nick'}',		120);
SetCookie('realname', '$so{'set_realname'}',	120);
SetCookie('email', '$so{'set_email'}',		120);
SetCookie('website', '$so{'set_website'}',	120);
SetCookie('sex', '$so{'set_sex'}',		120);
</SCRIPT>
			");

	                #
	                print("
	                <meta http-equiv=\"refresh\" content=\"0; url=/settings.pl?done=1\">
	                        ");
			goto past;
		}
		else
		{
			print("
			<blink><font color=red>$already_registered: <b>$so{'set_nick'}</b></font></blink>
				");
		}
	}

	#
	if($so{'cookie_profile_image'})
	{
		$image_html = ("
<IMG SRC=\"$IMAGES_BASE/thumb/th_$so{'cookie_profile_image'}\">
<BR>
				");
	}

	#
	print("
<DIV ALIGN=CENTER><FONT SIZE=6 class=caps>
$cap
</FONT>
<BR>

<FONT size=5>$so{'cookie_nick'}</FONT><BR>

$image_html
</DIV>
	");

	#
	if($so{'done'}==1)
	{
		SaveUser();
		print("
<h2><i>$asetukset_tallennettu ($profile) !</i></h2><BR><BR>
			");
	}

	#
	print("

<FONT SIZE=5>
$valitse_kieli
</FONT>
		");

	#
	print("
<FORM action=\"/settings.pl\" method=post>
<select name=set_language>
	");
	for($i=0; $i<($#langs+1); $i++)
	{
		$sel=""; if($so{'cookie_language'} eq $langs[$i]) { $sel=" selected"; }
		print "<option$sel>$langs[$i]</option>\n";
	}
	print("
</select>
		");

	#
	$dis = "<INPUT TYPE=TEXT NAME=set_nick value=\"$so{'cookie_nick'}\" size=10 $dis>";
	if($so{'cookie_nick'} ne "")
	{
		print("
<BR>
<BR>
<FONT SIZE=5>
<A HREF=\"https://vunet.net/images.pl?q=&r=/settings.pl?set_profile_image^\" class=news2>> $valitse_kuva</a>
</FONT>
<BR>
		");

		$dis = "<INPUT TYPE=hidden NAME=set_nick value=\"$so{'cookie_nick'}\"> <b>$so{'cookie_nick'}</b>";
	}

	#
	print("
<BR>
$nick: $dis ($com_tip)<BR>
$realname: <INPUT TYPE=TEXT NAME=set_realname value=\"$so{'cookie_realname'}\" size=40><BR>
$email: <INPUT TYPE=TEXT NAME=set_email value=\"$so{'cookie_email'}\" size=20><BR>
$website (URL): <input type=text name=set_website value=\"$so{'cookie_website'}\" size=30><BR>
$sex: <select name=set_sex value=\"$so{'cookie_sex'}\">");
	if($so{'cookie_sex'} eq "male") { $o1 = "selected"; } else { $o2 = "selected"; }
	print("
<option $o1>male</option>
<option $o2>female</option>
</select><BR>
<BR>
<input type=submit value=\"$tallenna\">
</FORM>
		");

	#
#	EnvList();

past:
	#
	print("
<BR><BR><BR><BR>
<BR><BR><BR><BR>
<BR><BR><BR><BR>
</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
		");

	#
}


