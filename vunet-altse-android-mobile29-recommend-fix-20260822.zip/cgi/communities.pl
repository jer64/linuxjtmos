#!/usr/bin/perl
use utf8;
#
# communities.pl
#
##############################################################################################################
#
# Rekisteröityneenä käyttäjänä voisit...
#
#    * Lisätä valokuviasi IRC-Galleriaan
#    * Kirjoittaa ja vastaanottaa kommentteja kuviisi
#    * Kirjoittaa nettipäiväkirjaa
#    * Etsiä käyttäjiä useilla hakuehdoilla
#    * Liittyä kiinnostuksen kohteisiisi liittyviin yhteisöihin ja kanaville
#
# Tutustu tarkemmin Rekisteröidy käyttäjäksi
#

#
require "tools.pl";

#
$COMCGI = "/userspace/index.pl";
# 60 minute time-out for logins.
$LOGIN_TIMEOUT_SECS = 60*60;

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
$fp = "english";
if($ENV{'NW_LANGUAGE'} eq "fi")
{
        $fp = "finnish";
}
#
$s = $so{'section'};
if($s eq "") { $s = "communities"; }
if($so{'cmd'} eq "whois" && $so{'q'} ne "")
{
	$s = "user_$so{'q'}";
}
OpenWebIndex("./webindex2.html");
WebWalkTo("main-menu");
print inc_menu($s, $fp);

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


#####################################################################################
#
sub UserLogged
{
	my ($i,$i2,$str,$str2,@lst,$t);

	#
	if(NoTracking())
	{
		#DumpCookies();
		#print "$so{'user_passwd'} < - > $so{'login_password'}<BR>\n";
	}

	#
	$u = "$ENV{'REMOTE_USER'}";
	if($so{'cookie_nick'} ne "" && $ENV{'REMOTE_USER'} eq "")
	{
		#
		$u = "$so{'cookie_nick'}";
	}
	LoadUser($u);

	#
	if($so{'logout'} eq "1")
	{
		$so{'user_login_time'} = "";
		$so{'user_login_ip'} = "";
		SaveUser();
		#
		print("
			<meta http-equiv=\"refresh\" content=\"0; url=/communities.pl?l=$so{'l'}\">
			");
		return 0;
	}

	# Is the login currently active still? (60 minute time-out...)
	$t = time;
	if($ENV{'REMOTE_USER'} ne "") { return 1; }
#	if( $ENV{'REMOTE_ADDR'} eq $so{'user_login_ip'} && ($t-$so{'user_login_time'}) < ($LOGIN_TIMEOUT_SECS) )
#	{
#		return 1;
#	}

	# Generate a password when necessary.
	if($so{'user_passwd'} eq "")
	{
		# Generate random password.
		srand();
		$so{'user_passwd'} = int(rand(1000000000));
		SaveUser();
	}

	#
	if($so{'user_login'} ne "" && $so{'login_password'} ne "")
	{
		# Create new session.
		$so{'user_login_time'} = time;
		$so{'user_login_ip'} = $ENV{'REMOTE_ADDR'};
		# Save user data.
		SaveUser();
		#
		print("
<SCRIPT LANGUAGE=\"Javascript\">
SetCookie('nick', '$ENV{'REMOTE_USER'}', 120);
</SCRIPT>
			<meta http-equiv=\"refresh\" content=\"0; url=$COMCGI\">
			");
		return 1;
	}

	#
	return 0;
}

#####################################################################################
#
sub EnvList
{
	my ($key);
        foreach $key (sort(keys %ENV))
        {
                print "<b>$key</b>=\"$ENV{$key}\"<br>\n";
        }
}

###########################################################################################
#
sub DumpCookies
{
	my ($key,$i);

	#
	$i = 0;

	#
        foreach $key (sort(keys %so))
        {
		if($key=~/^cookie_/)
		{
	                print "<b>$key</b>=\"$so{$key}\"<br>\n";
			$i++;
		}
        }

	#
	print "<font size=5>$i cookies detected.</font><BR>";

	#
}

###########################################################################################
#
# Save user profile.
#
sub SaveCommunity
{
        my ($key,$cfn,$key);

        #
        $so{'lastaccessdate'} = time;

	#
	$cfn = $_[0];
	$cfn =~ s/[^a-zA-Z0-9\._\-\ ]/_/g;
	$cfn = "users/$cfn.community";

        #
        open($f, ">$cfn") || die "error! lst\@vunet.net";
        #
        foreach $key (keys %so)
        {
                if($key=~/^community_/)
                {
                    print $f "$key=$so{$key}\n";
                }
        }
        close($f);
}

###########################################################################################
#
sub UpdateCommunity
{
	my ($cfn,$str,$str2,$f);

	#
	$cfn = $so{'q'};
	$cfn =~ s/[^a-zA-Z0-9\._\-\ ]/_/g;

	#
	if(-e "users/$cfn.community")
	{
		LoadVars("users/$cfn.community");
	        #
	        foreach $key (keys %so)
	        {
	                if($key=~/^set_community_/)
	                {
				$str = $key;
				$str =~ s/^set_//;
				$so{$str} = $so{$key};
	                }
	        }
		SaveCommunity($cfn);

		#
		print("
			<meta http-equiv=\"refresh\" content=\"0; url=$COMCGI?cmd=view&q=$so{'q'}\">
			");
	}

	#
}

###########################################################################################
#
# Save user profile.
#
sub SaveUser
{
        my ($key,$pfn,$str,$str2);

        #
        $so{'lastaccessdate'} = time;

	#
	$pfn = $ENV{'REMOTE_USER'};
	if($pfn eq "") { $pfn = $so{'cookie_nick'}; }
	$pfn =~ s/[^a-zA-Z0-9\._\-\ ]/_/g;
	$pfn = "users/$pfn.profile";

        #
        open($f, ">$pfn") || die "error while creating user profile, please contact lst\@vunet.net";
        # Save user settings.
        foreach $key (keys %so)
        {
                if($key=~/^user_/)
                {
			print $f "$key=$so{$key}\n";
                }
        }
        close($f);
}

###########################################################################################
#
# Save user profile.
#
sub LoadUser
{
	my ($key,$pfn,$key,@lst,$i,$i2,$i3,$i4,$str,$str2);

	#
	$pfn = $_[0];
	if( !($pfn=~/\//) )
	{
		if($pfn eq "") { $pfn = $so{'cookie_nick'}; }
		$pfn =~ s/[^a-zA-Z0-9\._\-\ ]/_/g;
		$pfn = "users/$pfn.profile";
	}

	#
	if( !(-e $pfn) ) { return 0; }

	#
	@lst = LoadList($pfn);

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		@sp = split(/\=/, $lst[$i]);
		$sp[0] =~ s/^cookie_/user_/;
		$so{$sp[0]} = $sp[1];
	}

	#
	return 1;
}

###########################################################################################################
#
sub isMember
{
	my ($i,$i2,$str,$str2,@sp);

	#
	@sp = split(/\;/, $so{'cookie_communities'});

	#
	for($i=0; $i<($#sp+1); $i++)
	{
		if($sp[$i] eq $_[0]) { return 1; }
	}

	#
	return 0;
}

###########################################################################################################
#
sub OptionCreateCommunity
{
	my ($cfn,$str,$str2,$f);

	#
	print("
<DIV ALIGN=CENTER>
<FORM action=$COMCGI>
$luo_uusi_yhteiso - $name: <input type=text name=q>
<input type=hidden name=cmd value=create_community>
<input type=submit value=\"$luo_yhteiso\">
</FORM>
</DIV>
		");
}

###########################################################################################################
#
sub CreateCommunity
{
	my ($cfn,$str,$str2,$f);

	#
	$cfn = $so{'q'};
	$cfn =~ s/[^a-zA-Z0-9\._\-\ ]/_/g;
	$cfn = "users/$cfn.community";
	#
	if( !(-e $cfn) )
	{
		#
		open($f, ">$cfn");
		print $f "community_owner=$so{'cookie_nick'}\n";
		close($f);
		return 1;
	}

	#
	return 0;
}

###########################################################################################################
#
sub ViewProfile
{
	my ($cfn,$str,$str2,$f,$pfn,@pro,@sp,$img_html,$i,$i2,$i3,$i4);

	#
	$pfn = $so{'q'};
	$pfn =~ s/[^a-zA-Z0-9\._\-\ ]/_/g;
	$pfn = "users/$pfn.profile";
	if(!(-e $pfn))
	{
		print "User not found: <B>$so{'q'}</B><BR>";
		return;
	}

	#
	@pro = LoadList($pfn);
	@pro = sort @pro;

	#
	for($i=0,$i2=0; $i<($#pro+1); $i++)
	{
		@sp = split(/\=/, $pro[$i]);
		if($sp[0]=~/^cookie_[a-z_]+$/)
		{
			$str = $sp[0];
			$str =~ s/^cookie_//;
			$str = "upr_$str";
			$so{$str} = $sp[1];
		}
		if($sp[0]=~/^user_[a-z_]+$/)
		{
			$str = $sp[0];
			$str =~ s/^user_//;
			$str = "upr_$str";
			$so{$str} = $sp[1];
		}
	}

	#
	$img_html = "";
	if($so{'upr_profile_image'} ne "")
	{
		$img_html = ("<IMG SRC=\"$IMAGES_BASE/thumb3/th_$so{'upr_profile_image'}\" border=1><BR>");
	}

	#
	if( !($so{'upr_website'}=~/^http:\/\//) )
	{
		$so{'upr_website'} = "https://$so{'upr_website'}";
	}

	if($so{'upr_nick'} eq $so{'cookie_nick'} && UserLogged())
	{
		$choose_image_html = ("
<A HREF=\"https://vunet.net/imgbank.pl?q=&r=$COMCGI?set_profile_image^\">
> select photo / valitse valokuvat
</A><BR>
<A HREF=\"#edit_description\">
> edit description / muokkaa kuvausta
</A><BR>
<A HREF=\"/communities.pl?logout=1\">
> log out / kirjaudu ulos
</A><BR>
		");
	}

	#
	print("
<H1>$so{'upr_nick'}</H1>

<TABLE width=100% cellspacing=0 cellpadding=0>
<TR>

<TD WIDTH=50%>
$img_html
$choose_image_html
</TD>

<TD WIDTH=50>
$so{'upr_realname'}<BR>
$sahkoposti: <A HREF=\"mailto:$so{'upr_email'}\">$so{'upr_email'}</A><BR>
$homepage: <A HREF=\"$so{'upr_website'}\">$so{'upr_website'}</A><BR>
$sukupuoli: $so{'upr_sex'}<BR>
</TD>

</TR>
</TABLE>
		");

	#
	$str = $so{'upr_html_content'};
	@lst = split(/\n/, $str);
	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$str = $lst[$i];
		$str =~ s/<br>$//gi;
		if( ($str=~/www\.[a-z0-9\-]*\.[a-z]*/) && $str=~/^[^\<\>]*$/ )
		{
			$str =~ s/(www\.[a-z0-9\-]*\.[a-z]*\S*)/<A HREF=\"http:\/\/$1\">$1<\/A>/g;
		}
		if( ($str=~/http:\/\/[a-z]*[\.\-]*/) )
		{
			$str =~ s/(http:\/\/)([a-z0-9\-]+\S+)/<A HREF=\"$1$2\">$2<\/A>/g;
		}
		$lst[$i] = $str;
	}
	$str = join("<BR>", @lst);


	if($str ne "")
	{
	print("
<BR>
$str
<BR>
		");
	}
	else
	{
		if($so{'upr_nick'} eq $so{'cookie_nick'} && UserLogged())
		{
			print("
<BR>
Olet tämän profiilin omistaja, voit muokata/lisätä sille kuvauksen.<BR>
You are the owner of this profile, you may edit/add a description for it.<BR>
			");
		}
	}

	#
	if($so{'upr_nick'} eq $so{'cookie_nick'} && UserLogged())
	{
		$str = "$so{'upr_html_content'}";
		$str =~ s/<br>/\n/gi;
		print("
<BR>
<A NAME=\"edit_description\"></A>
<FORM action=\"$COMCGI\" method=\"post\">
<TEXTAREA cols=80 rows=20 name=set_user_html_content>$str</TEXTAREA><BR>
<INPUT TYPE=SUBMIT VALUE=Save><BR>
</FORM>
			");
	}

	#
	if( !UserLogged() )
	{
		print("
<A HREF=\"$COMCGI\">
Haluatko muokata sivuasi? Kirjaudu sisälle! (tai rekisteröidy uudeksi käyttäjäksi!)<BR>
Want to edit your page? Log in! (or sign up as a new user!)<BR>
</A>
			");
	}


	#
}

###########################################################################################################
#
sub QuickViewProfile
{
	my ($cfn,$str,$str2,$f,$pfn,@pro,@sp);

	#
	$pfn = $_[0];
	$pfn =~ s/[^a-zA-Z0-9\._\-\ ]/_/g;
	$pfn = "users/$pfn.profile";
	if(!(-e $pfn))
	{
		return;
	}

	#
	$so{'upr_profile_image'} = "";
	@pro = LoadList($pfn);
	@pro = sort @pro;

	#
	for($i=0,$i2=0; $i<($#pro+1); $i++)
	{
		@sp = split(/\=/, $pro[$i]);
		if($sp[0]=~/^cookie_[a-z_]+$/)
		{
			$str = $sp[0];
			$str =~ s/^cookie_//;
			$str = "upr_$str";
			$so{$str} = $sp[1];
		}
	}

	$image_html = "";
	if($so{'upr_profile_image'} ne "")
	{
		$so{'upr_profile_image'} =~ s/\.jpg$/.png/;
		$image_html = ("
<IMG SRC=\"$IMAGES_BASE/thumb2/th_$so{'upr_profile_image'}\">
                                ");
	}

	#
	print("
<TABLE width=100% height=32 cellspacing=0 cellpadding=0
	bgcolor=$_[1]>
<TR>
<TD width=10%>
<A HREF=\"$COMCGI?cmd=whois&q=$so{'upr_nick'}\" class=news2>
$image_html
</A>
</TD>
<TD width=90>
<A HREF=\"$COMCGI?cmd=whois&q=$so{'upr_nick'}\" class=news2>
$so{'upr_nick'}
</A>
</TD>
</TR>
</TABLE>
		");

	#
}

###########################################################################################################
#
sub ViewCommunity
{
	my ($cfn,$str,$str2,$f);

	#
	$cfn = $so{'q'};
	$cfn =~ s/[^a-zA-Z0-9\._\-\ ]/_/g;
	$cfn = "users/$cfn.community";

	#
	if( !(-e $cfn) )
	{
		#
		print("
		<DIV ALIGN=CENTER><FONT SIZE=4 class=caps color=red>
		<BLINK>$yhteisoa_ei_loydy: $so{'q'}</BLINK>
		</FONT>
		</DIV><BR>
		");
		return;
	}

	#
	LoadVars($cfn);

	#
	print("
	<DIV ALIGN=CENTER>
	<A HREF=\"$COMCGI\">> $palaa</A>
	<BR><BR>
	<FONT SIZE=6 class=caps>
	$so{'q'}
	</FONT>
	</DIV><BR>
	");
	if($so{'community_image'} ne "")
	{
		print("
<DIV ALIGN=CENTER>
<IMG SRC=\"$IMAGES_BASE/thumb3/th_$so{'community_image'}\" border=1>
</DIV>
			");
	}

	#
	print("
<H3>$homepage:</H3>
<A HREF=\"$so{'community_homepage'}\">$so{'community_homepage'}</A><BR>
		");


	#
	print("
<BR>
<H3>$kuvaus:</H3> $so{'community_description'}<BR>
<BR>

		");


	#
	print("
<H3>$komjohtaja:</H3> <A HREF=\"/users/$so{'community_owner'}\">$so{'community_owner'}</A><BR>
<BR>
		");

	#
	@mem = split(/\;/, $so{'community_members'});
	$i = $#mem+1;
	#
	print("
<H3>$members ($i):</H3><BR>
		");
	#
	for($i=0; $i<($#mem+1); $i++)
	{
		print("
		<A HREF=\"/users/$mem[$i]\">$mem[$i]</A><BR>
		<BR>
		");
	}

	#
	if($so{'cookie_nick'} eq $so{'community_owner'})
	{
		print("
<BR>
<FONT COLOR=BLUE><H3>$olet_yhteison_johtaja</H3></FONT>

<FORM action=\"$COMCGI\" method=get>
$muokkaa_yhteison_kuvausta:<BR>
<input type=text name=\"set_community_description\" value=\"$so{'community_description'}\">
<BR>
$homepage ($esim https://www.testi.com):<BR>
<input type=text name=\"set_community_homepage\" value=\"$so{'community_homepage'}\">

<BR>
<input type=hidden name=cmd value=update_community>
<input type=hidden name=q value=\"$so{'q'}\">
<input type=submit value=\"$save\">
</FORM>

<A HREF=\"https://vunet.net/images.pl?q=&r=$COMGI?cmd^update_community~q^$so{'q'}~set_community_image^\">
> lisää kommuunille oma kuva
</A><BR>
<BR>
			");
	}

	#
	if(NoTracking())
	{
		print("
<b>VUNETIN YLLÄPITO</b><BR>
<A HREF=\"$COMCGI?q=$so{'q'}&cmd=rmcommunity\">
> poista tämä yhteisö
</A><BR>
<BR>
			");
	}

	#
}

###########################################################################################################
#
sub FormSendCommunityMessage
{
	my ($i,$i2,$str,$str2,@c,$r,$fn);

	#
	$r = int(rand(1000000000));
	$fn = "/tmp/sndpermission-$r.tmp";
	open($f, ">$fn") || die "error";
	close($f);

	#
	print("
	<DIV ALIGN=CENTER><FONT SIZE=6 class=caps>$send_message
	</FONT>
	</DIV><BR>
	");
	print("
<FORM action=\"/communities.pl\" method=post>
$subject: <INPUT TYPE=TEXT name=subject value=\"\"><BR>
$message:
<TEXTAREA name=message cols=80 rows=20></TEXTAREA>
<INPUT TYPE=SUBMIT value=\"$send_now\">
<INPUT TYPE=HIDDEN name=\"confirm\" value=\"$r\">
<INPUT TYPE=HIDDEN name=cmd value=sendcmsg>
<INPUT TYPE=HIDDEN name=section value=\"$so{'section'}\">
</FORM>
<BR>
<BR>
		");

	#
}

#
sub SendNowCommunityMessage
{
	my ($i,$i2,$str,$str2,@c,$r,$fn,$f,$f2,@lst,@lst2);

	#
	$r = $so{'confirm'};
	$r =~ s/[^0-9]//g;
	$fn = "/tmp/sndpermission-$r.tmp";
	if( !NoTracking() && !(-e $fn) ) { return; }
	$so{'subject'} =~ s/[^a-zA-Z0-9äöåÄÖÅ\.\,\+\-\/\\_\!\?\@\#\¤\%\&\{\}\[\]\(\)\£\:\; ]//g;

	#
	unlink($fn);

	#
	@lst = LoadList("find users -maxdepth 1 -name '*.profile' -type f|");

	#
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		$so{'user_nick'} = "";
		$so{'user_passwd'} = "";
		$so{'user_email'} = "";
		LoadUser($lst[$i]); # not cookie_* gets converted to user_* !!
		if($so{'user_email'} ne "")
		{
			$lst2[$i2++] = "$so{'user_email'}\n$so{'user_nick'}\n$so{'user_passwd'}";
		}
	}

	#
	print("
<DIV ALIGN=CENTER><FONT SIZE=6 class=caps>$send_message
</FONT>
</DIV><BR>

<TABLE bgcolor=#C0C000 bgcolor=0 cellspacing=0 cellpadding=4 width=100%>
<TR>
<TD>
<B>$so{'subject'}</B>
</TD>
</TR>
</TABLE>
");
	@lst = split(/\n/, $so{'message'});

	#
	print("
<TABLE bgcolor=#A0A000 bgcolor=0 cellspacing=0 cellpadding=4 width=100%>
<TR>
<TD>
		");
	for($i=0; $i<($#lst+1); $i++)
	{
		print "$lst[$i]<BR>\n";
	}
	print("
</TD>
</TR>
</TABLE>
		");

	#
	for($i=0; $i<($#lst2+1); $i++)
	{
		# [0] e-mail address (user_email)
		# [1] user login name (user_nick)
		# [2] user password (user_passwd)
		@sp = ();
		@sp = split(/\n/, $lst2[$i]);

		#
		$str2 = $so{'subject'};
		$str2 =~ s/USERNICK/$sp[1]/g;

		# $_[0]
		open($f, "|mail $sp[0] -s \"[Vunet.org] $str2\"");
		for($i2=0; $i2<($#lst+1); $i2++)
		{
			$str = $lst[$i2];
			if($str eq "USERINFO")
			{
				$str = ("
TERVETULOA VAIHTOEHTOUUTISIIN!
WELCOME TO VUNET.ORG!

HI $sp[1] / TERVE $sp[1] ($sp[0]) !

Your homepage at Vunet.org is :
Sinun Vunetin kotisivusi osoite on :

https://vunet.net/users/$sp[1]


Your user name (käyttäjätunnus) is $sp[1].
Your password (salasana) is $sp[2].


Click here to login to your account :
Klikkaa tästä kirjautuaksesi palveluun :
https://vunet.net/communities.pl?user_login=$sp[1]&login_password=$sp[2]&login_now=1

");
			}
			print $f "$str\n";
		}
		print $f "======================================================\n";
		print $f "This message has been sent via Vunet.org communities.\n";
		print $f "you can access Vunet communities at the following address:\n";
		print $f "https://vunet.net/communities.pl\n\n";
		print $f "Voit lähettää yhteisöjen kautta viestejä muille.\n";
		print $f "Tämä viesti lähetettiin Vunetin yhteisöjen kautta!\n";
		print $f "Vunetin yhteisöjen sivut sijaitsevat osoitteessa:\n";
		print $f "https://vunet.net/communities.pl\n\n";
		close($f);
	}

	#
	print("
<BR>
<B>$message_sent</B>
		");

	#
}

###########################################################################################################
#
sub BriefViewCommunities
{
	my ($i,$i2,$str,$str2,@c);

	#
	print("

	<DIV ALIGN=CENTER>
	<font size=5>
		<A HREF=\"$COMCGI?q=$ENV{'REMOTE_USER'}&cmd=whois\">
		> $show_my_page
		</A>
	</font>
	<BR>
	<BR>
	<FONT SIZE=6 class=caps>
	$communities
	</FONT>
	</DIV><BR>
	");

	#
	@c = LoadList("find users/ -maxdepth 1 -type f -name '*.community'|");
	for($i=0; $i<($#c+1); $i++)
	{
		$str = $c[$i];
		$str =~ s/^users\///;
		$str =~ s/\.community$//;
		$str =~ s/[^a-zA-Z0-9\._\-\ ]/_/g;

		$so{'community_image'} = "";
		LoadVars("$c[$i]");

		if( ($i&1) ) { $co = "#C0C0FF"; } else { $co = "#E0E0FF"; }

		#
		if( !isMember($str) )
		{		
			$html_liity = ("
				<A HREF=\"$COMCGI?cmd=join&q=$str\" class=news2>
				[$liity]
				</A>
				");
		}
		else
		{
			$html_liity = ("
				<i>$member</i> <A HREF=\"$COMCGI?cmd=part&q=$str\" class=news2>
				[$eroa]
				</A>
			");
		}

		#
		$image_html = "";
		if($so{'community_image'} ne "")
		{
			$image_html = ("
			<IMG SRC=\"$IMAGES_BASE/thumb/th_$so{'community_image'}\" class=bulletin>
				");
		}

		#
		@sp = split(/\;/, $so{'community_members'});
		$smiles = "";
		for($i4=0; $i4<($#sp+1); $i4++)
		{
			$smiles = "<IMG SRC=\"$IMAGES_BASE/smiles/smile.gif\" class=bulletin border=0>$smiles";
		}

		#
		print("
<TABLE width=100% cellspacing=0 cellpadding=0
	bgcolor=$co>
<TR>
<TD width=15%>
$image_html
</TD>
<TD width=35%>
	<font size=5>
	<A HREF=\"/groups/$str\" class=news2>$str</A> $smiles
	</font>
</TD>
<TD width=50%>
	<DIV ALIGN=CENTER>
	$html_liity
	</DIV>
</TD>
</TR>
</TABLE>
");
	}

	#
	OptionCreateCommunity();

	#
	print("
<BR><BR>
	<DIV ALIGN=CENTER><FONT SIZE=6 class=caps>
$kaikki_kayttajat:<BR>
	</FONT>
	</DIV><BR>
	");

	#
	@c = LoadList("find users/ -maxdepth 1 -type f -name '*.profile'|");
	for($i=0; $i<($#c+1); $i++)
	{
		$str = $c[$i];
		$str =~ s/^users\///;
		$str =~ s/\.profile$//;
		$str =~ s/[^a-zA-Z0-9\._\-\ ]/_/g;

		if( ($i&1) ) { $co = "#C0C0FF"; } else { $co = "#E0E0FF"; }

		QuickViewProfile($str,$co);
	}

	#
}

###########################################################################################################
#
sub JoinCommunity
{
		my ($str,$str2,$i,$i2,$com,@communities,@sp);

		#
		$com = $so{'q'};
		$com =~ s/[^a-zA-Z0-9\._\-\ ]//g;
		$str = $com;
		$cfn = $com;

		#
		$cfn = "users/$cfn.community";
		if( !(-e $cfn) ) { return; }

		# Load community variables.
		LoadVars($cfn);

		# REMOVE FROM COMMUNITY MEMBERS
		@mem = split(/\;/, $so{'community_members'});
		loop: for($i=0,$i2=0; $i<($#mem+1); $i++)
		{
			if($mem[$i] eq $so{'cookie_nick'}) { $i2=1; last loop; }
		}

		# If not member yet, then add.
		if(!$i2)
		{
			$so{'community_members'} = "$so{'cookie_nick'};$so{'community_members'}";
			SaveCommunity($str);
		}
		else
		{
			print "$already_member ($so{'community_members'})<BR>\n";
		}

		# REMOVE FROM COOKIE
		@sp = split(/\;/, $so{'cookie_communities'});
		loop2: for($i=0,$i2=0,$str2=""; $i<($#sp+1); $i++)
		{
			#print "$sp[$i] - $com<BR>";
			if($sp[$i] eq $com) { $i2=1; last loop2; }
		}

		if(!$i2)
		{
		print("
<SCRIPT LANGUAGE=\"Javascript\">
SetCookie('communities', '$com;$so{'cookie_communities'}', 120);
</SCRIPT>
			");
		}

                #
                print("
                <meta http-equiv=\"refresh\" content=\"0; url=/communities.pl?done=1\">
                        ");
}

###########################################################################################################
#
sub PartCommunity
{
		my ($str,$str2,$i,$i2,$com,@sp,$comn);

		#
		@sp = split(/\;/, $so{'cookie_communities'});

		# Remove from cookies.
		$comn = $so{'q'};
		$comn =~ s/[^a-zA-Z0-9\._\-\ ]/_/g;

		#
		$com = "";
		for($i=0; $i<($#sp+1); $i++)
		{
			if($sp[$i] ne $so{'q'})
			{
				$com = "$sp[$i];$com";
			}
		}

		#
		print("
<SCRIPT LANGUAGE=\"Javascript\">
SetCookie('communities', '$com', 120);
</SCRIPT>
			");

		# Remove from community's memberlist.
		LoadVars("users/$comn.community");
		@sp = split(/\;/, $so{'community_members'});
		for($i=0,$str=""; $i<($#sp+1); $i++)
		{
			if($sp[$i] ne $so{'cookie_nick'}) { $str = "$sp[$i];$str"; }
		}
		$so{'community_members'} = $str;
		SaveCommunity("$comn");

                #
                print("
                <meta http-equiv=\"refresh\" content=\"0; url=/communities.pl?done=1\">
                        ");
}

###########################################################################################################
#
sub main
{
	@langs = ("English", "Suomi", "Svenska");
	my ($i,$i2,$str,$str2,@sp,@lst);

	#
	if( $so{'l'} eq "" )
	{
		$so{'l'} = $ENV{'NW_LANGUAGE'};
	}
	if( $ENV{'REMOTE_USER'} ne "" )
	{
		print("
<SCRIPT LANGUAGE=\"Javascript\">
SetCookie('nick', '$ENV{'REMOTE_USER'}', 120);
</SCRIPT>
			");
	}

	#
	$ok = "ok";
	$kirjaudu_ulos = "log out";
	$show_my_page = "show my page";
	$forgot_password = "Did forgot your password or you don't have it yet? Enter your user name below, and it will be sent to your E-mail address!";
	if($so{'l'} ne "") { $ENV{'NW_LANGUAGE'} = $so{'l'}; }
	if( $ENV{'NW_LANGUAGE'} eq "en" )
	{
		$send_message = "send message";
		$message_sent = "message sent successfully";
		$send_now = "send";
		$subject = "subject";
		$message = "message";
		$login_title = "USER LOGIN";
		$login = "login";
		$user = "user";
		$password = "password";
		$sahkoposti = "e-mail";
		$sukupuoli = "sex";
		$esim = "f.e.";
		$already_member = "you are already a member!";
		$olet_yhteison_johtaja = "you are the community leader";
		$homepage = "homepage";
		$komjohtaja = "community leader";
		$palaa = "back to index";
		$name = "name";
		$luo_yhteiso = "create community";
		$luo_uusi_yhteiso = "create new community";
		$yhteisoa_ei_loydy = "community can't be found";
		$members = "members";
		$communities = "Communities (beta)";
		$liity = "join";
		$eroa = "part";
		$kirjautunut = "logged in";
		$registration_required = "Not yet registered? Registration is required (free) - click here !";
		$muutokset = "ok";
		$save = "save";
		$member = "member";
		$kaikki_kayttajat = "all users";
		$muokkaa_yhteison_kuvausta = "edit community description";
		$kuvaus = "description";
		$login_hint = "";
	}
	if( $ENV{'NW_LANGUAGE'} eq "fi" )
	{
		$forgot_password = "Unohditko salasanasi tai etkö ole vielä saanut sitä? Kirjoita käyttäjänimesi alle, ja salasanasi tullaan lähettämään sähköpostiisi!";
		$show_my_page = "näytä minun sivuni";
		$send_message = "viestin lähetys";
		$message_sent = "viesti lähetetty onnistuneesti";
		$send_now = "lähetä";
		$message = "viesti";
		$subject = "otsikko";
		$login_title = "JÄSENEN SISÄÄNKIRJAUTUMINEN";
		$login = "login";
		$user = "user";
		$password = "password";
		$sahkoposti = "sähköposti";
		$sukupuoli = "sukupuoli";
		$esim = "esim.";
		$already_member = "olet jo jäsen!";
		$olet_yhteison_johtaja = "olet yhteisön johtaja";
		$homepage = "kotisivu";
		$komjohtaja = "yhteisöjohtaja";
		$palaa = "palaa luetteloon";
		$name = "nimi";
		$luo_yhteiso = "luo yhteisö";
		$luo_uusi_yhteiso = "luo uusi yhteisö";
		$yhteisoa_ei_loydy = "yhteisoa ei loydy";
		$members = "jäsenet";
		$communities = "Yhteisöt (testi)";
		$liity = "liity";
		$eroa = "eroa";
		$kirjautunut = "kirjautunut sisälle";
		$registration_required = "Etkö ole vielä rekisteröitynyt? Tämä ominaisuus vaatii rekisteröitymisen (ilmainen) - klikkaa tästä !";
		$muutokset = "ok";
		$save = "tallenna";
		$member = "jäsen";
		$kaikki_kayttajat = "kaikki käyttäjät";
		$muokkaa_yhteison_kuvausta = "muokkaa yhteisön kuvausta";
		$kuvaus = "kuvaus";
		$login_hint = "Kysymyksiä? Ota yhteyttä meihin sähköpostitse osoitteeseen <b>jari <IMG src=\"$IMAGES_BASE/at.gif\" class=bulletin>  vunet.net</b>"
	}
	if( $ENV{'NW_LANGUAGE'} eq "se" )
	{
		$send_message = "send message";
		$message_sent = "message sent successfully";
		$send_now = "send";
		$message = "message";
		$subject = "subject";
		$login_title = "USER LOGIN";
		$login = "login";
		$user = "user";
		$password = "password";
		$sahkoposti = "e-mail";
		$sukupuoli = "sex";
		$esim = "f.e.";
		$already_member = "you are already a member!";
		$olet_yhteison_johtaja = "you are the community leader";
		$homepage = "homepage";
		$komjohtaja = "kommunledare";
		$palaa = "back to index";
		$name = "name";
		$luo_yhteiso = "create community";
		$luo_uusi_yhteiso = "create new community";
		$yhteisoa_ei_loydy = "community can't be found";
		$members = "members";
		$communities = "Communities (beta)";
		$liity = "join";
		$eroa = "part";
		$kirjautunut = "logged in";
		$registration_required = "Not yet registered? Registration is required (free) - click here !";
		$muutokset = "ok";
		$save = "save";
		$member = "member";
		$kaikki_kayttajat = "all users";
		$muokkaa_yhteison_kuvausta = "edit community description";
		$kuvaus = "description";
		$login_hint = "";
	}

	#
	print("
<SCRIPT LANGUAGE=\"Javascript\">
function SetCookie(cookieName,cookieValue,nDays) {
 var today = new Date();
 var expire = new Date();
 if (nDays==null || nDays==0) nDays=1;
 expire.setTime(today.getTime() + 3600000*24*nDays);
 document.cookie = cookieName+\"=\"+escape(cookieValue)
                 + \";expires=\"+expire.toGMTString();
}
</SCRIPT>
		");

	print("
<TABLE width=100% BGCOLOR=#000000 CELLSPACING=0 CELLPADDING=0>
<TR>
<TD>
<TABLE width=640 cellspacing=0 cellpadding=32>
<TR>
<TD>
		");

	#
	if($so{'set_profile_image'} ne "" && UserLogged())
	{
		$so{'cookie_profile_image'} = $so{'set_profile_image'};
		SaveUser();
		print("
		<meta http-equiv=\"refresh\" content=\"0; url=/users/$ENV{'REMOTE_USER'}\">
			");		
		goto past;
	}

	#
	if($so{'set_user_html_content'} ne "" && UserLogged())
	{
		$so{'user_html_content'} = $so{'set_user_html_content'};
		$so{'user_html_content'} =~ s/\n/<BR>/gi;
		SaveUser();
		print("
		<meta http-equiv=\"refresh\" content=\"0; url=/users/$ENV{'REMOTE_USER'}\">
			");		
		goto past;
	}

	#
	if( UserLogged() )
	{
		if($so{'quiet'} ne "1")
		{
		print("
		$kirjautunut: $so{'cookie_nick'} ($so{'cookie_realname'})<BR>
<BR>
		<A HREF=\"/communities.pl?logout=1\">> $kirjaudu_ulos</A>
<BR>
				");
		}
	}
	else
	{
		#
		if($so{'user_login'} ne "" && $so{'login_password'} eq "" && $so{'login_now'} eq "1")
		{
	                #
			if( LoadUser($so{'user_login'}) )
			{
		                open($f, "|mail $so{'user_email'} -s \"Your Vunet.org community password.\"");
		                print $f "Dear $so{'user_login'}, here is your community profile's password you requeested.\n";
				print $f "Login is :  $so{'user_login'}\n";
				print $f "Password is :  $so{'user_passwd'}\n\n";
				print $f "Click here to login now:  https://vunet.net/communities.pl\n\n";
		                print $f "==========================================\n";
		                print $f "Vunet.org Information System\n";
		                print $f "https://vunet.net\n";
		                close($f);
				#
				print ("
					<FONT COLOR=#C00000><P>Password successfully sent to your e-mail address !</P></FONT>
					");
			}
		}

		#
		if($so{'quiet'} ne "1")
		{
			#
			if($ENV{'REMOTE_USER'} ne "")
			{
				print("
				<meta http-equiv=\"refresh\" content=\"0; url=$COMCGI\">
					");
			}
			else
			{
				#
				print("

<A HREF=\"$COMCGI\">
<FONT size=5>> $login_title</FONT>
</A>
<BR>
$login_hint
<BR>
<BR>

$forgot_password<BR>
<FORM action=/communities.pl method=get>
$user :
<input type=text name=\"user_login\" value=\"$so{'user_login'}\"><BR>
<input type=hidden name=\"login_now\" value=\"1\">
<input type=submit value=\"$ok\">
</FORM>
				");
			}

			#
			print("
			<font size=6 face=impact>
			<A HREF=\"/register.pl?t=register\">$registration_required</A>
			</font>
			<BR>
			");
		}

		#
		goto past;

		#
	}


	#
	if(NoTracking())
	{
		#
		if($so{'q'} ne "" && $so{'cmd'} eq "rmcommunity" && $so{'confirm'} eq "1")
		{
			$str = $so{'q'};
			$str =~ s/[^a-zA-ZäöåÄÖÅ0-9]/_/g;
			unlink("users/$str.community");
			print("
			<meta http-equiv=\"refresh\" content=\"0; url=/communities.pl\">
				");
			goto past;
		}

		#
		if($so{'q'} ne "" && $so{'cmd'} eq "rmcommunity" && $so{'confirm'} ne "1")
		{
			print("
<FONT COLOR=RED SIZE=5>Poista yhteisö $so{'q'}</FONT><BR>
<B>OLETKO VARMA?</B><BR>
<A HREF=\"/communities.pl?q=$so{'q'}&cmd=rmcommunity&confirm=1\">
> kyllä
</A><BR>
<A HREF=\"Javascript:history.go(-1);\">
> peruuta
</A><BR>
<BR>
				");
			goto past;
		}

		#
	}

	#
	if($so{'cmd'} eq "update_community")
	{
		UpdateCommunity();
	}

	#
	if($so{'done'}==1)
	{
		SaveUser();
		print("
<h2><i>$muutokset !</i></h2><BR><BR>
			");
	}

	#
	if($so{'cmd'} eq "sendmsg")
	{
		FormSendCommunityMessage();
	}

	#
	if($so{'cmd'} eq "sendcmsg" && $so{'confirm'}=~/^[0-9]*$/)
	{
		SendNowCommunityMessage();
	}

	#
	if($so{'cmd'} eq "")
	{
		BriefViewCommunities();
	}

	#
	if($so{'cmd'} eq "create_community")
	{
		$r = CreateCommunity();
                print("
                <meta http-equiv=\"refresh\" content=\"0; url=/communities.pl?done=$r\">
                        ");
		goto past;
	}

	#
	if($so{'quiet'} ne "1")
	{
		print("
<A HREF=\"Javascript:history.go(-1);\">> $palaa</A><BR>
<BR>
			");
	}

	#
	if($so{'cmd'} eq "join" && $so{'q'} ne "")
	{
		JoinCommunity($so{'q'});
	}

	#
	if($so{'cmd'} eq "part" && $so{'q'} ne "")
	{
		PartCommunity($so{'q'});
	}

	#
#	EnvList();

past:
	# COMMANDS BELOW DO NOT REQUIRE USER TO BE LOGGED IN THE SYSTEM.
	# In other words these commands are publicly available.
	#

	# View community homepage.
	if($so{'cmd'} eq "view")
	{
		ViewCommunity();
	}

	# View user homepage.
	if($so{'cmd'} eq "whois")
	{
		ViewProfile();
	}


	#
	print("
<BR><BR><BR><BR>
<BR><BR><BR><BR>
<BR><BR><BR><BR>
<BR><BR><BR><BR>
<BR><BR><BR><BR>
<BR><BR><BR><BR>
</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
		");

	#
}


