#!/usr/bin/perl
use utf8;
#
##############################################################################################################

#
require "tools.pl";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

###########################################################################################################
#
sub main
{
	my ($l);

	#
	$path = "/home/vai/altse/html/uutiset";

	#
	if($so{'l'} ne "")
	{
		$l = $so{'l'};
	}
	else
	{
		$l = DetectLanguage();
	}

	# Is it a Swedish host?
	$fn = "$path/vunet-a1_$l.gif";

	#
	print "Content-type: image/gif\n\n";
	#
	system("cat $fn");

	#
}


