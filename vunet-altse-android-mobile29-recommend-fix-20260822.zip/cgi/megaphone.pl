#!/usr/bin/perl
#############################################################################
# megaphone.pl - "Mielenosoitus" online chat (polling)
# (C) 2022-2026 by Jari Tuominen.
#############################################################################

use strict;
use warnings;
use utf8;

use POSIX qw(strftime);
use Fcntl qw(:flock);

require "./modules/AltseOpenConfig.pm";
require "./modules/OpenHTMLDocument.pm";
require "./modules/AltseMenu.pm";

AltseOpenConfig();

# ---------------------------------------------
# Config
# ---------------------------------------------
my $CHAT_FILE        = "mielenosoitus.txt";
my $MAX_MSG_LEN      = 280;
my $MAX_LINES_RETURN = 200;   # fetch per request (server side cap)
my $POLL_DEFAULT_S   = 1;

# ---------------------------------------------
# CGI basics (you already have these helpers)
# ---------------------------------------------
our (%so);
our $DONT_AFFECT_DB;

print "Content-type: text/html; charset=UTF-8\n\n";
open(STDERR,'>&STDOUT'); $|=1;

$DONT_AFFECT_DB = 1;
ArgLineParse();

# ---------------------------------------------
# Routing: JSON endpoints for JS
# ---------------------------------------------
my $cmd = lc($so{'cmd'} // '');

if ($cmd eq 'fetch') {
    _json_fetch();
    exit;
}
if ($cmd eq 'post') {
    _json_post();
    exit;
}

# ---------------------------------------------
# Normal page render
# ---------------------------------------------
OpenHTMLDocument();
main();
CloseHTMLDocument();
exit;

# =============================================
# Helpers
# =============================================

sub _escape_html {
    my ($s) = @_;
    $s //= '';
    $s =~ s/&/&amp;/g;
    $s =~ s/</&lt;/g;
    $s =~ s/>/&gt;/g;
    $s =~ s/"/&quot;/g;
    $s =~ s/'/&#39;/g;
    return $s;
}

sub _clean_msg {
    my ($s) = @_;
    $s //= '';
    # strip tags (your original idea, but correct)
    $s =~ s/<[^>]*>//g;
    # collapse whitespace
    $s =~ s/\r//g;
    $s =~ s/\n/ /g;
    $s =~ s/\s{2,}/ /g;
    $s =~ s/^\s+|\s+$//g;

    # limit length
    if (length($s) > $MAX_MSG_LEN) {
        $s = substr($s, 0, $MAX_MSG_LEN);
    }
    return $s;
}

sub _read_chat_lines {
    # returns array of lines (already chomped) safely
    return () if !-e $CHAT_FILE;

    open(my $fh, '<:encoding(UTF-8)', $CHAT_FILE) or return ();
    flock($fh, LOCK_SH);
    my @lines = <$fh>;
    flock($fh, LOCK_UN);
    close($fh);

    chomp @lines;
    return @lines;
}

sub _append_chat_line {
    my ($line) = @_;
    open(my $fh, '>>:encoding(UTF-8)', $CHAT_FILE) or return 0;
    flock($fh, LOCK_EX);
    print $fh $line . "\n";
    flock($fh, LOCK_UN);
    close($fh);
    return 1;
}

sub _json_header {
    print "Content-type: application/json; charset=UTF-8\n\n";
}

sub _json_encode {
    # tiny JSON encoder for our limited needs (avoid extra deps)
    my ($s) = @_;
    $s //= '';
    $s =~ s/\\/\\\\/g;
    $s =~ s/"/\\"/g;
    $s =~ s/\r//g;
    $s =~ s/\n/\\n/g;
    $s =~ s/\t/\\t/g;
    return '"' . $s . '"';
}

sub _json_fetch {
    _json_header();

    my $since = $so{'since'};
    $since = 0 if !defined($since) || $since !~ /^\d+$/;

    my @all = _read_chat_lines();
    my $total = scalar(@all);

    # slice new messages since index
    my $start = $since;
    $start = 0 if $start < 0;
    $start = $total if $start > $total;

    my @new = @all[$start .. $total-1] if $start < $total;

    # cap returned lines (server safety)
    if (@new > $MAX_LINES_RETURN) {
        @new = @new[-$MAX_LINES_RETURN .. -1];
        # adjust start so client can keep up
        $start = $total - scalar(@new);
    }

    my $next_since = $total;

    print "{";
    print "\"ok\":true,";
    print "\"total\":$total,";
    print "\"start\":$start,";
    print "\"next_since\":$next_since,";
    print "\"lines\":[";
    for (my $i=0; $i<@new; $i++) {
        print "," if $i;
        print _json_encode($new[$i]);
    }
    print "]";
    print "}";
}

sub _json_post {
    _json_header();

    # accept msg from q or msg
    my $msg = $so{'msg'};
    $msg = $so{'q'} if (!defined($msg) || $msg eq '');

    $msg = _clean_msg($msg);

    if ($msg eq '') {
        print "{\"ok\":false,\"error\":\"empty\"}";
        return;
    }

    my $ts = strftime("%Y-%m-%d %H:%M:%S", localtime());
    my $line = "[$ts] $msg";

    my $ok = _append_chat_line($line);
    if (!$ok) {
        print "{\"ok\":false,\"error\":\"write_failed\"}";
        return;
    }

    print "{\"ok\":true}";
}

# =============================================
# Page UI
# =============================================
sub main {
    my $HTML_MENU = AltseMenu();

    my $poll_s = $so{'poll'};
    $poll_s = $POLL_DEFAULT_S if !defined($poll_s) || $poll_s !~ /^\d+$/;
    $poll_s = 1 if $poll_s < 1;
    $poll_s = 5 if $poll_s > 5;

    my @lines = _read_chat_lines();
    my $initial_count = scalar(@lines);

    print qq{
$HTML_MENU

<TABLE width="1000" align="center">
<TR><TD>

<div style="text-align:center;">
  <img src="/images/megaphone.png" alt="megaphone" style="max-width:96px;"><br>
  <div style="font-size:22px; font-weight:bold;">Demonstration! Mielenosoitus!</div>
  <div style="font-size:14px;">Yell at the megaphone — Huuda megafoniin</div>
</div>

<br>

<div id="chatbox" style="
  border:1px solid #000;
  background:#fff;
  padding:10px;
  height:420px;
  overflow:auto;
  font-family: monospace;
  font-size:14px;
">
</div>

<br>

<form id="chatform" action="javascript:void(0);" style="text-align:center;">
  <input type="text" id="msg" autocomplete="off"
         placeholder="Kirjoita viesti... (max $MAX_MSG_LEN)"
         style="width:70%; font-size:16px; padding:8px;">
  <button type="submit" style="font-size:16px; padding:8px 12px;">Lähetä</button>
</form>

<div id="status" style="text-align:center; font-size:12px; color:#606060; margin-top:6px;">
  Yhdistetään...
</div>

<script>
(() => {
  const chatbox = document.getElementById('chatbox');
  const form = document.getElementById('chatform');
  const msg  = document.getElementById('msg');
  const status = document.getElementById('status');

  // server gives "since" as line count index
  let since = $initial_count;

  function escapeHtml(s){
    return s.replaceAll('&','&amp;')
            .replaceAll('<','&lt;')
            .replaceAll('>','&gt;')
            .replaceAll('"','&quot;')
            .replaceAll("'",'&#39;');
  }

  function appendLine(line){
    const atBottom = (chatbox.scrollTop + chatbox.clientHeight) >= (chatbox.scrollHeight - 20);
    const div = document.createElement('div');
    div.innerHTML = escapeHtml(line);
    chatbox.appendChild(div);
    if (atBottom) chatbox.scrollTop = chatbox.scrollHeight;
  }

  async function fetchNew(){
    try {
      const r = await fetch('?cmd=fetch&since=' + encodeURIComponent(since), {cache:'no-store'});
      const j = await r.json();
      if (!j.ok) throw new Error('fetch_failed');
      if (Array.isArray(j.lines)) {
        for (const line of j.lines) appendLine(line);
      }
      since = j.next_since || since;
      status.textContent = 'Online. Viestejä: ' + (j.total ?? '?');
    } catch (e) {
      status.textContent = 'Yhteys katkesi. Yritetään uudelleen...';
    }
  }

  async function postMsg(text){
    const body = new URLSearchParams();
    body.set('cmd','post');
    body.set('msg', text);

    const r = await fetch('', {
      method: 'POST',
      headers: {'Content-Type':'application/x-www-form-urlencoded'},
      body: body.toString()
    });

    const j = await r.json().catch(() => ({}));
    if (!j.ok) throw new Error(j.error || 'post_failed');
  }

  // initial load: dump last ~100 lines so chatbox isn't empty
  (async () => {
    // backfill: ask from max(0, current-100)
    const backfillFrom = Math.max(0, since - 100);
    try {
      const r = await fetch('?cmd=fetch&since=' + encodeURIComponent(backfillFrom), {cache:'no-store'});
      const j = await r.json();
      if (j.ok && Array.isArray(j.lines)) {
        chatbox.innerHTML = '';
        for (const line of j.lines) appendLine(line);
        since = j.next_since || since;
      }
    } catch(e) {}
    msg.focus();
    await fetchNew();
  })();

  form.addEventListener('submit', async () => {
    const text = (msg.value || '').trim();
    if (!text) return;
    msg.value = '';
    try {
      await postMsg(text);
      // fetch immediately after posting so it appears for you too
      await fetchNew();
    } catch (e) {
      status.textContent = 'Viestin lähetys epäonnistui.';
    }
    msg.focus();
  });

  setInterval(fetchNew, ${poll_s}000);
})();
</script>

</TD></TR>
</TABLE>
};
}