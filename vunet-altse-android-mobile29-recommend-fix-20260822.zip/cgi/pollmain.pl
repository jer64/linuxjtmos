#!/usr/bin/perl
use utf8;
use File::Basename qw(dirname);

my $CGI_BASE = dirname(__FILE__);
require "$CGI_BASE/tools.pl";
require "$CGI_BASE/modules/poll-cfg.pl";
require "$CGI_BASE/modules/PollSystem.pm";
require "$CGI_BASE/modules/ModernHTML.pm";

$ENV{'CURSEC'} = 'vote';
$DONT_AFFECT_DB = 1;

binmode STDIN,  ':encoding(UTF-8)';
binmode STDOUT, ':encoding(UTF-8)';
print "Content-Type: text/html; charset=UTF-8\n\n";
open(STDERR, '>&STDOUT');
$| = 1;

ArgLineParse();

OpenWebIndex("$CGI_BASE/webindex2.html");
WebWalkTo('CHOOSE-TITLE1');
print qq{<title>Vunet.net – Äänestyspalvelu</title>\n};
print qq{<meta name="description" content="Vunet.netin äänestykset ja niiden tulokset">\n};
SkipTo('CHOOSE-TITLE2');
WebWalkTo('main-menu');
print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'} || 'finnish');
WebWalkTo('ENTERHERE_SECTION');

PollMainPage();

WebWalkTo('ALAPALKKITAHAN');
print EndBar();
HandleRest();

sub _poll_card
{
    my ($id, $featured) = @_;
    my $poll = PollLoad($id) or return '';
    my $results = PollResults($id);
    my $total = $results ? int($results->{'total'}) : 0;
    my $q = VNHtmlEscape($poll->{'question'});
    my $url = "$SCRIPT?POLL=$id";
    my $badge = $featured ? qq{<span class="vn-poll-badge">Ajankohtainen</span>} : '';
    return qq{
<article class="vn-poll-card" data-poll-id="$id">
  <div class="vn-poll-card__body">
    $badge
    <h2 class="vn-poll-card__question"><a href="$url">$q</a></h2>
    <p class="vn-poll-card__meta">$total annettua ääntä</p>
  </div>
  <div class="vn-poll-card__actions">
    <a class="vn-poll-primary" href="$url">Äänestä</a>
    <a class="vn-poll-secondary" href="$url&amp;VIEW=TRUE">Tulokset</a>
  </div>
</article>
};
}

sub PollMainPage
{
    my @ids = PollListIds();
    my $lang = (($ENV{'NW_LANGUAGE'} || '') eq 'en') ? 'en' : 'fi';
    my $current = PollCurrent($lang);

    print qq{
<main class="vn-poll-center vn-page-width" aria-labelledby="vn-poll-center-title">
  <header class="vn-poll-center__header">
    <span class="vn-section-kicker">Vunet.net</span>
    <h1 id="vn-poll-center-title">Äänestyspalvelu</h1>
    <p>Osallistu ajankohtaiseen äänestykseen tai selaa aikaisempia kysymyksiä.</p>
  </header>
};

    if($current && PollLoad($current)) {
        print qq{<section class="vn-poll-current" aria-labelledby="vn-poll-current-title"><h2 id="vn-poll-current-title" class="vn-visually-hidden">Ajankohtainen äänestys</h2>};
        print _poll_card($current, 1);
        print qq{</section>};
    } elsif(!@ids) {
        print qq{<p class="vn-notice">Äänestyksiä ei ole vielä julkaistu.</p>};
    }

    my @archive = grep { $_ != $current } reverse @ids;
    if(@archive) {
        print qq{
<details class="vn-disclosure vn-poll-archive">
  <summary>Aikaisemmat äänestykset <span class="vn-count-badge">} . scalar(@archive) . qq{</span></summary>
  <div class="vn-disclosure__content vn-poll-list">
};
        print _poll_card($_, 0) for @archive;
        print qq{</div></details>};
    }

    if(eval { NoTracking() }) {
        print qq{<p class="vn-poll-admin-link"><a href="$SCRIPT_ADM">Hallinnoi äänestyksiä</a></p>};
    }
    print qq{</main>};
}
