#!/usr/bin/perl
use utf8;

#
require "admin.pl";

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
HandleRest();


##################################################
sub main
{
	#
	print ("

<br>
<br>

<center>
<h1>VAI-TV (record)</h1>

<!-- BEGIN GENERIC ALL BROWSER FRIENDLY HTML FOR NETSHOW V3 --> 
<OBJECT ID=\"MediaPlayer\"
classid=\"CLSID:22D6F312-B0F6-11D0-94AB-0080C74C7E95\" 
codebase=\"https://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=,1,52,701\" 
standby=\"Loading Microsoft Windows Media Player components...\"  
type=\"application/x-oleobject\"> 
<PARAM name=\"FileName\" value=\"https://www.saunalahti.fi/~ehc50/temp/hologrammed.wmv\"> 
<EMBED type=\"application/x-mplayer2\"  
pluginspage=\"https://www.microsoft.com/Windows/Downloads/Contents/Products/MediaPlayer/\" 
SRC=\"https://www.saunalahti.fi/~ehc50/temp/hologrammed.wmv\" 
name=\"MediaPlayer\" 
width=320 
height=240> 
</EMBED> 
</OBJECT> 

<br>
<br>

		");

	#
	system "echo \"visitor television\" >> television.txt";
}


