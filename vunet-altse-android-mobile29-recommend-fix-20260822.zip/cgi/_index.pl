#!/usr/bin/perl
use utf8;
#############################################################################
# Version Rewrite 2022.
# index.pl - ALTSE text search CGI -frontend for the Internet Search.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);
use Encode;
use DateTime;
use Time::Piece;

#
require "./modules/AltseOpenConfig.pm";
require "./modules/settings.pm";
require "./modules/Logging.pm";
require "./modules/FixScands.pm";
require "./modules/EvalScore.pm";
require "./modules/AltseMenu.pm";
require "./modules/GetDBFileFromURL.pm";
require "./modules/BuildKeywordSuggestionsHTML.pm";
require "./modules/NewContent.pm";
require "./modules/NewSearches.pm";
require "./modules/sql.pm";
#
AltseOpenConfig();

##################################################################################################
#
if($so{'q'} eq "" && $so{'cmd'} ne "go" && $ENV{'SERVER_NAME'} eq "vunet.net")
{
	#
	require "./modules/OpenHTMLDocument.pm";

	#
	print "Content-Type: text/html; charset=UTF-8\n\n";

	# Send error messages to the user, not system log
	open(STDERR,'<&STDOUT');  $| = 1;


	# This should flush stdout.
	my $ofh = select(STDOUT);$| = 1;select $ofh;

	###############################################################################
	#
	# HTML, HEAD, BODY.
	#
	# ./modules/OpenHTMLDocument.pm
	OpenHTMLDocument();
	#
               print("
               <meta http-equiv=\"refresh\" content=\"0; url=/portal/\">
	");	

        CloseHTMLDocument();
	exit;
}

#
if($ENV{'SERVER_NAME'} eq "kultakaivos.info")
{
#
require "./modules/OpenHTMLDocument.pm";



#
print "Content-Type: text/html; charset=UTF-8\n\n";

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;


# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();
#
               print("
<meta http-equiv=\"refresh\" content=\"0; url=https://kultakaivos.info/nw/?FP_SECTION=finnish&section=gold\">
	");	

        CloseHTMLDocument();
	exit;
}

#
if($so{'q'} ne "")
{
	if(
$ENV{'HTTP_USER_AGENT'} =~ /Baiduspider/ ||
$ENV{'HTTP_USER_AGENT'} =~ /YandexBot/ ||
$ENV{'HTTP_USER_AGENT'} =~ /MJ12bot/ ||
$ENV{'HTTP_USER_AGENT'} =~ /AhrefsBot/ ||
$ENV{'HTTP_USER_AGENT'} =~ /SemrushBot/ ||
$ENV{'HTTP_USER_AGENT'} =~ /AmazonBot/ ||
$ENV{'HTTP_USER_AGENT'} =~ /BLEXBot/ ||
$ENV{'HTTP_USER_AGENT'} =~ /Sogou Spider/ ||
$ENV{'HTTP_USER_AGENT'} =~ /SeznamBot/)
	{
#
require "./modules/OpenHTMLDocument.pm";


#
print "Content-Type: text/html; charset=UTF-8\n\n";

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();#

		CloseHTMLDocument();
		exit;
	}
}

#
if($so{'b'} ne "")
{
	$so{'b'} =~ s/[^a-zäöå0-9_\-]//gi;
	$WWW_BASE = $so{'b'};
}
else
{
	$WWW_BASE = "www";
}
#
#$altse_debug = 1;

#
$so{'q'} =~ s|<.+?>||g;;
$so{'q'} =~ s/[\|]/ /g;
$so{'q'} =~ s/^\s//;
$so{'q'} =~ s/\s$//;
$so{'q'} = lc $so{'q'};
$so{'q'} =~ s/[^a-zA-ZäöåÄÖÅ0-9]/ /g;
#
$so{'q'} =~ s/\"/ /gi;
$so{'q'} =~ s/\|/ /gi;
$so{'q'} =~ s/\-\-/ /gi;
#
require "./modules/OpenHTMLDocument.pm";
#
print "Content-Type: text/html; charset=UTF-8\n\n";


#
#print ("
#"urther due maintenance. <a href=\"mailto:jari.t.tuominen\@gmail.com\">jari.t.tuominen\@gmail.com</a><br>
#"<a href=\"https://www.facebook.com/jari.t.tuominen\">https://www.facebook.com/jari.t.tuominen</a><br>
#"");
#"#
#"exit;


#
die "hmm";
if($ENV{'SERVER_NAME'}=~/vunet\.net/)
{
 	print("
<html>

<head>
<script async src=\"https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4178289363390566\"
     crossorigin=\"anonymous\"></script>
     
<meta name=\"google-adsense-account\" content=\"ca-pub-4178289363390566\">
<meta http-equiv=\"refresh\" content=\"0; url=/nw/?FP_SECTION=finnish\">
</head>

<body>
<DIV ALIGN=\"center\">
<IMG SRC=\"/images/Walk.gif\">
</DIV>
</body>

</html>
		");
	exit;
}

#
$MAX_SAFE_PRECOUNT = 5000;
$MAX_SAFE_RESULTS = 500;
#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
$so{'q'} =~ s/^\s+//g;

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# https://www.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();

# MENU.
#print("
#<DIV ALIGN=\"center\">
#        <iframe width=\"100%\" height=\"32\" src=\"/menu/\"
#                frameborder=\"0\"  onload=\"resizeIframe(this)\"/
#                loading=\"lazy\">
#        </iframe>
#</DIV>
#");

        if($so{'q'} eq "" && ($so{'iframe'} eq "" || $so{'iframe'} eq "")
        && $so{'frontpage'} eq "")
        {
                print("
<meta http-equiv=\"refresh\" content=\"0; url=/alternative/index.html\">
                ");
                exit;
        }

# Phases of Search.
if($so{'q'} ne "")
{
        #
        my $HTML_MENU;
        if( $so{'q'} ne "" && $so{'iframe'} eq "") { # && $so{'iframe'} ne "") {
                $HTML_MENU = AltseMenu();
        }
        print $HTML_MENU;


	InitSearch();
	DoSearch();
}

#
if($so{'q'} eq "" && $so{'iframe'} eq "") {
	PrintSearchForm(); 
}

if($so{'iframe'} eq "" && $so{'q'} ne "") { 
        #
        #
        $current_year_month_day = POSIX::strftime("%Y/%m/%d", localtime(time));
        $current_year_month = POSIX::strftime("%Y/%m", localtime(time));
        $current_year = POSIX::strftime("%Y", localtime(time));
        
        #
        print("
<table bgcolor=\"#000\" width=\"100%\">
<tr>
<td>
<font color=\"#FFF\">

        <DIV ALIGN=\"center\">
        <H2>Fix on:
        <A HREF=\"/?q=$so{'q'}&d=$current_year_month_day\" class=\"ubright\">24 hours</A> - <A HREF=\"/?q=$so{'q'}&d=$current_year_month\" class=\"ubright\">This month</A> - <A HREF=\"/?q=$so{'q'}&d=$current_year\" class=\"ubright\">This year</A> - <A HREF=\"/?q=$so{'q'}\" class=\"ubright\">All</A>
        </H2></DIV>
</font>

</td>
</tr>
</table>
        ");

        #
#        print STDERR $so{'q'};
        $first_word = $so{'q'};
        $first_word =~ s/\s$//g;
        $first_word =~ s/^\s//g;
        $first_word =~ s/^(\S*)\s.*/$1/;
        #print $first_word;
        my $htmlcon1 = ("
<table bgcolor=\"#000\" width=\"100%\">
<tr>
<td>

<font color=\"#EEE\">
        <H2>
<STRONG>Did you mean? - Tarkoititko?</STRONG>
</H2>
	");

        $htmlcon1 .= BuildKeywordSuggestionsHTML($first_word, "", "class=yellow");
        print $htmlcon1;
        print "<A HREF=\"/?cmd=go&q=$so{'q'}&clean=1&showurl=1&iframe=1\" class=\"ubright\">-> Print View</A><BR>\n";
        
        #
        my (@sites) = LoadList("cat $DB/$WWW_BASE/fastindex/sites.txt|sort -g|");
        my ($sites_html);
        
        #
        for($i=0; $i<($#sites+1); $i++)
        {
        	 $sites[$i] =~ s/^index[\/]//;
        	 $sites[$i] = sprintf("%1.8d %s", length($sites[$i]), $sites[$i]);
        }
        @sites = sort @sites;
        
        #
        my @common_domains = ("^www", "com", "net", "org");
        #
        for($i=0,$c=0; $i<($#sites+1) && $c<25; $i++)
        {
        	@sp = split(/\s/, $sites[$i]);
        	if($sp[1] ne "")
        	{
        		my @wor = split(/\s/, $so{'q'});

        		loopz1: for($i2=0; $i2<($#wor+1); $i2++)
        		{
	                        for($i4=0; $i4<($#common_domains+1); $i4++)
	                        {
	                        	if($wor[$i2] =~ /$common_domains[$i4]/)
	                        	{
	                        		goto ok1;
	                        	}
	                        }
        			#print $sites[$i] . " " . $wor[$i2] . " ";
        			if($wor[$i2] ne "" && $sp[1] =~ /$wor[$i2]/i)
        			{
        				if(!$got_sites{$sp[1]})
        				{
        					my $entry1 = $sp[1];
        					for($i3=0; $i3<($#wor+1); $i3++)
        					{
        						$entry1 =~ s/($wor[$i3])/<i>$1<\/i>/i;
        					}
	        				$sites_html .= ("
	        				<A HREF=\"/?q=$sp[1]\" class=\"ubright\">$entry1</A> 
	        				");
	        				$got_sites{$sp[1]}++;
					}
        				$c++;
        			}
			ok1:
        		}
        	}
        }
        
        #
        if($sites_html ne "")
        {
        	print "<BR>Related: ";
	        print $sites_html;
	}

	my ($htmlstr,@lstx,$dict);
	@lstx = LoadList("dict \"$so{'q'}\" 2>/dev/null|");
	print("
	<BR>
	");
	for($i=0; $i<($#lst+1); $i++)
	{
		$dict .= "<h2><font color=\"#DDD\">$lstx[$i]</a></h2> \n";
	}
	
	print("
	<Br>
</font>

</td>
</tr>
</table>
	");
	
#	print("
#        <a href='document.innerHTML'>Show more</a		>
#	");

}

# VIEW ONLY THE SUGGESTIONS ON iframe=2 && q!="".
if($so{'iframe'} eq "2" && $so{'q'} ne "")
{
        #
        $first_word = $so{'q'};
        $first_word =~ s/^(\S*)\s.*/$1/;
        #print $first_word;
        my $htmlcon1 = BuildKeywordSuggestionsHTML($first_word);
        print("
        <table
        style=\"
     background-image: url($so{'background'});
        background-size: $so{'background-size'};
        \">
        <tr>
        <td>
        ");
        #
        print $htmlcon1;
        print("
        </td>
        </tr>
        </table>
        ");
}

###################################################################################
#
#
if($so{'q'} eq "" && $so{'module'} eq "videos")
{

        #
        $current_year_month_day = POSIX::strftime("%Y/%m/%d", localtime(time));
        $current_year_month = POSIX::strftime("%Y/%m", localtime(time));
        $current_year = POSIX::strftime("%Y", localtime(time));
        #


	print("
<table width=\"100%\" align=\"center\">
<tr>
<td>
");

	#
	@videos = LoadList("cfg/videos.txt");
	     print("
<table width=\"100%\" align=\"center\" bgcolor=\"#000\">
<tr>
<td>

<div align=\"center\">
<h1 style=\"color:#FF0;\">Best Shots - Parhaat Snapsit</h1>
</div>
");

	for($i=0; $i<($#videos+1); $i++)
	{
		print("
<div style=\"display: box; align: left;\">
		<a href=\"https:\/\/youtube.com/watch?v=$videos[$i]\" target=\"_blank\">
		<img src=\"https://i.ytimg.com/vi/$videos[$i]\/hqdefault.jpg\" align=\"left\"
			width=\"200\" height=\"155\" vspace=\"4\" hspace=\"4\">
		</a>
</div>
		");
	}
	print("
</td>
</tr>
</table>
	");

	print("

   <iframe width=\"100%\" height=\"500\" src=\"/?q=news&iframe=1&max=50&d=$current_year_month_day\"
                        frameborder=\"1\"  onload=\"resizeIframe(this)\"/>
   </iframe>




<font style=\"color:brown\">
<center><strong><H1>Jari's favourite videos</H1></strong></center>
</font><br>

	");
	
	print("

<h1><b>Helvetistä Itään</b></H1><BR>
<h2>Kotiteollisuus</h2>
<br>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/_aB7FxLrS4E?si=yXpEL5nCj59lYRqw\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
	<br>
<br>

<h1><b>Viina, terva & hauta</b></H1><BR>
<h2>Viikate</h2>
<br>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/hmDpLTADhXw?si=jgJ5UL0tpvp2NeZX\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
	<br>
<br>

<h1><b>Poju & DJ Anton-Kannut (Olut virtaa taas)</b></H1><BR>
<h2>SkySound & Rockpool Rec</h2>
<br>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/VjuIoDEzBOs?si=Gr8WH1UUe58dYiaS\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
	<br>
<br>

<h1><b>Donald Trump Christmas Cold Open - SNL</b></H1><BR>
<h2>Saturday Night Live</h2>
<br>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/3Ar80sFzViw?si=izsSYDDLccZViQlz\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
	<br>
<br>


<h1><b>Бутырка - Запахло весной (видеоклип) - Butyrka - Smell of spring (video clip)</b></H1><BR>
<h2>РУССКИЕ ХИТЫ - RUSSIAN HITS</h2>
<br>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/O0sK3mGuSDA?si=2FtUm40Qlpu2iutm\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
	<br>
<br>

<h1><b>БУТЫРКА - 5 лучших клипов | Русский Шансон, FIN - BUTYRKA - 5 parasta leikettä | venäläinen chanson, ENG - BUTYRKA - 5 best clips | Russian chanson</b></H1><BR>
<h2>Butyrskaya prison (Russian: Бутырская тюрьма, tr. Butýrskaya tyurmá), usually known simply as Butyrka (Russian: Бутырка, IPA: [bʊˈtɨrkə]), is a prison in the Tverskoy District of central Moscow, Russia. In Imperial Russia it served as the central transit prison. During the Soviet Union era (1917–1991) it held many political prisoners. As of 2022 Butyrka remains the largest of Moscow's remand prisons. Overcrowding is an ongoing problem.</h2>
<br>
	<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/L8o3mJ8c-Fk?si=0wdaT-4IIpjS6VbB\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
	<br>
<br>

<h1><b>Сергей Наговицын - Блатные Хиты | Sergei Nagovitsyn - Blatnye Hits</b></H1><BR>
<h2>
Sergey Borisovich Nagovitsyn (Russian: Серге́й Борисович Наговицын; 22 July 1968 in Perm, RSFSR, USSR – 21 December 1999 in Perm, Russia) was a Russian singer, composer and author of Russian chanson style songs.
</h2>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/O8NsiaWPZkw?si=wfPODToXB3PVmJ40\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
<br>
<br>

<h1><b>System F - Exhale</b></H1><BR>
<h2>
</h2>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/uG0x0dobSQc?si=xNRc_wJ-uE6Jy_2Q\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
<br>
<br>

<h1><b>🔊 VOCAL TRANCE MIX 2023 🔷 November 🔷 Episode 67</b></H1><BR>
<h2>
</h2>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/b0df2WUaT8U?si=UQB4of8j-O53CEWC\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
<br>
<br>

<h1><b>ВОТ ЭТО ПЕСНЯ ✬ БЕЛАЯ ЛИЛИЯ - THIS IS THE SONG ✬ WHITE LILY</b></H1><BR>
<h2>А Это Счастье! ✬ ПРЕМЬЕРА 2023 - And this is Happiness! ✬ PREMIERE 2023
</h2>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/QTk2dHv2124?si=RNclyWh33SF5EvuG\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
<br>
<br>

<h1><b>Юрий Шатунов - Седая ночь Версия 2019</b></H1><BR>
<h2>
Yuriy Vasilevich Shatunov (Russian: Юрий Васильевич Шатунов; September 6, 1973 – June 23, 2022)[4] was a Russian singer, best known as the lead vocalist of the Russian band Laskoviy Mai (Ласковый май), which were active during the 1980's. After Laskoviy Mai disbanded in 1992, Shatunov found recognition as a solo singer.
</h2>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/gXKI4b2-xA0?si=lS-BnW2s7cszuNVB\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
<br>
<br>

<h1><b>Прощай навеки, последняя любовь: Hyvästi ikuisesti, viimeinen rakkaus: Goodbye forever, last love</b></H1><BR>
<h2>
Goodbye forever, last love
<br>
<br>
Vadim Gennadievich Kazachenko (Russian: Вади́м Генна́диевич Казаче́нко; born 13 July 1963) is a Soviet, Russian, and Ukrainian singer.[1] He had a music career in the 1990s.[2] He was the frontman of the group Freestyle.[3]
</h2>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/qJJiDd-bT1s?si=hbbyApCvYxFPgSY5\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
<br>
<br>


<h1><b>Kake Randelin</h1>
<h2>Kun eletään, ei pelätä</h2>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/SHVoab8Bhl0?si=xX7MhEYlimIYrqep\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
<br>
<br>

<h1><b>Kake Randelin</h1>

<h2>Veljet jotka yössä kohdataan</h2>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/K4p0wN_CvVg?si=6-gKVorEF5Z3_GLM\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
<br>
<br>

<h1><b>Taistojen tiellä</h1>

<h2>Soittokunta ja kuoro</h2>

<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/YS-CSnckHqM?si=bK19Z4YpAkcKaYd8\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
<br>
<br>

<h1><b>Алая роза - Виктор Королев - The Scarlet Rose - Victor Korolev - Punainen Ruusu-Victor Korolev </b></H1><BR>
<h2>
</h2>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/ATcID3WnZ7E?si=0bQHve73i9aw750j\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
<br>
<br>

<h1><b>Столичная - Metropolitan</b></H1><BR>
<h2>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/mJKSO4_T4AY?si=nfpSzUDnpAVbRvPf\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>
<br>
<br>

<a href=\"/images/1024px-Anchorage_Alaska_Museum_Russia_Exhibit_-_Stolichnaya_vodka.jpg\">
<p>
<IMG SRC=\"/images/1024px-Anchorage_Alaska_Museum_Russia_Exhibit_-_Stolichnaya_vodka.jpg\"
	width=\"560\" height=\"400\"
	style\"height: auto !important;\">
</p>
</a><br>
<a href=\"https://open.spotify.com/track/6UNxyQhainwoX7Z3TxbaRu\">
<p>
Listen to all Sergey's songs. - KUUNTELE LISÄÄ.
</p>
</a><br>



Stolichnaya (Russian: Столичная) is one of the most famous Russian vodka brands. Its production began in Moscow in 1901. The label of the bottle shows the Moscow hotel Moskva. The name means from the capital city. The alcohol content of Stolichnaya is 40% by volume. It is also prepared flavored with several different aromas. In March 2022, the Stoli Group company, which produces vodka, announced that the name of the vodka would be shortened to Stoli.[1]
<br>
<br>
Stolitšnaja (ven. Столичная) on yksi tunnetuimmista venäläisistä votkamerkeistä. Sen valmistus aloitettiin Moskovassa vuonna 1901. Pullon etiketissä on moskovalainen hotelli Moskva. Nimi tarkoittaa pääkaupunkilaista.
<br>

Stolitšnajan alkoholipitoisuus on 40 tilavuusprosenttia. Sitä valmistetaan myös useilla eri aromeilla maustettuna.
<br>

Maaliskuussa 2022 vodkaa valmistava Stoli Group -yhtiö ilmoitti vodkan nimen lyhentyvän muotoon Stoli.[1]
<br>
</h2>
<br>
<br>

	");
	print("
</td>
</tr>
</table>
	");
	}

if($so{'q'} ne "" && ($so{'iframe'} eq "1" || $so{'iframe'} eq "")) {

	# RECENT SEARCHES.
	if($so{'iframe'} eq "")
	{
		#print("
		#<script language=\"javascript\" src=\"/jsnewfinds/?full=true\">
		#</script>
		#");
		print BuildNewSearchesHTML();
	}

	#
	print("
	<H3>
	Results
	</H3>
	<BR>
	");
	DisplaySearchResults();
	if($g_continue ne "")
	{
		print("
<A HREF=\"$g_continue\">
<H1>
>> More
</H1>
</A>
		");
	}
} else
{
	
	if($so{'q'} eq "" && $so{'module'} eq "stats")
	{
	##########################
	# Front Page.
	#
#	my (@lst) = LoadList("$DB/download.log");
#	@lst = reverse @lst;
	
	#      0          1                2                                                                      3   4
	# 1697178396 downloaded https://www.washingtonpost.com/politics/2023/10/01/supreme-court-new-term-ethics/ as was/www.washingtonpost.com//home/vai/db/www/was/www.washingtonpost.com/1.dump.gz
	my ($i);
	
	print("
	<DIV ALIGN=\"CENTER\">
	<TABLE width=\"1000\" bgcolor=\"#F0F0F0\">
	<TR>
	<TD>
	");
	
	$ENV{'HOME'} = "/home/vai";
	my @hostlist = LoadList("$DB/altse/bin/hostlist -p $WWW_BASE|sort -g|");

	print("
	<DIV ALIGN=\"CENTER\">
	<H1>
	<FONT COLOR=\"#E04040\">
	List of Websites - Sivustolista
	</FONT>
	</H1>
	</DIV>
	
	
	<TABLE>
	<TR>
	<TD>
	<P>
	<DIV ALIGN=\CENTER\">
	");
	
	for($i=0; $i<($#hostlist+1); $i++)
	{
		@sp = split(/\|/, $hostlist[$i]);
		
		$niceservername = $sp[1];
		$niceservername =~ s/^www[0-9]*\.//;
		
		print("
		<DIV style=\"display: inline-block; float: left; padding: 16px 4px 4px; width: 64; height: 32; font-size: 24px;\">
		<A HREF=\"/?q=$niceservername\">$sp[1]</A> 
		</DIV>
		");
	}
	
	#
	print("
	</DIV>
	</P>
	</TD>
	</TR>
	</TABLE>
	<BR>
	<BR>
	");
	
	
	print("
	
	<DIV ALIGN=\"CENTER\">
	<H1>
	<FONT COLOR=\"#3A3\">
	New Content - Uutta Sisältöä
	</FONT>
	</H1>
	</DIV>
	");

	print("
	
	<DIV ALIGN=\"CENTER\">
	<H1>
	<FONT COLOR=\"#300\">
	Putin News
	</FONT>
	</H1>
	</DIV>
	");


	NewContent("putin");	
        print("<br>");

	print("
	
	<DIV ALIGN=\"CENTER\">
	<H1>
	<FONT COLOR=\"#300\">
	Trump News
	</FONT>
	</H1>
	</DIV>
	");


	NewContent("trump");
	print("<br>");

	print("
	
	<DIV ALIGN=\"CENTER\">
	<H1>
	<FONT COLOR=\"#300\">
	Web Spider's Latest
	</FONT>
	</H1>
	</DIV>
	");
	NewContent("");
	print("<br>");
	
	#
	print("
	</TD>
	</TR>
	</TABLE>
	</DIV>
	");
}
}

#############################################
# THE END OF THE HTML DOCUMENT.
#############################################

#
CloseHTMLDocument();

#
sub InitSearch
{
	@gl_reward_urls = LoadList("ranks/reward_urls.txt");
	@gl_reward_caps = LoadList("ranks/reward_caps.txt");
}

# Parameter: a single word of text.
sub SingleSearch
{
	my ($i,@lst,$con);

	#/db/fastdb/index/title/p/e/t/e
#	goto new_normal;
	
	#$con = $con . $keyword . "," . $nextword;

#	my $dir1 = "$DB/$WWW_BASE/fastindex/index/$_[2]/$chars";
#	print $dir1;
	if(1) #-e $dir1)
	{	
		my ($kw);
		$kw = $so{'q'};
		$kw =~ s/\s/.*/g;
		
		#print $kw;
		
		#@qlst = LoadList("cat \"$DB/juu/index.txt\"|grep -Ei \"[^a-z0-9]$kw\[^a-z0-9\]\"|grep 2024|");
		#if($#qlst>=10)
		#{
		#	@lst = @qlst;
		#}
		#else
		#{
		#print "\"$DB/juu/sorted.txt\"<BR>\n";
		
		#
retry:
#my $querycmd = ("grep -Ei \"[^a-z0-9]$kw\[^a-z0-9\]\"  \"$DB/juu/sorted.txt\" 2>/dev/null|");
# Fast Search, with hashcoded db:
my $querycmd =
("$DB/altse/bin/cmdsearch1.pl \"$so{'q'}\" -b $WWW_BASE 2>/dev/null|grep -i \"$kw\" 2>/dev/null|");
		# Open stream.
		open($f, $querycmd);
		# Error?
		if(!$f) {
			my $retryu = $so{'q'};
			$retryu =~ s/^www[0-9]*[\.]\s*//;
			if($retryu ne $so{'q'})
			{
				$so{'q'} = $retryu;
				goto retry;
			}
			goto past;
		}

if($altse_debug) { print "<H1>Successfully opened pipe: $querycmd</H1>\n"; }
		
		#}
		if($so{'i'} ne "")
		{
			$i = int($so{'i'});
		}
		else
		{
			$i = 0;
		}
		my $t = time();
		for($totcon=0; $totcon<1000 && (time()-$t)<5; $i++)
		{
	 		####$con .= "<H1>$lst[$i]</H1>";
	 		my $line = <$f>; chomp $line;
	 		$spp[0] = $line;
	 		$spp[0] =~ s/^([0-9]+)\s(.*)/$1/;
	 		$spp[1] = $line;
	 		$spp[1] =~ s/^([0-9]+)\s(.*)/$2/;
	 		$spp[1] =~ s/[^a-zäöå0-9_\/\,\.\-]/_/gi;
			#my @spp = split(//, $lst[$i]);
			#if($spp[0] > 0 && $spp[1] ne "" && -e $spp[1])
			
			#
			if(1)
			{
				my $_fn = "$DB/$WWW_BASE/fastindex/$spp[1]";

                                if(!-e $_fn) {
                                	print STDERR "not found:" . $_fn . "<BR>\n";
				}
                                else
                                {
					@res = LoadList($_fn); # \"$DB/$WWW_BASE/fastindex/$lst[$i]\"|");
				}
				if($altse_debug) { print STDERR "result count = $#res<BR>\n"; }
				$totcon += $#res+1;
				if($#res >= 2)
				{
					my $strcon = join("\n", @res);
					$strcon = EncodeToHTMLTags($strcon);
					#$strcon =~ s/\s/ /g;
					#$strcon =~ s/[^\sa-zA-ZäöåÄÖÅ0-9\-\+,\/:;\&\.\'\"\#\%\&ǁ\$\€\£]//g;
					$con = "$con\n$strcon";
					#print $strcon . "<BR>\n";
					#$con =~ s/\r\n/\n/g; 
				}
			}
		}
		if($altse_debug) {
			print("Found $i entires.<BR>\n");
		}
		close($f);

		if($i>=($#lst))
		{
			$g_continue = "";
		}
		else
		{
			$g_continue = "/?q=$so{'q'}&i=$i&d=$so{'d'}";
		}
		
		#print $g_continue . "\n";
	}
	
past:
	#
	return $con;
}

#
sub SearchFor
{
	my (@sp,$con,$i);
	
	@sp = split(/\s/, $_[0]);
	#print $_[0];
	
	#print $#sp+1 . " arguments\n";
	
#	if($#result<10) { $con .= SingleSearch($sp[$i], $sp[$i+1], "title"); }

	$con = "";

	$i=0;
	#for($i=0; $i<($#sp+1); $i++)
	#{
		if($sp[$i+0] ne "")
		{
			#if($#result<10) { $con .= SingleSearch($sp[$i], $sp[$i+1], "description"); }
			#if($#result<10) { $con .= SingleSearch($sp[$i], $sp[$i+1], "title"); }
			#if($#result<10) { $con .= SingleSearch($sp[$i], $sp[$i+1], "keywords"); }
			if($#result<10) { $con .= SingleSearch($sp[$i], $sp[$i+1], "title"); }
		}
	#}
	return $con;
}

#####################################################################################################
# vunet.net CGI CODE.
# (C) 2022 Jari Tapio Tuominen (jari.t.tuominen@gmail.com);
sub PrintSearchForm
{
	#
	my $HTML_MENU;
	if( $so{'q'} ne "" ) { # && $so{'iframe'} ne "") {
		$HTML_MENU = AltseMenu();
	}


	#
	print("
$HTML_MENU

<TABLE width=\"100%\" align=\"center\" bgcolor=\"black\"
	cellpadding=\"24\" cellspacing=\"0\">
<TR><TD>
	");
	
	################
	#
	# LOAD UP THE ALTSE's Search log slog.txt.
	#	
	
	#
	if($so{'q'} ne "")
	{
		$BOYLOGOWIDTH = int(450/2);
		$BOYLOGOHEIGHT = int(300/2);
		$REDCAP = "";
	}
	else
	{
		$BOYLOGOWIDTH = int(350/1.25);
		$BOYLOGOHEIGHT = int(350/1.25);
		
		$REDCAP = ("
<A HREF=\"/\"><H1>		
<H1>vunet.net talousuutishaku - vunet.net economic news search:</H1>
<H2>Hae vaihtoehtoisia talousuutisia täältä, suomeksi ja englanniksi 
- Search In Both Finnish And English </H2></A>

");
	}
#        $recent_searches_html = ("
#<script language=\"javascript\" src=\"/jsnewfinds/?full=\">
#        ");
#	BuildNewSearchesHTMLCompact();
	$SEARCH_FORM_HTML = ("
<CENTER>
<FONT style=\"color: WHITE; font-size: 24px;\">

<FORM method=\"get\" action=\"/?\">

<TABLE width=\"250\" height=\"32\">
<TR>
<TD>
	<A HREF=\"/?q=news\" class=\"ubright\">vunet.net - What's up?</A>
</TD>
</TR>
</TABLE>


<IMG SRC=\"/images/vainews.png\" width=\"200\" height=\"200\"><BR>

<INPUT TYPE=\"Text\" Id=\"q\" Name=\"q\" Value=\"$so{'q'}\"
	style=\"font-size: 24px;\">
<INPUT TYPE=\"Submit\" name=\"\" value=\"vunet.net Search\" target=\"_blank\" size=\"25\"
style=\"  background-color: #046DAA;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;\">

<DIV ALIGN=\"center\">
<TABLE width=\"500\">
<TR>
<TD>
<script language=\"javascript\" src=\"/jsnewfinds/?full=\">
</TD>
</TR>
</TABLE>
</DIV>
</FORM>

</FONT>
</CENTER>
	");
	
	#
#	@trends = LoadList("/usr/bin/perl ./trends|");
#	for($i=0; $i<($#trends+1) && $i<100; $i++)
#	{
#		$key = $trends[$i];
#		$key =~ s/^([0-9]+\s)(.*)$/$2/;
#		print("<DIV ALIGN=\"LEFT\"><A HREF=\"/?q=$key\">$key</A></DIV>");
#	}
	
	#
	
	if($so{'q'} eq "")
	{
        $SEARCH_FORM_HTML .= ("
        <script language=\"javascript\">
        document.getElementById('q').focus();
	</script>
	");
	}


	
	#
	if($so{'q'} eq "")
	{
		# SEARCH FORM
		print("
$SEARCH_FORM_HTML

$HTML_TOP500

	");
	}
	else
	{
		#
		#LogThisSearch();
		#
		print("

$SEARCH_FORM_HTML
<BR>
<FONT STYLE=\"color: WHITE;\">
<DIV ALIGN=\"CENTER\"><H2>
<IMG SRC=\"/images/400px-P_newspaper.svg.png\"
	alt=\"Hakutulokset: $so{'q'}\"
	title=\"Hakutulokset: $so{'q'}\"
	width=\"10\" height=\"8\" valign=\"middle\">
Tulokset haulle - Search Results: \"$so{'q'}\".
" . sprintf("%d",$#search_results+1) . " search result(s).
</H2></DIV>
</FONT>

	");


	}
	




	
	#
	print("
</TD>
</TR>
</TABLE>
	");
}

#
sub DoSearch
{
		#
                LogThisSearch();
		#$so{'q'} =~ s/[\s\.](com|net|org|xyz|online)$//;
		#$so{'q'} =~ s/^www[\s]+//;
 		#$so{'q'} =~ s/http[s]*//g;
		## Nice the query.
		$so{'q'} =~ s|<.+?>||g;;
		$so{'q'} =~ s/[\|]/ /g;
		$so{'q'} =~ s/^\s//;
		$so{'q'} =~ s/\s$//;
		$so{'q'} = lc $so{'q'};
		$so{'q'} =~ s/[^a-zA-ZäöåÄÖÅ0-9]/ /g;
		#print "\"" . $so{'q'}  ." \"\n";
		
		
		## SEARCH - RESULTS
		my ($res, $cfn, @results);
		
		$cfn = "cache/$so{'q'}--$so{'d'}--".int($so{'i'}).".txt";
		
		if( -e $cfn )
		{
			@results2 = LoadList($cfn);
			# GET INDEX VALUE
			$g_continue = $results2[0];
			#
			@results = ();
			for($i=0; $i<($#results2+1); $i++) { push @results, $results2[$i]; }
		}
		else
		{
			$res = SearchFor($so{'q'});
	                $res =~ s/\n\n/\n/g;
	                @results = split(/\n/, $res);
	                
	                # Save results to cache.
	                open($f, ">$cfn");
	                print $f "$g_continue\n";
	                if($f)
	                {
		                for($i=0; $i<($#results+1); $i++)
		                {
		                	print $f $results[$i] . "\n";
		                }
		                close($f);
			}
		}		
		
		my @spam_caps = LoadList("cfg/spam_caps.txt");
		my @spam_urls = LoadList("cfg/spam_urls.txt");
		#print @spam;
			
		#
		#print "results nr = $#results<BR>\n";
		loop: for($i=0; $i<($#results) && $i<$MAX_SAFE_PRECOUNT; $i+=4)
		{
			my $cap = $results[$i+0];
			my $des = $results[$i+1];
			my $url = $results[$i+2];
			if($cap eq "" || length($cap)<12) { $i++; $continue; }
if($altse_debug)
{
print("
cap=\"$cap\"<BR>
purl=\"$print_url\"<BR>
des=\"$des\"<BR>
");
}

			my ($doctime);
			
			if( !($results[$i+3]=~/^.+ǁ.+$/) )
			{
				$doctime = $results[$i+3];
				$doctime =~ s/^.*ǁ([0-9]*).*$/$1/;
				$results[$i+2] =~ s/^(.*)ǁ.*$/$1/;
				$results[$i+2] =~ s/^([^\'\"]+)[\"\'].*$/$1/;

			 if( int($doctime) > 0 )
			 {
			 	eval {
			 	$doctime = DateTime->from_epoch( epoch => $doctime ); 
			 	#strftime("%a %b %e %H:%M:%S %Y", $doctime);
			 	};
			 }
			 else
			 {
			 	$doctime = "";
			 }
			}
			
                        #if($results[$i+2] =~ /http[s]*:\/\// &&
                        #if(length($cap)<5)
                        #{
                        #        goto past;
                        #}
                        $print_url =~ s/\ǁ.*$//g;
                        $des =~ s|<.+?>||g;
                        $cap =~ s|<.+?>||g;
                        $des = encode 'iso-8859-1', $des;
                        $cap = encode 'iso-8859-1', $cap;
                        $des = EncodeToHTMLTags($des);
                        $cap = EncodeToHTMLTags($cap);
                        $des =~ s/[^a-zA-ZäöåÄÖÅ0-9\-\+,\/:;\&\.\'\"\#\%\&ǁ\$\€\£]/ /g;
                        $cap =~ s/[^a-zA-ZäöåÄÖÅ0-9\-\+,\/:;\&\.\'\"\#\%\&ǁ\$\€\£]/ /g;
                        my $host = $print_url;
                        $host =~ s/^http[s]*:\/\/([^\/]+).*$/$1/;
                        if($host=~/http[s]*:\/\// || !($print_url=~/^http[s]*:\/\//))
                        {
                                goto past;
                        }



			$cap =~ s/^\s*//g;
			$cap =~ s/\s*$//g;
			
			
			#for($ii=0; $ii<($#spam_caps+1); $ii++)
			#{
			#	if($spam_caps[$ii] ne "" && $cap =~ /$spam_caps[$ii]/) {
			#		goto past;
			#	}
			#}

			#for($ii=0; $ii<($#spam_urls+1); $ii++)
			#{
			#	my $spammi = $spam_urls[$ii];
			#	if($spam_urls[$ii] ne "" && $print_url =~ /$spammi/) {
			#		goto past;
			#	}
			#}
			
			my ($grepcap) = $so{'grepcap'};
			my ($grepurl) = $so{'grepurl'};
			
			my ($cutcap) = $cap;
			
			$cutcap = $cap;
			$cutcap =~ s/^(.{10}).*(.{10})$/$1-$2/;

			if( !($cap =~ /^http[s]*:\/\// && !$alcap{$cutcap} && !$alurl{$print_url})
				&& ($so{'d'} eq "" || $print_url=~/$so{'d'}/i)
				&& ($so{'grepcap'} eq "" || $cap=~/$grepcap/i)
				&& ($so{'grepurl'} eq "" || $print_url=~/$grepurl/i)
				 )
			{
				#print "<H1>$so{'d'} - $results[$i+0]</H1>\n";
				my $trimcap = $cap;
				$trimcap =~ s/^(.{130}).*$/$1 .../;
				
				# $print_url
#my $score = EvaluateScoreForSearchResultEntry("$url||$trimcap||$des||$host||$doctime");
				$score = int($results[$i+3]);
				
				push(@search_results, (sprintf "%1.8d", $score) . "||$url||$trimcap||$des||$host||$doctime");

				$alcap{$cutcap}++;
				$alurl{$print_url}++;
			}

past:
#			for(; $i<($#results+1) && !($results[$i+0] =~ /^http[s]*:\/\//); $i++)
#			{
#			}
		}
		
#		#
#		print("
#</FONT>
#		");
}

# PRINT ALL SEARCH RESULTS.
#
sub DisplaySearchResults
{
	@search_results = sort @search_results;
	@search_results = reverse @search_results;
	#
	if($so{'max'} eq "") {
		$so{'max'} = 999999;
	}
	for($i=0; $i<($#search_results+1) && $i<$so{'max'} && $i<$MAX_SAFE_RESULTS; $i++)
	{
		PrintSearchResult($search_results[$i]);
	}
}

# PRINT SEARCH RESULT.
sub PrintSearchResult
{
	my @sp = split(/\|\|/, $_[0]);
	
	my $i;
	my @keys = split(/\s/, $so{'q'});
	my $nicecap = $sp[2];
	$nicecap = EncodeToHTMLTags($nicecap);
	if($nicecap=~/^\s*$/ || $alc{$nicecap}) { return; }
	$alc{$nicecap}++;
	for($i=0; $i<($#keys+1); $i++)
	{
		#$keys =~ s/ä/\.\*/g;
		#$keys =~ s/ö/\.\*/g;
		if($nicecap ne "")
		{
			$nicecap =~ s/([^a-zäöå0-9])($keys[$i])([^a-zäöå0-9])/$1<b><font style=\"color: blue;\">$2<\/font><\/b>$3/gi;
		}
	}
	
	#
	#my ($dbfilefn);
	#if( ($dbfilefn = GetDBFileFromURL($sp[1])) )
	#{
	#	#
	#}
	
	#
	my $url = $sp[1];
	my $print_url = 
	#"/viewart/
		"$sp[1]";
        $print_url =~ s/^([^\s]+)\s.*$/$1/;
	if($sp[1]=~/\=/)
	{
		$print_url = $sp[1];
	}

if($so{'clean'} eq "")
{
	print("

<TABLE width=\"100%\" style=\"padding: 4px;\">
<TR>
<TD>

");

# LIKE BUTTON
#
#print("
#<TABLE align=\"left\"><TR><TD>
#        <iframe width=\"82\" height=\"68\" src=\"/like/?url=$sp[1]&action=button\"
#                frameborder=\"0\"  onload=\"resizeIframe(this)\"
#                loading=\"lazy\"/>
#	</iframe>
#</TD></TR></TABLE>
#");
}

print("
				<!--- CAPTION OF THE STORY ------>
                                <font style=\"font-size: 23px;\">
                                <A HREF=\"$url\" target=\"_blank\">$nicecap</A>
                                </font>
");

	if($so{'showurl'} ne "" && $sp[1]=~/http[s]*:\/\//)
	{
		print("
                                <H4><A HREF=\"$sp[1]\" target=\"_blank\">$sp[1]</A> </H4>
		");
	}
	
	if($so{'clean'} eq "")
	{
		if($print_url=~/202[0-9]\/[0-9]+\/[0-9]+/)
		{
		my $ts = $print_url;
		$ts =~ s/^.*\/([0-9]{4}\/[0-9]{2}\/[0-9]{2}).*$/$1/;
		$ts =~ s/\//./g;
		
		print("<STRONG>$ts</strong> - ");
		}
		
	}
	
	#
	if($so{'iframe'} eq "")
	{
	print("
	");
#	print("
#$sp[3] " # rank ".sprintf("%d",$sp[0])," - 
#);
				# Host
				if($sp[4] ne "")
				{
					print("
<A HREF=\"/?q=$sp[4]\" target=\"blank\">$sp[4]</A>
					");
					
					
				}
				if($sp[5] ne "")
				{
					print("
				<H3 style=\"color: #00C000;\">$sp[5]</H3>

						");
	}
    }

if($so{'clean'} eq "")
{
		print("
</TD>
</TR>
</TABLE>

		");
}

}

1;
