#!/usr/bin/perl
use utf8;

#
require "tools.pl";

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURSEC'} = "tv";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


##################################################
sub main
{
	#
	print("
<table width=100% cellpadding=8 cellspacing=0
	bgcolor=\"#000000\">
<tr>
<td>
		");

	#
	print("

<img src=\"$IMAGES_BASE/vtv-banner.gif\" align=right>

<table cellpadding=16 cellspacing=0 width=450 height=450>
<tr>
<td>

<font color=#808080 size=2>
Bufferointi voi kestää max. 30-60 sekuntia. Odota hetki.<br>
Buffering can take upto 30-60 seconds. Please wait awhile.
</font>

<object id=\"MediaPlayer\"
  classid=\"CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95\"
  codebase=\"https://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=6,4,5,715\"
  standby=\"Loading Microsoft Windows Media Player components...\"
  type=\"application/x-oleobject\">

    <param name=\"FileName\" value=\"https://la.vunet.net:4000\">
    <param name=\"SAMIFilename\" value=\"https://server/path/your-SAMIcaptionfile.smi\">
    <param name=\"AnimationatStart\" value=\"true\">
    <param name=\"TransparentatStart\" value=\"true\">
    <param name=\"AutoStart\" value=\"true\">
    <param name=\"ShowControls\" value=\"1\">

    <embed type=\"application/x-mplayer2\"
      pluginspage=\"https://www.microsoft.com/isapi/redir.dll?prd=windows&sbp=mediaplayer&ar=Media&sba=Plugin&\"
      src=\"https://la.vunet.net:4000\"
      name=\"MediaPlayer\"
      ShowControls=\"1\"
      width=\"512\"
      height=\"384\">
    </embed>

</object>

</td>
</tr>
</table>
		");

	#
	print("
<br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br>
</td>
</tr>
</table>
		");
}


