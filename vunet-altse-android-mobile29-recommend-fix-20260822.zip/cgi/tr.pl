#!/usr/bin/perl
use utf8;
#######################################################################
#
# VAI English to Finnish Translator.
#
#######################################################################
#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

require "tools.pl";

# Search arguments line for options.
#$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

#######################################################################
sub TranslateInit
{
	my $i,$i2,$i3,$i4,@tmp,@tmp2;

	#
	@tmp = LoadList("dictionary.txt");

	#
	for($i=0,$i2=0; $i<($#tmp+1); $i++)
	{
		@tmp2 = split("\=", $tmp[$i]);
		$dict[$i2++] = $tmp2[0];
		$dict[$i2++] = $tmp2[1];
	}
}

#######################################################################
sub LoadSourceText
{
	my $i,$i2,$i3,$i4,@tmp,@tmp2;

	#
	@tmp = LoadList($_[0]);

	#
	for($i=0,$i2=0; $i<($#tmp+1); $i++)
	{
		@tmp2 = split("\ ", $tmp[$i]);
		for($i3=0; $i3<($#tmp2+1); $i3++)
		{
			$wo[$i2] = $tmp2[$i3];
			$wo[$i2] =~ s/[.|,|!|\"|']//g;
			$wo[$i2] =~ tr/[A-ZÄÖÅ]/[a-zäöå]/;
			$i2++;
		}
	}
}

#######################################################################
sub TranslateWord
{
	my $i,$i2,$i3,$i4,@tmp,$tmp2,
		$str,$str2,$match;

	#
	if($skip)
	{
		$skip--;
		return true;
	}

	#
	for($i=0; $i<($#dict); $i+=2)
	{
		# Skip plain numbers.
		if( $_[0] =~ /[0-9]/ )
		{
			goto past;
		}

		#
		@tmp = split("-", $dict[$i]);

		#
		for($i2=0,$match=0; $i2<($#tmp+1); $i2++)
		{
			if( $wo[$_[1]+$i2] eq $tmp[$i2] )
			{
				$match++;
				if($match == ($#tmp+1))
				{
					print "$dict[$i+1] ";
					$skip = $match-1;
					$err1--;
					return true;
				}
			}
		}
past:
	}

	#
	$err1++;
	if($err1 >= 4)
	{
		print "\n\nUnknown English word '$_[0]', word #$_[1].\n";
		exit();
	}
	else
	{
		if($_[0] =~ /\d/)
		{
			print "$_[0] ";
		}
		else
		{
			print "?$_[0]? ";
		}
	}
	return false;
}

#######################################################################
sub Translate1
{
	my $i,$i2,$i3,$i4,@tmp,$tmp2,$r,
		$str,$str2;

	#
	print stderr "file: $#wo words.\n";
	print stderr "dictionary: $#dict words.\n";
	print stderr "-------------------------------------------------\n";

	#
	$skip = 0;

	#
	for($i=0; $i<($#wo+1); $i++)
	{
		#
		TranslateWord($wo[$i], $i);
	}
}

#######################################################################
sub Translate
{
	#
	TranslateInit();

	#
	LoadSourceText("example.txt");

	#
	Translate1();
}

#######################################################################
sub main
{
	#
	Translate();
	print("\n\n\n");
}


