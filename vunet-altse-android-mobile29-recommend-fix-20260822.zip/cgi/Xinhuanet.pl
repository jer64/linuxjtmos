#!/usr/bin/perl
use utf8;
#

#
require "tools.pl";

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURFPSEC'} = "english";
$ENV{'CURSEC'} = "xinhuanet";
#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();

########################################################################################################
#
sub ShowJsNews
{
	my ($i,$i2,$i3,$i4,$str,$str2,$fn,$fn2,@lst,$f,$f2);

	#
	$fn = "/home/vai/altse/html/js/$_[0].js";
	$fn2 = "/home/vai/altse/html/js/\_$_[0].js";
	$fn2b = "/~vai/js/\_$_[0].js";

	#
	if(!(-e $fn2) || FileAge($fn2)>120)
	{
		#
		@lst = LoadList($fn);

		#
		open($f, ">$fn2") || die "Oops... Something bad happended, mail LST\@VUNET.ORG";
		for($i=0; $i<($#lst+1); $i++)
		{
			#
			if( !($lst[$i] =~ /\{/)) {
				$lst[$i] =~ s/(http.*\")/http:\/\/vunet.net\?to\=$1/;
			}
			else
			{
				if($lst[$i]=~/www\.plenglish\.com/i)
				{
	$lst[$i] =~ s/http:\/\/\S*ID=\{(.*)\}\S*\=EN/http:\/\/vunet.net\?pl\=$1/;
				}
			}
			#
			print $f "$lst[$i]\n";
		}
		close($f);
	}

	#
	print("
		$str
		<script language=\"JavaScript\" src=\"$fn2b\"></script>
		");
}

#################################################################################################
#
sub main
{
	#
	print("
<TABLE width=70% cellpadding=32 cellspacing=0>
<TR>
<TD>
		");
		
	#
	ShowJsNews("XinhuaWorld");

	#
	print("
</TD>
</TR>
</TABLE>
	");
}


