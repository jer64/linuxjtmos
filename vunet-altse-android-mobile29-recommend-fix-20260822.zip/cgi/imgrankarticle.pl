#!/usr/bin/perl
use utf8;
# article thumb - athumb.pl
##########################################################################################

#
require "./tools.pl";

#
print "Content-type: image/gif\n\n";
#print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$kuva = "/home/vai/altse/html/www/thumb_up_c.gif";
$kuva_er = "/home/vai/altse/html/www/icon_jtmos_error.gif";
$kuva_er2 = "/home/vai/altse/html/www/grey_icon_jtmos_error.gif";
$kuva_er3 = "/home/vai/altse/html/www/invert_grey_icon_jtmos_error.gif";
#https://vunet.net/images/thumb_up.gif
chdir("/home/vai/cgi");

#
#if( 
#!($ENV{'HTTP_REFERER'} =~ /incoronation\.com/) 
#&&
#!($ENV{'HTTP_REFERER'} =~ /vunet\.net/) 
#D#&&
#!#($ENV{'HTTP_REFERER'} =~ /www\.kultakaivos.info\.info/) 
#)
#{
#	exit;
#}

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

##########################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,$opt);
	my @des=("down", "up");
	my @desimg=(
		"thumb_down.gif",
		"thumb_up.gif"
	);

	#
	if($ENV{'REMOTE_HOST'} =~ /googlebot\.com/)
	{
	        system("cat \"$kuva_er\"");
	        exit;
		#die "No access suitable for googlebot.com.\n";
	}
	
	#
	if( !($so{'article'}=~/^[a-z]+\/pub_artikkeli[0-9]+\.txt$/) )
	{
		$so{'article'} = "";
                system("cat \"$kuva_er2\"");
                exit;
	}
# $so{'article'} =~ s|^([^/]+)/pub_artikkeli(\d+)\.txt$|$1/pub_artikkeli$2.txt|
	my $rankfn = $so{'article'};
	$rankfn =~ s/\.txt$/\.rank/;
	
	#
	my $afn = "articles/$so{'article'}";
 	if($rankfn=~/\.rank$/ && -e "$afn") { # /home/vai/cgi/cache/genstat.txt 
system("/home/vai/altse/bin/rankarticle.pl \"$afn\" 1>/dev/null 2>/dev/null");
# \"/home/vai/cgi/cache/genstat_1w.txt\" \"/home/vai/cgi/cache/genstat_5w.txt\" \"/home/vai/cgi/cfg\" 2>/dev/null > \"articles\/$rankfn\"");
	} else {
                system("cat \"$kuva_er3\"");
                exit;

	}

	#
	system("cat \"$kuva\"");

	#
}


