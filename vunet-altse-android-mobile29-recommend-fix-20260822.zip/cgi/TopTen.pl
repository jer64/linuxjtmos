#!/usr/bin/perl
use utf8;
#
# TOP TEN CHART GENERATOR CGI SCRIPT.
#
##############################################################################################################

use POSIX qw(strftime);
use Encode;
use Encode::Guess;
use HTML::Entities;
#
require "./tools.pl";
require "./modules/KeywordsAverage.pm";
require "./modules/ViewArticleLib.pm";

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log.
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();
$ENV{'CURSEC'} = "topafi";
$so{'section'} = "topafi";
$so{'FP_SECTION'} = "finnish";
#
$fontsz = 4;
$fontszmain = 6;

#
if($ENV{'HTTP_HOST'}=~/vunet.net\/gold/) {
        $so{'FP_SECTION'} = "gold";
}

#
                #
                my $INDEXFN;
                if($so{'FP_SECTION'} eq "goldenchinatv") {
                        $INDEXFN = "GoldenChinaTVindex.html";
                } elsif($so{'FP_SECTION'} eq "gold") {
                        $INDEXFN = "goldindex.html";
                } elsif($so{'FP_SECTION'} eq "english") {
                        $INDEXFN = "englishindex.html";
                } else {
                        $INDEXFN = "webindex2.html";
                }
                @web = OpenWebIndex($INDEXFN);
                $wherebe = 0;
WebWalkTo("CHOOSE-TITLE1");
print("
<TITLE>Vunet.org Popularity Chart - Vunet:in Suosionkartoitus</TITLE>
<meta name=\"keywords\" content=\"popular, top ten, famous, most readed, top news, top notch, news, rumours, videos, kulta, hopea, pronssi, pörssi, pörssikauppa, kultakaivos.info, talousuutisia, bisnesuutisia maailmalta,Kominform, capitalism, kapitalismi, kapitalismi, sosiaalidemokratia, demokratia, totuus, Social democracy.\">
<META name=\"description\" content=\"TOP 100 suosituinta uutista kaikkialta maailmalta.\">

<SCRIPT LANGUAGE=\"JavaScript\">
function OpenIt(URL)
{
        newWindow = window.open(URL, '', 'width=700,height=480');
}

function OpenIt1(URL,W,H)
{
        newWindow = window.open(URL, '', 'width='+W+',height='+H);
}
</SCRIPT>
".JSAdminTools()."
");
SkipTo("CHOOSE-TITLE2");
WebWalkTo("main-menu");
if($so{'fp'} eq "") { $so{'fp'} = "finnish"; }
if($so{'section'} eq "") { $so{'section'} = "top100"; }

#
if($so{'FP_SECTION'} ne "gold") {
print inc_menu($so{'section'}, $so{'fp'});
                        } elsif($so{'FP_SECTION'} eq "gold") {
                my $printti =
                inc_gold_menu($so{'section'}, $so{'FP_SECTION'});
		print $printti;
}
#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


###########################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,$str,$str2,$fn,$lt,$hits,$unit);

	#
	$xxfilter = $so{'s'};
	$filter = $so{'q'};
	$xfilter = $so{'n'};

	#
	if($so{'q'}=~/video/i)
	{
		$unit = "Videos";
	}
	else
	{
		$unit = "Articles";
	}

	#
	if($so{'t'} ne "" && $so{'t'}=~/suo/)
	{
		$tit = $so{'t'};
	}
	else
	{
		$tit = "100 suosituinta uutista / Vunet.net";
	}

	#
	print("
<TABLE width=100% cellspacing=0 cellpadding=32>
<TR>
<TD width=550>
		");

	#
	print("
<TABLE width=550 cellspacing=0 cellpadding=0>
<TR>
<TD>

<DIV ALIGN=CENTER>
<FONT SIZE=\"$fontszmain\">
<i>
$tit
</i>
</FONT>
</DIV>

</TD>
</TR>
</TABLE>
<BR>

		");

	#
	@lst = LoadList("topten.txt");
	@lst2 = LoadList("topdate.txt");

	#
	for($i=0,$hits=0; $i<($#lst+1); $i++)
	{
		$str = $lst[$i];
		$str =~ s/^([0-9]*) .*$/$1/;
		$hits += $str;
	}

	#
	my $unique_html = ("


<TABLE width=550 cellspacing=0 cellpadding=0>
<TR>
<TD>
<DIV align=center>
$hits uniikkia artikkelin lukukertaa.
</DIV>
</TD>
</TR>
</TABLE>
");

#
        #
#        my $KEYWORD_HTML = ProduceKeywordsAverageHTML("bright", "4");

#
if($so{'sq'} eq "")
{
print("
<P>
<h2>
<a href=\"?sq=kulttuuri\">
> Kuuntele musiikkia!
</a>
</h2>
</P>
");
}
        #
        @gl_lst1 = @lst;
        my $top_table_html =("
<!--- SEPERATOR VERTICAL LINES --->
<TABLE WIDTH=100% HEIGHT=1 CELLSPACING=0 CELLPADDING=0
	BGCOLOR=\"#000000\">
<TR><TD></TD></TR></TABLE>

<TABLE WIDTH=100% HEIGHT=1 CELLSPACING=0 CELLPADDING=0
	BGCOLOR=\"#E0E040\">
<TR><TD></TD></TR></TABLE>

<TABLE WIDTH=100% HEIGHT=1 CELLSPACING=0 CELLPADDING=0
	BGCOLOR=\"#000000\">
<TR><TD></TD></TR></TABLE>

<TABLE width=550 cellspacing=0 cellpadding=0>
<TR>

<TD width=60 bgcolor=#FFFFFF>

<DIV ALIGN=CENTER>
<B>sija</B>
</DIV>
</TD>

<TD width=430 bgcolor=#FFFFFF>
artikkelin otsikko
</TD>

<TD width=60 bgcolor=#FFFFFF>
<DIV ALIGN=CENTER>
<FONT COLOR=#FF0000 size=\"$fontsz\">
<B>lukijaa</B>
</FONT>
</DIV>

</TD>

</TR>
</TABLE>

<!--- SEPERATOR VERTICAL LINES --->
<TABLE WIDTH=100% HEIGHT=1 CELLSPACING=0 CELLPADDING=0
	BGCOLOR=\"#000000\">
<TR><TD></TD></TR></TABLE>

<TABLE WIDTH=100% HEIGHT=1 CELLSPACING=0 CELLPADDING=0
	BGCOLOR=\"#E0E040\">
<TR><TD></TD></TR></TABLE>

<TABLE WIDTH=100% HEIGHT=1 CELLSPACING=0 CELLPADDING=0
	BGCOLOR=\"#000000\">
<TR><TD></TD></TR></TABLE>
		" . ProduceTopHTML($filter));
	
        #
        my $KEYWORD_HTML = ProduceKeywordsAverageHTML("dark", "6");
        print("<div class=\"ad_window_title\">" .
			$KEYWORD_HTML . $unique_html . 
			$top_table_html .
		"</div>");


	# topdate.txt
	############################################
	
	#
	print("
<BR><BR>

<!--- SEPERATOR VERTICAL LINES --->
<TABLE WIDTH=100% HEIGHT=1 CELLSPACING=0 CELLPADDING=0
	BGCOLOR=\"#000000\">
<TR><TD></TD></TR></TABLE>

<TABLE WIDTH=100% HEIGHT=1 CELLSPACING=0 CELLPADDING=0
	BGCOLOR=\"#E0E040\">
<TR><TD></TD></TR></TABLE>

<TABLE WIDTH=100% HEIGHT=1 CELLSPACING=0 CELLPADDING=0
	BGCOLOR=\"#000000\">
<TR><TD></TD></TR></TABLE>

<TABLE width=550 cellspacing=0 cellpadding=0>
<TR>

<TD width=60 bgcolor=#Fff>

<DIV ALIGN=CENTER>
<B>sija</B>
</DIV>
</TD>

<TD width=490 bgcolor=#Fff>
artikkelin otsikko
</TD>

<TD width=60 bgcolor=#FFF>
<DIV ALIGN=CENTER>
<FONT COLOR=#FF0000 size=\"$fontsz\">
<B>miilloin</B>
</FONT>
</DIV>

</TD>

</TR>
</TABLE>

<!--- SEPERATOR VERTICAL LINES --->
<TABLE WIDTH=100% HEIGHT=1 CELLSPACING=0 CELLPADDING=0
	BGCOLOR=\"#000000\">
<TR><TD></TD></TR></TABLE>

<TABLE WIDTH=100% HEIGHT=1 CELLSPACING=0 CELLPADDING=0
	BGCOLOR=\"#E0E040\">
<TR><TD></TD></TR></TABLE>

<TABLE WIDTH=100% HEIGHT=1 CELLSPACING=0 CELLPADDING=0
	BGCOLOR=\"#000000\">
<TR><TD></TD></TR></TABLE>
		");


	#
	$lt = time;
	@lst2 = sort @lst2;
	@lst2 = reverse @lst2;
	loop: for($i=0,$rp=0,$i2=0,$score_low=99999999,$score_high=-1,$score_avg=0; $rp<100 && $i<($#lst2+1); $i++)
	{
		#
		$t = time;
		if( ($t-$lt) >= 3 )
		{
			last loop;
		}

		#
		$num = $rp+1;

		#
		$fn = $lst2[$i];
		$fn =~ s/^[0-9]* //;
		$fn = "$fn.txt";
		
		#
		my $sq = $so{'sq'};
		$sq =~ s/[^a-z0-9]//g;
		if($sq ne "")
		{
			#die "<P>sq = \"$sq\"</P>";
			if($fn =~ /$sq/)
			{
			}
			else
			{
				goto past;
			}
		}

		#
		if(-e $fn)
		{
			@art = LoadList($fn);
			$cap = $art[0];
			$cap =~ s/<[^\>]*>//g;
			$score = $lst2[$i];
			$score =~ s/^([0-9]+)[^0-9].*$/$1/;
			$score = sprintf "%d", $score;
			#if(!NoTracking()) { $score = "N/A"; }			
			$url = $fn;
			$url =~ s/^$ENV{'DOCUMENT_ROOT'}//;
			$url = "/" . CapUrl($url, $cap);
			$url =~ s/^\/s//;
			if($cap eq "") { goto past; }
			
			my $found = 0;
			idloop: for($ii=0; $ii<($#art+1); $ii++)
			{
				# https://www.youtube.com/embed/CmBZdUdD1-o?si=lj1JNPRgHZNtVhv9
				#print $art[$ii];
if(
$art[$ii] =~/object/
&& $art[$ii]=~/https:\/\/www\.youtube\.com\/embed\/[a-zA-Z0-9\-]+/)
				{
					my $video_id = $art[$ii];
$video_id =~ s/^.*https:\/\/www\.youtube\.com\/embed\/([a-zA-Z0-9\-]+).*$/$1/;
					$found = 1;
					last idloop;
				}
			}
			
			if($found)
			{
#				print "JOO";
			}
		}
		else
		{
			goto past;
		}

		#
		if($filter ne "" && !($cap=~/$filter/i))
		{
			goto past;
		}

		#
		if($xfilter ne "" && ($cap=~/$xfilter/i))
		{
			goto past;
		}

		#
		if($xxfilter ne "" && !($lst2[$i]=~/$xxfilter/i))
		{
			goto past;
		}

		#
		if($rp<10)
		{
			$titbg = "#E0E040";
		}
		elsif($rp<20 && $rp>=10)
		{
			$titbg = "#E0E0E0";
		}
		else
		{
			$titbg = "#C0C0C0";
		}

		#
		$scores[$i2++] = $score;
		if($score<$score_low)
		{
			$score_low = $score;
		}
		if($score>$score_high)
		{
			$score_high = $score;
		}

		#
		print("
<TABLE width=550 height=1 cellspacing=0 cellpadding=0 bgcolor=#000000>
<TR>
<TD>
</TD>
</TR>
</TABLE>

<TABLE width=550 cellspacing=0 cellpadding=0>
<TR>

<TD width=60 bgcolor=#FFF>
<DIV ALIGN=CENTER>
<B>$num</B>
</DIV>
</TD>

<TD width=430 bgcolor=$titbg>

<TABLE width=100% cellpadding=4 cellspacing=0>
<TR>
<TD>
<A HREF=\"$url\" class=\"dark\" title=\"https://$ENV{'HTTP_HOST'}$url\">
<font size=\"$fontsz\">
$cap
</font>
</A>
</TD>
</TR>
</TABLE>

</TD>

<TD width=60 bgcolor=#FFF>
<DIV ALIGN=CENTER>
<FONT COLOR=#C0C0C0 size=$fontsz>
<B>".strftime("%Y-%m-%d %H:%M:%S", localtime($score))."</B>
</FONT>
</DIV>
</TD>

</TR>
</TABLE>

			");

	#
	$rp++;
past:
	}

	#
	for($i=0,$score_avg=0; $i<($#scores+1); $i++)
	{
		$score_avg += $scores[$i];
	}
	if(($#scores+1)>0)
	{
		$score_avg /= ($#scores+1);
	}
	else
	{
		$score_avg = 1;
	}
	$score_avg = sprintf "%d", $score_avg;

	#
	$fn = "$so{'q'}";
	$fn =~ s/[^a-zA-Z]/_/g;
	$fn = "cache/avg_$fn.txt";
	open($f, ">$fn");
	print $f "$score_low\n";
	print $f "$score_high\n";
	print $f "$score_avg\n";
	close($f);

	#
	print("
</TD>


<TD width=100% valign=top>
<A HREF=\"https://vunet.net\">
<IMG SRC=\"https://images.vunet.net/banners/best_investments_parhaat_sijoituskohteet_sijoitukset.png\" border=\"1\">
</A>
</TD>

</TR>
</TABLE>
		");

	#
	if(!NoTracking() && !isRobot($ENV{'REMOTE_HOST'}))
	{
                #
                open($f, "|mail seuranta\@vunet.net -s \"$ENV{'SERVER_NAME'}: Top 100: $ENV{'REMOTE_HOST'}\" 2>/dev/null");
                print $f "Uusi kävijä kävi Top 100-sivuilla osoitteesta:\n";
                print $f "From: $ENV{'REMOTE_HOST'} ($ENV{'REMOTE_ADDR'})\n";
                foreach $key (sort(keys %ENV))
                {
                        print $f "$key=\"$ENV{$key}\"\n";
                }
                print $f "==========================================\n";
                print $f "Vaihtoehtouutiset Information System\n";
                print $f "https://vunet.net\n";
                close($f);
	}

	#
}

#
sub ProduceTopHTML
{
	my ($html_top,$i,$i2,$rp,$score_high,$score_low,$lt,$fn);
	
	$filter = $_[0];

	# Produce Top 100
	$lt = time;
	loop: for($i=0,$rp=0,$i2=0,$score_low=99999999,$score_high=-1,$score_avg=0; $rp<100 && $i<($#gl_lst1+1); $i++)
	{
		#
		$t = time;
		if( ($t-$lt) >= 3 )
		{
			last loop;
		}

		#
		$num = $rp+1;

		#
		$fn = $gl_lst1[$i];
		$fn =~ s/^[0-9]* //;
		$fn = "$fn.txt";


                #
                my $sq = $so{'sq'};
                $sq =~ s/[^a-z0-9]//g;
                if($sq ne "")
                {
                        #die "<P>sq = \"$sq\"</P>";
                        if($fn =~ /$sq/)
                        {
                        }
                        else
                        {
                                goto past;
                        }
                }

		#
		if(-e $fn)
		{
			@art = LoadList($fn);
			$cap = $art[0];
			$cap =~ s/<[^\>]*>//g;
	                # New.
	                push(@gl_titles, $cap);
			#
			$score = $gl_lst1[$i];
			$score =~ s/^([0-9]*) .*$/$1/;
			$score = sprintf "%d", $score;
			#if(!NoTracking()) { $score = "N/A"; }
			$score = sprintf "%d", $score;			
			$url = $fn;
			$url =~ s/^$ENV{'DOCUMENT_ROOT'}//;
			$url = "/" . CapUrl($url, $cap);
			$url =~ s/^\/s//;
			if($cap eq "") { goto past; }

			my $found = 0;
			my ($video_id);
			idloop: for($ii=0; $ii<($#art+1); $ii++)
			{
				# https://www.youtube.com/embed/CmBZdUdD1-o?si=lj1JNPRgHZNtVhv9
				#print $art[$ii];
if(
$art[$ii] =~/object/
&& $art[$ii]=~/http[s]:\/\/www\.youtube\.com\/embed\/[a-zA-Z0-9\-]+/)
				{
					$video_id = $art[$ii];
					$playerh = $art[$ii];
$video_id =~ s/^.*http[s]:\/\/www\.youtube\.com\/embed\/([a-zA-Z0-9\-]+).*$/$1/;
					$found = 1;
					last idloop;
				}
			}
			
			if($found)
			{
#				print "JOo $video_id";
				my $html1 = ("<object><iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/$video_id\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe></object>");
				$html1 =~ s/\\/\\\\/g;
				$html1 =~ s/\"/\\\"/g;
				$html1 =~ s/\'/\\\'/g;
        $str =~ s/[\t\n\r\s]/ /g;
        $str =~ s/  / /g;
        $str =~ s/\"/\\\"/g;
				#$html1 =~ s/\</\\\</g;
				#$html1 =~ s/\>/\\\>/g;
				#$html1 =~ s/\\/\\\\/g;
				$html1 =~ s/[\t\n\r]//g;
				$html_top .= ("
				<script language=\"Javascript\">
				var plrhtml$i = \"$html1\";
				</script>
				<div id=\"fplayer$i\" name=\"fplayer$i\">
<a href=\"javascript:void(0);\" onclick=\"document.getElementById('fplayer$i').innerHTML=plrhtml$i;\">
				<img src=\"https://img.youtube.com/vi/$video_id/0.jpg\" border=\"2\"
					width=\"300\" height=\"210\" class=\"bright\">
				</a>
				</div>
				");
			}
		}
		else
		{
			goto past;
		}

		#
		if($filter ne "" && !($cap=~/$filter/i))
		{
			goto past;
		}

		#
		if($xfilter ne "" && ($cap=~/$xfilter/i))
		{
			goto past;
		}

		#
		if($xxfilter ne "" && !($gl_lst1[$i]=~/$xxfilter/i))
		{
			goto past;
		}

		#
		if($rp<10)
		{
			$titbg = "#E0E0E0";
		}
		elsif($rp<20 && $rp>=10)
		{
			$titbg = "#E0E0E0";
		}
		else
		{
			$titbg = "#E0E0E0";
		}

		#
		$scores[$i2++] = $score;
		if($score<$score_low)
		{
			$score_low = $score;
		}
		if($score>$score_high)
		{
			$score_high = $score;
		}

		#
		my $htmlstr = ("
<TABLE width=650 height=1 cellspacing=0 cellpadding=0 bgcolor=#FFF>
<TR>
<TD>
</TD>
</TR>
</TABLE>

<TABLE width=650 cellspacing=0 cellpadding=0>
<TR>

<TD width=60 bgcolor=#FFF>
<DIV ALIGN=CENTER>
<B>$num</B>
</DIV>
</TD>

<TD width=550 bgcolor=$titbg>

<TABLE width=100% cellpadding=4 cellspacing=0>
<TR>
<TD>
<A HREF=\"$url\" class=\"dark\" title=\"https://$ENV{'HTTP_HOST'}$url\">
<font size=\"$fontsz\">
$cap
</font>
</A>
</TD>
</TR>
</TABLE>

</TD>

<TD width=60 bgcolor=#FFF>
<DIV ALIGN=CENTER>
<FONT COLOR=#C0C0C0 size=\"$fontsz\">
<B>$score</B>
</FONT>
</DIV>
</TD>

<TD width=125>");

			#
			my $ARTID = $fn;
			$ARTID =~ s/^.*pub_artikkeli([0-9]+).*$/$1/;
			$so{'section'} = $fn;
			$so{'section'} =~ s/^.*\/([a-z]+)\/[a-z_]+[0-9]+\.[a-z]+.*$/$1/;
			$so{'section'} =~ s/^([a-z]+).*$/$1/;
			my $tex = ("

	<table width=\"125\" bgcolor=\"#FFF\" cellspacing=\"0\" cellpadding=\"0\">
	<tr>
	<td>
	<FONT SIZE=3>

<div id=\"imgathumb3\_$ARTID\_$so{'section'}\">
<A HREF=\"javascript:RenderHtml('imgathumb3\_$ARTID\_$so{'section'}','<img src=\\\'/cgi/imgathumb.pl?t=1&id=$ARTID&section=$so{'section'}\\\'>');\"
                class=\"dark\">
        <IMG SRC=\"$IMAGES_BASE/thumb_up.gif\" align=\"middle\" border=\"0\"><font size=\"2\"> Suosittele</font>
        <font size=\"6\">+</font>
        </A>
</div>

</font>
	</td>
	</tr>
	</table>
			");
			
$htmlstr .= ("
$tex
</td>

</TR>
</TABLE>

			");
			$html_top .= $htmlstr;

	#
	$rp++;
past:
	}
	
	#
	return $html_top;
}
