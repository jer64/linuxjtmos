#!/usr/bin/perl
use utf8;
#########################################################
#
# post_usenet_article.pl
#
#########################################################
require "tools.pl";

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$ENV{'CURSEC'} = "ilm";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

# Confirm sending of the message.
sub Confirmation
{
	my ($i,$i2,$i3,$i4,$found,@lst);
	@g = (
	"sfnet.keskustelu.politiikka",
	"alt.politics.bush",
	"test.group",
        "sfnet.tori.myydaan.kannettavat",
        "sfnet.tori.myydaan.komponentit",
        "sfnet.tori.myydaan.elokuvat",
        "sfnet.tori.ostetaan.muut",
        "sfnet.tori.myydaan.muut",
        "sfnet.tori.harrastus.valokuvaus",
        "sfnet.tori.tyopaikat.tarjotaan",
        "sfnet.tori.tyopaikat.halutaan",
        "sfnet.tori.asunnot",
        "sfnet.tori.ruoka+juoma",
        "sfnet.keskustelu.huumori",
        "sfnet.tori.veneily",
		);

	#
	print ("
<TABLE width=100% cellspacing=0 cellpadding=0>
<TR valign=top>
<TD width=640>
		<table width=\"640\" class=usenet_window
			cellspacing=0 cellpadding=0>
		<tr valign=top>
		<TD width=100%>

		<center>
		<h2>
<IMG SRC=\"$IMAGES_BASE/fast_mail.gif\" class=bulletin border=0>
Ilmoituksen julkaisu</h2>
		</center>

		<form action=\"/np.pl\" method=\"post\">
		otsikko: <input type=text name=cap value=\"$so{'cap'}\" size=80 id=ta><BR>
		nimi/nimimerkki: <input type=text name=nick value=\"$so{'nick'}\" size=20 id=ta><BR>
		sähköpostiosoite: <input type=text name=email value=\"$so{'email'}\" size=20 id=ta><BR>
		ryhmä: <select name=group>");
	for($i=0; $i<($#g+1); $i++)
	{
		print "<option>$g[$i]</option>\n";
	}
	if($so{'content'} eq "")
	{
		$so{'content'} = "Kirjoita tähän kuvaus.";
	}
	print("
		</select>
		<textarea name=content cols=60 rows=5>$so{'content'}</textarea><BR>
		<input type=submit value=\"lähetä\">
		<input type=hidden name=send value=true>
		</form>

		Huomio!: lähettäminen edellyttää että täytät kaikki yllämainitut kohdat.<BR>
		Sähköpostiosoitteen saa naamioida roskapostin ehkäisemiseksi.<BR>
		<b>Myynti-ilmoitukset</b> (kun myyt jotain) alkavat tavanomaisesti otsikolla \"M: ...\" ja<BR>
		<b>ostoilmoitukset</b> (kun ilmoitat ostavasi jotain) \"O: ...\".<BR>
		<b>Sähköpostiosoite</b> ei jostain jenkkien keksimistä syistä saa sisältää skandeja.<BR>
		<BR>
		Esimerkkejä <b>toimivista otsikoista</b>:<BR>
		O:Sony Ericsson k500i<BR>
		O: Sony PSP -käsikonsoli<BR>
		M: Jääkaappi<BR>
		M: Sähkömoottori 4 kW<BR>
		<BR>
		Kiitos kun luit!<BR>
		<BR>
		Terv. ylläpito<BR>
		admin at vunet.net<BR>

		<script language=\"Javascript\">
		document.getElementById('ta').focus();
		</script>

		<br><br><br><br>

		</td>
		</tr>
		</table>
</TD>
<TD width=100%>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
</TD>
</TR>
</TABLE>
		");
}

sub Jonoon
{
	my ($i,$i2,$i3,$i4,$fn,$fn2,$str,$str2,$t,@lst);

	#
	$t = time;

	#
	$fn = "outgoing/post$t.txt";
	open($f, ">$fn");
	print $f "Subject: $so{'cap'}\n";
	print $f "From: $so{'nick'} <$so{'email'}>\n";
	print $f "Newsgroups: $so{'group'}\n";
	print $f "Content-Type: text\n\n";
	@lst = split(/\n/, $so{'content'});
	for($i=0; $i<($#lst+1); $i++)
	{
		print $f "$lst[$i]\n";
	}
	close($f);
}

# Add address to the mailing list.
sub AddToQueue
{
	my ($i,$i2,$i3,$i4,$found,@lst);

	#########################################################################
	# Lisää listalle.
	#
	if($so{'action'} eq "mailmsg")
	{
		#########################################################################
		#
		Jonoon();

		#
		$url = "https://vunet.net/tori.pl";

		#
		print("<i><b>Ilmoitusteksti on lisätty jonoon käsiteltäväksi ja lisättäväksi.</b></i>
<meta http-equiv=\"refresh\" content=\"1; url=$url\">
");
	}
	else
	{
		die "unknown action\n";
	}

	#
}

#
sub main
{
	my ($i,$i2,$i3,$i4,$found,@lst);

	#
#	if($so{'file'} eq "") { die "article not defined\n"; }

	#
	$url = $so{'file'};
	$url =~ s/^([a-z]*)\/pub_artikkeli([0-9]*)\.txt$/http:\/\/vunet.net\/$1\/story-$2.html/;

	#
	OpenWebIndex("./webindex2.html");
	# Add main menu.
	WebWalkTo("main-menu");
	print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});

	#
	WebWalkTo("enterhere_section");
	if($so{'send'} eq "true")
	{
		#
		if($so{'cap'} eq "" || $so{'email'} eq "" || $so{'content'} eq "" || $so{'nick'} eq "")
		{
			goto conf;
		}
		$so{'action'} = "mailmsg";
		AddToQueue();
	}
	else	
	{
conf:
		Confirmation();
	}
	
        #
        WebWalkTo("ALAPALKKITAHAN");
        #
        print EndBar();

	#
	HandleRest();

	if(!NoTracking() && !isRobot($ENV{'REMOTE_HOST'}))
	{
                # Report to master.
                open($f, "|mail jari\@vunet.net -s \"[Postitus] vierailu: $ENV{'REMOTE_HOST'}\"");
                print $f "https://vunet.net/np.pl?$ENV{'QUERY_STRING'}\n\n";
                print $f "Uusi käynti sivulla IP:stä :\n";
                print $f "From: $ENV{'REMOTE_HOST'} ($ENV{'REMOTE_ADDR'})\n";
                foreach $key (sort(keys %ENV))
                {
                        print $f "$key=\"$ENV{$key}\"\n";
                }
                print $f "==========================================\n";
                print $f "Vaihtoehtouutiset Information System\n";
                print $f "https://vunet.net\n";
                close($f);
	}

	#
 }

#



