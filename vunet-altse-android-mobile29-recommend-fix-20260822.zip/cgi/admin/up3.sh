#!/bin/bash
#
lynx -dump "https://vunet.net/saa.pl?q=Helsinki" > /dev/zero
lynx -dump "https://vunet.net/saa.pl?q=Jyv�skyl�" > /dev/zero
lynx -dump "https://vunet.net/saa.pl?q=Kuopio" > /dev/zero
lynx -dump "https://vunet.net/saa.pl?q=Turku" > /dev/zero
lynx -dump "https://vunet.net/saa.pl?q=Lahti" > /dev/zero
lynx -dump "https://vunet.net/saa.pl?q=Rovaniemi" > /dev/zero
lynx -dump "https://vunet.net/saa.pl?q=Lappeenranta" > /dev/zero
lynx -dump "https://vunet.net/saa.pl?q=Ivalo" > /dev/zero
lynx -dump "https://vunet.net/saa.pl?q=Oulu" > /dev/zero
/home/vai/cgi/comwea
