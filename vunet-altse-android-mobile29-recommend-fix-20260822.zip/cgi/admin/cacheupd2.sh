#!/bin/bash
/home/vai/cgi/cacheupd.sh
/home/vai/cgi/up3.sh
/home/vai/cgi/up2.sh

