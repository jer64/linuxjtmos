#!/bin/bash
grep -iE "^[0-9]+\|[a-z0-9]+\|" cache/genstat.txt > cache/genstat_1w.txt
grep -iE "^[0-9]+\|[a-z0-9]+\s[a-z0-9]+\|" cache/genstat.txt > cache/genstat_2w.txt
grep -iE "^[0-9]+\|[a-z0-9]+\s[a-z0-9]+\s[a-z0-9]+\|" cache/genstat.txt > cache/genstat_3w.txt
grep -iE "^[0-9]+\|[a-z0-9]+\s[a-z0-9]+\s[a-z0-9]+\s[a-z0-9]+\s[a-z0-9]+\|" cache/genstat.txt > cache/genstat_5w.txt
