#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
main();

#################################################################################################
#
sub main
{
	my ($str,$str2,$str3,$str4,$i,$i2,$fn);

	#
	@GL_SECTIONS = LoadList("sections.txt");
	if($ARGV[0] eq "gold") {
		@GL_CACHE_24_H = LoadList("cache/chart-gold-cache-86400-0.asc");
	} else {
		@GL_CACHE_24_H = LoadList("cache/chart-cache-86400-0.asc");
	}

	#
	@GL_CACHE_24_H = reverse @GL_CACHE_24_H;

	#
	if($ARGV[0] ne "") {
		my @qual = LoadList("$ENV{'HOME'}/articles/$_[0]/fileindex.txt");
		for($i=0; $i<($#qual+1); $i++) {
			$qual[$i] =~ s/^..\///;
		}
	}

	#
	for($i=0; $i<($#GL_CACHE_24_H+1) && $i<20; $i++)
	{
		#
		my $cacent = $GL_CACHE_24_H[$i];
		#if( !($cacent=~/^\s*[0-9]+\s\<([0-9]+)x[0-9]+\>\s*$/) )
		#{
		#	print STDERR "Warning. Garbage at cache/chart-cache-86400-0.asc: $cacent\n";
		#	goto skip;
		#}

		#
		$str = $cacent;
		$str =~ s/^\s*[0-9]+\s\<([0-9]+)x[0-9]+\>\s*$/$1/;
	
		$str2 = $cacent;
		$str2 =~ s/^\s*[0-9]+\s\<[0-9]+x([0-9]+)\>\s*$/$1/;

		$str3 = $cacent;
		$str3 =~ s/^\s*([0-9]+)\s\<[0-9]+x[0-9]+\>\s*$/$1/;

		#$str4 = "$GL_SECTIONS[$str]/pub_artikkeli$str2.txt";
		$str4 = $cacent;
		$str4 =~ s/^[0-9]+\s+(.+)$/$1/;
		$str4 =~ s/^$ARTBASE\/+//;
		print "$str4=1\n";

		if($str4 =~ /^[a-z]\/pub_artikkeli[0-9]*\.txt$/)
		{
			print STDERR $str4 . "\n";
			$GL_TOP20{$str4}++;
		}
skip:
	}

	#
	#open($f, ">cache/top20.txt");
	#$i=0; 
	#loop: foreach $key (keys %GL_TOP20)
	#{
	#	if($i>=20) { last loop; }
	#	$i++;
	#	print $f "$key\=1\n";
	#}
	#close($f);

	#
}

