#!/usr/bin/perl
use utf8;
use File::Basename qw(dirname);

my $ADMIN_BASE = dirname(__FILE__);
my $CGI_BASE   = dirname($ADMIN_BASE);
require "$CGI_BASE/tools.pl";
require "$CGI_BASE/modules/poll-cfg.pl";
require "$CGI_BASE/modules/PollSystem.pm";
require "$CGI_BASE/modules/ModernHTML.pm";

$ENV{'CURSEC'} = 'hallinto';
$DONT_AFFECT_DB = 1;

binmode STDIN,  ':encoding(UTF-8)';
binmode STDOUT, ':encoding(UTF-8)';
print "Content-Type: text/html; charset=UTF-8\n";
print "X-Robots-Tag: noindex, nofollow\n\n";
open(STDERR, '>&STDOUT');
$| = 1;

ArgLineParse();

my $lang = (($so{'lang'} || '') eq 'en') ? 'en' : 'fi';
my $message = '';
my $message_kind = 'info';

if(($so{'CMD'} || '') eq 'START') {
    if(PollSetCurrent($lang, $so{'POLL'})) {
        $message = 'Aktiivinen äänestys päivitettiin.';
        $message_kind = 'success';
    } else {
        $message = 'Äänestyksen aktivointi epäonnistui.';
        $message_kind = 'error';
    }
    $so{'CMD'} = '';
}
elsif(($so{'CMD'} || '') eq 'SAVE') {
    my @answers;
    for my $i (1..20) {
        push @answers, ($so{"form$i"} || '');
    }
    my ($ok, $result) = PollSave(
        $so{'POLL'},
        $so{'form0'} || '',
        \@answers,
        {
            image   => $so{'formimage'} || '',
            reftext => $so{'formreftext'} || '',
            refurl  => $so{'formrefurl'} || '',
        }
    );
    if($ok) {
        $message = "Äänestys $result tallennettiin.";
        $message_kind = 'success';
        $so{'POLL'} = $result;
        $so{'CMD'} = '';
    } else {
        $message = $result eq 'two_answers_required'
            ? 'Anna kysymys ja vähintään kaksi vastausvaihtoehtoa.'
            : $result eq 'question_required'
                ? 'Anna äänestykselle kysymys.'
                : 'Äänestyksen tallentaminen epäonnistui.';
        $message_kind = 'error';
        $so{'CMD'} = 'EDIT';
    }
}

OpenWebIndex("$CGI_BASE/webindex2.html");
WebWalkTo('CHOOSE-TITLE1');
print qq{<title>Vunet News Center – äänestysten hallinta</title>\n};
SkipTo('CHOOSE-TITLE2');
WebWalkTo('main-menu');
print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'} || 'finnish');
WebWalkTo('ENTERHERE_SECTION');

PollAdministration();

WebWalkTo('ALAPALKKITAHAN');
print EndBar();
HandleRest();

sub _msg
{
    return if $message eq '';
    print qq{<p class="vn-poll-message vn-poll-message--$message_kind" role="status">} . VNHtmlEscape($message) . qq{</p>};
}

sub PollEditor
{
    my $id = $so{'POLL'};
    $id = PollNextId() if !PollValidId($id);
    my $poll = (($so{'CMD'} || '') eq 'CREATE') ? undef : PollLoad($id);
    my $question = $poll ? $poll->{'question'} : ($so{'form0'} || '');
    my @answers = $poll ? @{$poll->{'answers'}} : map { $so{"form$_"} || '' } (1..20);
    my $image = $poll ? $poll->{'image'} : ($so{'formimage'} || '');
    my $reftext = $poll ? $poll->{'reftext'} : ($so{'formreftext'} || '');
    my $refurl = $poll ? $poll->{'refurl'} : ($so{'formrefurl'} || '');

    print qq{
<section class="vn-admin-card vn-poll-editor" aria-labelledby="vn-poll-editor-title">
  <div class="vn-poll-editor__head">
    <div><span class="vn-section-kicker">Äänestys $id</span><h2 id="vn-poll-editor-title">} . ($poll ? 'Muokkaa äänestystä' : 'Luo uusi äänestys') . qq{</h2></div>
    <a class="vn-poll-secondary" href="$SCRIPT_ADM?lang=$lang">Sulje editori</a>
  </div>
  <form class="vn-admin-form vn-poll-admin-form" action="$SCRIPT_ADM" method="post">
    <input type="hidden" name="CMD" value="SAVE">
    <input type="hidden" name="POLL" value="$id">
    <input type="hidden" name="lang" value="$lang">
    <label class="vn-admin-field"><span>Kysymys</span><input type="text" name="form0" value="} . VNHtmlEscape($question) . qq{" required maxlength="500"></label>
    <fieldset class="vn-poll-answer-editor">
      <legend>Vastausvaihtoehdot</legend>
};
    for my $i (1..20) {
        my $value = VNHtmlEscape($answers[$i-1] || '');
        my $required = $i <= 2 ? ' required' : '';
        print qq{<label class="vn-admin-field vn-poll-answer-field"><span>Vastaus $i</span><input type="text" name="form$i" value="$value" maxlength="300"$required></label>\n};
    }
    print qq{
    </fieldset>
    <details class="vn-disclosure vn-poll-advanced">
      <summary>Lisäasetukset</summary>
      <div class="vn-disclosure__content vn-admin-form">
        <label class="vn-admin-field"><span>Kuvan URL</span><input type="url" name="formimage" value="} . VNHtmlEscape($image) . qq{" inputmode="url"></label>
        <label class="vn-admin-field"><span>Referenssin kuvaus</span><input type="text" name="formreftext" value="} . VNHtmlEscape($reftext) . qq{" maxlength="300"></label>
        <label class="vn-admin-field"><span>Referenssin URL</span><input type="url" name="formrefurl" value="} . VNHtmlEscape($refurl) . qq{" inputmode="url"></label>
      </div>
    </details>
    <div class="vn-admin-form-actions"><button class="vn-admin-button" type="submit">Tallenna äänestys</button></div>
  </form>
</section>
};
}

sub PollAdministration
{
    my @ids = PollListIds();
    my $current = PollCurrent($lang);
    print qq{
<main class="vn-admin-center vn-page-width vn-poll-admin" aria-labelledby="vn-poll-admin-title">
  <header class="vn-admin-header">
    <div class="vn-admin-heading">
      <span class="vn-admin-kicker">Vunet News Center</span>
      <h1 id="vn-poll-admin-title">Äänestysten hallinta</h1>
      <p>Luo, testaa ja aktivoi Vunet.netin äänestyksiä.</p>
    </div>
  </header>
};
    _msg();

    print qq{
<section class="vn-admin-card">
  <div class="vn-poll-admin-toolbar">
    <form action="$SCRIPT_ADM" method="get" class="vn-poll-language-form">
      <label for="poll-lang">Kieli</label>
      <select id="poll-lang" name="lang" onchange="this.form.submit()">
        <option value="fi"} . ($lang eq 'fi' ? ' selected' : '') . qq{>Suomi</option>
        <option value="en"} . ($lang eq 'en' ? ' selected' : '') . qq{>Englanti</option>
      </select>
    </form>
    <div class="vn-poll-admin-toolbar__actions">
      <a class="vn-poll-primary" href="$SCRIPT_ADM?CMD=CREATE&amp;POLL=} . PollNextId() . qq{&amp;lang=$lang">Luo uusi</a>
      <a class="vn-poll-secondary" href="$SCRIPT_MAIN">Avaa julkinen äänestyspalvelu</a>
      <a class="vn-poll-secondary" href="/cgi/admin/newscenter.pl">News Center</a>
    </div>
  </div>
  <p class="vn-poll-card__meta">} . scalar(@ids) . qq{ äänestystä. Aktiivinen: } . ($current || 'ei valittu') . qq{.</p>
</section>
};

    if(($so{'CMD'} || '') eq 'EDIT' || ($so{'CMD'} || '') eq 'CREATE') {
        PollEditor();
    }

    print qq{<section class="vn-admin-card" aria-labelledby="vn-poll-list-title"><h2 id="vn-poll-list-title">Äänestykset</h2><div class="vn-poll-admin-list">};
    for my $id (reverse @ids) {
        my $poll = PollLoad($id) or next;
        my $results = PollResults($id);
        my $total = $results ? $results->{'total'} : 0;
        my $q = VNHtmlEscape($poll->{'question'});
        my $active = ($id == $current) ? qq{<span class="vn-poll-badge">Aktiivinen</span>} : '';
        print qq{
<article class="vn-poll-admin-row">
  <div class="vn-poll-admin-row__content">$active<span class="vn-poll-id">#$id</span><h3>$q</h3><span class="vn-poll-card__meta">$total ääntä</span></div>
  <div class="vn-poll-admin-row__actions">
    <a href="$SCRIPT_ADM?CMD=EDIT&amp;POLL=$id&amp;lang=$lang">Muokkaa</a>
    <a href="$SCRIPT?POLL=$id">Testaa</a>
};
        if($id != $current) {
            print qq{<a class="vn-poll-start" href="$SCRIPT_ADM?CMD=START&amp;POLL=$id&amp;lang=$lang">Aktivoi</a>};
        }
        print qq{</div></article>};
    }
    print qq{</div></section></main>};
}
