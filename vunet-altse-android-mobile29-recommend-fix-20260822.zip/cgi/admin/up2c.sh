#!/bin/bash

#
cd /home/vai/altse/html/cgi/admin
#
PATH=$PATH:/home/vai/sdb/bin
export PATH

#
touch /home/vai/cache/reades_online.txt
chmod a+rw /home/vai/cache/reades_online.txt

#
#echo "8: Updating All Time Top"
#lynx -source "https://vunet.net/chart.pl?MAGIC=32785782378523758&TLI=86400" > /tmp/index-alltop.html
#cp /tmp/index-alltop.html /home/vai/altse/html/cache/index-alltop.html 
#
echo "9: Updating users favorites"
lynx -source https://vunet.net/userfavs.pl > /tmp/index-userfavs.html
cp /tmp/index-userfavs.html /home/vai/altse/html/cache/index-userfavs.html
echo "9B: Updating whats new"
lynx -source https://vunet.net/whatsnew.pl > /tmp/index-whatsnew.html
cp /tmp/index-whatsnew.html /home/vai/altse/html/cache/index-whatsnew.html

#
echo "10: Updating videos section cached page.";
lynx -source "https://vunet.net/nw.pl?top=1&js=top_videos.js&maxts=50&section=videos&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-videos.html

echo "11: Updating kummalliset section cached page.";
lynx -source "https://vunet.net/nw.pl?top=1&js=top_kummalliset.js&section=kummalliset&maxts=100&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-kummalliset.html

echo "12: Updating sexy cached page.";
lynx -source "https://vunet.net/nw.pl?q=strip alasto christina vibr seksi tissi alasti jessica galleria kuvia alba aasialaisia naisia porn takamuk takamus perse pylly masturb huor ilotyt&maxts=200&section=kummalliset&rs=seksi&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-seksi.html

#echo "12B: Updating Heikki Kinnunen -section"
#lynx -source "https://vunet.net/?rs=heikki&q=heikki+kinnunen&maxts=80&section=kulttuuri&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-heikki.html

echo "13: Updating cached section Picks.";
lynx -source "https://vunet.net/nw.pl?top=1&js=top_picks.js&section=picks&maxts=100&FP_SECTION=english" > /home/vai/altse/html/cache/index-picks.html

echo "16: Updating cached section Libya..";
lynx -source "https://vunet.net/nw.pl?rs=libya&q=libya&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-libya.html

echo "17: Updating cached section Laos.";
lynx -source "https://vunet.net/nw.pl?rs=laos&q=laos&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-laos.html

echo "18: Updating cached section Vietnam.";
lynx -source "https://vunet.net/nw.pl?rs=vietnam&q=vietnam&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-vietnam.html

echo "19: Updating cached section Kuuba.";
lynx -source "https://vunet.net/nw.pl?rs=kuuba&q=kuuba&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-kuuba.html

echo "20: Updating cached section Venezuela.";
lynx -source "https://vunet.net/nw.pl?rs=venezuela&q=venezuela&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-venezuela.html

echo "21: Updating cached section Kiina.";
lynx -source "https://vunet.net/nw.pl?rs=kiina&q=kiina&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-kiina.html

echo "21B: Updating cached section Venaj�.";
lynx -source "https://vunet.net/nw.pl?rs=venaja&q=ven%E4j%E4&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-venaja.html

echo "21BA: Updating cached section NATO..";
lynx -source "https://vunet.net/nw.pl?rs=nato&q=nato&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-nato.html

echo "22BB: Updating cached section SCO..";
lynx -source "https://vunet.net/nw.pl?rs=sco&q=sco&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-sco.html

echo "22BC: Updating cached section CSTO..";
lynx -source "https://vunet.net/nw.pl?rs=csto&q=csto&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-csto.html

echo "22BD: Updating cached section youtube..";
lynx -source "https://vunet.net/nw.pl?rs=youtube&q=video&maxts=200&section=kaikki&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-youtube.html

echo "21C: Updating cached section Intia.";
lynx -source "https://vunet.net/nw.pl?rs=intia&q=intia&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-intia.html

echo "22: Updating cached section Korea.";
lynx -source "https://vunet.net/nw.pl?rs=korea&q=korea&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-korea.html

echo "24: Updating cached section Iran.";
lynx -source "https://vunet.net/nw.pl?rs=iran&q=iran&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-iran.html

echo "25: Updating cached section Ossetia.";
lynx -source "https://vunet.net/nw.pl?rs=ossetia&q=ossetia&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-ossetia.html

echo "26: Updating cached section Serbia..";
lynx -source \
"https://vunet.net/nw.pl?rs=serbia&q=serbia&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-serbia.html

echo "27: Updating cached section Egypti..";
lynx -source "https://vunet.net/nw.pl?rs=egypti&q=egypti&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-egypti.html

echo "28: Updating cached section Irak..";
lynx -source "https://vunet.net/nw.pl?rs=irak&q=irak&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-irak.html

echo "29: Updating cached section Syyria..";
lynx -source "https://vunet.net/nw.pl?rs=syyria&q=syyria&maxts=200&section=ulkomaat&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-syyria.html

echo "30: Updating cached section Jim Rogers..";
lynx -source "https://vunet.net/nw.pl?rs=jim_rogers&q=rogers&maxts=200&section=talous&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-jim_rogers.html

echo "31: Updating cached section Kulta..";
lynx -source "https://vunet.net/nw.pl?rs=kulta&q=kulta&maxts=200&section=kaikki&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-kulta.html

echo "32: Updating cached section Hopea..";
lynx -source "https://vunet.net/nw.pl?rs=hopea&q=hopea&maxts=200&section=kaikki&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-hopea.html

echo "33: Updating cached section Pronssi..";
lynx -source "https://vunet.net/nw.pl?rs=pronssi&q=pronssi&maxts=200&section=kaikki&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-pronssi.html


echo "34: Updating cached section Pakistan..";
lynx -source "https://vunet.net/nw.pl?rs=pakistan&q=pakistan&maxts=200&section=kaikki&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-pakistan.html

echo "35: Updating cached section Myanmar..";
lynx -source "https://vunet.net/nw.pl?rs=myanmar&q=myanmar&maxts=200&section=kaikki&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-myanmar.html

echo "36: Updating cached section hongkong..";
lynx -source "https://vunet.net/nw.pl?rs=hongkong&q=hong%20kong&maxts=200&section=kaikki&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-hongkong.html

echo "37: Updating cached section Thaimaa..";
lynx -source "https://vunet.net/nw.pl?rs=thaimaa&q=thaimaa&maxts=200&section=kaikki&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-thaimaa.html

echo "38: Updating cached section Singapore..";
lynx -source "https://vunet.net/nw.pl?rs=singapore&q=singapore&maxts=200&section=kaikki&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-singapore.html

echo "39: Updating cached section Jemen..";
lynx -source "https://vunet.net/nw.pl?rs=jemen&q=jemen&maxts=200&section=kaikki&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-jemen.html



#
echo "Running psykologia.sh ..."
/home/vai/altse/html/cgi/admin/psykologia.sh
echo "Running bush.sh ..."
/home/vai/altse/html/cgi/admin/bush.sh

# Chinese and Russian outlets.
echo "26"
echo "Updating Chinese and Russian outlets..."
/home/vai/altse/html/cgi/admin/up_main.sh

#
#echo "28"
#echo "Updating automated news sections..."
#cd ~/articles/global/; gather.pl
#cd ~/articles/democrats/; gather.pl
#cd ~/articles/progressive/; gather.pl

#
echo "29"
echo "Updating Xinhua news RSS/XML feeds..."
cd ~/cache/; wget https://www.xinhuanet.com/english2010/rss/chinarss.xml \
-O english_chinanews.xml;
cd ~/cgi
cd ~/cache/; wget https://www.xinhuanet.com/english2010/rss/businessrss.xml \
-O english_chinabiz.xml;
cd ~/cgi
cd ~/cache/; wget https://www.xinhuanet.com/english2010/rss/worldrss.xml \
-O english_world.xml;
cd ~/cgi
cd ~/cache/; wget https://www.xinhuanet.com/english2010/rss/photosrss.xml \
-O english_photos.xml; \

cd ~/cgi
cd ~/cache/; wget \
"https://feeds.feedburner.com/PeterSchiffsEconomicCommentary?format=xml" \
-O peter_schiff.xml; \

cd ~/cgi

#
echo "Done."

