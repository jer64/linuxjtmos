#!/usr/bin/perl
#############################################################################
#
# ifeditart.pl
# Iframe-based Edit article.
#
# Called by a HTML form:
# ifeditart.pl?FILE=&RETURL=&CAPTION=
# Called by itself:
# ifeditart.pl?FILE=&RETURL=&CAPTION=&CMD=
#
#############################################################################

use utf8;

#
print "Content-Type: text/html; charset=UTF-8\n\n";
open(STDERR,'<&STDOUT');  $| = 1;

#
use Encode qw(decode encode is_utf8 FB_CROAK);
use Encode::Guess;
require "./tools.pl";
require "./modules/AltseOpenConfig.pm";
use HTML::Entities qw(encode_entities);

$DONT_AFFECT_DB = 1;
ArgLineParse();

main();

#######################################################
sub _escape_for_html_attr {
	my ($s)=@_;
	$s //= '';
	$s =~ s/&/&amp;/g;
	$s =~ s/"/&quot;/g;
	$s =~ s/</&lt;/g;
	$s =~ s/>/&gt;/g;
	return $s;
}

#######################################################
sub EditArticleForm
{
	my ($i,$str,$WARNING);

	@art = LoadList($fname);

	for($i=0; $i<($#art+1); $i++)
	{
		if($art[$i] =~ /\<o\:p\>/i) { $WARNING = 1; }
		$art[$i] = fix_text_to_unicode($art[$i]);
	}

	if($so{'CAPTION'} eq "") { $so{'CAPTION'} = "Artikkelin muokkaaminen"; }

	print qq(
		<div align="center">
			<font size="6"><b>$so{'CAPTION'}</b></font>
		</div>
		<br>
	);

	if($WARNING)
	{
		print qq(
			<div style="padding:10px;border:1px solid #cc0000;background:#220000;color:#fff;margin:10px 0;">
				<b>WARNING!</b> Complex HTML format detected. Edit with YOUR OWN RESPONSIBILITY.<br>
				This article should probably be edited with a bare HTML editor.
			</div>
		);
	}

	# Build initial content for editor
	my $initial_html = "";
	my $plain_mode   = ($so{'PLAIN'} eq "true") ? 1 : 0;

	if($so{'CONTENT'})
	{
		# If CONTENT already posted back, prefer it
		if($plain_mode) {
			# show as escaped text (will become text in editor)
			$initial_html = encode_entities($so{'CONTENT'});
			$initial_html =~ s/\r//g;
			# keep newlines as <br> for display
			$initial_html =~ s/\n/<br>\n/g;
		} else {
			$initial_html = $so{'CONTENT'};
		}
	}
	else
	{
		# load from file
		if($plain_mode)
		{
			for($i=0; $i<($#art+1); $i++)
			{
				$art[$i] =~ s/\r//g;
				$art[$i] =~ s/\n//g;
				$art[$i] =~ s/<br>/\n/ig;
			}
		}

		for($i=0, $str=""; $i<($#art+1); $i++)
		{
			next if ($art[$i]=~/^\s*$/ && $art[$i+1]=~/^\s*$/);

			if($plain_mode)
			{
				my $t = $art[$i];
				$t =~ s/\r//g;
				$t =~ s/\n//g;
				$t = encode_entities($t);
				$initial_html .= $t . "<br>\n";
			}
			else
			{
				$initial_html .= $art[$i];
				$initial_html .= "\n";
			}
		}
	}

	my $file_esc   = _escape_for_html_attr($fname);
	my $returl_esc = _escape_for_html_attr($so{'RETURL'});
	my $plain_val  = _escape_for_html_attr($so{'PLAIN'});

	print qq(
		<style>
			/* Minimal WYSIWYG look */
			.vu-toolbar{
				display:flex; flex-wrap:wrap; gap:6px;
				padding:8px; margin:10px 0 8px;
				border:1px solid #333; background:#111; color:#fff;
				width: 690px;
			}
			.vu-toolbar button{
				border:1px solid rgba(255,255,255,0.25);
				background:#1a1a1a; color:#fff;
				padding:6px 10px; cursor:pointer;
				font-size: 13px;
			}
			.vu-toolbar button:hover{ background:#222; }
			.vu-toolbar .sep{ width:1px; background:#333; margin:0 6px; }

			.vu-editor{
				width: 690px;
				min-height: 380px;
				padding: 10px;
				border:1px solid #333;
				background: #0b0b0b;
				color: #f0f0f0;
				font-family: Arial, Helvetica, sans-serif;
				font-size: 14px;
				line-height: 1.4;
				white-space: normal;
				overflow:auto;
			}
			.vu-editor:focus{
				outline:none;
				box-shadow: 0 0 0 2px rgba(255,215,0,0.25);
				border-color: rgba(255,215,0,0.5);
			}

			.vu-hint{
				width: 690px;
				color: #aaa;
				font-size: 12px;
				margin-top: 6px;
			}
		</style>

		<form method="post" action="ifeditart.pl" onsubmit="return vuBeforeSubmit();">
			<input type="hidden" name="cmd" value="cmdeditart123894">

			<input type="hidden" name="PLAIN" value="$plain_val">
			<input type="hidden" value="$file_esc" name="FILE">
			<input type="hidden" value="$returl_esc" name="RETURL">

			<!-- Hidden field that receives editor content on submit -->
			<textarea name="CONTENT" id="CONTENT" style="display:none;"></textarea>

			<div class="vu-toolbar">
				<button type="button" onclick="vuCmd('bold')"><b>B</b></button>
				<button type="button" onclick="vuCmd('italic')"><i>I</i></button>
				<button type="button" onclick="vuCmd('underline')"><u>U</u></button>
				<span class="sep"></span>
				<button type="button" onclick="vuMakeLink()">Linkki</button>
				<button type="button" onclick="vuCmd('unlink')">Poista linkki</button>
				<span class="sep"></span>
				<button type="button" onclick="vuRemoveEmptyLines()">Poista tyhjät rivit</button>
				<button type="button" onclick="vuAutoWrapDot()">Rivitys pisteen jälkeen</button>
				<span class="sep"></span>
				<button type="button" onclick="vuPlainize()">Siivoa (tekstiksi)</button>
			</div>

			<div id="editor" class="vu-editor" contenteditable="true">$initial_html</div>

			<div class="vu-hint">
				Vinkki: Tallennus synkkaa sisällön automaattisesti. (PLAIN=true tallentaa tekstin; muuten HTML.)
			</div>

			<br>
			<input type="submit" value="save">
		</form>

		<script>
			const VU_PLAIN_MODE = @{[ $plain_mode ? 'true' : 'false' ]};

			function vuCmd(cmd){
				document.execCommand(cmd, false, null);
				document.getElementById('editor').focus();
			}

			function vuMakeLink(){
				const url = prompt("Linkin URL (https://...)");
				if(!url) return;
				document.execCommand('createLink', false, url);
				document.getElementById('editor').focus();
			}

			/* Convert editor to plain text visually (keeps <br>) */
			function vuPlainize(){
				const ed = document.getElementById('editor');
				const text = ed.innerText.replace(/\\r/g,'');
				ed.innerHTML = vuEscapeHtml(text).replace(/\\n/g,'<br>\\n');
			}

			function vuEscapeHtml(s){
				return (s ?? '')
					.replace(/&/g,'&amp;')
					.replace(/</g,'&lt;')
					.replace(/>/g,'&gt;')
					.replace(/"/g,'&quot;');
			}

			/* Remove empty lines (JS) */
			function vuRemoveEmptyLines(){
				const ed = document.getElementById('editor');
				const text = ed.innerText.replace(/\\r/g,'');
				const lines = text.split('\\n').map(l => l.replace(/\\s+$/,''));
				const out = [];
				for(let i=0;i<lines.length;i++){
					const cur = lines[i].trim();
					const nxt = (lines[i+1] ?? '').trim();
					if(cur === '' && nxt === '') continue;
					out.push(lines[i]);
				}
				ed.innerHTML = vuEscapeHtml(out.join('\\n')).replace(/\\n/g,'<br>\\n');
				ed.focus();
			}

			/* Auto line break: if line ends with ".", add extra break after it */
			function vuAutoWrapDot(){
				const ed = document.getElementById('editor');
				const text = ed.innerText.replace(/\\r/g,'');
				const lines = text.split('\\n');
				const out = [];
				for(const line of lines){
					const t = line.replace(/\\s+$/,'');
					out.push(t);
					if(t.endsWith('.')) out.push(''); // blank line => visual paragraph break
				}
				ed.innerHTML = vuEscapeHtml(out.join('\\n')).replace(/\\n/g,'<br>\\n');
				ed.focus();
			}

			/* Sync editor to hidden CONTENT field before submit */
			function vuBeforeSubmit(){
				const ed = document.getElementById('editor');
				// You can optionally auto-run cleaners here:
				// vuRemoveEmptyLines();
				// vuAutoWrapDot();

				const contentField = document.getElementById('CONTENT');

				if(VU_PLAIN_MODE){
					// send plain text (SaveArticle will convert to <br>)
					contentField.value = ed.innerText.replace(/\\r/g,'');
				}else{
					// send HTML directly
					contentField.value = ed.innerHTML;
				}
				return true;
			}

			// Focus editor on load
			document.getElementById('editor').focus();
		</script>

		<a href="$returl_esc"><p>&gt; Peruuta</p></a>
		<br>
	);
}

#######################################################
sub AddImage1
{
	open(f, ">$fname\_imageurl.txt") || die "can't add image url";
	print f "$imageurl";
	close(f);
}

#######################################################
sub EditArt
{
	EditArticleForm();
}

###################################################################################################################################
sub SaveArticle
{
	my (@l,$i);

	@l = split("\n", $so{'CONTENT'});

	$l[0] =~ s/\n//g;
	$l[0] =~ s/\r//g;

	if($l[0] eq "")
	{
		print "<blink>First line must always contain the article subject.</blink><br><br>\n";
		EditArticleForm();
		return;
	}

	if($so{'PLAIN'} eq "true")
	{
		@l = split("\n", $so{'CONTENT'});
		$so{'CONTENT'} = "";
		for($i=0; $i<($#l+1); $i++)
		{
			$l[$i] =~ s/^(.*)\s$/$1/;
			$so{'CONTENT'} = "$so{'CONTENT'}$l[$i]<br>\n";
		}
	}

	open(f6, ">$fname") || print "Can't write $fname<BR>\n";
	print f6 $so{'CONTENT'};
	close(f6);

	system("$ENV{'DOCUMENT_ROOT'}/cgi/admin/Kaikki.sh");

	print("Tallenetaan ...<BR><BR>\n");

	if($so{'RETURL'} eq "")
	{
		print qq(
			<a href="Javascript:self.close();" class="dark">
			KIITOS. MUUTOKSESI ON TALLENNETTU.<BR><BR>
			&gt; SULJE IKKUNA TASTA<BR>
			</a>
		);
	}
	else
	{
		my $returl_esc = _escape_for_html_attr($so{'RETURL'});
		print qq(
			<a href="$returl_esc" class="dark">
			KIITOS. MUUTOKSESI ON TALLENNETTU.<BR><BR>
			&gt; SIIRRY TÄSTÄ TAKAISIN ARTIKKELIIN<BR>
			</a>
		);
	}
}

#######################################################
sub main
{
	my ($str);

	if($so{'RETURL'} eq "") { $so{'RETURL'} = "/"; }

	$str = $ENV{'DOCUMENT_ROOT'};
	if( !($so{'FILE'}=~/$str/) && !($so{'FILE'}=~/^\//) )
	{
		$so{'FILE'} = "$ENV{'DOCUMENT_ROOT'}/articles/$so{'FILE'}";
	}
	$fname = $so{'FILE'};

	print qq(
<!DOCTYPE html>
<html lang="fi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Pragma" content="no-cache">
  <link rel="STYLESHEET" type="text/css" href="$IMAGES_BASE/uutiset.css" title="Cool">
  <title>$so{'FILE'}</title>
</head>

<body id="keho">
	<table width="715" cellpadding="16" cellspacing="0">
	<tr align="top">
	<td>
	);

	if($so{'cmd'} eq "")
	{
		EditArt();
	}
	else
	{
		if($so{'cmd'} =~ /cmdeditart123894/)
		{
			SaveArticle();
		}
		else
		{
			print "Unknown request.\n";
		}
	}

	print qq(
	</td>
	</tr>
	</table>
</body>
</html>
	);
}