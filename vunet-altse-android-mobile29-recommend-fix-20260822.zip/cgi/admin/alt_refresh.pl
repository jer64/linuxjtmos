#!/usr/bin/perl
for(;;)
{
	chdir("/home/vai/altse/html/cgi/admin");
	#system("nice -n 20 /home/vai/altse/html/cgi/admin/online.pl");
	system("/home/vai/altse/html/cgi/admin/online.pl");
	system("nice -n 20 /home/vai/altse/html/cgi/admin/alt_up2b.sh");
	sleep(60*60*2);
}
