#!/bin/bash
wget https://vunet.net/qbar.pl -O /home/vai/altse/html/uutiset/qbar.js
