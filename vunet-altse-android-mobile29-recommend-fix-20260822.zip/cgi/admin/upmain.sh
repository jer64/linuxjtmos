#!/bin/bash
#
echo "0"
/home/vai/altse/html/cgi/admin/genranklist.pl > /home/vai/altse/html/cgi/cache/top20.txt
lynx -source https://vunet.net/osastot.pl > /tmp/index-osastot.html
cp /tmp/index-osastot.html /home/vai/altse/html/cache/index-osastot.html
lynx -source https://vunet.net/com.pl?l=fi > /tmp/index-keskustelu.html
cp /tmp/index-keskustelu.html /home/vai/altse/html/cache/index-keskustelu.html
lynx -source https://vunet.net/com.pl?l=en > /tmp/index-discussion.html
cp /tmp/index-discussion.html /home/vai/altse/html/cache/index-discussion.html
echo "1\n";
lynx -source https://vunet.net/userfavs.pl > /tmp/index-userfavs.html
cp /tmp/index-userfavs.html /home/vai/altse/html/cache/index-userfavs.html
lynx -source https://vunet.net/whatsnew.pl > /tmp/index-whatsnew.html
cp /tmp/index-whatsnew.html /home/vai/altse/html/cache/index-whatsnew.html
echo "2\n";
lynx -source https://vunet.net/chinese/ > /tmp/xinwen-.html
cp /tmp/xinwen-.html /home/vai/altse/html/cache/index-xinwen.html
lynx -source https://vunet.net/russian/ > /tmp/russian-.html
cp /tmp/russian-.html /home/vai/altse/html/cache/index-russian.html
echo "3\n";
lynx -source https://vunet.net/finnish/ > /tmp/finnish-.html
cp /tmp/finnish-.html /home/vai/altse/html/cache/index-finnish.html
echo "4\n";
lynx -source https://vunet.net/swedish/ > /tmp/swedish-.html
cp /tmp/swedish-.html /home/vai/altse/html/cache/index-swedish.html
echo "5\n";
lynx -source https://vunet.net/dutch/ > /tmp/dutch-.html
cp /tmp/dutch-.html /home/vai/altse/html/cache/index-dutch.html
echo "6\n";
lynx -source https://vunet.net/english/ > /tmp/english-.html
echo "7\n";
cp /tmp/english-.html /home/vai/altse/html/cache/index-english.html
chmod a+rw /home/vai/altse/html/cache/*
