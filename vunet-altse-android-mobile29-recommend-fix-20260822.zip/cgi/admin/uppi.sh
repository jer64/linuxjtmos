#!/bin/bash

#
cd /home/vai/altse/html/cgi/admin
#
PATH=$PATH:/home/vai/sdb/bin
export PATH

#
echo "7"
lynx -source "https://vunet.net/chart.pl?MAGIC=32785782378523758&TLI=86400" > /tmp/index-top.html
cp /tmp/index-top.html /home/vai/altse/html/cache/index-top.html 
