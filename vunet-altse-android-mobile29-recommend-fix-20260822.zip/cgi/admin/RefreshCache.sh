#!/bin/bash
/home/vai/altse/html/cgi/admin/update_titles.sh
/home/vai/altse/html/cgi/admin/CPtitles.sh
