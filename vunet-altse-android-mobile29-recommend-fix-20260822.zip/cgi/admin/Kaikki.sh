#!/bin/bash
#
cd /home/vai/public_html/articles/
cd kaikki; $DOCUMENT_ROOT/cgi/admin/titler.pl  2>/dev/null; cd ..
cd kaikki; $DOCUMENT_ROOT/cgi/admin/sqltitler.pl  2>/dev/null; cd ..

#/home/vai/altse/html/cgi/admin/CPtitles.pl

