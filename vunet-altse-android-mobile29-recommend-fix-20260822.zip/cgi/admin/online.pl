#!/usr/bin/perl
use strict;
use warnings;
use Fcntl qw(:flock);

##############################################################################################################

chdir("/home/vai/altse/html/cgi");

require "./tools.pl";
require "./modules/sql.pm";

#
AltseSQLConnect();

our $DONT_AFFECT_DB = 1;
ArgLineParse();

main();

###########################################################################################################
sub main {
    ReadersOnline();
}

#############################################################################################
sub ReadersOnline {    
    my ($i, $str, $url, $img, @lst, $fn, $pm, $t, @sp, %vis);
    $t = time();  # Asetetaan nykyinen aikaleima

    #
    @lst = GetAvlog();

    #
    for ($i = 0; $i < @lst; $i++) {
        @sp = split(/;/, $lst[$i]);
        $str = $sp[2] // '';
        if (($t - $sp[0]) < 900 && $str !~ /googlebot/i && $str !~ /inktomisearch/i && $str ne "vunet.net") {
            if ($str eq "") {
                $str = $sp[1];
            }
            $vis{$str}++;
        }
    }

    #
    $i = keys %vis;

    #
    my $file = "cache/readers_online.txt";
    open(my $fh, ">", $file) or die "Could not open file '$file': $!";
    flock $fh, LOCK_EX;
    print $fh "$i\n";
    flock $fh, LOCK_UN;
    close($fh);
}
