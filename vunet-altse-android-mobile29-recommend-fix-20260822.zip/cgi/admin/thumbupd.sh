
#!/bin/bash
echo "Updating thumb folder #1 ..."
cd /home/vai/altse/html/images/thumb; /home/vai/cgi/admin/th 2>&1 > /dev/null
echo "Updating thumb folder #2 ..."
cd /home/vai/altse/html/images/thumb2; /home/vai/cgi/admin/th2 2>&1 > /dev/null
echo "Updating thumb folder #3 ..."
cd /home/vai/altse/html/images/thumb3; /home/vai/cgi/admin/th3 2>&1 > /dev/null
echo "Updating thumb folder #4 ..."
cd /home/vai/altse/html/images/thumb4; /home/vai/cgi/admin/th4 2>&1 > /dev/null
echo "Updating thumb folder #6 ..."
cd /home/vai/altse/html/images/thumb6; /home/vai/cgi/admin/th6 2>&1 > /dev/null
echo "Done."
echo "Updating SQL-cache of file names ..."
cd /home/vai/cgi
/home/vai/cgi/admin/IMGdircache.pl
echo "Done."
