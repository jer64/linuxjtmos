#!/usr/bin/perl
#
use feature 'fc';
use utf8;
#binmode STDOUT, ':utf8';
use Encode;
use Encode::Guess;
use HTML::Entities;
#
binmode STDIN,  ':encoding(UTF-8)';
binmode STDOUT, ':encoding(UTF-8)';
#
require "./tools.pl";
require "./modules/sql.pm";
require "./modules/genstat_BuildStatistics.pm";

#
AltseSQLConnect();

#
$ARTBASE = "/home/vai/articles";

#
main();

#
sub main
{
	# Get kaikki section index.
	my @inde = LoadList("$ARTBASE/kaikki/fileindex.txt");
	##push(@inde, LoadList("$ARTBASE/picks/fileindex.txt"));
##	push(@inde, LoadList("$ARTBASE/business/fileindex.txt"));
	#push(@inde, LoadList("$ARTBASE/aifeed/fileindex.txt"));
	#
##	push(@inde, LoadList("$ARTBASE/lucianne/fileindex.txt"));
#	push(@inde, LoadList("$ARTBASE//fileindex.txt"));
##	push(@inde, LoadList("$ARTBASE/cnn/fileindex.txt"));
##	push(@inde, LoadList("$ARTBASE/nypost/fileindex.txt"));
#	push(@inde, LoadList("$ARTBASE/mvlehti/fileindex.txt"));
#	push(@inde, LoadList("$ARTBASE/	/fileindex.txt"));
	
	#
#	print $#inde+1;
	
	# Go through articles.
	for(my $i=0; $i<($#inde+1); $i++)
	{ 
		#
		print STDERR "\r$i / " . $#inde;
		my $lfn = "kaikki/$inde[$i]";
		my $absfn = "$ARTBASE/$lfn";
		my @art = LoadListTitle($absfn);
		#
		#for(my $i2=0; $i2<($#art+1); $i2++)
		#{
		#$art[$i2]
		my $comb = join(/ /, @art);
		$comb =~ s/\|/-/g;
		$comb = "$lfn|$comb";
		push(@gl_titles, $comb);
		#}
	}
	
	#
#	print("<pre");
	@st = BuildStatistics();
	for($i=0; $i<($#st+1); $i++)
	{
		print $st[$i] . "\n";
	}
#	print("</pre>");
}
