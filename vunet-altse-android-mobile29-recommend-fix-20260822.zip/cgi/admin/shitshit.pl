#!/usr/bin/perl
use DBI;

#
require "tools.pl";

#
main();

#
sub imgdesc_to_imglist
{
	my ($i,$i2,$i3,$i4,$f,$con,$time,$huh,
		$web_browser,$local_file,$sth,$article_title,
		$str,$str2,$str3,$str4);

	#
	@lst = LoadList($_[0]);

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		$fn = $lst[$i];
		$fn =~ s/(.+)\=(.*)$/$1/;
		$fn = "/home/vai/altse/html/uutiset/$fn";
		$category = $lst[$i];
		$category =~ s/.+\=(.*)$/$1/;
		$category =~ s/\,//g;

		# SELECT id, fname, age, group
		my $query = "SELECT * FROM imagelist WHERE fname='$fn';";
		print STDERR "$query\n";
		$sth = $gl_dbh->prepare($query);
		$sth->execute() or print "failed on $i ($DBI::errstr)\n";
		@lq = $sth->fetchrow_array();
		$sth->finish();

		# DELETE OLD
		$query = "DELETE FROM imagelist where fname='$fn';";
		print STDERR "$query\n";
		$sth = $gl_dbh->prepare($query);
		$sth->execute() or print "failed on $i ($DBI::errstr)\n";
		$sth->finish();

		# INSERT
		$query = ("INSERT INTO imagelist
			(category,fname,age)
			values
			(category='$category', fname='$fn', age='$lq[2]'); ");
		print STDERR "$query\n";
		$sth = $gl_dbh->prepare($query);
		# UPDATE example SET age='22' WHERE age='21'
		$sth->execute() or print "failed on $i ($DBI::errstr)\n";
		$sth->finish();
	}
#	$gl_dbh->commit();

	#
	close($f);
}

#
sub main
{
	my ($i,$i2,$i3,$i4,@lst);

	#
	imgdesc_to_imglist("cfg/imgdesc.txt");

	#
}
