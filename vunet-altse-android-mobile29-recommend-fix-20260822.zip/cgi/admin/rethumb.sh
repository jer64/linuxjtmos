#!/bin/bash
echo "Making a clean up ..."
rm -rf /home/vai/altse/html/images/thumb
rm -rf /home/vai/altse/html/images/thumb2
rm -rf /home/vai/altse/html/images/thumb3
rm -rf /home/vai/altse/html/images/thumb4
mkdir		/home/vai/altse/html/images/thumb
chmod a+rw	/home/vai/altse/html/images/thumb
mkdir		/home/vai/altse/html/images/thumb2
chmod a+rw	/home/vai/altse/html/images/thumb2
mkdir		/home/vai/altse/html/images/thumb3
chmod a+rw	/home/vai/altse/html/images/thumb3
mkdir		/home/vai/altse/html/images/thumb4
chmod a+rw	/home/vai/altse/html/images/thumb4
sleep 4
echo "Generating thumbnail images ..."
./thumbupd.sh
echo "Updating SQL-database ..."
./IMGdircache.pl
echo "All done."
