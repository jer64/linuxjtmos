#!/usr/bin/perl
################################################################
# Your home computer's IP (for master access in some cases).
$MASTER_IP=             "82.103.200.47";
#
@MASTER_IPS=(
	#	"82.103.200.47",
	#	"82.103.201.139"
		);
# Remove remark below to disable the search service for public users.
$SDB_SERVICE_OFF = 0;
#
$NWPUB_WWWBASE =        "/home/vai/altse/html";
$NWPUB_CGIBASE =        "/home/vai/altse/html/cgi";
$ENV{'NWPUB_WWWBASE'} = $NWPUB_WWWBASE;
$ENV{'NWPUB_CGIBASE'} = $NWPUB_CGIBASE;
#
$VAI_PROF_DIR = "$NWPUB_CGIBASE/user/";
$IMGBASE = "$IMAGES_BASE";
$NEBASE = "$IMAGES_BASE";
$NEBASECGI = "https://vunet.net/~vai/cgi";
#
$BGBAK1 = "$IMAGES_BASE/bakki5.gif";
$BGBAK2 = "$IMAGES_BASE/bakki6.gif";
$BGBAK3 = "$IMAGES_BASE/bg26.png";
$TABCOL = "40E0FF";
$IMAGES_BASE = "https://vunet.net/images";
#
$PRIM_ADMIN_EMAIL = "seuranta\@vunet.net";
