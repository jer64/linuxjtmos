#!/bin/bash
grep -iE " on | ovat | oli | olivat | tulee olemaan | näyttää olevan | arvioidaan | olevan | pidetään | tunnetaan | kutsutaan " cache/genstat.txt > /home/vai/cache/genstat_uusi_on.txt 

