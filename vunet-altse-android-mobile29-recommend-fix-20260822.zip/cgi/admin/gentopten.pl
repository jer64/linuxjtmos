#!/usr/bin/perl
#
# Generate Top Ten List.
#
##############################################################################################################

#
chdir("/home/vai/cgi");
#
require "./tools.pl";

#
main();

###########################################################################################################
#
sub main
{
	my (@lst,@ipl,$i,$i2,$i3,$i4,$str,$str2);

	#
	chdir("/home/vai/altse/html/cgi");

	#
	print "Browsing articles ... ";
	@lst = LoadList("find \"/home/vai/altse/html/articles/\" -name '*.counter' -type f|");
	print "\n";

	#
	print "Checking counter files for  scores  ... \n";
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		#
		printf "%6d / %6d    \r", $i,$#lst;

		#
		$str = $lst[$i];
		$str =~ s/^articles\///;
		$str =~ s/.counter$//;
		#
		@ipl = LoadList($lst[$i]);
		$ch[$i2++] = sprintf("%1.8d $str", $#ipl+1);
		for($i3=0; $i3<($#ipl+1); $i3++)
		{
			$key = $ipl[$i3];
		#	print STDERR "$key\n";
			$gipl{$key}++;
		}
	}
	print "\n";

	#
	@ch = sort @ch;
	@ch = reverse @ch;

	#
	print "Checking counter files for  dates  ... \n";
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		#
		printf "%6d / %6d    \r", $i,$#lst;

		#
		$str = $lst[$i];
		$str =~ s/^articles\///;
		$str =~ s/.counter$//;
		#
		@ipl = LoadList($lst[$i]);
#		print $str . "\n";
		$ch2[$i2++] = sprintf("%1.8d $str", CreationDate1($lst[$i]));
		for($i3=0; $i3<($#ipl+1); $i3++)
		{
			$key = $ipl[$i3];
		#	print STDERR "$key\n";
			$gipl2{$key}++;
		}
	}
	print "\n";

	#
	@ch2 = sort @ch2;
	@ch2 = reverse @ch2;

        #
	print STDERR "Generating 'topten.txt' ... \n";
	open($f, ">/home/vai/altse/html/cgi/topten.txt") || die "can't write file (1)";
	for($i=0; $i<($#ch+1); $i++)
	{
		print $f "$ch[$i]\n";
	}
	close($f);

        #
	print STDERR "Generating 'topdate.txt' ... \n";
	open($f, ">/home/vai/altse/html/cgi/topdate.txt") || die "can't write file (2)";
	for($i=0; $i<($#ch2+1); $i++)
	{
		print $f "$ch2[$i]\n";
	}
	close($f);

	#
	print STDERR "Generating 'iplist.txt' ... \n";
	open($f, ">/home/vai/altse/html/cgi/iplist.txt") || die "can't write file (2)\n";
	foreach $key (sort(keys %gipl))
	{
		print $f "$key=$gipl{$key}\n";
	}
	close($f);
}


