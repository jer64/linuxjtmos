##########################################
# PUBLISHING SETTINGS
##########################################

###########################################
$LOGO = "https://www.saunalahti.fi/ehc50/uutiset/uusilogo2.jpg";
$LOGOURL = "https://www.saunalahti.fi/ehc50/uutiset";

#


