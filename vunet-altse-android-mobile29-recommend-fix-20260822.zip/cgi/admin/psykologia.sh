#
echo "24";
lynx -source "https://vunet.net/nw.pl?q=terapeutti terapeutti ihmissuhteita capitalism magazine mieli psykologinen freud ahdistus ahdistuneisuus masennuslaake masennus masentuneisuus psykologia mielenterveys psykologi psykoosi psykopaatti sosiopaatti sosiopaattinen psykoottinen \
&maxts=200&section=tiede&rs=psykologia&FP_SECTION=finnish" > /home/vai/altse/html/cache/index-psykologia.html
