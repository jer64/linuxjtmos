#!/usr/bin/perl
system("/home/vai/altse/html/cgi/wapirc.exe");
