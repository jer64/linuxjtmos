#!/usr/bin/perl
# Compatibility endpoint for old Vunet admin URLs.
my $location = "/cgi/admin/newscenter.pl";
if(defined($ENV{'QUERY_STRING'}) && $ENV{'QUERY_STRING'} ne "")
{
        $location .= "?" . $ENV{'QUERY_STRING'};
}
print "Status: 302 Found\r\n";
print "Location: $location\r\n";
print "Cache-Control: no-store\r\n";
print "Content-Type: text/plain; charset=UTF-8\r\n\r\n";
print "Redirecting to Vunet News Center.\n";
