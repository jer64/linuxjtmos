#!/usr/bin/perl

#
require "./tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
if( !($ENV{'HTTP_REFERER'} =~ /www\.vunet\.org/) )
{
#	exit;
}

#
main();

#
sub main
{
	#
	chdir("/home/vai/altse/html/cgi/admin");
	system("chdir /home/vai/cgi/admin; ./thumbupd.sh");
	system("chdir /home/vai/cgi/admin; ./IMGdircache.pl");
	
	#
	if($so{'r'} ne "")
	{
		$so{'r'} =~ s/\^/\=/g;
		$so{'r'} =~ s/\~/\&/g;
		print(" <meta http-equiv=\"refresh\" content=\"0; url=$so{'r'}\"> ");
	}
}

##################################################
#
sub main2
{
	#
	chdir("/home/vai/altse/html/uutiset");
	system("./iml.sh 1> /dev/null");
	chdir("/home/vai/altse/html/cgi");

	#
	print("
<SCRIPT LANGUAGE=\"Javascript\">
document.title = 'Updating thumbnails ...';
</SCRIPT>
");
	print("Now updating thumbnails ... <br>");
	system("bash ./thumbupd.sh 1>/dev/null");
	#
	print("
<SCRIPT LANGUAGE=\"Javascript\">
document.title = 'Thumbnail update done.';
</SCRIPT>
");
	print("<br>Done.<br>");

	#
	if($so{'r'} ne "")
	{
		$so{'r'} =~ s/\^/\=/g;
		$so{'r'} =~ s/\~/\&/g;
		print(" <meta http-equiv=\"refresh\" content=\"0; url=$so{'r'}\"> ");
	}
}

