#!/bin/bash
screen -d -m /home/vai/altse/html/cgi/admin/up2b.sh
