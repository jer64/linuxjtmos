#!/usr/bin/perl

use utf8;
binmode STDIN,  ':encoding(UTF-8)';
binmode STDOUT, ':encoding(UTF-8)';
#
chdir("/home/vai/cgi/admin");
# build main genstat.txt
print STDERR "Building main genstat.txt ...\n";
system("/home/vai/cgi/genstat.pl >		cache/genstat.txt");
# 1w, 2w, 3w, 5w
print STDERR "Building 1w, 2w, 3w, 5w ...\n";
system("/home/vai/cgi/statgen.sh");
print STDERR "Done.\n";

#
my @impl = (
                "on",
                "ovat",
                "kertoo",
                "paljastaa",
                "vahvistaa",
                "julkaisee",
                "kuolee",
                "menehtyy",
                "nousee",
                "laskee"
                );

print STDERR "Building custom variable genstats ...\n";

for(my $i=0; $i<($#impl+1); $i++)
{
	system("grep \" $impl[$i] \" cache/genstat.txt > cache/$impl[$i]\_genstat.txt");
}

print STDERR "Done.\n";
