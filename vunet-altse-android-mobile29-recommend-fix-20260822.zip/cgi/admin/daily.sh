#!/bin/bash
links -dump "https://vunet.net/admin/chart.pl?TLI=86400&ILMAN=ei&blank=1"|mail LST@vunet.net "Subject: Paivan suosituimmat artikkelit"
