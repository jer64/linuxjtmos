#!/bin/bash
#


#
cd /home/vai/cgi
#
PATH=$PATH:/home/vai/sdb/bin
export PATH
#
/home/vai/cgi/update_titles.sh

#
/home/vai/cgi/comwea

#
/home/vai/cgi/upjs.sh
#
/home/vai/cgi/upmain.sh
#
/home/vai/cgi/upsecs.sh

#
/home/vai/cgi/analyze_vislogs.pl &
