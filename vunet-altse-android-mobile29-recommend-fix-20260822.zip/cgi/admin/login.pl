#!/usr/bin/perl
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();


###########################################################################################################
#
sub LogIn
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst);

	#
	AddAdmin();

	#
}

###########################################################################################################
#
sub main
{
	#
	LogIn();

	#
	if($so{'r'} ne "")
	{
	        print ("
	        <meta http-equiv=\"refresh\"
	        content=\"0; url=$so{'r'}\">
	                ");
	}

	#
}


