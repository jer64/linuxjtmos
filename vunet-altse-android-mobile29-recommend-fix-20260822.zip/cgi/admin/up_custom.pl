#!/bin/bash

#
cd /home/vai/altse/html/cgi/admin
#
PATH=$PATH:/home/vai/sdb/bin
export PATH

#
echo "0"
lynx -source "https://vunet.net/?rs=palestine&q=palestine&maxts=80&section=progressive&FP_SECTION=english" \
 > /tmp/index-palestine.html
cp /tmp/index-palestine.html /home/vai/altse/html/cache/index-palestine.html

#
echo "1"
lynx -source "https://vunet.net/?rs=iraq&q=iraq&maxts=80&section=progressive&FP_SECTION=english" \
 > /tmp/index-iraq.html
cp /tmp/index-iraq.html /home/vai/altse/html/cache/index-iraq.html

#
echo "2"
lynx -source "https://vunet.net/?rs=iran&q=iran&maxts=80&section=progressive&FP_SECTION=english" \
 > /tmp/index-iran.html
cp /tmp/index-iran.html /home/vai/altse/html/cache/index-iran.html

#
echo "3"
lynx -source "https://vunet.net/?rs=china&q=china&maxts=80&section=progressive&FP_SECTION=english" \
 > /tmp/index-china.html
cp /tmp/index-china.html /home/vai/altse/html/cache/index-china.html

#
echo "4"
lynx -source "https://vunet.net/?rs=russia&q=russia&maxts=80&section=progressive&FP_SECTION=english" \
 > /tmp/index-russia.html
cp /tmp/index-russia.html /home/vai/altse/html/cache/index-russia.html

#
echo "5"
lynx -source "https://vunet.net/?rs=belarus&q=belarus&maxts=80&section=progressive&FP_SECTION=english" \
 > /tmp/index-belarus.html
cp /tmp/index-belarus.html /home/vai/altse/html/cache/index-belarus.html

