use utf8;
use File::Basename qw(dirname);
use File::Spec;

# Polling System Configuration — UTF-8/mobile revision 2026.
# Prefer DOCUMENT_ROOT so the same tree works in production and test installs.
my $poll_cfg_here = dirname(__FILE__);
my $poll_cfg_cgi = ($poll_cfg_here =~ m{/modules$|/admin$|/guest$}) ? dirname($poll_cfg_here) : $poll_cfg_here;
$POLL_BASE = ($ENV{'DOCUMENT_ROOT'} || '') ne ''
    ? File::Spec->catdir($ENV{'DOCUMENT_ROOT'}, 'cgi')
    : $poll_cfg_cgi;
$VDB = File::Spec->catdir($POLL_BASE, 'votes');

# Keep public legacy URLs while fixing the administration URL.
$SCRIPT      = '/poll.pl';
$SCRIPT_ADM  = '/cgi/admin/polladm.pl';
$SCRIPT_MAIN = '/pollmain.pl';

1;
