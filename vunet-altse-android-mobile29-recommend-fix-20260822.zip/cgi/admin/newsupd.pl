#!/usr/bin/perl
#
$NWPUB_CGIBASE =        "/home/vai/altse/html/cgi";
#
chdir("/home/vai/altse/html/cgi/admin");
main();


#
sub main
{
	#
	system("./nu.pl");
	system("../up2b.sh");
}

