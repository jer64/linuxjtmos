#!/usr/bin/perl
##########################################################
# Left main menu.
##########################################################
#
require "admin.pl";
main();

sub main
{

	#
	#
	print("
	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"
	background=\"https://www.saunalahti.fi/ehc50/uutiset/grisland4.jpg\">
	<tr>
	<td>
	        <center>
	        <font color=\"#E0FFE0\">
	        <b>Osastot</b><br>
	        </font>
	        </center>
	</td>
	</tr>
	</table>

	");

	#
	print("
	<a style=\"color: rgb(255, 255, 255);\"
	href=\"factbook.pl\">
		Esittely
	</a><br>
	<br>
		");


	#
	print("
	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"
	background=\"https://www.saunalahti.fi/ehc50/uutiset/grisland4.jpg\">
	<tr>
	<td>
	        <center>
	        <font color=\"#E0FFE0\">
	        <b>Maat</b><br>
	        </font>
	        </center>
	</td>
	</tr>
	</table>

	");

	########################################################################################
	#
	# Add countries links.
	#
	#
	@maa = LoadList("countries.txt");
	for($i=0; $i<($#maa+1); $i++)
	{
		if($i) { print "<br>"; }
		print("
		<a style=\"color: rgb(255, 255, 255);\"
		href=\"country.pl?$maa[$i]\">$maa[$i]</a>
			");
	}

	#
	print("
	<br>
	<a style=\"color: rgb(255, 255, 255);\"
	href=\"admin/addcountry.pl?$maa[$i]\">
		> lis�� maa
	</a><br>
		");

	########################################################################################
	#
	print("
	<br>
	
	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"
	background=\"https://www.saunalahti.fi/ehc50/uutiset/grisland4.jpg\">
	<tr><td>
	        <font color=\"#E0FFE0\">
	        <b><center>Tiedote</center></b>
	        </font>
	</td></tr></table><br>

	<a href=\"https://www.democraticunderground.com/\" target=\"_blank\">
	<img src=\"https://www.saunalahti.fi/ehc50/cgi/rand_image/rand_image.pl\" align=\"center\"
	width=92 height=92>
	</a>
	
	<br>
	<br>

	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"
	background=\"https://www.saunalahti.fi/ehc50/uutiset/grisland4.jpg\">
	<tr><td>
	        <font color=\"#E0FFE0\">
	        <b><center>Ohjaus</center></b>
	        </font>
	</td></tr></table>
	
	<a style=\"color: rgb(255, 255, 255);\"
	href=\"newswire.pl\">palaa uutisiin</a><br>
	
	<br>

	");

	####################################################
	#
	
}


