#!/usr/bin/perl
##########################################################################
#
# logview.pl - PORTAL LOG VIEWER/PARSER (Modern HTML5 + JSON API)
# Local: cgi/admin/logview.pl
#
# Korjattu versio:
# - AJAX säilytetty.
# - JSON ei enää sisällä HTML-headeriä.
# - Content-Type tulostetaan vasta routerin jälkeen.
# - STDERR ei mene enää STDOUTiin, koska se sotkee JSONin.
# - require/DB/ArgLineParse-vaihe suojataan output-bufferilla.
#
##########################################################################

#use strict;
#use warnings;
use utf8;
use feature 'fc';

use POSIX qw(strftime);
use JSON::PP;
use Encode qw(decode encode is_utf8);

binmode STDIN,  ':encoding(UTF-8)';
binmode STDOUT, ':encoding(UTF-8)';

#
# ÄLÄ tulosta mitään ennen routeria.
# Ei Content-Typeä tässä.
# Ei STDERR -> STDOUT tässä.
#

select(STDOUT);
$| = 1;

#
# Virheet lokiin, eivät selaimen JSON-vastaukseen.
#

my $ERROR_LOG = "/home/vai/altse/html/cgi/cache/logview_error.log";

if (open my $errfh, '>>:encoding(UTF-8)', $ERROR_LOG) {
    open STDERR, '>&', $errfh;
}

#
# Globaalit, joita tools.pl / sql.pm käyttävät.
#

our %so;
our $DONT_AFFECT_DB = 1;
our $gl_dbh;

#
# Päättele jo raakakyselystä, halutaanko JSONia.
# Tämä tehdään ennen tools.pl:n latausta, jotta JSON-reitti voidaan pitää puhtaana.
#

my $raw_format = _raw_query_param('format') || _raw_query_param('fmt') || '';
$raw_format = lc($raw_format);

#
# Lataa työkalut ja avaa DB-yhteys suojatusti.
# Jos jokin require/moduuli vahingossa printtaa, se jää bufferiin eikä riko JSONia.
#

my $BOOT_OUTPUT = '';
my $BOOT_ERROR  = '';

{
    open my $bufh, '>', \$BOOT_OUTPUT;

    my $oldout = select($bufh);

    eval {
        require "./tools.pl";
        require "./modules/sql.pm";

        $DONT_AFFECT_DB = 1;
        AltseSQLConnect();

        $DONT_AFFECT_DB = 1;
        ArgLineParse();

        1;
    } or do {
        $BOOT_ERROR = $@ || "Unknown bootstrap error";
    };

    select($oldout);
}

#
# Jos bootstrap epäonnistui, vastataan silti oikein joko JSONina tai HTML:nä.
#

if ($BOOT_ERROR ne '') {
    if ($raw_format eq 'json') {
        _print_json_header();

        my %payload = (
            ok    => JSON::PP::false,
            depth => 0,
            error => _one_line($BOOT_ERROR),
        );

        print _json_encode(\%payload);
        exit;
    }

    _print_html_header();

    print "<h1>logview.pl virhe</h1>\n";
    print "<pre>" . _html_attr($BOOT_ERROR) . "</pre>\n";

    exit;
}

# -----------------------------
# Defaults / guardrails
# -----------------------------

my $depth = $so{'depth'} // 4000;
$depth =~ s/[^0-9]//g;
$depth = 4000 if !$depth;
$depth = 1 if $depth < 1;
$depth = 400000 if $depth > 400000;

my $format = lc($so{'format'} // $so{'fmt'} // $raw_format // '');

# -----------------------------
# Router: JSON or HTML
# -----------------------------

if ($format eq 'json') {
    _print_json($depth);
    exit;
}

#
# HTML mode.
# Header tulostetaan vasta nyt.
#

_print_html_header();

$ENV{'CURSEC'} = "linkit";

OpenWebIndex("$ENV{'DOCUMENT_ROOT'}/cgi/webindex.html");
WebWalkTo("main-menu");
print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});

WebWalkTo("enterhere_section");
_print_html($depth);

WebWalkTo("ALAPALKKITAHAN");
print EndBar();
HandleRest();

exit;

# ---------------------------------------------------------------------
# Raw query helper
# ---------------------------------------------------------------------

sub _raw_query_param
{
    my ($name) = @_;

    my $qs = $ENV{'QUERY_STRING'} // '';
    return '' if $qs eq '';

    foreach my $pair (split /[&;]/, $qs) {
        my ($k, $v) = split /=/, $pair, 2;

        $k //= '';
        $v //= '';

        $k =~ tr/+/ /;
        $v =~ tr/+/ /;

        $k =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/eg;
        $v =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/eg;

        return $v if $k eq $name;
    }

    return '';
}

# ---------------------------------------------------------------------
# Headers
# ---------------------------------------------------------------------

sub _print_html_header
{
    print "Content-Type: text/html; charset=UTF-8\n";
    print "Cache-Control: no-store\n";
    print "\n";
}

sub _print_json_header
{
    print "Content-Type: application/json; charset=UTF-8\n";
    print "Cache-Control: no-store\n";
    print "Pragma: no-cache\n";
    print "\n";
}

# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------

sub _json_encode
{
    my ($ref) = @_;

    return JSON::PP
        ->new
        ->utf8(0)
        ->canonical(1)
        ->encode($ref);
}

sub _one_line
{
    my ($s) = @_;

    $s //= '';
    $s =~ s/\s+/ /g;
    $s =~ s/^\s+|\s+$//g;

    return $s;
}

sub _param_utf8
{
    # Decode query params safely.
    #
    # HUOM: jos tools.pl/ArgLineParse on JO dekoodannut parametrin
    # (eli Perl-skalaarilla on utf8-flagi päällä), emme saa dekoodata
    # sitä toiseen kertaan. Tupladekoodaus joko kaataa eval:in tai,
    # pahempaa, tuottaa hiljaa väärän merkkijonon (esim. "–" tai "ä"
    # muuttuu vääriksi merkeiksi), jolloin LIKE-haku ei koskaan osu
    # tietokannassa olevaan, oikein tallennettuun otsikkoon.
    my ($v) = @_;

    $v //= '';

    return '' if $v eq '';

    return $v if is_utf8($v);

    my $out = eval { decode('UTF-8', $v, 1) };

    if (!defined $out) {
        $out = decode('ISO-8859-1', $v);
    }

    return $out;
}

sub _split_search_terms
{
    # Pilko hakulause sanoiksi. "Lainausmerkeissä oleva osuus" pysyy
    # yhtenä terminä, muuten pilkotaan välilyönneistä. Näin pitkän
    # otsikon liittäminen sellaisenaan hakuun toimii, vaikka välissä
    # olisi pieniä eroja (esim. ylimääräinen välilyönti, eri lainaus-
    # merkki tms.), koska jokainen sana vaaditaan erikseen LIKE:llä.
    my ($s) = @_;

    $s //= '';

    my @terms;

    while ($s =~ /"([^"]+)"|(\S+)/g) {
        my $t = defined($1) ? $1 : $2;
        $t = _trim($t // '');
        push @terms, $t if $t ne '';
    }

    return @terms;
}

sub _trim
{
    my ($s) = @_;

    $s //= '';
    $s =~ s/^\s+|\s+$//g;

    return $s;
}

sub _fix_mojibake
{
    # Repair double UTF-8 encoded text, e.g. "ä" stored/read once too
    # many times through Latin-1, which shows up as "Ã¤", "Â " etc.
    my ($s) = @_;

    return $s if !defined($s) || $s eq '';

    # Only bother if it actually looks double-encoded.
    return $s if $s !~ /[ÃÂ][\x{80}-\x{BF}\x{80}-\x{9F}]/;

    my $fixed = eval {
        my $bytes = encode('ISO-8859-1', $s);
        return decode('UTF-8', $bytes, 1);
    };

    return $s if !defined($fixed) || $fixed eq '';

    return $fixed;
}

sub _safe_like
{
    # Escape LIKE wildcards and backslash for ESCAPE '\'
    my ($s) = @_;

    $s //= '';
    $s =~ s/([%_\\])/\\$1/g;

    return $s;
}

sub _html_attr
{
    # Escape for HTML attribute/value context
    # plus extra hardening for ` and ´.
    my ($s) = @_;

    $s //= '';

    $s =~ s/&/&amp;/g;
    $s =~ s/</&lt;/g;
    $s =~ s/>/&gt;/g;
    $s =~ s/"/&quot;/g;
    $s =~ s/'/&#39;/g;
    $s =~ s/`/&#96;/g;
    $s =~ s/´/&#180;/g;

    return $s;
}

sub _strip_html
{
    my ($s) = @_;

    $s //= '';

    $s =~ s/<script\b[^>]*>.*?<\/script>//gis;
    $s =~ s/<style\b[^>]*>.*?<\/style>//gis;
    $s =~ s/<[^>]+>//g;
    $s =~ s/\&nbsp;/ /g;
    $s =~ s/\s+/ /g;

    return _trim($s);
}

sub _truncate
{
    my ($s, $max) = @_;

    $s //= '';
    $max ||= 220;

    return $s if length($s) <= $max;

    return substr($s, 0, $max - 1) . "…";
}

# ---------------------------------------------------------------------
# SQL
# ---------------------------------------------------------------------

sub _build_query
{
    my ($depth) = @_;

    my $search  = _trim(_param_utf8($so{'SEARCH'} // $so{'search'} // ''));
    my $site    = _trim(_param_utf8($so{'site'}    // ''));
    my $section = _trim(_param_utf8($so{'section'} // ''));
    my $referer = _trim(_param_utf8($so{'referer'} // ''));

    my $ips_only = ($so{'ips'} // '') ne '' ? 1 : 0;
    my $exact    = ($so{'exact'} // '') ne '' ? 1 : 0;

    # Support "site:foo" inside search
    if ($search =~ /site:([^\s]+)/i && $site eq '') {
        $site = $1;
        $search =~ s/\s*site:[^\s]+//ig;
        $search = _trim($search);
    }

    my @where;
    my @bind;

    if ($search ne '') {
        if ($exact) {
            # Tarkka lause: koko syöte yhtenä LIKE-osumana (vanha käytös).
            my $like = '%' . _safe_like($search) . '%';
            push @where, "article_title LIKE ? ESCAPE '\\\\'";
            push @bind, $like;
        }
        else {
            # Oletus: jokainen sana vaaditaan erikseen (AND), missä
            # tahansa järjestyksessä otsikossa. Tämä on huomattavasti
            # sietokykyisempi kuin koko otsikon vaatiminen sanasta
            # sanaan identtisenä, ja on syy siihen, miksi pitkien
            # otsikoiden liittäminen sellaisenaan hakuun ei aiemmin
            # tuottanut tuloksia.
            my @terms = _split_search_terms($search);

            if (@terms) {
                my @sub;

                for my $t (@terms) {
                    my $like = '%' . _safe_like($t) . '%';
                    push @sub, "article_title LIKE ? ESCAPE '\\\\'";
                    push @bind, $like;
                }

                push @where, '(' . join(' AND ', @sub) . ')';
            }
        }
    }

    # Päivämääräväli (uusi ominaisuus): from / to muodossa PP.KK.VVVV
    # tai VVVV-KK-PP. Molemmat rajat valinnaisia.
    my $from_raw = _trim(_param_utf8($so{'from'} // ''));
    my $to_raw   = _trim(_param_utf8($so{'to'}   // ''));

    my $from_epoch = _parse_date_to_epoch($from_raw, 0);
    my $to_epoch   = _parse_date_to_epoch($to_raw, 1);

    if (defined $from_epoch) {
        push @where, "time >= ?";
        push @bind, $from_epoch;
    }

    if (defined $to_epoch) {
        push @where, "time <= ?";
        push @bind, $to_epoch;
    }

    if ($site ne '') {
        my $like = '%' . _safe_like($site) . '%';
        push @where, "(host LIKE ? ESCAPE '\\\\' OR ip LIKE ? ESCAPE '\\\\')";
        push @bind, $like, $like;
    }

    if ($section ne '') {
        my $like = '%' . _safe_like($section) . '%';
        push @where, "local_file_name LIKE ? ESCAPE '\\\\'";
        push @bind, $like;
    }

    if ($referer ne '') {
        my $like = '%' . _safe_like($referer) . '%';
        push @where, "referer LIKE ? ESCAPE '\\\\'";
        push @bind, $like;
    }

    my $where_sql = @where ? ("WHERE " . join(" AND ", @where)) : "";

    # Järjestys (uusi ominaisuus): oletus uusimmat ensin, mutta sallitaan
    # myös vanhimmat ensin.
    my $order_dir = (lc($so{'order'} // '') eq 'asc') ? 'ASC' : 'DESC';

    my $sql = qq{
        SELECT
            time,
            referer,
            article_title,
            ip,
            host,
            web_browser,
            url,
            local_file_name
        FROM visitors
        $where_sql
        ORDER BY time $order_dir
        LIMIT ?
    };

    push @bind, $depth;

    return ($sql, \@bind, $ips_only);
}

sub _parse_date_to_epoch
{
    # Parsii "PP.KK.VVVV" tai "VVVV-KK-PP" -muotoisen päivämäärän
    # unix-timestampiksi. $end_of_day=1 -> asetetaan kellonaika 23:59:59,
    # jotta "to"-rajaan sisältyy koko kyseinen päivä.
    my ($s, $end_of_day) = @_;

    return undef if !defined($s) || $s eq '';

    my ($d, $m, $y);

    if ($s =~ /^(\d{1,2})\.(\d{1,2})\.(\d{4})$/) {
        ($d, $m, $y) = ($1, $2, $3);
    }
    elsif ($s =~ /^(\d{4})-(\d{1,2})-(\d{1,2})$/) {
        ($y, $m, $d) = ($1, $2, $3);
    }
    else {
        return undef;
    }

    my $hms = $end_of_day ? "23:59:59" : "00:00:00";
    my ($hh, $mm, $ss) = split /:/, $hms;

    require Time::Local;

    my $epoch = eval {
        Time::Local::timelocal($ss, $mm, $hh, $d, $m - 1, $y);
    };

    return undef if !defined $epoch;

    return $epoch;
}

sub _fetch_rows
{
    my ($depth) = @_;

    my ($sql, $bind_ref, $ips_only) = _build_query($depth);

    die "DB handle missing\n" if (!$gl_dbh);

    my $sth = $gl_dbh->prepare($sql);
    $sth->execute(@{$bind_ref}) or die "DB query failed: $DBI::errstr\n";

    my @rows;
    my $now = time;

    while (my @lq = $sth->fetchrow_array) {
        my $et   = $lq[0] // 0;
        my $ref  = $lq[1] // '';
        my $cap  = $lq[2] // '';
        $cap = _fix_mojibake($cap);
        my $ip   = $lq[3] // '';
        my $host = $lq[4] // '';
        my $ua   = $lq[5] // '';
        my $url  = $lq[6] // '';
        my $lfn  = $lq[7] // '';

        # Skip obvious robots, unless special social ref combos.
        if ($host ne '' && isRobot($host)) {
            if (!($ref =~ /t\.co/i && $ref =~ /facebook/i)) {
                next;
            }
        }

        # time string
        my $ts = '';

        if ($et =~ /^\d+$/ && $et > 0) {
            my ($sec, $min, $hour, $mday, $mon, $year) = localtime($et);
            $year += 1900;
            $mon  += 1;

            $ts = sprintf(
                "%02d.%02d.%04d %02d:%02d:%02d",
                $mday,
                $mon,
                $year,
                $hour,
                $min,
                $sec
            );
        }

        # Build a nice, title-based URL via CapUrl(URL, CAP) instead of
        # exposing the raw "story-NNN.html" filename straight from the DB.
        $url //= '';

        my $urli = eval { CapUrl($url, $cap) };
        $urli = $url if !defined($urli) || $urli eq '';

        $url = $urli;

        # normalize url
        $url =~ s/^\/+/\//g;
        $url = "/$url" if ($url ne '' && $url !~ /^\//);

        if ($ips_only) {
            push @rows, {
                ip   => $ip,
                host => $host,
            };

            next;
        }

        my $is_old = ($et > 0 && ($now - 86400) > $et)
            ? JSON::PP::true
            : JSON::PP::false;

        # q= from referer
        my $qstr = '';

        if ($ref =~ /[?&]q=/) {
            $qstr = $ref;
            $qstr =~ s/^.*[?&]q=([^&]*).*$/$1/;
            $qstr =~ s/\+/ /g;
            $qstr =~ s/%([0-9A-Fa-f]{2})/pack("C", hex($1))/eg;
            $qstr =~ s/\s+/ /g;
            $qstr = _trim($qstr);
        }

        my $cap_short = _truncate(_strip_html($cap), 240);

        my $ref_short = $ref;
        $ref_short =~ s/^https?:\/\///i;
        $ref_short = _truncate($ref_short, 80);

        my $blob = join(
            " ",
            $ts,
            $ip,
            $host,
            $cap_short,
            $ref_short,
            $qstr,
            $ua,
            $lfn
        );

        $blob =~ s/\s+/ /g;

        push @rows, {
            time_epoch    => $et,
            time          => $ts,
            ip            => $ip,
            host          => $host,
            ua            => $ua,
            url           => $url,
            local_file    => $lfn,
            title         => $cap_short,
            referer       => $ref,
            referer_short => $ref_short,
            q             => $qstr,
            is_old        => $is_old,
            blob          => $blob,
        };
    }

    $sth->finish();

    return \@rows;
}

# ---------------------------------------------------------------------
# JSON response
# ---------------------------------------------------------------------

sub _print_json
{
    my ($depth) = @_;

    _print_json_header();

    my $rows;

    eval {
        $rows = _fetch_rows($depth);
        1;
    } or do {
        my $err = $@ || "Unknown error";
        $err = _one_line($err);

        my %payload = (
            ok    => JSON::PP::false,
            depth => $depth,
            error => $err,
            data  => [],
            count => 0,
        );

        print _json_encode(\%payload);
        return;
    };

    my $search_raw = _trim(_param_utf8($so{'SEARCH'} // $so{'search'} // ''));
    my $exact      = ($so{'exact'} // '') ne '' ? 1 : 0;

    my @terms = ($search_raw eq '')
        ? ()
        : ($exact ? ($search_raw) : _split_search_terms($search_raw));

    my %payload = (
        ok    => JSON::PP::true,
        depth => $depth,
        count => scalar(@$rows),
        data  => $rows,
        terms => \@terms,
    );

    print _json_encode(\%payload);
}

# ---------------------------------------------------------------------
# HTML page
# ---------------------------------------------------------------------

sub _print_html
{
    my ($depth) = @_;

    my $search  = _html_attr(_param_utf8($so{'SEARCH'} // $so{'search'} // ''));
    my $site    = _html_attr(_param_utf8($so{'site'}    // ''));
    my $section = _html_attr(_param_utf8($so{'section'} // ''));
    my $referer = _html_attr(_param_utf8($so{'referer'} // ''));

    my $compact = ($so{'compact'} // '') ne '' ? 'checked' : '';
    my $ips     = ($so{'ips'}     // '') ne '' ? 'checked' : '';
    my $exact   = ($so{'exact'}   // '') ne '' ? 'checked' : '';

    my $from = _html_attr(_param_utf8($so{'from'} // ''));
    my $to   = _html_attr(_param_utf8($so{'to'}   // ''));

    my $order       = lc($so{'order'} // 'desc');
    my $order_desc  = ($order ne 'asc') ? 'selected' : '';
    my $order_asc   = ($order eq 'asc') ? 'selected' : '';

    my @depth_opts = (500, 1000, 2000, 4000, 18000, 160000, 240000, 400000);

    my $depth_options_html = join("", map {
        my $sel = ($_ == $depth) ? " selected" : "";
        "<option$sel>$_</option>"
    } @depth_opts);

    my $page = <<'HTML';
<link rel="stylesheet" href="/css/logview.css">

<section class="lv-wrap">
  <header class="lv-head">
    <div>
      <h1 class="lv-title">Article Reading History</h1>
      <p class="lv-sub">Haku tapahtuu JSON-rajapinnan kautta (<code>?format=json</code>) ja selain piirtää tulokset.</p>
    </div>
  </header>

  <form class="lv-form" id="lvForm" autocomplete="off">
    <div class="lv-grid">
      <label class="lv-field">
        <span>Article title</span>
        <input name="SEARCH" value="__SEARCH__" placeholder="esim. Trump, Gaza, Iran">
      </label>

      <label class="lv-field">
        <span>Visitor host / IP</span>
        <input name="site" value="__SITE__" placeholder="esim. .fi tai 1.2.3.4">
      </label>

      <label class="lv-field">
        <span>Section (local file)</span>
        <input name="section" value="__SECTION__" placeholder="esim. talous, maailma">
      </label>

      <label class="lv-field">
        <span>Referer</span>
        <input name="referer" value="__REFERER__" placeholder="esim. google, facebook">
      </label>

      <label class="lv-field">
        <span>Depth</span>
        <select name="depth">
          __DEPTH_OPTIONS__
        </select>
      </label>

      <label class="lv-field">
        <span>From (pp.kk.vvvv)</span>
        <input name="from" value="__FROM__" placeholder="esim. 01.01.2026">
      </label>

      <label class="lv-field">
        <span>To (pp.kk.vvvv)</span>
        <input name="to" value="__TO__" placeholder="esim. 31.01.2026">
      </label>

      <label class="lv-field">
        <span>Order</span>
        <select name="order">
          <option value="desc" __ORDER_DESC__>Newest first</option>
          <option value="asc" __ORDER_ASC__>Oldest first</option>
        </select>
      </label>

      <div class="lv-field lv-checks">
        <label class="lv-check"><input type="checkbox" name="compact" value="1" __COMPACT__> Compact</label>
        <label class="lv-check"><input type="checkbox" name="ips" value="1" __IPS__> IPs only</label>
        <label class="lv-check"><input type="checkbox" name="exact" value="1" __EXACT__> Exact phrase</label>
      </div>

      <div class="lv-actions">
        <button type="submit" class="lv-btn">Find</button>
        <button type="button" class="lv-btn lv-btn-ghost" id="lvReset">Reset</button>
      </div>
    </div>
  </form>

  <div class="lv-toolbar">
    <div class="lv-status" id="lvStatus">Ready.</div>
    <div class="lv-tools">
      <input id="lvQuick" class="lv-quick" type="search" placeholder="Suodata tuloksia lennosta…">
      <button class="lv-btn lv-btn-ghost" id="lvCopy" type="button">Copy visible</button>
      <button class="lv-btn lv-btn-ghost" id="lvExport" type="button">Export CSV</button>
    </div>
  </div>

  <div class="lv-table" role="table" aria-label="Visitor log">
    <div class="lv-row lv-row-head" role="row">
      <div class="lv-cell" role="columnheader">Time</div>
      <div class="lv-cell" role="columnheader">From where</div>
      <div class="lv-cell" role="columnheader">Article title</div>
      <div class="lv-cell" role="columnheader">Referer</div>
    </div>
    <div id="lvBody" class="lv-body" role="rowgroup"></div>
  </div>
</section>

<script>
(() => {
  const form      = document.getElementById('lvForm');
  const body      = document.getElementById('lvBody');
  const status    = document.getElementById('lvStatus');
  const quick     = document.getElementById('lvQuick');
  const reset     = document.getElementById('lvReset');
  const copyBtn   = document.getElementById('lvCopy');
  const exportBtn = document.getElementById('lvExport');

  let lastRows  = [];
  let lastTerms = [];

  const esc = (s) => (s ?? '').toString()
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;')
    .replaceAll("'",'&#39;')
    .replaceAll('`','&#96;')
    .replaceAll('´','&#180;');

  const escRegex = (s) => (s ?? '').toString().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  const highlight = (text, terms) => {
    let out = esc(text);

    if (!terms || !terms.length) {
      return out;
    }

    for (const t of terms) {
      if (!t) continue;
      const re = new RegExp('(' + escRegex(t) + ')', 'ig');
      out = out.replace(re, '<mark>$1</mark>');
    }

    return out;
  };

  const debounce = (fn, ms=150) => {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), ms);
    };
  };

  const cleanPossibleBadCgiPrefix = (text) => {
    /*
     * Normaalisti tätä ei enää tarvita.
     * Tämä on vain turvaverkko, jos jokin muu include tulostaa vahingossa.
     */

    text = (text ?? '').toString();

    const p1 = text.indexOf('{');
    const p2 = text.indexOf('[');

    let p = -1;

    if (p1 >= 0 && p2 >= 0) {
      p = Math.min(p1, p2);
    } else if (p1 >= 0) {
      p = p1;
    } else if (p2 >= 0) {
      p = p2;
    }

    if (p > 0) {
      return text.slice(p).trim();
    }

    return text.trim();
  };

  const fetchJSON = async (params) => {
    const url = new URL(window.location.href);

    url.search = params.toString();
    url.searchParams.set('format','json');
    url.searchParams.set('_', Date.now().toString());

    status.textContent = 'Loading…';

    const r = await fetch(url.toString(), {
      method: 'GET',
      cache: 'no-store',
      headers: {
        'Accept': 'application/json'
      }
    });

    if (!r.ok) {
      throw new Error('HTTP ' + r.status);
    }

    const text = await r.text();
    const cleaned = cleanPossibleBadCgiPrefix(text);

    try {
      return JSON.parse(cleaned);
    } catch (e) {
      throw new Error('JSON.parse failed. First 120 chars: ' + text.slice(0,120));
    }
  };

  const render = (rows) => {
    body.innerHTML = '';

    const ipsOnly = form.querySelector('input[name="ips"]').checked;

    if (ipsOnly) {
      for (const it of (rows || [])) {
        const row = document.createElement('div');
        row.className = 'lv-row';
        row.dataset.search = ((it.ip || '') + ' ' + (it.host || '')).toLowerCase();

        row.innerHTML = `
          <div class="lv-cell">${esc(it.ip || '')}</div>
          <div class="lv-cell">${esc(it.host || '')}</div>
          <div class="lv-cell"></div>
          <div class="lv-cell"></div>
        `;

        body.appendChild(row);
      }

      return;
    }

    for (const it of (rows || [])) {
      const row = document.createElement('div');
      row.className = 'lv-row' + (it.is_old ? ' lv-old' : '');
      row.dataset.search = ((it.blob || '')).toLowerCase();

      const titleHtml = highlight(it.title || '', lastTerms);

      const articleLink = it.url
        ? `<a class="lv-link" href="${esc(it.url)}" target="_blank" rel="noopener">${titleHtml}</a>`
        : titleHtml;

      const refLink = it.referer
        ? `<a class="lv-link lv-link-dim" href="${esc(it.referer)}" target="_blank" rel="noopener">${esc(it.referer_short || it.referer)}</a>`
        : '';

      const q = it.q ? `<div class="lv-q">q: ${esc(it.q)}</div>` : '';

      row.innerHTML = `
        <div class="lv-cell lv-time">${esc(it.time || '')}</div>
        <div class="lv-cell">
          <div class="lv-host">${esc(it.ip || '')} <span class="lv-host-dim">(${esc(it.host || '')})</span></div>
          <div class="lv-ua">${esc(it.ua || '')}</div>
        </div>
        <div class="lv-cell">${articleLink}</div>
        <div class="lv-cell">${q}${refLink}</div>
      `;

      body.appendChild(row);
    }
  };

  const applyQuick = () => {
    const q = (quick.value || '').trim().toLowerCase();
    const rows = Array.from(body.querySelectorAll('.lv-row'));

    let shown = 0;

    for (const r of rows) {
      const ok = !q || (r.dataset.search && r.dataset.search.includes(q));
      r.hidden = !ok;

      if (ok) {
        shown++;
      }
    }

    status.textContent = `Showing ${shown} / ${rows.length}`;
  };

  const run = async () => {
    const params = new URLSearchParams(new FormData(form));

    try {
      const data = await fetchJSON(params);

      if (!data || data.ok !== true) {
        const msg = data && data.error ? data.error : 'Unknown server error';
        status.textContent = 'Server error: ' + msg;
        body.innerHTML = '';
        return;
      }

      lastRows  = data.data  || [];
      lastTerms = data.terms || [];

      render(lastRows);

      status.textContent = `Loaded ${data.count} rows.`;

      applyQuick();
    } catch (e) {
      status.textContent = 'Error: ' + (e && e.message ? e.message : e);
    }
  };

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    run();
  });

  quick.addEventListener('input', debounce(applyQuick, 120));

  reset.addEventListener('click', () => {
    form.reset();
    quick.value = '';
    run();
  });

  exportBtn.addEventListener('click', () => {
    const ipsOnly = form.querySelector('input[name="ips"]').checked;

    // Suodatetut (näkyvät) rivit indeksin mukaan, koska lvRow-elementit
    // luodaan samassa järjestyksessä kuin lastRows.
    const rows = lastRows.filter((_, i) => {
      const el = body.children[i];
      return el && !el.hidden;
    });

    const csvEscape = (v) => {
      v = (v ?? '').toString();
      if (/[",\n]/.test(v)) {
        v = '"' + v.replace(/"/g, '""') + '"';
      }
      return v;
    };

    let header, lines;

    if (ipsOnly) {
      header = ['ip', 'host'];
      lines = rows.map(r => [r.ip, r.host].map(csvEscape).join(','));
    } else {
      header = ['time', 'ip', 'host', 'title', 'url', 'referer', 'q'];
      lines = rows.map(r => [r.time, r.ip, r.host, r.title, r.url, r.referer, r.q].map(csvEscape).join(','));
    }

    const csv = [header.join(','), ...lines].join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = 'logview_' + Date.now() + '.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);

    status.textContent = `Exported ${rows.length} rows to CSV.`;
  });

  copyBtn.addEventListener('click', async () => {
    const rows = Array.from(body.querySelectorAll('.lv-row')).filter(r => !r.hidden);

    const lines = rows.map(r =>
      r.innerText
        .replace(/\s+\n/g, '\n')
        .replace(/\n+/g, ' | ')
    );

    try {
      await navigator.clipboard.writeText(lines.join('\n'));
      status.textContent = 'Copied visible rows to clipboard.';
    } catch {
     status.textContent = 'Copy failed (browser denied).';
    }
  });

  run();
})();
</script>
HTML

    $page =~ s/__SEARCH__/$search/g;
    $page =~ s/__SITE__/$site/g;
    $page =~ s/__SECTION__/$section/g;
    $page =~ s/__REFERER__/$referer/g;
    $page =~ s/__DEPTH_OPTIONS__/$depth_options_html/g;
    $page =~ s/__COMPACT__/$compact/g;
    $page =~ s/__IPS__/$ips/g;
    $page =~ s/__EXACT__/$exact/g;
    $page =~ s/__FROM__/$from/g;
    $page =~ s/__TO__/$to/g;
    $page =~ s/__ORDER_DESC__/$order_desc/g;
    $page =~ s/__ORDER_ASC__/$order_asc/g;

    print $page;
}