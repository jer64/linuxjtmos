#!/bin/bash

#
cd /home/vai/altse/html/cgi
#
PATH=$PATH:/home/vai/sdb/bin
export PATH

#
echo "3"
lynx -source https://vunet.net/finnish/ > /tmp/index-finnish.html
cp /tmp/index-finnish.html /home/vai/altse/html/cache/index-finnish.html
#
echo "4"
lynx -source https://vunet.net/english/ > /tmp/index-english.html
cp /tmp/index-english.html /home/vai/altse/html/cache/index-english.html
