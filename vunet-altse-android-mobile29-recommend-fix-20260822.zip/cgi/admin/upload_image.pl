#!/usr/bin/perl
#
# upload_image.pl - Vunet.net admin upload
#

use strict;
use warnings;
use FindBin;
use Fcntl qw(O_WRONLY O_CREAT O_EXCL);
use File::Basename qw(basename);
use CGI ();

# tools.pl is loaded from the same directory as this CGI script.
require "$FindBin::Bin/tools.pl";

our $IMAGES_BASE;

# Allow uploads and reject excessively large POST requests cleanly.
$CGI::DISABLE_UPLOADS = 0;
$CGI::POST_MAX        = 50 * 1024 * 1024;    # 50 MiB

$| = 1;

my $query = CGI->new;

if (($ENV{'REQUEST_METHOD'} || 'GET') eq 'POST') {
    SaveFile($query);
}
else {
    print $query->header(
        -type    => 'text/html',
        -charset => 'UTF-8'
    );
    MainPage($query);
}

exit 0;

##############################################################################
sub UploadForm
{
    my ($q) = @_;

    my $r      = scalar($q->param('r')) || '';
    my $action = $ENV{'SCRIPT_NAME'} || '/cgi/admin/upload_image.pl';

    $r      = CGI::escapeHTML($r);
    $action = CGI::escapeHTML($action);

    print qq{
<h1>JPEG-kuvan l&auml;hetys Vunettiin</h1>
<br>

<form action="$action" enctype="multipart/form-data" method="post">
Valitse kuva tai muu sallittu tiedosto, jonka haluat l&auml;hett&auml;&auml:<br>
<input type="file" name="datafile" size="40" id="fo"><br>
<input type="submit" value="L&auml;het&auml; tiedosto">
<input type="hidden" name="r" value="$r">
</form>
};
}

##############################################################################
sub SaveFile
{
    my ($q) = @_;

    my $cgi_error = $q->cgi_error;
    if ($cgi_error) {
        ErrorPage($q, "HTTP/CGI-virhe tiedostoa vastaanotettaessa: $cgi_error");
    }

    # Do not decide whether an upload exists with param('datafile').
    # The actual upload filehandle is the reliable test for multipart uploads.
    my $upload = $q->upload('datafile');
    my $original_name = scalar($q->param('datafile')) || '';

    if (!$upload) {
        ErrorPage(
            $q,
            'Tiedostoa ei vastaanotettu. Tarkista, ett&auml; lomake k&auml;ytt&auml;&auml; '
            . 'multipart/form-data-enkoodausta ja ett&auml; tiedosto on valittu.'
        );
    }

    # Browsers can submit either Unix or Windows style paths.
    $original_name =~ tr{\\}{/};
    $original_name = basename($original_name);

    if ($original_name eq '') {
        ErrorPage($q, 'L&auml;hetetyn tiedoston nimi puuttuu.');
    }

    # Preserve the old accepted formats and add jpeg/webp.
    my %allowed_extension = map { $_ => 1 }
        qw(jpg jpeg gif png webp xls doc txt swf flv pdf);

    my ($extension) = $original_name =~ /\.([^.]+)\z/;
    $extension = defined($extension) ? lc($extension) : '';

    if (!$allowed_extension{$extension}) {
        ErrorPage(
            $q,
            'Tiedostomuoto ei ole sallittu. Sallitut p&auml;&auml;tteet: '
            . join(', ', sort keys %allowed_extension)
        );
    }

    # Make a safe local filename. Directory components and shell characters
    # are removed, while the accepted extension is retained.
    my $filename = lc($original_name);
    $filename =~ s/[^a-z0-9._ -]+/_/g;
    $filename =~ s/^\.+/_/;
    $filename =~ s/\.{2,}/./g;

    if ($filename eq '' || $filename eq '.' || $filename eq '..') {
        ErrorPage($q, 'Tiedostonimest&auml; ei saatu turvallista tiedostonime&auml;.');
    }

    my $path = '/home/vai/images';
    my $output_name = "$path/$filename";

    if (!-d $path) {
        ErrorPage($q, "Tallennushakemistoa ei ole olemassa: $path");
    }

    if (!-w $path) {
        my $effective_user = getpwuid($>) || $>;
        ErrorPage(
            $q,
            "CGI-prosessilla ($effective_user) ei ole kirjoitusoikeutta hakemistoon: $path"
        );
    }

    # Write to a temporary file in the same directory and rename it only after
    # the complete upload has been written. This also creates a valid 0-byte
    # file when the uploaded source file is empty.
    my $temporary_name = "$path/.upload-$$-" . time() . "-$filename";
    my $output;

    if (!sysopen($output, $temporary_name, O_WRONLY | O_CREAT | O_EXCL, 0644)) {
        ErrorPage($q, "V&auml;liaikaistiedostoa ei voitu avata: $temporary_name: $!");
    }

    binmode($upload);
    binmode($output);

    my $bytes_written = 0;
    my $buffer;

    while (1) {
        my $bytes_read = read($upload, $buffer, 64 * 1024);

        if (!defined($bytes_read)) {
            close($output);
            unlink($temporary_name);
            ErrorPage($q, "L&auml;hetystiedoston lukeminen ep&auml;onnistui: $!");
        }

        last if $bytes_read == 0;

        my $offset = 0;
        while ($offset < $bytes_read) {
            my $written = syswrite(
                $output,
                $buffer,
                $bytes_read - $offset,
                $offset
            );

            if (!defined($written) || $written == 0) {
                close($output);
                unlink($temporary_name);
                ErrorPage($q, "Tiedoston kirjoittaminen ep&auml;onnistui: $!");
            }

            $offset        += $written;
            $bytes_written += $written;
        }
    }

    if (!close($output)) {
        unlink($temporary_name);
        ErrorPage($q, "Tiedoston sulkeminen ep&auml;onnistui: $!");
    }

    if (!rename($temporary_name, $output_name)) {
        unlink($temporary_name);
        ErrorPage($q, "Valmista tiedostoa ei voitu siirt&auml;&auml; paikalleen: $output_name: $!");
    }

    chmod(0644, $output_name);

    # Remove old thumbnails only after the original file has been saved.
    for my $thumb_dir (qw(thumb thumb2 thumb3 thumb4)) {
        unlink("$path/$thumb_dir/$filename");
    }

    # Refresh the old image directory cache, but do not claim that the upload
    # failed if only cache refreshing fails.
    my $cache_warning = '';
    eval {
        my @temp = main::LoadList('/home/vai/altse/html/cgi/admin/IMGdircache/|');
        1;
    } or do {
        $cache_warning = $@ || 'Tuntematon IMGdircache-virhe';
    };

    my $r = scalar($q->param('r')) || '';
    if ($r eq '') {
        my $host = $ENV{'HTTP_HOST'} || 'vunet.net';
        my $self = $ENV{'SCRIPT_NAME'} || '/cgi/admin/upload_image.pl';
        $r = "https://$host$self";
    }

    my $redirect = '/cgi/admin/thumbupd.pl?r=' . CGI::escape($r);

    print $q->header(
        -type    => 'text/html',
        -charset => 'UTF-8'
    );

    my $safe_filename = CGI::escapeHTML($filename);
    my $safe_redirect = CGI::escapeHTML($redirect);
    my $kilobytes     = int(($bytes_written + 1023) / 1024);

    print qq{
<!doctype html>
<html lang="fi">
<head>
<meta charset="UTF-8">
<title>Tiedosto l&auml;hetetty</title>
<meta http-equiv="refresh" content="0; url=$safe_redirect">
</head>
<body>
<h3>Tiedosto l&auml;hetettiin onnistuneesti ($safe_filename, $bytes_written tavua / $kilobytes kt).</h3>
};

    if ($cache_warning ne '') {
        print '<p>Varoitus: hakemistov&auml;limuistin p&auml;ivitys ep&auml;onnistui: '
            . CGI::escapeHTML($cache_warning) . '</p>';
    }

    print qq{
<p><a href="$safe_redirect">Jatka pikkukuvien p&auml;ivitykseen</a></p>
</body>
</html>
};
}

##############################################################################
sub ErrorPage
{
    my ($q, $message) = @_;

    print $q->header(
        -type    => 'text/html',
        -charset => 'UTF-8',
        -status  => '500 Internal Server Error'
    );

    my $safe_message = CGI::escapeHTML($message || 'Tuntematon virhe');
    my $action = CGI::escapeHTML(
        $ENV{'SCRIPT_NAME'} || '/cgi/admin/upload_image.pl'
    );

    print qq{
<!doctype html>
<html lang="fi">
<head>
<meta charset="UTF-8">
<title>L&auml;hetys ep&auml;onnistui</title>
</head>
<body>
<h2>Tiedoston l&auml;hetys ep&auml;onnistui</h2>
<p>$safe_message</p>
<p><a href="$action">Palaa l&auml;hetyslomakkeeseen</a></p>
</body>
</html>
};

    exit 1;
}

##############################################################################
sub MainPage
{
    my ($q) = @_;

    my $images_base = CGI::escapeHTML($IMAGES_BASE || '');

    print qq{
<!doctype html>
<html lang="fi">
<head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="$images_base/uutiset.css" title="Cool">
<link rel="shortcut icon" href="$images_base/search.ico">
<title>Tiedoston l&auml;hetys</title>
</head>
<body>
<table width="100%" height="100%" cellspacing="0" cellpadding="0">
<tr valign="top">
<td>
<table width="640" height="100%" cellspacing="0" cellpadding="32">
<tr>
<td>
};

    UploadForm($q);

    print qq{
<br><br><br><br>
<br><br><br><br>
<br><br><br><br>
<br><br><br><br>
</td>
</tr>
</table>
</td>
</tr>
</table>
</body>
</html>
};
}
