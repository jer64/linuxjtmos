#!/usr/bin/perl
# postitus.pl
# POSTITUS SUOMENKIELISELLE LISTALLE
##############################################################################################################

#
chdir("/home/vai/altse/html/cgi/admin/");
require "/home/vai/altse/html/cgi/tools.pl";

#
main();



###########################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$f,$f2,@lst);

	#
	@lst = LoadList("/home/vai/altse/html/cgi/admin/lib_postitus.pl \"https://text.vunet.net/?v=&sec=kaikki&c=10&printable=2\"|");

	#
	@lista = LoadList("cfg/postituslista.txt"); # postituslista.txt

	#
	$subject = "[Vunet.org] $lst[3]";
	$subject =~ s/\n//g;
	$subject =~ s/\r//g;
	$subject =~ s/\t/ /g;
	$subject =~ tr/[A-Z���]/[a-z���]/;

	#
	loop: for($i=0,$st=time; $i<($#lista+1); $i++)
	{
		$recp = $lista[$i];
		if($jo{$recp} ne "") { goto past; }
		$jo{$recp}++;
		print STDERR "$recp\n";
		$lst[$i] =~ s/\s*$//;
		$lst[$i] =~ s/^\s*//;

		$t = time;
		if( ($t-$st)>=(60*2) ) { last loop; }

		if($recp=~/\@/ && $recp=~/\./)
		{
			open($f, "|mail $recp -s \"$subject\"");
			for($i2=0; $i2<($#lst+1); $i2++)
			{
				$lst[$i2] =~ s/\s*$//;
				$lst[$i2] =~ s/^\s*//;

				print $f "$lst[$i2]\n";
			}
			close($f);
		}
past:
	}

	#
}


