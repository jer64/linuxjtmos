#!/usr/bin/perl
chdir("cd /home/vai/altse/html/cgi/admin");
system("./up2b.sh");
