#!/usr/bin/perl
# en_postitus.pl
# POSTITUS ENGLANNINKIELISELLE LISTALLE
##############################################################################################################

#
chdir("/home/vai/altse/html/cgi/admin/");
require "/home/vai/altse/html/cgi/tools.pl";

#
main();

###########################################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$f,$f2,@lst);

	#
	@lst = LoadList("gov_article.txt");

	#
	@lista = LoadList("cfg/gov_postituslista.txt");

	#
	$subject =  "Saddam Hussein's Ba'ath Iraqi Television Online Now";

	#
	loop: for($i=0,$st=time; $i<($#lista+1); $i++)
	{
		$recp = $lista[$i];
		print STDERR "$recp\n";

		$t = time;
		if( ($t-$st)>=(60*2) ) { last loop; }

		if($recp=~/\@/ && $recp=~/\./)
		{
			open($f, "|mail $recp -s \"$subject\"");
			for($i2=0; $i2<($#lst+1); $i2++)
			{
				print $f "$lst[$i2]\n";
			}
			close($f);
		}
	}

	#
}


