#!/usr/bin/perl

#use strict;
#use warnings;
use utf8;
use open qw(:std :encoding(UTF-8));
use DBI;
use File::Find;
use File::Basename qw(basename);
use Cwd qw(abs_path);

################################################################################
#
# MakeImageList.pl
#
# Tekee koko kuvalistan SQL-tietokantaan:
#
#   vunet.imagelist
#
# Taulun formaatti, lisättynä score-kentällä:
#
#   id       bigint unsigned auto_increment
#   age      bigint unsigned
#   fname    TEXT
#   category char(30)
#   score    bigint unsigned
#
# Idea samaan suuntaan kuin rankarticle.pl:
#
#   - luetaan genstat.txt muistissa olevaan hash-tauluun
#   - otetaan rankarticle.pl:stä paikalliset aktivointisanat ja vahvat termit
#   - puretaan kuvatiedostonimestä ja polusta sanat
#   - verrataan tiedostonimen 1-5 sanan ngrammeja genstat.txt-termeihin
#   - lasketaan score
#   - poistetaan duplikaatit
#   - järjestetään koko valmis lista score DESC -järjestykseen
#   - kirjoitetaan SQL:ään siinä järjestyksessä
#
# Käyttö:
#
#   ./MakeImageList.pl
#   ./MakeImageList.pl /home/vai/altse/html/www
#   ./MakeImageList.pl /home/vai/altse/html/www /home/vai/altse/html/articles
#   ./MakeImageList.pl --genstat /home/vai/cgi/cache/genstat.txt /home/vai/altse/html/www
#
################################################################################

require "./tools.pl";
require "./modules/sql.pm";

my $DEFAULT_IMAGE_ROOT = "/home/vai/altse/html/www";
my $DEFAULT_GENSTAT    = "/home/vai/cgi/cache/genstat.txt";

my $BATCH_SIZE         = 500;
my $CATEGORY_MAX_LEN   = 30;
my $GENSTAT_MAX_TERMS  = 60000;
my $MAX_NGRAM_WORDS    = 5;

# Pisteytys.
my $GENSTAT_MATCH_SCORE = 700;
my $NORMAL_WORD_SCORE   = 300;
my $STRONG_WORD_SCORE   = 500;
my $CATEGORY_BONUS      = 150;
my $FRESH_IMAGE_BONUS   = 250;
my $OLD_IMAGE_PENALTY   = 100;

# Jos haluat vain JPG:t kuten alkuperäisessä versiossa, vaihda tähän:
# my $IMAGE_RE = qr/\.jpe?g$/i;
my $IMAGE_RE = qr/\.(?:jpe?g|png|gif|webp)$/i;

################################################################################
# rankarticle.pl:stä haetut paikalliset aktivointisanat.
################################################################################

my @activation_words = (
    'tekoäly',
    'AI',
    'robotiikka',
    'robotti',
    'ihmisrobotti',
    'teknologia',
    'puolijohde',
    'puolijohteet',
    'sirut',
    'avoimen',
    'lähdekoodin',

    'Kiina',
    'Yhdysvallat',
    'Venäjä',
    'Eurooppa',
    'EU',
    'Nato',
    'Ukraina',

    'dollari',
    'euro',
    'pörssi',
    'NASDAQ',
    'Nasdaq',
    'IPO',
    'inflaatio',
    'kulta',
    'öljy',
    'Bitcoin',
    'ETF',
    'rahoitus',
    'sijoittajat',
    'markkinat',
    'talous',

    'DeepSeek',
    'Unitree',
    'Nvidia',
    'NVIDIA',
    'OpenAI',
    'Microsoft',
    'Google',
    'Apple',
    'Intel',
    'Foxconn',
);

my %strong_words = map { lc($_) => 1 } (
    'DeepSeek',
    'Unitree',
    'Nvidia',
    'NVIDIA',
    'OpenAI',
    'Microsoft',
    'Google',
    'Apple',
    'Intel',
    'Foxconn',
    'IPO',
    'NASDAQ',
    'Bitcoin',
    'tekoäly',
    'AI',
    'robotiikka',
    'puolijohde',
    'puolijohteet',
);

my %activation_score;

foreach my $word (@activation_words) {
    my $k = NormalizeTerm($word);
    next if ($k eq '');

    if (exists $strong_words{lc($word)}) {
        $activation_score{$k} = $STRONG_WORD_SCORE;
    }
    else {
        $activation_score{$k} = $NORMAL_WORD_SCORE;
    }
}

our $gl_dbh;

AltseSQLConnect();
main();

################################################################################
# Pääohjelma.
################################################################################

sub main
{
    my ($genstat_file, @roots) = ParseCommandLine(@ARGV);

    @roots = CleanRoots(@roots);

    if (!@roots) {
        die "MakeImageList.pl: no readable image roots\n";
    }

    print STDERR "MakeImageList.pl: genstat=$genstat_file\n" if ($genstat_file ne '');

    my %genstat_score = LoadGenstatScores($genstat_file);
    my @images        = BuildImageList(\%genstat_score, @roots);

    RecreateImageListTable();
    InsertImageList(@images);

    print STDERR "MakeImageList.pl: inserted " . scalar(@images) . " images into vunet.imagelist, sorted by score\n";

    exit 0;
}

################################################################################
# Komentorivi.
################################################################################

sub ParseCommandLine
{
    my (@args) = @_;

    my $genstat_file = $DEFAULT_GENSTAT;
    my @roots;

    while (@args) {
        my $arg = shift @args;
        $arg //= '';

        if ($arg eq '--genstat' || $arg eq '-g') {
            $genstat_file = shift(@args) || '';
            next;
        }

        if ($arg eq '--jpg-only') {
            $IMAGE_RE = qr/\.jpe?g$/i;
            next;
        }

        push @roots, $arg;
    }

    @roots = ($DEFAULT_IMAGE_ROOT) if (!@roots);

    if (!defined $genstat_file || $genstat_file eq '' || !-e $genstat_file) {
        print STDERR "MakeImageList.pl: genstat.txt not found, using only filename activation words\n";
        $genstat_file = '';
    }

    return ($genstat_file, @roots);
}

################################################################################
# Siivoa ja varmista juurihakemistot.
################################################################################

sub CleanRoots
{
    my (@in) = @_;
    my @out;
    my %seen;

    foreach my $root (@in) {
        $root //= '';
        $root =~ s/^\s+|\s+$//g;
        next if ($root eq '');
        next if (!-d $root);

        my $abs = abs_path($root) || $root;
        $abs =~ s{/+$}{};

        next if ($seen{$abs}++);
        push @out, $abs;
    }

    return @out;
}

################################################################################
# Lue tiedosto.
################################################################################

sub ReadFile
{
    my ($file) = @_;

    return '' if (!defined $file || $file eq '');
    return '' if (!-e $file);

    open my $fh, '<:encoding(UTF-8)', $file
        or die "Cannot open '$file': $!\n";

    local $/;
    my $data = <$fh>;
    close $fh;

    $data //= '';
    return $data;
}

################################################################################
# Puhdista genstat-rivi.
#
# Tuetaan ainakin näitä muotoja:
#
#   sana
#   123 sana
#   sana 123
#   sana|123
#   123|sana
#   123|1-5 avainsanaa|koordinaattilista
#   1-5 avainsanaa|123
#
# Palauttaa: ($term, $weight)
################################################################################

sub CleanGenstatLine
{
    my ($line) = @_;

    $line //= '';
    $line =~ s/\r//g;
    $line =~ s/^\s+|\s+$//g;

    return ('', 0) if ($line eq '');
    return ('', 0) if ($line =~ /^#/);

    my $term   = $line;
    my $weight = 1;

    if ($line =~ /\|/) {
        my @p = split /\|/, $line;

        if (defined $p[0] && $p[0] =~ /^\s*(\d+)\s*$/) {
            $weight = int($1);
            $term = $p[1] // '';
        }
        elsif (defined $p[1] && $p[1] =~ /^\s*(\d+)\s*$/) {
            $term = $p[0] // '';
            $weight = int($1);
        }
        else {
            $term = $p[0] // '';
        }
    }
    elsif ($line =~ /^\s*(\d+)\s+(.+)$/) {
        $weight = int($1);
        $term = $2;
    }
    elsif ($line =~ /^(.+?)\s+(\d+)\s*$/) {
        $term = $1;
        $weight = int($2);
    }

    $term = NormalizeTerm($term);

    return ('', 0) if ($term eq '');
    return ('', 0) if ($term =~ /^\d+$/);
    return ('', 0) if ($term =~ /^https?\s+/i);
    return ('', 0) if ($term =~ /\b(lähteet|lahteet|sources|hakukyselyt|hakuehdotukset|hakusuositukset|avainsanat|keywords)\b/i);

    my $wc = WordCount($term);

    return ('', 0) if ($wc < 1);
    return ('', 0) if ($wc > $MAX_NGRAM_WORDS);

    $weight = 1 if (!defined $weight || $weight < 1);

    return ($term, $weight);
}

################################################################################
# Lue genstat.txt score-hashiksi.
################################################################################

sub LoadGenstatScores
{
    my ($file) = @_;
    my %score;

    return %score if (!defined $file || $file eq '' || !-e $file);

    my $data  = ReadFile($file);
    my @lines = split /\n+/, $data;
    my $count = 0;

    foreach my $line (@lines) {
        my ($term, $weight) = CleanGenstatLine($line);

        next if ($term eq '');

        # Jos sama termi tulee monta kertaa, pidetään suurempi paino.
        if (!exists $score{$term} || $score{$term} < $weight) {
            $score{$term} = $weight;
        }

        $count++;
        last if ($count >= $GENSTAT_MAX_TERMS);
    }

    print STDERR "MakeImageList.pl: loaded " . scalar(keys %score) . " genstat terms\n";

    return %score;
}

################################################################################
# Rakenna kuvalista kaikista annetuista hakemistoista.
################################################################################

sub BuildImageList
{
    my ($genstat_score, @roots) = @_;
    my @rows;
    my %seen;

    foreach my $root (@roots) {
        print STDERR "MakeImageList.pl: scanning $root\n";

        find(
            {
                wanted => sub {
                    my $file = $File::Find::name;

                    return if (!defined $file || $file eq '');
                    return if (!-f $file);
                    return if ($file !~ /$IMAGE_RE/);

                    my $clean_file = CleanFileName($file);
                    return if ($clean_file eq '');

                    # Sama tiedosto vain kerran, vaikka juuria olisi päällekkäin.
                    my $dedup_key = lc($clean_file);
                    return if ($seen{$dedup_key}++);

                    my $age      = SafeFileAge($clean_file);
                    my $category = DetermineCategory($clean_file, @roots);
                    my $score    = ScoreImageFile($clean_file, $category, $age, $genstat_score);

                    push @rows, {
                        score    => int($score),
                        age      => int($age),
                        fname    => $clean_file,
                        category => $category,
                    };
                },
                no_chdir => 1,
            },
            $root
        );
    }

    # Sama idea kuin rankarticle.pl: valmis koko lista lajitellaan scorella.
    @rows = sort {
        $b->{score} <=> $a->{score}
            ||
        $a->{age} <=> $b->{age}
            ||
        ($a->{category} cmp $b->{category})
            ||
        ($a->{fname} cmp $b->{fname})
    } @rows;

    return @rows;
}

################################################################################
# Tiedostonimen kevyt puhdistus SQL:ää varten.
# Varsinainen SQL-turva tulee placeholdereista.
################################################################################

sub CleanFileName
{
    my ($file) = @_;

    $file //= '';
    $file =~ s/\0//g;
    $file =~ s/\r|\n/ /g;
    $file =~ s/\s+$//g;
    $file =~ s/^\s+//g;

    return $file;
}

################################################################################
# Tiedoston ikä.
# Käyttää tools.pl:n FileAge()-funktiota, jos se on olemassa.
################################################################################

sub SafeFileAge
{
    my ($file) = @_;
    my $age;

    if (defined &FileAge) {
        eval {
            $age = FileAge($file);
        };
    }

    if (!defined $age || $age !~ /^\d+$/) {
        my @st = stat($file);
        if (@st) {
            $age = time() - $st[9];
        }
        else {
            $age = 0;
        }
    }

    $age = 0 if (!defined $age || $age < 0);
    return int($age);
}

################################################################################
# Päättele kategoria.
#
# Ensisijaisesti:
#   /articles/talous/kuva.jpg -> talous
#
# Muuten:
#   ensimmäinen alihakemisto annetun rootin alta.
#
# Jos kuva on suoraan juuressa:
#   /home/vai/altse/html/www/kuva.jpg -> www
################################################################################

sub DetermineCategory
{
    my ($file, @roots) = @_;

    $file //= '';

    if ($file =~ m{/articles/([^/]+)/}i) {
        return CleanCategory($1);
    }

    foreach my $root (@roots) {
        next if (!defined $root || $root eq '');

        my $r = $root;
        $r =~ s{/+$}{};

        if (index($file, "$r/") == 0) {
            my $rel = substr($file, length($r) + 1);

            if ($rel =~ m{^([^/]+)/}) {
                return CleanCategory($1);
            }

            return CleanCategory(basename($r));
        }
    }

    if ($file =~ m{/([^/]+)/[^/]+$}) {
        return CleanCategory($1);
    }

    return '';
}

################################################################################
# category char(30), joten katkaistaan turvallisesti.
################################################################################

sub CleanCategory
{
    my ($cat) = @_;

    $cat //= '';
    $cat =~ s/^\s+|\s+$//g;
    $cat =~ s/\0//g;
    $cat =~ s/[^A-Za-z0-9_\-ÅÄÖåäö]/_/g;
    $cat = substr($cat, 0, $CATEGORY_MAX_LEN);

    return $cat;
}

################################################################################
# Normalisoi sana/fraasi.
################################################################################

sub NormalizeTerm
{
    my ($text) = @_;

    $text //= '';
    $text = lc($text);

    # Kuvien tiedostonimissä sanat ovat usein viivoilla, alaviivoilla tai numeroilla.
    $text =~ s/[_\-\.]+/ /g;
    $text =~ s/[^\p{L}\p{N}]+/ /gu;
    $text =~ s/^\s+|\s+$//g;
    $text =~ s/\s+/ /g;

    return $text;
}

################################################################################
# Sanamäärä.
################################################################################

sub WordCount
{
    my ($text) = @_;

    return 0 if (!defined $text);

    my @words = ($text =~ /[\p{L}\p{N}][\p{L}\p{N}\-]*/gu);
    return scalar @words;
}

################################################################################
# Rakenna tiedostosta sanat.
#
# Pisteytystekstiin otetaan mukaan:
#   - basename ilman päätettä
#   - category
#   - polun osat
#
# Tällöin esimerkiksi:
#   /home/vai/altse/html/www/talous/china-ai-chip.jpg
# tuottaa osumia: talous, china, ai, chip jne.
################################################################################

sub ImageSearchText
{
    my ($file, $category) = @_;

    my $txt = $file // '';

    # Poistetaan yleiset juuri-/järjestelmäosat, ettei /home/vai/html anna turhaa kohinaa.
    $txt =~ s{^/home/[^/]+/}{}i;
    $txt =~ s{\b(altse|html|www|images|image|img|thumb|thumbs|thumb2|cgi|cache|public_html)\b}{ }ig;

    # Pääte pois.
    $txt =~ s/\.(?:jpe?g|png|gif|webp)$//i;

    $txt .= " " . ($category // '');

    return NormalizeTerm($txt);
}

################################################################################
# Tokenit.
################################################################################

sub TokensFromText
{
    my ($text) = @_;

    $text = NormalizeTerm($text);

    my @tokens = split /\s+/, $text;

    @tokens = grep {
        defined $_
        && $_ ne ''
        && length($_) >= 2
        && $_ !~ /^\d+$/
    } @tokens;

    return @tokens;
}

################################################################################
# Tee ngrammit 1-5 sanasta.
################################################################################

sub BuildNgrams
{
    my (@tokens) = @_;
    my %ng;

    for (my $i = 0; $i < @tokens; $i++) {
        my $s = '';

        for (my $n = 1; $n <= $MAX_NGRAM_WORDS; $n++) {
            last if (($i + $n - 1) >= @tokens);

            if ($n == 1) {
                $s = $tokens[$i];
            }
            else {
                $s .= ' ' . $tokens[$i + $n - 1];
            }

            $ng{$s} = $n;
        }
    }

    return %ng;
}

################################################################################
# Rajaa genstat-paino järkeväksi.
#
# genstat.txt:n ensimmäinen kenttä voi olla suuri, joten tästä tehdään
# hallittu lisäscore. Näin yksi jättisana ei tuhoa koko lajittelua.
################################################################################

sub GenstatWeightScore
{
    my ($weight, $words) = @_;

    $weight = 1 if (!defined $weight || $weight < 1);
    $words  = 1 if (!defined $words  || $words  < 1);

    my $wscore = $GENSTAT_MATCH_SCORE;

    # Kevyt log-tyylinen nousu ilman Math::log-riippuvuuksia.
    if ($weight >= 1000000) { $wscore += 1200; }
    elsif ($weight >= 100000) { $wscore += 900; }
    elsif ($weight >= 10000) { $wscore += 650; }
    elsif ($weight >= 1000) { $wscore += 400; }
    elsif ($weight >= 100) { $wscore += 200; }
    elsif ($weight >= 10) { $wscore += 100; }

    # Monisanaiset osumat ovat tiedostonimissä merkittävämpiä.
    $wscore += ($words - 1) * 250;

    return int($wscore);
}

################################################################################
# Skoraa yksittäinen kuvatiedosto.
################################################################################

sub ScoreImageFile
{
    my ($file, $category, $age, $genstat_score) = @_;

    my $text = ImageSearchText($file, $category);
    my @tokens = TokensFromText($text);

    return 0 if (!@tokens);

    my %ngrams = BuildNgrams(@tokens);
    my %rewarded;
    my $score = 0;

    # rankarticle.pl-tyyliset paikalliset aktivointisanat.
    foreach my $ng (keys %ngrams) {
        if (exists $activation_score{$ng}) {
            $score += $activation_score{$ng};
            $rewarded{"a:$ng"} = 1;
        }
    }

    # genstat.txt vastaan tiedostonimen sanat ja fraasit.
    foreach my $ng (keys %ngrams) {
        next if (!exists $genstat_score->{$ng});
        next if ($rewarded{"g:$ng"});

        my $words = $ngrams{$ng} || 1;
        my $weight_score = GenstatWeightScore($genstat_score->{$ng}, $words);

        $score += $weight_score;
        $rewarded{"g:$ng"} = 1;
    }

    # Kategoria saa pienen lisän, jos se on järkevä eikä yleinen tekninen hakemisto.
    if (defined $category && $category ne '') {
        my $cat = NormalizeTerm($category);
        if ($cat ne '' && $cat !~ /^(www|images|img|thumb|thumbs)$/) {
            $score += $CATEGORY_BONUS;

            if (exists $genstat_score->{$cat}) {
                $score += GenstatWeightScore($genstat_score->{$cat}, 1);
            }
        }
    }

    # Tuore kuva saa pienen lisän, hyvin vanha pienen miinuksen.
    if (defined $age && $age =~ /^\d+$/) {
        if ($age < 7 * 24 * 3600) {
            $score += $FRESH_IMAGE_BONUS;
        }
        elsif ($age > 365 * 24 * 3600) {
            $score -= $OLD_IMAGE_PENALTY;
        }
    }

    $score = 0 if ($score < 0);

    return int($score);
}

################################################################################
# Pudota ja luo taulu score-kentällä.
################################################################################

sub RecreateImageListTable
{
    my $sth;

    die "MakeImageList.pl: database handle missing\n" if (!$gl_dbh);

    $sth = $gl_dbh->prepare(q{
DROP TABLE IF EXISTS `vunet`.`imagelist`
});
    $sth->execute() or die "DROP imagelist failed: $DBI::errstr\n";
    $sth->finish();

    $sth = $gl_dbh->prepare(q{
CREATE TABLE `vunet`.`imagelist` ( `id` bigint(20) unsigned NOT NULL auto_increment,
  `age` bigint(20) unsigned default NULL,
  `fname` TEXT,
  `category` char(30),
  `score` bigint(20) unsigned default NULL,
  PRIMARY KEY USING BTREE (`id`)
)
});
    $sth->execute() or die "CREATE imagelist failed: $DBI::errstr\n";
    $sth->finish();
}

###############################################################################
# Insertoi koko valmis lista SQL-tauluun.
#
# Lista on jo sortattu scoren mukaan, joten auto_increment-id:t seuraavat
# rankkausjärjestystä. Lisäksi score tallennetaan omaan kenttään.
################################################################################

sub InsertImageList
{
    my (@images) = @_;

    return 1 if (!@images);

    my $sth = $gl_dbh->prepare(q{
INSERT INTO `vunet`.`imagelist`
    (`age`, `fname`, `category`, `score`)
VALUES
    (?, ?, ?, ?)
});

    my $lt = time();
    my $st = time();
    my $i  = 0;

    foreach my $row (@images) {
        $i++;

        if ((time() - $lt) >= 4) {
            $lt = time();
            print STDERR (time() - $st) . ": MakeImageList.pl: $i / " . scalar(@images) . "\n";
        }

        $sth->execute(
            int($row->{age} || 0),
            $row->{fname} || '',
            $row->{category} || '',
            int($row->{score} || 0)
        ) or die "INSERT imagelist failed at row $i: $DBI::errstr\n";
    }

    $sth->finish();
    return 1;
}