#!/usr/bin/perl
#############################################################################
# addimage.pl (2026)
# Adds image to an article + admin gallery search
#
# Improved score version:
# - Uses SQL table imagelist as source of truth
# - Uses imagelist.score for best-image ordering
# - Empty search shows best scored images first
# - q search uses genstat_1w.txt to pick two best words and OR between them
# - Search relevance: category hits are boosted before filename hits
# - Hides thumbnail files whose basename starts with th_
# - Supports score display in gallery
# - Scanner reads only DOCUMENT_ROOT/www top level (maxdepth 1 equivalent)
# - Supports only *.jpg JPEG files
# - Keeps legacy Vunet article imageurl/imageurl2...imageurl9 behaviour
#
# (C) 2004-2008, 2026 by Jari Tuominen (jari@vunet.net).
#############################################################################

#use strict;
#use warnings;
use utf8;

use File::Basename qw(basename);

# Legacy project layout
require "./tools.pl";
require "./modules/sql.pm";

# DB connect (expects AltseSQLConnect() and $gl_dbh from sql.pm)
AltseSQLConnect();

# CGI vars (expects ArgLineParse() => %so in tools.pl)
our %so;
our $DONT_AFFECT_DB = 1;
ArgLineParse();

# --- Output / UTF-8 ---
print "Content-Type: text/html; charset=UTF-8\r\n\r\n";
binmode(STDOUT, ":encoding(UTF-8)");
binmode(STDERR, ":encoding(UTF-8)");
open(STDERR, ">&STDOUT");
$| = 1;

# --- Constants / defaults ---
my $IMAGES_BASE = $ENV{'IMAGES_BASE'} // "/images";
my $NEBASE      = "https://vunet.net/images";
my $THUMBDIR    = "thumb6";

# Scanner root:
# Default is Apache DOCUMENT_ROOT, which is normally the site www directory.
# Override from Apache/env if needed:
#   SetEnv WWW_SCAN_DIR /home/vai/altse/html/www
#
# Important: scanner intentionally reads ONLY this directory itself.
# It does not recurse into subdirectories; this is the Perl equivalent of:
#   find "$WWW_SCAN_DIR" -maxdepth 1 -type f -iname '*.jpg'
my $WWW_SCAN_DIR = $ENV{'WWW_SCAN_DIR'} // ($ENV{'DOCUMENT_ROOT'} // "/home/vai/altse/html/www");

# Long word scoring:
# Search/scanner gives extra points for words longer than 2 characters.
# Override if needed:
#   SetEnv LONG_WORD_POINTS_PER_CHAR 25
my $LONG_WORD_POINTS_PER_CHAR = $ENV{'LONG_WORD_POINTS_PER_CHAR'} // 25;

# Page size safety
my $DEFAULT_PAGE_SIZE = 180;
my $MAX_PAGE_SIZE     = 240;
my $PAGE_SIZE         = $DEFAULT_PAGE_SIZE;

# SQL table
my $IMAGELIST_TABLE = "`imagelist`";

# Cache table-column checks
my %COLUMN_CACHE;

# genstat_1w.txt term ranking
# Override path from Apache/env if needed:
#   SetEnv GENSTAT_1W_FILE /home/vai/altse/genstat_1w.txt
my $GENSTAT_1W_FILE = $ENV{'GENSTAT_1W_FILE'} // "genstat_1w.txt";
my %GENSTAT_1W_CACHE;
my $GENSTAT_1W_LOADED = 0;

# CGI defaults
$so{'which'} = 1 if !defined($so{'which'})
              || $so{'which'} !~ /^\d+$/
              || $so{'which'} < 1
              || $so{'which'} > 9;

$so{'page'} = 1 if !defined($so{'page'})
             || $so{'page'} !~ /^\d+$/
             || $so{'page'} < 1;

if (defined $so{'limit'} && $so{'limit'} =~ /^\d+$/) {
    $PAGE_SIZE = int($so{'limit'});
    $PAGE_SIZE = 1 if $PAGE_SIZE < 1;
    $PAGE_SIZE = $MAX_PAGE_SIZE if $PAGE_SIZE > $MAX_PAGE_SIZE;
}

# Normalize article input to "section/pub_artikkeliNNN.txt"
$so{'article'} = NormalizeArticle($so{'article'} // '');

# Legacy compatibility
$so{'IML'} //= "";

# Back link to article
my $back = MakeBackLink($so{'article'});

# Run
main();
exit 0;

#############################################################################
# URL helpers
#############################################################################

sub ImageBasename {
    my ($maybe_path_or_url) = @_;
    return "" if !defined $maybe_path_or_url || $maybe_path_or_url eq "";

    my $x = $maybe_path_or_url;
    $x =~ s/\?.*$//;
    $x =~ s/\#.*$//;

    # If URL, remove up to last slash
    $x =~ s/^https?:\/\/[^\/]+\/.*\///i;

    # If path, take basename
    my $bn = basename($x);

    # Safety: prevent directory traversal / strange characters
    $bn =~ s/[^\w\.\-\(\)\!\s]//g;
    $bn =~ s/\s+/_/g;

    return $bn;
}

sub IsThumbnailName {
    my ($maybe_path_or_name) = @_;

    my $bn = ImageBasename($maybe_path_or_name);
    return 0 if $bn eq "";

    return ($bn =~ /^th_/i) ? 1 : 0;
}

sub ImagePublicUrl {
    my ($maybe_path_or_url) = @_;
    my $bn = ImageBasename($maybe_path_or_url);
    return "" if $bn eq "";
    return "$NEBASE/$bn";
}

sub ImageThumbUrl {
    my ($maybe_path_or_url) = @_;
    my $bn = ImageBasename($maybe_path_or_url);
    return "" if $bn eq "";
    return "$NEBASE/$THUMBDIR/th_$bn";
}

#############################################################################
# Main
#############################################################################

sub main {
    if ($so{'article'} eq "") {
        print HtmlHeader("Virhe");
        print qq~<h2>Virhe: ARTICLE puuttuu.</h2>~;
        print HtmlFooter();
        return;
    }

    # If cmd=addimage -> set selection
    if (($so{'cmd'} // '') eq "addimage") {
        handle_addimage();
        return;
    }

    # If cmd=scanimages -> scan www directory top-level only.
    # This is intentionally manual so the gallery page does not do DB writes
    # on every admin page load.
    if (($so{'cmd'} // '') eq "scanimages") {
        handle_scanimages();
        return;
    }

    # Otherwise show UI
    print HtmlHeader("Lisää kuva artikkeliin");
    print TopBar();
    print WhichSelector();
    print Gallery();
    print HtmlFooter();
}

#############################################################################
# Add image operation
#############################################################################

sub handle_addimage {
    my $url = $so{'url'} // "";

    # Allow removing image by giving empty url
    my $clean = "";

    if ($url ne "") {
        # Do not allow choosing thumbnails directly.
        if (IsThumbnailName($url)) {
            print HtmlHeader("Virhe");
            print qq~<div class="err">Thumbnail-kuvaa ei voi asettaa artikkelikuvaksi.</div>~;
            print qq~<p><a href="addimage.pl?article=~ . UrlEscape($so{'article'}) . qq~&which=~ . int($so{'which'}) . qq~">Takaisin</a></p>~;
            print HtmlFooter();
            return;
        }

        $clean = ImagePublicUrl($url);

        # Allow only *.jpg JPEG images.
        if ($clean !~ /\.jpg$/i) {
            print HtmlHeader("Virhe");
            print qq~<div class="err">Tuntematon kuvaformaatti. Salli vain *.jpg JPEG-kuvat.</div>~;
            print qq~<p><a href="addimage.pl?article=~ . UrlEscape($so{'article'}) . qq~&which=~ . int($so{'which'}) . qq~">Takaisin</a></p>~;
            print HtmlFooter();
            return;
        }
    }

    my $key = "imageurl";
    $key = "imageurl$so{'which'}" if $so{'which'} > 1;

    $so{$key} = $clean;

    # save_iopts expects absolute article file in your system
    # legacy: "$ENV{DOCUMENT_ROOT}/articles/<article>"
    my $abs_article = "$ENV{'DOCUMENT_ROOT'}/articles/$so{'article'}";

    eval {
        save_iopts($abs_article);
    };

    if ($@) {
        print HtmlHeader("Virhe");
        print qq~<div class="err">Kuvan tallennus epäonnistui: ~ . HtmlEscape($@) . qq~</div>~;
        print qq~<p><a href="addimage.pl?article=~ . UrlEscape($so{'article'}) . qq~&which=~ . int($so{'which'}) . qq~">Takaisin</a></p>~;
        print HtmlFooter();
        return;
    }

    # Redirect back to article
    print HtmlHeader("Tallennettu");
    print qq~<div class="ok">Kuva asetettu.</div>~ if $clean ne "";
    print qq~<div class="ok">Kuva poistettu.</div>~ if $clean eq "";

    print qq~<script>location.href="/$back";</script>~;
    print qq~<meta http-equiv="refresh" content="0; url=/$back">~;
    print HtmlFooter();
}

#############################################################################
# Manual www scanner
#
# Uses opendir/readdir instead of external find. This guarantees maxdepth 1:
# only files directly inside $WWW_SCAN_DIR are accepted.
#
# Accepted:
#   /www/example.jpg
#
# Rejected:
#   /www/example.jpeg
#   /www/example.png
#   /www/thumb6/th_example.jpg
#   /www/subdir/example.jpg
#############################################################################

sub handle_scanimages {
    print HtmlHeader("Skannaa kuvat");
    print TopBar();

    my ($added, $updated, $seen, $skipped, $errors_ref) = ScanWwwJpgImages();

    print qq~<section class="panel">~;
    print qq~<h2>Skannaus valmis</h2>~;
    print qq~<div class="ok">www-skanneri kävi läpi vain hakemiston <b>~ . HtmlEscape($WWW_SCAN_DIR) . qq~</b> ylimmän tason.</div>~;
    print qq~<p>Hyväksyttyjä <b>*.jpg</b>-kuvia löytyi: <b>~ . int($seen) . qq~</b>.</p>~;
    print qq~<p>Lisätty: <b>~ . int($added) . qq~</b>, päivitetty: <b>~ . int($updated) . qq~</b>, ohitettu: <b>~ . int($skipped) . qq~</b>.</p>~;

    if ($errors_ref && @$errors_ref) {
        print qq~<div class="err"><b>Virheitä:</b><br>~;
        print join("<br>", map { HtmlEscape($_) } @$errors_ref);
        print qq~</div>~;
    }

    print qq~<p><a class="btn" href="addimage.pl?article=~ . UrlEscape($so{'article'}) . qq~&which=~ . int($so{'which'}) . qq~">Takaisin kuvagalleriaan</a></p>~;
    print qq~</section>~;

    print HtmlFooter();
}

sub ScanWwwJpgImages {
    my $dir = $WWW_SCAN_DIR;

    my $added   = 0;
    my $updated = 0;
    my $seen    = 0;
    my $skipped = 0;
    my @errors;

    if (!defined $dir || $dir eq "" || !-d $dir) {
        push @errors, "WWW_SCAN_DIR ei ole hakemisto: " . ($dir // "");
        return ($added, $updated, $seen, $skipped, \@errors);
    }

    opendir(my $dh, $dir) or do {
        push @errors, "Hakemiston avaus epäonnistui: $dir: $!";
        return ($added, $updated, $seen, $skipped, \@errors);
    };

    while (my $entry = readdir($dh)) {
        next if $entry eq "." || $entry eq "..";

        my $full = "$dir/$entry";

        # maxdepth 1: never recurse. Directories are skipped.
        if (!-f $full) {
            $skipped++;
            next;
        }

        my $bn = ImageBasename($entry);

        if ($bn eq "" || IsThumbnailName($bn) || $bn !~ /\.jpg$/i) {
            $skipped++;
            next;
        }

        $seen++;

        my $age = 0;
        my @st = stat($full);
        if (@st) {
            my $mtime = $st[9] || time();
            $age = time() - $mtime;
            $age = 0 if $age < 0;
        }

        my $score = ScoreImageFilename($bn);

        my ($was_added, $was_updated, $err) = UpsertImagelistJpg(
            fname    => $bn,
            category => "",
            age      => $age,
            score    => $score,
        );

        if ($err ne "") {
            push @errors, $err;
            next;
        }

        $added++   if $was_added;
        $updated++ if $was_updated;
    }

    closedir($dh);

    return ($added, $updated, $seen, $skipped, \@errors);
}

sub ScoreImageFilename {
    my ($fname) = @_;

    $fname //= "";
    my $base = ImageBasename($fname);
    $base =~ s/\.jpg$//i;
    $base =~ tr/_\-.()/ /;
    $base =~ s/\s{2,}/ /g;

    my @words = NormalizeSearchTerms($base);
    return 0 if !@words;

    my $stats_ref = LoadGenStat1w();

    my $score = 0;

    for my $w (@words) {
        my $stat_score = exists $stats_ref->{$w} ? $stats_ref->{$w} : 0;

        # Basic point for a usable word, plus long-word specificity bonus.
        $score += 1;
        $score += WordLengthBonus($w);
        $score += int($stat_score);
    }

    return int($score);
}

sub UpsertImagelistJpg {
    my (%row) = @_;

    my $fname    = $row{fname}    // "";
    my $category = $row{category} // "";
    my $age      = int($row{age}  // 0);
    my $score    = int($row{score} // 0);

    return (0, 0, "Tyhjä fname, ei tallenneta.") if $fname eq "";
    return (0, 0, "Ei-JPG ohitettu: $fname") if $fname !~ /\.jpg$/i;

    my $has_score = ImageListHasColumn("score");
    my $has_age   = ImageListHasColumn("age");

    my $existing_id = 0;

    eval {
        my $sth = $gl_dbh->prepare("SELECT id FROM $IMAGELIST_TABLE WHERE fname=? LIMIT 1");
        $sth->execute($fname);
        ($existing_id) = $sth->fetchrow_array();
        $sth->finish();
    };

    if ($@) {
        return (0, 0, "SQL SELECT epäonnistui tiedostolle $fname: $@");
    }

    if ($existing_id) {
        my @sets = ("category=?");
        my @bind = ($category);

        if ($has_age) {
            push @sets, "age=?";
            push @bind, $age;
        }

        if ($has_score) {
            push @sets, "score=?";
            push @bind, $score;
        }

        push @bind, $existing_id;

        my $sql = "UPDATE $IMAGELIST_TABLE SET " . join(", ", @sets) . " WHERE id=?";

        eval {
            my $sth = $gl_dbh->prepare($sql);
            $sth->execute(@bind);
            $sth->finish();
        };

        if ($@) {
            return (0, 0, "SQL UPDATE epäonnistui tiedostolle $fname: $@");
        }

        return (0, 1, "");
    }

    my @cols = ("fname", "category");
    my @vals = ($fname, $category);

    if ($has_age) {
        push @cols, "age";
        push @vals, $age;
    }

    if ($has_score) {
        push @cols, "score";
        push @vals, $score;
    }

    my $placeholders = join(",", map { "?" } @cols);
    my $sql = "INSERT INTO $IMAGELIST_TABLE (" . join(",", @cols) . ") VALUES ($placeholders)";

    eval {
        my $sth = $gl_dbh->prepare($sql);
        $sth->execute(@vals);
        $sth->finish();
    };

    if ($@) {
        return (0, 0, "SQL INSERT epäonnistui tiedostolle $fname: $@");
    }

    return (1, 0, "");
}

#############################################################################
# Gallery UI
#############################################################################

sub Gallery {
    my $requested_page = int($so{'page'} // 1);
    $requested_page = 1 if $requested_page < 1;

    my ($rows_ref, $total, $pages, $page) = SearchImages(
        q     => ($so{'q'} // ""),
        group => ($so{'group'} // ""),
        page  => $requested_page,
        limit => $PAGE_SIZE,
    );

    $pages = 1 if !$pages || $pages < 1;
    $page  = 1 if !$page  || $page  < 1;

    my $q_esc = HtmlEscape($so{'q'} // "");
    my $g_esc = HtmlEscape($so{'group'} // "");

    my @info_terms = NormalizeSearchTerms($so{'q'} // "");
    my ($info_primary_ref, $info_secondary_ref) = BuildPrioritySearchTerms(\@info_terms, 2);
    my $search_plan_html = SearchPlanHtml($info_primary_ref, $info_secondary_ref);

    my $prev_link = ($page > 1)
        ? BuildLink(page => $page - 1)
        : "";

    my $next_link = ($page < $pages)
        ? BuildLink(page => $page + 1)
        : "";

    my $count_txt = int($total || 0);

    my $html = qq~
<section class="panel">
  <div class="panelhead">
    <div>
      <h2>Kuvagalleria</h2>
      <div class="sub">Sivu $page / $pages ($count_txt kuvaa) — parhaat score-kuvat ensin, thumbnailit piilotettu</div>
    </div>
    <div class="nav">
      ~ . ($prev_link ? qq~<a class="btn" href="$prev_link">← Edellinen</a>~ : qq~<span class="btn disabled">← Edellinen</span>~) . qq~
      ~ . ($next_link ? qq~<a class="btn" href="$next_link">Seuraava →</a>~ : qq~<span class="btn disabled">Seuraava →</span>~) . qq~
    </div>
  </div>

  <form class="search" method="get" action="addimage.pl">
    <input type="hidden" name="article" value="~ . HtmlEscape($so{'article'}) . qq~">
    <input type="hidden" name="which" value="~ . int($so{'which'}) . qq~">

    <input class="in" type="text" name="q" value="$q_esc" placeholder="Hae esim: tekoäly Kiina siru">
    <input class="in" type="text" name="group" value="$g_esc" placeholder="Ryhmä / category, esim: talous">

    <button class="btn" type="submit">Hae</button>
    <a class="btn" href="addimage.pl?article=~ . UrlEscape($so{'article'}) . qq~&which=~ . int($so{'which'}) . qq~">Tyhjennä</a>
    <a class="btn" href="addimage.pl?article=~ . UrlEscape($so{'article'}) . qq~&which=~ . int($so{'which'}) . qq~&cmd=scanimages">Skannaa www/*.jpg</a>
  </form>
  $search_plan_html
~;

    if (!$rows_ref || !@$rows_ref) {
        $html .= qq~<div class="empty">Ei tuloksia tällä haulla.</div>~;
        $html .= qq~</section>~;
        return $html;
    }

    $html .= qq~<div class="grid">~;

    for my $r (@$rows_ref) {
        my ($id, $fname, $category, $score, $age, $qscore) = @$r;

        my $bn = ImageBasename($fname);

        # Extra safety: do not show thumbnails or non-JPG files even if SQL table contains them.
        next if $bn eq "";
        next if IsThumbnailName($bn);
        next if $bn !~ /\.jpg$/i;

        my $puburl = ImagePublicUrl($fname);
        my $thumb  = ImageThumbUrl($fname);

        my $set_link = "addimage.pl?article=" . UrlEscape($so{'article'})
                     . "&which=" . int($so{'which'})
                     . "&cmd=addimage"
                     . "&url=" . UrlEscape($puburl);

        my $cap = $bn;
        $cap =~ s/^(.{28}).*$/$1.../ if length($cap) > 31;

        my $cat = $category // "";
        $cat = "" if $cat eq "0";
        $cat = HtmlEscape($cat);

        my $score_show = defined($score) ? int($score) : 0;
        my $qscore_show = defined($qscore) ? int($qscore) : 0;

        my $score_html = qq~<span class="score">score $score_show</span>~;
        if ($qscore_show > 0) {
            $score_html .= qq~ <span class="score qscore">haku +$qscore_show</span>~;
        }

        $html .= qq~
  <div class="card">
    <a class="thumb" href="$set_link" title="Valitse kuva">
      <img src="$thumb" alt="">
    </a>
    <div class="meta">
      <div class="fn" title="~ . HtmlEscape($bn) . qq~">~ . HtmlEscape($cap) . qq~</div>
      <div class="cat">~ . ($cat ne "" ? $cat : "&nbsp;") . qq~</div>
      <div class="scoreline">$score_html</div>
      <div class="actions">
        <a class="lnk" href="$puburl" target="_blank" rel="noopener">avaa</a>
        <a class="lnk" href="javascript:void(0)" onclick="window.open('/cgi/admin/editimage.pl?i=~ . UrlEscape($bn) . qq~','Edit','width=900,height=650')">muokkaa</a>
      </div>
    </div>
  </div>
~;
    }

    $html .= qq~</div></section>~;
    return $html;
}

#############################################################################
# SQL search
#
# Important:
# - Empty query: show all non-thumbnail images ordered by score DESC.
# - Non-empty query: terms match with OR, but primary q words rank first.
# - Thumbnail files are hidden:
#       fname NOT LIKE 'th_%'
#       fname NOT LIKE '%/th_%'
# - Search ordering:
#       primary-q hits first,
#       supplemental-q hits below them,
#       category hits before filename hits,
#       imagelist.score DESC,
#       age ASC,
#       id ASC
#
# Actual long-term ranking still comes from imagelist.score inside each tier.
#############################################################################

sub SearchImages {
    my (%opt) = @_;

    my $q     = $opt{q}     // "";
    my $group = $opt{group} // "";
    my $page  = int($opt{page}  // 1);
    my $limit = int($opt{limit} // $PAGE_SIZE);

    $page  = 1 if $page < 1;
    $limit = 1 if $limit < 1;
    $limit = $MAX_PAGE_SIZE if $limit > $MAX_PAGE_SIZE;

    # q-parametrista tehdään usean prioriteetin haku:
    #   1) genstat_1w.txt:n mukaan kaksi tärkeintä sanaa = päähaku
    #   2) loput sanat = täydentävä haku, joka järjestetään alemmaksi
    # SQL hakee kaikki termit OR-logiikalla, mutta ORDER BY pitää
    # päähakusanat aina täydentävien sanojen yläpuolella.
    my @raw_terms = NormalizeSearchTerms($q);
    my ($primary_terms_ref, $secondary_terms_ref) = BuildPrioritySearchTerms(\@raw_terms, 2);
    my @terms = (@$primary_terms_ref, @$secondary_terms_ref);

    $group = NormalizeGroup($group);

    my ($where_sql, $where_bind_ref) = BuildWhereSql($group, @terms);

    my $total = CountImages($where_sql, @$where_bind_ref);

    my $pages = $total > 0 ? int(($total + $limit - 1) / $limit) : 1;
    $pages = 1 if $pages < 1;

    $page = $pages if $page > $pages;

    my $offset = ($page - 1) * $limit;

    my ($order_sql, $order_bind_ref) = BuildOrderSql($primary_terms_ref, $secondary_terms_ref);

    my $has_score = ImageListHasColumn("score");
    my $has_age   = ImageListHasColumn("age");

    my $score_select = $has_score ? "COALESCE(score,0) AS score" : "0 AS score";
    my $age_select  = $has_age   ? "COALESCE(age,0) AS age"     : "0 AS age";

    my $qscore_select = BuildQScoreSql(@terms);

    my $sql = qq{
SELECT
    id,
    fname,
    category,
    $score_select,
    $age_select,
    $qscore_select AS qscore
FROM $IMAGELIST_TABLE
$where_sql
$order_sql
LIMIT ? OFFSET ?
};

    my @rows;

    eval {
        my $sth = $gl_dbh->prepare($sql);
        $sth->execute(@$where_bind_ref, @$order_bind_ref, $limit, $offset);

        while (my @r = $sth->fetchrow_array()) {
            push @rows, \@r;
        }

        $sth->finish();
    };

    if ($@) {
        print qq~<div class="err">SQL-haku epäonnistui: ~ . HtmlEscape($@) . qq~</div>~;
    }

    return (\@rows, int($total || 0), int($pages), int($page));
}

#############################################################################
# Normalize search terms
#############################################################################

sub NormalizeSearchTerms {
    my ($q) = @_;

    $q //= "";

    # Allow q=cola+fanta+sprite
    $q =~ tr/+/\ /;
    $q =~ s/^\s+|\s+$//g;
    $q =~ s/\s{2,}/ /g;

    return () if $q eq "";

    my @terms = split(/\s+/, $q);

    for (@terms) {
        s/[^\p{L}\p{N}\-_]//g;
        $_ = lc($_);
    }

    @terms = grep {
        defined $_
        && $_ ne ""
        && length($_) >= 2
    } @terms;

    # Remove duplicates while preserving order
    my %seen;
    @terms = grep { !$seen{$_}++ } @terms;

    return @terms;
}

#############################################################################
# Word length bonus
#
# Very short words often produce noisy image matches. Words longer than two
# characters get extra points both in q-term priority and SQL ordering.
#############################################################################

sub WordLengthBonus {
    my ($word) = @_;

    $word //= "";
    my $len = length($word);

    return 0 if $len <= 2;

    my $per_char = int($LONG_WORD_POINTS_PER_CHAR || 25);
    $per_char = 1 if $per_char < 1;

    return ($len - 2) * $per_char;
}

#############################################################################
# Build q word priority tiers using genstat_1w.txt
#
# Purpose:
#   If q contains many words, do not throw weaker words away.
#   Instead, split the query into search priority tiers:
#
#     primary terms:      two highest-value words according to genstat_1w.txt
#     supplemental terms: the remaining words, still searched, but ranked lower
#
# Example:
#   q = "cola pizza juoma uutinen"
#   genstat ranks cola and pizza highest
#   SQL WHERE searches: cola OR pizza OR juoma OR uutinen
#   SQL ORDER BY shows: cola/pizza hits first, juoma/uutinen hits below them
#
# Robust genstat parser supports common formats:
#   cola 123
#   cola=123
#   cola:123
#   123 cola
#############################################################################

sub BuildPrioritySearchTerms {
    my ($terms_ref, $primary_max) = @_;

    $terms_ref //= [];
    $primary_max = 2 if !$primary_max || $primary_max < 1;

    my @terms = @$terms_ref;
    return ([], []) if !@terms;

    my $stats_ref = LoadGenStat1w();

    my @ranked;
    my $pos = 0;

    for my $t (@terms) {
        next if !defined $t || $t eq "";

        # Unknown words are not discarded; they get score 0 and remain usable.
        # If all words are unknown, original q order decides the priority.
        my $stat_score = exists $stats_ref->{$t} ? $stats_ref->{$t} : 0;

        # Longer words are usually more specific than very short words.
        # Give extra ranking points for characters after the first two.
        $stat_score += WordLengthBonus($t);

        push @ranked, [ $t, $stat_score, $pos++ ];
    }

    @ranked = sort {
        $b->[1] <=> $a->[1]     # higher genstat score first
        || $a->[2] <=> $b->[2]  # stable fallback: original q order
    } @ranked;

    my @primary;
    my @secondary;

    for my $i (0 .. $#ranked) {
        if ($i < $primary_max) {
            push @primary, $ranked[$i]->[0];
        }
        else {
            push @secondary, $ranked[$i]->[0];
        }
    }

    return (\@primary, \@secondary);
}

sub LoadGenStat1w {
    return \%GENSTAT_1W_CACHE if $GENSTAT_1W_LOADED;

    %GENSTAT_1W_CACHE = ();
    $GENSTAT_1W_LOADED = 1;

    my @candidates;
    push @candidates, $GENSTAT_1W_FILE if defined $GENSTAT_1W_FILE && $GENSTAT_1W_FILE ne "";

    if (defined $ENV{'DOCUMENT_ROOT'} && $ENV{'DOCUMENT_ROOT'} ne "") {
        push @candidates,
            "$ENV{'DOCUMENT_ROOT'}/genstat_1w.txt",
            "$ENV{'DOCUMENT_ROOT'}/../genstat_1w.txt",
            "$ENV{'DOCUMENT_ROOT'}/../data/genstat_1w.txt";
    }

    push @candidates, "./genstat_1w.txt", "../genstat_1w.txt";

    my %seen;
    @candidates = grep { defined $_ && $_ ne "" && !$seen{$_}++ } @candidates;

    my $opened = "";

    for my $fn (@candidates) {
        next if !-e $fn;

        if (open(my $fh, "<:encoding(UTF-8)", $fn)) {
            $opened = $fn;

            while (my $line = <$fh>) {
                chomp $line;
                $line =~ s/\r$//;
                $line =~ s/^\s+|\s+$//g;

                next if $line eq "";
                next if $line =~ /^#/;

                my ($word, $score);

                # word 123, word=123, word:123
                if ($line =~ /^([^\s:=;]+)\s*(?:=|:|\s)\s*(-?\d+(?:\.\d+)?)/) {
                    ($word, $score) = ($1, $2);
                }
                # 123 word
                elsif ($line =~ /^(-?\d+(?:\.\d+)?)\s+([^\s:=;]+)/) {
                    ($score, $word) = ($1, $2);
                }
                else {
                    next;
                }

                $word //= "";
                $score //= 0;

                $word =~ s/[^\p{L}\p{N}\-_]//g;
                $word = lc($word);

                next if $word eq "" || length($word) < 2;

                # If a word appears many times, keep the highest value.
                if (!exists $GENSTAT_1W_CACHE{$word} || $score > $GENSTAT_1W_CACHE{$word}) {
                    $GENSTAT_1W_CACHE{$word} = $score + 0;
                }
            }

            close($fh);
            last;
        }
    }

    return \%GENSTAT_1W_CACHE;
}

#############################################################################
# Normalize group / category
#############################################################################

sub NormalizeGroup {
    my ($group) = @_;

    $group //= "";
    $group =~ s/^\s+|\s+$//g;
    $group =~ s/[^\p{L}\p{N}\-_ ]//g;
    $group =~ s/\s{2,}/ /g;

    return $group;
}

#############################################################################
# WHERE builder
#
# OR logic for q words:
#   - thumbnail files are always excluded
#   - group must match category
#   - selected q terms are searched with OR logic
#     example: q terms cola,pizza -> (fname/category LIKE cola) OR (fname/category LIKE pizza)
#############################################################################

sub BuildWhereSql {
    my ($group, @terms) = @_;

    my @where;
    my @bind;

    # Always hide thumbnail files.
    #
    # This removes:
    #   th_image.jpg
    #   /home/vai/altse/html/www/thumb6/th_image.jpg
    #
    # It does not remove normal files like:
    #   the-image.jpg
    #   author-photo.jpg
    push @where, "((fname NOT LIKE ?) AND (fname NOT LIKE ?))";
    push @bind, "th_%", "%/th_%";

    # Accept only *.jpg JPEG files. This intentionally excludes .jpeg,
    # .png, .gif and .webp, as requested.
    push @where, "(LOWER(fname) LIKE ?)";
    push @bind, "%.jpg";

    if (defined $group && $group ne "") {
        push @where, "(category LIKE ?)";
        push @bind, "%" . $group . "%";
    }

    if (@terms) {
        my @or_terms;

        for my $t (@terms) {
            next if !defined $t || $t eq "";

            push @or_terms, "((fname LIKE ?) OR (category LIKE ?))";
            push @bind, "%" . $t . "%", "%" . $t . "%";
        }

        if (@or_terms) {
            push @where, "(" . join(" OR ", @or_terms) . ")";
        }
    }

    my $where_sql = @where ? ("WHERE " . join(" AND ", @where)) : "";

    return ($where_sql, \@bind);
}

############################################################################
# Count images
#############################################################################

sub CountImages {
    my ($where_sql, @bind) = @_;

    my $total = 0;

    my $sql = "SELECT COUNT(*) FROM $IMAGELIST_TABLE $where_sql";

    eval {
        my $sth = $gl_dbh->prepare($sql);
        $sth->execute(@bind);
        ($total) = $sth->fetchrow_array();
        $sth->finish();
    };

    if ($@) {
        print qq~<div class="err">SQL-laskenta epäonnistui: ~ . HtmlEscape($@) . qq~</div>~;
        $total = 0;
    }

    return int($total || 0);
}

#############################################################################
# qscore SQL
#
# This is selected for display only.
# Actual live qscore is used in ORDER BY by BuildOrderSql().
#############################################################################

sub BuildQScoreSql {
    my (@terms) = @_;

    return "0" if !@terms;

    # Display qscore is not mission critical; keep SELECT simple.
    # MySQL does not require us to select ORDER BY expressions.
    return "0";
}

#############################################################################
# ORDER BY builder
#
# If q terms exist:
#   category match bonus + fname match bonus first,
#   then imagelist.score,
#   then age/id.
#
# If no q:
#   imagelist.score first.
#############################################################################

sub BuildOrderSql {
    my ($primary_terms_ref, $secondary_terms_ref) = @_;

    $primary_terms_ref   //= [];
    $secondary_terms_ref //= [];

    my @primary_terms   = @$primary_terms_ref;
    my @secondary_terms = @$secondary_terms_ref;

    my @order_bind;
    my @order;

    # Tier order:
    #   2 = image matches one of the best two q words
    #   1 = image matches only supplemental q words
    #   0 = no q match; normally impossible when q WHERE is active
    # This guarantees that weaker-word results are shown below main-word results.
    my @primary_any;
    my @secondary_any;

    for my $t (@primary_terms) {
        next if !defined $t || $t eq "";
        push @primary_any, "((category LIKE ?) OR (fname LIKE ?))";
        push @order_bind, "%" . $t . "%", "%" . $t . "%";
    }

    for my $t (@secondary_terms) {
        next if !defined $t || $t eq "";
        push @secondary_any, "((category LIKE ?) OR (fname LIKE ?))";
        push @order_bind, "%" . $t . "%", "%" . $t . "%";
    }

    if (@primary_any || @secondary_any) {
        my $primary_sql   = @primary_any   ? join(" OR ", @primary_any)   : "0";
        my $secondary_sql = @secondary_any ? join(" OR ", @secondary_any) : "0";

        push @order, qq~(CASE
            WHEN ($primary_sql) THEN 2
            WHEN ($secondary_sql) THEN 1
            ELSE 0
        END) DESC~;
    }

    # Relevance inside the tier.
    # Primary terms get bigger bonuses. Supplemental terms still matter,
    # but they cannot jump above primary-tier matches because the tier sort is first.
    my @qparts;

    for my $t (@primary_terms) {
        next if !defined $t || $t eq "";

        my $len_bonus = WordLengthBonus($t);
        my $cat_weight = 100 + $len_bonus;
        my $fname_weight = 40 + int($len_bonus / 2);

        push @qparts, "(CASE WHEN category LIKE ? THEN $cat_weight ELSE 0 END)";
        push @order_bind, "%" . $t . "%";

        push @qparts, "(CASE WHEN fname LIKE ? THEN $fname_weight ELSE 0 END)";
        push @order_bind, "%" . $t . "%";
    }

    for my $t (@secondary_terms) {
        next if !defined $t || $t eq "";

        my $len_bonus = WordLengthBonus($t);
        my $cat_weight = 25 + int($len_bonus / 2);
        my $fname_weight = 10 + int($len_bonus / 3);

        push @qparts, "(CASE WHEN category LIKE ? THEN $cat_weight ELSE 0 END)";
        push @order_bind, "%" . $t . "%";

        push @qparts, "(CASE WHEN fname LIKE ? THEN $fname_weight ELSE 0 END)";
        push @order_bind, "%" . $t . "%";
    }

    if (@qparts) {
        push @order, "(" . join(" + ", @qparts) . ") DESC";
    }

    my $has_score = ImageListHasColumn("score");
    my $has_age   = ImageListHasColumn("age");

    if ($has_score) {
        push @order, "COALESCE(score,0) DESC";
    }

    if ($has_age) {
        # FileAge is usually smaller for newer files.
        push @order, "COALESCE(age,0) ASC";
    }

    push @order, "id ASC";

    my $order_sql = "ORDER BY " . join(", ", @order);

    return ($order_sql, \@order_bind);
}

#############################################################################
# Does imagelist have a given column?
#
# Useful while developing:
# If score column is missing, addimage.pl still works with old table.
#############################################################################

sub ImageListHasColumn {
    my ($col) = @_;

    $col //= "";
    return 0 if $col eq "";

    return $COLUMN_CACHE{$col} if exists $COLUMN_CACHE{$col};

    my $ok = 0;

    eval {
        my $sth = $gl_dbh->prepare("SHOW COLUMNS FROM $IMAGELIST_TABLE LIKE ?");
        $sth->execute($col);

        if (my @r = $sth->fetchrow_array()) {
            $ok = 1;
        }

        $sth->finish();
    };

    $COLUMN_CACHE{$col} = $ok ? 1 : 0;
    return $COLUMN_CACHE{$col};
}

#############################################################################
# Search plan display
#############################################################################

sub SearchPlanHtml {
    my ($primary_terms_ref, $secondary_terms_ref) = @_;

    $primary_terms_ref   //= [];
    $secondary_terms_ref //= [];

    my @primary   = @$primary_terms_ref;
    my @secondary = @$secondary_terms_ref;

    return "" if !@primary && !@secondary;

    my $primary_txt = @primary
        ? join(", ", map { HtmlEscape($_) } @primary)
        : "-";

    my $secondary_txt = @secondary
        ? join(", ", map { HtmlEscape($_) } @secondary)
        : "ei muita hakusanoja";

    return qq~
  <div class="searchplan">
    <b>Päähaku:</b> $primary_txt
    <span class="sep">|</span>
    <b>Täydentävä haku alempana:</b> $secondary_txt
  </div>
~;
}

#############################################################################
# UI bits
#############################################################################

sub TopBar {
    my $art_title = ReadArticleTitle($so{'article'});
    my $art_show  = HtmlEscape($art_title);

    my $current_img = ReadCurrentImageForWhich($so{'article'}, $so{'which'});
    my $curr_pub = $current_img ? ImagePublicUrl($current_img) : "";
    my $curr_th  = $current_img ? ImageThumbUrl($current_img)  : "";

    my $preview = "";

    if ($curr_pub ne "") {
        $preview = qq~
<div class="current">
  <div class="lbl">Nykyinen kuva</div>
  <a href="$curr_pub" target="_blank" rel="noopener">
    <img src="$curr_th" alt="">
  </a>
  <div class="small">$curr_pub</div>
  <div class="small">
    <a class="lnk" href="addimage.pl?article=~ . UrlEscape($so{'article'}) . qq~&which=~ . int($so{'which'}) . qq~&cmd=addimage&url=">poista kuva</a>
  </div>
</div>
~;
    }
    else {
        $preview = qq~
<div class="current">
  <div class="lbl">Nykyinen kuva</div>
  <div class="empty">Ei asetettua kuvaa.</div>
</div>
~;
    }

    my $html = qq~
<header class="head">
  <div class="left">
    <h1>Lisää kuva artikkeliin</h1>
    <div class="art">
      <div class="small">Artikkeli</div>
      <div class="arttitle">$art_show</div>
      <div class="small"><a class="lnk" href="/$back">← takaisin artikkeliin</a></div>
    </div>
  </div>
  <div class="right">
    $preview
  </div>
</header>
~;

    return $html;
}

sub WhichSelector {
    my $html = qq~
<section class="panel">
  <h2>Kuvan paikka</h2>
  <form method="get" action="addimage.pl" class="which">
    <input type="hidden" name="article" value="~ . HtmlEscape($so{'article'}) . qq~">
    <label for="which">Valitse kuva nro:</label>
    <select id="which" name="which" onchange="this.form.submit()">
~;

    for my $i (1..9) {
        my $sel = ($i == int($so{'which'})) ? ' selected' : '';
        $html .= qq~      <option value="$i"$sel>Kuva $i</option>\n~;
    }

    $html .= qq~
    </select>
  </form>
</sction>
~;

    return $html;
}

#############################################################################
# HTML template
#############################################################################

sub HtmlHeader {
    my ($title) = @_;
    $title //= "addimage";

    return qq~<!doctype html>
<html lang="fi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>@{[ HtmlEscape($title) ]}</title>
  <style>
    :root {
      color-scheme: light;
    }

    body {
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
      background: #fff;
      color: #000;
    }

    a {
      color: #000;
    }

    .wrap {
      max-width: 1180px;
      margin: 0 auto;
      padding: 16px;
    }

    .head {
      display: flex;
      gap: 16px;
      align-items: flex-start;
      justify-content: space-between;
      border: 1px solid #ddd;
      padding: 14px;
      border-radius: 12px;
      background: #fff;
    }

    h1 {
      margin: 0 0 8px 0;
      font-size: 20px;
    }

    h2 {
      margin: 0 0 10px 0;
      font-size: 16px;
    }

    .small {
      font-size: 12px;
      color: #333;
      margin-top: 6px;
    }

    .arttitle {
      font-size: 14px;
      font-weight: bold;
      margin-top: 3px;
    }

    .panel {
      border: 1px solid #ddd;
      padding: 14px;
      border-radius: 12px;
      background: #fff;
      margin-top: 14px;
    }

    .which {
      display: flex;
      gap: 10px;
      align-items: center;
    }

    .which select {
      padding: 8px;
      border: 1px solid #bbb;
      border-radius: 8px;
      background: #fff;
      color: #000;
    }

    .search {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      align-items: center;
    }

    .searchplan {
      margin-top: 10px;
      padding: 8px 10px;
      border: 1px dashed #bbb;
      border-radius: 10px;
      background: #fff;
      font-size: 12px;
      color: #000;
    }

    .searchplan .sep {
      color: #777;
      padding: 0 8px;
    }

    .in {
      padding: 10px;
      border: 1px solid #bbb;
      border-radius: 10px;
      min-width: 240px;
      background: #fff;
      color: #000;
    }

    .btn {
      display: inline-block;
      padding: 10px 12px;
      border: 1px solid #bbb;
      border-radius: 10px;
      background: #fff;
      color: #000;
      text-decoration: none;
      cursor: pointer;
    }

    .btn:hover {
      border-color: #000;
    }

    .btn.disabled {
      opacity: .4;
      pointer-events: none;
    }

    .panelhead {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 14px;
    }

    .sub {
      font-size: 12px;
      color: #333;
      margin-top: 2px;
    }

    .nav {
      display: flex;
      gap: 8px;
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
      gap: 12px;
      margin-top: 12px;
    }

    .card {
      border: 1px solid #e0e0e0;
      border-radius: 12px;
      overflow: hidden;
      background: #fff;
    }

    .thumb {
      display: block;
      background: #f5f5f5;
      aspect-ratio: 1 / 1;
      overflow: hidden;
    }

    .thumb img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    .meta {
      padding: 10px;
    }

    .fn {
      font-size: 12px;
      font-weight: bold;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .cat {
      margin-top: 4px;
      font-size: 11px;
      color: #333;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .scoreline {
      margin-top: 7px;
      font-size: 11px;
      line-height: 1.5;
    }

    .score {
      display: inline-block;
      border: 1px solid #ccc;
      border-radius: 999px;
      padding: 2px 7px;
      background: #fafafa;
      color: #000;
      font-size: 11px;
    }

    .qscore {
      border-color: #aaa;
      background: #fff;
    }

    .actions {
      margin-top: 8px;
      display: flex;
      gap: 10px;
    }

    .lnk {
      font-size: 12px;
      text-decoration: underline;
    }

    .current img {
      width: 160px;
      height: 160px;
      object-fit: cover;
      border: 1px solid #dd;
      border-radius: 10px;
      display: block;
      background: #f5f5f5;
    }

    .lbl {
      font-size: 12px;
      font-weight: bold;
      margin-bottom: 8px;
    }

    .empty {
      padding: 10px;
      border: 1px dashed #bbb;
      border-radius: 10px;
      background: #fff;
      color: #000;
    }

    .ok {
      padding: 10px;
      border: 1px solid #2f7;
      border-radius: 10px;
      background: #fff;
      margin-top: 10px;
    }

    .err {
      padding: 10px;
      border: 1px solid #f55;
      border-radius: 10px;
      background: #fff;
      margin-top: 10px;
    }

    @media (max-width: 720px) {
      .head {
        display: block;
      }

      .right {
        margin-top: 14px;
      }

      .panelhead {
        display: block;
      }

      .nav {
        margin-top: 10px;
      }

      .in {
        min-width: 100%;
        box-sizing: border-box;
      }
    }
  </style>
</head>
<body>
<div class="wrap">
~;
}

sub HtmlFooter {
    return qq~
</div>
</body>
</html>
~;
}

#############################################################################
# Article helpers
#############################################################################

sub NormalizeArticle {
    my ($a) = @_;
    $a //= '';
    $a =~ s/\0//g;

    # If full path or url-like, extract section/pub_artikkeliNNN
    # Accept: section/pub_artikkeli123.txt
    if ($a =~ /([a-z]+)\/pub_artikkeli([0-9]+)\.txt/i) {
        return lc($1) . "/pub_artikkeli" . $2 . ".txt";
    }

    # Accept: section/pub_artikkeli123.html
    if ($a =~ /([a-z]+)\/pub_artikkeli([0-9]+)\.(html|htm)/i) {
        return lc($1) . "/pub_artikkeli" . $2 . ".txt";
    }

    # Accept: section/story-123.html
    if ($a =~ /([a-z]+)\/story\-([0-9]+)\.html/i) {
        return lc($1) . "/pub_artikkeli" . $2 . ".txt";
    }

    # Fallback sanitize
    $a =~ s/[^a-zA-Z0-9_\/\.\-]//g;
    return $a;
}

sub MakeBackLink {
    my ($article_rel) = @_;
    return "" if !$article_rel;

    my $x = $article_rel;
    $x =~ s/^\///g;

    return "viewarticle/?article=$x";
}

sub ReadArticleTitle {
    my ($article_rel) = @_;

    return "" if !$article_rel;

    my $fn = "$ENV{'DOCUMENT_ROOT'}/articles/$article_rel";
    return "" if !-e $fn;

    my @lst = LoadList($fn);
    return "" if !@lst;

    my $cap = $lst[0] // "";
    $cap =~ s/<[^>]*>//g;
    $cap =~ s/^\s+|\s+$//g;
    $cap =~ s/\s{2,}/ /g;

    return $cap;
}

sub ReadCurrentImageForWhich {
    my ($article_rel, $which) = @_;

    return "" if !$article_rel;

    my $opt = "$ENV{'DOCUMENT_ROOT'}/articles/$article_rel" . "_options.txt";
    return "" if !-e $opt;

    open(my $fh, "<:encoding(UTF-8)", $opt) or return "";

    my %tmp;

    while (my $line = <$fh>) {
        chomp $line;
        next if $line =~ /^\s*$/;

        my ($k, $v) = split(/\=/, $line, 2);
        next if !defined $k;

        $v //= "";
        $tmp{$k} = $v;
    }

    close($fh);

    my $key = "imageurl";
    $key = "imageurl$which" if $which && $which > 1;

    return $tmp{$key} // "";
}

#############################################################################
# Utils
#############################################################################

sub HtmlEscape {
    my ($s) = @_;

    $s //= '';
    $s =~ s/&/&amp;/g;
    $s =~ s/</&lt;/g;
    $s =~ s/>/&gt;/g;
    $s =~ s/"/&uot;/g;
    $s =~ s/'/&#39;/g;

    return $s;
}

sub UrlEscape {
    my ($s) = @_;

    $s //= '';
    $s =~ s/([^A-Za-z0-9\-_.~])/sprintf("%%%02X", ord($1))/ge;

    return $s;
}

sub BuildLink {
    my (%p) = @_;

    my $page = int($p{page} // 1);
    $page = 1 if $page < 1;

    my $u = "addimage.pl?article=" . UrlEscape($so{'article'})
          . "&which=" . int($so{'which'})
          . "&page="  . $page;

    $u .= "&q=" . UrlEscape($so{'q'} // "")
        if defined $so{'q'} && $so{'q'} ne "";

    $u .= "&group=" . UrlEscape($so{'group'} // "")
        if defined $so{'group'} && $so{'group'} ne "";

    $u .= "&limit=" . int($PAGE_SIZE)
        if $PAGE_SIZE != $DEFAULT_PAGE_SIZE;

    return $u;
}