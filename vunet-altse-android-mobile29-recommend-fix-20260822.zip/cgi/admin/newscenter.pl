#!/usr/bin/perl
use utf8;
##############################################################
#
# Vunet News Center Administration Center
# Mobile / div layout revision 2026-08-22
#
##############################################################

binmode STDIN,  ':encoding(UTF-8)';
binmode STDOUT, ':encoding(UTF-8)';

print "Content-Type: text/html; charset=UTF-8\n";
print "X-Robots-Tag: noindex, nofollow\n\n";

# Send error messages to the user, not system log.
open(STDERR,'<&STDOUT');
$| = 1;

require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";

$ENV{'CURSEC'} = "hallinto";

main();

##############################################################
sub _html
{
        my $s = defined($_[0]) ? $_[0] : "";
        $s =~ s/&/&amp;/g;
        $s =~ s/</&lt;/g;
        $s =~ s/>/&gt;/g;
        $s =~ s/\"/&quot;/g;
        $s =~ s/'/&#39;/g;
        return $s;
}

##############################################################
sub _cgi_file
{
        my $rel = defined($_[0]) ? $_[0] : "";
        $rel =~ s#^/+##;
        return "$NWPUB_CGIBASE/$rel" if defined($NWPUB_CGIBASE) && $NWPUB_CGIBASE ne "";
        return "$ENV{'DOCUMENT_ROOT'}/cgi/$rel";
}

##############################################################
sub CountSectionArticles
{
        my $section = defined($_[0]) ? $_[0] : "";
        $section =~ s#[^A-Za-z0-9_.-]##g;
        return 0 if $section eq "";

        my $fn = _cgi_file("$section/fileindex.txt");
        return 0 if !open(my $fh, "<", $fn);
        my @ind = <$fh>;
        close($fh);
        return scalar(@ind);
}

##############################################################
sub SeeSections
{
        my $fn = _cgi_file("sections.txt");
        return if !open(my $fh, "<", $fn);
        @sec = <$fh>;
        close($fh);
        chomp @sec;

        # Section counts were historically disabled here. Keep the data load
        # for compatibility without printing a large legacy list.
}

##############################################################
sub FigureOutUserCount
{
        my $fn = _cgi_file("visitors.log");
        return 0 if !open(my $fh, "<", $fn);

        my %seen;
        while(my $line = <$fh>)
        {
                chomp $line;
                next if $line eq "";
                $seen{$line} = 1;
        }
        close($fh);
        return scalar(keys %seen);
}

##############################################################
sub ViewActionsScript
{
        my @items = (
                ["Julkaise", "/publish/"],
                ["Portaalin mainokset", "/cgi/admin/ads.pl"],
                ["Äänestyspalvelu", "/cgi/admin/polladm.pl"],
                ["Mitä klikataan?", "/clickmon.pl"],
                ["Mitä luetaan tänään JUURI NYT?", "/cgi/admin/logview.pl"],
                ["Ulkomaalaiset lukijat", "/cgi/admin/logview.pl?MAGIC=32785782378523758&SEARCH=&site=%5C.%5B%5Ef%5D%5B%5Ei%5D%24&section=&depth=40&ignore_unknown=false"],
                ["Mistä lukijat VIRTAAVAT?", "/cgi/admin/referers.pl"],
                ["Päivän LUETUIMMAT", "/chart.pl?TLI=86400&ILMAN=ei&MAGIC=32785782378523758"],
                ["KOMMENTTIEN HALLINTA", "/com.pl"],
                ["Päivitä thumbnailit", "/thumbupd.pl"],
                ["Päivitä etusivu", "/cgi/admin/update.pl?pass=&stop=1"],
                ["Päivitä kaikki", "/cgi/admin/update.pl?pass=&stop="],
                ["TV.Vunet.Org Hallinto", "/cgi/admin/tvadmin.pl"],
                ["Automaattinen uutisten postitus", "/cgi/admin/mailinglist.pl"],
                ["Dada Mail-postituslista", "/~vai/cgi/dada/mail.cgi"],
                ["Top 100", "/TopTen.pl"],
                ["Kävijätilastot", "https://public.vunet.net/web"],
                ["Ilmoitusten hallinto (USENET)", "/cgi/admin/admpostnews.pl"],
                ["Vunetin sähköpostipalvelu", "/mail/"],
        );

        print qq{<div class="vn-admin-action-list" role="list">\n};
        for my $item (@items)
        {
                print qq{<a class="vn-admin-action" role="listitem" href="} . _html($item->[1]) . qq{">};
                print qq{<span class="vn-admin-action__arrow" aria-hidden="true">&rsaquo;</span>};
                print qq{<span class="vn-admin-action__label">} . _html($item->[0]) . qq{</span></a>\n};
        }
        print qq{</div>\n};
}

##############################################################
sub ContentEditOptions
{
        my @items = (
                ["edit WEBINDEX.HTML template", "/admin/editart.pl?FILE=$ENV{'DOCUMENT_ROOT'}/articles/cfg/webindex.html&CAPTION=Edit%20text%20file&RETURL=/cgi/admin/newscenter.pl"],
                ["edit site CSS", "/admin/editart.pl?FILE=$ENV{'DOCUMENT_ROOT'}/articles/cfg/uutiset.css&CAPTION=Edit%20text%20file&RETURL=/cgi/admin/newscenter.pl"],
                ["edit ENGLISH EDITION front page text", "/admin/editart.pl?FILE=$ENV{'DOCUMENT_ROOT'}/articles/cfg/english_captext.txt&CAPTION=Edit%20text%20file&RETURL=/cgi/admin/newscenter.pl"],
                ["edit FINNISH EDITION front page text", "/admin/editart.pl?FILE=$ENV{'DOCUMENT_ROOT'}/articles/cfg/finnish_captext.txt&CAPTION=Edit%20text%20file&RETURL=/cgi/admin/newscenter.pl"],
                ["edit no-track list", "/admin/editart.pl?FILE=$ENV{'DOCUMENT_ROOT'}/articles/cfg/notracking.txt&CAPTION=Edit%20no-track%20list&RETURL=/cgi/admin/newscenter.pl"],
                ["edit hot symbols list", "/admin/editart.pl?FILE=$ENV{'DOCUMENT_ROOT'}/articles/cfg/pub_artikkeli_symbols.txt&CAPTION=Hot%20symbols&RETURL=/cgi/admin/newscenter.pl"],
        );

        print qq{<div class="vn-admin-action-list">};
        for my $item (@items)
        {
                print qq{<a class="vn-admin-action" href="} . _html($item->[1]) . qq{"><span class="vn-admin-action__arrow">&rsaquo;</span><span class="vn-admin-action__label">} . _html($item->[0]) . qq{</span></a>};
        }
        print qq{</div>};
}

##############################################################
sub AdministrationCenter
{
        if(defined($firstname) && $firstname ne "")
        {
                print qq{<p class="vn-admin-welcome">Tervetuloa hallintokeskukseen, } . _html($firstname) . qq{.</p>\n};
        }

        if($VIEW_USER_COUNT)
        {
                ViewUserCount();
        }

        ViewActionsScript(_cgi_file("admin/admin.txt"));
        SeeSections();
}

##############################################################
sub ViewUserCount
{
        my $usercount = FigureOutUserCount();
        print qq{<p class="vn-admin-stat"><strong>} . int($usercount) . qq{</strong> eri kävijää tähän mennessä (ei kata kävijöitä, jotka eivät käyttäneet cookieta/JavaScriptia tukevaa selainta).</p>\n};
}

##############################################################
sub ViewMailingListSettings
{
        my $fn = _cgi_file("mail.lst");
        return if !open(my $fh, "<", $fn);
        my @lst = <$fh>;
        close($fh);
        chomp @lst;

        print qq{<section class="vn-admin-card"><h2>Vaihtoehtouutiset-postituslista</h2><ul class="vn-admin-mail-list">};
        for my $address (@lst)
        {
                next if $address eq "";
                print qq{<li>} . _html($address) . qq{</li>};
        }
        print qq{</ul></section>};
}

##############################################################
sub Tools
{
        my @items = (
                ["publish a new article", "/publish"],
                ["mailing lists", "https://lista.vunet.net/"],
                ["what are readers reading right now?", "/admin/logview.pl?MAGIC=32785782378523758"],
                ["visitor statistics", "/awstats/awstats.pl?config=vunet.net"],
        );

        print qq{<div class="vn-admin-action-list">};
        for my $item (@items)
        {
                print qq{<a class="vn-admin-action" href="} . _html($item->[1]) . qq{"><span class="vn-admin-action__arrow">&rsaquo;</span><span class="vn-admin-action__label">} . _html($item->[0]) . qq{</span></a>};
        }
        print qq{</div>};
}

##############################################################
sub Redirection
{
        my $url = defined($_[0]) ? $_[0] : "/cgi/admin/newscenter.pl";
        print qq{<meta http-equiv="refresh" content="0;url=} . _html($url) . qq{">};
}

##############################################################
sub UserEditor
{
        my $remote_user = _html($ENV{'REMOTE_USER'});
        my $fname = _html($so{'USR_FNAME'});
        my $lname = _html($so{'USR_LNAME'});
        my $email = _html($so{'USR_EMAIL'});

        print qq{
<section class="vn-admin-user-editor">
  <div class="vn-admin-user-id"><span>Käyttäjä</span><strong>$remote_user</strong></div>
  <form action="/cgi/admin/newscenter.pl" method="get" class="vn-admin-form">
    <label class="vn-admin-field"><span>Etunimi</span><input type="text" name="USR_FNAME" value="$fname" autocomplete="given-name"></label>
    <label class="vn-admin-field"><span>Sukunimi</span><input type="text" name="USR_LNAME" value="$lname" autocomplete="family-name"></label>
    <label class="vn-admin-field"><span>Sähköposti</span><input type="email" name="USR_EMAIL" value="$email" autocomplete="email" inputmode="email"></label>
    <div class="vn-admin-form-actions"><button type="submit" class="vn-admin-button">Tallenna</button></div>
  </form>
</section>
};
}

##############################################################
sub main
{
        $DONT_AFFECT_DB = 1;
        ArgLineParse();

        CookieTools();
        AddAdmin();

        if($so{'redirect'})
        {
                Redirection("../_tmpjulkaisu.pl");
                exit();
        }

        my $cmd = defined($ENV{'QUERY_STRING'}) ? $ENV{'QUERY_STRING'} : "";
        $cmd =~ s/\+/ /ig;
        $cmd =~ s/%(..)/pack("C", hex($1))/eg;
        my @vars = split("&", $cmd);
        my $userid = GetUserID();

        for(my $i = 0; $i < @vars; ++$i)
        {
                my @tmp = split("=", $vars[$i], 2);
                if(defined($tmp[0]) && $tmp[0] eq "VIEW_USER_COUNT")
                {
                        $VIEW_USER_COUNT = 1;
                }
        }

        if(defined($userid) && $userid ne "")
        {
                gotUserFile($userid);
        }

        OpenWebIndex("$ENV{'DOCUMENT_ROOT'}/cgi/webindex2.html");
        WebWalkTo("CHOOSE-TITLE1");
        print "<title>Vunet News Center - hallinto</title>\n";
        SkipTo("CHOOSE-TITLE2");

        WebWalkTo("main-menu");
        print inc_menu($ENV{'CURSEC'}, $so{'FP_SECTION'});
        WebWalkTo("ENTERHERE_SECTION");

        print qq{
<script>
AdminRegistration(1);
function AdminRegistration(days)
{
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        setCookie("vunetadmin", "true", date.toGMTString(), "/", "");
}
</script>
<section class="vn-admin-center vn-page-width" aria-labelledby="vn-admin-title">
  <header class="vn-admin-header">
    <img class="vn-admin-logo" src="$IMAGES_BASE/hallinto4.jpg" alt="Hallinto">
    <div class="vn-admin-heading">
      <span class="vn-admin-kicker">Vunet.net</span>
      <h1 id="vn-admin-title">News Center</h1>
      <p>Uutisportaalin hallinta ja ylläpitotyökalut.</p>
    </div>
  </header>
  <div class="vn-admin-grid">
    <section class="vn-admin-card vn-admin-card--actions" aria-labelledby="vn-admin-actions-title">
      <h2 id="vn-admin-actions-title">Hallintokeskus</h2>
};

        AdministrationCenter();

        print qq{
    </section>
    <section class="vn-admin-card vn-admin-card--user" aria-labelledby="vn-admin-user-title">
      <h2 id="vn-admin-user-title">Käyttäjätiedot</h2>
};

        UserEditor();

        print qq{
    </section>
  </div>
</section>
};

        WebWalkTo("ALAPALKKITAHAN");
        EndBar();
        HandleRest();
}
