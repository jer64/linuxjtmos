#!/bin/bash
echo "12: Updating sexy cached page.";
lynx -source "https://vunet.net/nw.pl?q=strip alasto christina vibr seksi tissi alasti jessica galleria kuvia alba aasialaisia naisia porn takamuk takamus perse pylly masturb huor ilotyt&maxts=200&section=kummalliset&rs=seksi&FP_SECTION=finnish" \
> /home/vai/altse/html/cache/index-seksi.html
                                            
