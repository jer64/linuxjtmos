#!/bin/bash
lynx -source https://vunet.net/userfavs/ > /home/vai/altse/html/cache/userfavs.js
lynx -source "https://vunet.net/jstopten/?c=100&Dt=Suosituimmat_Kummalliset&q=&s=kummalliset" > /home/vai/altse/html/cache/top_kummalliset.js
lynx -source "https://vunet.net/jstopten/?c=100&t=Popular_Videos&s=videos&n=" > /home/vai/altse/html/cache/top_videos.js
lynx -source "https://vunet.net/jstopten/?c=100&t=Popular_Articles&s=picks&n=" > /home/vai/altse/html/cache/top_picks.js
lynx -source "https://vunet.net/jstopten/?c=100&t=Popular_Progressive_Articles&s=progressive&n=" > /home/vai/altse/html/cache/top_progressive.js
lynx -source "https://vunet.net/jstopten/?c=100&t=Popular_Bush_Articles&s=bush&n=" > /home/vai/altse/html/cache/top_bush.js
