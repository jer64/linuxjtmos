#!/usr/bin/perl
use utf8;
##########################################################################
#
# WEB CHANNEL BROADCAST
#
##########################################################################

#
require "admin.pl";

# Load configuration & parse args.
ArgLineParse();

#
$ENV{'CURSEC'} = "webchannel";

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
OpenWebIndex("./index1.html");
WebWalkTo("enterhere_section");
main();
HandleRest();


################################################################
# Load & Parse Log !
#
sub LoadLog
{
	my @log,$i,$i2,$i3,$i4,
		$str,$str2,$str3,$str4;

	#
	@log = LoadList($_[0]);

	#
	for($i=0; $i<($#log+1); $i++)	
	{
		$log[$i] =~ s/<br>//g;
		$str2 = $log[$i];
		$str2 =~ s/(.*)(')(.*)(')(.*)/$3/i;
		$str2 =~ s/ /_/g;
		$str = $log[$i];
		$str =~ s/(.*)(')(.*)(')(.*)/$1/i;
		$log[$i] = "$str $str2";
	}

	#
	return @log;
}

################################################################
sub TableBeg
{
	#
	print("
		<center>
		<table width=\"780\"
			cellspacing=0 cellpadding=0
			background=\"../uutiset/wec/wec.jpg\">
		<tr>
		<td>
		");
}

################################################################
sub TableEnd
{
	#
	print("
		</td>
		</tr>
		</table>
		</center>
		");
}

################################################################
sub Logo
{
	print("
		<center>
		<img src=\"../uutiset/wec/logo.gif\">
		</center>
		");
}

################################################################
sub Spaces
{
	my $i,$i2,$i3,$i4;

	#
	for($i=0; $i<$_[0]; $i++) { print "<br>\n"; }	
}

################################################################
sub Music
{
	#
	print("
		<embed src=\"https://www.saunalahti.fi/takape6/music/music1.wav\"
			width=\"0\" height=\"0\" autostart=\"true\" loop=\"true\">
		");
}

################################################################
sub Frame
{
	#
	print("
<center>
<IFRAME SRC=\"newswire.pl?plainoutfit=true\" WIDTH=756 HEIGHT=400 ID=\"iframe1\">
Your browser does not support this page.
</IFRAME>
</center>
		");
}

################################################################
sub ActionMenu
{
	my $i,$i2,$i3,$i4;

	#######################################################
	#
	print("	

		<script language=\"javascript\">
		function GoHere(where)
		{
			o = document.getElementById('iframe1');
			o.src = where;
		}

                        function ArtTab(e, w)
                        {
                                if(w==0)
                                {
                                        e.className = 'tdSelector1';
                                }
                                if(w==1)
                                {
                                        e.className = 'tdSelector2';
                                }
                        }

		function MouseOver(e, color)
		{
			e.style.backgroundColor = color;
		}
		</script>

		<br>
		<center>
		<table width=\"400\" cellspacing=0 cellpadding=4>
		<tr>
		");

	#######################################################
	#
	@wecmenu = LoadList("menulist.txt");

	#######################################################
	#
	for($i=0; $i<($#wecmenu); $i+=2)
	{
		#
		@spt = split(":", $wecmenu[$i+0]);

		#
		print("
			<td width=\"40\" class=\"tdselector1\"
				onclick=\"GoHere('$wecmenu[$i+1]');\" class=\"bright\"
				onMouseOver=\"ArtTab(this, 1);\"
				onMouseOut=\"ArtTab(this, 0);\"
						>
			<center>
			$spt[0]
			</center>
			</td>
			");

		#
		if( ($i/2 % 5)==4 )
		{
			print("
				</tr>
				<tr>
				");
		}
	}

	#######################################################
	#
	print("
		</tr>
		</table>
		</center>

		");
}

################################################################
#
# Web Channel Main
#
sub WEC
{
	my $i,$i2,$i3,$i4;

	#####################################################
	#
	Spaces(1);

	#
	ActionMenu();

	#####################################################
	print("
		<table width=\"100%\" cellpadding=0 cellspacing=0>
		<tr>

		<br>

		");
	#
	print ("
			<td style=\"vertical-align: top;\">\n
		");
	Frame();
	print "</td>\n";

	#
	print "<td width=\"1\">\n";
	Spaces(22);
	print "</td>\n";

	#
	print ("
		</tr>
		</table>
		");

	#
	Music();
}

################################################################
#
sub main
{
	my $str,$str2,$str3,$str4,
		$i,$i2,$i3,$i4;

	#
	TableBeg();
	
	#
	WEC();
	
	#
	TableEnd();
}
