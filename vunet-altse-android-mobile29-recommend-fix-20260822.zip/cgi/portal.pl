#!/usr/bin/perl
use utf8;
#
# Vunet.org portal (C) 2011 JT
#
#######################################################

#
use POSIX;
#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');

#
if($ENV{'DOCUMENT_ROOT'} eq "")
{
  $ENV{'DOCUMENT_ROOT'} = "$ENV{'HOME'}/altse/html";
}

#
require "$ENV{'DOCUMENT_ROOT'}/cgi/tools.pl";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ArticleViewerMonitor.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/NaytaUutisotsikot.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewHL.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/AnyComments.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/ViewMainArticle.pm";
require "$ENV{'DOCUMENT_ROOT'}/cgi/modules/WebPortal.pm";

#######################################################
# Search arguments line for options.
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
if($so{'q'} ne "") {
print("
<meta http-equiv=\"refresh\" content=\"0; URL=https://vunet.net/altse/?q=$so{'q'}&cmd=go\"></META>
");
exit;
}

##
if($so{'cached'} eq "1") {
	system("cat /home/vai/altse/html/cache/index-vunetportal.html");
	exit;
}

#
if($so{'to'} ne "") {
Track($so{'to'});
print("
<meta http-equiv=\"refresh\" content=\"0; URL=$so{'to'}\"></META>
");
exit;
}

#
main();

#
sub Track
{
        # Specify that only users get logged.
        if(!NoTracking())
        {
                #
                open($f, ">>logs/redir.log") || die "<a href=\"$_[0]\">Error while redirecting. Click here manually ...</a>";
                $t = time;
                $str = "$t & $ENV{'REMOTE_ADDR'} & $ENV{'REMOTE_HOST'} & $_[0]\n";
                ####print $str;
                print $f $str;
                close($f);
        }
}

#
sub main
{
  #
  @web = OpenWebIndex("webportalindex.html");
  $wherebe = 0;

  #
  WebWalkTo("CHOOSE-TITLE1");
  $str = "vunet.net - uutisia ajatteleville massoille";
  $str2 = "Ajankohtainen uutisportaali.";
  $str3 = "kulta, hopea, pronssi, pörssi, pörssikauppa, kultakaivos.info, talousuutisia, bisnesuutisia maailmalta,Kominform, capitalism, kapitalismi, kapitalismi, sosiaalidemokratia, demokratia, totuus, Social democracy.";
  $str4 = "fi";

		#
	        print("
<TITLE>$str</TITLE>
<META HTTP-EQUIV=\"Content-Language\" CONTENT=\"$str4\">
<META name=\"description\" content=\"$str2\">
<META name=\"keywords\" content=\"$str3\">
<META name=\"revisit-after\" content=\"1 days\">
<META name=\"owner\" content=\"jari\@vunet.net\">
<meta name=\"author\" content=\"Jari Tuominen, Heikki Sipil&auml;\">
<meta name=\"robots\" content=\"All\">
<meta http-equiv=\"Content-Type\" content=\"text/xml; charset=UTF-8\" />
	                ");

	#
	SkipTo("CHOOSE-TITLE2");

	# TRANSPARENT TABLE
	WebWalkTo("before-uusilogo2");
	WebWalkTo("after-uusilogo2");

	#
	WebPortal();

	#
	HandleRest();
	
	#
}
