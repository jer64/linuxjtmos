#!/usr/bin/perl
use utf8;
#
# MajorPage.pl
#
##############################################################################################################

#
require "tools.pl";

#
print "Content-Type: text/html; charset=UTF-8\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
$ENV{'NW_MAJOR'} = "$so{'p'}";
if($ENV{'NW_MAJOR'} eq "Etusivu")
{
	system("./nw.pl");
	exit();
}

#
OpenWebIndex("./webindex2.html");
HandleExternal("main-menu", "./mainmenu.pl");

#
WebWalkTo("ENTERHERE_SECTION");
main();

#
WebWalkTo("ALAPALKKITAHAN");
#
print EndBar();
#
HandleRest();


#################################################################################
#
sub Editor
{
        my ($i,$i2,$i3,$i4,$str,$str2,@lst);

        #
	if(-e $_[0])
	{
	        @lst = LoadList($_[0]);
	}

        #
        print("
                <form action=\"/MajorPage.pl\" method=post>

                <input type=hidden name=save value=true>
                <input type=hidden name=p value=\"$so{'p'}\">

                <textarea name=data cols=80 rows=20>");
        loop: for($i2=$#lst; $i2>0; $i2--) { if( !($lst[$i2]=~/^\s*$/) ) { last loop; } }
        for($i=0; $i<($i2+1); $i++)
        {
                print("$lst[$i]\n");
        }
        #
        print("</textarea>
                <br>
                <input type=submit value=Save>

                </form>
                ");
}

#################################################################################
#
sub EditorActions
{
        my ($i,$i2,$i3,$i4,$str,$str2,@lst,$f);

        #
        if($so{'save'} eq "true")
        {
                #
                print("
                        $so{'q'} saved.<BR><BR>
                        ");

                #
                open($f, ">major/$so{'p'}.html");
                print $f "$so{'data'}\n";
                close($f);

		#
		print("
<meta http-equiv=\"refresh\" content=\"0; url=/$so{'p'}.major\">
			");
        }
}

###########################################################################################################
#
sub main
{
	my ($i,$i2,$str,$str2,$fn,@lst,$pureHtml);

	#
	$fn = "major/$so{'p'}.html";

	#
	if(NoTracking())
	{
		#
		EditorActions();
	}
	else
	{
	}

	#
	print("
<TABLE width=100% cellpadding=16 cellspacing=0>
<TR>
<TD>

<FONT COLOR=#C00000>
<H1>$so{'p'}</H1>
</FONT>
<TABLE width=100% height=8 cellspacing=0 cellpadding=0
	bgcolor=#000000>
<TR>
<TD>
</TD>
</TR>
</TABLE>
<BR>


		");

        #
	if(-e $fn)
	{
		#
	        @lst = LoadList($fn);
		#
		loop: for($i=0,$pureHtml=0; $i<($#lst+1); $i++)
		{
			if($lst[$i] eq "\@\@")
			{
				if(!NoTracking()) { last loop; }
				goto past;
			}
			if($lst[$i] eq "\\\\")
			{
				$pureHtml ^= 1;
				goto past;
			}
			else
			{
				print "$lst[$i]";
			}
			if(!$pureHtml) { print "<BR>\n"; }
past:
		}
	}

	#
	if( NoTracking() )
	{
		#
		print("<HR>
Hallinnon näkymä
<BR>
<BR>
");
		Editor($fn);
	}

	#
	print("
</TD>
</TR>
</TABLE>
		");

	#
}


