#!/usr/bin/perl
use utf8;
#############################################################################
# top20.pl - ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);
use DateTime;
use Time::Moment;
use Time::Piece;

#
require "./modules/AltseOpenConfig.pm";
#require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
#require "./modules/SearchSubModule.pm";
#require "./modules/DirectorySubModule.pm";
require "./modules/OpenHTMLDocument.pm";
require "./modules/AltseMenu.pm";
require "./modules/GetDBFileFromURL.pm";
require "./modules/htmlperlparse.pm";
require "./modules/BuildKeywordSuggestionsHTML.pm";
#
print "Content-Type: text/html; charset=UTF-8\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# https://www.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm

        #
        if($so{'action'} eq "like")
        {
        goto pasthmm;
        my $gzdumpfn = GetDBFileFromURL($so{'url'});
        my @art = LoadList("zcat $gzdumpfn 2>/dev/null|");
        $gzhtmlfn = $gzdumpfn;
        $gzhtmlfn =~ s/\.dump\.gz/.html.gz/;
        #print $gzhtmlfn;
        my $cap = HTML_GetPageTitle($gzhtmlfn);

$so{'q'} = $cap;
pasthmm:
}

OpenHTMLDocument();

# MENU.
#print("
#<DIV ALIGN=\"center\">
#        <iframe width=\"100%\" height=\"32\" src=\"/menu/\"
#                frameborder=\"0\"  onload=\"resizeIframe(this)\"/
#                loading=\"lazy\”>
#        </iframe>
#</DIV>
#");

# Call the main function.
#if($so{'url'} eq "" && $so{'action'} eq "")
#{
	# * Has if conditionsw on action, etc. incode.
	Like();
#}


#############################################
# THE END OF THE HTML DOCUMENT.
#############################################

#
CloseHTMLDocument();

#################################################################
#
sub Frontpage
{
	my ($i,$i2,@lst,%key);
	
	@lst = reverse LoadList("tail -n 10 cfg/likes.txt|");
	
	#
	print("

<TABLE width=\"1100\" align=\"center\">
<TR>

<TD>
");

	print("
<DIV ALIGN=\"left\"><IMG src=\"/images/thumbup.png\" align=\"left\" width=\"200\" height=\"200\">
</DIV>

<FONT face=\"Georgia\"
Social Likes
</FONT>
<BR>
<BR>
<BR>
	");

	my (%popular);

	for($i=0; $i<($#lst+1); $i++)
	{
		@sp = split(/\|/, $lst[$i]);
		$popular{$sp[0]}++;	
	}

	$i = 0;
	foreach $key (keys %popular)
	{
		$p[$i++] = sprintf "%.8d|%s", $popular{$key}, $key;
	}
	@p = sort @p;
	@p = reverse @p;

	for($i=0; $i<($#lst+1) && $i2<10; $i++)
	{
# https://mvlehti.net/2023/11/28/positvn-haastattelussa-presidenttiehdokas-paavo-vayrynen-video/|176.93.136.76||1701230333|
		@sp = split(/\|/, $p[$i]);
		
		$score = $sp[0];
		$url = $sp[1];
		
		if($key{$url} eq "")
		{

        #
        my $gzdumpfn = GetDBFileFromURL($url);
        my @art = LoadList("zcat $gzdumpfn 2>/dev/null|");
        my $gzhtmlfn = $gzdumpfn;
        $gzhtmlfn =~ s/\.dump\.gz/.html.gz/;
        #print $gzhtmlfn;
        my $cap = HTML_GetPageTitle($gzhtmlfn);
        my @images = HTML_GetPageImages($gzhtmlfn);
        $img_url = $images[0];
        #print $img_url;

        #
        $current_year_month_day = POSIX::strftime("%Y/%m/%d", localtime(time));
        $current_year_month = POSIX::strftime("%Y/%m", localtime(time));
        $current_year = POSIX::strftime("%Y", localtime(time));

        		if($cap ne "")
        		{

			print("
			<table>
			<tr>
			<td>
			".int($score)." point(s)
			</td>
			<td>
			<iframe width=\"82\" height=\"64\" src=\"/like/?url=$url&action=button\"
			  frameborder=\"0\"  onload=\"resizeIframe(this)\"
                loading=\"lazy\"/></iframe>
			</td>
			<td>
			<A HREF=\"/viewart/?url=$url\"><LI><H2>$cap</H2></LI></A><BR>
			</td>
			</tr>
			</table>
			");
			$key{$url}++;
			$i2++;
			}
		}
	}
	
	print("
</TD>
</TR>
</TABLE>
	");
}

#


#####################################################################################################
# ISTRUMP.LIFE CGI CODE.
# (C) Jari Tapio Tuominen (jari.t.tuominen@gmail.com);
sub Like
{
	if($so{'action'} eq "")
	{
	        #
	        my $HTML_MENU = AltseMenu();
	        print $HTML_MENU;
		Frontpage();
		goto past;
	}

	if($so{'action'} eq "button")
	{
		print("
		<A href=\"/like/?url=$so{'url'}&action=like\" alt=\"Like\" title=\"Like\">
                                
<IMG SRC=\"/images/thumbup.png\" width=64 height=64>
<H1 STYLE=\"COLOR: #030;\">Like</H1>
</A>
");
		goto past;
	}

        #
        open($f, ">>cfg/likes.txt");
        print $f "$so{'url'}|$ENV{'REMOTE_ADDR'}|$ENV{'REMOTE_HOST'}|".time()."|\n";
        close($f);
        
        print("
        <img src=\"/images/thankyou.jpg\" width=\"78\" height=\"64\">
        ");
        
        goto past;

        #
        my $HTML_MENU = AltseMenu();
        
        #
        my $gzdumpfn = GetDBFileFromURL($so{'url'});
        my @art = LoadList("zcat $gzdumpfn 2>/dev/null|");
        $gzhtmlfn = $gzdumpfn;
        $gzhtmlfn =~ s/\.dump\.gz/.html.gz/;
        #print $gzhtmlfn;
        my $cap = HTML_GetPageTitle($gzhtmlfn);
        my @images = HTML_GetPageImages($gzhtmlfn);
        $img_url = $images[0];
        #print $img_url;

	#
	$current_year_month_day = POSIX::strftime("%Y/%m/%d", localtime(time));
	$current_year_month = POSIX::strftime("%Y/%m", localtime(time));
	$current_year = POSIX::strftime("%Y", localtime(time));
        #
        print("
$HTML_MENU
	");
	
	#
	if($so{'d'} eq "")
	{
		$so{'d'} = "$current_year_month_day";
	}
	
	#
	open($f, ">>cfg/likes.txt");
	print $fC "$so{'url'}|$ENV{'REMOTE_ADDR'}|$ENV{'REMOTE_HOST'}|".time()."|\n";
	close($f);
	
	print("
	<img src=\"/images/thankyou.jpg\" width=\"32\" height=\"32\">
	");
	goto past;

	#
	print("

<TABLE width=\"1100\" align=\"center\">
<TR>

<TD> <DIV ALIGN=\"CENTER\"><H1>LIKED! <BR> <IMG src=\"/images/thumbup.png\" align=\"left\" width=\"200\" height=\"200\">
Thank you for liking this news article.<BR> Kiitos kun tykkäsit
uutisesta.<BR>
<A HREF=\"/like/\">Go To Likes</A></H1><BR> </DIV>

<DIV ALIGN=\"CENTER\">
<H1>
<A HREF=\"/news/\">
> Uutiset, News
</A>
</H1>
<H1>
<A HREF=\"$so{'url'}\" target=\"_blank\">
> Alkuperäinen, Original
</A>
</DIV>
<BR>
<H1>
$cap
</H1>

<!--<IMG SRC=\"$images[0]\"> --->
	");
	
	#
	my $singleword = $cap;
	$singleword =~ s/^(\S+)\s.*$/$1/;
	$singleword =~ s/[^a-zäöå0-9]/ /i;
	$singleword =~ s/\s$//g;
	$singleword = lc $singleword;
	print $singleword;
	my $html1 = BuildKeywordSuggestionsHTML($singleword,1);
	print $html1;
	my $singleword = $cap;
	$singleword =~ s/^\S+\s(\S+).*$/$1/;
	$singleword =~ s/[^a-zäöå0-9]/ /i;
	$singleword =~ s/\s$//g;
	$singleword = lc $singleword;
	print $singleword;
	my $html1 = BuildKeywordSuggestionsHTML($singleword,1);
	print $html1;
	
	if($img_url ne "")
	{
		print("
		<IMG SRC=\"$img_url\"
		                style\"width: auto !important;
  width: 100%;
  max-width: 678px;
  float: left;
  clear: both;
  \">
		");
	}
	
	#
	my ($found_cap, $printnr);
	for($i=0; $i<($#art+1) && $printnr<25; $i++)
	{
		my $cut1 = $cap;
		$cut1 =~ s/^(.{20}).*$/$1/;
		my $cut2 = $art[$i];
		$cut2 =~ s/^\s*\[[0-9]+\]\s*//;
		$cut2 =~ s/^(.{20}).*$/$1/;
		if($cut1 eq $cut2) #($art[$i] eq $cap)
		{
			$found_cap = 1;
		}
		if($found_cap)
		{
			print "<H2>$art[$i]</H2><BR>\n";
			$printnr++;
		}
	}
	if(!$found_cap)
	{
		for($i=0; $i<($#art+1) && $i<25; $i++)
		{
			print "<H2>$art[$i]</H2><BR>\n";
		}
	}
	
	print("
...<BR>
<BR>
<H1>
<A HREF=\"$so{'url'}\" target=\"_blank\">
> Lue Lisää
</A>
</H1>

</TD>
</TR>
</TABLE>
	");
past:

}


1;
