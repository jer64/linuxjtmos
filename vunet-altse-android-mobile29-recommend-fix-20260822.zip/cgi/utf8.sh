#!/bin/bash
find . -type f \( -name "*.pl" -o -name "*.pm" -o -name "*.t" \) \
  -exec sh -c '
    [ -f "$0" ] || exit
    iconv -f ISO-8859-1 -t UTF-8 "$0" -o "$0.utf8.tmp" 2>/dev/null &&
    mv "$0" "$0.bak.iso88591" &&
    mv "$0.utf8.tmp" "$0" &&
    echo "Converted: $0"
  ' {} \;