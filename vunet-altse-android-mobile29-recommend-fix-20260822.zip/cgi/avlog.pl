#!/usr/bin/perl
use utf8;
require "tools.pl";

#
@lst = GetAvlog();

#
for($i=0; $i<($#lst+1); $i++)
{
	print "$lst[$i]\n";
}

