# Vunet / Altse – Android mobile update (2026-08-21)

This package is based on `b-vunet-altse-cgi-210826.zip`. The newest source tree was kept as the authority; only UI/HTML/mobile-facing files were replaced or extended. In particular, the newer `cgi/modules/` code and 2026-08-21 `cgi/cfg/notracking.txt` remain in the tree.

## Main changes

- Responsive HTML5 shell shared by Altse and Vunet pages.
- Android-friendly viewport: `viewport-fit=cover` plus `interactive-widget=resizes-content`.
- HakuMaa-style news grid: 5 columns on wide desktop, 4/3/2 as space shrinks, and 1 column on phones (`<= 42rem`).
- Altse search results are semantic cards instead of fixed-width 500–1000 px result tables.
- Search forms scale to the viewport and use Android search keyboard hints (`inputmode=search`, `enterkeyhint=search`).
- Form controls use at least 16 px text on mobile to avoid unwanted zooming and maintain legibility.
- Main navigation is sticky, touch-friendly, horizontally scrollable, and has >=48 px-class touch targets.
- Legacy Vunet tables/images/iframes are clamped to the viewport by the modern stylesheet without changing the backend data/search logic.
- YouTube embeds and media scale down on narrow screens.
- Safe-area insets and `100dvh` support modern Android browsers and edge-to-edge layouts.
- Light/dark system theme support and reduced-motion/high-contrast fallbacks are retained.
- `webindex2.html` and `textindex2.html` use the same responsive shell, so old CGI pages using these templates also benefit.

## Files intentionally changed

- `cgi/altse.pl`
- `cgi/news.pl`
- `cgi/nw.pl`
- `cgi/webindex2.html`
- `cgi/textindex2.html`
- `cgi/qbar.html`
- `cgi/jsqbar2026.pl`
- `cgi/modules/OpenHTMLDocument.pm`
- `cgi/modules/AltseMenu.pm`
- `cgi/modules/MenuSystem.pm`
- `cgi/modules/EndBar.pm`
- `cgi/modules/CookieTools.pm`
- `www2/altse.css`
- `www2/menu.css`
- `www2/news.css`
- `www2/news.js`
- `www2/vunet.js`

## Deployment

Keep `cgi/` in the CGI tree as before. Copy `www2/` to the web root so these URLs resolve:

- `/www2/altse.css`
- `/www2/menu.css`
- `/www2/news.css`
- `/www2/news.js`
- `/www2/vunet.js`

The legacy `/images/altse.css` is still loaded first for compatibility; the new `/www2/altse.css` is loaded after it and overrides layout where needed.

## Validation performed

`perl -c` passed for:

- `altse.pl`
- `news.pl`
- `nw.pl`
- `jsqbar2026.pl`
- `modules/OpenHTMLDocument.pm`
- `modules/AltseMenu.pm`
- `modules/MenuSystem.pm`
- `modules/EndBar.pm`
- `modules/CookieTools.pm`

`node --check` passed for `www2/vunet.js` and `www2/news.js`. CSS brace-balance checks passed for all three new stylesheets.

## 2026-08-21 mobile pass 2 (nw.pl / modules)

This pass focuses on the Vunet front page and the modules loaded by `cgi/nw.pl`.

- Removed the extra white skip-link / Vunet brand header from `webindex2.html` and `textindex2.html`. The historic black quick/menu bars are now the first visible navigation UI.
- Converted all `cgi/modules/MenuSystem*.pm` menu renderers from legacy table/left-sidebar output to a full-width top navigation bar with horizontal touch scrolling.
- Converted `QuickNavMenu.pm` from a tiny table to touch-friendly links.
- Reworked `FinnishFP.pm` into a responsive main/sidebar grid; it stacks to one column on phone screens.
- Reworked `nw.pl` front-page, Tori and section wrappers to avoid fixed 650/750px layout tables.
- Added responsive hooks to `NaytaUutisotsikot.pm`, `SectionSpecificView.pm`, `ViewArticle.pm` and `ViewArticleLib.pm` and mobile hardening in `www2/altse.css`.
- Audited all 83 `cgi/modules/*.pm` files, prioritizing direct `nw.pl` dependencies and the newest modules first.

See `MODULES-MOBILE-AUDIT-20260821.txt` for the module audit and validation results.

## Mobile4 / ViewArticle hotfix (2026-08-21)

- `viewarticle.pl` uses `webindex2.html` / `textindex2.html`, matching `nw.pl`'s modern template path.
- `ifbar2.pl` is a shallow full-width horizontal news strip instead of a 210x3500 left sidebar.
- `ViewArticleLib.pm::BelowMenu()` embeds that strip at 100% width and 250px height.
- `Portaali`, `Uutiset`, `Sijoittaminen` and the other major menu labels are real `<a href>` links.
- `webindex2.html` includes the previously missing `past-uusilogo2` cursor marker.
- The `content-below-mmenu` insertion point is outside the top `<nav>`, preventing the article news strip from becoming part of the sticky menu.
- The article pipeline `viewarticle.pl -> ViewArticle.pm -> ViewArticleLib.pm -> RenderArticle.pm` was syntax checked; `ViewArticle.pm` still prints `$artcon1` returned by `RenderArticle()`.


## Mobile7 / ViewArticle max width (2026-08-21)

- `ViewArticle.pm` continues to use the responsive `.vn-article-layout` flex structure.
- The article X-axis maximum is now 1200 px, matching the Finnish front page.
- Below 1200 px the layout remains `100%` of the available width and keeps the existing mobile column breakpoint.
- The article container is centered on wider displays.
- CSS cache key updated to `mobile7`.

## Mobile9 / WordPress-inspired editorial theme (2026-08-21)

Mobile9 modernisoi Vunetin visuaalista rakennetta WordPress-tyyliseksi muuttamatta vanhoja URL-reittejä. Katso `URL-COMPATIBILITY-MOBILE9.md`.
