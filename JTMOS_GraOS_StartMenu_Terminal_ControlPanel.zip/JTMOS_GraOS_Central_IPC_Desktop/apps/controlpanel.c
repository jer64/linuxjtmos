// controlpanel.c - JTMOS GraOS Control Panel
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#ifndef JTMOS
#include <jtmos/app_port.h>
#include <limits.h>
#include <sys/types.h>
#include <unistd.h>
#endif

SYSMEMREQ(APPRAM_256K)

#define CP_TERMINAL  2001
#define CP_EDITOR    2002
#define CP_FILER     2003
#define CP_BLUE      2010
#define CP_GREEN     2011
#define CP_DARK      2012
#define CP_CLOSE     2099

static int launch_program(const char *name)
{
#ifdef JTMOS
    char cmd[160];
    snprintf(cmd,sizeof(cmd),"%s.bin",name);
    return cexec(cmd,"");
#else
    char exe[PATH_MAX],path[PATH_MAX];
    char *slash;
    ssize_t n=readlink("/proc/self/exe",exe,sizeof(exe)-1);
    pid_t p;
    path[0]=0;
    if(n>0 && (size_t)n<sizeof(exe)) {
        exe[n]=0; slash=strrchr(exe,'/');
        if(slash) { *slash=0; if(snprintf(path,sizeof(path),"%s/%s",exe,name)>=(int)sizeof(path)) path[0]=0; }
    }
    p=fork();
    if(p<0) return -1;
    if(p==0) {
        unsetenv("JTMOS_GRAOS_TERMINAL");
        unsetenv("JTMOS_GRAOS_NO_AUTO_WINDOW");
        if(path[0]) execl(path,path,(char*)NULL);
        execlp(name,name,(char*)NULL);
        _exit(127);
    }
    return (int)p;
#endif
}

static void set_desktop(int color)
{
#ifndef JTMOS
    JtmosGraOSSetDesktopColor(color);
#else
    (void)color; /* Native GraOS keeps its own desktop configuration. */
#endif
}

int main(int argc,char **argv)
{
    MSG m;
    GUICMD *cmd=(GUICMD *)m.buf;
    int wid;
    (void)argc; (void)argv;

    if(connectGraos()!=0) return 1;
    wid=createWindow(-1,-1,360,260,"JTMOS Control Panel",STANDARD_WINDOW|WINDOW_AUTOCLEAR);
    if(wid<0) return 2;

    createButton(wid,16,16,150,32,CP_TERMINAL,"Open Terminal");
    createButton(wid,190,16,150,32,CP_EDITOR,"Open Editor");
    createButton(wid,16,58,150,32,CP_FILER,"File Manager");

    createButton(wid,16,118,96,32,CP_BLUE,"Blue Desktop");
    createButton(wid,132,118,96,32,CP_GREEN,"Green Desktop");
    createButton(wid,244,118,96,32,CP_DARK,"Dark Desktop");

    createButton(wid,104,196,152,32,CP_CLOSE,"Close");
    refreshWindow(wid);

    for(;;) {
        while(receiveMessage(&m)) {
            if(cmd->id==GSID_EXIT) goto done;
            if(cmd->id!=GSID_BUTTON) continue;
            switch(cmd->v[0]) {
                case CP_TERMINAL: launch_program("terminal"); break;
                case CP_EDITOR: launch_program("edit"); break;
                case CP_FILER: launch_program("filer"); break;
                case CP_BLUE: set_desktop(BLUE); break;
                case CP_GREEN: set_desktop(GREEN); break;
                case CP_DARK: set_desktop(DARKGRAY); break;
                case CP_CLOSE: goto done;
                default: break;
            }
        }
        SwitchToThread();
        sleep(1);
    }

done:
    closeWindow(wid);
    return 0;
}
