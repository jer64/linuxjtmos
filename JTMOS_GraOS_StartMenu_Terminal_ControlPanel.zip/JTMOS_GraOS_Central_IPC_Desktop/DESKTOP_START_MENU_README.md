# JTMOS GraOS desktop: Start menu, Terminal and Control Panel

This tree extends the central Linux/SDL2 GraOS server architecture.

## Start the desktop

```sh
make
./build/bin/graos
```

The `graos` process owns the SDL2 desktop and starts `taskbar` by default.

## Start button and Start menu

The taskbar Start button now opens a GraOS popup menu over IPC. The menu contains:

- Terminal Shell
- File Manager
- Text Editor
- Task Manager
- Control Panel
- Close Menu

Applications are launched as separate processes. They connect back to the central `graos` server through the normal GraOS wrappers.

## Terminal Shell

`build/bin/terminal` creates a remote terminal with `CreateTerminal()`, attaches a `TYPE_TERMINAL_EMULATION` surface to a GraOS window, and launches `sqsh` with `bgexecEx()`. Shell output therefore goes through the terminal engine and the central GraOS compositor; the shell does not create its own SDL2 window.

## Control Panel

`build/bin/controlpanel` provides buttons for launching Terminal, Editor and File Manager. It also demonstrates a central GraOS setting by changing the desktop colour through `GRAOS_OP_SET_DESKTOP_COLOR` IPC.

## JTMOS compatibility

Linux-only process launching is inside `#ifndef JTMOS`. The JTMOS branch uses `cexec()` and `.bin` application names. Native per-application Makefiles `terminal.mak` and `controlpanel.mak` are included, and the native dispatcher also keeps `taskbar.mak` and `winshell.mak` in the GUI build path.
