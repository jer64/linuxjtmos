# CBMVM 0.3 — compact Commodore BASIC VM with BASIC 7 graphics for JTMOS

CBMVM executes tokenized Commodore BASIC directly. It is intentionally **not** a 6502 or full C64/C128 hardware emulator. The VM is small, sandboxed and designed to run as a JTMOS/GraOS process.

## Main features

- standard linked BASIC PRG loader/validator
- 64 KiB guest RAM; PEEK/POKE never become raw host pointers
- recursive-descent expression parser instead of the original multi-megabyte command queue
- cooperative `cbmvm_step()` / budgeted `cbmvm_run()`
- host callbacks for console, scheduler, virtual I/O and graphics
- BASIC V2 control flow, variables, numeric/string expressions
- BASIC 7.0 graphics and sprite command support
- packed 320x200 2-bit/source framebuffer (16,000 bytes)
- binary-safe 255-byte BASIC strings for SSHAPE/GSHAPE
- GraOS-facing JTMOS bridge that does not include GraOS headers

## BASIC V2 subset

Statements: `END`, `STOP`, assignment/`LET`, `PRINT`, `GOTO`, `IF...THEN`, `GOSUB/RETURN`, `FOR/NEXT/STEP`, `POKE`, `REM`, `CLR`, `RUN`.

Expressions: numeric/string variables and literals, concatenation, `+ - * / ^`, comparisons, `AND/OR/NOT`, parentheses, `PEEK()`, `INT()`, `ABS()`.

## BASIC 7 graphics added in 0.3

Screen/mode:

- `GRAPHIC 0..5[,clear][,split]`
- `GRAPHIC CLR`
- `RGR(x)` and optional CBMVM statement alias `RGR mode`
- `SCNCLR`

Drawing/color/shapes:

- `DRAW`, including chained `TO`
- `BOX`, including rotation and fill
- `CIRCLE` / ellipse / arc / polygon increment
- `PAINT`
- `CHAR`
- `COLOR`
- `SSHAPE` / `GSHAPE`

Sprites:

- `SPRITE`
- `MOVSPR` absolute, relative and angle/speed motion
- `SPRDEF` through a host-provided interactive editor callback

See `docs/BASIC7_GRAPHICS.md` for syntax, implementation details and deliberate compatibility limits.

## Build and test

```sh
make -j2
make test
make jtmos-check
make graphics-demo
```

`make graphics-demo` writes `examples/graphics_demo.ppm`. A ready rendered PNG is included as `examples/graphics_demo.png`.

## Small VM API

```c
CBMVM *vm = cbmvm_create(&host);
cbmvm_load_prg(vm, prg_bytes, prg_length);

for (;;) {
    int rc = cbmvm_run(vm, 256);
    cbmvm_graphic_tick(vm, 1);  /* normally driven by a GraOS timer */
    if (rc == CBMVM_YIELDED)
        continue;
    if (rc == CBMVM_HALTED)
        break;
    print_error(cbmvm_last_error(vm));
    break;
}

cbmvm_destroy(vm);
```

A BASIC infinite loop cannot permanently monopolize the caller: execution is bounded by a statement budget and yields to the host.

## JTMOS/GraOS bridge

`cbmvm_jtmos.c` translates generic VM callbacks into application-supplied bindings. In addition to the C64-like text memory bridge, the host can now supply:

```c
b.screen_clear     = my_clear;
b.graphics_mode    = my_mode;
b.graphics_color   = my_color;
b.graphics_present = my_blit_packed_sources;
b.sprite_update    = my_sprite_update;
b.sprite_editor    = my_graos_sprite_editor;
```

The presentation callback receives the packed 320x200 source framebuffer; GraOS can convert it directly to its window framebuffer without the VM knowing GraOS internals.

Existing virtual C64 addresses remain supported:

- `$0400-$07E7` — text screen cells
- `$D800-$DBE7` — color cells
- `$D020` / 53280 — border
- `$D021` / 53281 — background

## Memory footprint

On the current 64-bit development build, `cbmvm_instance_bytes()` is about **121 KiB**, including:

- 64 KiB guest RAM
- 16 KiB packed graphics framebuffer
- eight sprite states/patterns
- variables with 255-byte binary-safe strings
- GOSUB/FOR stacks and VM state

The pre-graphics 0.2 build was about 87 KiB. The added memory is bounded and deterministic.

## PRG compatibility

The original 2021 example set remains under `legacy_examples/`. Generated active tests use valid linked PRGs. BASIC 7 example programs use the real C128 extension tokens, including `$FE06` MOVSPR, `$FE07` SPRITE and `$FE1D` SPRDEF.
