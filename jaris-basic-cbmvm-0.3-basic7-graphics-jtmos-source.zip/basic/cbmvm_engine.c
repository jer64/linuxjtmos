/*
 * cbmvm_engine.c - small tokenized Commodore BASIC VM core.
 * Original project (C) 2021 Jari Tapio Tuominen.
 * Refactored 2026: standard PRG line links, compact execution core,
 * host callbacks, cooperative stepping and bounded guest memory.
 */
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cbmvm_engine.h"
#include "cbmvm_settings.h"
#include "cbmvm_graphics.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* Commodore BASIC V2 tokens used by this compact interpreter. */
#define T_END       0x80
#define T_FOR       0x81
#define T_NEXT      0x82
#define T_LET       0x88
#define T_GOTO      0x89
#define T_RUN       0x8a
#define T_IF        0x8b
#define T_GOSUB     0x8d
#define T_RETURN    0x8e
#define T_REM       0x8f
#define T_STOP      0x90
#define T_POKE      0x97
#define T_PRINT     0x99
#define T_CLR       0x9c
#define T_TO        0xa4
#define T_THEN      0xa7
#define T_NOT       0xa8
#define T_STEP      0xa9
#define T_PLUS      0xaa
#define T_MINUS     0xab
#define T_MUL       0xac
#define T_DIV       0xad
#define T_POW       0xae
#define T_AND       0xaf
#define T_OR        0xb0
#define T_GT        0xb1
#define T_EQ        0xb2
#define T_LT        0xb3
#define T_INT       0xb5
#define T_ABS       0xb6
#define T_PEEK      0xc2
/* BASIC 7.0 extension tokens. */
#define T_RGR       0xcc
#define T_GRAPHIC   0xde
#define T_PAINT     0xdf
#define T_CHAR      0xe0
#define T_BOX       0xe1
#define T_CIRCLE    0xe2
#define T_GSHAPE    0xe3
#define T_SSHAPE    0xe4
#define T_DRAW      0xe5
#define T_COLOR     0xe7
#define T_SCNCLR    0xe8
#define T_EXT_FE    0xfe
#define TFE_MOVSPR  0x06
#define TFE_SPRITE  0x07
#define TFE_SPRDEF  0x1d

#define C64_BORDER  53280u
#define C64_BG      53281u

typedef struct {
    int is_string;
    double number;
    char string[CBMVM_MAX_STRING];
    uint16_t string_length;
} VALUE;

typedef struct {
    CBMVM *vm;
    uint16_t pos;
} PARSER;

static uint16_t rd16(const uint8_t *p)
{
    return (uint16_t)((uint16_t)p[0] | ((uint16_t)p[1] << 8));
}

static void vm_set_error(CBMVM *vm, const char *msg)
{
    if (!vm) return;
    vm->error = 1;
    vm->halted = 1;
    if (!msg) msg = "CBMVM error";
    strncpy(vm->error_message, msg, sizeof(vm->error_message) - 1);
    vm->error_message[sizeof(vm->error_message) - 1] = 0;
}

static void vm_syntax_error(CBMVM *vm, const char *msg)
{
    char tmp[160];
    snprintf(tmp, sizeof(tmp), "?SYNTAX ERROR IN %u: %s",
             (unsigned)vm->line_number, msg ? msg : "invalid statement");
    vm_set_error(vm, tmp);
}

static void vm_putc(CBMVM *vm, int ch)
{
    if (vm->host.putc) vm->host.putc(vm->host.userdata, ch);
    if (ch == '\n' || ch == '\r') vm->print_column = 0;
    else vm->print_column++;
}

static void vm_puts(CBMVM *vm, const char *s)
{
    if (!s) return;
    while (*s) vm_putc(vm, (unsigned char)*s++);
}


static void vm_graphics_present(CBMVM *vm)
{
    if (vm && vm->host.graphics_present) {
        vm->host.graphics_present(vm->host.userdata, vm->graphics.pixels,
                                  sizeof(vm->graphics.pixels),
                                  CBMVM_GFX_WIDTH, CBMVM_GFX_HEIGHT,
                                  vm->graphics.color, vm->graphics.mode,
                                  vm->graphics.split_line);
    }
}

static void vm_sprite_present(CBMVM *vm, int index)
{
    CBMVM_SPRITE *s;
    if (!vm || index < 0 || index >= CBMVM_SPRITE_COUNT || !vm->host.sprite_update) return;
    s = &vm->graphics.sprites[index];
    vm->host.sprite_update(vm->host.userdata, index + 1, s->enabled, s->x, s->y,
                           s->color, s->priority, s->x_expand, s->y_expand,
                           s->multicolor, s->data);
}
static void vm_print_number(CBMVM *vm, double n)
{
    char buf[48];
    if (fabs(n) < 0.000000000001) n = 0.0;
    snprintf(buf, sizeof(buf), "%.12g", n);
    vm_puts(vm, buf);
}

static void skip_spaces(PARSER *p)
{
    while (p->pos < p->vm->program_end && p->vm->ram[p->pos] == ' ') p->pos++;
}

static int at_statement_end(PARSER *p)
{
    uint8_t c;
    skip_spaces(p);
    if (p->pos >= p->vm->program_end) return 1;
    c = p->vm->ram[p->pos];
    return c == 0 || c == ':';
}

static uint16_t statement_delimiter(CBMVM *vm, uint16_t pos)
{
    int quoted = 0;
    while (pos < vm->program_end) {
        uint8_t c = vm->ram[pos];
        if (c == '"') quoted = !quoted;
        if (!quoted && (c == 0 || c == ':')) break;
        pos++;
    }
    return pos;
}

static int normalize_name(const char *src, char *dst, size_t dstlen)
{
    size_t i = 0;
    if (!src || !dst || dstlen < 2) return -1;
    while (*src && i + 1 < dstlen) {
        unsigned char c = (unsigned char)*src++;
        if (c == ' ') continue;
        dst[i++] = (char)toupper(c);
    }
    dst[i] = 0;
    return i ? 0 : -1;
}

static int parse_var_name(PARSER *p, char *name, size_t n)
{
    size_t i = 0;
    skip_spaces(p);
    if (p->pos >= p->vm->program_end || !isalpha((unsigned char)p->vm->ram[p->pos])) return -1;
    while (p->pos < p->vm->program_end && i + 1 < n) {
        uint8_t c = p->vm->ram[p->pos];
        if (!(isalnum((unsigned char)c) || c == '$' || c == '%')) break;
        name[i++] = (char)toupper(c);
        p->pos++;
        if (c == '$' || c == '%') break;
    }
    name[i] = 0;
    return i ? 0 : -1;
}

static CBMVM_VARIABLE *find_var(CBMVM *vm, const char *name, int create)
{
    unsigned int i;
    char normalized[CBMVM_MAX_VAR_NAME];
    if (normalize_name(name, normalized, sizeof(normalized)) < 0) return NULL;
    for (i = 0; i < vm->variable_count; i++) {
        if (strcmp(vm->variables[i].name, normalized) == 0) return &vm->variables[i];
    }
    if (!create || vm->variable_count >= CBMVM_MAX_VARIABLES) return NULL;
    i = vm->variable_count++;
    memset(&vm->variables[i], 0, sizeof(vm->variables[i]));
    snprintf(vm->variables[i].name, sizeof(vm->variables[i].name), "%s", normalized);
    vm->variables[i].type = strchr(normalized, '$') ? CBMVM_VALUE_STRING : CBMVM_VALUE_NUMBER;
    return &vm->variables[i];
}

static VALUE value_number(double n)
{
    VALUE v;
    memset(&v, 0, sizeof(v));
    v.number = n;
    return v;
}

static VALUE value_blob(const void *data, size_t length)
{
    VALUE v;
    memset(&v, 0, sizeof(v));
    v.is_string = 1;
    if (length >= sizeof(v.string)) length = sizeof(v.string) - 1u;
    if (data && length) memcpy(v.string, data, length);
    v.string[length] = 0;
    v.string_length = (uint16_t)length;
    return v;
}

static VALUE value_string(const char *s)
{
    return value_blob(s, s ? strlen(s) : 0u);
}

static int value_truth(const VALUE *v)
{
    if (v->is_string) return v->string_length != 0;
    return v->number != 0.0;
}

static int value_to_number(CBMVM *vm, VALUE *v, double *out)
{
    if (v->is_string) {
        vm_syntax_error(vm, "numeric expression expected");
        return -1;
    }
    *out = v->number;
    return 0;
}

static int parse_expression(PARSER *p, VALUE *out);

static int parse_primary(PARSER *p, VALUE *out)
{
    CBMVM *vm = p->vm;
    uint8_t c;
    char name[CBMVM_MAX_VAR_NAME];
    char text[CBMVM_MAX_STRING];
    size_t i;

    skip_spaces(p);
    if (p->pos >= vm->program_end) return -1;
    c = vm->ram[p->pos];

    if (c == '(') {
        p->pos++;
        if (parse_expression(p, out) < 0) return -1;
        skip_spaces(p);
        if (vm->ram[p->pos] != ')') { vm_syntax_error(vm, "missing )"); return -1; }
        p->pos++;
        return 0;
    }

    if (c == T_MINUS || c == '-') {
        double n;
        p->pos++;
        if (parse_primary(p, out) < 0 || value_to_number(vm, out, &n) < 0) return -1;
        *out = value_number(-n);
        return 0;
    }
    if (c == T_PLUS || c == '+') {
        p->pos++;
        return parse_primary(p, out);
    }
    if (c == T_NOT) {
        double n;
        p->pos++;
        if (parse_primary(p, out) < 0 || value_to_number(vm, out, &n) < 0) return -1;
        *out = value_number((double)(~(int)n));
        return 0;
    }

    if (c == T_RGR) {
        VALUE dummy;
        p->pos++;
        skip_spaces(p);
        if (p->pos < vm->program_end && vm->ram[p->pos] == '(') {
            p->pos++;
            if (parse_expression(p, &dummy) < 0) return -1;
            skip_spaces(p);
            if (vm->ram[p->pos] != ')') { vm_syntax_error(vm, "missing ) after RGR"); return -1; }
            p->pos++;
        }
        *out = value_number((double)vm->graphics.mode);
        return 0;
    }

    if (c == T_PEEK) {
        VALUE a;
        double n;
        uint8_t b;
        p->pos++;
        skip_spaces(p);
        if (vm->ram[p->pos] == '(') p->pos++;
        if (parse_expression(p, &a) < 0 || value_to_number(vm, &a, &n) < 0) return -1;
        skip_spaces(p);
        if (vm->ram[p->pos] == ')') p->pos++;
        if (cbmvm_peek(vm, (uint16_t)((int)n & 0xffff), &b) < 0) return -1;
        *out = value_number((double)b);
        return 0;
    }

    if (c == T_INT || c == T_ABS) {
        uint8_t fn = c;
        VALUE a;
        double n;
        p->pos++;
        skip_spaces(p);
        if (vm->ram[p->pos] == '(') p->pos++;
        if (parse_expression(p, &a) < 0 || value_to_number(vm, &a, &n) < 0) return -1;
        skip_spaces(p);
        if (vm->ram[p->pos] == ')') p->pos++;
        *out = value_number(fn == T_INT ? floor(n) : fabs(n));
        return 0;
    }

    if (c == '"') {
        p->pos++;
        i = 0;
        while (p->pos < vm->program_end && vm->ram[p->pos] != '"' && vm->ram[p->pos] != 0) {
            if (i + 1 < sizeof(text)) text[i++] = (char)vm->ram[p->pos];
            p->pos++;
        }
        text[i] = 0;
        if (vm->ram[p->pos] == '"') p->pos++;
        *out = value_blob(text, i);
        return 0;
    }

    if (isdigit((unsigned char)c) || c == '.') {
        char numbuf[64];
        char *endp;
        i = 0;
        while (p->pos < vm->program_end && i + 1 < sizeof(numbuf)) {
            c = vm->ram[p->pos];
            if (!(isdigit((unsigned char)c) || c == '.' || c == 'E' || c == 'e' || c == '+' || c == '-')) break;
            /* +/- is only accepted following E/e. */
            if ((c == '+' || c == '-') && i > 0 && numbuf[i-1] != 'E' && numbuf[i-1] != 'e') break;
            numbuf[i++] = (char)c;
            p->pos++;
        }
        numbuf[i] = 0;
        *out = value_number(strtod(numbuf, &endp));
        if (endp == numbuf) { vm_syntax_error(vm, "bad number"); return -1; }
        return 0;
    }

    if (isalpha((unsigned char)c)) {
        CBMVM_VARIABLE *var;
        if (parse_var_name(p, name, sizeof(name)) < 0) return -1;
        var = find_var(vm, name, 1);
        if (!var) { vm_set_error(vm, "?OUT OF MEMORY ERROR"); return -1; }
        if (var->type == CBMVM_VALUE_STRING) *out = value_blob(var->string, var->string_length);
        else *out = value_number(var->number);
        return 0;
    }

    vm_syntax_error(vm, "expression expected");
    return -1;
}

static int parse_power(PARSER *p, VALUE *out)
{
    VALUE rhs;
    double a, b;
    if (parse_primary(p, out) < 0) return -1;
    skip_spaces(p);
    if (p->vm->ram[p->pos] == T_POW || p->vm->ram[p->pos] == '^') {
        p->pos++;
        if (parse_power(p, &rhs) < 0 || value_to_number(p->vm, out, &a) < 0 || value_to_number(p->vm, &rhs, &b) < 0) return -1;
        *out = value_number(pow(a, b));
    }
    return 0;
}

static int parse_mul(PARSER *p, VALUE *out)
{
    VALUE rhs;
    double a, b;
    uint8_t op;
    if (parse_power(p, out) < 0) return -1;
    for (;;) {
        skip_spaces(p); op = p->vm->ram[p->pos];
        if (!(op == T_MUL || op == '*' || op == T_DIV || op == '/')) break;
        p->pos++;
        if (parse_power(p, &rhs) < 0 || value_to_number(p->vm, out, &a) < 0 || value_to_number(p->vm, &rhs, &b) < 0) return -1;
        if ((op == T_DIV || op == '/') && b == 0.0) { vm_set_error(p->vm, "?DIVISION BY ZERO ERROR"); return -1; }
        *out = value_number((op == T_MUL || op == '*') ? a * b : a / b);
    }
    return 0;
}

static int parse_add(PARSER *p, VALUE *out)
{
    VALUE rhs;
    uint8_t op;
    if (parse_mul(p, out) < 0) return -1;
    for (;;) {
        double a, b;
        skip_spaces(p); op = p->vm->ram[p->pos];
        if (!(op == T_PLUS || op == '+' || op == T_MINUS || op == '-')) break;
        p->pos++;
        if (parse_mul(p, &rhs) < 0) return -1;
        if ((op == T_PLUS || op == '+') && (out->is_string || rhs.is_string)) {
            unsigned char temp[CBMVM_MAX_STRING];
            size_t used, add;
            if (!out->is_string || !rhs.is_string) { vm_syntax_error(p->vm, "type mismatch"); return -1; }
            used = out->string_length;
            if (used >= sizeof(temp)) used = sizeof(temp) - 1u;
            memcpy(temp, out->string, used);
            add = rhs.string_length;
            if (add > sizeof(temp) - 1u - used) add = sizeof(temp) - 1u - used;
            memcpy(temp + used, rhs.string, add);
            *out = value_blob(temp, used + add);
        } else {
            if (value_to_number(p->vm, out, &a) < 0 || value_to_number(p->vm, &rhs, &b) < 0) return -1;
            *out = value_number((op == T_PLUS || op == '+') ? a + b : a - b);
        }
    }
    return 0;
}

static int compare_values(CBMVM *vm, VALUE *a, VALUE *b, int relation)
{
    if (a->is_string || b->is_string) {
        int c;
        if (!a->is_string || !b->is_string) { vm_syntax_error(vm, "type mismatch"); return 0; }
        c = strcmp(a->string, b->string);
        if (relation == T_EQ) return c == 0;
        if (relation == T_LT) return c < 0;
        if (relation == T_GT) return c > 0;
        return 0;
    }
    if (relation == T_EQ) return a->number == b->number;
    if (relation == T_LT) return a->number < b->number;
    if (relation == T_GT) return a->number > b->number;
    return 0;
}

static int parse_compare(PARSER *p, VALUE *out)
{
    VALUE rhs;
    uint8_t op1, op2;
    int result;
    if (parse_add(p, out) < 0) return -1;
    skip_spaces(p);
    op1 = p->vm->ram[p->pos];
    if (!(op1 == T_EQ || op1 == T_LT || op1 == T_GT || op1 == '=' || op1 == '<' || op1 == '>')) return 0;
    p->pos++;
    skip_spaces(p);
    op2 = p->vm->ram[p->pos];
    if ((op1 == T_LT || op1 == '<') && (op2 == T_EQ || op2 == '=' || op2 == T_GT || op2 == '>')) p->pos++;
    else if ((op1 == T_GT || op1 == '>') && (op2 == T_EQ || op2 == '=')) p->pos++;
    else op2 = 0;
    if (parse_add(p, &rhs) < 0) return -1;

    if (op1 == '=') op1 = T_EQ;
    if (op1 == '<') op1 = T_LT;
    if (op1 == '>') op1 = T_GT;
    result = compare_values(p->vm, out, &rhs, op1);
    if (p->vm->error) return -1;
    if (op2 == T_GT || op2 == '>') result = !compare_values(p->vm, out, &rhs, T_EQ); /* <> */
    else if (op2 == T_EQ || op2 == '=') {
        if (op1 == T_LT) result = compare_values(p->vm, out, &rhs, T_LT) || compare_values(p->vm, out, &rhs, T_EQ);
        if (op1 == T_GT) result = compare_values(p->vm, out, &rhs, T_GT) || compare_values(p->vm, out, &rhs, T_EQ);
    }
    *out = value_number(result ? -1.0 : 0.0);
    return 0;
}

static int parse_logic(PARSER *p, VALUE *out)
{
    VALUE rhs;
    uint8_t op;
    double a, b;
    if (parse_compare(p, out) < 0) return -1;
    for (;;) {
        skip_spaces(p); op = p->vm->ram[p->pos];
        if (op != T_AND && op != T_OR) break;
        p->pos++;
        if (parse_compare(p, &rhs) < 0 || value_to_number(p->vm, out, &a) < 0 || value_to_number(p->vm, &rhs, &b) < 0) return -1;
        *out = value_number((double)(op == T_AND ? ((int)a & (int)b) : ((int)a | (int)b)));
    }
    return 0;
}

static int parse_expression(PARSER *p, VALUE *out)
{
    return parse_logic(p, out);
}

static int set_variable(CBMVM *vm, const char *name, const VALUE *v)
{
    CBMVM_VARIABLE *var = find_var(vm, name, 1);
    if (!var) { vm_set_error(vm, "?OUT OF MEMORY ERROR"); return -1; }
    if (var->type == CBMVM_VALUE_STRING) {
        if (!v->is_string) { vm_syntax_error(vm, "type mismatch"); return -1; }
        size_t n = v->string_length;
        if (n >= sizeof(var->string)) n = sizeof(var->string) - 1u;
        memcpy(var->string, v->string, n);
        var->string[n] = 0;
        var->string_length = (uint16_t)n;
    } else {
        if (v->is_string) { vm_syntax_error(vm, "type mismatch"); return -1; }
        var->number = v->number;
    }
    return 0;
}

static int prepare_line(CBMVM *vm, uint16_t address)
{
    uint16_t next;
    if ((size_t)address + 4u > vm->ram_size || address >= vm->program_end) {
        vm_set_error(vm, "?BAD PROGRAM POINTER");
        return -1;
    }
    next = rd16(&vm->ram[address]);
    vm->line_address = address;
    vm->next_line_address = next;
    vm->line_number = rd16(&vm->ram[address + 2]);
    vm->pc = (uint16_t)(address + 4);
    return 0;
}

static int advance_line(CBMVM *vm)
{
    if (vm->next_line_address == 0) {
        vm->halted = 1;
        return CBMVM_HALTED;
    }
    return prepare_line(vm, vm->next_line_address) < 0 ? CBMVM_ERR : CBMVM_OK;
}

static int find_line(CBMVM *vm, uint16_t line, uint16_t *address)
{
    uint16_t a = vm->first_line_address;
    unsigned int guard = 0;
    while (a && guard++ < 65535u) {
        uint16_t next, nr;
        if ((size_t)a + 4u > vm->ram_size || a >= vm->program_end) return -1;
        next = rd16(&vm->ram[a]);
        nr = rd16(&vm->ram[a + 2]);
        if (nr == line) { *address = a; return 0; }
        if (next == 0) break;
        if (next <= a || next >= vm->program_end) return -1;
        a = next;
    }
    return 1;
}

static int jump_line(CBMVM *vm, uint16_t line)
{
    uint16_t a;
    int rc = find_line(vm, line, &a);
    if (rc != 0) {
        char msg[96];
        snprintf(msg, sizeof(msg), "?UNDEFINED STATEMENT ERROR: %u", (unsigned)line);
        vm_set_error(vm, msg);
        return -1;
    }
    return prepare_line(vm, a);
}

static int parse_line_number_expr(PARSER *p, uint16_t *line)
{
    VALUE v;
    double n;
    if (parse_expression(p, &v) < 0 || value_to_number(p->vm, &v, &n) < 0) return -1;
    if (n < 0 || n > 65535) { vm_syntax_error(p->vm, "bad line number"); return -1; }
    *line = (uint16_t)n;
    return 0;
}

static int statement_assignment(PARSER *p)
{
    char name[CBMVM_MAX_VAR_NAME];
    VALUE v;
    skip_spaces(p);
    if (parse_var_name(p, name, sizeof(name)) < 0) { vm_syntax_error(p->vm, "variable expected"); return -1; }
    skip_spaces(p);
    if (p->vm->ram[p->pos] != T_EQ && p->vm->ram[p->pos] != '=') { vm_syntax_error(p->vm, "= expected"); return -1; }
    p->pos++;
    if (parse_expression(p, &v) < 0) return -1;
    return set_variable(p->vm, name, &v);
}

static int statement_print(PARSER *p)
{
    CBMVM *vm = p->vm;
    int suppress_newline = 0;
    skip_spaces(p);
    if (at_statement_end(p)) { vm_putc(vm, '\n'); return 0; }
    while (!at_statement_end(p)) {
        VALUE v;
        uint8_t c;
        if (parse_expression(p, &v) < 0) return -1;
        if (v.is_string) vm_puts(vm, v.string); else vm_print_number(vm, v.number);
        skip_spaces(p);
        c = vm->ram[p->pos];
        if (c == ';') {
            p->pos++;
            suppress_newline = 1;
            skip_spaces(p);
            continue;
        }
        if (c == ',') {
            unsigned int target;
            p->pos++;
            target = ((vm->print_column / CBMVM_PRINT_ZONE) + 1u) * CBMVM_PRINT_ZONE;
            while (vm->print_column < target) vm_putc(vm, ' ');
            suppress_newline = 1;
            skip_spaces(p);
            continue;
        }
        suppress_newline = 0;
        break;
    }
    if (!suppress_newline) vm_putc(vm, '\n');
    return 0;
}

static int statement_poke(PARSER *p)
{
    VALUE a, v;
    double ad, val;
    if (parse_expression(p, &a) < 0 || value_to_number(p->vm, &a, &ad) < 0) return -1;
    skip_spaces(p);
    if (p->vm->ram[p->pos] != ',') { vm_syntax_error(p->vm, ", expected"); return -1; }
    p->pos++;
    if (parse_expression(p, &v) < 0 || value_to_number(p->vm, &v, &val) < 0) return -1;
    return cbmvm_poke(p->vm, (uint16_t)((int)ad & 0xffff), (uint8_t)((int)val & 0xff));
}


static int parse_numeric_fields(PARSER *p, double *v, unsigned char *present, int max_fields)
{
    int n = 0;
    while (n < max_fields && !at_statement_end(p)) {
        VALUE x;
        double d;
        skip_spaces(p);
        if (p->vm->ram[p->pos] == ',') {
            present[n] = 0;
            v[n] = 0.0;
            n++;
            p->pos++;
            continue;
        }
        if (parse_expression(p, &x) < 0 || value_to_number(p->vm, &x, &d) < 0) return -1;
        present[n] = 1;
        v[n] = d;
        n++;
        skip_spaces(p);
        if (p->vm->ram[p->pos] == ',') { p->pos++; continue; }
        break;
    }
    return n;
}

static int int_round(double x)
{
    return (int)lrint(x);
}

static int gfx_x(const CBMVM *vm, double x)
{
    int v = int_round(x);
    if (vm->graphics.mode == 3 || vm->graphics.mode == 4) v *= 2;
    return v;
}

static int gfx_x_radius(const CBMVM *vm, double x)
{
    int v = abs(int_round(x));
    if (vm->graphics.mode == 3 || vm->graphics.mode == 4) v *= 2;
    return v;
}

static int valid_source(CBMVM *vm, int source)
{
    if (source < 0 || source > 3) { vm_syntax_error(vm, "graphics color source must be 0..3"); return -1; }
    if ((vm->graphics.mode == 1 || vm->graphics.mode == 2) && source > 1) {
        vm_syntax_error(vm, "color source 2/3 requires multicolor mode");
        return -1;
    }
    return source;
}

static int statement_graphic(PARSER *p)
{
    CBMVM *vm = p->vm;
    double f[3] = {0,0,0};
    unsigned char has[3] = {0,0,0};
    int n, mode, clear = 0, split = -1;
    skip_spaces(p);
    if (vm->ram[p->pos] == T_CLR) {
        /* The real C128 frees bitmap RAM. CBMVM keeps its compact framebuffer but returns to text mode. */
        p->pos++;
        cbmvm_graphics_set_mode(&vm->graphics, 0, 0, -1);
        if (vm->host.graphics_mode) vm->host.graphics_mode(vm->host.userdata, 0, vm->graphics.split_line);
        vm_graphics_present(vm);
        return 0;
    }
    n = parse_numeric_fields(p, f, has, 3);
    if (n < 1 || !has[0]) { vm_syntax_error(vm, "GRAPHIC mode expected"); return -1; }
    mode = int_round(f[0]);
    if (n > 1 && has[1]) clear = int_round(f[1]) != 0;
    if (n > 2 && has[2]) split = int_round(f[2]);
    if (cbmvm_graphics_set_mode(&vm->graphics, mode, clear, split) < 0) {
        vm_syntax_error(vm, "GRAPHIC mode must be 0..5"); return -1;
    }
    if (vm->host.graphics_mode) vm->host.graphics_mode(vm->host.userdata, mode, vm->graphics.split_line);
    if (clear && vm->host.screen_clear) vm->host.screen_clear(vm->host.userdata);
    vm_graphics_present(vm);
    return 0;
}

static int statement_rgr(PARSER *p)
{
    VALUE v;
    double mode;
    if (at_statement_end(p)) return 0;
    if (parse_expression(p, &v) < 0 || value_to_number(p->vm, &v, &mode) < 0) return -1;
    if (cbmvm_graphics_set_mode(&p->vm->graphics, int_round(mode), 0, -1) < 0) {
        vm_syntax_error(p->vm, "RGR mode must be 0..5"); return -1;
    }
    if (p->vm->host.graphics_mode)
        p->vm->host.graphics_mode(p->vm->host.userdata, p->vm->graphics.mode, p->vm->graphics.split_line);
    vm_graphics_present(p->vm);
    return 0;
}

static int statement_scnclr(PARSER *p)
{
    CBMVM *vm = p->vm;
    (void)p;
    cbmvm_graphics_clear(&vm->graphics, 0);
    if (vm->host.screen_clear) vm->host.screen_clear(vm->host.userdata);
    vm_graphics_present(vm);
    return 0;
}

static int statement_color(PARSER *p)
{
    double f[2] = {0,0};
    unsigned char has[2] = {0,0};
    int n = parse_numeric_fields(p, f, has, 2);
    int source, color;
    if (n < 2 || !has[0] || !has[1]) { vm_syntax_error(p->vm, "COLOR source,color expected"); return -1; }
    source = int_round(f[0]); color = int_round(f[1]);
    if (cbmvm_graphics_set_color(&p->vm->graphics, source, color) < 0) {
        vm_syntax_error(p->vm, "COLOR source 0..6 and color 1..16 required"); return -1;
    }
    if (p->vm->host.graphics_color) p->vm->host.graphics_color(p->vm->host.userdata, source, color);
    vm_graphics_present(p->vm);
    return 0;
}

static int statement_draw(PARSER *p)
{
    CBMVM *vm = p->vm;
    int source = vm->graphics.pen_source;
    int x, y;
    skip_spaces(p);
    if (vm->ram[p->pos] == T_TO) {
        x = vm->graphics.cursor_x; y = vm->graphics.cursor_y;
    } else {
        VALUE v;
        double d;
        if (vm->ram[p->pos] == ',') {
            p->pos++;
        } else {
            if (parse_expression(p, &v) < 0 || value_to_number(vm, &v, &d) < 0) return -1;
            source = int_round(d);
            if (valid_source(vm, source) < 0) return -1;
            skip_spaces(p);
            if (vm->ram[p->pos] != ',') { vm_syntax_error(vm, ", expected after DRAW source"); return -1; }
            p->pos++;
        }
        skip_spaces(p);
        if (vm->ram[p->pos] == T_TO) {
            x = vm->graphics.cursor_x; y = vm->graphics.cursor_y;
        } else {
            VALUE vx, vy; double dx, dy;
            if (parse_expression(p, &vx) < 0 || value_to_number(vm, &vx, &dx) < 0) return -1;
            skip_spaces(p); if (vm->ram[p->pos] != ',') { vm_syntax_error(vm, ", expected in DRAW"); return -1; } p->pos++;
            if (parse_expression(p, &vy) < 0 || value_to_number(vm, &vy, &dy) < 0) return -1;
            x = gfx_x(vm, dx); y = int_round(dy);
            cbmvm_graphics_put_pixel(&vm->graphics, x, y, (uint8_t)source);
        }
    }
    while (!at_statement_end(p)) {
        VALUE vx, vy; double dx, dy;
        skip_spaces(p);
        if (vm->ram[p->pos] != T_TO) break;
        p->pos++;
        if (parse_expression(p, &vx) < 0 || value_to_number(vm, &vx, &dx) < 0) return -1;
        skip_spaces(p); if (vm->ram[p->pos] != ',') { vm_syntax_error(vm, ", expected after DRAW TO x"); return -1; } p->pos++;
        if (parse_expression(p, &vy) < 0 || value_to_number(vm, &vy, &dy) < 0) return -1;
        cbmvm_graphics_line(&vm->graphics, x, y, gfx_x(vm, dx), int_round(dy), (uint8_t)source);
        x = gfx_x(vm, dx); y = int_round(dy);
    }
    vm_graphics_present(vm);
    return 0;
}

static int statement_box(PARSER *p)
{
    CBMVM *vm = p->vm;
    double f[7] = {0,0,0,0,0,0,0};
    unsigned char has[7] = {0,0,0,0,0,0,0};
    int n = parse_numeric_fields(p, f, has, 7);
    int source, x1, y1, x2, y2, paint = 0;
    double angle = 0.0;
    if (n < 3 || !has[1] || !has[2]) { vm_syntax_error(vm, "BOX [source],x1,y1[,x2,y2][,angle][,paint]"); return -1; }
    source = has[0] ? int_round(f[0]) : vm->graphics.pen_source;
    if (valid_source(vm, source) < 0) return -1;
    x1 = gfx_x(vm, f[1]); y1 = int_round(f[2]);
    x2 = (n > 3 && has[3]) ? gfx_x(vm, f[3]) : vm->graphics.cursor_x;
    y2 = (n > 4 && has[4]) ? int_round(f[4]) : vm->graphics.cursor_y;
    if (n > 5 && has[5]) angle = f[5];
    if (n > 6 && has[6]) paint = int_round(f[6]) != 0;
    cbmvm_graphics_box(&vm->graphics, x1, y1, x2, y2, angle, paint, (uint8_t)source);
    vm_graphics_present(vm);
    return 0;
}

static int statement_circle(PARSER *p)
{
    CBMVM *vm = p->vm;
    double f[9] = {0,0,0,0,0,0,0,0,0};
    unsigned char has[9] = {0,0,0,0,0,0,0,0,0};
    int n = parse_numeric_fields(p, f, has, 9);
    int source, cx, cy, xr, yr;
    double sa = 0.0, ea = 360.0, angle = 0.0, inc = 2.0;
    if (n < 4 || !has[1] || !has[2] || !has[3]) { vm_syntax_error(vm, "CIRCLE [source],x,y,xr[,yr][,sa][,ea][,angle][,inc]"); return -1; }
    source = has[0] ? int_round(f[0]) : vm->graphics.pen_source;
    if (valid_source(vm, source) < 0) return -1;
    cx = gfx_x(vm, f[1]); cy = int_round(f[2]); xr = gfx_x_radius(vm, f[3]);
    yr = (n > 4 && has[4]) ? abs(int_round(f[4])) : abs(int_round(f[3]));
    if (n > 5 && has[5]) sa = f[5];
    if (n > 6 && has[6]) ea = f[6];
    if (n > 7 && has[7]) angle = f[7];
    if (n > 8 && has[8]) inc = f[8];
    cbmvm_graphics_circle(&vm->graphics, cx, cy, xr, yr, sa, ea, angle, inc, (uint8_t)source);
    vm_graphics_present(vm);
    return 0;
}

static int statement_paint(PARSER *p)
{
    CBMVM *vm = p->vm;
    double f[4] = {0,0,0,0};
    unsigned char has[4] = {0,0,0,0};
    int n = parse_numeric_fields(p, f, has, 4);
    int source = (n > 0 && has[0]) ? int_round(f[0]) : vm->graphics.pen_source;
    int x = (n > 1 && has[1]) ? gfx_x(vm, f[1]) : vm->graphics.cursor_x;
    int y = (n > 2 && has[2]) ? int_round(f[2]) : vm->graphics.cursor_y;
    int mode = (n > 3 && has[3]) ? int_round(f[3]) : 0;
    int rc;
    if (valid_source(vm, source) < 0) return -1;
    rc = cbmvm_graphics_paint(&vm->graphics, x, y, (uint8_t)source, mode);
    if (rc == -2) { vm_set_error(vm, "?PAINT COMPLEXITY ERROR"); return -1; }
    if (rc < 0) { vm_syntax_error(vm, "PAINT coordinate out of range"); return -1; }
    vm_graphics_present(vm);
    return 0;
}

static int statement_char(PARSER *p)
{
    CBMVM *vm = p->vm;
    VALUE a, b, text, rev;
    double source_d, x_d, y_d, rev_d = 0;
    int source;
    if (parse_expression(p, &a) < 0 || value_to_number(vm, &a, &source_d) < 0) return -1;
    skip_spaces(p); if (vm->ram[p->pos] != ',') { vm_syntax_error(vm, "CHAR source,x,y,string expected"); return -1; } p->pos++;
    if (parse_expression(p, &b) < 0 || value_to_number(vm, &b, &x_d) < 0) return -1;
    skip_spaces(p); if (vm->ram[p->pos] != ',') { vm_syntax_error(vm, "CHAR x,y expected"); return -1; } p->pos++;
    if (parse_expression(p, &a) < 0 || value_to_number(vm, &a, &y_d) < 0) return -1;
    skip_spaces(p);
    if (vm->ram[p->pos] == ',') {
        p->pos++;
        if (parse_expression(p, &text) < 0) return -1;
        if (!text.is_string) { vm_syntax_error(vm, "CHAR string expected"); return -1; }
        skip_spaces(p);
        if (vm->ram[p->pos] == ',') {
            p->pos++;
            if (parse_expression(p, &rev) < 0 || value_to_number(vm, &rev, &rev_d) < 0) return -1;
        }
    } else text = value_string("");
    source = int_round(source_d);
    if (valid_source(vm, source) < 0) return -1;
    cbmvm_graphics_text(&vm->graphics, int_round(x_d), int_round(y_d),
                        (const unsigned char *)text.string, text.string_length,
                        (uint8_t)source, int_round(rev_d) != 0);
    vm_graphics_present(vm);
    return 0;
}

static int statement_sshape(PARSER *p)
{
    CBMVM *vm = p->vm;
    char name[CBMVM_MAX_VAR_NAME];
    CBMVM_VARIABLE *var;
    double f[4] = {0,0,0,0};
    unsigned char has[4] = {0,0,0,0};
    int n, x1, y1, x2, y2, w, h, x, y;
    size_t pixels, payload, total, bi;
    unsigned char temp[CBMVM_MAX_STRING];
    if (parse_var_name(p, name, sizeof(name)) < 0 || !strchr(name, '$')) { vm_syntax_error(vm, "SSHAPE string variable expected"); return -1; }
    skip_spaces(p); if (vm->ram[p->pos] != ',') { vm_syntax_error(vm, "SSHAPE variable,x1,y1 expected"); return -1; } p->pos++;
    n = parse_numeric_fields(p, f, has, 4);
    if (n < 2 || !has[0] || !has[1]) { vm_syntax_error(vm, "SSHAPE coordinates expected"); return -1; }
    x1 = gfx_x(vm, f[0]); y1 = int_round(f[1]);
    x2 = (n > 2 && has[2]) ? gfx_x(vm, f[2]) : vm->graphics.cursor_x;
    y2 = (n > 3 && has[3]) ? int_round(f[3]) : vm->graphics.cursor_y;
    if (x2 < x1) { int t=x1; x1=x2; x2=t; }
    if (y2 < y1) { int t=y1; y1=y2; y2=t; }
    w = x2 - x1 + 1; h = y2 - y1 + 1;
    if (w <= 0 || h <= 0 || w > CBMVM_GFX_WIDTH || h > CBMVM_GFX_HEIGHT) { vm_syntax_error(vm, "SSHAPE area out of range"); return -1; }
    pixels = (size_t)w * (size_t)h;
    payload = (pixels + 3u) / 4u;
    total = 4u + payload;
    if (total >= CBMVM_MAX_STRING) { vm_set_error(vm, "?STRING TOO LONG ERROR (SSHAPE)"); return -1; }
    memset(temp, 0, total);
    temp[0]=(unsigned char)(w & 255); temp[1]=(unsigned char)((w>>8)&255); temp[2]=(unsigned char)h; temp[3]=vm->graphics.mode;
    bi = 0;
    for (y=0; y<h; y++) for (x=0; x<w; x++,bi++) {
        uint8_t src = cbmvm_graphics_get_pixel(&vm->graphics, x1+x, y1+y);
        temp[4u + (bi>>2)] |= (unsigned char)((src & 3u) << ((bi & 3u)*2u));
    }
    var = find_var(vm, name, 1);
    if (!var) { vm_set_error(vm, "?OUT OF MEMORY ERROR"); return -1; }
    memcpy(var->string, temp, total); var->string[total]=0; var->string_length=(uint16_t)total; var->type=CBMVM_VALUE_STRING;
    return 0;
}

static int statement_gshape(PARSER *p)
{
    CBMVM *vm = p->vm;
    char name[CBMVM_MAX_VAR_NAME];
    CBMVM_VARIABLE *var;
    double f[3] = {0,0,0};
    unsigned char has[3] = {0,0,0};
    int n, dx, dy, mode, w, h, x, y;
    size_t bi, required;
    if (parse_var_name(p, name, sizeof(name)) < 0 || !strchr(name, '$')) { vm_syntax_error(vm, "GSHAPE string variable expected"); return -1; }
    var = find_var(vm, name, 0);
    if (!var || var->type != CBMVM_VALUE_STRING || var->string_length < 4) { vm_syntax_error(vm, "GSHAPE invalid shape string"); return -1; }
    skip_spaces(p);
    if (vm->ram[p->pos] == ',') { p->pos++; n = parse_numeric_fields(p, f, has, 3); } else n = 0;
    dx = (n > 0 && has[0]) ? gfx_x(vm, f[0]) : vm->graphics.cursor_x;
    dy = (n > 1 && has[1]) ? int_round(f[1]) : vm->graphics.cursor_y;
    mode = (n > 2 && has[2]) ? int_round(f[2]) : 0;
    if (mode < 0 || mode > 4) { vm_syntax_error(vm, "GSHAPE mode must be 0..4"); return -1; }
    w = (unsigned char)var->string[0] | ((unsigned char)var->string[1] << 8);
    h = (unsigned char)var->string[2];
    required = 4u + (((size_t)w*(size_t)h + 3u)/4u);
    if (w <= 0 || h <= 0 || required > var->string_length) { vm_syntax_error(vm, "GSHAPE corrupt shape string"); return -1; }
    bi = 0;
    for (y=0; y<h; y++) for (x=0; x<w; x++,bi++) {
        uint8_t src = ((unsigned char)var->string[4u+(bi>>2)] >> ((bi&3u)*2u)) & 3u;
        uint8_t old = cbmvm_graphics_get_pixel(&vm->graphics, dx+x, dy+y);
        uint8_t out = src;
        if (mode == 1) out = (uint8_t)(3u - src);
        else if (mode == 2) out = (uint8_t)((old | src) & 3u);
        else if (mode == 3) out = (uint8_t)((old & src) & 3u);
        else if (mode == 4) out = (uint8_t)((old ^ src) & 3u);
        cbmvm_graphics_put_pixel(&vm->graphics, dx+x, dy+y, out);
    }
    vm_graphics_present(vm);
    return 0;
}

static int parse_sprite_number(CBMVM *vm, double d)
{
    int n = int_round(d);
    if (n < 1 || n > 8) { vm_syntax_error(vm, "sprite number must be 1..8"); return -1; }
    return n - 1;
}

static int statement_sprite(PARSER *p)
{
    CBMVM *vm = p->vm;
    double f[7] = {0,0,0,0,0,0,0};
    unsigned char has[7] = {0,0,0,0,0,0,0};
    int n = parse_numeric_fields(p, f, has, 7);
    int index;
    CBMVM_SPRITE *s;
    if (n < 1 || !has[0]) { vm_syntax_error(vm, "SPRITE number expected"); return -1; }
    index = parse_sprite_number(vm, f[0]); if (index < 0) return -1;
    s = &vm->graphics.sprites[index];
    if (n>1 && has[1]) s->enabled=(uint8_t)(int_round(f[1])!=0);
    if (n>2 && has[2]) { int c=int_round(f[2]); if(c<1||c>16){vm_syntax_error(vm,"sprite color must be 1..16");return -1;} s->color=(uint8_t)c; }
    if (n>3 && has[3]) s->priority=(uint8_t)(int_round(f[3])!=0);
    if (n>4 && has[4]) s->x_expand=(uint8_t)(int_round(f[4])!=0);
    if (n>5 && has[5]) s->y_expand=(uint8_t)(int_round(f[5])!=0);
    if (n>6 && has[6]) s->multicolor=(uint8_t)(int_round(f[6])!=0);
    vm->graphics.generation++;
    vm_sprite_present(vm,index);
    return 0;
}

static int statement_movspr(PARSER *p)
{
    CBMVM *vm=p->vm;
    VALUE v; double d, a, b;
    int index, relative_x=0, relative_y=0;
    skip_spaces(p);
    if (parse_expression(p,&v)<0 || value_to_number(vm,&v,&d)<0) return -1;
    index=parse_sprite_number(vm,d); if(index<0)return -1;
    skip_spaces(p); if(vm->ram[p->pos]!=','){vm_syntax_error(vm,"MOVSPR number,x,y expected");return -1;} p->pos++;
    skip_spaces(p); if(vm->ram[p->pos]==T_PLUS||vm->ram[p->pos]=='+'||vm->ram[p->pos]==T_MINUS||vm->ram[p->pos]=='-') relative_x=1;
    if(parse_expression(p,&v)<0||value_to_number(vm,&v,&a)<0)return -1;
    skip_spaces(p);
    if(vm->ram[p->pos]=='#') {
        p->pos++;
        if(parse_expression(p,&v)<0||value_to_number(vm,&v,&b)<0)return -1;
        vm->graphics.sprites[index].angle=a;
        vm->graphics.sprites[index].speed=b<0?0:b;
        vm->graphics.sprites[index].moving=(uint8_t)(b>0.0);
    } else if(vm->ram[p->pos]==';') {
        /* Polar relative move: distance ; angle. */
        double r;
        p->pos++;
        if(parse_expression(p,&v)<0||value_to_number(vm,&v,&b)<0)return -1;
        r=b*M_PI/180.0;
        vm->graphics.sprites[index].x=(int16_t)lrint(vm->graphics.sprites[index].x + sin(r)*a);
        vm->graphics.sprites[index].y=(int16_t)lrint(vm->graphics.sprites[index].y - cos(r)*a);
        vm->graphics.sprites[index].moving=0;
    } else {
        if(vm->ram[p->pos]!=','){vm_syntax_error(vm,"MOVSPR y coordinate expected");return -1;} p->pos++;
        skip_spaces(p); if(vm->ram[p->pos]==T_PLUS||vm->ram[p->pos]=='+'||vm->ram[p->pos]==T_MINUS||vm->ram[p->pos]=='-') relative_y=1;
        if(parse_expression(p,&v)<0||value_to_number(vm,&v,&b)<0)return -1;
        if(relative_x||relative_y) {
            vm->graphics.sprites[index].x=(int16_t)(vm->graphics.sprites[index].x + int_round(a));
            vm->graphics.sprites[index].y=(int16_t)(vm->graphics.sprites[index].y + int_round(b));
        } else {
            vm->graphics.sprites[index].x=(int16_t)int_round(a);
            vm->graphics.sprites[index].y=(int16_t)int_round(b);
        }
        vm->graphics.sprites[index].moving=0;
    }
    vm->graphics.generation++;
    vm_sprite_present(vm,index);
    return 0;
}

static int statement_sprdef(PARSER *p)
{
    CBMVM *vm=p->vm;
    uint8_t data[CBMVM_SPRITE_COUNT][CBMVM_SPRITE_BYTES];
    int i, rc=0;
    (void)p;
    for(i=0;i<CBMVM_SPRITE_COUNT;i++) memcpy(data[i],vm->graphics.sprites[i].data,CBMVM_SPRITE_BYTES);
    /* C128 SPRDEF clears the bitmap work area. */
    cbmvm_graphics_clear(&vm->graphics,0);
    if(vm->host.sprite_editor) rc=vm->host.sprite_editor(vm->host.userdata,data);
    if(rc<0){vm_set_error(vm,"?SPRDEF HOST ERROR");return -1;}
    if(vm->host.sprite_editor) for(i=0;i<CBMVM_SPRITE_COUNT;i++){memcpy(vm->graphics.sprites[i].data,data[i],CBMVM_SPRITE_BYTES);vm_sprite_present(vm,i);}
    vm_graphics_present(vm);
    return 0;
}

static int statement_if(PARSER *p)
{
    VALUE cond;
    uint16_t line;
    if (parse_expression(p, &cond) < 0) return -1;
    skip_spaces(p);
    if (p->vm->ram[p->pos] != T_THEN) { vm_syntax_error(p->vm, "THEN expected"); return -1; }
    p->pos++;
    if (!value_truth(&cond)) {
        p->pos = statement_delimiter(p->vm, p->pos);
        return 0;
    }
    skip_spaces(p);
    if (p->vm->ram[p->pos] == T_GOTO) p->pos++;
    if (parse_line_number_expr(p, &line) < 0) return -1;
    return jump_line(p->vm, line) < 0 ? -1 : 1;
}

static int statement_gosub(PARSER *p)
{
    CBMVM *vm = p->vm;
    uint16_t line, ret;
    if (vm->gosub_depth >= CBMVM_GOSUB_DEPTH) { vm_set_error(vm, "?OUT OF MEMORY ERROR (GOSUB)"); return -1; }
    if (parse_line_number_expr(p, &line) < 0) return -1;
    ret = statement_delimiter(vm, p->pos);
    vm->gosub_stack[vm->gosub_depth].return_pc = ret;
    vm->gosub_stack[vm->gosub_depth].return_line_address = vm->line_address;
    vm->gosub_depth++;
    return jump_line(vm, line) < 0 ? -1 : 1;
}

static int statement_return(CBMVM *vm)
{
    CBMVM_GOSUB_FRAME f;
    if (!vm->gosub_depth) { vm_set_error(vm, "?RETURN WITHOUT GOSUB ERROR"); return -1; }
    f = vm->gosub_stack[--vm->gosub_depth];
    if (prepare_line(vm, f.return_line_address) < 0) return -1;
    vm->pc = f.return_pc;
    return 1;
}

static int statement_for(PARSER *p)
{
    CBMVM *vm = p->vm;
    char name[CBMVM_MAX_VAR_NAME];
    VALUE start, limit, step;
    double nstart, nlimit, nstep = 1.0;
    uint16_t loop_pc;
    if (vm->for_depth >= CBMVM_FOR_DEPTH) { vm_set_error(vm, "?OUT OF MEMORY ERROR (FOR)"); return -1; }
    if (parse_var_name(p, name, sizeof(name)) < 0) { vm_syntax_error(vm, "FOR variable expected"); return -1; }
    skip_spaces(p);
    if (vm->ram[p->pos] != T_EQ && vm->ram[p->pos] != '=') { vm_syntax_error(vm, "= expected"); return -1; }
    p->pos++;
    if (parse_expression(p, &start) < 0 || value_to_number(vm, &start, &nstart) < 0) return -1;
    skip_spaces(p);
    if (vm->ram[p->pos] != T_TO) { vm_syntax_error(vm, "TO expected"); return -1; }
    p->pos++;
    if (parse_expression(p, &limit) < 0 || value_to_number(vm, &limit, &nlimit) < 0) return -1;
    skip_spaces(p);
    if (vm->ram[p->pos] == T_STEP) {
        p->pos++;
        if (parse_expression(p, &step) < 0 || value_to_number(vm, &step, &nstep) < 0) return -1;
    }
    if (nstep == 0.0) { vm_syntax_error(vm, "STEP cannot be zero"); return -1; }
    start = value_number(nstart);
    if (set_variable(vm, name, &start) < 0) return -1;
    loop_pc = statement_delimiter(vm, p->pos);
    snprintf(vm->for_stack[vm->for_depth].variable, CBMVM_MAX_VAR_NAME, "%s", name);
    vm->for_stack[vm->for_depth].limit = nlimit;
    vm->for_stack[vm->for_depth].step = nstep;
    vm->for_stack[vm->for_depth].loop_pc = loop_pc;
    vm->for_stack[vm->for_depth].loop_line_address = vm->line_address;
    vm->for_depth++;
    p->pos = loop_pc;
    return 0;
}

static int statement_next(PARSER *p)
{
    CBMVM *vm = p->vm;
    char name[CBMVM_MAX_VAR_NAME];
    int idx;
    CBMVM_FOR_FRAME *f;
    CBMVM_VARIABLE *var;
    skip_spaces(p);
    name[0] = 0;
    if (isalpha((unsigned char)vm->ram[p->pos])) parse_var_name(p, name, sizeof(name));
    if (!vm->for_depth) { vm_set_error(vm, "?NEXT WITHOUT FOR ERROR"); return -1; }
    idx = (int)vm->for_depth - 1;
    if (name[0]) {
        while (idx >= 0 && strcmp(vm->for_stack[idx].variable, name) != 0) idx--;
        if (idx < 0) { vm_set_error(vm, "?NEXT WITHOUT FOR ERROR"); return -1; }
    }
    f = &vm->for_stack[idx];
    var = find_var(vm, f->variable, 0);
    if (!var || var->type != CBMVM_VALUE_NUMBER) { vm_set_error(vm, "?FOR STATE ERROR"); return -1; }
    var->number += f->step;
    if ((f->step > 0 && var->number <= f->limit) || (f->step < 0 && var->number >= f->limit)) {
        uint16_t la = f->loop_line_address;
        uint16_t pc = f->loop_pc;
        if (prepare_line(vm, la) < 0) return -1;
        vm->pc = pc;
        return 1;
    }
    vm->for_depth = (unsigned int)idx;
    return 0;
}

static int execute_statement(CBMVM *vm, PARSER *p)
{
    uint8_t token;
    skip_spaces(p);
    token = vm->ram[p->pos];

    if (token == 0 || token == ':') return 0;
    if (isalpha((unsigned char)token)) return statement_assignment(p);

    p->pos++;
    if (token == T_EXT_FE) {
        uint8_t ext;
        if (p->pos >= vm->program_end) { vm_syntax_error(vm, "truncated BASIC 7 token"); return -1; }
        ext = vm->ram[p->pos++];
        switch (ext) {
            case TFE_MOVSPR: return statement_movspr(p);
            case TFE_SPRITE: return statement_sprite(p);
            case TFE_SPRDEF: return statement_sprdef(p);
            default: { char msg[80]; snprintf(msg,sizeof(msg),"unsupported BASIC 7 token $FE%02X",(unsigned)ext); vm_syntax_error(vm,msg); return -1; }
        }
    }
    switch (token) {
        case T_END:
        case T_STOP:
            vm->halted = 1;
            return 1;
        case T_LET:
            return statement_assignment(p);
        case T_PRINT:
            return statement_print(p);
        case T_GOTO: {
            uint16_t line;
            if (parse_line_number_expr(p, &line) < 0) return -1;
            return jump_line(vm, line) < 0 ? -1 : 1;
        }
        case T_IF:
            return statement_if(p);
        case T_GOSUB:
            return statement_gosub(p);
        case T_RETURN:
            return statement_return(vm);
        case T_FOR:
            return statement_for(p);
        case T_NEXT:
            return statement_next(p);
        case T_POKE:
            return statement_poke(p);
        case T_RGR:
            return statement_rgr(p); /* CBMVM convenience alias; RGR(x) is the authentic function. */
        case T_GRAPHIC:
            return statement_graphic(p);
        case T_SCNCLR:
            return statement_scnclr(p);
        case T_DRAW:
            return statement_draw(p);
        case T_BOX:
            return statement_box(p);
        case T_CIRCLE:
            return statement_circle(p);
        case T_PAINT:
            return statement_paint(p);
        case T_CHAR:
            return statement_char(p);
        case T_COLOR:
            return statement_color(p);
        case T_SSHAPE:
            return statement_sshape(p);
        case T_GSHAPE:
            return statement_gshape(p);
        case T_REM:
            p->pos = statement_delimiter(vm, p->pos);
            while (p->pos < vm->program_end && vm->ram[p->pos] != 0) p->pos++;
            return 0;
        case T_CLR:
            memset(vm->variables, 0, sizeof(vm->variables));
            vm->variable_count = 0;
            vm->gosub_depth = 0;
            vm->for_depth = 0;
            return 0;
        case T_RUN:
            vm->gosub_depth = 0;
            vm->for_depth = 0;
            memset(vm->variables, 0, sizeof(vm->variables));
            vm->variable_count = 0;
            return prepare_line(vm, vm->first_line_address) < 0 ? -1 : 1;
        default: {
            char msg[80];
            snprintf(msg, sizeof(msg), "unsupported BASIC token $%02X", (unsigned)token);
            vm_syntax_error(vm, msg);
            return -1;
        }
    }
}

CBMVM *cbmvm_create(const CBMVM_HOST *host)
{
    CBMVM *vm = (CBMVM *)calloc(1, sizeof(CBMVM));
    if (!vm) return NULL;
    vm->ram = (uint8_t *)calloc(1, CBMVM_RAM_SIZE);
    if (!vm->ram) { free(vm); return NULL; }
    vm->ram_size = CBMVM_RAM_SIZE;
    if (host) vm->host = *host;
    cbmvm_reset(vm);
    return vm;
}

void cbmvm_destroy(CBMVM *vm)
{
    if (!vm) return;
    free(vm->ram);
    vm->ram = NULL;
    free(vm);
}

int cbmvm_reset(CBMVM *vm)
{
    if (!vm || !vm->ram) return CBMVM_ERR;
    vm->line_address = vm->first_line_address;
    vm->next_line_address = 0;
    vm->pc = 0;
    vm->line_number = 0;
    vm->halted = 0;
    vm->error = 0;
    vm->instructions = 0;
    vm->variable_count = 0;
    vm->gosub_depth = 0;
    vm->for_depth = 0;
    vm->print_column = 0;
    vm->error_message[0] = 0;
    memset(vm->variables, 0, sizeof(vm->variables));
    cbmvm_graphics_reset(&vm->graphics);
    if (vm->first_line_address) return prepare_line(vm, vm->first_line_address);
    return CBMVM_OK;
}

int cbmvm_load_prg(CBMVM *vm, const void *data, size_t length)
{
    const uint8_t *src = (const uint8_t *)data;
    uint16_t load;
    size_t payload;
    if (!vm || !src || length < 6) return CBMVM_ERR;
    load = rd16(src);
    payload = length - 2;
    if ((size_t)load + payload > vm->ram_size) { vm_set_error(vm, "PRG does not fit guest RAM"); return CBMVM_ERR; }
    memset(vm->ram, 0, vm->ram_size);
    memcpy(vm->ram + load, src + 2, payload);
    vm->load_address = load;
    vm->first_line_address = load;
    vm->program_end = (uint16_t)(load + payload);
    if ((size_t)load + payload == 65536u) vm->program_end = 0xffffu;
    if (load != CBMVM_C64_BASIC_START && load != CBMVM_C128_BASIC_START && vm->debug)
        vm_puts(vm, "[CBMVM] warning: unusual BASIC load address\n");
    if (cbmvm_validate_basic_program(vm) < 0) return CBMVM_ERR;
    return cbmvm_reset(vm);
}

#ifndef JTMOS
int cbmvm_load_prg_file(CBMVM *vm, const char *filename)
{
    FILE *f;
    long n;
    uint8_t *buf;
    int rc;
    if (!filename) return CBMVM_ERR;
    f = fopen(filename, "rb");
    if (!f) { vm_set_error(vm, "cannot open PRG file"); return CBMVM_ERR; }
    if (fseek(f, 0, SEEK_END) != 0 || (n = ftell(f)) < 0 || fseek(f, 0, SEEK_SET) != 0) { fclose(f); vm_set_error(vm, "cannot size PRG file"); return CBMVM_ERR; }
    buf = (uint8_t *)malloc((size_t)n);
    if (!buf) { fclose(f); vm_set_error(vm, "out of host memory"); return CBMVM_ERR; }
    if (fread(buf, 1, (size_t)n, f) != (size_t)n) { free(buf); fclose(f); vm_set_error(vm, "cannot read PRG file"); return CBMVM_ERR; }
    fclose(f);
    rc = cbmvm_load_prg(vm, buf, (size_t)n);
    free(buf);
    return rc;
}
#endif

int cbmvm_validate_basic_program(CBMVM *vm)
{
    uint16_t a;
    unsigned int guard = 0;
    if (!vm || !vm->ram || !vm->first_line_address) return CBMVM_ERR;
    a = vm->first_line_address;
    while (guard++ < 32768u) {
        uint16_t next;
        uint16_t p;
        if ((size_t)a + 4u > vm->ram_size || a >= vm->program_end) { vm_set_error(vm, "invalid BASIC line address"); return CBMVM_ERR; }
        next = rd16(&vm->ram[a]);
        p = (uint16_t)(a + 4);
        while (p < vm->program_end && vm->ram[p] != 0) p++;
        if (p >= vm->program_end) { vm_set_error(vm, "unterminated BASIC line"); return CBMVM_ERR; }
        if (next == 0) return CBMVM_OK;
        if (next <= a || next >= vm->program_end || next < p + 1u) { vm_set_error(vm, "invalid BASIC next-line pointer"); return CBMVM_ERR; }
        a = next;
    }
    vm_set_error(vm, "BASIC line-chain loop");
    return CBMVM_ERR;
}

int cbmvm_step(CBMVM *vm)
{
    PARSER p;
    int rc;
    if (!vm || vm->error) return CBMVM_ERR;
    if (vm->halted) return CBMVM_HALTED;

    /* Move over line terminators and colon separators before executing. */
    for (;;) {
        if (vm->pc >= vm->program_end) { vm->halted = 1; return CBMVM_HALTED; }
        if (vm->ram[vm->pc] == ':') { vm->pc++; continue; }
        if (vm->ram[vm->pc] == 0) {
            rc = advance_line(vm);
            if (rc != CBMVM_OK) return rc;
            continue;
        }
        break;
    }

    p.vm = vm;
    p.pos = vm->pc;
    rc = execute_statement(vm, &p);
    vm->instructions++;
    if (rc < 0 || vm->error) return CBMVM_ERR;
    if (vm->halted) return CBMVM_HALTED;

    /* rc==1 means the statement changed control flow and already set vm->pc. */
    if (rc == 0) vm->pc = p.pos;

    return CBMVM_OK;
}

int cbmvm_run(CBMVM *vm, unsigned int statement_budget)
{
    unsigned int i;
    int rc;
    if (!statement_budget) statement_budget = CBMVM_DEFAULT_BUDGET;
    for (i = 0; i < statement_budget; i++) {
        rc = cbmvm_step(vm);
        if (rc != CBMVM_OK) return rc;
    }
    if (vm->host.yield) vm->host.yield(vm->host.userdata);
    return CBMVM_YIELDED;
}

int cbmvm_poke(CBMVM *vm, uint16_t address, uint8_t value)
{
    if (!vm || !vm->ram) return CBMVM_ERR;
    vm->ram[address] = value;
    if (vm->host.io_write) vm->host.io_write(vm->host.userdata, address, value);
    return CBMVM_OK;
}

int cbmvm_peek(CBMVM *vm, uint16_t address, uint8_t *value)
{
    uint8_t v;
    if (!vm || !vm->ram || !value) return CBMVM_ERR;
    v = vm->ram[address];
    if (vm->host.io_read) {
        uint8_t io = v;
        if (vm->host.io_read(vm->host.userdata, address, &io) == 0) v = io;
    }
    *value = v;
    return CBMVM_OK;
}

int cbmvm_graphic_mode(const CBMVM *vm)
{
    return vm ? vm->graphics.mode : -1;
}

uint8_t cbmvm_graphic_pixel(const CBMVM *vm, int x, int y)
{
    return vm ? cbmvm_graphics_get_pixel(&vm->graphics, x, y) : 0;
}

const CBMVM_GRAPHICS *cbmvm_graphic_state(const CBMVM *vm)
{
    return vm ? &vm->graphics : NULL;
}

void cbmvm_graphic_tick(CBMVM *vm, unsigned int ticks)
{
    int i;
    if (!vm) return;
    cbmvm_graphics_tick(&vm->graphics, ticks);
    for (i=0;i<CBMVM_SPRITE_COUNT;i++) if (vm->graphics.sprites[i].enabled) vm_sprite_present(vm,i);
}

const char *cbmvm_last_error(const CBMVM *vm)
{
    return vm ? vm->error_message : "CBMVM is NULL";
}

void cbmvm_set_debug(CBMVM *vm, int enabled)
{
    if (vm) vm->debug = enabled != 0;
}

size_t cbmvm_instance_bytes(const CBMVM *vm)
{
    return vm ? sizeof(*vm) + vm->ram_size : 0;
}

#ifndef JTMOS
static void stdio_putc(void *userdata, int ch)
{
    (void)userdata;
    putchar(ch);
    fflush(stdout);
}

static int stdio_getc(void *userdata)
{
    (void)userdata;
    return getchar();
}

static int stdio_io_write(void *userdata, uint16_t address, uint8_t value)
{
    (void)userdata;
    if (address == C64_BORDER) fprintf(stderr, "[CBMVM] border=%u\n", (unsigned)value);
    else if (address == C64_BG) fprintf(stderr, "[CBMVM] background=%u\n", (unsigned)value);
    return 0;
}

int start_cbmvm_engine(int argc, char **argv)
{
    CBMVM_HOST host;
    CBMVM *vm;
    int rc;
    if (argc < 2) return 1;
    memset(&host, 0, sizeof(host));
    host.putc = stdio_putc;
    host.getc = stdio_getc;
    host.io_write = stdio_io_write;
    vm = cbmvm_create(&host);
    if (!vm) return 2;
    rc = cbmvm_load_prg_file(vm, argv[1]);
    if (rc == CBMVM_OK) {
        do { rc = cbmvm_run(vm, CBMVM_DEFAULT_BUDGET); } while (rc == CBMVM_YIELDED);
    }
    if (rc == CBMVM_ERR) fprintf(stderr, "%s\n", cbmvm_last_error(vm));
    cbmvm_destroy(vm);
    return rc == CBMVM_ERR ? 3 : 0;
}
#else
int start_cbmvm_engine(int argc, char **argv)
{
    (void)argc; (void)argv;
    return CBMVM_ERR;
}
#endif
