# CBMVM / JTMOS MiniVM roadmap

## Phase 1 — completed in 0.2

- compact 64 KiB guest VM
- safe PRG loader/validator
- host abstraction
- budgeted step/run API
- expression parser with precedence
- assignments, PRINT, GOTO, IF, GOSUB/RETURN, FOR/NEXT, POKE/PEEK
- JTMOS virtual-video bridge
- regression tests

## Phase 2 — BASIC compatibility

1. `INPUT`, `GET` using non-blocking host keyboard callbacks.
2. `DIM` and numeric/string arrays.
3. `DATA`, `READ`, `RESTORE` with a pre-indexed DATA cursor.
4. `ON ... GOTO/GOSUB`.
5. More functions: `LEN`, `VAL`, `STR$`, `ASC`, `CHR$`, `LEFT$`, `RIGHT$`, `MID$`, `SQR`, trig, `RND`.
6. Correct Commodore two-significant-character variable-name compatibility mode.
7. PETSCII-to-Unicode/GraOS character mapping.
8. C64 numeric edge cases and error messages.

## Phase 3 — interactive BASIC computer

- direct-mode command parser (`PRINT 1+1` without a line number)
- editable program store: `10 PRINT ...`, `LIST`, `NEW`, `RUN`
- `LOAD`/`SAVE` through sandboxed JTMOS VFS callbacks
- GraOS `cbasic` application with 40x25 screen, cursor and keyboard
- virtual device 8 mapped to a per-VM JTMOS directory

## Phase 4 — virtual devices

Add a device bus rather than hardcoding new POKE cases:

```c
typedef struct {
    uint16_t first, last;
    int (*read)(...);
    int (*write)(...);
} CBMVM_DEVICE;
```

Possible devices:

- VIC-like text/framebuffer adapter
- SID-like simple sound adapter mapped to JTMOS audio IPC
- timer/clock registers
- keyboard matrix
- virtual serial device

The implementation should emulate useful semantics, not expose physical hardware.

## Phase 5 — snapshot/debugger

- save/restore VM RAM + variables + stacks + PC
- single-step BASIC statements
- breakpoints by BASIC line number
- watch variable / watch POKE address
- instruction/statements-per-second counter
- deterministic replay of keyboard input

A snapshot should be a portable VM data format, not a dump of C pointers.

## Phase 6 — general JTMOS MiniVM

After BASIC is stable, split the execution substrate into an optional bytecode VM. BASIC becomes one frontend.

Suggested bytecode groups:

- stack: `PUSH8/16/32`, `DROP`, `DUP`
- memory: `LOAD8/16/32`, `STORE8/16/32`
- arithmetic: `ADD`, `SUB`, `MUL`, `DIV`, shifts/logic
- flow: `JMP`, `JZ`, `CALL`, `RET`, `HALT`
- host gateway: a capability-checked `SYS` instruction

Do **not** make `SYS` a raw JTMOS syscall number. A VM receives a capability table (console, one directory, one GraOS window, optional audio, etc.), and `SYS` addresses only that table.

This would allow small sandboxed JTMOS applications without introducing a second native executable format immediately.

## Phase 7 — optional 6502 backend

A real 6502 interpreter can later be attached to the same 64 KiB memory/device bus. Keep it optional: token BASIC remains dramatically smaller and faster for BASIC programs, while the 6502 backend enables machine-code PRGs and ROM-level C64 compatibility.

## Phase 2.5 — graphics compatibility after 0.3

The first BASIC 7 graphics layer is now implemented. The next graphics work should be:

1. Exact PETSCII/C128 character-ROM glyph rendering for `CHAR`.
2. Byte-compatible C128 `SSHAPE/GSHAPE` encoding, while retaining the current safe internal decoder for old CBMVM snapshots.
3. `LOCATE`, `RDOT`, `RCLR`, `SCALE`, and `WIDTH` to complete the non-sprite graphics command family.
4. `SPRCOLOR`, `SPRSAV`, `RSPRITE`, `RSPPOS`, and `RSPCOLOR`.
5. Sprite collision masks and `BUMP`/`COLLISION` callbacks.
6. Dirty rectangles so GraOS only redraws changed bitmap areas instead of receiving a full-present notification for every graphics statement.
7. Optional 320x200 8-bit resolved-color cache for hosts where conversion from source pixels is more expensive than memory.
8. A deterministic 50/60 Hz VM timer domain for sprite motion, sound envelopes and future `TI/TI$`.
9. Split-screen text/bitmap compositor in the reference GraOS `cbasic` application.
10. A graphics capability flag so headless CBMVM instances can reject or record graphics without allocating a presentation surface.

## Phase 3.5 — demo/game layer

Once keyboard input is implemented, add small BASIC 7 sample programs as compatibility tests:

- bouncing sprite demo
- vector starfield
- paint/shape stamp demo
- simple Breakout/Pong-style game
- rotating BOX/CIRCLE geometry demo

These demos should double as regression tests: each can hash its final packed framebuffer and sprite state so graphics behavior remains deterministic across JTMOS releases.
