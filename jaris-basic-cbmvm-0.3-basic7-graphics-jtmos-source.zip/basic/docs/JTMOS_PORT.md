# JTMOS / GraOS integration plan

## Process model

Run one `CBMVM` instance per JTMOS BASIC process/window. The VM owns a fixed 64 KiB guest address space plus bounded interpreter/graphics state. BASIC never receives a JTMOS pointer.

Recommended scheduler/UI loop:

```c
while (!closing) {
    int rc = cbmvm_run(vm, 128);

    if (frame_timer_fired)
        cbmvm_graphic_tick(vm, 1);

    graos_dispatch_events();
    if (rc == CBMVM_HALTED || rc == CBMVM_ERR)
        break;
    process_yield();
}
```

The statement budget protects the OS from infinite BASIC loops. Animation is deliberately timer-driven instead of instruction-driven so sprite speed is independent of CPU speed.

## GraOS `cbasic` window

Recommended layout:

- 320x200 graphics surface scaled 1x/2x/fit-to-window
- optional 40x25 text overlay / text mode
- border rendered outside the virtual bitmap
- split modes 2/4 use `split_line` to place a text region below the bitmap
- keyboard events feed the future `INPUT` / direct-mode editor

The VM provides a 16,000-byte packed framebuffer. Each 2-bit pixel is a BASIC source 0..3. `colors[0..6]` maps sources/areas to BASIC color numbers 1..16. The GraOS host can expand this directly into its native framebuffer.

## Graphics binding example

```c
CBMVM_JTMOS_BINDINGS b;
CBMVM_JTMOS_CONTEXT ctx;
CBMVM_HOST host;

memset(&b, 0, sizeof(b));
b.userdata          = app;
b.console_putc      = cbasic_putc;
b.yield             = cbasic_yield;
b.set_border        = cbasic_border;
b.set_background    = cbasic_background;
b.graphics_mode     = cbasic_graphics_mode;
b.graphics_present  = cbasic_blit_sources;
b.sprite_update     = cbasic_sprite_update;
b.sprite_editor     = cbasic_sprite_editor;

cbmvm_jtmos_host_init(&ctx, &b, &host);
vm = cbmvm_create(&host);
```

`cbasic_blit_sources()` should not retain the framebuffer pointer after the callback. It can either blit immediately or mark the GraOS window dirty and copy on the same thread.

## SPRDEF

The portable core intentionally does not contain a GUI event loop. `SPRDEF` invokes the JTMOS host callback with eight `63`-byte sprite image buffers. A GraOS implementation can open a modal 24x21 editor with:

- sprite selector 1..8
- pixel cursor
- foreground / multicolor source selection
- clear, copy, x/y expansion, multicolor toggles
- Save/Cancel

Returning 0 commits the edited buffers; a negative result reports a host error.

## File model

JTMOS should read PRG data through VFS/FlexFAT and call `cbmvm_load_prg(vm, buffer, size)`. Future BASIC `LOAD`/`SAVE` should use explicit host callbacks instead of linking filesystem code into the interpreter.

## Security rules

1. PEEK/POKE only access guest memory and virtual devices.
2. No BASIC address is cast to a host pointer.
3. Graphics draw only into the VM framebuffer; GraOS sees it through callbacks.
4. No raw JTMOS syscall token.
5. Future file access goes through sandboxed host callbacks.
6. Execution is statement-budgeted and cooperative.
7. Stack/variable/string/framebuffer sizes are hard-bounded.
8. Corrupt PRG line chains are rejected before execution.
9. PAINT has a bounded scanline work stack.
10. `SPRDEF` edits copies of sprite data; the host never receives VM RAM pointers.
