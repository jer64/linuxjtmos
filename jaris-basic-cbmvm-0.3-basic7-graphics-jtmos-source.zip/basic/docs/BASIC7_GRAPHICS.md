# BASIC 7.0 graphics support in CBMVM

CBMVM implements a compact C128-style graphics layer without emulating the VIC-II/VDC chips. Graphics commands modify a sandboxed virtual framebuffer and sprite state; a JTMOS/GraOS host receives presentation callbacks.

## Virtual display

- logical framebuffer: 320 x 200
- storage: 2 bits per pixel (four color-source pixels per byte)
- framebuffer size: 16,000 bytes
- pixels store BASIC color **sources** 0..3, not host RGB values
- `COLOR` maps each source to one of the 16 Commodore palette indices
- modes 3/4 accept multicolor x coordinates and expand them horizontally into the 320-pixel backing buffer

This design keeps the VM small and lets GraOS choose its native output format (8/16/24/32 bpp) when `graphics_present` fires.

## Implemented commands/functions

### Screen and mode

- `GRAPHIC mode[,clear][,split]`, modes 0..5
- `GRAPHIC CLR` (returns the compact VM to text mode; no host memory relocation is needed)
- `RGR(dummy)` returns the current mode
- CBMVM extension: statement-form `RGR mode` is accepted as a convenient alias for switching mode
- `SCNCLR`

### Drawing

- `DRAW [source],x,y [TO x,y]...`
- `DRAW TO x,y` from the current pixel cursor
- `BOX [source],x1,y1[,x2,y2][,angle][,paint]`
- `CIRCLE [source],x,y,xr[,yr][,start][,end][,rotation][,increment]`
- `PAINT [source],x,y[,mode]`
- `CHAR source,column,row[,string][,reverse]`

BOX rotation is implemented around its centre. CIRCLE supports ellipses, arcs and coarse polygon increments. PAINT uses a bounded scanline flood-fill stack so pathological guest programs cannot allocate arbitrary host memory.

### Colors and shapes

- `COLOR source,color` for sources 0..6 and colors 1..16
- `SSHAPE A$,x1,y1[,x2,y2]`
- `GSHAPE A$[,x,y][,mode]`, modes replace/invert/OR/AND/XOR

CBMVM strings are now binary-safe and support up to 255 data bytes plus a terminating host byte. Shape strings use a compact CBMVM 4-byte header plus packed 2-bit pixel data. Command semantics are compatible with BASIC 7.0, but the current shape byte format is intentionally documented as **CBMVM-internal**, not promised as byte-identical to C128 ROM SSHAPE output.

### Sprites

- `SPRITE number[,on][,color][,priority][,x-expand][,y-expand][,multicolor]`
- `MOVSPR number,x,y`
- relative `MOVSPR number,+x,-y`
- motion `MOVSPR number,angle#speed`
- polar relative `MOVSPR number,distance;angle`
- `SPRDEF`

Each of the eight virtual sprites stores 63 bytes of image data plus its C128-style attributes and motion state. `cbmvm_graphic_tick()` advances angle/speed motion independently of BASIC statement execution, so a GraOS timer can drive smooth animation.

`SPRDEF` is host-assisted: the VM copies all eight sprite images into the `sprite_editor` callback and copies edited data back when the host returns. This keeps GraOS window/event code outside the portable VM core.

## JTMOS rendering loop

A GraOS application can use roughly this structure:

```c
for (;;) {
    int rc = cbmvm_run(vm, 128);

    /* call from a timer, ideally around the UI refresh rate */
    cbmvm_graphic_tick(vm, 1);

    graos_dispatch_events();
    if (rc == CBMVM_HALTED || rc == CBMVM_ERR)
        break;
    process_yield();
}
```

`graphics_present` receives a pointer to the packed 320x200 source buffer, the seven source colors, mode and split line. The host can expand each source pixel to a GraOS palette/RGBA pixel while blitting.

## Deliberate simplifications

This is a graphics VM, not cycle-accurate C128 video emulation. Current differences include:

- no VIC-II 8x8-cell color restrictions
- no real bitmap RAM relocation on `GRAPHIC CLR`
- the built-in CHAR fallback is a compact 5x7 ASCII-like font rather than exact C128 character ROM PETSCII
- sprite collision registers and hardware timing are not yet emulated
- shape-string bytes are currently CBMVM-specific

These choices make graphics predictable, sandboxed and suitable for JTMOS while leaving a path to stricter compatibility later.
