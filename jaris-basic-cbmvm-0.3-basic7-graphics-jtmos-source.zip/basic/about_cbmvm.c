#include <stdio.h>
#include "about_cbmvm.h"

int about_cbmvm(void)
{
    printf("CBMVM 0.2 - compact tokenized Commodore BASIC VM.\n");
    printf("Usage: cbmvm program.prg\n");
    printf("The PRG must contain a standard linked BASIC program image.\n");
    return 0;
}
