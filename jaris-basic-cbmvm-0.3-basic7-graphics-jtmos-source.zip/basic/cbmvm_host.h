#ifndef CBMVM_HOST_H
#define CBMVM_HOST_H

#include <stddef.h>
#include <stdint.h>

typedef struct CBMVM_HOST {
    void *userdata;
    void (*putc)(void *userdata, int ch);
    int  (*getc)(void *userdata);                 /* -1 if no character is available */
    void (*yield)(void *userdata);                /* cooperative scheduler hook */
    int  (*io_write)(void *userdata, uint16_t address, uint8_t value);
    int  (*io_read)(void *userdata, uint16_t address, uint8_t *value);
    void (*screen_clear)(void *userdata);
    void (*graphics_mode)(void *userdata, int mode, int split_line);
    void (*graphics_color)(void *userdata, int source, int color);
    int  (*sprite_editor)(void *userdata, uint8_t sprite_data[8][63]);
    void (*graphics_present)(void *userdata, const uint8_t *packed_pixels, size_t bytes,
                             int width, int height, const uint8_t colors[7],
                             int mode, int split_line);
    void (*sprite_update)(void *userdata, int number, int enabled, int x, int y,
                          int color, int priority, int x_expand, int y_expand,
                          int multicolor, const uint8_t data[63]);
} CBMVM_HOST;

#endif
