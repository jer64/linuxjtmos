#!/usr/bin/env python3
"""Generate valid C64 BASIC V2 PRGs used by CBMVM tests."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / 'examples'

LOAD = 0x0801
TOK = {
    'END':0x80,'FOR':0x81,'NEXT':0x82,'LET':0x88,'GOTO':0x89,'IF':0x8b,
    'GOSUB':0x8d,'RETURN':0x8e,'POKE':0x97,'PRINT':0x99,
    'TO':0xa4,'THEN':0xa7,'STEP':0xa9,'PLUS':0xaa,'MUL':0xac,'EQ':0xb2,
    'GT':0xb1,'PEEK':0xc2,'RGR':0xcc,'GRAPHIC':0xde,'PAINT':0xdf,
    'CHAR':0xe0,'BOX':0xe1,'CIRCLE':0xe2,'GSHAPE':0xe3,'SSHAPE':0xe4,
    'DRAW':0xe5,'COLOR':0xe7,'SCNCLR':0xe8,
}

def prg(lines, load=LOAD):
    chunks=[]
    address=load
    bodies=[]
    for line_no, body in lines:
        body=bytes(body)
        size=2+2+len(body)+1
        next_addr=address+size
        bodies.append((address,next_addr,line_no,body))
        address=next_addr
    out=bytearray((load & 255, load >> 8))
    for i,(address,next_addr,line_no,body) in enumerate(bodies):
        nxt=0 if i == len(bodies)-1 else next_addr
        out += bytes((nxt & 255, nxt >> 8, line_no & 255, line_no >> 8))
        out += body + b'\0'
    return bytes(out)

def A(s): return s.encode('ascii')

def write(name, lines, load=LOAD):
    (EXAMPLES / name).write_bytes(prg(lines, load))

def EXT(code): return bytes((0xfe, code))

write('hello.prg', [
    (10, bytes([TOK['PRINT']])+A(' "HELLO WORLD"')),
    (20, bytes([TOK['END']])),
])
write('counting.prg', [
    (10, A('A')+bytes([TOK['EQ']])+A('0')),
    (20, bytes([TOK['PRINT']])+A(' A')),
    (30, A('A')+bytes([TOK['EQ']])+A('A')+bytes([TOK['PLUS']])+A('1')),
    (40, bytes([TOK['IF']])+A(' A')+bytes([TOK['GT']])+A('5 ')+bytes([TOK['THEN']])+A(' 60')),
    (50, bytes([TOK['GOTO']])+A(' 20')),
    (60, bytes([TOK['END']])),
])
write('printdemo1.prg', [
    (10, bytes([TOK['PRINT']])+A(' "HELLO WORLD"')),
    (20, bytes([TOK['POKE']])+A(' 53280,7')),
    (30, bytes([TOK['POKE']])+A(' 53281,0')),
    (40, bytes([TOK['END']])),
])
write('printdemo2.prg', [
    (10, bytes([TOK['PRINT']])+A(' "hello world ";')),
    (20, bytes([TOK['PRINT']])+A(' "again"')),
    (30, bytes([TOK['END']])),
])
write('fornext.prg', [
    (10, bytes([TOK['FOR']])+A(' I')+bytes([TOK['EQ']])+A('1 ')+bytes([TOK['TO']])+A(' 3')),
    (20, bytes([TOK['PRINT']])+A(' I')),
    (30, bytes([TOK['NEXT']])+A(' I')),
    (40, bytes([TOK['END']])),
])
write('gosub.prg', [
    (10, bytes([TOK['GOSUB']])+A(' 100')),
    (20, bytes([TOK['PRINT']])+A(' "DONE"')),
    (30, bytes([TOK['END']])),
    (100, bytes([TOK['PRINT']])+A(' "SUB"')),
    (110, bytes([TOK['RETURN']])),
])
write('peekpoke.prg', [
    (10, bytes([TOK['POKE']])+A(' 1000,42')),
    (20, bytes([TOK['PRINT']])+A(' ')+bytes([TOK['PEEK']])+A('(1000)')),
    (30, bytes([TOK['END']])),
])

write('math.prg', [
    (10, A('A')+bytes([TOK['EQ']])+A('2')+bytes([TOK['PLUS']])+A('3')+bytes([TOK['MUL']])+A('4')),
    (20, bytes([TOK['PRINT']])+A(' A')),
    (30, bytes([TOK['END']])),
])
write('forstep.prg', [
    (10, bytes([TOK['FOR']])+A(' I')+bytes([TOK['EQ']])+A('5 ')+bytes([TOK['TO']])+A(' 1 ')+bytes([TOK['STEP']])+A(' -2')),
    (20, bytes([TOK['PRINT']])+A(' I')),
    (30, bytes([TOK['NEXT']])+A(' I')),
    (40, bytes([TOK['END']])),
])
write('infinite.prg', [
    (10, bytes([TOK['GOTO']])+A(' 10')),
])


# C128 BASIC 7.0 graphics / sprite demo. These use the real extension token bytes.

write('sprdef.prg', [
    (10, EXT(0x1d)),
    (20, bytes([TOK['END']])),
], load=0x1c01)

write('scnclr.prg', [
    (10, bytes([TOK['GRAPHIC']])+A(' 1,1')),
    (20, bytes([TOK['DRAW']])+A(' 1,10,10')),
    (30, bytes([TOK['SCNCLR']])),
    (40, bytes([TOK['END']])),
], load=0x1c01)
write('graphics_demo.prg', [
    (10, bytes([TOK['COLOR']])+A(' 0,1')),
    (20, bytes([TOK['COLOR']])+A(' 1,2')),
    (30, bytes([TOK['COLOR']])+A(' 4,7')),
    (40, bytes([TOK['GRAPHIC']])+A(' 1,1')),
    (50, bytes([TOK['BOX']])+A(' 1,5,5,314,194')),
    (60, bytes([TOK['CIRCLE']])+A(' 1,160,95,50,30')),
    (70, bytes([TOK['PAINT']])+A(' 1,160,95')),
    (80, bytes([TOK['DRAW']])+A(' 1,20,170 ')+bytes([TOK['TO']])+A(' 300,170 ')+bytes([TOK['TO']])+A(' 160,20 ')+bytes([TOK['TO']])+A(' 20,170')),
    (90, bytes([TOK['CHAR']])+A(' 1,8,22,"JTMOS BASIC 7"')),
    (100, bytes([TOK['BOX']])+A(' 1,145,75,168,95,0,1')),
    (110, bytes([TOK['SSHAPE']])+A(' A$,145,75,168,95')),
    (120, bytes([TOK['GSHAPE']])+A(' A$,250,30,4')),
    (130, EXT(0x07)+A(' 1,1,3,0,0,0,0')),
    (140, EXT(0x06)+A(' 1,100,80')),
    (150, bytes([TOK['PRINT'],TOK['RGR']])+A('(0)')),
    (160, bytes([TOK['END']])),
], load=0x1c01)

write('sprite_motion.prg', [
    (10, EXT(0x07)+A(' 1,1,3,0,0,0,0')),
    (20, EXT(0x06)+A(' 1,100,80')),
    (30, EXT(0x06)+A(' 1,90#2')),
    (40, bytes([TOK['END']])),
], load=0x1c01)

print('generated', len(list(EXAMPLES.glob('*.prg'))), 'PRG files')
