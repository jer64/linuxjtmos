#include <stdio.h>
#ifndef JTMOS
#include "about_cbmvm.h"
#include "cbmvm_engine.h"

int main(int argc, char **argv)
{
    if (argc < 2) {
        about_cbmvm();
        return 0;
    }
    return start_cbmvm_engine(argc, argv);
}
#endif
