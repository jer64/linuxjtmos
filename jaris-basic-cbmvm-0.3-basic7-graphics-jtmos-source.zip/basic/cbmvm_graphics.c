#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "cbmvm_graphics.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define PAINT_STACK_MAX 4096

typedef struct { int x, y; } GFX_POINT;

static int clampi(int v, int lo, int hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static size_t pixel_index(int x, int y)
{
    return (size_t)y * CBMVM_GFX_WIDTH + (size_t)x;
}

static uint8_t packed_get(const uint8_t *p, size_t index)
{
    unsigned int shift = (unsigned int)((index & 3u) * 2u);
    return (uint8_t)((p[index >> 2] >> shift) & 3u);
}

static void packed_set(uint8_t *p, size_t index, uint8_t source)
{
    unsigned int shift = (unsigned int)((index & 3u) * 2u);
    uint8_t mask = (uint8_t)(3u << shift);
    p[index >> 2] = (uint8_t)((p[index >> 2] & (uint8_t)~mask) | ((source & 3u) << shift));
}

void cbmvm_graphics_reset(CBMVM_GRAPHICS *g)
{
    static const uint8_t defaults[CBMVM_GFX_COLOR_SOURCES] = { 1, 2, 3, 7, 1, 2, 1 };
    unsigned int i;
    if (!g) return;
    memset(g, 0, sizeof(*g));
    memcpy(g->color, defaults, sizeof(defaults));
    g->mode = 0;
    g->split_line = 19;
    g->pen_source = 1;
    for (i = 0; i < CBMVM_SPRITE_COUNT; i++) {
        g->sprites[i].color = 2;
        g->sprites[i].x = 0;
        g->sprites[i].y = 0;
    }
}

void cbmvm_graphics_clear(CBMVM_GRAPHICS *g, uint8_t source)
{
    uint8_t pattern;
    if (!g) return;
    source &= 3u;
    pattern = (uint8_t)(source | (source << 2) | (source << 4) | (source << 6));
    memset(g->pixels, pattern, sizeof(g->pixels));
    g->cursor_x = 0;
    g->cursor_y = 0;
    g->pen_source = source;
    g->generation++;
}

int cbmvm_graphics_set_mode(CBMVM_GRAPHICS *g, int mode, int clear, int split_line)
{
    if (!g || mode < 0 || mode > 5) return -1;
    g->mode = (uint8_t)mode;
    if (split_line >= 0) g->split_line = (uint8_t)clampi(split_line, 0, 24);
    else if (mode == 2 || mode == 4) g->split_line = 19;
    if (clear) cbmvm_graphics_clear(g, 0);
    g->generation++;
    return 0;
}

int cbmvm_graphics_set_color(CBMVM_GRAPHICS *g, int source, int color)
{
    if (!g || source < 0 || source >= CBMVM_GFX_COLOR_SOURCES || color < 1 || color > 16) return -1;
    g->color[source] = (uint8_t)color;
    g->generation++;
    return 0;
}

uint8_t cbmvm_graphics_get_pixel(const CBMVM_GRAPHICS *g, int x, int y)
{
    if (!g || x < 0 || x >= CBMVM_GFX_WIDTH || y < 0 || y >= CBMVM_GFX_HEIGHT) return 0;
    return packed_get(g->pixels, pixel_index(x, y));
}

void cbmvm_graphics_put_pixel(CBMVM_GRAPHICS *g, int x, int y, uint8_t source)
{
    if (!g || x < 0 || x >= CBMVM_GFX_WIDTH || y < 0 || y >= CBMVM_GFX_HEIGHT) return;
    packed_set(g->pixels, pixel_index(x, y), source);
    g->cursor_x = (int16_t)x;
    g->cursor_y = (int16_t)y;
    g->pen_source = source & 3u;
    g->generation++;
}

void cbmvm_graphics_line(CBMVM_GRAPHICS *g, int x0, int y0, int x1, int y1, uint8_t source)
{
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;
    if (!g) return;
    for (;;) {
        if (x0 >= 0 && x0 < CBMVM_GFX_WIDTH && y0 >= 0 && y0 < CBMVM_GFX_HEIGHT)
            packed_set(g->pixels, pixel_index(x0, y0), source);
        if (x0 == x1 && y0 == y1) break;
        {
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x0 += sx; }
            if (e2 <= dx) { err += dx; y0 += sy; }
        }
    }
    g->cursor_x = (int16_t)x1;
    g->cursor_y = (int16_t)y1;
    g->pen_source = source & 3u;
    g->generation++;
}

static void rotate_point(double cx, double cy, double angle, double x, double y, int *ox, int *oy)
{
    double r = angle * M_PI / 180.0;
    double c = cos(r), s = sin(r);
    double dx = x - cx, dy = y - cy;
    *ox = (int)lrint(cx + dx * c - dy * s);
    *oy = (int)lrint(cy + dx * s + dy * c);
}

static void fill_polygon(CBMVM_GRAPHICS *g, const GFX_POINT *p, int n, uint8_t source)
{
    int y, miny = CBMVM_GFX_HEIGHT - 1, maxy = 0;
    int nodes[16];
    int i, j;
    for (i = 0; i < n; i++) { miny = p[i].y < miny ? p[i].y : miny; maxy = p[i].y > maxy ? p[i].y : maxy; }
    miny = clampi(miny, 0, CBMVM_GFX_HEIGHT - 1);
    maxy = clampi(maxy, 0, CBMVM_GFX_HEIGHT - 1);
    for (y = miny; y <= maxy; y++) {
        int count = 0;
        j = n - 1;
        for (i = 0; i < n; i++) {
            if (((p[i].y < y && p[j].y >= y) || (p[j].y < y && p[i].y >= y)) && p[j].y != p[i].y) {
                if (count < (int)(sizeof(nodes)/sizeof(nodes[0])))
                    nodes[count++] = p[i].x + (y - p[i].y) * (p[j].x - p[i].x) / (p[j].y - p[i].y);
            }
            j = i;
        }
        for (i = 0; i + 1 < count; i++) {
            int k;
            for (k = i + 1; k < count; k++) if (nodes[k] < nodes[i]) { int t = nodes[i]; nodes[i] = nodes[k]; nodes[k] = t; }
        }
        for (i = 0; i + 1 < count; i += 2) {
            int x0 = clampi(nodes[i], 0, CBMVM_GFX_WIDTH - 1);
            int x1 = clampi(nodes[i+1], 0, CBMVM_GFX_WIDTH - 1);
            int x;
            for (x = x0; x <= x1; x++) packed_set(g->pixels, pixel_index(x, y), source);
        }
    }
}

void cbmvm_graphics_box(CBMVM_GRAPHICS *g, int x1, int y1, int x2, int y2,
                        double angle, int paint, uint8_t source)
{
    GFX_POINT p[4];
    double cx, cy;
    int i;
    if (!g) return;
    cx = ((double)x1 + (double)x2) / 2.0;
    cy = ((double)y1 + (double)y2) / 2.0;
    rotate_point(cx, cy, angle, x1, y1, &p[0].x, &p[0].y);
    rotate_point(cx, cy, angle, x2, y1, &p[1].x, &p[1].y);
    rotate_point(cx, cy, angle, x2, y2, &p[2].x, &p[2].y);
    rotate_point(cx, cy, angle, x1, y2, &p[3].x, &p[3].y);
    if (paint) fill_polygon(g, p, 4, source);
    for (i = 0; i < 4; i++) {
        int j = (i + 1) & 3;
        cbmvm_graphics_line(g, p[i].x, p[i].y, p[j].x, p[j].y, source);
    }
    g->cursor_x = (int16_t)x2;
    g->cursor_y = (int16_t)y2;
    g->generation++;
}

void cbmvm_graphics_circle(CBMVM_GRAPHICS *g, int cx, int cy, int xr, int yr,
                           double start_angle, double end_angle, double rotation,
                           double increment, uint8_t source)
{
    double a, end;
    int first = 1, px = cx, py = cy;
    if (!g) return;
    if (yr < 0) yr = -yr;
    if (xr < 0) xr = -xr;
    if (yr == 0) yr = xr;
    if (increment <= 0.0) increment = 2.0;
    if (increment > 360.0) increment = 360.0;
    while (end_angle < start_angle) end_angle += 360.0;
    end = end_angle;
    for (a = start_angle; a <= end + 0.0001; a += increment) {
        double ar = a * M_PI / 180.0;
        double rr = rotation * M_PI / 180.0;
        double ex = cos(ar) * xr, ey = sin(ar) * yr;
        int x = (int)lrint(cx + ex * cos(rr) - ey * sin(rr));
        int y = (int)lrint(cy + ex * sin(rr) + ey * cos(rr));
        if (first) { packed_set(g->pixels, pixel_index(clampi(x,0,CBMVM_GFX_WIDTH-1), clampi(y,0,CBMVM_GFX_HEIGHT-1)), source); first = 0; }
        else cbmvm_graphics_line(g, px, py, x, y, source);
        px = x; py = y;
    }
    if (a - increment < end) {
        double ar = end * M_PI / 180.0, rr = rotation * M_PI / 180.0;
        double ex = cos(ar) * xr, ey = sin(ar) * yr;
        int x = (int)lrint(cx + ex * cos(rr) - ey * sin(rr));
        int y = (int)lrint(cy + ex * sin(rr) + ey * cos(rr));
        cbmvm_graphics_line(g, px, py, x, y, source);
        px = x; py = y;
    }
    g->cursor_x = (int16_t)px;
    g->cursor_y = (int16_t)py;
    g->pen_source = source & 3u;
    g->generation++;
}

int cbmvm_graphics_paint(CBMVM_GRAPHICS *g, int x, int y, uint8_t source, int mode)
{
    uint16_t stack[PAINT_STACK_MAX];
    unsigned int sp = 0;
    uint8_t target;
    if (!g || x < 0 || x >= CBMVM_GFX_WIDTH || y < 0 || y >= CBMVM_GFX_HEIGHT) return -1;
    source &= 3u;
    target = cbmvm_graphics_get_pixel(g, x, y);
    if (target == source) return 0;
    stack[sp++] = (uint16_t)(y * CBMVM_GFX_WIDTH + x);
    while (sp) {
        uint16_t idx = stack[--sp];
        int sx = idx % CBMVM_GFX_WIDTH;
        int sy = idx / CBMVM_GFX_WIDTH;
        int lx = sx, rx, nx;
        while (lx > 0) {
            uint8_t c = cbmvm_graphics_get_pixel(g, lx - 1, sy);
            if ((mode == 0 && c != target) || (mode != 0 && c != 0)) break;
            lx--;
        }
        rx = lx;
        while (rx < CBMVM_GFX_WIDTH) {
            uint8_t c = cbmvm_graphics_get_pixel(g, rx, sy);
            if ((mode == 0 && c != target) || (mode != 0 && c != 0)) break;
            packed_set(g->pixels, pixel_index(rx, sy), source);
            rx++;
        }
        for (nx = lx; nx < rx; nx++) {
            int yy;
            for (yy = sy - 1; yy <= sy + 1; yy += 2) {
                uint8_t c;
                if (yy < 0 || yy >= CBMVM_GFX_HEIGHT) continue;
                c = cbmvm_graphics_get_pixel(g, nx, yy);
                if ((mode == 0 && c == target) || (mode != 0 && c == 0)) {
                    if (sp >= PAINT_STACK_MAX) return -2;
                    stack[sp++] = (uint16_t)(yy * CBMVM_GFX_WIDTH + nx);
                    while (nx + 1 < rx) {
                        uint8_t c2 = cbmvm_graphics_get_pixel(g, nx + 1, yy);
                        if (!((mode == 0 && c2 == target) || (mode != 0 && c2 == 0))) break;
                        nx++;
                    }
                }
            }
        }
    }
    g->cursor_x = (int16_t)x;
    g->cursor_y = (int16_t)y;
    g->pen_source = source;
    g->generation++;
    return 0;
}

/* Compact 5x7 glyphs. Each row uses low five bits; lowercase maps to uppercase. */
static const uint8_t *glyph5x7(unsigned char ch)
{
    static const uint8_t blank[7] = {0,0,0,0,0,0,0};
    static const uint8_t punct_dot[7] = {0,0,0,0,0,0,4};
    static const uint8_t punct_dash[7] = {0,0,0,31,0,0,0};
    static const uint8_t digits[10][7] = {
        {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},{30,1,1,14,1,1,30},{2,6,10,18,31,2,2},
        {31,16,16,30,1,1,30},{14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},{14,17,17,15,1,1,14}
    };
    static const uint8_t letters[26][7] = {
        {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},{30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},
        {14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},{7,2,2,2,2,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
        {17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},{30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},
        {15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},{17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},
        {17,17,10,4,4,4,4},{31,1,2,4,8,16,31}
    };
    if (ch >= 'a' && ch <= 'z') ch = (unsigned char)(ch - 'a' + 'A');
    if (ch >= '0' && ch <= '9') return digits[ch-'0'];
    if (ch >= 'A' && ch <= 'Z') return letters[ch-'A'];
    if (ch == '.') return punct_dot;
    if (ch == '-') return punct_dash;
    return blank;
}

void cbmvm_graphics_char(CBMVM_GRAPHICS *g, int column, int row, unsigned char ch,
                         uint8_t source, int reverse)
{
    const uint8_t *glyph;
    int base_x = column * 8, base_y = row * 8;
    int yy, xx;
    if (!g) return;
    glyph = glyph5x7(ch);
    for (yy = 0; yy < 8; yy++) {
        uint8_t bits = yy < 7 ? glyph[yy] : 0;
        for (xx = 0; xx < 8; xx++) {
            int on = xx < 5 ? ((bits >> (4 - xx)) & 1) : 0;
            if (reverse) on = !on;
            if (on) cbmvm_graphics_put_pixel(g, base_x + xx, base_y + yy, source);
            else if (reverse) cbmvm_graphics_put_pixel(g, base_x + xx, base_y + yy, 0);
        }
    }
}

void cbmvm_graphics_text(CBMVM_GRAPHICS *g, int column, int row,
                         const unsigned char *text, size_t length,
                         uint8_t source, int reverse)
{
    size_t i;
    int x = column, y = row;
    if (!g || !text) return;
    for (i = 0; i < length; i++) {
        if (text[i] == '\n' || x >= 40) { x = 0; y++; if (text[i] == '\n') continue; }
        if (y >= 25) break;
        cbmvm_graphics_char(g, x++, y, text[i], source, reverse);
    }
    g->cursor_x = (int16_t)(x * 8);
    g->cursor_y = (int16_t)(y * 8);
}

void cbmvm_graphics_tick(CBMVM_GRAPHICS *g, unsigned int ticks)
{
    unsigned int i;
    if (!g || !ticks) return;
    for (i = 0; i < CBMVM_SPRITE_COUNT; i++) {
        CBMVM_SPRITE *s = &g->sprites[i];
        if (s->enabled && s->moving && s->speed > 0.0) {
            double r = s->angle * M_PI / 180.0;
            double distance = s->speed * (double)ticks;
            s->x = (int16_t)lrint((double)s->x + sin(r) * distance);
            s->y = (int16_t)lrint((double)s->y - cos(r) * distance);
        }
    }
    g->generation++;
}
