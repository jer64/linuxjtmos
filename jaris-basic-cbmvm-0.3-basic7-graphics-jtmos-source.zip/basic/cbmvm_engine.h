#ifndef CBMVM_ENGINE_H
#define CBMVM_ENGINE_H

#include <stddef.h>
#include <stdint.h>
#include "cbmvm_host_variables.h"

/* Return codes for cbmvm_step/cbmvm_run. */
enum {
    CBMVM_OK = 0,
    CBMVM_HALTED = 1,
    CBMVM_YIELDED = 2,
    CBMVM_ERR = -1
};

CBMVM *cbmvm_create(const CBMVM_HOST *host);
void cbmvm_destroy(CBMVM *vm);
int cbmvm_reset(CBMVM *vm);
int cbmvm_load_prg(CBMVM *vm, const void *data, size_t length);
#ifndef JTMOS
int cbmvm_load_prg_file(CBMVM *vm, const char *filename);
#endif
int cbmvm_validate_basic_program(CBMVM *vm);
int cbmvm_step(CBMVM *vm);
int cbmvm_run(CBMVM *vm, unsigned int statement_budget);

int cbmvm_poke(CBMVM *vm, uint16_t address, uint8_t value);
int cbmvm_peek(CBMVM *vm, uint16_t address, uint8_t *value);

int cbmvm_graphic_mode(const CBMVM *vm);
uint8_t cbmvm_graphic_pixel(const CBMVM *vm, int x, int y);
const CBMVM_GRAPHICS *cbmvm_graphic_state(const CBMVM *vm);
void cbmvm_graphic_tick(CBMVM *vm, unsigned int ticks);

const char *cbmvm_last_error(const CBMVM *vm);
void cbmvm_set_debug(CBMVM *vm, int enabled);
size_t cbmvm_instance_bytes(const CBMVM *vm);

/* Compatibility entry point used by the original command line program. */
int start_cbmvm_engine(int argc, char **argv);

#endif
