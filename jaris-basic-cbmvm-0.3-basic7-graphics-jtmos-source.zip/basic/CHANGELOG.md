# Changelog

## 0.3 (2026-08-31)

- Added packed 320x200 virtual graphics framebuffer.
- Added BASIC 7.0 `GRAPHIC`, `RGR`, `SCNCLR`, `DRAW`, `BOX`, `CIRCLE`, `PAINT`, `CHAR`, `COLOR`, `SSHAPE` and `GSHAPE`.
- Added C128 extended-token parsing for `MOVSPR`, `SPRITE` and `SPRDEF`.
- Added eight virtual sprite states, 63-byte sprite patterns and host-timed movement.
- Added JTMOS/GraOS graphics-present, mode/color, sprite and interactive sprite-editor callbacks.
- Made BASIC strings binary-safe and increased their usable capacity to 255 bytes.
- Added BASIC 7 PRG generator examples, graphics/sprite regression tests and a PPM demo renderer.
- VM footprint is now about 121 KiB including 64 KiB RAM and the graphics state.

## 0.2 (2026-08-31)

- Rebuilt interpreter core around standard PRG linked lines.
- Reduced pre-graphics per-VM memory to roughly 87 KiB including 64 KiB guest RAM.
- Added host callback abstraction and JTMOS/GraOS adapter.
- Added cooperative `step/run` execution budget.
- Added expression precedence, variables and string values.
- Added GOTO/IF, GOSUB/RETURN, FOR/NEXT, POKE/PEEK and other core BASIC statements.
- Added strict program validation and regression tests.
- Preserved original examples under `legacy_examples/` and generated corrected standard examples.
