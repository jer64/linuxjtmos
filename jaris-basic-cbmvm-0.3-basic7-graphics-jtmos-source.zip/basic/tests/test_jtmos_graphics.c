#include <stdio.h>
#include <string.h>
#include "cbmvm_engine.h"
#include "cbmvm_jtmos.h"

typedef struct {
    int bg, border, mode, split;
    unsigned int presents, sprites, clears;
} JTSTATE;
static void set_bg(void *p,uint8_t c){((JTSTATE*)p)->bg=c;}
static void set_border(void *p,uint8_t c){((JTSTATE*)p)->border=c;}
static void mode(void *p,int m,int s){JTSTATE *x=(JTSTATE*)p;x->mode=m;x->split=s;}
static void present(void *p,const uint8_t *px,size_t bytes,int w,int h,const uint8_t colors[7],int m,int s)
{JTSTATE *x=(JTSTATE*)p;(void)px;(void)colors;(void)m;(void)s;if(bytes==16000u&&w==320&&h==200)x->presents++;}
static void sprite(void *p,int n,int e,int x,int y,int c,int pri,int xe,int ye,int mc,const uint8_t data[63])
{JTSTATE *st=(JTSTATE*)p;(void)n;(void)e;(void)x;(void)y;(void)c;(void)pri;(void)xe;(void)ye;(void)mc;(void)data;st->sprites++;}
static void clear(void *p){((JTSTATE*)p)->clears++;}

int main(void)
{
    JTSTATE st; CBMVM_JTMOS_BINDINGS b; CBMVM_JTMOS_CONTEXT ctx; CBMVM_HOST host; CBMVM *vm; int rc;
    memset(&st,0,sizeof(st)); memset(&b,0,sizeof(b));
    b.userdata=&st; b.set_background=set_bg; b.set_border=set_border; b.graphics_mode=mode;
    b.graphics_present=present; b.sprite_update=sprite; b.screen_clear=clear;
    cbmvm_jtmos_host_init(&ctx,&b,&host);
    vm=cbmvm_create(&host); if(!vm)return 1;
    if(cbmvm_load_prg_file(vm,"examples/graphics_demo.prg")!=CBMVM_OK)return 2;
    do{rc=cbmvm_run(vm,10000);}while(rc==CBMVM_YIELDED);
    if(rc!=CBMVM_HALTED){fprintf(stderr,"%s\n",cbmvm_last_error(vm));return 3;}
    if(st.bg!=0 || st.border!=6 || st.mode!=1 || st.presents<8 || st.sprites<2 || st.clears<1){
        fprintf(stderr,"bg=%d border=%d mode=%d presents=%u sprites=%u clears=%u\n",st.bg,st.border,st.mode,st.presents,st.sprites,st.clears);return 4;
    }
    cbmvm_destroy(vm); puts("PASS jtmos-graphics-bridge"); return 0;
}
