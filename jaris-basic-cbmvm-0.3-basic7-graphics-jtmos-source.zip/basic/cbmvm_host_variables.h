#ifndef CBMVM_HOST_VARIABLES_H
#define CBMVM_HOST_VARIABLES_H

#include <stddef.h>
#include <stdint.h>
#include "cbmvm_host.h"
#include "cbmvm_settings.h"
#include "cbmvm_graphics.h"

typedef enum {
    CBMVM_VALUE_NUMBER = 0,
    CBMVM_VALUE_STRING = 1
} CBMVM_VALUE_TYPE;

typedef struct {
    char name[CBMVM_MAX_VAR_NAME];
    CBMVM_VALUE_TYPE type;
    double number;
    char string[CBMVM_MAX_STRING];
    uint16_t string_length;
} CBMVM_VARIABLE;

typedef struct {
    uint16_t return_pc;
    uint16_t return_line_address;
} CBMVM_GOSUB_FRAME;

typedef struct {
    char variable[CBMVM_MAX_VAR_NAME];
    double limit;
    double step;
    uint16_t loop_pc;
    uint16_t loop_line_address;
} CBMVM_FOR_FRAME;

typedef struct CBMVM {
    uint8_t *ram;
    size_t ram_size;

    uint16_t load_address;
    uint16_t program_end;
    uint16_t first_line_address;
    uint16_t line_address;
    uint16_t next_line_address;
    uint16_t pc;
    uint16_t line_number;

    int halted;
    int error;
    int debug;
    unsigned long instructions;

    CBMVM_HOST host;

    CBMVM_VARIABLE variables[CBMVM_MAX_VARIABLES];
    unsigned int variable_count;

    CBMVM_GOSUB_FRAME gosub_stack[CBMVM_GOSUB_DEPTH];
    unsigned int gosub_depth;

    CBMVM_FOR_FRAME for_stack[CBMVM_FOR_DEPTH];
    unsigned int for_depth;

    unsigned int print_column;
    CBMVM_GRAPHICS graphics;
    char error_message[160];
} CBMVM;

#endif
