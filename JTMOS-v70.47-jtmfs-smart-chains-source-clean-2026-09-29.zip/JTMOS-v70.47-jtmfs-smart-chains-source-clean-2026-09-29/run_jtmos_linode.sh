#!/bin/sh
set -eu
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
# V68.201 compatibility entry point: preserve the historical/simple Linode name
# while keeping a single maintained Linode profile in run_jtmos_qemu_linode.sh.
exec "$DIR/run_jtmos_qemu_linode.sh" "$@"
