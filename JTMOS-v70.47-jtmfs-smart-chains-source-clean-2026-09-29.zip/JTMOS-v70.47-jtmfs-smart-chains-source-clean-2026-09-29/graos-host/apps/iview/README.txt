JTMOS iview - GraOS JPEG viewer
================================

Command line:
  iview picture.jpg
  iview picture.jpg --actual

iview decodes baseline 8-bit JPEG/JFIF images (grayscale or YCbCr), scales
images that are larger than the GraOS desktop, maps RGB into the canonical
JTMOS 256-colour MCGA palette, and displays the result through a GraOS
TYPE_BITMAP_SCREEN client framebuffer.  It decodes directly into 32-bpp RGBA and does not use the VGA DAC
palette, so other GraOS windows keep their normal colours.

Keys:
  Esc / Q   close viewer

Current built-in decoder limits:
  maximum JPEG dimensions: 1280x1024
  maximum compressed input file: 2 MiB
  progressive/lossless/CMYK JPEG: not supported
