/* jpegdec.c - small independent baseline JPEG decoder for JTMOS iview.
 *
 * Supported: SOF0 8-bit baseline sequential JPEG, one grayscale component or
 * three YCbCr components, common sampling factors, restart markers, 8-bit DQT.
 * Progressive/lossless/arithmetic/CMYK JPEG is intentionally rejected.
 */
#include <stdlib.h>
#include <string.h>
#include "jpegdec.h"

#define JD_MAX_W 1280
#define JD_MAX_H 1024
#define JD_MAX_PIXELS (JD_MAX_W*JD_MAX_H)
#define JD_MAX_COMPS 3
#define JD_MAX_HT 4

typedef struct {
    unsigned char count[17];
    unsigned char symbols[256];
    unsigned short first_code[17];
    unsigned short first_sym[17];
    int valid;
} HUFF;

typedef struct {
    int id,hs,vs,qt,dc,ac,pred;
    int stride,plane_h;
    unsigned char *plane;
} COMP;

typedef struct {
    const unsigned char *p,*end;
    int width,height,ncomp,hmax,vmax,mcu_w,mcu_h,mcu_cols,mcu_rows;
    int restart_interval;
    unsigned short q[4][64];
    unsigned char qvalid[4];
    HUFF huff[JD_MAX_HT];
    COMP comp[JD_MAX_COMPS];
    unsigned char *pixels;
    unsigned long bitbuf;
    int bits;
} JD;

static JD jd;
static const unsigned char zigzag[64]={
 0,1,8,16,9,2,3,10,17,24,32,25,18,11,4,5,
 12,19,26,33,40,48,41,34,27,20,13,6,7,14,21,28,
 35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,
 58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63
};
/* B[x][u] = C(u)*cos((2*x+1)*u*pi/16), scaled by 128. */
static const short idct_b[8][8]={
 {91,126,118,106,91,71,49,25},
 {91,106,49,-25,-91,-126,-118,-71},
 {91,71,-49,-126,-91,25,118,106},
 {91,25,-118,-71,91,106,-49,-126},
 {91,-25,-118,71,91,-106,-49,126},
 {91,-71,-49,126,-91,-25,118,-106},
 {91,-106,49,25,-91,126,-118,71},
 {91,-126,118,-106,91,-71,49,-25}
};

static int remain(void){return (int)(jd.end-jd.p);}
static int rd16(const unsigned char *p){return ((int)p[0]<<8)|p[1];}
static unsigned char clip8(long v){return v<0?0:(v>255?255:(unsigned char)v);}
static int comp_index(int id){int i;for(i=0;i<jd.ncomp;i++)if(jd.comp[i].id==id)return i;return -1;}

static int skip_segment(void)
{
    int n;if(remain()<2)return 0;n=rd16(jd.p);if(n<2||n>remain())return 0;jd.p+=n;return 1;
}
static int parse_dqt(void)
{
    int n,t,i;if(remain()<2)return 0;n=rd16(jd.p);if(n<2||n>remain())return 0;jd.p+=2;n-=2;
    while(n){if(n<65)return 0;t=*jd.p++;n--;if((t>>4)!=0||(t&15)>3)return -1;t&=15;for(i=0;i<64;i++)jd.q[t][zigzag[i]]=*jd.p++;n-=64;jd.qvalid[t]=1;}
    return 1;
}
static int build_huff(HUFF *h,const unsigned char *counts,const unsigned char *symbols,int nsym)
{
    int len,k=0,code=0,c;
    memset(h,0,sizeof(*h));
    for(len=1;len<=16;len++){
        c=counts[len-1];
        if(code+c>(1L<<len)) return 0;
        h->count[len]=(unsigned char)c;
        h->first_code[len]=(unsigned short)code;
        h->first_sym[len]=(unsigned short)k;
        k+=c;
        code=(code+c)<<1;
    }
    if(k!=nsym||k>256) return 0;
    memcpy(h->symbols,symbols,(size_t)k);
    h->valid=1;
    return 1;
}
static int parse_dht(void)
{
    int n,tc,th,i,sum;unsigned char counts[16];
    if(remain()<2) return 0;
    n=rd16(jd.p);
    if(n<2||n>remain()) return 0;
    jd.p+=2;
    n-=2;
    while(n){if(n<17)return 0;tc=jd.p[0]>>4;th=jd.p[0]&15;if(tc>1||th>1)return -1;for(i=0;i<16;i++)counts[i]=jd.p[i+1];jd.p+=17;n-=17;sum=0;for(i=0;i<16;i++)sum+=counts[i];if(sum>256||sum>n)return 0;if(!build_huff(&jd.huff[(tc<<1)|th],counts,jd.p,sum))return 0;jd.p+=sum;n-=sum;}
    return 1;
}
static int parse_sof0(void)
{
    int n,i,j,hv,sum=0;
    if(remain()<2) return 0;
    n=rd16(jd.p);
    if(n<8||n>remain()) return 0;
    if(jd.p[2]!=8) return -1;
    jd.height=rd16(jd.p+3);
    jd.width=rd16(jd.p+5);
    jd.ncomp=jd.p[7];
    if((jd.ncomp!=1&&jd.ncomp!=3)||n!=8+3*jd.ncomp)return -1;
    if(jd.width<=0||jd.height<=0||jd.width>JD_MAX_W||jd.height>JD_MAX_H||jd.width>JD_MAX_PIXELS/jd.height)return -1;
    jd.hmax=jd.vmax=0;jd.p+=8;
    for(i=0;i<jd.ncomp;i++){
        COMP *c=&jd.comp[i];
        c->id=jd.p[0];
        for(j=0;j<i;j++) if(jd.comp[j].id==c->id) return -1;
        hv=jd.p[1];
        c->hs=hv>>4;
        c->vs=hv&15;
        c->qt=jd.p[2];
        jd.p+=3;
        if(c->hs<1||c->hs>4||c->vs<1||c->vs>4||c->qt>3) return -1;
        sum+=c->hs*c->vs;
        if(c->hs>jd.hmax) jd.hmax=c->hs;
        if(c->vs>jd.vmax) jd.vmax=c->vs;
    }
    if(sum>10) return -1;
    for(i=0;i<jd.ncomp;i++)
        if(jd.hmax%jd.comp[i].hs!=0||jd.vmax%jd.comp[i].vs!=0) return -1;
    jd.mcu_w=jd.hmax*8;
    jd.mcu_h=jd.vmax*8;
    jd.mcu_cols=(jd.width+jd.mcu_w-1)/jd.mcu_w;
    jd.mcu_rows=(jd.height+jd.mcu_h-1)/jd.mcu_h;
    for(i=0;i<jd.ncomp;i++){
        COMP *c=&jd.comp[i];size_t bytes;c->stride=jd.mcu_cols*c->hs*8;c->plane_h=jd.mcu_rows*c->vs*8;bytes=(size_t)c->stride*(size_t)c->plane_h;c->plane=(unsigned char*)malloc(bytes);if(!c->plane)return -2;memset(c->plane,0,bytes);
    }
    return 1;
}
static int parse_dri(void)
{
    int n;if(remain()<4)return 0;n=rd16(jd.p);if(n!=4||n>remain())return 0;jd.restart_interval=rd16(jd.p+2);jd.p+=4;return 1;
}

static int entropy_byte(int *out)
{
    int b,m;if(jd.p>=jd.end)return 0;b=*jd.p++;if(b!=0xff){*out=b;return 1;}
    do{if(jd.p>=jd.end)return 0;m=*jd.p++;}while(m==0xff);
    if(m==0x00){*out=0xff;return 1;}
    jd.p-=2;return -1;
}
static int get_bit(int *bit)
{
    int b,r;if(jd.bits==0){r=entropy_byte(&b);if(r!=1)return 0;jd.bitbuf=(unsigned long)b;jd.bits=8;}*bit=(int)((jd.bitbuf>>(jd.bits-1))&1UL);jd.bits--;return 1;
}
static int get_bits(int n,int *v)
{
    int i,b,x=0;for(i=0;i<n;i++){if(!get_bit(&b))return 0;x=(x<<1)|b;}*v=x;return 1;
}
static int huff_symbol(HUFF *h,int *sym)
{
    int len,bit,code=0,first,cnt,idx;if(!h->valid)return 0;
    for(len=1;len<=16;len++){
        if(!get_bit(&bit)) return 0;
        code=(code<<1)|bit;
        first=h->first_code[len];
        cnt=h->count[len];
        if(cnt&&code>=first&&code<first+cnt){idx=h->first_sym[len]+code-first;if(idx<0||idx>=256)return 0;*sym=h->symbols[idx];return 1;}
    }
    return 0;
}
static int receive_extend(int n,int *out)
{
    int v;if(n==0){*out=0;return 1;}if(n>16||!get_bits(n,&v))return 0;if(v<(1<<(n-1)))v-=((1<<n)-1);*out=v;return 1;
}

static void idct8(const long *coef,unsigned char *dst,int stride)
{
    long t[64];int x,y,u,v;long sum,val;
    for(v=0;v<8;v++)for(x=0;x<8;x++){sum=0;for(u=0;u<8;u++)sum+=coef[v*8+u]*(long)idct_b[x][u];t[v*8+x]=(sum>=0?(sum+64):(sum-64))/128;}
    for(y=0;y<8;y++)for(x=0;x<8;x++){sum=0;for(v=0;v<8;v++)sum+=t[v*8+x]*(long)idct_b[y][v];val=(sum>=0?(sum+256):(sum-256))/512+128;dst[y*stride+x]=clip8(val);}
}
static int decode_block(COMP *c,unsigned char *dst)
{
    long coef[64],next_pred;int s,diff,k,rs,run,n,i;HUFF *hd,*ha;
    memset(coef,0,sizeof(coef));
    if(!jd.qvalid[c->qt]) return 0;
    hd=&jd.huff[c->dc];
    ha=&jd.huff[c->ac];
    if(!huff_symbol(hd,&s)||s>11||!receive_extend(s,&diff)) return 0;
    next_pred=(long)c->pred+(long)diff;
    if(next_pred < -2048L || next_pred > 2047L) return 0;
    c->pred=(int)next_pred;
    coef[0]=(long)c->pred*(long)jd.q[c->qt][0];
    k=1;
    while(k<64){
        if(!huff_symbol(ha,&rs)) return 0;
        if(rs==0) break;
        run=rs>>4;
        n=rs&15;
        if(n==0){
            if(run!=15||k>48) return 0;
            k+=16;
            continue;
        }
        k+=run;
        if(k>=64||n>10||!receive_extend(n,&diff)) return 0;
        i=zigzag[k];
        coef[i]=(long)diff*(long)jd.q[c->qt][i];
        k++;
    }
    idct8(coef,dst,c->stride);return 1;
}
static int consume_restart(int expected)
{
    int m;jd.bits=0;jd.bitbuf=0;if(jd.p>=jd.end||*jd.p++!=0xff)return 0;do{if(jd.p>=jd.end)return 0;m=*jd.p++;}while(m==0xff);return m==(0xd0+(expected&7));
}
static int parse_scan(void)
{
    int n,ns,i,ci,td,ta,mx,my,bx,by,si,sj,mcu_count=0,rst=0;
    int seen=0,order[JD_MAX_COMPS];
    if(remain()<2) return 0;
    n=rd16(jd.p);
    if(n<6||n>remain()) return 0;
    ns=jd.p[2];
    if(ns!=jd.ncomp||n!=6+2*ns) return -1;
    jd.p+=3;
    for(i=0;i<ns;i++){
        ci=comp_index(jd.p[0]);
        if(ci<0||(seen&(1<<ci))!=0) return 0;
        seen|=1<<ci;
        order[i]=ci;
        td=jd.p[1]>>4;
        ta=jd.p[1]&15;
        if(td>1||ta>1) return -1;
        jd.comp[ci].dc=td;
        jd.comp[ci].ac=2|ta;
        jd.p+=2;
    }
    if(jd.p[0]!=0||jd.p[1]!=63||jd.p[2]!=0) return -1;
    jd.p+=3;
    jd.bits=0;
    jd.bitbuf=0;
    for(i=0;i<jd.ncomp;i++)jd.comp[i].pred=0;
    for(my=0;my<jd.mcu_rows;my++)for(mx=0;mx<jd.mcu_cols;mx++){
        for(i=0;i<jd.ncomp;i++){
            COMP *c=&jd.comp[order[i]];for(sj=0;sj<c->vs;sj++)for(si=0;si<c->hs;si++){bx=(mx*c->hs+si)*8;by=(my*c->vs+sj)*8;if(!decode_block(c,c->plane+by*c->stride+bx))return 0;}
        }
        mcu_count++;if(jd.restart_interval&&mcu_count<jd.mcu_cols*jd.mcu_rows&&(mcu_count%jd.restart_interval)==0){if(!consume_restart(rst++))return 0;for(i=0;i<jd.ncomp;i++)jd.comp[i].pred=0;}
    }
    return 1;
}
static int make_pixels(void)
{
    int x,y;size_t bytes;if(jd.ncomp==1){bytes=(size_t)jd.width*(size_t)jd.height;jd.pixels=(unsigned char*)malloc(bytes);if(!jd.pixels)return 0;for(y=0;y<jd.height;y++){COMP *c=&jd.comp[0];int sy=(y*c->vs)/jd.vmax;for(x=0;x<jd.width;x++){int sx=(x*c->hs)/jd.hmax;jd.pixels[y*jd.width+x]=c->plane[sy*c->stride+sx];}}return 1;}
    bytes=(size_t)jd.width*(size_t)jd.height*3U;jd.pixels=(unsigned char*)malloc(bytes);if(!jd.pixels)return 0;
    for(y=0;y<jd.height;y++)for(x=0;x<jd.width;x++){
        int sy0=(y*jd.comp[0].vs)/jd.vmax,sx0=(x*jd.comp[0].hs)/jd.hmax;
        int sy1=(y*jd.comp[1].vs)/jd.vmax,sx1=(x*jd.comp[1].hs)/jd.hmax;
        int sy2=(y*jd.comp[2].vs)/jd.vmax,sx2=(x*jd.comp[2].hs)/jd.hmax;
        int yy=jd.comp[0].plane[sy0*jd.comp[0].stride+sx0];
        int cb=(int)jd.comp[1].plane[sy1*jd.comp[1].stride+sx1]-128;
        int cr=(int)jd.comp[2].plane[sy2*jd.comp[2].stride+sx2]-128;
        unsigned char *d=jd.pixels+(y*jd.width+x)*3;d[0]=clip8(yy+((359*cr+128)>>8));d[1]=clip8(yy-((88*cb+183*cr+128)>>8));d[2]=clip8(yy+((454*cb+128)>>8));
    }
    return 1;
}

void jpgInit(void){memset(&jd,0,sizeof(jd));}
void jpgDone(void){int i;for(i=0;i<JD_MAX_COMPS;i++){if(jd.comp[i].plane)free(jd.comp[i].plane);}if(jd.pixels)free(jd.pixels);memset(&jd,0,sizeof(jd));}
JPG_RESULT jpgDecode(const void *data,int size)
{
    int marker,r;
    jpgDone();
    if(!data||size<2) return JPG_NOT_JPEG;
    jd.p=(const unsigned char*)data;
    jd.end=jd.p+size;
    if(jd.p[0]!=0xff||jd.p[1]!=0xd8) return JPG_NOT_JPEG;
    jd.p+=2;
    while(remain()>0){while(jd.p<jd.end&&*jd.p!=0xff)jd.p++;if(remain()<2)break;while(jd.p<jd.end&&*jd.p==0xff)jd.p++;if(jd.p>=jd.end)break;marker=*jd.p++;
        if(marker==0xd9)break;
        if(marker==0xc0)r=parse_sof0();
        else if(marker==0xc4)r=parse_dht();
        else if(marker==0xdb)r=parse_dqt();
        else if(marker==0xdd)r=parse_dri();
        else if(marker==0xda){if(jd.width<=0)r=0;else r=parse_scan();if(r==1){if(!make_pixels())return JPG_NO_MEMORY;return JPG_OK;}}
        else if(marker==0xfe||(marker>=0xe0&&marker<=0xef))r=skip_segment();
        else if(marker==0x01||(marker>=0xd0&&marker<=0xd7))r=1;
        else return JPG_UNSUPPORTED;
        if(r==-2) return JPG_NO_MEMORY;
        if(r<0) return JPG_UNSUPPORTED;
        if(r==0) return JPG_BAD_DATA;
    }
    return JPG_BAD_DATA;
}
int jpgWidth(void){return jd.width;}int jpgHeight(void){return jd.height;}int jpgColor(void){return jd.ncomp==3;}unsigned char *jpgPixels(void){return jd.pixels;}int jpgPixelBytes(void){return jd.width*jd.height*(jd.ncomp==3?3:1);}
