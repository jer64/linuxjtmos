/* iview.c - command-line JPEG viewer for JTMOS GraOS. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jtmos/process.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include "jpegdec.h"

SYSMEMREQ(APPRAM_12288K)

#define VIEW_MAX_W 944
#define VIEW_MAX_H 680
#define JPEG_MAX_FILE (2*1024*1024)

typedef struct { BYTE *data; int size; } FILEBUF;

static int read_file(const char *name,FILEBUF *fb)
{
    FILE *f;long n;size_t got;
    if(!name || !fb)return -1;
    memset(fb,0,sizeof(*fb));
    f=fopen(name,"rb");if(!f)return -1;
    if(fseek(f,0,SEEK_END)!=0){fclose(f);return -2;}
    n=ftell(f);if(n<=0||n>JPEG_MAX_FILE){fclose(f);return -3;}
    if(fseek(f,0,SEEK_SET)!=0){fclose(f);return -2;}
    fb->data=(BYTE*)malloc((size_t)n);if(!fb->data){fclose(f);return -4;}
    got=fread(fb->data,1,(size_t)n,f);fclose(f);
    if(got!=(size_t)n){free(fb->data);fb->data=NULL;return -5;}
    fb->size=(int)n;return 0;
}
static void fit_size(int sw,int sh,int *dw,int *dh,int actual)
{
    long w=sw,h=sh;
    if(!actual&&(w>VIEW_MAX_W||h>VIEW_MAX_H)){
        if(w*VIEW_MAX_H>h*VIEW_MAX_W){h=(h*VIEW_MAX_W)/w;w=VIEW_MAX_W;}
        else {w=(w*VIEW_MAX_H)/h;h=VIEW_MAX_H;}
    }
    if(w>VIEW_MAX_W){h=(h*VIEW_MAX_W)/w;w=VIEW_MAX_W;}
    if(h>VIEW_MAX_H){w=(w*VIEW_MAX_H)/h;h=VIEW_MAX_H;}
    if(w<1) w=1;
    if(h<1) h=1;
    *dw=(int)w;
    *dh=(int)h;
}
static GRAOS_PIXEL *convert_scale(int sw,int sh,int color,int dw,int dh)
{
    BYTE *src=jpgPixels();GRAOS_PIXEL *dst;int x,y;unsigned long sx,sy;
    if(!src || sw<=0 || sh<=0 || dw<=0 || dh<=0)return NULL;
    dst=(GRAOS_PIXEL*)malloc((size_t)dw*(size_t)dh*sizeof(GRAOS_PIXEL));if(!dst)return NULL;
    for(y=0;y<dh;y++){
        sy=((unsigned long)y*(unsigned long)sh)/(unsigned long)dh;
        for(x=0;x<dw;x++){
            int r,g,b;unsigned long p;sx=((unsigned long)x*(unsigned long)sw)/(unsigned long)dw;p=sy*(unsigned long)sw+sx;
            if(color){r=src[p*3];g=src[p*3+1];b=src[p*3+2];}
            else r=g=b=src[p];
            dst[y*dw+x]=GRAOS_RGB(r,g,b);
        }
    }
    return dst;
}
static const char *jpg_error(JPG_RESULT e)
{
    switch(e){case JPG_NOT_JPEG:return "not a JPEG file";case JPG_UNSUPPORTED:return "unsupported JPEG (baseline <=1280x1024 required)";case JPG_NO_MEMORY:return "out of memory";case JPG_BAD_DATA:return "damaged/invalid JPEG";default:return "unknown decoder error";}
}
static void usage(const char *name)
{
    printf("JTMOS iview - GraOS JPEG image viewer\n");
    printf("Usage: %s file.jpg [--actual]\n",name?name:"iview");
    printf("Baseline JPEG/JFIF, grayscale or YCbCr. Esc/Q closes the window.\n");
}
int main(int argc,char **argv)
{
    FILEBUF f;JPG_RESULT jr;GRAOS_PIXEL *pixels;GUICMD ev;int sw,sh,dw,dh,color,wid,er,actual=0,server_closed=0;char title[96];
    if(argc<2){usage(argv[0]);return 1;}
    if(argc>2){if(!strcmp(argv[2],"--actual"))actual=1;else{usage(argv[0]);return 1;}}
    er=read_file(argv[1],&f);if(er<0){printf("iview: cannot read '%s' (error %d; max file size %d KiB).\n",argv[1],er,JPEG_MAX_FILE/1024);return 2;}
    jpgInit();jr=jpgDecode(f.data,f.size);free(f.data);f.data=NULL;
    if(jr!=JPG_OK){printf("iview: %s: %s.\n",argv[1],jpg_error(jr));jpgDone();return 3;}
    sw=jpgWidth();sh=jpgHeight();color=jpgColor();fit_size(sw,sh,&dw,&dh,actual);
    pixels=convert_scale(sw,sh,color,dw,dh);if(!pixels){printf("iview: framebuffer allocation failed.\n");jpgDone();return 4;}
    jpgDone();
    if(connectGraos()<0){printf("iview: GraOS is not running.\n");free(pixels);return 5;}
    snprintf(title,sizeof(title),"iview: %s - %dx%d",argv[1],sw,sh);
    wid=createWindow(-1,-1,dw+16,dh+44,title,GRAOS_WINDOW_STANDARD);
    if(wid<0||addFrameBuffer(wid,pixels,0,0,dw,dh,GRAOS_BPP,GRAOS_SURFACE_BITMAP,0)<0){printf("iview: cannot create GraOS image window.\n");if(wid>=0)closeWindow(wid);free(pixels);return 6;}
    if(refreshWindow(wid)<0){closeWindow(wid);free(pixels);return 6;}
    printf("iview: %s: %dx%d %s JPEG -> %dx%d GraOS RGBA32 window.\n",argv[1],sw,sh,color?"color":"grayscale",dw,dh);
    for(;;){
        while((er=JtmosGraOSPollEvent(wid,&ev))>0){
            if(ev.id==GRAOS_GSID_EXIT){server_closed=1;goto out;}
            if(ev.id==GRAOS_GSID_KEYPRESSED&&(ev.v[0]==27||ev.v[0]=='q'||ev.v[0]=='Q'))goto out;
        }
        if(er<0){server_closed=1;goto out;}
        SwitchToThread();
        Sleep(10);
    }
out:
	if(!server_closed) closeWindow(wid);
	free(pixels);
	return 0;
}
