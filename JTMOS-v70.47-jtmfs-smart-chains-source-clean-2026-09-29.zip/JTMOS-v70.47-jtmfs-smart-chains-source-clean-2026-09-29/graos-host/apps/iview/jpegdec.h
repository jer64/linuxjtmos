#ifndef JTMOS_IVIEW_JPEGDEC_H
#define JTMOS_IVIEW_JPEGDEC_H

typedef enum {
    JPG_OK=0,
    JPG_NOT_JPEG=1,
    JPG_UNSUPPORTED=2,
    JPG_NO_MEMORY=3,
    JPG_BAD_DATA=4
} JPG_RESULT;

void jpgInit(void);
void jpgDone(void);
JPG_RESULT jpgDecode(const void *data,int size);
int jpgWidth(void);
int jpgHeight(void);
int jpgColor(void);
unsigned char *jpgPixels(void);
int jpgPixelBytes(void);

#endif
