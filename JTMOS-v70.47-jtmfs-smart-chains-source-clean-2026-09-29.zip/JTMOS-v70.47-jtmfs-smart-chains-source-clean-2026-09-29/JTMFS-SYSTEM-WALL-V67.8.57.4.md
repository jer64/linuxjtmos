# JTMFS system-area hard wall — V67.8.57.4

## Reproduced risk pattern

A bootable HDA was formatted and populated with ordinary filesystem writes:

    d0
    mkfs hda
    cd hda
    mkdir bin
    cd bin
    sqa cdrom
    unz

After reboot, boot32pm could load the HDD kernel image but the kernel handoff failed.
`sqa` itself does not issue raw HDA writes; it creates ordinary JTMFS files.  This
therefore exposed a filesystem/system-area isolation problem.

## Two unsafe paths fixed

1. The free-block allocator previously trusted FAT reserved markers.  If a stale
   or corrupt FAT entry inside the boot/kernel/FAT area appeared free, normal
   file allocation could select it.  V67.8.57.4 adds a geometric SYSTEM-WALL:
   normal allocation starts at `sysarea_length` and can never return an earlier
   block, independent of the FAT entry value.

2. `mkfs` mixed cached boot-sector writes with direct information-block writes.
   A dirty pre-format/cache line could later be flushed over freshly written
   system metadata.  Boot loader, information block and kernel-checksum metadata
   are now written with an explicit flush/invalidate barrier, uncached physical
   I/O, physical readback verification, and a final cache invalidation.

## Runtime protection

- file read/write chains reject blocks in the boot/kernel/FAT system area;
- chain expansion rejects protected blocks;
- central runtime FAT mutation rejects system-area entries;
- current bootable JTMFS geometry validates the explicit 1 MiB kernel layout;
- root directory remains the sole special data block before normal allocation;
- `fsgeom hda` reports the protected SYSTEM-WALL and first normal data block.

For a 512-byte-sector HDD, the 16 KiB loader plus 1 MiB kernel reserve occupies
sectors 0..2079 before the FAT.  Normal file allocation begins only after the
complete JTMFS system area (kernel + FAT + root metadata), not merely after
sector 2080.

## Retest

Use a freshly formatted test HDD because a previously affected image may already
contain a damaged kernel or FAT:

    d0
    mkfs hda
    fsgeom hda
    cd hda
    mkdir bin
    cd bin
    sqa cdrom
    unz
    sync
    fsgeom hda
    fsck hda

Then reboot and select `boot: c`.
