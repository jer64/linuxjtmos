//
#ifndef __INCLUDED_CBMVM_MACROS_H__
#define __INCLUDED_CBMVM_MACROS_H__

//
//
#define CBMVM_DEBUG_LINE            if(cbmvm_debug_messages) printf("[%s / %s  Line %d]\n", \
                                __FILE__, __FUNCTION__, __LINE__);

//
//int cbmvm_input_program(CBMVM *vm)
#define cbmvm_input_program(_par1_) _cbmvm_input_program(_par1_, __FUNCTION__, __FILE__, __LINE__)

//
#endif

//