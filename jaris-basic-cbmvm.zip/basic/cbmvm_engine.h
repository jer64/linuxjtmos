#ifndef __INCLUDED_CBMVM_ENGINE_H__
#define __INCLUDED_CBMVM_ENGINE_H__

//
int start_cbmvm_engine(int argc, char **argv);

#endif
