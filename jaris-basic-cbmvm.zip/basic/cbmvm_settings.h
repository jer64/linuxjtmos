#ifndef __INCLUDED_CBMVM_SETTINGS_H__
#define __INCLUDED_CBMVM_SETTINGS_H__

// CBM COMMODORE 64 64K RAM space supported at the moment.
int DEFAULT_CBMVM_RAM_SIZE_K;
int CBM_BASIC_PROGRAM_START;
int MAX_LENGTH_OF_MATH_FORMULA;
int MAX_VARIABLES;
int MAX_VARIABLE_NAME_LENGTH;
int MAX_VARIABLE_CONTENT_LENGTH;

// Commodore 64/128 had a limit of something like this:
// Increase value to support more memory-hungry programs.
#define COMMON_STR_LENGTH		512

#endif
