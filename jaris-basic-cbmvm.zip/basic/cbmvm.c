// cbmvm.c - Commodore Business Machines Series Virtualization Environment - Main Function (Program Entrance).
// (C) 2021 by Jari Tapio Tuominen (jari.t.tuominen@gmail.com).
#include <stdio.h>

//
#ifndef JTMOS

//
#include "about_cbmvm.h"
#include "cbmvm_engine.h"

//
int main(int argc, char **argv)
{
    //
    if(argc<2)
    {
        about_cbmvm();
        return 0;
    }
    
    // First parameter is e.g. "basicprogram.prg".
    start_cbmvm_engine(argc,argv);
    
    //
    return 0;
}

//
#endif