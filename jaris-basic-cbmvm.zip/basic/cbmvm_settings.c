//
#include <stdio.h>
#include "cbmvm_settings.h"

// CBM COMMODORE 64 64K RAM space supported at the moment.
int DEFAULT_CBMVM_RAM_SIZE_K = 64;
int CBM_BASIC_PROGRAM_START = 0x0801;
int MAX_LENGTH_OF_MATH_FORMULA = 5000;
int MAX_VARIABLES =		5000;

//
