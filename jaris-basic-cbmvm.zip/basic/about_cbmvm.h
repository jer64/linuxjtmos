#ifndef __INCLUDED_ABOUT_CBMVM_H__
#define __INCLUDED_ABOUT_CBMVM_H__

//
int about_cbmvm(void);

#endif
