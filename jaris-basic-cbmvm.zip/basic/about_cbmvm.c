//
#include <stdio.h>
#include "about_cbmvm.h"

//
int about_cbmvm(void)
{
    //
    printf("Commodore Virtual Machine with Token Basic Support version 0.0.1.\n");
    printf("Usage: cbmvm [basic program.prg] (Reads start address from offset 0-1)\n");
    printf("Create programs in CBM machine and save it on a PC as a .PRG file.\n");
    return 0;
}