//***************************************************************************************************
// cbmvm_engine.c - Commodore Business Machines Series Virtualization Environment - Main Engine.
// (C) 2021 by Jari Tapio Tuominen (jari.t.tuominen@gmail.com).
//***************************************************************************************************
//
// Simplicity:
// A) INIT
// B) GET
// C) SORT
// D) RUN
#include <stdio.h>
#include "cbmvm_engine.h"
#include "cbmvm_host_variables.h"
#include "cbmvm_settings.h"
#include "cbmvm_macros.h" // DEBUGFUNC (printf with debug capabilities).

//
//char *cbmvm_set_statement_destination_variable(CBMVM *vm, char *varname);

// Enable debug messages? (Lots Of Output Will Follow).
int cbmvm_debug_messages = 1;

//
char *cbmvm_set_statement_destination_variable(CBMVM *vm, char *varname);

// Return value: -1 or less on error.
int cbmvm_execute_command_queue(CBMVM *vm)
{
    int i,i2,i3,i4,addi;
    char *s,*s2,*s3,*s4,*dvar,*dval;
    int token;
    char str[COMMON_STR_LENGTH];
    
    CBMVM_DEBUG_LINE
        
    //
    if(cbmvm_debug_messages)
    {
        printf("Basic at $%1.4x\n", vm->cursor);
        cbmvm_compact_print_command_queue(vm);
    }
    // Lets have fun:
    for(i=0; i<vm->n_command_queue; i++)
    {
        s = vm->command_queue[i];
    
        if(cbmvm_debug_messages) printf("CMD #%d: '%s'\n",
            i, s);
        
        //
        if(cbmvm_debug_messages)
            // Only when debugging cbmvm:
            cbmvm_hexdump_basic_program(vm,vm->cursor,256);
            
        // TOKEN, e.g. 0xFF.
        // IMPORTANT:
        // DUE TO INTERNAL PROGRAMMING DESIGN OF THE VIRTUAL MACHINE,
        // THE TOKEN MUST BE STORED AS 0x -HEXADECIMAL FORMAT.
        if( !strncmp(s, "0x", 2) )
        {
            token = 0x00;
            sscanf(s+2, "%x", &token);
            if(cbmvm_debug_messages) printf("SSCANF parsing tells token=$%1.2x\n",
                token);
            addi = cbmvm_execute_basic_token_command(vm, token, i);
            if(addi<0) { return addi; }
            i += addi;
            continue;
        }
        
        // NUMBERS
        if( isdigit(s[0]) )
        {
          // We will pass numbers, non-strict mode.
          continue;
        }
        
        // ALPHABETIC CONTENT
        if( isalpha(s[0]) )
        {
            s2 = vm->command_queue[i];
            if(s2==NULL)
            {
                printf("== Null Pointer Reference Error : %s/%s/line %d : vm->command_queue[%d] = $%1.4x\n",
                    __FUNCTION__, __FILE__, __LINE__, 
                    i, s2);
                return 3;
            }
            dvar =  vm->dest_var_name_ptr;
            dval =  vm->dest_var_value_ptr;
            if(dvar==NULL || dval==NULL)
            {
                printf("== Null Pointer Reference Error : %s/%s/line %d : dvar = $%1.4x, dval = $%1.x\n",
                    __FUNCTION__, __FILE__, __LINE__, 
                    dvar, dval);
                return 4;
            }

        // SET DESTINATION VARIABLE
        // ------------------------
        // e.g. dest = 1+2

        // Got variable, a decimal ?
        if(isalpha(s2[0]) && (strlen(s2)>1 && s[strlen(s2)-1]!='$') && i==0)
        {
            //
            // int cbmvm_get_basic_variable(CBMVM *vm, char *varname, char *varvalue)
            if( cbmvm_get_basic_variable(vm, s2, str)==-1 )
            {
                // No variable with this name, we have create one.
                cbmvm_new_basic_variable(vm, s2);
                cbmvm_set_basic_variable(vm, s2, "0");               
            }
            //
            cbmvm_get_basic_variable(vm, s2, str);
            //
            cbmvm_set_statement_destination_variable(vm, str);
            //
            return 2;
        }

        // Got variable, a string ?
        if(isalpha(s2[0]) && s[strlen(s2)-1]=='$' && i==0)
        {
            //
            // int cbmvm_get_basic_variable(CBMVM *vm, char *varname, char *varvalue)
            if( cbmvm_get_basic_variable(vm, s2, str)==-1 )
            {
                // No variable with this name, we have create one.
                cbmvm_new_basic_variable(vm, s2);
                cbmvm_set_basic_variable(vm, s2, "0");               
            }
            //
            cbmvm_get_basic_variable(vm, s2, str);
            //
            cbmvm_set_statement_destination_variable(vm, str);
            //
            return 2;
        }
        
        // Unhandled alphabetic content.
        return -1;

    }

    // Quoted string.

        // Support for simple quoted string. 
        // NOT SUPPORTED FOR THE DESTINATION VARIABLE (i!=0).
        if(s2[0]=='\"' && i>0 && dvar!=NULL && dval!=NULL)
        {
            // Character index set to zero, beginning.
            i = 0;
            // Skip quote.
            for(; i<256 && s[i]!=0; i++)
            {
                if(s[i]!='\"')break;
            }
            // Print until quote.
            for(i2=0; i<256 && s[i]!=0; i++)
            {
                if(s[i]=='\"')break;
                dvar[i2++] = s[i];
                dvar[i2] = 0;
            }
            // Skip quote.
            for(; i<256 && s[i]!=0; i++)
            {
                if(s[i]!='\"')break;
            }
            // Skip white spaces.
            for(; i<256 && s[i]!=0; i++)
            {
                if(s[i]!=' ')break;
            }
/*            // Default is new line. But if the string ends with ';', we skip the new line.
            if(s[i]!=';')
            {
                dvar[i2++] = "\n";
                dvar[i2] = 0;
            }*/
        }
        else
        {
            //
            return -1;
        }


          //
          continue;
     }
     
     /***************** END OF STATEMENT ***/

     //
     // Do we still got a job to do?
     // Lets look at the postjobs.
     if(vm->execute_nr_token_at_the_end_of_statement != -1)
     {
            // We execute from the beginning.
            i = 0;
            token = vm->execute_nr_token_at_the_end_of_statement;
            if(cbmvm_debug_messages)
                printf("*** POST STATEMENT JOB, Running Token = $%1.2x\n",
                    token);
            addi = cbmvm_execute_basic_token_command(vm, token, i);
            if(addi<0) { return addi; }
            i += addi;
     }

    // Success:
    return 0;
}

//
int waitkey(void)
{
    char str[COMMON_STR_LENGTH];

    gets(str);
}

//
int cbmvm_new_basic_variable(CBMVM *vm, char *varname)
{
    int i;

    //
    if(vm->n_vars>=vm->max_vars)
    {
        // Out of memory (variable space).
        return -1;
    }
    //
    i = vm->n_vars;

    //
    if(vm->varname[i]==NULL) { return -1; }
    //
    vm->n_vars++;
    strcpy(vm->varname[i], varname);
    // String variable?
    if( varname[strlen(varname)-1]=='$' )
    {
        strcpy(vm->varvalue[i], "");
    }
    else
    {
        // Decimal variable.
        // Set at zero in the beginning.
        strcpy(vm->varvalue[i], "0");
    }
    return i;
}

//
int cbmvm_set_basic_variable(CBMVM *vm, char *varname, char *varvalue)
{
    int i;
    
    //
    for(i=0; i<vm->n_vars; i++)
    {
        if(vm->varname[i] != NULL && !strcmp(vm->varname[i], varname))
        {
            // OK, we got the variable in index #i.
            strcpy(vm->varvalue[i], varvalue);
            return 0;
        }
    }
    // 
    return -1;
}

//
int cbmvm_get_basic_variable(CBMVM *vm, char *varname, char *varvalue)
{
    int i;

    //
    for(i=0; i<vm->n_vars; i++)
    {
        if(vm->varname[i] != NULL && !strcmp(vm->varname[i], varname))
        {
            // OK, we got the variable in index #i.
            strcpy(varvalue, vm->varvalue[i]);
            return 0;
        }
    }
    //
    return -1;
}

// Used in statements, equations.
char *cbmvm_set_statement_destination_variable(CBMVM *vm, char *varname)
{
    int i;

    //
    for(i=0; i<vm->n_vars; i++)
    {
        if(vm->varname[i]!=NULL && !strcmp(vm->varname[i], varname))
        {
            // OK, we got the variable in index #i.
            vm->dest_var_name_ptr =	vm->varname[i];
            vm->dest_var_value_ptr =	vm->varvalue[i];
        }
    }
    //
    return -1;
}

//
int cbmvm_hexdump_basic_program(CBMVM *vm,int beg_offs,int dump_length_bytes)
{
    int i,i2,ch,seq;
    
    //
    printf("\n");
    fflush(stdout);
    for(i=beg_offs,seq=0; i<65536 && i<(beg_offs+dump_length_bytes); i++)
    {
        if(seq==0) {
            printf("%1.4x: ", i);
        }
        printf("%1.2x,", vm->ram[i&0xFFFF]);
        seq++;
        if(seq>=24) {
            // Print ASCII view.
            printf(" ");
            for(i2=i-24; i2<i; i2++)
            {
               ch = vm->ram[i2&0xFFFF];
               if( isalpha(ch) || isdigit(ch) ) { } else { ch = '.'; }
               printf("%c", ch);
            }
            printf("\n"); seq=0;
        }
    }
    printf("\nOK\n");
    return 0;
}

// SORT COMMANDS
// Mathematics of Basic require ordering and
// prioritization of commands in right execution order fashion.
int cbmvm_sort_command_queue(CBMVM *vm)
{
    //
    CBMVM_DEBUG_LINE
    
    //
}

//
int cbmvm_is_token(CBMVM *vm, int i)
{
    if((i >= 0x80 && i <= 0xcb) || i==0xff)
    {
        // Actually a valid token code.
        return 1;
    }
    return 0;
}

//
int cbmvm_is_basic_v2_token(CBMVM *vm)
{
    int i;
    
    //
    CBMVM_DEBUG_LINE

    //
    i = cbmvm_input_program(vm);
    //
    return cbmvm_is_token(vm, i);
}

//
int cbmvm_peek_basic_v2_token(CBMVM *vm)
{
    int i;
    
    //
    CBMVM_DEBUG_LINE

    //
    i = cbmvm_peek_preview_input(vm);
    if((i >= 0x80 && i <= 0xcb) || i==0xff)
    {
        // Actually a valid token code.
        return 1;
    }
    return 0;
}

// COMMAND QUEUE ADD (A STATEMENT):
// Command queue is a full statement, that needs prioritization.
// Without prioritazion we wouldn't need to queue the commands before processing.
// Due to the complexness of Commoore mathematics it enables, we need to queue to
// follow up the priority of functions in mathematics.
// NOTE: Tokens begin with 0x - e.g. 0x99 - and rest are commands, numbers, etc.
int cbmvm_command_queue_add(CBMVM *vm, char *commandstr)
{
    //
    CBMVM_DEBUG_LINE

    //
    if(cbmvm_debug_messages)
        printf("[%s/%s/line %d] vm->n_command_queue = #%d <= \"%s\" (commandstr)\n",
        __FUNCTION__, __FILE__, __LINE__, 
        vm->n_command_queue,
        commandstr);
    if(vm->command_queue[vm->n_command_queue] != NULL)
    {
        strcpy(vm->command_queue[vm->n_command_queue], commandstr);
        vm->n_command_queue++;
    }
    return 0;
}


// Reset command queue executed before:
// GET, SORT, RUN.
int cbmvm_reset_command_queue(CBMVM *vm)
{
    //
    CBMVM_DEBUG_LINE

    //
    vm->n_command_queue = 0;
    vm->dest_var_name_ptr = NULL;
    vm->dest_var_value_ptr = NULL;
    return 0; // success
}

// Go to
// END OF LINE = EOL.
int cbmvm_go_to_eol(CBMVM *vm)
{
    int ch;
    
    //
    CBMVM_DEBUG_LINE

    //    
    while(1)
    {
     if( (ch = cbmvm_input_program(vm))==-1 ) { return 1; }
     if(ch==0) { cbmvm_head_move_back(vm); break; }
    }
    return 0;
}


//
int cbmvm_peek_preview_next_input(CBMVM *vm)
{
     //
     CBMVM_DEBUG_LINE

     //
     if((vm->cursor+1) < vm->l_ram)
     {
      return vm->ram[vm->cursor];
     }
     else
     return -1;
}

//
int cbmvm_peek_preview_input(CBMVM *vm)
{
     //
     CBMVM_DEBUG_LINE
    
     //
     if(vm->cursor >= 0 && vm->cursor < vm->l_ram)
     {
      return vm->ram[vm->cursor];
     }
     else
     return -1;
}

// BASIC PARSER, HEAD MOVE FORWARD
int cbmvm_head_move_foward(CBMVM *vm)
{
     //
     CBMVM_DEBUG_LINE

     //
     if( !(vm->cursor < vm->l_ram) )
     {
      return -1;
     }
     vm->cursor++;
     return 0;
}

// BASIC PARSER, HEAD MOVE BACK
int cbmvm_head_move_back(CBMVM *vm)
{
    CBMVM_DEBUG_LINE

    vm->cursor--;
    if(vm->cursor < 0) { return 1; } // memory mapping fix awaiting for this... rules
    return 0;
}

// INPUT A SINGLE CHARACTER OF BASIC PROGRAM
int _cbmvm_input_program(CBMVM *vm,
    char *caller_func,
    char *caller_file,
    int caller_line)
{
    int ch;
    
     if(cbmvm_debug_messages)
     {
       printf("* PARSING : $%1.4x = $%1.2x : [%s/%s/line %d]: This Function Was Called By %s/%s/line %d.\n",
         vm->cursor, cbmvm_peek(vm,vm->cursor),
         __FUNCTION__, __FILE__, __LINE__,
         caller_func,
         caller_file,
         caller_line);
      printf("%1.4x: $%1.2x\n",
          vm->cursor, vm->ram[vm->cursor]);
    }

     CBMVM_DEBUG_LINE

     if(vm->cursor >= vm->l_ram || vm->cursor >= vm->basic_prg_end)
     {
        goto handler1;
     }
     ch = vm->ram[vm->cursor];
     vm->cursor++;
     if(vm->cursor >= vm->l_ram || vm->cursor >= vm->basic_prg_end)
     {
handler1:
        //
        // End of file reached, it is same as running "end".
        

        // Or we could put it extremely risk for developing purposes:
/*
          printf("[%s/%s/line %d]: Error. Crossing RAM memory boundaries at: $%1.4x\n",
                __FUNCTION__, __FILE__, __LINE__,
                vm->cursor);*/
          return -1;
     }
     
     //
     return ch;
}

// LOADS BASIC PROGRAM AND AUTOMATICALLY ADJUSTS
// VIRTUAL MACHINE SETTINGS TO BE COMPATIBLE
// WITH THE PROGRAM LOADED.
//
// Basically there are two kinds of settings
// (START) $0801 COMMODORE 64	LINE TOKEN=0x08
// (START) $1C01 COMMODORE 128	LINE TOKEN=0x1C
//
int cbmvm_basic_load(CBMVM *vm, char *fn)
{
    //
    FILE *f;
    int i,ch,ad,a1,a2,rv;
    
    CBMVM_DEBUG_LINE

    // Default to "success".
    rv = 0;
    
    //
    f = fopen(fn, "rb");
    if(f==NULL)
    {
        return 1;
    }
    
    a1 = fgetc(f); if(a1==EOF) { rv=2; goto done_here; }
    a2 = fgetc(f); if(a2==EOF) { rv=2; goto done_here; }
    ad = (a2<<8) | a1;
    if(ad==0x01c01)
    {
        if(cbmvm_debug_messages)
        {
            printf("********************************************************\n");
            printf("   Commodore 128 Basic V7 virtualization enabled.\n");
            printf("********************************************************\n");
        }
        vm->ad_basic_0800 = 0x1c00;
        CBM_BASIC_PROGRAM_START = 0x1c01;
        vm->byte_nr_line_number_indicator = 0x1C;
    }
    else
    if(ad!=CBM_BASIC_PROGRAM_START)
    {
        if(cbmvm_debug_messages)
            printf("[%s/%s/line %d]: Unsupported start address for a basic program: $%1.4x\n",
                __FUNCTION__, __FILE__, __LINE__,
                ad);
        rv = 3;
        goto done_here;
    }
    else
    {
        if(cbmvm_debug_messages)
        {
            printf("********************************************************\n");
            printf("   Commodore 64 Basic V2 virtualization enabled.\n");
            printf("*******************************************************\n");
        }
        vm->ad_basic_0800 = 0x0800;
        vm->byte_nr_line_number_indicator = 0x08;
    }
    
    printf("*** Loading Program \"%s\" At $%1.4x\n",
        fn, ad);
    
    for(i=0; !feof(f); i++,ad++)
    {
        ch = fgetc(f);
        if(ch==EOF) { break; }
        cbmvm_poke(vm, ad, ch);
    }
    
    /** SET BASIC END, DEBUGGING AND SAFE GUARDING REASONS **/
    vm->basic_prg_end = ad;
    //
    printf("*** Basic Program Ends At $%1.4x\n",
        vm->basic_prg_end);
    
    //
done_here:
    //
    fclose(f);
    //
    return rv;
}

//
int cbmvm_free_machine(CBMVM *vm)
{
    CBMVM_DEBUG_LINE

    //
    free(vm->ram);
    free(vm);
    
    //
    return 0;
}

// cbmvm_poke
// Virtual basic poke command.
// (Protected Memory Access).
int cbmvm_poke(CBMVM *vm, int poke_ad, int poke_value)
{
    CBMVM_DEBUG_LINE

    //
    if(poke_ad < 0 || poke_ad >= vm->l_ram)
    {
        if(cbmvm_debug_messages)
        {
            printf("%s/%s/line %d: ERROR. ILLEGAL POKE ADDRESS $%1.4x,$%1.2x\n", 
                __FUNCTION__, __FILE__, __LINE__,
                poke_ad,poke_value);
        }
        return 1;    
    }
    printf("%s/%s/line %d: poke $%1.4x,$%1.2x\n", 
                __FUNCTION__, __FILE__, __LINE__,
                poke_ad,poke_value);
    vm->ram[poke_ad] = poke_value;
    return 0;
}

//
int cbmvm_peek(CBMVM *vm, int peek_ad)
{
    CBMVM_DEBUG_LINE

    //
    if(peek_ad < 0 || peek_ad >= vm->l_ram)
    {
        if(cbmvm_debug_messages)
        {
            printf("%s/%s/line %d: ERROR. ILLEGAL ACTION: peek $%1.4x\n", 
                __FUNCTION__, __FILE__, __LINE__,
                peek_ad);
        }
        return 1;    
    }
    printf("%s/%s/line %d: peek $%1.4x\n", 
                __FUNCTION__, __FILE__, __LINE__,
                peek_ad);
    //
    return vm->ram[peek_ad];
}

// Input a variable.
// a
// a$
int cbmvm_input_variable(CBMVM *vm, char *varname)
{
          int i,i2,ch,ch2;

          CBMVM_DEBUG_LINE

          // Avoid errors on uninitialized strings.
          strcpy(varname, "");

          // Detect white space and skip it.
          if( (cbmvm_peek_preview_input(vm)==' ') )
          {
           // Skip white space.
           while( (ch=cbmvm_input_program(vm))==' ' );
           // Avoid Losing A Character.
           cbmvm_head_move_back(vm);
          }
          
          // Get Character.
          ch = cbmvm_input_program(vm);

          // GET VARIABLE NAME TO STRING
          // First check its beginning with an alphabet character:
          // (Important)
          if( isalpha(ch) )
          {
              for(i=0; i<256; )
              {
                ch = cbmvm_input_program(vm);
             /*   if( cbmvm_is_token(vm, ch) ) {
                    cbmvm_head_move_back(vm);
                    return 0;
                }*/
                // EOF? => Return Back To Caller,
                // Report Return Value = -1.
                if(ch==-1) { return -1; }
                //
                if(ch==0 || ch==':')
                {
                    // Keep The Character For Calling Function:
                    //cbmvm_head_move_back(vm);
                    // Break.
                    cbmvm_head_move_back(vm);
                    break;
                }
                varname[i++] = ch;
                varname[i] = 0;
              }
          }
          else
          {
              // Actually a syntax error:
              return 1;
          }

          //
          return 0;
}

// INPUT A NUMBER (DIGIT) TO A STRING.
int cbmvm_input_number(CBMVM *vm, char *value)
{
          int i,i2,ch,ch2,lch;

          CBMVM_DEBUG_LINE
          
          
          
          // Avoid errors on uninitialized strings.
          strcpy(value, "");

          // Detect white space.
          if( (cbmvm_peek_preview_input(vm)==' ') )
          {
           // Skip white space.
           while( (ch=cbmvm_input_program(vm))==' ' );
          }

          // INPUT A NUMBER (DIGIT) to string
          ch = cbmvm_input_program(vm);

          // Handle numbers:
          if( isdigit(ch) )
          {
              i = 0;
              value[i++] = ch;
              value[i] = 0; // terminate string

              for(lch=-1;;)
              {
                // SPECIAL DEVELOPMENT NOTE:
                // We Are Here Handling A Decimal Number,
                // So We Should NOT Have Spaces Put In A Decimal Number STRING...
                // A Reminder.
                ch=cbmvm_input_program(vm);
                // Statement Terminates at \0:
                if(ch==0) { 
                    //
                    cbmvm_head_move_back(vm);
                    break;
                }
                // End Of File / EOF ? :
                if(ch==-1) { return -1; } // possibly an error, but we are not checking this (low level parsing...)
                // Non-Digit After All, Should We Quit Now?
                if( !isdigit(ch) && (ch!='.' && ch!=',') )
                   // decimal support on accepting "." character besides numbers
                   
                   // * Also breaking up on double dots
                   // or more dots in count like :
                   // "0..1" "0...1" or "0....1" being invalid numerics.
                {
                  // Apparent end of a number.
                  cbmvm_head_move_back(vm);
                  break;
                }
                //
              /*  if( cbmvm_is_token(vm, ch) ) {
                    cbmvm_head_move_back(vm);
                    return 0;
                }*/
                value[i++] = ch;
                value[i] = 0; // terminate string
              }
          }
          else
          {
              // Syntax error:
              return 1;
          }
          
          // So non-number character will not be ignored by the master (caller).
          if(ch!=0)
              cbmvm_head_move_back(vm);
          return 0;
}

// PARSE A SIMPLE / SINGLE STATEMENT.
// Return values as follows.
// 0:
// -1
// 1: ERROR 1: NUMBERS AT THE BEGINNING OF A STATEMENT
// (DESTINATION VARIABLE) NOT ALLOWED. 
//
int cbmvm_parse_simple_statement(CBMVM *vm, char *str)
{
        int i,i2,i3,i4,ch,ch2,rv;
        char varname[COMMON_STR_LENGTH],varnumber[COMMON_STR_LENGTH];
        
        CBMVM_DEBUG_LINE
        
        //
        i = 0;
        
           //*
           if(cbmvm_debug_messages)
           {
               printf("*** %s/line %d: SIMPLE STATEMENT - Basic At $%1.4x\n",
                    __FUNCTION__, __LINE__, vm->cursor);
           }

//    cbmvm_head_move_back(vm);
    fflush(stdout);
    printf("!!!!!!!!!!!!!!!!!!\n");
    fflush(stdout);
    sleep(2);

        // Skip white spaces.
        // cbmvm_peek_preview_input
        // ch=cbmvm_input_program
        //ch = cbmvm_input_program(vm);
        for(;;)
        {
            ch = cbmvm_input_program(vm);
            
            //
            if(ch==-1)
                return -1;
            // Terminator.
            if(ch==0)
            {
                cbmvm_head_move_back(vm);
                return 0;
            }
            if(ch!=' ') break;
        }
        
        // What do we have
        
        // ALPHABET => ACTUALLY A VARIABLE => HANDLE VARIABLES
        if(isalpha(ch))
        {
            //
            cbmvm_head_move_back(vm);
            rv = cbmvm_input_variable(vm, str);

            if(cbmvm_debug_messages)
                printf("*** %s/%d: GOT NEW VARIABLE : \"%s\"\n",
                    __FUNCTION__, __LINE__,
                    str);
            return rv;
        }
        
        // HANDLE DIGITS
        if(isdigit(ch))
        {
          //
          cbmvm_head_move_back(vm);
          rv = cbmvm_input_number(vm, str);

          if(cbmvm_debug_messages)
                printf("*** %s/line %d: GOT NEW NUMBER : \"%s\"\n",
                    __FUNCTION__, __LINE__,
                    str);
          return rv;
        }

        // Parse quoted string. E.g. used by print "hello world ";
        if(ch=='\"')
        {
          if(cbmvm_debug_messages)
              printf("*** %s/line %d:  Detected :  Getting A Quoted String Here :\n",
                  __FUNCTION__, __LINE__);

          // Save The Quota...
          //cbmvm_head_move_back(vm);
          // QUOTED, NULL TERMINATED TOKEN COMMAND.
          i = 0;
          str[i++] = ch;
          str[i] = 0;
          while( (ch=cbmvm_input_program(vm)) != 0 )
          {
            str[i++] = ch;
            str[i] = 0;
            if(ch=='\"') { break; }
            if(ch==-1) { break; }

            // Terminator
            if(ch==0)
            {
                // Pass The Terminator To The Caller.
                cbmvm_head_move_back(vm);
                return 0;
            }
          }
          
          // Detect white space.
          if( cbmvm_peek_preview_next_input(vm)==' ')
          {
           // Skip white space.
           for(; (ch=cbmvm_input_program(vm))==' '; )
           {
           }
          }
          
          //
          ch = cbmvm_input_program(vm);
            // Terminator
            if(ch==0)
            {
                // Pass The Terminator To The Caller.
                cbmvm_head_move_back(vm);
                return 0;
            }
          //
          if( ch==';')
          {
           // no new line on ";" terminated "print" basic token command.
           // Remember ";":
           str[i++] = ';';
           str[i] = 0;
          }
          else
          {
           //strcat(str, "");
           //i = strlen(str);
          }
          if(cbmvm_debug_messages)
              printf("*** %s/line %d:  GOT CONTENT: \"%s\"\n",
                  __FUNCTION__, __LINE__,
                  str);

          return 0;
        }
        
        //
        return 0;
}

//
int cbmvm_init_high_level_parsing(CBMVM *vm)
{
       CBMVM_DEBUG_LINE

       //
       vm->zeroes=0;
       vm->execute_jump_to = -1;
       vm->execute_nr_token_at_the_end_of_statement = -1;
}

//////////////////////////////////////////////////////////////////////
//
// Compact print of a command queue.
//
int cbmvm_compact_print_command_queue(CBMVM *vm)
{
    int i;
    char *s;
    
    //
    if(vm->n_command_queue <= 0)
    {
        printf("%s: *** Command Queue Is Empty :  No Program Stamement (N = %d).\n",
            __FUNCTION__, vm->n_command_queue);
    }
    else
    {
       printf("%s: *** Command Queue States Following:\n    ",
           __FUNCTION__);
       for(i=0; i<vm->n_command_queue; i++)
       {
        s = vm->command_queue[i];
        if( !strncmp(s,"0x",2) )
        {
          // Its a token!
           printf("(%s) ",
                vm->command_queue[i]);
        }
        else
        {
          // Its a parameter.
          printf("[%s] ",
          vm->command_queue[i]);
        }
      }
      
      //
    }
    printf("\n");
    
    //
    return 0;
}

/**** PARSE A TOKEN (A SINGLE BASIC COMMAND) **************************/
// -1 on error
// 0 on no action required
// other non-zero = take action of this number
// vm->command_queue[i]
int cbmvm_execute_basic_token_command(CBMVM *vm, int token, int command_queue_index)
{
    int ch,ch2,i,i2,i3,i4,
      poke_ad,poke_value,zeroes,ad,addi;
    char str[COMMON_STR_LENGTH],*s,*varname,*destvarname;

    //
    CBMVM_DEBUG_LINE
    
    //
    switch(token)
    {
        //---------------------------------------------------------------
        // END
        // End of program.
        case 0x80:
        //
        if(cbmvm_debug_messages)
            printf("End of program.\n");
        
        vm->end_of_program = 1;
        //
        return 123;
        
        //---------------------------------------------------------------
        // LET
        // (SET VARIABLE, FORMAL)
        // LET A = 1
        case 0x88:
        // Skipping.
        return 1;
        
        //---------------------------------------------------------------
        // =
        // (SET VARIABLE)
        // Set previously mentioned variable to a value of an equation.
        // Example of the command:
        // a = a + 1
        case 0xB2:
        // We need the first parameter or Syntax Error will happend.
        // Also need to have at least three commands, e.g.:
        // a = 1
        // Support for:
        // a = a + 1
        if( !(command_queue_index>0 && vm->n_command_queue<3))
        {
          if(cbmvm_debug_messages)
              printf("oops!");
          goto syntax_error;
        }
        
        //
        s = vm->command_queue[command_queue_index-1];
        // 
        // Set variable to zero, it is the default answer Basic will give.
        // Variable Name E.g.:
        // apple1		decimal
        // apple1$		string
        if(isalpha(s[0]))
        {
            // int cbmvm_get_basic_variable(CBMVM *vm, char *varname, char *varvalue)
            if( cbmvm_get_basic_variable(vm, s, str)==-1 )
            {
                // No variable with this name, we have create one.
                cbmvm_new_basic_variable(vm, s);
            }
            cbmvm_set_basic_variable(vm, s, "0");
        }
        else
        {
            printf("[%s/%s/line %d] Syntax error on line #%d\n",
                __FUNCTION__, __FILE__, __LINE__,
                vm->line_number);
            goto syntax_error;
        }

        for(i = command_queue_index+1; i<vm->n_command_queue; i++)
        {
            s = vm->command_queue[i];
           
            // Got token? E.g. "+" in a=a+1.
            if(s[0]=='0' && s[1]=='x') { 
                // We will call ourselves for an equatiation.
                addi = cbmvm_execute_basic_token_command(vm, token, command_queue_index);
                if(addi<0) { return addi; }
                i += addi;
                continue;
            }
            
            // Rock'n'roll:
            //
        
          // Are we setting 
        
          // Advance index by equated commands amount.
          return i - command_queue_index;
        }

        //---------------------------------------------------------------
        // PRINT
        // PRINT "HELLO WORLD"
        // PRINT "HELLO WORLD";
        //
        // PRINT A
        case 0x99:
        
        // Will be back.
        if(vm->execute_nr_token_at_the_end_of_statement==-1 && command_queue_index==0)
        {
            // Process the statement first.
            vm->execute_nr_token_at_the_end_of_statement = 0x99;
            // Move to next statement.
            return 1;
        }

        // CUT

        s = vm->command_queue[command_queue_index+1];
        
        // Got variable, a decimal ?
        if(isalpha(s[0]) && s[strlen(s)-1]!='$')
        {
            //
            // int cbmvm_get_basic_variable(CBMVM *vm, char *varname, char *varvalue)
            if( cbmvm_get_basic_variable(vm, s, str)==-1 )
            {
                // No variable with this name, we have create one.
                cbmvm_new_basic_variable(vm, s);
                cbmvm_set_basic_variable(vm, s, "0");               
            }
            //
            cbmvm_get_basic_variable(vm, s, str);
            // Print content.
            printf("%s\n", str);
            //
            return 2;
        }

        // Got variable, a string ?
        if(isalpha(s[0]) && s[strlen(s)-1]=='$')
        {
            //
            // int cbmvm_get_basic_variable(CBMVM *vm, char *varname, char *varvalue)
            if( cbmvm_get_basic_variable(vm, s, str)==-1 )
            {
                // No variable with this name, we have create one.
                cbmvm_new_basic_variable(vm, s);
                cbmvm_set_basic_variable(vm, s, "0");               
            }
            //
            cbmvm_get_basic_variable(vm, s, str);
            // Print content.
            printf("%s\ŋ", str);
            //
            return 2;
        }

        // Support for simple quoted string. 
        if(s[0]=='\"')
        {
            // Character index set to zero, beginning.
            i = 0;
            // Skip quote.
            for(; i<256 && s[i]!=0; i++)
            {
                if(s[i]!='\"')break;
            }
            // Print until quote.
            for(; i<256 && s[i]!=0; i++)
            {
                if(s[i]=='\"')break;
                printf("%c", s[i]);
            }
            // Skip quote.
            for(; i<256 && s[i]!=0; i++)
            {
                if(s[i]!='\"')break;
            }
            // Skip white spaces.
            for(; i<256 && s[i]!=0; i++)
            {
                if(s[i]!=' ')break;
            }
            // Default is new line. But if the string ends with ';', we skip the new line.
            if(s[i]!=';')
            {
                printf("\n");
            }
        }
        else
        {
            goto syntax_error;
        }


        // Advance index by +2.
        return 2;
        
        //---------------------------------------------------------------
        // GOTO 0
        case 0x89:
        s = vm->command_queue[command_queue_index+1];
        // Support for goto [number].
        if( isdigit(s[0]) )
        {
            // Character index set to zero, beginning.
            i = 0;
            // Skip number.
            for(; i<256 && s[i]!=0; i++)
            {
                if( !isdigit(s[i]) )break;
            }

            // Skip white spaces.
            for(; i<256 && s[i]!=0; i++)
            {
                if(s[i]!=' ')break;
            }
            s[i] = 0;
            
            // Make goto true.
            sscanf(s, "%d", &vm->execute_jump_to);
            //
            if(cbmvm_debug_messages)
                printf("  sscanf says, goto => line #%d\n",
                vm->execute_jump_to);
            // Remember, Important: Start at the beginning of the basic program.
            cbmvm_set_basic_cursor(vm, CBM_BASIC_PROGRAM_START+1);
        }
        else
        {
            goto syntax_error;
        }
        // Advance index by +2.
        return 2;
        
        ///////////////////////////////////////////////////////////////////
        //
        // POKE  -TOKEN
        //
        case 0x97:
        return 2;
        
        
        //--------------------------------------------------------------
        // UNKNOWN TOKEN
        default:
syntax_error:
        printf("[%s/%s/line %d]: Syntax error, unsupported token $%1.2x on line #%d\n",
            __FUNCTION__, __FILE__, __LINE__,
            token,
            vm->line_number);
        cbmvm_compact_print_command_queue(vm);
        return -1;
    }

    // Completed entire statement,
    // and skip anything thats missing - non-strict - for testing purposes.
    return 0;
}


/**** PRODUCE COMMAND QUEUE: ****************************************************
 **** PARSE A COMPLEX STATEMENT (HIGH-LEVEL) AND OUTPUT IT AT COMMAND QUEUE
 **** A PARSER FUNCTION ********************************************************/
// Development Note:
// When This Particular Function Encounters A \0 (Code 0) Character,
// It Should: return 0;
int cbmvm_produce_command_queue(CBMVM *vm)
{
    int token_ch,ch,ch2,i,i2,i3,i4,token,rv,
      poke_ad,poke_value,zeroes,ad,
      bytes_read;
    char str[COMMON_STR_LENGTH];

    CBMVM_DEBUG_LINE

    //
    if(cbmvm_debug_messages)
        printf("%s/line %d: Running program at $%1.4x:\n",
            __FUNCTION__, __LINE__, vm->cursor);
    
    //
    //cbmvm_head_move_back(vm);
    
    // Caps at 256 bytes of seeking, a fail-safe method.
    for(bytes_read=0,zeroes=0; bytes_read<256; bytes_read++)
    {
       //
       if( (token_ch = cbmvm_input_program(vm))==-1 )
       {
          // Strict
/*          printf("[%s/%s/line %d]: Out of boundaries  error.\n",
                __FUNCTION__, __FILE__, __LINE__);*/
          // Or happy ending.
          return -1;           
       }
       
       /////////////////////////////////////////////////////////////////////
       // IMPORTANT TOKEN VALIDATION, PARSING, AND EXECUTION CODE.
       /////////////////////////////////////////////////////////////////////
       // All statements in Basic V2 & V7 begin with a code number 0x1C character,
       // so this is we expect to find before any statements,
       // also so cant parse until found one.

       // Is It A Beginning of a statement and a 16-bit line number (0x1c).
       if( token_ch==vm->byte_nr_line_number_indicator) { // ch==':' ?
           printf("Found Line Number Token: Character Code = $%1.2x\n",
               ch);
           break;
           }
       
       // Got a token?
       if( cbmvm_is_token(vm, token_ch) )
       {
           printf("** TOKEN FOUND AT $%1.4x : Token Code = $%1.2x  (Runtime At %s/%s/line %d) **\n",
               vm->cursor, token_ch,
               __FUNCTION__, __FILE__, __LINE__);
           // Move Cursor Back To Save The Token.
           cbmvm_head_move_back(vm);
           goto parse_tokens;
       }
       
       //
       // Look for a terminator.
       if(token_ch==0) {
           cbmvm_head_move_back(vm);
           return 0;
       }
       
       // End of file reached? Four or more of terminator \0 chars.
       if(zeroes>=10) { return 123; }
    }
    //
    if(bytes_read>=256)
    {
        if(cbmvm_debug_messages)
            printf("Hmm.. End of file at cursor $%1.4x",
            vm->cursor);
        if(cbmvm_debug_messages)
            // Only when debugging
            cbmvm_hexdump_basic_program(vm,vm->cursor,256);
        exit(0);
        return -1;
    }

new_line_number:   
       // Line number follows up:
       // 16-bit unsigned int : BASIC LINE NUMBER
       vm->line_number = cbmvm_input_program(vm) | (cbmvm_input_program(vm)<<8);
       //
       if(cbmvm_debug_messages)
       {
           printf("******************************************************\n");
           printf("NEW LINE: Got line number %d. (cursor at $%1.4x)\n", vm->line_number, vm->cursor);
           printf("*****************************************************\n");
       }

           
    //
       // ARE WE DOING : GOTO, GOSUB, OR RETURNING ?
       if(vm->execute_jump_to != -1)
       {
         // ADDITION (IMPORTANT):
         // If jump line number is zero e.g.,
         // and current line number is zero as well,
         // it wont jump,
         // heres a fix:

         // SPECIAL JUMP CASE. (ON A GOTO SEEK; NOT INTERPRETING.)
         // Seek until the specified line number reached.
         if( (vm->line_number != vm->execute_jump_to) )
         {
          // Seek until terminator character \0.
          while( (ch=cbmvm_input_program(vm)) != 0 )
          {
            if(ch==-1)
            {
               // EOF reached.
               return -1;
            }
             
          }
          if(ch==0)
              cbmvm_head_move_back(vm);
          return 10; // 10 = continue request
         }
         else
         {
             // JUMP DONE! (goto N).
             vm->execute_jump_to = -1;
         }
       }


    // LOOP UNTIL END OF THE STATEMENT.
    // Get COMMAND_QUEUE content: e.g. the basic commands, parameters, etc. things.
//    cbmvm_head_move_back(vm);
    
   //
    if(cbmvm_debug_messages)
        printf("%s/line %d: Running program at $%1.4x:\n",
            __FUNCTION__, __LINE__, vm->cursor);
            
    
parse_tokens:
    for(i4=0; ; i4++)
    {
       // Accept Basic V2 token codes here:
       /////////////////////////////////////////////////////
       //
       
       //
       ch = cbmvm_input_program(vm);
       // EOD?
       if(ch==-1) { return -1; }
       // Skip past zero content.
       if(ch==0x00) {
           cbmvm_head_move_back(vm);
           return 0;
       }
       // INDICATOR OF LINE NUMBER?
       if(ch==vm->byte_nr_line_number_indicator)
       {
           goto new_line_number;
       }
       if(cbmvm_debug_messages)
           printf("basic line #%d: ch=0x%1.2x\n",
               vm->line_number, ch);
       
/*       // End of statement? => RETURN BACK.
       if( ch==-1 || ch==0 || ch==':' )
       {
           return 0;
       }*/
       
       // Whether if it is token code?
       if( cbmvm_is_token(vm,ch) )
       {
           //**** GOT A TOKEN HERE: **************************
           if(cbmvm_debug_messages)
               printf("*** Basic Line #%d: Found A Token  =>  character = 0x%1.2x\n",
           vm->line_number, ch);
           token = ch;
           sprintf(str, "0x%x", token);
           if(cbmvm_debug_messages)
               printf("*** ==>  STORING TOKEN $%1.2x AT COMMAND QUEUE  (\"%s\") \n", token,str);
           cbmvm_command_queue_add(vm, str);
           continue;
       }
       else
       {
          //
          if( ch=='\"' )
          {
            cbmvm_head_move_back(vm);
            if( (rv=cbmvm_parse_simple_statement(vm, str)) )
            {
                return rv;
            }
            cbmvm_command_queue_add(vm, str);
            if(cbmvm_debug_messages)
                printf("*** %s/line %d: FOUND QUOTED STRING = '%s' at $%1.4x\n",
                    __FUNCTION__, __LINE__,
                    str, vm->cursor);
          }
          // Say, we have like this kind of situation with digits:
          // 12345 = 54321 (non-sense):
          if( isdigit(ch) )
          {
            cbmvm_head_move_back(vm);
            if( (rv=cbmvm_parse_simple_statement(vm, str)) )
            {
                return rv;
            }
            cbmvm_command_queue_add(vm, str);
            if(cbmvm_debug_messages)
                printf("*** %s/line %d: FOUND DIGIT = \"%s\" at $%1.4x\n",
                    __FUNCTION__, __LINE__,
                    str, vm->cursor);
          } 
          //
          if( isalpha(ch) )
          {
              //
              cbmvm_head_move_back(vm);
              cbmvm_parse_simple_statement(vm, str);
              cbmvm_command_queue_add(vm, str);
              if(cbmvm_debug_messages)
                  printf("*** %s/line %d: FOUND ALPHABET = '%s' at $%1.4x\n",
                      __FUNCTION__, __LINE__,
                      str, vm->cursor);
 
         }
       }
          
       // Reset zero counter, not end of the program ?
       zeroes = 0;

     // FOR LOOP, goes through the singe statement we have:
    }
       
       //
       return 0;
}

// Beginning of statement: Reset Statement Variables, ETC.
/*********************************************************/
int cbmvm_reset_at_statement_beginning(CBMVM *vm)
{
    int ch;

    CBMVM_DEBUG_LINE
    
    //
    //***********************************************************************
    // Init variables and structures,
    // after this we can pretty much execute the mainloop of basic interpreter (token / string parser).
    // Also retried on GOTO and GOSUB commands...
    cbmvm_init_high_level_parsing(vm);
}

/**** MAIN HIGH-LEVEL BASIC INTERPRETER FUNCTION ****/
//
int cbmvm_run_basic_program(CBMVM *vm)
{
    int ch,ch2,i,i2,i3,i4,line_number,token,
      poke_ad,poke_value,zeroes,ad,rv;
    char str[COMMON_STR_LENGTH];

    CBMVM_DEBUG_LINE
        
    //
    vm->basic_execution_ad = vm->ad_basic_0800+1;
    
    // 0x0800 should be "0".
    if( cbmvm_peek(vm, vm->ad_basic_0800) != 0 )
    {
        //
        printf("[%s/%s/line %d]: Basic Error. Memory corruption? Peeking memory at $%1.4x returns non-zero.\n",
            __FUNCTION__, __FILE__, __LINE__,
            vm->ad_basic_0800);
        return 1;
    }
    


    
    
    //***********************************************************************
    // THE MAIN LOOP FOR PARSING, A TOKEN HUNT SESSION, ETC. PARSING.
    // (HIGH-LEVEL)
    //***********************************************************************
    //
    // But first init variables and structures,
    // after this we can pretty much execute the mainloop of basic interpreter (token / string parser).   
    cbmvm_reset_at_statement_beginning(vm);

    // ** THE ACTUAL MAIN LOOP :
    for(;; )
    {
        //
        if(cbmvm_debug_messages)
        {
            // DEBUGGING.
            //
            printf("\n=================================================\n");
            printf("==> Beginning Of A New Statement At $%1.4x\n",
                 vm->cursor);
            printf("=================================================\n");
            cbmvm_hexdump_basic_program(vm,vm->cursor,256);
            //printf("Press [Enter] To Continue:\n");
            //waitkey();
            //printf("Enter Pressed ... Continuing :\n");
        }
        // GET, SORT, EXECUTE
        // ==================
        //
        // This is what it does continously until end of program.
        //
        // PARSE A SINGLE STATEMENT AT TIME,
        // CALL FUNCTION TO DO THIS:
        // Return Value: Non-Zero: Got error
        // 1/4) INIT
        if(cbmvm_debug_messages)
            printf("*** Reset Command Queue:\n");
        rv = cbmvm_reset_command_queue(vm);
        // 2/4) GET (handles also GOTO, GOSUB,
        // RETURN statements REQUESTS,
        // like GOTO 0, it will go to line 0 or print error)
        if(cbmvm_debug_messages)
            printf("*** Produce Command Queue:\n");
        if( (rv=cbmvm_produce_command_queue(vm))==-1 )
            break;
        // RV = 123 : End OF Basic Program.
        if(rv==123) { if(cbmvm_debug_messages) printf("RETURN VALUE 123 => END OF FILE. Exit.\n"); /** End Of File / Basic Program Reached **/ break; }
        // 3/4) SORT
        if(cbmvm_debug_messages)
            printf("** Sort Command Queue:\n");
        rv = cbmvm_sort_command_queue(vm);
        // 4/4) EXECUTE (RUN)
        if(cbmvm_debug_messages)
        {
            printf("\n");
            printf("***************************\n");
            printf("** Execute Command Queue **\n");
            printf("***************************\n");
        }
        rv = cbmvm_execute_command_queue(vm);

        // Skip Terminators (Fixes The Produce Command Queue.
        if( (cbmvm_peek_preview_input(vm)==0) )
        {
           // Skip white space.
           for(;;)
           {
               ch=cbmvm_input_program(vm);
               if(ch==-1)
               {
                   break;
               }
               if(ch!=0)
               {
                   cbmvm_head_move_back(vm);
                   break;
               }
           }
        }
        
        //
        if(vm->end_of_program)
        {
            printf("** End Of Program\n");
            return 0;
        }
        
        //
        if(rv<0)
        {
            // Error.
            if(cbmvm_debug_messages)
                printf("** Error");
            break;
        }

        //
        if(cbmvm_debug_messages)
            printf("\n\n");
    }
    
    //printf("End of basic program.\n");
    //sleep(10);
 
    // Happily returning back.
    return 0;
}

//
int cbmvm_validate_basic_program(CBMVM *vm)
{
    CBMVM_DEBUG_LINE
    
    // Good.
    return 0;
}

//
int cbmvm_set_basic_cursor(CBMVM *vm, int new_cursor_location)
{
    CBMVM_DEBUG_LINE

    //
    vm->cursor = new_cursor_location;
    return 0;
}

//
int cbmvm_get_basic_cursor(CBMVM *vm)
{
    CBMVM_DEBUG_LINE

    return vm->cursor;
}

int cbmvm_clear_ram(CBMVM *vm)
{
    CBMVM_DEBUG_LINE
    
    // Clear execution memory space
    // (e.g. basic program space as well will be cleared).
    if(vm->ram == NULL)
    {
     vm->l_ram = DEFAULT_CBMVM_RAM_SIZE_K*1024;
     vm->ram = malloc(vm->l_ram);
    }
    memset(vm->ram, 0, vm->l_ram);
    return 0;
}

//
int cbmvm_init_command_queue_array(CBMVM *vm)
{
    int i = 0;

    CBMVM_DEBUG_LINE

    //
    if(vm->command_queue==NULL)
    {
        vm->max_command_queue = MAX_LENGTH_OF_MATH_FORMULA;
        vm->command_queue = malloc( sizeof(void*) * vm->max_command_queue );
        if(vm->command_queue == NULL) { return 1; } // ERROR 1.
        vm->n_command_queue =   0;
        for(i=0; i<vm->max_command_queue; i++)
        {
           vm->command_queue[i] = malloc(COMMON_STR_LENGTH);
           if(vm->command_queue[i]==NULL)
           {
             return 2; // ERROR 2.
           }
           memset(vm->command_queue[i], 0, COMMON_STR_LENGTH);
        }
    }
    
    //
    return 0;
}

//
int cbmvm_init_variables(CBMVM *vm)
{
    int i,i2;
    
    //
    vm->max_vars =	MAX_VARIABLES;
    vm->n_vars =	0;
    
    //
    vm->varname =  malloc( sizeof(void*) * vm->max_vars );
    vm->varvalue = malloc( sizeof(void*) * vm->max_vars );
    
    //
    for(i=0; i<vm->max_vars; i++)
    {
        vm->varname[i] = malloc(MAX_VARIABLE_NAME_LENGTH);
        vm->varvalue[i] = malloc(MAX_VARIABLE_CONTENT_LENGTH);
        memset(vm->varname[i], 0, MAX_VARIABLE_NAME_LENGTH);
        memset(vm->varvalue[i], 0, MAX_VARIABLE_CONTENT_LENGTH);
    }
    
    //
}

// COMPUTER HARD RESET.
int cbmvm_hard_reset(CBMVM *vm)
{
    CBMVM_DEBUG_LINE

    // Clear RAM.
    cbmvm_clear_ram(vm);
    // Start at the beginning of the basic program.
    cbmvm_set_basic_cursor(vm, CBM_BASIC_PROGRAM_START+1);
    //
    cbmvm_init_command_queue_array(vm);
    // By default there is no line, until 0x1C, int line_number reached.
    vm->line_number = -1;
    
    //
    cbmvm_init_variables(vm);

    //
    return 0;
}

//
CBMVM *new_cbmvm(int argc, char **argv)
{
    CBMVM *vm;

    CBMVM_DEBUG_LINE    

    //
    vm = malloc(sizeof(CBMVM));
    if(vm==NULL){return NULL;}
    memset(vm, 0, sizeof(CBMVM));

    //
    return vm;
}

////////////////////////////////////////////////////////////////////////////////
//
// MAIN ENGINE HIGH LEVEL LOGIC.
//
int start_cbmvm_engine(int argc, char **argv)
{
    CBMVM *vm;
    int rv;
    
    CBMVM_DEBUG_LINE
    
    //
    if( (vm = new_cbmvm(argc,argv))==NULL)
    {
        printf("[%s/%s/line %d]: Error. Failed at calling of new_cbmvm function.\n",
            __FUNCTION__, __FILE__, __LINE__);
            return 2;
    }

    // Clears the memory and resets the VM variable set and structures.
    if( (rv = cbmvm_hard_reset(vm)) )
    {
        printf("[%s/%s/line %d]: Error. Failed at calling of cbmvm_hard_reset, return value = %d.\n",
            __FUNCTION__, __FILE__, __LINE__,
            rv);
       goto exitprogram1;
    }
    
    // Loads a basic program at 0801 in poke RAM.
    if( (rv=cbmvm_basic_load(vm, argv[1])) )
    {
        printf("[%s/%s/line %d]: Error. Can't load basic program \"%s\". cbmvm_basic_load: return Value=%d.\n",
            __FUNCTION__, __FILE__, __LINE__,  argv[1], rv);
        goto exitprogram1;
    }
    
    //
    if( cbmvm_validate_basic_program(vm) )
    {
        printf("[%s/%s/line %d]: Error: Basic Program Validation: Invalid basic program: \"%s\".\n",
            __FUNCTION__, __FILE__, __LINE__,  argv[1]);
        goto exitprogram1;
    }
    
    // * * * * * * * * * * * * * * * 
    cbmvm_run_basic_program(vm);
    
exitprogram1:
    //
    cbmvm_free_machine(vm);
    
    //
    return 0;
}
