//
#ifndef __INCLUDED_CBMVM_HOST_VARIABLES_H__
#define __INCLUDED_CBMVM_HOST_VARIABLES_H__

//
typedef struct
{
    //
    unsigned char *ram;
    int l_ram;
    int basic_execution_ad;
    // Where are going at the moment, basic line number:
    int line_number;
    // Basic cursor. Defaults to 0x0801 (CBM BASIC V2).
    int cursor,
    // End of basic program according to the load up of the program.
        basic_prg_end;
    // Commonly 2 or 7 (C64 or C128).
    int basic_version;
    // command queue, e.g. single statement of a math formula
    // e.g.
    // "a"
    // + (token code in hex, e.g. 0x99)
    // "1"
    // max_formula = maximum number of
    // formula strings could be included in the database.
    // This is the only way if any to split the mathematic forumals
    // to actually parseable commands.
    char **command_queue;
    int n_command_queue;
    int max_command_queue;
    // Parsing
    int zeroes;
    int execute_jump_to;
    // -1 = none
    int current_token;
    // String variable mode?
    int string_string_mode;
    // Float variable mode?
    int float_variable_mode;

    // VARIABLE DATABASE
    //
    int n_vars, max_vars;
    char **varname;
    char **varvalue;
    //
    char *dest_var_name_ptr;
    char *dest_var_value_ptr;
    // This token will be called at the end of statement.
    // Cleared at the beginning of each new statement.
    int execute_nr_token_at_the_end_of_statement;
    // Non-zero => end program.
    int end_of_program;
    // 0x01c01 Commodore 128 Basic V7
    // 0x00801 Commodore 64 Basic V2
    int ad_basic_0800;
    // 0x08 COMMODORE 64, BASIC V2
    // 0x1C COMMMODORE 128, BASIC V7
    int byte_nr_line_number_indicator;
}CBMVM;

//
#endif

//