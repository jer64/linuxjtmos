start:
; Basic program, load to 0x0801.
	db 0x01,0x08

; Basic version ID.
db 0x15

; PRINT "HELLO WORLD"
; ===================
; BASIC LINE NUMBER 0
db 0x08
; Line Number
db 0x00,0x00
; 0x99 token (for "print")
db 0x99
;
db ' "HELLO WORLD"'
; Terminator:
db 0

;
db 0x23 ; "#"

; BASIC LINE NUMBER 1
db 0x08
db 0x01,0x00
; 0x97 token (for "poke")
db 0x97
db " 53280,7"
db 0x00

;
db 0x31

; BASIC LINE NUMBER 2
db 0x1C
db 0x02,0x00
; 0x97 token (for "poke")
db 0x97
db " 53281,0"

db 0,0,0,0

;
