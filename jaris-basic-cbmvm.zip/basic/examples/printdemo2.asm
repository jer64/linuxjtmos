start:
; Basic program, load to 0x0801.
	db 0x01,0x08

; Basic version ID.
db 0x15

; PRINT "HELLO WORLD"
; ===================
; BASIC LINE NUMBER 0
db 0x08
; Line Number
db 0x00,0x00
; 0x99 token (for "print")
db 0x99
;
db ' "hello world ";'
; Terminator:
db 0

;
db 0x1f ; "?"

db 0x08, 0x01,0x00 ; next token coming code and line number 1
db 0x89, ' 0' ; 0x89=GOTO  TOKEN CODE, jumps to line "0".
db 0,0,0,0

;
