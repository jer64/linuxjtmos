JTMOS V61 - Turbo C console/BGI compatibility and Filer GUI
===========================================================
Date: 2026-08-21

* Public text console coordinates are consistently Turbo C compatible: 1-based.
  gotoxy(1,1), wherex()/wherey() and window(1,1,80,25) now agree.
* SCREEN internals remain 0-based; the public window() API translates to them.
* Added SYS_window=113 and SYS_copyfromthread=114.
* CopyFromThread() lets the GraOS server safely copy an application framebuffer
  from its process mapping into server-owned memory.
* Modern libc GraOS calls are no longer ENOSYS stubs. createWindow(),
  addFrameBuffer(), refreshWindow(), closeWindow() and createButton() use Postman.
* GraOS GSID_ADDFRAMEBUFFER now supports 8-bit bitmap components; refresh copies
  the latest pixels and windowDraw composites them into the desktop.
* Replaced the historical text-only filer.c with the Explorer-style GraOS Filer
  frontend already present in the source tree. Its file-manager component is now
  backed by a real bitmap framebuffer instead of failing at addFrameBuffer().
* edit.c and snake.c explicitly normalize to window(1,1,80,25).
* Added Turbo C helpers randomize(), kbhit(), getche(), clreol(), delline(),
  insline() and a new graphics.h software BGI layer.
* BGI functions include initgraph/closegraph, putpixel/getpixel, line/lineto,
  rectangle/bar/bar3d, circle/ellipse/arc/pieslice/sector, fill/line settings,
  floodfill, viewport, simple text output and standard color constants.

Additional V61 integration
--------------------------
* GraOS forwards client-area mouse clicks as GSID_MOUSEBUTTON and keyboard input
  as GSID_KEYPRESSED to the selected application window. Event coordinates are
  relative to the application framebuffer, matching Filer's 604x408 UI.
* GraOS response/exit/event packets carry the native JTMOS GraOS magic value.
* Explorer Filer, edit, snake and bgidemo are built as static ELF32 applications
  with the current V60/V61 crt0 executable identification strings.
* install.img.nz now carries filer.bin, edit.bin, snake.bin, bgidemo.bin and the
  rebuilt graos.bin in addition to the existing installer utilities.
* buildimage.sh uses the repository-local ./img tool, preventing an old jtm32.img
  from being silently retained when `img` is absent from PATH.

Validation
----------
* Modern libc `make check` passes in application and kernel profiles.
* kernel32 full C build and link pass; kernel32.bin and dosker32.bin are produced.
* graos.bin, filer.bin, edit.bin, snake.bin and bgidemo.bin build successfully.
* install.img.nz and utilsdisk.img are regenerated, and jtm32.img is rebuilt from
  boot32/boot.bin + the V61 kernel + the new sys: payload.
* QEMU runtime validation is still required for on-screen Filer/BGI behaviour.
