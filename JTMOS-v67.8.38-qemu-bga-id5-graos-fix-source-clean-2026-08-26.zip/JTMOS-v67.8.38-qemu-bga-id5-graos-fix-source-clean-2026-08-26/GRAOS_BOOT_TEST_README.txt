JTMOS V23 GraOS VESA bring-up
=============================

Boot contract
-------------
boot32/boot.asm must be assembled with VESA_ENABLED=1.  The boot loader
statically selects VBE mode 0x101 with bit 14 set: 640x480x8 + linear
framebuffer.  The VBE ModeInfoBlock is left at physical 0x4000.

Kernel contract
---------------
VesaProbe() accepts only:
  width  = 640
  height = 480
  bpp    = 8
  planes = 1
  packed-pixel memory model
  valid linear framebuffer

VesaActivate() maps/activates the LFB after paging.  GraOSBootReady() refuses
to install or start GraOS unless VesaGraOSReady() is true.

Graphics ABI
------------
SYS_vgadrawframe (35) is retained as the ABI number, but it is no longer a
legacy VGA aperture operation.  It accepts only:
  buffer: packed 640x480x8 frame
  offset: 0
  length: 307200
and copies the frame to vesa_frame_buf, honoring hardware pitch.

GraOS V23
---------
The boot package contains only /bin/graos.bin.  The application allocates one
307200-byte software framebuffer, renders an integer diagnostic plasma and
presents complete frames with drawframe().  No taskbar, window manager, font,
background, mouse cursor, Postman graphics or VGA plane code is active.
