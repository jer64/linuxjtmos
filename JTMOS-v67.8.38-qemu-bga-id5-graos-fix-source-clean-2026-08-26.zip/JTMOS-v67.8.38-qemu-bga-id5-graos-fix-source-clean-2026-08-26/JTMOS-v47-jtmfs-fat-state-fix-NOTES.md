# JTMOS V47 — JTMFS/FlexFAT state fix

V47 keeps the V46 demand-paged FAT cache, but fixes the state transitions around it.

The key semantic change is that `DNR/DB == 0/0` is the synthetic JTMOS namespace root `/`. It is not a physical JTMFS directory. Device paths such as `/ram` and `/hda` therefore resolve directly to the selected block device's JTMFS root (`INFO BLOCK.data_offs`) and do not depend on a formatted boot floppy or a pre-existing current directory.

The JTMFAT INFO BLOCK API is now split by behavior: `jtmfat_getinfoblock()` remains cached/fast, while `jtmfat_chdev()` really refreshes the INFO BLOCK from media. Non-removable `jtmfat_isJTMFS()` checks are cached so ordinary pathname resolution does not turn into disk I/O.

Formatting now has an explicit transaction-like sequence: flush old FAT state, write new INFO BLOCK, invalidate old FlexFAT/DirDB state, reload INFO BLOCK, construct FAT, flush, drop the cache, read FAT back from disk, create root, flush again, drop cache again, and verify the root FAT EOF marker from disk. This makes cache bugs visible as `mkfs` errors instead of reporting a false success.
