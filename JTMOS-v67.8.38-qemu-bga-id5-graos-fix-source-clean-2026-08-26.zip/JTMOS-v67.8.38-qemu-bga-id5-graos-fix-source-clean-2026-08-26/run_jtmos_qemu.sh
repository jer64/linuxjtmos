#!/bin/sh
# JTMOS V67.8.35 QEMU launcher
#
# A: JTMOS system/boot floppy (jtm32.img)
# B: JTMOS 1.44 MiB extended utilities floppy (utils1440.img)
# HDA: persistent JTMOS IDE disk
# COM1: serial debug log (serial_output.log)
# COM2: RFC1055 SLIP pipe
# CPU: QEMU core2duo model (SSE3/SSSE3 capable; JTMOS still keeps i486 fallback)
# Audio: Gravis UltraSound, IRQ 5
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

# Optional positional overrides:
#   ./run_jtmos_qemu.sh [jtm32.img] [hd_jtmos.img] [utils1440.img]
# Environment variables take precedence over positional/default values.
FLOPPY=${JTMOS_FLOPPY:-${1:-$SCRIPT_DIR/jtm32.img}}
HDD=${JTMOS_HDD:-${2:-$SCRIPT_DIR/hd_jtmos.img}}
UTILS_FLOPPY=${JTMOS_UTILS_FLOPPY:-${3:-$SCRIPT_DIR/utils1440.img}}

RUNTIME=${JTMOS_SLIP_RUNTIME:-${XDG_RUNTIME_DIR:-/tmp}/jtmos-slip}
SLIP_PIPE=${JTMOS_SLIP_PIPE:-$RUNTIME/jtmos-slip}
SERIAL_LOG=${JTMOS_SERIAL_LOG:-$SCRIPT_DIR/serial_output.log}
QEMU_CPU=${JTMOS_QEMU_CPU:-coreduo}

if ! command -v qemu-system-i386 >/dev/null 2>&1; then
  echo "qemu-system-i386 not found in PATH." >&2
  exit 127
fi

if [ ! -f "$FLOPPY" ]; then
  echo "JTMOS boot floppy not found: $FLOPPY" >&2
  echo "Build it with: make image" >&2
  exit 1
fi

if [ ! -f "$UTILS_FLOPPY" ]; then
  echo "JTMOS extended utilities floppy not found: $UTILS_FLOPPY" >&2
  echo "Build it with: make utilsimage" >&2
  echo "(A normal top-level 'make' builds both images.)" >&2
  exit 1
fi

# Create the persistent IDE disk on first run.
if [ ! -f "$HDD" ]; then
  "$SCRIPT_DIR/make_hd_jtmos.sh" "$HDD"
fi

# COM2 is the default JTMOS RFC1055 SLIP line. ubuntu-slip/slip-up.sh creates
# the two QEMU pipe endpoints and connects them to Linux slattach -p slip.
if [ ! -p "$SLIP_PIPE.in" ] || [ ! -p "$SLIP_PIPE.out" ]; then
  echo "JTMOS SLIP FIFOs are not ready:" >&2
  echo "  $SLIP_PIPE.in" >&2
  echo "  $SLIP_PIPE.out" >&2
  echo "Run: $SCRIPT_DIR/ubuntu-slip/slip-up.sh" >&2
  exit 1
fi

echo "JTMOS QEMU configuration:"
echo "  floppy A: $FLOPPY"
echo "  floppy B: $UTILS_FLOPPY"
echo "  IDE HDA:   $HDD"
echo "  machine:   pc"
echo "  CPU:       $QEMU_CPU (SSE3-capable default)"
echo "  VGA:       QEMU Standard VGA / Bochs VBE DISPI"
echo "  GUS:       IRQ 5"
echo "  NE2000:    ISA 0x300 IRQ 9, QEMU user-mode DHCP"
echo "  COM1 log:  $SERIAL_LOG"
echo "  SLIP COM2: $SLIP_PIPE"

exec qemu-system-i386 -machine pc -cpu "$QEMU_CPU" -m 512 -vga std \
  -drive file="$FLOPPY",format=raw,if=floppy,index=0 \
  -drive file="$UTILS_FLOPPY",format=raw,if=floppy,index=1 \
  -drive file="$HDD",format=raw,if=ide,index=0,media=disk \
  -device gus,irq=5 \
  -netdev user,id=jtmosnet \
  -device ne2k_isa,netdev=jtmosnet,iobase=0x300,irq=9 \
  -serial "file:$SERIAL_LOG" \
  -serial "pipe:$SLIP_PIPE" \
  -boot a
