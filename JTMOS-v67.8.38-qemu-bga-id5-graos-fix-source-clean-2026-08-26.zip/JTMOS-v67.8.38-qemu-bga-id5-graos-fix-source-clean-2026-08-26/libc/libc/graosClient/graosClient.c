// GraOS client message API, V24 VESA bring-up.
#include <stdio.h>
#include <jtmos/msgbox.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/process.h>
#include "graosClient.h"
static int graosPID=-1;
static void init_request(MSG *m, GUICMD **cmd, int id)
{
    memset((char*)m,0,sizeof(*m));
    m->protocol=MB_PROTOCOL_GRAOS;
    m->amount=sizeof(GUICMD);
    *cmd=(GUICMD*)m->buf;
    (*cmd)->magic=0xFCE2E37BUL;
    (*cmd)->id=id;
}
int getGraosPID(void)
{
    if(graosPID<=0) graosPID=GetThreadPID(GRAOS_SERVER_PID_NAME);
    return graosPID;
}
void graosCheck(void)
{
    if(getGraosPID()<=0){printf("This program requires GraOS.\n");exit(1);}
}
void connectGraos(void)
{
    graosCheck();
    startMessageBox();
}
int waitGraosAnswer(void)
{
    MSG m; GUICMD *cmd;
    for(;;){
        if(receiveMessage(&m)){
            if(m.protocol!=MB_PROTOCOL_GRAOS) continue;
            cmd=(GUICMD*)m.buf;
            if(cmd->id==GSID_RESPONSE) return (int)cmd->rval;
            /* Leave asynchronous GUI notifications to the application's
             * normal message loop; connection setup should not mistake them
             * for request responses. */
        }
        SwitchToThread();
    }
}
int refreshWindow(int wid)
{
    MSG m;GUICMD *cmd;if(getGraosPID()<=0)return -1;init_request(&m,&cmd,GSID_REQUESTREFRESH);cmd->v[0]=wid;sendMessage(&m,graosPID);return waitGraosAnswer();
}
int createButton(int wid,int x1,int y1,int x2,int y2,int type,const char *caption)
{
    MSG m;GUICMD *cmd;if(getGraosPID()<=0)return -1;init_request(&m,&cmd,GSID_CREATEBUTTON);cmd->v[0]=wid;cmd->v[1]=x1;cmd->v[2]=y1;cmd->v[3]=x2;cmd->v[4]=y2;cmd->v[5]=type;strncpy(cmd->str,caption?caption:"",255);cmd->str[255]=0;sendMessage(&m,graosPID);return waitGraosAnswer();
}
int addFrameBuffer(int wid,BYTE *buf,int x,int y,int width,int height,int bpp,int type,int terID)
{
    MSG m;GUICMD *cmd;if(getGraosPID()<=0)return -1;init_request(&m,&cmd,GSID_ADDFRAMEBUFFER);cmd->v[0]=wid;cmd->v[1]=x;cmd->v[2]=y;cmd->v[3]=width;cmd->v[4]=height;cmd->v[5]=bpp;cmd->v[6]=type;cmd->v[7]=terID;cmd->ptr[0]=buf;sendMessage(&m,graosPID);return waitGraosAnswer();
}
int closeWindow(int wid)
{
    MSG m;GUICMD *cmd;if(getGraosPID()<=0)return -1;init_request(&m,&cmd,GSID_CLOSEWINDOW);cmd->v[0]=wid;sendMessage(&m,graosPID);return waitGraosAnswer();
}
int createWindow(int x,int y,int width,int height,const char *caption,int type)
{
    MSG m;GUICMD *cmd;if(getGraosPID()<=0)return -1;init_request(&m,&cmd,GSID_OPENWINDOW);cmd->v[0]=x;cmd->v[1]=y;cmd->v[2]=width;cmd->v[3]=height;cmd->v[4]=type;strncpy(cmd->str,caption?caption:"",255);cmd->str[255]=0;sendMessage(&m,graosPID);return waitGraosAnswer();
}

/* Legacy GraOS client compatibility wrappers for the V67.6.1 label widget. */
int createLabel(int wid,int x,int y,int width,int height,int id,int fg,int bg,int align,const char *text)
{
    MSG m;GUICMD *cmd;if(getGraosPID()<=0)return -1;init_request(&m,&cmd,GSID_CREATELABEL);
    cmd->v[0]=wid;cmd->v[1]=x;cmd->v[2]=y;cmd->v[3]=width;cmd->v[4]=height;
    cmd->v[5]=id;cmd->v[6]=fg;cmd->v[7]=bg;cmd->v[8]=align;
    strncpy(cmd->str,text?text:"",255);cmd->str[255]=0;sendMessage(&m,graosPID);return waitGraosAnswer();
}
int setLabelText(int wid,int id,const char *text)
{
    MSG m;GUICMD *cmd;if(getGraosPID()<=0)return -1;init_request(&m,&cmd,GSID_SETLABELTEXT);
    cmd->v[0]=wid;cmd->v[1]=id;strncpy(cmd->str,text?text:"",255);cmd->str[255]=0;sendMessage(&m,graosPID);return waitGraosAnswer();
}
int setLabelStyle(int wid,int id,int fg,int bg,int align)
{
    MSG m;GUICMD *cmd;if(getGraosPID()<=0)return -1;init_request(&m,&cmd,GSID_SETLABELSTYLE);
    cmd->v[0]=wid;cmd->v[1]=id;cmd->v[2]=fg;cmd->v[3]=bg;cmd->v[4]=align;sendMessage(&m,graosPID);return waitGraosAnswer();
}
int removeLabel(int wid,int id)
{
    MSG m;GUICMD *cmd;if(getGraosPID()<=0)return -1;init_request(&m,&cmd,GSID_REMOVELABEL);
    cmd->v[0]=wid;cmd->v[1]=id;sendMessage(&m,graosPID);return waitGraosAnswer();
}


/* V67.8 editable TextBox compatibility wrappers. */
int createTextBox(int wid,int x,int y,int width,int height,int id,int maxlen,const char *text)
{
    MSG m;GUICMD *cmd;if(getGraosPID()<=0)return -1;init_request(&m,&cmd,GSID_CREATETEXTBOX);
    cmd->v[0]=wid;cmd->v[1]=x;cmd->v[2]=y;cmd->v[3]=width;cmd->v[4]=height;cmd->v[5]=id;cmd->v[6]=maxlen;
    strncpy(cmd->str,text?text:"",255);cmd->str[255]=0;sendMessage(&m,graosPID);return waitGraosAnswer();
}
int setTextBoxText(int wid,int id,const char *text)
{
    MSG m;GUICMD *cmd;if(getGraosPID()<=0)return -1;init_request(&m,&cmd,GSID_SETTEXTBOXTEXT);
    cmd->v[0]=wid;cmd->v[1]=id;strncpy(cmd->str,text?text:"",255);cmd->str[255]=0;sendMessage(&m,graosPID);return waitGraosAnswer();
}
int getTextBoxText(int wid,int id,char *text,int cap)
{
    MSG m,r;GUICMD *cmd,*reply;int n;
    if(getGraosPID()<=0||!text||cap<=0)return -1;init_request(&m,&cmd,GSID_GETTEXTBOXTEXT);cmd->v[0]=wid;cmd->v[1]=id;
    sendMessage(&m,graosPID);
    for(;;){if(receiveMessage(&r)){if(r.protocol!=MB_PROTOCOL_GRAOS)continue;reply=(GUICMD*)r.buf;if(reply->id!=GSID_RESPONSE)continue;if((int)reply->rval<0){text[0]=0;return(int)reply->rval;}n=0;while(n<cap-1&&reply->str[n]){text[n]=reply->str[n];n++;}text[n]=0;return 0;}SwitchToThread();}
}
int removeTextBox(int wid,int id)
{
    MSG m;GUICMD *cmd;if(getGraosPID()<=0)return -1;init_request(&m,&cmd,GSID_REMOVETEXTBOX);cmd->v[0]=wid;cmd->v[1]=id;sendMessage(&m,graosPID);return waitGraosAnswer();
}

int JtmosGraOSMinimizeWindow(int wid){MSG m;GUICMD*c;if(getGraosPID()<=0)return-1;init_request(&m,&c,GSID_MINIMIZEWINDOW);c->v[0]=wid;sendMessage(&m,graosPID);return waitGraosAnswer();}
int JtmosGraOSRestoreWindow(int wid){MSG m;GUICMD*c;if(getGraosPID()<=0)return-1;init_request(&m,&c,GSID_RESTOREWINDOW);c->v[0]=wid;sendMessage(&m,graosPID);return waitGraosAnswer();}
