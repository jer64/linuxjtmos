#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>
#include <jtmos/filefind.h>
#include <jtmos/video.h>
#include <jtmos/audio.h>
#include <jtmos/network.h>
#include <jtmos/directdisk.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <fcntl.h>
#include <unistd.h>
int findfirst(const char*p,FFBLK*f){return(int)jtmos_syscall7(SYS_findfirst,(uintptr_t)p,(uintptr_t)f,0,0,0,0);} int findnext(int d,FFBLK*f){return(int)jtmos_syscall7(SYS_findnext,d,(uintptr_t)f,0,0,0,0);}
int drawframe(const void*b,...){va_list a;va_start(a,b);int o=va_arg(a,int),l=va_arg(a,int);va_end(a);return(int)jtmos_syscall7(SYS_vgadrawframe,(uintptr_t)b,o,l,0,0,0);} int drawframe1(const void*b,...){return drawframe(b,0,64000);} void waitretrace(void){jtmos_syscall7(SYS_vgawaitretrace,0,0,0,0,0,0);} int vgaselectplane(int p){return(int)jtmos_syscall7(SYS_vgaselectplane,p,0,0,0,0,0);} int setpalettemap(int offs,...){(void)offs;return 0;} int setpalette(int a,int b,int c,int d){return(int)jtmos_syscall7(SYS_vgasetpalette,a,b,c,d,0,0);} int setvmode(int m){if(m==0x105)return(int)jtmos_syscall7(SYS_graosgraphics,0,0,0,0,0,0);return 0;} int setmode(int m){return setvmode(m);}
int opensocket(unsigned long i,int p){return(int)jtmos_syscall7(SYS_opensocket,i,p,0,0,0,0);} int closesocket(int h){return(int)jtmos_syscall7(SYS_closesocket,h,0,0,0,0,0);} int readsocket(int h,void*b,int n){return(int)jtmos_syscall7(SYS_readsocket,h,(uintptr_t)b,n,0,0,0);} int writesocket(int h,const void*b,int n){return(int)jtmos_syscall7(SYS_writesocket,h,(uintptr_t)b,n,0,0,0);} int OpenSocket(DWORD i,int p){return opensocket(i,p);} int CloseSocket(int h){return closesocket(h);} int ReadSocket(int h,BYTE*b){return readsocket(h,b,1500);} int WriteSocket(int h,BYTE*b,int n){return writesocket(h,b,n);} int ReceiveRawPacket(int d,BYTE*b){return(int)jtmos_syscall7(SYS_receiverawpacket,d,(uintptr_t)b,0,0,0,0);} int TransmitRawPacket(int d,BYTE*b,int n){return(int)jtmos_syscall7(SYS_transmitrawpacket,d,(uintptr_t)b,n,0,0,0);} int htons(int x){return((x&255)<<8)|((x>>8)&255);}
int getdevnrbyname(const char*n){return(int)jtmos_syscall7(SYS_getdevnrbyname,(uintptr_t)n,0,0,0,0,0);} int getdevicenrbyname(const char*n){return(int)jtmos_syscall7(SYS_getdevicenrbyname,(uintptr_t)n,0,0,0,0,0);} int getdevicename(int d,char*n){long r;if(!n)return -1;n[0]=0;r=jtmos_syscall7(SYS_getdevicename,d,(uintptr_t)n,0,0,0,0);return (r==0 && n[0])?0:-1;} int readblock(int d,DWORD b,void*p){return(int)jtmos_syscall7(SYS_readblock,d,b,(uintptr_t)p,0,0,0);} int writeblock(int d,DWORD b,const void*p){return(int)jtmos_syscall7(SYS_writeblock,d,b,(uintptr_t)p,0,0,0);} int formatDrive(const char*n){int d=getdevnrbyname(n);return(int)jtmos_syscall7(SYS_mkfs,d,0,0,0,0,0);} int fexist(const char*p){int fd=open(p,O_RDONLY);if(fd<0)return 0;close(fd);return 1;} int fsizeof(const char*p){int fd=open(p,O_RDONLY);if(fd<0)return -1;int n=lseek(fd,0,SEEK_END);close(fd);return n;} DWORD syschksum(const void*p,int n){const unsigned char*b=(const unsigned char*)p;DWORD s=0;int i;if(p==NULL||n<0)return 0;for(i=0;i<n;i++)s+=(DWORD)b[i]+1U;return s;}
