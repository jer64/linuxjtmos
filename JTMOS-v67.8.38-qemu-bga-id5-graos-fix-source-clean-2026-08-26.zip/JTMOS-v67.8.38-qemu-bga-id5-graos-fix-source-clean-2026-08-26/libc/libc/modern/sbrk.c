#include <unistd.h>
#include <stdint.h>
#include <errno.h>
#include <jtmos/config.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>

/*
 * POSIX-style process break for JTMOS ELF32 applications.
 *
 * LaunchApp reserves the whole application window before the process starts.
 * sbrk()/brk() therefore do not ask kernel kmalloc for another contiguous
 * region; they only advance a bounded break inside the process-private heap
 * portion of that already mapped window.  This is intentional: it keeps heap
 * growth compatible with V67.4 sparse physical backing.
 */
#ifdef JTMOS_APPLICATION
extern char __jtmos_image_end;

static uintptr_t jtmos_brk_min;
static uintptr_t jtmos_brk_cur;
static uintptr_t jtmos_brk_max;
static int jtmos_brk_ready;

static uintptr_t align_up(uintptr_t value, uintptr_t alignment)
{
    return (value + alignment - 1U) & ~(alignment - 1U);
}

static int brk_init(void)
{
    long raw_size;
    uintptr_t top;

    if(jtmos_brk_ready)
        return 0;

    raw_size = jtmos_syscall7(SYS_GETAMEMSIZE,0,0,0,0,0,0);
    if(raw_size <= 0 || (uintptr_t)raw_size > JTMOS_USER_SIZE) {
        errno = ENOMEM;
        return -1;
    }

    jtmos_brk_min = align_up((uintptr_t)&__jtmos_image_end,
                             JTMOS_HEAP_ALIGNMENT);
    top = JTMOS_USER_BASE + (uintptr_t)raw_size;
    if(top <= JTMOS_APP_STACK_SIZE + JTMOS_APP_GUARD_SIZE) {
        errno = ENOMEM;
        return -1;
    }
    jtmos_brk_max = top - JTMOS_APP_STACK_SIZE - JTMOS_APP_GUARD_SIZE;
    jtmos_brk_max &= ~(uintptr_t)(JTMOS_HEAP_ALIGNMENT - 1U);

    if(jtmos_brk_min < JTMOS_USER_BASE || jtmos_brk_min > jtmos_brk_max) {
        errno = ENOMEM;
        return -1;
    }

    jtmos_brk_cur = jtmos_brk_min;
    jtmos_brk_ready = 1;
    return 0;
}

void *sbrk(intptr_t increment)
{
    uintptr_t oldbrk;
    uintptr_t newbrk;

    if(brk_init() != 0)
        return (void *)-1;

    oldbrk = jtmos_brk_cur;
    if(increment >= 0) {
        uintptr_t inc = (uintptr_t)increment;
        if(inc > jtmos_brk_max - jtmos_brk_cur) {
            errno = ENOMEM;
            return (void *)-1;
        }
        newbrk = jtmos_brk_cur + inc;
    } else {
        uintptr_t dec = (uintptr_t)(-(increment + 1)) + 1U;
        if(dec > jtmos_brk_cur - jtmos_brk_min) {
            errno = ENOMEM;
            return (void *)-1;
        }
        newbrk = jtmos_brk_cur - dec;
    }

    jtmos_brk_cur = newbrk;
    return (void *)oldbrk;
}

int brk(void *addr)
{
    uintptr_t requested;

    if(brk_init() != 0)
        return -1;
    requested = (uintptr_t)addr;
    if(requested < jtmos_brk_min || requested > jtmos_brk_max) {
        errno = ENOMEM;
        return -1;
    }
    jtmos_brk_cur = requested;
    return 0;
}

#else

void *sbrk(intptr_t increment)
{
    (void)increment;
    errno = ENOSYS;
    return (void *)-1;
}

int brk(void *addr)
{
    (void)addr;
    errno = ENOSYS;
    return -1;
}

#endif
