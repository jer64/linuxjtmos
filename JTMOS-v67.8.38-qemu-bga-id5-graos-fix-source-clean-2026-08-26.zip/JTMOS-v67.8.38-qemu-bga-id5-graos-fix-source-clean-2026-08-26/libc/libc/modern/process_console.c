#include <jtmos/process.h>
#include <jtmos/msgbox.h>
#include <jtmos/console.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>
#include <stdio.h>
#include <stdarg.h>
int __jtmos_tc_winleft=1,__jtmos_tc_wintop=1,__jtmos_tc_winright=80,__jtmos_tc_winbottom=25;

/* JTMOS/x86 extension: return the CPU Current Privilege Level.
 * POSIX has no CPU-ring API, but exposing this beside the process helpers
 * gives applications a small POSIX-style query function. */
int getringlevel(void)
{
#if defined(__i386__)
    unsigned short cs;
    __asm__ volatile("movw %%cs,%0" : "=rm"(cs));
    return (int)(cs & 3U);
#else
    return -1;
#endif
}
int getpid(void){return GetCurrentThread();} int GetCurrentThread(void){return(int)jtmos_syscall7(SYS_GETCURRENTTHREAD,0,0,0,0,0,0);} /* Legacy ABI name; JTMOS V65 uses plain PIDs and syscall 70 is identity. */ int GetThreadUniquePID(int p){return p;} int GetThreadPID(const char*n){return(int)jtmos_syscall7(SYS_getthreadpid,(uintptr_t)n,0,0,0,0,0);} int GetThreadPriority(int p){return(int)jtmos_syscall7(SYS_getthreadpriority,p,0,0,0,0,0);} int GetThreadSpending(int p){return(int)jtmos_syscall7(SYS_getthreadspending,p,0,0,0,0,0);} int GetThreadName(int p,char*s){return(int)jtmos_syscall7(SYS_getthreadname,p,(uintptr_t)s,0,0,0,0);} int GetThreadMemoryUsage(int p){return(int)jtmos_syscall7(SYS_getthreadmemoryusage,p,0,0,0,0,0);} int GetThreadCount(void){return(int)jtmos_syscall7(SYS_getthreadcount,0,0,0,0,0,0);} int GetCPUStats(JTMOS_CPU_STATS*s){if(!s)return -1;return(int)jtmos_syscall7(SYS_getcpustats,(uintptr_t)s,sizeof(*s),0,0,0,0);} void SwitchToThread(void){(void)jtmos_syscall7(SYS_switchtothread,0,0,0,0,0,0);} int SwitchToThreadEx(int p){return(int)jtmos_syscall7(SYS_switchtothreadex,p,0,0,0,0,0);} unsigned long GetTickCount(void){return(unsigned long)jtmos_syscall7(SYS_GETTICKCOUNT,0,0,0,0,0,0);} int GetSeconds(void){return(int)jtmos_syscall7(SYS_getseconds,0,0,0,0,0,0);} void Sleep(unsigned long m){jtmos_syscall7(SYS_milsleep,m,0,0,0,0,0);} void MilSleep(int m){Sleep(m);} int WaitProcessTermination(int p){return(int)jtmos_syscall7(SYS_waitprocterm,p,0,0,0,0,0);} int diskChange(int d){return(int)jtmos_syscall7(SYS_diskchange,d,0,0,0,0,0);} /* SYS_cexec EBX=fname, ECX=wait_for_termination, EDX=workdir,
 * ESI=&pid, EDI=terminal.  Keep these names aligned with the original JTMOS
 * libc contract: cexec() is foreground/waiting, bgexec() returns after the
 * child has been created.  V67.4 accidentally reversed these two flags,
 * which froze GraOS when its GUI thread launched the Squirrel Shell. */
static int jtmos_exec_ex(const char *f,const char *w,int t,int wait_for_termination)
{
    int pid=0;
    long rc;
    if(!f || !w) return 0;
    rc=jtmos_syscall7(SYS_cexec,(uintptr_t)f,(uintptr_t)wait_for_termination,
                      (uintptr_t)w,(uintptr_t)&pid,(uintptr_t)t,0);
    return rc<0?0:pid;
}
int cexecEx(const char*f,const char*w,int t){return jtmos_exec_ex(f,w,t,JTMOS_EXEC_WAIT);}
int cexec(const char*f,const char*w){return cexecEx(f,w,-1);}
int bgexecEx(const char*f,const char*w,int t){return jtmos_exec_ex(f,w,t,JTMOS_EXEC_BACKGROUND);}
int bgexec(const char*f,const char*w){return bgexecEx(f,w,-1);} int OutputTerminalKeyboardBuffer(int t,int c){return(int)jtmos_syscall7(SYS_outputterminalkeyboardbuffer,t,c,0,0,0,0);} int InputTerminalKeyboardBuffer(int t){return(int)jtmos_syscall7(SYS_inputterminalkeyboardbuffer,t,0,0,0,0,0);} int CreateTerminal(void){return(int)jtmos_syscall7(SYS_createterminal,0,0,0,0,0,0);} int NewTerminal(void){return(int)jtmos_syscall7(SYS_newterminal,0,0,0,0,0,0);} int SetTerminalOwner(int t,int p){return(int)jtmos_syscall7(SYS_setterminalowner,t,p,0,0,0,0);} int GetTerminalOwner(int t){return(int)jtmos_syscall7(SYS_getterminalowner,t,0,0,0,0,0);} int GetCursorLocation(int t){return(int)jtmos_syscall7(SYS_getcursorlocation,t,0,0,0,0,0);} int CopyThreadTerminal(int t,BYTE*b){if(!b)return -1;return(int)jtmos_syscall7(SYS_copyterminal,t,(uintptr_t)b,0,0,0,0);} int GetCurrentTerminal(void){return(int)jtmos_syscall7(SYS_getthreadterminal,GetCurrentThread(),0,0,0,0,0);} int GetThreadTerminal(int p){return(int)jtmos_syscall7(SYS_getthreadterminal,p,0,0,0,0,0);} int SetThreadTerminal(int p,int w){return(int)jtmos_syscall7(SYS_setthreadterminal,p,w,0,0,0,0);} int receiveMessage(MSG*m){return(int)jtmos_syscall7(SYS_receivemessage,(uintptr_t)m,0,0,0,0,0);} int sendMessage(MSG*m,int p){return(int)jtmos_syscall7(SYS_sendmessage,(uintptr_t)m,p,0,0,0,0);} void startMessageBox(void){jtmos_syscall7(SYS_activatemsgbox,0,0,0,0,0,0);}
void textcolor(int c){jtmos_syscall7(SYS_textcolor,c,0,0,0,0,0);} void textbackground(int c){jtmos_syscall7(SYS_textbackground,c,0,0,0,0,0);} int wherex(void){return jtmos_syscall7(SYS_WHEREX,0,0,0,0,0,0);} int wherey(void){return jtmos_syscall7(SYS_WHEREY,0,0,0,0,0,0);} void gotoxy(int x,int y){if(x<1||y<1)return;jtmos_syscall7(SYS_GOTOXY,x,y,0,0,0,0);} int window(int l,int t,int r,int b){int rc;if(l<1||t<1||r<l||b<t||r>80||b>25)return 1;rc=(int)jtmos_syscall7(SYS_window,l,t,r,b,0,0);if(rc==0){__jtmos_tc_winleft=l;__jtmos_tc_wintop=t;__jtmos_tc_winright=r;__jtmos_tc_winbottom=b;}return rc;} void clrscr(void){jtmos_syscall7(SYS_CLRSCR,0,0,0,0,0,0);} int getch(void){return jtmos_syscall7(SYS_GETCH,0,0,0,0,0,0);} int getch1(void){return getch();} int wgetch(void){return jtmos_syscall7(SYS_wgetch,0,0,0,0,0,0);} int putch(int c){return jtmos_syscall7(SYS_PUTCH,c,0,0,0,0,0);} int print(const char*s){return jtmos_syscall7(SYS_PUTS,(uintptr_t)s,0,0,0,0,0);} int cprintf(const char*f,...){va_list a;va_start(a,f);int r=vprintf(f,a);va_end(a);return r;} void StretchPrint(const char*s,int n){for(int i=0;s[i]&&i<n;i++)putchar(s[i]);} int getctrl(void){return jtmos_syscall7(SYS_getctrl,0,0,0,0,0,0);} int getalt(void){return jtmos_syscall7(SYS_getalt,0,0,0,0,0,0);}
void gettextinfo(struct text_info *r){if(!r)return;r->winleft=(BYTE)__jtmos_tc_winleft;r->wintop=(BYTE)__jtmos_tc_wintop;r->winright=(BYTE)__jtmos_tc_winright;r->winbottom=(BYTE)__jtmos_tc_winbottom;r->attribute=7;r->normattr=7;r->currmode=3;r->screenheight=25;r->screenwidth=80;r->curx=(BYTE)wherex();r->cury=(BYTE)wherey();}
int GetCTRL(void){return getctrl();} int GetALT(void){return getalt();} void _setcursortype(int t){(void)t;}

extern size_t __jtmos_allocated_bytes;
extern size_t __jtmos_heap_free_bytes(void);
extern char __jtmos_image_start __attribute__((weak));
extern char __jtmos_image_end __attribute__((weak));
DWORD GetMemorySize(void){ return (DWORD)jtmos_syscall7(SYS_GETAMEMSIZE,0,0,0,0,0,0); }
DWORD GetAmountFree(void){ return (DWORD)__jtmos_heap_free_bytes(); }
DWORD GetProgramStart(void){ return (DWORD)(uintptr_t)&__jtmos_image_start; }
DWORD GetProgramEnd(void){ return (DWORD)(uintptr_t)&__jtmos_image_end; }
int KillThread(int pid){ return (int)jtmos_syscall7(SYS_killthread,pid,0,0,0,0,0); }
int IdentifyThread(int pid,const char *name){ return (int)jtmos_syscall7(SYS_identifythread,pid,(uintptr_t)name,0,0,0,0); }
int CopyFromThread(int pid,const void *src,void *dst,DWORD len){return(int)jtmos_syscall7(SYS_copyfromthread,pid,(uintptr_t)src,len,(uintptr_t)dst,0,0);}
