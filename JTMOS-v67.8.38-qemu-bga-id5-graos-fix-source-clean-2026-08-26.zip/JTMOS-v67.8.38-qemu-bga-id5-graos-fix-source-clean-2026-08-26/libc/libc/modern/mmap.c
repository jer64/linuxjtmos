#include <sys/mman.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

/*
 * JTMOS application ABI has no mmap syscall in syscallcodes 1..104.
 * Provide useful POSIX source compatibility for anonymous/private mappings:
 * anonymous mappings are backed by kmalloc through malloc(); file-backed
 * MAP_PRIVATE mappings are snapshots and do not alter the file descriptor offset.
 * MAP_SHARED and fixed-address mappings require a VM/kernel hook and are rejected.
 */
void *mmap(void *addr,size_t length,int prot,int flags,int fd,off_t offset){
    void *p; (void)prot;
    if(!length || offset<0){errno=EINVAL;return MAP_FAILED;}
    if((flags&MAP_SHARED) || (flags&MAP_FIXED) || (flags&MAP_FIXED_NOREPLACE)){
        errno=ENOSYS; return MAP_FAILED;
    }
    if(!(flags&MAP_PRIVATE)){errno=EINVAL;return MAP_FAILED;}
    if(addr){ /* address is only a hint in this compatibility backend */ }
    p=malloc(length);
    if(!p)return MAP_FAILED;
    if(flags&MAP_ANONYMOUS){memset(p,0,length);return p;}
    if(fd<0){free(p);errno=EBADF;return MAP_FAILED;}
    {
        off_t cur=lseek(fd,0,SEEK_CUR);
        size_t done=0;
        if(lseek(fd,offset,SEEK_SET)<0){free(p);return MAP_FAILED;}
        while(done<length){
            ssize_t r=read(fd,(char*)p+done,length-done);
            if(r<0){if(cur>=0)(void)lseek(fd,cur,SEEK_SET);free(p);return MAP_FAILED;}
            if(r==0)break;
            done+=(size_t)r;
        }
        if(done<length)memset((char*)p+done,0,length-done);
        if(cur>=0)(void)lseek(fd,cur,SEEK_SET);
    }
    return p;
}
int munmap(void *addr,size_t length){
    if(!addr || addr==MAP_FAILED || !length){errno=EINVAL;return -1;}
    free(addr); return 0;
}
