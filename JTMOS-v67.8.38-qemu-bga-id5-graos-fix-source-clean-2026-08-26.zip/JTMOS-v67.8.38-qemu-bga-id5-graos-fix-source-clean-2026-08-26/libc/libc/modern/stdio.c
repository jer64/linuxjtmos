#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>

#define FILE_OP_NONE  0
#define FILE_OP_READ  1
#define FILE_OP_WRITE 2

static FILE fin  = {0,1,0,0,-1,NULL,1,NULL,0,0,0,_IONBF,0,FILE_OP_NONE,NULL};
static FILE fout = {1,2,0,0,-1,NULL,0,NULL,0,0,0,_IONBF,0,FILE_OP_NONE,NULL};
static FILE ferr = {2,2,0,0,-1,NULL,0,NULL,0,0,0,_IONBF,0,FILE_OP_NONE,NULL};
FILE *stdin=&fin,*stdout=&fout,*stderr=&ferr;
static FILE *open_streams;

static int mode_flags(const char *mode, int *readonly)
{
    int flags;
    int plus;
    int exclusive;
    if(mode == NULL || mode[0] == '\0') { errno = EINVAL; return -1; }
    plus = strchr(mode,'+') != NULL;
    exclusive = strchr(mode,'x') != NULL;
    switch(mode[0]) {
        case 'r': flags = plus ? O_RDWR : O_RDONLY; break;
        case 'w': flags = (plus ? O_RDWR : O_WRONLY) | O_CREAT | O_TRUNC; break;
        case 'a': flags = (plus ? O_RDWR : O_WRONLY) | O_CREAT | O_APPEND; break;
        default: errno = EINVAL; return -1;
    }
    if(exclusive) flags |= O_EXCL;
    if(readonly != NULL) *readonly = (!plus && mode[0] == 'r');
    return flags;
}

static int write_all(int fd, const unsigned char *data, size_t length, size_t *written)
{
    size_t done = 0U;
    while(done < length) {
        ssize_t rc = write(fd, data + done, length - done);
        if(rc < 0) { if(errno == EINTR) continue; break; }
        if(rc == 0) { errno = EIO; break; }
        done += (size_t)rc;
    }
    if(written != NULL) *written = done;
    return done == length ? 0 : -1;
}

static int flush_write(FILE *stream)
{
    size_t written;
    if(stream == NULL) { errno = EINVAL; return EOF; }
    if(stream->last_op != FILE_OP_WRITE || stream->buffer_len == 0U) return 0;
    if(write_all(stream->fd, stream->buffer, stream->buffer_len, &written) != 0) {
        if(written < stream->buffer_len) {
            memmove(stream->buffer, stream->buffer + written, stream->buffer_len - written);
            stream->buffer_len -= written;
        }
        stream->err = 1;
        return EOF;
    }
    stream->buffer_len = 0U;
    return 0;
}

static int discard_read_buffer(FILE *stream, int restore_position)
{
    size_t unread;
    if(stream->last_op != FILE_OP_READ) return 0;
    unread = stream->buffer_len > stream->buffer_pos ? stream->buffer_len - stream->buffer_pos : 0U;
    if(restore_position && unread != 0U) {
        if(lseek(stream->fd, -(off_t)unread, SEEK_CUR) < 0) { stream->err = 1; return -1; }
    }
    stream->buffer_pos = stream->buffer_len = 0U;
    stream->ungot = -1;
    return 0;
}

static int ensure_buffer(FILE *stream)
{
    if(stream->buffer_mode == _IONBF) return 0;
    if(stream->buffer != NULL && stream->buffer_capacity != 0U) return 0;
    stream->buffer = (unsigned char *)malloc(BUFSIZ);
    if(stream->buffer == NULL) {
        stream->buffer_mode = _IONBF;
        return -1;
    }
    stream->buffer_capacity = BUFSIZ;
    stream->buffer_owned = 1;
    return 0;
}

static void link_stream(FILE *stream)
{
    stream->next = open_streams;
    open_streams = stream;
}

static void unlink_stream(FILE *stream)
{
    FILE **cursor = &open_streams;
    while(*cursor != NULL) {
        if(*cursor == stream) { *cursor = stream->next; return; }
        cursor = &(*cursor)->next;
    }
}

FILE *fopen(const char *path, const char *mode)
{
    FILE *stream;
    int readonly;
    int flags = mode_flags(mode, &readonly);
    int fd;
    if(flags < 0 || path == NULL) { if(path == NULL) errno = EFAULT; return NULL; }
    fd = open(path, flags, 0666);
    if(fd < 0) return NULL;
    stream = (FILE *)calloc(1U, sizeof(*stream));
    if(stream == NULL) { (void)close(fd); return NULL; }
    stream->fd = fd;
    stream->ungot = -1;
    stream->readonly = readonly;
    stream->buffer_mode = _IOFBF;
    (void)ensure_buffer(stream);
    if(mode[0] == 'a') (void)lseek(fd,0,SEEK_END);
    link_stream(stream);
    return stream;
}

FILE *freopen(const char *path, const char *mode, FILE *stream)
{
    int readonly;
    int flags;
    int fd;
    if(stream == NULL || path == NULL) { errno = EINVAL; return NULL; }
    flags = mode_flags(mode, &readonly);
    if(flags < 0) return NULL;
    (void)fflush(stream);
    if(stream->last_op == FILE_OP_READ) (void)discard_read_buffer(stream,0);
    if(stream->fd > 2) (void)close(stream->fd);
    fd = open(path,flags,0666);
    if(fd < 0) return NULL;
    stream->fd = fd;
    stream->eof = stream->err = 0;
    stream->ungot = -1;
    stream->readonly = readonly;
    stream->buffer_pos = stream->buffer_len = 0U;
    stream->last_op = FILE_OP_NONE;
    if(mode[0] == 'a') (void)lseek(fd,0,SEEK_END);
    return stream;
}

int fflush(FILE *stream)
{
    int result = 0;
    if(stream == NULL) {
        FILE *cur;
        if(flush_write(stdout) == EOF) result = EOF;
        if(flush_write(stderr) == EOF) result = EOF;
        for(cur = open_streams; cur != NULL; cur = cur->next)
            if(flush_write(cur) == EOF) result = EOF;
        return result;
    }
    if(stream->last_op == FILE_OP_WRITE) return flush_write(stream);
    return 0;
}

int fclose(FILE *stream)
{
    int result = 0;
    if(stream == NULL) { errno = EINVAL; return EOF; }
    if(fflush(stream) == EOF) result = EOF;
    if(stream->last_op == FILE_OP_READ) (void)discard_read_buffer(stream,0);
    if(stream->fd > 2 && close(stream->fd) < 0) result = EOF;
    if(stream != stdin && stream != stdout && stream != stderr) {
        unlink_stream(stream);
        if(stream->buffer_owned) free(stream->buffer);
        free(stream);
    }
    return result;
}

size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream)
{
    const unsigned char *data = (const unsigned char *)ptr;
    size_t total;
    size_t done = 0U;
    if(stream == NULL || (ptr == NULL && size != 0U && nmemb != 0U)) { errno = EINVAL; return 0U; }
    if(size == 0U || nmemb == 0U) return 0U;
    if(nmemb > (size_t)-1 / size) { errno = EFBIG; stream->err = 1; return 0U; }
    if(stream->readonly) { errno = EBADF; stream->err = 1; return 0U; }
    total = size * nmemb;
    if(stream->last_op == FILE_OP_READ && discard_read_buffer(stream,1) != 0) return 0U;
    stream->last_op = FILE_OP_WRITE;

    if(stream->buffer_mode == _IONBF || ensure_buffer(stream) != 0) {
        (void)write_all(stream->fd,data,total,&done);
        if(done != total) stream->err = 1;
        return done / size;
    }

    while(done < total) {
        size_t room;
        size_t chunk;
        if(stream->buffer_len == 0U && total - done >= stream->buffer_capacity) {
            size_t direct = 0U;
            if(write_all(stream->fd,data + done,total - done,&direct) != 0) {
                done += direct; stream->err = 1; break;
            }
            done += direct;
            continue;
        }
        room = stream->buffer_capacity - stream->buffer_len;
        if(room == 0U) { if(flush_write(stream) == EOF) break; room = stream->buffer_capacity; }
        chunk = total - done < room ? total - done : room;
        memcpy(stream->buffer + stream->buffer_len, data + done, chunk);
        stream->buffer_len += chunk;
        done += chunk;
        if(stream->buffer_mode == _IOLBF && memchr(data + done - chunk,'\n',chunk) != NULL) {
            if(flush_write(stream) == EOF) break;
        } else if(stream->buffer_len == stream->buffer_capacity) {
            if(flush_write(stream) == EOF) break;
        }
    }
    return done / size;
}

size_t fread(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
    unsigned char *out = (unsigned char *)ptr;
    size_t total;
    size_t done = 0U;
    if(stream == NULL || (ptr == NULL && size != 0U && nmemb != 0U)) { errno = EINVAL; return 0U; }
    if(size == 0U || nmemb == 0U) return 0U;
    if(nmemb > (size_t)-1 / size) { errno = EFBIG; stream->err = 1; return 0U; }
    total = size * nmemb;
    if(stream->last_op == FILE_OP_WRITE && flush_write(stream) == EOF) return 0U;
    stream->last_op = FILE_OP_READ;

    while(done < total) {
        if(stream->ungot >= 0) {
            out[done++] = (unsigned char)stream->ungot;
            stream->ungot = -1;
            continue;
        }
        if(stream->buffer_pos < stream->buffer_len) {
            size_t avail = stream->buffer_len - stream->buffer_pos;
            size_t chunk = total - done < avail ? total - done : avail;
            memcpy(out + done,stream->buffer + stream->buffer_pos,chunk);
            stream->buffer_pos += chunk;
            done += chunk;
            continue;
        }
        stream->buffer_pos = stream->buffer_len = 0U;
        if(stream->buffer_mode == _IONBF || ensure_buffer(stream) != 0 || total - done >= stream->buffer_capacity) {
            ssize_t rc = read(stream->fd,out + done,total - done);
            if(rc < 0) { if(errno == EINTR) continue; stream->err = 1; break; }
            if(rc == 0) { stream->eof = 1; break; }
            done += (size_t)rc;
        } else {
            ssize_t rc = read(stream->fd,stream->buffer,stream->buffer_capacity);
            if(rc < 0) { if(errno == EINTR) continue; stream->err = 1; break; }
            if(rc == 0) { stream->eof = 1; break; }
            stream->buffer_len = (size_t)rc;
        }
    }
    return done / size;
}

int fgetc(FILE *stream)
{
    unsigned char c;
    return fread(&c,1U,1U,stream) == 1U ? (int)c : EOF;
}
int getc(FILE *stream){return fgetc(stream);} int getchar(void){return fgetc(stdin);}
int ungetc(int c,FILE *stream){if(stream==NULL||c==EOF||stream->ungot>=0)return EOF;stream->ungot=(unsigned char)c;stream->eof=0;return(unsigned char)c;}
int fputc(int c,FILE *stream){unsigned char x=(unsigned char)c;return fwrite(&x,1U,1U,stream)==1U?(int)x:EOF;}
int putc(int c,FILE *stream){return fputc(c,stream);} int putchar(int c){return fputc(c,stdout);}
int fputs(const char *s,FILE *stream){size_t n;if(s==NULL){errno=EINVAL;return EOF;}n=strlen(s);return fwrite(s,1U,n,stream)==n?0:EOF;}
int puts(const char *s){if(fputs(s,stdout)==EOF||fputc('\n',stdout)==EOF)return EOF;return 0;}

char *fgets(char *s,int n,FILE *stream)
{
    int i=0,c=EOF;
    if(s==NULL||stream==NULL||n<=0){errno=EINVAL;return NULL;}
    if(n==1){s[0]='\0';return s;}
    while(i<n-1 && (c=fgetc(stream))!=EOF){s[i++]=(char)c;if(c=='\n')break;}
    if(i==0 && c==EOF) return NULL;
    s[i]='\0';
    return s;
}

/* Retained only for old JTMOS source compatibility. New code must use fgets(). */
char *gets(char *s)
{
    int c;
    char *p=s;
    if(s==NULL){errno=EINVAL;return NULL;}
    while((c=getchar())!=EOF && c!='\n' && c!='\r') *p++=(char)c;
    *p='\0';
    return s;
}

int fseek(FILE *stream,long offset,int whence)
{
    if(stream==NULL){errno=EINVAL;return -1;}
    if(stream->last_op==FILE_OP_WRITE && flush_write(stream)==EOF)return -1;
    if(stream->last_op==FILE_OP_READ && whence==SEEK_CUR){
        size_t unread=stream->buffer_len>stream->buffer_pos?stream->buffer_len-stream->buffer_pos:0U;
        offset-=(long)unread;
    }
    stream->buffer_pos=stream->buffer_len=0U;stream->ungot=-1;
    if(lseek(stream->fd,(off_t)offset,whence)<0){stream->err=1;return -1;}
    stream->eof=0;stream->last_op=FILE_OP_NONE;return 0;
}

long ftell(FILE *stream)
{
    off_t pos;
    if(stream==NULL){errno=EINVAL;return -1L;}
    pos=lseek(stream->fd,0,SEEK_CUR);
    if(pos<0)return -1L;
    if(stream->last_op==FILE_OP_READ && stream->buffer_len>stream->buffer_pos)
        pos-=(off_t)(stream->buffer_len-stream->buffer_pos);
    else if(stream->last_op==FILE_OP_WRITE)
        pos+=(off_t)stream->buffer_len;
    return(long)pos;
}

void rewind(FILE *stream){if(stream!=NULL){(void)fseek(stream,0L,SEEK_SET);clearerr(stream);}}
int feof(FILE *stream){return stream!=NULL?stream->eof:0;} int ferror(FILE *stream){return stream!=NULL?stream->err:1;}
void clearerr(FILE *stream){if(stream!=NULL){stream->eof=0;stream->err=0;}}
int fileno(FILE *stream){if(stream==NULL){errno=EINVAL;return -1;}return stream->fd;}
int remove(const char *path){return unlink(path);}
int rename(const char *oldpath,const char *newpath){long r;if(!oldpath||!newpath){errno=EFAULT;return-1;}r=jtmos_syscall7(SYS_rename,(uintptr_t)oldpath,(uintptr_t)newpath,0,0,0,0);if(r<0){errno=EIO;return-1;}return(int)r;}
void perror(const char *s){if(s&&*s){fputs(s,stderr);fputs(": ",stderr);}fputs(strerror(errno),stderr);fputc('\n',stderr);}

int setvbuf(FILE *stream,char *buffer,int mode,size_t size)
{
    if(stream==NULL || (mode!=_IOFBF&&mode!=_IOLBF&&mode!=_IONBF)){errno=EINVAL;return -1;}
    if(fflush(stream)==EOF)return -1;
    if(stream->buffer_owned)free(stream->buffer);
    stream->buffer=NULL;stream->buffer_capacity=0U;stream->buffer_pos=stream->buffer_len=0U;stream->buffer_owned=0;
    stream->buffer_mode=mode;
    if(mode==_IONBF)return 0;
    if(size==0U)size=BUFSIZ;
    if(buffer!=NULL){stream->buffer=(unsigned char*)buffer;stream->buffer_capacity=size;return 0;}
    stream->buffer=(unsigned char*)malloc(size);
    if(stream->buffer==NULL){stream->buffer_mode=_IONBF;return -1;}
    stream->buffer_capacity=size;stream->buffer_owned=1;return 0;
}
void setbuf(FILE *stream,char *buffer){(void)setvbuf(stream,buffer,buffer?_IOFBF:_IONBF,BUFSIZ);}
