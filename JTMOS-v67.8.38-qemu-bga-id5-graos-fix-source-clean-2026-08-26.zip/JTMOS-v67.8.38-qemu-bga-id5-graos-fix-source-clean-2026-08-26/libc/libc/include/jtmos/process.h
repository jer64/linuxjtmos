#ifndef _JTMOS_PROCESS_H
#define _JTMOS_PROCESS_H
#include <jtmos/types.h>

/* SYS_cexec ECX mode: historical JTMOS process API contract. */
#define JTMOS_EXEC_BACKGROUND 0
#define JTMOS_EXEC_WAIT       1

#define JTMOS_CPU_STATS_VERSION 1
typedef struct {
    DWORD version;
    DWORD size;
    DWORD hz;
    DWORD total_threads;
    DWORD runnable_threads;
    DWORD idle_pid;
    DWORD cpu_idle_per_mille;
    DWORD cpu_busy_per_mille;
    DWORD load_a_x1000;
    DWORD load_b_x1000;
    DWORD load_c_x1000;
    DWORD sample_ticks;
    DWORD sample_idle_ticks;
    DWORD uptime_ms;
} JTMOS_CPU_STATS;

#define APPRAM_64K   64
#define APPRAM_128K  128
#define APPRAM_256K  256
#define APPRAM_512K  512
#define APPRAM_1024K 1024
#define APPRAM_2048K 2048
#define APPRAM_4096K 4096
#define APPRAM_8192K 8192
#define APPRAM_12288K 12288
#define __JTMOS_STR_1(x) #x
#define __JTMOS_STR(x) __JTMOS_STR_1(x)
#define SYSMEMREQ(x) \
    static const char __jtmos_memcfg[] \
    __attribute__((used,section(".jtmos.memcfg"))) = \
    "SQUIRREL VERIFY APPLICATION MEMORY CONFIGURATION=" __JTMOS_STR(x);

/* JTMOS/x86 extension. POSIX itself does not define CPU privilege rings. */
int getringlevel(void);
int getpid(void);
int GetCurrentThread(void);
int GetThreadUniquePID(int); /* deprecated V65 identity compatibility */
int GetThreadPID(const char*);
int GetThreadPriority(int);
int GetThreadSpending(int);
int GetThreadName(int,char*);
int GetThreadMemoryUsage(int);
int GetThreadCount(void);
int GetCPUStats(JTMOS_CPU_STATS*);
void SwitchToThread(void);
int SwitchToThreadEx(int);
unsigned long GetTickCount(void);
int GetSeconds(void);
void Sleep(unsigned long);
void MilSleep(int);
int WaitProcessTermination(int);
int cexec(const char*,const char*);
int cexecEx(const char*,const char*,int);
int bgexec(const char*,const char*);
int bgexecEx(const char*,const char*,int);
int diskChange(int);
int OutputTerminalKeyboardBuffer(int,int);
int InputTerminalKeyboardBuffer(int);
int GetCurrentTerminal(void);
int GetThreadTerminal(int);
int SetThreadTerminal(int,int);

DWORD GetAmountFree(void);
DWORD GetMemorySize(void);
DWORD GetProgramStart(void);
DWORD GetProgramEnd(void);
int KillThread(int);
int IdentifyThread(int,const char*);
int CopyFromThread(int,const void*,void*,DWORD);
#endif
