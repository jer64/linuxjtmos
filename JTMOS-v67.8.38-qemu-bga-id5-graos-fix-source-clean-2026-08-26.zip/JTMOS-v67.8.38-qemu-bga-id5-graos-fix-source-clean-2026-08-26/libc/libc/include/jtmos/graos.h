#ifndef _JTMOS_GRAOS_H
#define _JTMOS_GRAOS_H
#include <jtmos/types.h>
#include <jtmos/msgbox.h>
#include <jtmos/graosprotocol.h>
#define GRAOS_SERVER_PID_NAME "guiserver"
int getGraosPID(void);
int connectGraos(void);
int waitGraosAnswer(void);
int createWindow(int,int,int,int,const char*,...);
int closeWindow(int);
int refreshWindow(int);
int addFrameBuffer(int,BYTE*,...);
int createButton(int,int,int,int,int,int,const char*);
int createLabel(int,int,int,int,int,int,int,int,int,const char*);
int setLabelText(int,int,const char*);
int setLabelStyle(int,int,int,int,int);
int removeLabel(int,int);
int createBitmap(int,int,int,int,int,int,const BYTE*,int);
int setBitmapData(int,int,const BYTE*,int);
int removeBitmap(int,int);
int createTextBox(int,int,int,int,int,int,int,const char*);
int setTextBoxText(int,int,const char*);
int getTextBoxText(int,int,char*,int);
int removeTextBox(int,int);
int JtmosGraOSPollEvent(int,GUICMD*);
int JtmosGraOSSetGray16Palette(void);
int CreateTerminal(void);
int JtmosGraOSFreeTerminal(int);
int JtmosGraOSPing(void);
int JtmosGraOSGetStats(int *windows,int *terminals,int *focus,unsigned long *frames);
int JtmosGraOSShutdown(void);
int JtmosGraOSSetDesktopColor(int color);
int JtmosGraOSSetPalette(int index,int r,int g,int b);
int JtmosGraOSRestorePalette(void);
int JtmosGraOSMinimizeWindow(int wid);
int JtmosGraOSRestoreWindow(int wid);
#endif
