#ifndef _JTMOS_MSGBOX_H
#define _JTMOS_MSGBOX_H
#include <jtmos/types.h>
#define MB_PROTOCOL_DC      12341234
#define MB_PROTOCOL_POSTMAN 46842632
#define MB_PROTOCOL_GRAOS   99436111
#define N_MAX_BYTES_PER_MSG 2048
typedef struct { DWORD magic1,isFree; int type,protocol,sndPID,rcvPID,amount; DWORD un,magic2; BYTE buf[N_MAX_BYTES_PER_MSG]; } MSG;
void startMessageBox(void); int receiveMessage(MSG*); int sendMessage(MSG*,int); int MessageBox(void*,const char*,const char*,unsigned);
#endif
