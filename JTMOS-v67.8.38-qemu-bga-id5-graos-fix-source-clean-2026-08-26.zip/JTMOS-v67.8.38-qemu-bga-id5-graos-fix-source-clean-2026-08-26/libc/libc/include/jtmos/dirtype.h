#ifndef _JTMOS_DIRTYPE_H
#define _JTMOS_DIRTYPE_H

/* On-disk JTMFS file-entry type/attribute bits.  These values are ABI and
 * filesystem format constants; keep them in sync with kernel32/fs/jtmfs/dirtype.h. */
#define JTMFS_ID_WRITEONLY      0x01
#define JTMFS_ID_SYSTEM         0x02
#define JTMFS_ID_DEVICE         0x04
#define JTMFS_ID_ARCHIVE        0x08
#define JTMFS_ID_EXECUTABLE     0x10
#define JTMFS_ID_HIDDEN         0x20
#define JTMFS_ID_DIRNAME        0x40
#define JTMFS_ID_DIRECTORY      0x80

/* A normal regular file has no directory bit set.  Keep this convenience
 * spelling for newer userspace code without confusing it with WRITEONLY. */
#define JTMFS_ID_FILE           0x00

#endif
