#ifndef _JTMOS_GRAOS_PROTOCOL_H
#define _JTMOS_GRAOS_PROTOCOL_H
#include <jtmos/types.h>
#define WINDOW_CLOSE_BUTTON 1
#define EXIT_ON_CLICK 2
#define WINDOW_HAS_CAPTION 4
#define WINDOW_HAS_BORDER 8
#define WINDOW_AUTOCLEAR 16
#define WINDOW_MINIMIZE_BUTTON 32
#define STANDARD_BUTTON 0
#define STANDARD_WINDOW (WINDOW_HAS_CAPTION|WINDOW_CLOSE_BUTTON|WINDOW_MINIMIZE_BUTTON|WINDOW_HAS_BORDER|WINDOW_AUTOCLEAR)
#define TASKBAR_WINDOW 0
/* Native GraOS desktop ABI geometry.  Keep external clients on the same
 * contract as the Ring3 server and kernel VESA presenter. */
#define GRAOS_SCREEN_WIDTH 1024
#define GRAOS_SCREEN_HEIGHT 768
#define GRAOS_SCREEN_BPP 8
#define GRAOS_SCREEN_PANEL_HEIGHT 20

/* Common GraOS widget base.  Every concrete component embeds this as its
 * first member so generic layout/hit-test/state code can operate on it. */
#define GRAOS_WIDGET_NONE 0
#define GRAOS_WIDGET_BUTTON 1
#define GRAOS_WIDGET_LABEL 2
#define GRAOS_WIDGET_BITMAP 3
#define GRAOS_WIDGET_WINDOW_ROOT 4
#define GRAOS_WIDGET_TEXTBOX 5
#define GRAOS_WIDGET_VISIBLE 0x0001U
#define GRAOS_WIDGET_ENABLED 0x0002U
#define GRAOS_WIDGET_FOCUSABLE 0x0004U
#define GRAOS_WIDGET_DIRTY 0x0008U
typedef struct GRAOS_WIDGET {
    int type;
    int id;
    int x,y,width,height;
    int visible;
    int enabled;
    int focusable;
    int z;
    int owner_window;
    unsigned int flags;
    void *userdata;
} GRAOS_WIDGET;

#define GRAOS_LABEL_ALIGN_LEFT 0
#define GRAOS_LABEL_ALIGN_CENTER 1
#define GRAOS_LABEL_ALIGN_RIGHT 2
#define GRAOS_LABEL_TRANSPARENT (-1)
#define GRAOS_BITMAP_TRANSPARENT_NONE (-1)
#define GRAOS_GRAY16_BASE 240
#define GRAOS_GRAY16_COLORS 16
#define TYPE_TERMINAL_EMULATION 1
#define TYPE_BITMAP_SCREEN 2
#define GSID_RESPONSE 1
#define GSID_OPENWINDOW 2
#define GSID_CLOSEWINDOW 3
#define GSID_EXIT 4
#define GSID_ADDFRAMEBUFFER 5
#define GSID_REQUESTREFRESH 6
#define GSID_KEYPRESSED 7
#define GSID_CREATEBUTTON 8
#define GSID_PING 9
#define GSID_GETSTATS 10
#define GSID_SHUTDOWN 11
#define GSID_SETDESKTOPCOLOR 12
#define GSID_SETPALETTE 13
#define GSID_BUTTON 14
#define GSID_FREETERMINAL 15
#define GSID_CREATELABEL 16
#define GSID_SETLABELTEXT 17
#define GSID_SETLABELSTYLE 18
#define GSID_REMOVELABEL 19
#define GSID_MOUSEBUTTON 20
#define GSID_CREATEBITMAP 21
#define GSID_SETBITMAPDATA 22
#define GSID_REMOVEBITMAP 23
#define GSID_POLLEVENT 24
#define GSID_WINDOW_FOCUS 25
#define GSID_WINDOW_BLUR 26
#define GSID_WINDOW_MINIMIZED 27
#define GSID_WINDOW_RESTORED 28
#define GSID_MINIMIZEWINDOW 29
#define GSID_RESTOREWINDOW 30
#define GSID_CREATETEXTBOX 31
#define GSID_SETTEXTBOXTEXT 32
#define GSID_GETTEXTBOXTEXT 33
#define GSID_REMOVETEXTBOX 34
#define GSID_TEXTBOX_CHANGED 35
#define GSID_TEXTBOX_ENTER 36
#define GSID_TEXTBOX_FOCUS 37
#define GSID_TEXTBOX_BLUR 38

typedef struct {
    DWORD magic;
    int wid;
    int id;
    DWORD rval;
    char str[256];
    int v[20];
    BYTE *ptr[20];
} GUICMD;
#endif
