#ifndef _JTMOS_SIGNAL_H
#define _JTMOS_SIGNAL_H
typedef void (*sighandler_t)(int);
#define SIG_DFL ((sighandler_t)0)
#define SIG_IGN ((sighandler_t)1)
#define SIGINT 2
#define SIGABRT 6
#define SIGKILL 9
#define SIGTERM 15
sighandler_t signal(int,sighandler_t); int raise(int); int kill(int,int);
#endif
