#ifndef _JTMOS_SYS_TYPES_H
#define _JTMOS_SYS_TYPES_H
#include <stddef.h>
typedef long off_t; typedef int pid_t; typedef unsigned int mode_t; typedef long ssize_t;
typedef unsigned long time_t;
typedef unsigned long useconds_t;
#endif
