#ifndef __INCLUDED_FILEFIND_H__
#define __INCLUDED_FILEFIND_H__

#include "basdef.h" // DWORD

/* Must match kernel32/fs/jtmfs/dirtype.h. */
#define JTMFS_ID_FILE       0x00
#define JTMFS_ID_DIRECTORY  0x80

typedef struct
{
        DWORD _ff_reserved[5];
        DWORD ff_attrib;
        DWORD ff_ftime;
        DWORD ff_fdate;
        DWORD ff_fsize;
        char ff_name[260];
}FFBLK;

typedef char jtmos_ffblk_size_must_be_296[(sizeof(FFBLK) == 296) ? 1 : -1];

int findfirst(const char *path, FFBLK *ff);
int findnext(int fd, FFBLK *ff);

#endif
