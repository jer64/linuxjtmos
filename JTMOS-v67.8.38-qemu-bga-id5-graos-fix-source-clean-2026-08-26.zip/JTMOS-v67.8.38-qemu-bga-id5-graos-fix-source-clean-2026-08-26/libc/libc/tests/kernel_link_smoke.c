#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <jtmos/types.h>
long jtmos_kernel_syscall7(DWORD n,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t s,uintptr_t di,uintptr_t bp){
    (void)n;(void)b;(void)c;(void)d;(void)s;(void)di;(void)bp; return -1;
}
int jtmos_kernel_libc_link_smoke(void){
    void *p=malloc(8); if(p){memset(p,0,8);free(p);} return 0;
}
