#!/bin/sh
set -eu
APPS=${1:-}
MODE=${2:-raw}
[ -n "$APPS" ] || { echo "usage: $0 /path/to/apps [raw|fix-known-msdos]" >&2; exit 2; }
HERE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT HUP INT TERM
SRC=$APPS
if [ "$MODE" = fix-known-msdos ]; then
  cp -a "$APPS" "$WORK/apps"
  SRC=$WORK/apps
  python3 - "$SRC/msdos.h" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
s=s.replace('WORD totalSectors;', 'WORD totalSectors16;', 1)
s=s.replace('DWORD totalSectors;', 'DWORD totalSectors32;', 1)
p.write_text(s)
PY
fi
mkdir -p "$WORK/obj" "$WORK/log"
ok=0; fail=0
for f in "$SRC"/*.c; do
  [ -f "$f" ] || continue
  n=$(basename "$f" .c)
  if gcc -m32 -march=i486 -std=gnu89 -O2 -ffreestanding -fno-builtin \
      -fno-stack-protector -fno-pie -fno-pic -fno-unwind-tables \
      -fno-asynchronous-unwind-tables -nostdinc \
      -Ulinux -U__linux -U__linux__ \
      -DJTMOS=1 -DJTMOS_APPLICATION=1 -DJTMOS_LEGACY_SOURCE=1 -DCPU=i486 \
      -I"$HERE/include" -I"$SRC" \
      -Wno-implicit-int -Wno-implicit-function-declaration -Wno-int-conversion \
      -Wno-pointer-to-int-cast -Wno-int-to-pointer-cast -Wno-return-type \
      -c "$f" -o "$WORK/obj/$n.o" >"$WORK/log/$n.log" 2>&1; then
    ok=$((ok+1))
  else
    fail=$((fail+1)); echo "FAIL: $(basename "$f")"; grep -E 'error:|fatal error:' "$WORK/log/$n.log" | head -5 || true
  fi
done
echo "apps C compile: $ok OK, $fail FAIL, total $((ok+fail)) ($MODE)"
[ "$fail" -eq 0 ]
