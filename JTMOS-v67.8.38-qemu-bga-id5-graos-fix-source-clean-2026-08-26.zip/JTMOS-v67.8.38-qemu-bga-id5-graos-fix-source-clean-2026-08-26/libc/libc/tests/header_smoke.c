#include <pc.h>
#include <go32.h>
#include <dpmi.h>
#include <jtmos/dma.h>
#include <jtmos/irq.h>
#include <stddef.h>
#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <jtmos/process.h>
#include <jtmos/filefind.h>
#include <jtmos/console.h>

_Static_assert(sizeof(FFBLK) == 296, "SYS_findfirst FFBLK ABI size");
_Static_assert(offsetof(FFBLK, ff_name) == 36, "SYS_findfirst FFBLK name offset");
_Static_assert(offsetof(FFBLK, ff_fsize) == 32, "SYS_findfirst FFBLK size offset");
_Static_assert(JTMFS_ID_DIRECTORY == 0x80, "JTMFS directory ABI bit");
int jtmos_header_smoke(void){char b[32];snprintf(b,sizeof b,"%u",(unsigned)sizeof(void*));return strcmp(b,"4");}
