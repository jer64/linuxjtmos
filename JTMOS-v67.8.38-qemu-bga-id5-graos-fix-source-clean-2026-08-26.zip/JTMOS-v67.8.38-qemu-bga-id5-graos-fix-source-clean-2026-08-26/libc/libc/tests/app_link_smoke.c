#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
int main(int argc,char **argv){
    char *p=(char*)malloc(32);
    void *m=mmap(0,4096,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(p){strcpy(p,argc&&argv?"jtmos":"libc");puts(p);free(p);}
    if(m!=MAP_FAILED)munmap(m,4096);
    return 0;
}
