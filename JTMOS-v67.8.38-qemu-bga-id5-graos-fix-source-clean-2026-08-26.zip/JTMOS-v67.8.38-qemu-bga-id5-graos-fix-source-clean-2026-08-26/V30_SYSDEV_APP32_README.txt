JTMOS V30 - sys: floppy device + 32-bit LIBC Applications build
================================================================

SYS: DEVICE
-----------
The system floppy is split using the historical JTMOS 2002 layout:

  0..639 KiB     boot sector + kernel image area
  640..1439 KiB  sys: system utilities area

The sys: block device therefore maps logical block 0 to floppy: block 1280
and exposes 1600 blocks of 512 bytes = 800 KiB.  system: is registered as
an alias/name for the same device.  The device is registered immediately
after fdc_init(), once floppy: exists.

The release image contains tools/utilsdisk.img at offset 640 KiB.  It is a
Squirrel archive containing selected 32-bit JTMOS utilities and is directly
accessible with commands such as:

  sqa sys
  sqa floppy

LIBC APPLICATIONS ON 64-BIT LINUX HOSTS
---------------------------------------
libc/apps makefiles now explicitly build IA-32 objects:

  -m32 -march=i486 -std=gnu89 -ffreestanding
  -fno-builtin -fno-stack-protector -fno-pie -fno-pic
  -fcommon -fcf-protection=none
  -fno-unwind-tables -fno-asynchronous-unwind-tables

Application links explicitly use:

  ld -m elf_i386

makgen.pl emits these settings for regenerated application makefiles.
The same architecture/hardening cleanup was applied to legacy libc/drv
makefiles used by the distribution utility-disk build.

TESTED IN THIS BUILD ENVIRONMENT
--------------------------------
  cd libc/apps && make          PASS
  21 default applications       PASS
  cat.o / sqa.o                 ELF 32-bit Intel i386
  kernel sysdev.c/init.c build  PASS
  full kernel link              PASS
  sys: image offset/size        PASS

The included jtm32.img contains the kernel at 0x2400 and utilsdisk.img at
640 KiB.  jtm32-kernel-only.cfg is retained for kernel-only images.

KNOWN LEGACY DRIVER NOTE
------------------------
The 32-bit compiler flags also let libc/drv sources compile as IA-32.  The
legacy libc/drv/hd target still has its older, separate link dependency on
readblock(), which is not exported by the current libcjtmos.a.  This is not
part of the libc/apps 64-bit-host fix and does not affect the kernel sys:
driver or the included system-disk image.
