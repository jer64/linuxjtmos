JTMOS V59 - 8-bit WAV player, GUS QEMU launcher and installer payload
=====================================================================
Date: 2026-08-21

WAV playback
------------
The SMSH built-in `sound` command and the external static ELF32 `sound.bin`
now parse RIFF/WAVE files instead of assuming a fixed playback frequency.
Supported input is deliberately strict:

  * RIFF/WAVE
  * WAVE_FORMAT_PCM (format tag 1)
  * mono
  * unsigned 8-bit samples
  * 4000..44100 Hz

The sample_rate value from the WAV `fmt ` chunk is passed unchanged to the
JTMOS AudioWrite/audio_write API. RIFF chunks are walked normally, so fmt/data
need not be at fixed byte 12/36 positions and LIST/JUNK/metadata chunks are
skipped with RIFF even-byte padding.

Examples:

  sound sample.wav
  sound gus sample.wav
  sound sb sample.wav
  :sound.bin sample.wav
  :sound.bin gus sample.wav

Unsupported PCM widths, stereo/multichannel WAV, non-PCM encodings, malformed
block alignment, missing fmt/data chunks, truncated streams and sample rates
outside the current driver range produce an explicit error rather than being
played with guessed parameters.

Audio startup policy
--------------------
AUDIO_DRIVERS may be compiled into the kernel, but SB and GUS hardware backends
are OFF/lazy by default. Boot no longer calls audio_init(). The first `sound`
command or audio syscall initializes the FIFO and probes/starts the requested
backend. This avoids touching ISA audio hardware during ordinary text boot.

QEMU
----
run_jtmos_qemu.sh now uses:

  qemu-system-i386 -machine pc -m 512 \
    -drive file=jtm32.img,format=raw,if=floppy,index=0 \
    -drive file=hd_jtmos.img,format=raw,if=ide,index=0,media=disk \
    -device gus,irq=5 \
    -boot a

If the hard-disk image does not exist, make_hd_jtmos.sh creates it. The default
is a 16 MiB blank raw IDE image (override with JTMOS_HDD_MB). Inside JTMOS use
`mkfs hda` and optionally `rootinstall hda`.

Installer image
---------------
tools/build_install_image.sh builds the modern static ELF32 sound.bin, sqa.bin
and unz.bin and creates this two-stage installation layout:

  sys:/utilsdisk.img
      -> unz.bin
      -> install.img.nz

  unz
      -> nzip decompression: install.img.nz -> install.img
      -> embedded SQA extraction of install.img
      -> installed files

`unz archive.nz` can also unpack one named archive; with no argument it scans
the current directory for .nz files. An output filename containing `.img` is
passed automatically to the embedded SQA extractor.
