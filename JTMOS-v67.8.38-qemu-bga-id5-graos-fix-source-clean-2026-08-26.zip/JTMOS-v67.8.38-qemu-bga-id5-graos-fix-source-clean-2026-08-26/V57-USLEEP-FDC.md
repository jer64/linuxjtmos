JTMOS V57 - scheduler-friendly usleep and 1.44 MB FDC timing refresh
===================================================================
Date: 2026-08-21

Time/sleep changes
------------------
* Added SYS_usleep (106) and libc int usleep(useconds_t usec).
* Added useconds_t to sys/types.h.
* usleep no longer rounds to milliseconds through SYS_milsleep.
* PIT now maintains an exact-average microsecond duration clock from the
  1,193,180 Hz PC/AT timer source.  CMOS remains the wall-clock source; the
  CMOS calendar itself has only one-second resolution and cannot provide a
  genuine microsecond sleep clock.
* The public millisecond divider now uses the exact PIT divisor ratio instead
  of first truncating divisor 0x100 to 4660 Hz.
* UsecSleep() calls SwitchToThread() while multitasking and uses HLT during
  boot/storage-safe waits.
* SwitchToThread() is now a pure yield.  It no longer silently marks the
  caller asleep for two complete scheduler rounds.

Floppy/FDC changes
------------------
* Fixed the controller version-probe condition (i==-1); the old i!=-1 test
  skipped CMD_VERSION entirely because i starts at -1.
* Fixed the enhanced-FDC reset DOR sequence.  The historical 0x1A value leaves
  nRESET (DOR bit 2) clear and can keep the controller in reset once version
  detection actually works.  Reset now asserts nRESET low deliberately, restores
  500 kbit/s, releases reset, waits for IRQ6, drains four SENSE INTERRUPT
  statuses, sends SPECIFY, and recalibrates the selected drive.
* FDC IRQ completion waits now use the PIT millisecond clock rather than
  repeatedly polling the coarse CMOS seconds counter.
* Boot/storage-safe FDC waits HLT until PIT/IRQ6 instead of burning CPU.
* Removed nested maxTries retrying from fdc_rw().  A request now has one
  hardware command per outer retry, with three total attempts and escalating
  recalibrate/reset recovery.  The old nesting could reach 16 long attempts.
* Kept safe physical-drive timings: 500 ms initial motor spin-up and 15 ms
  post-seek settle.  These are not shortened below conservative 3.5-inch
  hardware values.
* Motor idle hold is now the configured 3000 ms and is measured in PIT ms,
  reducing repeated 500 ms spin-ups during filesystem bursts.
* fd_sendbyte() now uses sendByte rather than the getByte timeout field.
* The existing 36-sector (one cylinder) cache and 64 KiB-safe DMA bounce
  buffer remain intact.

Runtime note
------------
Static build/link validation is performed in this package.  Real 1.44 MB
floppy hardware and VirtualBox/QEMU FDC timing still require runtime testing.
