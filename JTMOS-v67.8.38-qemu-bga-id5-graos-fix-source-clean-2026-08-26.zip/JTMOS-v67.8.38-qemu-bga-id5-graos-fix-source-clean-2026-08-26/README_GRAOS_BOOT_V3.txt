GraOS native boot test V3 - 2026-08-19

V3 boot-critical changes:
- kernel entry at 0x10000 is now a naked bootstrap (no GCC prologue before ESP)
- CLI+CLD and flat data segments are explicitly established at entry
- stack moved to 0x001EFFF0, the reserved zero-process stack region
- early terminal buffer fixed from BYTE *array to actual BYTE array
- pre-malloc SCREEN[0] fields are explicitly initialized
- early term_buf clear uses xmemset
- removed sleep() before CMOS/timer/multitasking initialization
- V2 low-memory BSS guard remains enabled

Run:
 qemu-system-i386 -m 64 -drive file=GraOS-boot-test-v3-2026-08-19.img,format=raw,if=floppy -boot a
