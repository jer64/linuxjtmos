JTMOS V27 - SMSH / LaunchApp integration boot
=============================================

Purpose
-------
This profile temporarily removes GraOS from the boot path so the critical
kernel, filesystem, scheduler and application-loader integration can be tested
from the native SMSH maintenance shell.

Boot behaviour
--------------
* boot32 stays in BIOS VGA text mode; it does not select VESA 640x480x8.
* START_GRAOS=0.
* modules.conf has GRAOS_BOOT=0, SH=1 and APP_LOADER=1.
* HWDET remains skipped exactly as in V26.
* The Central Process source was NOT changed by V27.
* After storage init, PitStorageSafeEnd(), CP init and scheduler/IRQ0 enable,
  StartShellProcess() creates SMSH on terminal 0.

Expected final boot messages
----------------------------
  VESA probe skipped: START_GRAOS=0; using native text console.
  GraOS boot module disabled: continuing with native kernel only.
  Kernel boot: PIT timer/scheduler confirmed enabled.
  SMSH boot: starting native maintenance shell on terminal 0.
  Built-In System Maintenance Debug Shell 1.1 / 2020-2026
  #

Explicit external application syntax
------------------------------------
A leading ':' forces an external application load.  The ':' is SMSH syntax
only and is removed before the application loader is called.

Examples:
  :install
  :install -f /ram/package.sqa
  :/bin/test.bin arg1 arg2

For ':install', SMSH passes filename "install" and command line "install" to
centralprocess_exec().  The CP loader appends .bin when required, searches the
kernel PATH (./:/bin:/usr/bin), reads the executable from JTMFS, then starts it
through LaunchAppEx().  SMSH waits for the child process to terminate and then
returns to '#'.

This deliberately avoids the historical centralprocess pseudo-name
":install.bin" because the shell strips ':' before calling the loader.

Built-in commands
-----------------
Commands without ':' still use the SMSH built-in table first.  Unknown
non-prefixed commands retain the old system() fallback for compatibility.
Thus ':help' means "load help.bin", while 'help' means the built-in SMSH help.

Build notes
-----------
autogen.pl now ignores the historical duplicate source mirrors core/int,
core/iodma, core/lowlevel and irq. Their C/ASM source hashes were verified to
have canonical equivalents in core/chiplevel or drivers/. Linking both copies
caused duplicate symbols. The canonical generated object list has 242 objects
for this V27 profile and `make -f generated.mak linkit` succeeds.

The environment used to create this package has no NASM, so the existing
unchanged canonical assembler .o files from V26 were retained. The prebuilt
boot32/boot.bin was patched at its known VESA setup CALL (file offset 0x104b)
to NOP NOP NOP. boot32/boot.asm is also configured with VESA_ENABLED disabled
for the next normal NASM rebuild.
