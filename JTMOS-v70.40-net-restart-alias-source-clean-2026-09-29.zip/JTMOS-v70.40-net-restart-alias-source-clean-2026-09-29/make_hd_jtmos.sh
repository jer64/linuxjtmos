#!/bin/sh
set -eu
OUT=${1:-hd_jtmos.img}
SIZE_MB=${JTMOS_HDD_MB:-512}
case "$SIZE_MB" in
  ''|*[!0-9]*) echo "make_hd_jtmos.sh: JTMOS_HDD_MB must be an integer." >&2; exit 1;;
esac
if [ "$SIZE_MB" -lt 2 ]; then
  echo "make_hd_jtmos.sh: disk must be at least 2 MiB." >&2
  exit 1
fi
# Blank 512 MiB raw ATA image by default. Override with JTMOS_HDD_MB.
# Equivalent default content: dd if=/dev/zero of=hd_jtmos.img bs=1M count=512 status=progress
# JTMOS formats it itself with: mkfs hda
# and can install the boot kernel with: rootinstall hda
if command -v truncate >/dev/null 2>&1; then
  truncate -s "${SIZE_MB}M" "$OUT"
else
  dd if=/dev/zero of="$OUT" bs=1M count="$SIZE_MB" status=none
fi
printf 'Created %s (%s MiB raw IDE image).\n' "$OUT" "$SIZE_MB"
printf 'Inside JTMOS use: mkfs hda ; rootinstall hda\n'
