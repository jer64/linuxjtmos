//--------------------------------------------------------------------------------------------
// ls.c - Directory displayer kernel mode application.
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lsapp.h"


#ifndef JTMOS
#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>

int ls_app(int argc, char **argv)
{
    const char *path = (argc >= 2 && argv[1] != NULL) ? argv[1] : ".";
    DIR *directory = opendir(path);
    struct dirent *entry;

    if (directory == NULL) {
        perror(path);
        return 1;
    }

    while ((entry = readdir(directory)) != NULL) {
        char full_path[4096];
        struct stat status;
        int is_directory = 0;

        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }

        if (snprintf(full_path, sizeof(full_path), "%s/%s", path, entry->d_name)
            < (int)sizeof(full_path)
            && stat(full_path, &status) == 0) {
            is_directory = S_ISDIR(status.st_mode);
        }

        if (is_directory) {
            printf("[%s] ", entry->d_name);
        } else {
            printf("%s ", entry->d_name);
        }
    }
    putchar('\n');

    if (closedir(directory) != 0) {
        perror("closedir");
        return 1;
    }
    return 0;
}
#endif

//
#ifdef JTMOS
#include "scheduler.h"
#include "compat_stdio.h"
#include "jtmfat.h"
#include "fswalk.h"
#include "fsdos.h"
#include "directfileaccess.h"

#define LS_PACKED_WIDTH 79

/* DOS/JTMOS-style wildcard matching used by both the SMSH builtin and
 * userspace ls.bin.  Matching is ASCII case-insensitive so names such as
 * BWBASIC.BIN are found by either *BWBASIC* or *bwbasic*. */
static int ls_fold_ascii(int c)
{
    if(c>='A' && c<='Z') return c+('a'-'A');
    return c;
}

static int ls_wildmatch(const char *pattern,const char *name)
{
    const char *star=NULL,*retry=NULL;
    if(!pattern || !name) return 0;
    while(*name) {
        if(*pattern=='?' ||
           (*pattern && ls_fold_ascii((unsigned char)*pattern)==
                        ls_fold_ascii((unsigned char)*name))) {
            pattern++; name++; continue;
        }
        if(*pattern=='*') {
            star=pattern++;
            retry=name;
            continue;
        }
        if(star) {
            pattern=star+1;
            name=++retry;
            continue;
        }
        return 0;
    }
    while(*pattern=='*') pattern++;
    return *pattern==0;
}

static void ls_print_name(const char *name, int long_listing, int *line_width)
{
    int n;

    if(long_listing)
    {
        printf("%s\n", name);
        *line_width = 0;
        return;
    }

    n = strlen(name);
    if(*line_width != 0 && (*line_width + 2 + n) > LS_PACKED_WIDTH)
    {
        printf("\n");
        *line_width = 0;
    }

    if(*line_width != 0)
    {
        printf("  ");
        *line_width += 2;
    }

    printf("%s", name);
    *line_width += n;

    /* A very long JTMFS name should never make the following entry start
     * beyond the normal 80-column SMSH terminal. */
    if(*line_width >= LS_PACKED_WIDTH)
    {
        printf("\n");
        *line_width = 0;
    }
}

// Dir function (ls)
// -----------------
//
// Use the same descriptor-owned immutable snapshot API as ls.bin.  The old
// built-in walker kept a raw DIRDB pointer across SchedulerCooperate(), which
// could be invalidated by another filesystem user.  User-visible output must
// use printf(): printk is intentionally the diagnostic dprintk channel.
int ls_app(int argc, char **argv)
{
    FFBLK ff;
    int fd;
    int long_listing = 0;
    int line_width = 0;
    int totalBytes = 0;
    int totalFiles = 0;
    int totalDirs = 0;
    int arg;
    int have_pattern=0;
    const char *pattern="*";
    char display_name[300];

    for(arg=1; arg<argc; arg++)
    {
        if(argv[arg] && strcmp(argv[arg], "-l") == 0)
        {
            long_listing = 1;
            continue;
        }
        if(argv[arg] && !have_pattern)
        {
            pattern=argv[arg];
            have_pattern=1;
            continue;
        }

        printf("Usage: ls [-l] [PATTERN]\n");
        printf("       wildcards: * = any string, ? = one character\n");
        return 1;
    }

    memset(&ff,0,sizeof(ff));
    fd=findfirst("*",&ff);
    if(fd<=0)
    {
        printf("ls: cannot read directory\n");
        return 1;
    }

    for(;;)
    {
        if(ff.ff_fsize!=(DWORD)-1 && ff.ff_name[0] &&
           ls_wildmatch(pattern,ff.ff_name))
        {
            if(JTMFS_TYPE_IS_DIRECTORY(ff.ff_attrib))
            {
                totalDirs++;
                snprintf(display_name,sizeof(display_name),"[%s]",ff.ff_name);
            }
            else if(!JTMFS_TYPE_IS_DIRNAME(ff.ff_attrib))
            {
                totalFiles++;
                totalBytes += (int)ff.ff_fsize;
                snprintf(display_name,sizeof(display_name),"%s",ff.ff_name);
            }
            else
            {
                display_name[0]=0;
            }

            if(display_name[0])
                ls_print_name(display_name,long_listing,&line_width);
        }

        SchedulerCooperate();
        memset(&ff,0,sizeof(ff));
        if(findnext(fd,&ff)!=0)
            break;
    }

    close(fd);

    if(!long_listing && line_width != 0)
        printf("\n");

    printf("%d File(s), %d Dir(s), %d bytes\n",
           totalFiles,totalDirs,totalBytes);
    return 0;
}

#endif
