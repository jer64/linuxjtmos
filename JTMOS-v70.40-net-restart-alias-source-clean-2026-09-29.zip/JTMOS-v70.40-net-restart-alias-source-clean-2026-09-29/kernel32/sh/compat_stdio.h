#ifndef __INCLUDED_SH_COMPAT_STDIO_H__
#define __INCLUDED_SH_COMPAT_STDIO_H__

int putchar(int c);

#endif
