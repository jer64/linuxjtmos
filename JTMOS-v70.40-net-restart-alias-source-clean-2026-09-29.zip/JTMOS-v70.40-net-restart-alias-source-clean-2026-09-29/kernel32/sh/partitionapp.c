/* -------------------------------------------------------------------------
 * partitionapp.c - native SMSH MBR primary-partition editor.
 *
 * V68.214: partition is a kernel/SMSH builtin.  It no longer depends on
 * /bin/partition.bin being present on ram:, sys:, or utilities media.
 *
 * Commands intentionally match the historical Ring3 partition.bin utility:
 *   partition hda auto
 *   partition list
 *   partition init
 *   partition create <1..4> <start-LBA> <sectors|rest> [type]
 *   partition delete <1..4>
 *   partition active <0..4>
 *   partition type <1..4> <type>
 *   partition sync
 * ------------------------------------------------------------------------- */
#include <stdio.h>
#include <string.h>
#include "partitionapp.h"

#ifdef JTMOS
#include "kernel32.h"
#include "driver_api.h"
#include "driver_sys.h"
#include "driver_rw.h"
#include "driver_devcall.h"
#include "dcpacket.h"
#include "keyb.h"
#include "logging.h"
#include "../../boot_storage_layout.h"
#endif

#define MBR_SIZE             512U
#define MBR_PART_OFFSET      446U
#define MBR_SIG_OFFSET       510U
#define JTMOS_DEFAULT_TYPE   0x7fU

typedef struct SMSH_MBR_PART {
    BYTE boot_indicator;
    BYTE beg_chs1,beg_chs2,beg_chs3;
    BYTE system_indicator;
    BYTE end_chs1,end_chs2,end_chs3;
    DWORD begsec;
    DWORD sector_count;
} __attribute__((packed)) SMSH_MBR_PART;

static void partition_usage(void)
{
    printf("JTMOS partition - built-in MBR/partsup synchronizing editor\n");
    printf("usage:\n");
    printf("  partition hda auto\n");
    printf("  partition list\n");
    printf("  partition init\n");
    printf("  partition create N START SECTORS|rest [TYPE]\n");
    printf("  partition delete N\n");
    printf("  partition active 0|1|2|3|4\n");
    printf("  partition type N TYPE\n");
    printf("  partition sync\n");
    printf("TYPE accepts decimal or 0xNN; default create type is 0x7f (JTMOS).\n");
    printf("init creates active hda1 from LBA %lu to end of disk.\n",
           (unsigned long)JTMOS_HDD_FIRST_PARTITION_LBA);
    printf("hda auto asks before replacing the table, then performs a live partsup resync.\n");
}

/* Kernel libc intentionally has no strtoul().  Keep parsing bounded to DWORD
 * and accept the same decimal/0x hexadecimal syntax as partition.bin. */
static int partition_get_u32(const char *s,DWORD *out)
{
    unsigned long value=0UL;
    unsigned int base=10U,digit;
    const char *p=s;

    if(s==NULL || out==NULL || *s=='\0') return -1;
    if(p[0]=='0' && (p[1]=='x' || p[1]=='X')) {
        base=16U; p+=2;
        if(*p=='\0') return -1;
    }
    while(*p) {
        if(*p>='0' && *p<='9') digit=(unsigned int)(*p-'0');
        else if(base==16U && *p>='a' && *p<='f') digit=(unsigned int)(*p-'a')+10U;
        else if(base==16U && *p>='A' && *p<='F') digit=(unsigned int)(*p-'A')+10U;
        else return -1;
        if(digit>=base) return -1;
        if(value>(0xffffffffUL-(unsigned long)digit)/(unsigned long)base) return -1;
        value=value*(unsigned long)base+(unsigned long)digit;
        ++p;
    }
    *out=(DWORD)value;
    return 0;
}

static SMSH_MBR_PART *partition_entry(BYTE *mbr,int slot)
{
    return (SMSH_MBR_PART *)(mbr+MBR_PART_OFFSET+(slot*16));
}

#ifdef JTMOS
static int partition_disk_info(int dnr,DWORD *sectors,DWORD *blocksize)
{
    int n,bs;
    n=getsize(dnr);
    bs=getblocksize(dnr);
    if(n<=0 || bs<512) return -1;
    if(sectors!=NULL) *sectors=(DWORD)n;
    if(blocksize!=NULL) *blocksize=(DWORD)bs;
    return 0;
}

static int partition_read_mbr(int dnr,BYTE *mbr)
{
    if(readblock(dnr,0,mbr)!=0) {
        printf("partition: unable to read hda LBA0.\n");
        return -1;
    }
    return 0;
}

static int partition_sync_partsup(void)
{
    int pdnr=driver_getdevicenrbyname("partsup");
    DWORD active=0;
    int rv;
    if(!isValidDevice(pdnr)) {
        printf("partition: kernel partsup control device not found; reboot/rescan required.\n");
        return -1;
    }
    rv=device_call(pdnr,DEVICE_CMD_SYNC,0,0,0,0,&active,NULL);
    if(rv!=0) {
        printf("partition: partsup sync failed, error %d.\n",rv);
        return -1;
    }
    printf("partition: partsup sync OK, %lu partition device(s) active.\n",
           (unsigned long)active);
    return 0;
}

static int partition_commit_mbr(int dnr,BYTE *mbr)
{
    BYTE verify[MBR_SIZE];
    int i,rv=-1;

    /* V68.216: partition-table writes can replace/remove an hda1 that KLOGGER
     * is currently using.  Quiesce persistence before touching LBA0 and keep
     * it detached through partsup refresh/readback.  StorageChanged() resets
     * the hda1 candidate timer, so the new geometry must then remain stable
     * for eight seconds before persistent logging can resume. */
    if(SystemLoggingStorageChanging("hda1")!=0) {
        printf("partition: KLOGGER did not quiesce hda1; MBR update aborted.\n");
        return -1;
    }

    mbr[MBR_SIG_OFFSET]=0x55;
    mbr[MBR_SIG_OFFSET+1]=0xaa;
    if(writeblock(dnr,0,mbr)!=0) {
        printf("partition: MBR write failed.\n");
        goto out;
    }
    /* partsup owns the durability/order barrier and refreshes hda1..hda4 only
     * after the parent-disk write has been flushed. */
    if(partition_sync_partsup()!=0) goto out;
    if(readblock(dnr,0,verify)!=0) {
        printf("partition: MBR readback failed after partsup sync.\n");
        goto out;
    }
    for(i=(int)MBR_PART_OFFSET;i<(int)MBR_SIZE;i++) {
        if(verify[i]!=mbr[i]) {
            printf("partition: MBR verify mismatch at byte %d (expected %02x got %02x).\n",
                   i,mbr[i],verify[i]);
            goto out;
        }
    }
    printf("partition: MBR write + partsup durability sync + readback verify OK.\n");
    rv=0;
out:
    SystemLoggingStorageChanged("hda1");
    return rv;
}
#else
static int partition_sync_partsup(void) { return -1; }
#endif

static void partition_print_part(int n,const SMSH_MBR_PART *p)
{
    DWORD end;
    if(p->system_indicator==0 || p->sector_count==0) {
        printf("hda%d: <empty>\n",n+1);
        return;
    }
    end=p->begsec+p->sector_count-1U;
    printf("hda%d: %s type=0x%02x start=%lu sectors=%lu end=%lu (%lu MiB)\n",
           n+1,p->boot_indicator==0x80?"active":"      ",p->system_indicator,
           (unsigned long)p->begsec,(unsigned long)p->sector_count,
           (unsigned long)end,(unsigned long)(p->sector_count/2048UL));
}

static int partition_list_parts(BYTE *mbr,DWORD sectors)
{
    int i;
    printf("hda: %lu sectors, %lu MiB, MBR signature %s\n",
           (unsigned long)sectors,(unsigned long)(sectors/2048UL),
           (mbr[510]==0x55 && mbr[511]==0xaa)?"55AA":"missing");
    for(i=0;i<4;i++) partition_print_part(i,partition_entry(mbr,i));
    return 0;
}

static int partition_overlaps(BYTE *mbr,int slot,DWORD start,DWORD count)
{
    int i;
    DWORD end;
    if(count>0xffffffffUL-start) return -1;
    end=start+count;
    for(i=0;i<4;i++) {
        SMSH_MBR_PART *p;
        DWORD pe;
        if(i==slot) continue;
        p=partition_entry(mbr,i);
        if(p->system_indicator==0 || p->sector_count==0) continue;
        if(p->sector_count>0xffffffffUL-p->begsec) return -1;
        pe=p->begsec+p->sector_count;
        if(start<pe && p->begsec<end) return i+1;
    }
    return 0;
}

static void partition_fill_chs_lba(SMSH_MBR_PART *p)
{
    p->beg_chs1=0xfe; p->beg_chs2=0xff; p->beg_chs3=0xff;
    p->end_chs1=0xfe; p->end_chs2=0xff; p->end_chs3=0xff;
}

#ifdef JTMOS
static int partition_create(int dnr,BYTE *mbr,DWORD disk,int argc,char **argv)
{
    DWORD sn,start,count,type=JTMOS_DEFAULT_TYPE;
    SMSH_MBR_PART *p;
    int slot,ov;
    if(argc<5) { partition_usage(); return 1; }
    if(partition_get_u32(argv[2],&sn) || sn<1 || sn>4 ||
       partition_get_u32(argv[3],&start)) {
        printf("partition: invalid slot/start.\n"); return 1;
    }
    slot=(int)sn-1;
    if(start<JTMOS_HDD_FIRST_PARTITION_LBA) {
        printf("partition: start LBA must be >= %lu to protect the JTMOS boot/kernel area.\n",
               (unsigned long)JTMOS_HDD_FIRST_PARTITION_LBA);
        return 1;
    }
    if(!strcmp(argv[4],"rest")) {
        if(start>=disk) { printf("partition: start is beyond disk.\n"); return 1; }
        count=disk-start;
    } else if(partition_get_u32(argv[4],&count) || count==0) {
        printf("partition: invalid sector count.\n"); return 1;
    }
    if(argc>=6 && (partition_get_u32(argv[5],&type) || type==0 || type>255)) {
        printf("partition: invalid type.\n"); return 1;
    }
    if(start>=disk || count>disk-start) {
        printf("partition: requested range exceeds hda.\n"); return 1;
    }
    ov=partition_overlaps(mbr,slot,start,count);
    if(ov<0) { printf("partition: invalid/overflowing existing partition geometry.\n"); return 1; }
    if(ov) { printf("partition: requested range overlaps hda%d.\n",ov); return 1; }
    p=partition_entry(mbr,slot);
    memset(p,0,sizeof(*p));
    p->system_indicator=(BYTE)type;
    p->begsec=start;
    p->sector_count=count;
    partition_fill_chs_lba(p);
    if(partition_commit_mbr(dnr,mbr)!=0) return 1;
    partition_print_part(slot,p);
    return 0;
}

static int partition_init_disk(int dnr,BYTE *mbr,DWORD disk);

static int partition_confirm_auto_overwrite(void)
{
    int key;
    printf("Over write partition table on hda: (y/n) ? ");
    for(;;) {
        key=getch();
        if(ConsumeTerminalInterrupt(GetCurrentTerminal())) {
            printf("^C\npartition: cancelled.\n");
            return 0;
        }
        if(key=='y' || key=='Y') { printf("%c\n",key); return 1; }
        if(key=='n' || key=='N' || key==27 || key==3) {
            if(key>=32 && key<=126) printf("%c",key);
            printf("\npartition: cancelled.\n");
            return 0;
        }
    }
}

static int partition_auto_disk(int dnr,BYTE *mbr,DWORD disk)
{
    if(!partition_confirm_auto_overwrite()) return 0;
    return partition_init_disk(dnr,mbr,disk);
}

static int partition_init_disk(int dnr,BYTE *mbr,DWORD disk)
{
    SMSH_MBR_PART *p;
    if(disk<=JTMOS_HDD_FIRST_PARTITION_LBA) {
        printf("partition: disk is too small for JTMOS partition layout.\n");
        return 1;
    }
    printf("partition: WARNING: replacing all four primary partition entries.\n");
    memset(mbr+MBR_PART_OFFSET,0,64);
    p=partition_entry(mbr,0);
    p->boot_indicator=0x80;
    p->system_indicator=JTMOS_DEFAULT_TYPE;
    p->begsec=JTMOS_HDD_FIRST_PARTITION_LBA;
    p->sector_count=disk-JTMOS_HDD_FIRST_PARTITION_LBA;
    partition_fill_chs_lba(p);
    if(partition_commit_mbr(dnr,mbr)!=0) return 1;
    partition_print_part(0,p);
    printf("Next: mkfs hda1\n");
    return 0;
}
#endif

int partition_app(int argc,char **argv)
{
#ifdef JTMOS
    BYTE mbr[MBR_SIZE];
    DWORD sectors=0,bs=0,n=0,type=0;
    int dnr,slot,i;
    SMSH_MBR_PART *p;

    dnr=driver_getdevicenrbyname("hda");
    if(!isValidDevice(dnr) || partition_disk_info(dnr,&sectors,&bs)!=0) {
        printf("partition: hda not available.\n"); return 1;
    }
    if(bs!=512) {
        printf("partition: only 512-byte logical-sector MBR disks are supported (hda=%lu).\n",
               (unsigned long)bs); return 1;
    }
    if(partition_read_mbr(dnr,mbr)!=0) return 1;

    if(argc==3 && !strcmp(argv[1],"hda") && !strcmp(argv[2],"auto"))
        return partition_auto_disk(dnr,mbr,sectors);
    if(argc<2 || !strcmp(argv[1],"list")) return partition_list_parts(mbr,sectors);
    if(!strcmp(argv[1],"sync")) {
        int sync_rv;
        if(SystemLoggingStorageChanging("hda1")!=0) {
            printf("partition: KLOGGER did not quiesce hda1; partsup sync aborted.\n");
            return 1;
        }
        sync_rv=partition_sync_partsup();
        SystemLoggingStorageChanged("hda1");
        return sync_rv!=0;
    }
    if(!strcmp(argv[1],"init")) return partition_init_disk(dnr,mbr,sectors);
    if(!strcmp(argv[1],"create")) return partition_create(dnr,mbr,sectors,argc,argv);

    if(!strcmp(argv[1],"delete")) {
        if(argc!=3 || partition_get_u32(argv[2],&n) || n<1 || n>4) {
            partition_usage(); return 1;
        }
        slot=(int)n-1;
        memset(partition_entry(mbr,slot),0,sizeof(SMSH_MBR_PART));
        if(partition_commit_mbr(dnr,mbr)!=0) return 1;
        printf("partition: hda%d deleted.\n",slot+1);
        return 0;
    }
    if(!strcmp(argv[1],"active")) {
        if(argc!=3 || partition_get_u32(argv[2],&n) || n>4) {
            partition_usage(); return 1;
        }
        for(i=0;i<4;i++) partition_entry(mbr,i)->boot_indicator=0;
        if(n) {
            p=partition_entry(mbr,(int)n-1);
            if(p->system_indicator==0 || p->sector_count==0) {
                printf("partition: hda%lu is empty.\n",(unsigned long)n); return 1;
            }
            p->boot_indicator=0x80;
        }
        if(partition_commit_mbr(dnr,mbr)!=0) return 1;
        printf("partition: active primary partition = %s.\n",n?argv[2]:"none");
        return 0;
    }
    if(!strcmp(argv[1],"type")) {
        if(argc!=4 || partition_get_u32(argv[2],&n) || n<1 || n>4 ||
           partition_get_u32(argv[3],&type) || type==0 || type>255) {
            partition_usage(); return 1;
        }
        p=partition_entry(mbr,(int)n-1);
        if(p->sector_count==0) {
            printf("partition: hda%lu is empty.\n",(unsigned long)n); return 1;
        }
        p->system_indicator=(BYTE)type;
        if(partition_commit_mbr(dnr,mbr)!=0) return 1;
        partition_print_part((int)n-1,p);
        return 0;
    }
    partition_usage();
    return 1;
#else
    (void)argc; (void)argv;
    printf("partition: native disk administration is unavailable in the host shell build.\n");
    return 1;
#endif
}
