/* sqa.c - bounds-checked streaming SQARC520 extractor, JTMOS V65. */
#if defined(JTMOSKERNEL)
#include "kernel32.h"
#include "sqa.h"
#include "nzip.h"
#include "scheduler.h"
#define SQA_COOPERATE() SchedulerCooperate()
typedef long SQA_IO_COUNT;
typedef long SQA_OFF;
#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include "sqa.h"
#include "nzip.h"
typedef ssize_t SQA_IO_COUNT;
typedef off_t SQA_OFF;
#define SQA_COOPERATE() ((void)0)
#endif

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

/* V68.124: all mutable extractor state is invocation-local. */


#define SQA_PROGRESS_WIDTH 22

typedef struct sqa_progress_state {
    DWORD total;
    DWORD done;
    DWORD start_ms;
    DWORD last_ms;
    unsigned last_percent;
    char label[19];
} SQA_PROGRESS;

static DWORD sqa_progress_now(void)
{
#if defined(JTMOSKERNEL) || defined(JTMOS_APPLICATION)
    return (DWORD)GetTickCount();
#else
    return 0U;
#endif
}

static unsigned sqa_progress_percent(DWORD done,DWORD total)
{
    if(total==0U || done>=total) return 100U;
    /* Avoid overflowing 32-bit arithmetic for very large archive members. */
    while(total>0x02000000UL) { total>>=1; done>>=1; }
    return (unsigned)((done*100UL)/total);
}

static void sqa_progress_label(char out[19],const char *name)
{
    unsigned i;
    for(i=0U;i<18U;i++) out[i]=' ';
    out[18]='\0';
    if(name==NULL) return;
    for(i=0U;i<18U && name[i];i++) out[i]=name[i];
}

static void sqa_progress_begin(SQA_PROGRESS *p,const char *name,DWORD total)
{
    memset(p,0,sizeof(*p));
    p->total=total;
    p->start_ms=sqa_progress_now();
    p->last_ms=p->start_ms;
    p->last_percent=101U;
    sqa_progress_label(p->label,name);
}

static void sqa_progress_draw(SQA_PROGRESS *p,DWORD done,int final)
{
    char bar[SQA_PROGRESS_WIDTH+1];
    unsigned percent,filled,i,eta_s=0U,eta_m=0U,eta_ss=0U;
    DWORD now,elapsed,remaining,rate,elapsed_s,eta_ms;
    int eta_known=0;

    if(p==NULL) return;
    if(done>p->total) done=p->total;
    p->done=done;
    percent=sqa_progress_percent(done,p->total);
    now=sqa_progress_now();

    /* At most ten screen refreshes/second, and never repaint an unchanged
     * percentage.  This keeps the progress indicator cheaper than the I/O. */
    if(!final && percent==p->last_percent) return;
    if(!final && p->last_percent<=100U && (DWORD)(now-p->last_ms)<100U) return;

    filled=(percent*SQA_PROGRESS_WIDTH)/100U;
    for(i=0U;i<SQA_PROGRESS_WIDTH;i++) bar[i]=(i<filled)?'#':'-';
    bar[SQA_PROGRESS_WIDTH]='\0';

    elapsed=(DWORD)(now-p->start_ms);
    remaining=p->total-done;
    if(done>0U && elapsed>=250U && remaining>0U) {
        if(done>=elapsed) {
            /* Fast path: bytes/ms, avoids done*1000 overflow. */
            rate=done/elapsed;
            if(rate>0U) {
                eta_ms=(remaining+rate-1U)/rate;
                eta_s=(unsigned)((eta_ms+999U)/1000U);
                eta_known=1;
            }
        } else {
            elapsed_s=(elapsed+999U)/1000U;
            rate=elapsed_s ? done/elapsed_s : 0U;
            if(rate>0U) {
                eta_s=(unsigned)((remaining+rate-1U)/rate);
                eta_known=1;
            }
        }
    }
    if(final || remaining==0U) { eta_s=0U; eta_known=1; }
    eta_m=eta_s/60U;
    eta_ss=eta_s%60U;

    if(final) {
        unsigned elapsed_total_s=(unsigned)((elapsed+999U)/1000U);
        printf("\r%s [%s] %3u%% time %02u:%02u",p->label,bar,percent,
               elapsed_total_s/60U,elapsed_total_s%60U);
    } else if(eta_known)
        printf("\r%s [%s] %3u%% ETA %02u:%02u",p->label,bar,percent,eta_m,eta_ss);
    else
        printf("\r%s [%s] %3u%% ETA --:--",p->label,bar,percent);
    if(final) printf("\n");
#if !defined(JTMOSKERNEL)
    fflush(stdout);
#endif
    p->last_percent=percent;
    p->last_ms=now;
}

static int read_exact(int fd, void *buffer, size_t length)
{
    BYTE *p;
    size_t done;
    p = (BYTE *)buffer;
    done = 0U;
    while(done < length) {
        SQA_IO_COUNT n = read(fd,p+done,length-done);
        if(n < 0) { if(errno == EINTR) continue; return -1; }
        if(n == 0) { errno = EIO; return -1; }
        done += (size_t)n;
        SQA_COOPERATE();
    }
    return 0;
}

static int write_exact(int fd, const void *buffer, size_t length)
{
    const BYTE *p;
    size_t done;
    p = (const BYTE *)buffer;
    done = 0U;
    while(done < length) {
        SQA_IO_COUNT n = write(fd,p+done,length-done);
        if(n < 0) { if(errno == EINTR) continue; return -1; }
        if(n == 0) { errno = EIO; return -1; }
        done += (size_t)n;
        SQA_COOPERATE();
    }
    return 0;
}

static DWORD decode_u32_le(const BYTE p[4])
{
    return (DWORD)p[0] | ((DWORD)p[1] << 8U)
         | ((DWORD)p[2] << 16U) | ((DWORD)p[3] << 24U);
}

static int JTM_UNUSED read_u32_le(int fd, DWORD *value)
{
    BYTE p[4];
    if(read_exact(fd,p,sizeof(p)) != 0) return -1;
    *value = decode_u32_le(p);
    return 0;
}

static int valid_name(const char *name)
{
    return name != NULL && name[0] != '\0'
        && strcmp(name,".") != 0 && strcmp(name,"..") != 0
        && strchr(name,'/') == NULL && strchr(name,'\\') == NULL
        && strchr(name,':') == NULL;
}

static int duplicate_name(const SQA_CONTEXT *ctx, unsigned upto, const char *name)
{
    unsigned i;
    for(i=0U;i<upto;++i)
        if(strcmp(ctx->disk.entries[i].fname,name) == 0) return 1;
    return 0;
}

static int make_output_name(const SQA_CONTEXT *ctx, char *out, size_t capacity, const char *name)
{
    size_t a,b;
    int slash;
    if(out == NULL || capacity == 0U || !valid_name(name)) return -1;
    a = strlen(ctx->dstdir);
    b = strlen(name);
    slash = a > 0U && ctx->dstdir[a-1U] != '/' && ctx->dstdir[a-1U] != ':';
    if(a + (slash ? 1U : 0U) + b + 1U > capacity) return -1;
    out[0] = '\0';
    if(a != 0U) {
        memcpy(out,ctx->dstdir,a+1U);
        if(slash) { out[a++] = '/'; out[a] = '\0'; }
    }
    memcpy(out+a,name,b+1U);
    return 0;
}

static void reset_archive(SQA_CONTEXT *ctx)
{
    free(ctx->disk.entries);
    memset(&ctx->disk,0,sizeof(ctx->disk));
}

static int archive_file_size(int fd, long *size)
{
    SQA_OFF current,end;
    current = lseek(fd,0,SEEK_CUR);
    if(current < 0) return -1;
    end = lseek(fd,0,SEEK_END);
    if(end < 0) return -1;
    if(lseek(fd,current,SEEK_SET) < 0) return -1;
    *size = (long)end;
    return 0;
}

static int load_directory(SQA_CONTEXT *ctx, int fd)
{
    BYTE count[2];
    BYTE *dirbuf=NULL;
    unsigned i;
    long header,dir_bytes,data_offset,archive_size;
    DWORD expected_offset;

    reset_archive(ctx);
    if(ctx->seloffs < 0) return 1;
    if(archive_file_size(fd,&archive_size) != 0) return 1;
    header = (long)ctx->seloffs + SQA_SAFE_AREA_SIZE;
    if(header < 0 || header > archive_size) return 1;
    if(lseek(fd,(SQA_OFF)header,SEEK_SET) < 0) return 1;
    if(read_exact(fd,ctx->disk.identifier,SQA_IDENTIFIER_SIZE) != 0) return 1;
    ctx->disk.identifier[SQA_IDENTIFIER_SIZE] = '\0';
    if(memcmp(ctx->disk.identifier,SQA_IDENTIFIER,SQA_IDENTIFIER_SIZE) != 0) return 1;
    if(read_exact(fd,count,sizeof(count)) != 0) return 2;
    ctx->disk.nr_files = (WORD)((WORD)count[0] | ((WORD)count[1] << 8U));
    if((unsigned)ctx->disk.nr_files > SQA_MAX_FILES) return 2;

    dir_bytes = (long)ctx->disk.nr_files * (long)SQA_DISK_ENTRY_SIZE;
    data_offset = header + (long)SQA_IDENTIFIER_SIZE + 2L + dir_bytes;
    if(data_offset < header || data_offset > archive_size) return 2;
    ctx->disk.data_offset = data_offset;
    ctx->disk.archive_size = archive_size;

    if(ctx->disk.nr_files != 0U) {
        ctx->disk.entries = (FE *)malloc((size_t)ctx->disk.nr_files*sizeof(FE));
        dirbuf = (BYTE *)malloc((size_t)dir_bytes);
        if(ctx->disk.entries == NULL || dirbuf == NULL) {
            free(dirbuf);
            return 3;
        }
        memset(ctx->disk.entries,0,(size_t)ctx->disk.nr_files*sizeof(FE));

        /* V67.8.53: one directory read instead of five read() calls for every
         * archive member.  SQARC520 is still decoded field-by-field. */
        if(read_exact(fd,dirbuf,(size_t)dir_bytes)!=0) {
            free(dirbuf);
            return 2;
        }
    }

    expected_offset = 0U;
    for(i=0U;i<(unsigned)ctx->disk.nr_files;++i) {
        FE *e;
        const BYTE *raw;
        DWORD endoff;
        unsigned j;
        SQA_COOPERATE();
        e = &ctx->disk.entries[i];
        raw=dirbuf + (size_t)i*(size_t)SQA_DISK_ENTRY_SIZE;
        memcpy(e->fname,raw,SQA_FILENAME_SIZE);
        e->reserved=raw[SQA_FILENAME_SIZE];
        e->offset=decode_u32_le(raw+32U);
        e->length=decode_u32_le(raw+36U);
        e->chksum=decode_u32_le(raw+40U);
        /* A valid disk name must contain a NUL within its fixed field. */
        for(j=0U;j<SQA_FILENAME_SIZE;++j) if(e->fname[j] == '\0') break;
        if(j == SQA_FILENAME_SIZE || !valid_name(e->fname) || duplicate_name(ctx,i,e->fname)
           || e->offset != expected_offset || e->length > 0xffffffffUL-e->offset) {
            free(dirbuf);
            return 2;
        }
        endoff = e->offset+e->length;
        if((unsigned long)endoff > (unsigned long)(archive_size-data_offset)) {
            free(dirbuf);
            return 2;
        }
        expected_offset = endoff;
    }
    free(dirbuf);
    return 0;
}

static int verify_output_file(const char *path, const FE *e, BYTE *buffer, size_t capacity)
{
    int fd,rc=0;
    DWORD remaining,sum=0U,done=0U;
    BYTE extra;

    if(path==NULL || e==NULL || buffer==NULL || capacity==0U) return -1;
    fd=open(path,O_RDONLY);
    if(fd<0) return -1;
    remaining=e->length;
    while(remaining!=0U) {
        size_t chunk,i;
        chunk=remaining>(DWORD)capacity ? capacity : (size_t)remaining;
        if(read_exact(fd,buffer,chunk)!=0) { rc=-1; break; }
        for(i=0U;i<chunk;++i) sum+=(DWORD)buffer[i]+1U;
        remaining-=(DWORD)chunk;
        done+=(DWORD)chunk;
        SQA_COOPERATE();
    }
    if(rc==0) {
        SQA_IO_COUNT n=read(fd,&extra,1U);
        if(n!=0) rc=-1;
    }
    if(close(fd)!=0) rc=-1;
    if(rc!=0 || done!=e->length || sum!=e->chksum) return -1;
    return 0;
}

static int open_output_file(const char *path)
{
#if defined(JTMOSKERNEL)
    /* SQA is a multi-file transaction.  Per-file ATA FLUSH CACHE dominates
     * extraction on real HDDs, so close files cheaply and issue one sync()
     * after the archive pass. */
    return open(path,O_WRONLY|O_CREAT|O_TRUNC|O_JTMOS_BATCH);
#else
    return open(path,O_WRONLY|O_CREAT|O_TRUNC,0666);
#endif
}

static int sqa_has_suffix(const char *name, const char *suffix)
{
    size_t n,m;
    if(name==NULL || suffix==NULL) return 0;
    n=strlen(name);
    m=strlen(suffix);
    return n>=m && strcmp(name+n-m,suffix)==0;
}

static int sqa_make_child_path(char *out, size_t capacity,
                               const char *dst, const char *name)
{
    size_t a,b;
    int slash;
    if(out==NULL || capacity==0U || name==NULL) return -1;
    if(dst==NULL) dst="";
    a=strlen(dst); b=strlen(name);
    slash=a>0U && dst[a-1U]!='/' && dst[a-1U]!=':';
    if(a+(slash?1U:0U)+b+1U>capacity) return -1;
    out[0]='\0';
    if(a!=0U) {
        memcpy(out,dst,a+1U);
        if(slash) { out[a++]='/'; out[a]='\0'; }
    }
    memcpy(out+a,name,b+1U);
    return 0;
}

/* V68.226: SQA understands compressed Squirrel images directly.  The .nz
 * member is first copied and verified by the normal SQARC path.  After the
 * outer archive has been closed, the already-linked NZIP decoder expands it,
 * the compressed temporary is removed to release JTMFS/RAM-disk space, and
 * the resulting .img is recursively extracted by SQA.  No external nzip/unz
 * process or shell command is used. */
static int sqa_expand_compressed_image(const char *nz_path,
                                       const char *dst, int quiet)
{
    char img_path[512];
    int rc;

    if(nz_path==NULL || !sqa_has_suffix(nz_path,".img.nz")) return 0;
    if(nzip_output_name(img_path,sizeof(img_path),nz_path)!=0) return 6;

    if(!quiet) printf("sqa: built-in NZIP %s -> %s\n",nz_path,img_path);
    rc=nzip_uncompress(nz_path,img_path);
    if(rc!=0) {
        if(!quiet) printf("sqa: built-in NZIP decompression failed (%d)\n",rc);
        (void)remove(img_path);
        return 20;
    }

    /* The compressed copy is no longer needed.  Reclaim it before expanding
     * the usually much larger Squirrel image, which matters on ram:. */
    (void)remove(nz_path);
#if defined(JTMOSKERNEL)
    (void)sync();
#endif

    if(!quiet) printf("sqa: extracting compressed Squirrel image %s\n",img_path);
    rc=extract_archive_ex(img_path,"",dst,0,quiet);
    if(rc!=0) {
        if(!quiet) printf("sqa: nested SQA extraction failed for %s (%d)\n",img_path,rc);
        return 21;
    }

    (void)remove(img_path);
#if defined(JTMOSKERNEL)
    (void)sync();
#endif
    if(!quiet) printf("sqa: compressed image extracted; temporary .nz/.img removed\n");
    return 0;
}

static int extract_one(SQA_CONTEXT *ctx, int fd, const FE *e, BYTE *buffer, size_t capacity)
{
    DWORD remaining,sum,done;
    char output[512];
    int outfd,rc;
    SQA_OFF pos;
    SQA_PROGRESS progress;

    if(make_output_name(ctx,output,sizeof(output),e->fname) != 0) {
        if(!ctx->quiet) printf("sqa: unsafe or too-long output name '%s'\n",e->fname);
        return 6;
    }
    pos = (SQA_OFF)ctx->disk.data_offset + (SQA_OFF)e->offset;
    if(pos < (SQA_OFF)ctx->disk.data_offset || lseek(fd,pos,SEEK_SET) < 0) return 8;

    outfd = open_output_file(output);
    if(outfd < 0) return 10;

    remaining = e->length;
    done = 0U;
    sum = 0U;
    rc = 0;
    if(!ctx->quiet) {
        sqa_progress_begin(&progress,e->fname,e->length);
        if(e->length>(DWORD)capacity)
            printf("sqa: bounded stream for %s (%u-byte chunks; EOF at close)\n",
                   e->fname,(unsigned)capacity);
        sqa_progress_draw(&progress,0U,0);
    }
    /* V69.31: one proven, bounded buffer path for every member.  Whole-member
     * heap staging stopped nondeterministically before its first source read
     * for demos.sqa/install.img.nz.  O_JTMOS_BATCH keeps these data chunks
     * behind the old visible EOF and publishes the length once at close(). */
    while(remaining != 0U) {
        size_t chunk,i;
        chunk = remaining > (DWORD)capacity ? capacity : (size_t)remaining;
        if(read_exact(fd,buffer,chunk) != 0) { rc=8; break; }
        for(i=0U;i<chunk;++i) {
            if((i&0xfffU)==0xfffU) SQA_COOPERATE();
            sum += (DWORD)buffer[i]+1U;
        }
        if(write_exact(outfd,buffer,chunk) != 0) { rc=11; break; }
        remaining -= (DWORD)chunk;
        done += (DWORD)chunk;
        if(!ctx->quiet) sqa_progress_draw(&progress,done,0);
        SQA_COOPERATE();
    }
    if(close(outfd) != 0 && rc == 0) rc = 11;
    if(!ctx->quiet) sqa_progress_draw(&progress,done,1);
    if(rc != 0 || sum != e->chksum) {
        (void)remove(output);
        if(rc == 0) rc = 9;
        if(!ctx->quiet && rc == 9)
            printf("sqa: source checksum mismatch for %s (%08x != %08x)\n",
                   e->fname,(unsigned)sum,(unsigned)e->chksum);
        return rc;
    }

    /* Source checksum alone only proves that the SQA member was read correctly.
     * Re-open the destination and verify the exact bytes JTMFS made visible.
     * This catches target-chain/RMW corruption immediately instead of letting
     * a later consumer such as UNZ fail at 99 percent. */
    if(verify_output_file(output,e,buffer,capacity)!=0) {
        (void)remove(output);
        if(!ctx->quiet)
            printf("sqa: output verification failed for %s; corrupt copy removed.\n",
                   e->fname);
        return 13;
    }
    if(!ctx->quiet) printf("%s (%u bytes, verified)\n",output,(unsigned)e->length);
    return 0;
}

int extract_archive_ex(const char *fname, const char *spec, const char *dst,
                       int archive_offset, int quiet_mode)
{
    SQA_CONTEXT ctx_storage;
    SQA_CONTEXT *ctx=&ctx_storage;
    int fd,rc=0,pending_image=0;
    unsigned i,produced;
    BYTE *buffer=NULL;
    size_t n,capacity;
    char pending_nz[512];

    pending_nz[0]='\0';

    memset(ctx,0,sizeof(*ctx));
    ctx->quiet=quiet_mode ? 1 : 0;
    ctx->seloffs=archive_offset;

    if(fname == NULL || fname[0] == '\0') return 3;
    if(spec != NULL && spec[0] != '\0') {
        n=strlen(spec);
        if(n >= sizeof(ctx->specific)) return 6;
        memcpy(ctx->specific,spec,n+1U);
    }
    if(dst != NULL && dst[0] != '\0') {
        n=strlen(dst);
        if(n >= sizeof(ctx->dstdir)) return 6;
        memcpy(ctx->dstdir,dst,n+1U);
    }

    fd = open(fname,O_RDONLY);
    if(fd < 0) {
        if(!ctx->quiet) printf("sqa: cannot open %s\n",fname);
        return 3;
    }

    rc = load_directory(ctx,fd);
    if(rc != 0) goto out;

    /* Match JTMFS/ATA's 256-sector transport ceiling (128 KiB with 512-byte
     * sectors), but preserve fresh-boot operation by falling back to 8 KiB. */
    capacity=SQA_COPY_BUFFER_SIZE;
    while(buffer==NULL && capacity>=SQA_COPY_BUFFER_MIN) {
        buffer=(BYTE *)malloc(capacity);
        if(buffer==NULL) capacity>>=1;
    }
    if(buffer==NULL) { rc=7; goto out; }

    produced = 0U;
    for(i=0U;i<(unsigned)ctx->disk.nr_files;++i) {
        FE *e = &ctx->disk.entries[i];
        SQA_COOPERATE();
        if(ctx->specific[0] != '\0' && strcmp(ctx->specific,e->fname) != 0)
            continue;
        rc = extract_one(ctx,fd,e,buffer,capacity);
        if(rc != 0) break;
        ++produced;
        if(sqa_has_suffix(e->fname,".img.nz")) {
            if(pending_image) {
                if(!ctx->quiet) printf("sqa: more than one compressed .img.nz member is not supported in one archive\n");
                rc=22;
                break;
            }
            if(sqa_make_child_path(pending_nz,sizeof(pending_nz),ctx->dstdir,e->fname)!=0) {
                rc=6;
                break;
            }
            pending_image=1;
        }
    }
    if(rc == 0 && ctx->specific[0] != '\0' && produced == 0U) rc = 12;
    if(!ctx->quiet && rc == 0) printf("sqa: %u file(s) extracted\n",produced);

out:
    free(buffer);
    if(close(fd) != 0 && rc == 0) rc = 11;
#if defined(JTMOSKERNEL)
    /* O_JTMOS_BATCH deliberately skipped per-file hda barriers.  Make the
     * complete archive extraction durable once, including cleanup on error. */
    if(sync()!=0 && rc==0) rc=11;
#endif
    reset_archive(ctx);

    if(rc==0 && pending_image) {
        /* SMSH autostart stages the outer archive as ram:/bin/utils.iso.
         * Reclaim that known disposable copy before NZIP creates install.img;
         * this preserves V68.213's low RAM-disk high-water behaviour while
         * keeping ordinary archive files such as utilities.iso intact. */
        if(strcmp(fname,"utils.iso")==0 || sqa_has_suffix(fname,"/utils.iso")) {
            if(remove(fname)==0 && !quiet_mode)
                printf("sqa: reclaimed staged %s before compressed-image expansion\n",fname);
#if defined(JTMOSKERNEL)
            (void)sync();
#endif
        }
        rc=sqa_expand_compressed_image(pending_nz,dst,quiet_mode);
    }
    return rc;
}

/* Compatibility API: ordinary extraction at the canonical SQARC520 offset. */
int extract_archive(const char *fname, const char *spec)
{
    return extract_archive_ex(fname,spec,"",0,0);
}
