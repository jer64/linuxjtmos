/* graos_shell.c - V67.6 native SMSH adapter for GraOS/Postman functionality.
 * Uses the existing plain-PID Central Process and msgbox implementation;
 * intentionally does not import the old SDL2 tree's legacy generation-ID msgbox code. */
#include <stdio.h>
#include <string.h>
#include "kernel32.h"
#include "centralprocess.h"
#include "threads.h"
#include "ps2mouse.h"

#define SH_NOT_HANDLED (-32767)
#define GRAOS_START_TIMEOUT_MS 5000UL
#define GRAOS_START_POLL_MS      20

extern volatile int graos_startup_diag_pid;
extern volatile DWORD graos_startup_diag_magic;
extern volatile int graos_startup_diag_stage;
extern volatile int graos_startup_diag_row;

static const char *graos_stage_name(int stage)
{
    switch(stage) {
    case 1:return "main"; case 2:return "display"; case 3:return "vmode";
    case 4:return "front-buffer"; case 5:return "back-cache";
    case 6:return "resources"; case 7:return "early-frame";
    case 8:return "window-db"; case 9:return "first-draw";
    case 10:return "first-present"; case 11:return "server-ready";
    case 12:return "event-loop"; case 13:return "early-fill";
    case 14:return "early-present"; case 15:return "early-done";
    default:return "unknown";
    }
}

/* More than one shell may be active (SMSH, VT2, telnet).  The server does not
 * publish the guiserver name until its first desktop frame is visible, so a
 * plain GetThreadPID() check leaves a window in which two GraOS processes can
 * be started.  Claim that window explicitly on this single-CPU kernel. */
static volatile int graos_launch_in_progress=0;

static int graos_launch_claim(void)
{
    DWORD flags=get_eflags();
    int claimed=0;
    disable();
    if(!graos_launch_in_progress) {
        graos_launch_in_progress=1;
        claimed=1;
    }
    set_eflags(flags);
    return claimed;
}

static void graos_launch_release(void)
{
    DWORD flags=get_eflags();
    disable();
    graos_launch_in_progress=0;
    set_eflags(flags);
}

static int graos_process_live(int pid,DWORD magic)
{
    return pid>0 && pid<nr_threads && pid<N_MAX_THREADS &&
           thread_states[pid]!=0 && thread_magic[pid]==magic &&
           GetThreadMemoryUsage(pid)>0;
}

/* guiServerInit() publishes "guiserver" only after the first complete
 * desktop frame has been presented.  That name is therefore the startup
 * readiness handshake, not merely a process-created notification. */
static int graos_wait_ready(int pid,DWORD magic)
{
    DWORD started=GetTickCount();
    for(;;) {
        if(!graos_process_live(pid,magic)) return -1;
        if(GetThreadPID("guiserver")==pid) return 0;
        if((DWORD)(GetTickCount()-started)>=GRAOS_START_TIMEOUT_MS) return -2;
        MilSleep(GRAOS_START_POLL_MS);
    }
}

static void graos_launch_rollback(int pid,DWORD magic,int ter,
                                  int parent_terminal)
{
    int i;
    if(graos_process_live(pid,magic)) {
        KillThread(pid);
        for(i=0;i<10 && graos_process_live(pid,magic);i++) MilSleep(10);
    }
    (void)FreeTerminal(ter);
    if(parent_terminal>=0 && parent_terminal<N_MAX_SCREENS)
        (void)SwitchUserTerminal(parent_terminal);
    /* A failed child may already have switched the adapter and disabled the
     * LFB text mirror.  Repaint SMSH so startup failure never leaves a black
     * or frozen graphical screen. */
    if(vesa_enabled) VesaTextConsoleEnable(TRUE);
}

static int launch_background(const char *command)
{
    char exe[256]; size_t i=0; int pid;
    if(!command || !*command)return 1;
    while(command[i] && command[i]!=' ' && command[i]!='\t' && i<sizeof(exe)-1){exe[i]=command[i];i++;}
    exe[i]=0; if(!exe[0])return 1;
    pid=centralprocess_exec(exe,command,GetCurrentDNR(),GetCurrentDB(),"",GetCurrentTerminal());
    if(pid<=0){printf("launch failed: %s\n",command);return 1;}
    printf("PID %d: %s\n",pid,command);return 0;
}

static int launch_graos(void)
{
    int ter,pid,parent_terminal,ready;
    DWORD child_magic;

    parent_terminal=GetCurrentTerminal();

    if(!VesaGraOSAvailable()) {
        printf("GraOS: no usable 1024x768x32 framebuffer/provider is available.\n");
        printf("GraOS: display state enabled=%d boot=%d mode=%dx%dx%d pitch=%d LFB=0x%x bytes=0x%x provider=%d.\n",
               vesa_enabled?1:0,vesa_boot_graphics?1:0,vesa_width,vesa_height,
               vesa_bpp,vesa_pitch,vesa_frame_buf,vesa_frame_buf_bytes,
               VesaTextGraphicsProvider());
        printf("GraOS: staying on SMSH terminal %d.\n",parent_terminal);
        return 1;
    }
    if(!graos_launch_claim()) {
        printf("GraOS: startup is already in progress.\n");
        return 0;
    }

    /* The maintained START_GRAOS=0 boot path reaches GraOS through this SMSH
     * adapter, not GraOSBootStart().  Attach AUX/IRQ12 at the last safe moment:
     * root/UTILS.ISO recovery is complete, but graos.bin has not started yet. */
    if(PS2MOUSE_ENABLED)
    {
        printf("GraOS: preparing PS/2 mouse before GUI launch.\n");
        if(ps2mouse_prepare_graos())
            printf("GraOS: PS/2 mouse attach failed; GUI will continue keyboard-only.\n");
    }

    /* Never let the background SMSH and GraOS consume the same terminal FIFO.
     * Give the GUI server a private terminal and make that terminal the target
     * of physical keyboard IRQ1 input only after the first desktop frame has
     * confirmed that startup succeeded. */
    ter=NewTerminal();
    if(ter<0) {
        printf("GraOS: cannot allocate input terminal.\n");
        graos_launch_release();
        return 1;
    }

    pid=centralprocess_exec("graos.bin","graos.bin",GetCurrentDNR(),GetCurrentDB(),"",ter);
    if(pid<=0)
        pid=centralprocess_exec("graos.bin","graos.bin",GetCurrentDNR(),GetCurrentDB(),"/",ter);
    if(pid<=0 || pid>=nr_threads || pid>=N_MAX_THREADS) {
        printf("launch failed: graos.bin\n");
        FreeTerminal(ter);
        graos_launch_release();
        return 1;
    }
    child_magic=thread_magic[pid];
    graos_startup_diag_pid=pid;
    graos_startup_diag_magic=child_magic;
    graos_startup_diag_stage=0;
    graos_startup_diag_row=-1;

    /* GraOS is the compositor/server and must be able to snapshot bitmap
     * surfaces owned by client processes.  Grant the capability here, in the
     * kernel-controlled GraOS launcher, instead of trusting the user-settable
     * process name "guiserver".  GraOSBootStart() grants the same bit on the
     * direct boot path. */
    SetThreadType(pid,GetThreadType(pid)|THREAD_TYPE_SERVICE);
    if(SetTerminalOwner(ter,pid)!=0) {
        printf("GraOS: cannot transfer terminal %d ownership to PID %d.\n",ter,pid);
        graos_launch_rollback(pid,child_magic,ter,parent_terminal);
        graos_launch_release();
        return 1;
    }

    printf("GraOS: waiting for PID %d to present its first desktop frame...\n",pid);
    ready=graos_wait_ready(pid,child_magic);
    if(ready!=0) {
        if(ready==-1) {
            printf("GraOS: PID %d exited before the desktop became ready.\n",pid);
            if(graos_startup_diag_pid==pid && graos_startup_diag_magic==child_magic) {
                printf("GraOS: last startup stage=%d (%s).\n",
                       graos_startup_diag_stage,graos_stage_name(graos_startup_diag_stage));
                if(graos_startup_diag_row>=0)
                    printf("GraOS: last framebuffer row=%d of %d.\n",
                           graos_startup_diag_row,GRAOS_VESA_HEIGHT);
            }
        } else
            printf("GraOS: PID %d startup timed out after %lu ms.\n",
                   pid,(unsigned long)GRAOS_START_TIMEOUT_MS);
        printf("GraOS: failure display state enabled=%d boot=%d mode=%dx%dx%d pitch=%d provider=%d.\n",
               vesa_enabled?1:0,vesa_boot_graphics?1:0,vesa_width,vesa_height,
               vesa_bpp,vesa_pitch,VesaTextGraphicsProvider());
        graos_launch_rollback(pid,child_magic,ter,parent_terminal);
        graos_launch_release();
        return 1;
    }

    printf("GraOS: desktop ready; focusing keyboard terminal %d.\n",ter);
    if(SwitchUserTerminal(ter)) {
        printf("GraOS: cannot focus terminal %d.\n",ter);
        graos_launch_rollback(pid,child_magic,ter,parent_terminal);
        graos_launch_release();
        return 1;
    }
    graos_launch_release();
    printf("PID %d: graos.bin (keyboard terminal %d; SMSH terminal %d)\n",
           pid,ter,parent_terminal);
    return 0;
}

static int join_args(int argc,char **argv,int first,char *out,int cap)
{
    int i,used=0,j;

    if(!out || cap<=0) return 0;
    out[0]=0;

    /* Kernel SMSH is not linked against the userspace stdio implementation.
     * Build the command line explicitly instead of depending on snprintf(). */
    for(i=first;i<argc;i++)
    {
        if(!argv[i]) continue;

        if(used)
        {
            if(used+1>=cap) { out[0]=0; return 0; }
            out[used++]=' ';
        }

        for(j=0;argv[i][j];j++)
        {
            if(used+1>=cap) { out[0]=0; return 0; }
            out[used++]=argv[i][j];
        }
        out[used]=0;
    }
    return used>0;
}
static void pm_help(void)
{
    printf("Postman commands:\n  pm status\n  pm find NAME\n  pm exec COMMAND...\n  pm cleanup\n");
}
static int pm_main(int argc,char **argv)
{
    const char *sub=argc>1?argv[1]:"status";
    if(!strcmp(sub,"status")){printf("Postman/current PID: %d\n",GetCurrentThread());printf("GraOS PID: %d\n",GetThreadPID("guiserver"));return 0;}
    if(!strcmp(sub,"find")){int p;if(argc<3){pm_help();return 1;}p=GetThreadPID(argv[2]);printf("%s: %d\n",argv[2],p);return p>0?0:1;}
    if(!strcmp(sub,"exec")||!strcmp(sub,"launch")){char cmd[1024];if(!join_args(argc,argv,2,cmd,sizeof(cmd))){pm_help();return 1;}return launch_background(cmd);}
    if(!strcmp(sub,"cleanup")){printf("Postman cleanup: native msgbox state is PID-owned and cleaned on process exit.\n");return 0;}
    pm_help();return !(!strcmp(sub,"help")||!strcmp(sub,"--help"));
}
int graos_shell_try_command(const char *command,int argc,char **argv)
{
    int server_pid;
    if(!command)return SH_NOT_HANDLED;
    if(!strcmp(command,"graos")||!strcmp(command,"gui")){
        server_pid=GetThreadPID("guiserver");
        if(server_pid>0){printf("GraOS already running, PID %d.\n",server_pid);return 0;}
        return launch_graos();
    }
    if(!strcmp(command,"postman")||!strcmp(command,"pm"))return pm_main(argc,argv);
    return SH_NOT_HANDLED;
}
