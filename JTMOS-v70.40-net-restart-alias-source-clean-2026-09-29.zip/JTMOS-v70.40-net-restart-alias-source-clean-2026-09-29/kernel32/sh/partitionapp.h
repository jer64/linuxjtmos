#ifndef __INCLUDED_SMSH_PARTITIONAPP_H__
#define __INCLUDED_SMSH_PARTITIONAPP_H__

int partition_app(int argc, char **argv);

#endif
