// (C) 2020-2026 JTT.
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sh.h"
#include "lsapp.h"
#include "findapp.h"
#include "formatapp.h"
#include "partitionapp.h"
#include "chdirapp.h"
#include "helpapp.h"
#include "exitapp.h"
#include "nzip.h"
#include "sqa.h"
#include "copyall.h"
#include "rmwildcard.h"
#include "debugmode.h"
#include "memdump.h"
#include "freeapp.h"
#include "fsadmin.h"
#include "kyberapp.h"
#include "aiapp.h"
#if JTMOS_MOD_NETWORK
#include "networkapp.h"
#ifdef JTMOS
#include "networkControl.h"
#endif
#endif

#ifdef JTMOS
#include "kernel32.h"
#include "jtmfsPath.h"
#include "fswalk.h"
#include "dirtype.h"
#include "centralprocess.h"
#include "scheduler.h"
#include "reboot.h"
#include "linuxabi.h"
#include "keymap.h"
#include "input_policy.h"
#include "mouse.h"
#include "ps2mouse.h"
#include "bootutilsram.h"
#include "locktop.h"
#include "nmiapp.h"
#include "nmi.h"
#include "pit.h"
#include "int.h"
#include "apic.h"
#include "jtmos_release.h"
#if JTMOS_MOD_GRAOS_BOOT
#include "graos_boot.h"
#endif
#include "fs/api.h"
#include "fs/filebuf.h"
#include "core/dataproc/kformat.h"
#if JTMOS_MOD_PCI
#include "pci.h"
#include "usb_input.h"
#include "compat_stdio.h"
#include "fprintf.h"
#endif
#endif

#define SH_MAX_LINE 65536U
#define SH_MAX_ARGS 100
#define SH_NOT_HANDLED (-32767)
#define SH_MAX_PIPE_STAGES 16

typedef int (*shell_command_fn)(int argc, char **argv);

typedef struct shell_command {
    const char *name;
    shell_command_fn function;
} SHELL_COMMAND;

/* When shell_graos.o is linked, this weak hook adds gui/graos/postman/pm
 * without making the standalone shell depend on SDL2 or Postman. */
#if defined(__GNUC__)
extern int graos_shell_try_command(const char *command, int argc, char **argv)
    __attribute__((weak));
extern int AudioDemoMain(int argc, char **argv) __attribute__((weak));
#endif

#ifdef JTMOS
/* Restricted SMSH builtins normally print through the kernel console.  When a
 * Ring3 SQSH pipeline invokes the builtin bridge, selected stream-safe builtins
 * use smsh_printf() instead: it writes to the calling process' fd 1, which may
 * be a real kernel pipe.  Direct SMSH still falls back to normal vprintf(). */
static volatile int smsh_bridge_owner=-1;
static volatile DWORD smsh_bridge_owner_magic=0;
static volatile int smsh_bridge_depth=0;

static DWORD smsh_bridge_thread_magic(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS || !valid_pid(pid)) return 0;
    return thread_magic[pid];
}

static int smsh_bridge_owner_alive(int pid,DWORD magic)
{
    if(pid<0 || pid>=N_MAX_THREADS || !valid_pid(pid)) return 0;
    if(!thread_states[pid]) return 0;
    if(pid==0) return magic==thread_magic[0];
    return magic!=0 && thread_magic[pid]==magic;
}

typedef struct SMSH_PIPE_PRINTF_CONTEXT {
    int pid;
    int error;
    unsigned int used;
    char data[256];
} SMSH_PIPE_PRINTF_CONTEXT;

static void smsh_pipe_printf_flush(SMSH_PIPE_PRINTF_CONTEXT *ctx)
{
    int wrote;
    if(!ctx || ctx->error || ctx->used==0U) return;
    wrote=KernelFileBufWrite(ctx->pid,1,ctx->data,(int)ctx->used);
    if(wrote!=(int)ctx->used) ctx->error=1;
    ctx->used=0U;
}

static void smsh_pipe_printf_emit(void *opaque,char ch)
{
    SMSH_PIPE_PRINTF_CONTEXT *ctx=(SMSH_PIPE_PRINTF_CONTEXT *)opaque;
    if(!ctx || ctx->error) return;
    ctx->data[ctx->used++]=ch;
    if(ctx->used>=sizeof(ctx->data) || ch=='\n') smsh_pipe_printf_flush(ctx);
}

int smsh_printf(const char *fmt,...)
{
    va_list args;
    int result;
    SMSH_PIPE_PRINTF_CONTEXT ctx;
    if(fmt==NULL) return 0;
    if(smsh_bridge_owner!=GetCurrentThread()) {
        va_start(args,fmt);
        result=vprintf(fmt,args);
        va_end(args);
        return result;
    }
    memset(&ctx,0,sizeof(ctx));
    ctx.pid=GetCurrentThread();
    va_start(args,fmt);
    result=jt_vformat(smsh_pipe_printf_emit,&ctx,fmt,args);
    va_end(args);
    smsh_pipe_printf_flush(&ctx);
    return ctx.error ? -1 : result;
}

static void smsh_bridge_enter(void)
{
    int pid=GetCurrentThread();
    DWORD magic=smsh_bridge_thread_magic(pid);
    for(;;) {
        DWORD flags=get_eflags();
        int stale_owner=-1;
        DWORD stale_magic=0;
        disable();
        if(smsh_bridge_owner>=0 &&
           !smsh_bridge_owner_alive(smsh_bridge_owner,smsh_bridge_owner_magic)) {
            stale_owner=smsh_bridge_owner;
            stale_magic=smsh_bridge_owner_magic;
            smsh_bridge_owner=-1;
            smsh_bridge_owner_magic=0;
            smsh_bridge_depth=0;
        }
        if(smsh_bridge_owner<0 ||
           (smsh_bridge_owner==pid && smsh_bridge_owner_magic==magic)) {
            smsh_bridge_owner=pid;
            smsh_bridge_owner_magic=magic;
            smsh_bridge_depth++;
            set_eflags(flags);
            if(stale_owner>=0)
                dprintk("[LOCK] STALE-CLEAR kind=smsh-bridge owner_pid=%d owner_magic=%x caller_pid=%d\n",
                        stale_owner,(unsigned)stale_magic,pid);
            return;
        }
        set_eflags(flags);
        SchedulerWaitPause(1000UL);
    }
}

static void smsh_bridge_leave(void)
{
    int pid=GetCurrentThread();
    DWORD magic=smsh_bridge_thread_magic(pid);
    DWORD flags=get_eflags();
    disable();
    if(smsh_bridge_owner==pid && smsh_bridge_owner_magic==magic) {
        if(smsh_bridge_depth>0) smsh_bridge_depth--;
        if(smsh_bridge_depth==0) {
            smsh_bridge_owner=-1;
            smsh_bridge_owner_magic=0;
        }
    }
    set_eflags(flags);
}
#endif

static int sound_builtin(int argc, char **argv)
{
#if defined(__GNUC__)
    if(AudioDemoMain != NULL)
        return AudioDemoMain(argc, argv);
#endif
    printf("sound: audio drivers are not included in this kernel build.\n");
    return 1;
}

#ifdef JTMOS
/* Kernel-controlled GraOS launch entry.  SQSH reaches this through the
 * restricted SMSH builtin syscall so GraOS receives both a private terminal
 * and THREAD_TYPE_SERVICE before any GUI client can attach a framebuffer. */
static const char *gfx_provider_name(int provider)
{
    if(provider==VESA_TEXT_GFX_NV6150) return "GeForce 6150SE/MCP61";
    if(provider==VESA_TEXT_GFX_VM_VGA) return "VM VGA/BGA";
    if(provider==VESA_TEXT_GFX_BOOT_VESA) return "boot VESA/LFB";
    if(provider==VESA_TEXT_GFX_AUTO) return "auto";
    return "none/text VGA";
}

static void gfx_usage(void)
{
    printf("Usage: gfx [auto|geforce|vmvga|640x480|1024x768|status|off]\n");
    printf("       gfx [auto|geforce|vmvga] [640x480|1024x768]\n");
    printf("       gfx vt <0-6>\n");
    printf("Default: auto provider, 640x480x32 framebuffer text console.\n");
    printf("On eMachines GeForce 6150SE/MCP61, use: gfx geforce [640x480|1024x768]\n");
}

static int gfx_parse_mode(const char *s, int *w, int *h)
{
    if(strcmp(s,"640x480")==0) { *w=640; *h=480; return 0; }
    if(strcmp(s,"1024x768")==0) { *w=1024; *h=768; return 0; }
    return 1;
}

static int gfx_builtin(int argc, char **argv)
{
    int provider=VESA_TEXT_GFX_AUTO;
    int width=VESA_TEXT_GFX_DEFAULT_WIDTH;
    int height=VESA_TEXT_GFX_DEFAULT_HEIGHT;
    int active;
    int explicit_mode=FALSE;
    const char *name;

    if(argc>=2 && strcmp(argv[1],"status")==0)
    {
        if(argc!=2) { gfx_usage(); return 2; }
        active=VesaTextGraphicsProvider();
        name=gfx_provider_name(active);
        printf("gfx: provider=%s graphics=%d vt-render=%d mode=%dx%dx%d pitch=%d LFB=0x%x\n",
               name,vesa_enabled?1:0,vesa_text_console_enabled?1:0,
               vesa_width,vesa_height,vesa_bpp,vesa_pitch,vesa_frame_buf);
        printf("gfx: prepared nv6150=%d mapped=%d phys=0x%x linear=0x%x vm-vga=%d mapped=%d visible-vt=%d input-vt=%d\n",
               Nv6150IsPrepared()?1:0,Nv6150FramebufferMapped()?1:0,
               Nv6150GetFramebufferPhysical(),Nv6150GetFramebufferLinear(),
               VBoxBgaIsPrepared()?1:0,VBoxBgaFramebufferMapped()?1:0,
               GetVisibleTerminal(),GetInputTerminal());
        return 0;
    }

    if(argc>=2 && strcmp(argv[1],"off")==0)
    {
        if(argc!=2) { gfx_usage(); return 2; }
        /* Do not attempt a BIOS/VGA mode-3 transition from protected mode on
         * native MCP61 hardware. `off` only releases the framebuffer terminal
         * renderer; a later gfx command re-enables it idempotently. */
        VesaTextConsoleEnable(FALSE);
        printf("gfx: virtual-terminal framebuffer renderer disabled; hardware mode unchanged.\n");
        return 0;
    }

    if(argc>=2 && strcmp(argv[1],"vt")==0)
    {
        int vt;
        if(argc!=3 || argv[2][0]<'0' || argv[2][0]>'6' || argv[2][1]!=0)
        {
            printf("Usage: gfx vt <0-6>\n");
            return 2;
        }
        vt=argv[2][0]-'0';
        if(SwitchUserTerminal(vt)!=0)
        {
            printf("gfx: VT%d is not available.\n",vt);
            return 1;
        }
        if(vesa_enabled && !vesa_text_console_enabled)
            VesaTextConsoleEnable(TRUE);
        if(vesa_enabled)
            VesaTextConsoleRefresh();
        printf("gfx: switched display and keyboard focus to VT%d.\n",vt);
        return 0;
    }

    if(argc>3) { gfx_usage(); return 2; }

    if(argc>=2)
    {
        if(strcmp(argv[1],"auto")==0) provider=VESA_TEXT_GFX_AUTO;
        else if(strcmp(argv[1],"geforce")==0) provider=VESA_TEXT_GFX_NV6150;
        else if(strcmp(argv[1],"vmvga")==0) provider=VESA_TEXT_GFX_VM_VGA;
        else if(gfx_parse_mode(argv[1],&width,&height)==0) { provider=VESA_TEXT_GFX_AUTO; explicit_mode=TRUE; }
        else { gfx_usage(); return 2; }
    }

    if(argc==3)
    {
        if(!(strcmp(argv[1],"auto")==0 || strcmp(argv[1],"geforce")==0 ||
             strcmp(argv[1],"vmvga")==0) ||
           gfx_parse_mode(argv[2],&width,&height)!=0)
        {
            gfx_usage();
            return 2;
        }
        explicit_mode=TRUE;
    }

    if(provider==VESA_TEXT_GFX_AUTO && !explicit_mode)
        active=VesaStartTextGraphics();
    else
        active=VesaSetTextGraphics(provider,width,height);
    if(active==VESA_TEXT_GFX_NONE)
    {
        printf("gfx: graphics console activation failed: %s.\n",
               VesaTextGraphicsLastError());
        printf("gfx: nv6150 prepared=%d mapped=%d phys=0x%x linear=0x%x; paging=%d.\n",
               Nv6150IsPrepared()?1:0,Nv6150FramebufferMapped()?1:0,
               Nv6150GetFramebufferPhysical(),Nv6150GetFramebufferLinear(),
               paging_enabled?1:0);
        return 1;
    }

    name=gfx_provider_name(active);
    printf("gfx: %s %dx%dx%d active; virtual-terminal renderer enabled.\n",
           name,vesa_width,vesa_height,vesa_bpp);
    return 0;
}

static int graos_builtin(int argc, char **argv)
{
#if defined(__GNUC__)
    if(graos_shell_try_command != NULL)
        return graos_shell_try_command("graos",argc,argv);
#endif
    (void)argc; (void)argv;
    printf("graos: GraOS launcher is not included in this kernel build.\n");
    return 1;
}
#endif

static int sh_debug = 0;

#ifdef JTMOS
static int sh_directory_exists(const char *path)
{
    int pid,dnr,db;
    if(path==NULL || !path[0]) return 0;
    pid=GetCurrentThread(); dnr=GetCurrentDNR(); db=GetCurrentDB();
    if(chdir(path)!=0) return 0;
    /* Restore by DNR/DB identity instead of reparsing a saved pathname.  This
     * keeps mkdir -p side-effect free even across device-qualified paths. */
    SetThreadDNR(pid,dnr); SetThreadDB(pid,db);
    return 1;
}

static int sh_mkdir_p(const char *path)
{
    char tmp[1024];
    int i,n;
    if(path==NULL || !path[0] || strlen(path)>=(int)sizeof(tmp)) return -1;
    strcpy(tmp,path); n=(int)strlen(tmp);
    for(i=1;i<n;i++) {
        if(tmp[i]=='/' || tmp[i]=='\\') {
            char save=tmp[i];
            if(i>0 && tmp[i-1]==':') continue;
            tmp[i]=0;
            if(tmp[0] && !sh_directory_exists(tmp)) (void)mkdir(tmp,0);
            tmp[i]=save;
        }
    }
    if(!sh_directory_exists(tmp) && mkdir(tmp,0)!=0 && !sh_directory_exists(tmp)) return -1;
    return 0;
}

static int mkdir_builtin(int argc, char **argv)
{
    int i,start=1,pflag=0,rc=0;
    if(argc < 2) {
        printf("Usage: mkdir [-p] DIRECTORY [DIRECTORY ...]\n");
        return 2;
    }
    if(!strcmp(argv[1], "-h") || !strcmp(argv[1], "--help")) {
        printf("Usage: mkdir [-p] DIRECTORY [DIRECTORY ...]\n");
        printf("Create JTMFS directories; -p creates missing parent directories.\n");
        return 0;
    }
    if(!strcmp(argv[1],"-p")) { pflag=1; start=2; }
    if(start>=argc) return 2;
    for(i=start;i<argc;i++) {
        if((pflag ? sh_mkdir_p(argv[i]) : mkdir(argv[i],0))!=0) {
            if(!(pflag && sh_directory_exists(argv[i]))) {
                printf("mkdir: cannot create '%s'\n",argv[i]); rc=1;
            }
        }
    }
    return rc;
}

static int env_split_assignment(const char *arg,char *name,int cap,const char **value)
{
    const char *eq;
    int n;
    if(arg==NULL || name==NULL || cap<2 || value==NULL) return -1;
    eq=strchr(arg,'=');
    if(eq==NULL) return -1;
    n=(int)(eq-arg);
    if(n<=0 || n>=cap) return -1;
    memcpy(name,arg,(unsigned int)n); name[n]=0; *value=eq+1;
    return envdb_ValidName(name) ? 0 : -1;
}

static const char *smsh_env_canonical_name(const char *name)
{
    /* Match SQSH convenience semantics: only PATH is case-insensitive. */
    if(name!=NULL &&
       (name[0]=='p' || name[0]=='P') &&
       (name[1]=='a' || name[1]=='A') &&
       (name[2]=='t' || name[2]=='T') &&
       (name[3]=='h' || name[3]=='H') && name[4]==0)
        return "PATH";
    return name;
}

static int env_builtin_common(int argc,char **argv,int global)
{
    int i,count,rc;
    char name[256];
    const char *value,*entry;
    ENVDB *db;
    if(global) db=kenv; else db=ProcessEnvGetDB(GetCurrentThread(),1);
    if(db==NULL) { smsh_printf("%s: environment unavailable\n",global?"setglobal":"set"); return 1; }
    if(argc==1) {
        count=envdb_Count(db);
        for(i=0;i<count;i++) { entry=envdb_EntryAt(db,i); if(entry) smsh_printf("%s\n",entry); }
        return 0;
    }
    if(argc==3 && !strcmp(argv[1],"-u"))
        return global ? (kunsetglobalenv(smsh_env_canonical_name(argv[2]))<0) : (ProcessEnvUnset(GetCurrentThread(),smsh_env_canonical_name(argv[2]))<0);
    if(argc==2 && env_split_assignment(argv[1],name,sizeof(name),&value)==0) {
        rc=global ? ksetglobalenv(smsh_env_canonical_name(name),value,1) : ProcessEnvSet(GetCurrentThread(),smsh_env_canonical_name(name),value,1);
        return rc<0 ? 1 : 0;
    }
    if(argc==3 && envdb_ValidName(argv[1])) {
        rc=global ? ksetglobalenv(smsh_env_canonical_name(argv[1]),argv[2],1) : ProcessEnvSet(GetCurrentThread(),smsh_env_canonical_name(argv[1]),argv[2],1);
        return rc<0 ? 1 : 0;
    }
    smsh_printf("Usage: %s [NAME=VALUE | NAME VALUE | -u NAME]\n",global?"setglobal":"set");
    return 2;
}

static int set_builtin(int argc,char **argv) { return env_builtin_common(argc,argv,0); }
static int setglobal_builtin(int argc,char **argv) { return env_builtin_common(argc,argv,1); }

static int path_builtin(int argc,char **argv)
{
    char value[1024];
    if(argc==1) {
        if(ProcessEnvGet(GetCurrentThread(),"PATH",value,sizeof(value))<0) value[0]=0;
        smsh_printf("PATH=%s\n",value);
        return 0;
    }
    if(argc==2) return ProcessEnvSet(GetCurrentThread(),"PATH",argv[1],1)<0 ? 1 : 0;
    smsh_printf("Usage: path [VALUE]\n");
    return 2;
}

static int keymap_builtin(int argc, char **argv)
{
    if(argc==1 || (argc==2 && strcmp(argv[1],"status")==0))
    {
        int input=GetInputTerminal();
        int current=GetCurrentTerminal();
        printf("Keyboard layout: %s\n",KeyboardGetLayoutName());
        printf("PS/2 keyboard: init=%d scan=%d controller=%x IRQ1=%lu bytes=%lu poll=%lu rescue=%s pid=%d polls=%lu events=%lu\n",
               keyb_hwinit_status,keyb_scan_enable_status,
               (unsigned int)keyb_controller_byte,
               (unsigned long)keyb_irq_count,(unsigned long)keyb_byte_count,
               (unsigned long)keyb_poll_count,
               KeyboardRescueWorkerRunning()?"running":"stopped",keyb_rescue_worker_pid,
               (unsigned long)keyb_rescue_worker_polls,(unsigned long)keyb_rescue_worker_events);
        printf("Keyboard stream: backend=%s decoded=%lu queued=%lu dropped=%lu visible=%d input=%d thread=%d pid=%d owner=%d foreground=%d depth=%d\n",
               input_policy_backend_name(input_policy_keyboard_backend()),
               (unsigned long)keyb_decoded_count,
               (unsigned long)keyb_terminal_queued_count,
               (unsigned long)keyb_terminal_drop_count,
               GetVisibleTerminal(),input,current,GetCurrentThread(),
               GetTerminalOwner(input),GetTerminalForegroundProcess(input),
               TerminalKeyboardPending(input));
#if JTMOS_MOD_PCI
        printf("USB stream: reports=%lu events=%lu worker=%d pid=%d polls=%lu\n",
               (unsigned long)usb_input.keyboard_reports,
               (unsigned long)usb_input.keyboard_events,
               usb_input_worker_running(),usb_input.worker_pid,
               (unsigned long)usb_input.worker_polls);
        printf("SMSH keyboard rescue: worker=%s pid=%d polls=%lu events=%lu\n",
               KeyboardRescueWorkerRunning()?"running":"stopped",
               keyb_rescue_worker_pid,(unsigned long)keyb_rescue_worker_polls,
               (unsigned long)keyb_rescue_worker_events);
#endif
        printf("Usage: keymap [status|english|finnish]\n");
        return 0;
    }
    if(argc!=2 || KeyboardSetLayoutByName(argv[1])!=0)
    {
        printf("keymap: unknown layout '%s'\n",argc>1 ? argv[1] : "");
        printf("Available layouts: english (default), finnish\n");
        return 2;
    }
    printf("Keyboard layout: %s\n",KeyboardGetLayoutName());
    return 0;
}


static int usbinfo_builtin(int argc, char **argv JTM_UNUSED)
{
    if(argc!=1)
    {
        printf("Usage: usbinfo\n");
        return 2;
    }
#if JTMOS_MOD_PCI
    usb_input_dump();
    return 0;
#else
    printf("usbinfo: PCI/USB input scaffold disabled in this build.\n");
    return 1;
#endif
}

static int mouseinfo_builtin(int argc, char **argv)
{
    int rv=0;

    if(argc>2) {
        printf("Usage: mouseinfo [reinit]\n");
        return 2;
    }
    if(argc==2) {
        if(strcmp(argv[1],"reinit")!=0) {
            printf("Usage: mouseinfo [reinit]\n");
            return 2;
        }
        if(!PS2MOUSE_ENABLED) {
            printf("mouseinfo: PS/2 mouse is disabled in keropt.\n");
            return 1;
        }
        if(!ps2mouse_enabled)
            ps2mouse_init();
        else
            rv=ps2mouse_hardwareinit();
    }

    (void)mouse_poll();
    printf("PS/2 mouse: enabled=%d stream=%d x=%d y=%d buttons=%x IRQ12=%lu bytes=%lu packets=%lu\n",
           ps2mouse_enabled,ps2mouse_stream_status,mouse.x,mouse.y,mouse_getbuttons(),
           (unsigned long)ps2mouse_irq_count,(unsigned long)ps2mouse_byte_count,
           (unsigned long)ps2mouse_packet_count);
    printf("i8042 status=%x PIC master mask=%x slave mask=%x%s\n",
           (unsigned int)inportb(0x64),(unsigned int)inportb(0x21),
           (unsigned int)inportb(0xA1),rv ? " reinit FAILED" : "");
    return rv ? 1 : 0;
}

static int reboot_builtin(int argc, char **argv)
{
    (void)argc; (void)argv;
    printf("Rebooting JTMOS...\n");
    system_reset();
    return 0;
}

#define RAMEXTRACT_BUILTIN_MAX_BYTES JTMOS_BOOT_UTILS_RAM_BYTES

static int ramextract_builtin(int argc, char **argv)
{
    const char *outname="utils.iso";
    const void *image;
    DWORD size;
    FILE *out;
    size_t wrote;

    if(argc>2) {
        printf("Usage: ramextract [OUTPUT]\n");
        return 2;
    }
    if(argc==2) {
        if(!strcmp(argv[1],"-h") || !strcmp(argv[1],"--help")) {
            printf("Usage: ramextract [OUTPUT]\n");
            printf("Extract DOSBOOT-staged UTILS.ISO (max 32 MiB); default OUTPUT is utils.iso.\n");
            return 0;
        }
        outname=argv[1];
    }

    size=BootUtilsRamSize();
    image=BootUtilsRamData();
    if(size==0 || size>RAMEXTRACT_BUILTIN_MAX_BYTES || image==NULL) {
        printf("ramextract: no valid DOSBOOT UTILS.ISO RAM bank\n");
        return 1;
    }

    out=fopen(outname,"wb");
    if(out==NULL) {
        printf("ramextract: cannot create '%s'\n",outname);
        return 1;
    }

    /* One JTMFS write is intentional.  ram: uses 512-byte allocation units on
     * the 20 MiB rescue disk, so the historical 32 KiB loop caused every
     * write to walk an ever-longer FAT chain: ~143 writes and O(n^2) FAT work
     * for a 4.6 MiB utils.iso.  The staged image is already kernel-mapped, so
     * reserve the final chain once and stream it through WriteFileChainEx in a
     * single write() transaction. */
    printf("ramextract: writing %lu bytes to %s (bulk RAM->JTMFS)\n",
           (unsigned long)size,outname);
    wrote=fwrite(image,1U,(size_t)size,out);
    if(wrote!=(size_t)size) {
        printf("ramextract: write failed after %lu/%lu bytes\n",
               (unsigned long)wrote,(unsigned long)size);
        fclose(out);
        return 1;
    }
    if(fclose(out)!=0) {
        printf("ramextract: close failed for '%s'\n",outname);
        return 1;
    }
    printf("ramextract: done (%lu bytes)\n",(unsigned long)size);
    return 0;
}
#endif

#ifdef JTMOS
static int scheduler_builtin(int argc, char **argv)
{
    (void)argc; (void)argv;
    SchedulerDump();
    return 0;
}

static int perf_builtin(int argc, char **argv)
{
    JTMOS_CPU_STATS st;
    if(argc>2) {
        printf("Usage: perf [fast|slow|status]\n");
        return 2;
    }
    if(argc==2 && strcmp(argv[1],"status"))
    {
        if(!strcmp(argv[1],"fast"))
            SchedulerSetPerformanceMode(JTMOS_PERF_FAST);
        else if(!strcmp(argv[1],"slow"))
            SchedulerSetPerformanceMode(JTMOS_PERF_SLOW);
        else {
            printf("Usage: perf [fast|slow|status]\n");
            return 2;
        }
    }
    memset(&st,0,sizeof(st));
    (void)SchedulerGetCpuStats(&st,sizeof(st));
    printf("JTMOS performance mode: %s; scheduler=%lu Hz, idle=%lu.%lu%%, switches=%lu/s, HLT=%lu\n",
           SchedulerPerformanceModeName(),(unsigned long)st.hz,
           (unsigned long)(st.cpu_idle_per_mille/10U),
           (unsigned long)(st.cpu_idle_per_mille%10U),
           (unsigned long)st.context_switches_per_sec,
           (unsigned long)st.idle_halts);
    printf("FAST minimizes scheduling latency; SLOW is debug/low-noise. Both use STI;HLT when idle.\n");
    return 0;
}

#if JTMOS_MOD_NETWORK
static int uip_builtin(int argc, char **argv)
{
    JTMOS_THREAD_BUDGET_STATS bs;
    int pid=JtInternetStackPID();
    if(argc>2) {
        printf("Usage: uip [fast|slow|status]\n");
        return 2;
    }
    if(argc==2 && strcmp(argv[1],"status"))
    {
        if(!strcmp(argv[1],"fast"))
            JtUipSetPerformanceMode(JTMOS_UIP_PERF_FAST);
        else if(!strcmp(argv[1],"slow"))
            JtUipSetPerformanceMode(JTMOS_UIP_PERF_SLOW);
        else {
            printf("Usage: uip [fast|slow|status]\n");
            return 2;
        }
    }
    memset(&bs,0,sizeof(bs));
    (void)JtUipGetBudgetStats(&bs);
    printf("uIP mode: %s (default SLOW), pid=%d, CPU=%lu.%lu%%",
           JtUipPerformanceModeName(),pid,
           (unsigned long)(bs.cpu_per_mille/10U),
           (unsigned long)(bs.cpu_per_mille%10U));
    if(JtUipPerformanceMode()==JTMOS_UIP_PERF_SLOW)
        printf(", budget=%lu%%/%lu ms used=%lu/%lu ticks throttles=%lu%s\n",
               (unsigned long)bs.percent,(unsigned long)bs.window_ms,
               (unsigned long)bs.used_ticks,(unsigned long)bs.window_ticks,
               (unsigned long)bs.throttle_count,bs.throttled?" THROTTLED":"");
    else
        printf(", scheduler budget=off\n");
    printf("SLOW preserves the low-CPU polling profile; FAST reduces network poll latency.\n");
    return 0;
}
#endif

static int pit_builtin(int argc, char **argv)
{
    BYTE status=0;
    WORD irr,isr,mask;
    unsigned int count;

    if(argc>2 || (argc==2 && strcmp(argv[1],"status")))
    {
        printf("Usage: pit [status]\n");
        return 2;
    }

    mask=pic_get_mask();
    irr=pic_read_irr();
    isr=pic_read_isr();
    count=PitReadCounter(0);
    printf("Advanced PIT: %s, IRQ0=%u Hz, ch0 count=%u\n",
           PitAdvanced8254Active()?"8254 read-back / mode 2":"8253 latch fallback / mode 2",
           (unsigned)PitGetIrqHz(),count);
    printf("PIT IRQ0-driven uptime: %lu ms\n",(unsigned long)GetTickCount());
    printf("Scheduler clock: %u Hz via %s\n",
           (unsigned)SchedulerClockHz(),
           apic_rapid_scheduler_active()?"rapid LAPIC timer":"PIT IRQ0");
    if(PitReadStatus(0,&status))
        printf("PIT8254 ch0: status=0x%x OUT=%u NULL=%u RW=%u mode=%u BCD=%u\n",
               (unsigned)status,(unsigned)((status>>7)&1U),
               (unsigned)((status>>6)&1U),(unsigned)((status>>4)&3U),
               (unsigned)((status>>1)&7U),(unsigned)(status&1U));
    if(apic_active())
        printf("IRQ controller: %s mask=0x%x LAPIC-IRR=0x%x LAPIC-ISR=0x%x\n",
               apic_status(),(unsigned)mask,(unsigned)irr,(unsigned)isr);
    else
        printf("PIC8259: mask=0x%x IRR=0x%x ISR=0x%x spurious7=%lu spurious15=%lu\n",
               (unsigned)mask,(unsigned)irr,(unsigned)isr,
               (unsigned long)pic_get_spurious_count(7),
               (unsigned long)pic_get_spurious_count(15));
    return 0;
}


static int bootopts_builtin(int argc,char **argv)
{
    const char *shown;
    (void)argv;
    if(argc!=1)
    {
        printf("Usage: bootopts\n");
        return 2;
    }
    if(kernel_boot_options[0]) shown=kernel_boot_options;
    else if(BOOTOPT_NOAPIC && BOOTOPT_GUI_OFF) shown="safe (compiled default)";
    else if(BOOTOPT_NOAPIC) shown="noapic (compiled default)";
    else if(BOOTOPT_GUI_OFF) shown="nogui (compiled default)";
    else shown="<default>";
    printf("Boot options: %s\n",shown);
    printf("Compiled boot profile: VESA=%d SAFE=%d NOAPIC=%d NOGUI=%d\n",
           BOOT_PROFILE_VESA,BOOT_PROFILE_SAFE,BOOT_PROFILE_NOAPIC,BOOT_PROFILE_NOGUI);
    printf("IRQ request: APIC=%s LAPIC=%s ACPI-MADT=%s; active backend: %s (%s)\n",
           JTMOS_APIC_ENABLED?"on":"off",JTMOS_LAPIC_ENABLED?"on":"off",
           JTMOS_ACPI_ENABLED?"on":"off",apic_active()?"APIC":"8259 PIC",apic_status());
    printf("Boot policy: GUI=%s USB=%s debug=%s report=%s\n",
           GUI_ENABLED?"on":"off",USB_ENABLED?"on":"off",
           jtmos_debug?"on":"off",debug2?"on":"off");
    return 0;
}

static int apic_builtin(int argc,char **argv)
{
    JTMOS_APIC_INFO info;
    int i;
    DWORD low,high;
    if(argc>2 || (argc==2 && strcmp(argv[1],"status")))
    {
        printf("Usage: apic [status]\n");
        return 2;
    }
    apic_get_info(&info);
    printf("APIC: %s (%s)\n",info.active?"active":"inactive",apic_status());
    printf("LAPIC scheduler timer: %s, %u Hz (PIT timebase %u Hz)\n",
           apic_rapid_scheduler_active()?"active":"inactive",
           (unsigned)apic_rapid_scheduler_hz(),(unsigned)PitGetIrqHz());
    if(!info.madt_found)
        return info.active?0:1;
    printf("MADT=%x LAPIC=%x id=%u version=0x%x IOAPICs=%d\n",
           (unsigned)info.madt_phys,(unsigned)info.lapic_phys,
           (unsigned)info.lapic_id,(unsigned)info.lapic_version,
           info.ioapic_count);
    for(i=0;i<info.ioapic_count && i<JTMOS_APIC_MAX_IOAPICS;i++)
        printf("  IOAPIC%d phys=%x GSI=%lu..%lu inputs=%lu\n",i,
               (unsigned)info.ioapic_phys[i],
               (unsigned long)info.ioapic_gsi_base[i],
               (unsigned long)(info.ioapic_gsi_base[i]+info.ioapic_redir_count[i]-1U),
               (unsigned long)info.ioapic_redir_count[i]);
    printf("Legacy ISA routing:\n");
    for(i=0;i<JTMOS_APIC_LEGACY_IRQS;i++)
    {
        if(info.active && i==2)
        {
            printf("  IRQ2: 8259 cascade only; no I/O APIC route\n");
            continue;
        }
        low=high=0;
        if(apic_get_legacy_redir((unsigned short)i,&low,&high)==0)
            printf("  IRQ%u -> GSI %lu flags=0x%x redir=%08lx:%08lx%s\n",i,
                   (unsigned long)info.legacy_gsi[i],
                   (unsigned)info.legacy_flags[i],
                   (unsigned long)high,(unsigned long)low,
                   (info.legacy_gsi[i]!=(DWORD)i || info.legacy_flags[i])?" override":"");
        else
            printf("  IRQ%u -> GSI %lu flags=0x%x%s\n",i,
                   (unsigned long)info.legacy_gsi[i],
                   (unsigned)info.legacy_flags[i],
                   (info.legacy_gsi[i]!=(DWORD)i || info.legacy_flags[i])?" override":"");
    }
    return 0;
}
#endif

#if defined(JTMOS) && JTMOS_MOD_PCI
static int lspci_builtin(int argc, char **argv)
{
    int i,b,verbose;
    const PCIDEVICE *d;
    PCIBAR bar;
    verbose=0;
    if(argc>2 || (argc==2 && strcmp(argv[1],"-v"))) {
        printf("Usage: lspci [-v]\n");
        return 2;
    }
    if(argc==2) verbose=1;
    pci_init();
    if(!verbose) {
        pci_dump_devices();
        return 0;
    }
    printf("PCI: %d retained function(s)\n",pci_get_device_count());
    for(i=0; i<pci_get_device_count(); ++i) {
        d=pci_get_device(i);
        pci_print_device(d);
        for(b=0; b<PCI_MAX_BARS; ++b) {
            if(pci_get_bar(d,b,&bar)==0 && bar.valid) {
                if(bar.io)
                    printf("  BAR%d I/O  base=%x\n",b,bar.base_low);
                else if(bar.is64)
                    printf("  BAR%d MMIO64 base=%x:%x%s\n",b,bar.base_high,bar.base_low,
                           bar.prefetchable?" prefetch":"");
                else
                    printf("  BAR%d MMIO base=%x%s\n",b,bar.base_low,
                           bar.prefetchable?" prefetch":"");
                if(bar.is64) ++b;
            }
        }
        if(d->class_code==0x06 && d->subclass==0x04)
            printf("  bridge buses: primary=%d secondary=%d subordinate=%d\n",
                   d->primary_bus,d->secondary_bus,d->subordinate_bus);
        if(d->cap_ptr)
            printf("  caps: ptr=%x PM=%d MSI=%d MSI-X=%d PCIe=%d\n",
                   d->cap_ptr,d->has_pm,d->has_msi,d->has_msix,d->has_pcie);
    }
    return 0;
}
#endif

#ifdef JTMOS
static int unique_builtin(int argc, char **argv)
{
    char command[1024];
    char workdir[256];
    int used,i,pid;
    if(argc<2) {
        printf("Usage: unique FILE.uni [args ...]\n");
        printf("       uni FILE.uni [args ...]\n");
        return 2;
    }
    strcpy(command,"unique.bin"); used=(int)strlen(command);
    for(i=1;i<argc;i++) {
        size_t arglen=strlen(argv[i]);
        /* Kernel sh is linked without userspace formatted-stdio helpers. Append the
         * tokenized argv element directly and keep one byte for the NUL. */
        if((size_t)used + 1U + arglen >= sizeof(command)) {
            printf("unique: command line too long.\n"); return 2;
        }
        command[used++]=' ';
        memcpy(command+used,argv[i],arglen);
        used+=(int)arglen;
        command[used]=0;
    }
    workdir[0]=0; /* exact current DNR/DB inheritance */
    pid=centralprocess_exec("unique.bin",command,GetCurrentDNR(),GetCurrentDB(),workdir,GetCurrentTerminal());
    if(pid<=0) { printf("unique: cannot launch unique.bin from current device/CWD or PATH\n"); return 1; }
    return WaitProcessTerminationInterruptible(pid)?130:0;
}
#endif

static const SHELL_COMMAND shell_commands[] = {
    {"cd", chdir_app},
    {"chdir", chdir_app},
    {"ls", ls_app},
    {"dir", ls_app},
    {"find", find_app},
    {"lsdev", lsdev_app},
#if defined(JTMOS) && JTMOS_MOD_PCI
    {"lspci", lspci_builtin},
#endif
    {"mkfs", format_app},
    {"format", format_app},
    {"partition", partition_app},
    {"mount", mount_app},
    {"umount", umount_app},
    {"unmount", umount_app},
    {"root", root_app},
    {"rootinstall", rootinstall_app},
    {"bootroot", bootroot_app},
    {"sync", sync_app},
    {"hdatest", hdatest_app},
    {"fsgeom", fsgeom_app},
    {"smartdrv", smartdrv_app},
    {"condense", condense_app},
    {"fsck", fsck_app},
    {"jtmfsck", jtmfsck_app},
    {"diskspace", diskspace_app},
#ifdef JTMOS
    {"ai", ai_native_app},
    {"gfx", gfx_builtin},
    {"graos", graos_builtin},
    {"gui", graos_builtin},
    {"mkdir", mkdir_builtin},
    {"unique", unique_builtin},
    {"uni", unique_builtin},
    {"set", set_builtin},
    {"setglobal", setglobal_builtin},
    {"path", path_builtin},
    {"keymap", keymap_builtin},
    {"kbd", keymap_builtin},
    {"usbinfo", usbinfo_builtin},
    {"mouseinfo", mouseinfo_builtin},
    {"mouse", mouseinfo_builtin},
    {"reboot", reboot_builtin},
    {"reset", reboot_builtin},
    {"ramextract", ramextract_builtin},
#endif
    {"help", help_app},
    {"exit", exit_app},
    {"quit", exit_app},
    {"sqa", sqa_main},
    {"sqarc", sqarc_main},
    {"nzip", nzip_main},
#ifdef JTMOS
    {"kyber", kyber_app},
    {"sched", scheduler_builtin},
    {"perf", perf_builtin},
#if JTMOS_MOD_NETWORK
    {"uip", uip_builtin},
#endif
    {"pit", pit_builtin},
    {"apic", apic_builtin},
    {"bootopts", bootopts_builtin},
    {"locktop", locktop_app},
    {"nmi", nmi_app},
#endif
    {"copyall", copyall_main},
    {"rm_wildcard", rm_wildcard_main},
    {"rmwild", rm_wildcard_main},
    {"rmw", rm_wildcard_main},
    {"debug", DebugModeSwitchMain},
    {"debug1", DebugModeSwitchMain},
    {"report", ReportModeSwitchMain},
    {"debug2", ReportModeSwitchMain},
    {"d0", DebugReportOffMain},
    {"m", kmed_main},
    {"kmed", kmed_main},
    {"fm", file_memory_dump_main},
#ifdef JTMOS
    {"free", free_app},
#endif
    {"sound", sound_builtin},
#if JTMOS_MOD_NETWORK
    {"internet", internet_app},
    {"inet", internet_app},
    {"www", www_app},
    {"telnetd", telnetd_app},
    {"ping", ping_app},
    {"host", host_app},
    {"nutget", nutget_app},
    {"async", async_app},
#endif
    {NULL, NULL}
};

int sh_dprint(const char *fmt, ...)
{
    va_list args;

    if (!sh_debug || fmt == NULL) {
        return 0;
    }

    va_start(args, fmt);
    (void)vprintf(fmt, args);
    va_end(args);
    return 0;
}

char *splitter(char *split_what, char *with_what, int n_occurance)
{
    char *cursor;
    size_t separator_length;
    int found = 0;

    if (split_what == NULL || with_what == NULL || n_occurance <= 0) {
        return split_what;
    }

    separator_length = strlen(with_what);
    if (separator_length == 0U) {
        return split_what;
    }

    cursor = split_what;
    while (*cursor != '\0') {
        if (strncmp(cursor, with_what, separator_length) == 0) {
            ++found;
            cursor += separator_length;
            if (found == n_occurance) {
                return cursor;
            }
        } else {
            ++cursor;
        }
    }
    return cursor;
}

static int is_separator(char value, const char *separators)
{
    if (separators == NULL || separators[0] == '\0') {
        return value == ' ' || value == '\t';
    }
    return strchr(separators, value) != NULL;
}

static void free_argv(char **argv, int argc)
{
    int i;

    if (argv == NULL) {
        return;
    }
    for (i = 0; i < argc; ++i) {
        free(argv[i]);
    }
    free(argv);
}

/* Build a conventional argv array. Quoted strings and backslash escapes are
 * accepted, so e.g. postman exec "program name" remains one argument. */
char **argvbuilder(char *cmdstr, char *filterstring, int *pointer_to_argc)
{
    const char *cursor;
    char **argv;
    int argc = 0;

    if (pointer_to_argc != NULL) {
        *pointer_to_argc = 0;
    }
    if (cmdstr == NULL) {
        return NULL;
    }

    argv = (char **)calloc((size_t)SH_MAX_ARGS + 1U, sizeof(*argv));
    if (argv == NULL) {
        return NULL;
    }

    cursor = cmdstr;
    while (*cursor != '\0' && argc < SH_MAX_ARGS) {
        const char *start;
        char quote = '\0';
        char *argument;
        size_t capacity;
        size_t used = 0U;

        while (*cursor != '\0' && is_separator(*cursor, filterstring)) {
            ++cursor;
        }
        if (*cursor == '\0') {
            break;
        }

        start = cursor;
        capacity = strlen(start) + 1U;
        argument = (char *)malloc(capacity);
        if (argument == NULL) {
            free_argv(argv, argc);
            return NULL;
        }

        while (*cursor != '\0') {
            char value = *cursor;

            if (quote == '\0' && is_separator(value, filterstring)) {
                break;
            }
            if (value == '\\' && cursor[1] != '\0') {
                argument[used++] = cursor[1];
                cursor += 2;
                continue;
            }
            if (value == '\'' || value == '"') {
                if (quote == '\0') {
                    quote = value;
                    ++cursor;
                    continue;
                }
                if (quote == value) {
                    quote = '\0';
                    ++cursor;
                    continue;
                }
            }
            argument[used++] = value;
            ++cursor;
        }
        argument[used] = '\0';
        argv[argc++] = argument;

        while (*cursor != '\0' && is_separator(*cursor, filterstring)) {
            ++cursor;
        }
    }

    argv[argc] = NULL;
    if (pointer_to_argc != NULL) {
        *pointer_to_argc = argc;
    }
    return argv;
}

char **old_argvbuilder(char *cmdstr, char *filterstring, int *pointer_to_argc)
{
    return argvbuilder(cmdstr, filterstring, pointer_to_argc);
}

/* Legacy flat-buffer helper. The returned buffer is a copy of the command
 * line; pointer_to_argc receives the parsed argument count. */
char *b_argvbuilder(char *cmdstr, char *filterstring, char *pointer_to_argc)
{
    char **argv;
    char *copy;
    int argc = 0;

    if (cmdstr == NULL) {
        return NULL;
    }
    argv = argvbuilder(cmdstr, filterstring, &argc);
    if (argv == NULL) {
        return NULL;
    }
    copy = (char *)malloc(strlen(cmdstr) + 1U);
    if (copy != NULL) {
        strcpy(copy, cmdstr);
    }
    if (pointer_to_argc != NULL) {
        *pointer_to_argc = (char)((argc > 127) ? 127 : argc);
    }
    free_argv(argv, argc);
    return copy;
}

/* Legacy tokenizer for callers that supply an argv array. */
int getargumentlist(char *command_line, char **argv)
{
    static char storage[8192];
    char *token;
    int argc = 0;

    if (command_line == NULL || argv == NULL) {
        return 0;
    }
    strncpy(storage, command_line, sizeof(storage) - 1U);
    storage[sizeof(storage) - 1U] = '\0';

    token = strtok(storage, " \t");
    while (token != NULL && argc < SH_MAX_ARGS) {
        argv[argc++] = token;
        token = strtok(NULL, " \t");
    }
    argv[argc] = NULL;
    return argc;
}

static shell_command_fn find_builtin(const char *name)
{
    size_t i;

    if (name == NULL) {
        return NULL;
    }
    for (i = 0U; shell_commands[i].name != NULL; ++i) {
        if (strcmp(shell_commands[i].name, name) == 0) {
            return shell_commands[i].function;
        }
    }
    return NULL;
}


/* Native JTMOS has a terminal getch() primitive but no fgets()-based pipe
 * stream for interactive input. Keep fgets() only in the host test branch. */
#define SH_HISTORY_MAX 32
#define SH_ISEARCH_QUERY_MAX 256
#define SH_ISEARCH_MATCH_DISPLAY_MAX 96

static char *sh_history[SH_HISTORY_MAX];
static int sh_history_count=0;
static int sh_history_next=0;
static char sh_last_isearch[SH_ISEARCH_QUERY_MAX];

static void sh_history_add(const char *line)
{
    char *copy;
    size_t length;
    int newest;

    if(line==NULL || line[0]=='\0') return;
    if(sh_history_count>0) {
        newest=(sh_history_next+SH_HISTORY_MAX-1)%SH_HISTORY_MAX;
        if(sh_history[newest] && strcmp(sh_history[newest],line)==0) return;
    }
    length=strlen(line);
    copy=(char *)malloc(length+1U);
    if(copy==NULL) return;
    memcpy(copy,line,length+1U);
    if(sh_history[sh_history_next]) free(sh_history[sh_history_next]);
    sh_history[sh_history_next]=copy;
    sh_history_next=(sh_history_next+1)%SH_HISTORY_MAX;
    if(sh_history_count<SH_HISTORY_MAX) sh_history_count++;
}

static const char *sh_history_get(int offset)
{
    int index;
    if(offset<0 || offset>=sh_history_count) return NULL;
    index=sh_history_next-1-offset;
    while(index<0) index+=SH_HISTORY_MAX;
    return sh_history[index];
}

/* Bash/Readline-style reverse incremental history search.  Search is
 * case-sensitive and matches the query anywhere in the command line. */
static void sh_replace_edit_line(char *line, size_t capacity, size_t *used,
                                 const char *replacement);

static const char *sh_history_search(const char *needle, int start_offset,
                                     int *found_offset)
{
    int offset;
    const char *h;

    if(found_offset) *found_offset=-1;
    if(needle==NULL || needle[0]=='\0') return NULL;
    if(start_offset<0) start_offset=0;
    for(offset=start_offset;offset<sh_history_count;offset++) {
        h=sh_history_get(offset);
        if(h && strstr(h,needle)!=NULL) {
            if(found_offset) *found_offset=offset;
            return h;
        }
    }
    return NULL;
}

static void sh_isearch_clear_display(int *display_len)
{
    if(display_len==NULL) return;
    while(*display_len>0) {
        --(*display_len);
        putchar('\b'); putchar(' '); putchar('\b');
    }
}

static int sh_isearch_put_limited(const char *text, int limit)
{
    int count=0;
    if(text==NULL || limit<=0) return 0;
    while(*text && count<limit) {
        putchar((unsigned char)*text++);
        count++;
    }
    return count;
}

static void sh_isearch_show(const char *query, const char *match, int failed,
                            int *display_len)
{
    const char *prefix;
    int n=0,available,query_show,query_length;

    sh_isearch_clear_display(display_len);
    /* putch1() cannot backspace across a wrapped row.  Leave the last
     * column unused, so every status character can be erased in place. */
    available=(int)(screens[MYTER].window.x2-screens[MYTER].window.x1+1)
              -wherex();
    if(available<=0) return;
    prefix=failed ? "(failed reverse-i-search)`" : "(reverse-i-search)`";
    n+=sh_isearch_put_limited(prefix,available);
    if(n+3<=available) {
        query_length=query ? (int)strlen(query) : 0;
        query_show=available-n-3;
        if(match && query_show>24) query_show=24;
        if(query_show>query_length) query_show=query_length;
        if(query_length>query_show && query_show>3) {
            n+=sh_isearch_put_limited("...",3);
            query_show-=3;
        }
        if(query_show>0)
            n+=sh_isearch_put_limited(query+query_length-query_show,query_show);
        putchar('\''); putchar(':'); putchar(' '); n+=3;
        if(match)
            n+=sh_isearch_put_limited(match,
                 available-n<SH_ISEARCH_MATCH_DISPLAY_MAX ? available-n :
                 SH_ISEARCH_MATCH_DISPLAY_MAX);
    }
    if(display_len) *display_len=n;
}

static void sh_isearch_remember(const char *query)
{
    if(query==NULL || query[0]=='\0') return;
    strncpy(sh_last_isearch,query,sizeof(sh_last_isearch)-1U);
    sh_last_isearch[sizeof(sh_last_isearch)-1U]='\0';
}

/* Return values:
 *   0  search ended; continue editing selected/original line
 *   1  Enter accepted a matching history line
 *  -3  Ctrl+C interrupted the whole SMSH input line
 */
static int sh_reverse_isearch(char *line, size_t capacity, size_t *used)
{
    char query[SH_ISEARCH_QUERY_MAX];
    char *original;
    const char *match=NULL;
    int query_len=0;
    int match_offset=-1;
    int display_len=0;
    int search_exhausted=0;
    int key,start;

    if(line==NULL || used==NULL || capacity<2U) return 0;
    original=(char *)malloc(*used+1U);
    if(original==NULL) return 0;
    memcpy(original,line,*used+1U);
    query[0]='\0';

    sh_replace_edit_line(line,capacity,used,"");
    sh_isearch_show(query,NULL,0,&display_len);

    for(;;) {
        key=getch();

        if(key==3 || ConsumeTerminalInterrupt(GetCurrentTerminal())) {
            sh_isearch_clear_display(&display_len);
            line[0]='\0';
            *used=0U;
            printf("^C\n");
            free(original);
            return -3;
        }

        if(key==18) { /* Ctrl+R: next older match; reuse remembered query. */
            if(query_len>0 && search_exhausted) {
                continue;
            }
            if(query_len==0 && sh_last_isearch[0]) {
                strncpy(query,sh_last_isearch,sizeof(query)-1U);
                query[sizeof(query)-1U]='\0';
                query_len=(int)strlen(query);
                start=0;
            } else if(query_len==0) {
                continue;
            } else {
                start=(match_offset>=0) ? match_offset+1 : 0;
            }
            match=sh_history_search(query,start,&match_offset);
            search_exhausted=(match==NULL);
            sh_isearch_show(query,match,query_len>0 && match==NULL,&display_len);
            continue;
        }

        if(key=='\b' || key==127) {
            if(query_len>0) {
                query[--query_len]='\0';
                search_exhausted=0;
                if(query_len>0)
                    match=sh_history_search(query,0,&match_offset);
                else {
                    match=NULL;
                    match_offset=-1;
                }
                sh_isearch_show(query,match,query_len>0 && match==NULL,&display_len);
            }
            continue;
        }

        if(key==7) { /* Ctrl+G: abort and restore the original draft. */
            sh_isearch_clear_display(&display_len);
            sh_replace_edit_line(line,capacity,used,original);
            free(original);
            return 0;
        }

        if(key=='\r' || key=='\n') {
            if(match==NULL) {
                continue;
            }
            sh_isearch_remember(query);
            sh_isearch_clear_display(&display_len);
            sh_replace_edit_line(line,capacity,used,match);
            putchar('\n');
            sh_history_add(line);
            free(original);
            return 1;
        }

        if(key==27) { /* Esc keeps the match editable without executing it. */
            const char *selected=match ? match : original;
            sh_isearch_remember(query);
            sh_isearch_clear_display(&display_len);
            sh_replace_edit_line(line,capacity,used,selected);
            free(original);
            return 0;
        }

        if(key>=32 && key<=255) {
            if(query_len+1<(int)sizeof(query)) {
                query[query_len++]=(char)key;
                query[query_len]='\0';
                search_exhausted=0;
                start=(match_offset>=0) ? match_offset : 0;
                match=sh_history_search(query,start,&match_offset);
                sh_isearch_show(query,match,match==NULL,&display_len);
            }
            continue;
        }

        {
            const char *selected=match ? match : original;
            sh_isearch_remember(query);
            sh_isearch_clear_display(&display_len);
            sh_replace_edit_line(line,capacity,used,selected);
            free(original);
            return 0;
        }
    }
}

static void sh_replace_edit_line(char *line, size_t capacity, size_t *used,
                                 const char *replacement)
{
    size_t i,length;
    if(line==NULL || used==NULL || replacement==NULL || capacity<2U) return;
    while(*used>0U) {
        --(*used);
        putchar('\b'); putchar(' '); putchar('\b');
    }
    length=strlen(replacement);
    if(length>=capacity) length=capacity-1U;
    memcpy(line,replacement,length);
    line[length]='\0';
    for(i=0U;i<length;i++) putchar((unsigned char)line[i]);
    *used=length;
}

#ifdef JTMOS
static int sh_key_up(int key)
{
    return key==0xFF48 || key==0x4800;
}

static int sh_key_down(int key)
{
    return key==0xFF50 || key==0x5000;
}

/* Complete the token at the end of the line against the JTMFS directory that
 * contains it.  resolveFileNamePath() resolves only the parent, so an
 * incomplete final component such as "inst" is valid input. */
static int sh_complete_file(char *line, size_t capacity, size_t *used)
{
    size_t token_start,typed_name_len,token_len,head_len,best_len,i;
    char *token;
    char best[34];
    int dnr,db,matches=0,best_is_dir=0;
    RESOLVE resolved;
    DIRWALK *walk;
    JTMFS_FILE_ENTRY *entry;

    if(line==NULL || used==NULL || *used==0U) return 0;
    token_start=*used;
    while(token_start>0U && line[token_start-1U]!=' ' && line[token_start-1U]!='\t')
        token_start--;
    token=&line[token_start];
    if(token[0]=='\0') return 0;

    memset(&resolved,0,sizeof(resolved));
    dnr=GetCurrentDNR();
    db=GetCurrentDB();
    if(resolveFileNamePath(token,&dnr,&db,&resolved)!=JTMFS_PATH_OK) return 0;
    typed_name_len=strlen(resolved.name);
    token_len=strlen(token);
    if(typed_name_len==0U || typed_name_len>token_len) return 0;
    head_len=token_len-typed_name_len;

    walk=(DIRWALK *)malloc(sizeof(DIRWALK));
    if(walk==NULL) return 0;
    memset(walk,0,sizeof(*walk));
    if(jtmfs_ffirst(dnr,db,walk)) {
        free(walk);
        return 0;
    }
    best[0]='\0';
    best_len=0U;
    for(;;) {
        entry=walk->fe;
        if(entry && entry->length!=-1 && entry->name[0] &&
           strncmp(entry->name,resolved.name,typed_name_len)==0) {
            if(matches==0) {
                strncpy(best,entry->name,sizeof(best)-1U);
                best[sizeof(best)-1U]='\0';
                best_len=strlen(best);
                best_is_dir=JTMFS_TYPE_IS_DIRECTORY(entry->type) ? 1 : 0;
            } else {
                size_t n=strlen(entry->name);
                if(n<best_len) best_len=n;
                for(i=0U;i<best_len;i++)
                    if(best[i]!=entry->name[i]) break;
                best_len=i;
                best[best_len]='\0';
                best_is_dir=0;
            }
            matches++;
        }
        if(jtmfs_fnext(dnr,walk)) break;
    }
    jtmfs_fend(walk);
    free(walk);
    if(matches==0 || best_len<=typed_name_len) return matches;

    if(token_start+head_len+best_len+2U>capacity) return matches;
    for(i=typed_name_len;i<best_len;i++) {
        line[(*used)++]=best[i];
        putchar((unsigned char)best[i]);
    }
    line[*used]='\0';
    if(matches==1 && best_is_dir && *used+1U<capacity) {
        line[(*used)++]='/';
        line[*used]='\0';
        putchar('/');
    }
    return matches;
}
#endif

/* Native JTMOS has a terminal getch() primitive but no fgets()-based pipe
 * stream for interactive input. Keep fgets() only in the host test branch. */
static int sh_readline(char *line, size_t capacity)
{
#ifdef JTMOS
    size_t used = 0U;
    int overflow = 0;
    int history_offset=-1;
    char *draft=NULL;

    if(line == NULL || capacity < 2U) return -1;
    line[0] = '\0';

    for(;;) {
        int key = getch();

        if(key == 3) {
            printf("^C\n");
            line[0]='\0';
            if(draft) free(draft);
            return -3;
        }

        if(ConsumeTerminalInterrupt(GetCurrentTerminal())) {
            printf("^C\n");
            line[0]='\0';
            if(draft) free(draft);
            return -3;
        }
        if(key == '\r' || key == '\n') {
            putchar('\n');
            if(!overflow) sh_history_add(line);
            if(draft) free(draft);
            break;
        }
        if(key == 4) {
            if(used == 0U) {
                if(draft) free(draft);
                return -1;
            }
            if(!overflow) sh_history_add(line);
            if(draft) free(draft);
            break;
        }
        if(key==18) {
            int search_result;
            if(history_offset>=0) history_offset=-1;
            if(draft) { free(draft); draft=NULL; }
            search_result=sh_reverse_isearch(line,capacity,&used);
            overflow=0;
            if(search_result==1) return (int)used;
            if(search_result==-3) return -3;
            continue;
        }
        if(sh_key_up(key)) {
            const char *h;
            if(sh_history_count==0) continue;
            if(history_offset<0) {
                if(used>0U) {
                    draft=(char *)malloc(used+1U);
                    if(draft==NULL) continue;
                    memcpy(draft,line,used+1U);
                }
                history_offset=0;
            } else if(history_offset+1<sh_history_count) {
                history_offset++;
            }
            h=sh_history_get(history_offset);
            if(h) sh_replace_edit_line(line,capacity,&used,h);
            overflow=0;
            continue;
        }
        if(sh_key_down(key)) {
            const char *h;
            if(history_offset<0) continue;
            if(history_offset>0) {
                history_offset--;
                h=sh_history_get(history_offset);
                if(h) sh_replace_edit_line(line,capacity,&used,h);
            } else {
                history_offset=-1;
                sh_replace_edit_line(line,capacity,&used,draft ? draft : "");
                if(draft) { free(draft); draft=NULL; }
            }
            overflow=0;
            continue;
        }
        if(key == '\t') {
            if(history_offset>=0) {
                history_offset=-1;
                if(draft) { free(draft); draft=NULL; }
            }
            (void)sh_complete_file(line,capacity,&used);
            overflow=0;
            continue;
        }
        if(key == '\b' || key == 127) {
            if(history_offset>=0) {
                history_offset=-1;
                if(draft) { free(draft); draft=NULL; }
            }
            if(used > 0U) {
                --used;
                line[used] = '\0';
                putchar('\b'); putchar(' '); putchar('\b');
                overflow=0;
            }
            continue;
        }
        if(key == 27 || key < 32 || key > 255) continue;

        if(history_offset>=0) {
            history_offset=-1;
            if(draft) { free(draft); draft=NULL; }
        }
        if(used + 1U < capacity) {
            line[used++] = (char)key;
            line[used] = '\0';
            putchar(key);
        } else {
            overflow = 1;
        }
    }

    if(overflow) {
        printf("sh: command line too long (maximum %u characters)\\n",
               (unsigned)(capacity - 1U));
        line[0] = '\0';
        return -2;
    }
    return (int)used;
#else
    size_t length;
    if(line == NULL || capacity < 2U) return -1;
    if(fgets(line, (int)capacity, stdin) == NULL) return -1;
    length = strlen(line);
    if(length > 0U && line[length-1U] != '\n' && !feof(stdin)) {
        int ch;
        while((ch = getchar()) != '\n' && ch != EOF) { }
        line[0] = '\0';
        return -2;
    }
    while(length > 0U && (line[length-1U] == '\n' || line[length-1U] == '\r'))
        line[--length] = '\0';
    sh_history_add(line);
    return (int)length;
#endif
}

/* The compact rescue environment can run without net.bin.  Keep the
 * historical TCP connection test external, but route the status/restart
 * forms to the network owner that is already built into SMSH. */
static int smsh_net_lifecycle(int argc, char **argv)
{
#if JTMOS_MOD_NETWORK
    if(argc>0 && argv!=NULL && argv[0]!=NULL && !strcmp(argv[0],"net") &&
       (argc==1 || (argc==2 && argv[1]!=NULL &&
        (!strcmp(argv[1],"status") || !strcmp(argv[1],"restart") ||
         !strcmp(argv[1],"reset")))))
        return internet_app(argc,argv);
#else
    (void)argc;
    (void)argv;
#endif
    return SH_NOT_HANDLED;
}

static int try_optional_dispatch(const char *command, int argc, char **argv)
{
    int net_rc;
    (void)command;
    net_rc=smsh_net_lifecycle(argc,argv);
    if(net_rc!=SH_NOT_HANDLED) return net_rc;
#if defined(__GNUC__)
    if (graos_shell_try_command != NULL) {
        return graos_shell_try_command(command, argc, argv);
    }
#else
    (void)command;
    (void)argc;
    (void)argv;
#endif
    return SH_NOT_HANDLED;
}

#ifdef JTMOS
/*
 * Native SMSH external-program path.
 *
 *   install
 *   ls /ram
 *   :/bin/test.bin arg1 arg2
 *
 * V68.188 routes BOTH ordinary unknown commands and explicit ':' commands
 * directly through Central Process.  SMSH is a ring-0 kernel shell, so using
 * libc/kernel system()->cexec()->scall() here needlessly re-enters the syscall
 * path from kernel context.  That made command launch sensitive to syscall/TSS
 * state and could turn a harmless command into a #GP.  ':' remains only a
 * syntax override that bypasses builtin lookup; it is stripped here.
 */
static int smsh_launch_external(const char *line)
{
    char command[256];
    char executable[256];
    char workdir[256];
    const char *src;
    size_t len;
    size_t i;
    int pid;
    int background = 0;

    if(line == NULL)
        return -1;

    src = line;
    if(*src == ':')
        ++src;
    while(*src == ' ' || *src == '\t')
        ++src;

    if(*src == '\0') {
        printf("SMSH: external program name is required.\n");
        return -1;
    }

    len = strlen(src);
    if(len >= sizeof(command)) {
        printf("SMSH: external command is too long (max %u bytes).\n",
               (unsigned)(sizeof(command) - 1U));
        return -1;
    }

    strcpy(command, src);

    /* A trailing ampersand is SMSH background syntax for external programs.
     * Remove it from argv before LaunchApp and, after a successful
     * launch, do not wait for process termination. */
    while(len>0U && (command[len-1U]==' ' || command[len-1U]=='\t'))
        command[--len]='\0';
    if(len>0U && command[len-1U]=='&')
    {
        background=1;
        command[--len]='\0';
        while(len>0U && (command[len-1U]==' ' || command[len-1U]=='\t'))
            command[--len]='\0';
    }
    if(len==0U)
    {
        printf("SMSH: background marker requires an external program.\n");
        return -1;
    }

    /* centralprocess_exec() wants argv[0]/filename separately from the full
     * command line.  Keep quoting/arguments intact in command[]. */
    for(i = 0U; i < sizeof(executable) - 1U && command[i] != '\0'; ++i) {
        if(command[i] == ' ' || command[i] == '\t')
            break;
        executable[i] = command[i];
    }
    executable[i] = '\0';

    if(executable[0] == '\0') {
        printf("SMSH: invalid external program name.\n");
        return -1;
    }

    /* GraOS is a resident compositor/server, not a normal foreground utility.
     * A direct `graos.bin` command used to enter the generic foreground path
     * below and then wait forever for the GUI server to terminate.  Worse, that
     * bypassed the kernel GraOS launcher which gives the server its private
     * keyboard terminal and THREAD_TYPE_SERVICE capability.  Treat any
     * device/path-qualified graos.bin basename as the `graos` builtin. */
    {
        const char *base=executable;
        const char *q=executable;
        while(*q) {
            if(*q=='/' || *q==':') base=q+1;
            q++;
        }
        if(!strcmp(base,"graos.bin")) {
#if defined(__GNUC__)
            if(graos_shell_try_command != NULL) {
                char *gargv[2];
                gargv[0]=(char *)"graos";
                gargv[1]=NULL;
                printf("SMSH: routing '%s' through the GraOS service launcher.\n", executable);
                return graos_shell_try_command("graos",1,gargv);
            }
#endif
            printf("SMSH: GraOS service launcher is unavailable.\n");
            return -1;
        }
    }

    /* SMSH must enter a blocking Central Process launch with interrupts
     * enabled.  A buggy builtin/driver must not poison the next command by
     * returning with IF clear.  Also normalize DF because C string/memory code
     * assumes the System V/JTMOS ABI direction flag is clear. */
    __asm__ __volatile__("cld" : : : "cc");
    if(!(get_eflags() & 0x200UL)) {
        dprintk("SMSH: external dispatch repaired IF=0 before '%s'.\n", executable);
        enable();
    }

    /* Empty workDir means exact caller DNR/DB inheritance; do not stringify
     * cwd and resolve it back through another process. */
    workdir[0] = '\0';
    ReportMessage("SMSH LaunchApp: '%s' (cwd=DNR/DB %d/%d)\n",
                  command,GetCurrentDNR(),GetCurrentDB());
    pid = centralprocess_exec(executable, command,
                              GetCurrentDNR(), GetCurrentDB(),
                              workdir, GetCurrentTerminal());
    if(pid <= 0) {
        ReportMessage("SMSH LaunchApp: unable to load/execute '%s'.\n",executable);
        return -1;
    }

    if(background)
    {
        ReportMessage("SMSH LaunchApp: PID %d started in background.\n",pid);
        return 0;
    }

    ReportMessage("SMSH LaunchApp: PID %d started; waiting for termination.\n",pid);
    if(WaitProcessTerminationInterruptible(pid))
        ReportMessage("SMSH LaunchApp: PID %d interrupted.\n",pid);
    else
        ReportMessage("SMSH LaunchApp: PID %d terminated.\n",pid);
    return 0;
}
#endif


#ifdef JTMOS
static char *sh_trim(char *s)
{
    char *e;
    while(*s==' ' || *s=='\t') s++;
    e=s+strlen(s);
    while(e>s && (e[-1]==' ' || e[-1]=='\t')) *--e='\0';
    return s;
}

/* Split only unquoted, unescaped pipe characters.  This deliberately leaves
 * argv quoting to argvbuilder/LaunchApp so arguments such as "a|b" survive. */
static int sh_split_pipeline(char *line, char **stage, int maxstage)
{
    char quote=0;
    int escape=0,n=1,i;
    char *p;
    if(!line || !stage || maxstage<1) return -1;
    stage[0]=line;
    for(p=line; *p; ++p)
    {
        if(escape) { escape=0; continue; }
        if(*p=='\\') { escape=1; continue; }
        if(quote) { if(*p==quote) quote=0; continue; }
        if(*p=='\'' || *p=='"') { quote=*p; continue; }
        if(*p=='|')
        {
            if(n>=maxstage) return -2;
            *p='\0';
            stage[n++]=p+1;
        }
    }
    if(n==1) return 0;
    for(i=0;i<n;i++)
    {
        stage[i]=sh_trim(stage[i]);
        if(!*stage[i]) return -1;
    }
    return n;
}

static int smsh_pipeline_builtin_bridgeable(const char *name)
{
    static const char *names[]={"internet","inet","www","telnetd","ping","host","nutget","async",
                                "perf","uip","ai","set","setglobal","path","find",NULL};
    int i;
    if(!name) return 0;
    for(i=0;names[i];i++) if(!strcmp(name,names[i])) return 1;
    return 0;
}

static int sh_resolve_pipeline_exe(const char *exe,char *envpath,char *found,int foundcap)
{
    char withbin[256];
    if(!exe || !found || foundcap<2) return 0;
    found[0]='\0';
    if(strchr(exe,'/') || strchr(exe,'\\') || strchr(exe,':')) {
        if(strlen(exe)>=foundcap) return 0;
        strcpy(found,exe);
        return 1;
    }
    if(envpath && envpath[0] && SearchThroughPath(envpath,exe,found)) return 1;
    /* The normal JTMOS loader appends .bin automatically.  SMSH's historical
     * pipeline pre-resolver bypassed that step, so `cat | more` searched for a
     * literal file called `more`.  Mirror normal loader semantics here. */
    if(strchr(exe,'.')==NULL && strlen(exe)+4U<sizeof(withbin)) {
        strcpy(withbin,exe); strcat(withbin,".bin");
        if(envpath && envpath[0] && SearchThroughPath(envpath,withbin,found)) return 1;
    }
    return 0;
}

/* V68.171: native SMSH builtin pipeline workers.
 *
 * A kernel builtin must not depend on sqsh.bin merely to gain a process-local
 * stdout route.  Each bridgeable builtin now runs in a short-lived kernel task
 * whose stdio is attached directly to the pipe endpoint.  The worker enters
 * the existing smsh_bridge so stream-aware builtins use KernelFileBufWrite()
 * on fd 1.  This keeps `inet status | more` functional even on the rescue RAM
 * filesystem before sqsh.bin has been installed. */
#define SMSH_PIPE_WORKER_SLOTS SH_MAX_PIPE_STAGES

typedef struct SMSH_PIPE_WORKER {
    volatile int used;
    volatile int ready;
    volatile int pid;
    THREAD thread;
    char command[1024];
} SMSH_PIPE_WORKER;

static SMSH_PIPE_WORKER smsh_pipe_workers[SMSH_PIPE_WORKER_SLOTS];

static SMSH_PIPE_WORKER *smsh_pipe_worker_for_pid(int pid)
{
    int i;
    for(i=0;i<SMSH_PIPE_WORKER_SLOTS;i++)
        if(smsh_pipe_workers[i].used && smsh_pipe_workers[i].pid==pid)
            return &smsh_pipe_workers[i];
    return NULL;
}

static SMSH_PIPE_WORKER *smsh_pipe_worker_for_stack(DWORD esp)
{
    int i;
    DWORD lo,hi;
    for(i=0;i<SMSH_PIPE_WORKER_SLOTS;i++)
    {
        if(!smsh_pipe_workers[i].used || smsh_pipe_workers[i].thread.stack==NULL)
            continue;
        lo=(DWORD)smsh_pipe_workers[i].thread.stack;
        hi=lo+(DWORD)smsh_pipe_workers[i].thread.l_stack;
        if(esp>=lo && esp<hi) return &smsh_pipe_workers[i];
    }
    return NULL;
}

static void smsh_pipeline_worker_main(void)
{
    SMSH_PIPE_WORKER *w=NULL;
    shell_command_fn command;
    char line[1024];
    char **argv=NULL;
    int argc=0,rc=1,pid=GetCurrentThread();
    DWORD flags,esp;

    /* create_thread() may schedule this worker before the creator publishes
     * its PID.  Match by the private stack range rather than by "first -1";
     * this remains correct when two shells launch builtin pipeline stages at
     * the same time. */
    __asm__ __volatile__("movl %%esp,%0" : "=r"(esp));
    flags=get_eflags(); disable();
    w=smsh_pipe_worker_for_pid(pid);
    if(w==NULL)
    {
        w=smsh_pipe_worker_for_stack(esp);
        if(w!=NULL && w->pid==-1) w->pid=pid;
    }
    set_eflags(flags);
    if(w==NULL) ExitThread(127);

    while(!w->ready) SchedulerWaitPause(1000UL);
    strncpy(line,w->command,sizeof(line)-1U); line[sizeof(line)-1U]=0;
    argv=argvbuilder(line," \t",&argc);
    if(argv!=NULL && argc>0)
    {
        command=find_builtin(argv[0]);
        if(command!=NULL && smsh_pipeline_builtin_bridgeable(argv[0]))
        {
            smsh_bridge_enter();
            rc=command(argc,argv);
            smsh_bridge_leave();
            (void)KernelFileBufFlush(pid,1);
        }
        else rc=127;
    }
    if(argv!=NULL) free_argv(argv,argc);

    flags=get_eflags(); disable();
    w->ready=0; w->used=0; w->pid=0;
    set_eflags(flags);
    ExitThread(rc);
}

static int sh_launch_builtin_pipe_worker(const char *command,int stdin_fd,int stdout_fd,int *pid_out)
{
    SMSH_PIPE_WORKER *w=NULL;
    int i,pid,parent,terminal,setup;
    DWORD flags;

    if(command==NULL || pid_out==NULL || strlen(command)>=(int)sizeof(smsh_pipe_workers[0].command))
        return -1;
    parent=GetCurrentThread(); terminal=GetCurrentTerminal();

    flags=get_eflags(); disable();
    for(i=0;i<SMSH_PIPE_WORKER_SLOTS;i++)
        if(!smsh_pipe_workers[i].used)
        {
            w=&smsh_pipe_workers[i];
            memset((void *)w,0,sizeof(*w));
            w->used=1; w->pid=-1;
            strcpy(w->command,command);
            break;
        }
    set_eflags(flags);
    if(w==NULL) { *pid_out=0; return -1; }

    if(ThreadCreateStack(&w->thread,JTMOS_MIN_DYNAMIC_STACK)!=0)
    {
        flags=get_eflags(); disable(); w->used=0; w->pid=0; set_eflags(flags);
        *pid_out=0; return -1;
    }

    /* Do not wrap create_thread()/environment inheritance in CLI.  The worker
     * startup barrier above makes publication race-safe without a long IF=0
     * critical section. */
    pid=(int)create_thread(w->thread.stack,w->thread.l_stack,smsh_pipeline_worker_main);
    if(pid<=0)
    {
        ThreadDestroyStack(&w->thread);
        flags=get_eflags(); disable(); w->used=0; w->pid=0; set_eflags(flags);
        *pid_out=0; return -1;
    }

    flags=get_eflags(); disable();
    if(w->pid==-1) w->pid=pid;
    setup=(w->pid==pid)?0:-1;
    set_eflags(flags);
    if(setup==0)
        setup=LinuxProcessExecSetup(pid,parent,stdin_fd,stdout_fd,-1);
    if(setup==0)
    {
        SetThreadTerminal(pid,terminal);
        SetThreadCmdLine(pid,w->command);
        IdentifyThread(pid,"smsh-pipe");
        flags=get_eflags(); disable(); w->ready=1; set_eflags(flags);
        *pid_out=pid;
        return 0;
    }

    KillThreadEx(pid,KT_NO_THREAD_SWITCH);
    flags=get_eflags(); disable(); w->ready=0; w->used=0; w->pid=0; set_eflags(flags);
    *pid_out=0;
    return -1;
}

/* V69.18: dangerous in-kernel builtins must never execute on the long-lived
 * SMSH thread.  A fault or hard loop there otherwise takes the user's only
 * rescue shell with it, and the NMI watchdog correctly refuses to kill that
 * essential kernel thread.  Run these commands in an expendable Ring0 worker
 * and explicitly mark only that worker as fail-stop NMI eligible. */
#define SMSH_GUARDED_WORKER_SLOTS 4

typedef struct SMSH_GUARDED_WORKER {
    volatile int used;
    volatile int ready;
    volatile int pid;
    THREAD thread;
    char command[1024];
} SMSH_GUARDED_WORKER;

static SMSH_GUARDED_WORKER smsh_guarded_workers[SMSH_GUARDED_WORKER_SLOTS];

static int smsh_builtin_needs_guard(const char *name)
{
    /* Start with nzip, the demonstrated whole-kernel failure.  Add another
     * builtin only after its teardown/locking behavior has been audited. */
    return name!=NULL && !strcmp(name,"nzip");
}

static SMSH_GUARDED_WORKER *smsh_guarded_worker_for_pid(int pid)
{
    int i;
    for(i=0;i<SMSH_GUARDED_WORKER_SLOTS;i++)
        if(smsh_guarded_workers[i].used && smsh_guarded_workers[i].pid==pid)
            return &smsh_guarded_workers[i];
    return NULL;
}

static SMSH_GUARDED_WORKER *smsh_guarded_worker_for_stack(DWORD esp)
{
    int i; DWORD lo,hi;
    for(i=0;i<SMSH_GUARDED_WORKER_SLOTS;i++)
    {
        if(!smsh_guarded_workers[i].used || smsh_guarded_workers[i].thread.stack==NULL)
            continue;
        lo=(DWORD)smsh_guarded_workers[i].thread.stack;
        hi=lo+(DWORD)smsh_guarded_workers[i].thread.l_stack;
        if(esp>=lo && esp<hi) return &smsh_guarded_workers[i];
    }
    return NULL;
}

static void smsh_guarded_worker_main(void)
{
    SMSH_GUARDED_WORKER *w=NULL;
    shell_command_fn command;
    char line[1024];
    char **argv=NULL;
    int argc=0,rc=127,pid=GetCurrentThread();
    DWORD flags,esp;

    __asm__ __volatile__("movl %%esp,%0" : "=r"(esp));
    flags=get_eflags(); disable();
    w=smsh_guarded_worker_for_pid(pid);
    if(w==NULL)
    {
        w=smsh_guarded_worker_for_stack(esp);
        if(w!=NULL && w->pid==-1) w->pid=pid;
    }
    set_eflags(flags);
    if(w==NULL) ExitThread(127);

    while(!w->ready) SchedulerWaitPause(1000UL);
    strncpy(line,w->command,sizeof(line)-1U); line[sizeof(line)-1U]=0;
    argv=argvbuilder(line," \t",&argc);
    if(argv!=NULL && argc>0 && smsh_builtin_needs_guard(argv[0]))
    {
        command=find_builtin(argv[0]);
        if(command!=NULL) rc=command(argc,argv);
    }
    if(argv!=NULL) free_argv(argv,argc);
    ExitThread(rc);
}

static int smsh_run_guarded_builtin(const char *command_text)
{
    SMSH_GUARDED_WORKER *w=NULL;
    int i,pid,parent,terminal,setup,interrupted;
    DWORD flags;

    if(command_text==NULL || (size_t)strlen(command_text)>=sizeof(smsh_guarded_workers[0].command))
        return 2;
    parent=GetCurrentThread(); terminal=GetCurrentTerminal();

    flags=get_eflags(); disable();
    for(i=0;i<SMSH_GUARDED_WORKER_SLOTS;i++)
        if(!smsh_guarded_workers[i].used)
        {
            w=&smsh_guarded_workers[i];
            memset((void *)w,0,sizeof(*w));
            w->used=1; w->pid=-1;
            strcpy(w->command,command_text);
            break;
        }
    set_eflags(flags);
    if(w==NULL) { printf("sh: no guarded-worker slots available\n"); return 1; }

    if(ThreadCreateStack(&w->thread,JTMOS_MIN_DYNAMIC_STACK)!=0)
    {
        flags=get_eflags(); disable(); w->used=0; w->pid=0; set_eflags(flags);
        printf("sh: unable to allocate guarded worker stack\n");
        return 1;
    }
    pid=(int)create_thread(w->thread.stack,w->thread.l_stack,smsh_guarded_worker_main);
    if(pid<=0)
    {
        ThreadDestroyStack(&w->thread);
        flags=get_eflags(); disable(); w->used=0; w->pid=0; set_eflags(flags);
        printf("sh: unable to create guarded worker\n");
        return 1;
    }

    flags=get_eflags(); disable();
    if(w->pid==-1) w->pid=pid;
    setup=(w->pid==pid)?0:-1;
    set_eflags(flags);
    if(setup==0) setup=LinuxProcessExecSetup(pid,parent,-1,-1,-1);
    if(setup==0) setup=CopyThreadCWDContext(pid,parent);
    if(setup==0)
    {
        SetThreadTerminal(pid,terminal);
        SetThreadCmdLine(pid,w->command);
        IdentifyThread(pid,"smsh-guarded");
        if(!NmiWatchdogSetThreadAutokill(pid,1)) setup=-1;
    }
    if(setup!=0)
    {
        KillThreadEx(pid,KT_NO_THREAD_SWITCH);
        ThreadDestroyStack(&w->thread);
        flags=get_eflags(); disable(); w->ready=0; w->used=0; w->pid=0; set_eflags(flags);
        printf("sh: guarded worker setup failed\n");
        return 1;
    }

    flags=get_eflags(); disable(); w->ready=1; set_eflags(flags);
    interrupted=WaitProcessTerminationInterruptible(pid);

    /* Whether the worker exited normally, fault containment killed it, or NMI
     * armed a TF kill trap, SMSH owns and reclaims this private stack/slot. */
    if(valid_pid(pid)) (void)NmiWatchdogSetThreadAutokill(pid,0);
    ThreadDestroyStack(&w->thread);
    flags=get_eflags(); disable(); w->ready=0; w->used=0; w->pid=0; set_eflags(flags);
    return interrupted?130:0;
}

static int sh_pipeline_launch_one(const char *stage, int stdin_fd, int stdout_fd, int *pid_out)
{
    char command[1024],exe[256],savedcwd[JTMFS_PATH_MAX],envpath[512],found[512];
    const char *src;
    size_t i;
    int pid=0;

    if(!stage || !pid_out) return -1;
    src=stage;
    while(*src==' ' || *src=='\t') src++;
    if(*src==':') { src++; while(*src==' ' || *src=='\t') src++; }
    if(!*src || strlen(src)>=(int)sizeof(command)) return -1;
    strcpy(command,src);

    for(i=0;i<sizeof(exe)-1 && command[i] && command[i]!=' ' && command[i]!='\t';i++)
        exe[i]=command[i];
    exe[i]='\0';
    if(!exe[0]) return -1;
    if(getcwd(savedcwd,sizeof(savedcwd)-1U)==NULL) strcpy(savedcwd,"ram:/");
    savedcwd[sizeof(savedcwd)-1U]='\0';
    if(ProcessEnvGet(GetCurrentThread(),"PATH",envpath,sizeof(envpath))<0 || !envpath[0])
    {
        if(kgetglobalenv("PATH",envpath,sizeof(envpath))<0)
            envpath[0]='\0';
    }

    /* Bridgeable builtins execute in a native kernel worker with the pipe
     * endpoints attached directly.  No sqsh.bin bootstrap dependency. */
    if(find_builtin(exe)!=NULL && smsh_pipeline_builtin_bridgeable(exe)) {
        int wrv=sh_launch_builtin_pipe_worker(command,stdin_fd,stdout_fd,&pid);
        (void)chdir(savedcwd);
        *pid_out=pid;
        return wrv;
    }

    if(!sh_resolve_pipeline_exe(exe,envpath,found,sizeof(found))) {
        (void)chdir(savedcwd);
        *pid_out=0;
        return -1;
    }

    pid=centralprocess_exec_stdio(found,command,GetCurrentDNR(),GetCurrentDB(),
            "",GetCurrentTerminal(),stdin_fd,stdout_fd,-1);
    (void)chdir(savedcwd);
    *pid_out=pid;
    return pid>0 ? 0 : -1;
}

static int sh_run_pipeline_to(char *line,int final_stdout_fd)
{
    char *stage[SH_MAX_PIPE_STAGES];
    int pipes[SH_MAX_PIPE_STAGES-1][2];
    int pids[SH_MAX_PIPE_STAGES];
    int n,i,j,rc=0,created=0;

    n=sh_split_pipeline(line,stage,SH_MAX_PIPE_STAGES);
    if(n==0) return SH_NOT_HANDLED;
    if(n<0)
    {
        printf("sh: invalid pipeline (maximum %d stages)\n",SH_MAX_PIPE_STAGES);
        return 2;
    }
    memset(pipes,-1,sizeof(pipes));
    memset(pids,0,sizeof(pids));
    for(i=0;i<n-1;i++)
    {
        if(LinuxPipeCreate(pipes[i])!=0)
        {
            printf("sh: pipe: unable to allocate pipe %d\n",i+1);
            rc=1; goto cleanup;
        }
    }

    for(i=0;i<n;i++)
    {
        int in_fd=(i==0)?-1:pipes[i-1][0];
        int out_fd=(i==n-1)?final_stdout_fd:pipes[i][1];
        if(sh_pipeline_launch_one(stage[i],in_fd,out_fd,&pids[i])!=0)
        {
            printf("sh: pipeline: unable to launch stage %d: %s\n",i+1,stage[i]);
            rc=1; goto cleanup;
        }
        created++;
    }

cleanup:
    /* Parent must close every endpoint after children have inherited their
     * selected ends.  Otherwise readers would never observe EOF. */
    for(i=0;i<n-1;i++)
        for(j=0;j<2;j++) if(pipes[i][j]>=3) { (void)close(pipes[i][j]); pipes[i][j]=-1; }

    for(i=0;i<created;i++)
    {
        if(pids[i]>0 && WaitProcessTerminationInterruptible(pids[i]))
        {
            int k;
            rc=130;
            for(k=i+1;k<created;k++) if(pids[k]>0) KillThread(pids[k]);
            break;
        }
    }
    return rc;
}

static int sh_run_pipeline(char *line)
{
    return sh_run_pipeline_to(line,-1);
}

/* Parse one unquoted stdout redirection.  The operator is shell syntax, not an
 * argv token, so both `find>hello.txt` and `find > hello.txt` work.  Filenames
 * containing whitespace must be quoted.  `>>` appends; `>` truncates. */
static int sh_parse_output_redirect(char *line,char *target,int targetcap,int *append)
{
    char quote=0,*p,*rhs,*end;
    int escape=0,oplen=0;
    if(!line || !target || targetcap<2 || !append) return -1;
    target[0]=0; *append=0;
    for(p=line;*p;p++)
    {
        if(escape) { escape=0; continue; }
        if(*p=='\\') { escape=1; continue; }
        if(quote) { if(*p==quote) quote=0; continue; }
        if(*p=='\'' || *p=='"') { quote=*p; continue; }
        if(*p=='>') { oplen=(p[1]=='>')?2:1; break; }
    }
    if(!oplen) return 0;
    *append=(oplen==2);
    *p=0; rhs=p+oplen;
    if(!*sh_trim(line)) return -1;
    rhs=sh_trim(rhs);
    if(!*rhs) return -1;

    /* No second redirection/operator is accepted yet. */
    quote=0; escape=0;
    for(p=rhs;*p;p++)
    {
        if(escape) { escape=0; continue; }
        if(*p=='\\') { escape=1; continue; }
        if(quote) { if(*p==quote) quote=0; continue; }
        if(*p=='\'' || *p=='"') { quote=*p; continue; }
        if(*p=='>') return -1;
    }
    if(quote) return -1;

    end=rhs+strlen(rhs);
    if((rhs[0]=='\'' || rhs[0]=='"') && end>rhs+1 && end[-1]==rhs[0])
    {
        rhs++; end-=1; *end=0;
    }
    else
    {
        for(p=rhs;*p;p++) if(*p==' ' || *p=='\t') return -1;
    }
    if(!*rhs || strlen(rhs)>=targetcap) return -1;
    strcpy(target,rhs);
    return 1;
}

static int sh_run_output_redirect(char *line)
{
    char target[JTMFS_PATH_MAX];
    int append=0,parsed,fd,pid=0,rc,pipeline_rc;
    parsed=sh_parse_output_redirect(line,target,sizeof(target),&append);
    if(parsed==0) return SH_NOT_HANDLED;
    if(parsed<0) { printf("sh: invalid output redirection\n"); return 2; }

    fd=open(target,O_WRONLY|O_CREAT|(append?O_APPEND:O_TRUNC));
    if(fd<0) { printf("sh: cannot open redirect target '%s'\n",target); return 1; }

    pipeline_rc=sh_run_pipeline_to(line,fd);
    if(pipeline_rc!=SH_NOT_HANDLED)
    {
        (void)close(fd);
        return pipeline_rc;
    }

    if(sh_pipeline_launch_one(line,-1,fd,&pid)!=0 || pid<=0)
    {
        (void)close(fd);
        printf("sh: output redirection cannot launch: %s\n",line);
        return 1;
    }
    (void)close(fd);
    rc=WaitProcessTerminationInterruptible(pid)?130:0;
    return rc;
}
#endif

#ifdef JTMOS
/* Execute one non-interactive SMSH command through the same builtin/GraOS/
 * external dispatch order as the interactive shell.  Autostart deliberately
 * does not invent private filesystem shortcuts: the bootstrap path therefore
 * exercises the exact same command implementations a user would type. */
/* Restricted userspace bridge for SQSH.  This intentionally exposes only
 * established SMSH builtins whose semantics are useful for system
 * administration.  It never falls through to system()/external execution. */
static int smsh_userspace_builtin_allowed(const char *name)
{
    static const char *allowed[]={
        /* Ring3 SQSH bridge: user/session operations only.  Administrative
         * root/mount/reset/raw-disk controls remain available from trusted
         * kernel SMSH but are intentionally not callable through INT 0x7F. */
        "cd","chdir","mkdir","sync",
        "fsgeom","smartdrv","condense","fsck","diskspace","ai","keymap","kbd","usbinfo","mouseinfo","mouse",
        "sched","perf","uip","kyber","debug","debug1","report","debug2","d0","sound","free","lspci",
        "gfx","graos","gui","ping","internet","inet","net","www","telnetd","host","nutget",
        "copyall","sqa","sqarc","nzip",NULL
    };
    int i;
    if(name==NULL || !name[0]) return 0;
    for(i=0; allowed[i]!=NULL; ++i)
        if(strcmp(name,allowed[i])==0) return 1;
    return 0;
}

int smsh_execute_builtin_text(const char *text)
{
    char line[1024];
    char **argv;
    int argc=0,rc;
    shell_command_fn command;

    if(text==NULL || text[0]=='\0' || strlen(text)>=(int)sizeof(line)) return 2;
    strcpy(line,text);
    argv=argvbuilder(line," \t",&argc);
    if(argv==NULL || argc==0) {
        if(argv!=NULL) free_argv(argv,argc);
        return 2;
    }
    if(!smsh_userspace_builtin_allowed(argv[0])) {
        free_argv(argv,argc);
        return -3;
    }
    command=find_builtin(argv[0]);
    if(command==NULL) {
        if(!strcmp(argv[0],"net")) {
            smsh_bridge_enter();
            rc=smsh_net_lifecycle(argc,argv);
            smsh_bridge_leave();
            free_argv(argv,argc);
            return rc==SH_NOT_HANDLED ? -3 : rc;
        }
        free_argv(argv,argc);
        return -2;
    }

    if(smsh_builtin_needs_guard(argv[0])) {
        free_argv(argv,argc);
        return smsh_run_guarded_builtin(text);
    }

    /* Builtins own any command-specific foreground-job semantics.  In
     * particular ping_app() now marks/restores itself so SMSH and SQSH behave
     * identically. */
    smsh_bridge_enter();
    rc=command(argc,argv);
    smsh_bridge_leave();
    free_argv(argv,argc);
    return rc;
}

static int smsh_execute_command_text(const char *text)
{
    char line[1024];
    char **argv;
    int argc=0;
    int rc;
    shell_command_fn command;

    if(text==NULL || text[0]=='\0' || strlen(text)>=(int)sizeof(line))
        return 2;
    strcpy(line,text);

    argv=argvbuilder(line," \t",&argc);
    if(argv==NULL || argc==0) {
        if(argv!=NULL) free_argv(argv,argc);
        return 2;
    }

    command=find_builtin(argv[0]);
    if(command!=NULL) {
        if(smsh_builtin_needs_guard(argv[0])) {
            free_argv(argv,argc);
            return smsh_run_guarded_builtin(text);
        }
        rc=command(argc,argv);
        free_argv(argv,argc);
        return rc;
    }

    rc=try_optional_dispatch(argv[0],argc,argv);
    if(rc!=SH_NOT_HANDLED) {
        free_argv(argv,argc);
        return rc;
    }

    free_argv(argv,argc);
    /* Kernel SMSH must not re-enter SYS_cexec via system().  Use the same
     * direct launch path as an interactive external command. */
    rc=smsh_launch_external(text);
    return rc==0 ? 0 : 1;
}


static int smsh_vt_launcher_pid=-1;
static int smsh_vt_missing_reported=0;
static int smsh_vt_busy_reported=0;

static int smsh_pid_is_alive(int pid)
{
    if(pid<=0 || pid>=N_MAX_THREADS) return 0;
    if(!valid_pid(pid)) return 0;
    return thread_states[pid] ? 1 : 0;
}

static int smsh_find_vt_launcher_executable(char *found,int foundcap)
{
    char candidate[256];
    char devname[32];
    char path[512];
    int fd,sz;

    if(found==NULL || foundcap<2) return 0;
    found[0]='\0';

    /* Prefer the exact caller cwd first, matching Central Process semantics. */
    fd=open("vt2.bin",O_RDONLY);
    if(fd>=0) {
        sz=lseek(fd,0,SEEK_END);
        close(fd);
        if(sz>0) { strncpy(found,"vt2.bin",foundcap-1); found[foundcap-1]='\0'; return 1; }
    }

    /* Then keep lookup on the active device's /bin, as V69.56 exec does. */
    devname[0]='\0';
    if(getdevicename(GetCurrentDNR(),devname)!=NULL && devname[0] &&
       strlen(devname)+20U<sizeof(candidate)) {
        sprintf(candidate,"%s:/bin/vt2.bin",devname);
        fd=open(candidate,O_RDONLY);
        if(fd>=0) {
            sz=lseek(fd,0,SEEK_END);
            close(fd);
            if(sz>0) { strncpy(found,candidate,foundcap-1); found[foundcap-1]='\0'; return 1; }
        }
    }

    /* Finally use the shell/global PATH. */
    path[0]='\0';
    if(ProcessEnvGet(GetCurrentThread(),"PATH",path,sizeof(path))<0 || !path[0])
        (void)kgetglobalenv("PATH",path,sizeof(path));
    if(path[0] && SearchThroughPath(path,"vt2.bin",found)) return 1;
    return 0;
}

/* V70: the persistent shell launcher is a recovery service on VT4.  The
 * historical payload filename remains vt2.bin for image compatibility, but
 * VT1 (status), VT2 (boot log) and VT3 (primary SMSH) now have fixed roles.
 * Safe-console boots may use the launcher too; it is recovery infrastructure,
 * not GraOS/full-autostart policy. */
static int smsh_ensure_vt_launcher(int verbose)
{
    const int launcher_terminal=JTMOS_VT_LAUNCHER;
    char executable[256];
    int owner,pid;

    if(!VT2_BOOT_LAUNCHER_ENABLED) return 0;

    /* A previous kernel command may have left DF set; normalize before path
     * probing because the resolver uses ordinary C string/memory routines. */
    __asm__ __volatile__("cld" : : : "cc");

    if(smsh_vt_launcher_pid>0 && smsh_pid_is_alive(smsh_vt_launcher_pid) &&
       GetTerminalOwner(launcher_terminal)==smsh_vt_launcher_pid)
        return 1;
    smsh_vt_launcher_pid=-1;

    owner=GetTerminalOwner(launcher_terminal);
    if(owner>0) {
        if(smsh_pid_is_alive(owner)) {
            if(verbose && !smsh_vt_busy_reported) {
                ReportMessage("SMSH VT4 launcher: VT4 already owned by PID %d; not replacing it.\n",owner);
                smsh_vt_busy_reported=1;
            }
            return 0;
        }
        (void)SetTerminalOwner(launcher_terminal,0);
    }
    smsh_vt_busy_reported=0;

    if(!smsh_find_vt_launcher_executable(executable,sizeof(executable))) {
        if(verbose && !smsh_vt_missing_reported) {
            ReportMessage("SMSH VT4 launcher: vt2.bin not available yet; startup deferred until it is installed.\n");
            smsh_vt_missing_reported=1;
        }
        return 0;
    }

    /* centralprocess_exec() is blocking while it publishes the new process;
     * never enter it carrying IF=0/DF=1 from an earlier kernel command. */
    __asm__ __volatile__("cld" : : : "cc");
    if(!(get_eflags() & 0x200UL)) enable();

    if(verbose) ReportMessage("SMSH VT4 launcher: starting %s on VT4.\n",executable);
    pid=centralprocess_exec(executable,executable,GetCurrentDNR(),GetCurrentDB(),"",launcher_terminal);
    if(pid<=0) {
        if(verbose) ReportMessage("SMSH VT4 launcher: launch failed; will retry at a later shell safe-point.\n");
        return 0;
    }

    (void)SetTerminalOwner(launcher_terminal,pid);
    smsh_vt_launcher_pid=pid;
    smsh_vt_missing_reported=0;
    ReportMessage("SMSH VT4 launcher: PID %d ready on VT4; use Alt+F4 or Alt+4.\n",pid);
    return 1;
}

static int smsh_autostart_after_root(void)
{
    static const char *root_steps[]={
        "cd ram:",
        "mkdir bin",
        "cd bin",
        NULL
    };
    int i,rc,graos_rc=0;
    int package_media=0;
    const char *media_command;

    printf("SMSH autostart: utilities bootstrap enabled; GraOS starts after extraction when graphics is available.\n");
    for(i=0;root_steps[i]!=NULL;i++) {
        printf("autostart> %s\n",root_steps[i]);
        rc=smsh_execute_command_text(root_steps[i]);

        /* mkdir is intentionally idempotent.  An existing ram:/bin is not an
         * autostart failure; the following cd bin is the authoritative test. */
        if(i==1 && rc!=0) {
            printf("SMSH autostart: mkdir bin returned %d; continuing in case it already exists.\n",rc);
            continue;
        }
        if(rc!=0) {
            printf("SMSH autostart: stopped at '%s' (status %d); maintenance prompt remains available.\n",
                   root_steps[i],rc);
            return rc;
        }
    }

    /* V69.25: DOSBOOT and native/QEMU media boots are different transports.
     * ramextract is valid only when DOSBOOT handed UTILS.ISO to the protected
     * kernel in the persistent RAM bank.  Native boot32/QEMU normally has no
     * such handoff, but sys: already aliases the validated B:/ATAPI SQARC
     * medium.  The old unconditional ramextract therefore stopped an otherwise
     * healthy boot at ram:/bin# even though cdrom:/sys: were present. */
    if(BootUtilsRamSize()!=0U) {
        printf("SMSH autostart: DOSBOOT UTILS.ISO RAM bank detected; staging utils.iso.\n");
        printf("autostart> ramextract utils.iso\n");
        rc=smsh_execute_command_text("ramextract utils.iso");
        if(rc!=0) {
            printf("SMSH autostart: stopped at 'ramextract utils.iso' (status %d); maintenance prompt remains available.\n",rc);
            return rc;
        }
        media_command="sqa utils.iso";
        package_media=1;
    } else if(driver_getdevicebyname("sys")!=NULL) {
        printf("SMSH autostart: no DOSBOOT RAM handoff; extracting directly from sys: bootstrap media.\n");
        media_command="sqa sys";
    } else if(driver_getdevicebyname("cdrom")!=NULL) {
        /* Defensive fallback for old images which have ATAPI but no sys alias. */
        printf("SMSH autostart: no DOSBOOT RAM handoff/sys: alias; trying cdrom directly.\n");
        media_command="sqa cdrom";
        package_media=1;
    } else {
        printf("SMSH autostart: no utilities bootstrap medium (DOSBOOT RAM, sys:, or cdrom); maintenance prompt remains available.\n");
        return 3;
    }

    printf("autostart> %s\n",media_command);
    rc=smsh_execute_command_text(media_command);
    if(rc!=0) {
        printf("SMSH autostart: stopped at '%s' (status %d); maintenance prompt remains available.\n",
               media_command,rc);
        return rc;
    }

    /* V70.29: utilities.iso has a package-only outer surface.  Install the
     * normal command environment and GraOS explicitly after extracting the
     * outer archive.  sys:/B: remains the compact legacy rescue bootstrap and
     * therefore does not use this nested package step. */
    if(package_media) {
        printf("autostart> sqa core.sqa\n");
        rc=smsh_execute_command_text("sqa core.sqa");
        if(rc!=0) {
            printf("SMSH autostart: core.sqa extraction failed (status %d).\n",rc);
            return rc;
        }
        printf("autostart> sqa graos.sqa\n");
        rc=smsh_execute_command_text("sqa graos.sqa");
        if(rc!=0) {
            printf("SMSH autostart: graos.sqa extraction failed (status %d).\n",rc);
            return rc;
        }
    }

    /* V68.226: sqa itself reclaims staged utils.iso (when present) before its
     * built-in NZIP + nested SQA phase, so no separate unz step is needed.
     * V70: VT4 launcher is independent from autostart, but this is the first
     * guaranteed point after automatic extraction where vt2.bin is present. */
    (void)smsh_ensure_vt_launcher(1);

#if JTMOS_MOD_GRAOS_BOOT
    /* START_GRAOS=0 deliberately keeps storage extraction out of KernelInit,
     * but normal graphical boot still promises a desktop.  Launch it now,
     * after SQA has populated ram:/bin.  The service launcher waits for the
     * first complete frame and rolls back to this SMSH terminal on failure. */
    if(GraOSBootReady()) {
        printf("autostart> graos\n");
        graos_rc=smsh_execute_command_text("graos");
        if(graos_rc!=0)
            printf("SMSH autostart: GraOS startup failed (status %d); maintenance prompt remains available.\n",
                   graos_rc);
        else
            printf("SMSH autostart: GraOS desktop is ready.\n");
    } else {
        printf("SMSH autostart: no GraOS graphics provider; continuing with the maintenance console.\n");
    }
#else
    printf("SMSH autostart: GraOS module disabled; continuing with the maintenance console.\n");
#endif
#if JTMOS_MOD_NETWORK
    /* V68.200: storage/bootstrap has reached its success boundary.  Only now
     * may the background polling network owner start.  This keeps uIP/nForce
     * completely out of install.img.nz extraction and JTMFS bootstrap I/O. */
    if(JtInternetState()==JTMOS_INET_OFFLINE) {
        int netrv=JtInternetStart(SLIP_COM_PORT_N,DefaultSlipBPS);
        if(netrv<0)
            printf("SMSH autostart: post-bootstrap network start failed (%d); use 'internet start' manually.\n",netrv);
        else
            printf("SMSH autostart: storage/bootstrap complete; Ethernet/uIP start requested.\n");
    }
#endif
    return graos_rc;
}
#endif

static int smsh_enter_interactive_terminal(void)
{
    int pid=GetCurrentThread();
    int owner=GetTerminalOwner(JTMOS_VT_SMSH);

    if(owner>0 && owner!=pid && smsh_pid_is_alive(owner)) {
        ReportMessage("SMSH: VT3 is already owned by live PID %d; remaining on VT2.\n",owner);
        return -1;
    }
    if(owner>0 && owner!=pid)
        (void)SetTerminalOwner(JTMOS_VT_SMSH,0);

    if(GetTerminalOwner(JTMOS_VT_BOOTLOG)==pid)
        (void)SetTerminalOwner(JTMOS_VT_BOOTLOG,0);
    SetThreadTerminal(pid,JTMOS_VT_SMSH);
    (void)SetTerminalOwner(JTMOS_VT_SMSH,pid);

    textbackground(BLACK);
    textcolor(LIGHTGRAY);
    clrscr();
    (void)SwitchUserTerminal(JTMOS_VT_SMSH);
    return 0;
}

static void smsh_print_banner(void)
{
    const char *version=JTMOS_SOURCE_RELEASE;
    if(version[0]=='V' || version[0]=='v') version++;
    printf("SMSH/JTMOS System Maintenance Shell v%s\n",version);
    printf("Type 'help' for commands.  VT4 provides the recovery shell launcher.\n\n");
}

int run_shell(void)
{
    char *line;
    int first_prompt=1;

#ifdef JTMOS
    /* SMSH is a long-lived process-context task and must never enter its
     * interactive/bootstrap loop with IF clear.  V68.151 exposed a launch
     * path that could propagate IF=0 across a cooperative yield. */
    if(!(get_eflags() & 0x200UL)) {
        DebugSerialEmergencyWrite("SMSH: IF was clear on shell entry; enabling interrupts.\n");
        enable();
    }
#endif

    line = (char *)malloc(SH_MAX_LINE);
    if (line == NULL) {
        fprintf(stderr, "sh: unable to allocate command buffer\n");
        return 1;
    }

#ifdef JTMOS
    if(boot_ctrl_smsh_override)
        printf("SMSH safe boot: Ctrl held during boot; automatic commands and GraOS are disabled.\n");
    else if(!autostart)
        printf("SMSH bootstrap: automatic ramextract/SQA startup disabled; run bootstrap commands manually.\n");

    /* V68.203+: keep normal debug/report/serial output enabled through the
     * complete automatic storage/bootstrap path.  In particular, do not run
     * d0 before SQA's built-in NZIP/image extraction: a hang while extracting
     * install.img.nz must remain
     * visible on the ordinary serial log.  d0 remains available manually. */
    ReportMessage("SMSH source release: %s (%s).\n",
                  JTMOS_SOURCE_RELEASE,JTMOS_SOURCE_RELEASE_NOTE);

    if(smsh_boot_root_policy()!=0)
        printf("SMSH boot: root filesystem is not available; maintenance shell continues.\n");

    /* Start the persistent VT4 recovery shell launcher without re-enabling the full
     * utilities/GraOS autostart.  If the compact payload is not installed yet,
     * the prompt loop below retries after manual bootstrap commands. */
    (void)smsh_ensure_vt_launcher(1);
#endif

#ifdef JTMOS
    /* This line is intentionally printed before interactive input.  If a
     * keyboard regression prevents typing, the screen still tells us whether
     * CPU IRQs and PIC IRQ1 were enabled when SMSH took control. */
    {
        DWORD irq1low=0,irq1high=0;
        DWORD usb_kbd_reports=0,usb_kbd_events=0;
        int have_irq1_redir=apic_get_legacy_redir(1,&irq1low,&irq1high)==0;
#if JTMOS_MOD_PCI
        usb_kbd_reports=usb_input.keyboard_reports;
        usb_kbd_events=usb_input.keyboard_events;
#endif
        ReportMessage("SMSH keyboard bootdiag: IF=%d status64=%x PICmask=%x init=%d scan=%d cb=%x IRQ1=%lu bytes=%lu poll=%lu USBreports=%lu USBevents=%lu USBworker=%d pid=%d wpolls=%lu\n",
               (get_eflags() & 0x200UL) ? 1 : 0,
               (unsigned int)inportb(0x64),(unsigned int)inportb(0x21),
               keyb_hwinit_status,keyb_scan_enable_status,
               (unsigned int)keyb_controller_byte,
               (unsigned long)keyb_irq_count,(unsigned long)keyb_byte_count,
               (unsigned long)keyb_poll_count,
               (unsigned long)usb_kbd_reports,
               (unsigned long)usb_kbd_events,
               usb_input_worker_running(),usb_input.worker_pid,
               (unsigned long)usb_input.worker_polls);
        ReportMessage("SMSH keyboard route: backend=%s visible=%d input=%d shell_terminal=%d shell_pid=%d owner=%d pending=%d decoded=%lu routed=%lu dropped=%lu\n",
               input_policy_backend_name(input_policy_keyboard_backend()),
               GetVisibleTerminal(),GetInputTerminal(),GetCurrentTerminal(),
               GetCurrentThread(),GetTerminalOwner(GetCurrentTerminal()),
               TerminalKeyboardPending(GetCurrentTerminal()),
               (unsigned long)keyb_decoded_count,
               (unsigned long)keyb_terminal_queued_count,
               (unsigned long)keyb_terminal_drop_count);
        if(have_irq1_redir)
            ReportMessage("SMSH keyboard APICdiag: IRQ1 redir=%08lx:%08lx vector=0x%x masked=%d IRR=%d ISR=%d\n",
                   (unsigned long)irq1high,(unsigned long)irq1low,
                   (unsigned)(irq1low&0xffU),(irq1low&(1UL<<16))?1:0,
                   apic_irq_pending(1),apic_irq_in_service(1));
    }
    if(autostart && !boot_ctrl_smsh_override) {
#if JTMOS_MOD_GRAOS_BOOT
        if(START_GRAOS && GraOSBootStarted())
            printf("SMSH autostart: GraOS already started by kernel; legacy GUI bootstrap skipped.\n");
        else
#endif
            (void)smsh_autostart_after_root();
    }

    /* Everything above is startup/bootstrap output and therefore remains on
     * VT2.  Only now publish the clean interactive SMSH on VT3. */
    if(smsh_enter_interactive_terminal()==0)
        smsh_print_banner();
#endif

    for (;;) {
        char **argv;
        int argc = 0;
        int dispatch_result;
        shell_command_fn command;

#ifdef JTMOS
        /* If the launcher payload became available after a manual bootstrap command, start
         * the persistent launcher now.  This is intentionally silent while
         * the file is still absent. */
        (void)smsh_ensure_vt_launcher(0);

        /* Every prompt is a kernel-shell safe point.  Commands are allowed to
         * mask IRQs temporarily, but SMSH itself must never carry IF=0 or DF=1
         * into parsing, allocation, Central Process waits or the scheduler. */
        __asm__ __volatile__("cld" : : : "cc");
        if(!(get_eflags() & 0x200UL)) {
            dprintk("SMSH: repaired IF=0 at command safe point.\n");
            enable();
        }
        if(first_prompt) {
            int terminal=GetCurrentTerminal();
            int visible=GetVisibleTerminal();
            int before=GetInputTerminal();
            int discarded;

            /* Kernel boot/storage work can leave complete physical keys in
             * the SMSH terminal FIFO before any prompt is ready.  They must
             * not silently become the first shell command.  Never take
             * keyboard focus away from GraOS or a different visible VT. */
            if(visible==terminal && before>=0 && before<10 &&
               before!=terminal)
                (void)SetInputTerminal(terminal);
            discarded=TerminalKeyboardDiscardPending(terminal);
            ReportMessage("SMSH keyboard prompt: visible=%d input=%d thread_terminal=%d pid=%d owner=%d discarded_boot_keys=%d decoded=%lu routed=%lu dropped=%lu\n",
                   GetVisibleTerminal(),GetInputTerminal(),terminal,
                   GetCurrentThread(),GetTerminalOwner(terminal),discarded,
                   (unsigned long)keyb_decoded_count,
                   (unsigned long)keyb_terminal_queued_count,
                   (unsigned long)keyb_terminal_drop_count);
            first_prompt=0;
        }
        {
            char cwd[JTMFS_PATH_MAX];
            char prompt = (getringlevel() == 0) ? '#' : '$';
            if(getcwd(cwd, sizeof(cwd)) == 0 && cwd[0] != '\0')
                printf("%s%c ", cwd, prompt);
            else
                printf("?%c ", prompt);
        }
#else
        printf("# ");
        fflush(stdout);
#endif

        {
            int read_result = sh_readline(line, SH_MAX_LINE);
            if(read_result == -1) {
                putchar('\n');
                break;
            }
            if(read_result == -2) {
                printf("sh: input discarded\n");
                continue;
            }
            if(read_result == -3)
                continue;
        }
#ifdef JTMOS
        {
            int redirect_result=sh_run_output_redirect(line);
            if(redirect_result!=SH_NOT_HANDLED)
                continue;
        }
        {
            int pipe_result=sh_run_pipeline(line);
            if(pipe_result!=SH_NOT_HANDLED)
                continue;
        }
#endif
        argv = argvbuilder(line, " \t", &argc);
        if (argv == NULL) {
            fprintf(stderr, "sh: unable to parse command line\n");
            continue;
        }
        if (argc == 0) {
            free_argv(argv, argc);
            continue;
        }

#ifdef JTMOS
        /* A leading ':' always means "load an external executable".
         * Do this before builtin lookup so :help can launch help.bin rather
         * than invoking the SMSH builtin help command. */
        if(line[0] == ':') {
            (void)smsh_launch_external(line);
            free_argv(argv, argc);
            continue;
        }
#endif

        command = find_builtin(argv[0]);
        if (command != NULL) {
            int command_result;
            if(smsh_builtin_needs_guard(argv[0]))
                command_result=smsh_run_guarded_builtin(line);
            else
                command_result=command(argc, argv);
            free_argv(argv, argc);
            if(command_result == SHELL_EXIT_REQUEST)
                break;
            continue;
        }

        dispatch_result = try_optional_dispatch(argv[0], argc, argv);
        if (dispatch_result != SH_NOT_HANDLED) {
            free_argv(argv, argc);
            continue;
        }

        /* GRAOS/Postman gets the first chance through the optional dispatcher.
         * Native SMSH then launches directly through Central Process.  Do not
         * call system()/SYS_cexec from this ring-0 shell. */
#ifdef JTMOS
        if (smsh_launch_external(line) != 0)
            printf("Unable to launch: %s\n", argv[0]);
#else
        if (system(line) == -1)
            perror("system");
#endif
        free_argv(argv, argc);
    }

    free(line);
    sh_dprint("Exiting Shell, Thank You For Visiting Us!\n");
    return 0;
}
