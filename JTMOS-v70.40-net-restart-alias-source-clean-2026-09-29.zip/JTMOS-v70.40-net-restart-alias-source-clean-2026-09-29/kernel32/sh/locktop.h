#ifndef __JTMOS_LOCKTOP_H__
#define __JTMOS_LOCKTOP_H__
int locktop_app(int argc,char **argv);
#endif
