/* nmiapp.c - SMSH diagnostics/control for JTMOS vector-2 NMI watchdog. */
#include <stdio.h>
#include <string.h>
#include "kernel32.h"
#include "nmi.h"
#include "nmi_source.h"
#include "threads.h"
#include "nmiapp.h"


static THREAD nmi_probe_thread;
static int nmi_probe_pid=0;
static THREAD nmi_killprobe_thread;
static int nmi_killprobe_pid=0;

static void nmi_watchdog_probe_worker(void)
{
    int me=GetCurrentThread();
    DWORD f;
    IdentifyThread(me,"NMI-PROBE");
    printf("NMI probe PID %d: entering ordinary CLI loop; waiting for generic IF repair.\n",me);
    disable();
    for(;;)
    {
        f=get_eflags();
        if(f&0x200U) break;
        __asm__ volatile("nop");
    }
    printf("NMI watchdog probe: PASS - NMI reopened IF without recoverable opt-in.\n");
    nmi_probe_pid=0;
    ExitThread(0);
}

static int nmi_watchdog_probe(void)
{
    if(!NmiPeriodicSourceActive())
    {
        printf("nmi watchdog probe: autonomous source is not active (%s).\n",
               NmiPeriodicSourceStatus());
        return 1;
    }
    if(nmi_probe_pid>0 && nmi_probe_pid<nr_threads && thread_states[nmi_probe_pid])
    {
        printf("nmi watchdog probe: probe PID %d is already active.\n",nmi_probe_pid);
        return 1;
    }
    memset(&nmi_probe_thread,0,sizeof(nmi_probe_thread));
    if(ThreadCreateStack(&nmi_probe_thread,JTMOS_MIN_DYNAMIC_STACK)!=0)
    {
        printf("nmi watchdog probe: stack allocation failed.\n");
        return 1;
    }
    nmi_probe_thread.pid=create_thread(nmi_probe_thread.stack,nmi_probe_thread.l_stack,
                                       nmi_watchdog_probe_worker);
    if(nmi_probe_thread.pid<=0)
    {
        ThreadDestroyStack(&nmi_probe_thread);
        printf("nmi watchdog probe: thread creation failed.\n");
        return 1;
    }
    nmi_probe_pid=nmi_probe_thread.pid;
    printf("nmi watchdog probe: started PID %d using %s.\n",
           nmi_probe_pid,NmiPeriodicSourceName());
    printf("Expected result: automatic IF repair; no rescue prompt or thread kill.\n");
    return 0;
}

static void nmi_watchdog_killprobe_worker(void)
{
    int me=GetCurrentThread();
    IdentifyThread(me,"NMI-KILLPROBE");
    (void)NmiWatchdogSetThreadAutokill(me,1);
    printf("NMI Guard Dog killprobe PID %d: intentional CLI hard loop entered.\n",me);
    disable();
    for(;;) __asm__ volatile("nop");
}

static int nmi_watchdog_killprobe(void)
{
    if(!NmiPeriodicSourceActive())
    {
        printf("nmi watchdog killprobe: autonomous source is not active (%s).\n",
               NmiPeriodicSourceStatus());
        return 1;
    }
    if(nmi_killprobe_pid>0 && nmi_killprobe_pid<nr_threads &&
       thread_states[nmi_killprobe_pid])
    {
        printf("nmi watchdog killprobe: PID %d is already active.\n",nmi_killprobe_pid);
        return 1;
    }
    memset(&nmi_killprobe_thread,0,sizeof(nmi_killprobe_thread));
    if(ThreadCreateStack(&nmi_killprobe_thread,JTMOS_MIN_DYNAMIC_STACK)!=0)
    {
        printf("nmi watchdog killprobe: stack allocation failed.\n");
        return 1;
    }
    nmi_killprobe_thread.pid=create_thread(nmi_killprobe_thread.stack,
                                           nmi_killprobe_thread.l_stack,
                                           nmi_watchdog_killprobe_worker);
    if(nmi_killprobe_thread.pid<=0)
    {
        ThreadDestroyStack(&nmi_killprobe_thread);
        printf("nmi watchdog killprobe: thread creation failed.\n");
        return 1;
    }
    nmi_killprobe_pid=nmi_killprobe_thread.pid;
    printf("nmi watchdog killprobe: started PID %d using %s.\n",
           nmi_killprobe_pid,NmiPeriodicSourceName());
    printf("Expected result: Guard Dog kills only the probe and SMSH remains responsive.\n");
    return 0;
}

static int nmi_parse_uint(const char *s,DWORD *out)
{
    DWORD v=0;
    if(!s || !*s || !out) return -1;
    while(*s)
    {
        unsigned d=(unsigned)(*s-'0');
        if(d>9U || v>(0xffffffffU-d)/10U) return -1;
        v=v*10U+d;
        ++s;
    }
    *out=v;
    return 0;
}

static void nmi_print_rescue(void)
{
    JTMOS_NMI_RESCUE_INFO r;
    int rc=NmiRescueGetInfo(&r);
    if(rc<=0)
    {
        printf("NMI rescue: no process is currently quarantined.\n");
        return;
    }
    printf("NMI rescue: PID=%u terminal=%u no-switch=%us irq-stall=%us suspended=%s\n",
           (unsigned)r.pid,(unsigned)r.terminal,(unsigned)r.no_switch_seconds,
           (unsigned)r.stall_seconds,
           (r.pid<N_MAX_THREADS && nmi_thread_suspended[r.pid])?"yes":"no");
    printf("NMI rescue: CS:EIP=%x:%x original-EFLAGS=%x forced-IRQs=%s seq=%u\n",
           (unsigned)r.cs,(unsigned)r.eip,(unsigned)r.eflags,
           r.forced_irqs_on?"yes":"no",(unsigned)r.sequence);
}

static void nmi_print_status(void)
{
    JTMOS_NMI_STATS s;
    NmiGetStats(&s);
    printf("NMI subsystem: %s (default=on, safe interrupt-gate mode; safe/nmi=off override)\n",NmiSystemGetEnabled()?"ON":"OFF");
    printf("NMI: total=%u unknown=%u parity=%u io-check=%u tests=%u nested=%u max-depth=%u\n",
           (unsigned)s.total,(unsigned)s.unknown,(unsigned)s.parity,
           (unsigned)s.io_check,(unsigned)s.software_tests,(unsigned)s.nested,
           (unsigned)s.max_depth);
    printf("NMI: last reason61=0x%x pid=%u CS:EIP=%x:%x EFLAGS=%x CR2=%x unknown-panic=%s\n",
           (unsigned)s.last_reason,(unsigned)s.last_pid,(unsigned)s.last_cs,
           (unsigned)s.last_eip,(unsigned)s.last_eflags,(unsigned)s.last_cr2,
           NmiGetUnknownPanic()?"on":"off");
    printf("NMI task-gate (experimental/not installed by nmi on): entries=%u bad-backlink=%u active=%u\n",
           (unsigned)s.task_gate_entries,(unsigned)s.task_gate_bad_backlink,
           (unsigned)s.task_gate_active);
    printf("NMI watchdog: %s threshold=%us events=%u samples=%u forced-IRQ-rescues=%u pending=%u\n",
           s.watchdog_enabled?"on":"off",(unsigned)s.watchdog_threshold_seconds,
           (unsigned)s.watchdog_events,(unsigned)s.watchdog_samples,
           (unsigned)s.rescue_forced_irq_count,(unsigned)s.rescue_pending);
    printf("NMI watchdog: unowned-NMI-skipped=%u kernel-context-skipped=%u rescue-publish-conflicts=%u\n",
           (unsigned)s.watchdog_unowned_skipped,
           (unsigned)s.watchdog_kernel_context_skipped,
           (unsigned)s.rescue_publish_conflicts);
    printf("NMI watchdog IF repair: %s repairs=%u last-pid=%u last-eip=%x\n",
           s.watchdog_force_if_enabled?"on":"off",
           (unsigned)s.watchdog_force_if_repairs,
           (unsigned)s.watchdog_last_force_if_pid,
           (unsigned)s.watchdog_last_force_if_eip);
    printf("NMI watchdog: process/worker-autokills=%u TF-kill-traps=%u guarddog-reaps=%u\n",
           (unsigned)s.watchdog_autokills,(unsigned)s.watchdog_kill_traps,
           (unsigned)s.watchdog_guarddog_reaps);
    printf("NMI watchdog source: %s (%s)\n",NmiPeriodicSourceName(),NmiPeriodicSourceStatus());
    if(!NmiPeriodicSourceActive())
        printf("NMI watchdog WARNING: no autonomous NMI source is active; IF=0 hard hangs cannot be rescued automatically.\n");
    if(s.last_pid<N_MAX_THREADS)
        printf("NMI watchdog: PID %u cached scheduler seconds without task switch=%u\n",
               (unsigned)s.last_pid,
               (unsigned)thread_rtc_seconds_without_task_switch[s.last_pid]);
    if(s.rescue_pending)
        nmi_print_rescue();
}

static int nmi_watchdog_command(int argc,char **argv)
{
    DWORD v;
    if(argc==2 || (argc==3 && !strcmp(argv[2],"status")))
    {
        nmi_print_status();
        return 0;
    }
    if(argc==3 && !strcmp(argv[2],"probe"))
        return nmi_watchdog_probe();
    if(argc==3 && (!strcmp(argv[2],"killprobe") || !strcmp(argv[2],"guarddog")))
        return nmi_watchdog_killprobe();
    if(argc==3 && (!strcmp(argv[2],"on") || !strcmp(argv[2],"off")))
    {
        if(!strcmp(argv[2],"on") && !NmiWatchdogSetEnabled(1))
            printf("nmi watchdog: no safe autonomous source active; bare-metal PMU auto-source is disabled.\n");
        else if(!strcmp(argv[2],"off"))
            (void)NmiWatchdogSetEnabled(0);
        nmi_print_status();
        return 0;
    }
    if(argc==4 && !strcmp(argv[2],"pmu") &&
       (!strcmp(argv[3],"on") || !strcmp(argv[3],"off")))
    {
        if(!strcmp(argv[3],"on") && !NmiWatchdogSetPmuEnabled(1))
            printf("nmi watchdog pmu: explicit PMU source could not be armed (%s).\n",
                   NmiPeriodicSourceStatus());
        else if(!strcmp(argv[3],"off"))
            (void)NmiWatchdogSetPmuEnabled(0);
        nmi_print_status();
        return 0;
    }
    if(argc==4 && (!strcmp(argv[2],"repair") || !strcmp(argv[2],"force-if")) &&
       (!strcmp(argv[3],"on") || !strcmp(argv[3],"off")))
    {
        (void)NmiWatchdogSetForceIf(!strcmp(argv[3],"on"));
        nmi_print_status();
        return 0;
    }
    if(argc==4 && (!strcmp(argv[2],"seconds") || !strcmp(argv[2],"threshold")))
    {
        if(nmi_parse_uint(argv[3],&v)!=0 ||
           NmiWatchdogSetThreshold(v)!=0)
        {
            printf("nmi watchdog: threshold must be 1..%u seconds (IB700; PMU uses conservative progress samples).\n",
                   (unsigned)JTMOS_NMI_WATCHDOG_MAX_SECONDS);
            return 2;
        }
        nmi_print_status();
        return 0;
    }
    printf("Usage: nmi watchdog [status|on|off|seconds N|probe|killprobe|guarddog|pmu on|off|repair on|off]\n");
    return 2;
}

static int nmi_rescue_command(int argc,char **argv)
{
    JTMOS_NMI_RESCUE_INFO r;
    int rc=NmiRescueGetInfo(&r);

    if(argc==2 || (argc==3 && !strcmp(argv[2],"status")))
    {
        nmi_print_rescue();
        return 0;
    }
    if(rc<=0)
    {
        printf("nmi rescue: no pending rescue.\n");
        return 1;
    }
    if(argc==3 && !strcmp(argv[2],"continue"))
    {
        rc=NmiRescueContinue((int)r.pid);
        printf("nmi rescue: PID %u %s.\n",(unsigned)r.pid,
               rc==0?"continued with IRQs enabled":"could not be continued");
        return rc==0?0:1;
    }
    if(argc==3 && (!strcmp(argv[2],"suspend") || !strcmp(argv[2],"hold")))
    {
        rc=NmiRescueKeepSuspended((int)r.pid);
        printf("nmi rescue: PID %u remains suspended.\n",(unsigned)r.pid);
        return rc==0?0:1;
    }
    if(argc==3 && !strcmp(argv[2],"kill"))
    {
        printf("nmi rescue: terminating PID %u; held kernel/driver locks cannot be guaranteed recoverable.\n",
               (unsigned)r.pid);
        rc=NmiRescueKill((int)r.pid);
        printf("nmi rescue: PID %u %s.\n",(unsigned)r.pid,
               rc==0?"terminated":"could not be terminated");
        return rc==0?0:1;
    }
    printf("Usage: nmi rescue [status|continue|suspend|kill]\n");
    return 2;
}

int nmi_app(int argc,char **argv)
{
    if(argc<=1 || !strcmp(argv[1],"status"))
    {
        nmi_print_status();
        return 0;
    }
    if(!strcmp(argv[1],"on") || !strcmp(argv[1],"off"))
    {
        (void)NmiSystemSetEnabled(!strcmp(argv[1],"on"));
        nmi_print_status();
        return 0;
    }
    if(!strcmp(argv[1],"test"))
    {
        int rc=NmiSoftwareSelfTest();
        if(rc==-2)
            printf("NMI software vector-2 self-test: disabled; run `nmi on` first.\n");
        else
            printf("NMI software vector-2 self-test: %s\n",rc==0?"PASS":"FAIL");
        nmi_print_status();
        return rc==0?0:1;
    }
    if(!strcmp(argv[1],"strict"))
    {
        if(argc!=3 || (strcmp(argv[2],"on") && strcmp(argv[2],"off")))
        {
            printf("Usage: nmi strict on|off\n");
            return 2;
        }
        NmiSetUnknownPanic(!strcmp(argv[2],"on"));
        nmi_print_status();
        return 0;
    }
    if(!strcmp(argv[1],"watchdog"))
        return nmi_watchdog_command(argc,argv);
    if(!strcmp(argv[1],"rescue"))
        return nmi_rescue_command(argc,argv);

    printf("Usage: nmi [status|on|off|test|strict on|off|watchdog ...|rescue ...]\n");
    printf("  watchdog detects CLI/no-IRQ stalls from autonomous NMI + scheduler/PIT progress.\n");
    printf("  ordinary applications use two-stage NMI Guard Dog fail-stop containment (#DB + deferred reap).\n");
    printf("  rescue remains interactive for explicitly recoverable kernel/service probes.\n");
    printf("  generic IF repair reopens IRQ delivery after a proven CLI/disable stall without killing the thread.\n");
    return 2;
}
