// ============================================================================
// mmap.c - POSIX-call-compatible mmap()/munmap() and ELF32 process mappings.
//
// The public mmap API is intentionally separate from kmalloc(). kmalloc keeps
// its historical one-argument kernel allocation role: kmalloc(size).
//
// Current JTMOS limitations:
//   * anonymous mappings are implemented;
//   * file-backed mappings are not implemented yet;
//   * MAP_FIXED requires a free exact range (it does not destroy an old map);
//   * munmap currently releases one complete mmap allocation, not a subrange;
//   * IA-32 non-PAE paging cannot enforce PROT_EXEC/NX separately.
// ============================================================================

#include <stddef.h>
#include "mm.h"
#include "mmAlloc.h"
#include "paging.h"
#include "buddy.h"
#include "slab.h"
#include "threads.h"
#include "sys/mman.h"

#if defined(N_MAX_THREADS) && (N_MAX_THREADS > MM_PROCESS_PAGE_TABLE_CAPACITY)
#error "JTMOS MM: PG_USER_PAGE_TABLES_BYTES is too small for N_MAX_THREADS"
#endif

/* V69.66: every public process-PTE mutation invalidates the local TLB when
 * it targets the currently running process.  Keep the helper declaration
 * above the low-level mapping routines so DMA and mmap callers cannot bypass
 * this rule accidentally. */
static void mm_process_invalidate(int pid, DWORD address, DWORD length);
static DWORD mm_cow_alias_for_user_nolock(int pid,DWORD user_page);
#define MM_USER_PTE_SOFT_RESERVED 0x200UL /* Present=0, software bit 9 */
#define MM_USER_PTE_LAZY          0x400UL /* Present=0, first-touch sparse page */
#define MM_USER_PTE_LAZY_MASK     (MM_USER_PTE_SOFT_RESERVED|MM_USER_PTE_LAZY)

/* V70.9 Linux-style COW reference map.
 *
 * IA-32 has 20 physical-page-number bits.  A flat WORD array would consume
 * 2 MiB even on small machines, so allocate 2 KiB leaves lazily.  One leaf
 * covers 1024 physical pages (4 MiB).  A zero reference means the page is
 * exclusively owned through its ordinary sparse/demand descriptor. */
#define MM_COW_REF_BLOCK_SHIFT 10U
#define MM_COW_REF_BLOCK_PAGES (1U << MM_COW_REF_BLOCK_SHIFT)
#define MM_COW_REF_BLOCK_COUNT (MM_BITMAP_PAGES / MM_COW_REF_BLOCK_PAGES)
#define MM_COW_REF_BLOCK_MASK  (MM_COW_REF_BLOCK_PAGES - 1U)

static WORD *cow_ref_blocks[MM_COW_REF_BLOCK_COUNT];
static DWORD cow_faults_handled;
static DWORD cow_pages_copied;
static DWORD cow_exclusive_reuses;
static DWORD cow_fault_failures;
static DWORD cow_shared_pages;
static DWORD cow_tracked_references;
/* V70.10 first-touch sparse accounting. */
static DWORD sparse_lazy_faults_handled;
static DWORD sparse_lazy_pages_live;
static DWORD sparse_virtual_only_pages;
static DWORD sparse_lazy_fault_failures;

static WORD *mm_cow_ref_slot_nolock(DWORD physical)
{
    DWORD page=physical/PAGESIZE;
    WORD *block;
    if((physical&MM_PAGE_MASK)!=0 || page>=MM_BITMAP_PAGES) return NULL;
    block=cow_ref_blocks[page>>MM_COW_REF_BLOCK_SHIFT];
    if(block==NULL) return NULL;
    return &block[page&MM_COW_REF_BLOCK_MASK];
}

static int mm_cow_prepare_physical(DWORD physical)
{
    DWORD page,block_index,mmflags;
    WORD *block,*candidate;

    if((physical&MM_PAGE_MASK)!=0 || physical<PG_STRUCTURES_PHYS_END)
        return -1;
    page=physical/PAGESIZE;
    if(page>=MM_BITMAP_PAGES) return -1;
    block_index=page>>MM_COW_REF_BLOCK_SHIFT;

    mmflags=mmCriticalEnter();
    block=cow_ref_blocks[block_index];
    mmCriticalLeave(mmflags);
    if(block!=NULL) return 0;

    candidate=(WORD *)_kmalloc((int)(MM_COW_REF_BLOCK_PAGES*sizeof(WORD)),0,
                               "COW refcount leaf");
    if(candidate==NULL) return -1;
    memset(candidate,0,MM_COW_REF_BLOCK_PAGES*sizeof(WORD));

    mmflags=mmCriticalEnter();
    if(cow_ref_blocks[block_index]==NULL)
    {
        cow_ref_blocks[block_index]=candidate;
        candidate=NULL;
    }
    mmCriticalLeave(mmflags);
    if(candidate!=NULL) _kfree(candidate);
    return 0;
}

/* Add one new mapping reference.  The first fork changes the implicit single
 * owner into two explicit references; later forks add one. */
static int mm_cow_share_physical(DWORD physical)
{
    WORD *ref;
    DWORD mmflags;
    int result=0;

    mmflags=mmCriticalEnter();
    ref=mm_cow_ref_slot_nolock(physical);
    if(ref==NULL || *ref==0xffffU) result=-1;
    else if(*ref==0)
    {
        *ref=2;
        cow_shared_pages++;
        cow_tracked_references+=2;
    }
    else
    {
        if(*ref==1) cow_shared_pages++;
        (*ref)++;
        cow_tracked_references++;
    }
    mmCriticalLeave(mmflags);
    return result;
}

/* Drop one owner.  Return non-zero only when the physical page now has no
 * owner and must be returned to buddy/the legacy bitmap. */
static int mm_cow_release_physical(DWORD physical)
{
    WORD *ref;
    DWORD mmflags;
    int release=0;

    mmflags=mmCriticalEnter();
    ref=mm_cow_ref_slot_nolock(physical);
    if(ref==NULL || *ref==0) release=1;
    else if(*ref==1)
    {
        *ref=0;
        if(cow_tracked_references) cow_tracked_references--;
        release=1;
    }
    else
    {
        if(*ref==2 && cow_shared_pages) cow_shared_pages--;
        (*ref)--;
        if(cow_tracked_references) cow_tracked_references--;
    }
    mmCriticalLeave(mmflags);
    return release;
}

static void mm_physical_page_free(DWORD physical_page)
{
    void *buddy_alias;
    if(physical_page==0) return;
    buddy_alias=mm_buddy_physical_to_virtual(physical_page*PAGESIZE);
    if(buddy_alias) (void)mm_buddy_free(buddy_alias);
    else mmFreeRegion(physical_page,physical_page+1U);
}

static DWORD mmap_align_up(DWORD value)
{
    if(value > (0xffffffffUL - MM_PAGE_MASK))
        return 0;
    return (value + MM_PAGE_MASK) & ~MM_PAGE_MASK;
}

static int mmap_valid_prot(int prot)
{
    return (prot & ~(PROT_READ | PROT_WRITE | PROT_EXEC)) == 0;
}

void *mmap(void *addr, size_t length, int prot, int flags,
           int fd, off_t offset)
{
    DWORD bytes;
    void *p;
    int sharing;
    int pages;

    if(length == 0 || length > (size_t)0x7fffffffU)
        return MAP_FAILED;
    if(!mmap_valid_prot(prot))
        return MAP_FAILED;

    sharing = flags & (MAP_PRIVATE | MAP_SHARED);
    if(sharing != MAP_PRIVATE && sharing != MAP_SHARED)
        return MAP_FAILED;

    /* The first JTMOS implementation is anonymous-memory only. */
    if((flags & MAP_ANONYMOUS) == 0)
        return MAP_FAILED;
    if(fd != -1 || offset != 0)
        return MAP_FAILED;

    bytes = mmap_align_up((DWORD)length);
    if(bytes == 0 || bytes > 0x7fffffffUL)
        return MAP_FAILED;
    pages = (int)(bytes / PAGESIZE);

    if((flags & (MAP_FIXED | MAP_FIXED_NOREPLACE)) != 0)
    {
        if(addr == NULL || (((DWORD)addr) & MM_PAGE_MASK) != 0)
            return MAP_FAILED;

        /* Safe JTMOS interpretation: exact address, but never silently
           destroy an existing allocation. */
        p = _kmalloc_at((int)bytes, GetCurrentThread(), "mmap", (DWORD)addr);
    }
    else
    {
        /* addr is a POSIX hint here. The current JTMOS virtual allocator has
           no nearest-to-hint search, so an available mapping is selected. */
        p = kmalloc((int)bytes);
    }

    if(p == NULL)
        return MAP_FAILED;

    /* Anonymous mmap pages must initially read as zero. Do this while the
       mapping is writable, then apply the requested protection bits. */
    memset(p, 0, bytes);

    if(pg_protectmemory((DWORD)p, pages, prot) != 0)
    {
        kfree(p);
        return MAP_FAILED;
    }

    return p;
}

int munmap(void *addr, size_t length)
{
    DWORD bytes;
    int allocation_bytes;

    if(addr == NULL || addr == MAP_FAILED || length == 0)
        return -1;
    if(((DWORD)addr & MM_PAGE_MASK) != 0)
        return -1;
    if(length > (size_t)0x7fffffffU)
        return -1;

    bytes = mmap_align_up((DWORD)length);
    if(bytes == 0)
        return -1;

    allocation_bytes = malloc_getsize(addr);
    if(allocation_bytes <= 0)
        return -1;

    /* The MM descriptor currently represents one contiguous allocation.
       Reject partial unmaps rather than freeing more memory than requested. */
    if((DWORD)allocation_bytes != bytes)
        return -1;

    kfree(addr);
    return 0;
}

DWORD mm_page_align_down(DWORD value)
{
    return value & ~MM_PAGE_MASK;
}

DWORD mm_page_align_up(DWORD value)
{
    return mmap_align_up(value);
}

/*
 * V70.10 sparse first-touch process backing.
 *
 * Reserve one contiguous kernel virtual window and one MD/page-vector, but
 * keep every data PTE non-present until the first actual access.  A zero
 * page_vector entry belongs to the virtual-only page pool and consumes no
 * physical 4 KiB frame.  #PF materializes exactly one page at a time.
 */
void *mm_sparse_alloc(DWORD length, int owner_pid, const char *name)
{
    DWORD bytes,base,pages,flags;
    DWORD *page_vector;
    MD *m;

    if(length == 0 || owner_pid < 0)
        return NULL;
    bytes=mm_page_align_up(length);
    if(bytes==0 || bytes>0x7fffffffUL)
        return NULL;
    pages=bytes/PAGESIZE;
    if(pages==0 || pages>0x7fffffffUL/sizeof(DWORD))
        return NULL;

    /* V70.10 first-touch sparse allocation.  The virtual range and its MD are
     * committed immediately, but no data page is consumed here.  A zero entry
     * in page_vector is the authoritative "virtual-only" state; the #PF path
     * installs exactly one zeroed 4 KiB frame when that page is first read,
     * written or executed. */
    base=pg_reserve_virtual((int)pages);
    if(base==0)
        return NULL;

    page_vector=(DWORD *)_kmalloc((int)(pages*sizeof(DWORD)),0,
                                  "lazy sparse page vector");
    if(page_vector==NULL)
    {
        (void)pg_release_virtual(base,(int)pages);
        return NULL;
    }
    memset(page_vector,0,pages*sizeof(DWORD));

    flags=mmCriticalEnter();
    m=mmGetNewEntry();
    if(m!=NULL)
    {
        memset(m,0,sizeof(*m));
        m->PID=owner_pid;
        m->isFree=0;
        m->kind=MM_MD_KIND_SPARSE;
        m->page=-1;
        m->pages=(int)pages;
        m->bytes=(int)bytes;
        m->mapad=base;
        m->p=NULL;                 /* no physical first page before first touch */
        m->page_vector=page_vector;
        m->page_vector_count=(int)pages;
        if(name==NULL) name="lazy sparse";
        strncpy(m->name,name,sizeof(m->name)-1);
        m->name[sizeof(m->name)-1]=0;
        mmIndexEntry(m);
    }
    mmCriticalLeave(flags);
    if(m==NULL)
    {
        _kfree(page_vector);
        (void)pg_release_virtual(base,(int)pages);
        return NULL;
    }

    /* Resident accounting deliberately stays at zero here.  The page-fault
     * materializer charges one resident page at a time.  Until then all pages
     * belong to the non-physical virtual-only pool. */
    flags=mmCriticalEnter();
    sparse_virtual_only_pages+=pages;
    mmCriticalLeave(flags);
    return (void *)base;
}

/* Create a second sparse kernel alias of the same physical page vector.
 * Both aliases become supervisor-read-only+COW.  mm_clone_process_space_cow()
 * applies the matching policy to the user PTEs after the child PID exists. */
void *mm_sparse_clone_cow(void *source, DWORD length, int owner_pid,
                          const char *name)
{
    DWORD bytes,pages,base,i,flags,physical,source_pte,child_pte;
    DWORD shared=0;
    DWORD *page_vector;
    MD *src,*dst;

    if(source==NULL || (((DWORD)source)&MM_PAGE_MASK)!=0 || length==0 ||
       owner_pid<0)
        return NULL;
    bytes=mm_page_align_up(length);
    if(bytes==0) return NULL;

    flags=mmCriticalEnter();
    src=mmGiveMD(source);
    if(src==NULL || src->isFree || src->kind!=MM_MD_KIND_SPARSE ||
       (DWORD)src->bytes!=bytes || src->page_vector==NULL ||
       src->page_vector_count!=src->pages)
    {
        mmCriticalLeave(flags);
        return NULL;
    }
    pages=(DWORD)src->pages;
    mmCriticalLeave(flags);

    /* Page-fault handling cannot allocate refcount metadata recursively.
     * Provision every leaf before publishing any COW PTE. */
    for(i=0;i<pages;i++)
    {
        flags=mmCriticalEnter();
        src=mmGiveMD(source);
        physical=(src && src->page_vector && i<(DWORD)src->page_vector_count) ?
                 src->page_vector[i]*PAGESIZE : 0;
        mmCriticalLeave(flags);
        if(physical!=0 && mm_cow_prepare_physical(physical)!=0) return NULL;
    }

    base=pg_reserve_virtual((int)pages);
    if(base==0) return NULL;
    page_vector=(DWORD *)_kmalloc((int)(pages*sizeof(DWORD)),0,
                                  "COW sparse page vector");
    if(page_vector==NULL)
    {
        (void)pg_release_virtual(base,(int)pages);
        return NULL;
    }
    memset(page_vector,0,pages*sizeof(DWORD));

    flags=mmCriticalEnter();
    dst=mmGetNewEntry();
    if(dst!=NULL)
    {
        memset(dst,0,sizeof(*dst));
        dst->PID=-1;
        dst->isFree=0;
        dst->kind=MM_MD_KIND_SPARSE;
        dst->page=-1;
        dst->pages=(int)pages;
        dst->bytes=(int)bytes;
        dst->page_vector=page_vector;
        dst->page_vector_count=(int)pages;
    }
    mmCriticalLeave(flags);
    if(dst==NULL)
    {
        _kfree(page_vector);
        (void)pg_release_virtual(base,(int)pages);
        return NULL;
    }

    for(i=0;i<pages;i++)
    {
        flags=mmCriticalEnter();
        src=mmGiveMD(source);
        physical=(src && src->page_vector && i<(DWORD)src->page_vector_count) ?
                 src->page_vector[i]*PAGESIZE : 0;
        mmCriticalLeave(flags);
        if(physical==0)
        {
            /* Preserve the virtual-only state across fork.  No COW reference
             * exists until a process actually materializes this page. */
            page_vector[i]=0;
            continue;
        }
        if(mm_cow_share_physical(physical)!=0) goto fail;
        shared++;
        page_vector[i]=physical/PAGESIZE;
        if(pg_map_reserved_page(base+i*PAGESIZE,physical)!=0) goto fail;
    }

    /* Validate every alias before changing source permissions. */
    for(i=0;i<pages;i++)
    {
        physical=page_vector[i]*PAGESIZE;
        source_pte=GetPage((((DWORD)source)+i*PAGESIZE)/PAGESIZE);
        child_pte=GetPage((base+i*PAGESIZE)/PAGESIZE);
        if(physical==0)
        {
            if((source_pte&1U) || (child_pte&1U) ||
               !(source_pte&MM_USER_PTE_SOFT_RESERVED) ||
               !(child_pte&MM_USER_PTE_SOFT_RESERVED))
                goto fail;
            continue;
        }
        if((source_pte&0xfffff000UL)!=physical || !(source_pte&1U) ||
           (child_pte&0xfffff000UL)!=physical || !(child_pte&1U))
            goto fail;
    }

    /* CR0.WP makes these supervisor aliases obey the same COW invariant as
     * Ring-3.  Preserve cache/access attributes, clear RW and set bit 9. */
    flags=mmCriticalEnter();
    for(i=0;i<pages;i++)
    {
        DWORD source_page=(((DWORD)source)+i*PAGESIZE)/PAGESIZE;
        DWORD child_page=(base+i*PAGESIZE)/PAGESIZE;
        if(page_vector[i]==0) continue;
        source_pte=GetPage(source_page);
        child_pte=GetPage(child_page);
        SetPage(source_page,(source_pte&~2UL)|MM_PTE_COW);
        SetPage(child_page,(child_pte&~2UL)|MM_PTE_COW);
    }
    dst->PID=owner_pid;
    dst->mapad=base;
    dst->p=page_vector[0] ? (char *)(page_vector[0]*PAGESIZE) : NULL;
    if(name==NULL) name="COW sparse";
    strncpy(dst->name,name,sizeof(dst->name)-1);
    dst->name[sizeof(dst->name)-1]=0;
    mmIndexEntry(dst);
    mmCriticalLeave(flags);
    AffectProcessML(owner_pid,(int)shared);
    flags=mmCriticalEnter();
    sparse_lazy_pages_live+=shared;
    sparse_virtual_only_pages+=pages-shared;
    mmCriticalLeave(flags);
    return (void *)base;

fail:
    (void)pg_release_virtual(base,(int)pages);
    for(i=0;i<pages;i++)
        if(page_vector[i]!=0)
            (void)mm_cow_release_physical(page_vector[i]*PAGESIZE);
    flags=mmCriticalEnter();
    mmRemoveEntry(dst);
    mmCriticalLeave(flags);
    _kfree(page_vector);
    return NULL;
}

int mm_sparse_free(void *base, DWORD length)
{
    DWORD bytes,pages,i,flags,resident=0,virtual_only;
    DWORD *page_vector;
    int owner;
    MD *m;

    if(base==NULL || (((DWORD)base)&MM_PAGE_MASK)!=0 || length==0)
        return -1;
    bytes=mm_page_align_up(length);
    if(bytes==0)
        return -1;

    flags=mmCriticalEnter();
    m=mmGiveMD(base);
    if(m==NULL || m->isFree || m->kind!=MM_MD_KIND_SPARSE ||
       (DWORD)m->bytes!=bytes || m->page_vector==NULL ||
       m->page_vector_count!=m->pages)
    {
        mmCriticalLeave(flags);
        return -1;
    }
    pages=(DWORD)m->pages;
    page_vector=m->page_vector;
    owner=m->PID;
    /* Remove the public index before any backing page becomes free. */
    mmUnindexEntry(m);
    m->mapad=0;
    m->page_vector=NULL;
    m->page_vector_count=0;
    mmCriticalLeave(flags);

    (void)pg_release_virtual((DWORD)base,(int)pages);
    for(i=0;i<pages;++i)
        if(page_vector[i]!=0)
        {
            DWORD physical=page_vector[i]*PAGESIZE;
            resident++;
            if(mm_cow_release_physical(physical))
                mm_physical_page_free(page_vector[i]);
        }
    AffectProcessML(owner,-(int)resident);
    virtual_only=pages-resident;
    flags=mmCriticalEnter();
    if(sparse_lazy_pages_live>=resident) sparse_lazy_pages_live-=resident;
    else sparse_lazy_pages_live=0;
    if(sparse_virtual_only_pages>=virtual_only)
        sparse_virtual_only_pages-=virtual_only;
    else sparse_virtual_only_pages=0;
    mmCriticalLeave(flags);

    flags=mmCriticalEnter();
    mmRemoveEntry(m);
    mmCriticalLeave(flags);
    _kfree(page_vector);
    return 0;
}

int mm_sparse_change_owner(void *base, DWORD length, int old_pid, int new_pid)
{
    DWORD bytes,flags,i,resident=0;
    MD *m;

    if(base==NULL || (((DWORD)base)&MM_PAGE_MASK)!=0 || length==0 ||
       old_pid<0 || new_pid<0)
        return -1;
    bytes=mm_page_align_up(length);
    if(bytes==0)
        return -1;

    flags=mmCriticalEnter();
    m=mmGiveMD(base);
    if(m==NULL || m->isFree || m->kind!=MM_MD_KIND_SPARSE ||
       (DWORD)m->bytes!=bytes || m->PID!=old_pid ||
       m->page_vector==NULL || m->page_vector_count!=m->pages)
    {
        mmCriticalLeave(flags);
        return -1;
    }
    for(i=0;i<(DWORD)m->page_vector_count;i++)
        if(m->page_vector[i]!=0) resident++;
    m->PID=new_pid;
    mmCriticalLeave(flags);

    /* Only materialized pages are resident.  Virtual-only pages transfer
     * ownership at zero physical cost and are charged when first touched. */
    if(resident)
    {
        AffectProcessML(old_pid,-(int)resident);
        AffectProcessML(new_pid,(int)resident);
    }
    return 0;
}


static DWORD *mm_process_page_table(int pid)
{
    DWORD bytes_per_process;
    DWORD maximum_processes;

    if(pid < 0)
        return NULL;

    bytes_per_process = MM_PROCESS_PAGE_TABLE_BYTES;
    maximum_processes = MM_PROCESS_PAGE_TABLE_CAPACITY;
    if((DWORD)pid >= maximum_processes)
        return NULL;

    return (DWORD *)(PG_USER_PAGE_TABLES_PHYS +
                     ((DWORD)pid * bytes_per_process));
}

static DWORD mm_pte_flags_from_prot(int prot)
{
    DWORD flags;

    if(prot == PROT_NONE)
        return 0;

    /* Process mappings are ring-3 pages.  The parent PDE is also marked
       U/S by scheduler.c when the PID is selected. */
    flags = 1 | 4;              /* present + user */
    if(prot & PROT_WRITE)
        flags |= 2;             /* writable */

    /* IA-32 non-PAE has no NX bit, so PROT_EXEC cannot be independently
       enforced. PROT_READ/PROT_EXEC both mean a present, read-only PTE when
       PROT_WRITE is absent. */
    return flags;
}

void mm_clear_process_space(int pid)
{
    DWORD *table;
    DWORD i;
    DWORD mmflags;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return;

    mmflags=mmCriticalEnter();
    for(i = 0; i < MM_USER_PAGES; ++i)
        table[i] = 0;
    mmCriticalLeave(mmflags);
}

/* Clone the primary ELF32 userspace mappings onto a freshly allocated
 * child backing window.  The backing pages are private copies; only the
 * parent's PTE protection bits/presence are inherited.  This deliberately
 * excludes kernel-mediated DMA/IRQ resources, which have their own lifetime. */
int mm_clone_process_space(int parent_pid, int child_pid, void *child_backing, DWORD length)
{
    DWORD *parent_table;
    DWORD *child_table;
    DWORD bytes;
    DWORD pages;
    DWORD child_kernel_page;
    DWORD child_source_pte;
    DWORD physical;
    DWORD flags;
    DWORD i;

    if(child_backing == NULL || (((DWORD)child_backing) & MM_PAGE_MASK) != 0 || length == 0)
        return -1;

    bytes = mm_page_align_up(length);
    if(bytes == 0 || bytes > MM_USER_SIZE)
        return -1;

    parent_table = mm_process_page_table(parent_pid);
    child_table = mm_process_page_table(child_pid);
    if(parent_table == NULL || child_table == NULL)
        return -1;

    pages = bytes / PAGESIZE;
    if(pages > MM_USER_PAGES)
        pages = MM_USER_PAGES;

    mm_clear_process_space(child_pid);
    child_kernel_page = ((DWORD)child_backing) / PAGESIZE;

    for(i = 0; i < pages; ++i)
    {
        if((parent_table[i] & 1U) == 0)
            continue;

        child_source_pte = GetPage(child_kernel_page + i);
        physical = child_source_pte & 0xfffff000UL;
        if((child_source_pte & 1U) == 0 || physical < PG_STRUCTURES_PHYS_END)
        {
            mm_clear_process_space(child_pid);
            return -1;
        }

        /* Preserve IA-32 low PTE attributes (P/RW/US/cache/access bits), but
         * always use the child's newly allocated physical page. */
        flags = parent_table[i] & 0x00000fffUL;
        flags |= 1U | 4U;
        child_table[i] = physical | flags;
    }

    return 0;
}

static int mm_clone_process_range_cow(int parent_pid, int child_pid,
                                      DWORD user_address,
                                      void *parent_backing,
                                      void *child_backing, DWORD length)
{
    DWORD *parent_table,*child_table;
    DWORD first,pages,i,flags,mmflags;
    DWORD parent_alias_pte,child_alias_pte,parent_pte,physical;

    if(parent_backing==NULL || child_backing==NULL || length==0 ||
       (((DWORD)parent_backing)&MM_PAGE_MASK) ||
       (((DWORD)child_backing)&MM_PAGE_MASK) ||
       (user_address&MM_PAGE_MASK))
        return -1;
    length=mm_page_align_up(length);
    if(length==0 || user_address<MM_USER_BASE ||
       user_address>MM_USER_TOP-length)
        return -1;
    parent_table=mm_process_page_table(parent_pid);
    child_table=mm_process_page_table(child_pid);
    if(parent_table==NULL || child_table==NULL) return -1;
    first=(user_address-MM_USER_BASE)/PAGESIZE;
    pages=length/PAGESIZE;

    mmflags=mmCriticalEnter();
    for(i=0;i<pages;i++)
    {
        parent_alias_pte=GetPage((((DWORD)parent_backing)+i*PAGESIZE)/PAGESIZE);
        child_alias_pte=GetPage((((DWORD)child_backing)+i*PAGESIZE)/PAGESIZE);
        parent_pte=parent_table[first+i];

        if(parent_alias_pte&1U)
        {
            physical=parent_alias_pte&0xfffff000UL;
            if(!(child_alias_pte&1U) ||
               (child_alias_pte&0xfffff000UL)!=physical ||
               !(parent_alias_pte&MM_PTE_COW) || !(child_alias_pte&MM_PTE_COW))
            {
                mmCriticalLeave(mmflags);
                return -1;
            }
            if((parent_pte&0xfffff000UL)!=0 &&
               (parent_pte&0xfffff000UL)!=physical)
            {
                mmCriticalLeave(mmflags);
                return -1;
            }
        }
        else
        {
            /* Untouched backing remains virtual-only in both processes. */
            if((child_alias_pte&1U) ||
               !(parent_alias_pte&MM_USER_PTE_SOFT_RESERVED) ||
               !(child_alias_pte&MM_USER_PTE_SOFT_RESERVED) ||
               (parent_pte&0xfffff000UL)!=0)
            {
                mmCriticalLeave(mmflags);
                return -1;
            }
        }

        if(child_table[first+i]!=0 &&
           child_table[first+i]!=MM_USER_PTE_SOFT_RESERVED)
        {
            mmCriticalLeave(mmflags);
            return -1;
        }
    }

    for(i=0;i<pages;i++)
    {
        parent_alias_pte=GetPage((((DWORD)parent_backing)+i*PAGESIZE)/PAGESIZE);
        parent_pte=parent_table[first+i];
        if(!(parent_alias_pte&1U))
        {
            if((parent_pte&MM_USER_PTE_LAZY_MASK)==MM_USER_PTE_LAZY_MASK)
                child_table[first+i]=parent_pte;
            else
                child_table[first+i]=0;
            continue;
        }

        physical=parent_alias_pte&0xfffff000UL;
        if((parent_pte&0xfffff000UL)==0)
        {
            child_table[first+i]=0;
            continue;
        }
        flags=parent_pte&0x00000fffUL;
        if((flags&1U) && ((flags&2U) || (flags&MM_PTE_COW)))
        {
            flags=(flags&~2UL)|MM_PTE_COW;
            parent_table[first+i]=physical|flags;
        }
        child_table[first+i]=physical|flags;
    }
    mmCriticalLeave(mmflags);
    mm_process_invalidate(parent_pid,user_address,length);
    mm_process_invalidate(child_pid,user_address,length);
    return 0;
}


int mm_clone_process_space_cow(int parent_pid, int child_pid,
                               void *parent_backing, void *child_backing,
                               DWORD length)
{
    DWORD bytes;
    if(length==0) return -1;
    bytes=mm_page_align_up(length);
    if(bytes==0 || bytes>MM_USER_SIZE) return -1;
    mm_clear_process_space(child_pid);
    if(mm_clone_process_range_cow(parent_pid,child_pid,MM_USER_BASE,
                                  parent_backing,child_backing,bytes)!=0)
    {
        mm_clear_process_space(child_pid);
        return -1;
    }
    return 0;
}


DWORD mm_get_process_pte(int pid, DWORD virtual_address)
{
    DWORD *table;
    DWORD index;
    DWORD pte;
    DWORD mmflags;

    if(virtual_address < MM_USER_BASE || virtual_address >= MM_USER_TOP)
        return 0;
    table = mm_process_page_table(pid);
    if(table == NULL)
        return 0;
    index = (virtual_address - MM_USER_BASE) / PAGESIZE;
    if(index >= MM_USER_PAGES)
        return 0;

    mmflags=mmCriticalEnter();
    pte=table[index];
    mmCriticalLeave(mmflags);
    return pte;
}

int mm_map_process_range(int pid, DWORD virtual_address,
                         void *kernel_address, DWORD length, int prot)
{
    DWORD *table;
    DWORD virtual_end;
    DWORD first_index;
    DWORD page_count;
    DWORD source_page;
    DWORD source_pte;
    DWORD physical;
    DWORD pte_flags;
    DWORD mmflags;
    DWORD i;
    MD *source_md;
    DWORD source_md_first=0;

    if(kernel_address == NULL || length == 0 || !mmap_valid_prot(prot))
        return -1;
    if((virtual_address & MM_PAGE_MASK) != 0 ||
       ((DWORD)kernel_address & MM_PAGE_MASK) != 0)
        return -1;

    length = mm_page_align_up(length);
    if(length == 0 || virtual_address < MM_USER_BASE)
        return -1;
    if(virtual_address > 0xffffffffUL - length)
        return -1;

    virtual_end = virtual_address + length;
    if(virtual_end > MM_USER_TOP)
        return -1;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return -1;

    first_index = (virtual_address - MM_USER_BASE) / PAGESIZE;
    page_count = length / PAGESIZE;
    source_page = ((DWORD)kernel_address) / PAGESIZE;
    pte_flags = mm_pte_flags_from_prot(prot);

    /* Transactional failure: never expose a partially installed process PTE
     * range.  Validate every source and destination before publication.
     * A sparse source may still be entirely virtual.  In that case publish a
     * non-present user PTE carrying the requested U/RW protection bits plus a
     * software lazy marker.  The first #PF binds both aliases to one frame. */
    mmflags=mmCriticalEnter();
    source_md=mmDetermineOwner(kernel_address);
    if(source_md!=NULL && !source_md->isFree &&
       source_md->kind==MM_MD_KIND_SPARSE && source_md->page_vector!=NULL &&
       source_md->page_vector_count==source_md->pages &&
       (DWORD)kernel_address>=source_md->mapad)
        source_md_first=((DWORD)kernel_address-source_md->mapad)/PAGESIZE;
    else
        source_md=NULL;

    for(i = 0; i < page_count; ++i)
    {
        source_pte = GetPage(source_page + i);
        physical = source_pte & 0xfffff000UL;
        if((source_pte & 1U) != 0)
        {
            if(physical < PG_STRUCTURES_PHYS_END)
            {
                mmCriticalLeave(mmflags);
                return -1;
            }
        }
        else
        {
            DWORD sparse_index=source_md_first+i;
            if(source_md==NULL || sparse_index>=(DWORD)source_md->page_vector_count ||
               source_md->page_vector[sparse_index]!=0 ||
               !(source_pte&MM_USER_PTE_SOFT_RESERVED))
            {
                mmCriticalLeave(mmflags);
                return -1;
            }
        }
        if(table[first_index+i] != 0 &&
           table[first_index+i] != MM_USER_PTE_SOFT_RESERVED)
        {
            mmCriticalLeave(mmflags);
            return -1;
        }
    }

    for(i = 0; i < page_count; ++i)
    {
        source_pte = GetPage(source_page + i);
        physical = source_pte & 0xfffff000UL;
        if(source_pte&1U)
            table[first_index + i] = physical | pte_flags;
        else
            table[first_index + i] = MM_USER_PTE_LAZY_MASK |
                                     (pte_flags & (2U|4U));
    }
    mmCriticalLeave(mmflags);
    mm_process_invalidate(pid,virtual_address,length);
    return 0;
}


int mm_protect_process_range(int pid, DWORD virtual_address,
                             DWORD length, int prot)
{
    DWORD *table;
    DWORD virtual_end;
    DWORD first_index;
    DWORD page_count;
    DWORD pte;
    DWORD pte_flags;
    DWORD physical;
    DWORD alias;
    DWORD alias_pte;
    DWORD mmflags;
    DWORD i;
    WORD *ref;

    if(length == 0 || !mmap_valid_prot(prot) ||
       (virtual_address & MM_PAGE_MASK) != 0)
        return -1;

    length = mm_page_align_up(length);
    if(length == 0 || virtual_address < MM_USER_BASE)
        return -1;
    if(virtual_address > 0xffffffffUL - length)
        return -1;

    virtual_end = virtual_address + length;
    if(virtual_end > MM_USER_TOP)
        return -1;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return -1;

    first_index = (virtual_address - MM_USER_BASE) / PAGESIZE;
    page_count = length / PAGESIZE;
    pte_flags = mm_pte_flags_from_prot(prot);

    mmflags=mmCriticalEnter();
    /* Validate the complete range first so protection changes are atomic. */
    for(i=0;i<page_count;++i)
    {
        pte=table[first_index+i];
        physical=pte&0xfffff000UL;
        if(physical==0)
        {
            if((pte&MM_USER_PTE_LAZY_MASK)!=MM_USER_PTE_LAZY_MASK)
            {
                mmCriticalLeave(mmflags);
                return -1;
            }
            continue;
        }
        ref=mm_cow_ref_slot_nolock(physical);
        if(ref && *ref)
        {
            alias=mm_cow_alias_for_user_nolock(pid,
                    virtual_address+i*PAGESIZE);
            if(alias==0 ||
               (GetPage(alias/PAGESIZE)&0xfffff000UL)!=physical)
            {
                mmCriticalLeave(mmflags);
                return -1;
            }
        }
    }
    for(i=0;i<page_count;++i)
    {
        pte=table[first_index+i];
        physical=pte&0xfffff000UL;
        if(physical==0)
        {
            table[first_index+i]=MM_USER_PTE_LAZY_MASK |
                                 (pte_flags&(2U|4U));
            continue;
        }
        ref=mm_cow_ref_slot_nolock(physical);
        alias=mm_cow_alias_for_user_nolock(pid,virtual_address+i*PAGESIZE);
        if(ref && *ref)
        {
            alias_pte=GetPage(alias/PAGESIZE);
            if(prot&PROT_WRITE)
            {
                if(*ref>1)
                {
                    table[first_index+i]=physical|
                        ((pte_flags&~2UL)|MM_PTE_COW);
                    SetPage(alias/PAGESIZE,
                        (alias_pte&~2UL)|MM_PTE_COW);
                    continue;
                }
                *ref=0;
                if(cow_tracked_references) cow_tracked_references--;
                SetPage(alias/PAGESIZE,
                    (alias_pte|2U)&~MM_PTE_COW);
            }
            else
                SetPage(alias/PAGESIZE,
                    alias_pte&~(2UL|MM_PTE_COW));
        }
        table[first_index+i]=physical|pte_flags;
    }
    mmCriticalLeave(mmflags);
    mm_process_invalidate(pid,virtual_address,length);
    return 0;
}

int mm_unmap_process_range(int pid, DWORD virtual_address, DWORD length)
{
    DWORD *table;
    DWORD virtual_end;
    DWORD first_index;
    DWORD page_count;
    DWORD mmflags;
    DWORD i;

    if(length == 0 || (virtual_address & MM_PAGE_MASK) != 0)
        return -1;

    length = mm_page_align_up(length);
    if(length == 0 || virtual_address < MM_USER_BASE)
        return -1;
    if(virtual_address > 0xffffffffUL - length)
        return -1;

    virtual_end = virtual_address + length;
    if(virtual_end > MM_USER_TOP)
        return -1;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return -1;

    first_index = (virtual_address - MM_USER_BASE) / PAGESIZE;
    page_count = length / PAGESIZE;
    mmflags=mmCriticalEnter();
    for(i = 0; i < page_count; ++i)
        table[first_index + i] = 0;
    mmCriticalLeave(mmflags);
    mm_process_invalidate(pid,virtual_address,length);
    return 0;
}

DWORD mm_find_process_free_range(int pid, DWORD length, DWORD low, DWORD high)
{
    DWORD *table;
    DWORD pages;
    DWORD low_index;
    DWORD high_index;
    DWORD start;
    DWORD i;
    DWORD result;
    DWORD mmflags;
    int free_range;

    length = mm_page_align_up(length);
    if(length == 0)
        return 0;
    if(low < MM_USER_BASE)
        low = MM_USER_BASE;
    if(high > MM_USER_TOP)
        high = MM_USER_TOP;
    low = mm_page_align_up(low);
    high = mm_page_align_down(high);
    if(high <= low || length > high-low)
        return 0;

    table = mm_process_page_table(pid);
    if(table == NULL)
        return 0;
    pages = length / PAGESIZE;
    low_index = (low-MM_USER_BASE)/PAGESIZE;
    high_index = (high-MM_USER_BASE)/PAGESIZE;
    if(high_index < pages)
        return 0;

    result=0;
    mmflags=mmCriticalEnter();
    start = high_index-pages;
    for(;;)
    {
        if(start < low_index)
            break;
        free_range = 1;
        for(i=0; i<pages; ++i)
        {
            if(table[start+i] != 0)
            {
                free_range = 0;
                break;
            }
        }
        if(free_range)
        {
            result=MM_USER_BASE + start*PAGESIZE;
            break;
        }
        if(start == 0)
            break;
        --start;
    }
    mmCriticalLeave(mmflags);
    return result;
}



/* -------------------------------------------------------------------------
 * V67.8.57.8 process mmap manager.
 *
 * The original mmap() above is a kernel-linear allocator.  ELF32 processes,
 * however, execute in their own 0x80000000..0x80ffffff page-table window.
 * These helpers allocate sparse kernel backing pages, map them into that
 * process window and retain the kernel alias needed by syscall copyin/copyout.
 * ------------------------------------------------------------------------- */
#define MM_PROCESS_MMAP_SLOTS 64

/* Process mmap metadata is published in two phases.  RESERVED claims both the
 * metadata slot and user virtual range before any slow backing allocation is
 * started.  ACTIVE is visible to A2K/translation.  REMOVING prevents a second
 * munmap/teardown from claiming the same mapping while its PTEs are removed.
 *
 * The registry is protected by mmCriticalEnter()/Leave().  On current JTMOS
 * this is an IRQ-safe single-CPU critical section; the reservation_id prevents
 * an old in-flight mmap from committing into a slot that teardown cancelled
 * and a later mapping reused (ABA protection). */
#define MM_PROCESS_MAP_FREE       0
#define MM_PROCESS_MAP_RESERVED   1
#define MM_PROCESS_MAP_ACTIVE     2
#define MM_PROCESS_MAP_REMOVING   3

typedef struct {
    BYTE state;
    BYTE demand;
    WORD reserved16;
    DWORD reservation_id;
    DWORD user_address;
    DWORD kernel_address;
    DWORD length;
    int prot;
    int flags;
    DWORD page_array; /* demand map: original kernel alias per user page */
} MM_PROCESS_MAPPING;

/* V70: per-process VMAs grow in page-sized blocks instead of stopping at a
 * fixed 64-mapping ceiling.  Blocks remain stable for kernel lifetime so an
 * in-flight reservation token can never point into freed/reused metadata. */
typedef struct mm_process_mapping_block {
    struct mm_process_mapping_block *next;
    MM_PROCESS_MAPPING slots[MM_PROCESS_MMAP_SLOTS];
} MM_PROCESS_MAPPING_BLOCK;

static MM_PROCESS_MAPPING_BLOCK *process_mmaps[MM_PROCESS_PAGE_TABLE_CAPACITY];
static DWORD process_mmap_next_reservation=1;
static DWORD demand_faults_handled;
static DWORD demand_pages_live;
static DWORD demand_fault_failures;
static volatile DWORD demand_pf_active;
static volatile DWORD demand_pf_nested_latched;
static volatile DWORD demand_fault_nested;

static int mm_process_pid_ok(int pid)
{
    return pid >= 0 && (DWORD)pid < MM_PROCESS_PAGE_TABLE_CAPACITY;
}

static MM_PROCESS_MAPPING_BLOCK *mm_process_registry_ensure(int pid)
{
    MM_PROCESS_MAPPING_BLOCK *registry,*candidate;
    DWORD mmflags;
    if(!mm_process_pid_ok(pid)) return NULL;
    mmflags=mmCriticalEnter();
    registry=process_mmaps[pid];
    mmCriticalLeave(mmflags);
    if(registry!=NULL) return registry;

    candidate=(MM_PROCESS_MAPPING_BLOCK *)_kmalloc(
        (int)sizeof(MM_PROCESS_MAPPING_BLOCK),0,"process VMA block");
    if(candidate==NULL) return NULL;
    memset(candidate,0,sizeof(*candidate));

    mmflags=mmCriticalEnter();
    if(process_mmaps[pid]==NULL)
    {
        process_mmaps[pid]=candidate;
        registry=candidate;
        candidate=NULL;
    }
    else registry=process_mmaps[pid];
    mmCriticalLeave(mmflags);
    if(candidate) _kfree(candidate);
    return registry;
}

static MM_PROCESS_MAPPING *mm_process_free_slot_nolock(int pid)
{
    MM_PROCESS_MAPPING_BLOCK *b;
    int i;
    if(!mm_process_pid_ok(pid)) return NULL;
    for(b=process_mmaps[pid];b;b=b->next)
        for(i=0;i<MM_PROCESS_MMAP_SLOTS;i++)
            if(b->slots[i].state==MM_PROCESS_MAP_FREE)
                return &b->slots[i];
    return NULL;
}

static int mm_process_registry_ensure_free_slot(int pid)
{
    MM_PROCESS_MAPPING_BLOCK *candidate,*b;
    DWORD mmflags;
    if(mm_process_registry_ensure(pid)==NULL) return -1;
    mmflags=mmCriticalEnter();
    if(mm_process_free_slot_nolock(pid)!=NULL)
    {
        mmCriticalLeave(mmflags);
        return 0;
    }
    mmCriticalLeave(mmflags);

    candidate=(MM_PROCESS_MAPPING_BLOCK *)_kmalloc(
        (int)sizeof(MM_PROCESS_MAPPING_BLOCK),0,"process VMA grow");
    if(candidate==NULL) return -1;
    memset(candidate,0,sizeof(*candidate));

    mmflags=mmCriticalEnter();
    if(mm_process_free_slot_nolock(pid)==NULL)
    {
        b=process_mmaps[pid];
        candidate->next=b;
        process_mmaps[pid]=candidate;
        candidate=NULL;
    }
    mmCriticalLeave(mmflags);
    if(candidate) _kfree(candidate);
    return 0;
}

static DWORD mm_process_next_reservation_nolock(void)
{
    DWORD id;
    id=process_mmap_next_reservation++;
    if(id==0)
    {
        id=process_mmap_next_reservation++;
        if(id==0) { process_mmap_next_reservation=2; id=1; }
    }
    return id;
}

static int mm_process_pte_range_free_nolock(int pid,DWORD address,DWORD length)
{
    DWORD *table,first_index,pages,i;
    if(!mm_process_pid_ok(pid) || length==0 || (address&MM_PAGE_MASK)) return 0;
    length=mm_page_align_up(length);
    if(length==0 || address<MM_USER_BASE || address>MM_USER_TOP-length) return 0;
    table=mm_process_page_table(pid);
    if(table==NULL) return 0;
    first_index=(address-MM_USER_BASE)/PAGESIZE;
    pages=length/PAGESIZE;
    for(i=0;i<pages;i++) if(table[first_index+i]!=0) return 0;
    return 1;
}

static int mm_process_mark_reserved_nolock(int pid,DWORD address,DWORD length)
{
    DWORD *table,first,pages,i;
    if(!mm_process_pte_range_free_nolock(pid,address,length)) return -1;
    table=mm_process_page_table(pid); if(table==NULL) return -1;
    first=(address-MM_USER_BASE)/PAGESIZE;
    pages=mm_page_align_up(length)/PAGESIZE;
    for(i=0;i<pages;i++) table[first+i]=MM_USER_PTE_SOFT_RESERVED;
    return 0;
}

static void mm_process_clear_reserved_nolock(int pid,DWORD address,DWORD length)
{
    DWORD *table,first,pages,i,bytes;
    if(!mm_process_pid_ok(pid) || length==0 || address<MM_USER_BASE) return;
    bytes=mm_page_align_up(length);
    if(bytes==0 || address>MM_USER_TOP-bytes) return;
    table=mm_process_page_table(pid); if(table==NULL) return;
    first=(address-MM_USER_BASE)/PAGESIZE; pages=bytes/PAGESIZE;
    for(i=0;i<pages;i++)
        if(table[first+i]==MM_USER_PTE_SOFT_RESERVED) table[first+i]=0;
}

static int mm_process_registry_range_free_nolock(int pid,DWORD address,DWORD length)
{
    DWORD end,mend;
    int i;
    MM_PROCESS_MAPPING_BLOCK *b;
    MM_PROCESS_MAPPING *m;
    if(!mm_process_pid_ok(pid) || length==0 || address>0xffffffffUL-length) return 0;
    end=address+length;
    for(b=process_mmaps[pid];b;b=b->next)
        for(i=0;i<MM_PROCESS_MMAP_SLOTS;i++)
        {
            m=&b->slots[i];
            if(m->state==MM_PROCESS_MAP_FREE || m->length==0) continue;
            if(m->user_address>0xffffffffUL-m->length) return 0;
            mend=m->user_address+m->length;
            if(address<mend && m->user_address<end) return 0;
        }
    return 1;
}

static int mm_process_range_available_nolock(int pid,DWORD address,DWORD length)
{
    return mm_process_pte_range_free_nolock(pid,address,length) &&
           mm_process_registry_range_free_nolock(pid,address,length);
}

static DWORD mm_process_find_free_range_nolock(int pid,DWORD length,DWORD low,DWORD high)
{
    DWORD candidate;
    length=mm_page_align_up(length);
    if(length==0) return 0;
    if(low<MM_USER_BASE) low=MM_USER_BASE;
    if(high>MM_USER_TOP) high=MM_USER_TOP;
    low=mm_page_align_up(low); high=mm_page_align_down(high);
    if(high<=low || length>high-low) return 0;
    candidate=high-length;
    for(;;)
    {
        if(candidate<low) break;
        if(mm_process_range_available_nolock(pid,candidate,length)) return candidate;
        if(candidate<low+PAGESIZE) break;
        candidate-=PAGESIZE;
    }
    return 0;
}

static MM_PROCESS_MAPPING *mm_process_find_active_nolock(int pid,DWORD address)
{
    MM_PROCESS_MAPPING_BLOCK *b;
    MM_PROCESS_MAPPING *m;
    int i;
    if(!mm_process_pid_ok(pid)) return NULL;
    for(b=process_mmaps[pid];b;b=b->next)
        for(i=0;i<MM_PROCESS_MMAP_SLOTS;i++)
        {
            m=&b->slots[i];
            if(m->state==MM_PROCESS_MAP_ACTIVE && m->user_address==address) return m;
        }
    return NULL;
}

static MM_PROCESS_MAPPING *mm_process_find_containing_nolock(int pid,DWORD address)
{
    MM_PROCESS_MAPPING_BLOCK *b;
    MM_PROCESS_MAPPING *m;
    int i;
    if(!mm_process_pid_ok(pid)) return NULL;
    for(b=process_mmaps[pid];b;b=b->next)
        for(i=0;i<MM_PROCESS_MMAP_SLOTS;i++)
        {
            m=&b->slots[i];
            if(m->state!=MM_PROCESS_MAP_ACTIVE || address<m->user_address) continue;
            if(address-m->user_address<m->length) return m;
        }
    return NULL;
}

/* Resolve the supervisor alias corresponding to one user page.  Primary
 * ELF/heap/stack backing uses thread_base[]; dynamic mmap VMAs use the
 * process registry.  Caller holds the MM critical section. */
static DWORD mm_cow_alias_for_user_nolock(int pid,DWORD user_page)
{
    DWORD base,bytes,offset;
    MM_PROCESS_MAPPING *m;
    if(!mm_process_pid_ok(pid) || user_page<MM_USER_BASE ||
       user_page>=MM_USER_TOP || (user_page&MM_PAGE_MASK)) return 0;
    base=thread_base[pid];
    bytes=(DWORD)thread_memkb[pid]*1024UL;
    offset=user_page-MM_USER_BASE;
    if(base && offset<bytes) return base+offset;
    m=mm_process_find_containing_nolock(pid,user_page);
    if(m==NULL || m->demand || m->kernel_address==0) return 0;
    return m->kernel_address+(user_page-m->user_address);
}

/* Reverse lookup used when CR0.WP catches a syscall writing through a
 * supervisor alias.  The descriptor owner, not the currently running PID,
 * is authoritative because inter-process copy syscalls can target another
 * process.  Caller holds the MM critical section. */
static DWORD mm_cow_user_for_alias_nolock(MD *descriptor,DWORD alias_page)
{
    int pid,i;
    DWORD offset;
    MM_PROCESS_MAPPING_BLOCK *b;
    MM_PROCESS_MAPPING *m;
    if(descriptor==NULL || descriptor->kind!=MM_MD_KIND_SPARSE ||
       alias_page<descriptor->mapad ||
       alias_page-descriptor->mapad>=(DWORD)descriptor->bytes)
        return 0;
    pid=descriptor->PID;
    if(!mm_process_pid_ok(pid)) return 0;
    offset=alias_page-descriptor->mapad;
    if(thread_base[pid]==descriptor->mapad &&
       offset<(DWORD)thread_memkb[pid]*1024UL)
        return MM_USER_BASE+offset;
    for(b=process_mmaps[pid];b;b=b->next)
        for(i=0;i<MM_PROCESS_MMAP_SLOTS;i++)
        {
            m=&b->slots[i];
            if(m->state==MM_PROCESS_MAP_ACTIVE && !m->demand &&
               m->kernel_address==descriptor->mapad && offset<m->length)
                return m->user_address+offset;
        }
    return 0;
}

typedef struct
{
    DWORD physical;
    void *copy_alias;
    int buddy;
    int temporary_alias;
} MM_COW_FRESH_PAGE;

static int mm_cow_alloc_fresh(MM_COW_FRESH_PAGE *fresh)
{
    void *page;
    int physical_page;
    DWORD reservation,mmflags;
    if(fresh==NULL) return -1;
    memset(fresh,0,sizeof(*fresh));
    page=mm_buddy_alloc_order(0);
    if(page!=NULL)
    {
        fresh->physical=mm_buddy_virtual_to_physical(page);
        fresh->copy_alias=page;
        fresh->buddy=1;
        if(fresh->physical>=PG_STRUCTURES_PHYS_END) return 0;
        (void)mm_buddy_free(page);
        memset(fresh,0,sizeof(*fresh));
        return -1;
    }

    mmflags=mmCriticalEnter();
    physical_page=mmFindFreePages(1);
    if(physical_page>0 &&
       mmTryReserveRegion((DWORD)physical_page,(DWORD)physical_page+1U)!=0)
        physical_page=0;
    mmCriticalLeave(mmflags);
    if(physical_page<=0) return -1;
    reservation=pg_reserve_virtual(1);
    if(reservation==0 ||
       pg_map_reserved_page(reservation,(DWORD)physical_page*PAGESIZE)!=0)
    {
        if(reservation) (void)pg_release_virtual(reservation,1);
        mmFreeRegion((DWORD)physical_page,(DWORD)physical_page+1U);
        return -1;
    }
    fresh->physical=(DWORD)physical_page*PAGESIZE;
    fresh->copy_alias=(void *)reservation;
    fresh->temporary_alias=1;
    return 0;
}

static void mm_cow_discard_fresh(MM_COW_FRESH_PAGE *fresh)
{
    if(fresh==NULL || fresh->physical==0) return;
    if(fresh->temporary_alias)
        (void)pg_release_virtual((DWORD)fresh->copy_alias,1);
    if(fresh->buddy) (void)mm_buddy_free(fresh->copy_alias);
    else mmFreeRegion(fresh->physical/PAGESIZE,
                      fresh->physical/PAGESIZE+1U);
    memset(fresh,0,sizeof(*fresh));
}

static void mm_cow_finish_fresh(MM_COW_FRESH_PAGE *fresh)
{
    if(fresh && fresh->temporary_alias)
        (void)pg_release_virtual((DWORD)fresh->copy_alias,1);
    if(fresh) memset(fresh,0,sizeof(*fresh));
}


/* V70.10: bind one virtual-only sparse alias to physical RAM on first touch.
 * This helper never changes a user PTE itself; callers publish the matching
 * user mapping only after the kernel alias and MD page_vector are committed. */
static int mm_sparse_materialize_alias(MD *descriptor,DWORD alias_page,
                                       DWORD *physical_out)
{
    DWORD index,pte,mmflags,physical;
    int owner;
    MM_COW_FRESH_PAGE fresh;

    if(physical_out) *physical_out=0;
    if(descriptor==NULL || (alias_page&MM_PAGE_MASK)!=0)
        return 0;

    mmflags=mmCriticalEnter();
    if(descriptor->isFree || descriptor->kind!=MM_MD_KIND_SPARSE ||
       descriptor->mapad==0 || descriptor->page_vector==NULL ||
       descriptor->page_vector_count!=descriptor->pages ||
       alias_page<descriptor->mapad ||
       alias_page-descriptor->mapad>=(DWORD)descriptor->bytes)
    {
        mmCriticalLeave(mmflags);
        return 0;
    }
    index=(alias_page-descriptor->mapad)/PAGESIZE;
    if(index>=(DWORD)descriptor->page_vector_count)
    {
        mmCriticalLeave(mmflags);
        return 0;
    }
    if(descriptor->page_vector[index]!=0)
    {
        physical=descriptor->page_vector[index]*PAGESIZE;
        pte=GetPage(alias_page/PAGESIZE);
        if(!(pte&1U) || (pte&0xfffff000UL)!=physical)
        {
            sparse_lazy_fault_failures++;
            mmCriticalLeave(mmflags);
            return 0;
        }
        if(physical_out) *physical_out=physical;
        mmCriticalLeave(mmflags);
        return 1;
    }
    pte=GetPage(alias_page/PAGESIZE);
    if((pte&1U) || !(pte&MM_USER_PTE_SOFT_RESERVED))
    {
        mmCriticalLeave(mmflags);
        return 0;
    }
    owner=descriptor->PID;
    mmCriticalLeave(mmflags);

    if(mm_cow_alloc_fresh(&fresh)!=0)
    {
        mmflags=mmCriticalEnter();
        sparse_lazy_fault_failures++;
        mmCriticalLeave(mmflags);
        return 0;
    }
    memset(fresh.copy_alias,0,PAGESIZE);

    mmflags=mmCriticalEnter();
    if(descriptor->isFree || descriptor->kind!=MM_MD_KIND_SPARSE ||
       descriptor->mapad==0 || descriptor->page_vector==NULL ||
       index>=(DWORD)descriptor->page_vector_count ||
       descriptor->mapad+index*PAGESIZE!=alias_page)
    {
        mmCriticalLeave(mmflags);
        mm_cow_discard_fresh(&fresh);
        return 0;
    }
    if(descriptor->page_vector[index]!=0)
    {
        physical=descriptor->page_vector[index]*PAGESIZE;
        pte=GetPage(alias_page/PAGESIZE);
        mmCriticalLeave(mmflags);
        mm_cow_discard_fresh(&fresh);
        if(!(pte&1U) || (pte&0xfffff000UL)!=physical) return 0;
        if(physical_out) *physical_out=physical;
        return 1;
    }
    pte=GetPage(alias_page/PAGESIZE);
    if((pte&1U) || !(pte&MM_USER_PTE_SOFT_RESERVED) ||
       pg_map_reserved_page(alias_page,fresh.physical)!=0)
    {
        sparse_lazy_fault_failures++;
        mmCriticalLeave(mmflags);
        mm_cow_discard_fresh(&fresh);
        return 0;
    }

    physical=fresh.physical;
    descriptor->page_vector[index]=physical/PAGESIZE;
    if(index==0) descriptor->p=(char *)physical;
    owner=descriptor->PID;
    sparse_lazy_faults_handled++;
    sparse_lazy_pages_live++;
    if(sparse_virtual_only_pages) sparse_virtual_only_pages--;
    mmCriticalLeave(mmflags);

    mm_cow_finish_fresh(&fresh);
    if(owner>0) (void)mm_charge_process_pages(owner,1);
    if(physical_out) *physical_out=physical;
    return 1;
}

static int mm_sparse_handle_fault(int current_pid,DWORD address,DWORD error)
{
    DWORD page,alias,physical,pte,mmflags,user_page;
    DWORD *table;
    MD *descriptor;

    /* First-touch is strictly a not-present fault.  Reserved-bit faults and
     * ordinary protection violations stay on the fatal/containment path. */
    if((error&1U) || (error&8U)) return 0;

    if(error&4U)
    {
        if(!mm_process_pid_ok(current_pid) || address<MM_USER_BASE ||
           address>=MM_USER_TOP) return 0;
        page=mm_page_align_down(address);
        table=mm_process_page_table(current_pid);
        if(table==NULL) return 0;

        mmflags=mmCriticalEnter();
        pte=table[(page-MM_USER_BASE)/PAGESIZE];
        if((pte&MM_USER_PTE_LAZY_MASK)!=MM_USER_PTE_LAZY_MASK ||
           !(pte&4U) || ((error&2U) && !(pte&2U)))
        {
            mmCriticalLeave(mmflags);
            return 0;
        }
        alias=mm_cow_alias_for_user_nolock(current_pid,page);
        descriptor=alias ? mmDetermineOwner((void *)alias) : NULL;
        mmCriticalLeave(mmflags);
        if(alias==0 || descriptor==NULL) return 0;
        if(!mm_sparse_materialize_alias(descriptor,alias,&physical)) return 0;

        mmflags=mmCriticalEnter();
        pte=table[(page-MM_USER_BASE)/PAGESIZE];
        if((pte&MM_USER_PTE_LAZY_MASK)!=MM_USER_PTE_LAZY_MASK)
        {
            mmCriticalLeave(mmflags);
            return (pte&1U) ? 1 : 0;
        }
        table[(page-MM_USER_BASE)/PAGESIZE]=physical|1U|(pte&(2U|4U));
        mmCriticalLeave(mmflags);
        mm_process_invalidate(current_pid,page,PAGESIZE);
        return 1;
    }

    /* Supervisor first touch of a kernel sparse alias (ELF loader, copyout,
     * kernel-side mmap consumer, etc.). */
    alias=mm_page_align_down(address);
    mmflags=mmCriticalEnter();
    pte=GetPage(alias/PAGESIZE);
    descriptor=mmDetermineOwner((void *)alias);
    if(descriptor==NULL || descriptor->kind!=MM_MD_KIND_SPARSE ||
       (pte&1U) || !(pte&MM_USER_PTE_SOFT_RESERVED))
    {
        mmCriticalLeave(mmflags);
        return 0;
    }
    mmCriticalLeave(mmflags);
    if(!mm_sparse_materialize_alias(descriptor,alias,&physical)) return 0;

    /* If this alias already belongs to a published user mapping, make that
     * PTE resident too while preserving the original user/RW policy. */
    mmflags=mmCriticalEnter();
    user_page=mm_cow_user_for_alias_nolock(descriptor,alias);
    if(user_page!=0)
    {
        int owner=descriptor->PID;
        table=mm_process_page_table(owner);
        if(table!=NULL)
        {
            DWORD index=(user_page-MM_USER_BASE)/PAGESIZE;
            pte=table[index];
            if((pte&MM_USER_PTE_LAZY_MASK)==MM_USER_PTE_LAZY_MASK && (pte&4U))
                table[index]=physical|1U|(pte&(2U|4U));
        }
        mmCriticalLeave(mmflags);
        if(table!=NULL) mm_process_invalidate(owner,user_page,PAGESIZE);
    }
    else mmCriticalLeave(mmflags);
    return 1;
}

static int mm_cow_break_page(int pid,DWORD user_page,DWORD alias_page)
{
    DWORD *table,index,user_pte,alias_pte,physical,mmflags,alias_index;
    DWORD user_flags,alias_flags;
    WORD *ref;
    MD *descriptor;
    MM_COW_FRESH_PAGE fresh;

    table=mm_process_page_table(pid);
    if(table==NULL) return 0;
    index=(user_page-MM_USER_BASE)/PAGESIZE;

    mmflags=mmCriticalEnter();
    user_pte=table[index];
    alias_pte=GetPage(alias_page/PAGESIZE);
    physical=user_pte&0xfffff000UL;
    descriptor=mmDetermineOwner((void *)alias_page);
    if(!(user_pte&1U) || !(user_pte&MM_PTE_COW) ||
       !(alias_pte&1U) || !(alias_pte&MM_PTE_COW) ||
       physical<PG_STRUCTURES_PHYS_END ||
       (alias_pte&0xfffff000UL)!=physical || descriptor==NULL ||
       descriptor->kind!=MM_MD_KIND_SPARSE || descriptor->PID!=pid ||
       alias_page<descriptor->mapad)
    {
        mmCriticalLeave(mmflags);
        return 0;
    }
    alias_index=(alias_page-descriptor->mapad)/PAGESIZE;
    if(alias_index>=(DWORD)descriptor->page_vector_count ||
       descriptor->page_vector[alias_index]!=physical/PAGESIZE)
    {
        mmCriticalLeave(mmflags);
        return 0;
    }
    ref=mm_cow_ref_slot_nolock(physical);
    if(ref==NULL || *ref==0)
    {
        cow_fault_failures++;
        mmCriticalLeave(mmflags);
        return 0;
    }

    /* Linux's do_wp_page() optimization: if every other owner has gone away,
     * simply restore write permission instead of copying the page. */
    if(*ref==1)
    {
        *ref=0;
        if(cow_tracked_references) cow_tracked_references--;
        user_flags=((user_pte&0x00000fffUL)&~MM_PTE_COW)|2U;
        alias_flags=((alias_pte&0x00000fffUL)&~MM_PTE_COW)|2U;
        table[index]=physical|user_flags;
        SetPage(alias_page/PAGESIZE,physical|alias_flags);
        cow_faults_handled++;
        cow_exclusive_reuses++;
        mmCriticalLeave(mmflags);
        mm_process_invalidate(pid,user_page,PAGESIZE);
        return 1;
    }
    mmCriticalLeave(mmflags);

    if(mm_cow_alloc_fresh(&fresh)!=0)
    {
        mmflags=mmCriticalEnter(); cow_fault_failures++; mmCriticalLeave(mmflags);
        return 0;
    }
    memcpy(fresh.copy_alias,(void *)alias_page,PAGESIZE);

    mmflags=mmCriticalEnter();
    user_pte=table[index];
    alias_pte=GetPage(alias_page/PAGESIZE);
    descriptor=mmDetermineOwner((void *)alias_page);
    ref=mm_cow_ref_slot_nolock(physical);
    if((user_pte&0xfffff000UL)!=physical || !(user_pte&MM_PTE_COW) ||
       (alias_pte&0xfffff000UL)!=physical || !(alias_pte&MM_PTE_COW) ||
       descriptor==NULL || descriptor->PID!=pid ||
       alias_index>=(DWORD)descriptor->page_vector_count ||
       descriptor->page_vector[alias_index]!=physical/PAGESIZE ||
       ref==NULL || *ref<2)
    {
        cow_fault_failures++;
        mmCriticalLeave(mmflags);
        mm_cow_discard_fresh(&fresh);
        return 0;
    }
    descriptor->page_vector[alias_index]=fresh.physical/PAGESIZE;
    user_flags=((user_pte&0x00000fffUL)&~MM_PTE_COW)|2U;
    alias_flags=((alias_pte&0x00000fffUL)&~MM_PTE_COW)|2U;
    table[index]=fresh.physical|user_flags;
    SetPage(alias_page/PAGESIZE,fresh.physical|alias_flags);
    if(*ref==2 && cow_shared_pages) cow_shared_pages--;
    (*ref)--;
    if(cow_tracked_references) cow_tracked_references--;
    cow_faults_handled++;
    cow_pages_copied++;
    mmCriticalLeave(mmflags);
    mm_cow_finish_fresh(&fresh);
    mm_process_invalidate(pid,user_page,PAGESIZE);
    return 1;
}

static int mm_cow_handle_fault(int current_pid,DWORD address,DWORD error)
{
    DWORD user_page,alias_page,mmflags,pte;
    int owner=current_pid;
    MD *descriptor;

    /* COW is a present-page write protection fault, never reserved-bit. */
    if((error&3U)!=3U || (error&8U)!=0) return 0;
    if(error&4U)
    {
        if(!mm_process_pid_ok(owner) || address<MM_USER_BASE ||
           address>=MM_USER_TOP) return 0;
        user_page=mm_page_align_down(address);
        mmflags=mmCriticalEnter();
        pte=mm_process_page_table(owner)[(user_page-MM_USER_BASE)/PAGESIZE];
        alias_page=mm_cow_alias_for_user_nolock(owner,user_page);
        mmCriticalLeave(mmflags);
        if(!(pte&1U) || !(pte&MM_PTE_COW) || alias_page==0) return 0;
        return mm_cow_break_page(owner,user_page,alias_page);
    }

    /* Supervisor write through a process backing alias.  CR0.WP is required
     * so kernel copyout cannot silently modify a page shared after fork(). */
    alias_page=mm_page_align_down(address);
    mmflags=mmCriticalEnter();
    pte=GetPage(alias_page/PAGESIZE);
    descriptor=mmDetermineOwner((void *)alias_page);
    if(descriptor==NULL || !(pte&1U) || !(pte&MM_PTE_COW))
    {
        mmCriticalLeave(mmflags);
        return 0;
    }
    owner=descriptor->PID;
    user_page=mm_cow_user_for_alias_nolock(descriptor,alias_page);
    mmCriticalLeave(mmflags);
    if(user_page==0) return 0;
    return mm_cow_break_page(owner,user_page,alias_page);
}


static void mm_process_cancel_reservation(int pid,MM_PROCESS_MAPPING *slot, DWORD reservation_id)
{
    DWORD mmflags;

    if(slot==NULL || reservation_id==0)
        return;
    mmflags=mmCriticalEnter();
    if(slot->state==MM_PROCESS_MAP_RESERVED &&
       slot->reservation_id==reservation_id) {
        mm_process_clear_reserved_nolock(pid,slot->user_address,slot->length);
        memset(slot,0,sizeof(*slot));
    }
    mmCriticalLeave(mmflags);
}

static void mm_process_invalidate(int pid, DWORD address, DWORD length)
{
#if defined(__i386__) && !defined(LIBCVERSION)
    DWORD end;
    if(pid != GetCurrentThread())
        return;
    end=address+length;
    while(address<end)
    {
        asm volatile("invlpg (%0)" : : "r" ((void *)address) : "memory");
        address+=PAGESIZE;
    }
#else
    (void)pid; (void)address; (void)length;
#endif
}


static void mm_demand_page_discard(void *page)
{
    if(page==NULL) return;
    if(mm_buddy_owns(page)) (void)mm_buddy_free(page);
    else _kfree(page);
}

static void mm_demand_page_free(int pid, void *page)
{
    if(page==NULL) return;
    if(mm_buddy_owns(page))
    {
        if(mm_buddy_free(page)==0) (void)mm_charge_process_pages(pid,-1);
    }
    else _kfree(page);
}

static void mm_demand_alias_array_free(DWORD *aliases)
{
    if(aliases==NULL) return;
    if(mm_slab_owns(aliases)) (void)mm_slab_free(aliases);
    else _kfree(aliases);
}

static void mm_demand_release(int pid,DWORD kernel_address,DWORD length,DWORD page_array)
{
    DWORD *aliases=(DWORD *)page_array;
    DWORD pages,i;
    if(length==0) return;
    pages=mm_page_align_up(length)/PAGESIZE;
    if(kernel_address) (void)pg_release_virtual(kernel_address,(int)pages);
    if(aliases) {
        for(i=0;i<pages;i++) if(aliases[i]) {
            mm_demand_page_free(pid,(void *)aliases[i]);
            if(demand_pages_live) demand_pages_live--;
        }
        mm_demand_alias_array_free(aliases);
    }
}

static int mm_demand_populate_page(int pid,DWORD address,DWORD error)
{
    MM_PROCESS_MAPPING *m;
    DWORD user_page,page_index,kernel_alias,reservation_id,physical;
    DWORD *aliases,*table;
    int prot;
    void *fresh;
    DWORD mmflags;

    if(!mm_process_pid_ok(pid) || address<MM_USER_BASE || address>=MM_USER_TOP)
        return 0;
    user_page=mm_page_align_down(address);

    mmflags=mmCriticalEnter();
    m=mm_process_find_containing_nolock(pid,user_page);
    if(m==NULL || !m->demand || m->page_array==0 || m->kernel_address==0) {
        mmCriticalLeave(mmflags); return 0;
    }
    prot=m->prot;
    /* Only not-present faults are demand candidates.  Protection violations
     * must retain the normal exception/kill path. */
    if((error&1U) || prot==PROT_NONE || ((error&2U) && !(prot&PROT_WRITE))) {
        mmCriticalLeave(mmflags); return 0;
    }
    page_index=(user_page-m->user_address)/PAGESIZE;
    aliases=(DWORD *)m->page_array;
    if(aliases[page_index]) { mmCriticalLeave(mmflags); return 1; }
    kernel_alias=m->kernel_address+page_index*PAGESIZE;
    reservation_id=m->reservation_id;
    mmCriticalLeave(mmflags);

    /* Prefer the order-0 buddy page pool; retain legacy kmalloc as a safe
     * fallback so demand paging cannot exhaust the small experimental arena. */
    fresh=mm_buddy_alloc_zero(0);
    if(fresh!=NULL)
        physical=mm_buddy_virtual_to_physical(fresh);
    else {
        fresh=_kmalloc(PAGESIZE,pid,"demand-zero page");
        if(fresh!=NULL) memset(fresh,0,PAGESIZE);
        physical=fresh ? (GetPage(((DWORD)fresh)/PAGESIZE)&0xfffff000UL) : 0;
    }
    if(fresh==NULL || physical<PG_STRUCTURES_PHYS_END) {
        mm_demand_page_discard(fresh); demand_fault_failures++; return 0;
    }

    mmflags=mmCriticalEnter();
    m=mm_process_find_containing_nolock(pid,user_page);
    if(m==NULL || !m->demand || m->reservation_id!=reservation_id ||
       m->page_array!=(DWORD)aliases || m->kernel_address+page_index*PAGESIZE!=kernel_alias) {
        mmCriticalLeave(mmflags); mm_demand_page_discard(fresh); return 0;
    }
    if(aliases[page_index]) {
        mmCriticalLeave(mmflags); mm_demand_page_discard(fresh); return 1;
    }
    if(pg_map_reserved_page(kernel_alias,physical)!=0) {
        mmCriticalLeave(mmflags); mm_demand_page_discard(fresh); demand_fault_failures++; return 0;
    }
    table=mm_process_page_table(pid);
    if(table==NULL) {
        (void)pg_release_virtual(kernel_alias,1);
        mmCriticalLeave(mmflags); mm_demand_page_discard(fresh); demand_fault_failures++; return 0;
    }
    table[(user_page-MM_USER_BASE)/PAGESIZE]=physical|mm_pte_flags_from_prot(prot);
    aliases[page_index]=(DWORD)fresh;
    if(mm_buddy_owns(fresh)) (void)mm_charge_process_pages(pid,1);
    demand_pages_live++;
    demand_faults_handled++;
    mmCriticalLeave(mmflags);
    mm_process_invalidate(pid,user_page,PAGESIZE);
    return 1;
}

static int mm_demand_populate_range(int pid,DWORD address,DWORD length)
{
    DWORD first,last,p;
    if(length==0) return -1;
    first=mm_page_align_down(address);
    if(address>0xffffffffUL-(length-1U)) return -1;
    last=mm_page_align_down(address+length-1U);
    for(p=first;;p+=PAGESIZE) {
        /* Each page performs a fresh registry/token lookup.  This avoids
         * holding a raw mapping pointer across _kmalloc() or teardown. */
        if(!mm_demand_populate_page(pid,p,0)) return -1;
        if(p==last) break;
        if(p>0xffffffffUL-PAGESIZE) return -1;
    }
    return 0;
}

int mm_handle_page_fault(DWORD fault_address,DWORD error_code)
{
    int pid=GetCurrentThread();
    int handled;
    /* Never recurse through demand paging or COW.  In particular a fault in
     * the page-copy/allocator path must fail closed instead of consuming a
     * second exception frame and corrupting reference ownership. */
    if(__sync_lock_test_and_set(&demand_pf_active,1U)!=0U) {
        demand_pf_nested_latched=1U;
        __sync_add_and_fetch(&demand_fault_nested,1U);
        return 0;
    }
    handled=mm_cow_handle_fault(pid,fault_address,error_code);
    if(handled) {
        __sync_lock_release(&demand_pf_active);
        return 1;
    }
    handled=mm_sparse_handle_fault(pid,fault_address,error_code);
    if(handled) {
        __sync_lock_release(&demand_pf_active);
        return 1;
    }
    /* Explicit MAP_JTMOS_DEMAND remains Ring-3-only.  Generic sparse
     * first-touch above is allowed for both kernel aliases and user pages. */
    if((error_code&4U)==0 || (error_code&8U)!=0) {
        __sync_lock_release(&demand_pf_active);
        return 0;
    }
    handled=mm_demand_populate_page(pid,fault_address,error_code);
    __sync_lock_release(&demand_pf_active);
    return handled;
}

int mm_prepare_kernel_copy_range(const void *address,DWORD length)
{
    DWORD start=(DWORD)address;
    DWORD page,last,pte;

    if(length==0 || start>0xffffffffUL-(length-1UL)) return 0;
    page=mm_page_align_down(start);
    last=mm_page_align_down(start+length-1UL);
    for(;;)
    {
        pte=GetPage(page/PAGESIZE);
        if(!(pte&1U))
        {
            /* Only a registered sparse alias with a reserved PTE may be
             * materialized.  The pager rejects a freed or foreign hole. */
            if(!(pte&MM_USER_PTE_SOFT_RESERVED) ||
               !mm_handle_page_fault(page,0) ||
               !(GetPage(page/PAGESIZE)&1U)) return 0;
        }
        if(page==last) return 1;
        page+=PAGESIZE;
    }
}

int mm_page_fault_context_nested(void)
{
    return demand_pf_nested_latched ? 1 : 0;
}

void mm_page_fault_context_reset(void)
{
    /* Called by the fatal/containment path before abandoning a fault frame.
     * This also clears guards left set if the pager itself faulted. */
    demand_pf_active=0;
    demand_pf_nested_latched=0;
}

void mm_get_demand_stats(MM_DEMAND_STATS *out)
{
    DWORD flags;
    if(!out) return;
    flags=mmCriticalEnter();
    out->faults_handled=demand_faults_handled;
    out->pages_live=demand_pages_live;
    out->fault_failures=demand_fault_failures;
    out->nested_faults=demand_fault_nested;
    out->sparse_faults_handled=sparse_lazy_faults_handled;
    out->sparse_pages_live=sparse_lazy_pages_live;
    out->sparse_virtual_only_pages=sparse_virtual_only_pages;
    out->sparse_fault_failures=sparse_lazy_fault_failures;
    mmCriticalLeave(flags);
}

void mm_get_cow_stats(MM_COW_STATS *out)
{
    DWORD flags;
    if(!out) return;
    flags=mmCriticalEnter();
    out->faults_handled=cow_faults_handled;
    out->pages_copied=cow_pages_copied;
    out->exclusive_reuses=cow_exclusive_reuses;
    out->fault_failures=cow_fault_failures;
    out->shared_pages=cow_shared_pages;
    out->tracked_references=cow_tracked_references;
    mmCriticalLeave(flags);
}

void *mm_process_mmap_anon(int pid, DWORD requested_address, DWORD length,
                           int prot, int flags, DWORD low)
{
    DWORD bytes;
    DWORD user_address;
    DWORD reservation_id;
    DWORD mmflags;
    void *backing;
    MM_PROCESS_MAPPING *slot;
    int fixed;
    int map_rv;

    if(!mm_process_pid_ok(pid) || length==0 || !mmap_valid_prot(prot))
        return NULL;
    if((flags&MAP_ANONYMOUS)==0 || (flags&MAP_PRIVATE)==0 || (flags&MAP_SHARED))
        return NULL;

    bytes=mm_page_align_up(length);
    if(bytes==0 || bytes>MM_USER_SIZE)
        return NULL;
    if(low<MM_USER_BASE) low=MM_USER_BASE;
    low=mm_page_align_up(low);
    if(low>=MM_USER_TOP || bytes>MM_USER_TOP-low)
        return NULL;

    /* Lazily provision the per-PID registry outside the reservation critical
     * section.  Only the pointer table itself remains in fixed kernel BSS. */
    if(mm_process_registry_ensure_free_slot(pid)!=0)
        return NULL;

    /* Atomically claim a registry slot and the user VA range.  No PTE is
     * installed yet; RESERVED metadata makes the range unavailable to another
     * mmap while the potentially slow sparse backing allocation runs. */
    mmflags=mmCriticalEnter();
    slot=mm_process_free_slot_nolock(pid);
    if(slot==NULL)
    {
        mmCriticalLeave(mmflags);
        return NULL;
    }

    fixed=(flags&(MAP_FIXED|MAP_FIXED_NOREPLACE))!=0;
    user_address=0;
    if(requested_address)
    {
        if((requested_address&MM_PAGE_MASK)==0 && requested_address>=low &&
           requested_address<=MM_USER_TOP-bytes &&
           mm_process_range_available_nolock(pid,requested_address,bytes))
            user_address=requested_address;
        else if(fixed)
        {
            mmCriticalLeave(mmflags);
            return NULL;
        }
    }
    if(user_address==0)
        user_address=mm_process_find_free_range_nolock(pid,bytes,low,MM_USER_TOP);
    if(user_address==0)
    {
        mmCriticalLeave(mmflags);
        return NULL;
    }

    if(mm_process_mark_reserved_nolock(pid,user_address,bytes)!=0)
    {
        mmCriticalLeave(mmflags);
        return NULL;
    }
    reservation_id=mm_process_next_reservation_nolock();
    memset(slot,0,sizeof(*slot));
    slot->state=MM_PROCESS_MAP_RESERVED;
    slot->reservation_id=reservation_id;
    slot->user_address=user_address;
    slot->length=bytes;
    slot->prot=prot;
    slot->flags=flags;
    mmCriticalLeave(mmflags);

    if(flags&MAP_JTMOS_DEMAND)
    {
        DWORD pages=bytes/PAGESIZE;
        DWORD kernel_reservation;
        DWORD *aliases;

        {
            DWORD alias_bytes=pages*sizeof(DWORD);
            /* Small demand-mapping metadata is a real slab consumer.  Larger
             * alias arrays keep using legacy kmalloc until slab gains large
             * object support. */
            aliases=NULL;
            if(alias_bytes<=1024U) aliases=(DWORD *)mm_slab_alloc(alias_bytes);
            if(aliases==NULL) aliases=(DWORD *)_kmalloc((int)alias_bytes,0,"demand page aliases");
            if(aliases==NULL) { mm_process_cancel_reservation(pid,slot,reservation_id); return NULL; }
            memset(aliases,0,alias_bytes);
        }
        kernel_reservation=pg_reserve_virtual((int)pages);
        if(kernel_reservation==0) { mm_demand_alias_array_free(aliases); mm_process_cancel_reservation(pid,slot,reservation_id); return NULL; }

        mmflags=mmCriticalEnter();
        if(slot->state!=MM_PROCESS_MAP_RESERVED || slot->reservation_id!=reservation_id ||
           slot->user_address!=user_address || slot->length!=bytes)
        {
            mmCriticalLeave(mmflags);
            (void)pg_release_virtual(kernel_reservation,(int)pages);
            mm_demand_alias_array_free(aliases);
            return NULL;
        }
        slot->kernel_address=kernel_reservation;
        slot->page_array=(DWORD)aliases;
        slot->demand=1;
        slot->state=MM_PROCESS_MAP_ACTIVE;
        mmCriticalLeave(mmflags);
        (void)mm_charge_process_virtual(pid,(int)pages);
        mm_process_invalidate(pid,user_address,bytes);
        return (void *)user_address;
    }

    backing=mm_sparse_alloc(bytes,pid,"process mmap");
    if(backing==NULL)
    {
        mm_process_cancel_reservation(pid,slot,reservation_id);
        return NULL;
    }

    /* Commit PTEs and metadata under the same MM critical section.  Teardown
     * may have cancelled this reservation while backing was allocated; token
     * validation prevents that stale operation from publishing into a reused
     * slot. */
    mmflags=mmCriticalEnter();
    if(slot->state!=MM_PROCESS_MAP_RESERVED ||
       slot->reservation_id!=reservation_id ||
       slot->user_address!=user_address || slot->length!=bytes)
    {
        mmCriticalLeave(mmflags);
        mm_sparse_free(backing,bytes);
        return NULL;
    }

    map_rv=mm_map_process_range(pid,user_address,backing,bytes,prot);
    if(map_rv!=0)
    {
        mm_process_clear_reserved_nolock(pid,user_address,bytes);
        memset(slot,0,sizeof(*slot));
        mmCriticalLeave(mmflags);
        mm_sparse_free(backing,bytes);
        return NULL;
    }

    slot->kernel_address=(DWORD)backing;
    slot->state=MM_PROCESS_MAP_ACTIVE;
    mmCriticalLeave(mmflags);
    (void)mm_charge_process_virtual(pid,(int)(bytes/PAGESIZE));

    mm_process_invalidate(pid,user_address,bytes);
    return (void *)user_address;
}

int mm_process_munmap(int pid, DWORD user_address, DWORD length)
{
    MM_PROCESS_MAPPING *m;
    DWORD bytes;
    DWORD backing;
    DWORD mapped_address;
    DWORD mapped_length;
    DWORD page_array;
    int demand;
    DWORD mmflags;

    if(!mm_process_pid_ok(pid) || user_address==0 ||
       (user_address&MM_PAGE_MASK) || length==0)
        return -1;
    bytes=mm_page_align_up(length);
    if(bytes==0)
        return -1;

    mmflags=mmCriticalEnter();
    m=mm_process_find_active_nolock(pid,user_address);
    if(m==NULL || m->length!=bytes)
    {
        mmCriticalLeave(mmflags);
        return -1;
    }

    /* REMOVING makes a second munmap/translate fail before the PTEs/backing
     * can be touched twice. */
    m->state=MM_PROCESS_MAP_REMOVING;
    backing=m->kernel_address;
    mapped_address=m->user_address;
    mapped_length=m->length;
    page_array=m->page_array;
    demand=m->demand;
    if(mm_unmap_process_range(pid,mapped_address,mapped_length)!=0)
    {
        m->state=MM_PROCESS_MAP_ACTIVE;
        mmCriticalLeave(mmflags);
        return -1;
    }
    memset(m,0,sizeof(*m));
    mmCriticalLeave(mmflags);

    mm_process_invalidate(pid,mapped_address,mapped_length);
    (void)mm_charge_process_virtual(pid,-(int)(mapped_length/PAGESIZE));
    if(demand) { mm_demand_release(pid,backing,bytes,page_array); return 0; }
    return mm_sparse_free((void *)backing,bytes);
}

DWORD mm_translate_process_mapping(int pid, DWORD user_address, DWORD length)
{
    MM_PROCESS_MAPPING_BLOCK *b;
    MM_PROCESS_MAPPING *m;
    DWORD offset,result=0,mmflags;
    int i,demand=0;
    if(!mm_process_pid_ok(pid) || length==0) return 0;
    mmflags=mmCriticalEnter();
    for(b=process_mmaps[pid];b && !result;b=b->next)
        for(i=0;i<MM_PROCESS_MMAP_SLOTS;i++)
        {
            m=&b->slots[i];
            if(m->state!=MM_PROCESS_MAP_ACTIVE || user_address<m->user_address) continue;
            offset=user_address-m->user_address;
            if(offset<m->length && length<=m->length-offset)
            { result=m->kernel_address+offset; demand=m->demand; break; }
        }
    mmCriticalLeave(mmflags);
    if(result && demand && mm_demand_populate_range(pid,user_address,length)!=0) return 0;
    return result;
}


void mm_release_process_mappings(int pid)
{
    MM_PROCESS_MAPPING_BLOCK *b;
    MM_PROCESS_MAPPING *m;
    DWORD backing,bytes,address,page_array,mmflags;
    int i,have_backing,demand;
    if(!mm_process_pid_ok(pid)) return;

    for(b=process_mmaps[pid];b;b=b->next)
        for(i=0;i<MM_PROCESS_MMAP_SLOTS;i++)
        {
            backing=bytes=address=page_array=0;
            have_backing=0; demand=0;
            mmflags=mmCriticalEnter();
            m=&b->slots[i];
            if(m->state==MM_PROCESS_MAP_FREE)
            { mmCriticalLeave(mmflags); continue; }
            if(m->state==MM_PROCESS_MAP_RESERVED)
            {
                mm_process_clear_reserved_nolock(pid,m->user_address,m->length);
                memset(m,0,sizeof(*m));
                mmCriticalLeave(mmflags);
                continue;
            }
            if(m->state==MM_PROCESS_MAP_ACTIVE)
            {
                m->state=MM_PROCESS_MAP_REMOVING;
                backing=m->kernel_address; bytes=m->length; address=m->user_address;
                page_array=m->page_array; demand=m->demand;
                have_backing=backing!=0 && bytes!=0;
                (void)mm_unmap_process_range(pid,address,bytes);
                memset(m,0,sizeof(*m));
            }
            else memset(m,0,sizeof(*m));
            mmCriticalLeave(mmflags);
            if(have_backing)
            {
                mm_process_invalidate(pid,address,bytes);
                (void)mm_charge_process_virtual(pid,-(int)(bytes/PAGESIZE));
                if(demand) mm_demand_release(pid,backing,bytes,page_array);
                else (void)mm_sparse_free((void *)backing,bytes);
            }
        }
}


int mm_clone_process_mappings(int parent_pid, int child_pid)
{
    MM_PROCESS_MAPPING_BLOCK *b;
    MM_PROCESS_MAPPING *src,*dst;
    DWORD src_user,src_kernel,src_length,reservation_id,mmflags;
    int src_prot,src_flags,src_demand,map_rv,i,use_cow;
    void *backing;

    if(!mm_process_pid_ok(parent_pid) || !mm_process_pid_ok(child_pid)) return -1;
    if(process_mmaps[parent_pid]==NULL) return 0;
    if(mm_process_registry_ensure_free_slot(child_pid)!=0) return -1;

    for(b=process_mmaps[parent_pid];b;b=b->next)
        for(i=0;i<MM_PROCESS_MMAP_SLOTS;i++)
        {
            mmflags=mmCriticalEnter();
            src=&b->slots[i];
            if(src->state!=MM_PROCESS_MAP_ACTIVE)
            { mmCriticalLeave(mmflags); continue; }
            src_user=src->user_address; src_kernel=src->kernel_address;
            src_length=src->length; src_prot=src->prot; src_flags=src->flags;
            src_demand=src->demand;
            mmCriticalLeave(mmflags);

            if(src_demand)
            {
                if(mm_demand_populate_range(parent_pid,src_user,src_length)!=0) goto fail;
                src_flags&=~MAP_JTMOS_DEMAND;
            }
            use_cow=!src_demand;
            if(mm_process_registry_ensure_free_slot(child_pid)!=0) goto fail;

            mmflags=mmCriticalEnter();
            src=&b->slots[i];
            if(src->state!=MM_PROCESS_MAP_ACTIVE || src->user_address!=src_user ||
               src->length!=src_length)
            { mmCriticalLeave(mmflags); goto fail; }
            src_kernel=src->kernel_address;
            dst=mm_process_free_slot_nolock(child_pid);
            if(dst==NULL || !mm_process_range_available_nolock(child_pid,src_user,src_length))
            { mmCriticalLeave(mmflags); goto fail; }
            if(mm_process_mark_reserved_nolock(child_pid,src_user,src_length)!=0)
            { mmCriticalLeave(mmflags); goto fail; }
            reservation_id=mm_process_next_reservation_nolock();
            memset(dst,0,sizeof(*dst));
            dst->state=MM_PROCESS_MAP_RESERVED; dst->reservation_id=reservation_id;
            dst->user_address=src_user; dst->length=src_length;
            dst->prot=src_prot; dst->flags=src_flags;
            mmCriticalLeave(mmflags);

            if(use_cow)
                backing=mm_sparse_clone_cow((void *)src_kernel,src_length,
                                             child_pid,"fork mmap COW");
            else
                backing=mm_sparse_alloc(src_length,child_pid,"fork demand mmap");
            if(backing==NULL)
            { mm_process_cancel_reservation(child_pid,dst,reservation_id); goto fail; }
            /* MAP_JTMOS_DEMAND keeps its existing eager snapshot fallback:
             * populated demand pages do not use sparse ownership descriptors.
             * Ordinary private mmap regions share every page through COW. */
            if(!use_cow) memcpy(backing,(void *)src_kernel,src_length);

            mmflags=mmCriticalEnter();
            if(dst->state!=MM_PROCESS_MAP_RESERVED || dst->reservation_id!=reservation_id ||
               dst->user_address!=src_user || dst->length!=src_length)
            {
                mmCriticalLeave(mmflags); mm_sparse_free(backing,src_length); goto fail;
            }
            if(use_cow)
                map_rv=mm_clone_process_range_cow(parent_pid,child_pid,
                         src_user,(void *)src_kernel,backing,src_length);
            else
                map_rv=mm_map_process_range(child_pid,src_user,backing,
                                             src_length,src_prot);
            if(map_rv!=0)
            {
                mm_process_clear_reserved_nolock(child_pid,src_user,src_length);
                memset(dst,0,sizeof(*dst)); mmCriticalLeave(mmflags);
                mm_sparse_free(backing,src_length); goto fail;
            }
            dst->kernel_address=(DWORD)backing; dst->state=MM_PROCESS_MAP_ACTIVE;
            mmCriticalLeave(mmflags);
            (void)mm_charge_process_virtual(child_pid,(int)(src_length/PAGESIZE));
            mm_process_invalidate(child_pid,src_user,src_length);
        }
    return 0;
fail:
    mm_release_process_mappings(child_pid);
    return -1;
}
