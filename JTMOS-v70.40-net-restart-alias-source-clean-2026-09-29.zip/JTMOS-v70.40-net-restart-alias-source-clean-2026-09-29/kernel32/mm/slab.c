/* slab.c - V68.215 elementary fixed-size kernel object caches. */
#include <stdio.h>
#include "mm.h"
#include "buddy.h"
#include "slab.h"

#define SLAB_MAGIC 0x534C4142UL /* SLAB */
#define SLAB_DATA_OFFSET 64U
#define SLAB_BITMAP_WORDS 4

typedef struct slab_page {
    DWORD magic;
    struct slab_page *next;
    WORD object_size;
    WORD capacity;
    WORD inuse;
    WORD hint;
    BYTE cache_index;
    BYTE reserved[3];
    DWORD bitmap[SLAB_BITMAP_WORDS];
} SLAB_PAGE;
typedef char slab_header_must_fit_data_offset[(sizeof(SLAB_PAGE)<=SLAB_DATA_OFFSET)?1:-1];

typedef struct {
    WORD object_size;
    SLAB_PAGE *pages;
    DWORD page_count;
    DWORD inuse;
} SLAB_CACHE;

static const WORD slab_sizes[MM_SLAB_CACHE_COUNT]={32,64,128,256,512,1024};
static SLAB_CACHE slab_caches[MM_SLAB_CACHE_COUNT];
static int slab_enabled;
static DWORD slab_allocations,slab_frees,slab_failures;

static int slab_bit_test(SLAB_PAGE *p,int n)
{ return (p->bitmap[n>>5]&(1UL<<(n&31)))!=0; }
static void slab_bit_set(SLAB_PAGE *p,int n)
{ p->bitmap[n>>5]|=(1UL<<(n&31)); }
static void slab_bit_clear(SLAB_PAGE *p,int n)
{ p->bitmap[n>>5]&=~(1UL<<(n&31)); }

int mm_slab_ready(void)
{
    return slab_enabled;
}

int mm_slab_init(void)
{
    int i;
    if(slab_enabled) return 0;
    if(mm_buddy_init()!=0) return -1;
    memset(slab_caches,0,sizeof(slab_caches));
    for(i=0;i<MM_SLAB_CACHE_COUNT;i++) slab_caches[i].object_size=slab_sizes[i];
    slab_allocations=slab_frees=slab_failures=0;
    slab_enabled=1;
    dprintk("slab: caches 32/64/128/256/512/1024 bytes enabled.\n");
    return 0;
}

static int slab_cache_for_size(size_t size)
{
    int i;
    for(i=0;i<MM_SLAB_CACHE_COUNT;i++) if(size<=slab_sizes[i]) return i;
    return -1;
}

static SLAB_PAGE *slab_new_page(int cache_index)
{
    SLAB_PAGE *p;
    SLAB_CACHE *c=&slab_caches[cache_index];
    DWORD cap=(PAGESIZE-SLAB_DATA_OFFSET)/c->object_size;
    if(cap>SLAB_BITMAP_WORDS*32U) cap=SLAB_BITMAP_WORDS*32U;
    if(cap==0) return NULL;
    p=(SLAB_PAGE *)mm_buddy_alloc_zero(0);
    if(!p) return NULL;
    p->magic=SLAB_MAGIC;
    p->object_size=c->object_size;
    p->capacity=(WORD)cap;
    p->cache_index=(BYTE)cache_index;
    p->next=c->pages;
    c->pages=p;
    c->page_count++;
    return p;
}

void *mm_slab_alloc(size_t size)
{
    int ci,i,start;
    SLAB_CACHE *c;
    SLAB_PAGE *p;
    DWORD flags;
    BYTE *result=NULL;
    if(!slab_enabled && mm_slab_init()!=0) return NULL;
    if(size==0) size=1;
    ci=slab_cache_for_size(size);
    if(ci<0) { slab_failures++; return NULL; }
    flags=mmCriticalEnter();
    c=&slab_caches[ci];
    for(p=c->pages;p;p=p->next) if(p->inuse<p->capacity) break;
    if(!p) p=slab_new_page(ci);
    if(!p) { slab_failures++; mmCriticalLeave(flags); return NULL; }
    start=p->hint;
    for(i=0;i<p->capacity;i++) {
        int n=(start+i)%p->capacity;
        if(!slab_bit_test(p,n)) {
            slab_bit_set(p,n); p->inuse++; c->inuse++;
            p->hint=(WORD)((n+1)%p->capacity);
            result=(BYTE *)p+SLAB_DATA_OFFSET+(DWORD)n*p->object_size;
            memset(result,0,p->object_size);
            slab_allocations++;
            break;
        }
    }
    if(!result) slab_failures++;
    mmCriticalLeave(flags);
    return result;
}

int mm_slab_owns(const void *ptr)
{
    DWORD base;
    SLAB_PAGE *p;
    if(!slab_enabled || ptr==NULL || !mm_buddy_owns(ptr)) return 0;
    base=((DWORD)ptr)&~(PAGESIZE-1UL);
    p=(SLAB_PAGE *)base;
    return p->magic==SLAB_MAGIC && p->cache_index<MM_SLAB_CACHE_COUNT;
}

int mm_slab_free(void *ptr)
{
    DWORD base,off;
    int n,ci;
    SLAB_PAGE *p,*cur,*prev;
    SLAB_CACHE *c;
    DWORD flags;
    if(!mm_slab_owns(ptr)) return -1;
    flags=mmCriticalEnter();
    base=((DWORD)ptr)&~(PAGESIZE-1UL);
    p=(SLAB_PAGE *)base;
    ci=p->cache_index; c=&slab_caches[ci];
    off=(DWORD)ptr-base;
    if(off<SLAB_DATA_OFFSET || (off-SLAB_DATA_OFFSET)%p->object_size) {
        mmCriticalLeave(flags); return -1;
    }
    n=(int)((off-SLAB_DATA_OFFSET)/p->object_size);
    if(n<0 || n>=p->capacity || !slab_bit_test(p,n)) {
        mmCriticalLeave(flags); return -1;
    }
    slab_bit_clear(p,n); p->inuse--; c->inuse--; p->hint=(WORD)n; slab_frees++;

    /* Keep one empty page warm per cache, return additional empty slabs to
     * the buddy allocator so small-object bursts do not permanently pin RAM. */
    if(p->inuse==0) {
        int other_empty=0;
        for(cur=c->pages;cur;cur=cur->next) if(cur!=p && cur->inuse==0) { other_empty=1; break; }
        if(other_empty) {
            prev=NULL; cur=c->pages;
            while(cur && cur!=p) { prev=cur; cur=cur->next; }
            if(cur==p) {
                if(prev) prev->next=p->next; else c->pages=p->next;
                c->page_count--; p->magic=0;
                (void)mm_buddy_free(p);
            }
        }
    }
    mmCriticalLeave(flags);
    return 0;
}

void mm_slab_get_stats(MM_SLAB_STATS *out)
{
    DWORD flags,pages=0,inuse=0;
    int i;
    if(!out) return;
    flags=mmCriticalEnter();
    for(i=0;i<MM_SLAB_CACHE_COUNT;i++) { pages+=slab_caches[i].page_count; inuse+=slab_caches[i].inuse; }
    memset(out,0,sizeof(*out)); out->enabled=slab_enabled; out->pages=pages;
    out->objects_inuse=inuse; out->allocations=slab_allocations; out->frees=slab_frees; out->failures=slab_failures;
    mmCriticalLeave(flags);
}

void mm_slab_dump(void)
{
    int i;
    WORD sizes[MM_SLAB_CACHE_COUNT];
    DWORD pages[MM_SLAB_CACHE_COUNT],objects[MM_SLAB_CACHE_COUNT];
    DWORD flags=mmCriticalEnter();
    /* Never printf while the MM lock/IRQ critical section is held. */
    for(i=0;i<MM_SLAB_CACHE_COUNT;i++) {
        sizes[i]=slab_caches[i].object_size;
        pages[i]=slab_caches[i].page_count;
        objects[i]=slab_caches[i].inuse;
    }
    mmCriticalLeave(flags);
    printf("Slab cache   pages  objects\n");
    for(i=0;i<MM_SLAB_CACHE_COUNT;i++)
        printf("%4u bytes %6u %8u\n",(unsigned)sizes[i],
               (unsigned)pages[i],(unsigned)objects[i]);
}
