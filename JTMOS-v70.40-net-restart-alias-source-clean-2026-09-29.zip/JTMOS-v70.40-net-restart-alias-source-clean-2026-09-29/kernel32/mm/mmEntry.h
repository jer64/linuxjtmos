#ifndef __INCLUDED_MMENTRY_H__
#define __INCLUDED_MMENTRY_H__

#include <stdio.h>
#include "mm.h"

MD *mmGiveMD(void *ptr);
MD *mmGetNewEntry(void);
MD *mmNewEntry(void);
MD *mmFindFreeEntry(void);
MD *mmAddEntry(int sp, int pages, int bytes);
void mmRemoveEntry(MD *m);
void mmEntryResetIndex(void);
void mmIndexEntry(MD *m);
void mmUnindexEntry(MD *m);
MD *mmFindOwnedEntry(int pid);
int mmCountActiveEntries(void);
DWORD mmCountSparseEntries(void);
int GetChunkOwner(void *p);
MD *mmDetermineOwner(void *p);

#endif
