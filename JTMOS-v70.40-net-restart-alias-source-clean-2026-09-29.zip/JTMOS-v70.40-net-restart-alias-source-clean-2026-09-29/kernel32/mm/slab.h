#ifndef JTMOS_MM_SLAB_H
#define JTMOS_MM_SLAB_H

#include <stddef.h>

#define MM_SLAB_CACHE_COUNT 6

typedef struct {
    int enabled;
    DWORD pages;
    DWORD objects_inuse;
    DWORD allocations;
    DWORD frees;
    DWORD failures;
} MM_SLAB_STATS;

int mm_slab_init(void);
int mm_slab_ready(void);
void *mm_slab_alloc(size_t size);
int mm_slab_free(void *ptr);
int mm_slab_owns(const void *ptr);
void mm_slab_get_stats(MM_SLAB_STATS *out);
void mm_slab_dump(void);

#endif
