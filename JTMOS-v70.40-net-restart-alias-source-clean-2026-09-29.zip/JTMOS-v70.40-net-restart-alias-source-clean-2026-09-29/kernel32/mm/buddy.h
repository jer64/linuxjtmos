#ifndef JTMOS_MM_BUDDY_H
#define JTMOS_MM_BUDDY_H

#include <stddef.h>

#define MM_BUDDY_MAX_ORDER 14

typedef struct {
    int enabled;
    int max_order;
    DWORD pool_pages;
    DWORD free_pages;
    DWORD physical_start;
    DWORD virtual_start;
    DWORD allocations;
    DWORD frees;
    DWORD failed_allocations;
} MM_BUDDY_STATS;

/* V70: primary page-oriented allocator. Legacy kmalloc remains as a
 * compatibility path for arbitrary contiguous byte allocations, while sparse,
 * demand and slab page consumers prefer this buddy arena. */
int mm_buddy_init(void);
void *mm_buddy_alloc_order(int order);
void *mm_buddy_alloc_zero(int order);
int mm_buddy_free(void *ptr);
int mm_buddy_owns(const void *ptr);
DWORD mm_buddy_virtual_to_physical(const void *ptr);
void *mm_buddy_physical_to_virtual(DWORD physical);
void mm_buddy_get_stats(MM_BUDDY_STATS *out);

#endif
