#ifndef __INCLUDED_MM_H__
#define __INCLUDED_MM_H__

/* Historical high alias retained as an ABI/source constant only.
 * Since V67.8.31 the kernel MM database is identity-mapped at its physical
 * backing address during bootstrap; allocator code does not use this alias. */
#define MAPAD_MM_DB             0xF2000000

#include <stdio.h>

// To debug or not to debug
//#define MMPRINT               printk
#define MMPRINT                 //

// Page size for IA-32 JTMOS.
#define PAGESIZE                4096

// Allocation database backing store. The database contains the descriptor
// pointer array, descriptors themselves and a 4 GB / 4 KB free-page bitmap.
/* The allocation DB grows with detected RAM.  One MiB remains the historical
 * minimum for small machines; mmInit() computes the actual page-aligned size. */
#define ALLOCATION_DATABASE_MIN_SIZE (1024*1024*1)
#define ALLOCATION_DATABASE_SIZE     ALLOCATION_DATABASE_MIN_SIZE /* legacy minimum */
#define MM_BITMAP_PAGES             (1024*1024)
#define MM_BITMAP_BYTES             (MM_BITMAP_PAGES/8)

// Virtual allocation-database mapping bounds (legacy exported names).
extern char *MSTART,*MEND,*REND;

// Memory Descriptor (MD)
#define MM_MD_KIND_CONTIG 0
#define MM_MD_KIND_SPARSE 1
typedef struct
{
    // INFO REGION
    // Physical beginning of the region.
    char *p;
    // Process ID of the process which owns this memory region.
    int PID;
    // Physical start page for the region.
    int page;
    // Length of the region in pages.
    int pages;
    // Allocated length of the region in bytes (page rounded).
    int bytes;
    // 1 = descriptor slot is free, 0 = descriptor is in use.
    int isFree;

    // Linear address where the memory is mapped.
    DWORD mapad;

    /* V69.68: one sparse descriptor can own a vector of independently
     * allocated physical pages while presenting one contiguous kernel VA. */
    int kind;
    DWORD *page_vector;
    int page_vector_count;
    /* V70 overflow descriptors are allocated from slab after bootstrap. */
    int dynamic_slot;
    void *all_next;

    /* V69.67 allocator indexes.  free_next is valid only while isFree=1;
     * hash_next links active descriptors sharing one map-address bucket. */
    void *free_next;
    void *hash_next;

    // DEBUG REGION
    char name[20];
} MD;

typedef struct
{
    // PTRs to the descriptors of allocated/free descriptor slots.
    MD **allocated;
    // High-water mark: number of descriptor slots introduced into the table.
    int n_allocated;
    // Maximum number of descriptor slots available in the DB.
    int max_allocated;
    // Physical free-page bitmap; one bit represents one 4 KB page.
    BYTE *bitmap;
    int l_bitmap;
    /* Head of recycled descriptor slots. New high-water slots are introduced
     * only when this list is empty. */
    MD *free_head;
} MM;
extern MM mm;
extern MM *p_mm;
extern char *phMSTART,*phMEND,*phREND;

extern int mallocOK;
extern int mm_debug;

typedef struct
{
    DWORD total_bytes;
    DWORD free_bytes;              /* effective legacy + buddy free */
    DWORD allocated_bytes;
    int descriptors_active;
    int descriptors_highwater;
    int descriptors_capacity;
    /* V69.69 detailed allocator telemetry. */
    DWORD legacy_free_bytes;
    DWORD buddy_pool_bytes;
    DWORD buddy_free_bytes;
    DWORD slab_pages;
    DWORD slab_objects_inuse;
    DWORD sparse_regions;
    DWORD process_resident_pages;
    DWORD process_virtual_pages;
} MM_MEMORY_STATS;

typedef struct
{
    DWORD resident_pages;
    DWORD virtual_pages;
    DWORD peak_resident_pages;
    DWORD peak_virtual_pages;
    DWORD resident_alloc_events;
    DWORD resident_free_events;
} MM_PROCESS_MEMORY_STATS;

/* V68.215: elementary demand-paging accounting.  This is intentionally
 * separate from the legacy allocator statistics: a reserved anonymous mmap
 * consumes virtual address space immediately but physical pages only on #PF. */
typedef struct
{
    DWORD faults_handled;
    DWORD pages_live;
    DWORD fault_failures;
    DWORD nested_faults;
    /* V70.10 generic sparse first-touch pool. */
    DWORD sparse_faults_handled;
    DWORD sparse_pages_live;
    DWORD sparse_virtual_only_pages;
    DWORD sparse_fault_failures;
} MM_DEMAND_STATS;

/* V70.9: fork() copy-on-write accounting.  IA-32 software bit 9 marks a
 * present read-only PTE as COW; the same bit remains the historical
 * non-present reservation marker when Present=0. */
#define MM_PTE_COW 0x200UL
typedef struct
{
    DWORD faults_handled;
    DWORD pages_copied;
    DWORD exclusive_reuses;
    DWORD fault_failures;
    DWORD shared_pages;
    DWORD tracked_references;
} MM_COW_STATS;

DWORD malloc_getmemorytotal(void);
void mm_get_memory_stats(MM_MEMORY_STATS *stats);
void mm_get_process_memory_stats(int pid, MM_PROCESS_MEMORY_STATS *stats);
int mm_charge_process_pages(int pid, int pages);
int mm_charge_process_virtual(int pid, int pages);

// Core functions.
void mmInit(void *region, int length);
void mm_Diagnostics(void);
void ShowPageMap(void);
void MMPANIC(const char *msg);

/*
 * Single-CPU MM critical section.  Enter leaves interrupts disabled until the
 * matching leave.  Nested callers are safe because each level restores the
 * EFLAGS value it observed on entry.  Memory allocator code must not yield or
 * perform a task switch while this section is active.
 */
DWORD mmCriticalEnter(void);
void mmCriticalLeave(DWORD flags);

#include "mmBit.h"
#include "mmEntry.h"
#include "paging.h"


/* ------------------------------------------------------------------
 * ELF32 application address-space helpers.
 * One application owns a 16 MiB window beginning at 0x80000000.
 * ------------------------------------------------------------------ */
#define MM_PAGE_SIZE       PAGESIZE
#define MM_USER_BASE       0x80000000UL
#define MM_USER_PAGES      4096UL
#define MM_USER_SIZE       (MM_USER_PAGES * PAGESIZE)
#define MM_USER_TOP        (MM_USER_BASE + MM_USER_SIZE)
#define MM_PAGE_MASK       (PAGESIZE - 1UL)

/* Each process owns one 16 MiB / 4096-entry PTE array. On IA-32 a PTE is
 * exactly four bytes. Four MiB at PG_USER_PAGE_TABLES_PHYS provides 256 slots,
 * enough for the kernel's N_MAX_THREADS=250 configuration. */
#define MM_IA32_PTE_BYTES              4UL
#define MM_PROCESS_PAGE_TABLE_BYTES    (MM_USER_PAGES * MM_IA32_PTE_BYTES)
#define MM_PROCESS_PAGE_TABLE_CAPACITY (PG_USER_PAGE_TABLES_BYTES / MM_PROCESS_PAGE_TABLE_BYTES)

DWORD mm_page_align_down(DWORD value);
DWORD mm_page_align_up(DWORD value);

/* V67.4: reserve one contiguous kernel virtual range backed by independently
 * allocated physical pages.  This removes LaunchApp's dependency on one large
 * physically contiguous kmalloc region while preserving the historical A2K
 * offset translation and ELF32 ABI. */
void *mm_sparse_alloc(DWORD length, int owner_pid, const char *name);
void *mm_sparse_clone_cow(void *source, DWORD length, int owner_pid,
                          const char *name);
int mm_sparse_free(void *base, DWORD length);
int mm_sparse_change_owner(void *base, DWORD length, int old_pid, int new_pid);
void mm_clear_process_space(int pid);
int mm_clone_process_space(int parent_pid, int child_pid, void *child_backing, DWORD length);
int mm_clone_process_space_cow(int parent_pid, int child_pid,
                               void *parent_backing, void *child_backing,
                               DWORD length);
/* V69.66: map is collision-safe and commits source validation + target PTEs
 * atomically under the MM critical section. */
int mm_map_process_range(int pid, DWORD virtual_address,
                         void *kernel_address, DWORD length, int prot);
DWORD mm_get_process_pte(int pid, DWORD virtual_address);
int mm_protect_process_range(int pid, DWORD virtual_address,
                             DWORD length, int prot);
int mm_unmap_process_range(int pid, DWORD virtual_address, DWORD length);
DWORD mm_find_process_free_range(int pid, DWORD length, DWORD low, DWORD high);

/* V67.8.57.8: real per-process anonymous mappings used by userspace mmap()
 * and libc heap growth after the original SYSMEMREQ arena is exhausted. */
void *mm_process_mmap_anon(int pid, DWORD requested_address, DWORD length,
                           int prot, int flags, DWORD low);
int mm_process_munmap(int pid, DWORD user_address, DWORD length);
DWORD mm_translate_process_mapping(int pid, DWORD user_address, DWORD length);
void mm_release_process_mappings(int pid);
int mm_clone_process_mappings(int parent_pid, int child_pid);

/* Demand-zero, V70.9 COW and V70.10 sparse first-touch repair.  Returns
 * non-zero only after mapping/ownership state is committed and may IRETD. */
int mm_handle_page_fault(DWORD fault_address, DWORD error_code);
/* Resolve valid first-touch kernel aliases before a checked userspace copy.
 * Returns zero for unmapped/stale pages or if materialization fails. */
int mm_prepare_kernel_copy_range(const void *address, DWORD length);
int mm_page_fault_context_nested(void);
void mm_page_fault_context_reset(void);
void mm_get_demand_stats(MM_DEMAND_STATS *out);
void mm_get_cow_stats(MM_COW_STATS *out);

#endif
