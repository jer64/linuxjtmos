#ifndef __JTMOS_SYS_MMAN_H__
#define __JTMOS_SYS_MMAN_H__

#include <stddef.h>

/* JTMOS/i386 uses a 32-bit off_t in this POSIX-compatible interface. */
#ifndef __off_t_defined
typedef long off_t;
#define __off_t_defined 1
#endif

/* POSIX protection flags. */
#define PROT_NONE       0x0
#define PROT_READ       0x1
#define PROT_WRITE      0x2
#define PROT_EXEC       0x4

/* Linux/POSIX-compatible mapping flag values. */
#define MAP_SHARED      0x01
#define MAP_PRIVATE     0x02
#define MAP_FIXED       0x10
#define MAP_ANONYMOUS   0x20
#define MAP_ANON        MAP_ANONYMOUS

/* JTMOS extension: anonymous pages are allocated on first access. */
#define MAP_JTMOS_DEMAND 0x20000000

/* JTMOS does not currently replace an occupied MAP_FIXED range.  This flag is
   accepted as an explicit request for the same no-replace behaviour. */
#define MAP_FIXED_NOREPLACE 0x100000

#define MAP_FAILED      ((void *)-1)

void *mmap(void *addr, size_t length, int prot, int flags,
           int fd, off_t offset);
int munmap(void *addr, size_t length);

#endif
