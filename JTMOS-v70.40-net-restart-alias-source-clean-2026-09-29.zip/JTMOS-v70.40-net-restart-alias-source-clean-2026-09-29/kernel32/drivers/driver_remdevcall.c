//=========================================================
// driver_remdevcall.c - remote device call
// Remote device call is required when a non-kernel mode
// device driver is being accessed.
// Implements MSGBOX communication.
// (C) 2003-2004 by Jari Tuominen.
//=========================================================
#include "kernel32.h"
#include "scheduler.h"
#include "driver_sys.h"
#include "driver_api.h"
#include "driver_remdevcall.h"

// Cached device block sizes
static int dbs[N_MAX_DEVICES]={0};
// Cache device sizes
static int ds[N_MAX_DEVICES]={0};

// Device call queue
int init_devq=1;
DCALL *devq[N_MAX_DEVQ];

////////////////////////////////////////////////////////////////////////////////////////////
//
static int remote_driver_alive(int pid)
{
    return pid>0 && pid<N_MAX_THREADS && valid_pid(pid) && thread_states[pid];
}

int remoteDeviceCall(int dnr,
    int pid,
    int n_function,
    int par1,int par2,int par3,int par4,
    void *p1,void *p2)
{
    MSG *m;
    DCPACKET *dc;
    volatile int done;
    volatile int rval;
    int i,send_rv,time,warns=0,flags,cached;

    if(dnr<0 || dnr>=N_MAX_DEVICES || !remote_driver_alive(pid)) return -1;

    /* Geometry caches are tiny control-plane values.  Snapshot them with IRQ
     * exclusion so concurrent remote callers cannot publish/read half of a
     * cache update. */
    flags=get_eflags();
    disable();
    cached=(n_function==DEVICE_CMD_GETBLOCKSIZE) ? dbs[dnr] :
           (n_function==DEVICE_CMD_GETSIZE) ? ds[dnr] : 0;
    set_eflags(flags);
    if(cached && p1!=NULL &&
       (n_function==DEVICE_CMD_GETBLOCKSIZE || n_function==DEVICE_CMD_GETSIZE))
    {
        *((int *)p1)=cached;
        return 0;
    }

    dprintk("%s: dnr=%d, func=%d, v1=%d, v2=%d, v3=%d, v4=%d, p1=%x, p2=%x, pid=%d\n",
        __FUNCTION__,dnr,n_function,par1,par2,par3,par4,p1,p2,pid);

    m=malloc(sizeof(MSG));
    if(m==NULL) return -2;
    memset(m,0,sizeof(MSG));
    dc=(DCPACKET *)m->buf;

    done=FALSE;
    rval=-1;
    dc->done=(int *)&done;
    dc->rval=(int *)&rval;
    dc->p1=p1;
    dc->p2=p2;
    dc->par1=par1;
    dc->par2=par2;
    dc->par3=par3;
    dc->par4=par4;
    dc->n_function=n_function;
    m->protocol=MB_PROTOCOL_DC;
    m->amount=sizeof(DCPACKET);

    send_rv=sendMessage(m,pid);
    if(send_rv!=0)
    {
        free(m);
        return -3;
    }

    SwitchToThreadEx(pid);

    /* V70.6 asynchronous lifetime rule: never return while a live remote
     * service can still write through dc->p1/p2/done/rval.  The old fixed
     * five-second timeout returned stack/buffer pointers to the caller and a
     * late service reply could then corrupt a reused stack frame or freed
     * buffer.  Five seconds is now a diagnostic interval.  We return early
     * only after the service PID is gone, at which point no late reply is
     * possible. */
    time=GetSeconds();
    for(i=0; done==FALSE; i++)
    {
        SchedulerWaitPause(1000UL);
        if(done) break;
        if(!remote_driver_alive(pid))
        {
            dprintk("REMOTE/DC: service pid=%d died while dnr=%d cmd=%d was pending.\n",
                    pid,dnr,n_function);
            free(m);
            return -4;
        }
        if((GetSeconds()-time)>=5)
        {
            warns++;
            dprintk("REMOTE/DC: slow live service dnr=%d cmd=%d pid=%d waited>=5s warning=%d; keeping request storage alive.\n",
                    dnr,n_function,pid,warns);
            time=GetSeconds();
        }
    }

    if(rval==0 && p1!=NULL)
    {
        flags=get_eflags();
        disable();
        if(n_function==DEVICE_CMD_GETBLOCKSIZE) dbs[dnr]=*((int *)p1);
        if(n_function==DEVICE_CMD_GETSIZE) ds[dnr]=*((int *)p1);
        set_eflags(flags);
    }

    free(m);
    return (int)rval;
}
