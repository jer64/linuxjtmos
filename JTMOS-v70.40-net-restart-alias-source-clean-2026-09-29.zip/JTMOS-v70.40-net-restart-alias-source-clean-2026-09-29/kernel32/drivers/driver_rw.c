// =============================================================
// JTMOS DEVAPI block I/O
// V67.8.53: true readblocks/writeblocks + generic read/write-back cache.
// (C) 2002-2026 by Jari Tuominen.
// =============================================================
#include "basdef.h"
#include "sysmem.h"
#include "kernel32.h"
#include "macrodef.h"
#include "int.h"
#include "pit.h"
#include "keyb.h"
#include "syssh.h"
#include "cmos.h"
#include "floppy.h"
#include "buildnr.h"
#include "driver_api.h"
#include "driver_sys.h"
#include "driver_lock.h"
#include "driver_rw.h"
#include "kyber.h"
#include "scheduler.h"

/* Bigfoot V1: 256 resident 512-byte hda blocks allow a stream of legacy
 * one-sector writes to collapse into one 128 KiB DEVICE_CMD_WRITEBLOCKS
 * request.  Logical block size is unchanged; only the transfer footprint
 * grows.  Non-contiguous/random traffic still uses ordinary cache entries. */
#define DAPI_CACHE_MIN_KIB             128U
#define DAPI_CACHE_DEFAULT_KIB        4096U
#define DAPI_CACHE_MAX_KIB           32768U
#define DAPI_CACHE_MIN_BLOCK_BYTES      512U
#define DAPI_CACHE_MAX_BLOCKSIZE      4096
#define DAPI_CACHE_READ_FILL_BLOCKS       16
/* V69.57: small reads are promoted to a 16 KiB sequential window.  This
 * turns old readblock()/4 KiB callers into cache hits instead of issuing a
 * fresh ATA request for every logical sector/page. */
#define DAPI_CACHE_READAHEAD_BLOCKS        32
/* Streaming I/O larger than these limits bypasses the cache.  Keep normal
 * V70.13 keeps a 512 KiB small/random-I/O working set on 512-byte hda media
 * (1024 cache entries), so FAT/DIRDB/journal traffic does not immediately evict
 * neighboring tiny-file data.  4/8/16 KiB file traffic stays in write-back so
 * adjacent calls can coalesce into
 * 64 KiB media requests; truly large transfers already arrive coalesced. */
#define DAPI_CACHE_DIRECT_READ_BLOCKS       64
#define DAPI_CACHE_DIRECT_WRITE_BLOCKS     128
#define DAPI_CACHE_DIRECT_SLOW_BLOCKS       32
#define DAPI_CACHE_WRITEBACK_HIGH_BLOCKS   128
#define DAPI_CACHE_LOCK_NR               DRIVER_LOCK_DAPI_CACHE

typedef struct {
    int valid;
    int dirty;
    int dnr;
    long block_nr;
    int block_size;
    int allocated;
    BYTE *data;
    DWORD age;
    int hash_next; /* index+1; 0 terminates a bucket chain */
} DAPI_CACHE_ENTRY;

static DAPI_CACHE_ENTRY *dapi_cache=NULL;
static int *dapi_cache_hash=NULL; /* entry index+1 */
static int dapi_cache_entries=0;
static unsigned dapi_cache_hash_buckets=0;
static DWORD dapi_cache_limit_bytes=DAPI_CACHE_DEFAULT_KIB*1024UL;
static DWORD dapi_cache_payload_bytes=0;
static DWORD dapi_cache_clock=1;
static int dapi_dirty_owner=-1;
static BYTE *dapi_io_buffer=NULL;
static int dapi_io_buffer_size=0;
static BYTE *dapi_readahead_buffer=NULL;
static int dapi_readahead_buffer_size=0;
static DWORD dapi_cache_hits=0,dapi_cache_misses=0;
static DWORD dapi_cache_hash_steps=0,dapi_cache_readahead_blocks=0;
static DWORD dapi_cache_write_hits=0,dapi_cache_flush_blocks=0;
static DWORD dapi_cache_flush_runs=0,dapi_cache_max_flush_run=0;
static DWORD dapi_cache_highwater_flushes=0;
static DWORD dapi_debug_direct_reads=0,dapi_debug_direct_writes=0;
static DWORD dapi_debug_flush_calls=0;

static int block_range_valid(int dnr,long block_nr,int count)
{
    int size;
    if(!isValidDevice(dnr) || block_nr<0 || count<=0) {
        dprintk("DAPI/range: reject dnr=%d block=%d count=%d (invalid device/negative/zero).\n",
                dnr,(int)block_nr,count);
        return 0;
    }
    size=getsize(dnr);
    if(size<=0 || block_nr>=(long)size) {
        dprintk("DAPI/range: reject dnr=%d block=%d count=%d size=%d.\n",
                dnr,(int)block_nr,count,size);
        return 0;
    }
    if((long)count>(long)size-block_nr) {
        dprintk("DAPI/range: reject tail dnr=%d block=%d count=%d size=%d remaining=%d.\n",
                dnr,(int)block_nr,count,size,(int)((long)size-block_nr));
        return 0;
    }
    return 1;
}

static int transfer_buffer_valid(const BYTE *buf,int count,int block_size)
{
    DWORD start,bytes;
    if(buf==NULL || count<=0 || block_size<=0) return 0;
    if((DWORD)count > 0xffffffffUL/(DWORD)block_size) {
        dprintk("DAPI/range: reject byte-count overflow count=%d blocksize=%d.\n",count,block_size);
        return 0;
    }
    bytes=(DWORD)count*(DWORD)block_size;
    start=(DWORD)buf;
    if(bytes==0 || start>0xffffffffUL-(bytes-1U)) {
        dprintk("DAPI/range: reject buffer wrap start=0x%x bytes=%u.\n",start,(unsigned)bytes);
        return 0;
    }
    return 1;
}

static unsigned cache_next_pow2(unsigned n)
{
    unsigned p=1U;
    while(p<n && p<131072U) p<<=1;
    return p;
}

static int cache_allocate_tables_locked(DWORD limit_bytes,
                                        DAPI_CACHE_ENTRY **entries_out,
                                        int **hash_out,
                                        int *entry_count_out,
                                        unsigned *hash_count_out)
{
    DWORD count32;
    unsigned hcount;
    DAPI_CACHE_ENTRY *entries;
    int *hash;

    if(limit_bytes==0) {
        *entries_out=NULL; *hash_out=NULL;
        *entry_count_out=0; *hash_count_out=0;
        return 1;
    }
    count32=(limit_bytes + DAPI_CACHE_MIN_BLOCK_BYTES-1UL)/DAPI_CACHE_MIN_BLOCK_BYTES;
    if(count32<1UL) count32=1UL;
    if(count32>65536UL) count32=65536UL;
    hcount=cache_next_pow2((unsigned)count32*2U);
    entries=(DAPI_CACHE_ENTRY *)malloc((size_t)count32*sizeof(DAPI_CACHE_ENTRY));
    if(entries==NULL) return 0;
    hash=(int *)malloc((size_t)hcount*sizeof(int));
    if(hash==NULL) { free(entries); return 0; }
    memset(entries,0,(size_t)count32*sizeof(DAPI_CACHE_ENTRY));
    memset(hash,0,(size_t)hcount*sizeof(int));
    *entries_out=entries; *hash_out=hash;
    *entry_count_out=(int)count32; *hash_count_out=hcount;
    return 1;
}

static int cache_ensure_tables_locked(void)
{
    DAPI_CACHE_ENTRY *entries;
    int *hash,ec;
    unsigned hc;
    if(dapi_cache_limit_bytes==0) return 0;
    if(dapi_cache!=NULL && dapi_cache_hash!=NULL && dapi_cache_entries>0) return 1;
    if(!cache_allocate_tables_locked(dapi_cache_limit_bytes,&entries,&hash,&ec,&hc))
        return 0;
    dapi_cache=entries; dapi_cache_hash=hash;
    dapi_cache_entries=ec; dapi_cache_hash_buckets=hc;
    return 1;
}

static void cache_free_payload_locked(DAPI_CACHE_ENTRY *e)
{
    if(e==NULL || e->data==NULL) return;
    if((DWORD)e->allocated<=dapi_cache_payload_bytes)
        dapi_cache_payload_bytes-=(DWORD)e->allocated;
    else
        dapi_cache_payload_bytes=0;
    free(e->data);
    e->data=NULL; e->allocated=0;
}

static void cache_free_tables_locked(void)
{
    int i;
    if(dapi_cache) {
        for(i=0;i<dapi_cache_entries;i++) cache_free_payload_locked(&dapi_cache[i]);
        free(dapi_cache);
    }
    if(dapi_cache_hash) free(dapi_cache_hash);
    dapi_cache=NULL; dapi_cache_hash=NULL;
    dapi_cache_entries=0; dapi_cache_hash_buckets=0;
    dapi_cache_payload_bytes=0; dapi_dirty_owner=-1;
}

static void cache_touch(DAPI_CACHE_ENTRY *e)
{
    if(++dapi_cache_clock==0) dapi_cache_clock=1;
    e->age=dapi_cache_clock;
}

static unsigned cache_hash_value(int dnr,long block_nr)
{
    DWORD x=(DWORD)block_nr;
    if(dapi_cache_hash_buckets==0) return 0;
    x^=(DWORD)dnr*0x9e3779b9UL;
    x^=x>>16;
    x*=0x7feb352dUL;
    x^=x>>15;
    return (unsigned)(x & (dapi_cache_hash_buckets-1U));
}

static void cache_hash_remove_locked(int idx)
{
    unsigned h;
    int cur,prev=0;
    DAPI_CACHE_ENTRY *e;
    if(idx<0 || idx>=dapi_cache_entries) return;
    e=&dapi_cache[idx];
    if(!e->valid) { e->hash_next=0; return; }
    h=cache_hash_value(e->dnr,e->block_nr);
    cur=dapi_cache_hash[h];
    while(cur) {
        int ci=cur-1;
        if(ci==idx) {
            if(prev) dapi_cache[prev-1].hash_next=e->hash_next;
            else dapi_cache_hash[h]=e->hash_next;
            e->hash_next=0;
            return;
        }
        prev=cur;
        cur=dapi_cache[ci].hash_next;
    }
    e->hash_next=0;
}

static void cache_hash_insert_locked(int idx)
{
    unsigned h;
    DAPI_CACHE_ENTRY *e;
    if(idx<0 || idx>=dapi_cache_entries) return;
    e=&dapi_cache[idx];
    if(!e->valid) return;
    h=cache_hash_value(e->dnr,e->block_nr);
    e->hash_next=dapi_cache_hash[h];
    dapi_cache_hash[h]=idx+1;
}

static DAPI_CACHE_ENTRY *cache_find_locked(int dnr,long block_nr)
{
    int cur;
    unsigned h=cache_hash_value(dnr,block_nr);
    cur=dapi_cache_hash[h];
    while(cur) {
        DAPI_CACHE_ENTRY *e=&dapi_cache[cur-1];
        dapi_cache_hash_steps++;
        if(e->valid && e->dnr==dnr && e->block_nr==block_nr) return e;
        cur=e->hash_next;
    }
    return NULL;
}

static int cache_has_dirty_locked(int dnr)
{
    int i;
    for(i=0;i<dapi_cache_entries;i++)
        if(dapi_cache[i].valid && dapi_cache[i].dirty &&
           (dnr<0 || dapi_cache[i].dnr==dnr)) return 1;
    return 0;
}

static int cache_dirty_count_locked(int dnr)
{
    int i,n=0;
    for(i=0;i<dapi_cache_entries;i++)
        if(dapi_cache[i].valid && dapi_cache[i].dirty &&
           (dnr<0 || dapi_cache[i].dnr==dnr)) n++;
    return n;
}

static void cache_refresh_dirty_owner_locked(void)
{
    int i;
    dapi_dirty_owner=-1;
    for(i=0;i<dapi_cache_entries;i++)
        if(dapi_cache[i].valid && dapi_cache[i].dirty) {
            dapi_dirty_owner=dapi_cache[i].dnr;
            return;
        }
}

static int cache_ensure_io_locked(int bytes)
{
    BYTE *p;
    if(bytes<=0) return 0;
    if(dapi_io_buffer!=NULL && dapi_io_buffer_size>=bytes) return 1;
    p=(BYTE *)malloc((size_t)bytes);
    if(p==NULL) return 0;
    if(dapi_io_buffer) free(dapi_io_buffer);
    dapi_io_buffer=p;
    dapi_io_buffer_size=bytes;
    return 1;
}

static int cache_ensure_readahead_locked(int bytes)
{
    BYTE *p;
    if(bytes<=0) return 0;
    if(dapi_readahead_buffer!=NULL && dapi_readahead_buffer_size>=bytes) return 1;
    p=(BYTE *)malloc((size_t)bytes);
    if(p==NULL) return 0;
    if(dapi_readahead_buffer) free(dapi_readahead_buffer);
    dapi_readahead_buffer=p;
    dapi_readahead_buffer_size=bytes;
    return 1;
}

/* Called with DAPI_CACHE_LOCK_NR held.  This intentionally uses the uncached
 * direct backend so flushing cannot recursively re-enter the cache. */
static int cache_flush_device_locked(int dnr)
{
    int i,j,bs,run,bytes,transferred,owner;
    long first,next;
    DAPI_CACHE_ENTRY *e;

    while(cache_has_dirty_locked(dnr)) {
        /* dnr < 0 means every device.  Keep the wildcard separate from the
         * selected owner; the old code overwrote dnr with the first owner and
         * silently stopped after flushing only that one device. */
        owner=dnr;
        if(owner<0) {
            owner=-1;
            for(i=0;i<dapi_cache_entries;i++)
                if(dapi_cache[i].valid && dapi_cache[i].dirty) {
                    owner=dapi_cache[i].dnr;
                    break;
                }
            if(owner<0) break;
        }

        first=-1; bs=0;
        for(i=0;i<dapi_cache_entries;i++) {
            e=&dapi_cache[i];
            if(!e->valid || !e->dirty || e->dnr!=owner) continue;
            if(first<0 || e->block_nr<first) {
                first=e->block_nr; bs=e->block_size;
            }
        }
        if(first<0) continue;

        /* Sequential workloads naturally form contiguous runs.  Gather the
         * longest resident run and issue one physical multi-block command. */
        run=1;
        while(run<dapi_cache_entries) {
            next=first+run;
            e=cache_find_locked(owner,next);
            if(e==NULL || !e->dirty || e->block_size!=bs) break;
            run++;
        }
        bytes=run*bs;
        if(run>1 && cache_ensure_io_locked(bytes)) {
            for(j=0;j<run;j++) {
                e=cache_find_locked(owner,first+j);
                memcpy(dapi_io_buffer+j*bs,e->data,(size_t)bs);
            }
            if(run>=8 && (dapi_cache_flush_runs<8 || (dapi_cache_flush_runs&0xffUL)==0))
                dprintk("DAPI/flush-run: owner=%d first=%d run=%d bs=%d bytes=%d dirty-owner=%d.\n",
                        owner,(int)first,run,bs,bytes,dapi_dirty_owner);
            transferred=writeblocks1(owner,first,dapi_io_buffer,run);
            if(transferred!=run) {
                dprintk("DAPI/flush-run: FAILED owner=%d first=%d requested=%d transferred=%d.\n",
                        owner,(int)first,run,transferred);
                return 1;
            }
            for(j=0;j<run;j++) {
                e=cache_find_locked(owner,first+j);
                if(e) { e->dirty=0; cache_touch(e); }
            }
            dapi_cache_flush_blocks+=(DWORD)run;
        } else {
            e=cache_find_locked(owner,first);
            if(e==NULL || writeblocks1(owner,first,e->data,1)!=1) return 1;
            e->dirty=0; cache_touch(e);
            dapi_cache_flush_blocks++;
            run=1;
        }
        dapi_cache_flush_runs++;
        if((DWORD)run>dapi_cache_max_flush_run) dapi_cache_max_flush_run=(DWORD)run;
    }
    cache_refresh_dirty_owner_locked();
    return 0;
}

static void cache_drop_device_locked(int dnr)
{
    int i;
    for(i=0;i<dapi_cache_entries;i++) {
        if(!dapi_cache[i].valid) continue;
        if(dnr<0 || dapi_cache[i].dnr==dnr) {
            cache_hash_remove_locked(i);
            dapi_cache[i].valid=0;
            dapi_cache[i].dirty=0;
        }
    }
    cache_refresh_dirty_owner_locked();
}

static void cache_drop_other_devices_locked(int dnr)
{
    int i;
    for(i=0;i<dapi_cache_entries;i++)
        if(dapi_cache[i].valid && dapi_cache[i].dnr!=dnr && !dapi_cache[i].dirty) {
            cache_hash_remove_locked(i);
            dapi_cache[i].valid=0;
        }
}

static void cache_drop_range_locked(int dnr,long first,int count)
{
    int i;
    long end=first+(long)count;
    for(i=0;i<dapi_cache_entries;i++)
        if(dapi_cache[i].valid && dapi_cache[i].dnr==dnr &&
           dapi_cache[i].block_nr>=first && dapi_cache[i].block_nr<end) {
            cache_hash_remove_locked(i);
            dapi_cache[i].valid=0;
            dapi_cache[i].dirty=0;
        }
    cache_refresh_dirty_owner_locked();
}

static DAPI_CACHE_ENTRY *cache_victim_locked(int dnr)
{
    int i,best=-1;
    DWORD oldest=0xffffffffUL;

    for(i=0;i<dapi_cache_entries;i++)
        if(!dapi_cache[i].valid) return &dapi_cache[i];

    /* Prefer evicting clean data. */
    for(i=0;i<dapi_cache_entries;i++)
        if(!dapi_cache[i].dirty && dapi_cache[i].age<=oldest) {
            oldest=dapi_cache[i].age; best=i;
        }
    if(best>=0) return &dapi_cache[best];

    /* All entries are dirty: write the current stream as large contiguous
     * requests, then retry the now-clean LRU search. */
    if(cache_flush_device_locked(dnr)!=0) return NULL;
    oldest=0xffffffffUL; best=-1;
    for(i=0;i<dapi_cache_entries;i++)
        if(!dapi_cache[i].dirty && dapi_cache[i].age<=oldest) {
            oldest=dapi_cache[i].age; best=i;
        }
    return best>=0 ? &dapi_cache[best] : NULL;
}

static int cache_make_payload_room_locked(DAPI_CACHE_ENTRY *keep,int bytes)
{
    int i,best;
    DWORD oldest;
    if(bytes<=0 || (DWORD)bytes>dapi_cache_limit_bytes) return 0;
    while(dapi_cache_payload_bytes+(DWORD)bytes>dapi_cache_limit_bytes) {
        best=-1; oldest=0xffffffffUL;
        for(i=0;i<dapi_cache_entries;i++) {
            DAPI_CACHE_ENTRY *e=&dapi_cache[i];
            if(e==keep || e->data==NULL || e->dirty) continue;
            if(!e->valid) { best=i; break; }
            if(e->age<=oldest) { oldest=e->age; best=i; }
        }
        if(best<0) {
            if(cache_flush_device_locked(-1)!=0) return 0;
            for(i=0;i<dapi_cache_entries;i++) {
                DAPI_CACHE_ENTRY *e=&dapi_cache[i];
                if(e==keep || e->data==NULL || e->dirty) continue;
                if(!e->valid) { best=i; break; }
                if(best<0 || e->age<=oldest) { oldest=e->age; best=i; }
            }
            if(best<0) return 0;
        }
        if(dapi_cache[best].valid) cache_hash_remove_locked(best);
        dapi_cache[best].valid=0; dapi_cache[best].dirty=0;
        cache_free_payload_locked(&dapi_cache[best]);
    }
    return 1;
}

static DAPI_CACHE_ENTRY *cache_store_locked(int dnr,long block_nr,int bs,
                                             const BYTE *src,int dirty,int *was_hit)
{
    DAPI_CACHE_ENTRY *e;
    BYTE *p;
    e=cache_find_locked(dnr,block_nr);
    if(was_hit) *was_hit=(e!=NULL);
    if(e==NULL) e=cache_victim_locked(dnr);
    if(e==NULL) return NULL;
    /* Do not unlink a valid victim until replacement storage is guaranteed.
     * If malloc fails, the old cache entry must remain fully discoverable. */
    if(e->data==NULL || e->allocated<bs) {
        int delta=bs-(e->data ? e->allocated : 0);
        if(!cache_make_payload_room_locked(e,delta)) return NULL;
        p=(BYTE *)malloc((size_t)bs);
        if(p==NULL) return NULL;
        if(e->valid) cache_hash_remove_locked((int)(e-dapi_cache));
        if(e->data) {
            if((DWORD)e->allocated<=dapi_cache_payload_bytes)
                dapi_cache_payload_bytes-=(DWORD)e->allocated;
            free(e->data);
        }
        e->data=p; e->allocated=bs;
        dapi_cache_payload_bytes+=(DWORD)bs;
    } else if(e->valid)
        cache_hash_remove_locked((int)(e-dapi_cache));
    memcpy(e->data,src,(size_t)bs);
    e->valid=1; e->dirty=dirty; e->dnr=dnr;
    e->block_nr=block_nr; e->block_size=bs;
    cache_hash_insert_locked((int)(e-dapi_cache));
    cache_touch(e);
    if(dirty) dapi_dirty_owner=dnr;
    return e;
}

static int cache_prepare_read_locked(int dnr)
{
    /* Logical devices may alias one physical disk (hda/hda1/etc).  Never let
     * dirty data for one DNR remain hidden when another DNR is read. */
    if(dapi_dirty_owner>=0 && dapi_dirty_owner!=dnr)
        return cache_flush_device_locked(dapi_dirty_owner);
    return 0;
}

static int cache_prepare_write_locked(int dnr)
{
    if(dapi_dirty_owner>=0 && dapi_dirty_owner!=dnr)
        if(cache_flush_device_locked(dapi_dirty_owner)!=0) return 1;
    /* We cannot in general map partition aliases back to physical LBAs here,
     * so invalidate clean entries belonging to other logical devices. */
    cache_drop_other_devices_locked(dnr);
    return 0;
}

int driver_block_cache_flush(int dnr)
{
    int r,owner;
    DWORD seq;
    driver_lockOn(DAPI_CACHE_LOCK_NR);
    seq=++dapi_debug_flush_calls;
    owner=dapi_dirty_owner;
    if(seq<=8 || (seq&0xffUL)==0)
        dprintk("DAPI/cache-flush #%u begin dnr=%d dirty-owner=%d.\n",
                (unsigned)seq,dnr,owner);
    r=cache_flush_device_locked(dnr);
    if(r || seq<=8 || (seq&0xffUL)==0)
        dprintk("DAPI/cache-flush #%u end dnr=%d rv=%d flushed=%u runs=%u max-run=%u.\n",
                (unsigned)seq,dnr,r,(unsigned)dapi_cache_flush_blocks,
                (unsigned)dapi_cache_flush_runs,(unsigned)dapi_cache_max_flush_run);
    driver_lockOff(DAPI_CACHE_LOCK_NR);
    return r;
}

/* V70.6 cache policy publication.  Policy bits are consumed while the same
 * DAPI lock is held, so disabling write-back is a true flush+disable barrier:
 * no writer can observe the old policy and insert a fresh dirty entry between
 * the flush and the flag change. */
int driver_block_cache_set_read_policy(int dnr,int enabled)
{
    DEVICE_ENTRY *de;
    int rv=0;
    driver_lockOn(DAPI_CACHE_LOCK_NR);
    de=driver_getdevice(dnr);
    if(de==NULL || de->isfree || !(de->type&DEVICE_TYPE_BLOCK)) rv=1;
    else de->DAPIReadCache=(enabled && !DISABLE_BLOCK_CACHE) ? 1 : 0;
    driver_lockOff(DAPI_CACHE_LOCK_NR);
    return rv;
}

int driver_block_cache_set_writeback_policy(int dnr,int enabled)
{
    DEVICE_ENTRY *de;
    int rv=0;
    driver_lockOn(DAPI_CACHE_LOCK_NR);
    de=driver_getdevice(dnr);
    if(de==NULL || de->isfree || !(de->type&DEVICE_TYPE_BLOCK)) rv=1;
    else if(enabled && (DISABLE_BLOCK_CACHE || (de->type&DEVICE_TYPE_READONLY)))
        de->DAPIWriteBackCache=0;
    else
    {
        if(!enabled && de->DAPIWriteBackCache)
            rv=cache_flush_device_locked(dnr);
        if(!rv) de->DAPIWriteBackCache=enabled ? 1 : 0;
    }
    driver_lockOff(DAPI_CACHE_LOCK_NR);
    return rv;
}

void driver_block_cache_invalidate(int dnr)
{
    driver_lockOn(DAPI_CACHE_LOCK_NR);
    cache_drop_device_locked(dnr);
    driver_lockOff(DAPI_CACHE_LOCK_NR);
}

void driver_block_cache_invalidate_range(int dnr,long first,int count)
{
    if(!isValidDevice(dnr) || first<0 || count<=0) return;
    driver_lockOn(DAPI_CACHE_LOCK_NR);
    cache_drop_range_locked(dnr,first,count);
    driver_lockOff(DAPI_CACHE_LOCK_NR);
}

int driver_block_cache_resize_kib(unsigned kib)
{
    DWORD new_limit;
    DAPI_CACHE_ENTRY *new_entries=NULL;
    int *new_hash=NULL,new_count=0;
    unsigned new_hash_count=0;
    int rv=0;

    if(kib!=0U && (kib<DAPI_CACHE_MIN_KIB || kib>DAPI_CACHE_MAX_KIB)) return 2;
    new_limit=(DWORD)kib*1024UL;
    driver_lockOn(DAPI_CACHE_LOCK_NR);
    if(cache_flush_device_locked(-1)!=0) { driver_lockOff(DAPI_CACHE_LOCK_NR); return 1; }
    if(new_limit!=0 && !cache_allocate_tables_locked(new_limit,&new_entries,&new_hash,
                                                      &new_count,&new_hash_count)) {
        driver_lockOff(DAPI_CACHE_LOCK_NR); return 3;
    }
    cache_free_tables_locked();
    dapi_cache_limit_bytes=new_limit;
    dapi_cache=new_entries; dapi_cache_hash=new_hash;
    dapi_cache_entries=new_count; dapi_cache_hash_buckets=new_hash_count;
    dapi_cache_clock=1;
    driver_lockOff(DAPI_CACHE_LOCK_NR);
    return rv;
}

unsigned driver_block_cache_limit_kib(void)
{
    return (unsigned)(dapi_cache_limit_bytes/1024UL);
}

unsigned driver_block_cache_resident_kib(void)
{
    unsigned rv;
    driver_lockOn(DAPI_CACHE_LOCK_NR);
    rv=(unsigned)((dapi_cache_payload_bytes+1023UL)/1024UL);
    driver_lockOff(DAPI_CACHE_LOCK_NR);
    return rv;
}

void driver_block_cache_stats(void)
{
    int dirty,owner;
    driver_lockOn(DAPI_CACHE_LOCK_NR);
    dirty=cache_dirty_count_locked(-1);
    owner=dapi_dirty_owner;
    driver_lockOff(DAPI_CACHE_LOCK_NR);
    printk("DAPI cache: limit=%u KiB resident=%u KiB slots=%d hits=%u misses=%u write-hits=%u flushed=%u blocks runs=%u max-run=%u hash-steps=%u readahead=%u dirty=%d highwater=%u owner=%d\n",
           (unsigned)(dapi_cache_limit_bytes/1024UL),
           (unsigned)((dapi_cache_payload_bytes+1023UL)/1024UL),dapi_cache_entries,
           (unsigned)dapi_cache_hits,(unsigned)dapi_cache_misses,
           (unsigned)dapi_cache_write_hits,(unsigned)dapi_cache_flush_blocks,
           (unsigned)dapi_cache_flush_runs,(unsigned)dapi_cache_max_flush_run,
           (unsigned)dapi_cache_hash_steps,(unsigned)dapi_cache_readahead_blocks,
           dirty,(unsigned)dapi_cache_highwater_flushes,owner);
}

/* ------------------------------------------------------------------ */
/* Direct uncached backend.  One lock covers the whole multi-block command. */
int readblocks1(long dnr,long block_nr,BYTE *buf,int count)
{
    DEVICE_ENTRY *de;
    int i,r,done=0,bs;
    if(buf==NULL || !block_range_valid((int)dnr,block_nr,count)) return 0;
    de=driver_getdevice((int)dnr);
    if(de==NULL) return 0;
    bs=getblocksize((int)dnr);
    if(bs<=0 || !transfer_buffer_valid(buf,count,bs)) return 0;
    dapi_debug_direct_reads++;
    if(count>=8 && (dapi_debug_direct_reads<=8 || (dapi_debug_direct_reads&0x3ffUL)==0))
        dprintk("DAPI/direct-read #%u dnr=%d LBA=%d count=%d bytes=%u.\n",
                (unsigned)dapi_debug_direct_reads,(int)dnr,(int)block_nr,count,
                (unsigned)((DWORD)count*(DWORD)bs));

    driver_directAccessLockOn();
    HDLED(1);
    if(de->type & DEVICE_TYPE_MULTIBLOCK) {
        r=device_call(dnr,DEVICE_CMD_READBLOCKS,block_nr,count,0,0,buf,NULL);
        done=(r==0)?count:0;
    } else {
        for(i=0;i<count;i++) {
            r=device_call(dnr,DEVICE_CMD_READBLOCK,block_nr+i,0,0,0,
                          buf+(i*bs),NULL);
            if(r!=0) break;
            done++;
            /* Slow single-block backends (floppy/legacy devices) must not
             * monopolize a kernel task for an entire large request. */
            if((done&7)==0) SchedulerCooperate();
        }
    }
    HDLED(0);
    driver_directAccessLockOff();
    return done;
}

/* Read-only benchmark path.  This deliberately bypasses DAPI read/write-back
 * caches and can only reach drivers that explicitly publish the one-way
 * DEVICE_TYPE_RAW_PIO_READ capability.  There is no raw-PIO write command. */
int readblocksRawPIO(long dnr,long block_nr,BYTE *buf,int count)
{
    DEVICE_ENTRY *de;
    int r,done=0,bs;

    if(buf==NULL || !block_range_valid((int)dnr,block_nr,count)) return 0;
    de=driver_getdevice((int)dnr);
    if(de==NULL || !(de->type&DEVICE_TYPE_RAW_PIO_READ)) return 0;
    bs=getblocksize((int)dnr);
    if(bs!=512 || !transfer_buffer_valid(buf,count,bs)) return 0;

    driver_directAccessLockOn();
    HDLED(1);
    r=device_call(dnr,DEVICE_CMD_READBLOCKS_RAW_PIO,
                  block_nr,count,0,0,buf,NULL);
    if(r==0) done=count;
    HDLED(0);
    driver_directAccessLockOff();
    return done;
}

int writeblocks1(long dnr,long block_nr,BYTE *buf,int count)
{
    DEVICE_ENTRY *de;
    int i,r,done=0,bs;
    if(buf==NULL || !block_range_valid((int)dnr,block_nr,count)) return 0;
    de=driver_getdevice((int)dnr);
    if(de==NULL || (de->type & DEVICE_TYPE_READONLY)) return 0;
    bs=getblocksize((int)dnr);
    if(bs<=0 || !transfer_buffer_valid(buf,count,bs)) return 0;
    dapi_debug_direct_writes++;
    if(count>=8 && (dapi_debug_direct_writes<=8 || (dapi_debug_direct_writes&0x3ffUL)==0))
        dprintk("DAPI/direct-write #%u dnr=%d LBA=%d count=%d bytes=%u.\n",
                (unsigned)dapi_debug_direct_writes,(int)dnr,(int)block_nr,count,
                (unsigned)((DWORD)count*(DWORD)bs));

    driver_directAccessLockOn();
    HDLED(2);
    if(de->type & DEVICE_TYPE_MULTIBLOCK) {
        r=device_call(dnr,DEVICE_CMD_WRITEBLOCKS,block_nr,count,0,0,buf,NULL);
        done=(r==0)?count:0;
    } else {
        for(i=0;i<count;i++) {
            r=device_call(dnr,DEVICE_CMD_WRITEBLOCK,block_nr+i,0,0,0,
                          buf+(i*bs),NULL);
            if(r!=0) break;
            done++;
            if((done&7)==0) SchedulerCooperate();
        }
    }
    HDLED(0);
    driver_directAccessLockOff();
    return done;
}

int readblock1(long dnr,long block_nr,BYTE *buf)
{
    return readblocks1(dnr,block_nr,buf,1)==1 ? 0 : 1;
}

int writeblock1(long dnr,long block_nr,BYTE *buf)
{
    return writeblocks1(dnr,block_nr,buf,1)==1 ? 0 : 1;
}

static int physical_readblocks(int dnr,long block_nr,BYTE *buf,int count)
{
    if(kyber_should_schedule(dnr))
        return kyber_submit_sync_blocks(dnr,JTMOS_KYBER_READ,block_nr,buf,count)==0 ? count : 0;
    return readblocks1(dnr,block_nr,buf,count);
}

static int physical_writeblocks(int dnr,long block_nr,BYTE *buf,int count)
{
    if(kyber_should_schedule(dnr))
        return kyber_submit_sync_blocks(dnr,JTMOS_KYBER_WRITE,block_nr,buf,count)==0 ? count : 0;
    return writeblocks1(dnr,block_nr,buf,count);
}

/* ------------------------------------------------------------------ */
static void dapi_reward_io_progress(int blocks)
{
    if(blocks>0 && Multitasking) {
        SchedulerRewardIO(GetCurrentThread(),blocks);
        /* readblocks()/writeblocks() call this after releasing the DAPI cache
         * lock.  A sizeable completed transfer is therefore an ideal safe
         * cooperative boundary. */
        if(blocks>=8) SchedulerCooperate();
    }
}

int readblocks(long dnr,long block_nr,BYTE *buf,int count)
{
    DEVICE_ENTRY *de;
    int bs,i,j,run,got,use_read_cache,use_write_cache JTM_UNUSED;
    int direct_threshold,dev_blocks;
    DAPI_CACHE_ENTRY *e;

    if(buf==NULL || !block_range_valid((int)dnr,block_nr,count)) return 0;
    de=driver_getdevice((int)dnr);
    if(de==NULL) return 0;
    bs=getblocksize((int)dnr);
    if(bs<=0 || !transfer_buffer_valid(buf,count,bs)) return 0;
    direct_threshold=(de->type & DEVICE_TYPE_MULTIBLOCK) ?
                     DAPI_CACHE_DIRECT_READ_BLOCKS : DAPI_CACHE_READ_FILL_BLOCKS;
    dev_blocks=getsize((int)dnr);

    driver_lockOn(DAPI_CACHE_LOCK_NR);
    if(de->isfree) { driver_lockOff(DAPI_CACHE_LOCK_NR); return 0; }
    if(dapi_cache_limit_bytes!=0 && dapi_cache==NULL) (void)cache_ensure_tables_locked();
    use_read_cache=de->DAPIReadCache && dapi_cache!=NULL && bs<=DAPI_CACHE_MAX_BLOCKSIZE;
    use_write_cache=de->DAPIWriteBackCache && dapi_cache!=NULL && bs<=DAPI_CACHE_MAX_BLOCKSIZE;
    if(cache_prepare_read_locked((int)dnr)!=0) {
        driver_lockOff(DAPI_CACHE_LOCK_NR); return 0;
    }

    /* Large streaming reads should remain one real device request rather than
     * polluting the 256-entry random-access cache.  Flush dirty blocks first. */
    if(count>=direct_threshold) {
        if(cache_has_dirty_locked((int)dnr) && cache_flush_device_locked((int)dnr)!=0) {
            driver_lockOff(DAPI_CACHE_LOCK_NR); return 0;
        }
        got=physical_readblocks((int)dnr,block_nr,buf,count);
        driver_lockOff(DAPI_CACHE_LOCK_NR);
        dapi_reward_io_progress(got);
        return got;
    }

    /* V69.57 adaptive read-ahead.  The old cache widened only count==1, while
     * common libc/JTMFS callers issue 4/8/16 KiB reads.  If the requested
     * range begins with a miss and contains no resident (possibly dirty) cache
     * block, fetch at least a 32-sector/16 KiB window, return the requested
     * prefix and retain the rest.  This preserves dirty-cache precedence while
     * turning sequential small reads into cache hits. */
    if(use_read_cache && count>0 && count<direct_threshold &&
       cache_find_locked((int)dnr,block_nr)==NULL) {
        run=DAPI_CACHE_READAHEAD_BLOCKS;
        if(run<count) run=count;
        if(block_nr+run>(long)dev_blocks) run=(int)((long)dev_blocks-block_nr);
        for(j=1;j<run;j++)
            if(cache_find_locked((int)dnr,block_nr+j)!=NULL) { run=j; break; }
        if(run>=count && cache_ensure_readahead_locked(run*bs)) {
            got=physical_readblocks((int)dnr,block_nr,dapi_readahead_buffer,run);
            if(got>=count) {
                memcpy(buf,dapi_readahead_buffer,(size_t)count*(size_t)bs);
                for(j=0;j<got;j++)
                    (void)cache_store_locked((int)dnr,block_nr+j,bs,
                                             dapi_readahead_buffer+j*bs,0,NULL);
                dapi_cache_misses+=(DWORD)count;
                dapi_cache_readahead_blocks+=(DWORD)got;
                driver_lockOff(DAPI_CACHE_LOCK_NR);
                dapi_reward_io_progress(got);
                return count;
            }
        }
    }

    i=0;
    while(i<count) {
        e=cache_find_locked((int)dnr,block_nr+i);
        if(e && (e->dirty || use_read_cache) && e->block_size==bs) {
            memcpy(buf+i*bs,e->data,(size_t)bs);
            cache_touch(e); dapi_cache_hits++; i++; continue;
        }
        dapi_cache_misses++;

        /* Coalesce consecutive misses into one hardware request. */
        run=1;
        while(i+run<count) {
            e=cache_find_locked((int)dnr,block_nr+i+run);
            if(e && (e->dirty || use_read_cache) && e->block_size==bs) break;
            run++;
        }
        got=physical_readblocks((int)dnr,block_nr+i,buf+i*bs,run);
        if(got!=run) {
            driver_lockOff(DAPI_CACHE_LOCK_NR);
            dapi_reward_io_progress(i+got);
            return i+got;
        }
        if(use_read_cache) {
            for(j=0;j<run;j++)
                (void)cache_store_locked((int)dnr,block_nr+i+j,bs,
                                         buf+(i+j)*bs,0,NULL);
        }
        i+=run;
    }
    driver_lockOff(DAPI_CACHE_LOCK_NR);
    dapi_reward_io_progress(count);
    return count;
}

int writeblocks(long dnr,long block_nr,BYTE *buf,int count)
{
    DEVICE_ENTRY *de;
    int bs,i,written,use_write_cache,was_hit,direct_threshold;
    DAPI_CACHE_ENTRY *e;

    if(buf==NULL || !block_range_valid((int)dnr,block_nr,count)) return 0;
    de=driver_getdevice((int)dnr);
    if(de==NULL || (de->type & DEVICE_TYPE_READONLY)) return 0;
    bs=getblocksize((int)dnr);
    if(bs<=0 || !transfer_buffer_valid(buf,count,bs)) return 0;
    direct_threshold=(de->type & DEVICE_TYPE_MULTIBLOCK) ?
                     DAPI_CACHE_DIRECT_WRITE_BLOCKS : DAPI_CACHE_DIRECT_SLOW_BLOCKS;

    driver_lockOn(DAPI_CACHE_LOCK_NR);
    if(de->isfree) { driver_lockOff(DAPI_CACHE_LOCK_NR); return 0; }
    if(dapi_cache_limit_bytes!=0 && dapi_cache==NULL) (void)cache_ensure_tables_locked();
    use_write_cache=de->DAPIWriteBackCache && dapi_cache!=NULL && bs<=DAPI_CACHE_MAX_BLOCKSIZE;
    if(cache_prepare_write_locked((int)dnr)!=0) {
        driver_lockOff(DAPI_CACHE_LOCK_NR); return 0;
    }

    /* Large writes are already optimal as one READ/WRITE MULTIPLE-style
     * request.  Do not copy hundreds of blocks into a small write-back cache. */
    if(!use_write_cache || count>=direct_threshold) {
        if(cache_has_dirty_locked((int)dnr) && cache_flush_device_locked((int)dnr)!=0) {
            driver_lockOff(DAPI_CACHE_LOCK_NR); return 0;
        }
        cache_drop_range_locked((int)dnr,block_nr,count);
        written=physical_writeblocks((int)dnr,block_nr,buf,count);
        driver_lockOff(DAPI_CACHE_LOCK_NR);
        dapi_reward_io_progress(written);
        return written;
    }

    for(i=0;i<count;i++) {
        /* cache_store_locked() already has to resolve the resident entry.
         * Return that hit information instead of doing a second 256-entry
         * lookup in the write-back hot path. */
        was_hit=0;
        e=cache_store_locked((int)dnr,block_nr+i,bs,buf+i*bs,1,&was_hit);
        if(was_hit) dapi_cache_write_hits++;
        if(e==NULL) {
            /* Low-memory fallback: commit what we have and issue one direct
             * transfer for the caller's complete request. */
            if(cache_flush_device_locked((int)dnr)!=0) {
                driver_lockOff(DAPI_CACHE_LOCK_NR); return i;
            }
            cache_drop_range_locked((int)dnr,block_nr,count);
            written=physical_writeblocks((int)dnr,block_nr,buf,count);
            driver_lockOff(DAPI_CACHE_LOCK_NR);
            dapi_reward_io_progress(written);
            return written;
        }
    }

    /* Do not wait until every cache entry is dirty and eviction is forced.
     * A 128-sector high-water mark gives sequential 512-byte/4 KiB writers a
     * 64 KiB write-combining window, then drains it as contiguous WRITEBLOCKS
     * runs.  fsync()/syncdev() remain the explicit durability barriers. */
    if(cache_dirty_count_locked((int)dnr)>=DAPI_CACHE_WRITEBACK_HIGH_BLOCKS) {
        dapi_cache_highwater_flushes++;
        if(cache_flush_device_locked((int)dnr)!=0) {
            driver_lockOff(DAPI_CACHE_LOCK_NR);
            return 0;
        }
    }
    driver_lockOff(DAPI_CACHE_LOCK_NR);
    dapi_reward_io_progress(count);
    return count;
}

int readblock(int dnr,int b,BYTE *buf)
{
    if(!isValidDevice(dnr)) return 1;
    if(b<0 || b>=getsize(dnr)) return 2;
    return readblocks(dnr,b,buf,1)==1 ? 0 : 1;
}

int writeblock(int dnr,int b,BYTE *buf)
{
    DEVICE_ENTRY *de;
    if(!isValidDevice(dnr)) return 1;
    de=driver_getdevice(dnr);
    if(de && (de->type & DEVICE_TYPE_READONLY)) return 3;
    if(b<0 || b>=getsize(dnr)) return 2;
    return writeblocks(dnr,b,buf,1)==1 ? 0 : 1;
}

int _readblock(int dnr,int b,BYTE *buf) { return readblock1(dnr,b,buf); }
int _writeblock(int dnr,int b,BYTE *buf) { return writeblock1(dnr,b,buf); }
int readblockCached(long dnr,long block_nr,BYTE *buf) { return readblock((int)dnr,(int)block_nr,buf); }
int writeblockCached(long dnr,long block_nr,BYTE *buf) { return writeblock((int)dnr,(int)block_nr,buf); }

void HDLED(int c)
{
#ifdef ENABLE_DEVAPI_HDLED
    /* VT0 is the hardware EGA/VGA text page at B8000.  Reserve the physical
     * top-right cell only while disk I/O is active: green background=read,
     * red background=write.  Restore the exact previous character/attribute
     * afterwards so the LED never destroys terminal contents. */
    static WORD saved_cell=0;
    static int active=0;
    volatile WORD *vga=(volatile WORD *)0x000B8000UL;
    WORD attr;

    if(c==0) {
        if(active) {
            vga[79]=saved_cell;
            active=0;
        }
        return;
    }

    if(!active) {
        saved_cell=vga[79];
        active=1;
    }
    attr=(c==2) ? 0x4FUL : 0x2FUL;
    vga[79]=(WORD)(' ' | (attr<<8));
#else
    (void)c;
#endif
}
