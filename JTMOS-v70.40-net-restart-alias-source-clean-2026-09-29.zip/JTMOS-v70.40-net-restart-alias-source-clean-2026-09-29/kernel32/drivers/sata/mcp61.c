/* ========================================================================
 * JTMOS NVIDIA MCP61 SATA rescue backend
 *
 * Acer/eMachines EL1352-class systems commonly expose the MCP61 SATA ports as
 * PCI IDE/native-mode functions (10de:03f6, class 01/01, prog-if 85) rather
 * than as AHCI.  A hard-coded 0x1f0 legacy probe can therefore miss the disk
 * even though BIOS calls this an "IDE" mode.
 *
 * This driver is deliberately conservative:
 *   - it only claims known MCP61 SATA PCI IDs;
 *   - task-file I/O addresses come from PCI BAR0..BAR3, never guessed;
 *   - standard PCI IDE bus-master DMA (BAR4) is enabled only when the BIOS
 *     already marks the selected drive DMA-capable;
 *   - IDENTIFY + repeated PIO sector-0 reads must succeed before hda exists;
 *   - the first BMDMA sector read is compared byte-for-byte with PIO, and any
 *     DMA error permanently falls back to the optimized PIO path.
 *
 * V70.12 removes the historical rescue-driver bottlenecks while keeping the
 * existing FlexFAT/DAPI contract and an always-available PIO fallback.
 * ======================================================================== */
#include "kernel32.h"
#include "driver_api.h"
#include "driver_sys.h"
#include "pci.h"
#include "pit.h"
#include "mcp61.h"
#include "scheduler.h"
#include "userhw.h"

#define NVIDIA_VENDOR_ID       0x10de
#define MCP61_SATA_03E7        0x03e7
#define MCP61_SATA_03F6        0x03f6
#define MCP61_SATA_03F7        0x03f7

#define ATA_SR_ERR             0x01
#define ATA_SR_DRQ             0x08
#define ATA_SR_DF              0x20
#define ATA_SR_DRDY            0x40
#define ATA_SR_BSY             0x80

#define ATA_CMD_READ_PIO       0x20
#define ATA_CMD_READ_PIO_EXT   0x24
#define ATA_CMD_WRITE_PIO      0x30
#define ATA_CMD_WRITE_PIO_EXT  0x34
#define ATA_CMD_READ_DMA       0xc8
#define ATA_CMD_WRITE_DMA      0xca
#define ATA_CMD_READ_DMA_EXT   0x25
#define ATA_CMD_WRITE_DMA_EXT  0x35
#define ATA_CMD_CACHE_FLUSH    0xe7
#define ATA_CMD_CACHE_FLUSH_EXT 0xea
#define ATA_CMD_IDENTIFY       0xec

#define MCP61_TIMEOUT_MS       3000UL
#define MCP61_SPIN_LIMIT       80000000UL
#define MCP61_POLL_COOP_MASK   0x0fffUL

/* V70.12: PIO is a fallback, not the fast path.  32 sectors/16 KiB is still
 * modest for READ/WRITE SECTORS but avoids four ATA commands where V70.11
 * used four 4 KiB bursts. */
#define MCP61_SAFE_PIO_SECTORS 32UL

/* Standard PCI IDE bus-master registers (BAR4 + channel*8). */
#define BMDMA_CMD              0
#define BMDMA_STATUS           2
#define BMDMA_PRDT             4
#define BMDMA_START            0x01
#define BMDMA_READ_FROM_DISK   0x08
#define BMDMA_ST_ACTIVE        0x01
#define BMDMA_ST_ERROR         0x02
#define BMDMA_ST_IRQ           0x04
#define BMDMA_DRIVE0_DMA       0x20
#define BMDMA_DRIVE1_DMA       0x40
#define BMDMA_PRD_EOT          0x80000000UL
#define MCP61_DMA_BYTES        65536UL
#define MCP61_DMA_META_BYTES   4096UL
#define MCP61_DMA_TOTAL_BYTES  (MCP61_DMA_META_BYTES+MCP61_DMA_BYTES)
#define MCP61_DMA_SECTORS      (MCP61_DMA_BYTES/512UL)
#define MCP61_DMA_PRD_COUNT    2

typedef struct __attribute__((packed)) {
    DWORD addr;
    DWORD flags_len;
} MCP61_PRD;

typedef struct {
    int present;
    int mounted;
    BYTE bus,dev,fun;
    WORD cmd;
    WORD ctrl;
    WORD bm;
    int channel;
    int slave;
    int lba48;
    int dma_supported;
    int dma_enabled;
    DWORD sectors;
    BYTE *dma_bounce;
    DWORD dma_bounce_phys;
    MCP61_PRD *dma_prd;
    DWORD dma_prd_phys;
    DWORD dma_commands;
    DWORD dma_failures;
    DWORD dma_read_sectors;
    DWORD dma_write_sectors;
    DWORD dma_short_commands; /* 1..8 sectors: metadata/small files */
    DWORD dma_full_commands;  /* >=64 sectors: bulk transfer */
    DWORD pio_commands;
    DWORD pio_sectors;
    char model[41];
} MCP61_DISK;

static MCP61_DISK mcpd;
static DWORD mcp61_debug_rw_seq=0;
static DWORD mcp61_debug_flush_seq=0;

/* V68.199: MCP61 SATA rescue and nForce Ethernet share the same southbridge.
 * Physical EL1352 testing showed that allowing aggressive Ethernet MMIO/MDIO
 * polling while PIO storage is active can destroy forward progress.  Keep a
 * tiny cross-driver arbitration state: storage wins, and Ethernet backs off. */
#define MCP61_NETWORK_QUIET_MS 25UL
static volatile unsigned int mcp61_storage_io_depth=0;
static volatile DWORD mcp61_storage_last_io_tick=0;

static void mcp61_storage_io_enter(void)
{
    DWORD flags=get_eflags();
    disable();
    mcp61_storage_io_depth++;
    set_eflags(flags);
}

static void mcp61_storage_io_leave(void)
{
    DWORD flags=get_eflags();
    DWORD now=GetTickCount();
    disable();
    if(mcp61_storage_io_depth) mcp61_storage_io_depth--;
    mcp61_storage_last_io_tick=now;
    set_eflags(flags);
}

int mcp61_sata_io_busy(void)
{
    return mcp61_storage_io_depth!=0U;
}

int mcp61_sata_network_quiet(void)
{
    DWORD last,now;
    if(!mcpd.present) return 0;
    if(mcp61_storage_io_depth) return 1;
    last=mcp61_storage_last_io_tick;
    if(!last) return 0;
    now=GetTickCount();
    return (DWORD)(now-last)<MCP61_NETWORK_QUIET_MS;
}

static int mcp61_known_id(WORD id)
{
    return id==MCP61_SATA_03E7 || id==MCP61_SATA_03F6 || id==MCP61_SATA_03F7;
}

static BYTE ata_status(void)
{
    return (BYTE)inportb((WORD)(mcpd.cmd+7));
}

static void ata_400ns(void)
{
    /* Native-mode IDE control BAR points at the control block base; alternate
     * status/device-control live at +2. Four reads provide the ATA delay. */
    (void)inportb(mcpd.ctrl); (void)inportb(mcpd.ctrl);
    (void)inportb(mcpd.ctrl); (void)inportb(mcpd.ctrl);
}

static void ata_deadline_start(RTC_IO_DEADLINE *deadline)
{
    rtc_io_deadline_start(deadline,MCP61_TIMEOUT_MS,
        (unsigned int)(MCP61_TIMEOUT_MS/1000UL)+2U,MCP61_SPIN_LIMIT);
}

static int ata_wait_not_busy(void)
{
    DWORD spins=0;
    BYTE st;
    RTC_IO_DEADLINE deadline;
    ata_deadline_start(&deadline);
    do {
        st=ata_status();
        if(st==0x00 || st==0xff) return 1;
        if(!(st&ATA_SR_BSY)) return 0;
        ata_400ns();
        if((spins&MCP61_POLL_COOP_MASK)==MCP61_POLL_COOP_MASK) SchedulerCooperate();
        spins++;
    } while(!rtc_io_deadline_expired(&deadline));
    return 1;
}

static int ata_wait_drq(void)
{
    DWORD spins=0;
    BYTE st;
    RTC_IO_DEADLINE deadline;
    ata_deadline_start(&deadline);
    for(;;) {
        st=ata_status();
        if(st==0x00 || st==0xff) return 1;
        if(!(st&ATA_SR_BSY)) {
            if(st&(ATA_SR_ERR|ATA_SR_DF)) return 1;
            if(st&ATA_SR_DRQ) return 0;
        }
        ata_400ns();
        if((spins&MCP61_POLL_COOP_MASK)==MCP61_POLL_COOP_MASK) SchedulerCooperate();
        spins++;
        if(rtc_io_deadline_expired(&deadline)) return 1;
    }
}

static void ata_select(int slave)
{
    outportb((WORD)(mcpd.cmd+6),(BYTE)(slave ? 0xb0 : 0xa0));
    ata_400ns();
}

static int ata_identify(int slave)
{
    WORD id[256];
    unsigned long long n48;
    DWORD n28;
    int i,j,end;

    ata_select(slave);
    outportb((WORD)(mcpd.cmd+1),0);
    outportb((WORD)(mcpd.cmd+2),0);
    outportb((WORD)(mcpd.cmd+3),0);
    outportb((WORD)(mcpd.cmd+4),0);
    outportb((WORD)(mcpd.cmd+5),0);
    outportb((WORD)(mcpd.cmd+7),ATA_CMD_IDENTIFY);
    ata_400ns();
    if(ata_wait_not_busy()) return 1;
    if(ata_wait_drq()) return 1;

    inportsw(mcpd.cmd,id,256);

    if(!(id[49]&(1U<<9))) return 1; /* SATA media must support LBA */
    mcpd.dma_supported=(id[49]&(1U<<8)) ? 1 : 0;
    mcpd.lba48=(id[83]&(1U<<10)) ? 1 : 0;
    n28=((DWORD)id[61]<<16)|(DWORD)id[60];
    n48=((unsigned long long)id[100])|
        ((unsigned long long)id[101]<<16)|
        ((unsigned long long)id[102]<<32)|
        ((unsigned long long)id[103]<<48);
    if(mcpd.lba48 && n48) mcpd.sectors=n48>0xffffffffULL ? 0xffffffffUL : (DWORD)n48;
    else mcpd.sectors=n28;
    if(!mcpd.sectors) return 1;
    dprintk("MCP61/identify: %s LBA28=%u LBA48=%08x:%08x supported=%d DMA=%d exported=%u sectors (%u MiB).\n",
            slave?"slave":"master",(unsigned)n28,
            (unsigned)(DWORD)(n48>>32),(unsigned)(DWORD)n48,mcpd.lba48,
            mcpd.dma_supported,(unsigned)mcpd.sectors,
            (unsigned)((unsigned long long)mcpd.sectors/2048ULL));

    j=0;
    for(i=27;i<=46 && j<40;i++) {
        mcpd.model[j++]=(char)((id[i]>>8)&0xff);
        mcpd.model[j++]=(char)(id[i]&0xff);
    }
    mcpd.model[40]=0;
    end=39;
    while(end>=0 && (mcpd.model[end]==' ' || mcpd.model[end]==0)) mcpd.model[end--]=0;
    mcpd.slave=slave;
    return 0;
}

static int ata_flush(void);

static void ata_program_lba(unsigned long long lba,WORD count,int ext)
{
    BYTE drive=(BYTE)(0xe0 | (mcpd.slave ? 0x10 : 0));
    if(ext) {
        outportb((WORD)(mcpd.cmd+6),drive);
        ata_400ns();
        outportb((WORD)(mcpd.cmd+2),(BYTE)((count>>8)&0xff));
        outportb((WORD)(mcpd.cmd+3),(BYTE)((lba>>24)&0xff));
        outportb((WORD)(mcpd.cmd+4),(BYTE)((lba>>32)&0xff));
        outportb((WORD)(mcpd.cmd+5),(BYTE)((lba>>40)&0xff));
        outportb((WORD)(mcpd.cmd+2),(BYTE)(count&0xff));
        outportb((WORD)(mcpd.cmd+3),(BYTE)(lba&0xff));
        outportb((WORD)(mcpd.cmd+4),(BYTE)((lba>>8)&0xff));
        outportb((WORD)(mcpd.cmd+5),(BYTE)((lba>>16)&0xff));
    } else {
        drive|=(BYTE)((lba>>24)&0x0f);
        outportb((WORD)(mcpd.cmd+6),drive);
        ata_400ns();
        outportb((WORD)(mcpd.cmd+2),(BYTE)(count&0xff));
        outportb((WORD)(mcpd.cmd+3),(BYTE)(lba&0xff));
        outportb((WORD)(mcpd.cmd+4),(BYTE)((lba>>8)&0xff));
        outportb((WORD)(mcpd.cmd+5),(BYTE)((lba>>16)&0xff));
    }
}

static int ata_pio_rw(DWORD first,int count,BYTE *buf,int write)
{
    DWORD lba,left,chunk,off,seq;
    int ext,s;
    BYTE cmd;
    if(buf==NULL || count<=0 || first>=mcpd.sectors ||
       (DWORD)count>mcpd.sectors-first) {
        dprintk("MCP61/pio: reject %s LBA=%u count=%d sectors=%u buffer=0x%x.\n",
                write?"WRITE":"READ",(unsigned)first,count,
                (unsigned)mcpd.sectors,(unsigned)buf);
        return 1;
    }

    seq=++mcp61_debug_rw_seq;
    if(count>=32 && (seq<=8 || (seq&0x3ffUL)==0))
        dprintk("MCP61/pio #%u: %s LBA=%u count=%d bytes=%u safe-PIO=%u sectors.\n",
                (unsigned)seq,write?"WRITE":"READ",(unsigned)first,count,
                (unsigned)((DWORD)count*512UL),(unsigned)MCP61_SAFE_PIO_SECTORS);

    lba=first; left=(DWORD)count; off=0;
    while(left) {
        chunk=left>MCP61_SAFE_PIO_SECTORS ? MCP61_SAFE_PIO_SECTORS : left;
        ext=mcpd.lba48 ? 1 : 0;
        if(!mcpd.lba48 && ((unsigned long long)lba+chunk>0x10000000ULL)) return 1;
        if(ata_wait_not_busy()) return 1;
        ata_program_lba((unsigned long long)lba,(WORD)chunk,ext);
        cmd=write ? (ext ? ATA_CMD_WRITE_PIO_EXT : ATA_CMD_WRITE_PIO)
                  : (ext ? ATA_CMD_READ_PIO_EXT  : ATA_CMD_READ_PIO);
        outportb((WORD)(mcpd.cmd+7),cmd);
        ata_400ns();

        for(s=0;s<(int)chunk;s++) {
            if(ata_wait_drq()) {
                printk("SATA MCP61: PIO %s failed lba=%u sector=%d status=0x%x.\n",
                       write?"write":"read",(unsigned)lba,s,ata_status());
                return 1;
            }
            if(write) outportsw(mcpd.cmd,buf+off,256);
            else inportsw(mcpd.cmd,buf+off,256);
            off+=512;
            if(write) ata_400ns();
        }
        if(ata_wait_not_busy()) return 1;
        mcpd.pio_commands++;
        mcpd.pio_sectors+=chunk;
        lba+=chunk; left-=chunk;
    }

    /* Durability is handled by DEVICE_CMD_FLUSH after DAPI write-back.  V70.11
     * flushed the disk after every physical write request, serializing the
     * drive cache and making small writes orders of magnitude slower. */
    return 0;
}

static int bmdma_build_prd(DWORD phys,DWORD bytes)
{
    int n=0;
    DWORD chunk,boundary;
    if(!mcpd.dma_prd || bytes==0 || bytes>MCP61_DMA_BYTES) return 1;
    while(bytes) {
        if(n>=MCP61_DMA_PRD_COUNT) return 1;
        boundary=0x10000UL-(phys&0xffffUL);
        if(boundary==0) boundary=0x10000UL;
        chunk=bytes<boundary ? bytes : boundary;
        mcpd.dma_prd[n].addr=phys;
        mcpd.dma_prd[n].flags_len=(chunk==0x10000UL) ? 0UL : (chunk&0xffffUL);
        phys+=chunk; bytes-=chunk; n++;
    }
    mcpd.dma_prd[n-1].flags_len|=BMDMA_PRD_EOT;
    return 0;
}

static void bmdma_stop_clear(void)
{
    BYTE cmd,st;
    if(!mcpd.bm) return;
    cmd=(BYTE)inportb((WORD)(mcpd.bm+BMDMA_CMD));
    outportb((WORD)(mcpd.bm+BMDMA_CMD),(BYTE)(cmd&~BMDMA_START));
    st=(BYTE)inportb((WORD)(mcpd.bm+BMDMA_STATUS));
    outportb((WORD)(mcpd.bm+BMDMA_STATUS),(BYTE)(st|BMDMA_ST_ERROR|BMDMA_ST_IRQ));
}

static int bmdma_wait_complete(void)
{
    DWORD spins=0;
    BYTE bst,ast;
    RTC_IO_DEADLINE deadline;
    ata_deadline_start(&deadline);
    for(;;) {
        bst=(BYTE)inportb((WORD)(mcpd.bm+BMDMA_STATUS));
        ast=ata_status();
        if((bst&BMDMA_ST_ERROR) || (ast&(ATA_SR_ERR|ATA_SR_DF))) return 1;
        if(!(bst&BMDMA_ST_ACTIVE) && !(ast&ATA_SR_BSY)) return 0;
        if((spins&MCP61_POLL_COOP_MASK)==MCP61_POLL_COOP_MASK)
            SchedulerCooperate();
        spins++;
        if(rtc_io_deadline_expired(&deadline)) return 1;
    }
}

static int ata_dma_rw(DWORD first,int count,BYTE *buf,int write)
{
    DWORD lba,left,chunk,off,bytes;
    BYTE dmactl,cmd,bst,ast;
    int ext;
    if(!mcpd.dma_enabled || !mcpd.bm || !mcpd.dma_bounce || !mcpd.dma_prd ||
       !buf || count<=0 || first>=mcpd.sectors || (DWORD)count>mcpd.sectors-first)
        return 1;

    lba=first; left=(DWORD)count; off=0;
    while(left) {
        chunk=left>MCP61_DMA_SECTORS ? MCP61_DMA_SECTORS : left;
        bytes=chunk*512UL;
        ext=mcpd.lba48 ? 1 : 0;
        if(!mcpd.lba48 && ((unsigned long long)lba+chunk>0x10000000ULL)) return 1;
        if(write) memcpy(mcpd.dma_bounce,buf+off,(int)bytes);
        if(bmdma_build_prd(mcpd.dma_bounce_phys,bytes)) return 1;
        if(ata_wait_not_busy()) return 1;

        bmdma_stop_clear();
        outportd((WORD)(mcpd.bm+BMDMA_PRDT),mcpd.dma_prd_phys);
        dmactl=write ? 0 : BMDMA_READ_FROM_DISK;
        outportb((WORD)(mcpd.bm+BMDMA_CMD),dmactl);

        ata_program_lba((unsigned long long)lba,(WORD)chunk,ext);
        cmd=write ? (ext ? ATA_CMD_WRITE_DMA_EXT : ATA_CMD_WRITE_DMA)
                  : (ext ? ATA_CMD_READ_DMA_EXT  : ATA_CMD_READ_DMA);
        __asm__ __volatile__("" ::: "memory");
        outportb((WORD)(mcpd.cmd+7),cmd);
        ata_400ns();
        outportb((WORD)(mcpd.bm+BMDMA_CMD),(BYTE)(dmactl|BMDMA_START));

        if(bmdma_wait_complete()) {
            bst=(BYTE)inportb((WORD)(mcpd.bm+BMDMA_STATUS));
            ast=ata_status();
            bmdma_stop_clear();
            mcpd.dma_failures++;
            dprintk("MCP61/BMDMA: %s failed LBA=%u count=%u bm=0x%x ata=0x%x.\n",
                    write?"write":"read",(unsigned)lba,(unsigned)chunk,
                    (unsigned)bst,(unsigned)ast);
            return 1;
        }
        bmdma_stop_clear();
        __asm__ __volatile__("" ::: "memory");
        if(!write) memcpy(buf+off,mcpd.dma_bounce,(int)bytes);
        mcpd.dma_commands++;
        if(write) mcpd.dma_write_sectors+=chunk;
        else mcpd.dma_read_sectors+=chunk;
        if(chunk<=8UL) mcpd.dma_short_commands++;
        if(chunk>=64UL) mcpd.dma_full_commands++;
        lba+=chunk; left-=chunk; off+=bytes;
    }
    return 0;
}

static int mcp61_bmdma_prepare(const PCIDEVICE *d,int channel)
{
    PCIBAR bar;
    BYTE st,drive_bit;
    BYTE pio[512],dma[512];
    DWORD addr;
    int i;

    if(!d || !(d->prog_if&0x80) || !mcpd.dma_supported) return 0;
    if(pci_get_bar(d,4,&bar)!=0 || !bar.valid || !bar.io || !bar.base_low ||
       bar.base_low>0xffffUL) return 0;
    if(pci_enable_device(d,PCI_ENABLE_IO|PCI_ENABLE_MASTER)!=0) return 0;

    mcpd.bm=(WORD)(bar.base_low+(channel ? 8 : 0));
    mcpd.channel=channel;
    st=(BYTE)inportb((WORD)(mcpd.bm+BMDMA_STATUS));
    drive_bit=mcpd.slave ? BMDMA_DRIVE1_DMA : BMDMA_DRIVE0_DMA;
    if(!(st&drive_bit)) {
        printk("SATA MCP61: BMDMA present at 0x%x but BIOS left %s in PIO mode; keeping PIO fallback.\n",
               mcpd.bm,mcpd.slave?"slave":"master");
        mcpd.bm=0;
        return 0;
    }

    /* One contiguous allocation avoids partial-allocation leaks: first page is
     * the PRD table, followed by the 64 KiB bounce area. */
    addr=userhw_dma_alloc_kernel32(MCP61_DMA_TOTAL_BYTES,&mcpd.dma_prd_phys);
    if(!addr) { mcpd.bm=0; return 0; }
    mcpd.dma_prd=(MCP61_PRD *)addr;
    mcpd.dma_bounce=(BYTE *)(addr+MCP61_DMA_META_BYTES);
    mcpd.dma_bounce_phys=mcpd.dma_prd_phys+MCP61_DMA_META_BYTES;
    if(userhw_dma_verify_kernel32(addr,mcpd.dma_prd_phys,MCP61_DMA_TOTAL_BYTES)!=0) {
        mcpd.bm=0; mcpd.dma_bounce=NULL; mcpd.dma_prd=NULL; return 0;
    }
    memset(mcpd.dma_prd,0,MCP61_DMA_META_BYTES);
    bmdma_stop_clear();

    /* Compare the first DMA transfer with known-good PIO before exposing DMA
     * to DAPI/FlexFAT.  A failed comparison leaves the disk usable in PIO. */
    if(ata_pio_rw(0,1,pio,0)) { mcpd.bm=0; return 0; }
    mcpd.dma_enabled=1;
    if(ata_dma_rw(0,1,dma,0)) {
        mcpd.dma_enabled=0;
        printk("SATA MCP61: BMDMA self-test failed; falling back to PIO.\n");
        return 0;
    }
    for(i=0;i<512;i++) if(pio[i]!=dma[i]) {
        mcpd.dma_enabled=0;
        printk("SATA MCP61: BMDMA/PIO compare mismatch; falling back to PIO.\n");
        return 0;
    }
    printk("SATA MCP61: standard PCI IDE BMDMA enabled at 0x%x, 64 KiB bounce/PRD self-test PASS.\n",
           mcpd.bm);
    return 1;
}

static int ata_rw(DWORD first,int count,BYTE *buf,int write)
{
    if(mcpd.dma_enabled) {
        if(ata_dma_rw(first,count,buf,write)==0) return 0;
        /* A timeout/error disables DMA for the rest of this boot. Reads can be
         * retried safely through PIO.  For writes report the failed command to
         * the cache/filesystem instead of guessing how much reached media. */
        bmdma_stop_clear();
        mcpd.dma_enabled=0;
        printk("SATA MCP61: disabling BMDMA after runtime error; continuing with PIO.\n");
        if(write) return 1;
    }
    return ata_pio_rw(first,count,buf,write);
}

static int ata_flush(void)
{
    DWORD seq=++mcp61_debug_flush_seq;
    BYTE st;
    if(seq<=8 || (seq&0xffUL)==0)
        dprintk("MCP61/flush #%u begin command=%s.\n",
                (unsigned)seq,mcpd.lba48?"FLUSH CACHE EXT":"FLUSH CACHE");
    ata_select(mcpd.slave);
    outportb((WORD)(mcpd.cmd+7),mcpd.lba48 ? ATA_CMD_CACHE_FLUSH_EXT : ATA_CMD_CACHE_FLUSH);
    ata_400ns();
    if(ata_wait_not_busy()) {
        dprintk("MCP61/flush #%u timeout status=0x%x.\n",(unsigned)seq,(unsigned)ata_status());
        return 1;
    }
    st=ata_status();
    if((st&(ATA_SR_ERR|ATA_SR_DF)) || seq<=8 || (seq&0xffUL)==0)
        dprintk("MCP61/flush #%u end status=0x%x result=%d.\n",
                (unsigned)seq,(unsigned)st,(st&(ATA_SR_ERR|ATA_SR_DF))?1:0);
    return (st&(ATA_SR_ERR|ATA_SR_DF)) ? 1 : 0;
}

static int ata_sector_sanity(void)
{
    BYTE a[512],b[512];
    int i;
    if(ata_pio_rw(0,1,a,0) || ata_pio_rw(0,1,b,0)) return 1;
    for(i=0;i<512;i++) if(a[i]!=b[i]) return 1;
    return 0;
}

static int mcp61_guarded_rw(DWORD first,int count,BYTE *buf,int write)
{
    int rv;
    mcp61_storage_io_enter();
    rv=ata_rw(first,count,buf,write);
    mcp61_storage_io_leave();
    return rv;
}

static int mcp61_guarded_pio_rw(DWORD first,int count,BYTE *buf,int write)
{
    int rv;
    mcp61_storage_io_enter();
    rv=ata_pio_rw(first,count,buf,write);
    mcp61_storage_io_leave();
    return rv;
}

static int mcp61_guarded_flush(void)
{
    int rv;
    mcp61_storage_io_enter();
    rv=ata_flush();
    mcp61_storage_io_leave();
    return rv;
}

static int mcp61_device_call(DEVICE_CALL_PARS)
{
    DWORD *size;
    (void)p3; (void)p4; (void)po2;
    if(n_call!=DEVICE_CMD_MOUNT && !mcpd.mounted) return 1;
    switch(n_call) {
        case DEVICE_CMD_MOUNT: mcpd.mounted=1; return 0;
        case DEVICE_CMD_UNMOUNT: mcpd.mounted=0; return 0;
        case DEVICE_CMD_INIT: return 0;
        case DEVICE_CMD_SHUTDOWN: return mcp61_guarded_flush();
        case DEVICE_CMD_READBLOCK: return mcp61_guarded_rw((DWORD)p1,1,(BYTE *)po1,0);
        case DEVICE_CMD_WRITEBLOCK: return mcp61_guarded_rw((DWORD)p1,1,(BYTE *)po1,1);
        case DEVICE_CMD_READBLOCKS: return mcp61_guarded_rw((DWORD)p1,p2,(BYTE *)po1,0);
        case DEVICE_CMD_READBLOCKS_RAW_PIO:
            /* Keep hdbench --raw-pio as a true PIO diagnostic even when the
             * normal MCP61 backend is running BMDMA. */
            return mcp61_guarded_pio_rw((DWORD)p1,p2,(BYTE *)po1,0);
        case DEVICE_CMD_WRITEBLOCKS: return mcp61_guarded_rw((DWORD)p1,p2,(BYTE *)po1,1);
        case DEVICE_CMD_GETSIZE:
            if(!po1) return 1;
            size=(DWORD *)po1; *size=mcpd.sectors; return 0;
        case DEVICE_CMD_GETBLOCKSIZE:
            if(!po1) return 1;
            size=(DWORD *)po1; *size=512; return 0;
        case DEVICE_CMD_FLUSH: return mcp61_guarded_flush();
        default: return 0;
    }
}

/* Called outside timed benchmark intervals through fsgeom hda.  The short
 * command share separates seek/metadata latency from bulk throughput. */
void mcp61_sata_print_stats(void)
{
    DWORD total=mcpd.dma_read_sectors+mcpd.dma_write_sectors;
    if(!mcpd.present) return;
    printk("MCP61 SATA: mode=%s DMA commands=%u sectors=%u read=%u write=%u short(<=8)=%u full(>=64)=%u failures=%u flushes=%u\n",
           mcpd.dma_enabled?"BMDMA":"PIO",(unsigned)mcpd.dma_commands,
           (unsigned)total,(unsigned)mcpd.dma_read_sectors,
           (unsigned)mcpd.dma_write_sectors,(unsigned)mcpd.dma_short_commands,
           (unsigned)mcpd.dma_full_commands,(unsigned)mcpd.dma_failures,
           (unsigned)mcp61_debug_flush_seq);
    printk("MCP61 SATA: PIO commands=%u sectors=%u (includes probe/self-test).\n",
           (unsigned)mcpd.pio_commands,(unsigned)mcpd.pio_sectors);
}

static int mcp61_register_hda(void)
{
    int dnr;
    if(driver_getdevicebyname("hda")) return 1;
    dnr=driver_register_new_device("hda",mcp61_device_call,
                                   DEVICE_TYPE_BLOCK|DEVICE_TYPE_MULTIBLOCK|
                                   DEVICE_TYPE_RAW_PIO_READ);
    if(dnr<0) return 1;
    driver_geometry_seed(dnr,mcpd.sectors,512);
    driver_enableDAPIReadCache(dnr);
    /* DAPI combines small writes and provides the durability boundary through
     * DEVICE_CMD_FLUSH.  BMDMA handles up to 64 KiB per command; the PIO
     * fallback handles bounded 16 KiB bursts. */
    driver_enableDAPIWriteBackCache(dnr);
    printk("SATA rescue: hda DAPI policy = 16 KiB read-ahead + bounded write-back.\n");
    return 0;
}

static int mcp61_try_channel(const PCIDEVICE *d,int channel)
{
    PCIBAR cmdbar,ctlbar;
    int bcmd=channel ? 2 : 0;
    int bctl=channel ? 3 : 1;
    int slave;

    if(pci_get_bar(d,bcmd,&cmdbar)!=0 || !cmdbar.valid || !cmdbar.io || !cmdbar.base_low)
        return 0;
    if(pci_get_bar(d,bctl,&ctlbar)!=0 || !ctlbar.valid || !ctlbar.io || !ctlbar.base_low)
        return 0;
    if(cmdbar.base_low>0xffffUL || ctlbar.base_low>0xffffUL) return 0;

    mcpd.cmd=(WORD)cmdbar.base_low;
    mcpd.ctrl=(WORD)(ctlbar.base_low+2);
    printk("SATA rescue: MCP61 PCI %d:%d.%d ch%d taskfile=0x%x ctrl=0x%x.\n",
           d->bus,d->device,d->function,channel,mcpd.cmd,mcpd.ctrl);

    /* Disable channel IRQ at device-control while the rescue backend uses
     * polling. This does not change transfer mode or reset the controller. */
    outportb(mcpd.ctrl,0x02);
    ata_400ns();
    for(slave=0;slave<2;slave++) {
        if(ata_identify(slave)==0) {
            printk("SATA rescue: IDENTIFY succeeded on ch%d %s, model '%s'.\n",
                   channel,slave?"slave":"master",mcpd.model);
            if(ata_sector_sanity()==0) {
                (void)mcp61_bmdma_prepare(d,channel);
                return 1;
            }
            printk("SATA MCP61: sector-0 repeat-read sanity failed; rejecting this port.\n");
        }
    }
    return 0;
}

int mcp61_sata_hda_active(void)
{
    return mcpd.present;
}

int mcp61_sata_init_hda(void)
{
    int i,channel;
    const PCIDEVICE *d;
    memset(&mcpd,0,sizeof(mcpd));
    pci_init();

    for(i=0;i<pci_get_device_count();i++) {
        d=pci_get_device(i);
        if(!d || d->vendor_id!=NVIDIA_VENDOR_ID || !mcp61_known_id(d->device_id)) continue;
        if(d->class_code!=0x01 || d->subclass!=0x01) continue;
        if(pci_enable_device(d,PCI_ENABLE_IO)!=0) continue;
        printk("SATA rescue: found NVIDIA MCP61 SATA %04x at PCI %d:%d.%d prog-if=0x%x.\n",
               d->device_id,d->bus,d->device,d->function,d->prog_if);
        mcpd.bus=d->bus; mcpd.dev=d->device; mcpd.fun=d->function;
        for(channel=0;channel<2;channel++) {
            if(mcp61_try_channel(d,channel)) {
                mcpd.mounted=1;
                if(mcp61_register_hda()) return -1;
                mcpd.present=1;
                printk("SATA MCP61: hda registered %s/%s, %u sectors.\n",
                       mcpd.dma_enabled?"BMDMA":"PIO",
                       mcpd.lba48?"LBA48":"LBA28",(unsigned)mcpd.sectors);
                printk("SATA MCP61: native <=64 KiB DMA; PIO fallback <=32 sectors; DAPI read-ahead/write-back enabled.\n");
                return 1;
            }
        }
    }
    return 0;
}
