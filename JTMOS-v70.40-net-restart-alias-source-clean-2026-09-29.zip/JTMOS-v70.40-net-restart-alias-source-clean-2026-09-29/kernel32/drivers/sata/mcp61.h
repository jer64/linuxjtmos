#ifndef __JTMOS_MCP61_SATA_H__
#define __JTMOS_MCP61_SATA_H__

/* NVIDIA MCP61 (GeForce 6150SE/nForce 430) exposes SATA in PCI IDE/native
 * mode on common eMachines systems instead of class-code AHCI.  This backend
 * probes those native task-file BARs and registers the first usable SATA ATA
 * disk as hda:. */
int mcp61_sata_init_hda(void);
int mcp61_sata_hda_active(void);
void mcp61_sata_print_stats(void);
/* Shared MCP61 southbridge arbitration.  The eMachines EL1352 can expose
 * both SATA rescue PIO and nForce Ethernet through the same MCP61.  Network
 * polling must back off while storage owns the southbridge. */
int mcp61_sata_io_busy(void);
int mcp61_sata_network_quiet(void);

#endif
