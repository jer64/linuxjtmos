/*
 * JTMOS single-seat input backend policy.
 *
 * Exactly one producer owns the logical keyboard and one producer owns the
 * logical mouse.  Native USB is preferred, PS/2/BIOS-legacy is fallback.
 * Merely finding a PCI USB controller is not enough to claim an input class:
 * the first valid HID report promotes that class to USB.  Once promoted,
 * lower-priority PS/2 bytes are drained by their hardware drivers but ignored
 * by the logical input layer, so PS/2 can never override a working USB device.
 */
#include "kernel32.h"
#include "input_policy.h"

static volatile int input_policy_initialized=0;
static volatile int input_keyboard_backend=INPUT_BACKEND_NONE;
static volatile int input_mouse_backend=INPUT_BACKEND_NONE;
static volatile DWORD input_keyboard_usb_promotions=0;
static volatile DWORD input_mouse_usb_promotions=0;
static volatile DWORD input_keyboard_ps2_dropped=0;
static volatile DWORD input_keyboard_usb_last_activity=0;
static volatile DWORD input_keyboard_ps2_failbacks=0;
#define INPUT_USB_KEYBOARD_STALE_MS 1500UL
static volatile DWORD input_mouse_ps2_dropped=0;

void input_policy_init(void)
{
    if(input_policy_initialized) return;
    input_keyboard_backend=INPUT_BACKEND_NONE;
    input_mouse_backend=INPUT_BACKEND_NONE;
    input_keyboard_usb_promotions=0;
    input_mouse_usb_promotions=0;
    input_keyboard_ps2_dropped=0;
    input_mouse_ps2_dropped=0;
    input_keyboard_usb_last_activity=0;
    input_keyboard_ps2_failbacks=0;
    input_policy_initialized=1;
    printk("Input policy: one keyboard + one mouse; priority USB -> PS/2 fallback.\n");
}

const char *input_policy_backend_name(int backend)
{
    switch(backend)
    {
        case INPUT_BACKEND_USB: return "USB";
        case INPUT_BACKEND_PS2: return "PS/2/BIOS-legacy";
        default: return "none";
    }
}

void input_policy_note_keyboard_activity(int backend)
{
    input_policy_init();
    if(backend==INPUT_BACKEND_USB)
        input_keyboard_usb_last_activity=GetTickCount();
}

/* Return non-zero if this event is allowed to reach the logical keyboard. */
int input_policy_keyboard_event(int backend)
{
    input_policy_init();

    if(backend==INPUT_BACKEND_USB)
    {
        if(input_keyboard_backend!=INPUT_BACKEND_USB)
        {
            printk("Input policy: keyboard backend -> USB (PS/2 fallback locked out).\n");
            input_keyboard_backend=INPUT_BACKEND_USB;
            input_keyboard_usb_promotions++;
            input_keyboard_usb_last_activity=GetTickCount();
        }
        return 1;
    }

    if(backend==INPUT_BACKEND_PS2)
    {
        /* A USB keyboard may disappear, stall, or be only partially usable on
         * old OHCI/legacy firmware. Do not permanently suppress a real PS/2
         * byte just because USB once produced a report. If USB has had no real
         * key activity for a while, the new PS/2 byte is stronger evidence of
         * a usable keyboard and is allowed to reclaim the logical seat. */
        if(input_keyboard_backend==INPUT_BACKEND_USB &&
           (DWORD)(GetTickCount()-input_keyboard_usb_last_activity)>=INPUT_USB_KEYBOARD_STALE_MS)
        {
            input_keyboard_backend=INPUT_BACKEND_PS2;
            input_keyboard_ps2_failbacks++;
            printk("Input policy: stale USB keyboard -> PS/2/BIOS-legacy failback.\n");
            return 1;
        }
        if(input_keyboard_backend==INPUT_BACKEND_NONE)
        {
            input_keyboard_backend=INPUT_BACKEND_PS2;
            printk("Input policy: keyboard backend -> PS/2/BIOS-legacy fallback.\n");
            return 1;
        }
        if(input_keyboard_backend==INPUT_BACKEND_PS2) return 1;
        input_keyboard_ps2_dropped++;
    }
    return 0;
}

/* Return non-zero if this event is allowed to reach the logical mouse. */
int input_policy_mouse_event(int backend)
{
    input_policy_init();

    if(backend==INPUT_BACKEND_USB)
    {
        if(input_mouse_backend!=INPUT_BACKEND_USB)
        {
            printk("Input policy: mouse backend -> USB (PS/2 fallback locked out).\n");
            input_mouse_backend=INPUT_BACKEND_USB;
            input_mouse_usb_promotions++;
        }
        return 1;
    }

    if(backend==INPUT_BACKEND_PS2)
    {
        if(input_mouse_backend==INPUT_BACKEND_NONE)
        {
            input_mouse_backend=INPUT_BACKEND_PS2;
            printk("Input policy: mouse backend -> PS/2/BIOS-legacy fallback.\n");
            return 1;
        }
        if(input_mouse_backend==INPUT_BACKEND_PS2) return 1;
        input_mouse_ps2_dropped++;
    }
    return 0;
}

void input_policy_release_keyboard(int backend)
{
    input_policy_init();
    if(input_keyboard_backend==backend)
        input_keyboard_backend=INPUT_BACKEND_NONE;
}

void input_policy_release_mouse(int backend)
{
    input_policy_init();
    if(input_mouse_backend==backend)
        input_mouse_backend=INPUT_BACKEND_NONE;
}

int input_policy_keyboard_backend(void)
{
    input_policy_init();
    return input_keyboard_backend;
}

int input_policy_mouse_backend(void)
{
    input_policy_init();
    return input_mouse_backend;
}

void input_policy_dump(void)
{
    input_policy_init();
    printk("Input policy: keyboard=%s mouse=%s preference=USB->PS/2\n",
           input_policy_backend_name(input_keyboard_backend),
           input_policy_backend_name(input_mouse_backend));
    printk("Input policy: USB promotions kbd=%lu mouse=%lu; suppressed PS/2 kbd=%lu mouse=%lu\n",
           (unsigned long)input_keyboard_usb_promotions,
           (unsigned long)input_mouse_usb_promotions,
           (unsigned long)input_keyboard_ps2_dropped,
           (unsigned long)input_mouse_ps2_dropped);
    printk("Input policy: USB keyboard last-activity=%lu ms PS/2 failbacks=%lu stale=%lu ms\n",
           (unsigned long)input_keyboard_usb_last_activity,
           (unsigned long)input_keyboard_ps2_failbacks,
           (unsigned long)INPUT_USB_KEYBOARD_STALE_MS);
}
