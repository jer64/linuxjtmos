/*
 * KAsync - bounded asynchronous kernel work queue for JTMOS.
 *
 * V68.217 replaces whole-table CLI serialization with a sleeping mutex.  Job
 * state transitions remain short transactions, workers run callbacks without
 * the mutex, and submissions explicitly wake sleeping workers.
 */
#include "kernel32.h"
#include "kasync.h"
#include "scheduler.h"
#include "mutex.h"

#define KASYNC_EAGAIN       (-11)
#define KASYNC_EINVAL       (-22)
#define KASYNC_ETIMEDOUT   (-110)
#define KASYNC_ECANCELLED  (-125)
#define KASYNC_WORKER_IDLE_US 10000UL

typedef struct
{
    int state;
    int generation;
    int id;
    int result;
    int flags;
    int cancel_requested;
    DWORD sequence;
    DWORD submitted_at;
    DWORD started_at;
    DWORD finished_at;
    DWORD deadline;
    KASYNC_FUNCTION function;
    unsigned int argument_size;
    BYTE argument[KASYNC_ARG_MAX];
} KJOB;

static KJOB jobs[KASYNC_MAX_JOBS];
static THREAD workers[KASYNC_WORKERS];
static DWORD sequence;
static int initialized;
static DEFINE_MUTEX(kasync_lock);

static int kasync_terminal(int state)
{
    return state==KASYNC_DONE || state==KASYNC_CANCELLED ||
           state==KASYNC_TIMEDOUT;
}

static int kasync_deadline_reached(const KJOB *job,DWORD now)
{
    if(job==0 || job->deadline==0) return 0;
    return (DWORD)(now-job->deadline)<0x80000000UL;
}

/* Keep deadline comparisons inside the unambiguous half of the 32-bit tick
 * range.  Zero remains the public/internal "no deadline" sentinel. */
static DWORD kasync_make_deadline(DWORD now,DWORD timeout_ms)
{
    DWORD deadline;
    if(timeout_ms==0) return 0;
    if(timeout_ms>0x7fffffffUL) timeout_ms=0x7fffffffUL;
    deadline=now+timeout_ms;
    if(deadline==0) deadline=1;
    return deadline;
}

/* Generation survives a free/reuse cycle, while every pointer and timestamp
 * is scrubbed.  Stale IDs therefore cannot observe a newly reused slot. */
static void kasync_make_free(KJOB *job)
{
    int generation;
    if(job==0) return;
    generation=job->generation;
    memset(job,0,sizeof(*job));
    job->generation=generation;
}

/* Caller holds kasync_lock. */
static KJOB *kasync_lookup_locked(int id)
{
    int slot=id&255;
    if(slot<0 || slot>=KASYNC_MAX_JOBS) return 0;
    if(jobs[slot].state==KASYNC_FREE || jobs[slot].id!=id) return 0;
    return &jobs[slot];
}

/* Caller holds kasync_lock. */
static void kasync_fill_status_locked(const KJOB *job,KASYNC_STATUS *status)
{
    if(job==0 || status==0) return;
    status->id=job->id;
    status->state=job->state;
    status->result=job->result;
    status->submitted_at=job->submitted_at;
    status->started_at=job->started_at;
    status->finished_at=job->finished_at;
    status->deadline=job->deadline;
}

/* Caller holds kasync_lock. */
static void kasync_finish_queued_locked(KJOB *job,int state,int result,DWORD now)
{
    job->state=state;
    job->result=result;
    job->finished_at=now;
    if(job->flags&KASYNC_DETACHED) kasync_make_free(job);
}

/* Expire every queued job, not just the one a worker happens to inspect.
 * This keeps poll/count/submit truthful even while all workers are occupied by
 * long callbacks, and reclaims detached slots without needing a free worker. */
static void kasync_expire_queued_locked(DWORD now)
{
    int i;
    for(i=0;i<KASYNC_MAX_JOBS;i++)
        if(jobs[i].state==KASYNC_QUEUED &&
           kasync_deadline_reached(&jobs[i],now))
            kasync_finish_queued_locked(&jobs[i],KASYNC_TIMEDOUT,
                                        KASYNC_ETIMEDOUT,now);
}

/* Claim the oldest runnable job.  Age relative to the current sequence is
 * wrap-safe; comparing raw sequence values broke FIFO order after wrap. */
static int kasync_take(void)
{
    int i,slot;
    DWORD age,oldest_age,now;
    KJOB *job;

    mutex_lock(&kasync_lock);
    for(;;)
    {
        now=GetTickCount();
        kasync_expire_queued_locked(now);
        slot=-1;
        oldest_age=0;
        for(i=0;i<KASYNC_MAX_JOBS;i++)
        {
            if(jobs[i].state!=KASYNC_QUEUED) continue;
            age=(DWORD)(sequence-jobs[i].sequence);
            if(slot<0 || age>oldest_age)
            {
                slot=i;
                oldest_age=age;
            }
        }

        if(slot<0)
        {
            mutex_unlock(&kasync_lock);
            return -1;
        }

        job=&jobs[slot];
        now=GetTickCount();
        if(job->cancel_requested)
        {
            kasync_finish_queued_locked(job,KASYNC_CANCELLED,
                                        KASYNC_ECANCELLED,now);
            continue;
        }
        if(kasync_deadline_reached(job,now))
        {
            kasync_finish_queued_locked(job,KASYNC_TIMEDOUT,
                                        KASYNC_ETIMEDOUT,now);
            continue;
        }
        if(job->function==0)
        {
            kasync_finish_queued_locked(job,KASYNC_CANCELLED,
                                        KASYNC_EINVAL,now);
            continue;
        }

        job->state=KASYNC_RUNNING;
        job->started_at=now;
        mutex_unlock(&kasync_lock);
        return slot;
    }
}

static void kasync_worker(void)
{
    int slot,result,id;
    DWORD now;
    KJOB *job;
    KASYNC_FUNCTION function;

    IdentifyThread(GetCurrentThread(),"kasync");
    for(;;)
    {
        slot=kasync_take();
        if(slot<0)
        {
            SchedulerWaitPause(KASYNC_WORKER_IDLE_US);
            continue;
        }

        /* A RUNNING job cannot be released or reused.  Cancellation only sets
         * a flag, so its callback and copied argument remain stable here. */
        job=&jobs[slot];
        id=job->id;
        function=job->function;
        result=function(id,job->argument,job->argument_size);

        mutex_lock(&kasync_lock);
        job=kasync_lookup_locked(id);
        if(job && job->state==KASYNC_RUNNING)
        {
            now=GetTickCount();
            job->finished_at=now;
            if(job->cancel_requested)
            {
                job->state=KASYNC_CANCELLED;
                job->result=KASYNC_ECANCELLED;
            }
            else if(kasync_deadline_reached(job,now))
            {
                /* The old code reported DONE when a callback completed after
                 * its deadline.  Preserve timeout semantics through finish. */
                job->state=KASYNC_TIMEDOUT;
                job->result=KASYNC_ETIMEDOUT;
            }
            else
            {
                job->state=KASYNC_DONE;
                job->result=result;
            }
            if(job->flags&KASYNC_DETACHED) kasync_make_free(job);
        }
        mutex_unlock(&kasync_lock);
    }
}

int kasync_init(void)
{
    int i,j,rv=0;

    mutex_lock(&kasync_lock);
    if(initialized)
    {
        mutex_unlock(&kasync_lock);
        return 1;
    }

    memset(jobs,0,sizeof(jobs));
    memset(workers,0,sizeof(workers));
    sequence=0;

    for(i=0;i<KASYNC_WORKERS;i++)
    {
        if(ThreadCreateStack(&workers[i],JTMOS_MIN_DYNAMIC_STACK)!=0)
        {
            for(j=0;j<i;j++) ThreadDestroyStack(&workers[j]);
            memset(workers,0,sizeof(workers));
            rv=-1;
            goto out;
        }
    }

    for(i=0;i<KASYNC_WORKERS;i++)
    {
        workers[i].pid=create_thread(workers[i].stack,workers[i].l_stack,
                                     kasync_worker);
        if(workers[i].pid<=0)
        {
            /* create_thread() leaves this stack with the caller on failure. */
            ThreadDestroyStack(&workers[i]);
            for(j=i+1;j<KASYNC_WORKERS;j++) ThreadDestroyStack(&workers[j]);
            /* Already-published workers get ordinary process-context teardown.
             * A worker blocked on kasync_lock is detached by thread cleanup. */
            for(j=0;j<i;j++)
                if(workers[j].pid>0)
                    KillThreadEx((DWORD)workers[j].pid,KT_NO_THREAD_SWITCH);
            memset(workers,0,sizeof(workers));
            memset(jobs,0,sizeof(jobs));
            rv=-2;
            goto out;
        }
    }

    initialized=1;
out:
    mutex_unlock(&kasync_lock);
    if(rv==0)
        printk("KAsync: %d workers, %d bounded jobs ready (thread mutex).\n",
               KASYNC_WORKERS,KASYNC_MAX_JOBS);
    return rv;
}

int kasync_submit(KASYNC_FUNCTION function,const void *argument,
                  unsigned int argument_size,DWORD timeout_ms,int flags)
{
    int i,id,generation;
    DWORD now;

    if(function==0 || argument_size>KASYNC_ARG_MAX ||
       (argument_size && argument==0)) return -1;

    mutex_lock(&kasync_lock);
    if(!initialized)
    {
        mutex_unlock(&kasync_lock);
        return -1;
    }
    now=GetTickCount();
    kasync_expire_queued_locked(now);
    for(i=0;i<KASYNC_MAX_JOBS;i++)
        if(jobs[i].state==KASYNC_FREE) break;
    if(i==KASYNC_MAX_JOBS)
    {
        mutex_unlock(&kasync_lock);
        return KASYNC_EAGAIN;
    }

    generation=(jobs[i].generation+1)&0x7fffff;
    if(!generation) generation=1;
    id=(generation<<8)|i;
    memset(&jobs[i],0,sizeof(jobs[i]));
    jobs[i].generation=generation;
    jobs[i].id=id;
    jobs[i].state=KASYNC_QUEUED;
    jobs[i].function=function;
    jobs[i].argument_size=argument_size;
    if(argument_size) memcpy(jobs[i].argument,argument,argument_size);
    jobs[i].flags=flags;
    jobs[i].sequence=++sequence;
    jobs[i].submitted_at=now;
    jobs[i].deadline=kasync_make_deadline(now,timeout_ms);
    mutex_unlock(&kasync_lock);

    /* Workers use deadline sleep when the queue is empty.  Cancel that sleep
     * now instead of adding up to 10 ms of avoidable dispatch latency. */
    for(i=0;i<KASYNC_WORKERS;i++)
        if(workers[i].pid>0) SchedulerWakeThread(workers[i].pid);
    return id;
}

int kasync_poll(int id,KASYNC_STATUS *status)
{
    KJOB *job;
    mutex_lock(&kasync_lock);
    kasync_expire_queued_locked(GetTickCount());
    job=kasync_lookup_locked(id);
    if(!job)
    {
        mutex_unlock(&kasync_lock);
        return -1;
    }
    kasync_fill_status_locked(job,status);
    mutex_unlock(&kasync_lock);
    return 0;
}

int kasync_wait(int id,DWORD timeout_ms,KASYNC_STATUS *status)
{
    DWORD start=GetTickCount();
    KASYNC_STATUS current;
    for(;;)
    {
        if(kasync_poll(id,&current)<0) return -1;
        if(kasync_terminal(current.state))
        {
            if(status) *status=current;
            return 0;
        }
        if(timeout_ms && (DWORD)(GetTickCount()-start)>=timeout_ms)
            return KASYNC_ETIMEDOUT;
        SchedulerWaitPause(1000UL);
    }
}

int kasync_cancel(int id)
{
    KJOB *job;
    DWORD now;
    mutex_lock(&kasync_lock);
    now=GetTickCount();
    kasync_expire_queued_locked(now);
    job=kasync_lookup_locked(id);
    if(!job)
    {
        mutex_unlock(&kasync_lock);
        return -1;
    }
    if(kasync_terminal(job->state))
    {
        mutex_unlock(&kasync_lock);
        return 1;
    }

    job->cancel_requested=1;
    if(job->state==KASYNC_QUEUED)
    {
        kasync_finish_queued_locked(job,KASYNC_CANCELLED,
                                    KASYNC_ECANCELLED,now);
    }
    mutex_unlock(&kasync_lock);
    return 0;
}

int kasync_cancelled(int id)
{
    KJOB *job;
    int cancelled;
    mutex_lock(&kasync_lock);
    kasync_expire_queued_locked(GetTickCount());
    job=kasync_lookup_locked(id);
    cancelled=!job || job->cancel_requested ||
              kasync_deadline_reached(job,GetTickCount());
    mutex_unlock(&kasync_lock);
    return cancelled;
}

int kasync_release(int id)
{
    KJOB *job;
    mutex_lock(&kasync_lock);
    kasync_expire_queued_locked(GetTickCount());
    job=kasync_lookup_locked(id);
    if(!job || !kasync_terminal(job->state))
    {
        mutex_unlock(&kasync_lock);
        return -1;
    }
    kasync_make_free(job);
    mutex_unlock(&kasync_lock);
    return 0;
}

void kasync_counts(int *queued,int *running,int *finished)
{
    int i,q=0,r=0,d=0;
    mutex_lock(&kasync_lock);
    kasync_expire_queued_locked(GetTickCount());
    for(i=0;i<KASYNC_MAX_JOBS;i++)
    {
        if(jobs[i].state==KASYNC_QUEUED) q++;
        else if(jobs[i].state==KASYNC_RUNNING) r++;
        else if(kasync_terminal(jobs[i].state)) d++;
    }
    mutex_unlock(&kasync_lock);
    if(queued) *queued=q;
    if(running) *running=r;
    if(finished) *finished=d;
}

DWORD kasync_memory_bytes(void)
{
    return (DWORD)sizeof(jobs)+(DWORD)sizeof(workers)+(DWORD)sizeof(kasync_lock);
}
