#ifndef JTMOS_NMI_SOURCE_H
#define JTMOS_NMI_SOURCE_H

/* Optional autonomous vector-2 producer.  Unsupported/occupied hardware is
 * deliberately a normal state: the watchdog then remains external-NMI only. */
int NmiPeriodicSourceInit(void);
/* Explicit opt-in for physical PMU programming.  This shares all ownership
 * checks with the conservative initializer but bypasses only its bare-metal
 * auto-source refusal. */
int NmiPeriodicSourceForcePmu(void);
void NmiPeriodicSourceShutdown(void);
int NmiPeriodicSourceActive(void);
const char *NmiPeriodicSourceName(void);
const char *NmiPeriodicSourceStatus(void);
/* NMI-context safe. Returns 1 only when this source actually overflowed. */
int NmiPeriodicSourceAcknowledge(void);
/* True when the current event came from the host-clocked IB700 source; it
 * proves no scheduler switch (or idle kick) fed it for four seconds. */
int NmiPeriodicSourceHardExpiry(void);
/* True if PIT ran during the IB700 interval that just expired. */
int NmiPeriodicSourcePITProgress(void);
/* PIT activity/idle keepalive and immediate real-switch kick for IB700. */
void NmiPeriodicSourceHeartbeat(void);
void NmiPeriodicSourceTaskSwitchHeartbeat(void);

#endif
