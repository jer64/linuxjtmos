/*
 * pit.c - programmable interrupt timer
 *
 * (C) 2001-2005 by Jari Tuominen.
 *
 * Programmable Interrupt Chip handler library.
 * Basically we need a PIC to do anything nice
 * with the OS, so here's one of the most
 * needed part of the entire OS ;-)
 */

//
// Update: finally got rid of the AT&T standard
// assembly code, quickly translated it into NASM,
// now it seems to compile, and it'll be possible
// to start coding task switching code with NASM
// standard ASM by now, great.
//

#include "kernel32.h"
#include "pit.h"
#include "io.h"
#include "sysglvar.h"
#include "basdef.h"
#include "int.h"
#include "delay.h"
#include "floppy.h" // fd_int1c
#include "tss.h"
#include "scheduler.h"
#include "nmi_source.h"
#include "threads.h"

static void initPitMeasure(void);
static void init_counters(void);

//
PIT *pit;
//
static int lala JTM_UNUSED=0;

/*
 * Boot/storage timing mode.  During early floppy/IDE I/O we need IRQ0 for
 * millisecond counters and driver timeouts, but we do NOT want a hardware
 * TSS task switch on every PIT tick.  The old task-gate scheduler can perform
 * thousands of task switches during a single floppy seek and eventually
 * corrupt the init task context.
 */
static volatile int pit_storage_safe_active=0;
static int pit_storage_saved_multitasking=0;
#define PIT_INPUT_HZ 1193180UL
/* 16.16 fixed-point conversion: one PIT input clock ~= 0.838095 usec.
 * round((1,000,000 << 16) / 1,193,180) = 54925.  Multiplying by the
 * maximum 65536-count interval still fits in 32 bits. */
#define PIT_INPUT_TICK_USEC_Q16 54925UL
static DWORD pit_input_ticks_per_second=1;
static DWORD pit_programmed_divisor=1;
static DWORD pit_target_scheduler_hz=0;
static DWORD pit_ms_phase=0;
static volatile int pit_irq_active=0;
static int pit_advanced_8254=0;
static BYTE pit_channel0_status=0;

static BYTE pit_readback_select(unsigned char channel)
{
    if(channel==0) return TMR_CH0;
    if(channel==1) return TMR_CH1;
    if(channel==2) return TMR_CH2;
    return 0;
}

/* Caller must hold IF=0.  The 8254 read-back command latches the running
 * counter without stopping or perturbing it.  On the 8253-compatible fallback
 * use the older per-counter latch command. */
static unsigned int pit_read_counter_unsafe(unsigned char channel)
{
    unsigned int value;
    BYTE sel;

    if(channel>2) return 0;
    sel=pit_readback_select(channel);
    if(pit_advanced_8254)
        outportb(TMR_CTRL, TMR_READBACK | TMR_RB_NO_STATUS | sel);
    else
        outportb(TMR_CTRL, (BYTE)((channel<<6) | TMR_LATCH));
    value=(unsigned int)inportb((WORD)(TMR_CNT0+channel));
    value|=(unsigned int)inportb((WORD)(TMR_CNT0+channel))<<8;
    return value;
}

/* 8254-only status latch.  Status is read before any count bytes when both
 * are requested, so keep this helper status-only and make ordering explicit. */
static int pit_read_status_8254_unsafe(unsigned char channel, BYTE *status)
{
    BYTE sel;
    if(channel>2 || status==NULL) return 0;
    sel=pit_readback_select(channel);
    outportb(TMR_CTRL, TMR_READBACK | TMR_RB_NO_COUNT | sel);
    *status=inportb((WORD)(TMR_CNT0+channel));
    return 1;
}

static void pit_probe_8254_channel0(void)
{
    BYTE status1=0,status2=0;
    const BYTE expected=(BYTE)(TMR_BOTH | TMR_MD2);

    /* Read-back is the defining 8254 extension over the 8253.  A real 8254
     * reports the exact RW/mode/BCD bits last programmed in D5..D0.  Sample
     * twice: an 8253 that treats SC=11 as undefined must not be mistaken for
     * an 8254 merely because one live count byte happens to match 0x34. */
    pit_advanced_8254=0;
    pit_channel0_status=0;
    if(!pit_read_status_8254_unsafe(0,&status1)) return;
    inportb(0x80);
    if(!pit_read_status_8254_unsafe(0,&status2)) return;
    if((status1 & 0x3fU) == expected && (status2 & 0x3fU) == expected)
    {
        pit_advanced_8254=1;
        pit_channel0_status=status2;
    }
}

static DWORD pit_divisor_for_hz(DWORD hz)
{
    DWORD divisor;
    if(hz<19U) hz=19U; /* 65536 divisor is about 18.2 Hz. */
    if(hz>PIT_INPUT_HZ) hz=PIT_INPUT_HZ;
    divisor=(PIT_INPUT_HZ + hz/2U)/hz;
    if(divisor<1U) divisor=1U;
    if(divisor>65536U) divisor=65536U;
    return divisor;
}

static DWORD pit_select_scheduler_hz(void)
{
    if(!PIT_CPU_PROFILE_ENABLED) return 0;

    /* AMD family 0x10 includes the K10/Regor generation used by Athlon II.
     * Give this explicit profile precedence over the generic modern-x86 one. */
    if(cpuHasFeature(JTMOS_CPUF_CPUID) &&
       !strcmp(jtmos_cpu_info.vendor,"AuthenticAMD") &&
       jtmos_cpu_info.family>=0x10U)
        return (PIT_ATHLON_II_SCHEDULER_HZ>0)?
            (DWORD)PIT_ATHLON_II_SCHEDULER_HZ:250U;

    /* V68.176: 250 Hz keeps the normal scheduler/input latency at about 4 ms
     * while avoiding one thousand host wakeups per second when QEMU is idle. */
    if(cpuHasFeature(JTMOS_CPUF_CPUID) && jtmos_cpu_info.family>=6U)
        return (PIT_MODERN_X86_SCHEDULER_HZ>0)?
            (DWORD)PIT_MODERN_X86_SCHEDULER_HZ:250U;

    return (PIT_LEGACY_I486_SCHEDULER_HZ>0)?
        (DWORD)PIT_LEGACY_I486_SCHEDULER_HZ:250U;
}

/* High-resolution monotonic duration clock.  CMOS/RTC is the wall-clock
 * source, but PC/AT CMOS has only one-second calendar resolution.  Sub-second
 * sleeps are therefore derived from the PIT crystal (1,193,180 Hz), which is
 * the correct hardware time base for usleep().  The whole/remainder pair
 * keeps the average exact without floating point or 64-bit division. */
static volatile DWORD pit_monotonic_usec=0;
static DWORD pit_usec_tick_whole=0;
static DWORD pit_usec_tick_remainder=0;
static volatile DWORD pit_usec_phase=0;

static void pit_prepare_usec_increment(DWORD divisor)
{
	DWORD i;
	DWORD whole=0;
	DWORD rem=0;

	/* Compute (divisor * 1,000,000) / PIT_INPUT_HZ without overflowing
	 * 32-bit arithmetic.  Since 1,000,000 < PIT_INPUT_HZ, each iteration
	 * needs at most one carry.  This runs only when the PIT is programmed. */
	for(i=0; i<divisor; i++)
	{
		rem += 1000000UL;
		if(rem >= PIT_INPUT_HZ)
		{
			rem -= PIT_INPUT_HZ;
			whole++;
		}
	}

	pit_usec_tick_whole = whole;
	pit_usec_tick_remainder = rem;
	pit_usec_phase = 0;
	pit_monotonic_usec = 0;
}

void pit_handler(void);

/* Normal interrupt-gate IRQ0 handler used only during boot/storage I/O.
 * It advances JTMOS timers and acknowledges the PIC, but never invokes the
 * TSS scheduler.  IRET restores the interrupted EFLAGS/segments/registers. */
__attribute__((naked)) void pit_tick_only_ISR(void)
{
	__asm__ __volatile__(
		"cld\n\t"
		"pushal\n\t"
		"push %ds\n\t"
		"push %es\n\t"
		"push %fs\n\t"
		"push %gs\n\t"
		"mov $0x10, %ax\n\t"
		"mov %ax, %ds\n\t"
		"mov %ax, %es\n\t"
		"mov %ax, %fs\n\t"
		"mov %ax, %gs\n\t"
		"call pit_handler\n\t"
		/* Controller-neutral EOI: LAPIC in APIC mode, 8259 in fallback. */
		"push $0\n\t"
		"call pic_send_eoi\n\t"
		"add $4, %esp\n\t"
		"pop %gs\n\t"
		"pop %fs\n\t"
		"pop %es\n\t"
		"pop %ds\n\t"
		"popal\n\t"
		"iret\n\t"
	);
}

/* Steady-state IRQ0 interrupt gate. It preserves the interrupted register
 * frame and lets SchedulerTimerInterruptDispatch decide whether a TSS transfer
 * is needed. */
__attribute__((naked)) void pit_scheduler_ISR(void)
{
	__asm__ __volatile__(
		"cld\n\t"
		"pushal\n\t"
		"push %ds\n\t"
		"push %es\n\t"
		"push %fs\n\t"
		"push %gs\n\t"
		"mov $0x10, %ax\n\t"
		"mov %ax, %ds\n\t"
		"mov %ax, %es\n\t"
		"mov %ax, %fs\n\t"
		"mov %ax, %gs\n\t"
		"call SchedulerTimerInterruptDispatch\n\t"
		"pop %gs\n\t"
		"pop %fs\n\t"
		"pop %es\n\t"
		"pop %ds\n\t"
		"popal\n\t"
		"iret\n\t"
	);
}

int PitStorageSafeActive(void)
{
	return pit_storage_safe_active;
}

void PitStorageSafeBegin(void)
{
	DWORD flags;

	flags = get_eflags();
	disable();

	if(!pit_storage_safe_active)
	{
		pit_storage_saved_multitasking = Multitasking;
		Multitasking = FALSE;
		setint(M_VEC, pit_tick_only_ISR, SEG_CODE32,
			D_INT + D_PRESENT);
		pit_storage_safe_active = TRUE;
	}

	enable_irq(0);
	set_eflags(flags);
	dprintk("PIT: storage-safe tick-only IRQ0 enabled; TSS scheduler paused.\n");
}

void PitStorageSafeEnd(void)
{
	DWORD flags;
	static unsigned context_dump_budget=4;

	flags = get_eflags();
	disable();

	if(pit_storage_safe_active)
	{
		/* V68.160: capture runnable TSS state while IF is still guaranteed
		 * clear.  The previous crash happened immediately after this function
		 * restored the IRQ0 scheduler, so this snapshot distinguishes a TSS
		 * that was already corrupt from corruption inside the task switch. */
		if(context_dump_budget)
		{
			SchedulerDebugDumpRunnable("PIT/pre-steady-state");
			context_dump_budget--;
		}
		InstallPitSchedulerGate();
		Multitasking = pit_storage_saved_multitasking;
		pit_storage_safe_active = FALSE;
	}

	set_eflags(flags);
	dprintk("PIT: steady-state interrupt-gate IRQ0 scheduler restored.\n");
}

//
extern void pit_ISR(void);

//
void Sleep(int _count)
{
	MilSleep(_count);
}

//
void runPitHandlers(void)
{
	//
#ifndef IMPLEMENT_MULTIPLE_PIT_HANDLERS
	return;
#endif

	//
	int i;

	// Call other handlers
	for(i=0; i<pit->n_handlers; i++)
	{
		//
		if(pit->handler[i]!=NULL)
			(*(void (*)(void)) pit->handler[i])();
	}
}

//---------------------------------------------------------------------------------
// Init programmable interrupt timer
//
void InitTimer(void)
{
        // Let's enable timer:

	//
	disable();
        /* Select a scheduler rate in Hz from the detected CPU class, then convert
         * it to the nearest legal 8253/8254 divisor.  V68.176 defaults modern
         * x86 and Athlon II/K10 to 250 Hz (~4 ms IRQ0), reducing QEMU idle
         * wakeups while preserving interactive scheduling. */
        pit_target_scheduler_hz=pit_select_scheduler_hz();
        if(pit_target_scheduler_hz) {
                DWORD divisor=pit_divisor_for_hz(pit_target_scheduler_hz);
                printk("PIT: CPU scheduler profile target=%u Hz divisor=%u.\n",
                       (unsigned)pit_target_scheduler_hz,(unsigned)divisor);
                init_pit((long)((divisor==65536U)?0U:divisor),0);
        } else if(cpuHasFeature(JTMOS_CPUF_CPUID) && jtmos_cpu_info.family >= 5)
                init_pit(GOOD_TIMER_FREQUENCY, 0);
        else
                init_pit(FAIR_TIMER_FREQUENCY, 0);
        // 2) Setup handler for the PIT timer interrupt
        setint(M_VEC,
                pit_low, GIMMIE_CS(),
                D_INT + D_PRESENT);
        // 3) Enable PIT timer
//        enable_irq(0);
}

/*
The timer output frequency is obtained by dividing the 8253 master clock
frequency of 1,193,180 Hz by a 16 bit divisor.  (A zero divisor is treated as
65,536.  This is the value programmed by the BIOS, to give a system timer of
18.2065 Hz.)  The timer is programmed by sending a control byte to port 43h,
followed by a divisor word (low byte, high byte) to port 4Xh where X is the
timer being programmed.

If the system timer (counter 0) is modified, an Int 8 handler must be written to
call the original Int 8 handler 18.2 times per second, otherwise some system
functions (eg time of day) may be upset.  When it does call the original Int 8
handler it must NOT send and EOI to the 8259 for the timer interrupt, since the
original Int 8 handler will send the EOI also.

Mitch

default 0x1000(16x BIOS default)
*/
void init_pit(long h, unsigned char channel)
{
	//
	DWORD temp=0;
	DWORD saved_flags;
	int i JTM_UNUSED;

	// Initialize PIT structure
	pit = malloc(sizeof(PIT));
	memset(pit, 0, sizeof(PIT));
	
	//
	temp = h;
	
	// -----------------------------------------------------------------
	/*
	 * Do not use the historical PUSHFLAGS/POPFLAGS macros here.  They were
	 * separate inline-asm pushf/popf statements with an invisible ESP side
	 * effect.  an optimizing GCC build is therefore free to move stack-argument cleanup
	 * across PUSHFLAGS; in V67.8.50 that consumed the saved EFLAGS word and
	 * POPFLAGS later loaded unrelated stack data, occasionally setting TF
	 * and causing an early #DB (single-step) exception.
	 */
	saved_flags = get_eflags();
	disable();

	//
	/* Channel 0 runs in 8254 mode 2 (rate generator).  Unlike mode 3's
	 * square-wave duty-cycle rules, mode 2 gives one clean periodic terminal
	 * pulse per divisor and is the natural scheduler/IRQ0 mode. */
	outportb(TMR_CTRL, (BYTE)((channel*0x40) + TMR_BOTH + TMR_MD2));
	outportb((WORD)(TMR_CNT0+channel), (unsigned char) temp);
	outportb((WORD)(TMR_CNT0+channel), (unsigned char) (temp>>8));
	if(channel==0) pit_probe_8254_channel0();

	// Init all tick counters
	init_counters();
	pit_ms_phase = 0;
	/* PIT input clock is 1,193,180 Hz. A programmed divisor of zero means
	 * 65536 on the 8253/8254. */
	{
		DWORD divisor = ((DWORD)h & 0xFFFF);
		if(divisor == 0) divisor = 65536;
		pit_programmed_divisor = divisor;
		/* Rounded raw IRQ frequency is used by scheduler statistics only.
		 * Milliseconds and microseconds below use the exact divisor ratio. */
		pit_input_ticks_per_second = (PIT_INPUT_HZ + divisor/2) / divisor;
		if(!pit_input_ticks_per_second) pit_input_ticks_per_second = 1;
		pit_prepare_usec_increment(divisor);
	}

	// Determine raw tick rate deterministically; IRQ0 is not enabled yet.
	initPitMeasure();

	//
	set_eflags(saved_flags);
	// -----------------------------------------------------------------
}

// Makes up precalculations,
// e.g. how many ticks is one second
// at the current tick rate.
// To delay a millisecond, the amount
// of ticks needed to delay a single second
// is divided by 100, then this amount
// of ticks is waited and
// a millisecond has passed.
static void initPitMeasure(void)
{
	/* IRQ0 is still masked while InitTimer() runs, so the historical
	 * sleep()/GetTickCount2() calibration always measured zero.  Derive the
	 * rate directly from the 8253/8254 input clock instead. */
	pit->secondInTicks = pit_input_ticks_per_second;
	pit->millisecondInTicks = pit->secondInTicks / 1000;
	if(!pit->secondInTicks) pit->secondInTicks = 1;
	if(!pit->millisecondInTicks) pit->millisecondInTicks = 1;
	printk("%s: Advanced PIT=%s, mode=2, divisor=%u, IRQ rate=%u Hz, target=%u Hz, exact clock ~= %u us/IRQ.\n",
		__FUNCTION__, pit_advanced_8254?"8254 read-back":"8253 latch fallback",
		pit_programmed_divisor, pit->secondInTicks,
		(unsigned)pit_target_scheduler_hz,pit_usec_tick_whole);
	if(pit_advanced_8254)
		printk("PIT8254: ch0 status=0x%x (OUT=%u null=%u rw/mode=0x%x).\n",
			(unsigned)pit_channel0_status,
			(unsigned)((pit_channel0_status>>7)&1U),
			(unsigned)((pit_channel0_status>>6)&1U),
			(unsigned)(pit_channel0_status&0x3fU));
	if(pit->secondInTicks < 250)
		printk("PIT WARNING: IRQ rate below 250 Hz; scheduler/wakeup granularity is coarse.\n");
}

DWORD PitGetIrqHz(void)
{
    return pit_input_ticks_per_second;
}

DWORD PitMillisecondsToTicks(DWORD msec)
{
    DWORD hz=pit_input_ticks_per_second;
    DWORD whole,rem,ticks,part;
    if(!msec) return 0;
    if(!hz) hz=1;

    /* Ceiling(hz*msec/1000) without overflowing 32-bit arithmetic. */
    whole=msec/1000U;
    rem=msec%1000U;
    if(whole && hz>0xffffffffUL/whole) return 0xffffffffUL;
    ticks=whole*hz;
    part=(rem*hz + 999U)/1000U; /* rem<1000, hz<=PIT input clock */
    if(0xffffffffUL-ticks<part) return 0xffffffffUL;
    ticks+=part;
    if(!ticks) ticks=1;
    return ticks;
}

/* Return the PIT-derived monotonic clock in microseconds.  The software epoch
 * wraps naturally at 2^32 usec (~71.6 minutes).  On an 8254, read-back gives
 * sub-IRQ interpolation from the live counter; an 8253-compatible machine
 * retains the interrupt-resolution software clock. */
DWORD PitGetUsec(void)
{
	DWORD flags;
	DWORD now;

	flags = get_eflags();
	disable();
	now = pit_monotonic_usec;

	/* Advanced 8254 path: interpolate inside the current IRQ period using a
	 * latched hardware count.  PIC IRR closes the rollover race: if IRQ0 is
	 * pending, the PIT has already reloaded but pit_handler() has not yet
	 * committed that period to the software epoch. */
	if(pit_advanced_8254 && pit_programmed_divisor && !pit_irq_active)
	{
		WORD irr_before,irr_after;
		DWORD count,elapsed,subtick,next_delta;

		irr_before=pic_read_irr();
		count=(DWORD)pit_read_counter_unsafe(0);
		irr_after=pic_read_irr();

		/* If rollover happened between the first IRR sample and the count
		 * read, take a new post-reload count so we never add a full period to
		 * a pre-rollover count. */
		if(!(irr_before&1U) && (irr_after&1U))
			count=(DWORD)pit_read_counter_unsafe(0);

		if(count==0) count=65536UL;
		if(count>pit_programmed_divisor) count=pit_programmed_divisor;
		elapsed=pit_programmed_divisor-count;
		subtick=(elapsed*PIT_INPUT_TICK_USEC_Q16 + 0x8000UL)>>16;

		if(irr_after&1U)
		{
			/* Mirror exactly the next fractional software-clock carry that
			 * pit_handler() will commit once IRQ0 is accepted. */
			next_delta=pit_usec_tick_whole;
			if(pit_usec_phase + pit_usec_tick_remainder >= PIT_INPUT_HZ)
				next_delta++;
			now += next_delta;
		}
		now += subtick;
	}

	set_eflags(flags);
	return now;
}

int PitAdvanced8254Active(void)
{
	return pit_advanced_8254;
}

unsigned int PitReadCounter(unsigned char channel)
{
	DWORD flags;
	unsigned int value;
	if(channel>2) return 0;
	flags=get_eflags();
	disable();
	value=pit_read_counter_unsafe(channel);
	set_eflags(flags);
	return value;
}

int PitReadStatus(unsigned char channel, unsigned char *status)
{
	DWORD flags;
	int ok=0;
	if(channel>2 || status==NULL || !pit_advanced_8254) return 0;
	flags=get_eflags();
	disable();
	ok=pit_read_status_8254_unsafe(channel,status);
	set_eflags(flags);
	return ok;
}

/* V70.11: true sub-tick delay for short hardware timing requirements.
 *
 * UsecSleep() is intentionally scheduler based and therefore has 1 ms
 * granularity with the rapid LAPIC scheduler (4 ms on the 250 Hz PIT
 * fallback). Device protocols also need 4..250 us settle/poll delays, where
 * that rounding is disastrous. Measure channel-0 PIT input counts directly
 * instead. Interrupts are only masked around each latched count read, so a
 * sub-millisecond device delay does not turn into a long global CLI region.
 *
 * This helper is deliberately capped at one millisecond. Longer waits belong
 * to UsecSleep() so CPU_IDLE/HLT and other runnable tasks can make progress. */
int UsecDelay(DWORD usec)
{
    DWORD target,elapsed=0,delta,divisor;
    unsigned int prev,cur;
    DWORD guard=0,guard_max;

    if(usec==0) return 0;
    if(usec>1000UL) return UsecSleep(usec);
    divisor=pit_programmed_divisor;
    if(!pit || divisor==0)
    {
        /* Very early fallback: legacy ISA I/O delay. It is intentionally
         * conservative; normal callers run after InitTimer(). */
        DWORD i;
        for(i=0;i<usec;i++) inportb(0x80);
        return 0;
    }

    /* ceil(usec * 1,193,180 / 1,000,000), safe because usec<=1000. */
    target=(usec*PIT_INPUT_HZ + 999999UL)/1000000UL;
    if(target==0) target=1;
    prev=PitReadCounter(0);
    if(prev==0) prev=(unsigned int)divisor;

    /* A stuck/virtualized PIT must never hang the kernel. The limit is far
     * above the number of reads a healthy PIT needs for <=1 ms. */
    guard_max=target*256UL + 65536UL;
    while(elapsed<target && guard++<guard_max)
    {
        cur=PitReadCounter(0);
        if(cur==0) cur=(unsigned int)divisor;
        if(prev>=cur) delta=(DWORD)(prev-cur);
        else delta=(DWORD)prev + divisor - (DWORD)cur;
        if(delta<=divisor) elapsed+=delta;
        prev=cur;
        inportb(0x80);
    }
    if(elapsed<target)
    {
        dprintk("UsecDelay: PIT did not advance, usec=%lu.\n",
                (unsigned long)usec);
        return -1;
    }
    return 0;
}

/* Scheduler-friendly microsecond sleep.  This is a minimum-duration sleep,
 * as POSIX-style usleep() must be: scheduler load may make the actual delay
 * longer.  With normal multitasking it explicitly yields via SwitchToThread;
 * during storage-safe/early boot it executes HLT and wakes on PIT/IRQ6 rather
 * than burning CPU in a polling loop. */
int UsecSleep(DWORD usec)
{
	DWORD start;
	DWORD flags;

	if(usec == 0)
	{
		if(Multitasking && !PitStorageSafeActive())
			SwitchToThread();
		return 0;
	}

	flags = get_eflags();
	if(!Multitasking && !(flags & 0x200))
	{
		/* With no scheduler and IF clear, neither IRQ0 nor another runnable
		 * task can advance the software clock.  A normal userspace syscall
		 * enters through an interrupt gate with IF clear, but Multitasking is
		 * active there: SwitchToThread() lets other tasks/PIT advance time. */
		return -1;
	}

	if(Multitasking && !PitStorageSafeActive())
		return SchedulerSleepCurrentUsec(usec);

	/* Early boot/storage-safe mode has no runnable-task scheduler.  Never make
	 * this wait depend solely on IRQ0/HLT: USB/FDC/ATA init may be exactly where
	 * a broken interrupt path is being diagnosed.  Poll PIT progress, but bound
	 * the wait independently with direct CMOS seconds and a finite spin budget. */
	{
		RTC_IO_DEADLINE deadline;
		DWORD timeout_ms=(usec+999UL)/1000UL;
		unsigned int rtc_seconds=(unsigned int)(timeout_ms/1000UL)+2U;
		unsigned long poll_limit;

		if(timeout_ms<1UL) timeout_ms=1UL;
		poll_limit=(usec>80000000UL) ? 4000000000UL :
			(usec*50UL + 100000UL);
		rtc_io_deadline_start(&deadline,timeout_ms,rtc_seconds,poll_limit);
		start = PitGetUsec();
		while((DWORD)(PitGetUsec() - start) < usec)
		{
			if(rtc_io_deadline_expired(&deadline))
			{
				dprintk("UsecSleep: early/storage-safe timeout usec=%lu IF=%d.\n",
					(unsigned long)usec,(get_eflags()&0x200)?1:0);
				return -1;
			}
			inportb(0x80);
		}
	}

	return 0;
}

// Sleep a specified amount of milliseconds (1/1000 seconds).
void MilSleep(int periodMilliseconds)
{
	DWORD chunk;

	if(periodMilliseconds <= 0) return;

	/* Avoid overflow in msec*1000 while retaining the historical void API. */
	while(periodMilliseconds > 0)
	{
		chunk = (periodMilliseconds > 1000000) ? 1000000UL :
			(DWORD)periodMilliseconds;
		if(UsecSleep(chunk * 1000UL) != 0)
			return;
		periodMilliseconds -= (int)chunk;
	}
}

//
unsigned int pit_getchannel(unsigned char channel)
{
	return PitReadCounter(channel);
}

//----------------------------------------------------------------
// PIT interrupt handler (timer interrupt handler)
//
void pit_handler(void)
{
	int i,kert JTM_UNUSED;
	char *p JTM_UNUSED;

	pit_irq_active=1;
	/* Commit the hardware period before any timeout/scheduler/PIT callback can
	 * ask for PitGetUsec().  This keeps the high-resolution clock monotonic
	 * even from inside IRQ0 callbacks. */
	pit_monotonic_usec += pit_usec_tick_whole;
	pit_usec_phase += pit_usec_tick_remainder;
	if(pit_usec_phase >= PIT_INPUT_HZ)
	{
		pit_usec_phase -= PIT_INPUT_HZ;
		pit_monotonic_usec++;
	}

	// test...
/*	p = 0xB8000;
	for(i=0; i<50; i++)
	{
		p[i]++;
	}*/

	//
	ThreadTimeOut();
	SchedulerCpuTick();
	/* Observe PIT activity, and feed IB700 only when a real task switch has
	 * occurred (or while idle).  A CPU-bound task with live IRQ0 must still
	 * reach the no-switch watchdog timeout. */
	NmiPeriodicSourceHeartbeat();

	/* Increase generic raw-tick timers, but NOT timer[10].  timer[10] is
	 * the public millisecond clock returned by GetTickCount().  The old loop
	 * incremented timer[10] on every raw PIT IRQ and then incremented it again
	 * in the millisecond divider, making time run several times too fast. */
	for(i=0; i<50; i++)
	{
		if(i != 10) glvar.timer[i]++;
	}

	runPitHandlers();

	/* Exact PIT-ratio millisecond divider.  Do not round the PIT to an integer
	 * Hz first: the programmed divisor is not generally an integer-Hz rate. */
	pit_ms_phase += pit_programmed_divisor * 1000UL;
	while(pit_ms_phase >= PIT_INPUT_HZ)
	{
		pit_ms_phase -= PIT_INPUT_HZ;
		glvar.timer[10]++;
		fd_int1c();
	}

	pit_irq_active=0;

	// This is done in ASM handler timerhandler.mac:
//	outportb(0x20, 0x20);
}

//
static void init_counters(void)
{
	//
	int i;

	//
	for(i=0; i<50; i++) { glvar.timer[i]=0; glvar.dbtimer[i]=0; }
}

// Add new PIT handler
void addPitHandler(void *ptr)
{
	int i;

	if(ptr==NULL)
	{
		dprintk("addPitHandler: NULL handler rejected.\n");
		return;
	}

	//
	if(pit->n_handlers==0)
		pit->n_handlers++;

	//--------------------------------------------------
	// Look for empty entry, if not found,
	// add one more entry.
	for(; ; pit->n_handlers++)
	{
		//
		if(pit->n_handlers>=N_MAX_PIT_HANDLERS)
		{
			dprintk("addPitHandler: handler table full (%d).\n",N_MAX_PIT_HANDLERS);
			return;
		}

		//--------------------------------------------------
		for(i=0; i<pit->n_handlers; i++)
		{
			//
			if(pit->handler[i]==NULL)
			{
				//
				pit->handler[i]=ptr;
				return;
			}
		}
	}
}

// Remove a PIT handler
void removePitHandler(void *ptr)
{
	int i;

	//
	for(i=0; i<pit->n_handlers; i++)
	{
		//
		if(pit->handler[i]==ptr)
		{
			//
			pit->handler[i]=NULL;
			return;
		}
	}
}

//

