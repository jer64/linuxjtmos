// =======================================================
// scs.c - JTMOS system call services
// (C) 2002 by Jari Tuominen(jari@vunet.org).
// OBSOLETE....
// =======================================================
//
#include "kernel32.h"
#include "systemcalls.h" // aka scs.h
#include "scconf.h" // contains only defines, works with nasm
#include "postman.h" // POSTMANCMD, etc..
#include "ega.h"
#include "threads.h"
#include "scheduler.h"
#include <jtmos/hdbench.h>

// ebx = name of the device
// Return value: handle of the device(DWORD)
DWORD scall_getdevnrbyname(SYSCALLPAR)
{
	char *s;

	//
	s = A2K(scall_ebx);
	return driver_getdevicenrbyname(s);
}

// ebx=devnr, ecx=blocknr, edx=pointer to buffer
DWORD scall_readblock(SYSCALLPAR)
{
	BYTE *s;

	//
	s = A2K(scall_edx);
	return readblock(scall_ebx, scall_ecx, s);
}

// ebx=devnr, ecx=blocknr, edx=pointer to buffer
DWORD scall_writeblock(SYSCALLPAR)
{
	BYTE *s;

	/* SCALL_IRQ_ON: block I/O may wait for a device IRQ. */
	s = A2K(scall_edx);
	return writeblock(scall_ebx, scall_ecx, s);
}



// ebx=devnr, ecx=first block, edx=user buffer, esi=block count
DWORD scall_readblocks(SYSCALLPAR)
{
    DWORD bytes;
    char *s;
    int bs,count;

    count=(int)scall_esi;
    if(count<=0 || !isValidDevice((int)scall_ebx)) return 0;
    bs=getblocksize((int)scall_ebx);
    if(bs<=0 || (DWORD)count > (0xffffffffUL/(DWORD)bs)) return 0;
    bytes=(DWORD)count*(DWORD)bs;
    s=(char *)A2KRange(scall_edx,bytes);
    if(s==NULL) return 0;
    return (DWORD)readblocks((long)scall_ebx,(long)scall_ecx,(BYTE *)s,count);
}

// ebx=devnr, ecx=first block, edx=user buffer, esi=block count
DWORD scall_writeblocks(SYSCALLPAR)
{
    DWORD bytes;
    char *s;
    int bs,count;

    count=(int)scall_esi;
    if(count<=0 || !isValidDevice((int)scall_ebx)) return 0;
    bs=getblocksize((int)scall_ebx);
    if(bs<=0 || (DWORD)count > (0xffffffffUL/(DWORD)bs)) return 0;
    bytes=(DWORD)count*(DWORD)bs;
    s=(char *)A2KRange(scall_edx,bytes);
    if(s==NULL) return 0;
    return (DWORD)writeblocks((long)scall_ebx,(long)scall_ecx,(BYTE *)s,count);
}

/* SYS_hdbench (168): bounded, read-only performance service for hda.
 *
 * Unlike the privileged raw block syscalls, this ABI never returns sector
 * contents to Ring 3.  It accepts no device name/number, write operation,
 * cache flush operation or ATA command byte.  The kernel owns and discards
 * the transfer buffer and returns only aggregate timing/progress metadata. */
DWORD scall_hdbench(SYSCALLPAR)
{
    JTMOS_HDBENCH_INFO info;
    JTMOS_HDBENCH_RESULT result;
    JTMOS_HDBENCH_INFO *uinfo;
    JTMOS_HDBENCH_RESULT *uresult;
    DEVICE_ENTRY *de;
    BYTE *buffer;
    DWORD op=scall_ebx;
    DWORD mode=scall_ecx;
    DWORD first=scall_edx;
    DWORD sectors=scall_esi;
    DWORD request=scall_edi;
    DWORD total,done,n,start_tick;
    int dnr,got,status=0,bs,total_i;

    dnr=driver_getdevicenrbyname("hda");
    if(dnr<=0 || !isValidDevice(dnr)) return (DWORD)-ENODEV;
    de=driver_getdevice(dnr);
    if(de==NULL || !(de->type&DEVICE_TYPE_BLOCK)) return (DWORD)-ENODEV;
    bs=getblocksize(dnr);
    total_i=getsize(dnr);
    total=(DWORD)total_i;
    if(bs!=512 || total_i==0) return (DWORD)-ENODEV;

    memset(&info,0,sizeof(info));
    info.version=JTMOS_HDBENCH_ABI_VERSION;
    info.size=sizeof(info);
    info.sector_size=(DWORD)bs;
    info.total_sectors=total;
    info.max_request_sectors=JTMOS_HDBENCH_MAX_REQUEST_SECTORS;
    info.max_test_sectors=JTMOS_HDBENCH_MAX_TEST_SECTORS;
    info.capabilities=JTMOS_HDBENCH_CAP_NATIVE_READ|
                      JTMOS_HDBENCH_CAP_READ_ONLY;
    if(de->type&DEVICE_TYPE_RAW_PIO_READ)
        info.capabilities|=JTMOS_HDBENCH_CAP_RAW_PIO;

    if(op==JTMOS_HDBENCH_OP_INFO) {
        if(scall_edx<sizeof(info)) return (DWORD)-ERANGE;
        uinfo=(JTMOS_HDBENCH_INFO *)A2KRange(scall_ecx,sizeof(info));
        if(uinfo==NULL) return (DWORD)-EFAULT;
        memcpy(uinfo,&info,sizeof(info));
        return 0;
    }
    if(op!=JTMOS_HDBENCH_OP_RUN) return (DWORD)-EINVAL;

    uresult=(JTMOS_HDBENCH_RESULT *)A2KRange(scall_ebp,sizeof(result));
    if(uresult==NULL) return (DWORD)-EFAULT;
    memset(&result,0,sizeof(result));
    result.version=JTMOS_HDBENCH_ABI_VERSION;
    result.size=sizeof(result);
    result.mode=mode;
    result.start_lba=first;
    result.requested_sectors=sectors;
    result.request_sectors=request;
    result.failed_lba=first;

    if(mode!=JTMOS_HDBENCH_MODE_NATIVE &&
       mode!=JTMOS_HDBENCH_MODE_RAW_PIO) status=-EINVAL;
    else if(mode==JTMOS_HDBENCH_MODE_RAW_PIO &&
            !(info.capabilities&JTMOS_HDBENCH_CAP_RAW_PIO)) status=-ENODEV;
    else if(sectors==0 || sectors>JTMOS_HDBENCH_MAX_TEST_SECTORS ||
            request==0 || request>JTMOS_HDBENCH_MAX_REQUEST_SECTORS)
        status=-EINVAL;
    else if(first>=total || sectors>total-first) status=-ERANGE;

    if(status<0) {
        result.status=status;
        memcpy(uresult,&result,sizeof(result));
        return (DWORD)status;
    }

    buffer=(BYTE *)malloc(request*512UL);
    if(buffer==NULL) {
        result.status=-ENOMEM;
        memcpy(uresult,&result,sizeof(result));
        return (DWORD)-ENOMEM;
    }

    start_tick=GetTickCount();
    done=0;
    while(done<sectors) {
        n=sectors-done;
        if(n>request) n=request;
        if(mode==JTMOS_HDBENCH_MODE_RAW_PIO)
            got=readblocksRawPIO(dnr,(long)(first+done),buffer,(int)n);
        else
            got=readblocks1(dnr,(long)(first+done),buffer,(int)n);
        if(got!=(int)n) { status=-EIO; break; }
        done+=n;
        if(Multitasking) SchedulerCooperate();
    }
    result.elapsed_ms=GetTickCount()-start_tick;
    if(result.elapsed_ms==0) result.elapsed_ms=1;
    result.completed_sectors=done;
    result.failed_lba=first+done;
    result.status=status;
    free(buffer);
    memcpy(uresult,&result,sizeof(result));
    return (DWORD)status;
}
