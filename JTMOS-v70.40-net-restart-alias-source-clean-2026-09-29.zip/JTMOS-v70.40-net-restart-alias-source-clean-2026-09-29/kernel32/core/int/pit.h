/*
 * Header file for JTMOS PIT library.
 */
#ifndef __INCLUDED_PIT_H__
#define __INCLUDED_PIT_H__

//
#include "basdef.h"

//
#define IMPLEMENT_MULTIPLE_PIT_HANDLERS

// Max. amount of PIT handlers
#define N_MAX_PIT_HANDLERS	250

//
typedef struct
{
	// Number of handlers for PIT interrupt
	int n_handlers;

	// Pointers to handler functions
	void *handler[N_MAX_PIT_HANDLERS];

	// Estimations
	int secondInTicks;      // How many ticks is one second?
	int millisecondInTicks; // How many ticks is one millisecond?
}PIT;
extern PIT *pit;

//
extern void init_pit(long h, unsigned char channel);
extern unsigned int pit_getchannel(unsigned char channel);
extern void delay(DWORD);

// Some essential defs. 
#define 	TMR_CTRL	0x43	/*	I/O for control		*/
#define		TMR_CNT0	0x40	/*	I/O for counter 0	*/
#define		TMR_CNT1	0x41	/*	I/O for counter 1	*/
#define		TMR_CNT2	0x42	/*	I/O for counter 2	*/
//
#define		TMR_SC0		0	/*	Select channel 0 	*/
#define		TMR_SC1		0x40	/*	Select channel 1 	*/
#define		TMR_SC2		0x80	/*	Select channel 2 	*/
//
#define		TMR_LOW		0x10	/*	RW low byte only 	*/
#define		TMR_HIGH	0x20	/*	RW high byte only 	*/
#define		TMR_BOTH	0x30	/*	RW both bytes 		*/
//
#define		TMR_MD0		0	/*	Mode 0 			*/
#define		TMR_MD1		0x2	/*	Mode 1 			*/
#define		TMR_MD2		0x4	/*	Mode 2 			*/
#define		TMR_MD3		0x6	/*	Mode 3 			*/
#define		TMR_MD4		0x8	/*	Mode 4 			*/
#define		TMR_MD5		0xA	/*	Mode 5 			*/
//
#define		TMR_BCD		1	/*	BCD mode 		*/
//
#define		TMR_LATCH	0	/*	Latch command 		*/
//
/* 8254 read-back command. D5/D4 are active-low latch requests.  The old
 * TMR_READ value 0xF0 selected neither status nor count and was effectively a
 * no-op. */
#define		TMR_READBACK	0xC0
#define		TMR_RB_NO_COUNT 0x20
#define		TMR_RB_NO_STATUS 0x10
#define		TMR_CH2		0x08
#define		TMR_CH1		0x04
#define		TMR_CH0		0x02

//
extern void pit_ISR();
//
void addPitHandler(void *ptr);
void removePitHandler(void *ptr);
void InitTimer(void);
void runPitHandlers(void);
void PitStorageSafeBegin(void);
void PitStorageSafeEnd(void);
int PitStorageSafeActive(void);
DWORD PitGetIrqHz(void);
DWORD PitMillisecondsToTicks(DWORD msec);
DWORD PitGetUsec(void);
int PitAdvanced8254Active(void);
unsigned int PitReadCounter(unsigned char channel);
int PitReadStatus(unsigned char channel, unsigned char *status);
int UsecSleep(DWORD usec);
/* V70.11: sub-tick hardware delay.  Unlike UsecSleep(), this does not
 * round short device timing requirements up to a scheduler tick. */
int UsecDelay(DWORD usec);
void MilSleep(int periodMilliseconds);

/* V68.121 steady-state timer interrupt-gate entry. */
void pit_scheduler_ISR(void);

void pit_handler(void);

#endif
