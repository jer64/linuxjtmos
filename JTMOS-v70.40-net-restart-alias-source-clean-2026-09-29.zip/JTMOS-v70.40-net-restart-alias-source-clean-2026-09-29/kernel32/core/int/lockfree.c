/* Lock-free data structures for JTMOS V68.219. */
#include "kernel32.h"
#include "atomic.h"
#include "lockfree.h"

int lf_spsc_init(LF_SPSC_QUEUE *q,void **storage,DWORD capacity)
{
    if(!q || !storage || capacity<2 || (capacity&(capacity-1))!=0) return -1;
    q->slots=storage;
    q->capacity=capacity;
    q->mask=capacity-1;
    q->head=0;
    q->tail=0;
    atomic_compiler_barrier();
    return 0;
}

int lf_spsc_push(LF_SPSC_QUEUE *q,void *value)
{
    DWORD head,tail;
    if(!q || !q->slots) return 0;
    head=q->head;
    atomic_compiler_barrier();
    tail=q->tail;
    if((DWORD)(head-tail)>=q->capacity) return 0;
    q->slots[head&q->mask]=value;
    atomic_compiler_barrier();
    q->head=head+1;
    return 1;
}

int lf_spsc_pop(LF_SPSC_QUEUE *q,void **value)
{
    DWORD head,tail;
    void *item;
    if(!q || !q->slots || !value) return 0;
    tail=q->tail;
    atomic_compiler_barrier();
    head=q->head;
    if(tail==head) return 0;
    atomic_compiler_barrier();
    item=q->slots[tail&q->mask];
    q->slots[tail&q->mask]=0;
    atomic_compiler_barrier();
    q->tail=tail+1;
    *value=item;
    return 1;
}

DWORD lf_spsc_count(const LF_SPSC_QUEUE *q)
{
    DWORD head,tail;
    if(!q) return 0;
    head=q->head;
    atomic_compiler_barrier();
    tail=q->tail;
    return (DWORD)(head-tail);
}

void lf_mpsc_init(LF_MPSC_QUEUE *q)
{
    if(!q) return;
    q->stub.next=0;
    q->tail=&q->stub;
    q->head=&q->stub;
    atomic_compiler_barrier();
}

void lf_mpsc_push(LF_MPSC_QUEUE *q,LF_MPSC_NODE *node)
{
    LF_MPSC_NODE *previous;
    if(!q || !node) return;
    node->next=0;
    atomic_compiler_barrier();
    previous=(LF_MPSC_NODE *)atomic_ptr_xchg((void * volatile *)&q->head,node);
    atomic_compiler_barrier();
    previous->next=node;
}

LF_MPSC_NODE *lf_mpsc_pop(LF_MPSC_QUEUE *q)
{
    LF_MPSC_NODE *tail,*next,*head;
    if(!q) return 0;

    tail=q->tail;
    atomic_compiler_barrier();
    next=tail->next;
    if(tail==&q->stub)
    {
        if(!next) return 0;
        q->tail=next;
        tail=next;
        atomic_compiler_barrier();
        next=tail->next;
    }

    if(next)
    {
        q->tail=next;
        return tail;
    }

    head=q->head;
    atomic_compiler_barrier();
    if(tail!=head)
        return 0; /* a producer exchanged head and is linking previous->next */

    lf_mpsc_push(q,&q->stub);
    atomic_compiler_barrier();
    next=tail->next;
    if(next)
    {
        q->tail=next;
        return tail;
    }
    return 0;
}

int lf_mpsc_empty(const LF_MPSC_QUEUE *q)
{
    LF_MPSC_NODE *tail,*next,*head;
    if(!q) return 1;
    tail=q->tail;
    atomic_compiler_barrier();
    next=tail->next;
    head=q->head;
    if(tail==&q->stub) return next==0;
    return next==0 && tail==head;
}
