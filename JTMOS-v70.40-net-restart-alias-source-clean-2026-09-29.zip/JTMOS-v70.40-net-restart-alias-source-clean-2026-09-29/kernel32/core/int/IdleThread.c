//=====================================================
// JTMOS THREADS - IdleThread.
// (C) 2001-2005 by Jari Tuominen.
//=====================================================
#include "cpu.h"
#include "kernel32.h"
#include "threads.h"
#include "IdleThread.h"
#include "scheduler.h"

//
DWORD IdleThreadCounter=0;
//
THREAD IdleThread;

// Creates an idle thread
void init_IdleThread(void)
{
	//
	if(ThreadCreateStack(&IdleThread,JTMOS_MIN_DYNAMIC_STACK)!=0)
		KERNEL_FATAL("init_IdleThread: cannot allocate idle stack");
	IdleThread.pid=create_thread(IdleThread.stack,IdleThread.l_stack,IdleThreadProgram);
	if(IdleThread.pid<=0)
	{
		ThreadDestroyStack(&IdleThread);
		KERNEL_FATAL("init_IdleThread: cannot create idle thread");
	}

	// max. 31 characters.
	IdentifyThread(IdleThread.pid, "CPU_IDLE");

	// Idle thread should be immortal.
	Immortal(IdleThread.pid);
}

//
void IdleThreadProgram(void)
{
	/*
	 * True CPU idle loop. SchedulerIdleWait() uses a short HLT burst.  IRQ0
	 * and device IRQs remain enabled throughout, so real work can preempt
	 * CPU_IDLE immediately while QEMU/real hardware spends the idle interval
	 * in HLT.  Keeping the burst short also guarantees that crash flushing,
	 * quarantined-thread reaping and log maintenance are revisited promptly.
	 */
	IdleThreadCounter=0;
	for(;;)
	{
		IdleThreadCounter++;
		/* First tell the operator why a process disappeared. Exception/NMI
		 * capture cannot safely print, so notification is deferred to CPU_IDLE.
		 * Then persist the full report when storage is ready. */
		CrashAnalysisNotifyPending();
		CrashAnalysisFlushPending();
		ThreadReapQuarantined();
		SystemLoggingMaintenance();
		SchedulerIdleWait();
	}
}

//

