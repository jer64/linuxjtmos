#ifndef JTMOS_KSEM_H
#define JTMOS_KSEM_H

/* Counting semaphore with FIFO sleeping waiters. */
#include "basdef.h"

struct semaphore_waiter;
struct semaphore
{
    volatile unsigned int count;
    struct semaphore_waiter *wait_head;
    struct semaphore_waiter *wait_tail;
    volatile unsigned int waiters;
    const char *name;
    struct semaphore *registry_next;
    BYTE registered;
};

#define __SEMAPHORE_INITIALIZER(semname,value) \
    { (unsigned int)(value), 0, 0, 0, #semname, 0, 0 }
#define DEFINE_SEMAPHORE(semname,value) \
    struct semaphore semname = __SEMAPHORE_INITIALIZER(semname,value)

void semaphore_init(struct semaphore *sem,unsigned int value);
int semaphore_destroy(struct semaphore *sem);
void semaphore_wait_at(struct semaphore *sem,const char *function,const char *file,int line);
int semaphore_trywait_at(struct semaphore *sem,const char *function,const char *file,int line);
void semaphore_post_at(struct semaphore *sem,const char *function,const char *file,int line);
unsigned int semaphore_value(const struct semaphore *sem);
unsigned int semaphore_waiters(const struct semaphore *sem);

#ifndef JTMOS_SEMAPHORE_IMPLEMENTATION
#define semaphore_wait(sem) \
    semaphore_wait_at((sem),__FUNCTION__,__FILE__,__LINE__)
#define semaphore_trywait(sem) \
    semaphore_trywait_at((sem),__FUNCTION__,__FILE__,__LINE__)
#define semaphore_post(sem) \
    semaphore_post_at((sem),__FUNCTION__,__FILE__,__LINE__)
#endif

int JtSemaphoreThreadBlocked(int pid);
const char *JtSemaphoreThreadWaitName(int pid);
void JtSemaphoreThreadInit(int pid);
void JtSemaphoreThreadCleanup(int pid);

#endif
