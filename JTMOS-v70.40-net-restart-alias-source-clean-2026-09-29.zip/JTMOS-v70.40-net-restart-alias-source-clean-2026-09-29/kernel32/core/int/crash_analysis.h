#ifndef __JTMOS_CRASH_ANALYSIS_H_INCLUDED__
#define __JTMOS_CRASH_ANALYSIS_H_INCLUDED__

#include "basdef.h"
#include "tss.h"

/*
 * V68.210 crash analysis.
 *
 * The capture side is exception/IRQ safe: no malloc, filesystem I/O, locks or
 * scheduler calls.  A fixed RAM snapshot is persisted later by CPU_IDLE.
 */
#define JTMOS_CRASH_ANALYSIS_VERSION 1U
#define JTMOS_CRASH_SYSCALL_HISTORY 8
#define JTMOS_CRASH_SWITCH_HISTORY 16
#define JTMOS_CRASH_LOCK_HISTORY 16

#define CRASH_LOCK_WAIT     1
#define CRASH_LOCK_ACQUIRE  2
#define CRASH_LOCK_RELEASE  3
#define CRASH_LOCK_TIMEOUT  4
#define CRASH_LOCK_BAD      5

#define CRASH_DISPOSITION_UNKNOWN     0
#define CRASH_DISPOSITION_QUARANTINE  1
#define CRASH_DISPOSITION_FATAL       2

typedef struct JTMOS_CRASH_FRAME
{
    DWORD error;
    DWORD eip;
    DWORD cs;
    DWORD eflags;
    DWORD entry_esp;
    DWORD user_esp;
    DWORD user_ss;
    DWORD cr2;
    DWORD eax,ebx,ecx,edx,esi,edi,ebp;
    BYTE authoritative;
    BYTE regs_authoritative;
    BYTE from_user;
} JTMOS_CRASH_FRAME;

void CrashAnalysisTraceSyscall(int pid,DWORD nr,DWORD ebx,DWORD ecx,DWORD edx,
                               DWORD esi,DWORD edi,DWORD ebp);
void CrashAnalysisTraceSwitch(int old_pid,int new_pid);
void CrashAnalysisTraceLock(int pid,int action,DWORD lock_id,int owner_pid,
                            const char *function,const char *file,int line);
void CrashAnalysisCaptureException(const char *reason,int code,int pid,
                                   const JTMOS_CRASH_FRAME *frame,
                                   const TSSEG *tss);
void CrashAnalysisSetDisposition(int pid,int disposition);
void CrashAnalysisNotifyPending(void);
void CrashAnalysisFlushPending(void);
DWORD CrashAnalysisPendingCount(void);

#endif
