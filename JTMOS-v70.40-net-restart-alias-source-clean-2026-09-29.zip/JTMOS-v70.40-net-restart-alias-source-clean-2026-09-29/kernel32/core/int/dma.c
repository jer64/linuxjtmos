/*
 * dma.c - DIRECT MEMORY ACCESS - Function Library
 *
 *	floppy.c uses this, so its needed,
 *	other hardware support providing
 *	drivers will probably need this
 *	eventually everything will be counted
 *	on the workability of this library.
 *
 *	the floppy uses dma 2
 *
 * (C)2002 by Jari Tuominen(jari@vunet.org)
 *
 */
#include "basdef.h"
#include "io.h"
#include "dma.h"
#include "int.h"

// defines for accessing the upper and lower byte of an integer
#define LOW_BYTE(x)         (x & 0x00FF)
#define HI_BYTE(x)          ((x & 0xFF00) >> 8)

// quick-access registers and ports for each DMA channel
BYTE MaskReg[8]   = { 0x0A, 0x0A, 0x0A, 0x0A, 0xD4, 0xD4, 0xD4, 0xD4 };
BYTE ModeReg[8]   = { 0x0B, 0x0B, 0x0B, 0x0B, 0xD6, 0xD6, 0xD6, 0xD6 };
BYTE ClearReg[8]  = { 0x0C, 0x0C, 0x0C, 0x0C, 0xD8, 0xD8, 0xD8, 0xD8 };
//
BYTE PagePort[8]  = { 0x87, 0x83, 0x81, 0x82, 0x8F, 0x8B, 0x89, 0x8A };
BYTE AddrPort[8]  = { 0x00, 0x02, 0x04, 0x06, 0xC0, 0xC4, 0xC8, 0xCC };
BYTE CountPort[8] = { 0x01, 0x03, 0x05, 0x07, 0xC2, 0xC6, 0xCA, 0xCE };

//
void _dma_xfer(BYTE DMA_channel, BYTE page, unsigned int offset, unsigned int length, BYTE mode);

//
void dma_xfer(BYTE channel, DWORD address, unsigned int length, BYTE read)
{
    BYTE page, mode, local;
    unsigned int offset, count;
    DWORD last;

    /* ISA 8237 constraints.  Channel 4 is the cascade channel.  DMA buffers
     * are physical, below 16 MiB, non-empty and may not cross a 64 KiB page.
     * Channels 5..7 transfer words, so both address and byte count are even
     * and the address/count registers are programmed in word units. */
    if(channel>=8 || channel==4 || length==0 || length>65536U) {
        return;
    }
    if(address>=0x01000000UL || address>0xffffffffUL-(DWORD)(length-1U)) {
        return;
    }
    last=address+(DWORD)length-1UL;
    if((address&0xffff0000UL)!=(last&0xffff0000UL)) {
        return;
    }
    local=(channel>=4)?(BYTE)(channel-4):channel;
    page=(BYTE)(address>>16);
    if(channel>=5) {
        if((address&1UL) || (length&1U)) {
            return;
        }
        offset=(unsigned int)((address>>1)&0xffffUL);
        count=(length>>1)-1U;
    } else {
        offset=(unsigned int)(address&0xffffUL);
        count=length-1U;
    }
    /* 01 = peripheral -> memory, 10 = memory -> peripheral; mode register
     * channel select is local to each 8237 controller, not global 0..7. */
    mode=(BYTE)((read?0x48:0x44)|local);
    _dma_xfer(channel,page,offset,count,mode);
}

void _dma_xfer(BYTE DMA_channel, BYTE page, unsigned int offset, unsigned int length, BYTE mode)
{
    DWORD flags;
    BYTE local;
    if(DMA_channel>=8 || DMA_channel==4) return;
    local=(DMA_channel>=4)?(BYTE)(DMA_channel-4):DMA_channel;
    flags=(DWORD)irq_save();
    outportb(MaskReg[DMA_channel], (BYTE)(0x04 | local));
    outportb(ClearReg[DMA_channel], 0x00);
    outportb(ModeReg[DMA_channel], mode);
    outportb(AddrPort[DMA_channel], LOW_BYTE(offset));
    outportb(AddrPort[DMA_channel], HI_BYTE(offset));
    outportb(PagePort[DMA_channel], page);
    outportb(CountPort[DMA_channel], LOW_BYTE(length));
    outportb(CountPort[DMA_channel], HI_BYTE(length));
    outportb(MaskReg[DMA_channel], local);
    irq_restore((unsigned long)flags);
}

//


/* Mask an ISA DMA channel without changing the caller's IF state. */
void dma_mask_channel(BYTE channel)
{
    DWORD flags;
    BYTE local;

    if(channel >= 8)
        return;
    local = (channel >= 4) ? (channel-4) : channel;
    flags = (DWORD)irq_save();
    outportb(MaskReg[channel], 0x04 | local);
    irq_restore((unsigned long)flags);
}
