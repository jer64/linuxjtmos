#ifndef __INCLUDED_DEBUG_H__
#define __INCLUDED_DEBUG_H__

// Lock IDs
#define ID_REPORT_MESSAGE 1
#define ID_DPRINTK        2
#define ID_PRINTF         3

int ReportMessage(const char *fmt, ...);
void doch(int ch);

/* Polled serial diagnostics.  The ordinary path can be disabled at runtime
 * with SMSH `d0`; the emergency path remains available for crash reports. */
void DebugSerialEarlyInit(void);
void DebugSerialPutChar(int ch);
void DebugSerialWrite(const char *s);
void DebugSerialWriteHex32(DWORD value);
void DebugSerialSetRuntimeEnabled(int enabled);
int  DebugSerialRuntimeEnabled(void);

void DebugSerialEmergencyPutChar(int ch);
void DebugSerialEmergencyWrite(const char *s);
void DebugSerialEmergencyWriteHex32(DWORD value);
/* NMI-safe bounded polling variants: never spend an unbounded/very long time
 * waiting for a missing or wedged UART while vector 2 owns the CPU. */
void DebugSerialNmiWrite(const char *s);
void DebugSerialNmiWriteHex32(DWORD value);

#endif
