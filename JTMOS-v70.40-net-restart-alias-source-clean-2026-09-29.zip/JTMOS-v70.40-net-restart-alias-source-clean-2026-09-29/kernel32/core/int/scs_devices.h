#ifndef __INCLUDED_SCS_DEVICES_H__
#define __INCLUDED_SCS_DEVICES_H__

//
#include "scs.h"

//
DWORD scall_getdevnrbyname(SYSCALLPAR);
DWORD scall_readblock(SYSCALLPAR);
DWORD scall_writeblock(SYSCALLPAR);
DWORD scall_readblocks(SYSCALLPAR);
DWORD scall_writeblocks(SYSCALLPAR);
DWORD scall_hdbench(SYSCALLPAR);

#endif
