#ifndef JTMOS_RWSEM_H
#define JTMOS_RWSEM_H

/*
 * Scheduler-aware shared/exclusive lock for JTMOS.
 *
 * This is deliberately named rwsem rather than rwlock_t: unlike Linux'
 * spin-based rwlock_t, a contended JTMOS rwsem sleeps the current thread.
 * Readers may run concurrently, writers are exclusive, and queued writers
 * cannot be bypassed indefinitely by newly arriving readers.
 */
#include "basdef.h"
#include "threadscfg.h"

#define JTMOS_RWSEM_READER_WORDS ((N_MAX_THREADS + 31) / 32)

struct rwsem_waiter;
struct rwsem
{
    volatile int writer_pid;
    DWORD writer_magic;
    volatile unsigned int readers;
    DWORD reader_bits[JTMOS_RWSEM_READER_WORDS];
    struct rwsem_waiter *wait_head;
    struct rwsem_waiter *wait_tail;
    volatile unsigned int waiters;
    volatile unsigned int waiting_writers;
    const char *name;
    const char *writer_function;
    const char *writer_file;
    int writer_line;
    DWORD acquired_ms;
    struct rwsem *registry_next;
    BYTE registered;
};

#define __RWSEM_INITIALIZER(lockname) \
    { -1, 0, 0, {0}, 0, 0, 0, 0, #lockname, 0, 0, 0, 0, 0, 0 }
#define DEFINE_RWSEM(lockname) \
    struct rwsem lockname = __RWSEM_INITIALIZER(lockname)

void rwsem_init(struct rwsem *lock);
int rwsem_destroy(struct rwsem *lock);
void rwsem_down_read_at(struct rwsem *lock,const char *function,const char *file,int line);
int rwsem_down_read_trylock_at(struct rwsem *lock,const char *function,const char *file,int line);
void rwsem_up_read_at(struct rwsem *lock,const char *function,const char *file,int line);
void rwsem_down_write_at(struct rwsem *lock,const char *function,const char *file,int line);
int rwsem_down_write_trylock_at(struct rwsem *lock,const char *function,const char *file,int line);
void rwsem_up_write_at(struct rwsem *lock,const char *function,const char *file,int line);
unsigned int rwsem_reader_count(const struct rwsem *lock);
int rwsem_writer(const struct rwsem *lock);

#ifndef JTMOS_RWSEM_IMPLEMENTATION
#define rwsem_down_read(lock) \
    rwsem_down_read_at((lock),__FUNCTION__,__FILE__,__LINE__)
#define rwsem_down_read_trylock(lock) \
    rwsem_down_read_trylock_at((lock),__FUNCTION__,__FILE__,__LINE__)
#define rwsem_up_read(lock) \
    rwsem_up_read_at((lock),__FUNCTION__,__FILE__,__LINE__)
#define rwsem_down_write(lock) \
    rwsem_down_write_at((lock),__FUNCTION__,__FILE__,__LINE__)
#define rwsem_down_write_trylock(lock) \
    rwsem_down_write_trylock_at((lock),__FUNCTION__,__FILE__,__LINE__)
#define rwsem_up_write(lock) \
    rwsem_up_write_at((lock),__FUNCTION__,__FILE__,__LINE__)
#endif

int JtRwsemThreadBlocked(int pid);
const char *JtRwsemThreadWaitName(int pid);
void JtRwsemThreadInit(int pid);
void JtRwsemThreadCleanup(int pid);

#endif
