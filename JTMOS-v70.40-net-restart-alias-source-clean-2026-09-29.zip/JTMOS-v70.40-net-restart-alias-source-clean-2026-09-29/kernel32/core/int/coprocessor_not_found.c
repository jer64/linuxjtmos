/* JTMOS lazy x87/MMX/SSE context management.
 *
 * V68.187 hardening:
 *  - one owner PID for the live hardware state
 *  - PID teardown/reuse invalidates that owner before memory reclamation
 *  - fresh contexts scrub x87/MMX and XMM0..XMM7, preventing cross-process
 *    register disclosure
 *  - FXSAVE/FXRSTOR carries x87, MMX aliases, MXCSR and all IA-32 XMM regs
 *  - old processors retain the FSAVE/FRSTOR fallback
 */
#include <stdio.h>
#include "coprocessor_not_found.h"
#include "cpu.h"
#include "threads.h"

static int fpu_last_user_pid=-1;
int mathHandling=0;

static int fpu_uses_fxsave(void)
{
    return cpuHasFeature(JTMOS_CPUF_FXSR|JTMOS_CPUF_SSE_OS);
}

static void fpu_state_save(FPUREGS *r)
{
    if(!r)return;
    if(fpu_uses_fxsave())
        __asm__ __volatile__("fxsave (%0)" : : "r"(r->state) : "memory");
    else
        __asm__ __volatile__("fnsave (%0); fwait" : : "r"(r->state) : "memory");
}

static void fpu_state_restore(FPUREGS *r)
{
    if(!r)return;
    if(fpu_uses_fxsave())
        __asm__ __volatile__("fxrstor (%0)" : : "r"(r->state) : "memory");
    else
        __asm__ __volatile__("frstor (%0)" : : "r"(r->state) : "memory");
}

/* FINIT resets tags/control state but does not erase the physical x87/MMX
 * payload, and it does not clear XMM registers.  A new process must not be
 * able to observe register data left by the previous FPU owner. */
static void fpu_make_clean_hardware_state(void)
{
    unsigned long mxcsr=0x1f80UL;

    __asm__ __volatile__(
        "fninit\n\t"
        /* Fill all eight physical x87/MMX slots with zero. */
        "fldz\n\tfldz\n\tfldz\n\tfldz\n\t"
        "fldz\n\tfldz\n\tfldz\n\tfldz\n\t"
        /* Mark them empty again and restore TOP after a full rotation. */
        "ffree %%st(0)\n\tfincstp\n\t"
        "ffree %%st(0)\n\tfincstp\n\t"
        "ffree %%st(0)\n\tfincstp\n\t"
        "ffree %%st(0)\n\tfincstp\n\t"
        "ffree %%st(0)\n\tfincstp\n\t"
        "ffree %%st(0)\n\tfincstp\n\t"
        "ffree %%st(0)\n\tfincstp\n\t"
        "ffree %%st(0)\n\tfincstp\n\t"
        "fnclex"
        : : : "memory");

    if(fpu_uses_fxsave())
    {
        __asm__ __volatile__("ldmxcsr %0" : : "m"(mxcsr) : "memory");
        /* Keep XMM names inside the assembly template: the kernel compiler
         * baseline remains i486 and does not allocate XMM registers itself. */
        __asm__ __volatile__(
            "pxor %%xmm0,%%xmm0\n\t"
            "pxor %%xmm1,%%xmm1\n\t"
            "pxor %%xmm2,%%xmm2\n\t"
            "pxor %%xmm3,%%xmm3\n\t"
            "pxor %%xmm4,%%xmm4\n\t"
            "pxor %%xmm5,%%xmm5\n\t"
            "pxor %%xmm6,%%xmm6\n\t"
            "pxor %%xmm7,%%xmm7"
            : : : "memory");
    }
}

void FpuForgetThread(int pid)
{
    int flags;

    if(pid < 0 || pid >= N_MAX_THREADS)
        return;

    /* Serialize against PIT scheduling/#NM on the uniprocessor kernel. The
     * caller may already have IF=0; restoring captured flags preserves it. */
    flags=get_eflags();
    disable();

    /* Clear the published pointer before the process allocator can reclaim it. */
    thread_fpuregs[pid] = NULL;
    if(fpu_last_user_pid == pid)
        fpu_last_user_pid = -1;

    set_eflags(flags);
}

static int fpu_state_new(int pid)
{
    FPUREGS *r;
    int i;

    r=(FPUREGS *)malloc(sizeof(FPUREGS));
    if(!r)return -1;

    /* JTMOS malloc maps whole pages; keep an explicit runtime guard because
     * FXSAVE/FXRSTOR require a 16-byte-aligned image. */
    if(((DWORD)r->state & 15UL)!=0)
    {
        dprintk("FPU: unaligned state buffer for PID %d at %x.\n",pid,(DWORD)r->state);
        free(r);
        return -1;
    }

    /* Do not call optimized memset while constructing an FPU save image. */
    for(i=0;i<(int)sizeof(FPUREGS);i++) ((BYTE *)r)[i]=0;
    thread_fpuregs[pid]=r;

    fpu_make_clean_hardware_state();
    fpu_state_save(r);
    return 0;
}

void coprocessor_not_found(void)
{
    int current=GetCurrentThread();
    mathHandling++;

    if(current<0 || current>=N_MAX_THREADS)
        goto out;

    /* Returning owner after tasks that did not touch FPU only needs CLTS,
     * already executed by ASMexception_7. */
    if(fpu_last_user_pid==current)
        goto out;

    /* A hardware TSS switch set CR0.TS.  ASMexception_7 did CLTS immediately
     * before this call, so the previous owner's state can now be saved. */
    if(fpu_last_user_pid>=0 && fpu_last_user_pid<N_MAX_THREADS &&
       thread_fpuregs[fpu_last_user_pid]!=NULL)
        fpu_state_save(thread_fpuregs[fpu_last_user_pid]);

    if(thread_fpuregs[current]==NULL && fpu_state_new(current)!=0)
    {
        /* Deterministic low-memory fallback.  No owner is published; the next
         * successful hardware task switch re-arms TS and another #NM can retry. */
        dprintk("FPU: unable to allocate state for PID %d; using transient clean state.\n",current);
        fpu_make_clean_hardware_state();
        fpu_last_user_pid=-1;
        goto out;
    }

    fpu_state_restore(thread_fpuregs[current]);
    fpu_last_user_pid=current;

out:
    mathHandling--;
}
