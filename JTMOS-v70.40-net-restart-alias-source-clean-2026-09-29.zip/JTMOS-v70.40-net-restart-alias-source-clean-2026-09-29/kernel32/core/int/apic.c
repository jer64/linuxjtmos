/*
 * apic.c - JTMOS xAPIC / I/O APIC interrupt-controller backend.
 *
 * V69.20 design goals:
 *   - keep the public legacy IRQ 0..15 ABI used by existing drivers;
 *   - discover routing from ACPI MADT instead of assuming IRQ==INTIN;
 *   - preserve JTMOS vectors 0x68..0x77, so existing IDT gates remain valid;
 *   - keep all I/O APIC inputs masked until individual drivers call enable_irq();
 *   - keep PIT as wall-clock timebase and optionally use LAPIC for rapid scheduling;
 *   - fall back cleanly to the fully working 8259 path on old/non-ACPI systems.
 *
 * Intel xAPIC MMIO accesses are deliberately 32-bit only.  The I/O APIC
 * indirect register pair is serialized with IF clear because IOREGSEL/IOWIN
 * form one shared transaction on this CPU.
 */
#include "kernel32.h"
#include "apic.h"
#include "paging.h"
#include "int.h"
#include "pit.h"
#include "scheduler.h"

#define MSR_IA32_APIC_BASE       0x0000001bUL
#define APIC_BASE_BSP            (1UL<<8)
#define APIC_BASE_X2APIC         (1UL<<10)
#define APIC_BASE_ENABLE         (1UL<<11)
#define APIC_BASE_ADDR_MASK      0xfffff000UL

#define LAPIC_ID                 0x020U
#define LAPIC_VERSION            0x030U
#define LAPIC_TPR                0x080U
#define LAPIC_EOI                0x0b0U
#define LAPIC_SVR                0x0f0U
#define LAPIC_ISR_BASE           0x100U
#define LAPIC_IRR_BASE           0x200U
#define LAPIC_LVT_TIMER          0x320U
#define LAPIC_LVT_THERMAL        0x330U
#define LAPIC_LVTPC              0x340U
#define LAPIC_LVT_LINT0          0x350U
#define LAPIC_LVT_LINT1          0x360U
#define LAPIC_LVT_ERROR          0x370U
#define LAPIC_TIMER_INITIAL      0x380U
#define LAPIC_TIMER_CURRENT      0x390U
#define LAPIC_TIMER_DIVIDE       0x3e0U
#define LAPIC_TIMER_PERIODIC     0x00020000UL
#define LAPIC_TIMER_DIV16        0x00000003UL
#define LAPIC_RAPID_VECTOR       0x67U
#define LAPIC_TIMER_CAL_USEC     20000UL
#define LAPIC_SVR_ENABLE         0x00000100UL
#define LAPIC_LVT_MASKED         0x00010000UL
#define LAPIC_LVT_DELIVERY_MASK  0x00000700UL
#define LAPIC_LVT_NMI            0x00000400UL
#define LAPIC_SPURIOUS_VECTOR    0xffU

#define IOAPIC_REG_ID            0x00U
#define IOAPIC_REG_VERSION       0x01U
#define IOAPIC_REDTBL_BASE       0x10U
#define IOAPIC_REDIR_MASK        0x00010000UL
#define IOAPIC_REDIR_LOW_ACTIVE  0x00002000UL
#define IOAPIC_REDIR_LEVEL       0x00008000UL

#define ACPI_SDT_HEADER_BYTES    36U
#define ACPI_MADT_FIXED_BYTES    44U
#define ACPI_MADT_PCAT_COMPAT    0x00000001UL

#define ACPI_MADT_LOCAL_APIC     0U
#define ACPI_MADT_IO_APIC        1U
#define ACPI_MADT_ISO            2U
#define ACPI_MADT_LOCAL_NMI      4U
#define ACPI_MADT_LAPIC_OVERRIDE 5U

#define APIC_INVALID_CPU_ID      0xffU

/* paging.c deliberately makes linear page zero non-present after paging is
 * enabled, but preserves an alias of physical 0..8 MiB at 0x10000000.
 * ACPI IA-PC discovery needs the BDA word at physical 0x40e and may scan EBDA
 * and the legacy BIOS area, so never dereference those physical addresses as
 * linear pointers after pg_init(). */
#define APIC_LOWMEM_ALIAS_BASE   0x10000000UL
#define APIC_LOWMEM_ALIAS_BYTES  0x00800000UL

#pragma pack(push,1)
typedef struct ACPI_RSDP1 {
    char signature[8];
    BYTE checksum;
    char oemid[6];
    BYTE revision;
    DWORD rsdt_address;
} ACPI_RSDP1;

typedef struct ACPI_RSDP2 {
    ACPI_RSDP1 first;
    DWORD length;
    DWORD xsdt_lo;
    DWORD xsdt_hi;
    BYTE extended_checksum;
    BYTE reserved[3];
} ACPI_RSDP2;

typedef struct ACPI_SDT_HEADER {
    char signature[4];
    DWORD length;
    BYTE revision;
    BYTE checksum;
    char oemid[6];
    char oem_table_id[8];
    DWORD oem_revision;
    DWORD creator_id;
    DWORD creator_revision;
} ACPI_SDT_HEADER;

typedef struct ACPI_MADT_HEADER {
    ACPI_SDT_HEADER header;
    DWORD lapic_address;
    DWORD flags;
} ACPI_MADT_HEADER;

typedef struct ACPI_MADT_ENTRY_HEADER {
    BYTE type;
    BYTE length;
} ACPI_MADT_ENTRY_HEADER;

typedef struct ACPI_MADT_LOCAL_APIC_ENTRY {
    BYTE type;
    BYTE length;
    BYTE acpi_processor_id;
    BYTE apic_id;
    DWORD flags;
} ACPI_MADT_LOCAL_APIC_ENTRY;

typedef struct ACPI_MADT_IOAPIC_ENTRY {
    BYTE type;
    BYTE length;
    BYTE ioapic_id;
    BYTE reserved;
    DWORD address;
    DWORD gsi_base;
} ACPI_MADT_IOAPIC_ENTRY;

typedef struct ACPI_MADT_ISO_ENTRY {
    BYTE type;
    BYTE length;
    BYTE bus;
    BYTE source;
    DWORD gsi;
    WORD flags;
} ACPI_MADT_ISO_ENTRY;

typedef struct ACPI_MADT_LOCAL_NMI_ENTRY {
    BYTE type;
    BYTE length;
    BYTE acpi_processor_id;
    WORD flags;
    BYTE lint;
} ACPI_MADT_LOCAL_NMI_ENTRY;

typedef struct ACPI_MADT_LAPIC_OVERRIDE_ENTRY {
    BYTE type;
    BYTE length;
    WORD reserved;
    DWORD address_lo;
    DWORD address_hi;
} ACPI_MADT_LAPIC_OVERRIDE_ENTRY;
#pragma pack(pop)

typedef struct APIC_PHYS_MAP {
    DWORD map_base;
    DWORD map_pages;
    BYTE *ptr;
} APIC_PHYS_MAP;

typedef struct JTM_IOAPIC {
    BYTE id;
    BYTE reserved[3];
    DWORD phys;
    DWORD gsi_base;
    DWORD redir_count;
    DWORD map_base;
    volatile DWORD *mmio;
} JTM_IOAPIC;

typedef struct JTM_LOCAL_NMI {
    BYTE valid;
    BYTE acpi_processor_id;
    BYTE lint;
    BYTE reserved;
    WORD flags;
    WORD reserved2;
} JTM_LOCAL_NMI;

static volatile DWORD *lapic;
static DWORD lapic_map;
static DWORD lapic_phys;
static BYTE lapic_id;
static BYTE lapic_version;
static BYTE bsp_acpi_processor_id=APIC_INVALID_CPU_ID;
static int apic_is_active;
static volatile int lapic_rapid_timer_active=0;
static DWORD lapic_rapid_timer_hz=0;
static DWORD lapic_timer_count_hz=0;
/* V69.40: firmware/MADT local NMI routes are opt-in. */
static volatile int apic_nmi_delivery_enabled=0;
static int madt_found;
static DWORD madt_phys;
static DWORD madt_flags;
static JTM_IOAPIC ioapics[JTMOS_APIC_MAX_IOAPICS];
static int ioapic_count;
static DWORD legacy_gsi[JTMOS_APIC_LEGACY_IRQS];
static WORD legacy_flags[JTMOS_APIC_LEGACY_IRQS];
static JTM_LOCAL_NMI local_nmi[8];
static int local_nmi_count;
static const char *apic_state="8259 PIC fallback";

static int bytes_equal(const char *a,const char *b,unsigned n)
{
    unsigned i;
    for(i=0;i<n;i++) if(a[i]!=b[i]) return 0;
    return 1;
}

static BYTE checksum8(const void *p,DWORD bytes)
{
    const BYTE *b=(const BYTE *)p;
    BYTE sum=0;
    DWORD i;
    for(i=0;i<bytes;i++) sum=(BYTE)(sum+b[i]);
    return sum;
}

static void apic_cpuid(DWORD leaf,DWORD sub,DWORD *a,DWORD *b,DWORD *c,DWORD *d)
{
    DWORD ra,rb,rc,rd;
    __asm__ volatile("cpuid":"=a"(ra),"=b"(rb),"=c"(rc),"=d"(rd):"a"(leaf),"c"(sub):"memory");
    if(a) *a=ra;
    if(b) *b=rb;
    if(c) *c=rc;
    if(d) *d=rd;
}

static void apic_rdmsr(DWORD msr,DWORD *lo,DWORD *hi)
{
    DWORD a,d;
    __asm__ volatile("rdmsr":"=a"(a),"=d"(d):"c"(msr):"memory");
    if(lo) *lo=a;
    if(hi) *hi=d;
}

static void apic_wrmsr(DWORD msr,DWORD lo,DWORD hi)
{
    __asm__ volatile("wrmsr"::"c"(msr),"a"(lo),"d"(hi):"memory");
}

static DWORD lapic_read(DWORD reg)
{
    return lapic ? lapic[reg/4U] : 0;
}

static void lapic_write(DWORD reg,DWORD value)
{
    if(!lapic) return;
    lapic[reg/4U]=value;
    (void)lapic[reg/4U];
}

static int map_physical(DWORD phys,DWORD length,int io,APIC_PHYS_MAP *m)
{
    DWORD first,offset,last,pages,map;
    if(!m || !length) return -1;
    first=phys&~0xfffUL;
    offset=phys&0xfffUL;
    if(length-1U > 0xffffffffUL-phys) return -1;
    last=(phys+length-1U)&~0xfffUL;
    pages=((last-first)/4096UL)+1U;
    if(pages>0x7fffffffUL) return -1;
    map=io ? pg_mapio((int)(first/4096UL),(int)pages)
           : pg_mapmemory((int)(first/4096UL),(int)pages);
    if(!map) return -1;
    m->map_base=map;
    m->map_pages=pages;
    m->ptr=(BYTE *)(map+offset);
    return 0;
}

static void unmap_physical(APIC_PHYS_MAP *m)
{
    if(!m || !m->map_base) return;
    pg_unmapmemory(m->map_base,(int)m->map_pages);
    m->map_base=0;
    m->map_pages=0;
    m->ptr=NULL;
}

static const void *apic_lowmem_ptr(DWORD phys,DWORD bytes)
{
    DWORD linear,first,last,page;
    if(!bytes || phys>=APIC_LOWMEM_ALIAS_BYTES) return NULL;
    if(bytes>APIC_LOWMEM_ALIAS_BYTES-phys) return NULL;
    linear=APIC_LOWMEM_ALIAS_BASE+phys;
    first=linear/PAGESIZE;
    last=(linear+bytes-1U)/PAGESIZE;
    /* Fail closed to the 8259 path if the historical alias is ever removed or
     * shortened by a future paging layout.  Do not turn ACPI discovery into a
     * second early-boot page fault. */
    for(page=first;page<=last;page++)
        if(!(GetPage(page)&1U)) return NULL;
    return JTM_DWORD_TO_PTR(const void,linear);
}

static const ACPI_RSDP1 *scan_rsdp_region(DWORD start,DWORD length)
{
    DWORD p,end;
    const ACPI_RSDP1 *r;
    if(!length || start>0xffffffffUL-length) return NULL;
    end=start+length;
    start=(start+15U)&~15UL;
    for(p=start;p+20U<=end;p+=16U)
    {
        /* Null-page protection makes physical==linear unsafe for the BDA.
         * Use the permanent low-memory alias for all legacy ACPI scanning. */
        r=(const ACPI_RSDP1 *)apic_lowmem_ptr(p,20U);
        if(!r) return NULL;
        if(!bytes_equal(r->signature,"RSD PTR ",8)) continue;
        if(checksum8(r,20U)!=0) continue;
        if(r->revision>=2U)
        {
            const ACPI_RSDP2 *r2=(const ACPI_RSDP2 *)r;
            /* ACPI 2.0+ RSDP is at least 36 bytes.  Do not checksum beyond
             * the BIOS search window even if corrupt firmware advertises a
             * bogus length. */
            if(r2->length<sizeof(ACPI_RSDP2) || r2->length>4096U ||
               p>end-r2->length || !apic_lowmem_ptr(p,r2->length) ||
               checksum8(r2,r2->length)!=0)
                continue;
        }
        return r;
    }
    return NULL;
}

static WORD apic_read_lowmem_word(DWORD phys)
{
    const WORD *p=(const WORD *)apic_lowmem_ptr(phys,sizeof(WORD));
    WORD value=0;
    if(!p) return 0;
    memcpy(&value,p,sizeof(value));
    return value;
}

static const ACPI_RSDP1 *find_rsdp(void)
{
    WORD ebda_seg;
    DWORD ebda;
    const ACPI_RSDP1 *r;
    /* Physical page zero is intentionally unmapped.  Read the BDA through
     * JTMOS low-memory alias instead of linear 0x40e. */
    ebda_seg=apic_read_lowmem_word(0x0000040eUL);
    ebda=((DWORD)ebda_seg)<<4;
    if(ebda>=0x00080000UL && ebda<0x000a0000UL)
    {
        r=scan_rsdp_region(ebda,1024U);
        if(r) return r;
    }
    return scan_rsdp_region(0x000e0000UL,0x00020000UL);
}

static int map_sdt(DWORD phys,APIC_PHYS_MAP *m,ACPI_SDT_HEADER **hdr)
{
    APIC_PHYS_MAP first={0,0,NULL};
    ACPI_SDT_HEADER *h;
    DWORD length;
    if(!m || !hdr || phys<4096U) return -1;
    if(map_physical(phys,sizeof(ACPI_SDT_HEADER),0,&first)!=0) return -1;
    h=(ACPI_SDT_HEADER *)first.ptr;
    length=h->length;
    if(length<sizeof(ACPI_SDT_HEADER) || length>(1024U*1024U))
    {
        unmap_physical(&first);
        return -1;
    }
    unmap_physical(&first);
    if(map_physical(phys,length,0,m)!=0) return -1;
    h=(ACPI_SDT_HEADER *)m->ptr;
    if(h->length!=length || checksum8(h,length)!=0)
    {
        unmap_physical(m);
        return -1;
    }
    *hdr=h;
    return 0;
}

static int find_madt_in_root(DWORD root_phys,int xsdt,DWORD *out_phys,
                             APIC_PHYS_MAP *out_map,ACPI_MADT_HEADER **out_madt)
{
    APIC_PHYS_MAP root_map={0,0,NULL};
    ACPI_SDT_HEADER *root;
    DWORD count,i,entry_bytes;
    BYTE *entries;

    if(map_sdt(root_phys,&root_map,&root)!=0) return -1;
    if((xsdt && !bytes_equal(root->signature,"XSDT",4)) ||
       (!xsdt && !bytes_equal(root->signature,"RSDT",4)) ||
       root->length<ACPI_SDT_HEADER_BYTES)
    {
        unmap_physical(&root_map);
        return -1;
    }
    entry_bytes=xsdt ? 8U : 4U;
    if((root->length-ACPI_SDT_HEADER_BYTES)%entry_bytes)
    {
        unmap_physical(&root_map);
        return -1;
    }
    entries=(BYTE *)root+ACPI_SDT_HEADER_BYTES;
    count=(root->length-ACPI_SDT_HEADER_BYTES)/entry_bytes;
    for(i=0;i<count;i++)
    {
        APIC_PHYS_MAP table_map={0,0,NULL};
        ACPI_SDT_HEADER *h;
        DWORD phys,hi=0;
        BYTE *e=entries+i*entry_bytes;
        /* XSDT entries are 64 bit and not guaranteed naturally aligned after
         * the 36-byte SDT header.  Read them as two 32-bit halves.  JTMOS is
         * IA-32, so tables above 4 GiB are skipped rather than truncated. */
        memcpy(&phys,e,4U);
        if(xsdt) memcpy(&hi,e+4U,4U);
        if(!phys || hi) continue;
        if(map_sdt(phys,&table_map,&h)!=0) continue;
        if(bytes_equal(h->signature,"APIC",4) && h->length>=ACPI_MADT_FIXED_BYTES)
        {
            *out_phys=phys;
            *out_map=table_map;
            *out_madt=(ACPI_MADT_HEADER *)h;
            unmap_physical(&root_map);
            return 0;
        }
        unmap_physical(&table_map);
    }
    unmap_physical(&root_map);
    return -1;
}

static int find_madt(DWORD *out_phys,APIC_PHYS_MAP *out_map,ACPI_MADT_HEADER **out_madt)
{
    const ACPI_RSDP1 *rsdp;

    rsdp=find_rsdp();
    if(!rsdp) return -1;
    /* Prefer XSDT on ACPI 2.0+ firmware, but only when its address is usable
     * by the 32-bit kernel.  RSDT remains a fully supported fallback. */
    if(rsdp->revision>=2U)
    {
        const ACPI_RSDP2 *r2=(const ACPI_RSDP2 *)rsdp;
        if(r2->xsdt_lo && !r2->xsdt_hi &&
           find_madt_in_root(r2->xsdt_lo,1,out_phys,out_map,out_madt)==0)
            return 0;
    }
    if(rsdp->rsdt_address &&
       find_madt_in_root(rsdp->rsdt_address,0,out_phys,out_map,out_madt)==0)
        return 0;
    return -1;
}

static void legacy_routes_reset(void)
{
    int i;
    for(i=0;i<JTMOS_APIC_LEGACY_IRQS;i++)
    {
        legacy_gsi[i]=(DWORD)i;
        legacy_flags[i]=0; /* conforms to ISA: active-high, edge triggered */
    }
}

static int parse_madt(void)
{
    APIC_PHYS_MAP map={0,0,NULL};
    ACPI_MADT_HEADER *madt;
    BYTE *p,*end;
    DWORD table_phys=0;

    legacy_routes_reset();
    ioapic_count=0;
    local_nmi_count=0;
    bsp_acpi_processor_id=APIC_INVALID_CPU_ID;

    if(find_madt(&table_phys,&map,&madt)!=0)
    {
        apic_state="8259 fallback: ACPI MADT not found";
        return -1;
    }
    madt_found=1;
    madt_phys=table_phys;
    madt_flags=madt->flags;
    if(madt->lapic_address)
        lapic_phys=madt->lapic_address;

    p=(BYTE *)madt+ACPI_MADT_FIXED_BYTES;
    end=(BYTE *)madt+madt->header.length;
    while(p+2U<=end)
    {
        ACPI_MADT_ENTRY_HEADER *eh=(ACPI_MADT_ENTRY_HEADER *)p;
        if(eh->length<2U || p+eh->length>end) break;
        if(eh->type==ACPI_MADT_IO_APIC && eh->length>=sizeof(ACPI_MADT_IOAPIC_ENTRY))
        {
            ACPI_MADT_IOAPIC_ENTRY *e=(ACPI_MADT_IOAPIC_ENTRY *)p;
            if(ioapic_count<JTMOS_APIC_MAX_IOAPICS && e->address)
            {
                JTM_IOAPIC *io=&ioapics[ioapic_count++];
                memset(io,0,sizeof(*io));
                io->id=e->ioapic_id;
                io->phys=e->address;
                io->gsi_base=e->gsi_base;
            }
        }
        else if(eh->type==ACPI_MADT_ISO && eh->length>=sizeof(ACPI_MADT_ISO_ENTRY))
        {
            ACPI_MADT_ISO_ENTRY *e=(ACPI_MADT_ISO_ENTRY *)p;
            if(e->bus==0U && e->source<JTMOS_APIC_LEGACY_IRQS)
            {
                legacy_gsi[e->source]=e->gsi;
                legacy_flags[e->source]=e->flags;
            }
        }
        else if(eh->type==ACPI_MADT_LOCAL_NMI && eh->length>=sizeof(ACPI_MADT_LOCAL_NMI_ENTRY))
        {
            ACPI_MADT_LOCAL_NMI_ENTRY *e=(ACPI_MADT_LOCAL_NMI_ENTRY *)p;
            if(local_nmi_count<(int)(sizeof(local_nmi)/sizeof(local_nmi[0])) && e->lint<=1U)
            {
                JTM_LOCAL_NMI *n=&local_nmi[local_nmi_count++];
                n->valid=1;
                n->acpi_processor_id=e->acpi_processor_id;
                n->lint=e->lint;
                n->flags=e->flags;
            }
        }
        else if(eh->type==ACPI_MADT_LAPIC_OVERRIDE && eh->length>=sizeof(ACPI_MADT_LAPIC_OVERRIDE_ENTRY))
        {
            ACPI_MADT_LAPIC_OVERRIDE_ENTRY *e=(ACPI_MADT_LAPIC_OVERRIDE_ENTRY *)p;
            if(e->address_hi==0U && e->address_lo)
                lapic_phys=e->address_lo;
        }
        p+=eh->length;
    }

    /* Keep the MADT mapping only as long as parsing requires it. */
    unmap_physical(&map);
    if(ioapic_count<=0)
    {
        apic_state="8259 fallback: MADT has no I/O APIC";
        return -1;
    }
    return 0;
}

static DWORD ioapic_read(JTM_IOAPIC *io,BYTE reg)
{
    DWORD flags,value;
    if(!io || !io->mmio) return 0;
    flags=get_eflags();
    disable();
    io->mmio[0]=(DWORD)reg;
    (void)io->mmio[0];
    value=io->mmio[4]; /* IOWIN at +0x10 */
    set_eflags(flags);
    return value;
}

static void ioapic_write(JTM_IOAPIC *io,BYTE reg,DWORD value)
{
    DWORD flags;
    if(!io || !io->mmio) return;
    flags=get_eflags();
    disable();
    io->mmio[0]=(DWORD)reg;
    (void)io->mmio[0];
    io->mmio[4]=value;
    (void)io->mmio[4];
    set_eflags(flags);
}

static JTM_IOAPIC *ioapic_for_gsi(DWORD gsi,DWORD *pin)
{
    int i;
    for(i=0;i<ioapic_count;i++)
    {
        JTM_IOAPIC *io=&ioapics[i];
        if(gsi>=io->gsi_base && (gsi-io->gsi_base)<io->redir_count)
        {
            if(pin) *pin=gsi-io->gsi_base;
            return io;
        }
    }
    return NULL;
}

static void ioapic_write_redir(JTM_IOAPIC *io,DWORD pin,DWORD low,DWORD high)
{
    BYTE reg;
    if(!io || pin>=io->redir_count) return;
    reg=(BYTE)(IOAPIC_REDTBL_BASE+(pin*2U));
    /* Mask/update low first, then destination high, then publish final low. */
    ioapic_write(io,reg,low|IOAPIC_REDIR_MASK);
    ioapic_write(io,(BYTE)(reg+1U),high);
    ioapic_write(io,reg,low);
}

static void ioapic_set_redir_mask(JTM_IOAPIC *io,DWORD pin,int masked)
{
    BYTE reg;
    DWORD low;
    if(!io || pin>=io->redir_count) return;
    reg=(BYTE)(IOAPIC_REDTBL_BASE+(pin*2U));
    low=ioapic_read(io,reg);
    if(masked) low|=IOAPIC_REDIR_MASK;
    else low&=~IOAPIC_REDIR_MASK;
    ioapic_write(io,reg,low);
}

static int map_ioapics(void)
{
    int i,j;
    for(i=0;i<ioapic_count;i++)
    {
        DWORD map,version;
        JTM_IOAPIC *io=&ioapics[i];
        if(io->phys&0xfffUL) goto fail;
        map=pg_mapio((int)(io->phys/4096UL),1);
        if(!map) goto fail;
        io->map_base=map;
        io->mmio=(volatile DWORD *)map;
        version=ioapic_read(io,IOAPIC_REG_VERSION);
        io->redir_count=((version>>16)&0xffU)+1U;
        if(io->redir_count==0U || io->redir_count>120U) goto fail;
        /* Firmware routes are not trusted once JTMOS takes APIC ownership. */
        for(j=0;j<(int)io->redir_count;j++)
        {
            BYTE reg=(BYTE)(IOAPIC_REDTBL_BASE+(j*2));
            DWORD low=ioapic_read(io,reg);
            ioapic_write(io,reg,low|IOAPIC_REDIR_MASK);
        }
    }
    return 0;
fail:
    for(i=0;i<ioapic_count;i++)
    {
        if(ioapics[i].map_base)
            pg_unmapmemory(ioapics[i].map_base,1);
        ioapics[i].map_base=0;
        ioapics[i].mmio=NULL;
        ioapics[i].redir_count=0;
    }
    return -1;
}

static void unmap_ioapics(void)
{
    int i;
    for(i=0;i<ioapic_count;i++)
    {
        if(ioapics[i].map_base)
            pg_unmapmemory(ioapics[i].map_base,1);
        ioapics[i].map_base=0;
        ioapics[i].mmio=NULL;
        ioapics[i].redir_count=0;
    }
}

static DWORD irq_redir_flags(unsigned irq)
{
    WORD f;
    unsigned polarity,trigger;
    DWORD low=0;
    if(irq>=JTMOS_APIC_LEGACY_IRQS) return 0;
    f=legacy_flags[irq];
    polarity=(unsigned)(f&3U);
    trigger=(unsigned)((f>>2)&3U);
    /* ACPI 'conforms' on ISA means active-high and edge-triggered. */
    if(polarity==3U) low|=IOAPIC_REDIR_LOW_ACTIVE;
    if(trigger==3U) low|=IOAPIC_REDIR_LEVEL;
    return low;
}

static int route_legacy_irqs(void)
{
    unsigned irq,other;
    /* Validate the map before changing a redirection entry.  A MADT override
     * may move IRQ0 to GSI2, but device IRQs cannot share an I/O APIC input
     * if their handlers use different vectors. */
    for(irq=0;irq<JTMOS_APIC_LEGACY_IRQS;irq++)
    {
        if(irq==2U) continue; /* IRQ2 exists only as the old 8259 cascade. */
        for(other=0;other<irq;other++)
        {
            if(other==2U) continue;
            if(legacy_gsi[irq]==legacy_gsi[other])
            {
                dprintk("APIC: IRQ%u and IRQ%u both use GSI %lu.\n",
                        other,irq,(unsigned long)legacy_gsi[irq]);
                return -1;
            }
        }
        if(!ioapic_for_gsi(legacy_gsi[irq],NULL))
        {
            dprintk("APIC: IRQ%u GSI %lu is not covered by an I/O APIC.\n",
                    irq,(unsigned long)legacy_gsi[irq]);
            return -1;
        }
    }
    for(irq=0;irq<JTMOS_APIC_LEGACY_IRQS;irq++)
    {
        DWORD pin,low,high;
        JTM_IOAPIC *io;
        /* On common PCs IRQ0->GSI2.  Programming the obsolete IRQ2 route
         * afterward would replace the PIT vector 0x68 with unused 0x6a. */
        if(irq==2U) continue;
        io=ioapic_for_gsi(legacy_gsi[irq],&pin);
        low=(DWORD)(M_VEC+irq)|irq_redir_flags(irq)|IOAPIC_REDIR_MASK;
        high=((DWORD)lapic_id)<<24;
        ioapic_write_redir(io,pin,low,high);
        if(ioapic_read(io,(BYTE)(IOAPIC_REDTBL_BASE+(pin*2U)))!=low ||
           ioapic_read(io,(BYTE)(IOAPIC_REDTBL_BASE+(pin*2U)+1U))!=high)
        {
            dprintk("APIC: IRQ%u GSI %lu redirection readback failed.\n",
                    irq,(unsigned long)legacy_gsi[irq]);
            return -1;
        }
    }
    return 0;
}

static void apply_local_nmi_routes(void)
{
    int i;
    DWORD lint0,lint1;
    if(!lapic) return;

    /* LINT0 normally carries 8259 ExtINT in virtual-wire mode.  JTMOS masks
     * the 8259 in APIC mode, so prevent a second legacy interrupt path. */
    lint0=lapic_read(LAPIC_LVT_LINT0)|LAPIC_LVT_MASKED;
    lapic_write(LAPIC_LVT_LINT0,lint0);

    /* V69.40: default OFF masks both LAPIC local NMI inputs regardless of
     * firmware or ACPI MADT routing. */
    lint1=lapic_read(LAPIC_LVT_LINT1);
    if(!apic_nmi_delivery_enabled)
    {
        lapic_write(LAPIC_LVT_LINT0,lint0|LAPIC_LVT_MASKED);
        lapic_write(LAPIC_LVT_LINT1,lint1|LAPIC_LVT_MASKED);
        return;
    }

    if((lint1&LAPIC_LVT_DELIVERY_MASK)!=LAPIC_LVT_NMI)
        lint1|=LAPIC_LVT_MASKED;
    else
        lint1&=~LAPIC_LVT_MASKED;
    lapic_write(LAPIC_LVT_LINT1,lint1);

    for(i=0;i<local_nmi_count;i++)
    {
        JTM_LOCAL_NMI *n=&local_nmi[i];
        DWORD v=LAPIC_LVT_NMI;
        unsigned polarity=(unsigned)(n->flags&3U);
        unsigned trigger=(unsigned)((n->flags>>2)&3U);
        if(!n->valid) continue;
        if(n->acpi_processor_id!=0xffU &&
           (bsp_acpi_processor_id==APIC_INVALID_CPU_ID || n->acpi_processor_id!=bsp_acpi_processor_id))
            continue;
        if(polarity==3U) v|=IOAPIC_REDIR_LOW_ACTIVE;
        if(trigger==3U) v|=IOAPIC_REDIR_LEVEL;
        lapic_write(n->lint ? LAPIC_LVT_LINT1 : LAPIC_LVT_LINT0,v);
    }
}

int apic_set_nmi_enabled(int enabled)
{
    DWORD flags=get_eflags();
    disable();
    apic_nmi_delivery_enabled=enabled?1:0;
    if(lapic) apply_local_nmi_routes();
    set_eflags(flags);
    return apic_nmi_delivery_enabled;
}

int apic_nmi_enabled(void)
{
    return apic_nmi_delivery_enabled?1:0;
}

static void find_bsp_acpi_processor_id(void)
{
    APIC_PHYS_MAP map={0,0,NULL};
    ACPI_MADT_HEADER *madt;
    BYTE *p,*end;
    DWORD phys=0;
    if(find_madt(&phys,&map,&madt)!=0) return;
    p=(BYTE *)madt+ACPI_MADT_FIXED_BYTES;
    end=(BYTE *)madt+madt->header.length;
    while(p+2U<=end)
    {
        ACPI_MADT_ENTRY_HEADER *eh=(ACPI_MADT_ENTRY_HEADER *)p;
        if(eh->length<2U || p+eh->length>end) break;
        if(eh->type==ACPI_MADT_LOCAL_APIC && eh->length>=sizeof(ACPI_MADT_LOCAL_APIC_ENTRY))
        {
            ACPI_MADT_LOCAL_APIC_ENTRY *e=(ACPI_MADT_LOCAL_APIC_ENTRY *)p;
            if(e->apic_id==lapic_id && (e->flags&1U))
            {
                bsp_acpi_processor_id=e->acpi_processor_id;
                break;
            }
        }
        p+=eh->length;
    }
    unmap_physical(&map);
}

static int enable_local_apic(void)
{
    DWORD a,b,c,d,lo,hi,msr_phys,map;
    if(!cpuHasFeature(JTMOS_CPUF_CPUID) || jtmos_cpu_info.max_basic_leaf<1U)
    {
        apic_state="8259 fallback: CPU has no CPUID/APIC enumeration";
        return -1;
    }
    apic_cpuid(1,0,&a,&b,&c,&d);
    if(!(d&(1UL<<9)))
    {
        apic_state="8259 fallback: CPU reports no local APIC";
        return -1;
    }
    if(!(d&(1UL<<5)))
    {
        apic_state="8259 fallback: CPU reports no MSR support";
        return -1;
    }
    apic_rdmsr(MSR_IA32_APIC_BASE,&lo,&hi);
    if(hi!=0U)
    {
        apic_state="8259 fallback: LAPIC base is above 4 GiB";
        return -1;
    }
    if(lo&APIC_BASE_X2APIC)
    {
        apic_state="8259 fallback: x2APIC mode is not enabled yet";
        return -1;
    }
    msr_phys=lo&APIC_BASE_ADDR_MASK;
    if(!msr_phys) msr_phys=lapic_phys ? lapic_phys : 0xfee00000UL;

    /* ACPI and the APIC-base MSR normally agree.  The MSR is authoritative for
     * the executing processor; only use the MADT address when the MSR had no
     * usable base. */
    lapic_phys=msr_phys;
    if(!(lo&APIC_BASE_ENABLE))
    {
        lo=(lo&~APIC_BASE_ADDR_MASK)|lapic_phys|APIC_BASE_ENABLE;
        apic_wrmsr(MSR_IA32_APIC_BASE,lo,0);
        apic_rdmsr(MSR_IA32_APIC_BASE,&lo,&hi);
        if(hi!=0U || !(lo&APIC_BASE_ENABLE))
        {
            apic_state="8259 fallback: could not enable local APIC";
            return -1;
        }
    }
    map=pg_mapio((int)(lapic_phys/4096UL),1);
    if(!map)
    {
        apic_state="8259 fallback: LAPIC MMIO mapping failed";
        return -1;
    }
    lapic_map=map;
    lapic=(volatile DWORD *)map;
    lapic_id=(BYTE)(lapic_read(LAPIC_ID)>>24);
    lapic_version=(BYTE)(lapic_read(LAPIC_VERSION)&0xffU);

    lapic_write(LAPIC_TPR,0U);
    lapic_write(LAPIC_SVR,LAPIC_SVR_ENABLE|LAPIC_SPURIOUS_VECTOR);
    /* Keep local timer/error sources masked in V69.20.  LVTPC stays masked so
     * the later PMU->NMI watchdog may claim it safely. */
    lapic_write(LAPIC_LVT_TIMER,lapic_read(LAPIC_LVT_TIMER)|LAPIC_LVT_MASKED);
    if(((lapic_read(LAPIC_VERSION)>>16)&0xffU)>=4U)
        lapic_write(LAPIC_LVTPC,lapic_read(LAPIC_LVTPC)|LAPIC_LVT_MASKED);
    lapic_write(LAPIC_LVT_ERROR,lapic_read(LAPIC_LVT_ERROR)|LAPIC_LVT_MASKED);
    /* Thermal LVT does not exist on the oldest P6 APICs; writing the architected
     * slot on CPUs that report it is harmless, but leave it untouched here. */
    return 0;
}

static void disable_local_apic_mapping(void)
{
    if(lapic_map) pg_unmapmemory(lapic_map,1);
    lapic_map=0;
    lapic=NULL;
}


/* V70 rapid preemption timer ------------------------------------------------
 *
 * The PIT intentionally remains programmed at the conservative platform rate
 * and remains the only source of GetTickCount()/PitGetUsec wall time.  LAPIC
 * timer IRQs only drive scheduler decisions, so raising the preemption rate
 * cannot make public time run fast.
 */
__attribute__((naked)) static void lapic_rapid_scheduler_ISR(void)
{
    __asm__ __volatile__(
        "cld\n\t"
        "pushal\n\t"
        "push %ds\n\t"
        "push %es\n\t"
        "push %fs\n\t"
        "push %gs\n\t"
        "mov $0x10, %ax\n\t"
        "mov %ax, %ds\n\t"
        "mov %ax, %es\n\t"
        "mov %ax, %fs\n\t"
        "mov %ax, %gs\n\t"
        "call SchedulerRapidTimerInterruptDispatch\n\t"
        "pop %gs\n\t"
        "pop %fs\n\t"
        "pop %es\n\t"
        "pop %ds\n\t"
        "popal\n\t"
        "iret\n\t"
    );
}

static int lapic_calibrate_timer(DWORD *count_hz_out)
{
    DWORD saved_flags,start_us,now_us,elapsed_us;
    DWORD start_count,end_count,delta;
    DWORD whole_mhz,remainder,frac_khz,rate;
    DWORD spins=0;

    if(count_hz_out) *count_hz_out=0;
    if(!apic_is_active || !lapic || !pit || !PitGetIrqHz())
        return -1;

    saved_flags=get_eflags();
    disable();
    lapic_write(LAPIC_LVT_TIMER,
                (DWORD)LAPIC_RAPID_VECTOR|LAPIC_LVT_MASKED);
    lapic_write(LAPIC_TIMER_DIVIDE,LAPIC_TIMER_DIV16);
    lapic_write(LAPIC_TIMER_INITIAL,0xffffffffUL);
    start_count=lapic_read(LAPIC_TIMER_CURRENT);

    /* Calibration deliberately allows PIT IRQ0 to run.  If the current task
     * is preempted during this window, both PIT wall time and the LAPIC counter
     * continue advancing, so the measured ratio remains valid. */
    enable();
    start_us=PitGetUsec();
    do {
        now_us=PitGetUsec();
        elapsed_us=(DWORD)(now_us-start_us);
        spins++;
        __asm__ __volatile__("nop");
        if(spins>100000000UL) break;
    } while(elapsed_us<LAPIC_TIMER_CAL_USEC);

    disable();
    end_count=lapic_read(LAPIC_TIMER_CURRENT);
    lapic_write(LAPIC_TIMER_INITIAL,0U);
    lapic_write(LAPIC_LVT_TIMER,
                (DWORD)LAPIC_RAPID_VECTOR|LAPIC_LVT_MASKED);
    set_eflags(saved_flags);

    elapsed_us=(DWORD)(now_us-start_us);
    if(elapsed_us<5000UL || elapsed_us>1000000UL || end_count>start_count)
        return -2;
    delta=start_count-end_count;
    if(delta<1000UL)
        return -3;

    /* Keep calibration entirely in 32-bit arithmetic.  The i486 freestanding
     * kernel does not link libgcc, so a 64-bit divide would emit __udivdi3.
     * Split delta/elapsed_us into an integer MHz part and a 1 kHz fractional
     * part.  The remainder is < elapsed_us (normally ~20,000), therefore
     * remainder*1000 cannot overflow DWORD during the calibration window.
     * 1 kHz resolution is far tighter than the scheduler needs. */
    whole_mhz=delta/elapsed_us;
    remainder=delta%elapsed_us;
    if(whole_mhz>0xffffffffUL/1000000UL)
        return -4;
    frac_khz=(remainder*1000UL + elapsed_us/2U)/elapsed_us;
    if(frac_khz>=1000UL) {
        whole_mhz++;
        frac_khz-=1000UL;
        if(whole_mhz>0xffffffffUL/1000000UL)
            return -4;
    }
    rate=whole_mhz*1000000UL + frac_khz*1000UL;
    if(rate<100000UL)
        return -4;
    if(count_hz_out) *count_hz_out=rate;
    return 0;
}

int apic_start_rapid_scheduler(DWORD target_hz)
{
#if !JTMOS_INTERRUPT_GATE_SCHEDULER
    (void)target_hz;
    return -10;
#else
    DWORD count_hz,initial,actual_hz,flags,lvt;
    int rv;

    if(lapic_rapid_timer_active)
        return (int)lapic_rapid_timer_hz;
    if(!apic_is_active || !lapic)
        return -1;
    if(target_hz<100U) target_hz=100U;
    if(target_hz>5000U) target_hz=5000U;

    setint(LAPIC_RAPID_VECTOR,lapic_rapid_scheduler_ISR,SEG_CODE32,
           D_INT + D_PRESENT);

    rv=lapic_calibrate_timer(&count_hz);
    if(rv!=0)
    {
        dprintk("APIC timer: calibration failed (%d); PIT scheduler retained.\n",rv);
        return rv;
    }

    initial=(count_hz + target_hz/2U)/target_hz;
    if(initial<16U) initial=16U;
    actual_hz=(count_hz + initial/2U)/initial;
    if(!actual_hz) return -5;

    flags=get_eflags();
    disable();
    lapic_timer_count_hz=count_hz;
    lapic_rapid_timer_hz=actual_hz;
    lapic_rapid_timer_active=1;

    /* Reset old PIT-quantum units before the first LAPIC scheduler IRQ. */
    SchedulerSetClockHz(actual_hz);
    lapic_write(LAPIC_TIMER_DIVIDE,LAPIC_TIMER_DIV16);
    lapic_write(LAPIC_LVT_TIMER,
                (DWORD)LAPIC_RAPID_VECTOR|LAPIC_TIMER_PERIODIC);
    lapic_write(LAPIC_TIMER_INITIAL,initial);
    lvt=lapic_read(LAPIC_LVT_TIMER);
    if((lvt&0xffU)!=LAPIC_RAPID_VECTOR ||
       !(lvt&LAPIC_TIMER_PERIODIC) || (lvt&LAPIC_LVT_MASKED))
    {
        lapic_write(LAPIC_LVT_TIMER,
                    (DWORD)LAPIC_RAPID_VECTOR|LAPIC_LVT_MASKED);
        lapic_write(LAPIC_TIMER_INITIAL,0U);
        lapic_rapid_timer_active=0;
        lapic_rapid_timer_hz=0;
        lapic_timer_count_hz=0;
        SchedulerSetClockHz(0);
        set_eflags(flags);
        return -6;
    }
    set_eflags(flags);

    dprintk("APIC timer: rapid scheduler active target=%u Hz actual=%u Hz count-clock=%u Hz initial=%u divide=16 vector=0x%x.\n",
            (unsigned)target_hz,(unsigned)actual_hz,(unsigned)count_hz,
            (unsigned)initial,(unsigned)LAPIC_RAPID_VECTOR);
    return (int)actual_hz;
#endif
}

void apic_stop_rapid_scheduler(void)
{
    DWORD flags=get_eflags();
    disable();
    if(lapic)
    {
        lapic_write(LAPIC_LVT_TIMER,
                    (DWORD)LAPIC_RAPID_VECTOR|LAPIC_LVT_MASKED);
        lapic_write(LAPIC_TIMER_INITIAL,0U);
    }
    lapic_rapid_timer_active=0;
    lapic_rapid_timer_hz=0;
    lapic_timer_count_hz=0;
    SchedulerSetClockHz(0);
    set_eflags(flags);
}

int apic_rapid_scheduler_active(void)
{
    return lapic_rapid_timer_active ? 1 : 0;
}

DWORD apic_rapid_scheduler_hz(void)
{
    return lapic_rapid_timer_hz;
}

int InitAPIC(void)
{
    DWORD flags;
    int i;

    flags=get_eflags();
    disable();
    apic_is_active=0;
    lapic_rapid_timer_active=0;
    lapic_rapid_timer_hz=0;
    lapic_timer_count_hz=0;
    madt_found=0;
    madt_phys=0;
    madt_flags=0;
    lapic=NULL;
    lapic_map=0;
    lapic_phys=0;
    lapic_id=0;
    lapic_version=0;
    memset(ioapics,0,sizeof(ioapics));
    memset(local_nmi,0,sizeof(local_nmi));
    legacy_routes_reset();

    /* V69.43: explicit recovery policy must be evaluated BEFORE parse_madt()
     * and enable_local_apic().  On MCP61/nForce 430 hardware this guarantees
     * no LAPIC/I/O-APIC MMIO access at all when noapic/nolapic was requested. */
    if(BOOTOPT_ACPI_OFF)
    {
        apic_state="8259 PIC forced by acpi=off";
        goto fallback;
    }
    if(BOOTOPT_NOLAPIC)
    {
        apic_state="8259 PIC forced by nolapic";
        goto fallback;
    }
    if(BOOTOPT_NOAPIC)
    {
        apic_state="8259 PIC forced by noapic";
        goto fallback;
    }
    if(!JTMOS_ACPI_ENABLED || !JTMOS_LAPIC_ENABLED || !JTMOS_APIC_ENABLED)
    {
        apic_state="8259 PIC forced by kernel option policy";
        goto fallback;
    }

    if(parse_madt()!=0) goto fallback;
    if(enable_local_apic()!=0) goto fallback;
    find_bsp_acpi_processor_id();
    if(map_ioapics()!=0)
    {
        apic_state="8259 fallback: I/O APIC MMIO mapping failed";
        goto fallback;
    }
    if(route_legacy_irqs()!=0)
    {
        apic_state="8259 fallback: incomplete legacy IRQ/GSI routing";
        goto fallback;
    }
    apply_local_nmi_routes();

    /* The PCAT-compatible 8259 pair remains initialized but fully masked.  Do
     * not unmask cascade IRQ2: external interrupts now enter through I/O APIC. */
    irq_mask=0xffffU;
    outportb(M_IMR,0xffU);
    outportb(S_IMR,0xffU);

    apic_is_active=1;
    apic_state="xAPIC + ACPI I/O APIC";
    dprintk("APIC: active LAPIC id=%u version=0x%x phys=%x, IOAPICs=%d MADT=%x%s\n",
            (unsigned)lapic_id,(unsigned)lapic_version,(unsigned)lapic_phys,
            ioapic_count,(unsigned)madt_phys,
            (madt_flags&ACPI_MADT_PCAT_COMPAT)?" PCAT-compatible":"");
    for(i=0;i<JTMOS_APIC_LEGACY_IRQS;i++)
        if(legacy_gsi[i]!=(DWORD)i || legacy_flags[i])
            dprintk("APIC: ISA IRQ%u -> GSI %lu flags=0x%x\n",i,
                    (unsigned long)legacy_gsi[i],(unsigned)legacy_flags[i]);
    {
        DWORD low,high;
        if(apic_get_legacy_redir(0U,&low,&high)==0)
            dprintk("APIC: PIT IRQ0 GSI %lu RTE=%08lx:%08lx (vector=0x%x, masked)\n",
                    (unsigned long)legacy_gsi[0],(unsigned long)high,
                    (unsigned long)low,(unsigned)(low&0xffU));
    }
    set_eflags(flags);
    return 1;

fallback:
    unmap_ioapics();
    disable_local_apic_mapping();
    apic_is_active=0;
    /* Init8259() ran immediately before us and left all lines masked.  Preserve
     * that safe state; later enable_irq() calls will use the PIC backend. */
    irq_mask=0xffffU;
    outportb(M_IMR,0xffU);
    outportb(S_IMR,0xffU);
    dprintk("APIC: %s.\n",apic_state);
    set_eflags(flags);
    return 0;
}

int apic_active(void)
{
    return apic_is_active;
}

const char *apic_status(void)
{
    return apic_state;
}

int apic_set_legacy_irq_mask(unsigned short irq,int masked)
{
    DWORD pin;
    DWORD low;
    BYTE reg;
    JTM_IOAPIC *io;
    if(!apic_is_active || irq>=JTMOS_APIC_LEGACY_IRQS || irq==2U) return -1;
    io=ioapic_for_gsi(legacy_gsi[irq],&pin);
    if(!io) return -1;
    ioapic_set_redir_mask(io,pin,masked ? 1 : 0);

    /* V69.22: read back the redirection entry.  A posted MMIO write that did
     * not reach the I/O APIC must never be reported to a driver as a working
     * enable/disable operation. */
    reg=(BYTE)(IOAPIC_REDTBL_BASE+(pin*2U));
    low=ioapic_read(io,reg);
    if(masked)
    {
        if(!(low&IOAPIC_REDIR_MASK)) return -2;
    }
    else if(low&IOAPIC_REDIR_MASK)
        return -2;
    return 0;
}

int apic_get_legacy_redir(unsigned short irq,DWORD *low,DWORD *high)
{
    DWORD pin;
    BYTE reg;
    JTM_IOAPIC *io;
    if(low) *low=0;
    if(high) *high=0;
    if(!apic_is_active || irq>=JTMOS_APIC_LEGACY_IRQS || irq==2U) return -1;
    io=ioapic_for_gsi(legacy_gsi[irq],&pin);
    if(!io) return -1;
    reg=(BYTE)(IOAPIC_REDTBL_BASE+(pin*2U));
    if(low) *low=ioapic_read(io,reg);
    if(high) *high=ioapic_read(io,(BYTE)(reg+1U));
    return 0;
}

void apic_send_eoi(void)
{
    if(apic_is_active && lapic)
        lapic_write(LAPIC_EOI,0U);
}

static int lapic_vector_bit(DWORD base,unsigned vector)
{
    DWORD reg,bit;
    if(!apic_is_active || !lapic || vector>255U) return 0;
    reg=base+((vector>>5)*0x10U);
    bit=1UL<<(vector&31U);
    return (lapic_read(reg)&bit) ? 1 : 0;
}

int apic_irq_pending(unsigned short irq)
{
    if(irq>=JTMOS_APIC_LEGACY_IRQS) return 0;
    return lapic_vector_bit(LAPIC_IRR_BASE,(unsigned)(M_VEC+irq));
}

int apic_irq_in_service(unsigned short irq)
{
    if(irq>=JTMOS_APIC_LEGACY_IRQS) return 0;
    return lapic_vector_bit(LAPIC_ISR_BASE,(unsigned)(M_VEC+irq));
}

WORD apic_legacy_irr(void)
{
    WORD v=0;
    unsigned i;
    for(i=0;i<JTMOS_APIC_LEGACY_IRQS;i++)
        if(apic_irq_pending((unsigned short)i)) v|=(WORD)(1U<<i);
    return v;
}

WORD apic_legacy_isr(void)
{
    WORD v=0;
    unsigned i;
    for(i=0;i<JTMOS_APIC_LEGACY_IRQS;i++)
        if(apic_irq_in_service((unsigned short)i)) v|=(WORD)(1U<<i);
    return v;
}

int apic_get_info(JTMOS_APIC_INFO *out)
{
    int i;
    if(!out) return -1;
    memset(out,0,sizeof(*out));
    out->active=apic_is_active;
    out->madt_found=madt_found;
    out->ioapic_count=ioapic_count;
    out->madt_phys=madt_phys;
    out->lapic_phys=lapic_phys;
    out->lapic_id=lapic_id;
    out->lapic_version=lapic_version;
    for(i=0;i<JTMOS_APIC_LEGACY_IRQS;i++)
    {
        out->legacy_gsi[i]=legacy_gsi[i];
        out->legacy_flags[i]=legacy_flags[i];
    }
    for(i=0;i<ioapic_count && i<JTMOS_APIC_MAX_IOAPICS;i++)
    {
        out->ioapic_phys[i]=ioapics[i].phys;
        out->ioapic_gsi_base[i]=ioapics[i].gsi_base;
        out->ioapic_redir_count[i]=ioapics[i].redir_count;
    }
    return 0;
}
