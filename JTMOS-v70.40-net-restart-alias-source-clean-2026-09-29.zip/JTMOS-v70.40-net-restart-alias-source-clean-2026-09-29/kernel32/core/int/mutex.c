/*
 * mutex.c - Linux-style sleeping thread mutexes for JTMOS V68.217.
 *
 * This is intentionally separate from lock.c.  The historical LOCK macro is
 * recursive and polls periodically; struct mutex is non-recursive, FIFO and
 * blocks a contended thread in the scheduler until direct hand-off.
 */
#define JTMOS_MUTEX_IMPLEMENTATION 1
#include "kernel32.h"
#include "mutex.h"
#include "lock.h"
#include "sync.h"
#include "scheduler.h"
#include "io.h"

typedef struct mutex_waiter
{
    struct mutex_waiter *next;
    struct mutex *lock;
    int pid;
    DWORD magic;
    volatile BYTE granted;
    const char *function;
    const char *file;
    int line;
} MUTEX_WAITER;

/* A thread can synchronously wait for only one mutex at a time.  Keeping the
 * waiter on its sleeping kernel stack mirrors Linux' stack waiter and avoids
 * allocation in the contended path. */
static MUTEX_WAITER *thread_waiter[N_MAX_THREADS];
static volatile BYTE thread_blocked[N_MAX_THREADS];
static struct mutex *mutex_registry;

/* A bounded walk keeps an accidentally damaged registry from hanging the
 * kernel forever with interrupts disabled.  JTMOS currently has only a small
 * number of static mutexes, so this is also a corruption sentinel. */
#define JTMOS_MUTEX_REGISTRY_LIMIT 1024U

static const char *mutex_safe_string(const char *s)
{
    return s ? s : "?";
}

static DWORD mutex_thread_magic(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    return thread_magic[pid];
}

static int mutex_owner_is_current(const struct mutex *lock,int pid)
{
    return lock->owner_pid==pid && lock->owner_magic==mutex_thread_magic(pid);
}

static int mutex_owner_is_alive(const struct mutex *lock)
{
    int pid=lock->owner_pid;
    if(pid<0) return 0;
    if(pid>=nr_threads || pid>=N_MAX_THREADS) return 0;
    if(!thread_states[pid]) return 0;
    return lock->owner_magic==thread_magic[pid];
}

/* Find a mutex by address without trusting its registered flag.  Return 1
 * when found, 0 when absent and -1 for a cyclic/overlong registry. */
static int mutex_registry_find_locked(struct mutex *wanted,
                                      struct mutex **previous_out)
{
    struct mutex *p,*previous;
    unsigned int scanned;

    previous=0;
    p=mutex_registry;
    for(scanned=0; p && scanned<JTMOS_MUTEX_REGISTRY_LIMIT; scanned++)
    {
        if(p==wanted)
        {
            if(previous_out) *previous_out=previous;
            return 1;
        }
        if(p->registry_next==p)
            return -1;
        previous=p;
        p=p->registry_next;
    }
    if(p) return -1;
    if(previous_out) *previous_out=0;
    return 0;
}

/* Caller holds the local IRQ-save critical section. */
static int mutex_registry_remove_locked(struct mutex *lock)
{
    struct mutex *previous,*next;
    int found;

    previous=0;
    found=mutex_registry_find_locked(lock,&previous);
    if(found<=0) return found;

    next=lock->registry_next;
    if(next==lock) next=0;
    if(previous) previous->registry_next=next;
    else mutex_registry=next;
    lock->registry_next=0;
    lock->registered=0;
    return 1;
}

/* Caller holds the local IRQ-save critical section. */
static int mutex_register_locked(struct mutex *lock)
{
    int found;

    found=mutex_registry_find_locked(lock,0);
    if(found<0) return -1;
    if(found>0)
    {
        lock->registered=1;
        return 0;
    }
    lock->registry_next=mutex_registry;
    mutex_registry=lock;
    lock->registered=1;
    return 0;
}

/* Caller holds the local IRQ-save critical section. */
static void mutex_clear_owner_locked(struct mutex *lock)
{
    lock->owner_pid=-1;
    lock->owner_magic=0;
    lock->owner_function=0;
    lock->owner_file=0;
    lock->owner_line=0;
    lock->acquired_ms=0;
}

/* Caller holds the local IRQ-save critical section. */
static int mutex_waiter_live_locked(MUTEX_WAITER *waiter,struct mutex *lock)
{
    int pid;
    if(waiter==0 || waiter->lock!=lock) return 0;
    pid=waiter->pid;
    if(pid<0 || pid>=nr_threads || pid>=N_MAX_THREADS) return 0;
    if(!thread_states[pid] || thread_magic[pid]!=waiter->magic) return 0;
    if(!thread_blocked[pid] || thread_waiter[pid]!=waiter) return 0;
    return 1;
}

/* Remove a particular queued waiter.  Caller holds the IRQ-save section. */
static int mutex_remove_waiter_locked(struct mutex *lock,MUTEX_WAITER *wanted)
{
    MUTEX_WAITER *waiter,*previous=0;
    for(waiter=(MUTEX_WAITER *)lock->wait_head; waiter; waiter=waiter->next)
    {
        if(waiter==wanted)
        {
            if(previous) previous->next=waiter->next;
            else lock->wait_head=waiter->next;
            if(lock->wait_tail==waiter) lock->wait_tail=previous;
            if(lock->waiters) lock->waiters--;
            waiter->next=0;
            return 1;
        }
        previous=waiter;
    }
    return 0;
}

/* Transfer ownership directly to the first live FIFO waiter.  Publishing the
 * new owner before clearing its blocked flag prevents lock stealing.  Caller
 * holds the IRQ-save section. */
static int mutex_handoff_locked(struct mutex *lock)
{
    MUTEX_WAITER *waiter;
    int pid;

    mutex_clear_owner_locked(lock);
    while((waiter=(MUTEX_WAITER *)lock->wait_head)!=0)
    {
        lock->wait_head=waiter->next;
        if(lock->wait_tail==waiter) lock->wait_tail=0;
        if(lock->waiters) lock->waiters--;
        waiter->next=0;

        pid=waiter->pid;
        if(!mutex_waiter_live_locked(waiter,lock))
        {
            if(pid>=0 && pid<N_MAX_THREADS && thread_waiter[pid]==waiter)
            {
                thread_waiter[pid]=0;
                thread_blocked[pid]=0;
            }
            continue;
        }

        lock->owner_pid=pid;
        lock->owner_magic=waiter->magic;
        lock->owner_function=waiter->function;
        lock->owner_file=waiter->file;
        lock->owner_line=waiter->line;
        lock->acquired_ms=GetTickCount();

        thread_waiter[pid]=0;
        thread_blocked[pid]=0;
        io_memory_barrier();
        waiter->granted=1;
        SchedulerWakeThread(pid);
        return pid;
    }
    return -1;
}

/* Follow mutex-only wait-for edges before putting requester to sleep.  If the
 * owner (or an owner further down the chain) is waiting for requester, the
 * new edge would form a cycle.  The N_MAX_THREADS bound also treats corrupt
 * cyclic metadata as unsafe instead of sleeping forever. */
static int mutex_would_deadlock_locked(struct mutex *lock,int requester)
{
    struct mutex *waiting_on;
    MUTEX_WAITER *waiter;
    int owner,depth;

    waiting_on=lock;
    for(depth=0; depth<N_MAX_THREADS; depth++)
    {
        owner=waiting_on->owner_pid;
        if(owner<0) return 0;
        if(owner==requester)
            return waiting_on->owner_magic==mutex_thread_magic(requester);
        if(owner>=nr_threads || owner>=N_MAX_THREADS ||
           !thread_states[owner] || !thread_blocked[owner]) return 0;
        if(waiting_on->owner_magic!=mutex_thread_magic(owner)) return 0;

        waiter=thread_waiter[owner];
        if(waiter==0 || waiter->pid!=owner || waiter->lock==0 ||
           waiter->magic!=mutex_thread_magic(owner))
            return 0;
        waiting_on=waiter->lock;
    }
    return 1;
}

void mutex_init(struct mutex *lock)
{
    int flags,found,busy;
    if(lock==0) return;
    flags=get_eflags();
    disable();

    found=mutex_registry_find_locked(lock,0);
    busy=found>0 &&
        (lock->owner_pid!=-1 || lock->wait_head!=0 ||
         lock->wait_tail!=0 || lock->waiters!=0);
    if(found<0 || busy)
    {
        set_eflags(flags);
        dprintk("[MUTEX] init rejected lock=%x reason=%s\n",
                (unsigned long)lock,found<0 ? "registry-corrupt" : "busy");
        return;
    }
    if(found>0) (void)mutex_registry_remove_locked(lock);

    lock->owner_pid=-1;
    lock->owner_magic=0;
    lock->wait_head=0;
    lock->wait_tail=0;
    lock->waiters=0;
    lock->name="<dynamic>";
    lock->owner_function=0;
    lock->owner_file=0;
    lock->owner_line=0;
    lock->acquired_ms=0;
    lock->registry_next=0;
    lock->registered=0;
    set_eflags(flags);
}

int mutex_destroy(struct mutex *lock)
{
    int flags,removed;
    if(lock==0) return -1;
    flags=get_eflags();
    disable();
    if(lock->owner_pid!=-1 || lock->wait_head!=0 || lock->wait_tail!=0 ||
       lock->waiters!=0)
    {
        set_eflags(flags);
        return -1;
    }
    removed=mutex_registry_remove_locked(lock);
    if(removed<0)
    {
        set_eflags(flags);
        return -1;
    }
    lock->registry_next=0;
    lock->registered=0;
    set_eflags(flags);
    return 0;
}

int mutex_trylock_at(struct mutex *lock,
                     const char *function,const char *file,int line)
{
    int flags,pid,acquired=0;
    if(lock==0) return 0;
    pid=GetCurrentThread();
    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    flags=get_eflags();
    disable();
    if(mutex_register_locked(lock)!=0)
    {
        set_eflags(flags);
        CrashAnalysisTraceLock(pid,CRASH_LOCK_BAD,(DWORD)lock,-1,
                               function,file,line);
        return 0;
    }
    if(lock->owner_pid!=-1 && !mutex_owner_is_alive(lock))
        (void)mutex_handoff_locked(lock);
    if(lock->owner_pid==-1)
    {
        lock->owner_pid=pid;
        lock->owner_magic=mutex_thread_magic(pid);
        lock->owner_function=function;
        lock->owner_file=file;
        lock->owner_line=line;
        lock->acquired_ms=GetTickCount();
        acquired=1;
    }
    set_eflags(flags);
    if(acquired)
        CrashAnalysisTraceLock(pid,CRASH_LOCK_ACQUIRE,(DWORD)lock,pid,
                               function,file,line);
    return acquired;
}

void mutex_lock_at(struct mutex *lock,
                   const char *function,const char *file,int line)
{
    MUTEX_WAITER waiter;
    int flags,pid,owner,waitcheck;
    DWORD waited_at;

    if(lock==0) KERNEL_FATAL("mutex_lock: NULL mutex");
    pid=GetCurrentThread();
    if(pid<0 || pid>=N_MAX_THREADS)
        KERNEL_FATAL("mutex_lock: invalid current PID");

    flags=get_eflags();
    disable();
    if(mutex_register_locked(lock)!=0)
    {
        set_eflags(flags);
        dprintk("[MUTEX] registry corrupt lock=%x at=%s %s:%d\n",
                (unsigned long)lock,mutex_safe_string(function),
                mutex_safe_string(file),line);
        KERNEL_FATAL("mutex_lock: registry corrupt");
    }

    if(lock->owner_pid!=-1 && !mutex_owner_is_alive(lock))
        (void)mutex_handoff_locked(lock);

    if(lock->owner_pid==-1)
    {
        lock->owner_pid=pid;
        lock->owner_magic=mutex_thread_magic(pid);
        lock->owner_function=function;
        lock->owner_file=file;
        lock->owner_line=line;
        lock->acquired_ms=GetTickCount();
        set_eflags(flags);
        CrashAnalysisTraceLock(pid,CRASH_LOCK_ACQUIRE,(DWORD)lock,pid,
                               function,file,line);
        return;
    }

    if(mutex_owner_is_current(lock,pid))
    {
        set_eflags(flags);
        CrashAnalysisTraceLock(pid,CRASH_LOCK_BAD,(DWORD)lock,pid,
                               function,file,line);
        dprintk("[MUTEX] recursive lock=%x name=%s pid=%d at=%s %s:%d\n",
                (unsigned long)lock,mutex_safe_string(lock->name),pid,
                mutex_safe_string(function),mutex_safe_string(file),line);
        KERNEL_FATAL("mutex_lock: recursive acquisition");
    }

    owner=lock->owner_pid;
    waited_at=GetTickCount();
    waitcheck=JtSyncBlockingWaitCheck(pid,flags);
    if(waitcheck!=JTMOS_SYNC_WAIT_OK)
    {
        set_eflags(flags);
        CrashAnalysisTraceLock(pid,CRASH_LOCK_BAD,(DWORD)lock,owner,
                               function,file,line);
        dprintk("[MUTEX] cannot-block lock=%x name=%s pid=%d owner=%d reason=%s at=%s %s:%d IF=%d\n",
                (unsigned long)lock,mutex_safe_string(lock->name),pid,owner,
                JtSyncBlockingWaitReason(waitcheck),
                mutex_safe_string(function),mutex_safe_string(file),line,
                (flags&0x200)?1:0);
        if(waitcheck==JTMOS_SYNC_WAIT_ATOMIC)
            KERNEL_FATAL("mutex_lock: contended in atomic context; use mutex_trylock");
        KERNEL_FATAL("mutex_lock: thread already has a blocking wait");
    }

    if(mutex_would_deadlock_locked(lock,pid))
    {
        set_eflags(flags);
        CrashAnalysisTraceLock(pid,CRASH_LOCK_BAD,(DWORD)lock,owner,
                               function,file,line);
        dprintk("[MUTEX] deadlock cycle lock=%x name=%s pid=%d owner=%d at=%s %s:%d\n",
                (unsigned long)lock,mutex_safe_string(lock->name),pid,owner,
                mutex_safe_string(function),mutex_safe_string(file),line);
        KERNEL_FATAL("mutex_lock: wait-for deadlock");
    }

    memset(&waiter,0,sizeof(waiter));
    waiter.lock=lock;
    waiter.pid=pid;
    waiter.magic=mutex_thread_magic(pid);
    waiter.function=function;
    waiter.file=file;
    waiter.line=line;
    if(lock->wait_tail)
        ((MUTEX_WAITER *)lock->wait_tail)->next=&waiter;
    else
        lock->wait_head=&waiter;
    lock->wait_tail=&waiter;
    lock->waiters++;
    thread_waiter[pid]=&waiter;
    thread_blocked[pid]=1;
    set_eflags(flags);

    CrashAnalysisTraceLock(pid,CRASH_LOCK_WAIT,(DWORD)lock,owner,
                           function,file,line);
    dprintk("[MUTEX] wait lock=%x name=%s pid=%d owner=%d at=%s %s:%d\n",
            (unsigned long)lock,mutex_safe_string(lock->name),pid,owner,
            mutex_safe_string(function),mutex_safe_string(file),line);

    /* The scheduler will not select this PID while thread_blocked[] is set.
     * A direct hand-off in mutex_unlock() clears it and grants ownership. */
    while(!waiter.granted)
        SwitchToThread();

    io_memory_barrier();
    CrashAnalysisTraceLock(pid,CRASH_LOCK_ACQUIRE,(DWORD)lock,pid,
                           function,file,line);
#if JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
    dprintk("[MUTEX] acquire lock=%x name=%s pid=%d waited_ms=%u\n",
            (unsigned long)lock,mutex_safe_string(lock->name),pid,
            (unsigned)(GetTickCount()-waited_at));
#else
    (void)waited_at;
#endif
}

void mutex_unlock_at(struct mutex *lock,
                     const char *function,const char *file,int line)
{
    int flags,pid,owner,next;
    DWORD acquired;
    const char *owner_function,*owner_file;
    int owner_line;

    if(lock==0) return;
    pid=GetCurrentThread();
    flags=get_eflags();
    disable();
    owner=lock->owner_pid;
    acquired=lock->acquired_ms;
    owner_function=lock->owner_function;
    owner_file=lock->owner_file;
    owner_line=lock->owner_line;

    if(!mutex_owner_is_current(lock,pid))
    {
        set_eflags(flags);
        CrashAnalysisTraceLock(pid,CRASH_LOCK_BAD,(DWORD)lock,owner,
                               function,file,line);
        dprintk("[MUTEX] bad unlock lock=%x name=%s pid=%d owner=%d owner_at=%s %s:%d caller=%s %s:%d\n",
                (unsigned long)lock,mutex_safe_string(lock->name),pid,owner,
                mutex_safe_string(owner_function),mutex_safe_string(owner_file),
                owner_line,mutex_safe_string(function),mutex_safe_string(file),line);
        return;
    }

    next=mutex_handoff_locked(lock);
    set_eflags(flags);
    CrashAnalysisTraceLock(pid,CRASH_LOCK_RELEASE,(DWORD)lock,owner,
                           function,file,line);
#if JTMOS_LOCK_TRACE_ACQUIRE_RELEASE
    dprintk("[MUTEX] release lock=%x name=%s pid=%d held_ms=%u next=%d\n",
            (unsigned long)lock,mutex_safe_string(lock->name),pid,
            (unsigned)(GetTickCount()-acquired),next);
#else
    (void)acquired;
    (void)next;
#endif
}

int mutex_is_locked(const struct mutex *lock)
{
    int flags,result;
    if(lock==0) return 0;
    flags=get_eflags();
    disable();
    result=lock->owner_pid!=-1;
    set_eflags(flags);
    return result;
}

int mutex_owner(const struct mutex *lock)
{
    int flags,result;
    if(lock==0) return -1;
    flags=get_eflags();
    disable();
    result=lock->owner_pid;
    set_eflags(flags);
    return result;
}

int JtMutexThreadBlocked(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    return thread_blocked[pid] ? 1 : 0;
}

const char *JtMutexThreadWaitName(int pid)
{
    MUTEX_WAITER *waiter;
    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    waiter=thread_waiter[pid];
    return (waiter && waiter->lock && waiter->lock->name) ?
           waiter->lock->name : 0;
}

/* Caller may already have interrupts disabled.  Nested IRQ-save is safe.
 * keep_owned_lock is used only by self-teardown: the lifecycle serializer
 * must remain owned until the thread table has been made consistently dead. */
void JtMutexThreadCleanupExcept(int pid,struct mutex *keep_owned_lock)
{
    struct mutex *lock;
    MUTEX_WAITER *waiter;
    int flags,registry_corrupt=0;
    unsigned int scanned;

    if(pid<0 || pid>=N_MAX_THREADS) return;
    flags=get_eflags();
    disable();

    waiter=thread_waiter[pid];
    if(waiter)
    {
        lock=waiter->lock;
        if(lock) (void)mutex_remove_waiter_locked(lock,waiter);
        thread_waiter[pid]=0;
        thread_blocked[pid]=0;
    }

    /* JTMOS can quarantine a faulting kernel/service thread.  Do not let its
     * mutexes wedge the rest of the system forever; hand each one to its next
     * live waiter.  The crash trace still records the original owner. */
    for(lock=mutex_registry,scanned=0;
        lock && scanned<JTMOS_MUTEX_REGISTRY_LIMIT;
        lock=lock->registry_next,scanned++)
        if(lock->owner_pid==pid && lock!=keep_owned_lock)
            (void)mutex_handoff_locked(lock);

    if(lock) registry_corrupt=1;

    set_eflags(flags);
    if(registry_corrupt)
        dprintk("[MUTEX] cleanup stopped at corrupt registry pid=%d\n",pid);
}

void JtMutexThreadCleanup(int pid)
{
    JtMutexThreadCleanupExcept(pid,0);
}

void JtMutexThreadInit(int pid)
{
    /* Also clears an impossible stale owner/waiter before a recycled PID gets
     * a new thread_magic value.  Normally lifecycle cleanup made this a no-op. */
    JtMutexThreadCleanup(pid);
}

/* locktop bridge; the public monitor structure lives in lock.h. */
int JtmosMutexSnapshot(JTMOS_LOCK_MONITOR_ENTRY *out,int capacity)
{
    struct mutex *lock;
    int flags,n=0;
    unsigned int scanned;
    if(out==0 || capacity<=0) return 0;
    flags=get_eflags();
    disable();
    for(lock=mutex_registry,scanned=0;
        lock && n<capacity && scanned<JTMOS_MUTEX_REGISTRY_LIMIT;
        lock=lock->registry_next,scanned++)
    {
        if(lock->owner_pid<0) continue;
        out[n].kind=JTMOS_LOCK_KIND_MUTEX;
        out[n].key=(DWORD)lock;
        out[n].owner_pid=lock->owner_pid;
        out[n].depth=1;
        out[n].acquired_ms=lock->acquired_ms;
        out[n].owner_function=lock->owner_function;
        out[n].owner_file=lock->owner_file;
        out[n].owner_line=lock->owner_line;
        n++;
    }
    set_eflags(flags);
    return n;
}
