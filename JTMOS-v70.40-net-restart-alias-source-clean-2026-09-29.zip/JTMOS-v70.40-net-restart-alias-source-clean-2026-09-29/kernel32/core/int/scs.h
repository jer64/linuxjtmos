//
#ifndef __INCLUDED_SYSTEMCALLS_H__
#define __INCLUDED_SYSTEMCALLS_H__
//
#include "basdef.h"
#include "localscall.h"

// Max. amount of time that a single postman command can take.
// Longer commands should be splitted automatically
// into several shorter commands.
// (TODO)
// 5 minutes.
#define TM_POSTCMD	(60*5)

//
extern void *A2K(DWORD appoffs);
extern void *_A2K(DWORD appoffs, int pid);
extern void *A2KRange(DWORD appoffs, DWORD length);
extern void *_A2KRange(DWORD appoffs, DWORD length, int pid);

//
#if defined(__GNUC__)
#define JTM_ABI_UNUSED __attribute__((unused))
#else
#define JTM_ABI_UNUSED
#endif

#define SYSCALLPAR	DWORD scall_eax JTM_ABI_UNUSED,\
			DWORD scall_ebx JTM_ABI_UNUSED,\
			DWORD scall_ecx JTM_ABI_UNUSED,\
			DWORD scall_edx JTM_ABI_UNUSED,\
			DWORD scall_esi JTM_ABI_UNUSED,\
			DWORD scall_edi JTM_ABI_UNUSED,\
			DWORD scall_ebp JTM_ABI_UNUSED

#define MYSYSCALLPAR	scall_eax,\
			scall_ebx,\
			scall_ecx,\
			scall_edx,\
			scall_esi,\
			scall_edi,\
			scall_ebp

// Max. amount of system calls specified at once
#define N_MAX_SCALLS		1000

// external functions
extern void relax_thread(void);
extern void scall_dummy(SYSCALLPAR);

// basic variables
extern void *scall_functions[N_MAX_SCALLS];
extern const unsigned char scall_irq_policy[N_MAX_SCALLS];
extern volatile DWORD scall_irq_unexpected_off_count;
extern volatile DWORD scall_irq_unexpected_off_last;
extern DWORD nr_scall_func;

//
DWORD scall_nothing(SYSCALLPAR);

//
void scallDeactive(void);
void scallActive(SYSCALLPAR);

// MISCELLANEOUS FUNCTIONS
DWORD scall_cexec(SYSCALLPAR);
DWORD scall_puts(SYSCALLPAR);
DWORD scall_putchar(SYSCALLPAR);
DWORD scall_exit(SYSCALLPAR);
DWORD scall_clrscr(SYSCALLPAR);
DWORD scall_getch(SYSCALLPAR);
int scall_postcmd(SYSCALLPAR);
int scall_getthreaduniquepid(SYSCALLPAR);

//
DWORD scall_getcurdev(SYSCALLPAR);
DWORD scall_getcurdb(SYSCALLPAR);
DWORD scall_getdevicename(SYSCALLPAR);
DWORD scall_chdir(SYSCALLPAR);

//
int scall_setint(SYSCALLPAR);
int scall_enableirq(SYSCALLPAR);

//
int scall_getthreadmemoryusage(SYSCALLPAR);
int scall_getthreadname(SYSCALLPAR);
int scall_getthreadspending(SYSCALLPAR);
int scall_getthreadpriority(SYSCALLPAR);
int scall_getthreadcount(SYSCALLPAR);
int scall_getcpustats(SYSCALLPAR);
int scall_bootutils(SYSCALLPAR);
int scall_fsusage(SYSCALLPAR);
void scall_relaxthread(SYSCALLPAR);
int scall_gotoxy(SYSCALLPAR);
DWORD scall_gettickcount(SYSCALLPAR);
DWORD scall_getamemsize(SYSCALLPAR);
DWORD scall_getcurrentthread(SYSCALLPAR);
DWORD scall_getargc(SYSCALLPAR);
int scall_getargv(SYSCALLPAR);
DWORD scall_waitprocterm(SYSCALLPAR);
int scall_textcolor(SYSCALLPAR);
int scall_textbackground(SYSCALLPAR);
int scall_getcursorlocation(SYSCALLPAR);
int scall_switchtothreadex(SYSCALLPAR);
int scall_switchtothread(SYSCALLPAR);

//
DWORD scall_findfirst(SYSCALLPAR);
DWORD scall_findnext(SYSCALLPAR);
DWORD scall_inputmouse(SYSCALLPAR);
int scall_setmouserect(SYSCALLPAR);
int scall_diskchange(SYSCALLPAR);

// VGA functions
DWORD scall_vgadrawframe(SYSCALLPAR);
int scall_graosstartup(SYSCALLPAR);
DWORD scall_vgaselectplane(SYSCALLPAR);
DWORD scall_vgawaitretrace(SYSCALLPAR);
int scall_killthread(SYSCALLPAR);

//
DWORD scall_wherex(SYSCALLPAR);
DWORD scall_wherey(SYSCALLPAR);

// Time / Date calls
DWORD scall_getdate(SYSCALLPAR);

//
int scall_getalt(SYSCALLPAR);
int scall_getctrl(SYSCALLPAR);

// Sockets
int scall_opensocket(SYSCALLPAR);
int scall_closesocket(SYSCALLPAR);
int scall_readsocket(SYSCALLPAR);
int scall_writesocket(SYSCALLPAR);

//
int scall_activatemsgbox(SYSCALLPAR);
int scall_receivemessage(SYSCALLPAR);
int scall_sendmessage(SYSCALLPAR);
int scall_getdevicenrbyname(SYSCALLPAR);
int scall_getthreadpid(SYSCALLPAR);
int scall_identifythread(SYSCALLPAR);
int scall_globalcopy(SYSCALLPAR);

//
int scall_getseconds(SYSCALLPAR);

//
int scall_getthreadterminal(SYSCALLPAR);
int scall_setthreadterminal(SYSCALLPAR);
int scall_newterminal(SYSCALLPAR);
int scall_outputterminalkeyboardbuffer(SYSCALLPAR);
int scall_inputterminalkeyboardbuffer(SYSCALLPAR);
int scall_copyterminal(SYSCALLPAR);
int scall_registernewdevice(SYSCALLPAR);

//
int scall_createterminal(SYSCALLPAR);
int scall_freeterminal(SYSCALLPAR);
int scall_setterminalowner(SYSCALLPAR);
int scall_getterminalowner(SYSCALLPAR);
int scall_serialget(SYSCALLPAR);
int scall_serialput(SYSCALLPAR);
int scall_setserialportspeed(SYSCALLPAR);
int scall_transmitrawpacket(SYSCALLPAR);
int scall_receiverawpacket(SYSCALLPAR);
int scall_devicecall(SYSCALLPAR);
int scall_milsleep(SYSCALLPAR);
int scall_usleep(SYSCALLPAR);
int scall_audioinit(SYSCALLPAR);
int scall_audiowrite(SYSCALLPAR);
int scall_audioposition(SYSCALLPAR);
int scall_audiostop(SYSCALLPAR);
int scall_audioinfo(SYSCALLPAR);
int scall_audioselect(SYSCALLPAR);
int scall_wgetch(SYSCALLPAR);
DWORD scall_rename(SYSCALLPAR);
DWORD scall_remove(SYSCALLPAR);
DWORD scall_mkfs(SYSCALLPAR);
DWORD scall_mkdir(SYSCALLPAR);

//
int scall_getcwd(SYSCALLPAR);
//
void *scall_kmalloc(SYSCALLPAR);
int scall_kfree(SYSCALLPAR);
DWORD scall_mmap(SYSCALLPAR);
int scall_munmap(SYSCALLPAR);
DWORD scall_mem_grow(SYSCALLPAR);

//
#include "postman.h"

//
#include "syscallcodes.h"

//
typedef struct {
  char lfn_magic[6];        /* LFN: the magic "LFN32" signature */
  short lfn_handle;         /* LFN: the handle used by findfirst/findnext */
  unsigned short lfn_ctime; /* LFN: file creation time */
  unsigned short lfn_cdate; /* LFN: file creation date */
  unsigned short lfn_atime; /* LFN: file last access time (usually 0) */
  unsigned short lfn_adate; /* LFN: file last access date */
  char ff_reserved[5];      /* used to hold the state of the search */
  unsigned char ff_attrib;  /* actual attributes of the file found */
  unsigned short ff_ftime;  /* hours:5, minutes:6, (seconds/2):5 */
  unsigned short ff_fdate;  /* (year-1980):7, month:4, day:5 */
  unsigned long ff_fsize;   /* size of file */
  char ff_name[260];        /* name of file as ASCIIZ string */
}VFAT_FFBLK;

//
int scall_fexist1(SYSCALLPAR);
int scall_getfiledatablock(SYSCALLPAR);
int scall_isdriveready(SYSCALLPAR);
int scall_getfilesize(SYSCALLPAR);
int scall_setsize(SYSCALLPAR);
int scall_read1(SYSCALLPAR);
int scall_write1(SYSCALLPAR);
int scall_creat1(SYSCALLPAR);
int scall_unlink1(SYSCALLPAR);

//
int scall_read(SYSCALLPAR);
int scall_write(SYSCALLPAR);
int scall_creat(SYSCALLPAR);
int scall_unlink(SYSCALLPAR);
int scall_open(SYSCALLPAR);
int scall_close(SYSCALLPAR);
int scall_lseek(SYSCALLPAR);
int scall_stat(SYSCALLPAR);
int scall_lstat(SYSCALLPAR);
int scall_fstat(SYSCALLPAR);

//
int scall_window(SYSCALLPAR);
int scall_copyfromthread(SYSCALLPAR);
int scall_irqsubscribe(SYSCALLPAR);
int scall_irqunsubscribe(SYSCALLPAR);
int scall_irqwait(SYSCALLPAR);
int scall_dmaalloc(SYSCALLPAR);
int scall_dmafree(SYSCALLPAR);
int scall_dmaprogram(SYSCALLPAR);
int scall_dmastop(SYSCALLPAR);
int scall_vgasetpalette(SYSCALLPAR);
int scall_getcpufeatures(SYSCALLPAR);
int scall_graosgraphics(SYSCALLPAR);
int scall_fork(SYSCALLPAR);
int scall_filebuf_read(SYSCALLPAR);
int scall_filebuf_write(SYSCALLPAR);
int scall_filebuf_flush(SYSCALLPAR);
int scall_filebuf_set(SYSCALLPAR);
int scall_filebuf_seek(SYSCALLPAR);
int scall_filebuf_tell(SYSCALLPAR);
DWORD scall_cexec_stdio(SYSCALLPAR);
int scall_setcursortype(SYSCALLPAR);

int scall_keystate(SYSCALLPAR);
int scall_smsh_builtin(SYSCALLPAR);
int scall_rmdir(SYSCALLPAR);
int scall_fsync(SYSCALLPAR);
int scall_sync(SYSCALLPAR);
int scall_truncate(SYSCALLPAR);
int scall_ftruncate(SYSCALLPAR);
int scall_access(SYSCALLPAR);
int scall_gettimeofday(SYSCALLPAR);
int scall_nanosleep(SYSCALLPAR);
int scall_sched_yield(SYSCALLPAR);

int scall_env(SYSCALLPAR);

#endif

//
