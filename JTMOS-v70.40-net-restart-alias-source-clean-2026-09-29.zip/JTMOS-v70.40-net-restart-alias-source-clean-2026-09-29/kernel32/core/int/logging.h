#ifndef __LOGGING_H_INCLUDED__
#define __LOGGING_H_INCLUDED__
void initSystemLogging(void);
void initSystemLog(void);
void WriteSystemLog(const char *msg);
void WriteSystemLogRaw(const char *msg,int len);
void WriteSystemLogStream(const char *channel,const char *msg);
int WriteCrashLogRaw(const char *msg,int len);
void SystemLoggingStorageReady(void);
int SystemLoggingPausePersistence(void);
void SystemLoggingResumePersistence(void);
int SystemLoggingStorageChanging(const char *device);
void SystemLoggingStorageChanged(const char *device);
void SystemLoggingWorkerFaulted(int pid);
int SystemLoggingIsWorker(int pid);
void SystemLoggingMaintenance(void);
int SystemLoggingStorageIsReady(void);
int SystemLoggingStreamEnabled(void);
int SystemLogFlushNow(void);
void WriteWWWLog(const char *msg);
void LoggerThreadProgram(void);
extern int system_logging;
#endif
