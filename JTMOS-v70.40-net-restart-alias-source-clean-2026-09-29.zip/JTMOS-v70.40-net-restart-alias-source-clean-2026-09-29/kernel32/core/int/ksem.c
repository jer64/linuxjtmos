/* FIFO sleeping counting semaphores for JTMOS V68.219. */
#define JTMOS_SEMAPHORE_IMPLEMENTATION 1
#include "kernel32.h"
#include "ksem.h"
#include "lock.h"
#include "sync.h"
#include "scheduler.h"
#include "io.h"

typedef struct semaphore_waiter
{
    struct semaphore_waiter *next;
    struct semaphore *sem;
    int pid;
    DWORD magic;
    volatile BYTE granted;
    const char *function;
    const char *file;
    int line;
} SEM_WAITER;

static SEM_WAITER *sem_thread_waiter[N_MAX_THREADS];
static volatile BYTE sem_thread_blocked[N_MAX_THREADS];
static struct semaphore *sem_registry;

#define JTMOS_SEM_REGISTRY_LIMIT 1024U

static DWORD sem_thread_magic(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    return thread_magic[pid];
}

static int sem_waiter_live_locked(SEM_WAITER *w,struct semaphore *sem)
{
    int pid;
    if(!w || w->sem!=sem) return 0;
    pid=w->pid;
    if(pid<0 || pid>=nr_threads || pid>=N_MAX_THREADS) return 0;
    if(!thread_states[pid] || thread_magic[pid]!=w->magic) return 0;
    if(!sem_thread_blocked[pid] || sem_thread_waiter[pid]!=w) return 0;
    return 1;
}

/* Do not trust sem->registered: a stale mutable flag must not be able to
 * duplicate a node or create a registry cycle.  Bounded traversal also keeps
 * IRQ-off lifecycle paths from hanging forever on damaged metadata. */
static int sem_registry_find_locked(struct semaphore *wanted,
                                    struct semaphore **previous_out)
{
    struct semaphore *sem,*previous=0;
    unsigned int scanned;
    for(sem=sem_registry,scanned=0;
        sem && scanned<JTMOS_SEM_REGISTRY_LIMIT;
        sem=sem->registry_next,scanned++)
    {
        if(sem==wanted)
        {
            if(previous_out) *previous_out=previous;
            return 1;
        }
        if(sem->registry_next==sem) return -1;
        previous=sem;
    }
    if(sem) return -1;
    if(previous_out) *previous_out=0;
    return 0;
}

static int sem_registry_remove_locked(struct semaphore *sem)
{
    struct semaphore *previous,*next;
    int found=sem_registry_find_locked(sem,&previous);
    if(found<=0) return found;
    next=sem->registry_next;
    if(next==sem) next=0;
    if(previous) previous->registry_next=next;
    else sem_registry=next;
    sem->registry_next=0;
    sem->registered=0;
    return 1;
}

static int sem_register_locked(struct semaphore *sem)
{
    int found=sem_registry_find_locked(sem,0);
    if(found<0) return -1;
    if(found>0)
    {
        sem->registered=1;
        return 0;
    }
    sem->registry_next=sem_registry;
    sem_registry=sem;
    sem->registered=1;
    return 0;
}

static int sem_remove_waiter_locked(struct semaphore *sem,SEM_WAITER *wanted)
{
    SEM_WAITER *w,*previous=0;
    for(w=(SEM_WAITER *)sem->wait_head;w;w=w->next)
    {
        if(w==wanted)
        {
            if(previous) previous->next=w->next;
            else sem->wait_head=w->next;
            if(sem->wait_tail==w) sem->wait_tail=previous;
            if(sem->waiters) sem->waiters--;
            w->next=0;
            return 1;
        }
        previous=w;
    }
    return 0;
}

static SEM_WAITER *sem_pop_live_locked(struct semaphore *sem)
{
    SEM_WAITER *w;
    int pid;
    while((w=(SEM_WAITER *)sem->wait_head)!=0)
    {
        sem->wait_head=w->next;
        if(sem->wait_tail==w) sem->wait_tail=0;
        if(sem->waiters) sem->waiters--;
        w->next=0;
        if(sem_waiter_live_locked(w,sem)) return w;
        pid=w->pid;
        if(pid>=0 && pid<N_MAX_THREADS && sem_thread_waiter[pid]==w)
        { sem_thread_waiter[pid]=0; sem_thread_blocked[pid]=0; }
    }
    return 0;
}

void semaphore_init(struct semaphore *sem,unsigned int value)
{
    int flags,found,busy;
    if(!sem) return;
    flags=get_eflags(); disable();
    found=sem_registry_find_locked(sem,0);
    busy=found>0 && (sem->wait_head || sem->wait_tail || sem->waiters);
    if(found<0 || busy)
    {
        set_eflags(flags);
        dprintk("[SEM] init rejected sem=%x reason=%s\n",
                (unsigned long)sem,found<0 ? "registry-corrupt" : "busy");
        return;
    }
    if(found>0) (void)sem_registry_remove_locked(sem);
    sem->count=value; sem->wait_head=0; sem->wait_tail=0; sem->waiters=0;
    sem->name="<dynamic>"; sem->registry_next=0; sem->registered=0;
    set_eflags(flags);
}

int semaphore_destroy(struct semaphore *sem)
{
    int flags,removed;
    if(!sem) return -1;
    flags=get_eflags(); disable();
    if(sem->wait_head || sem->wait_tail || sem->waiters)
    { set_eflags(flags); return -1; }
    removed=sem_registry_remove_locked(sem);
    if(removed<0) { set_eflags(flags); return -1; }
    sem->registry_next=0; sem->registered=0;
    set_eflags(flags); return 0;
}

int semaphore_trywait_at(struct semaphore *sem,const char *function,const char *file,int line)
{
    int flags,ok=0;
    (void)function; (void)file; (void)line;
    if(!sem) return 0;
    flags=get_eflags(); disable();
    if(sem_register_locked(sem)!=0) { set_eflags(flags); return 0; }
    if(sem->count && sem->wait_head==0) { sem->count--; ok=1; }
    set_eflags(flags); return ok;
}

void semaphore_wait_at(struct semaphore *sem,const char *function,const char *file,int line)
{
    SEM_WAITER waiter;
    int flags,pid,waitcheck;
    if(!sem) KERNEL_FATAL("semaphore_wait: NULL");
    pid=GetCurrentThread();
    if(pid<0 || pid>=N_MAX_THREADS) KERNEL_FATAL("semaphore_wait: invalid PID");
    flags=get_eflags(); disable();
    if(sem_register_locked(sem)!=0)
    { set_eflags(flags); KERNEL_FATAL("semaphore_wait: registry corrupt"); }
    if(sem->count && sem->wait_head==0)
    { sem->count--; set_eflags(flags); return; }
    waitcheck=JtSyncBlockingWaitCheck(pid,flags);
    if(waitcheck!=JTMOS_SYNC_WAIT_OK)
    {
        set_eflags(flags);
        dprintk("[SEM] cannot-block sem=%x name=%s pid=%d reason=%s IF=%d\n",
                (unsigned long)sem,sem->name ? sem->name : "?",pid,
                JtSyncBlockingWaitReason(waitcheck),(flags&0x200)?1:0);
        if(waitcheck==JTMOS_SYNC_WAIT_ATOMIC)
            KERNEL_FATAL("semaphore_wait: contention in atomic context");
        KERNEL_FATAL("semaphore_wait: thread already has a blocking wait");
    }
    memset(&waiter,0,sizeof(waiter));
    waiter.sem=sem; waiter.pid=pid; waiter.magic=sem_thread_magic(pid);
    waiter.function=function; waiter.file=file; waiter.line=line;
    if(sem->wait_tail) ((SEM_WAITER *)sem->wait_tail)->next=&waiter;
    else sem->wait_head=&waiter;
    sem->wait_tail=&waiter; sem->waiters++;
    sem_thread_waiter[pid]=&waiter; sem_thread_blocked[pid]=1;
    set_eflags(flags);
    while(!waiter.granted) SwitchToThread();
    io_memory_barrier();
}

void semaphore_post_at(struct semaphore *sem,const char *function,const char *file,int line)
{
    SEM_WAITER *w;
    int flags,pid;
    (void)function; (void)file; (void)line;
    if(!sem) return;
    flags=get_eflags(); disable();
    if(sem_register_locked(sem)!=0)
    { set_eflags(flags); KERNEL_FATAL("semaphore_post: registry corrupt"); }
    w=sem_pop_live_locked(sem);
    if(w)
    {
        pid=w->pid;
        sem_thread_waiter[pid]=0; sem_thread_blocked[pid]=0;
        io_memory_barrier();
        w->granted=1;
        SchedulerWakeThread(pid);
    }
    else if(sem->count!=0xffffffffUL)
        sem->count++;
    set_eflags(flags);
}

unsigned int semaphore_value(const struct semaphore *sem)
{
    int flags; unsigned int value;
    if(!sem) return 0;
    flags=get_eflags(); disable(); value=sem->count; set_eflags(flags); return value;
}

unsigned int semaphore_waiters(const struct semaphore *sem)
{
    int flags; unsigned int value;
    if(!sem) return 0;
    flags=get_eflags(); disable(); value=sem->waiters; set_eflags(flags); return value;
}

int JtSemaphoreThreadBlocked(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    return sem_thread_blocked[pid] ? 1 : 0;
}

const char *JtSemaphoreThreadWaitName(int pid)
{
    SEM_WAITER *w;
    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    w=sem_thread_waiter[pid];
    return (w && w->sem && w->sem->name) ? w->sem->name : 0;
}

void JtSemaphoreThreadCleanup(int pid)
{
    SEM_WAITER *w;
    int flags;
    if(pid<0 || pid>=N_MAX_THREADS) return;
    flags=get_eflags(); disable();
    w=sem_thread_waiter[pid];
    if(w)
    {
        if(w->sem) (void)sem_remove_waiter_locked(w->sem,w);
        sem_thread_waiter[pid]=0; sem_thread_blocked[pid]=0;
    }
    set_eflags(flags);
}

void JtSemaphoreThreadInit(int pid)
{
    JtSemaphoreThreadCleanup(pid);
}
