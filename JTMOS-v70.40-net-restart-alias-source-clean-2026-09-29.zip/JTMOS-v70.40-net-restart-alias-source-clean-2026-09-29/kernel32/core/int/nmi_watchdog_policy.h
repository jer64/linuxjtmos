#ifndef JTMOS_NMI_WATCHDOG_POLICY_H
#define JTMOS_NMI_WATCHDOG_POLICY_H

/* Pure arithmetic used by the NMI path.  No RTC/CMOS I/O, lock or syscall. */
static inline unsigned long NmiWatchdogElapsedSeconds(unsigned long now,
                                                      unsigned long last,
                                                      int hard_expiry)
{
    unsigned long age=now>=last ? now-last : 0UL;
    if(hard_expiry && age<4UL) age=4UL; /* independent IB700 host clock */
    return age;
}

static inline int NmiWatchdogMayTerminate(unsigned long measured_age,
                                           unsigned long threshold,
                                           int hard_expiry)
{
    return measured_age>threshold || (hard_expiry && 4UL>threshold);
}

/* IB700 may expire with IRQ0 still live if a task never switches.  In that
 * case do not turn IF on in a kernel IRQ/critical frame.  A PMU needs repeated
 * samples with no timer progress before attempting the same repair. */
static inline int NmiWatchdogMayRepairIf(int hard_expiry,int pit_progress,
                                         unsigned long pmu_stall_samples,
                                         unsigned long required_samples)
{
    if(hard_expiry) return !pit_progress;
    return pmu_stall_samples>=required_samples;
}

#endif
