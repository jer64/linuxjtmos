// =====================================================
// int 0x7E - JTMOS system call & FD database init.
// (C) 2001-2003 by Jari Tuominen
// =====================================================
#include "kernel32.h"
#include "system_call.h"
#include "int.h"
#include "systemcalls.h"
#include "filedes.h" // init_filedes - inits filedes database system

// System calls status.
int scallsIsWorking=FALSE;

// Install system call handler.
// (enables system calls)
void scall_init(void)
{
	int gate_entry JTM_UNUSED;
	DWORD i,irq_body_count=0,atomic_count=0;

	scallsIsWorking = FALSE;

	//
/*	gate_entry = gdt_NewEntry();
	SetCallGate(gate_entry, scall_handler,SEG_CODE32,
		128+ 64+32+ 8+4, // access: present(128), DPL3(64+32), 8+4(type=call gate)
		0);
	setint(SCALL_INT_NR, 0, gate_entry, 0xEE00);
*/

	//
	printk("[SCALL] installing INT 0x7F gate...\n");
	setint(SCALL_INT_NR, scall_handler, SEG_CODE32, 0xEE00); /* P=1,DPL=3,32-bit interrupt gate */
	printk("[SCALL] INT 0x7F gate installed.\n");

	/* V69.37: report the audited call-duration IRQ policy at boot. */
	scall_irq_unexpected_off_count=0;
	scall_irq_unexpected_off_last=0xffffffffUL;
	for(i=0;i<nr_scall_func;i++)
	{
		if(scall_irq_policy[i]) irq_body_count++;
		else atomic_count++;
	}
	printk("[SCALL] IRQ body policy: %lu enabled, %lu atomic; IF restored by IRET.\n",
		(unsigned long)irq_body_count,(unsigned long)atomic_count);

	// Init only
	// see scconf.h
//	setint(SCALL_INT_NR, scall_handler, SEG_CODE32, 0xEE00); /* P=1,DPL=3,32-bit interrupt gate */

	//
	printk("[SCALL] reserving INT 0x7E until TSS task gate is ready...\n");
	/* Never expose a present DPL3 interrupt gate with a NULL offset.  Thread/TSS
	 * initialization replaces this descriptor with the intended task gate. */
	setint(0x7E, NULL, SEG_CODE32, 0x0000);
	printk("[SCALL] INT 0x7E reserved non-present.\n");

	// Do not advertise syscall readiness until init_filedes() has completed.

	// Init file descriptor database system
	printk("[SCALL] initializing file descriptor database...\n");
	init_filedes();
	scallsIsWorking = TRUE;
	printk("[SCALL] file descriptor database initialized.\n");

	// Report
	if(scallsIsWorking)
		printk("System calls are enabled.\n");
	else
		printk("System calls are disabled.\n");
}

//

