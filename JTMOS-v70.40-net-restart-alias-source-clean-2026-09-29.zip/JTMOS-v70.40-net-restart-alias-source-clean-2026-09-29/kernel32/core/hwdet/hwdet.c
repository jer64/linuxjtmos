// ===========================================================
// HARDWARE DETECTION PROCESS
// Tries different drives and searches for new hardware.
// (C) 2003-2020 by Jari Tuominen (jari.t.tuominen@gmail.com).
// ===========================================================
#include "kernel32.h"
#include "threads.h"
#include "hwdet.h"
#include "serial.h"
#include "lpt.h"
#include "audio.h"

//
int alreadyCalled=0;
DWORD hwdetCounter=0,hwdetDone=0;
//
THREAD hwdetThread;

// Hardware detection
void hwdet(void)
{
	unsigned long irq_flags;

	//
	hwdetDone=0;

	//
	printk("HWDET ...\n");

	/* Only the publication of the worker is atomic.  Save/restore the incoming
	 * IF state instead of blindly enabling interrupts on each exit. */
	irq_flags=irq_save();
	hwdetDone = FALSE;
	if(ThreadCreateStack(&hwdetThread,1024*512)!=0)
	{ irq_restore(irq_flags); printk("HWDET: stack allocation failed.\n"); return; }
	hwdetThread.pid=create_thread(hwdetThread.stack,hwdetThread.l_stack,hwdetProgram);
	if(hwdetThread.pid<=0)
	{ ThreadDestroyStack(&hwdetThread); irq_restore(irq_flags); printk("HWDET: thread creation failed.\n"); return; }

	// Non-visible thread terminal
	////SetThreadTerminal(hwdetThread.pid, 1);
	// Max. 31 characters
	IdentifyThread(hwdetThread.pid, "KHWDET");
	irq_restore(irq_flags);

	/* This is a blocking process-context wait.  If a legacy IF=0 caller reaches
	 * it, allow timer/device IRQ progress temporarily and restore IF on return. */
	if(!(irq_flags & JTMOS_EFLAGS_IF)) enable();
	while(hwdetDone==FALSE)
	{
		sleep(1);
	}
	irq_restore(irq_flags);
	printk("End of internal driver running.\n");
}

//
void hwdetProgram(void)
{
	//
	if(alreadyCalled)
	{
		//
		hwdetDone=TRUE;
		ExitThread(0);
	}
	else
		//
		alreadyCalled=TRUE;

	// === DETECT NEW HARDWARE =======================
	// ===============================================


	// ===========================
	// COMMUNICATION DEVICES INIT:

	//
	if(LPT_ENABLED)
		// LPT ports
		lpt_init();

	// (HINT: DO THIS BEFORE THE SERIAL MOUSE, MOST WISE THING.)
	if(SERIAL_ENABLED && !serialInitialized)
		// SERIAL ports (normally already initialized by InitSystem)
		serial_init();

	if(PCI_ENABLED)
		// PCI bus
		pci_init();

	/* PS/2 mouse is attached during InitSystem() immediately after keyboard
	 * setup.  Do not make device availability depend on optional HWDET. */

	//
	if(SERMOUSE_ENABLED)
		SerialMouseInit();

	// ============================
	// OTHER HARDWARE DEVICES INIT:

	//
	// loading_logo();

	// =========================
	// BLOCK DEVICE DRIVERS INIT:

	// Generic audio device(GAD) init.
	// GAD is required for any audio drivers.
	if(AUDIO_ENABLED)
	{
		// Init GAD.
		audio_init();

		// Gravis Ultrasound init.
		if(GUS_ENABLED)
			gus_init();

		// Sound Blaster init.
		// 0=only checks briefly for SB, 1=hardscan, takes time.
		if(SB_ENABLED)
			sb_init(0);
	}

	// Flag that we are done here
	hwdetDone=1;

	// Exit.
	ExitThread(0);
}

//

