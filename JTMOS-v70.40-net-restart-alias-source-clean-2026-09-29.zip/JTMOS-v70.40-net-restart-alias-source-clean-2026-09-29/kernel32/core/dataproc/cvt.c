/*
 *	ecvt converts to decimal
 *	the number of digits is specified by ndigit
 *	decpt is set to the position of the decimal point
 *	sign is set to 0 for positive, 1 for negative
 */

#include <stdio.h>
#include "kernel32.h"
#include "int.h"
#include "modf.h"
//#include <math.h>

static char *cvt(double arg,int ndigits,int *decpt,int *sign,int eflag);

#define	NDIG	80

char *ecvt(double arg,int ndigits,int *decpt,int *sign)
{
	return cvt(arg,ndigits,decpt,sign,1);
}

char *fcvt(double arg,int ndigits,int *decpt,int *sign)
{
	return cvt(arg,ndigits,decpt,sign,0);
}

int ecvt_r(double arg,int ndigits,int *decpt,int *sign,char *out,int out_len)
{
    char *src;
    DWORD flags;
    int i;
    if(!out || out_len<=0 || !decpt || !sign) return -1;
    out[0]=0;
    /* Legacy ecvt() returns storage tied to the current PID.  Keep the
     * call+copy atomic with respect to ordinary IRQ/preemption so callers that
     * need a stable result can immediately detach it from that legacy slot. */
    flags=get_eflags();
    disable();
    src=cvt(arg,ndigits,decpt,sign,1);
    for(i=0;i+1<out_len && src && src[i];i++) out[i]=src[i];
    out[i]=0;
    set_eflags(flags);
    return (src && !src[i]) ? 0 : -1;
}

int fcvt_r(double arg,int ndigits,int *decpt,int *sign,char *out,int out_len)
{
    char *src;
    DWORD flags;
    int i;
    if(!out || out_len<=0 || !decpt || !sign) return -1;
    out[0]=0;
    flags=get_eflags();
    disable();
    src=cvt(arg,ndigits,decpt,sign,0);
    for(i=0;i+1<out_len && src && src[i];i++) out[i]=src[i];
    out[i]=0;
    set_eflags(flags);
    return (src && !src[i]) ? 0 : -1;
}

static char *cvt(double arg,int ndigits,int *decpt,int *sign,int eflag)
{
	register int r2;
	double fi, fj;
	register char *p, *p1;
	char *buf;
	static char thread_buf[N_MAX_THREADS][NDIG];
	static char bootstrap_buf[NDIG];
	int i,pid;

	/* ecvt/fcvt historically shared one global result buffer.  Concurrent
	 * printk/shell formatting could therefore corrupt another thread's number.
	 * Keep the legacy return-pointer ABI but make storage per thread. */
	pid=GetCurrentThread();
	buf=(pid>=0 && pid<N_MAX_THREADS && valid_pid(pid)) ? thread_buf[pid] : bootstrap_buf;

	if (ndigits<0)
		ndigits = 0;
	if (ndigits>=NDIG-1)
		ndigits = NDIG-2;
	r2 = 0;
	*sign = 0;
	p = &buf[0];
	if (arg<0) {
		*sign = 1;
		arg = -arg;
	}
	arg = modf(arg, &fi);
	p1 = &buf[NDIG];
	/*
	 * Do integer part
	 */
	if (fi != 0) {
		p1 = &buf[NDIG];
		for(i=0; i<NDIG && (fi != 0); i++) {
			fj = modf(fi/10, &fi);
			*--p1 = (int)((fj+.03)*10) + '0';
			r2++;
		}
		while (p1 < &buf[NDIG])
			*p++ = *p1++;
	} else if (arg > 0) {
		for(i=0; (fj = arg*10)<1; i++) {
			arg = fj;
			r2--;
		}
	}
	p1 = &buf[ndigits];
	if (eflag==0)
		p1 += r2;
	*decpt = r2;
	if (p1 < &buf[0]) {
		buf[0] = '\0';
		return(buf);
	}
	while (p<=p1 && p<&buf[NDIG]) {
		arg *= 10;
		arg = modf(arg, &fj);
		*p++ = (int)fj + '0';
	}
	if (p1 >= &buf[NDIG]) {
		buf[NDIG-1] = '\0';
		return(buf);
	}
	p = p1;
	*p1 += 5;
	while (*p1 > '9') {
		*p1 = '0';
		if (p1>buf)
			++*--p1;
		else {
			*p1 = '1';
			(*decpt)++;
			if (eflag==0) {
				if (p>buf)
					*p = '0';
				p++;
			}
		}
	}
	*p = '\0';
	return(buf);
}











