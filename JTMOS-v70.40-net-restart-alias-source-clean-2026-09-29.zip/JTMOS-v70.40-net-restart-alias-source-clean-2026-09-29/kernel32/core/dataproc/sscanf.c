// sscanf.c - bounded freestanding scanner for the JTMOS i386 kernel
#include <stdio.h>
#include "sscanf.h"
#include "string.h"
#include "ctypefamily.h"

#define JT_SCAN_MAX_WIDTH 0x7fffffff

enum jt_scan_len {
    JT_LEN_NONE=0,
    JT_LEN_HH,
    JT_LEN_H,
    JT_LEN_L,
    JT_LEN_LL,
    JT_LEN_CAPL,
    JT_LEN_Z,
    JT_LEN_T
};

static int jt_digit_value(int c,int base)
{
    int d;
    if(c>='0' && c<='9') d=c-'0';
    else if(c>='a' && c<='f') d=c-'a'+10;
    else if(c>='A' && c<='F') d=c-'A'+10;
    else return -1;
    return d<base ? d : -1;
}

static int jt_scan_uint64(const char **input,int width,int base,
                          unsigned long long *out,int *negative)
{
    const char *s;
    unsigned long long value=0ULL;
    int used=0,digits=0,d,neg=0;

    if(width<=0 || !input || !out) return 0;
    s=*input;
    if(!s) return 0;
    if((*s=='+' || *s=='-') && used<width) {
        neg=(*s=='-'); s++; used++;
    }
    if(base==0) {
        if(used+2<width && s[0]=='0' && (s[1]=='x' || s[1]=='X') &&
           jt_digit_value((unsigned char)s[2],16)>=0)
            base=16;
        else if(*s=='0') base=8;
        else base=10;
    }
    if(base==16 && used+2<width && s[0]=='0' && (s[1]=='x' || s[1]=='X') &&
       jt_digit_value((unsigned char)s[2],16)>=0) {
        s+=2; used+=2;
    }

    while(*s && used<width) {
        d=jt_digit_value((unsigned char)*s,base);
        if(d<0) break;
        if(base==16) {
            if(value>(~0ULL>>4)) return 0;
            value=(value<<4)|(unsigned)d;
        } else if(base==8) {
            if(value>(~0ULL>>3)) return 0;
            value=(value<<3)|(unsigned)d;
        } else {
            if(value>1844674407370955161ULL ||
               (value==1844674407370955161ULL && d>5)) return 0;
            value=value*10ULL+(unsigned)d;
        }
        s++; used++; digits++;
    }
    if(!digits) return 0;
    *input=s;
    *out=value;
    if(negative) *negative=neg;
    return 1;
}

static int jt_signed_fits(unsigned long long magnitude,int negative,int len)
{
    unsigned long long posmax,negmax;
    switch(len) {
        case JT_LEN_HH: posmax=127ULL; negmax=128ULL; break;
        case JT_LEN_H:  posmax=32767ULL; negmax=32768ULL; break;
        case JT_LEN_LL: posmax=0x7fffffffffffffffULL; negmax=0x8000000000000000ULL; break;
        default:        posmax=0x7fffffffULL; negmax=0x80000000ULL; break;
    }
    return magnitude <= (negative ? negmax : posmax);
}

static long long jt_signed_value(unsigned long long magnitude,int negative)
{
    if(!negative) return (long long)magnitude;
    if(magnitude==0x8000000000000000ULL)
        return (-0x7fffffffffffffffLL)-1LL;
    return -(long long)magnitude;
}

static void jt_store_signed(va_list *arg,int len,long long value)
{
    if(len==JT_LEN_HH) *va_arg(*arg,signed char *)=(signed char)value;
    else if(len==JT_LEN_H) *va_arg(*arg,short *)=(short)value;
    else if(len==JT_LEN_LL) *va_arg(*arg,long long *)=value;
    else if(len==JT_LEN_L || len==JT_LEN_Z || len==JT_LEN_T)
        *va_arg(*arg,long *)=(long)value;
    else *va_arg(*arg,int *)=(int)value;
}

static void jt_store_unsigned(va_list *arg,int len,unsigned long long value)
{
    if(len==JT_LEN_HH) *va_arg(*arg,unsigned char *)=(unsigned char)value;
    else if(len==JT_LEN_H) *va_arg(*arg,unsigned short *)=(unsigned short)value;
    else if(len==JT_LEN_LL) *va_arg(*arg,unsigned long long *)=value;
    else if(len==JT_LEN_L || len==JT_LEN_Z || len==JT_LEN_T)
        *va_arg(*arg,unsigned long *)=(unsigned long)value;
    else *va_arg(*arg,unsigned int *)=(unsigned int)value;
}

int sscanf(const char *s,const char *fmt,...)
{
    va_list arg;
    int result;
    va_start(arg,fmt);
    result=svscanf(s,fmt,arg);
    va_end(arg);
    return result;
}

int svscanf(const char *ss,const char *fmt,va_list arg)
{
    const char *s=ss;
    int assigned=0,suppress,width,spec,n,neg,len;
    char *dst,*end;
    unsigned long long value,uvalue;
    double dv;

    if(!s || !fmt) return 0;

    while(*fmt) {
        if(isspace((unsigned char)*fmt)) {
            while(isspace((unsigned char)*fmt)) fmt++;
            while(isspace((unsigned char)*s)) s++;
            continue;
        }
        if(*fmt!='%') {
            if(*s!=*fmt) break;
            s++; fmt++; continue;
        }
        fmt++;
        if(*fmt=='%') {
            if(*s!='%') break;
            s++; fmt++; continue;
        }

        suppress=0;
        if(*fmt=='*') { suppress=1; fmt++; }
        width=0;
        while(isdigit((unsigned char)*fmt)) {
            int digit=*fmt-'0';
            if(width>(JT_SCAN_MAX_WIDTH-digit)/10) width=JT_SCAN_MAX_WIDTH;
            else width=width*10+digit;
            fmt++;
        }
        if(width==0) width=JT_SCAN_MAX_WIDTH;

        len=JT_LEN_NONE;
        if(*fmt=='h') {
            fmt++; len=JT_LEN_H;
            if(*fmt=='h') { fmt++; len=JT_LEN_HH; }
        } else if(*fmt=='l') {
            fmt++; len=JT_LEN_L;
            if(*fmt=='l') { fmt++; len=JT_LEN_LL; }
        } else if(*fmt=='L') { fmt++; len=JT_LEN_CAPL; }
        else if(*fmt=='z') { fmt++; len=JT_LEN_Z; }
        else if(*fmt=='t') { fmt++; len=JT_LEN_T; }

        spec=(unsigned char)*fmt;
        if(!spec) break;
        fmt++;

        if(spec!='c' && spec!='n')
            while(isspace((unsigned char)*s)) s++;

        if(spec=='s') {
            if(!*s) break;
            n=0; dst=suppress ? NULL : va_arg(arg,char *);
            while(*s && !isspace((unsigned char)*s) && n<width) {
                if(dst) dst[n]=*s;
                s++; n++;
            }
            if(n==0) break;
            if(dst) { dst[n]=0; assigned++; }
        } else if(spec=='c') {
            n=(width==JT_SCAN_MAX_WIDTH)?1:width;
            if(n<=0) break;
            dst=suppress ? NULL : va_arg(arg,char *);
            while(n>0 && *s) {
                if(dst) *dst++=*s;
                s++; n--;
            }
            if(n!=0) break;
            if(!suppress) assigned++;
        } else if(spec=='n') {
            if(!suppress) {
                long long count=(long long)(s-ss);
                jt_store_signed(&arg,len,count);
            }
        } else if(spec=='d' || spec=='i' || spec=='u' || spec=='x' ||
                  spec=='X' || spec=='o' || spec=='p') {
            int base=(spec=='x' || spec=='X' || spec=='p')?16:
                     (spec=='o'?8:(spec=='i'?0:10));
            const char *scan=s;
            neg=0;
            if(!jt_scan_uint64(&scan,width,base,&value,&neg)) break;
            if(spec=='d' || spec=='i') {
                if(!jt_signed_fits(value,neg,len)) break;
                if(!suppress) {
                    jt_store_signed(&arg,len,jt_signed_value(value,neg));
                    assigned++;
                }
            } else if(spec=='p') {
                if(value>0xffffffffULL) break;
                if(!suppress) {
                    *va_arg(arg,void **)=(void *)(DWORD)value;
                    assigned++;
                }
            } else {
                uvalue=neg ? (0ULL-value) : value;
                if(!suppress) {
                    jt_store_unsigned(&arg,len,uvalue);
                    assigned++;
                }
            }
            s=scan;
        } else if(spec=='f' || spec=='e' || spec=='E' || spec=='g' || spec=='G') {
            dv=jt_strntod(s,(unsigned long)width,&end);
            if(end==s) break;
            s=end;
            if(!suppress) {
                if(len==JT_LEN_CAPL) *va_arg(arg,long double *)=(long double)dv;
                else if(len==JT_LEN_L) *va_arg(arg,double *)=dv;
                else *va_arg(arg,float *)=(float)dv;
                assigned++;
            }
        } else {
            break;
        }
    }
    return assigned;
}
