/*
 * JTMOS kernel printf-format core.
 *
 * This deliberately stays freestanding and 32-bit.  It is used by both
 * console printf/printk and string formatting so the two paths understand
 * exactly the same format language.
 */
#include "kernel32.h"
#include "stdarg.h"
#include "kformat.h"
#include "memcpy.h"

#define JTM_FORMAT_SANE_LIMIT 10000
#define JTM_FORMAT_FIELD_LIMIT 4096
#define JTM_FORMAT_OUTPUT_LIMIT 65536

static int jt_u32toa(char *dst, DWORD value, unsigned base, int upper)
{
    char rev[33];
    const char *digits;
    int n, i;

    digits = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    n = 0;
    do {
        rev[n++] = digits[value % base];
        value /= base;
    } while(value != 0 && n < (int)sizeof(rev));

    for(i=0; i<n; i++)
        dst[i] = rev[n-1-i];
    dst[n] = 0;
    return n;
}

/* Divide an unsigned 64-bit value by a small formatter base without relying
 * on compiler runtime helpers such as __udivdi3.  Four 16-bit limbs keep the
 * intermediate dividend below 2^20 for the supported bases 8, 10 and 16. */
static unsigned long long jt_u64_div_small(unsigned long long value,
                                            unsigned base, unsigned *remainder)
{
    DWORD hi=(DWORD)(value>>32);
    DWORD lo=(DWORD)value;
    unsigned limb[4], qlimb[4];
    unsigned rem=0, cur;
    DWORD qhi, qlo;
    int i;

    limb[0]=(unsigned)(hi>>16);
    limb[1]=(unsigned)(hi&0xffffU);
    limb[2]=(unsigned)(lo>>16);
    limb[3]=(unsigned)(lo&0xffffU);
    for(i=0;i<4;i++) {
        cur=(rem<<16)|limb[i];
        qlimb[i]=cur/base;
        rem=cur%base;
    }
    qhi=((DWORD)qlimb[0]<<16)|(DWORD)qlimb[1];
    qlo=((DWORD)qlimb[2]<<16)|(DWORD)qlimb[3];
    if(remainder) *remainder=rem;
    return ((unsigned long long)qhi<<32)|(unsigned long long)qlo;
}

static int jt_u64toa(char *dst, unsigned long long value, unsigned base, int upper)
{
    char rev[65];
    const char *digits=upper ? "0123456789ABCDEF" : "0123456789abcdef";
    int n=0,i;
    do {
        unsigned rem=0;
        value=jt_u64_div_small(value,base,&rem);
        rev[n++]=digits[rem];
    } while(value!=0ULL && n<(int)sizeof(rev));
    for(i=0;i<n;i++) dst[i]=rev[n-1-i];
    dst[n]=0;
    return n;
}

static int jt_text_len(const char *s, int precision)
{
    int n;
    n = 0;
    while(s[n] && (precision < 0 || n < precision))
        n++;
    return n;
}

static void jt_emit_repeat(jt_format_emit_fn emit, void *context,
                           char ch, int count, int *written)
{
    while(count-- > 0 && *written < JTM_FORMAT_OUTPUT_LIMIT) {
        emit(context, ch);
        (*written)++;
    }
}

static void jt_emit_text(jt_format_emit_fn emit, void *context,
                         const char *text, int length, int *written)
{
    int i;
    for(i=0; i<length && *written < JTM_FORMAT_OUTPUT_LIMIT; i++) {
        emit(context, text[i]);
        (*written)++;
    }
}

int jt_vformat(jt_format_emit_fn emit, void *context,
               const char *format, va_list args)
{
    const char *f;
    int scanned, written;

    if(!emit || !format)
        return 0;

    f = format;
    scanned = 0;
    written = 0;

    while(*f && scanned < JTM_FORMAT_SANE_LIMIT && written < JTM_FORMAT_OUTPUT_LIMIT) {
        int left, plus, space, alt, zero;
        int width, precision;
        int long_count, short_count;
        char spec;
        char number[40];
        const char *text;
        int text_len, numeric, negative;
        int base, upper;
        DWORD value;
        unsigned long long value64;
        int use64;
        char sign;
        char prefix[2];
        int prefix_len, precision_zeroes, pad;
        int core_len;

        scanned++;
        if(*f != '%') {
            emit(context, *f++);
            written++;
            continue;
        }

        f++;
        if(*f == '%') {
            emit(context, '%');
            written++;
            f++;
            continue;
        }
        if(*f == 0) {
            emit(context, '%');
            written++;
            break;
        }

        left = plus = space = alt = zero = 0;
        width = 0;
        precision = -1;
        long_count = short_count = 0;

        for(;;) {
            if(*f == '-') left = 1;
            else if(*f == '+') plus = 1;
            else if(*f == ' ') space = 1;
            else if(*f == '#') alt = 1;
            else if(*f == '0') zero = 1;
            else break;
            f++;
        }

        if(*f == '*') {
            width = va_arg(args, int);
            if(width < 0) {
                left = 1;
                if(width < -JTM_FORMAT_FIELD_LIMIT) width = JTM_FORMAT_FIELD_LIMIT;
                else width = -width;
            } else if(width > JTM_FORMAT_FIELD_LIMIT) {
                width = JTM_FORMAT_FIELD_LIMIT;
            }
            f++;
        } else {
            while(*f >= '0' && *f <= '9') {
                int digit=*f-'0';
                if(width > (JTM_FORMAT_FIELD_LIMIT-digit)/10)
                    width = JTM_FORMAT_FIELD_LIMIT;
                else
                    width = width * 10 + digit;
                f++;
            }
        }

        if(*f == '.') {
            f++;
            precision = 0;
            if(*f == '*') {
                precision = va_arg(args, int);
                if(precision < 0)
                    precision = -1;
                else if(precision > JTM_FORMAT_FIELD_LIMIT)
                    precision = JTM_FORMAT_FIELD_LIMIT;
                f++;
            } else {
                while(*f >= '0' && *f <= '9') {
                    int digit=*f-'0';
                    if(precision > (JTM_FORMAT_FIELD_LIMIT-digit)/10)
                        precision = JTM_FORMAT_FIELD_LIMIT;
                    else
                        precision = precision * 10 + digit;
                    f++;
                }
            }
        }

        if(*f == 'h') {
            short_count = 1;
            f++;
            if(*f == 'h') {
                short_count = 2;
                f++;
            }
        } else if(*f == 'l') {
            long_count = 1;
            f++;
            if(*f == 'l') {
                /* ll is a real 64-bit vararg even on the i386 ABI.  It must
                 * be consumed as such or every following argument is shifted. */
                long_count = 2;
                f++;
            }
        } else if(*f == 'L') {
            long_count = 1;
            f++;
        } else if(*f == 'z' || *f == 't') {
            /* size_t/ptrdiff_t are 32-bit in the JTMOS i386 ABI. */
            long_count = 1;
            f++;
        }

        spec = *f;
        if(spec == 0) {
            emit(context, '%');
            written++;
            break;
        }
        f++;

        text = number;
        text_len = 0;
        numeric = 0;
        negative = 0;
        base = 10;
        upper = 0;
        value = 0;
        value64 = 0ULL;
        use64 = 0;
        sign = 0;
        prefix_len = 0;

        if(spec == 's') {
            text = va_arg(args, const char *);
            if(!text || illegal(text))
                text = "[NULL]";
            text_len = jt_text_len(text, precision);
        } else if(spec == 'c') {
            number[0] = (char)va_arg(args, int);
            number[1] = 0;
            text_len = 1;
        } else if(spec == 'd' || spec == 'i') {
            long long signed_value;
            numeric = 1;
            if(long_count >= 2) {
                signed_value = va_arg(args, long long);
                use64 = 1;
            } else if(long_count == 1) {
                signed_value = (long long)va_arg(args, long);
            } else {
                int raw = va_arg(args, int);
                if(short_count == 1) raw=(int)(short)raw;
                else if(short_count >= 2) raw=(int)(signed char)raw;
                signed_value = (long long)raw;
            }
            if(signed_value < 0) {
                negative = 1;
                value64 = (unsigned long long)(-(signed_value + 1LL));
                value64 += 1ULL;
            } else {
                value64 = (unsigned long long)signed_value;
            }
            value=(DWORD)value64;
            if(negative) sign = '-';
            else if(plus) sign = '+';
            else if(space) sign = ' ';
            if(precision == 0 && value64 == 0ULL)
                text_len = 0;
            else if(use64)
                text_len = jt_u64toa(number, value64, 10U, 0);
            else
                text_len = jt_u32toa(number, value, 10U, 0);
        } else if(spec == 'u' || spec == 'x' || spec == 'X' || spec == 'o') {
            numeric = 1;
            if(long_count >= 2) {
                value64 = va_arg(args, unsigned long long);
                use64 = 1;
            } else if(long_count == 1) {
                value64 = (unsigned long long)va_arg(args, unsigned long);
            } else if(short_count) {
                unsigned int raw=(unsigned int)va_arg(args,int);
                if(short_count == 1) raw=(unsigned int)(unsigned short)raw;
                else raw=(unsigned int)(unsigned char)raw;
                value64=(unsigned long long)raw;
            } else {
                value64 = (unsigned long long)va_arg(args, unsigned int);
            }
            value=(DWORD)value64;
            if(spec == 'x' || spec == 'X') {
                base = 16;
                upper = (spec == 'X');
            } else if(spec == 'o') {
                base = 8;
            }
            if(precision == 0 && value64 == 0ULL)
                text_len = 0;
            else if(use64)
                text_len = jt_u64toa(number, value64, (unsigned)base, upper);
            else
                text_len = jt_u32toa(number, value, (unsigned)base, upper);
            if(alt && value64 != 0ULL && (spec == 'x' || spec == 'X')) {
                prefix[0] = '0';
                prefix[1] = spec;
                prefix_len = 2;
            } else if(alt && spec == 'o' &&
                      (text_len == 0 || number[0] != '0')) {
                prefix[0] = '0';
                prefix_len = 1;
            }
        } else if(spec == 'p') {
            numeric = 1;
            value = (DWORD)va_arg(args, void *);
            base = 16;
            prefix[0] = '0';
            prefix[1] = 'x';
            prefix_len = 2;
            text_len = jt_u32toa(number, value, 16U, 0);
        } else if(spec == 'f' || spec == 'F') {
            /* Preserve the historical kernel behaviour: floating point
             * formatting is intentionally not performed in printk context. */
            (void)va_arg(args, double);
            text = "";
            text_len = 0;
        } else {
            /* Unknown conversion: preserve it visibly instead of eating text. */
            emit(context, '%');
            emit(context, spec);
            written += 2;
            continue;
        }

        if(numeric && precision >= 0)
            zero = 0;

        precision_zeroes = 0;
        if(numeric && precision > text_len)
            precision_zeroes = precision - text_len;

        core_len = text_len + precision_zeroes + prefix_len + (sign ? 1 : 0);
        pad = width > core_len ? width - core_len : 0;

        if(!left && !zero)
            jt_emit_repeat(emit, context, ' ', pad, &written);
        if(sign) {
            emit(context, sign);
            written++;
        }
        if(prefix_len)
            jt_emit_text(emit, context, prefix, prefix_len, &written);
        if(!left && zero)
            jt_emit_repeat(emit, context, '0', pad, &written);
        jt_emit_repeat(emit, context, '0', precision_zeroes, &written);
        jt_emit_text(emit, context, text, text_len, &written);
        if(left)
            jt_emit_repeat(emit, context, ' ', pad, &written);
    }

    return written;
}
