//--------------------------------------------------------------------------------
// scheduler.c - Main scheduler.
// (C) 2004-2005 by Jari Tuominen(jari@vunet.org).
//
// A TSS based task switching system.
// See threadSwitch.c for the switching logic.
//--------------------------------------------------------------------------------
#include "kernel32.h"
#include "system_call.h" // scallsIsWorking
#include "scheduler.h"
#include "syscallcodes.h"
#include "pit.h"
#include "rtc.h"
#include "nmi.h"
#include "nmi_source.h"
#include "sync.h"
#include "apic.h"

/*
 * Fixed-point scheduler accounting.
 *
 * Load averages are sampled once per second and use the same exponential
 * time constants as the familiar Unix/Linux 1/5/15 minute load averages.
 * The internal representation is Q16.  A 64-bit intermediate is used only for
 * the multiply; i386 GCC emits ordinary integer instructions for this path and
 * no floating-point state is touched by the scheduler.
 */
#define LOAD_A_BETA_Q16 1083U   /* 1 - exp(-1/60)  */
#define LOAD_B_BETA_Q16  218U   /* 1 - exp(-1/300) */
#define LOAD_C_BETA_Q16   73U   /* 1 - exp(-1/900) */

/* -------------------------------------------------------------------------
 * V68.160 TSS context validation.
 *
 * JTMOS still uses 386 hardware task switching for the final process-to-
 * process transfer even though IRQ0 itself is now an interrupt gate.  A bad
 * saved TSS EIP/CR3/descriptor therefore becomes live CPU state immediately
 * at the far JMP.  Validate the target before executing that JMP and keep a
 * small serial trace budget for the first switches after boot.
 *
 * These diagnostics intentionally use the raw debug UART helpers rather than
 * printf/dprintk: PitStorageSafeEnd() calls the dump with IF=0, so the
 * diagnostic path must not allocate, lock, or depend on scheduler progress.
 */
#define SCHED_TSS_BAD_PID          0x00000001UL
#define SCHED_TSS_BAD_GLOBAL       0x00000002UL
#define SCHED_TSS_BAD_SELECTORS    0x00000004UL
#define SCHED_TSS_BAD_EFLAGS       0x00000008UL
#define SCHED_TSS_BAD_CR3          0x00000010UL
#define SCHED_TSS_BAD_DESC_BASE    0x00000020UL
#define SCHED_TSS_BAD_DESC_PRESENT 0x00000040UL
#define SCHED_TSS_BAD_DESC_TYPE    0x00000080UL
#define SCHED_TSS_BAD_KERNEL_EIP   0x00000100UL
#define SCHED_TSS_BAD_TARGET_BUSY  0x00000200UL
#define SCHED_TSS_BAD_PRIVILEGE    0x00000400UL
#define SCHED_TSS_BAD_USER_RANGE   0x00000800UL

static volatile DWORD scheduler_switch_trace_budget=16;

static DWORD scheduler_tss_descriptor_base(const CDSEG *d)
{
    DWORD base;

    if(!d) return 0;
    base=(DWORD)d->base0_15;
    base|=((DWORD)d->base16_23)<<16;
    base|=((DWORD)d->base24_31)<<24;
    return base;
}

static DWORD scheduler_task_context_issues(int pid, int switch_target)
{
    TSSEG *t;
    CDSEG *d;
    DWORD issues=0;
    int threadtype;
    DWORD desc_base;
    DWORD text_end;
    unsigned type;

    if(pid<0 || pid>=nr_threads || pid>=N_MAX_THREADS)
        return SCHED_TSS_BAD_PID;
    if(!tasks || !gdt_table)
        return SCHED_TSS_BAD_GLOBAL;

    t=&tasks->tss[pid];
    d=&gdt_table->tssdes[pid];
    threadtype=GetThreadType(pid);

    if(!t->cs || !t->ss || !t->ds || !t->es || !t->fs || !t->gs)
        issues|=SCHED_TSS_BAD_SELECTORS;

    /* Architectural EFLAGS bit 1 is always one in a valid saved task. */
    if(!(t->eflags & 0x00000002UL))
        issues|=SCHED_TSS_BAD_EFLAGS;

    /* Ring3 application invariant.
     *
     * The interrupt-gate scheduler executes its hardware TSS jump while it
     * is still in the timer/yield ISR.  Even a task interrupted in Ring3 is
     * therefore saved with kernel CS and the private ss0 stack.  Other kernel
     * handlers can be suspended too.  thread_scall_active[] covers only INT
     * 0x7f and cannot identify the saved privilege.
     *
     * For a kernel resume require the exact kernel selectors, an EIP inside
     * kernel text (checked below), and ESP on this task's private ss0 stack.
     * A userspace task cannot load the kernel selectors or write its TSS. */
    if(threadtype & THREAD_TYPE_APPLICATION)
    {
        if(thread_selector[pid]!=USER_CS || thread_ss[pid]!=USER_DS ||
           t->ss0!=SEG_DATA32 || t->esp0==0 || t->iopb<sizeof(TSSEG))
            issues|=SCHED_TSS_BAD_PRIVILEGE;

        if(t->eflags & (0x00003000UL|0x00004000UL|0x00020000UL))
            issues|=SCHED_TSS_BAD_EFLAGS;

        if(t->cs==SEG_CODE32)
        {
            DWORD stack_low;

            /* IRQ0/scheduler_yield_ISR normalise all data selectors to the
             * flat kernel data selector before the hardware task switch. */
            if(t->cs!=SEG_CODE32 || t->ss!=SEG_DATA32 ||
               t->ds!=SEG_DATA32 || t->es!=SEG_DATA32 ||
               t->fs!=SEG_DATA32 || t->gs!=SEG_DATA32)
                issues|=SCHED_TSS_BAD_PRIVILEGE;

            /* esp0 is the top of NewTSS()'s JTMOS_MIN_DYNAMIC_STACK buffer.
             * A suspended syscall must still be executing on that private
             * trusted Ring0 stack, never on arbitrary application memory. */
            if(t->esp0 < JTMOS_MIN_DYNAMIC_STACK)
                issues|=SCHED_TSS_BAD_USER_RANGE;
            else
            {
                stack_low=t->esp0-JTMOS_MIN_DYNAMIC_STACK;
                if(t->esp<stack_low || t->esp>t->esp0)
                    issues|=SCHED_TSS_BAD_USER_RANGE;
            }
        }
        else
        {
            if(t->cs!=USER_CS || t->ss!=USER_DS || t->ds!=USER_DS ||
               t->es!=USER_DS || t->fs!=USER_DS || t->gs!=USER_DS)
                issues|=SCHED_TSS_BAD_PRIVILEGE;
            if(t->eip<MM_USER_BASE || t->eip>=MM_USER_TOP ||
               t->esp<MM_USER_BASE || t->esp>=MM_USER_TOP)
                issues|=SCHED_TSS_BAD_USER_RANGE;
        }
    }

    /* The TSS CR3 is a physical page-directory address. */
    if(!t->cr3 || (t->cr3 & (PAGESIZE-1U)))
        issues|=SCHED_TSS_BAD_CR3;

    desc_base=scheduler_tss_descriptor_base(d);
    if(desc_base!=(DWORD)t)
        issues|=SCHED_TSS_BAD_DESC_BASE;
    if(!(d->flags & 0x80U))
        issues|=SCHED_TSS_BAD_DESC_PRESENT;

    type=(unsigned)(d->flags & 0x0fU);
    if(type!=9U && type!=11U)
        issues|=SCHED_TSS_BAD_DESC_TYPE;
    if(switch_target && type==11U)
        issues|=SCHED_TSS_BAD_TARGET_BUSY;

    /* Only the flat DPL0 kernel code selector can be range-checked this way.
     * Ring-3/application selectors may legitimately use 0x80000000+ EIPs. */
    if((t->cs & 0xfffcU)==SEG_CODE32)
    {
        text_end=(DWORD)&etext;
        if(t->eip<JTMOS_KERNEL_LOAD_PHYS || t->eip>=text_end)
            issues|=SCHED_TSS_BAD_KERNEL_EIP;
    }

    return issues;
}

static void scheduler_serial_hex(const char *label, DWORD value)
{
    DebugSerialWrite(label);
    DebugSerialWriteHex32(value);
}

static void scheduler_debug_dump_task(const char *tag, int pid, int target)
{
    TSSEG *t;
    CDSEG *d;
    DWORD issues;

    if(!DebugSerialRuntimeEnabled()) return;

    DebugSerialWrite("[SCHED/TSS] ");
    DebugSerialWrite(tag ? tag : "snapshot");
    scheduler_serial_hex(" pid=",(DWORD)pid);

    issues=scheduler_task_context_issues(pid,target);
    if(pid<0 || pid>=nr_threads || pid>=N_MAX_THREADS || !tasks || !gdt_table)
    {
        scheduler_serial_hex(" issues=",issues);
        DebugSerialWrite("\n");
        return;
    }

    t=&tasks->tss[pid];
    d=&gdt_table->tssdes[pid];
    scheduler_serial_hex(" state=",(DWORD)thread_states[pid]);
    scheduler_serial_hex(" type=",(DWORD)thread_type[pid]);
    scheduler_serial_hex(" cs=",(DWORD)t->cs);
    scheduler_serial_hex(" eip=",t->eip);
    scheduler_serial_hex(" ss=",(DWORD)t->ss);
    scheduler_serial_hex(" esp=",t->esp);
    scheduler_serial_hex(" esp0=",t->esp0);
    scheduler_serial_hex(" eflags=",t->eflags);
    scheduler_serial_hex(" cr3=",t->cr3);
    scheduler_serial_hex(" descbase=",scheduler_tss_descriptor_base(d));
    scheduler_serial_hex(" desctype=",(DWORD)(d->flags & 0x0fU));
    scheduler_serial_hex(" scall=",(DWORD)thread_scall_active[pid]);
    scheduler_serial_hex(" issues=",issues);
    DebugSerialWrite("\n");
}

int SchedulerTaskContextSane(int pid)
{
    return scheduler_task_context_issues(pid,FALSE)==0;
}

void SchedulerDebugDumpRunnable(const char *tag)
{
    int i;

    if(!DebugSerialRuntimeEnabled()) return;
    DebugSerialWrite("[SCHED/TSS] runnable snapshot begin: ");
    DebugSerialWrite(tag ? tag : "snapshot");
    DebugSerialWrite("\n");
    for(i=0;i<nr_threads && i<N_MAX_THREADS;i++)
        if(thread_states[i])
            scheduler_debug_dump_task(tag,i,FALSE);
    DebugSerialWrite("[SCHED/TSS] runnable snapshot end\n");
}

static int scheduler_validate_switch_target(int old_pid, int new_pid,
                                            const char *where)
{
    DWORD issues;

    issues=scheduler_task_context_issues(new_pid,TRUE);
    if(!issues) return TRUE;

    scheduler_debug_dump_task(where,new_pid,TRUE);
    DebugSerialWrite("[SCHED/TSS] refusing corrupt switch target; keeping old PID\n");

    if(new_pid==0)
        KERNEL_FATAL("scheduler: PID0 has a corrupt TSS context");

    /* Quarantine instead of entering a TSS whose saved CPU state is already
     * known to be impossible.  Full destruction is intentionally deferred:
     * KillThreadEx() is not IRQ-context-safe. */
    if(new_pid>0 && new_pid<nr_threads && new_pid<N_MAX_THREADS)
        ThreadQuarantineFromIRQ(new_pid);
    nr_curthread=old_pid;
    return FALSE;
}

static volatile DWORD cpu_sample_ticks=0;
static volatile DWORD cpu_sample_idle_ticks=0;
static volatile DWORD cpu_idle_per_mille=0;
static volatile DWORD cpu_busy_per_mille=0;
static volatile DWORD load_a_q16=0;
static volatile DWORD load_b_q16=0;
static volatile DWORD load_c_q16=0;
static volatile DWORD cpu_last_sample_ticks=0;
static volatile DWORD cpu_last_sample_idle_ticks=0;
/* V70.2: referenced by once-per-second telemetry before the full RRS
 * counter block later in this file. */
static volatile DWORD scheduler_context_switches=0;
static volatile DWORD scheduler_idle_halts=0;

/* Scheduler-side wall-clock cache used by diagnostics/rescue metadata. RTC I/O
 * stays in ordinary PIT/kernel context; vector 2 never touches CMOS in V69.38. */
static volatile DWORD scheduler_last_rtc_heartbeat=0;
static volatile DWORD scheduler_last_switch_rtc=0;
static volatile BYTE scheduler_rtc_heartbeat_valid=0;
static volatile BYTE scheduler_last_switch_rtc_valid=0;

/* Deadline sleeps are scheduler state, not polling loops. */
/* Absolute start tick + duration in the active scheduler clock domain. */
static volatile DWORD scheduler_sleep_start[N_MAX_THREADS];
static volatile DWORD scheduler_sleep_duration[N_MAX_THREADS];
static int scheduler_thread_sleeping(int pid);

static int scheduler_idle_slot(void)
{
    int idle;

    /* IdleThread is a zero-initialized global before init_IdleThread().
     * Do not accidentally treat bootstrap PID 0 as idle during early PIT
     * ticks just because PID 0 is also zero. */
    if(!IdleThread.pid || nr_threads <= 0)
        return -1;

    idle = IdleThread.pid;
    if(idle < 0 || idle >= nr_threads || !thread_states[idle])
        return -1;
    return idle;
}

static DWORD scheduler_count_threads(int runnable_only)
{
    int i;
    int idle;
    DWORD n=0;

    idle = scheduler_idle_slot();
    for(i=0; i<nr_threads; i++)
    {
        if(!thread_states[i])
            continue;
        if(i == idle)
            continue;
        if(runnable_only && (nmi_thread_suspended[i] || thread_idling[i] ||
                             scheduler_thread_sleeping(i) ||
                             JtSyncThreadBlocked(i)))
            continue;
        n++;
    }
    return n;
}

static DWORD scheduler_rtc_elapsed(DWORD now, DWORD then)
{
    DWORD d;

    if(now>=86400U || then>=86400U) return 0;
    d=(now>=then) ? (now-then) : (86400U-then+now);
    /* Ignore a large manual backwards RTC correction instead of reporting an
     * almost-24-hour uninterrupted run. */
    if(d>43200U) return 0;
    return d;
}

/* Fast-path flag for the old thread_idling[] compatibility delay.  The idle
 * steady state stays O(1); we scan the thread table only for the few PIT ticks
 * while a legacy SetToSleep() delay is actually outstanding. */
static volatile int scheduler_legacy_delay_pending=0;

/* V70: scheduler preemption clock may be faster than the PIT wall clock.
 * Zero means "use PIT IRQ rate".  All RRS quanta/aging remain wall-time based
 * by converting milliseconds through this abstraction. */
static volatile DWORD scheduler_clock_hz_override=0;

/* V70.2 performance policy and scheduler-time accounting.
 * FAST is the normal JTMOS mode. SLOW deliberately changes only scheduler
 * policy/maintenance cadence; it never changes GetTickCount()/PitGetUsec().
 * Per-thread budgets use scheduler ticks, so a 5% budget remains proportional
 * at both the PIT fallback rate and the rapid LAPIC rate. */
static volatile int scheduler_perf_mode=JTMOS_PERF_FAST;
static volatile DWORD scheduler_policy_ticks=0;
static DWORD scheduler_budget_percent[N_MAX_THREADS];
static DWORD scheduler_budget_window_ms[N_MAX_THREADS];
static DWORD scheduler_budget_window_start[N_MAX_THREADS];
static DWORD scheduler_budget_used_ticks[N_MAX_THREADS];
static DWORD scheduler_budget_throttle_count[N_MAX_THREADS];
static DWORD scheduler_cpu_ticks_accum[N_MAX_THREADS];
static DWORD scheduler_cpu_per_mille[N_MAX_THREADS];
static volatile DWORD scheduler_cpu_ticks_total=0;
static volatile DWORD scheduler_context_switches_per_sec=0;
static volatile DWORD scheduler_context_switches_sample_base=0;

DWORD SchedulerClockHz(void)
{
    DWORD hz=scheduler_clock_hz_override;
    if(!hz) hz=PitGetIrqHz();
    if(!hz) hz=1;
    return hz;
}

DWORD SchedulerMillisecondsToTicks(DWORD msec)
{
    DWORD hz=SchedulerClockHz();
    DWORD whole,rem,ticks,part;
    if(!msec) return 0;
    whole=msec/1000U;
    rem=msec%1000U;
    if(whole && hz>0xffffffffUL/whole) return 0xffffffffUL;
    ticks=whole*hz;
    part=(rem*hz + 999U)/1000U;
    if(0xffffffffUL-ticks<part) return 0xffffffffUL;
    ticks+=part;
    if(!ticks) ticks=1;
    return ticks;
}

/* V70.2 buildfix1: convert process-context sleeps to scheduler-clock ticks.
 *
 * The rapid LAPIC scheduler is deliberately independent from the legacy PIT
 * wall clock.  VirtualBox can continue delivering LAPIC timer interrupts even
 * when legacy IRQ0 is delayed or not routed as expected.  A scheduler sleep
 * must therefore never depend on PitGetUsec() making progress.  Round usec up
 * to milliseconds: the scheduler cannot represent a delay shorter than one
 * scheduler tick anyway (1 ms at 1 kHz, 4 ms on the 250 Hz PIT fallback). */
static DWORD scheduler_usec_to_ticks(DWORD usec)
{
    DWORD msec;
    if(!usec) return 0;
    msec=usec/1000U;
    if(usec%1000U) msec++;
    if(!msec) msec=1;
    return SchedulerMillisecondsToTicks(msec);
}

int SchedulerSetPerformanceMode(int mode)
{
    if(mode!=JTMOS_PERF_FAST && mode!=JTMOS_PERF_SLOW) return -1;
    scheduler_perf_mode=mode;
    return 0;
}

int SchedulerPerformanceMode(void)
{
    return scheduler_perf_mode;
}

const char *SchedulerPerformanceModeName(void)
{
    return scheduler_perf_mode==JTMOS_PERF_SLOW ? "SLOW" : "FAST";
}

static DWORD scheduler_budget_window_ticks_for(int pid)
{
    DWORD ticks;
    if(pid<0 || pid>=N_MAX_THREADS || !scheduler_budget_percent[pid]) return 0;
    ticks=SchedulerMillisecondsToTicks(scheduler_budget_window_ms[pid]);
    if(!ticks) ticks=1;
    return ticks;
}

static DWORD scheduler_budget_limit_ticks(int pid,DWORD window_ticks)
{
    DWORD percent,limit;
    if(pid<0 || pid>=N_MAX_THREADS || !window_ticks) return 0;
    percent=scheduler_budget_percent[pid];
    if(!percent) return 0;
    /* Floor is intentional: the budget must not exceed the requested CPU %.
     * Keep one tick minimum so low-frequency PIT fallback can still progress. */
    limit=(window_ticks*percent)/100U;
    if(!limit) limit=1;
    if(limit>window_ticks) limit=window_ticks;
    return limit;
}

static void scheduler_budget_refresh(int pid,DWORD now)
{
    DWORD window;
    if(pid<0 || pid>=N_MAX_THREADS || !scheduler_budget_percent[pid]) return;
    window=scheduler_budget_window_ticks_for(pid);
    if(!scheduler_budget_window_start[pid] ||
       (DWORD)(now-scheduler_budget_window_start[pid])>=window)
    {
        scheduler_budget_window_start[pid]=now;
        scheduler_budget_used_ticks[pid]=0;
    }
}

static int scheduler_thread_budget_throttled(int pid)
{
    DWORD window,limit;
    if(pid<0 || pid>=N_MAX_THREADS || !scheduler_budget_percent[pid]) return 0;
    scheduler_budget_refresh(pid,scheduler_policy_ticks);
    window=scheduler_budget_window_ticks_for(pid);
    limit=scheduler_budget_limit_ticks(pid,window);
    return limit && scheduler_budget_used_ticks[pid]>=limit;
}

int SchedulerSetThreadCpuBudget(int pid, DWORD percent, DWORD window_ms)
{
    DWORD flags;
    if(pid<=0 || pid>=N_MAX_THREADS || !thread_states[pid]) return -1;
    if(percent>100U) return -2;
    if(percent && (window_ms<20U || window_ms>10000U)) return -3;
    flags=get_eflags();
    disable();
    scheduler_budget_percent[pid]=percent;
    scheduler_budget_window_ms[pid]=percent ? window_ms : 0;
    scheduler_budget_window_start[pid]=scheduler_policy_ticks;
    scheduler_budget_used_ticks[pid]=0;
    set_eflags(flags);
    return 0;
}

void SchedulerClearThreadCpuBudget(int pid)
{
    DWORD flags;
    if(pid<0 || pid>=N_MAX_THREADS) return;
    flags=get_eflags();
    disable();
    scheduler_budget_percent[pid]=0;
    scheduler_budget_window_ms[pid]=0;
    scheduler_budget_window_start[pid]=0;
    scheduler_budget_used_ticks[pid]=0;
    set_eflags(flags);
}

DWORD SchedulerThreadCpuPerMille(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    return scheduler_cpu_per_mille[pid];
}

DWORD SchedulerContextSwitchesPerSecond(void)
{
    return scheduler_context_switches_per_sec;
}

int SchedulerGetThreadCpuBudgetStats(int pid, JTMOS_THREAD_BUDGET_STATS *out)
{
    DWORD window;
    if(!out || pid<0 || pid>=N_MAX_THREADS) return -1;
    memset(out,0,sizeof(*out));
    scheduler_budget_refresh(pid,scheduler_policy_ticks);
    window=scheduler_budget_window_ticks_for(pid);
    out->percent=scheduler_budget_percent[pid];
    out->window_ms=scheduler_budget_window_ms[pid];
    out->window_ticks=window;
    out->used_ticks=scheduler_budget_used_ticks[pid];
    out->throttle_count=scheduler_budget_throttle_count[pid];
    out->cpu_per_mille=scheduler_cpu_per_mille[pid];
    out->throttled=scheduler_thread_budget_throttled(pid)?1:0;
    return 0;
}

static DWORD scheduler_load_step(DWORD old_q16, DWORD active, DWORD beta_q16)
{
    long target;
    long delta;
    long step;
    long long product;

    if(active > N_MAX_THREADS)
        active = N_MAX_THREADS;

    target = (long)(active << 16);
    delta = target - (long)old_q16;
    product = (long long)delta * (long long)beta_q16;
    step = (long)(product >> 16);

    if((long)old_q16 + step < 0)
        return 0;
    return (DWORD)((long)old_q16 + step);
}

void SchedulerCpuTick(void)
{
    DWORD hz;
    DWORD runnable;
    int idle;
    int i;

    /* Legacy SetToSleep()/schedSleepSwitch() used to decrement thread_idling
     * only while SchedulerPickNext() happened to scan a task.  When CPU_IDLE
     * was selected and every real task had thread_idling!=0, no scan needed
     * to occur and those tasks could stay asleep indefinitely.  Age these
     * tiny compatibility delays from the always-running PIT clock instead.
     * The pending flag avoids an O(nthreads) scan on normal idle ticks. */
    if(scheduler_legacy_delay_pending) {
        int still_pending=0;
        for(i=0;i<nr_threads && i<N_MAX_THREADS;i++) {
            if(!thread_states[i] || !thread_idling[i]) continue;
            thread_idling[i]--;
            if(thread_idling[i]) still_pending=1;
        }
        scheduler_legacy_delay_pending=still_pending;
    }

    cpu_sample_ticks++;
    idle = scheduler_idle_slot();
    if(idle >= 0 && nr_curthread == idle)
        cpu_sample_idle_ticks++;

    if(!pit || !pit->secondInTicks)
        return;

    hz = pit->secondInTicks;
    if(cpu_sample_ticks < hz)
        return;

    cpu_last_sample_ticks = cpu_sample_ticks;
    cpu_last_sample_idle_ticks = cpu_sample_idle_ticks;

    /* V70.2: snapshot scheduler-clock runtime once per PIT second.  The
     * denominator is the number of actual scheduler clock samples, so this
     * remains proportional when rapid LAPIC is 1 kHz or PIT fallback is used. */
    if(scheduler_cpu_ticks_total)
    {
        for(i=0;i<nr_threads && i<N_MAX_THREADS;i++)
        {
            DWORD ticks=scheduler_cpu_ticks_accum[i];
            scheduler_cpu_per_mille[i]=(ticks*1000U)/scheduler_cpu_ticks_total;
            if(scheduler_cpu_per_mille[i]>1000U) scheduler_cpu_per_mille[i]=1000U;
            scheduler_cpu_ticks_accum[i]=0;
        }
    }
    else
    {
        for(i=0;i<nr_threads && i<N_MAX_THREADS;i++) scheduler_cpu_per_mille[i]=0;
    }
    scheduler_cpu_ticks_total=0;
    scheduler_context_switches_per_sec=
        (DWORD)(scheduler_context_switches-scheduler_context_switches_sample_base);
    scheduler_context_switches_sample_base=scheduler_context_switches;

    if(cpu_sample_ticks)
    {
        cpu_idle_per_mille = (cpu_sample_idle_ticks * 1000U) / cpu_sample_ticks;
        if(cpu_idle_per_mille > 1000U)
            cpu_idle_per_mille = 1000U;
        cpu_busy_per_mille = 1000U - cpu_idle_per_mille;
    }

    runnable = scheduler_count_threads(TRUE);
    load_a_q16 = scheduler_load_step(load_a_q16, runnable, LOAD_A_BETA_Q16);
    load_b_q16 = scheduler_load_step(load_b_q16, runnable, LOAD_B_BETA_Q16);
    load_c_q16 = scheduler_load_step(load_c_q16, runnable, LOAD_C_BETA_Q16);

    {
        DWORD rtc_second;
        if(rtc_getseconds_of_day_atomic(&rtc_second)==0)
        {
            scheduler_last_rtc_heartbeat=rtc_second;
            scheduler_rtc_heartbeat_valid=1;
            if(!scheduler_last_switch_rtc_valid)
            {
                scheduler_last_switch_rtc=rtc_second;
                scheduler_last_switch_rtc_valid=1;
            }

            /* Keep the user's requested per-thread RTC age live during normal
             * operation too, not only when an NMI samples a stalled CPU.  A
             * real context switch resets the new task to zero in
             * SchedulerOnSwitch(); this once-per-second update is deliberately
             * coarse so normal scheduling never performs CMOS I/O per switch. */
            if(nr_curthread>=0 && nr_curthread<nr_threads &&
               nr_curthread<N_MAX_THREADS && thread_states[nr_curthread])
                thread_rtc_seconds_without_task_switch[nr_curthread]=
                    scheduler_rtc_elapsed(rtc_second,scheduler_last_switch_rtc);
        }
    }

    cpu_sample_ticks = 0;
    cpu_sample_idle_ticks = 0;
}

int SchedulerGetCpuStats(JTMOS_CPU_STATS *out, DWORD out_size)
{
    JTMOS_CPU_STATS s;
    DWORD copy_size;

    if(!out || out_size == 0)
        return -1;

    memset(&s, 0, sizeof(s));
    s.version = JTMOS_CPU_STATS_VERSION;
    s.size = sizeof(s);
    s.hz = SchedulerClockHz();
    s.total_threads = scheduler_count_threads(FALSE);
    if(scheduler_idle_slot() >= 0)
        s.total_threads++; /* report CPU_IDLE too, like the process table does */
    s.runnable_threads = scheduler_count_threads(TRUE);
    s.idle_pid = (scheduler_idle_slot() >= 0) ? IdleThread.pid : 0;
    s.cpu_idle_per_mille = cpu_idle_per_mille;
    s.cpu_busy_per_mille = cpu_busy_per_mille;
    s.load_a_x1000 = (load_a_q16 >> 16) * 1000U + (((load_a_q16 & 0xffffU) * 1000U) >> 16);
    s.load_b_x1000 = (load_b_q16 >> 16) * 1000U + (((load_b_q16 & 0xffffU) * 1000U) >> 16);
    s.load_c_x1000 = (load_c_q16 >> 16) * 1000U + (((load_c_q16 & 0xffffU) * 1000U) >> 16);
    s.sample_ticks = cpu_last_sample_ticks;
    s.sample_idle_ticks = cpu_last_sample_idle_ticks;
    s.uptime_ms = GetTickCount();
    s.context_switches_per_sec = scheduler_context_switches_per_sec;
    s.idle_halts = scheduler_idle_halts;
    s.perf_mode = (DWORD)scheduler_perf_mode;

    copy_size = out_size;
    if(copy_size > sizeof(s))
        copy_size = sizeof(s);
    memcpy(out, &s, copy_size);
    return 0;
}

/* -------------------------------------------------------------------------
 * V67.8.54 responsive reward scheduler (RRS)
 *
 * The old JTMOS scheduler switched tasks on every PIT interrupt.  At the old
 * 0x100 divisor that meant about 4661 hardware task-switch opportunities per
 * second: only ~214 us of useful execution between IRQ0 entries.  RRS keeps
 * PIT as a time source but gives each task a real multi-tick quantum.
 *
 * Policy:
 *   level 0  interactive       short latency, short quantum
 *   level 1  normal            default
 *   level 2  background        lower dispatch preference, longer quantum
 *   level 3  batch             lowest preference, longest quantum
 *
 * A task that voluntarily yields early or completes block I/O is promoted
 * (bounded by its explicit base priority).  A task that consumes a complete
 * quantum is demoted.  Runnable waiters accrue aging credit, so even a batch
 * task cannot starve behind permanently interactive work.
 */
#define SCHED_LEVELS                 4
#define SCHED_LEVEL_INTERACTIVE      0
#define SCHED_LEVEL_NORMAL           1
#define SCHED_LEVEL_BACKGROUND       2
#define SCHED_LEVEL_BATCH            3
#define SCHED_AGE_WINDOWS_MAX        3

/* V68.156: express RRS quanta as milliseconds.  The PIT profile may be 250,
 * ~583 or 1000 Hz; converting at dispatch keeps the scheduling policy stable
 * in wall-clock time instead of silently changing it when IRQ0 is retuned. */
static const BYTE scheduler_quantum_ms[SCHED_LEVELS] = { 4, 7, 12, 20 };
static BYTE scheduler_initialized[N_MAX_THREADS];
static BYTE scheduler_level[N_MAX_THREADS];
static BYTE scheduler_quantum_left[N_MAX_THREADS];
static BYTE scheduler_run_ticks[N_MAX_THREADS];
static BYTE scheduler_empty_yield_streak[N_MAX_THREADS];
static WORD scheduler_wait_ticks[N_MAX_THREADS];

/* -------------------------------------------------------------------------
 * V68.154 syscall-aware lazy priority history.
 *
 * A deliberately small FIFO makes this a recent-behaviour signal, not a
 * permanent priority promotion.  Entries encode one of three syscall classes
 * plus an optional DIRTY bit.  Points are removed again when an old entry is
 * overwritten, so the score naturally decays without a timer walk.
 *
 * FAST is intentionally gated by a minimum count of CRITICAL calls.  A task
 * cannot obtain the long quantum merely by spamming normal/low-value syscalls.
 * DIRTY is only applied to repeated polling-style low-value calls. */
#define SCHED_SC_LOW              0U
#define SCHED_SC_NORMAL           1U
#define SCHED_SC_CRITICAL         2U
#define SCHED_SC_CLASS_MASK       3U
#define SCHED_SC_DIRTY            0x80U
#define SCHED_SC_FIFO_LEN         16U
#define SCHED_SC_FAST_CRIT_MIN    4U
#define SCHED_SC_FAST_SCORE_MIN   18
#define SCHED_SC_DIRTY_STREAK     4U
#define SCHED_SC_QUANTUM_MIN_MS   2U
#define SCHED_SC_QUANTUM_MAX_MS  32U

#define SCHED_LAZY_FAST           0U
#define SCHED_LAZY_NORMAL         1U
#define SCHED_LAZY_LOW            2U
#define SCHED_LAZY_DIRTY          3U

static BYTE scheduler_quantum_budget[N_MAX_THREADS];

void SchedulerSetClockHz(DWORD hz)
{
    DWORD flags=get_eflags();
    int i;
    disable();
    scheduler_clock_hz_override=hz;
    /* Quantums and waiter ages are measured in scheduler-clock ticks.  Do not
     * carry counters across a PIT<->LAPIC rate change with the old units. */
    for(i=0;i<N_MAX_THREADS;i++)
    {
        scheduler_quantum_left[i]=0;
        scheduler_quantum_budget[i]=0;
        scheduler_run_ticks[i]=0;
        scheduler_wait_ticks[i]=0;
        /* Sleep deadlines are expressed in scheduler-clock ticks.  A PIT ->
         * LAPIC (or LAPIC -> PIT) rate transition changes those units, so wake
         * existing process-context sleepers rather than carrying a stale
         * deadline into the new clock domain. */
        scheduler_sleep_start[i]=0;
        scheduler_sleep_duration[i]=0;
    }
    set_eflags(flags);
}
static BYTE scheduler_syscall_fifo[N_MAX_THREADS][SCHED_SC_FIFO_LEN];
static BYTE scheduler_syscall_head[N_MAX_THREADS];
static BYTE scheduler_syscall_count[N_MAX_THREADS];
static BYTE scheduler_syscall_critical[N_MAX_THREADS];
static BYTE scheduler_syscall_normal[N_MAX_THREADS];
static BYTE scheduler_syscall_low[N_MAX_THREADS];
static BYTE scheduler_syscall_dirty[N_MAX_THREADS];
static signed short scheduler_syscall_score[N_MAX_THREADS];
static WORD scheduler_syscall_last_nr[N_MAX_THREADS];
static BYTE scheduler_syscall_same_streak[N_MAX_THREADS];
static volatile DWORD scheduler_syscall_events=0;
static volatile DWORD scheduler_syscall_dirty_events=0;
static volatile DWORD scheduler_syscall_fast_qualifications=0;

/* V68.155 real-input activity boost.  Deadlines are absolute GetTickCount()
 * values so no O(n) decay pass is needed on every PIT interrupt.  A hint
 * changes dispatch preference only for a short bounded window; repeated
 * events extend that window but never reset/extend the current quantum. */
#define SCHED_ACTIVITY_KEYBOARD_MS 220U
#define SCHED_ACTIVITY_MOUSE_MS    140U
#define SCHED_ACTIVITY_NETWORK_MS  120U
#define SCHED_ACTIVITY_QADD_USER_MS 2U
#define SCHED_ACTIVITY_QADD_NET_MS  1U
static DWORD scheduler_activity_keyboard_until[N_MAX_THREADS];
static DWORD scheduler_activity_mouse_until[N_MAX_THREADS];
static DWORD scheduler_activity_network_until[N_MAX_THREADS];
static volatile DWORD scheduler_activity_keyboard_events=0;
static volatile DWORD scheduler_activity_mouse_events=0;
static volatile DWORD scheduler_activity_network_events=0;

static volatile DWORD scheduler_preemptions=0;
static volatile DWORD scheduler_voluntary_yields=0;
static volatile DWORD scheduler_promotions=0;
static volatile DWORD scheduler_demotions=0;
static volatile DWORD scheduler_io_rewards=0;
static volatile DWORD scheduler_empty_yields=0;
static volatile DWORD scheduler_timer_irqs=0;
static volatile DWORD scheduler_timer_same_task=0;
static volatile DWORD scheduler_timer_switches=0;
static volatile DWORD scheduler_yield_irqs=0;
static volatile DWORD scheduler_yield_switches=0;
static volatile DWORD scheduler_idle_rechecks=0;
static volatile DWORD scheduler_coop_requests=0;
static volatile DWORD scheduler_coop_yields=0;
static volatile DWORD scheduler_coop_suppressed=0;
static void scheduler_ensure_thread(int pid);

static int scheduler_deadline_active(DWORD deadline,DWORD now)
{
    return deadline!=0U && (long)(deadline-now)>0;
}

static BYTE scheduler_activity_mask(int pid)
{
    DWORD now;
    BYTE mask=0;
    if(!SCHEDULER_ACTIVITY_PRIORITY_ENABLED || pid<=0 || pid>=N_MAX_THREADS)
        return 0;
    now=GetTickCount();
    if(scheduler_deadline_active(scheduler_activity_keyboard_until[pid],now)) mask|=1U;
    if(scheduler_deadline_active(scheduler_activity_mouse_until[pid],now)) mask|=2U;
    if(SCHEDULER_NETWORK_PRIORITY_ENABLED &&
       scheduler_deadline_active(scheduler_activity_network_until[pid],now)) mask|=4U;
    return mask;
}

void SchedulerNoteActivity(int pid,int kind,int work_units)
{
    DWORD now,until,span;
    DWORD *slot=NULL;
    if(!SCHEDULER_ACTIVITY_PRIORITY_ENABLED || work_units<=0 ||
       pid<=0 || pid>=N_MAX_THREADS || !thread_states[pid]) return;
    if(kind==SCHED_ACTIVITY_NETWORK && !SCHEDULER_NETWORK_PRIORITY_ENABLED) return;

    switch(kind) {
    case SCHED_ACTIVITY_KEYBOARD:
        span=SCHED_ACTIVITY_KEYBOARD_MS; slot=&scheduler_activity_keyboard_until[pid];
        scheduler_activity_keyboard_events++; break;
    case SCHED_ACTIVITY_MOUSE:
        span=SCHED_ACTIVITY_MOUSE_MS; slot=&scheduler_activity_mouse_until[pid];
        scheduler_activity_mouse_events++; break;
    case SCHED_ACTIVITY_NETWORK:
        span=SCHED_ACTIVITY_NETWORK_MS; slot=&scheduler_activity_network_until[pid];
        scheduler_activity_network_events++; break;
    default:
        return;
    }
    /* A larger packet/burst may deserve a little more service time, but cap
     * the extension tightly so traffic cannot create a permanent boost. */
    if(work_units>1) {
        DWORD extra=(DWORD)(work_units>8?8:work_units-1)*8U;
        span+=extra;
    }
    now=GetTickCount();
    until=now+span;
    if(*slot==0U || !scheduler_deadline_active(*slot,now) ||
       (long)(until-*slot)>0) *slot=until;
}

static int scheduler_syscall_points(BYTE entry)
{
    int p=0;
    switch(entry&SCHED_SC_CLASS_MASK) {
    case SCHED_SC_CRITICAL: p=6; break;
    case SCHED_SC_NORMAL:   p=2; break;
    default:                p=0; break;
    }
    if(entry&SCHED_SC_DIRTY) p-=3;
    return p;
}

static BYTE scheduler_syscall_classify(int nr,int *dirty_eligible)
{
    if(dirty_eligible) *dirty_eligible=0;

    /* Class 1: operations where extra uninterrupted CPU time commonly turns
     * directly into useful I/O/IPC progress or interactive latency reduction. */
    switch(nr) {
    case SYS_GETCH:
    case SYS_wgetch:
    case SYS_open:
    case SYS_close:
    case SYS_read:
    case SYS_write:
    case SYS_cexec:
    case SYS_cexec_stdio:
    case SYS_readblock:
    case SYS_writeblock:
    case SYS_readblocks:
    case SYS_writeblocks:
    case SYS_waitprocterm:
    case SYS_sendmessage:
    case SYS_inputterminalkeyboardbuffer:
    case SYS_outputterminalkeyboardbuffer:
    case SYS_serialget:
    case SYS_serialput:
    case SYS_transmitrawpacket:
    case SYS_devicecall:
    case SYS_writesocket:
    case SYS_irqwait:
    case SYS_filebuf_read:
    case SYS_filebuf_write:
    case SYS_filebuf_flush:
    case SYS_resolvehost4:
        return SCHED_SC_CRITICAL;
    default:
        break;
    }

    /* Class 3: cheap status/polling/yield calls.  They are not harmful by
     * themselves.  Only a consecutive streak of selected calls is DIRTY. */
    switch(nr) {
    case SYS_IDLE:
    case SYS_GETTICKCOUNT:
    case SYS_GETCURRENTTHREAD:
    case SYS_WHEREX:
    case SYS_WHEREY:
    case SYS_getthreadpriority:
    case SYS_getthreadspending:
    case SYS_getthreadmemoryusage:
    case SYS_getthreadcount:
    case SYS_getctrl:
    case SYS_getalt:
    case SYS_getseconds:
    case SYS_inputmouse:
    case SYS_getcursorlocation:
    case SYS_switchtothread:
    case SYS_audioposition:
    case SYS_keystate:
    case SYS_receiverawpacket:
    case SYS_readsocket:
    case SYS_poll:
        if(dirty_eligible) {
            switch(nr) {
            case SYS_GETTICKCOUNT:
            case SYS_inputmouse:
            case SYS_getctrl:
            case SYS_getalt:
            case SYS_getseconds:
            case SYS_getcursorlocation:
            case SYS_switchtothread:
            case SYS_audioposition:
            case SYS_keystate:
            case SYS_receiverawpacket:
            case SYS_readsocket:
            case SYS_poll:
                *dirty_eligible=1;
                break;
            default:
                break;
            }
        }
        return SCHED_SC_LOW;
    default:
        break;
    }

    /* Class 2: metadata, memory management, process control, drawing and
     * configuration calls.  These receive a modest quantum benefit but never
     * qualify FAST mode without critical calls in the recent FIFO. */
    return SCHED_SC_NORMAL;
}

static void scheduler_syscall_remove_entry(int pid,BYTE entry)
{
    BYTE cls=entry&SCHED_SC_CLASS_MASK;
    scheduler_syscall_score[pid]-=(signed short)scheduler_syscall_points(entry);
    if(cls==SCHED_SC_CRITICAL) {
        if(scheduler_syscall_critical[pid]) scheduler_syscall_critical[pid]--;
    } else if(cls==SCHED_SC_NORMAL) {
        if(scheduler_syscall_normal[pid]) scheduler_syscall_normal[pid]--;
    } else {
        if(scheduler_syscall_low[pid]) scheduler_syscall_low[pid]--;
    }
    if((entry&SCHED_SC_DIRTY) && scheduler_syscall_dirty[pid])
        scheduler_syscall_dirty[pid]--;
}

static void scheduler_syscall_add_entry(int pid,BYTE entry)
{
    BYTE cls=entry&SCHED_SC_CLASS_MASK;
    scheduler_syscall_score[pid]+=(signed short)scheduler_syscall_points(entry);
    if(cls==SCHED_SC_CRITICAL) scheduler_syscall_critical[pid]++;
    else if(cls==SCHED_SC_NORMAL) scheduler_syscall_normal[pid]++;
    else scheduler_syscall_low[pid]++;
    if(entry&SCHED_SC_DIRTY) scheduler_syscall_dirty[pid]++;
}

static BYTE scheduler_lazy_band(int pid)
{
    if(!SYSCALL_LAZY_PRIORITY_ENABLED || pid<0 || pid>=N_MAX_THREADS)
        return SCHED_LAZY_NORMAL;

    if(scheduler_syscall_critical[pid]>=SCHED_SC_FAST_CRIT_MIN &&
       scheduler_syscall_score[pid]>=SCHED_SC_FAST_SCORE_MIN)
        return SCHED_LAZY_FAST;

    if(SYSCALL_DIRTY_CALLS_ENABLED && scheduler_syscall_dirty[pid]>=4U &&
       scheduler_syscall_score[pid]<0)
        return SCHED_LAZY_DIRTY;

    if(scheduler_syscall_count[pid]>=8U &&
       scheduler_syscall_critical[pid]==0U &&
       scheduler_syscall_normal[pid]<3U)
        return SCHED_LAZY_LOW;

    return SCHED_LAZY_NORMAL;
}

static BYTE scheduler_quantum_for(int pid)
{
    DWORD base_ms,q_ms,q_ticks;
    BYTE band;
    if(pid<0 || pid>=N_MAX_THREADS)
        return (BYTE)SchedulerMillisecondsToTicks(scheduler_quantum_ms[SCHED_LEVEL_NORMAL]);

    base_ms=scheduler_quantum_ms[scheduler_level[pid]];
    band=scheduler_lazy_band(pid);
    q_ms=base_ms;

    if(band==SCHED_LAZY_FAST) {
        DWORD add=base_ms/2U;
        if(add<1U) add=1U;
        q_ms=base_ms+add;
    } else if(band==SCHED_LAZY_NORMAL) {
        /* Normal useful syscall traffic earns one millisecond, independent of
         * the current PIT HZ. */
        if(scheduler_syscall_normal[pid]>=4U || scheduler_syscall_critical[pid]>0U)
            q_ms=base_ms+1U;
    } else if(band==SCHED_LAZY_LOW) {
        if(q_ms>SCHED_SC_QUANTUM_MIN_MS) q_ms--;
    } else { /* DIRTY */
        if(q_ms>SCHED_SC_QUANTUM_MIN_MS+1U) q_ms-=2U;
        else q_ms=SCHED_SC_QUANTUM_MIN_MS;
    }

    {
        BYTE activity=scheduler_activity_mask(pid);
        if(activity&(1U|2U)) q_ms+=SCHED_ACTIVITY_QADD_USER_MS;
        else if(activity&4U) q_ms+=SCHED_ACTIVITY_QADD_NET_MS;
    }

    /* Global SLOW is a debugging/low-noise policy: fewer task transfers and
     * longer coherent runs, while timer/wall-clock semantics stay unchanged. */
    if(scheduler_perf_mode==JTMOS_PERF_SLOW) q_ms*=2U;

    if(q_ms<SCHED_SC_QUANTUM_MIN_MS) q_ms=SCHED_SC_QUANTUM_MIN_MS;
    if(q_ms>SCHED_SC_QUANTUM_MAX_MS) q_ms=SCHED_SC_QUANTUM_MAX_MS;
    q_ticks=SchedulerMillisecondsToTicks(q_ms);
    if(q_ticks<1U) q_ticks=1U;
    if(q_ticks>255U) q_ticks=255U;
    return (BYTE)q_ticks;
}

void SchedulerAccountSyscall(int pid,int syscall_nr)
{
    BYTE cls,entry,head,old,oldband,newband;
    int dirty_eligible=0;

    if(!SYSCALL_LAZY_PRIORITY_ENABLED || pid<=0 || pid>=N_MAX_THREADS ||
       !thread_states[pid]) return;

    scheduler_ensure_thread(pid);
    oldband=scheduler_lazy_band(pid);
    cls=scheduler_syscall_classify(syscall_nr,&dirty_eligible);

    if((WORD)syscall_nr==scheduler_syscall_last_nr[pid]) {
        if(scheduler_syscall_same_streak[pid]<255U)
            scheduler_syscall_same_streak[pid]++;
    } else {
        scheduler_syscall_last_nr[pid]=(WORD)syscall_nr;
        scheduler_syscall_same_streak[pid]=1U;
    }

    entry=cls;
    if(SYSCALL_DIRTY_CALLS_ENABLED && dirty_eligible &&
       scheduler_syscall_same_streak[pid]>=SCHED_SC_DIRTY_STREAK) {
        entry|=SCHED_SC_DIRTY;
        scheduler_syscall_dirty_events++;
    }

    head=scheduler_syscall_head[pid];
    if(scheduler_syscall_count[pid]>=SCHED_SC_FIFO_LEN) {
        old=scheduler_syscall_fifo[pid][head];
        scheduler_syscall_remove_entry(pid,old);
    } else scheduler_syscall_count[pid]++;

    scheduler_syscall_fifo[pid][head]=entry;
    scheduler_syscall_add_entry(pid,entry);
    head++;
    if(head>=SCHED_SC_FIFO_LEN) head=0;
    scheduler_syscall_head[pid]=head;
    scheduler_syscall_events++;

    newband=scheduler_lazy_band(pid);
    if(oldband!=SCHED_LAZY_FAST && newband==SCHED_LAZY_FAST)
        scheduler_syscall_fast_qualifications++;
}

static BYTE scheduler_priority_floor(BYTE prio)
{
    if(prio<=THREAD_PRIORITY_NORMAL) return SCHED_LEVEL_INTERACTIVE;
    if(prio<=THREAD_PRIORITY_BELOW_NORMAL) return SCHED_LEVEL_NORMAL;
    if(prio<=THREAD_PRIORITY_IDLE) return SCHED_LEVEL_BACKGROUND;
    return SCHED_LEVEL_BATCH;
}

static BYTE scheduler_initial_level(BYTE prio)
{
    BYTE floor=scheduler_priority_floor(prio);
    if(floor<SCHED_LEVEL_BATCH) return (BYTE)(floor+1);
    return SCHED_LEVEL_BATCH;
}

static DWORD scheduler_age_window_ticks(void)
{
    DWORD hz=SchedulerClockHz();
    DWORD ticks=hz/25U; /* about 40 ms */
    if(ticks<1U) ticks=1U;
    if(ticks>0xffffU) ticks=0xffffU;
    return ticks;
}

static int scheduler_thread_sleeping(int pid)
{
    DWORD duration;
    DWORD elapsed;

    if(pid<0 || pid>=N_MAX_THREADS) return 0;
    duration=scheduler_sleep_duration[pid];
    if(!duration) return 0;
    /* scheduler_sleep_* are scheduler-clock units, not PIT microseconds.
     * This keeps timed waits alive when rapid LAPIC is the active scheduler
     * clock and prevents VirtualBox-specific PIT routing from stranding a
     * sleeping SQSH or filesystem/driver waiter forever. */
    elapsed=(DWORD)(scheduler_policy_ticks-scheduler_sleep_start[pid]);
    if(elapsed>=duration) {
        scheduler_sleep_duration[pid]=0;
        scheduler_sleep_start[pid]=0;
        return 0;
    }
    return 1;
}

static void scheduler_ensure_thread(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return;
    if(scheduler_initialized[pid]) return;
    scheduler_initialized[pid]=1;
    scheduler_level[pid]=scheduler_initial_level(thread_states[pid]);
    scheduler_quantum_left[pid]=0;
    scheduler_quantum_budget[pid]=0;
    scheduler_run_ticks[pid]=0;
    scheduler_empty_yield_streak[pid]=0;
    scheduler_wait_ticks[pid]=0;
}

static BYTE scheduler_effective_level(int pid)
{
    DWORD win;
    DWORD boost;
    BYTE level;
    BYTE floor;
    BYTE band;

    scheduler_ensure_thread(pid);
    level=scheduler_level[pid];
    floor=scheduler_priority_floor(thread_states[pid]);
    band=scheduler_lazy_band(pid);

    /* Syscall history is a soft latency hint only.  FAST can improve one
     * dynamic level, but never beyond the explicit base-priority floor.
     * DIRTY/LOW can make a task one class lazier; aging below still prevents
     * starvation. */
    if(band==SCHED_LAZY_FAST) {
        if(level>floor) level--;
    } else if(band==SCHED_LAZY_DIRTY || band==SCHED_LAZY_LOW) {
        if(level<SCHED_LEVEL_BATCH) level++;
    }

    /* Real input outranks inferred syscall behaviour.  Keyboard/mouse may
     * improve up to two dynamic levels; freshly received network data improves
     * one.  The explicit priority floor remains authoritative. */
    {
        BYTE activity=scheduler_activity_mask(pid);
        BYTE ab=(activity&(1U|2U))?2U:((activity&4U)?1U:0U);
        while(ab && level>floor) { level--; ab--; }
    }

    win=scheduler_age_window_ticks();
    boost=(win ? ((DWORD)scheduler_wait_ticks[pid]/win) : 0U);
    if(boost>SCHED_AGE_WINDOWS_MAX) boost=SCHED_AGE_WINDOWS_MAX;
    if(boost>level) boost=level;
    return (BYTE)(level-boost);
}

static int scheduler_runnable_nonidle_exists(void)
{
    int i,idle=scheduler_idle_slot();
    for(i=0;i<nr_threads;i++) {
        if(i==idle) continue;
        if(thread_states[i] && !nmi_thread_suspended[i] && !thread_idling[i] &&
           !scheduler_thread_sleeping(i) && !JtSyncThreadBlocked(i) &&
           !scheduler_thread_budget_throttled(i)) return 1;
    }
    return 0;
}

static int scheduler_more_urgent_waiter(int current)
{
    int i,idle=scheduler_idle_slot();
    BYTE clevel=scheduler_effective_level(current);
    for(i=0;i<nr_threads;i++) {
        if(i==current || i==idle || !thread_states[i] || nmi_thread_suspended[i] ||
           thread_idling[i] || scheduler_thread_sleeping(i) ||
           JtSyncThreadBlocked(i) || scheduler_thread_budget_throttled(i)) continue;
        if(scheduler_wait_ticks[i]<3) continue;
        if(scheduler_effective_level(i)+1U < clevel) return 1;
    }
    return 0;
}

void SchedulerThreadInit(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return;
    JtSyncThreadInit(pid);
    NmiWatchdogResetThread(pid);
    scheduler_initialized[pid]=0;
    scheduler_level[pid]=SCHED_LEVEL_NORMAL;
    scheduler_quantum_left[pid]=0;
    scheduler_quantum_budget[pid]=0;
    scheduler_run_ticks[pid]=0;
    scheduler_empty_yield_streak[pid]=0;
    scheduler_wait_ticks[pid]=0;
    scheduler_sleep_start[pid]=0;
    scheduler_sleep_duration[pid]=0;
    scheduler_budget_percent[pid]=0;
    scheduler_budget_window_ms[pid]=0;
    scheduler_budget_window_start[pid]=0;
    scheduler_budget_used_ticks[pid]=0;
    scheduler_budget_throttle_count[pid]=0;
    scheduler_cpu_ticks_accum[pid]=0;
    scheduler_cpu_per_mille[pid]=0;
    memset(scheduler_syscall_fifo[pid],0,SCHED_SC_FIFO_LEN);
    scheduler_syscall_head[pid]=0;
    scheduler_syscall_count[pid]=0;
    scheduler_syscall_critical[pid]=0;
    scheduler_syscall_normal[pid]=0;
    scheduler_syscall_low[pid]=0;
    scheduler_syscall_dirty[pid]=0;
    scheduler_syscall_score[pid]=0;
    scheduler_syscall_last_nr[pid]=0xffffU;
    scheduler_syscall_same_streak[pid]=0;
    scheduler_activity_keyboard_until[pid]=0;
    scheduler_activity_mouse_until[pid]=0;
    scheduler_activity_network_until[pid]=0;
    scheduler_ensure_thread(pid);
}

void SchedulerPriorityChanged(int pid, BYTE prio)
{
    BYTE floor;
    if(pid<0 || pid>=N_MAX_THREADS) return;
    if(prio==0) {
        nmi_thread_suspended[pid]=0;
        thread_rtc_seconds_without_task_switch[pid]=0;
        scheduler_initialized[pid]=0;
        scheduler_quantum_left[pid]=0;
        scheduler_quantum_budget[pid]=0;
        scheduler_run_ticks[pid]=0;
        scheduler_empty_yield_streak[pid]=0;
        scheduler_wait_ticks[pid]=0;
        scheduler_sleep_start[pid]=0;
        scheduler_sleep_duration[pid]=0;
        scheduler_budget_percent[pid]=0;
        scheduler_budget_window_ms[pid]=0;
        scheduler_budget_window_start[pid]=0;
        scheduler_budget_used_ticks[pid]=0;
        scheduler_cpu_ticks_accum[pid]=0;
        scheduler_cpu_per_mille[pid]=0;
        memset(scheduler_syscall_fifo[pid],0,SCHED_SC_FIFO_LEN);
        scheduler_syscall_head[pid]=0;
        scheduler_syscall_count[pid]=0;
        scheduler_syscall_critical[pid]=0;
        scheduler_syscall_normal[pid]=0;
        scheduler_syscall_low[pid]=0;
        scheduler_syscall_dirty[pid]=0;
        scheduler_syscall_score[pid]=0;
        scheduler_syscall_last_nr[pid]=0xffffU;
        scheduler_syscall_same_streak[pid]=0;
        scheduler_activity_keyboard_until[pid]=0;
        scheduler_activity_mouse_until[pid]=0;
        scheduler_activity_network_until[pid]=0;
        return;
    }
    scheduler_ensure_thread(pid);
    floor=scheduler_priority_floor(prio);
    scheduler_level[pid]=scheduler_initial_level(prio);
    if(scheduler_level[pid]<floor) scheduler_level[pid]=floor;
    scheduler_quantum_left[pid]=0;
    scheduler_quantum_budget[pid]=0;
    scheduler_run_ticks[pid]=0;
    scheduler_empty_yield_streak[pid]=0;
}

void SchedulerOnVoluntaryYield(int pid)
{
    BYTE q,left,used,floor;
    int idle=scheduler_idle_slot();
    if(pid<0 || pid>=nr_threads || pid==idle || !thread_states[pid]) return;
    scheduler_ensure_thread(pid);
    scheduler_voluntary_yields++;
    if(scheduler_sleep_duration[pid]) {
        scheduler_quantum_left[pid]=0;
        scheduler_quantum_budget[pid]=0;
        scheduler_run_ticks[pid]=0;
        return;
    }
    q=scheduler_quantum_budget[pid];
    if(!q) q=scheduler_quantum_for(pid);
    left=scheduler_quantum_left[pid];
    if(left==0 || left>q) left=q;
    used=(BYTE)(q-left);
    floor=scheduler_priority_floor(thread_states[pid]);

    /* A zero-tick yield loop is not useful interactive work.  Do not let a
     * process game the reward policy by repeatedly calling SwitchToThread()
     * without doing anything between calls.  Four consecutive empty yields
     * move it one latency class toward batch operation. */
    if(used==0) {
        scheduler_empty_yields++;
        if(scheduler_empty_yield_streak[pid]<255)
            scheduler_empty_yield_streak[pid]++;
        if(scheduler_empty_yield_streak[pid]>=4) {
            scheduler_empty_yield_streak[pid]=0;
            if(scheduler_level[pid]<SCHED_LEVEL_BATCH) {
                scheduler_level[pid]++;
                scheduler_demotions++;
            }
        }
    } else {
        scheduler_empty_yield_streak[pid]=0;
        if(used<=(BYTE)(q/2) && scheduler_level[pid]>floor) {
            scheduler_level[pid]--;
            scheduler_promotions++;
        }
    }
    /* A voluntary hand-off ends the current burst.  Start a fresh quantum
     * when this task is dispatched again. */
    scheduler_quantum_left[pid]=0;
    scheduler_quantum_budget[pid]=0;
    scheduler_run_ticks[pid]=0;
}

void SchedulerRewardIO(int pid, int work_units)
{
    BYTE floor;
    int idle=scheduler_idle_slot();
    if(work_units<=0 || pid<0 || pid>=nr_threads || pid==idle || !thread_states[pid]) return;
    scheduler_ensure_thread(pid);
    scheduler_io_rewards++;
    scheduler_empty_yield_streak[pid]=0;
    floor=scheduler_priority_floor(thread_states[pid]);
    if(scheduler_level[pid]>floor) {
        scheduler_level[pid]--;
        scheduler_promotions++;
    }
}

int SchedulerSleepCurrentUsec(DWORD usec)
{
    int pid;
    BYTE floor;
    DWORD sleep_ticks;

    if(usec==0) { SwitchToThread(); return 0; }
    if(!Multitasking) return -1;
    pid=nr_curthread;
    if(pid<0 || pid>=nr_threads || !thread_states[pid]) return -1;
    scheduler_ensure_thread(pid);
    sleep_ticks=scheduler_usec_to_ticks(usec);
    if(!sleep_ticks) sleep_ticks=1;
    scheduler_sleep_start[pid]=scheduler_policy_ticks;
    scheduler_sleep_duration[pid]=sleep_ticks;
    scheduler_empty_yield_streak[pid]=0;

    /* Blocking before the end of a quantum is useful cooperative behaviour. */
    floor=scheduler_priority_floor(thread_states[pid]);
    if(scheduler_level[pid]>floor) {
        scheduler_level[pid]--;
        scheduler_promotions++;
    }
    scheduler_quantum_left[pid]=0;
    scheduler_quantum_budget[pid]=0;
    scheduler_run_ticks[pid]=0;

    /* The scheduler will not select this PID again until the deadline expires
     * or an explicit SchedulerWakeThread()/SwitchToThreadEx() occurs. */
    while(scheduler_thread_sleeping(pid)) SwitchToThread();
    return 0;
}

/* V68.171: generic low-duty-cycle wait primitive for process-context loops.
 *
 * SwitchToThread() is only a yield.  If the caller is still runnable and no
 * better peer exists, the scheduler may select it again immediately.  A loop
 * that waits for an external condition must therefore sleep, not merely yield,
 * or it can prevent CPU_IDLE from reaching sti;hlt and burn a complete QEMU
 * host CPU.  Do not turn a true IF=0 critical section into a sleeping one: in
 * that case retain the historical cooperative yield/fail-safe behaviour. */
void SchedulerWaitPause(DWORD usec)
{
    DWORD flags;
    if(usec==0U) { SwitchToThread(); return; }
    flags=get_eflags();
    if(Multitasking && !PitStorageSafeActive() && (flags&0x200UL))
    {
        if(SchedulerSleepCurrentUsec(usec)==0) return;
    }
    SwitchToThread();
}

/* V68.174: cheap cooperative preemption point for CPU/IO work loops.
 *
 * Unlike SchedulerWaitPause(), this does not put the task to sleep.  It simply
 * gives another runnable task an immediate opportunity after a bounded amount
 * of useful work.  Callers must place this only at state-consistent boundaries
 * where a voluntary task switch is safe.  In particular, never manufacture
 * IF=1 and never switch during storage-safe boot.
 */
int SchedulerCanCooperate(void)
{
    DWORD flags;
    if(!systemStarted || !Multitasking || PitStorageSafeActive()) return 0;
    flags=get_eflags();
    return (flags&0x200UL) ? 1 : 0;
}

void SchedulerCooperate(void)
{
    scheduler_coop_requests++;
    if(SchedulerCanCooperate())
    {
        scheduler_coop_yields++;
        SwitchToThread();
    }
    else
        scheduler_coop_suppressed++;
}

void SchedulerCooperateEvery(DWORD iteration,DWORD interval)
{
    if(interval==0U || iteration==0U) return;
    if((iteration%interval)==0U)
        SchedulerCooperate();
}

void SchedulerSetLegacyDelay(int pid,int ticks)
{
    if(pid<0 || pid>=N_MAX_THREADS) return;
    if(ticks<0) ticks=0;
    if(ticks>255) ticks=255;
    thread_idling[pid]=(BYTE)ticks;
    if(ticks) scheduler_legacy_delay_pending=1;
}

void SchedulerWakeThread(int pid)
{
    if(pid<0 || pid>=N_MAX_THREADS) return;
    scheduler_sleep_duration[pid]=0;
    scheduler_sleep_start[pid]=0;
    scheduler_wait_ticks[pid]=0;
}

int SchedulerTimerShouldPreempt(void)
{
    int i,current,idle;
    DWORD agewin,agemax;
    BYTE q;

    if(!Multitasking) return 0;
    current=nr_curthread;
    idle=scheduler_idle_slot();

    /* One call corresponds to one scheduler-clock tick (PIT fallback or
     * rapid LAPIC). Account it before the idle fast path. */
    scheduler_policy_ticks++;
    scheduler_cpu_ticks_total++;
    if(current>=0 && current<nr_threads && current<N_MAX_THREADS && thread_states[current])
    {
        DWORD window,limit,before;
        scheduler_cpu_ticks_accum[current]++;
        if(current!=idle && scheduler_budget_percent[current])
        {
            scheduler_budget_refresh(current,scheduler_policy_ticks);
            window=scheduler_budget_window_ticks_for(current);
            limit=scheduler_budget_limit_ticks(current,window);
            before=scheduler_budget_used_ticks[current];
            if(before<0xffffffffUL) scheduler_budget_used_ticks[current]=before+1U;
            if(limit && before<limit && scheduler_budget_used_ticks[current]>=limit)
                scheduler_budget_throttle_count[current]++;
        }
    }

    /* CPU_IDLE is the overwhelmingly common steady-state path.  Do not walk
     * every process and update aging counters at PIT frequency while the CPU
     * is halted.  If a real task became runnable, the cheap runnable scan
     * below immediately asks the scheduler to leave idle; normal aging then
     * resumes on real-task ticks.  This removes a surprisingly expensive
     * O(nthreads) operation from every idle IRQ0 in QEMU. */
    if(current==idle) return scheduler_runnable_nonidle_exists();
    if(current>=0 && current<nr_threads && nmi_thread_suspended[current]) return 1;
    if(current>=0 && current<nr_threads && JtSyncThreadBlocked(current)) return 1;

    agewin=scheduler_age_window_ticks();
    agemax=agewin*SCHED_AGE_WINDOWS_MAX;
    if(agemax>0xffffU) agemax=0xffffU;
    for(i=0;i<nr_threads;i++) {
        if(i==current || i==idle || !thread_states[i] || nmi_thread_suspended[i] ||
           thread_idling[i] || scheduler_thread_sleeping(i) ||
           JtSyncThreadBlocked(i) || scheduler_thread_budget_throttled(i)) continue;
        if((DWORD)scheduler_wait_ticks[i]<agemax) scheduler_wait_ticks[i]++;
    }
    if(current<0 || current>=nr_threads || !thread_states[current]) return 1;
    if(scheduler_thread_sleeping(current) || JtSyncThreadBlocked(current)) return 1;
    if(scheduler_thread_budget_throttled(current)) {
        scheduler_preemptions++;
        return 1;
    }

    scheduler_ensure_thread(current);
    if(!scheduler_quantum_left[current]) {
        q=scheduler_quantum_for(current);
        scheduler_quantum_budget[current]=q;
        scheduler_quantum_left[current]=q;
    } else {
        q=scheduler_quantum_budget[current];
        if(!q) q=scheduler_quantum_for(current);
    }
    if(scheduler_quantum_left[current]) scheduler_quantum_left[current]--;
    if(scheduler_run_ticks[current]<255) scheduler_run_ticks[current]++;

    if(!scheduler_quantum_left[current]) {
        if(scheduler_level[current]<SCHED_LEVEL_BATCH) {
            scheduler_level[current]++;
            scheduler_demotions++;
        }
        scheduler_run_ticks[current]=0;
        scheduler_quantum_budget[current]=0;
        scheduler_empty_yield_streak[current]=0;
        scheduler_preemptions++;
        return 1;
    }

    /* Do not make a latency-sensitive waiter sit behind a long batch slice.
     * Still allow at least two scheduler-clock ticks of useful work before early preempt. */
    if(scheduler_run_ticks[current]>=2 && scheduler_more_urgent_waiter(current)) {
        scheduler_preemptions++;
        return 1;
    }
    return 0;
}

int SchedulerPickNext(int current)
{
    int offset,pid,best=-1,idle;
    BYTE eff,best_eff=0xff;

    idle=scheduler_idle_slot();
    if(nr_threads<=0) return 0;
    for(offset=1;offset<nr_threads;offset++) {
        pid=current+offset;
        while(pid>=nr_threads) pid-=nr_threads;
        if(pid==idle || !thread_states[pid] || nmi_thread_suspended[pid] ||
           scheduler_thread_sleeping(pid) || JtSyncThreadBlocked(pid) ||
           scheduler_thread_budget_throttled(pid)) continue;
        if(thread_idling[pid]) continue;
        eff=scheduler_effective_level(pid);
        if(best<0 || eff<best_eff) {
            best=pid;
            best_eff=eff;
            if(best_eff==SCHED_LEVEL_INTERACTIVE) {
                /* Keep scanning only for round-robin fairness among equal
                 * level-zero tasks; the first encountered wins ties. */
            }
        }
    }

    if(best<0) {
        if(current>=0 && current<nr_threads && current!=idle &&
           thread_states[current] && !nmi_thread_suspended[current] &&
           !thread_idling[current] && !scheduler_thread_sleeping(current) &&
           !JtSyncThreadBlocked(current) &&
           !scheduler_thread_budget_throttled(current)) best=current;
        else if(idle>=0 && idle<nr_threads && thread_states[idle]) best=idle;
        else if(current>=0 && current<nr_threads && thread_states[current] &&
                !nmi_thread_suspended[current] &&
                !JtSyncThreadBlocked(current)) best=current;
        else best=0;
    }

    if(best>=0 && best<nr_threads) {
        scheduler_ensure_thread(best);
        scheduler_wait_ticks[best]=0;
        if(best!=idle && !scheduler_quantum_left[best]) {
            scheduler_quantum_budget[best]=scheduler_quantum_for(best);
            scheduler_quantum_left[best]=scheduler_quantum_budget[best];
        }
    }
    return best;
}

void SchedulerOnSwitch(int old_pid, int new_pid)
{
    if(old_pid!=new_pid)
    {
        /* Published once per real context change, including voluntary yield.
         * The NMI reads only this scalar and the PIT-maintained uptime. */
        thread_lastsec=SchedulerWatchdogSeconds();
        NmiPeriodicSourceTaskSwitchHeartbeat();
        CrashAnalysisTraceSwitch(old_pid,new_pid);
        scheduler_context_switches++;
        if(scheduler_rtc_heartbeat_valid)
        {
            scheduler_last_switch_rtc=scheduler_last_rtc_heartbeat;
            scheduler_last_switch_rtc_valid=1;
        }
        if(new_pid>=0 && new_pid<N_MAX_THREADS)
            thread_rtc_seconds_without_task_switch[new_pid]=0;
    }
    if(new_pid>=0 && new_pid<nr_threads) scheduler_wait_ticks[new_pid]=0;
}

DWORD SchedulerWatchdogSeconds(void)
{
    return GetTickCount()/1000U;
}

int SchedulerGetWatchdogSnapshot(JTMOS_SCHED_WATCHDOG *out)
{
    if(!out) return -1;
    out->timer_irqs=scheduler_timer_irqs;
    out->context_switches=scheduler_context_switches;
    out->rtc_heartbeat=scheduler_last_rtc_heartbeat;
    out->last_switch_rtc=scheduler_last_switch_rtc;
    out->rtc_heartbeat_valid=scheduler_rtc_heartbeat_valid;
    out->last_switch_rtc_valid=scheduler_last_switch_rtc_valid;
    return 0;
}

void SchedulerDump(void)
{
    int i,idle=scheduler_idle_slot();
    printk("RRS scheduler: mode=%s clock=%u Hz PIT-timebase=%u Hz switches=%u (%u/s) preempt=%u yields=%u empty=%u promote=%u demote=%u io-reward=%u\n",
           SchedulerPerformanceModeName(),(unsigned)SchedulerClockHz(),(unsigned)PitGetIrqHz(),
           (unsigned)scheduler_context_switches,(unsigned)scheduler_context_switches_per_sec,
           (unsigned)scheduler_preemptions,(unsigned)scheduler_voluntary_yields,
           (unsigned)scheduler_empty_yields,(unsigned)scheduler_promotions,
           (unsigned)scheduler_demotions,(unsigned)scheduler_io_rewards);
    printk(" policy: FAST=low-latency, SLOW=debug/low-noise; idle always STI;HLT; budget clock=%u\n",
           (unsigned)scheduler_policy_ticks);
    printk(" IRQ-gate: timer=%u same=%u switch=%u yield=%u yswitch=%u idle-hlt=%u recheck=%u\n",
           (unsigned)scheduler_timer_irqs,(unsigned)scheduler_timer_same_task,
           (unsigned)scheduler_timer_switches,(unsigned)scheduler_yield_irqs,
           (unsigned)scheduler_yield_switches,(unsigned)scheduler_idle_halts,
           (unsigned)scheduler_idle_rechecks);
    printk(" cooperative: requests=%u yields=%u suppressed=%u (IF0/boot/storage-safe)\n",
           (unsigned)scheduler_coop_requests,(unsigned)scheduler_coop_yields,
           (unsigned)scheduler_coop_suppressed);
    printk(" syscall-lazy: enabled=%d dirty=%d events=%u dirty-events=%u fast-enter=%u FIFO=%u crit-min=%u\n",
           SYSCALL_LAZY_PRIORITY_ENABLED,SYSCALL_DIRTY_CALLS_ENABLED,
           (unsigned)scheduler_syscall_events,(unsigned)scheduler_syscall_dirty_events,
           (unsigned)scheduler_syscall_fast_qualifications,(unsigned)SCHED_SC_FIFO_LEN,
           (unsigned)SCHED_SC_FAST_CRIT_MIN);
    printk(" activity: enabled=%d net=%d keyboard=%u mouse=%u network=%u windows=%u/%u/%u ms\n",
           SCHEDULER_ACTIVITY_PRIORITY_ENABLED,SCHEDULER_NETWORK_PRIORITY_ENABLED,
           (unsigned)scheduler_activity_keyboard_events,(unsigned)scheduler_activity_mouse_events,
           (unsigned)scheduler_activity_network_events,(unsigned)SCHED_ACTIVITY_KEYBOARD_MS,
           (unsigned)SCHED_ACTIVITY_MOUSE_MS,(unsigned)SCHED_ACTIVITY_NETWORK_MS);
    printk(" PID base lvl eff q/qb wait score C N L D lazy act cpu cpu/1000 budget name\n");
    for(i=0;i<nr_threads;i++) {
        char name[128];
        if(!thread_states[i]) continue;
        GetThreadName(i,name);
        {
            static const char lazyname[4]={'F','N','L','D'};
            BYTE band=scheduler_lazy_band(i);
            BYTE activity=scheduler_activity_mask(i);
            char act[4]; int ai=0;
            if(activity&1U) act[ai++]='K';
            if(activity&2U) act[ai++]='M';
            if(activity&4U) act[ai++]='N';
            if(!ai) act[ai++]='-';
            act[ai]=0;
            printk(" %3d %4u %3u %3u %2u/%2u %4u %5d %u %u %u %u %c %s %u %3u %2u%% %s%s%s%s%s\n", i,
                   (unsigned)thread_states[i],(unsigned)scheduler_level[i],
                   (unsigned)scheduler_effective_level(i),
                   (unsigned)scheduler_quantum_left[i],(unsigned)scheduler_quantum_budget[i],
                   (unsigned)scheduler_wait_ticks[i],(int)scheduler_syscall_score[i],
                   (unsigned)scheduler_syscall_critical[i],(unsigned)scheduler_syscall_normal[i],
                   (unsigned)scheduler_syscall_low[i],(unsigned)scheduler_syscall_dirty[i],
                   lazyname[(band<4U)?band:SCHED_LAZY_NORMAL],act,
                   (unsigned)thread_CPUspending[i],
                   (unsigned)scheduler_cpu_per_mille[i],
                   (unsigned)scheduler_budget_percent[i],name,(i==idle)?" [idle]":"",
                   scheduler_thread_sleeping(i)?" [sleep]":"",
                   JtSyncThreadBlocked(i)?" [sync]":"",
                   scheduler_thread_budget_throttled(i)?" [throttle]":"");
        }
    }
}

//--------------------------------------------------------------------------------
// Calls int 0x7E.
//
void _idle_moment(void)
{
	//
	if(scallsIsWorking && Multitasking)
		asm("int $0x7E");
}

//--------------------------------------------------------------------------------
//
// 0x8000 0000 = will have the application memory space, if any.
//
void MapApplicationMemory(void)
{
    DWORD *pd;
    BYTE *process_page_tables;
    DWORD ad;
    DWORD cr3;
    int i;

    /* Every PID owns four 4 KiB page tables covering the 16 MiB
     * 0x80000000..0x80ffffff Ring-3 window.  The kernel shares one CR3 and
     * switches only PDEs 512..515, so changing those PDEs MUST be followed
     * by an explicit CR3 reload.  Relying on the subsequent hardware task
     * switch to notice same-CR3 paging-structure changes leaves stale TLB /
     * paging-structure-cache entries on real CPUs and caused valid GraOS
     * text addresses (for example 0x800155c8) to #PF. */
    if(nr_curthread < 0 || nr_curthread >= N_MAX_THREADS)
        return;

    pd = (DWORD *)GetKernelPageDirPTR();
    if(pd == NULL)
        return;

    process_page_tables = (BYTE *)PG_USER_PAGE_TABLES_PHYS +
                          ((DWORD)nr_curthread * MM_PROCESS_PAGE_TABLE_BYTES);

    for(i=0; i<4; ++i)
    {
        ad = (DWORD)(process_page_tables + ((DWORD)i * PAGESIZE));
        pd[512+i] = ad | 7U; /* present + writable + ring-3 user */
    }

    /* Intel requires translation invalidation after paging-structure
     * modification.  All JTMOS processes intentionally use the same page
     * directory physical address, therefore reload even when CR3's numeric
     * value does not change.  Non-global Ring-3 translations are flushed. */
    asm volatile("mov %%cr3,%0" : "=r"(cr3));
    asm volatile("mov %0,%%cr3" : : "r"(cr3) : "memory");
}

//--------------------------------------------------------------------------------
/* V68.121 interrupt-gate scheduler. The interrupted task stays current while
 * the ISR accounts the tick and selects work. A far TSS JMP is done only when
 * the PID actually changes, avoiding the old current->scheduler->task pair of
 * hardware task switches on every PIT tick. */
static int SchedulerDirectTaskSwitch(int old_pid)
{
    int new_pid;
    int sel;

    new_pid=nr_curthread;
    if(new_pid==old_pid) return 0;
    if(new_pid<0 || new_pid>=nr_threads || !thread_states[new_pid] ||
       nmi_thread_suspended[new_pid] || JtSyncThreadBlocked(new_pid))
    {
        nr_curthread=old_pid;
        return 0;
    }

    /* The first post-storage IRQ0 switch is exactly where corrupted boot TSS
     * state used to become executable.  Trace the first few transfers, then
     * keep only failure diagnostics. */
    if(scheduler_switch_trace_budget)
    {
        scheduler_debug_dump_task("switch-target",new_pid,TRUE);
        scheduler_switch_trace_budget--;
    }
    if(!scheduler_validate_switch_target(old_pid,new_pid,
                                         "BAD switch-target"))
        return 0;

    taskSwitchNr++;
    SchedulerOnSwitch(old_pid,new_pid);
    MapApplicationMemory();
    sel=new_pid*8+TSSSEL_OFFS;
    tss_goto(sel);
    /* Returns only when old_pid is selected again. */
    return 1;
}

void SchedulerTimerInterruptDispatch(void)
{
    int old_pid;

    old_pid=nr_curthread;
    pit_handler();
    /* Release legacy IRQ0 before any task transfer.  With the V70 rapid LAPIC
     * scheduler active, PIT IRQ0 is timekeeping/watchdog only. */
    pic_send_eoi(0);

    if(apic_rapid_scheduler_active())
        return;

    scheduler_timer_irqs++;
    if(!Multitasking || !SchedulerTimerShouldPreempt())
    {
        scheduler_timer_same_task++;
        return;
    }

    forceSwitch();
    if(nr_curthread==old_pid)
    {
        scheduler_timer_same_task++;
        return;
    }
    if(SchedulerDirectTaskSwitch(old_pid))
        scheduler_timer_switches++;
    else
        scheduler_timer_same_task++;
}

/* V70 LAPIC-only scheduler clock.  It deliberately does not call pit_handler:
 * PIT owns wall time, legacy timeouts, INT 1Ch and watchdog heartbeat. */
void SchedulerRapidTimerInterruptDispatch(void)
{
    int old_pid=nr_curthread;

    scheduler_timer_irqs++;
    /* LAPIC EOI must be sent before a hardware TSS switch, because the C call
     * below may not return until this old task is scheduled again. */
    apic_send_eoi();

    if(!Multitasking || !SchedulerTimerShouldPreempt())
    {
        scheduler_timer_same_task++;
        return;
    }

    forceSwitch();
    if(nr_curthread==old_pid)
    {
        scheduler_timer_same_task++;
        return;
    }
    if(SchedulerDirectTaskSwitch(old_pid))
        scheduler_timer_switches++;
    else
        scheduler_timer_same_task++;
}

void SchedulerYieldInterruptDispatch(void)
{
    int old_pid;

    if(!Multitasking) return;
    old_pid=nr_curthread;
    scheduler_yield_irqs++;
    SchedulerOnVoluntaryYield(old_pid);
    forceSwitch();
    if(nr_curthread==old_pid) return;
    if(SchedulerDirectTaskSwitch(old_pid))
        scheduler_yield_switches++;
}

__attribute__((naked)) void scheduler_yield_ISR(void)
{
    __asm__ __volatile__(
        "cld\n\t"
        "pushal\n\t"
        "push %ds\n\t"
        "push %es\n\t"
        "push %fs\n\t"
        "push %gs\n\t"
        "mov $0x10, %ax\n\t"
        "mov %ax, %ds\n\t"
        "mov %ax, %es\n\t"
        "mov %ax, %fs\n\t"
        "mov %ax, %gs\n\t"
        "call SchedulerYieldInterruptDispatch\n\t"
        "pop %gs\n\t"
        "pop %fs\n\t"
        "pop %es\n\t"
        "pop %ds\n\t"
        "popal\n\t"
        "iret\n\t"
    );
}

/* Enter idle with IF clear, recheck work, then STI;HLT. Because STI delays
 * maskable IRQ recognition through the following instruction when IF was 0,
 * a pending IRQ cannot slip into the check->HLT window and strand runnable
 * work until an unrelated later interrupt. */
void SchedulerIdleWait(void)
{
    DWORD i;
    DWORD burst=(scheduler_perf_mode==JTMOS_PERF_SLOW) ?
        SCHED_IDLE_HLT_BURST_SLOW : SCHED_IDLE_HLT_BURST_FAST;

    disable();
    scheduler_idle_rechecks++;
    if(scheduler_runnable_nonidle_exists())
    {
        enable();
        SwitchToThread();
        return;
    }

    /* FAST uses a 16-interrupt HLT burst; SLOW/debug uses 64.  Every HLT still
     * wakes on the next external interrupt/scheduler tick, so runnable work
     * leaves CPU_IDLE immediately.  The longer SLOW burst only reduces how
     * often outer idle-loop maintenance runs while the machine is truly idle. */
    for(i=0; i<burst; ++i)
    {
        scheduler_idle_halts++;
        cpu_sti_hlt();

        disable();
        if(scheduler_runnable_nonidle_exists())
        {
            enable();
            SwitchToThread();
            return;
        }
    }
    enable();
}

//--------------------------------------------------------------------------------
// Historical scheduler-task path (compile-time fallback).
static void SchedulerJumpSelected(int old_pid)
{
    TSSEG *ts;
    int sel;

    if(old_pid!=nr_curthread) taskSwitchNr++;
    SchedulerOnSwitch(old_pid,nr_curthread);
    unbusyTSS();
    if(old_pid!=nr_curthread) MapApplicationMemory();
    LOADTR(0x48);
    sel=nr_curthread*8+TSSSEL_OFFS;
    ts=&tasks->tss[nr_curthread];
    (void)ts;

    if(old_pid!=nr_curthread)
    {
        if(scheduler_switch_trace_budget)
        {
            scheduler_debug_dump_task("legacy-switch-target",nr_curthread,TRUE);
            scheduler_switch_trace_budget--;
        }
        if(!scheduler_validate_switch_target(old_pid,nr_curthread,
                                             "BAD legacy-switch-target"))
            return;
    }
    tss_goto(sel);
}

void LLSchedule(void)
{
    int old_pid=nr_curthread;

    /* INT 0x7E is a voluntary yield.  Reward a short burst, then choose a
     * peer immediately instead of waiting for the hardware quantum. */
    SchedulerOnVoluntaryYield(old_pid);
    forceSwitch();
    SchedulerJumpSelected(old_pid);
}

static void LLScheduleFromTimer(void)
{
    int old_pid=nr_curthread;

    /* A scheduler clock tick is not automatically a process switch. */
    if(SchedulerTimerShouldPreempt()) forceSwitch();
    SchedulerJumpSelected(old_pid);
}

//--------------------------------------------------------------------------------
//
void TaskPitHandler(void)
{
    pit_handler();
    pic_send_eoi(0);
    LLScheduleFromTimer();
}

//--------------------------------------------------------------------------------
