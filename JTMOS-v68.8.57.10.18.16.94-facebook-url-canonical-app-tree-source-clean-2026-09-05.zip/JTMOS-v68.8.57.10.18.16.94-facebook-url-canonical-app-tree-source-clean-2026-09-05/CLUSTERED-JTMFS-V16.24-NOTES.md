# JTMOS V67.8.57.10.18.16.24 - Clustered JTMFS / FlexFAT + GraOS V38 busy cursor

## Clustered JTMFS / JTMFAT / FlexFAT

V16.24 keeps the DEVAPI logical block size unchanged. SATA/IDE still expose their normal
physical/logical sectors (normally 512 bytes), and Bigfoot still coalesces those sectors into
larger I/O transfers. The filesystem allocation unit can now be a cluster consisting of more
than one DEVAPI sector.

New large-volume allocation policy:

- below 4 GiB: 1 sector/allocation unit (legacy layout)
- >= 4 GiB: 8 sectors (4 KiB at 512 B/sector)
- >= 16 GiB: 16 sectors (8 KiB)
- >= 64 GiB: 32 sectors (16 KiB)
- >= 256 GiB: 64 sectors (32 KiB)

The maximum V16.24 cluster is 64 sectors. A nominal 500 GB disk therefore uses 32 KiB
clusters. Its FAT is approximately 58.2 MiB instead of about 3.64 GiB with the old one-entry-
per-512-byte-sector layout.

### On-disk compatibility

Legacy JTMFS volumes remain legacy sector-mode volumes. Cluster mode is only enabled when
the JTMFS information block contains the V16.24 cluster-layout tag/version and a cluster size
greater than one sector.

For clustered volumes:

- `fat_offs` and `fat_length` remain physical DEVAPI LBA-sector geometry.
- FAT indexes and file/directory chain block numbers are allocation-unit (cluster) IDs.
- cluster ID 0 is reserved.
- cluster ID 1 is the root allocation unit.
- cluster ID 2 and above are ordinary allocation units.
- `res6` stores sectors per cluster.
- `res7` stores the physical LBA corresponding to cluster ID 1.
- `max_val` stores the allocation-unit count.

Physical mapping is:

    LBA = res7 + (cluster_id - 1) * res6

Old volumes need no conversion to remain readable. A large disk must be reformatted with
V16.24 to gain clustered allocation and the smaller FAT.

### Paths converted to allocation-unit semantics

The V16.24 audit converted the filesystem-facing paths that previously assumed
`FAT index == physical sector`:

- mkfs geometry and FAT initialization
- JTMFAT allocation/free/range helpers
- FlexFAT cache sizing and entry count
- ReadChain / WriteChain cluster-to-LBA translation
- root and path validation
- directory creation, DIRDB buffering and durable writes
- fsadd/fsaddblocks allocation
- fsck/integrity scanning
- free-space/allocation-unit accounting

Direct raw-device file access remains physical-sector based intentionally.

## GraOS V38 cursor and consistently-busy indication

The old external `mousecursor.raw` is no longer authoritative. GraOS builds a known-good
Windows 95/98-style white arrow with black outline internally, preventing a missing or corrupt
cursor resource from breaking the pointer.

Long operations can request a consistently-busy cursor. GraOS debounces the state for 150 ms
to avoid flashing the hourglass for tiny operations. Once shown, a 32x32 hourglass is animated
at roughly 220 ms per frame while the request remains active.

Client API:

    JtmosGraOSSetBusy(1);
    /* long operation */
    JtmosGraOSSetBusy(0);

Compatibility alias:

    GraOS_SetBusy(1);
    GraOS_SetBusy(0);

Manual test:

    graosctl busy on
    graosctl busy off

Protocol IDs:

- `GRAOS_GSID_SETBUSY = 44`
- `GRAOS_GSID_GETBUSY = 45`

## Validation status

- All 32 JTMFS/FlexFAT C objects compile with the JTMOS i486/freestanding flags using
  `make -j2`.
- No `__udivdi3`, `__umoddi3`, or `snprintf` unresolved dependency is introduced by the
  clustered JTMFS object set.
- `libc/apps/gui: make -j2 check` passes.
- `graos.bin` and `graosctl.bin` are ELF32/i386 with entry point `0x80004000`.
- Host geometry test preserves the existing 16 MiB QEMU layout and selects 32 KiB clusters
  with ~58.2 MiB FAT for a nominal 500 GB/512-byte-sector disk.

The clustered format has not yet been boot/runtime-tested on a newly formatted 500 GB physical
volume in this build. Keep a backup before reformatting the eMachines disk for the first V16.24
test. Existing legacy volumes should remain readable without reformatting.
