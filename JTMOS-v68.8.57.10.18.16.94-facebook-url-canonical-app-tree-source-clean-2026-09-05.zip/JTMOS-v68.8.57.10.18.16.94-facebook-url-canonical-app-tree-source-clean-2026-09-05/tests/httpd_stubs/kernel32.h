/* Empty hosted-test locator. jt_httpd_policy_test.c supplies the required
 * kernel types/functions and defines the real kernel32.h include guard. */
