from pathlib import Path
p=Path(__file__).resolve().parents[1]/'kernel32/drivers/tcpip/ne2k.c'
s=p.read_text()
assert '#define TX_PAGE 0x40' in s
assert '#define TX_PAGES 6' in s
assert '#define RX_START (TX_PAGE + TX_PAGES)' in s
assert '#define TX_PAGE 0x20' not in s
assert 'regw(ISR,0x0a)' in s
assert 'if(isr&0x08)' in s
assert 'if(isr&0x02)' in s
print('PASS NE2000 TX page/ring layout and transmit completion')
