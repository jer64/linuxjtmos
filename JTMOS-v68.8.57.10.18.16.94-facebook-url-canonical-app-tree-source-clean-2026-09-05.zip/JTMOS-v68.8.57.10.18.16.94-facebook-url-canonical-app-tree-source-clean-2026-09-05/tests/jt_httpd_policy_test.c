/* Hosted state-machine test for the DHCP-owned JTMOS HTTP listener policy. */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned int DWORD;
typedef unsigned short u16_t;
#define UIP_TCP_MSS 536

/* Let jt_httpd.c use these hosted substitutes while still compiling the real
 * implementation rather than a copied model of it. */
#define __INCLUDED_KERNEL32_H__
#define __UIP_H__

typedef struct TEST_UIP_CONN {
    u16_t lport;
    u16_t mss;
    unsigned char appstate[200];
} TEST_UIP_CONN;

static TEST_UIP_CONN test_conn;
static TEST_UIP_CONN *uip_conn=&test_conn;
static unsigned char test_appdata[64];
static void *uip_appdata=test_appdata;
static u16_t uip_len;
static int listen_calls,unlisten_calls,last_listen,last_unlisten;

static int get_eflags(void){return 0;}
static void disable(void){}
static void set_eflags(int flags){(void)flags;}
static u16_t htons(u16_t value){return (u16_t)((value<<8)|(value>>8));}
static void uip_listen(u16_t port){listen_calls++;last_listen=port;}
static void uip_unlisten(u16_t port){unlisten_calls++;last_unlisten=port;}
static int printk(const char *fmt,...){(void)fmt;return 0;}
static int uip_connected(void){return 0;}
static int uip_aborted(void){return 0;}
static int uip_timedout(void){return 0;}
static int uip_closed(void){return 0;}
static int uip_newdata(void){return 0;}
static int uip_datalen(void){return 0;}
static int uip_rexmit(void){return 0;}
static int uip_poll(void){return 0;}
static int uip_acked(void){return 0;}
static int uip_mss(void){return test_conn.mss?test_conn.mss:UIP_TCP_MSS;}
static void uip_send(BYTE *data,int len){(void)data;(void)len;}
static void uip_close(void){}
static void uip_abort(void){}
#define O_RDONLY 0
#define SEEK_SET 0
#define SEEK_END 2
static int kgetglobalenv(const char *name,char *out,unsigned int cap){(void)name;(void)out;(void)cap;return -1;}
static int open(const char *path,int flags){(void)path;(void)flags;return -1;}
static int close(int fd){(void)fd;return 0;}
static int lseek(int fd,int off,int whence){(void)fd;(void)off;(void)whence;return -1;}
static int read(int fd,void *buf,int count){(void)fd;(void)buf;(void)count;return -1;}
static void WriteWWWLog(const char *line){(void)line;}

#include "../kernel32/drivers/tcpip/jt_httpd.c"

static void require(int condition,const char *message)
{
    if(!condition){fprintf(stderr,"FAIL: %s\n",message);exit(1);}
    printf("PASS: %s\n",message);
}

int main(void)
{
    static const unsigned char first_ip[4]={192,0,2,44};
    static const unsigned char second_ip[4]={198,51,100,19};

    require(JtHttpdAutoEnabled() && !JtHttpdRequested(),
            "HTTP autostart is enabled but waits for DHCP");

    JtHttpdDhcpLease(1,first_ip);
    require(JtHttpdRequested() && JtHttpdPort()==8080,
            "DHCP lease requests TCP port 8080");
    JtHttpdSync();
    require(JtHttpdIsListening() && listen_calls==1 && last_listen==8080,
            "owner sync starts the DHCP listener on port 8080");

    JtHttpdDhcpLease(0,NULL);
    JtHttpdSync();
    require(!JtHttpdRequested() && !JtHttpdIsListening() &&
            unlisten_calls==1 && last_unlisten==8080,
            "lease loss removes the DHCP-owned listener");

    JtHttpdDhcpLease(1,second_ip);
    JtHttpdSync();
    require(JtHttpdIsListening() && listen_calls==2,
            "a later DHCP lease restarts port 8080");

    require(JtHttpdEnable(8181)==0,"manual port request is accepted");
    JtHttpdDhcpLease(1,second_ip);
    JtHttpdSync();
    require(JtHttpdRequested() && JtHttpdPort()==8181 &&
            last_unlisten==8080 && last_listen==8181,
            "manual port is not overwritten by DHCP autostart");
    JtHttpdDhcpLease(0,NULL);
    JtHttpdSync();
    require(JtHttpdRequested() && JtHttpdIsListening(),
            "lease loss does not cancel a manual listener request");

    JtHttpdDisable();
    JtHttpdSync();
    JtHttpdDhcpLease(1,first_ip);
    JtHttpdSync();
    require(!JtHttpdAutoEnabled() && !JtHttpdRequested(),
            "explicit WWW stop disables DHCP autostart for this boot");

    JtHttpdSetAuto(1);
    JtHttpdSync();
    require(JtHttpdAutoEnabled() && JtHttpdPort()==8080 && JtHttpdIsListening(),
            "WWW auto re-enables and starts port 8080 with a live lease");

    JtHttpdNetworkStop();
    require(JtHttpdAutoEnabled() && !JtHttpdRequested() && !JtHttpdIsListening(),
            "network stop retains policy but clears active HTTP state");
    JtHttpdDhcpLease(1,second_ip);
    JtHttpdSync();
    require(JtHttpdRequested() && JtHttpdPort()==8080 && JtHttpdIsListening(),
            "next DHCP lease restarts HTTP after a network restart");

    puts("PASS: JTMOS DHCP HTTP autostart state machine");
    return 0;
}
