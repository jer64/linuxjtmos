/* Hosted stream test for JTMOS V16.63 multi-MSS uIP static HTTP server. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned int DWORD;
typedef unsigned short u16_t;
#define UIP_TCP_MSS 536
#define __INCLUDED_KERNEL32_H__
#define __UIP_H__

typedef struct TEST_UIP_CONN {
    u16_t lport;
    u16_t mss;
    unsigned char appstate[200];
} TEST_UIP_CONN;

static TEST_UIP_CONN test_conn;
static TEST_UIP_CONN *uip_conn=&test_conn;
static unsigned char request_buf[2048];
static void *uip_appdata=request_buf;
static int ev_connected,ev_aborted,ev_timedout,ev_closed,ev_newdata,ev_rexmit,ev_poll,ev_acked;
static int request_len,close_calls,listen_calls;
static u16_t uip_len;
static unsigned char output[131072];
static size_t output_len;
static int max_send;
static const char fake_article_path[] =
    "cdrom:/politiikka/putin_saksan_syytokset_leipzigin_drooni_iskusta_liittyvat_maan_sisapoliittiseen_kriisiin_izvestija-715.html";
static const unsigned char fake_article_body[] =
    "<!doctype html><html><body>Facebook canonical path works.</body></html>";
static int fake_file_pos;
static char last_open_path[512];

static int get_eflags(void){return 0;}
static void disable(void){}
static void set_eflags(int flags){(void)flags;}
static u16_t htons(u16_t value){return (u16_t)((value<<8)|(value>>8));}
static void uip_listen(u16_t port){(void)port;listen_calls++;}
static void uip_unlisten(u16_t port){(void)port;}
static int printk(const char *fmt,...){(void)fmt;return 0;}
static int uip_connected(void){return ev_connected;}
static int uip_aborted(void){return ev_aborted;}
static int uip_timedout(void){return ev_timedout;}
static int uip_closed(void){return ev_closed;}
static int uip_newdata(void){return ev_newdata;}
static int uip_datalen(void){return request_len;}
static int uip_rexmit(void){return ev_rexmit;}
static int uip_poll(void){return ev_poll;}
static int uip_acked(void){return ev_acked;}
static int uip_mss(void){return test_conn.mss?test_conn.mss:UIP_TCP_MSS;}
static void uip_send(BYTE *data,int len)
{
    if(len<0 || output_len+(size_t)len>sizeof(output)) { fprintf(stderr,"send overflow\n"); exit(2); }
    if(len>max_send) max_send=len;
    memcpy(output+output_len,data,(size_t)len);
    output_len+=(size_t)len;
}
static void uip_close(void){close_calls++;}
static void uip_abort(void){close_calls++;}
#define O_RDONLY 0
#define SEEK_SET 0
#define SEEK_END 2
/* Hosted regression intentionally forces the embedded fallback; filesystem
 * WWW_ROOT behavior is validated structurally by check_jt_httpd_site.sh. */
static int kgetglobalenv(const char *name,char *out,unsigned int cap){(void)name;(void)out;(void)cap;return -1;}
static int open(const char *path,int flags)
{
    (void)flags;
    strncpy(last_open_path,path,sizeof(last_open_path)-1);
    last_open_path[sizeof(last_open_path)-1]=0;
    if(strcmp(path,fake_article_path)==0) { fake_file_pos=0; return 7; }
    return -1;
}
static int close(int fd){(void)fd;return 0;}
static int lseek(int fd,int off,int whence)
{
    int size=(int)(sizeof(fake_article_body)-1);
    if(fd!=7) return -1;
    if(whence==SEEK_SET) fake_file_pos=off;
    else if(whence==SEEK_END) fake_file_pos=size+off;
    else return -1;
    if(fake_file_pos<0 || fake_file_pos>size) return -1;
    return fake_file_pos;
}
static int read(int fd,void *buf,int count)
{
    int size=(int)(sizeof(fake_article_body)-1);
    int remain,n;
    if(fd!=7 || count<0) return -1;
    remain=size-fake_file_pos;
    n=(count<remain)?count:remain;
    if(n>0) memcpy(buf,fake_article_body+fake_file_pos,(size_t)n);
    fake_file_pos+=n;
    return n;
}
static void WriteWWWLog(const char *line){(void)line;}

#include "../kernel32/drivers/tcpip/jt_httpd.c"

static void clear_events(void)
{
    ev_connected=ev_aborted=ev_timedout=ev_closed=ev_newdata=ev_rexmit=ev_poll=ev_acked=0;
}
static void require(int ok,const char *msg)
{
    if(!ok){fprintf(stderr,"FAIL: %s\n",msg);exit(1);} printf("PASS: %s\n",msg);
}

static void fetch_and_check(const char *path,const BYTE *body,size_t body_len,const char *header_token)
{
    char req[1536];
    size_t header_len;
    int loops=0;
    memset(&test_conn,0,sizeof(test_conn));
    test_conn.lport=htons(80);
    test_conn.mss=173; /* deliberately small/non-round to force many segments */
    output_len=0; max_send=0; close_calls=0;
    snprintf(req,sizeof(req),"GET %s HTTP/1.0\r\nHost: jtmos\r\n\r\n",path);
    request_len=(int)strlen(req);
    memcpy(request_buf,req,(size_t)request_len);
    uip_appdata=request_buf;
    clear_events(); ev_connected=1; ev_newdata=1;
    JtHttpdAppCall();
    clear_events();
    while(close_calls==0 && loops++<2000) {
        ev_acked=1;
        JtHttpdAppCall();
        clear_events();
    }
    require(close_calls==1,"HTTP stream closes after final ACK");
    require(max_send<=173,"every uIP send respects negotiated MSS");
    require(output_len>body_len,"HTTP response contains a header and body");
    header_len=output_len-body_len;
    require(memmem(output,header_len,header_token,strlen(header_token))!=NULL,"HTTP response has expected content type/status");
    require(memcmp(output+header_len,body,body_len)==0,"HTTP body is byte-exact across ACK-driven segments");
}


static void fragmented_request_check(void)
{
    const char *part1="GE";
    const char *part2="T /index.html HTTP/1.0\r\nHost: jtmos\r\n\r\n";
    int loops=0;
    size_t header_len;

    memset(&test_conn,0,sizeof(test_conn));
    test_conn.lport=htons(80);
    test_conn.mss=181;
    output_len=0; max_send=0; close_calls=0;

    request_len=(int)strlen(part1);
    memcpy(request_buf,part1,(size_t)request_len);
    uip_appdata=request_buf; uip_len=(u16_t)request_len;
    clear_events(); ev_connected=1; ev_newdata=1;
    JtHttpdAppCall();
    require(output_len==0 && close_calls==0,"fragmented HTTP request waits for complete request line");

    request_len=(int)strlen(part2);
    memcpy(request_buf,part2,(size_t)request_len);
    uip_appdata=request_buf; uip_len=(u16_t)request_len;
    clear_events(); ev_newdata=1;
    JtHttpdAppCall();
    clear_events();
    while(close_calls==0 && loops++<2000) {
        ev_acked=1;
        JtHttpdAppCall();
        clear_events();
    }
    require(close_calls==1,"fragmented HTTP request completes normally");
    require(output_len>JT_SITE_INDEX_HTML_LEN,"fragmented HTTP response has header and body");
    header_len=output_len-JT_SITE_INDEX_HTML_LEN;
    require(memmem(output,header_len,"200 OK",6)!=NULL,"fragmented HTTP request returns 200");
    require(memcmp(output+header_len,jt_site_index_html,JT_SITE_INDEX_HTML_LEN)==0,
            "fragmented HTTP request returns byte-exact index body");
}


static void facebook_url_check(void)
{
    const char *tracked=
        "/politiikka/putin_saksan_syytokset_leipzigin_drooni_iskusta_liittyvat_maan_sisapoliittiseen_kriisiin_izvestija-715.html"
        "?fbclid=IwY2xjawUHkatwZG9mBWV4dG4DYWVtAjEwAGJyaWQRMVgwZFNlYWFnNmRtRnJ4VUpzcnRjBmFwcF9pZBAyMjIwMzkxNzg4MjAwODkyAAEeueV5Ane507OeH_2W0xt0bfm9v6wlsxXmLCXWhGWPHZoipPtcJnWCsd7hS3w_aem_XwXDE0Dp0UZGDCQFKAVO1g";
    const char *absolute=
        "https://vunet.net/politiikka/putin_saksan_syytokset_leipzigin_drooni_iskusta_liittyvat_maan_sisapoliittiseen_kriisiin_izvestija-715.html"
        "?fbclid=another-long-facebook-tracker-that-must-not-become-part-of-the-filename";
    char safe[256];
    const char *bad="GET /../secret.html";

    last_open_path[0]=0;
    fetch_and_check(tracked,fake_article_body,sizeof(fake_article_body)-1,"Content-Type: text/html");
    require(strcmp(last_open_path,fake_article_path)==0,
            "Facebook fbclid is discarded before WWW_ROOT file lookup");

    last_open_path[0]=0;
    fetch_and_check(absolute,fake_article_body,sizeof(fake_article_body)-1,"Content-Type: text/html");
    require(strcmp(last_open_path,fake_article_path)==0,
            "absolute-form social URL is reduced to its essential path");

    require(http_extract_target_path((const BYTE *)bad,(int)strlen(bad),safe,sizeof(safe))<0,
            "WWW_ROOT fallback rejects dot-dot traversal");
}

static void malformed_request_check(void)
{
    char req[JT_HTTP_REQUEST_LINE_MAX+32];
    int i;
    memset(&test_conn,0,sizeof(test_conn));
    test_conn.lport=htons(80); test_conn.mss=200;
    output_len=0; close_calls=0; max_send=0;
    for(i=0;i<(int)sizeof(req);++i) req[i]='X';
    request_len=(int)sizeof(req); memcpy(request_buf,req,(size_t)request_len);
    uip_appdata=request_buf; uip_len=(u16_t)request_len;
    clear_events(); ev_connected=1; ev_newdata=1;
    JtHttpdAppCall();
    require(output_len>0 && memmem(output,output_len,"400 Bad Request",15)!=NULL,
            "overlong HTTP request line returns 400 instead of misparsing");
}

int main(void)
{
    unsigned char first[536],second[536];
    size_t first_len,second_len;
    const char *req="GET /index.html HTTP/1.0\r\nHost: jtmos\r\n\r\n";

    require(sizeof(JT_HTTP_CONN_STATE)<=sizeof(test_conn.appstate),
            "HTTP connection state fits uIP appstate ABI");
    JtHttpdEnable(80);
    JtHttpdSync();
    require(listen_calls==1,"HTTP listener enabled for hosted stream test");

    fetch_and_check("/index.html",jt_site_index_html,JT_SITE_INDEX_HTML_LEN,"Content-Type: text/html");
    fetch_and_check("/?health=1",jt_site_index_html,JT_SITE_INDEX_HTML_LEN,"Content-Type: text/html");
    fetch_and_check("/invest.html",jt_site_invest_html,JT_SITE_INVEST_HTML_LEN,"Content-Type: text/html");
    fetch_and_check("/index-en.html",jt_site_index_en_html,JT_SITE_INDEX_EN_HTML_LEN,"Content-Type: text/html");
    fetch_and_check("/en",jt_site_index_en_html,JT_SITE_INDEX_EN_HTML_LEN,"Content-Type: text/html");
    fetch_and_check("/invest-en.html",jt_site_invest_en_html,JT_SITE_INVEST_EN_HTML_LEN,"Content-Type: text/html");
    fetch_and_check("/en/invest",jt_site_invest_en_html,JT_SITE_INVEST_EN_HTML_LEN,"Content-Type: text/html");
    fetch_and_check("/jtmos.css",jt_site_jtmos_css,JT_SITE_JTMOS_CSS_LEN,"Content-Type: text/css");
    fetch_and_check("/jtmos.js",jt_site_jtmos_js,JT_SITE_JTMOS_JS_LEN,"Content-Type: application/javascript");
    fragmented_request_check();
    facebook_url_check();
    malformed_request_check();

    /* A retransmit must reproduce the same outstanding segment without moving offset. */
    memset(&test_conn,0,sizeof(test_conn)); test_conn.lport=htons(80); test_conn.mss=211;
    output_len=0; max_send=0; close_calls=0; request_len=(int)strlen(req); memcpy(request_buf,req,(size_t)request_len); uip_appdata=request_buf;
    clear_events(); ev_connected=1; ev_newdata=1; JtHttpdAppCall(); clear_events();
    first_len=output_len; require(first_len>0 && first_len<=sizeof(first),"initial HTTP segment emitted"); memcpy(first,output,first_len);
    output_len=0; ev_rexmit=1; JtHttpdAppCall(); clear_events(); second_len=output_len; memcpy(second,output,second_len);
    require(second_len==first_len && memcmp(first,second,first_len)==0,"uIP retransmit repeats identical outstanding segment");

    puts("PASS: JTMOS V16.94 Facebook/query canonicalization + safe WWW_ROOT multi-MSS HTTP stream");
    return 0;
}
