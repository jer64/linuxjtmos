#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
A="$ROOT/kernel32/drivers/sata/ahci.c"
H="$ROOT/kernel32/drivers/sata/ahci.h"
S="$ROOT/kernel32/drivers/hd/hdService.c"
P="$ROOT/kernel32/mm/paging.c"
PH="$ROOT/kernel32/mm/paging.h"
F="$ROOT/kernel32/fs/jtmfs/diskcache/flexFat.c"
SET="$ROOT/kernel32/settings.txt"
Q="$ROOT/run_jtmos_qemu_sata.sh"

fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }

[ -f "$A" ] && [ -f "$H" ] || fail "AHCI source/header missing"
grep -q 'AHCI_PCI_CLASS_STORAGE.*0x01' "$A" || fail "PCI storage class missing"
grep -q 'AHCI_PCI_SUBCLASS_SATA.*0x06' "$A" || fail "PCI SATA subclass missing"
grep -q 'AHCI_PCI_PROGIF_AHCI.*0x01' "$A" || fail "PCI AHCI prog-if missing"
grep -q 'pci_get_bar(pdev,5' "$A" || fail "AHCI shared BAR5 decode missing"
grep -q 'pci_enable_device(pdev,PCI_ENABLE_MEMORY|PCI_ENABLE_MASTER)' "$A" || fail "PCI memory/bus-master enable missing"
grep -q 'pci_find_class' "$A" || fail "AHCI shared PCI class lookup missing"
pass "PCI AHCI discovery and safe bus-master enable"

grep -q 'DWORD pg_mapio' "$PH" || fail "pg_mapio declaration missing"
grep -q 'DWORD pg_mapio' "$P" || fail "pg_mapio implementation missing"
grep -q 'rad | 0x1bUL' "$P" || fail "MMIO mapping lacks PWT+PCD"
pass "AHCI ABAR uses uncached kernel MMIO mapping"

grep -q 'AHCI_CMD_LIST_OFF.*0x000' "$A" || fail "command-list layout missing"
grep -q 'AHCI_RFIS_OFF.*0x400' "$A" || fail "received-FIS layout missing"
grep -q 'AHCI_CMD_TABLE_OFF.*0x500' "$A" || fail "command-table layout missing"
grep -q 'ahci_hba_size_check' "$A" || fail "HBA ABI size assertion missing"
grep -q 'ahci_port_size_check' "$A" || fail "port ABI size assertion missing"
grep -q 'userhw_dma_alloc_kernel32(AHCI_DMA_META_BYTES' "$A" || fail "command DMA allocation missing"
grep -q 'userhw_dma_alloc_kernel32(AHCI_BOUNCE_BYTES' "$A" || fail "bounce DMA allocation missing"
grep -q 'AHCI_BOUNCE_BYTES.*131072' "$A" || fail "128 KiB bounce buffer missing"
pass "AHCI command/FIS/PRDT DMA layout is bounded and aligned"

grep -q 'ATA_CMD_IDENTIFY.*0xec' "$A" || fail "IDENTIFY command missing"
grep -q 'ATA_CMD_READ_DMA_EXT.*0x25' "$A" || fail "READ DMA EXT missing"
grep -q 'ATA_CMD_WRITE_DMA_EXT.*0x35' "$A" || fail "WRITE DMA EXT missing"
grep -q 'ATA_CMD_READ_DMA.*0xc8' "$A" || fail "LBA28 READ DMA fallback missing"
grep -q 'ATA_CMD_WRITE_DMA.*0xca' "$A" || fail "LBA28 WRITE DMA fallback missing"
grep -q 'id\[83\].*1U<<10' "$A" || fail "LBA48 capability parse missing"
grep -q 'id\[100\]' "$A" || fail "LBA48 capacity parse missing"
pass "IDENTIFY, LBA48 DMA and LBA28 DMA fallback present"

grep -q 'ATA_CMD_FLUSH_CACHE.*0xe7' "$A" || fail "FLUSH CACHE missing"
grep -q 'ATA_CMD_FLUSH_CACHE_EXT.*0xea' "$A" || fail "FLUSH CACHE EXT missing"
grep -q 'AHCI_TIMEOUT_MS.*5000' "$A" || fail "bounded command timeout missing"
grep -q 'AHCI_PXIS_TFES' "$A" || fail "task-file error handling missing"
pass "flush, error and timeout paths present"

grep -q 'DEVICE_CMD_READBLOCKS' "$A" || fail "multi-block read DEVAPI missing"
grep -q 'DEVICE_CMD_WRITEBLOCKS' "$A" || fail "multi-block write DEVAPI missing"
grep -q 'DEVICE_TYPE_BLOCK|DEVICE_TYPE_MULTIBLOCK' "$A" || fail "hda multiblock registration missing"
grep -q 'driver_enableDAPIReadCache' "$A" || fail "DAPI read cache not enabled"
grep -q 'driver_enableDAPIWriteBackCache' "$A" || fail "DAPI write-back cache not enabled"
pass "hda DEVAPI/DAPI block contract retained"

python3 - "$S" <<'PY'
import sys
s=open(sys.argv[1],encoding='utf-8').read()
i=s.find('hw_hd_init()')
m=s.find('mcp61_sata_init_hda()',i)
a=s.find('ahci_init_hda()',m)
if i < 0 or m < 0 or a < 0 or not (i < m < a):
    raise SystemExit('IDE sanity -> MCP61 rescue -> AHCI fallback order missing')
PY
pass "hd_init preserves IDE sanity first, then MCP61 rescue, then AHCI fallback"

grep -q -- '-Idrivers/sata' "$SET" || fail "drivers/sata include path missing"
grep -q 'driver_FlushDrive' "$F" || fail "FlexFAT device flush durability stage missing"
grep -q 'readblocks1' "$F" || fail "FlexFAT direct physical readback stage missing"
grep -q 'writeblocks' "$F" || fail "FlexFAT multi-block write path missing"
pass "existing FlexFAT write/flush/readback durability remains connected"

[ -x "$Q" ] || fail "SATA QEMU launcher missing/not executable"
grep -q 'ich9-ahci' "$Q" || fail "SATA QEMU launcher lacks AHCI controller"
grep -q 'bus=jtmosahci.0' "$Q" || fail "SATA QEMU disk is not attached to AHCI port 0"
sh -n "$Q" || fail "SATA QEMU launcher shell syntax invalid"
pass "explicit AHCI QEMU test launcher is present"

if [ -f "$ROOT/kernel32/generated.mak" ]; then
    grep -q 'drivers/sata/ahci.o' "$ROOT/kernel32/generated.mak" || fail "generated kernel makefile omitted AHCI object"
    pass "generated kernel build includes drivers/sata/ahci.o"
fi

echo "PASS: SATA/AHCI hda regression checks complete"
