#!/usr/bin/env python3
from pathlib import Path
import os, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]

def require(cond,msg):
    if not cond:
        raise SystemExit('FAIL: '+msg)

def text(rel):
    return (ROOT/rel).read_text(errors='replace')

mod=text('kernel32/modules.conf')
require('NETWORK=1' in mod,'NETWORK must be enabled')
require('LEGACY_TCP=0' in mod,'legacy TCP must be excluded from default network profile')
require('START_SLIP=\t\t\t0;' in text('kernel32/keropt.c') or 'START_SLIP=\t\t0;' in text('kernel32/keropt.c'),'network must stay boot-time opt-in')
mk=text('kernel32/generated.mak')
require('drivers/slip/slip.o' in mk,'SLIP is missing from generated build')
require('drivers/tcpip/uip.o' in mk,'uIP is missing from generated build')
require('drivers/tcp/tcp.o' not in mk,'legacy TCP unexpectedly linked')
sh=text('kernel32/sh/sh.c')
require('{"internet", internet_app}' in sh and '{"www", www_app}' in sh,'SMSH networking commands missing')
require('WaitProcessTermination(pid);' in sh and 'if(background)' in sh,'background external launch path missing')
http=text('kernel32/drivers/tcpip/jt_httpd.c')
require('HTTP/1.0 200 OK' in http and 'uip_listen' in http,'HTTP server missing')
qemu=text('run_jtmos_qemu.sh')
require('-serial null' in qemu and '-serial "pipe:$SLIP_PIPE"' in qemu,'QEMU COM2 pipe wiring missing')
up=text('ubuntu-slip/slip-up.sh')
require('-p slip' in up,'host must explicitly select plain slip')
require('-p cslip' not in up,'host must not select CSLIP mode')
require('TCPMSS --clamp-mss-to-pmtu' in up,'MTU/MSS forwarding protection missing')

# Boot image must contain the linked kernel at sector 18 and a matching 512 KiB checksum.
img=(ROOT/'jtm32.img').read_bytes()
k=(ROOT/'kernel32/kernel32.bin').read_bytes()
require(len(img)==1440*1024,'unexpected floppy image size')
region=img[18*512:(18+1024)*512]
require(region[:len(k)]==k,'kernel prefix differs from jtm32 image')
require(not any(region[len(k):]),'kernel boot region is not zero padded')
stored=img[501] | (img[502]<<8)
require(stored==(sum(region)&0xffff),'boot checksum does not match 512 KiB kernel region')
print('PASS: JTMOS V64 SLIP/uIP/WWW static smoke tests')
