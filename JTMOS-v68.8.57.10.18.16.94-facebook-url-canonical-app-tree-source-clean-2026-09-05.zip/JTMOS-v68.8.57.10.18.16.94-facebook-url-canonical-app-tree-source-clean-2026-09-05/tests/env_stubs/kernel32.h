#ifndef TEST_KERNEL32_H
#define TEST_KERNEL32_H
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <stdint.h>
typedef uint32_t DWORD;
#endif
