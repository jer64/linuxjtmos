#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)

fail() { echo "vesa/autostart/mouse-union regression: $*" >&2; exit 1; }

grep -Eq '^%define[[:space:]]+BOOT_VESA_GRAPHICS[[:space:]]+0([[:space:]]|$)' "$ROOT/boot32/boot.asm" || fail "boot32 text-default VESA gate missing"
grep -q '%if BOOT_VESA_GRAPHICS' "$ROOT/boot32/boot.asm" || fail "boot32 VESA opt-in path missing"
grep -Eq '^%define[[:space:]]+BOOT_VESA_GRAPHICS[[:space:]]+0([[:space:]]|$)' "$ROOT/boot32/dosboot.asm" || fail "DOSBOOT text-default VESA gate missing"
grep -q '%if BOOT_VESA_GRAPHICS' "$ROOT/boot32/dosboot.asm" || fail "DOSBOOT VESA opt-in path missing"
grep -Eq '^GRAOS_BOOT=1([[:space:]]|$)' "$ROOT/kernel32/modules.conf" || fail "default module profile does not contain GraOS boot"
grep -Eq '^int[[:space:]]+START_GRAOS[[:space:]]*=[[:space:]]*0;' "$ROOT/kernel32/init/keropt.c" || fail "START_GRAOS compatibility flag is not safely disabled by default"
grep -Eq '^int[[:space:]]+autostart[[:space:]]*=[[:space:]]*1;' "$ROOT/kernel32/init/keropt.c" || fail "SMSH autostart is not enabled"
grep -Eq '^int[[:space:]]+mouse_union[[:space:]]*=[[:space:]]*1;' "$ROOT/kernel32/init/keropt.c" || fail "mouse_union is not enabled"
grep -q 'if(mouse_union && (buttons & 0x03))' "$ROOT/kernel32/drivers/mouse/mouse.c" || fail "mouse button aliasing condition is missing"
grep -Eq 'buttons[[:space:]]*=[[:space:]]*\(buttons[[:space:]]*&[[:space:]]*~0x03\)[[:space:]]*\|[[:space:]]*0x01;' "$ROOT/kernel32/drivers/mouse/mouse.c" || fail "left/right are not normalized to primary button"
grep -q 'START_GRAOS && GraOSBootStarted()' "$ROOT/kernel32/sh/sh.c" || fail "duplicate GraOS autostart guard is missing"

echo "VESA opt-in graphical boot + GraOS autostart + mouse_union: PASS"
