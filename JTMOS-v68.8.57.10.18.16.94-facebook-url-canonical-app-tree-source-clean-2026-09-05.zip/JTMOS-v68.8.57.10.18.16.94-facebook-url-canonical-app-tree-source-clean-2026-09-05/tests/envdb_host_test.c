#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../kernel32/core/environment/env.c"

static void need(int ok,const char *what){ if(!ok){fprintf(stderr,"FAIL: %s\n",what);exit(1);} printf("PASS: %s\n",what); }
int main(void)
{
    ENVDB *g,*p;
    char out[128];
    g=envdb_CreateVariableDatabase(); need(g!=NULL,"create ENVDB");
    need(envdb_SetVariableEx(g,"PATH","/bin:/usr/bin",1)==0,"set PATH");
    need(envdb_SetVariableEx(g,"EMPTY","",1)==0,"empty POSIX value is valid");
    need(envdb_SetVariableEx(g,"PATH","ignored",0)==0,"overwrite=0 preserves existing value");
    need(envdb_GetVariableEx(g,"PATH",out,sizeof(out))==0 && !strcmp(out,"/bin:/usr/bin"),"get PATH preserves value");
    need(envdb_SetVariableEx(g,"BAD=NAME","x",1)==-EINVAL,"reject name containing equals");
    p=envdb_CloneVariableDatabase(g); need(p!=NULL,"clone inherited environment");
    need(envdb_SetVariableEx(p,"PATH","/private",1)==0,"child modifies private copy");
    need(!strcmp(envdb_GetValuePtr(g,"PATH"),"/bin:/usr/bin"),"parent/global snapshot is unchanged");
    need(envdb_DeleteVariable(p,"MISSING")==0,"unset missing variable succeeds");
    need(envdb_DeleteVariable(p,"EMPTY")==0 && envdb_GetValuePtr(p,"EMPTY")==NULL,"unset removes variable");
    envdb_DestroyVariableDatabase(p); envdb_DestroyVariableDatabase(g);
    puts("PASS: POSIX ENVDB hosted regression");
    return 0;
}
