#!/usr/bin/env python3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def text(p): return (ROOT/p).read_text(errors='replace')
def must(cond,msg):
    if not cond: raise SystemExit('FAIL: '+msg)
    print('PASS:',msg)

eth=text('kernel32/drivers/tcpip/ethdev.c')
j=text('kernel32/drivers/tcpip/jnet.c')
nc=text('kernel32/drivers/tcpip/networkControl.c')
ui=text('kernel32/sh/networkapp.c')

must('ETHDEV_LINK_POLL_MS' in eth and 'link_changes++' in eth,'Ethernet carrier polling is rate-limited and counts transitions')
must('ETHDEV_ERR_LINK_DOWN' in eth and 'ETHDEV_ERR_IO' in eth,'Ethernet backend errors are normalized')
must('cfg.config_method==JNET_CFG_QEMU_USER_STATIC || cfg.config_method==JNET_CFG_NFORCE_DIRECT' in j,'automatic fallback configurations are DHCP-probed')
must('clear_dhcp_address(JNET_DHCP_SELECTING,0)' in j,'DHCP address is invalidated after carrier recovery before fresh DORA')
must('dhcp_link_losses' in j and 'dhcp_link_recoveries' in j,'JNET records carrier loss/recovery')
must('nc && nc->configured && ethdev_link_up()' in nc,'Internet online state requires both IPv4 configuration and Ethernet carrier')
must('ETHDEV_STATS es' in ui and 'fallback DHCP probes' in ui,'internet status exposes Ethernet and DHCP recovery telemetry')
