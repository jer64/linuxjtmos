#!/usr/bin/env python3
PIT_HZ=1193180
DIV=0x800
HZ=round(PIT_HZ/DIV)
QUANTA=[3,4,6,10]
AGE=max(1,HZ//25)

def floor(prio):
    if prio <= 1: return 0
    if prio <= 2: return 1
    if prio <= 4: return 2
    return 3

def initial(prio):
    return min(3,floor(prio)+1)

def eff(level, wait):
    return max(0, level-min(3,wait//AGE))

assert 582 <= HZ <= 583
ms=[q*1000.0/HZ for q in QUANTA]
assert 5.0 < ms[0] < 5.4
assert 6.5 < ms[1] < 7.2
assert 9.0 < ms[2] < 11.5
assert 16.0 < ms[3] < 18.5
assert initial(1)==1 and floor(1)==0
assert initial(2)==2 and floor(2)==1
assert eff(3,AGE*3)==0              # starvation prevention
assert max(3,1)-1==2                 # bounded one-step I/O reward
assert 1-1==0                        # short-burst promotion
assert min(3,0+1)==1                 # full-quantum demotion
# A spin loop that yields without running a PIT tick cannot remain interactive forever.
level=0
streak=0
for _ in range(4):
    streak += 1
    if streak >= 4:
        streak=0
        level=min(3,level+1)
assert level==1

print('PASS scheduler policy')
print('PIT Hz:',HZ)
print('quanta ms:',', '.join(f'{x:.2f}' for x in ms))
print('aging window ms:',f'{AGE*1000.0/HZ:.2f}')
