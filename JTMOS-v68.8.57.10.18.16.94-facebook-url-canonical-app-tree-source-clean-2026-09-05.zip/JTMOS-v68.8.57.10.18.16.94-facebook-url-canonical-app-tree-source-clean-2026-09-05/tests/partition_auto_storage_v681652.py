#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]
part=(r/'libc/apps/partition.c').read_text()
ps=(r/'kernel32/drivers/partsup/partsup.c').read_text()
dc=(r/'kernel32/drivers/driver_api_devcall.c').read_text()

assert 'partition hda auto' in part
assert 'Over write partition table on hda: (y/n) ? ' in part
assert 'fgets(answer,sizeof(answer),stdin)' in part
assert 'return auto_disk(dnr,mbr,sectors);' in part
assert 'p->boot_indicator=0x80;' in part
assert 'p->begsec=JTMOS_HDD_FIRST_PARTITION_LBA;' in part
assert 'p->sector_count=disk-JTMOS_HDD_FIRST_PARTITION_LBA;' in part
assert 'sync_partsup()' in part
assert 'DEVICE_CMD_SYNC' in part

# hdaN must use the active parent backend, never legacy IDE's raw routine.
transfer=ps[ps.index('static int partition_transfer'):ps.index('static int partition_device_call')]
assert 'device_call(hda,cmd' in transfer
code='\n'.join(line.split('/*')[0] for line in transfer.splitlines())
assert 'hdSectorRW_LBA(chd' not in code
assert 'chd' not in transfer
assert 'bs!=512' in ps
assert 'DEVICE_CMD_FLUSH' in ps and 'device_call(hda,DEVICE_CMD_FLUSH' in ps

# Early device-call validation failures must release the global gate.
assert dc.count('device_call_busy=0;') >= 3
assert 'Never leak the global gate' in dc
print('PASS: V68.8.57.10.18.16.52 partition auto + backend-safe hdaN forwarding invariants')
