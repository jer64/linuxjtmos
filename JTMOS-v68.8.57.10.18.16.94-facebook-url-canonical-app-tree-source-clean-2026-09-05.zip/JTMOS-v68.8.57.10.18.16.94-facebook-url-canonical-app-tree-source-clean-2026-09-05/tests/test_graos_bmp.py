#!/usr/bin/env python3
"""Regression checks for GraOS 8-bit BMP wallpaper contract."""
from pathlib import Path
import struct

ROOT=Path(__file__).resolve().parents[1]
BMP=ROOT/'libc/apps/gui/background.bmp'

def parse_bmp8(data):
    assert data[:2]==b'BM'
    off=struct.unpack_from('<I',data,10)[0]
    dib=struct.unpack_from('<I',data,14)[0]
    assert dib>=40
    w,h=struct.unpack_from('<ii',data,18)
    planes,bpp=struct.unpack_from('<HH',data,26)
    comp=struct.unpack_from('<I',data,30)[0]
    colors=struct.unpack_from('<I',data,46)[0] or 256
    assert w>0 and h and planes==1 and bpp==8 and comp==0 and colors<=256
    top=h<0
    hh=abs(h)
    stride=(w+3)&~3
    rows=[]
    for y in range(hh):
        sy=y if top else hh-1-y
        p=off+sy*stride
        rows.append(data[p:p+w])
    return w,hh,rows

def stretch(rows,sw,sh,dw,dh):
    return [bytes(rows[(y*sh)//dh][(x*sw)//dw] for x in range(dw)) for y in range(dh)]

def synthetic(top_down=False):
    w,h=3,2
    rows=[bytes([1,2,3]),bytes([4,5,6])]
    stride=4
    pal=bytearray(256*4)
    for i in range(256): pal[i*4:i*4+4]=bytes((i,i,i,0))
    stored=rows if top_down else list(reversed(rows))
    pix=b''.join(r+b'\0'*(stride-w) for r in stored)
    off=14+40+len(pal)
    hs=-h if top_down else h
    fh=b'BM'+struct.pack('<IHHI',off+len(pix),0,0,off)
    ih=struct.pack('<IiiHHIIiiII',40,w,hs,1,8,0,len(pix),0,0,256,256)
    return fh+ih+pal+pix, rows

def main():
    w,h,rows=parse_bmp8(BMP.read_bytes())
    assert (w,h)==(1024,768)
    assert len(rows)==768 and all(len(r)==1024 for r in rows)
    for td in (False,True):
        data,expect=synthetic(td)
        sw,sh,r=parse_bmp8(data)
        assert r==expect
        out=stretch(r,sw,sh,7,5)
        assert len(out)==5 and all(len(x)==7 for x in out)
        assert out[0][0]==1 and out[-1][-1]==6
    print('GraOS BMP regression: PASS')
    print(f'wallpaper={w}x{h}x8, bytes={BMP.stat().st_size}')
    print('bottom-up/top-down + DWORD padding + nearest stretch: PASS')
if __name__=='__main__': main()
