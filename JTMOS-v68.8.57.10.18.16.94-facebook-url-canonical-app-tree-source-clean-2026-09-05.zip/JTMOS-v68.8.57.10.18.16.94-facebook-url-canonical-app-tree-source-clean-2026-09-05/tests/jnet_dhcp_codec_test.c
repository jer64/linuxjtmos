#include <stdio.h>
#include <string.h>
#include "../kernel32/drivers/tcpip/jnet_dhcp.h"

static unsigned r16(const unsigned char *p){return ((unsigned)p[0]<<8)|p[1];}
static void w16(unsigned char *p,unsigned v){p[0]=(unsigned char)(v>>8);p[1]=(unsigned char)v;}
static void w32(unsigned char *p,unsigned v){p[0]=(unsigned char)(v>>24);p[1]=(unsigned char)(v>>16);p[2]=(unsigned char)(v>>8);p[3]=(unsigned char)v;}
static unsigned sum16(const unsigned char *p,int n){unsigned s=0;while(n>1){s+=r16(p);p+=2;n-=2;}if(n)s+=((unsigned)*p)<<8;while(s>>16)s=(s&0xffff)+(s>>16);return (~s)&0xffff;}

static int opt_find(const unsigned char *d,int n,int tag)
{
    int o=240,l;
    while(o<n){if(d[o]==255)return -1;if(d[o]==0){o++;continue;}if(o+1>=n)return -1;l=d[o+1];if(o+2+l>n)return -1;if(d[o]==tag)return o;o+=2+l;}return -1;
}

static int build_reply(unsigned char *f,int ihl,int mt,unsigned xid,const unsigned char mac[6])
{
    unsigned char *ip,*udp,*d,*o;int n;
    memset(f,0,1600);memset(f,0xff,6);memcpy(f+6,"ABCDEF",6);w16(f+12,0x0800);
    ip=f+14;ip[0]=(unsigned char)(0x40|(ihl/4));ip[8]=64;ip[9]=17;ip[12]=10;ip[13]=0;ip[14]=2;ip[15]=2;ip[16]=255;ip[17]=255;ip[18]=255;ip[19]=255;
    udp=ip+ihl;w16(udp,67);w16(udp+2,68);d=udp+8;d[0]=2;d[1]=1;d[2]=6;w32(d+4,xid);d[16]=10;d[17]=0;d[18]=2;d[19]=15;memcpy(d+28,mac,6);d[236]=99;d[237]=130;d[238]=83;d[239]=99;o=d+240;
#define OPT1(t,v) do{*o++=(t);*o++=1;*o++=(v);}while(0)
#define OPT4(t,a,b,c,e) do{*o++=(t);*o++=4;*o++=(a);*o++=(b);*o++=(c);*o++=(e);}while(0)
    OPT1(53,mt);OPT4(54,10,0,2,2);OPT4(1,255,255,255,0);OPT4(3,10,0,2,2);OPT4(6,10,0,2,3);
    *o++=51;*o++=4;w32(o,3600);o+=4;*o++=58;*o++=4;w32(o,1800);o+=4;*o++=59;*o++=4;w32(o,3150);o+=4;*o++=255;
    n=(int)(o-d);w16(udp+4,n+8);w16(ip+2,ihl+n+8);w16(ip+10,sum16(ip,ihl));return 14+ihl+8+n;
}

static int ck(int ok,const char *what){if(!ok){fprintf(stderr,"FAIL: %s\n",what);return 1;}printf("PASS: %s\n",what);return 0;}

int main(void)
{
    unsigned char f[1600],mac[6]={0x52,0x54,0,0x12,0x34,0x56};
    JNET_DHCP_BUILD b;JNET_DHCP_REPLY r;int n,o,fail=0;

    memset(&b,0,sizeof(b));b.message_type=JNET_DHCP_DISCOVER;b.xid=0x12345678U;b.broadcast=1;memcpy(b.client_mac,mac,6);memset(b.ethernet_dest,0xff,6);memset(b.destination_ip,0xff,4);
    n=jnet_dhcp_build_frame(f,sizeof(f),&b);fail|=ck(n>=342,"DISCOVER frame builds and pads DHCP payload to 300 bytes");
    fail|=ck(r16(f+12)==0x0800 && f[14]==0x45 && r16(f+34)==68 && r16(f+36)==67,"DISCOVER Ethernet/IPv4/UDP headers");
    fail|=ck(r16(f+52)==0x8000,"DISCOVER BOOTP broadcast flag");
    o=opt_find(f+42,n-42,53);fail|=ck(o>=0 && f[42+o+2]==JNET_DHCP_DISCOVER,"DISCOVER message-type option");
    fail|=ck(opt_find(f+42,n-42,61)>=0 && opt_find(f+42,n-42,55)>=0,"DISCOVER client-id and parameter request list");

    n=build_reply(f,24,JNET_DHCP_OFFER,0x12345678U,mac);
    fail|=ck(jnet_dhcp_parse_reply(f,n,0x12345678U,mac,&r)==JNET_DHCP_OFFER,"OFFER accepts IPv4 options/IHL=24");
    fail|=ck(r.yiaddr[0]==10&&r.yiaddr[3]==15&&r.gateway[3]==2&&r.dns[3]==3,"OFFER address/router/DNS parse");
    fail|=ck(r.lease_seconds==3600U&&r.t1_seconds==1800U&&r.t2_seconds==3150U,"OFFER lease/T1/T2 parse");
    fail|=ck(jnet_dhcp_parse_reply(f,n,0x87654321U,mac,&r)<0,"wrong XID rejected");
    f[14+6]|=0x20;w16(f+14+10,0);w16(f+14+10,sum16(f+14,24));fail|=ck(jnet_dhcp_parse_reply(f,n,0x12345678U,mac,&r)<0,"fragmented DHCP reply rejected");

    n=build_reply(f,20,JNET_DHCP_NAK,0x12345678U,mac);fail|=ck(jnet_dhcp_parse_reply(f,n,0x12345678U,mac,&r)==JNET_DHCP_NAK,"DHCP NAK parsed immediately");
    f[42+240+1]=250;fail|=ck(jnet_dhcp_parse_reply(f,n,0x12345678U,mac,&r)<0,"malformed option length rejected");

    memset(&b,0,sizeof(b));b.message_type=JNET_DHCP_REQUEST;b.xid=7;b.broadcast=1;memcpy(b.client_mac,mac,6);memset(b.ethernet_dest,0xff,6);memset(b.destination_ip,0xff,4);b.requested_ip[0]=10;b.requested_ip[3]=15;b.include_requested_ip=1;b.server_id[0]=10;b.server_id[3]=2;b.include_server_id=1;
    n=jnet_dhcp_build_frame(f,sizeof(f),&b);fail|=ck(opt_find(f+42,n-42,50)>=0&&opt_find(f+42,n-42,54)>=0,"SELECTING REQUEST includes requested-IP/server-ID");

    memset(&b,0,sizeof(b));b.message_type=JNET_DHCP_REQUEST;b.xid=8;memcpy(b.client_mac,mac,6);memcpy(b.source_ip,"\x0a\x00\x02\x0f",4);memcpy(b.destination_ip,"\x0a\x00\x02\x02",4);memcpy(b.ciaddr,b.source_ip,4);memcpy(b.ethernet_dest,"ABCDEF",6);
    n=jnet_dhcp_build_frame(f,sizeof(f),&b);fail|=ck(opt_find(f+42,n-42,50)<0&&opt_find(f+42,n-42,54)<0,"RENEW REQUEST omits SELECTING-only options");
    fail|=ck(!memcmp(f+42+12,b.source_ip,4),"RENEW REQUEST carries ciaddr");

    /* RFC2132 option-overload: move DNS into BOOTP file field and announce
     * file-field overloading from the normal options area. */
    n=build_reply(f,20,JNET_DHCP_OFFER,0x12345678U,mac);
    {
        unsigned char *d=f+42,*opts=d+240,*q=opts;
        while(*q!=255){if(*q==0){q++;continue;}if(*q==6){memmove(q,q+6,(size_t)((d+(r16(f+38)-8))-q-6));n-=6;w16(f+38,r16(f+38)-6);w16(f+16,r16(f+16)-6);break;}q+=2+q[1];}
        q=d+240;while(*q!=255){if(*q==0){q++;continue;}q+=2+q[1];}
        memmove(q+3,q,(size_t)((d+(r16(f+38)-8))-q));q[0]=52;q[1]=1;q[2]=1;n+=3;w16(f+38,r16(f+38)+3);w16(f+16,r16(f+16)+3);
        d[108]=6;d[109]=4;d[110]=1;d[111]=1;d[112]=1;d[113]=1;d[114]=255;
        w16(f+24,0);w16(f+24,sum16(f+14,20));
    }
    fail|=ck(jnet_dhcp_parse_reply(f,n,0x12345678U,mac,&r)==JNET_DHCP_OFFER && r.have_dns && r.dns[0]==1 && r.dns[3]==1,"OFFER parses RFC2132 file-field option overload");

    return fail?1:0;
}
