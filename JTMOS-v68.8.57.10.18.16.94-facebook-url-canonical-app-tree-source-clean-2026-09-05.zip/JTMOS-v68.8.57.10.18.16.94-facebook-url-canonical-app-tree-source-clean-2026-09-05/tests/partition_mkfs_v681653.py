#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]
ps=(r/'kernel32/drivers/partsup/partsup.c').read_text()
jh=(r/'kernel32/fs/jtmfs/jtmfat.h').read_text()
jc=(r/'kernel32/fs/jtmfs/jtmfat.c').read_text()
cf=(r/'kernel32/fs/jtmfs/createfat.c').read_text()
df=(r/'kernel32/fs/jtmfs/publicapi/directfileaccess.c').read_text()

# Partition aliases must implement mount protocol without unmounting parent hda.
start=ps.index('static int partition_device_call', ps.index('static int partition_transfer'))
end=ps.index('static int hda1_device_call', start)
pdc=ps[start:end]
assert 'case DEVICE_CMD_MOUNT:' in pdc
assert 'case DEVICE_CMD_UNMOUNT:' in pdc
mount_part=pdc[pdc.index('case DEVICE_CMD_MOUNT:'):pdc.index('case DEVICE_CMD_FLUSH:')]
assert 'return 0;' in mount_part
assert 'device_call(hda' not in mount_part

# Cluster geometry must be independent of BIOS boot-layout tag.
assert 'int jtmfat_infoblock_uses_clusters' in jh
helper=jc[jc.index('int jtmfat_infoblock_uses_clusters'):jc.index('int jtmfat_isclustered')]
assert 'res5>=JTMFS_CLUSTER_LAYOUT_VERSION' in helper
assert 'res6>1' in helper
assert 'JTMFS_BOOT_LAYOUT_TAG' not in helper
assert 'if(jtmfat_infoblock_uses_clusters(inf))' in jc
assert 'nentries=jtmfat_infoblock_uses_clusters(inf)' in cf

# mkfs must not continue after a failed mount.
mk=df[df.index('int mkfs(const char *path)'):]
assert 'r=mountDNR(dnr);' in mk
assert 'if(r)' in mk[mk.index('r=mountDNR(dnr);'):mk.index('r = formatdrive(dnr);')]

# Reproduce a representative 500 GB hda1 layout produced by `partition hda auto`.
# The important point is that it is clustered but intentionally lacks boot tag.
nblocks=976_558_404
bs=512
boot=32
cs=64
entries_per_block=bs//4
cluster_count=(nblocks-boot)//cs
fatblocks=0
data_lba=0
for _ in range(8):
    nentries=cluster_count+1
    fatblocks=(nentries//entries_per_block)+(1 if nentries%entries_per_block else 0)+2
    base=boot+fatblocks+10
    aligned=(base+cs-1)&~(cs-1)
    new_count=(nblocks-aligned)//cs
    if new_count==cluster_count:
        data_lba=aligned
        break
    cluster_count=new_count
if not data_lba:
    base=boot+fatblocks+10
    data_lba=(base+cs-1)&~(cs-1)
    cluster_count=(nblocks-data_lba)//cs
max_val=cluster_count+1
assert fatblocks>0 and data_lba>fatblocks and max_val>2
# New cluster discriminator: res5=2,res6=64 is enough; res3 boot tag is not required.
res3=0; res5=2; res6=cs; res7=data_lba
uses_clusters=(res5>=2 and res6>1)
assert uses_clusters and res3==0 and res7>0
# Cluster validator invariants used by jtmfat_validateinfoblock().
assert res6<=64 and (res6&(res6-1))==0
assert 1==1 and 2==2 and boot<=fatblocks+boot
last_lba=data_lba+(max_val-2)*res6
assert last_lba<nblocks and res6<=nblocks-last_lba

print('PASS: V68.8.57.10.18.16.53 hdaN mount + non-boot clustered JTMFS mkfs invariants')
print(f'geometry: blocks={nblocks} cluster={cs} FAT={boot}+{fatblocks} dataLBA={data_lba} units={max_val}')
