from pathlib import Path
r=Path(__file__).resolve().parents[1]
net=(r/'kernel32/sh/networkapp.c').read_text(errors='ignore')
jnet=(r/'kernel32/drivers/tcpip/jnet.c').read_text(errors='ignore')
key=(r/'kernel32/drivers/keyboard/keyb.c').read_text(errors='ignore')
th=(r/'kernel32/core/chiplevel/threads.c').read_text(errors='ignore')
sh=(r/'kernel32/sh/sh.c').read_text(errors='ignore')
assert 'ping [-c count]' in net
assert 'count==0 || transmitted<count' in net
assert 'ping statistics' in net and 'packet loss' in net and 'rtt min/avg/max/mdev' in net
assert 'jnet_ping_request_ex' in net
assert 'w16(ic+6,sequence)' in jnet
assert 'r16(ic+6)==sequence' in jnet
assert 'ping_ttl' in jnet and 'if(ttl)*ttl=rip[8]' in jnet
assert 'jnet_host_request(target,3000,&host_result)' in net
assert 'ipv4_frame_view' in jnet and 'ping_icmp_error' in jnet
assert 'terminal_interrupt_pending[N_MAX_SCREENS]' in key
assert 'sc==SCODE_C' in key and 'SCODE_LEFTCONTROL' in key and 'SCODE_RIGHTCONTROL' in key
assert 'OutTermKey(GetInputTerminal(),3)' in key
assert 'WaitProcessTerminationInterruptible' in th
assert 'GetThreadTerminal(pid)==terminal' in th
assert 'KillThreadEx((DWORD)pid,KT_NO_THREAD_SWITCH)' in th
assert 'WaitProcessTerminationInterruptible(pid)' in sh
assert 'ConsumeTerminalInterrupt(GetCurrentTerminal())' in sh
print('PASS Linux-like multi-ping structure')
print('PASS terminal-scoped Ctrl+C foreground job control structure')
