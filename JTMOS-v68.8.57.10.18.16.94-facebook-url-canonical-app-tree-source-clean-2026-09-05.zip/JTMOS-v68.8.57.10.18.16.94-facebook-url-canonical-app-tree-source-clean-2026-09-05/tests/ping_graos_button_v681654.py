from pathlib import Path
r=Path(__file__).resolve().parents[1]
wm=(r/'libc/apps/gui/windowMoving.c').read_text(errors='ignore')
wl=(r/'libc/apps/gui/guiLoop.c').read_text(errors='ignore')
wf=(r/'libc/apps/gui/windowFunc.c').read_text(errors='ignore')
net=(r/'kernel32/sh/networkapp.c').read_text(errors='ignore')
jnet=(r/'kernel32/drivers/tcpip/jnet.c').read_text(errors='ignore')
jh=(r/'kernel32/drivers/tcpip/jnet.h').read_text(errors='ignore')
sh=(r/'kernel32/sh/sh.c').read_text(errors='ignore')

# GraOS: captured button release is processed before desktop routing.
assert wl.index('windowReleaseCapturedButton(v)') < wl.index('guiDesktopInput(v)')
assert 'pb->pressed=0' in wm
assert 'v->pressed_button=NULL' in wm and 'v->pressed_window=NULL' in wm
assert 'activate=(pw && !pw->isfree && hover==pb && hover_window==pw)' in wm
assert 'int visual=(b==pb && bw==pw) ? 1 : 0' in wm
assert 'if(v->pressed_window==w) windowCancelButtonCapture(v);' in wf

# Ping: builtin owns foreground status for both SMSH and SQSH and JNET waits
# can be cancelled instead of forcing the user to wait for network timeout.
assert 'SetTerminalForegroundProcess(terminal,GetCurrentThread())' in net
assert 'GetTerminalForegroundProcess(terminal)' in net
assert 'SetTerminalForegroundProcess(terminal,saved_foreground>0?saved_foreground:0)' in net
assert '#define JNET_EINTR (-4)' in jh
assert 'jnet_foreground_interrupt_pending()' in jnet
assert 'ping_cancel=1' in jnet and 'host_cancel=1' in jnet
assert 'if(ping_cancel) return JNET_EINTR;' in jnet
assert 'if(host_cancel) return JNET_EINTR;' in jnet
assert 'if(jnet_control_cancelled()) return JNET_EINTR;' in jnet
assert 'ping_app() now marks/restores itself' in sh
print('PASS V68.8.57.10.18.16.54 ping Ctrl+C + GraOS button capture invariants')
