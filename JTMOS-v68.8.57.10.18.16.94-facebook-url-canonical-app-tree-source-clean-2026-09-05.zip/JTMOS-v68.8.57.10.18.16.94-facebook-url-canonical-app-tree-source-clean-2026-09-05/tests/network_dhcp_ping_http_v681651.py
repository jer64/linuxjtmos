#!/usr/bin/env python3
"""Structural regression checks for V68.8.57.10.18.16.51 networking.

These checks complement the host-executed DHCP codec test.  They pin the
owner-thread ordering and cross-module policy which cannot be linked as a
normal hosted executable without the JTMOS kernel runtime.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def source(path):
    return (ROOT / path).read_text(errors="replace")


def must(condition, message):
    if not condition:
        raise SystemExit("FAIL: " + message)
    print("PASS:", message)


init = source("kernel32/init/init.c")
jnet = source("kernel32/drivers/tcpip/jnet.c")
jnet_h = source("kernel32/drivers/tcpip/jnet.h")
uip = source("kernel32/drivers/tcpip/uipMain.c")
httpd = source("kernel32/drivers/tcpip/jt_httpd.c")
control = source("kernel32/drivers/tcpip/networkControl.c")
shell = source("kernel32/sh/networkapp.c")

must("StartSerialNetworkProcesses();" in init and
     "rv=JtInternetStart(SLIP_COM_PORT_N,DefaultSlipBPS);" in init,
     "boot starts the Ethernet/uIP owner which performs DHCP")

must("static volatile int httpd_auto_enabled = 1" in httpd and
     "httpd_requested_port=JT_HTTP_DEFAULT_PORT" in httpd,
     "HTTP IPv4 autostart defaults to TCP port 8080")
must("JtHttpdDhcpLease(int active" in httpd and
     "if(httpd_dhcp_active && httpd_auto_enabled)" in httpd,
     "HTTP listener request follows the synchronized usable-IPv4 state")
must("else if(httpd_auto_owned)" in httpd and "httpd_requested=0" in httpd,
     "lease loss withdraws an automatically-owned listener")
must("10.0.0.5" not in httpd,
     "HTTP response and diagnostics do not advertise a hard-coded address")

must("uip_sync_ipv4_services" in uip and
     "nc && nc->configured && ethdev_link_up()" in uip,
     "HTTP autostart requires configured IPv4 and carrier, not specifically DHCP")
loop = uip[uip.index("while(!JtInternetStopRequested())"):]
must(loop.index("jnet_maintenance();") < loop.index("uip_sync_ipv4_services();") <
     loop.index("JtHttpdSync();") < loop.index("jnet_service_requests();"),
     "owner loop applies post-maintenance IPv4 state before requests")
must("uip_ethernet_ipv4_length" in uip and
     "total>frame_len-UIP_LLH_LEN" in uip and
     "uip_len=(u16_t)iplen" in uip,
     "uIP trims Ethernet padding to the IPv4 total length")

must(jnet.count("owner_forward_frame(frame,n)") >= 5 and
     "JtUipServiceEthernetFrame(frame,len)" in jnet,
     "DHCP/ARP/ICMP/DNS control waits preserve unrelated uIP traffic")
must("static int valid_netmask" in jnet and
     "r->have_mask && valid_netmask(r->mask)" in jnet,
     "DHCP accepts only a contiguous non-zero subnet mask")
must("static int ipv4_frame_view" in jnet and
     "if(csum(ip,ihl)!=0)return -1" in jnet and
     "static int ping_icmp_error" in jnet,
     "ping validates IPv4/ICMP replies and reports network ICMP errors")
must("unsigned long owner_forwarded;" in jnet_h,
     "owner-wait forwarding is observable in network statistics")

must("jnet_host_request(target,3000,&host_result)" in shell and
     "<host|IPv4|gateway>" in shell,
     "ping resolves a hostname through DHCP-provided DNS")
must("WWW URL: http://%d.%d.%d.%d:%d/" in shell and
     "DHCP autostart enabled; TCP port 8080" in shell,
     "WWW status/controls use the dynamic address and expose autostart")
must("JtHttpdNetworkStop();" in control and "JtHttpdDisable();" not in control,
     "network stop closes HTTP without disabling next-lease autostart")

must(not (ROOT / "tools/kernel32").exists(),
     "tools/kernel32 mirror is removed; kernel32 is canonical")

print("PASS: V68.8.57.10.18.16.94 DHCP/static IPv4, Internet ping and HTTP autostart invariants")
