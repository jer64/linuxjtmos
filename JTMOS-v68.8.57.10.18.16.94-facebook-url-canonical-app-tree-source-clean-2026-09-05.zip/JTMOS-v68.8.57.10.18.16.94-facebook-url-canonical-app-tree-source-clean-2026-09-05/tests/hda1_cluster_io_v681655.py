#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]
ps=(r/'kernel32/drivers/partsup/partsup.c').read_text()
rc=(r/'kernel32/fs/jtmfs/ReadChain.c').read_text()
wc=(r/'kernel32/fs/jtmfs/WriteChain.c').read_text()

assert '#define PARTSUP_PARENT_MAX_SECTORS 8' in ps
assert '#define PARTSUP_IO_RETRIES 3' in ps
assert 'while(left)' in ps and 'buf+done*512UL' in ps
assert 'PARTSUP: %s failed parent hda' in ps

# Clustered partial I/O must use the sector window, not a complete-cluster RMW.
for text, op in ((rc,'readblocks'),(wc,'writeblocks')):
    assert '(skipBytes%pbs)==0 && (chunk%pbs)==0' in text
    assert 'sector_off=skipBytes/pbs' in text
    assert 'sectors=chunk/pbs' in text
    assert f'{op}(dnr,(long)(lba+(DWORD)sector_off)' in text

# Reproduce the user's exact copyall boundary: 32 KiB cluster, 16 KiB chunks.
cluster=32768
pbs=512
requests=[]
for offset in (0,16384,32768):
    unit_skip=offset//cluster
    skip_bytes=offset%cluster
    chunk=min(16384,cluster-skip_bytes)
    assert skip_bytes%pbs==0 and chunk%pbs==0
    sector_off=skip_bytes//pbs
    sectors=chunk//pbs
    requests.append((unit_skip,sector_off,sectors))
assert requests == [(0,0,32),(0,32,32),(1,0,32)]

# partsup turns every 32-sector filesystem request into four 4 KiB parent commands.
def split(n):
    out=[]
    while n:
        c=min(n,8); out.append(c); n-=c
    return out
assert split(32)==[8,8,8,8]
assert split(64)==[8]*8

print('PASS: V68.8.57.10.18.16.55 hda1 clustered partial-I/O + 4KiB parent chunk/retry invariants')
print('copyall offsets: 0 -> sectors 0..31; 16384 -> 32..63; 32768 -> next cluster sectors 0..31')
