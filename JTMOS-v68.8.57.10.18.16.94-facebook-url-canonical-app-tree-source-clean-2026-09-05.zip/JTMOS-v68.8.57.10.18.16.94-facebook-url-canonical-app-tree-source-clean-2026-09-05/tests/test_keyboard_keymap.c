#include <stdio.h>
#include "keymap.h"

static int failures=0;
#define CHECK(label,expr,want) do { int got=(expr); if(got!=(want)) { \
    printf("FAIL %-28s got=0x%x want=0x%x\n",label,got,(want)); failures++; \
} } while(0)

int main(void)
{
    /* English is the global default. */
    CHECK("default English",KeyboardGetLayout(),KEYBOARD_LAYOUT_ENGLISH);
    CHECK("US a",KeyboardTranslateScancode(KEYBOARD_LAYOUT_ENGLISH,0x1e,0,0,0),'a');
    CHECK("US Shift+a",KeyboardTranslateScancode(KEYBOARD_LAYOUT_ENGLISH,0x1e,1,0,0),'A');
    CHECK("US Caps+a",KeyboardTranslateScancode(KEYBOARD_LAYOUT_ENGLISH,0x1e,0,0,1),'A');
    CHECK("US Shift+Caps+a",KeyboardTranslateScancode(KEYBOARD_LAYOUT_ENGLISH,0x1e,1,0,1),'a');
    CHECK("US . unaffected caps",KeyboardTranslateScancode(KEYBOARD_LAYOUT_ENGLISH,0x34,0,0,1),'.');
    CHECK("US Shift+.",KeyboardTranslateScancode(KEYBOARD_LAYOUT_ENGLISH,0x34,1,0,0),'>');
    CHECK("US Shift+2",KeyboardTranslateScancode(KEYBOARD_LAYOUT_ENGLISH,0x03,1,0,0),'@');

    CHECK("FI aa",KeyboardTranslateScancode(KEYBOARD_LAYOUT_FINNISH,0x1a,0,0,0),0xe5);
    CHECK("FI AA",KeyboardTranslateScancode(KEYBOARD_LAYOUT_FINNISH,0x1a,1,0,0),0xc5);
    CHECK("FI o-umlaut",KeyboardTranslateScancode(KEYBOARD_LAYOUT_FINNISH,0x27,0,0,0),0xf6);
    CHECK("FI a-umlaut",KeyboardTranslateScancode(KEYBOARD_LAYOUT_FINNISH,0x28,0,0,0),0xe4);
    CHECK("FI Shift+.",KeyboardTranslateScancode(KEYBOARD_LAYOUT_FINNISH,0x34,1,0,0),':');
    CHECK("FI AltGr+2",KeyboardTranslateScancode(KEYBOARD_LAYOUT_FINNISH,0x03,0,1,0),'@');
    CHECK("FI AltGr+7",KeyboardTranslateScancode(KEYBOARD_LAYOUT_FINNISH,0x08,0,1,0),'{');
    CHECK("FI AltGr+0",KeyboardTranslateScancode(KEYBOARD_LAYOUT_FINNISH,0x0b,0,1,0),'}');
    CHECK("FI AltGr+-like +",KeyboardTranslateScancode(KEYBOARD_LAYOUT_FINNISH,0x0c,0,1,0),'\\');
    CHECK("FI AltGr ISO",KeyboardTranslateScancode(KEYBOARD_LAYOUT_FINNISH,0x56,0,1,0),'|');

    CHECK("set finnish",KeyboardSetLayoutByName("fi"),0);
    CHECK("get finnish",KeyboardGetLayout(),KEYBOARD_LAYOUT_FINNISH);
    CHECK("set english",KeyboardSetLayoutByName("english"),0);
    CHECK("get english",KeyboardGetLayout(),KEYBOARD_LAYOUT_ENGLISH);
    CHECK("reject layout",KeyboardSetLayoutByName("dvorak"),-1);

    if(failures) return 1;
    puts("keyboard keymap tests: PASS");
    return 0;
}
