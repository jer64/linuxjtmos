#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
net=(root/'libc/apps/net.c').read_text()
gpf=(root/'kernel32/core/cp/gpf.c').read_text()
tss=(root/'kernel32/core/chiplevel/tss.c').read_text()
sched=(root/'kernel32/core/cp/scheduler.c').read_text()
assert 'if(argc==1)' in net
assert 'else if(argc==6)' in net
assert 'fgets(str,sizeof(str),stdin)' in net
assert 'gets(str)' not in net
assert 'strcmp(argv[1]' not in net
assert 'parsed!=5' in net
assert 'ip1<=0 || ip1>255' in net and 'port<=0 || port>65535' in net
assert 'for(;;)\n        SwitchToThread();' in gpf
# unbusyTSS must not reload TR during exception recovery.
unbusy=tss[tss.index('void unbusyTSS(void)'):tss.index('void tssNextThread(void)')]
assert not any(line.strip()=='LOADTR(0x48);' for line in unbusy.splitlines())
# The one deliberate dump-TSS load belongs in the common scheduler switch path.
assert 'SchedulerJumpSelected' in sched and 'LOADTR(0x48);' in sched
print('PASS net argument safety')
print('PASS Ring3 exception scheduler recovery structure')
