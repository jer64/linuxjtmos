# JTMOS V64: Ubuntu plain SLIP + SMSH Internet + background WWW

Date: 2026-08-22

## Purpose

V64 turns the restored JTMOS serial networking code into an on-demand service
that can be connected to an Ubuntu Desktop host through QEMU COM2.

The transport is **plain RFC1055 SLIP**. It is intentionally not CSLIP and does
not use Van Jacobson header compression.

Default link:

- JTMOS: `10.0.0.5`
- Ubuntu: `10.0.0.1`
- JTMOS serial port: COM2
- speed: 115200, 8N1
- SLIP MTU: 1006 bytes
- IP stack: restored uIP

The old `drivers/tcp` implementation remains as historical source but is not
linked by the default V64 NETWORK profile (`LEGACY_TCP=0`). This prevents two
stacks from competing for the same SLIP packet queue and saves kernel space.

## Ubuntu side

`ubuntu-slip/` contains:

- `slip_pipe_bridge.py`: byte-transparent QEMU `.in/.out` FIFO <-> PTY relay
- `slip-up.sh`: creates the relay, attaches Linux `slattach -p slip`, configures
  `slN`, IPv4 forwarding, NAT and TCP MSS clamping
- `slip-down.sh`: removes only the JTMOS firewall rules and stops the link
- `slip-status.sh`: reports the bridge/interface state
- `install-deps.sh`: installs Ubuntu dependencies

QEMU's second serial port is connected to the FIFO base by
`run_jtmos_qemu.sh`. COM1 is a null chardev and COM2 is the SLIP pipe.

### Ubuntu start sequence

```sh
cd ubuntu-slip
./install-deps.sh
./slip-up.sh
cd ..
./run_jtmos_qemu.sh
```

The relay creates:

```text
${XDG_RUNTIME_DIR:-/tmp}/jtmos-slip/jtmos-slip.in
${XDG_RUNTIME_DIR:-/tmp}/jtmos-slip/jtmos-slip.out
```

The first carries host -> guest bytes; the second carries guest -> host bytes.

## SMSH commands

Networking is compiled in but does **not** take COM2 during boot. `START_SLIP`
is zero by default. Start it explicitly:

```text
internet
```

Equivalent/full forms:

```text
internet start
internet start com2 115200
internet status
internet stop
```

`internet` starts two background kernel workers:

- `slipd`: UART ownership, RFC1055 framing and packet queues
- `uip`: IPv4/TCP processing and periodic timers

The command returns to SMSH after initialization instead of owning the shell.

## Background WWW server

Start:

```text
www start
```

or a non-default TCP port:

```text
www start 8080
```

Status/stop:

```text
www status
www stop
```

If the network is offline, `www start` automatically starts its default COM2
SLIP/uIP dependency. The HTTP service executes from the long-lived uIP worker,
so the SMSH command returns immediately while the server continues running.

Ubuntu test:

```sh
curl http://10.0.0.5/
```

This release provides a small built-in HTTP/1.0 page for `/` and `/index.html`.
It is deliberately a minimal transport/server proof rather than a full CGI or
filesystem web stack.

## Generic SMSH background launch

Explicit external programs can now be launched without waiting:

```text
:program.bin arg1 arg2 &
```

Without `&`, SMSH retains the previous foreground behaviour and waits for the
process to terminate.

## Internet sharing

`slip-up.sh` configures the point-to-point `slN` link, enables IPv4 forwarding
and adds narrowly scoped firewall/NAT rules tagged `JTMOS-SLIP`. Forwarded TCP
SYNs are TCPMSS-clamped to the 1006-byte link MTU.

The host's previous `net.ipv4.ip_forward` setting is saved; `slip-down.sh`
restores it when the script had enabled forwarding itself.

V64 has raw IPv4/TCP connectivity. It does not add a DNS resolver to SMSH, so
JTMOS clients should use numeric IPv4 addresses unless an application supplies
its own DNS implementation.

## Runtime lifecycle fixes

- SLIP and uIP are no longer forced to start during boot.
- COM2 is claimed only while the Internet service is running.
- On startup failure the uIP worker is told to stop instead of waiting forever
  for `slipOnline`.
- `internet stop` requests a clean worker shutdown and releases the serial
  port/device.
- uIP gained `uip_unlisten()` so the WWW listener can be stopped/reconfigured.
- The uIP application callback now dispatches the JTMOS HTTP server.

## Build notes

The default V64 profile uses:

```text
NETWORK=1
LEGACY_TCP=0
START_SLIP=0
USE_LEGACY_UIP=1
```

This makes the feature available but dormant until SMSH starts it.
