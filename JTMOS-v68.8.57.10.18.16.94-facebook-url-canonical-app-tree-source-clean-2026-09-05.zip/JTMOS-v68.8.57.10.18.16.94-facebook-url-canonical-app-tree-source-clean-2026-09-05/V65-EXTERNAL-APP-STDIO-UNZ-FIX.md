# JTMOS V65 external application stdio / UNZ fix

## Runtime evidence

The COM1 serial log from QEMU proves that the ELF32 loader reaches userspace:

- `LaunchAppELF32Ex` creates PID 6.
- ELF entry point is `0x80004000`.
- `unz.bin` prints `unz: JTMOS installer starting` from `main()`.
- The old build then floods the console/serial log with `[NULL]`.

Therefore the loader/ELF entry itself is not the immediate failure point.  The
fix in this release concentrates on the application libc <-> syscall boundary.

## Standard file descriptors

The modern libc has always used the POSIX numbers:

- fd 0 = stdin
- fd 1 = stdout
- fd 2 = stderr

The kernel previously reserved only fd 0.  A normal `open()` could therefore
return fd 1 or fd 2, colliding with libc stdout/stderr.  V65 now permanently
reserves all three descriptors.  Real JTMFS files start at fd 3.

The syscall layer implements fd 0/1/2 as terminal streams.  `write(1,...)` and
`write(2,...)` go to the process terminal; `read(0,...)` reads the terminal.
Closing fd 0/1/2 is harmless and does not release them back into the global FD
pool.

## Userspace pointers

Application pointers passed to file-related syscalls are translated with A2K
before kernel filesystem code dereferences them.  The active chiplevel syscall
path now covers open/read/write/stat/fstat/lstat and the relevant legacy helper
calls.  GETARGV also validates its output pointer and rejects `which >= argc`.

## UNZ performance

The old decompressor emitted every expanded byte with `fputc()`.  Expanding a
roughly 1.5 MiB `install.img` therefore generated roughly 1.5 million userspace
write syscalls and JTMFS write operations.

The decoder now reconstructs the image in memory and stores it in 32 KiB
chunks.  This also stays below the current JTMFS maximum single-write size.
`unz.bin` requests 8 MiB of application RAM so compressed and expanded payloads
have enough workspace during installation/demo use.

## Serial diagnostics

The standalone installer now emits direct SYS_PUTS markers before stdio/file
operations:

    unz: JTMOS installer starting
    unz: default install mode
    unz: checking install.img.nz
    unz: install.img.nz found
    unz: starting nzip decompression
    unz: nzip decompression returned

If an explicit argument is supplied it instead prints:

    unz: explicit archive argument mode

These markers make the next runtime failure location unambiguous even if stdio
itself is the failing subsystem.

## Validation performed off-target

- modern libc `make check`: PASS
- `unz.bin` build: PASS
- ELF32/i386, static, entry `0x80004000`
- changed kernel syscall/file-descriptor C objects: PASS with JTMOS i386 flags
- modified nzip decompressor output compared byte-for-byte with original host
  decoder for the V65 install payload: PASS
- source mirrors under `tools/`, `apps/`, and `graos-host/`: synchronized

No QEMU runtime execution was possible in the build environment.  The next
required test is the real JTMOS/QEMU run with COM1 serial logging enabled.
