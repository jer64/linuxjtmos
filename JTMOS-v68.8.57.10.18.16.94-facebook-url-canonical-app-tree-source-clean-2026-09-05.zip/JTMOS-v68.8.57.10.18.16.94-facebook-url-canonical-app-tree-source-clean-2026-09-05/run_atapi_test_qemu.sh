#!/bin/sh
# Focused JTMOS V67.8.56.11 ATAPI smoke-test launcher.
# No SLIP setup is required: this boots the normal system floppy/HDD and
# attaches utilities.iso as an IDE ATAPI CD-ROM through QEMU -cdrom.
set -eu
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
FLOPPY=${JTMOS_FLOPPY:-${1:-$SCRIPT_DIR/jtm32.img}}
HDD=${JTMOS_HDD:-${2:-$SCRIPT_DIR/hd_jtmos.img}}
UTILS_CDROM=${JTMOS_UTILS_CDROM:-${3:-$SCRIPT_DIR/utilities.iso}}
SERIAL_LOG=${JTMOS_ATAPI_SERIAL_LOG:-$SCRIPT_DIR/atapi_test_serial.log}

command -v qemu-system-i386 >/dev/null 2>&1 || { echo "qemu-system-i386 not found in PATH." >&2; exit 127; }
[ -f "$FLOPPY" ] || { echo "Boot floppy missing: $FLOPPY" >&2; exit 1; }
[ -f "$UTILS_CDROM" ] || { echo "Utilities CD image missing: $UTILS_CDROM (run: make utilscdrom)" >&2; exit 1; }
if [ ! -f "$HDD" ]; then
  "$SCRIPT_DIR/make_hd_jtmos.sh" "$HDD"
fi

echo "JTMOS ATAPI smoke test:"
echo "  boot floppy: $FLOPPY"
echo "  IDE HDA:     $HDD"
echo "  IDE CD-ROM:  $UTILS_CDROM"
echo "  serial log:  $SERIAL_LOG"
echo "Inside JTMOS run: atapitest"
echo "Then:             sqa cdrom"
echo "                  unz.bin"

exec qemu-system-i386 -machine pc -m 512 -vga std \
  -drive file="$FLOPPY",format=raw,if=floppy,index=0 \
  -drive file="$HDD",format=raw,if=ide,index=0,media=disk \
  -cdrom "$UTILS_CDROM" \
  -device gus,irq=5 \
  -serial "file:$SERIAL_LOG" \
  -net none \
  -boot a
