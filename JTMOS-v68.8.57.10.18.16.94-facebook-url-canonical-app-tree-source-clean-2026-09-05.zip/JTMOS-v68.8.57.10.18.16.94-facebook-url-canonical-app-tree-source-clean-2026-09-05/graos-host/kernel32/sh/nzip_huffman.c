#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>

/* Huffman tree node. */
typedef struct HuffNode {
    unsigned char data;
    unsigned int freq;
    struct HuffNode *left;
    struct HuffNode *right;
} HuffNode;

static HuffNode *newNode(unsigned char data, unsigned int freq)
{
    HuffNode *node = malloc(sizeof(*node));

    if (node == NULL) {
        fprintf(stderr, "Out of memory\n");
        return NULL;
    }

    node->data = data;
    node->freq = freq;
    node->left = NULL;
    node->right = NULL;
    return node;
}

static void freeHuffmanTree(HuffNode *root)
{
    if (root == NULL) {
        return;
    }

    freeHuffmanTree(root->left);
    freeHuffmanTree(root->right);
    free(root);
}

static void swapNodes(HuffNode **a, HuffNode **b)
{
    HuffNode *tmp = *a;
    *a = *b;
    *b = tmp;
}

static void minHeapify(HuffNode **heap, int idx, int heapSize)
{
    int smallest = idx;
    int left = 2 * idx + 1;
    int right = 2 * idx + 2;

    if (left < heapSize && heap[left]->freq < heap[smallest]->freq) {
        smallest = left;
    }

    if (right < heapSize && heap[right]->freq < heap[smallest]->freq) {
        smallest = right;
    }

    if (smallest != idx) {
        swapNodes(&heap[idx], &heap[smallest]);
        minHeapify(heap, smallest, heapSize);
    }
}

static HuffNode *extractMin(HuffNode **heap, int *heapSize)
{
    HuffNode *minimum;

    if (heap == NULL || heapSize == NULL || *heapSize <= 0) {
        return NULL;
    }

    minimum = heap[0];
    --(*heapSize);

    if (*heapSize > 0) {
        heap[0] = heap[*heapSize];
        minHeapify(heap, 0, *heapSize);
    }

    return minimum;
}

static void insertMinHeap(HuffNode **heap, HuffNode *node, int *heapSize)
{
    int i;

    if (heap == NULL || node == NULL || heapSize == NULL) {
        return;
    }

    i = (*heapSize)++;

    while (i > 0 && node->freq < heap[(i - 1) / 2]->freq) {
        heap[i] = heap[(i - 1) / 2];
        i = (i - 1) / 2;
    }

    heap[i] = node;
}

static HuffNode *buildHuffmanTree(const unsigned char data[],
                                  const unsigned int freq[],
                                  int size)
{
    HuffNode **heap;
    HuffNode *left;
    HuffNode *right;
    HuffNode *top;
    HuffNode *root;
    int heapSize = 0;
    int i;

    if (data == NULL || freq == NULL || size <= 0) {
        return NULL;
    }

    heap = malloc((size_t)size * sizeof(*heap));
    if (heap == NULL) {
        fprintf(stderr, "Out of memory\n");
        return NULL;
    }

    for (i = 0; i < size; ++i) {
        if (freq[i] == 0) {
            continue;
        }

        heap[heapSize] = newNode(data[i], freq[i]);
        if (heap[heapSize] == NULL) {
            while (heapSize > 0) {
                freeHuffmanTree(heap[--heapSize]);
            }
            free(heap);
            return NULL;
        }
        ++heapSize;
    }

    if (heapSize == 0) {
        free(heap);
        return NULL;
    }

    for (i = heapSize / 2 - 1; i >= 0; --i) {
        minHeapify(heap, i, heapSize);
    }

    while (heapSize > 1) {
        left = extractMin(heap, &heapSize);
        right = extractMin(heap, &heapSize);

        top = newNode(0, left->freq + right->freq);
        if (top == NULL) {
            freeHuffmanTree(left);
            freeHuffmanTree(right);
            while (heapSize > 0) {
                freeHuffmanTree(heap[--heapSize]);
            }
            free(heap);
            return NULL;
        }

        top->left = left;
        top->right = right;
        insertMinHeap(heap, top, &heapSize);
    }

    root = extractMin(heap, &heapSize);
    free(heap);
    return root;
}

static void printCodes(const HuffNode *root, int code[], int depth)
{
    int i;

    if (root == NULL) {
        return;
    }

    if (root->left != NULL) {
        code[depth] = 0;
        printCodes(root->left, code, depth + 1);
    }

    if (root->right != NULL) {
        code[depth] = 1;
        printCodes(root->right, code, depth + 1);
    }

    if (root->left == NULL && root->right == NULL) {
        printf("  %c       | ", root->data);

        /* A one-symbol tree has an otherwise empty code. */
        if (depth == 0) {
            printf("0");
        } else {
            for (i = 0; i < depth; ++i) {
                printf("%d", code[i]);
            }
        }

        printf("\n");
    }
}

static int generateHuffmanCodes(const unsigned char data[],
                                const unsigned int freq[],
                                int size)
{
    HuffNode *root;
    int *code;

    root = buildHuffmanTree(data, freq, size);
    if (root == NULL) {
        fprintf(stderr, "Could not build Huffman tree\n");
        return 1;
    }

    code = malloc((size_t)size * sizeof(*code));
    if (code == NULL) {
        fprintf(stderr, "Out of memory\n");
        freeHuffmanTree(root);
        return 1;
    }

    printf("Character | Huffman code\n");
    printf("------------------------\n");
    printCodes(root, code, 0);

    free(code);
    freeHuffmanTree(root);
    return 0;
}

int main(void)
{
    const unsigned char data[] = {'a', 'b', 'c', 'd', 'e', 'f'};
    const unsigned int freq[] = {5, 9, 12, 13, 16, 45};
    const int size = (int)(sizeof(data) / sizeof(data[0]));

    return generateHuffmanCodes(data, freq, size);
}
