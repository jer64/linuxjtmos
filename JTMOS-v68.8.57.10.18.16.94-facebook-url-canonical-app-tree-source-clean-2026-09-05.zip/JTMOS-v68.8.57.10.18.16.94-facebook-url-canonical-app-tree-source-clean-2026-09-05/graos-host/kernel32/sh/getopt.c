/* Compatibility stub retained for old JTMOS sources.
 * The current shell does not use getopt().
 */
int getopt(int argc, char * const argv[], const char *optstring)
{
    (void)argc;
    (void)argv;
    (void)optstring;
    return -1;
}
