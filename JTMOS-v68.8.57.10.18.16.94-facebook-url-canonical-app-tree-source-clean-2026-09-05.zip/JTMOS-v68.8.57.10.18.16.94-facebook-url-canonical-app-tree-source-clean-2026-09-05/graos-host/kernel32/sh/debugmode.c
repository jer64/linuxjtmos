/*
 * debugmode.c - SMSH kernel debug/reporting switches.
 *
 * Historical versions called ExitThread(0) after changing the flag.  That was
 * correct when each command ran in its own temporary shell thread, but it is
 * fatal for the current builtin-command model: the command executes directly
 * in the persistent SMSH thread.  The argc/argv Main functions therefore
 * return normally to run_shell().
 */
#include <stdio.h>
#include <string.h>

#include "debugmode.h"

#ifdef JTMOS
#include "kernel32.h"
#else
/* Keep the standalone/host SMSH build useful for parser regressions. */
static int host_jtmos_debug = 0;
static int host_debug2 = 0;
static int host_glvar_debug_msg = 0;
#endif

#define SWITCH_TOGGLE (-1)
#define SWITCH_STATUS (-2)
#define SWITCH_INVALID (-3)

static int smsh_switch_request(int argc, char **argv)
{
    const char *arg;

    if(argc <= 1)
        return SWITCH_TOGGLE;
    if(argc != 2 || argv == NULL || argv[1] == NULL)
        return SWITCH_INVALID;

    arg = argv[1];
    if(!strcmp(arg, "toggle"))
        return SWITCH_TOGGLE;
    if(!strcmp(arg, "status"))
        return SWITCH_STATUS;
    if(!strcmp(arg, "on") || !strcmp(arg, "enable") || !strcmp(arg, "1"))
        return 1;
    if(!strcmp(arg, "off") || !strcmp(arg, "disable") || !strcmp(arg, "0"))
        return 0;

    return SWITCH_INVALID;
}

static int debug_level1_get(void)
{
#ifdef JTMOS
    return jtmos_debug ? 1 : 0;
#else
    return host_jtmos_debug ? 1 : 0;
#endif
}

static void debug_level1_set(int enabled)
{
    enabled = enabled ? 1 : 0;
#ifdef JTMOS
    /* Keep the two historical level-1 switches synchronized.  Some old JTMOS
     * code tests glvar.debugMsg while newer dprintk users test jtmos_debug. */
    glvar.debugMsg = enabled;
    jtmos_debug = enabled;
#else
    host_glvar_debug_msg = enabled;
    host_jtmos_debug = enabled;
#endif
}

static int debug_level2_get(void)
{
#ifdef JTMOS
    return debug2 ? 1 : 0;
#else
    return host_debug2 ? 1 : 0;
#endif
}

static void debug_level2_set(int enabled)
{
#ifdef JTMOS
    debug2 = enabled ? 1 : 0;
#else
    host_debug2 = enabled ? 1 : 0;
#endif
}

int DebugModeSwitchMain(int argc, char **argv)
{
    int request = smsh_switch_request(argc, argv);
    int enabled;

    if(request == SWITCH_INVALID) {
        printf("Usage: debug [on|off|toggle|status]\n");
        return 1;
    }

    enabled = debug_level1_get();
    if(request == SWITCH_TOGGLE)
        enabled ^= 1;
    else if(request == 0 || request == 1)
        enabled = request;

    if(request != SWITCH_STATUS)
        debug_level1_set(enabled);

    printf("Debug is %s (debug level 1).\n", enabled ? "ON" : "OFF");
    return 0;
}

int ReportModeSwitchMain(int argc, char **argv)
{
    int request = smsh_switch_request(argc, argv);
    int enabled;

    if(request == SWITCH_INVALID) {
        printf("Usage: report [on|off|toggle|status]\n");
        return 1;
    }

    enabled = debug_level2_get();
    if(request == SWITCH_TOGGLE)
        enabled ^= 1;
    else if(request == 0 || request == 1)
        enabled = request;

    if(request != SWITCH_STATUS)
        debug_level2_set(enabled);

    printf("Reporting %s (debug level 2).\n",
           enabled ? "ENABLED" : "DISABLED");
    return 0;
}

void DebugModeSwitch(void)
{
    (void)DebugModeSwitchMain(0, NULL);
}

void ReportModeSwitch(void)
{
    (void)ReportModeSwitchMain(0, NULL);
}
