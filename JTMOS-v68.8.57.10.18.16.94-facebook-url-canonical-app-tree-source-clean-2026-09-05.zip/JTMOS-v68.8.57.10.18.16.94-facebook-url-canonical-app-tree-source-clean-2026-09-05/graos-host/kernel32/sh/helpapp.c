//--------------------------------------------------------------------------------------------
// helpapp.c - Shell Manual.
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include "helpapp.h"

// Bring up the manual.
int help_app(int argc, char **argv)
{
	//
	printf("cd - changes directory\n");
	printf("chdir - changes directory\n");
	printf("ls [-l] - list directory; -l puts one name on each line\n");
	printf("dir [-l] - alias for ls\n");
	printf("mkfs [device name]\n");
	printf("format [device name]\n");
	printf("help - this manual\n");
	printf("exit / quit - leave SMSH\n");
	printf("sqa archive.sqa [options] - extract Squirrel archive\n");
	printf("sqarc directory archive.sqa - create Squirrel archive\n");
	printf("nzip file / nzip -d file.nz - compress or extract\n");
	printf("copyall [source path] - copy and verify all source files into current directory\n");
	printf("rm_wildcard [text] (aliases: rmwild, rmw) - delete matching files\n");
	printf("debug [on|off|toggle|status] (alias: debug1) - kernel debug level 1\n");
	printf("report [on|off|toggle|status] (alias: debug2) - reporting level 2\n");
	printf("m <hex-address> [hex-length] (alias: kmed) - kernel memory hex/ASCII dump\n");
	printf("fm <filename> - file hex/ASCII dump\n");
	printf(":program [args] - load an external .bin through LaunchApp (example: :install)\n");
	printf("Unknown commands without ':' keep the legacy system() fallback.\n");
	printf("\n");

	return 0;
}

