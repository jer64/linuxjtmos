#ifndef __INCLUDED_HELPAPP_H__
#define __INCLUDED_HELPAPP_H__

//
int help_app(int argc, char **argv);

#endif
