//--------------------------------------------------------------------------------------------
// ls.c - Directory displayer kernel mode application.
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lsapp.h"


#ifndef JTMOS
#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>

int ls_app(int argc, char **argv)
{
    const char *path = (argc >= 2 && argv[1] != NULL) ? argv[1] : ".";
    DIR *directory = opendir(path);
    struct dirent *entry;

    if (directory == NULL) {
        perror(path);
        return 1;
    }

    while ((entry = readdir(directory)) != NULL) {
        char full_path[4096];
        struct stat status;
        int is_directory = 0;

        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }

        if (snprintf(full_path, sizeof(full_path), "%s/%s", path, entry->d_name)
            < (int)sizeof(full_path)
            && stat(full_path, &status) == 0) {
            is_directory = S_ISDIR(status.st_mode);
        }

        if (is_directory) {
            printf("[%s] ", entry->d_name);
        } else {
            printf("%s ", entry->d_name);
        }
    }
    putchar('\n');

    if (closedir(directory) != 0) {
        perror("closedir");
        return 1;
    }
    return 0;
}
#endif

//
#ifdef JTMOS

#define LS_PACKED_WIDTH 79

static void ls_print_name(const char *name, int long_listing, int *line_width)
{
    int n;

    if(long_listing)
    {
        printk("%s\n", name);
        *line_width = 0;
        return;
    }

    n = strlen(name);
    if(*line_width != 0 && (*line_width + 2 + n) > LS_PACKED_WIDTH)
    {
        printk("\n");
        *line_width = 0;
    }

    if(*line_width != 0)
    {
        printk("  ");
        *line_width += 2;
    }

    printk("%s", name);
    *line_width += n;

    /* A very long JTMFS name should never make the following entry start
     * beyond the normal 80-column SMSH terminal. */
    if(*line_width >= LS_PACKED_WIDTH)
    {
        printk("\n");
        *line_width = 0;
    }
}

// Dir function (ls)
// -----------------
//
// Default output is packed for the 80-column SMSH console.  `ls -l` keeps
// every file/directory name on its own line.  Directories are shown in [] so
// the compact form remains useful without adding a separate size/type column.
int ls_app(int argc, char **argv)
{
    JTMFS_FILE_ENTRY *fe;
    DIRWALK *dw;
    int k;
    int dnr,db;
    int long_listing = 0;
    int line_width = 0;
    int totalBytes = 0;
    int totalFiles = 0;
    int totalDirs = 0;
    int arg;
    char display_name[40];

    for(arg=1; arg<argc; arg++)
    {
        if(argv[arg] && strcmp(argv[arg], "-l") == 0)
        {
            long_listing = 1;
            continue;
        }

        printk("Usage: ls [-l]\n");
        return 1;
    }

    dnr = GetCurrentDNR();
    db = GetCurrentDB();

    if(!jtmfat_isJTMFS(dnr))
    {
        printk("Looks like the drive is not JTMFS formatted.\n");
        return 1;
    }

    dw = malloc(sizeof(DIRWALK));
    if(!dw)
    {
        printk("ls: out of memory.\n");
        return 1;
    }

    if(jtmfs_ffirst(dnr,db,dw))
    {
        free(dw);
        return 1;
    }

    for(;;)
    {
        fe = dw->fe;

        /* ESC keeps the historical ability to abort a long directory walk. */
        if((k=getch1()) == 27)
            break;

        if(fe->length == -1)
            goto nextEntry;

        if(!strlen(fe->name))
            break;

        if(JTMFS_TYPE_IS_DIRECTORY(fe->type))
        {
            totalDirs++;
            sprintf(display_name,"[%s]",fe->name);
        }
        else
        {
            totalFiles++;
            totalBytes += fe->length;
            sprintf(display_name,"%s",fe->name);
        }

        ls_print_name(display_name,long_listing,&line_width);

nextEntry:
        if(jtmfs_fnext(dnr,dw))
            break;
    }

    if(!long_listing && line_width != 0)
        printk("\n");

    printk("%d File(s), %d Dir(s), %d bytes\n",
           totalFiles,totalDirs,totalBytes);

    free(dw);
    return 0;
}

#endif
