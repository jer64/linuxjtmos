GRAOS and Postman have been installed below sh/.

Main integration files:
  sh/Makefile.graos
  sh/graos/shell_graos.c
  sh/graos/SHELL_INTEGRATION.md
  sh/postman/msgbox.c
  sh/postman/postman_process.c
  sh/postman/shell_postman.c
  sh/postman/README.md

Shell commands after dispatcher integration:
  gui
  graos
  postman status
  postman find guiserver
  postman exec COMMAND...

SDL2 test build:
  cd sh/graos
  make
  ./msgbox-test
  ./process-test
  GRAOS_ASSET_DIR=. ./graos-sdl2

2026-08-19 terminal integration update:
  - This directory is an overlay for the native kernel32/sh tree.
  - sh.c uses bounded getch() input in JTMOS; fgets() is host-test-only.
  - SQSH exposes the SMSH command set in the GraOS Terminal.
  - The package intentionally does not overwrite a newer full sh/graos tree;
    only shell_graos.c/.h and integration documentation are carried here.
  - POSIX pipe() is not required by the terminal path and is not part of this patch.
