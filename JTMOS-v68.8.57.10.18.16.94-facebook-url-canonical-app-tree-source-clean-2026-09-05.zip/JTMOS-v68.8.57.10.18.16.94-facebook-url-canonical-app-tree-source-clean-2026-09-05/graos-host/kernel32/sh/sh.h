#ifndef __INCLUDED_SH_H__
#define __INCLUDED_SH_H__

//
#define EXIT_FAILURE 1
#define SHELL_EXIT_REQUEST 1000
//
int sqa_main(int argc,char **argv);
int run_shell(void);
int argv_main(int argc, char **argv);
int sqarc_main(int argc,char **argv);
int copyall_main(int argc,char **argv);
int rm_wildcard_main(int argc,char **argv);
int DebugModeSwitchMain(int argc,char **argv);
int ReportModeSwitchMain(int argc,char **argv);
int kmed_main(int argc,char **argv);
int file_memory_dump_main(int argc,char **argv);

#endif

