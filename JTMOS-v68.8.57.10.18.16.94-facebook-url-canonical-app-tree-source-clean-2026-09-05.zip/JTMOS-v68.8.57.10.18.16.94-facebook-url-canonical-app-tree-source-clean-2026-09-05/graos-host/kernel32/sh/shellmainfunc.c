//
#include <stdio.h>
#include "sh.h"
#ifndef JTMOS
int main(int argc, char **argv)
{
        (void)argc;
        (void)argv;
        return run_shell();
}
#endif
