# SMSH debug/report switches (V38)

Builtins:

- `debug` / `debug1`: toggle kernel debug level 1.
- `report` / `debug2`: toggle report/debug level 2.
- Optional argument: `on`, `off`, `toggle`, `status`, `1`, `0`, `enable`, `disable`.

Entry points:

    int DebugModeSwitchMain(int argc, char **argv);
    int ReportModeSwitchMain(int argc, char **argv);

The historical `DebugModeSwitch()` and `ReportModeSwitch()` symbols are retained
as compatibility wrappers, but they now return normally.  They no longer call
`ExitThread(0)`, because builtins execute in the persistent SMSH thread.

Level 1 keeps `glvar.debugMsg` and `jtmos_debug` synchronized.  Level 2 controls
`debug2`.
