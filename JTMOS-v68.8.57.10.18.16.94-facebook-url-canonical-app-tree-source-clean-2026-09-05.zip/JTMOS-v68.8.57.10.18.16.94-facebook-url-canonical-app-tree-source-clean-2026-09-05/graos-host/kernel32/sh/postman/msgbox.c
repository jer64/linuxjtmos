/*
 * msgbox.c - JTMOS Postman IPC
 * Original design (C) 2003-2005, 2013-2014 Jari Tuominen.
 * Portable Linux/SDL2 transport and synchronization added in 2026.
 */

#ifdef JTMOS

#include "kernel32.h"
#include "msgbox.h"

static DWORD unique_number;

static DWORD next_packet_number(void)
{
    return unique_number++;
}

void initMessage(MSG *msg, int protocol, int type, int amount)
{
    if (msg == NULL) return;
    memset(msg, 0, sizeof(*msg));
    msg->magic1 = MSGBOX_MAGIC1;
    msg->magic2 = MSGBOX_MAGIC2;
    msg->isFree = MSG_RESERVED;
    msg->protocol = protocol;
    msg->type = type;
    msg->amount = amount;
}

int VerifyMessage(const MSG *msg)
{
    if (msg == NULL) return 0;
    if (msg->magic1 != MSGBOX_MAGIC1 || msg->magic2 != MSGBOX_MAGIC2) return 0;
    if (msg->amount < 0 || msg->amount > N_MAX_BYTES_PER_MSG) return 0;
    return 1;
}

void initMessageBox(MSGBOX *box)
{
    int i;
    if (box == NULL) return;
    memset(box, 0, sizeof(*box));
    box->isFree = FALSE;
    box->n_q = N_MAX_QUEUED_MSGS;
    for (i = 0; i < box->n_q; ++i) box->q[i].isFree = MSG_FREE;
}

MSGBOX *createMessageBox(void)
{
    MSGBOX *box = (MSGBOX *)malloc(sizeof(*box));
    if (box != NULL) initMessageBox(box);
    return box;
}

void destroyMessageBox(MSGBOX *box)
{
    if (box != NULL) free(box);
}

int ActivateThreadMessageBox(int unipid)
{
    DWORD flags;
    MSGBOX *new_box = NULL;
    if (!unipid) return 1;
    UNIF(unipid) { } else return 1;

    /* Do not allocate heap memory while interrupts are disabled. */
    if (thread_msgbox[RPID(unipid)] == NULL) {
        new_box = createMessageBox();
        if (new_box == NULL) return 1;
    }
    flags = get_eflags();
    disable();
    if (thread_msgbox[RPID(unipid)] == NULL) {
        thread_msgbox[RPID(unipid)] = new_box;
        new_box = NULL;
    }
    set_eflags(flags);
    if (new_box != NULL) destroyMessageBox(new_box);
    return thread_msgbox[RPID(unipid)] == NULL;
}

int startMessageBox(void)
{
    return ActivateThreadMessageBox(GetCurrentThread());
}

int postmanCurrentPID(void)
{
    return GetCurrentThread();
}

int postmanSetProcessName(const char *name)
{
    if (name == NULL || *name == 0) return 1;
    IdentifyThread(GetCurrentThread(), name);
    return 0;
}

int postmanInit(const char *name)
{
    if (startMessageBox() != 0) return 1;
    return (name != NULL && *name != 0) ? postmanSetProcessName(name) : 0;
}

void postmanShutdown(void)
{
    /* The kernel owns thread_msgbox[] lifetime. */
}

int postmanFindProcess(const char *name)
{
    if (name == NULL) return -1;
    return GetThreadPID(name);
}

int postmanPurgeStale(void)
{
    return 0;
}

const char *postmanLastError(void)
{
    return "JTMOS Postman error";
}

int sendMessage(MSG *deliver_this, int unipid)
{
    MSGBOX *box;
    DWORD flags;
    int i;

    if (deliver_this == NULL || !unipid) return 1;
    UNIF(unipid) { } else return 1;
    if (deliver_this->amount < 0 || deliver_this->amount > N_MAX_BYTES_PER_MSG) return 1;

    if (ActivateThreadMessageBox(unipid) != 0) return 1;

    deliver_this->isFree = MSG_RESERVED;
    deliver_this->sndPID = GetCurrentThread();
    deliver_this->rcvPID = unipid;
    deliver_this->magic1 = MSGBOX_MAGIC1;
    deliver_this->magic2 = MSGBOX_MAGIC2;
    deliver_this->un = next_packet_number();
    if (!VerifyMessage(deliver_this)) return 1;

    flags = get_eflags();
    disable();
    box = thread_msgbox[RPID(unipid)];
    if (box != NULL) {
        for (i = 0; i < box->n_q; ++i) {
            if (box->q[i].isFree == MSG_FREE) {
                memcpy(&box->q[i], deliver_this, sizeof(*deliver_this));
                set_eflags(flags);
                return 0;
            }
        }
    }
    set_eflags(flags);
    return 1; /* Queue full. */
}

int receiveMessage(MSG *out)
{
    MSGBOX *box;
    MSG *oldest = NULL;
    DWORD oldest_number = 0xFFFFFFFFU;
    DWORD flags;
    int i;

    if (out == NULL) return 0;
    if (startMessageBox() != 0) return 0;

    flags = get_eflags();
    disable();
    box = thread_msgbox[RPID(GetCurrentThread())];
    if (box != NULL) {
        for (i = 0; i < box->n_q; ++i) {
            MSG *candidate = &box->q[i];
            if (candidate->isFree != MSG_RESERVED) continue;
            if (!VerifyMessage(candidate)) {
                candidate->isFree = MSG_FREE;
                continue;
            }
            if (candidate->un <= oldest_number) {
                oldest = candidate;
                oldest_number = candidate->un;
            }
        }
    }
    if (oldest != NULL) {
        memcpy(out, oldest, sizeof(*out));
        oldest->isFree = MSG_FREE;
        set_eflags(flags);
        return 1;
    }
    set_eflags(flags);
    return 0;
}

int receiveMessageTimed(MSG *out, int timeout_ms)
{
    DWORD started = GetTickCount();
    do {
        if (receiveMessage(out)) return 1;
        SwitchToThread();
    } while (timeout_ms < 0 || (int)(GetTickCount() - started) < timeout_ms);
    return 0;
}

#else /* Linux / SDL2 host */

#define _POSIX_C_SOURCE 200809L
#include "msgbox.h"

#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/file.h>
#include <poll.h>
#include <pthread.h>
#include <stdatomic.h>
#include <errno.h>
#include <dirent.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

static MSGBOX process_box = { .fd = -1 };
static pthread_mutex_t process_lock = PTHREAD_MUTEX_INITIALIZER;
static atomic_uint packet_number = 1U;
static char last_error[256];
static int atexit_registered;

static void set_error_text(const char *operation)
{
    int saved = errno;
    snprintf(last_error, sizeof(last_error), "%s: %s", operation, strerror(saved));
}

const char *postmanLastError(void)
{
    return last_error[0] != 0 ? last_error : "no error";
}

static int registry_directory(char *out, size_t out_size)
{
    int n = snprintf(out, out_size, "/tmp/jtmos-postman-%lu", (unsigned long)getuid());
    if (n < 0 || (size_t)n >= out_size) {
        errno = ENAMETOOLONG;
        return -1;
    }
    return 0;
}

static int ensure_registry_directory(char *out, size_t out_size)
{
    if (registry_directory(out, out_size) != 0) return -1;
    if (mkdir(out, 0700) != 0 && errno != EEXIST) {
        set_error_text("mkdir Postman registry");
        return -1;
    }
    if (chmod(out, 0700) != 0) {
        set_error_text("chmod Postman registry");
        return -1;
    }
    return 0;
}

static void sanitize_name(const char *name, char *out, size_t out_size)
{
    size_t i = 0;
    if (out_size == 0U) return;
    if (name != NULL) {
        while (*name != 0 && i + 1U < out_size && i < POSTMAN_NAME_MAX) {
            unsigned char c = (unsigned char)*name++;
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                (c >= '0' && c <= '9') || c == '-' || c == '_') out[i++] = (char)c;
            else out[i++] = '_';
        }
    }
    out[i] = 0;
}

static int build_socket_path(int pid, char *out, size_t out_size)
{
    char dir[PATH_MAX];
    int n;
    if (registry_directory(dir, sizeof(dir)) != 0) return -1;
    n = snprintf(out, out_size, "%s/mbx-%d.sock", dir, pid);
    if (n < 0 || (size_t)n >= out_size) {
        errno = ENAMETOOLONG;
        return -1;
    }
    return 0;
}

static int build_pid_path(int pid, char *out, size_t out_size)
{
    char dir[PATH_MAX];
    int n;
    if (registry_directory(dir, sizeof(dir)) != 0) return -1;
    n = snprintf(out, out_size, "%s/pid-%d", dir, pid);
    if (n < 0 || (size_t)n >= out_size) {
        errno = ENAMETOOLONG;
        return -1;
    }
    return 0;
}

static int build_name_path(const char *name, char *out, size_t out_size)
{
    char dir[PATH_MAX];
    char safe[POSTMAN_NAME_MAX + 1];
    int n;
    if (registry_directory(dir, sizeof(dir)) != 0) return -1;
    sanitize_name(name, safe, sizeof(safe));
    if (safe[0] == 0) {
        errno = EINVAL;
        return -1;
    }
    n = snprintf(out, out_size, "%s/name-%s", dir, safe);
    if (n < 0 || (size_t)n >= out_size) {
        errno = ENAMETOOLONG;
        return -1;
    }
    return 0;
}

static int write_registry_file(const char *path, int pid)
{
    char tmp[PATH_MAX];
    char text[64];
    int fd;
    int n;

    n = snprintf(tmp, sizeof(tmp), "%s.tmp-%d", path, (int)getpid());
    if (n < 0 || (size_t)n >= sizeof(tmp)) return -1;
    fd = open(tmp, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
    if (fd < 0) return -1;
    n = snprintf(text, sizeof(text), "%d\n", pid);
    if (write(fd, text, (size_t)n) != n) {
        int saved = errno;
        close(fd);
        unlink(tmp);
        errno = saved;
        return -1;
    }
    if (close(fd) != 0) {
        unlink(tmp);
        return -1;
    }
    if (rename(tmp, path) != 0) {
        unlink(tmp);
        return -1;
    }
    return 0;
}

static int read_registry_pid(const char *path)
{
    char text[64];
    char *end;
    long value;
    int fd;
    ssize_t got;

    fd = open(path, O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) return -1;
    got = read(fd, text, sizeof(text) - 1U);
    close(fd);
    if (got <= 0) return -1;
    text[got] = 0;
    errno = 0;
    value = strtol(text, &end, 10);
    if (errno != 0 || end == text || value <= 0 || value > INT_MAX) return -1;
    return (int)value;
}

static int process_is_alive(int pid)
{
    if (pid <= 0) return 0;
    if (kill(pid, 0) == 0) return 1;
    return errno == EPERM;
}

void initMessage(MSG *msg, int protocol, int type, int amount)
{
    if (msg == NULL) return;
    memset(msg, 0, sizeof(*msg));
    msg->magic1 = MSGBOX_MAGIC1;
    msg->magic2 = MSGBOX_MAGIC2;
    msg->isFree = MSG_RESERVED;
    msg->protocol = protocol;
    msg->type = type;
    msg->amount = amount;
}

int VerifyMessage(const MSG *msg)
{
    if (msg == NULL) return 0;
    if (msg->magic1 != MSGBOX_MAGIC1 || msg->magic2 != MSGBOX_MAGIC2) return 0;
    if (msg->amount < 0 || msg->amount > N_MAX_BYTES_PER_MSG) return 0;
    if (msg->protocol != MB_PROTOCOL_DC && msg->protocol != MB_PROTOCOL_POSTMAN &&
        msg->protocol != MB_PROTOCOL_GRAOS) return 0;
    return 1;
}

void initMessageBox(MSGBOX *box)
{
    if (box == NULL) return;
    memset(box, 0, sizeof(*box));
    box->fd = -1;
    box->isFree = 1;
}

MSGBOX *createMessageBox(void)
{
    MSGBOX *box = (MSGBOX *)malloc(sizeof(*box));
    if (box != NULL) initMessageBox(box);
    return box;
}

void destroyMessageBox(MSGBOX *box)
{
    if (box == NULL) return;
    if (box->fd >= 0) close(box->fd);
    if (box->socket_path[0] != 0) unlink(box->socket_path);
    free(box);
}

static void shutdown_at_exit(void)
{
    postmanShutdown();
}

int postmanSetProcessName(const char *name)
{
    char path[PATH_MAX];
    if (name == NULL || *name == 0) return 1;
    if (build_name_path(name, path, sizeof(path)) != 0) return 1;
    if (write_registry_file(path, postmanCurrentPID()) != 0) {
        set_error_text("write Postman name registry");
        return 1;
    }
    snprintf(process_box.name, sizeof(process_box.name), "%s", name);
    return 0;
}

int postmanInit(const char *process_name)
{
    struct sockaddr_un address;
    char dir[PATH_MAX];
    char pid_path[PATH_MAX];
    int fd = -1;
    int flags;
    int result = 1;

    pthread_mutex_lock(&process_lock);
    /* A forked child inherits the descriptor but not ownership of the parent mailbox. */
    if (process_box.active && process_box.owner_pid != (int)getpid()) {
        if (process_box.fd >= 0) close(process_box.fd);
        initMessageBox(&process_box);
    }
    if (process_box.active) {
        result = (process_name != NULL && *process_name != 0)
            ? postmanSetProcessName(process_name) : 0;
        pthread_mutex_unlock(&process_lock);
        return result;
    }
    if (ensure_registry_directory(dir, sizeof(dir)) != 0) goto done;
    initMessageBox(&process_box);
    process_box.owner_pid = (int)getpid();
    if (build_socket_path(process_box.owner_pid, process_box.socket_path,
                          sizeof(process_box.socket_path)) != 0) goto done;

    fd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (fd < 0) { set_error_text("socket Postman mailbox"); goto done; }
    flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0 || fcntl(fd, F_SETFL, flags | O_NONBLOCK) != 0 ||
        fcntl(fd, F_SETFD, FD_CLOEXEC) != 0) {
        set_error_text("configure Postman mailbox");
        goto done;
    }

    memset(&address, 0, sizeof(address));
    address.sun_family = AF_UNIX;
    snprintf(address.sun_path, sizeof(address.sun_path), "%s", process_box.socket_path);
    unlink(address.sun_path);
    if (bind(fd, (struct sockaddr *)&address, sizeof(address)) != 0) {
        set_error_text("bind Postman mailbox");
        goto done;
    }
    if (chmod(address.sun_path, 0600) != 0) {
        set_error_text("chmod Postman mailbox");
        goto done;
    }

    process_box.fd = fd;
    fd = -1;
    process_box.active = 1;
    process_box.isFree = 0;
    if (build_pid_path(process_box.owner_pid, pid_path, sizeof(pid_path)) != 0 ||
        write_registry_file(pid_path, process_box.owner_pid) != 0) {
        set_error_text("write Postman PID registry");
        goto done;
    }
    if (process_name != NULL && *process_name != 0 && postmanSetProcessName(process_name) != 0)
        goto done;
    if (!atexit_registered) {
        atexit(shutdown_at_exit);
        atexit_registered = 1;
    }
    last_error[0] = 0;
    result = 0;

done:
    if (fd >= 0) close(fd);
    if (result != 0 && process_box.active) {
        close(process_box.fd);
        unlink(process_box.socket_path);
        initMessageBox(&process_box);
    }
    pthread_mutex_unlock(&process_lock);
    return result;
}

int ActivateThreadMessageBox(int pid)
{
    if (pid != 0 && pid != (int)getpid()) {
        errno = EINVAL;
        snprintf(last_error, sizeof(last_error),
                 "Linux can activate only the current process mailbox");
        return 1;
    }
    return postmanInit(NULL);
}

int startMessageBox(void)
{
    return postmanInit(NULL);
}

int postmanCurrentPID(void)
{
    return (int)getpid();
}

void postmanShutdown(void)
{
    char pid_path[PATH_MAX];
    char name_path[PATH_MAX];

    pthread_mutex_lock(&process_lock);
    if (!process_box.active) {
        pthread_mutex_unlock(&process_lock);
        return;
    }
    if (process_box.owner_pid != (int)getpid()) {
        if (process_box.fd >= 0) close(process_box.fd);
        initMessageBox(&process_box);
        pthread_mutex_unlock(&process_lock);
        return;
    }
    if (process_box.name[0] != 0 &&
        build_name_path(process_box.name, name_path, sizeof(name_path)) == 0) {
        int registered = read_registry_pid(name_path);
        if (registered == process_box.owner_pid) unlink(name_path);
    }
    if (build_pid_path(process_box.owner_pid, pid_path, sizeof(pid_path)) == 0)
        unlink(pid_path);
    if (process_box.fd >= 0) close(process_box.fd);
    if (process_box.socket_path[0] != 0) unlink(process_box.socket_path);
    initMessageBox(&process_box);
    pthread_mutex_unlock(&process_lock);
}

int postmanFindProcess(const char *name)
{
    char path[PATH_MAX];
    char socket_path[108];
    int pid;
    if (name == NULL || *name == 0) return -1;
    if (build_name_path(name, path, sizeof(path)) != 0) return -1;
    pid = read_registry_pid(path);
    if (pid <= 0 || !process_is_alive(pid) ||
        build_socket_path(pid, socket_path, sizeof(socket_path)) != 0 ||
        access(socket_path, F_OK) != 0) {
        unlink(path);
        return -1;
    }
    return pid;
}

int postmanPurgeStale(void)
{
    char dir[PATH_MAX];
    DIR *directory;
    struct dirent *entry;

    if (ensure_registry_directory(dir, sizeof(dir)) != 0) return -1;
    directory = opendir(dir);
    if (directory == NULL) {
        set_error_text("open Postman registry");
        return -1;
    }
    while ((entry = readdir(directory)) != NULL) {
        char path[PATH_MAX];
        char socket_path[108];
        int pid = -1;
        int remove_entry = 0;

        if (strncmp(entry->d_name, "pid-", 4) == 0) {
            char *end;
            long value = strtol(entry->d_name + 4, &end, 10);
            if (*end == 0 && value > 0 && value <= INT_MAX) pid = (int)value;
            if (pid > 0 && !process_is_alive(pid)) remove_entry = 1;
        } else if (strncmp(entry->d_name, "name-", 5) == 0) {
            int n = snprintf(path, sizeof(path), "%s/%s", dir, entry->d_name);
            if (n > 0 && (size_t)n < sizeof(path)) pid = read_registry_pid(path);
            if (pid <= 0 || !process_is_alive(pid) ||
                build_socket_path(pid, socket_path, sizeof(socket_path)) != 0 ||
                access(socket_path, F_OK) != 0) remove_entry = 1;
        } else {
            continue;
        }

        if (remove_entry) {
            int n = snprintf(path, sizeof(path), "%s/%s", dir, entry->d_name);
            if (n > 0 && (size_t)n < sizeof(path)) unlink(path);
            if (pid > 0 && build_socket_path(pid, socket_path, sizeof(socket_path)) == 0)
                unlink(socket_path);
        }
    }
    closedir(directory);
    return 0;
}

int sendMessage(MSG *msg, int pid)
{
    struct sockaddr_un target;
    ssize_t sent;

    if (msg == NULL || pid <= 0) return 1;
    if (startMessageBox() != 0) return 1;
    if (!process_is_alive(pid)) {
        errno = ESRCH;
        set_error_text("Postman target process is not alive");
        return 1;
    }

    msg->magic1 = MSGBOX_MAGIC1;
    msg->magic2 = MSGBOX_MAGIC2;
    msg->isFree = MSG_RESERVED;
    msg->sndPID = postmanCurrentPID();
    msg->rcvPID = pid;
    msg->un = atomic_fetch_add_explicit(&packet_number, 1U, memory_order_relaxed);
    if (!VerifyMessage(msg)) {
        errno = EINVAL;
        snprintf(last_error, sizeof(last_error), "invalid Postman message");
        return 1;
    }

    memset(&target, 0, sizeof(target));
    target.sun_family = AF_UNIX;
    if (build_socket_path(pid, target.sun_path, sizeof(target.sun_path)) != 0) return 1;
    sent = sendto(process_box.fd, msg, sizeof(*msg), MSG_NOSIGNAL,
                  (struct sockaddr *)&target, sizeof(target));
    if (sent != (ssize_t)sizeof(*msg)) {
        set_error_text("send Postman message");
        if (errno == ENOENT || errno == ECONNREFUSED) {
            char pid_path[PATH_MAX];
            if (build_pid_path(pid, pid_path, sizeof(pid_path)) == 0) unlink(pid_path);
        }
        return 1;
    }
    return 0;
}

static int receive_now(MSG *out)
{
    ssize_t got;
    if (out == NULL || startMessageBox() != 0) return 0;
    got = recvfrom(process_box.fd, out, sizeof(*out), MSG_DONTWAIT, NULL, NULL);
    if (got < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) return 0;
        set_error_text("receive Postman message");
        return 0;
    }
    if (got != (ssize_t)sizeof(*out) || !VerifyMessage(out) ||
        out->rcvPID != postmanCurrentPID()) {
        errno = EBADMSG;
        snprintf(last_error, sizeof(last_error), "discarded malformed Postman packet");
        return 0;
    }
    return 1;
}

int receiveMessage(MSG *out)
{
    return receive_now(out);
}

int receiveMessageTimed(MSG *out, int timeout_ms)
{
    struct pollfd pfd;
    int result;
    if (out == NULL || startMessageBox() != 0) return 0;
    if (receive_now(out)) return 1;
    pfd.fd = process_box.fd;
    pfd.events = POLLIN;
    pfd.revents = 0;
    do {
        result = poll(&pfd, 1, timeout_ms);
    } while (result < 0 && errno == EINTR);
    if (result <= 0) return 0;
    return receive_now(out);
}

#endif
