# JTMOS Postman IPC and process launcher

This directory integrates the former Central Process/Postman sources with the
GRAOS shell module. The untouched historical source set is retained in
`legacy_jtmos/` for reference. The build uses the corrected portable files in
this directory instead of `legacy_jtmos/msgbox.c`.

## IPC transport

### JTMOS

`msgbox.c` keeps the historical `MSG`, `MSGBOX`, `sendMessage()`,
`receiveMessage()` and `startMessageBox()` API. Queue access is now atomic with
respect to JTMOS task switching: the mailbox slot search/copy/free operations
run while the previous EFLAGS interrupt state is preserved. Heap allocation is
performed before interrupts are disabled.

### Linux / SDL2

Each Linux process receives an `AF_UNIX/SOCK_DGRAM` mailbox under the private
`/tmp/jtmos-postman-UID/` directory. Complete fixed-size `MSG` packets are sent
atomically. A name registry maps `guiserver` to the GRAOS process PID. Socket
and registry permissions are restricted to the current user.

The Linux implementation supports actual separate processes; it is not merely
a pthread-only in-memory queue. `receiveMessageTimed()` uses `poll()` and the
normal `receiveMessage()` remains non-blocking.

## Synchronized GRAOS drawing

`guiServerPoll()` receives at most 32 queued packets per GUI frame. It executes
all window, button, refresh and frame-buffer changes in the GRAOS main thread.
SDL rendering therefore never occurs in a worker process or launcher thread.
Arrival order becomes the GUI work order.

Raw pointers in `GSID_ADDFRAMEBUFFER` remain valid only on JTMOS. Linux clients
must create a POSIX shared-memory object and call `addSharedFrameBuffer()`.
GRAOS maps it read-only and releases the mapping when the window closes.

## Process launching

`postman_process.c` provides one ordered launch queue. The Linux worker launches
commands in FIFO order using a detached `/bin/sh -c` child. The JTMOS branch
routes the same request to the existing `centralprocess_exec()` implementation.
GRAOS Start Menu and the shell `postman exec` command both use this queue.

## Shell commands

- `postman status`
- `postman find guiserver`
- `postman exec COMMAND...`
- `postman cleanup`

The aliases `pm` and `postman launch` are also accepted.

## Important integration rule

Remove the old `cp/msgbox.c` from the JTMOS kernel source list when enabling
`postman/msgbox.c`; otherwise duplicate symbols will be produced. The original
file is retained only in `legacy_jtmos/`.
