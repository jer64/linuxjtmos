#ifndef JTMOS_POSTMAN_MSGBOX_H
#define JTMOS_POSTMAN_MSGBOX_H

/*
 * JTMOS Postman IPC message boxes.
 *
 * JTMOS: keeps the historic in-kernel mailbox ABI.
 * Linux/SDL2: maps the same API to AF_UNIX datagram mailboxes so separate
 *             host processes can exchange complete MSG packets safely.
 */

#ifndef JTMOS
#include <stdint.h>
#include <stddef.h>
typedef uint8_t BYTE;
typedef uint16_t WORD;
typedef uint32_t DWORD;
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define MB_PROTOCOL_DC          12341234
#define MB_PROTOCOL_POSTMAN     46842632
#define MB_PROTOCOL_GRAOS       99436111

#define MSG_RESERVED            0x55555555U
#define MSG_FREE                0xAAAAAAAAU
#define ISFREEX                 0x00000010U

#define MSGBOX_MAGIC1           0x55AACCEEU
#define MSGBOX_MAGIC2           0xFF0088DDU

#ifdef JTMOS
#define N_MAX_QUEUED_MSGS       5
#else
#define N_MAX_QUEUED_MSGS       32
#endif
#define N_MAX_BYTES_PER_MSG     2048
#define POSTMAN_NAME_MAX        63

/* Portable Postman control message types. */
#define POSTMAN_MSG_PING        1
#define POSTMAN_MSG_PONG        2
#define POSTMAN_MSG_SHUTDOWN    3

typedef struct {
    DWORD magic1;
    DWORD isFree;
    int type;
    int protocol;
    int sndPID;
    int rcvPID;
    int amount;
    DWORD un;
    DWORD magic2;
    BYTE buf[N_MAX_BYTES_PER_MSG];
} MSG;

#ifdef JTMOS
typedef struct {
    char isFree;
    char name[256];
    MSG q[N_MAX_QUEUED_MSGS];
    int n_q;
} MSGBOX;
#else
typedef struct {
    int isFree;
    char name[256];
    int fd;
    int owner_pid;
    int active;
    char socket_path[108];
} MSGBOX;
#endif

MSGBOX *createMessageBox(void);
void destroyMessageBox(MSGBOX *box);
void initMessageBox(MSGBOX *box);
void initMessage(MSG *msg, int protocol, int type, int amount);

int VerifyMessage(const MSG *msg);
int sendMessage(MSG *msg, int pid);
int receiveMessage(MSG *out);
int receiveMessageTimed(MSG *out, int timeout_ms);
int ActivateThreadMessageBox(int pid);
int startMessageBox(void);

/* Cross-platform process/name helpers used by GRAOS and the shell. */
int postmanInit(const char *process_name);
void postmanShutdown(void);
int postmanSetProcessName(const char *process_name);
int postmanFindProcess(const char *process_name);
int postmanCurrentPID(void);
int postmanPurgeStale(void);
const char *postmanLastError(void);

#ifdef __cplusplus
}
#endif

#endif
