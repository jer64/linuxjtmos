#ifndef JTMOS_POSTMAN_PROCESS_H
#define JTMOS_POSTMAN_PROCESS_H

#ifdef __cplusplus
extern "C" {
#endif

#define POSTMAN_LAUNCH_QUEUE_MAX 32

int postmanProcessInit(void);
void postmanProcessShutdown(void);
int postmanLaunchQueued(const char *command, const char *work_directory);
int postmanLaunchImmediate(const char *command, const char *work_directory, int *pid_out);
int postmanLaunchQueueDepth(void);
const char *postmanProcessLastError(void);

#ifdef __cplusplus
}
#endif

#endif
