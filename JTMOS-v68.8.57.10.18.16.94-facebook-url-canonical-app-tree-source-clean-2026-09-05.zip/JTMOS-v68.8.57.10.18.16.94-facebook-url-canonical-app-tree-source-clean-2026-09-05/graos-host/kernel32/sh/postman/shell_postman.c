#include <stdio.h>
#include <string.h>
#include "msgbox.h"
#include "postman_process.h"
#include "shell_postman.h"

static void print_help(void)
{
    printf("Postman commands:\n");
    printf("  postman status             show IPC and launch queue status\n");
    printf("  postman find NAME          find a named Postman process\n");
    printf("  postman exec COMMAND...    queue a host/JTMOS program launch\n");
    printf("  postman cleanup            remove stale host registrations lazily\n");
}

static int join_arguments(int argc, char **argv, int first, char *out, size_t out_size)
{
    int i;
    size_t used = 0;
    if (out_size == 0U) return 0;
    out[0] = 0;
    for (i = first; i < argc; ++i) {
        int n;
        if (argv[i] == NULL) continue;
        n = snprintf(out + used, out_size - used, "%s%s", used ? " " : "", argv[i]);
        if (n < 0 || (size_t)n >= out_size - used) return 0;
        used += (size_t)n;
    }
    return used != 0U;
}

int postman_shell_main(int argc, char **argv)
{
    const char *subcommand = argc > 1 ? argv[1] : "status";

    if (postmanInit(NULL) != 0) {
        printf("Postman IPC initialization failed: %s\n", postmanLastError());
        return 1;
    }

    if (strcmp(subcommand, "status") == 0) {
        printf("Postman PID: %d\n", postmanCurrentPID());
        printf("GRAOS PID: %d\n", postmanFindProcess("guiserver"));
        printf("Launch queue depth: %d\n", postmanLaunchQueueDepth());
        return 0;
    }
    if (strcmp(subcommand, "find") == 0) {
        int pid;
        if (argc < 3) { print_help(); return 1; }
        pid = postmanFindProcess(argv[2]);
        printf("%s: %d\n", argv[2], pid);
        return pid > 0 ? 0 : 1;
    }
    if (strcmp(subcommand, "exec") == 0 || strcmp(subcommand, "launch") == 0) {
        char command[1024];
        if (!join_arguments(argc, argv, 2, command, sizeof(command))) {
            print_help();
            return 1;
        }
        if (!postmanLaunchQueued(command, ".")) {
            printf("Postman launch failed: %s\n", postmanProcessLastError());
            return 1;
        }
        printf("Queued: %s\n", command);
        return 0;
    }
    if (strcmp(subcommand, "cleanup") == 0) {
        int result = postmanPurgeStale();
        printf("Postman cleanup: %s\n", result == 0 ? "ok" : postmanLastError());
        return result != 0;
    }
    if (strcmp(subcommand, "help") == 0 || strcmp(subcommand, "--help") == 0) {
        print_help();
        return 0;
    }

    print_help();
    return 1;
}

int postman_shell_try_command(const char *command, int argc, char **argv)
{
    if (command == NULL) return POSTMAN_SHELL_NOT_HANDLED;
    if (strcmp(command, "postman") == 0 || strcmp(command, "pm") == 0)
        return postman_shell_main(argc, argv);
    return POSTMAN_SHELL_NOT_HANDLED;
}
