/* Ordered Postman application launcher. */
#ifdef JTMOS

#include "kernel32.h"
#include "legacy_jtmos/centralprocess.h"
#include "postman_process.h"

static char process_error[128];

const char *postmanProcessLastError(void) { return process_error; }
int postmanProcessInit(void) { process_error[0] = 0; return 0; }
void postmanProcessShutdown(void) { }
int postmanLaunchQueueDepth(void) { return 0; }

static void first_word(const char *command, char *out, int out_size)
{
    int i = 0;
    while (command != NULL && *command == ' ') ++command;
    while (command != NULL && *command != 0 && *command != ' ' && i + 1 < out_size)
        out[i++] = *command++;
    out[i] = 0;
}

int postmanLaunchImmediate(const char *command, const char *work_directory, int *pid_out)
{
    char executable[256];
    int pid;
    if (command == NULL || *command == 0) return 0;
    first_word(command, executable, sizeof(executable));
    pid = centralprocess_exec(executable, command,
                              GetCurrentDNR(), GetCurrentDB(),
                              (work_directory != NULL && *work_directory != 0)
                                  ? work_directory : "/",
                              GetCurrentTerminal());
    if (pid_out != NULL) *pid_out = pid;
    return pid > 0;
}

int postmanLaunchQueued(const char *command, const char *work_directory)
{
    return postmanLaunchImmediate(command, work_directory, NULL);
}

#else

#define _POSIX_C_SOURCE 200809L
#include "postman_process.h"

#include <pthread.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define COMMAND_MAX 1024
#define WORKDIR_MAX 512

typedef struct {
    char command[COMMAND_MAX];
    char work_directory[WORKDIR_MAX];
} LAUNCH_JOB;

static struct {
    pthread_mutex_t mutex;
    pthread_cond_t available;
    pthread_t worker;
    LAUNCH_JOB queue[POSTMAN_LAUNCH_QUEUE_MAX];
    int head;
    int tail;
    int count;
    int running;
    int initialized;
} launcher = {
    .mutex = PTHREAD_MUTEX_INITIALIZER,
    .available = PTHREAD_COND_INITIALIZER
};

static char process_error[256];

const char *postmanProcessLastError(void)
{
    return process_error[0] != 0 ? process_error : "no error";
}

static void set_process_error(const char *operation)
{
    int saved = errno;
    snprintf(process_error, sizeof(process_error), "%s: %s", operation, strerror(saved));
}

int postmanLaunchImmediate(const char *command, const char *work_directory, int *pid_out)
{
    int pipefd[2] = {-1, -1};
    pid_t first;
    pid_t grandchild = -1;
    ssize_t got;
    int status;

    if (pid_out != NULL) *pid_out = -1;
    if (command == NULL || *command == 0) {
        errno = EINVAL;
        set_process_error("empty launch command");
        return 0;
    }
    if (pipe(pipefd) != 0) {
        set_process_error("create launcher pipe");
        return 0;
    }
    first = fork();
    if (first < 0) {
        set_process_error("fork launcher");
        close(pipefd[0]); close(pipefd[1]);
        return 0;
    }
    if (first == 0) {
        pid_t second;
        close(pipefd[0]);
        second = fork();
        if (second < 0) _exit(126);
        if (second > 0) {
            (void)write(pipefd[1], &second, sizeof(second));
            _exit(0);
        }
        close(pipefd[1]);
        (void)setsid();
        if (work_directory != NULL && *work_directory != 0 && chdir(work_directory) != 0)
            _exit(125);
        execl("/bin/sh", "sh", "-c", command, (char *)NULL);
        _exit(127);
    }

    close(pipefd[1]);
    do { got = read(pipefd[0], &grandchild, sizeof(grandchild)); }
    while (got < 0 && errno == EINTR);
    close(pipefd[0]);
    do { status = 0; } while (waitpid(first, &status, 0) < 0 && errno == EINTR);
    if (got != (ssize_t)sizeof(grandchild) || grandchild <= 0 ||
        !WIFEXITED(status) || WEXITSTATUS(status) != 0) {
        errno = ECHILD;
        set_process_error("launch child process");
        return 0;
    }
    if (pid_out != NULL) *pid_out = (int)grandchild;
    process_error[0] = 0;
    return 1;
}

static void *launcher_worker(void *unused)
{
    (void)unused;
    for (;;) {
        LAUNCH_JOB job;
        pthread_mutex_lock(&launcher.mutex);
        while (launcher.running && launcher.count == 0)
            pthread_cond_wait(&launcher.available, &launcher.mutex);
        if (!launcher.running && launcher.count == 0) {
            pthread_mutex_unlock(&launcher.mutex);
            break;
        }
        job = launcher.queue[launcher.head];
        launcher.head = (launcher.head + 1) % POSTMAN_LAUNCH_QUEUE_MAX;
        --launcher.count;
        pthread_mutex_unlock(&launcher.mutex);
        (void)postmanLaunchImmediate(job.command, job.work_directory, NULL);
    }
    return NULL;
}

int postmanProcessInit(void)
{
    int result = 0;
    pthread_mutex_lock(&launcher.mutex);
    if (!launcher.initialized) {
        launcher.head = launcher.tail = launcher.count = 0;
        launcher.running = 1;
        if (pthread_create(&launcher.worker, NULL, launcher_worker, NULL) != 0) {
            launcher.running = 0;
            errno = EAGAIN;
            set_process_error("create Postman launcher thread");
            result = 1;
        } else {
            launcher.initialized = 1;
        }
    }
    pthread_mutex_unlock(&launcher.mutex);
    return result;
}

void postmanProcessShutdown(void)
{
    pthread_mutex_lock(&launcher.mutex);
    if (!launcher.initialized) {
        pthread_mutex_unlock(&launcher.mutex);
        return;
    }
    launcher.running = 0;
    pthread_cond_broadcast(&launcher.available);
    pthread_mutex_unlock(&launcher.mutex);
    pthread_join(launcher.worker, NULL);
    pthread_mutex_lock(&launcher.mutex);
    launcher.initialized = 0;
    launcher.count = launcher.head = launcher.tail = 0;
    pthread_mutex_unlock(&launcher.mutex);
}

int postmanLaunchQueued(const char *command, const char *work_directory)
{
    LAUNCH_JOB *job;
    if (command == NULL || *command == 0) return 0;
    if (postmanProcessInit() != 0) return 0;

    pthread_mutex_lock(&launcher.mutex);
    if (launcher.count >= POSTMAN_LAUNCH_QUEUE_MAX) {
        pthread_mutex_unlock(&launcher.mutex);
        errno = EAGAIN;
        set_process_error("Postman launch queue full");
        return 0;
    }
    job = &launcher.queue[launcher.tail];
    snprintf(job->command, sizeof(job->command), "%s", command);
    snprintf(job->work_directory, sizeof(job->work_directory), "%s",
             (work_directory != NULL && *work_directory != 0) ? work_directory : ".");
    launcher.tail = (launcher.tail + 1) % POSTMAN_LAUNCH_QUEUE_MAX;
    ++launcher.count;
    pthread_cond_signal(&launcher.available);
    pthread_mutex_unlock(&launcher.mutex);
    process_error[0] = 0;
    return 1;
}

int postmanLaunchQueueDepth(void)
{
    int count;
    pthread_mutex_lock(&launcher.mutex);
    count = launcher.count;
    pthread_mutex_unlock(&launcher.mutex);
    return count;
}

#endif
