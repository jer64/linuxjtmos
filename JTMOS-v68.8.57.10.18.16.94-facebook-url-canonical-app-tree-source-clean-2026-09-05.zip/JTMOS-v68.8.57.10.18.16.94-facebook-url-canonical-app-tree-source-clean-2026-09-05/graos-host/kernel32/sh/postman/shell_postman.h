#ifndef JTMOS_SHELL_POSTMAN_H
#define JTMOS_SHELL_POSTMAN_H

#define POSTMAN_SHELL_NOT_HANDLED (-32767)

int postman_shell_main(int argc, char **argv);
int postman_shell_try_command(const char *command, int argc, char **argv);

#endif
