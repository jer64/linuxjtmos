#ifndef __INCLUDED_LSAPP_H__
#define __INCLUDED_LSAPP_H__

//
extern int ls_app(int argc, char **argv);

#endif
