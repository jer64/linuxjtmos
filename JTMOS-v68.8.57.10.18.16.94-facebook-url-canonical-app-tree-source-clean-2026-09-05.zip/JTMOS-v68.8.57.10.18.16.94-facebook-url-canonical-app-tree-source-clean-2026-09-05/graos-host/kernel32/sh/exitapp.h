#ifndef __INCLUDED_EXITAPP_H__
#define __INCLUDED_EXITAPP_H__

//
int exit_app(int argc, char **argv);

#endif
