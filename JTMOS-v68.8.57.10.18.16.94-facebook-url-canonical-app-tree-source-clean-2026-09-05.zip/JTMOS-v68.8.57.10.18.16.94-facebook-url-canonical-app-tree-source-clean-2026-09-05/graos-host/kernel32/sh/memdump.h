#ifndef __INCLUDED_SMSH_MEMDUMP_H__
#define __INCLUDED_SMSH_MEMDUMP_H__

int kmed_main(int argc, char **argv);
int file_memory_dump_main(int argc, char **argv);

/* Historical names retained for kernel/debug callers. */
void DisplayMemory(char *buf, int sz, int offs, char memoryAddresses);
void DisplayMemory2(char *buf, int sz, int offs);

#endif
