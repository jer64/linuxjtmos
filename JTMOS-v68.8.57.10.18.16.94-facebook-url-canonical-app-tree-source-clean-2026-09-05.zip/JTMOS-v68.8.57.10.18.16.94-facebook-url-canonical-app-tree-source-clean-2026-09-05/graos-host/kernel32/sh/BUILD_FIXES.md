# SMSH build fixes

This source tree fixes the `sqa.c` errors and the additional build failures
that appeared after them.

## Build

The original SMSH target is 32-bit:

```sh
make clean
make
```

That requires the compiler's 32-bit development environment. On Debian or
Ubuntu this is normally provided by `gcc-multilib` and `libc6-dev-i386`.

For a native Linux host build without `-m32`:

```sh
make native
```

GRAOS/SDL2 remains buildable separately:

```sh
cd graos
make clean
make
```

## Main corrections

- Fixed the undeclared output descriptor in `put_unsigned()` and `put_hex32()`.
- Fixed the extra parentheses and the `prinotf()` typo in `sqa.c`.
- Restored fixed-width `BYTE`, `WORD` and `DWORD` types on Linux.
- Added the missing `SQA_INT32` and `SQA_UINT32` definitions.
- Replaced the untyped `char *` command table with typed function pointers.
- Replaced unsafe `gets()` with bounded `fgets()` input.
- Replaced the broken argument builders with a conventional argv parser.
- Added a weak GRAOS/Postman dispatcher hook. Linking the objects from
  `Makefile.graos` activates `gui`, `graos`, `postman` and `pm` commands.
- Corrected Linux `ls`, `cd`, SQA and NZIP type/prototype errors.
- Made NZIP decoding alignment-safe and added truncated-stream checks.
- Made the Makefile configurable and added `clean` and `native` targets.

## Validation performed

- Native Linux build with `-Wall -Wextra -Werror -Wformat=2`.
- Shell command and quoted-argument smoke test.
- SQA archive/create/extract round trip with byte-for-byte comparison.
- NZIP compress/extract round trip with byte-for-byte comparison.
- AddressSanitizer and UndefinedBehaviorSanitizer smoke tests.
- Separate GRAOS/SDL2 build.
