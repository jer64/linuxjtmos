#define _POSIX_C_SOURCE 200809L
/* sqaMain.c - POSIX-only command-line front end for the extractor */
#include <errno.h>
#include <stdio.h>
#include <string.h>
#ifndef JTMOS
#include <unistd.h>
#else
#include "kernel32.h"
#endif

#include "sqa.h"

#ifdef JTMOS
typedef long SQA_MAIN_IO_COUNT;
#else
typedef ssize_t SQA_MAIN_IO_COUNT;
#endif

static int copy_option(char *destination, size_t capacity, const char *source)
{
    size_t length;

    if (source == NULL) {
        return -1;
    }
    length = strlen(source);
    if (length >= capacity) {
        return -1;
    }
    memcpy(destination, source, length + 1U);
    return 0;
}

SQA_UINT32 syschksum(const BYTE *buf, size_t len)
{
    size_t i;
    SQA_UINT32 value = 0U;

    if (buf == NULL && len != 0U) {
        return 0U;
    }
    for (i = 0U; i < len; ++i) {
        value += (SQA_UINT32)buf[i] + 1U;
    }
    return value;
}

static void print_usage(const char *program)
{
    printf( "Squirrel Archive Extractor 1.0\n");
    printf( "(C) 2002-2026 by Jari Tuominen\n");
    printf( "Usage: ");
    printf("%s", program != NULL ? program : "sqa");
    printf( " archive.sqa [options]\n");
    printf( "Options:\n");
    printf( "  -q          quiet mode\n");
    printf( "  -u file     extract only the named file\n");
    printf( "  -o dir      write extracted files into dir\n");
}

int sqa_main(int argc, char **argv)
{
    int i;
    int result;

    if (argc < 2 || argv == NULL || argv[0] == NULL) {
        print_usage((argv != NULL) ? argv[0] : "sqa");
        return 0;
    }

    quiet = 0;
    specific[0] = '\0';
    dstdir[0] = '\0';

    for (i = 2; i < argc; ++i) {
        if (strcmp(argv[i], "-q") == 0) {
            quiet = 1;
        } else if (strcmp(argv[i], "-u") == 0) {
            ++i;
            if (i >= argc) {
                printf(
                         "Option -u requires a file name.\n");
                return 2;
            }
            if (copy_option(specific, sizeof(specific), argv[i]) != 0) {
                printf(
                         "File name supplied to -u is too long.\n");
                return 2;
            }
        } else if (strcmp(argv[i], "-o") == 0) {
            ++i;
            if (i >= argc) {
                printf(
                         "Option -o requires a directory.\n");
                return 2;
            }
            if (copy_option(dstdir, sizeof(dstdir), argv[i]) != 0) {
                printf(
                         "Directory supplied to -o is too long.\n");
                return 2;
            }
        } else {
            printf( "Unknown option: ");
            printf("%s", argv[i]);
            printf( "\n");
            return 2;
        }
    }

    seloffs = 0;
    result = extract_archive(argv[1], specific);

    if (result == 1) {
        seloffs = 640 * 1024;
        result = extract_archive(argv[1], specific);
    }

    if (result != 0 && !quiet) {
        printf( "Archive extraction failed.\n");
    }
    return result;
}
