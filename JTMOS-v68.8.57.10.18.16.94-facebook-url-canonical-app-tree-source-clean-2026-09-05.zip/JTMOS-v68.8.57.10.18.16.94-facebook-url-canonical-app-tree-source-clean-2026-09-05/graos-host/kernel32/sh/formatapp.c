//--------------------------------------------------------------------------------------------
// formatapp.c - SMSH JTMFS formatter command.
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include "formatapp.h"

int format_app(int argc, char **argv)
{
    int result;

    if(argc != 2)
    {
        printf("Usage: %s [device]\n", (argc > 0 && argv && argv[0]) ? argv[0] : "format");
        printf("Examples: format ram | format sys | format floppy | format hda\n");
        return 2;
    }

#ifdef JTMOS
    result = formatDrive(argv[1]);
    if(result != 0)
    {
        printf("Invalid device or formatting failed: '%s'\n", argv[1]);
        return 1;
    }
    printf("Formatting of drive %s completed.\n", argv[1]);
    return 0;
#else
    (void)result;
    printf("%s: formatting is disabled in the host test build.\n", argv[0]);
    return 1;
#endif
}
