//--------------------------------------------------------------------------------------------
// exitapp.c - Leave the System Maintenance Shell.
//--------------------------------------------------------------------------------------------
#include "exitapp.h"
#include "sh.h"

int exit_app(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    return SHELL_EXIT_REQUEST;
}
