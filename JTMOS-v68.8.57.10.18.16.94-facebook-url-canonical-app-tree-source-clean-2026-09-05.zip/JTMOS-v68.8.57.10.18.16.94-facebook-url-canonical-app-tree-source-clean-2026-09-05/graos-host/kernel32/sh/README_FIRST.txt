JTMOS GRAOS + LibSDL 2.0 shell integration
==========================================

Copy the included `sh/graos` directory and `sh/Makefile.graos` into
`kernel32/sh` in the JTMOS source tree.

Read first:
  sh/graos/SHELL_INTEGRATION.md

SDL2 host test:
  cd sh/graos
  make
  GRAOS_ASSET_DIR=. ./graos-sdl2

The uploaded GUI archive did not include the complete existing SMSH source
files, so the package uses a command adapter (`shell_graos.c`) and documents
the small dispatcher insertion instead of replacing an unknown sh.c version.
