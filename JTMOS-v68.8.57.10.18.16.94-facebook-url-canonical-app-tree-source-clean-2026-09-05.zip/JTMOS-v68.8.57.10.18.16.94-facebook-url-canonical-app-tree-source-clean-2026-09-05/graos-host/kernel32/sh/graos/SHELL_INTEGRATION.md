# SMSH integration

Add `sh/Makefile.graos` to the shell/kernel build and append
`$(GRAOS_OBJECTS) $(POSTMAN_OBJECTS)` to the linked object list.

The supplied `sh.c` already contains a weak call to
`graos_shell_try_command()` before its external-program path. Append
`$(GRAOS_OBJECTS) $(POSTMAN_OBJECTS)` to the final JTMOS link and the commands
become active automatically. If this directory is copied into an older shell,
add the adapter call manually before that shell's unknown-command path.

The adapter handles:

- `gui` and `graos`: enter the GRAOS server.
- `postman` and `pm`: Postman status, lookup, cleanup and process launching.

JTMOS must compile with `-DJTMOS -DGRAOS_EMBEDDED`. The new
`sh/postman/msgbox.c` replaces the old Central Process `msgbox.c`; do not link
both implementations.
