/* SMSH command adapter for the embedded GRAOS server. */
#include <string.h>
#include "graos.h"
#include "shell_graos.h"
#include "shell_postman.h"

int gui_main(int argc, char **argv)
{
    return graos_main(argc, argv);
}

int graos_shell_try_command(const char *command, int argc, char **argv)
{
    if (command == NULL) return GRAOS_SHELL_NOT_HANDLED;
    if (strcmp(command, "gui") == 0 || strcmp(command, "graos") == 0)
        return gui_main(argc, argv);
    {
        int result = postman_shell_try_command(command, argc, argv);
        if (result != POSTMAN_SHELL_NOT_HANDLED) return result;
    }
    return GRAOS_SHELL_NOT_HANDLED;
}
