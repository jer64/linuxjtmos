#ifndef JTMOS_SHELL_GRAOS_H
#define JTMOS_SHELL_GRAOS_H

#define GRAOS_SHELL_NOT_HANDLED (-32767)

int gui_main(int argc, char **argv);
int graos_shell_try_command(const char *command, int argc, char **argv);

#endif /* JTMOS_SHELL_GRAOS_H */
