//--------------------------------------------------------------------------------------------
// ls.c - Directory displayer kernel mode application.
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#ifndef JTMOS
#include <unistd.h>
#else
#include "kernel32.h"
#endif
#include "formatapp.h"

// Dir function (ls)
// -----------------
//
// This function outputs directory from specified block(linear) to stdout.
int chdir_app(int argc, char **argv)
{
	//
	if(argc<2)
	{
		printf("Usage: chdir [path]\n");
	}
	else
	{
		if (chdir(argv[1]) != 0) {
#ifndef JTMOS
			perror("chdir");
#else
			printf("chdir failed: %s\n", argv[1]);
#endif
			return 1;
		}
	}
	return 0;
}

