APPNAME=pdump
include app-common.mk
