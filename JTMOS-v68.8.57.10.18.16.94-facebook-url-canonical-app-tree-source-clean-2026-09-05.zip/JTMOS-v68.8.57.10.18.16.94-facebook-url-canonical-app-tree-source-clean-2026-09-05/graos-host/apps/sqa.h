#ifndef JTMOS_SQA_H
#define JTMOS_SQA_H

/* SQARC520 is a fixed little-endian wire format.  Never fwrite()/read() the
 * C structure itself: the explicit 44-byte layout is part of the ABI. */
#if defined(JTMOSKERNEL)
#include "basdef.h"
typedef signed long SQA_INT32;
typedef unsigned long SQA_UINT32;
#elif defined(JTMOS_APPLICATION)
#include <stddef.h>
#include <stdint.h>
#include <jtmos/types.h>
typedef int32_t SQA_INT32;
typedef uint32_t SQA_UINT32;
#else
#include <stddef.h>
#include <stdint.h>
typedef uint8_t BYTE;
typedef uint16_t WORD;
typedef uint32_t DWORD;
typedef int32_t SQA_INT32;
typedef uint32_t SQA_UINT32;
#endif

#define SQA_IDENTIFIER       "SQARC520"
#define SQA_IDENTIFIER_SIZE  8U
#define SQA_SAFE_AREA_SIZE   2048L
#define SQA_MAX_FILES        10000U
#define SQA_FILENAME_SIZE    31U
#define SQA_DISK_ENTRY_SIZE  44U
#define SQA_COPY_BUFFER_SIZE 32768U

/* In-memory representation; the on-disk representation is always encoded
 * field-by-field as 31+1+4+4+4 bytes. */
typedef struct FE {
    char fname[SQA_FILENAME_SIZE];
    BYTE reserved;
    DWORD offset;
    DWORD length;
    DWORD chksum;
} FE;

typedef struct SQDSK {
    WORD nr_files;
    FE *entries;
    char identifier[SQA_IDENTIFIER_SIZE + 1U];
    long data_offset;
    long archive_size;
} SQDSK;

extern SQDSK sqdsk;
extern int quiet;
extern char specific[256];
extern char dstdir[256];
extern int seloffs;

SQA_UINT32 syschksum(const BYTE *buf, size_t len);
int extract_archive(const char *fname, const char *spec);
int archive(const char *pathx, const char *dst);
int archive1(const char *pathx, const char *dst);
int sqa_main(int argc, char **argv);
int sqarc_main(int argc, char **argv);

#endif
