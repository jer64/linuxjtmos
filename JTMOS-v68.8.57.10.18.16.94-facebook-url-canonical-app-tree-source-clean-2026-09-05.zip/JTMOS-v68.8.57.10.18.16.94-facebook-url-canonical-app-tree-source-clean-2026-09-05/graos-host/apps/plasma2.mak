# JTMOS V67 static ELF32 application
APPNAME=plasma2
include app-common.mk
