# JTMOS V67 static ELF32 application
APPNAME=ren
include app-common.mk
