# JTMOS V67 static ELF32 application
APPNAME=memconfig
include app-common.mk
