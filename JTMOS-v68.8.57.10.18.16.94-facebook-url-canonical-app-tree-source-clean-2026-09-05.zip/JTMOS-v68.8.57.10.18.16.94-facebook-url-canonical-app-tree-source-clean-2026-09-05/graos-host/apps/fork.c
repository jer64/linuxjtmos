#include <stdio.h>
#include <unistd.h>
#include <jtmos/process.h>

int main(void)
{
    pid_t child;
    int me = getpid();

    printf("JTMOS fork test 1.0: parent PID=%d\n", me);
    child = fork();
    if(child < 0)
    {
        printf("fork: failed\n");
        return 1;
    }

    if(child == 0)
    {
        printf("fork: child PID=%d, fork()=0\n", getpid());
        return 0;
    }

    printf("fork: parent PID=%d, child PID=%d\n", getpid(), child);
    WaitProcessTermination(child);
    printf("fork: child PID=%d terminated\n", child);
    return 0;
}
