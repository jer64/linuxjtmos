/* vgaplasma.c - historical VGA plasma converted to a GraOS window framebuffer. */
#include <stdlib.h>
#include <math.h>
#include <jtmos/process.h>
#include "graos_demo.h"
SYSMEMREQ(APPRAM_512K)
#define W 320
#define H 200
static BYTE *stab;
static void build_sine(void)
{
    int i; double a=0.0;
    for(i=0;i<65536;i++,a+=0.014) stab[i]=(BYTE)(128+(int)(127.0*sin(a)));
}
static void render(JTMOS_GRAOS_DEMO *d,unsigned long cycle)
{
    int x,y; unsigned long tick=GetTickCount(); unsigned int a,v;
    for(y=0;y<H;y++) for(x=0;x<W;x++) {
        a=(unsigned int)stab[(x+tick)&65535]
          +(unsigned int)stab[(y+tick)&65535]
          +(unsigned int)stab[(x-(tick>>1))&65535]
          +(unsigned int)stab[(y-(tick>>2))&65535]
          +(unsigned int)cycle;
        v=((unsigned int)stab[a&65535]>>2)+64U;
        d->pixels[y*W+x]=GRAOS_RGB((v*2U)&255U,(255U-v),((v+cycle)*3U)&255U);
    }
}
int main(void)
{
    JTMOS_GRAOS_DEMO d; unsigned long cycle=0; int key;
    stab=(BYTE*)malloc(65536); if(!stab) return 1; build_sine();
    if(jtmos_demo_open(&d,"VGA Plasma - GraOS window - Esc closes",W,H)!=0) { free(stab); return 2; }
    for(;;) {
        key=jtmos_demo_poll(&d); if(key<0 || key==27) break;
        if(!d.focused) { jtmos_demo_idle(30); continue; }
        render(&d,cycle++); if(jtmos_demo_present(&d)<0) break;
        jtmos_demo_idle(35);
    }
    jtmos_demo_close(&d); free(stab); return 0;
}
