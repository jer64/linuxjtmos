/*
 * Lar - LU format library file maintainer
 * by Stephen C. Hemminger
 *	linus!sch	or	sch@Mitre-Bedford
 *
 *  Usage: lar key library [files] ...
 *
 *  Key functions are:
 *	u - Update, add files to library
 *	t - Table of contents
 *	e - Extract files from library
 *	p - Print files in library
 *	d - Delete files in library
 *	r - Reorginize library
 *  Other keys:
 *	v - Verbose
 *
 *  This program is public domain software, no warranty intended or
 *  implied.
 *
 *  DESCRPTION
 *     Lar is a Unix program to manipulate CP/M LU format libraries.
 *     The original CP/M library program LU is the product
 *     of Gary P. Novosielski. The primary use of lar is to combine several
 *     files together for upload/download to a personal computer.
 *
 *  PORTABILITY
 *     The code is modeled after the Software tools archive program,
 *     and is setup for Version 7 Unix.  It does not make any assumptions
 *     about byte ordering, explict and's and shift's are used.
 *     If you have a dumber C compiler, you may have to recode new features
 *     like structure assignment, typedef's and enumerated types.
 *
 *  BUGS/MISFEATURES
 *     The biggest problem is text files, the programs tries to detect
 *     text files vs. binaries by checking for non-Ascii (8th bit set) chars.
 *     If the file is text then it will throw away Control-Z chars which
 *     CP/M puts on the end.  All files in library are padded with Control-Z
 *     at the end to the CP/M sector size if necessary.
 *
 *     No effort is made to handle the difference between CP/M and Unix
 *     end of line chars.  CP/M uses Cr/Lf and Unix just uses Lf.
 *     The solution is just to use the Unix command sed when necessary.
 *
 *  * Unix is a trademark of Bell Labs.
 *  ** CP/M is a trademark of Digital Research.
 */

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#ifndef JTMOS
#include <jtmos/app_port.h>
#endif

#define ACTIVE	00
#define UNUSED	0xff
#define DELETED 0xfe
#define CTRLZ	0x1a

#define MAXFILES 256
#define SECTOR	 128
#define DSIZE	( sizeof(struct ludir) )
#define SLOTS_SEC (SECTOR/DSIZE)
#define equal(s1, s2) ( strcmp(s1,s2) == 0 )
/* if you don't have void type just define as blank */
#define VOID	(void)

#if defined(__GNUC__)
#define NORETURN __attribute__((noreturn))
#else
#define NORETURN
#endif

/* if no enum's then define false as 0 and true as 1 and bool as int */
typedef enum {false=0, true=1} bool;

/* Globals */
char   *fname[MAXFILES+1];
bool ftouched[MAXFILES];

typedef struct {
    unsigned char   lobyte;
    unsigned char   hibyte;
} word;

/* convert word to int */
#define wtoi(w) ( (w.hibyte<<8) + w.lobyte)
#define itow(dst,src)	dst.hibyte = (src & 0xff00) >> 8;\
				dst.lobyte = src & 0xff;

struct ludir {			/* Internal library ldir structure */
    unsigned char   l_stat;	/*  status of file */
    char    l_name[8];		/*  name */
    char    l_ext[3];		/*  extension */
    word    l_off;		/*  offset in library */
    word    l_len;		/*  length of file */
    char    l_fill[16];		/*  pad to 32 bytes */
} ldir[MAXFILES];

int     errcnt, nfiles, nslots;
bool	verbose = false;
char	*cmdname;

static void help(void) NORETURN;
static void conflict(void) NORETURN;
static void error(const char *str) NORETURN;
static void cant(const char *name) NORETURN;
static void filenames(int ac,char **av);
static void table(char *lib);
static void getdir(FILE *f);
static void putdir(FILE *f);
static void initdir(FILE *f);
static char *getname(char *nm,char *ex);
static void putname(char *cpmname,const char *unixname);
static int filarg(char *name);
static void not_found(void);
static void extract(char *name);
static void print_members(char *name);
static void getfiles(char *name,bool pflag);
static void acopy(FILE *fdi,FILE *fdo,unsigned int nsecs);
static void update(char *name);
static void addfil(char *name,FILE *lfd);
static int fcopy(FILE *ifd,FILE *ofd);
static void delete(char *lname);
static void reorg(char *name);
static void copyentry(struct ludir *old,FILE *of,struct ludir *new,FILE *nf);
static void copymem(char *dst,const char *src,unsigned int n);

int main(int argc,char **argv)
{
    register char *flagp;
    char   *aname;			/* name of library file */
    void   (*function)(char *) = NULL;	/* function to do on library */
/* set the function to be performed, but detect conflicts */
#define setfunc(val) do { if(function != NULL) conflict(); else function = val; } while(0)

    cmdname = argc>0 && argv[0] ? argv[0] : "lar";
    if (argc < 3)
	help ();

    aname = argv[2];
    filenames (argc, argv);

    for(flagp = argv[1]; *flagp; flagp++)
	switch (*flagp) {
	case 'u': 
	    setfunc(update);
	    break;
	case 't': 
	    setfunc(table);
	    break;
	case 'e': 
	    setfunc(extract);
	    break;
	case 'p': 
	    setfunc(print_members);
	    break;
	case 'd': 
	    setfunc(delete);
	    break;
	case 'r': 
	    setfunc(reorg);
	    break;
	case 'v':
	    verbose = true;
	    break;
	default: 
	    help ();
    }

    if(function == NULL) {
	fprintf(stderr,"No function key letter specified\n");
	help();
    }

    (*function)(aname);
    return errcnt==0 ? 0 : 1;
}

/* print error message and exit */
static void help(void)
{
    fprintf (stderr, "Usage: %s {utepdr}[v] library [files] ...\n", cmdname);
    fprintf (stderr, "Functions are:\n\tu - Update, add files to library\n");
    fprintf (stderr, "\tt - Table of contents\n");
    fprintf (stderr, "\te - Extract files from library\n");
    fprintf (stderr, "\tp - Print files in library\n");
    fprintf (stderr, "\td - Delete files in library\n");
    fprintf (stderr, "\tr - Reorginize library\n");

    fprintf (stderr, "Flags are:\n\tv - Verbose\n");
    exit (1);
    for (;;) { }
}

static void conflict(void)
{
   fprintf(stderr,"Conficting keys\n");
   help();
}

static void error(const char *str)
{
    fprintf (stderr, "%s: %s\n", cmdname, str);
    exit (1);
    for (;;) { }
}

static void cant(const char *name)
{
    fprintf(stderr,"%s: I/O error %d\n",name,errno);
    exit (1);
    for (;;) { }
}

/* Get file names, check for dups, and initialize */
static void filenames(int ac,char **av)
{
    register int    i, j;
    int count;

    errcnt = 0;
    count=ac-3;
    if(count<0) count=0;
    if(count>MAXFILES)
        error("Too many file names.");
    for (i = 0; i < count; i++) {
	fname[i] = av[i + 3];
	ftouched[i] = false;
    }
    fname[i] = NULL;
    nfiles = i;
    for (i = 0; i < nfiles; i++)
	for (j = i + 1; j < nfiles; j++)
	    if (equal (fname[i], fname[j])) {
		fprintf (stderr, "%s", fname[i]);
		error (": duplicate file name");
	    }
}

static void table(char *lib)
{
    FILE   *lfd;
    register int    i, total;
    int active = 0, unused = 0, deleted = 0;
    char *uname;

    if ((lfd = fopen (lib, "rb")) == NULL)
	cant (lib);

    getdir (lfd);
    total = wtoi(ldir[0].l_len);
    if(verbose) {
 	printf("Name          Index Length\n");
	printf("Directory           %4d\n", total);
    }

    for (i = 1; i < nslots; i++)
	switch(ldir[i].l_stat) {
	case ACTIVE:
		active++;
		uname = getname(ldir[i].l_name, ldir[i].l_ext);
			if (filarg (uname)) {
			    if(verbose) {
				printf ("%-12s   %4d %4d\n", uname,
				    wtoi (ldir[i].l_off), wtoi (ldir[i].l_len));
			    } else {
				printf ("%s\n", uname);
			    }
			}
		total += wtoi(ldir[i].l_len);
		break;
	case UNUSED:
		unused++;
		break;
	default:
		deleted++;
	}
    if(verbose) {
	printf("--------------------------\n");
	printf("Total sectors       %4d\n", total);
	printf("\nLibrary %s has %d slots, %d deleted %d active, %d unused\n",
		lib, nslots, deleted, active, unused);
    }

    VOID fclose (lfd);
    not_found ();
}

static void getdir(FILE *f)
{
    int remaining;

    rewind(f);

    if (fread ((char *) & ldir[0], DSIZE, 1, f) != 1)
	error ("No directory\n");

    nslots = wtoi (ldir[0].l_len) * SLOTS_SEC;
    if(nslots<1 || nslots>MAXFILES)
	error("Invalid directory size");
    remaining=nslots-1;
    if(remaining>0 &&
       fread((char *)&ldir[1],DSIZE,(size_t)remaining,f)!=(size_t)remaining)
	error ("Can't read directory - is it a library?");
}

static void putdir(FILE *f)
{

    rewind(f);
    if(nslots<1 || nslots>MAXFILES)
	error("Invalid directory size");
    if(fwrite((char *)ldir,DSIZE,(size_t)nslots,f)!=(size_t)nslots)
	error ("Can't write directory - library may be botched");
}

static void initdir(FILE *f)
{
    register int    i;
    int     numsecs;
    char    line[80];
    static struct ludir blankentry = {
	UNUSED,
	{ ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
	{ ' ', ' ', ' ' },
	{ 0, 0 },
	{ 0, 0 },
	{ 0 }
    };

    for (;;) {
	printf ("Number of slots to allocate: ");
	if (fgets (line, 80, stdin) == NULL)
	    error ("Eof when reading input");
	nslots = atoi (line);
	if (nslots < 1)
	    printf ("Must have at least one!\n");
	else if (nslots > MAXFILES)
	    printf ("Too many slots\n");
	else
	    break;
    }

    numsecs = (nslots+SLOTS_SEC-1) / SLOTS_SEC;
    nslots = numsecs * SLOTS_SEC;
    if(nslots>MAXFILES)
	error("Too many directory slots");

    for (i = 0; i < nslots; i++)
	ldir[i] = blankentry;
    ldir[0].l_stat = ACTIVE;
    itow (ldir[0].l_len, numsecs);

    putdir (f);
}

/* convert nm.ex to a Unix style string */
static char *getname(char *nm,char *ex)
{
    static char namebuf[14];
    register char  *cp, *dp;

    for (cp = namebuf, dp = nm; dp != &nm[8] && *dp != ' ';) {
	unsigned char ch=(unsigned char)*dp++;
	*cp++ = (char)(isupper(ch) ? tolower(ch) : ch);
    }
    *cp++ = '.';

    for (dp = ex; dp != &ex[3] && *dp != ' ';) {
	unsigned char ch=(unsigned char)*dp++;
	*cp++ = (char)(isupper(ch) ? tolower(ch) : ch);
    }

    *cp = '\0';
    return namebuf;
}

static void putname(char *cpmname,const char *unixname)
{
    const char *base,*p,*dot=NULL,*end;
    int i,truncated=0;

    memset(cpmname,' ',11);
    if(!unixname) return;
    base=unixname;
    for(p=unixname;*p;p++) {
	if(*p=='/' || *p=='\\') { base=p+1;dot=NULL; }
	else if(p>=base && *p=='.') dot=p;
    }
    end=p;
    if(dot==base) dot=NULL;

    p=base;
    for(i=0;i<8 && p<end && (!dot || p<dot);i++,p++) {
	unsigned char ch=(unsigned char)*p;
	cpmname[i]=(char)(islower(ch)?toupper(ch):ch);
    }
    if(p<end && (!dot || p<dot)) truncated=1;

    if(dot) {
	p=dot+1;
	for(i=0;i<3 && p<end;i++,p++) {
	    unsigned char ch=(unsigned char)*p;
	    cpmname[8+i]=(char)(islower(ch)?toupper(ch):ch);
	}
	if(p<end) truncated=1;
    }
    if(truncated) fprintf(stderr,"%s: name truncated\n",unixname);
}

/* filarg - check if name matches argument list */
static int filarg(char *name)
{
    register int    i;

    if (nfiles <= 0)
	return 1;

    for (i = 0; i < nfiles; i++)
	if (equal (name, fname[i])) {
	    ftouched[i] = true;
	    return 1;
	}

    return 0;
}

static void not_found(void)
{
    register int    i;

    for (i = 0; i < nfiles; i++)
	if (!ftouched[i]) {
	    fprintf (stderr, "%s: not in library.\n", fname[i]);
	    errcnt++;
	}
}


static void extract(char *name)
{
	getfiles(name, false);
}

static void print_members(char *name)
{
	getfiles(name, true);
}

static void getfiles(char *name,bool pflag)
{
    FILE *lfd, *ofd;
    register int    i;
    char   *unixname;

    if ((lfd = fopen (name, "rb"))  == NULL)
	cant (name);

    ofd = pflag ? stdout : NULL;
    getdir (lfd);

    for (i = 1; i < nslots; i++) {
	if(ldir[i].l_stat != ACTIVE)
		continue;
	unixname = getname (ldir[i].l_name, ldir[i].l_ext);
	if (!filarg (unixname))
	    continue;
	fprintf(stderr,"%s", unixname);
	if (ofd != stdout)
	    ofd = fopen (unixname, "wb");
	if (ofd == NULL) {
	    fprintf (stderr, "  - can't create");
	    errcnt++;
	}
	else {
	    VOID fseek (lfd, (long) wtoi (ldir[i].l_off) * SECTOR, 0);
	    acopy (lfd, ofd, wtoi (ldir[i].l_len));
	    if (ofd != stdout)
		VOID fclose (ofd);
	}
	putc('\n', stderr);
    }
    VOID fclose (lfd);
    not_found ();
}

static void acopy(FILE *fdi,FILE *fdo,unsigned int nsecs)
{
    register int    i, c;
    int	    textfile = 1;

    while( nsecs-- != 0) 
	for(i=0; i<SECTOR; i++) {
		c = getc(fdi);
		if( feof(fdi) ) 
			error("Premature EOF\n");
		if( ferror(fdi) )
		    error ("Can't read");
		if( !isascii(c) )
		    textfile = 0;
		if( nsecs != 0 || !textfile || c != CTRLZ) {
			putc(c, fdo);
			if ( ferror(fdo) )
			    error ("write error");
		}
	 }
}

static void update(char *name)
{
    FILE *lfd;
    register int    i;

    if ((lfd = fopen (name, "r+b")) == NULL) {
	if ((lfd = fopen (name, "w+b")) == NULL)
	    cant (name);
	initdir (lfd);
    }
    else
	getdir (lfd);		/* read old directory */

    if(verbose)
	    fprintf (stderr,"Updating files:\n");
    for (i = 0; i < nfiles; i++)
	addfil (fname[i], lfd);
    if (errcnt == 0)
	putdir (lfd);
    else
	fprintf (stderr, "fatal errors - library not changed\n");
    VOID fclose (lfd);
}

static void addfil(char *name,FILE *lfd)
{
    FILE	*ifd;
    register int secoffs, numsecs;
    register int i;
    char cpmname[11],member[14];

    if ((ifd = fopen (name, "rb")) == NULL) {
	fprintf (stderr, "%s: can't find to add\n",name);
	errcnt++;
	return;
    }
    if(verbose)
        fprintf(stderr, "%s\n", name);
    putname(cpmname,name);
    strcpy(member,getname(cpmname,cpmname+8));
    for (i = 1; i < nslots; i++) {
	if (equal( getname (ldir[i].l_name, ldir[i].l_ext), member) ) /* update */
	    break;
	if (ldir[i].l_stat != ACTIVE)
		break;
    }
    if (i >= nslots) {
	fprintf (stderr, "%s: can't add library is full\n",name);
	errcnt++;
	VOID fclose(ifd);
	return;
    }

    ldir[i].l_stat = ACTIVE;
    copymem(ldir[i].l_name,cpmname,8);
    copymem(ldir[i].l_ext,cpmname+8,3);
    VOID fseek(lfd, 0L, 2);		/* append to end */
    secoffs = ftell(lfd) / SECTOR;

    itow (ldir[i].l_off, secoffs);
    numsecs = fcopy (ifd, lfd);
    itow (ldir[i].l_len, numsecs);
    VOID fclose (ifd);
}

static int fcopy(FILE *ifd,FILE *ofd)
{
    register int total = 0;
    register int i, n;
    char sectorbuf[SECTOR];


    while ( (n = fread( sectorbuf, 1, SECTOR, ifd)) != 0) {
	if (n != SECTOR)
	    for (i = n; i < SECTOR; i++)
		sectorbuf[i] = CTRLZ;
	if (fwrite( sectorbuf, 1, SECTOR, ofd ) != SECTOR)
		error("write error");
	++total;
    }
    if(ferror(ifd))
	error("read error");
    return total;
}

static void delete(char *lname)
{
    FILE *f;
    register int    i;

    if ((f = fopen (lname, "r+b")) == NULL)
	cant (lname);

    if (nfiles <= 0)
	error("delete by name only");

    getdir (f);
    for (i = 1; i < nslots; i++) {
	if (!filarg ( getname (ldir[i].l_name, ldir[i].l_ext)))
	    continue;
	ldir[i].l_stat = DELETED;
    }

    not_found();
    if (errcnt > 0)
	fprintf (stderr, "errors - library not updated\n");
    else
	putdir (f);
    VOID fclose (f);
}

static void reorg(char *name)
{
    FILE *olib, *nlib;
    int oldsize;
    register int i, j;
    struct ludir odir[MAXFILES];
    char tmpname[SECTOR];
    int tmp_len;

    tmp_len=snprintf(tmpname,sizeof(tmpname),"%s.TMP",name);
    if(tmp_len<0 || tmp_len>=(int)sizeof(tmpname))
	error("temporary file name too long");

    if( (olib = fopen(name,"rb")) == NULL)
	cant(name);

    if( (nlib = fopen(tmpname, "wb")) == NULL)
	cant(tmpname);

    getdir(olib);
    printf("Old library has %d slots\n", oldsize = nslots);
    for(i = 0; i < nslots ; i++)
	    copymem( (char *) &odir[i], (char *) &ldir[i],
			sizeof(struct ludir));
    initdir(nlib);
    errcnt = 0;

    for (i = j = 1; i < oldsize; i++)
	if( odir[i].l_stat == ACTIVE ) {
	    if (j >= nslots) {
		errcnt++;
		fprintf(stderr, "Not enough room in new library\n");
		break;
	    }
	    if(verbose)
		fprintf(stderr, "Copying: %-8.8s.%3.3s\n",
			odir[i].l_name, odir[i].l_ext);
	    copyentry( &odir[i], olib,  &ldir[j], nlib);
	    ++j;
        }

    VOID fclose(olib);
    putdir(nlib);
    VOID fclose (nlib);

    if(errcnt == 0) {
	if(unlink(name)<0)
	    cant(name);
	if(rename(tmpname,name)<0) {
	    fprintf(stderr,
	            "lar: replacement failed; recovered archive remains in %s\n",
	            tmpname);
	    errcnt++;
	    return;
	}
    }
    else
	fprintf(stderr,"Errors, library not updated\n");
    if(errcnt!=0)
	VOID unlink(tmpname);

}

static void copyentry(struct ludir *old,FILE *of,struct ludir *new,FILE *nf)
{
    register int secoffs, numsecs;
    char buf[SECTOR];

    new->l_stat = ACTIVE;
    copymem(new->l_name, old->l_name, 8);
    copymem(new->l_ext, old->l_ext, 3);
    VOID fseek(of, (long) wtoi(old->l_off)*SECTOR, 0);
    VOID fseek(nf, 0L, 2);
    secoffs = ftell(nf) / SECTOR;

    itow (new->l_off, secoffs);
    numsecs = wtoi(old->l_len);
    itow (new->l_len, numsecs);

    while(numsecs-- != 0) {
	if( fread( buf, 1, SECTOR, of) != SECTOR)
	    error("read error");
	if( fwrite( buf, 1, SECTOR, nf) != SECTOR)
	    error("write error");
    }
}

static void copymem(char *dst,const char *src,unsigned int n)
{
	while(n-- != 0)
		*dst++ = *src++;
}
