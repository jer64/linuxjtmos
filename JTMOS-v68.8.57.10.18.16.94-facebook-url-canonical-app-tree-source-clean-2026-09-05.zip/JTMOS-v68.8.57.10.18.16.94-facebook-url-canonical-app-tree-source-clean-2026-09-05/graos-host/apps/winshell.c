// winshell.c - legacy GraOS terminal window shell, V67.8.57.6
#include <stdio.h>
#include <conio.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/process.h>

#define LOG_TO_FILE
SYSMEMREQ(APPRAM_256K)
static FILE *log;

static void terminalEmulationWindow(int wid,int terID,int *child_pid)
{
    GUICMD ev;
    int er,server_closed=0;
    if(addFrameBuffer(wid,NULL,0,16,80,25,0,GRAOS_SURFACE_TERMINAL,terID)<0) {
        fprintf(log,"winshell: addFrameBuffer failed\n");
        return;
    }
    refreshWindow(wid);
    for(;;) {
        while((er=JtmosGraOSPollEvent(wid,&ev))>0) {
            if(ev.id==GRAOS_GSID_EXIT) { server_closed=1; goto out; }
            /* Terminal surfaces are fed directly by the GraOS server.  Keep
             * this fallback for older servers that still forward key events. */
            if(ev.id==GRAOS_GSID_KEYPRESSED)
                OutputTerminalKeyboardBuffer(terID,ev.v[0]);
        }
        if(er<0) { server_closed=1; goto out; }
        if(child_pid && *child_pid>0 && GetThreadMemoryUsage(*child_pid)==0) {
            *child_pid=0;
            goto out;
        }
        SwitchToThread();
        Sleep(10);
    }
out:
    if(!server_closed) closeWindow(wid);
}

int main(int argc,char **argv)
{
    int wid=-1,terID=-1,pid=0;
    char fname[256];

    if(connectGraos()!=0) { printf("winshell: GraOS is not running.\n"); return 1; }
    if(snprintf(fname,sizeof(fname),"winshell%d.log",GetCurrentThread())>=(int)sizeof(fname))
        return 1;
#ifdef LOG_TO_FILE
    log=fopen(fname,"wb");
    if(!log) log=stderr;
#else
    log=stderr;
#endif
    fprintf(log,"WINSHELL TERMINAL EMULATION WINDOW LAUNCHPAD 1.1\n");
    if(argc<2) { fprintf(log,"Usage: winshell [program to launch in window]\n"); goto out; }

    terID=CreateTerminal();
    if(terID<0) { fprintf(log,"winshell: cannot create terminal\n"); goto out; }
    fprintf(log,"Running %s into background\n",argv[1]);
    pid=bgexecEx(argv[1],"/",terID);
    if(pid<=0) { fprintf(log,"Program not found: %s\n",argv[1]); goto out; }

    wid=createWindow(-1,-1,640,436,argv[1],GRAOS_WINDOW_STANDARD & (~GRAOS_WINDOW_AUTOCLEAR));
    if(wid<0) { fprintf(log,"winshell: createWindow failed (%d)\n",wid); goto out; }
    createLabel(wid,4,20,632,16,7300,0,7,GRAOS_LABEL_ALIGN_LEFT,
                "Legacy WinShell - 80x25 VGA terminal - 8x16 font");
    terminalEmulationWindow(wid,terID,&pid);
    wid=-1;
out:
    if(wid>=0) closeWindow(wid);
    if(pid>0 && GetThreadMemoryUsage(pid)>0) KillThread(pid);
#ifdef LOG_TO_FILE
    if(log && log!=stderr) fclose(log);
#endif
    return 0;
}
