# JTMOS MPEG-1 + MP2 GraOS player
APPNAME=mpeg1
APP_OBJS=mpeg1/mpeg1.o mpeg1/pl_mpeg_impl.o
APP_CFLAGS=-std=gnu17
include app-common.mk
