/*
 * JTMOS V59 sound - 8-bit PCM WAV player and audio demo.
 *
 * Supported WAV format:
 *   RIFF/WAVE, WAVE_FORMAT_PCM (1), mono, unsigned 8-bit PCM,
 *   sample rate 4000..44100 Hz.
 *
 * The sample rate is taken directly from the WAV fmt chunk and passed to
 * AudioWrite(); no fixed 11025 Hz assumption is made for WAV playback.
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <jtmos/audio.h>

#define DEMO_RATE 11025
#define DEMO_CHUNK 512
#define WAV_CHUNK 4096

#define WAV_OK                 0
#define WAV_ERR_OPEN          -1
#define WAV_ERR_RIFF          -2
#define WAV_ERR_TRUNCATED     -3
#define WAV_ERR_FMT_MISSING   -4
#define WAV_ERR_DATA_MISSING  -5
#define WAV_ERR_ENCODING      -6
#define WAV_ERR_CHANNELS      -7
#define WAV_ERR_BITS          -8
#define WAV_ERR_RATE          -9
#define WAV_ERR_BLOCKALIGN   -10
#define WAV_ERR_IO           -11

typedef struct {
    unsigned short encoding;
    unsigned short channels;
    unsigned long sample_rate;
    unsigned long byte_rate;
    unsigned short block_align;
    unsigned short bits_per_sample;
    unsigned long data_offset;
    unsigned long data_size;
} WAV_INFO;

static unsigned short rd16le(const unsigned char *p)
{
    return (unsigned short)((unsigned short)p[0] | ((unsigned short)p[1] << 8));
}

static unsigned long rd32le(const unsigned char *p)
{
    return (unsigned long)p[0] |
           ((unsigned long)p[1] << 8) |
           ((unsigned long)p[2] << 16) |
           ((unsigned long)p[3] << 24);
}

static int read_exact(int fd, void *buf, int len)
{
    unsigned char *p=(unsigned char *)buf;
    int done=0;
    while(done<len)
    {
        int n=(int)read(fd,p+done,(size_t)(len-done));
        if(n<=0) return -1;
        done+=n;
    }
    return 0;
}

static int skip_bytes(int fd, unsigned long amount)
{
    if(amount>0x7fffffffUL) return -1;
    return lseek(fd,(long)amount,SEEK_CUR)<0 ? -1 : 0;
}

static int wav_probe_fd(int fd, WAV_INFO *wi)
{
    unsigned char h[12],ch[8],fmt[16];
    int have_fmt=0,have_data=0;

    memset(wi,0,sizeof(*wi));
    if(lseek(fd,0,SEEK_SET)<0 || read_exact(fd,h,12)<0) return WAV_ERR_TRUNCATED;
    if(memcmp(h,"RIFF",4) || memcmp(h+8,"WAVE",4)) return WAV_ERR_RIFF;

    while(!have_fmt || !have_data)
    {
        unsigned long size,skip;
        long here;

        if(read_exact(fd,ch,8)<0) break;
        size=rd32le(ch+4);
        here=lseek(fd,0,SEEK_CUR);
        if(here<0) return WAV_ERR_IO;

        if(!memcmp(ch,"fmt ",4))
        {
            if(size<16) return WAV_ERR_TRUNCATED;
            if(read_exact(fd,fmt,16)<0) return WAV_ERR_TRUNCATED;
            wi->encoding=rd16le(fmt+0);
            wi->channels=rd16le(fmt+2);
            wi->sample_rate=rd32le(fmt+4);
            wi->byte_rate=rd32le(fmt+8);
            wi->block_align=rd16le(fmt+12);
            wi->bits_per_sample=rd16le(fmt+14);
            have_fmt=1;
            skip=size-16;
            if(skip_bytes(fd,skip+(size&1UL))<0) return WAV_ERR_TRUNCATED;
        }
        else if(!memcmp(ch,"data",4))
        {
            wi->data_offset=(unsigned long)here;
            wi->data_size=size;
            have_data=1;
            if(have_fmt) break;
            if(skip_bytes(fd,size+(size&1UL))<0) return WAV_ERR_TRUNCATED;
        }
        else
        {
            if(skip_bytes(fd,size+(size&1UL))<0) return WAV_ERR_TRUNCATED;
        }
    }

    if(!have_fmt) return WAV_ERR_FMT_MISSING;
    if(!have_data) return WAV_ERR_DATA_MISSING;
    if(wi->encoding!=1) return WAV_ERR_ENCODING;
    if(wi->channels!=1) return WAV_ERR_CHANNELS;
    if(wi->bits_per_sample!=8) return WAV_ERR_BITS;
    if(wi->block_align!=1) return WAV_ERR_BLOCKALIGN;
    if(wi->sample_rate<4000UL || wi->sample_rate>44100UL) return WAV_ERR_RATE;
    if(wi->byte_rate!=0 && wi->byte_rate!=wi->sample_rate) return WAV_ERR_BLOCKALIGN;
    return WAV_OK;
}

static void wav_error(const char *name,int err,const WAV_INFO *wi)
{
    printf("sound: %s: ",name);
    switch(err)
    {
        case WAV_ERR_OPEN: printf("cannot open WAV file.\n"); break;
        case WAV_ERR_RIFF: printf("not a RIFF/WAVE file.\n"); break;
        case WAV_ERR_TRUNCATED: printf("truncated or malformed WAV file.\n"); break;
        case WAV_ERR_FMT_MISSING: printf("missing fmt chunk.\n"); break;
        case WAV_ERR_DATA_MISSING: printf("missing data chunk.\n"); break;
        case WAV_ERR_ENCODING:
            printf("unsupported WAV encoding %u; only PCM (format 1) is supported.\n",
                   (unsigned)wi->encoding); break;
        case WAV_ERR_CHANNELS:
            printf("unsupported channel count %u; only mono is supported.\n",
                   (unsigned)wi->channels); break;
        case WAV_ERR_BITS:
            printf("unsupported sample width %u-bit; only unsigned 8-bit PCM is supported.\n",
                   (unsigned)wi->bits_per_sample); break;
        case WAV_ERR_RATE:
            printf("unsupported sample rate %lu Hz; JTMOS currently supports 4000..44100 Hz.\n",
                   wi->sample_rate); break;
        case WAV_ERR_BLOCKALIGN:
            printf("invalid/unsupported PCM block alignment.\n"); break;
        default: printf("I/O error while reading WAV file.\n"); break;
    }
}

static const char *backend_name(unsigned long b)
{
    if(b==AUDIO_BACKEND_SB) return "Sound Blaster";
    if(b==AUDIO_BACKEND_GUS) return "Gravis UltraSound";
    return "none";
}

static int status(void)
{
    JTMOS_AUDIO_INFO i;
    if(AudioGetInfo(&i)<0) return 1;
    printf("backend=%s rate=%lu queued=%lu active=%lu played=%lu underruns=%lu\n",
           backend_name(i.backend),i.sample_rate,i.queued_bytes,i.active_bytes,
           i.played_bytes,i.underruns);
    return 0;
}

static unsigned char triangle(unsigned long phase)
{
    unsigned long half=DEMO_RATE/2,v;
    if(phase<half) v=(phase*160UL)/half;
    else v=((DEMO_RATE-1UL-phase)*160UL)/half;
    if(v>160) v=160;
    return (unsigned char)(48+v);
}

static int note(int hz,int ms)
{
    unsigned char b[DEMO_CHUNK];
    unsigned long phase=0;
    int left=(DEMO_RATE*ms)/1000;
    while(left>0)
    {
        int n=left>DEMO_CHUNK?DEMO_CHUNK:left;
        int i,off=0;
        for(i=0;i<n;i++)
        {
            if(!hz) b[i]=0x80;
            else {
                phase+=(unsigned long)hz;
                while(phase>=DEMO_RATE) phase-=DEMO_RATE;
                b[i]=triangle(phase);
            }
        }
        while(off<n)
        {
            int w=AudioWrite(b+off,n-off,AUDIO_FORMAT_U8_MONO,DEMO_RATE);
            if(w<0) return w;
            if(!w){usleep(1000);continue;}
            off+=w;
        }
        left-=n;
    }
    return 0;
}

static int select_backend(int backend)
{
    if(backend==AUDIO_BACKEND_AUTO) return AudioInit();
    return AudioSelectBackend(backend);
}

static int play_wav(const char *name,int backend)
{
    WAV_INFO wi;
    unsigned char buf[WAV_CHUNK];
    unsigned long left;
    int fd,err,r;

    fd=open(name,O_RDONLY);
    if(fd<0){ wav_error(name,WAV_ERR_OPEN,&wi); return 1; }
    err=wav_probe_fd(fd,&wi);
    if(err!=WAV_OK){ wav_error(name,err,&wi); close(fd); return 1; }

    r=select_backend(backend);
    if(r<0){ printf("sound: no supported audio adapter found.\n"); close(fd); return 1; }
    AudioStop();

    if(lseek(fd,(long)wi.data_offset,SEEK_SET)<0)
    { printf("sound: %s: cannot seek to WAV data.\n",name); close(fd); return 1; }

    printf("Playing %s: PCM 8-bit mono, %lu Hz, %lu bytes via %s.\n",
           name,wi.sample_rate,wi.data_size,backend_name((unsigned long)r));

    left=wi.data_size;
    while(left>0)
    {
        int n=(left>WAV_CHUNK)?WAV_CHUNK:(int)left;
        int off=0;
        if(read_exact(fd,buf,n)<0)
        {
            printf("sound: %s: truncated PCM data.\n",name);
            AudioStop(); close(fd); return 1;
        }
        while(off<n)
        {
            int w=AudioWrite(buf+off,n-off,AUDIO_FORMAT_U8_MONO,(int)wi.sample_rate);
            if(w<0)
            {
                printf("sound: playback failed (AudioWrite=%d).\n",w);
                AudioStop(); close(fd); return 1;
            }
            if(w==0){ usleep(1000); continue; }
            off+=w;
        }
        left-=(unsigned long)n;
    }
    close(fd);

    while(GetAudioPosition()!=0) usleep(10000);
    return status();
}

static void usage(const char *p)
{
    printf("JTMOS sound - 8-bit PCM WAV player\n");
    printf("Usage:\n");
    printf("  %s file.wav\n",p);
    printf("  %s sb file.wav\n",p);
    printf("  %s gus file.wav\n",p);
    printf("  %s              (built-in sound demo)\n",p);
    printf("  %s status | stop\n",p);
    printf("Supported WAV: PCM format 1, mono, unsigned 8-bit, 4000..44100 Hz.\n");
}

int main(int argc,char **argv)
{
    int backend=AUDIO_BACKEND_AUTO;
    int arg=1,r;

    if(argc>1 && !strcmp(argv[1],"status")) return status();
    if(argc>1 && !strcmp(argv[1],"stop")) return AudioStop();
    if(argc>1 && (!strcmp(argv[1],"-h") || !strcmp(argv[1],"--help")))
    { usage(argv[0]); return 0; }

    if(argc>1 && !strcmp(argv[1],"sb")){ backend=AUDIO_BACKEND_SB; arg++; }
    else if(argc>1 && !strcmp(argv[1],"gus")){ backend=AUDIO_BACKEND_GUS; arg++; }

    if(arg<argc)
    {
        if(arg+1!=argc){ usage(argv[0]); return 1; }
        return play_wav(argv[arg],backend);
    }

    r=select_backend(backend);
    if(r<0){printf("sound: no supported audio adapter found.\n");return 1;}
    AudioStop();
    printf("JTMOS libc sound demo - %s, 8-bit mono %d Hz\n",backend_name((unsigned long)r),DEMO_RATE);
    if(note(262,180)<0||note(330,180)<0||note(392,180)<0||note(523,280)<0||
       note(392,180)<0||note(330,180)<0||note(262,360)<0)
    {printf("sound: playback write failed.\n");return 1;}
    while(GetAudioPosition()!=0) usleep(10000);
    return status();
}
