// JTMOS LIBC DYNAMICAL MEMORY ALLOCATION TEST
#include <stdio.h>
#include <stdlib.h>
int main(int argc,char **argv)
{
 //
 int i;
 char *data1[10];

 //
 printf("JTMOS LIBC dynamic memory test\n");
 //
 printf("%dK dynamic memory free.\n", GetAmountFree()/1024);
 //
 printf("Doing some mallocs.\n");
 for(i=0; i<10; i++) {
  data1[i]=malloc(1024);
  if(!data1[i]) {
   printf("malloc test: FAILED at block %d\n",i);
   while(i>0) free(data1[--i]);
   return 1;
  }
 }
 //
 printf("%dK dynamic memory free.\n", GetAmountFree()/1024);
 //
 printf("Freeing memory.\n");
 for(i=0; i<10; i++) { free(data1[i]); }
 printf("%dK dynamic memory free.\n", GetAmountFree()/1024);

 /* V67.8.57.8: deliberately exceed a small initial heap so malloc must
  * obtain a process mmap arena through SYS_mem_grow. */
 {
  char *grow = malloc(2U*1024U*1024U);
  if(!grow) { printf("mmap grow test: FAILED\n"); return 1; }
  grow[0]='G'; grow[2U*1024U*1024U-1U]='W';
  printf("mmap grow test: PASS (%c%c)\n", grow[0], grow[2U*1024U*1024U-1U]);
  free(grow);
 }

 //
 return 0;
}
