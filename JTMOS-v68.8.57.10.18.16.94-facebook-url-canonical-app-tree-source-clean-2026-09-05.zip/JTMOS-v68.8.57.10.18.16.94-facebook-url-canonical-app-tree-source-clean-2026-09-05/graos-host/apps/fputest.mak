# JTMOS V67 static ELF32 application
APPNAME=fputest
include app-common.mk
