/* grep.c - small streaming grep for JTMOS SMSH/SQSH pipelines.
 *
 * Common use:
 *   cat /var/log/system.log | grep -i dhcp | more
 *   grep -in error /var/log/system.log
 *
 * This implementation deliberately uses literal substring matching rather than
 * a large regular-expression engine.  It is intended as a small, dependable
 * log/pipeline filter for the JTMOS rescue environment.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#ifdef JTMOS
#include <jtmos/process.h>
SYSMEMREQ(APPRAM_256K)
#else
static void SwitchToThread(void) { }
#endif

#define GREP_LINE_MAX 4096
#define GREP_MAX_PATTERNS 32

typedef struct GREP_OPTIONS {
    int ignore_case;
    int invert;
    int line_numbers;
    int count_only;
    int quiet;
    int show_filename;
    int suppress_filename;
} GREP_OPTIONS;

static int ascii_lower(int c)
{
    if(c>='A' && c<='Z') return c+('a'-'A');
    return c;
}

static int char_equal(int a,int b,int ignore_case)
{
    if(ignore_case) return ascii_lower((unsigned char)a)==ascii_lower((unsigned char)b);
    return (unsigned char)a==(unsigned char)b;
}

static int contains_literal(const char *line,const char *pattern,int ignore_case)
{
    const char *p,*q,*s;
    if(!pattern || !pattern[0]) return 1;
    if(!line) return 0;
    for(s=line;*s;s++) {
        p=s; q=pattern;
        while(*p && *q && char_equal(*p,*q,ignore_case)) { p++; q++; }
        if(!*q) return 1;
    }
    return 0;
}

static int line_matches(const char *line,char **patterns,int npat,const GREP_OPTIONS *opt)
{
    int i,matched=0;
    for(i=0;i<npat;i++) {
        if(contains_literal(line,patterns[i],opt->ignore_case)) { matched=1; break; }
    }
    return opt->invert ? !matched : matched;
}

static void output_prefix(const char *name,unsigned long lineno,int multi,const GREP_OPTIONS *opt)
{
    int filename=(opt->show_filename || (multi && !opt->suppress_filename));
    if(filename && name) printf("%s:",name);
    if(opt->line_numbers) printf("%lu:",lineno);
}

/* Process a logical line.  fgets() may split an exceptionally long line; the
 * logger emits short records, and the 4 KiB buffer avoids heap allocation while
 * keeping grep usable very early in the system/rescue environment. */
static int grep_stream(FILE *f,const char *name,char **patterns,int npat,
                       const GREP_OPTIONS *opt,int multi,unsigned long *selected_out)
{
    char line[GREP_LINE_MAX];
    unsigned long lineno=0,selected=0;
    int had_fragment=0;

    while(fgets(line,sizeof(line),f)!=NULL) {
        size_t n=strlen(line);
        int ends_line=(n>0 && line[n-1]=='\n');
        int selected_line;

        if(!had_fragment) lineno++;
        selected_line=line_matches(line,patterns,npat,opt);
        if(selected_line) {
            selected++;
            if(opt->quiet) { if(selected_out) *selected_out=selected; return 1; }
            if(!opt->count_only) {
                output_prefix(name,lineno,multi,opt);
                fputs(line,stdout);
                if(!ends_line && feof(f)) fputc('\n',stdout);
            }
        }
        had_fragment=!ends_line;
        SwitchToThread();
    }
    if(ferror(f)) {
        fprintf(stderr,"grep: read error on '%s'\n",name?name:"stdin");
        return -1;
    }
    if(selected_out) *selected_out=selected;
    return selected ? 1 : 0;
}

static void usage(void)
{
    printf("Usage: grep [-ivncqHh] [-e PATTERN] PATTERN [FILE ...]\n");
    printf("Search input lines for literal PATTERN text. No FILE or '-' reads stdin.\n");
    printf("Options:\n");
    printf("  -i  ignore ASCII letter case\n");
    printf("  -v  select non-matching lines\n");
    printf("  -n  prefix output with line number\n");
    printf("  -c  print only selected-line count\n");
    printf("  -q  quiet; stop after first selected line\n");
    printf("  -H  always print filename, -h never print filename\n");
    printf("  -e PATTERN  add a pattern (up to %d; any match selects the line)\n",GREP_MAX_PATTERNS);
    printf("Example: cat /var/log/system.log|grep -i dhcp|more\n");
}

int main(int argc,char **argv)
{
    GREP_OPTIONS opt;
    char *patterns[GREP_MAX_PATTERNS];
    int npat=0,i,file_start=-1,rc=1,had_error=0,multi=0;
    unsigned long total;

    memset(&opt,0,sizeof(opt));

    for(i=1;i<argc;i++) {
        char *a=argv[i];
        int j;
        if(!strcmp(a,"--")) { file_start=i+1; break; }
        if(!strcmp(a,"--help")) { usage(); return 0; }
        if(a[0]!='-' || a[1]=='\0') { file_start=i; break; }
        if(a[1]=='e' && a[2]=='\0') {
            if(i+1>=argc) { fprintf(stderr,"grep: -e requires PATTERN\n"); return 2; }
            if(npat>=GREP_MAX_PATTERNS) { fprintf(stderr,"grep: too many patterns\n"); return 2; }
            patterns[npat++]=argv[++i];
            continue;
        }
        for(j=1;a[j];j++) {
            switch(a[j]) {
                case 'i': opt.ignore_case=1; break;
                case 'v': opt.invert=1; break;
                case 'n': opt.line_numbers=1; break;
                case 'c': opt.count_only=1; break;
                case 'q': opt.quiet=1; break;
                case 'H': opt.show_filename=1; opt.suppress_filename=0; break;
                case 'h': opt.suppress_filename=1; opt.show_filename=0; break;
                case 'e':
                    if(a[j+1]) {
                        if(npat>=GREP_MAX_PATTERNS) { fprintf(stderr,"grep: too many patterns\n"); return 2; }
                        patterns[npat++]=&a[j+1];
                        j=(int)strlen(a)-1;
                    } else {
                        if(i+1>=argc) { fprintf(stderr,"grep: -e requires PATTERN\n"); return 2; }
                        if(npat>=GREP_MAX_PATTERNS) { fprintf(stderr,"grep: too many patterns\n"); return 2; }
                        patterns[npat++]=argv[++i];
                    }
                    break;
                default:
                    fprintf(stderr,"grep: unknown option -%c\n",a[j]);
                    usage(); return 2;
            }
        }
    }

    if(file_start<0) file_start=argc;
    if(npat==0) {
        if(file_start>=argc) { usage(); return 2; }
        patterns[npat++]=argv[file_start++];
    }

    multi=(argc-file_start)>1;
    if(file_start>=argc) {
        int r=grep_stream(stdin,"-",patterns,npat,&opt,0,&total);
        if(r<0) return 2;
        if(opt.count_only && !opt.quiet) printf("%lu\n",total);
        return r?0:1;
    }

    for(i=file_start;i<argc;i++) {
        FILE *f;
        int r;
        total=0;
        if(!strcmp(argv[i],"-")) f=stdin;
        else f=fopen(argv[i],"rb");
        if(!f) {
            fprintf(stderr,"grep: cannot open '%s'\n",argv[i]);
            had_error=1;
            continue;
        }
        r=grep_stream(f,argv[i],patterns,npat,&opt,multi,&total);
        if(f!=stdin && fclose(f)!=0) had_error=1;
        if(r<0) had_error=1;
        else if(r>0) rc=0;
        if(opt.count_only && !opt.quiet) {
            if((opt.show_filename || (multi && !opt.suppress_filename))) printf("%s:",argv[i]);
            printf("%lu\n",total);
        }
        if(opt.quiet && r>0) return 0;
    }
    return had_error?2:rc;
}
