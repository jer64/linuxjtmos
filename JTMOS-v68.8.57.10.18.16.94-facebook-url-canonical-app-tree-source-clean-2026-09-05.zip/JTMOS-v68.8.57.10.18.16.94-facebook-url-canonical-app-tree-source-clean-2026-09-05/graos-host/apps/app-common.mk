# JTMOS V67 common ELF32 application build rules.
# Include from an app .mak after defining APPNAME and optionally APP_OBJS/APP_CFLAGS.
LIBCDIR ?= ../libc
CROSS ?=
CC = $(CROSS)gcc
LD = $(CROSS)ld

APP_OBJS ?= $(APPNAME).o
APP_CFLAGS ?=
CFLAGS_COMMON = -m32 -march=i486 -std=gnu89 -O2 -ffreestanding -fno-builtin \
	-fno-stack-protector -fno-pie -fno-pic -fcommon -fcf-protection=none \
	-fno-unwind-tables -fno-asynchronous-unwind-tables -nostdinc \
	-Ulinux -U__linux -U__linux__ -DJTMOS=1 -DJTMOS_APPLICATION=1 \
	-DJTMOS_LEGACY_SOURCE=1 -DCPU=i486 -I$(LIBCDIR)/include
CFLAGS = $(CFLAGS_COMMON) $(APP_CFLAGS)
LDFLAGS = -m elf_i386 -static -z noexecstack -Map $(APPNAME).map -T $(LIBCDIR)/jtmos_elf32.ld
CRT0 = $(LIBCDIR)/build/application/crt0.o
LIBC_ARCHIVE = $(LIBCDIR)/libcjtmos.a

.PHONY: default all application libc clean

default all: $(APPNAME).bin

# Build modern libc automatically.  Link the archive by its exact path; do not
# depend on host ld's -L/-l lookup rules.
application libc $(CRT0) $(LIBC_ARCHIVE):
	$(MAKE) -C $(LIBCDIR) application

%.o: %.c
	$(CC) $(CFLAGS) -c $< -o $@

$(APPNAME).bin: $(CRT0) $(LIBC_ARCHIVE) $(APP_OBJS)
	$(LD) $(LDFLAGS) $(CRT0) $(APP_OBJS) $(LIBC_ARCHIVE) -o $@
	@LC_ALL=C readelf -h $@ | grep -q 'Class:.*ELF32'
	@LC_ALL=C readelf -h $@ | grep -q 'Machine:.*Intel 80386'
	@LC_ALL=C readelf -h $@ | grep -q 'Entry point address:.*0x80004000'

clean:
	rm -f $(APP_OBJS) $(APPNAME).bin $(APPNAME).map
