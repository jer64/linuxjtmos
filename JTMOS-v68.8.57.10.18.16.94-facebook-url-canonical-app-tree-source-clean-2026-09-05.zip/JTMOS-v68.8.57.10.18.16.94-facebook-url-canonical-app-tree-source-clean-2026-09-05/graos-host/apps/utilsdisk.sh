#!/bin/sh
# Historical alias for the canonical V67.8 system utilities package build.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
exec make -C "$ROOT" packages
