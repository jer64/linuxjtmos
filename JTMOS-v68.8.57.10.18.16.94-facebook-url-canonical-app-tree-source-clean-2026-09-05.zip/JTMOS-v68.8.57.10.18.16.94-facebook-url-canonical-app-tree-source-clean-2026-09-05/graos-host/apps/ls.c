/* ls.c - list directory contents */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <jtmos/filefind.h>

#define PAGE_LINES 22

static int pause_output = 0;

static void format_size(char *out, size_t outsz, DWORD sz)
{
    if(sz >= 1024UL * 1024UL)
        snprintf(out, outsz, "%luM", (unsigned long)(sz / (1024UL * 1024UL)));
    else if(sz >= 1024UL)
        snprintf(out, outsz, "%luK", (unsigned long)(sz / 1024UL));
    else
        snprintf(out, outsz, "%lu bytes", (unsigned long)sz);
}

static int list_current(void)
{
    FFBLK ff;
    int fd;
    int total_files = 0;
    int total_dirs = 0;
    int page_lines = 0;
    unsigned long total_bytes = 0;
    char name[256];
    char size[64];

    fd = findfirst("*", &ff);
    if(fd <= 0) {
        printf("ls: cannot read directory\n");
        return 1;
    }

    for(;;) {
        if(ff.ff_fsize != -1 && ff.ff_name[0]) {
            if(pause_output && page_lines >= PAGE_LINES) {
                int key;
                printf("Press any key to continue ... ");
                key = getch();
                printf("\r                                 \r");
                page_lines = 0;
                if(key == 27) break;
            }

            if(JTMFS_TYPE_IS_DIRECTORY(ff.ff_attrib)) {
                ++total_dirs;
                snprintf(name, sizeof(name), "[%s]", ff.ff_name);
                size[0] = 0;
            } else {
                DWORD sz = (DWORD)ff.ff_fsize;
                ++total_files;
                total_bytes += (unsigned long)sz;
                snprintf(name, sizeof(name), "%s", ff.ff_name);
                format_size(size, sizeof(size), sz);
            }
            StretchPrint(name, 32);
            StretchPrint(size, 16);
            printf("\n");
            ++page_lines;
        }
        if(findnext(fd, &ff) != 0) break;
    }
    close(fd);

    printf("%d File(s), %lu bytes\n", total_files, total_bytes);
    printf("%d Dir(s)\n", total_dirs);
    return 0;
}

static void help(void)
{
    printf("Usage: ls [OPTIONS] [DIRECTORY]\n");
    printf("List directory contents.\n");
    printf("  -p, --pause   pause after each screenful\n");
    printf("  -h, --help    show this help\n");
}

int main(int argc, char **argv)
{
    const char *path = NULL;
    int i;

    for(i = 1; i < argc; ++i) {
        if(!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help") || !strcmp(argv[i], "/?")) {
            help();
            return 0;
        }
        if(!strcmp(argv[i], "-p") || !strcmp(argv[i], "--pause") || !strcmp(argv[i], "/p")) {
            pause_output = 1;
            continue;
        }
        if(path != NULL) {
            printf("ls: too many operands\n");
            return 1;
        }
        path = argv[i];
    }

    if(path != NULL && chdir(path) != 0) {
        printf("ls: cannot access '%s'\n", path);
        return 1;
    }
    return list_current();
}
