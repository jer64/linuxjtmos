#ifndef __INCLUDED_EDIT_H__
#define __INCLUDED_EDIT_H__

/* JTMOS text editor geometry.  Rows 1,24,25 are UI; rows 2..23 are text. */
#define MAX_LINES       5000
#define MAX_PER_LINE    81      /* 80 visible chars + NUL */
#define CURSOR_X_MIN    1
#define CURSOR_Y_MIN    2
#define CURSOR_X_MAX    80
#define CURSOR_Y_MAX    23
#define EDIT_ROWS       (CURSOR_Y_MAX-CURSOR_Y_MIN+1)
#define TAB_WIDTH       8

#define COLOR1          7
#define COLOR1B         1
#define COLOR2          0
#define COLOR2B         7

typedef struct
{
    int ctrl,alt;
    BYTE *buf[MAX_LINES];
    int lines;
    int insertMode;
    int modified;
    struct { int x,y; } cursor;
    struct {
        int x,y;
        int upd;          /* non-zero = full text viewport redraw */
        int dirty_line;   /* logical line to redraw, -1 = none */
    } view;
} EDITOR;

extern EDITOR ed;

void EditorInit(void);
int EditorLoad(const char *fname);
int EditorSave(const char *fname);
void EditorOnClose(void);
void UpdateEditBox(void);
void OrderRefresh(void);
void MarkLineDirty(int logical_y);
void CursorUp(void);
void CursorDown(void);
void CursorLeft(void);
void CursorRight(void);
int GetWritePointX(void);
int GetWritePointY(void);
void StoreChar(int ch);
void DeleteAtCursor(void);
void BackspaceAtCursor(void);
void SplitLine(void);
void InsertTab(void);

#endif
