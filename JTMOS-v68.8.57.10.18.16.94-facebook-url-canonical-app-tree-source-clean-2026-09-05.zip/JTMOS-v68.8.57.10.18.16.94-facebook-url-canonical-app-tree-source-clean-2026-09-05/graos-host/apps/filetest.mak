# JTMOS V67 static ELF32 application
APPNAME=filetest
include app-common.mk
