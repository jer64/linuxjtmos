APPNAME=idler
.PHONY: default clean
default:
	@echo "idler: legacy raw NASM application; not converted to the V67 ELF32 crt0/libc ABI." >&2
	@false
clean:
	@rm -f idler.o idler.bin idler.map
