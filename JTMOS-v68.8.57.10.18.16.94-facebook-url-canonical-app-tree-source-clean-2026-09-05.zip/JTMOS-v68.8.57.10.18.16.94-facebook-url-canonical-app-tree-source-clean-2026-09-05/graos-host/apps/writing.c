#include <stdio.h>
#include <stdlib.h>
#ifndef JTMOS
#include <jtmos/app_port.h>
#endif

char *pattern="0123456789ABCDEFSquirrelDuckBirdDogCatExcitingWorld";
#define length	1024*256

void WriteFile(const char *name)
{
	FILE *f;
	int i;

	f = fopen(name, "wb");
	if(f==NULL) { printf("%s: error\n", __FUNCTION__); exit(1); }
	for(i=0; i<length; i++) { fputc(pattern[i&31], f); }
	fclose(f);
}

void VerifyFile(const char *name)
{
	FILE *f;
	int i;

	f = fopen(name, "rb");
	if(f==NULL) { printf("%s: error\n", __FUNCTION__); exit(2); }
	for(i=0; i<length; i++)
	{
		if( fgetc(f)!=pattern[i&31] )
		{
				printf("Verification failure on file %s at offset 0x%x\n",
					name, i);
				fclose(f);
				exit(10);
		}
	}
	fclose(f);
}

int main(int argc, char **argv)
{
	char str[256];
	int i,i2;

	for(i=0; i<4; i++)
	{
		if(snprintf(str,sizeof(str),"%s%d.dat",argv[0],i)>=(int)sizeof(str))
		{
			printf("writing: output name is too long.\n");
			return 1;
		}
		printf("Writing %s ...\n", str);
		WriteFile(str);
	}

	for(i=0; i<4; i++)
	{
		if(snprintf(str,sizeof(str),"%s%d.dat",argv[0],i)>=(int)sizeof(str))
			return 1;
		printf("Verifying %s ...\n", str);
		VerifyFile(str);
	}
	return 0;
}
