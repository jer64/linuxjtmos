APPNAME=talk
include app-common.mk
