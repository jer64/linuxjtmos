# JTMOS V67 static ELF32 application
APPNAME=otest
include app-common.mk
