# JTMOS V67 static ELF32 application
APPNAME=setup
include app-common.mk
