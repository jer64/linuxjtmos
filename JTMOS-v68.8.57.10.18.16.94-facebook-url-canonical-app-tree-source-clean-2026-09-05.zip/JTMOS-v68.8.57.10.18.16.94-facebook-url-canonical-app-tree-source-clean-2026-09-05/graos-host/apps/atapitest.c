/* atapitest.c - JTMOS ATAPI utilities-media smoke test. */
#include <stdio.h>
#include <string.h>
#include <jtmos/types.h>
#include <jtmos/directdisk.h>

#define CD_SECTOR 2048
#define SQA_MAGIC "SQARC520"

int main(int argc, char **argv)
{
    const char *name;
    int dnr, got, i;
    BYTE buf[CD_SECTOR * 2];

    name = (argc > 1 && argv[1] && argv[1][0]) ? argv[1] : "cdrom";
    dnr = getdevnrbyname(name);
    if(dnr < 0)
    {
        printf("atapitest: device '%s' not found.\n", name);
        return 1;
    }

    memset(buf, 0xA5, sizeof(buf));
    got = readblocks(dnr, 0, buf, 2);
    if(got != 2)
    {
        printf("atapitest: READ(10) failed on %s (got %d/2 blocks).\n", name, got);
        return 2;
    }

    for(i=0; i<CD_SECTOR; ++i)
    {
        if(buf[i] != 0)
        {
            printf("atapitest: sector 0 safe area mismatch at byte %d.\n", i);
            return 3;
        }
    }

    if(memcmp(buf + CD_SECTOR, SQA_MAGIC, 8) != 0)
    {
        printf("atapitest: sector 1 is readable, but SQARC520 signature is missing.\n");
        printf("atapitest: media is not the JTMOS utilities CD image.\n");
        return 4;
    }

    printf("ATAPI OK: %s READ(10) returned two 2048-byte sectors.\n", name);
    printf("Utilities media OK: SQARC520 signature found at byte 2048.\n");
    printf("Next: sqa %s\n", name);
    printf("      unz.bin\n");
    return 0;
}
