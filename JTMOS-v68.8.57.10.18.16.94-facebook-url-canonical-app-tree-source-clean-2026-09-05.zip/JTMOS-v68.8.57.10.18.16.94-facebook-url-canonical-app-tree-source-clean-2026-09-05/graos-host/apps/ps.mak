# JTMOS V67 static ELF32 application
APPNAME=ps
include app-common.mk
