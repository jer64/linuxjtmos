APPNAME := fork
include app-common.mk
