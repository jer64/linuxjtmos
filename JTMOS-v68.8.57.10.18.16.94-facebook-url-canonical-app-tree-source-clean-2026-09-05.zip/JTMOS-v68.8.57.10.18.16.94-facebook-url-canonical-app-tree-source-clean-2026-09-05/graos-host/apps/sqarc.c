#define _POSIX_C_SOURCE 200809L
/* sqarc.c - portable Squirrel Archive creator, V65 modernization. */
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include "sqa.h"

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif
#define COPY_CHUNK 65536U

typedef struct SOURCE_ENTRY { FE disk; char *path; } SOURCE_ENTRY;
typedef struct SOURCE_LIST { SOURCE_ENTRY *v; size_t n, cap; DWORD next_offset; } SOURCE_LIST;

static int compare_source_entry(const void *a,const void *b)
{
    const SOURCE_ENTRY *ea=(const SOURCE_ENTRY *)a;
    const SOURCE_ENTRY *eb=(const SOURCE_ENTRY *)b;
    return strcmp(ea->disk.fname,eb->disk.fname);
}

static int finalize_offsets(SOURCE_LIST *l)
{
    size_t i;
    DWORD next=0U;
    if(l->n>1U) qsort(l->v,l->n,sizeof(l->v[0]),compare_source_entry);
    for(i=0U;i<l->n;++i){
        if(l->v[i].disk.length>UINT32_MAX-next){errno=EFBIG;return -1;}
        l->v[i].disk.offset=next;
        next+=l->v[i].disk.length;
    }
    l->next_offset=next;
    return 0;
}

static int write_all(int fd,const void *buf,size_t len)
{
    const unsigned char *p=buf; size_t done=0;
    while(done<len){ssize_t n=write(fd,p+done,len-done);if(n<0){if(errno==EINTR)continue;return -1;}if(n==0){errno=EIO;return -1;}done+=(size_t)n;}return 0;
}
static int put_u16(int fd,unsigned v){BYTE b[2]={(BYTE)v,(BYTE)(v>>8)};return write_all(fd,b,2);}
static int put_u32(int fd,DWORD v){BYTE b[4]={(BYTE)v,(BYTE)(v>>8),(BYTE)(v>>16),(BYTE)(v>>24)};return write_all(fd,b,4);}
static const char *base_name(const char *p){const char *s=strrchr(p,'/');return s?s+1:p;}
static int join_path(char *out,size_t cap,const char *a,const char *b)
{size_t x=strlen(a),y=strlen(b);int slash=x&&a[x-1]!='/';if(x+(slash?1U:0U)+y+1U>cap){errno=ENAMETOOLONG;return -1;}memcpy(out,a,x);if(slash)out[x++]='/';memcpy(out+x,b,y+1U);return 0;}
static void free_list(SOURCE_LIST *l){size_t i;for(i=0;i<l->n;i++)free(l->v[i].path);free(l->v);memset(l,0,sizeof(*l));}
static int duplicate_name(const SOURCE_LIST *l,const char *name){size_t i;for(i=0;i<l->n;i++)if(strcmp(l->v[i].disk.fname,name)==0)return 1;return 0;}
static int ensure_list(SOURCE_LIST *l)
{SOURCE_ENTRY *p;size_t nc;if(l->n<SQA_MAX_FILES&&l->n<l->cap)return 0;if(l->n>=SQA_MAX_FILES){errno=EFBIG;return -1;}nc=l->cap?l->cap*2U:128U;if(nc>SQA_MAX_FILES)nc=SQA_MAX_FILES;p=realloc(l->v,nc*sizeof(*p));if(!p)return -1;l->v=p;l->cap=nc;return 0;}
static int file_info(const char *path,DWORD *len,DWORD *sum)
{BYTE buf[COPY_CHUNK];uint64_t total=0;DWORD checksum=0;int fd=open(path,O_RDONLY);if(fd<0)return -1;for(;;){ssize_t n=read(fd,buf,sizeof(buf));size_t i;if(n<0){if(errno==EINTR)continue;close(fd);return -1;}if(!n)break;if(total+(uint64_t)n>UINT32_MAX){close(fd);errno=EFBIG;return -1;}for(i=0;i<(size_t)n;i++)checksum+=(DWORD)buf[i]+1U;total+=(uint64_t)n;}if(close(fd)!=0)return -1;*len=(DWORD)total;*sum=checksum;return 0;}
static int add_file(SOURCE_LIST *l,const char *path)
{const char *name=base_name(path);size_t nl=strlen(name);SOURCE_ENTRY *e;if(nl==0U||nl>=SQA_FILENAME_SIZE||duplicate_name(l,name)){fprintf(stderr,"sqarc: invalid/duplicate basename: %s\n",path);errno=EINVAL;return -1;}if(ensure_list(l)!=0)return -1;e=&l->v[l->n];memset(e,0,sizeof(*e));memcpy(e->disk.fname,name,nl+1U);if(file_info(path,&e->disk.length,&e->disk.chksum)!=0)return -1;e->path=strdup(path);if(!e->path)return -1;fprintf(stderr,"Adding %s (%u bytes)\n",path,e->disk.length);l->n++;return 0;}
static int collect(SOURCE_LIST *l,const char *path)
{struct stat st;if(lstat(path,&st)!=0)return -1;if(S_ISREG(st.st_mode))return add_file(l,path);if(S_ISDIR(st.st_mode)){DIR *d=opendir(path);struct dirent *de;int rc=0;if(!d)return -1;errno=0;while((de=readdir(d))!=NULL){char child[PATH_MAX];if(!strcmp(de->d_name,".")||!strcmp(de->d_name,".."))continue;if(join_path(child,sizeof(child),path,de->d_name)!=0||collect(l,child)!=0){rc=-1;break;}errno=0;}if(!de&&errno&&rc==0)rc=-1;if(closedir(d)!=0&&rc==0)rc=-1;return rc;}return 0;}
static int write_safe(int fd)
{BYTE buf[SQA_SAFE_AREA_SIZE];char path[PATH_MAX];const char *root=getenv("JTMOSDIR");int bfd;size_t done=0;memset(buf,0,sizeof(buf));if(!root||!*root)root=".";if(join_path(path,sizeof(path),root,"boot32/nonsysdisk.bin")!=0)return -1;bfd=open(path,O_RDONLY);if(bfd>=0){while(done<sizeof(buf)){ssize_t n=read(bfd,buf+done,sizeof(buf)-done);if(n<0){if(errno==EINTR)continue;close(bfd);return -1;}if(!n)break;done+=(size_t)n;}if(close(bfd)!=0)return -1;}else if(errno!=ENOENT)return -1;else fprintf(stderr,"sqarc: warning: %s missing; safe area zero-filled\n",path);return write_all(fd,buf,sizeof(buf));}
static int write_header(int fd,const SOURCE_LIST *l)
{size_t i;if(write_all(fd,SQA_IDENTIFIER,SQA_IDENTIFIER_SIZE)!=0||put_u16(fd,(unsigned)l->n)!=0)return -1;for(i=0;i<l->n;i++){const FE *e=&l->v[i].disk;BYTE z=0;if(write_all(fd,e->fname,SQA_FILENAME_SIZE)!=0||write_all(fd,&z,1)!=0||put_u32(fd,e->offset)!=0||put_u32(fd,e->length)!=0||put_u32(fd,e->chksum)!=0)return -1;}return 0;}
static int append_file(int afd,const char *path)
{BYTE buf[COPY_CHUNK];int fd=open(path,O_RDONLY);if(fd<0)return -1;for(;;){ssize_t n=read(fd,buf,sizeof(buf));if(n<0){if(errno==EINTR)continue;close(fd);return -1;}if(!n)break;if(write_all(afd,buf,(size_t)n)!=0){close(fd);return -1;}}return close(fd);}
int archive(const char *src,const char *dst)
{SOURCE_LIST l;int fd=-1,rc=1;size_t i;memset(&l,0,sizeof(l));if(!src||!dst||!*src||!*dst){errno=EINVAL;return 1;}if(collect(&l,src)!=0||l.n==0U){perror("sqarc: collect");goto done;}if(finalize_offsets(&l)!=0){perror("sqarc: offsets");goto done;}fd=open(dst,O_WRONLY|O_CREAT|O_TRUNC,0666);if(fd<0){perror("sqarc: create");goto done;}if(write_safe(fd)!=0||write_header(fd,&l)!=0){perror("sqarc: header");goto done;}for(i=0;i<l.n;i++)if(append_file(fd,l.v[i].path)!=0){perror("sqarc: append");goto done;}if(fsync(fd)!=0){perror("sqarc: fsync");goto done;}if(close(fd)!=0){fd=-1;perror("sqarc: close");goto done;}fd=-1;fprintf(stderr,"sqarc: %zu file(s), %u data bytes -> %s\n",l.n,l.next_offset,dst);rc=0;done:if(fd>=0)close(fd);if(rc)unlink(dst);free_list(&l);return rc;}
int sqarc_main(int argc,char **argv){if(argc!=3){fprintf(stderr,"Usage: %s directory archive.sqa\n",argv[0]);return 2;}return archive(argv[1],argv[2]);}
int main(int argc,char **argv){return sqarc_main(argc,argv);}
