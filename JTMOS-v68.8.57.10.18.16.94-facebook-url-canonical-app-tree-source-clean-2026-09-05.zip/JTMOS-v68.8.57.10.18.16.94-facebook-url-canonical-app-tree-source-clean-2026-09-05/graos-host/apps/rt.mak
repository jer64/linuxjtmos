# JTMOS V67 static ELF32 application
APPNAME=rt
include app-common.mk
