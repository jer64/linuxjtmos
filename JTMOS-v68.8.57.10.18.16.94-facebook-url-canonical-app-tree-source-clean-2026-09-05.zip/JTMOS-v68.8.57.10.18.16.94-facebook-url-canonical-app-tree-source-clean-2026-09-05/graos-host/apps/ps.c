/* ps.c - list running JTMOS processes */
#include <stdio.h>
#include <string.h>
#include <jtmos/process.h>

static void help(void)
{
    printf("Usage: ps\n");
    printf("Show running processes using plain JTMOS PIDs.\n");
}

int main(int argc, char **argv)
{
    int pid;
    int count;
    int mem;
    char str[128];
    char name[128];

    if(argc > 1) {
        if(argc == 2 && (!strcmp(argv[1], "-h") || !strcmp(argv[1], "--help"))) {
            help();
            return 0;
        }
        printf("ps: unexpected argument\n");
        return 1;
    }

    StretchPrint("PID", 8);
    StretchPrint("CPU ticks", 12);
    StretchPrint("Priority", 10);
    StretchPrint("Process name", 24);
    StretchPrint("Memory", 16);
    printf("\n");

    count = GetThreadCount();
    if(count < 0) return 1;
    for(pid = 0; pid < count; ++pid) {
        if(GetThreadPriority(pid) == 0) continue;

        snprintf(str, sizeof(str), "%d", pid); StretchPrint(str, 8);
        snprintf(str, sizeof(str), "%d", GetThreadSpending(pid)); StretchPrint(str, 12);
        snprintf(str, sizeof(str), "%d", GetThreadPriority(pid)); StretchPrint(str, 10);

        name[0] = 0;
        GetThreadName(pid, name);
        if(!name[0]) strcpy(name, "[none]");
        StretchPrint(name, 24);

        mem = GetThreadMemoryUsage(pid);
        if(mem > 0) snprintf(str, sizeof(str), "%dK", mem / 1024);
        else strcpy(str, "kernel");
        StretchPrint(str, 16);
        printf("\n");
    }
    return 0;
}
