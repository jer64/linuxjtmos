# JTMOS V67 static ELF32 application
APPNAME=lar
include app-common.mk
