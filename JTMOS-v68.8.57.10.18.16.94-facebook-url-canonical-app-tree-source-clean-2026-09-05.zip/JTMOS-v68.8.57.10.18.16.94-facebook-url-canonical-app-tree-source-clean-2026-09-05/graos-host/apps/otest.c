// UNIX open, write, close test.
#include <stdio.h>
#ifndef JTMOS
#include <fcntl.h>
#include <jtmos/app_port.h>
#endif

//
#define SZ	2048

//
int main(void)
{
	int i,i2,i4,fd;
	static unsigned char str[SZ];
	char fname[256];

	//
	for(i=0; i<5; i++)
	{
		//
		sprintf(fname, "otestfile%d.tmp", i);
#ifdef JTMOS
		if( (fd = open(fname, O_CREAT))<0 )
#else
		if( (fd = open(fname, O_WRONLY | O_CREAT | O_TRUNC, 0644))<0 )
#endif
		{
			printf("Could not create file '%s', reason=%d.\n",
				str, fd);
			break;
		}
		else	printf("%s: fd = %d.\n", 
					fname, fd);

		// Write stuff...
		for(i2=0; i2<400; i2++)
		{
			printf(".");
			memset(str, i2, SZ);
			write(fd, str, SZ);
		}
		printf("\n");
		close(fd);

		// Verify ....
		fd = open(fname, 0);
		for(i2=0; i2<400; i2++)
		{
			printf("v");
			memset(str, 0xFF, SZ);
			read(fd, str, SZ);
			for(i4=0; i4<SZ; i4++)
			{
				if(str[i4]!=(i2&255))
				{
					printf("\nChecksum error: i2=%d (0x%x), file=%s\n",
						i2,i2*SZ,fname);
					sleep(5);
					goto past;
				}
			}
		}
		close(fd);

	}

	//
past:

	//
	printf("%d files written.\n",
		i);

	return 0;
}

//


