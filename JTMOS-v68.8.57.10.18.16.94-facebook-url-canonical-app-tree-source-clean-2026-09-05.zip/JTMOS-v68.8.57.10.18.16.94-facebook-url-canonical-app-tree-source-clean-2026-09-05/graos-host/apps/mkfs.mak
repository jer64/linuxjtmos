# JTMOS V67 static ELF32 application
APPNAME=mkfs
include app-common.mk
