# JTMOS V67 static ELF32 application
APPNAME=wintest3
include app-common.mk
