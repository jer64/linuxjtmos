#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <poll.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/sysinfo.h>
#include <sys/resource.h>
#include <string.h>

static int test_proc(void)
{
    int fd,n;
    char b[192];
    fd=open("/proc/uptime",O_RDONLY);
    if(fd<0) return 1;
    n=(int)read(fd,b,sizeof(b)-1);
    close(fd);
    if(n<=0) return 2;
    b[n]=0;
    printf("/proc/uptime: %s",b);
    return 0;
}

static int test_devzero(void)
{
    int fd,n,i;
    unsigned char b[32];
    memset(b,0xa5,sizeof(b));
    fd=open("/dev/zero",O_RDONLY);
    if(fd<0) return 1;
    n=(int)read(fd,b,sizeof(b));
    close(fd);
    if(n!=(int)sizeof(b)) return 2;
    for(i=0;i<n;i++) if(b[i]!=0) return 3;
    return 0;
}

static int test_pipe_wait(void)
{
    int fds[2],status,n;
    pid_t child,rv;
    struct pollfd p;
    char b[32];

    if(pipe(fds)!=0) return 1;
    child=fork();
    if(child<0) return 2;
    if(child==0)
    {
        close(fds[0]);
        (void)write(fds[1],"pipe-ok",7);
        close(fds[1]);
        return 7;
    }

    close(fds[1]);
    p.fd=fds[0]; p.events=POLLIN; p.revents=0;
    if(poll(&p,1,2000)<=0) { close(fds[0]); return 3; }
    n=(int)read(fds[0],b,sizeof(b)-1);
    close(fds[0]);
    if(n!=7) return 4;
    b[n]=0;
    if(strcmp(b,"pipe-ok")) return 5;
    rv=waitpid(child,&status,0);
    if(rv!=child || !WIFEXITED(status) || WEXITSTATUS(status)!=7) return 6;
    return 0;
}

int main(void)
{
    struct utsname u;
    struct sysinfo si;
    int rc;

    printf("JTMOS Linux core10 self-test\n");
    printf("pid=%d ppid=%d nice=%d\n",(int)getpid(),(int)getppid(),getpriority(PRIO_PROCESS,0));

    if(uname(&u)!=0) { printf("FAIL uname\n"); return 1; }
    printf("uname: %s %s %s %s\n",u.sysname,u.release,u.version,u.machine);
    if(sysinfo(&si)!=0) { printf("FAIL sysinfo\n"); return 2; }
    printf("uptime=%ld sec free=%lu total=%lu procs=%u\n",
           si.uptime,si.freeram,si.totalram,(unsigned)si.procs);

    if(signal(SIGTERM,SIG_IGN)==SIG_ERR || kill(getpid(),SIGTERM)!=0)
    { printf("FAIL signal ignore\n"); return 3; }
    (void)signal(SIGTERM,SIG_DFL);

    rc=test_proc(); if(rc) { printf("FAIL procfs %d\n",rc); return 10+rc; }
    rc=test_devzero(); if(rc) { printf("FAIL devzero %d\n",rc); return 20+rc; }
    rc=test_pipe_wait(); if(rc) { printf("FAIL pipe/wait %d\n",rc); return 30+rc; }

    printf("PASS linux-core10\n");
    return 0;
}
