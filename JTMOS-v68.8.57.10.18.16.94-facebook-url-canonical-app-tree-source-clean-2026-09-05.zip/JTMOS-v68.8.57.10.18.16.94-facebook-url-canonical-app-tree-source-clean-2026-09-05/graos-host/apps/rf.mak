# Historical JTMOS application placeholder.
APPNAME=rf
.PHONY: default clean
default:
	@echo "rf: source file is not present in the active libc/apps tree; target is archival only." >&2
	@false
clean:
	@rm -f rf.o rf.bin rf.map
