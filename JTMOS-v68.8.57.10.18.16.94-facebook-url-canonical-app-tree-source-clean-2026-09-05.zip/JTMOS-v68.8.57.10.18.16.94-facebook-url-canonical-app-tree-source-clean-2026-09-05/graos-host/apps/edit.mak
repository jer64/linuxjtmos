APPNAME=edit
LIBCDIR=../libc
CC?=gcc
LD?=ld
CFLAGS=-m32 -march=i486 -std=gnu89 -O2 -ffreestanding -fno-builtin -fno-stack-protector -fno-pie -fno-pic -fno-unwind-tables -fno-asynchronous-unwind-tables -nostdinc -Ulinux -U__linux -U__linux__ -DJTMOS=1 -DJTMOS_APPLICATION=1 -DJTMOS_LEGACY_SOURCE=1 -DCPU=i486 -I$(LIBCDIR)/include
OBJS=edit.o editEditor.o
default all: $(APPNAME).bin
%.o: %.c
	$(CC) $(CFLAGS) -c $< -o $@
$(APPNAME).bin: $(OBJS)
	$(MAKE) -C $(LIBCDIR) application
	$(LD) -m elf_i386 -static -z noexecstack -T $(LIBCDIR)/jtmos_elf32.ld $(LIBCDIR)/build/application/crt0.o $(OBJS) $(LIBCDIR)/libcjtmos.a -o $@
clean:
	rm -f $(OBJS) $(APPNAME).bin
