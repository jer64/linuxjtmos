/* cat.c - concatenate files or standard input to standard output */
#include <stdio.h>
#include <string.h>

static int cat_stream(FILE *f, const char *label, int close_after)
{
    unsigned char buf[4096];
    size_t got;
    while((got=fread(buf,1U,sizeof(buf),f))!=0U) {
        if(fwrite(buf,1U,got,stdout)!=got) {
            fprintf(stderr,"cat: write error while reading '%s'\n",label);
            if(close_after) fclose(f);
            return 1;
        }
        SwitchToThread();
    }
    if(ferror(f)) {
        fprintf(stderr,"cat: read error on '%s'\n",label);
        if(close_after) fclose(f);
        return 1;
    }
    return close_after && fclose(f)!=0;
}

static int cat_file(const char *path)
{
    FILE *f;
    if(!strcmp(path,"-")) return cat_stream(stdin,"stdin",0);
    f=fopen(path,"rb");
    if(f==NULL) {
        fprintf(stderr,"cat: cannot open '%s'\n",path);
        return 1;
    }
    return cat_stream(f,path,1);
}

static void help(void)
{
    printf("Usage: cat [FILE ...]\n");
    printf("Concatenate files to standard output; '-' or no FILE reads stdin.\n");
}

int main(int argc, char **argv)
{
    int i,rc=0;
    if(argc==1) return cat_stream(stdin,"stdin",0);
    if(argc==2 && (!strcmp(argv[1],"-h") || !strcmp(argv[1],"--help"))) {
        help(); return 0;
    }
    for(i=1;i<argc;i++) if(cat_file(argv[i])!=0) rc=1;
    return rc;
}
