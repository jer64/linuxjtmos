/* D64 2 Zipcode, version 1.1.
 * Original converter (C) 1993 Tony Ambardar.
 * JTMOS port by Jari Tuominen; bounds/error handling refreshed in 2026.
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

#define DBLOCKS 683
#define D64_SECTOR_BYTES 256
#define PART_NAME_SIZE 256
#define REP_INFO_COUNT 64

typedef unsigned char byte;
typedef enum { WHOLE=0, VARIABLE, NONE } repeat_t;

static const char info[]=
    " D64 2 Zipcode   Version 1.1   Tony Ambardar (C) 1993\n";
static const char repeat_c[]=".oO";
static const byte trk_lims[4]={0,8,16,25};
static byte image_buffer[DBLOCKS*D64_SECTOR_BYTES];
static byte max_sector[35];

static int num_repeats;
static byte repchar;
static int rle_len;
static struct {
    int startpos;
    int len;
} rep_info[REP_INFO_COUNT];

static FILE *zipfile;

static repeat_t rep_scan(const byte *sec_buf);
static int init_stuff(const char *name);
static int openfiles(int track,const char *base_name);

static int write_byte(int value)
{
    return fputc(value,zipfile)==EOF ? -1 : 0;
}

static int write_data(const void *data,size_t amount)
{
    return fwrite(data,1,amount,zipfile)==amount ? 0 : -1;
}

int main(int argc,char **argv)
{
    byte *sec_buf;
    int i,j,k,track,sector,base;
    int oddadd,evenadd,begin,length;
    repeat_t sec_type;

    if(argc!=3) {
        printf("%s",info);
        printf("Converts a .D64 disk image to a Zipcode 4-pack\n\n");
        printf("Usage: %s diskimage.d64 zipfilename\n",argv[0]);
        return argc==1 ? 0 : 2;
    }
    if(strlen(argv[2])+3U>=PART_NAME_SIZE) {
        fprintf(stderr,"d642zip: output name is too long.\n");
        return 2;
    }
    if(init_stuff(argv[1])!=0)
        return 1;

    zipfile=NULL;
    base=0;
    oddadd=11;
    evenadd=-10;
    printf("\n            RLE Compression Map:\n");
    printf("O = No Compression  -->  . = Max. Compression\n");
    for(track=0;track<35;base+=max_sector[track++]+1) {
        printf("\nTrack: %2u ",track+1);
        if(openfiles(track,argv[2])!=0)
            goto write_error;
        if(track==17 || track==24) {
            --oddadd;
            ++evenadd;
        }
        i=base-evenadd;
        sector=-evenadd;
        for(k=0;k<=max_sector[track];k++) {
            i+=k%2 ? oddadd : evenadd;
            sector+=k%2 ? oddadd : evenadd;
            if(i<0 || i>=DBLOCKS) {
                fprintf(stderr,"\nd642zip: internal sector map error.\n");
                goto fail;
            }
            sec_buf=image_buffer+i*D64_SECTOR_BYTES;
            sec_type=rep_scan(sec_buf);
            printf("%c",repeat_c[sec_type]);

            if(sec_type==NONE) {
                if(write_byte(track+1)!=0 || write_byte(sector)!=0 ||
                   write_data(sec_buf,D64_SECTOR_BYTES)!=0)
                    goto write_error;
            } else if(sec_type==WHOLE) {
                if(write_byte(track+1+64)!=0 || write_byte(sector)!=0 ||
                   write_byte(sec_buf[0])!=0)
                    goto write_error;
            } else {
                if(write_byte(track+1+128)!=0 || write_byte(sector)!=0 ||
                   write_byte(rle_len)!=0 || write_byte(repchar)!=0)
                    goto write_error;
                for(j=0;j<num_repeats;j++) {
                    begin=j==0 ? 0 :
                        rep_info[j-1].startpos+rep_info[j-1].len;
                    length=rep_info[j].startpos-begin;
                    if(length<0 || write_data(sec_buf+begin,(size_t)length)!=0 ||
                       write_byte(repchar)!=0 ||
                       write_byte(rep_info[j].len)!=0 ||
                       write_byte(sec_buf[rep_info[j].startpos])!=0)
                        goto write_error;
                }
                begin=rep_info[num_repeats-1].startpos+
                      rep_info[num_repeats-1].len;
                length=D64_SECTOR_BYTES-begin;
                if(length<0 || write_data(sec_buf+begin,(size_t)length)!=0)
                    goto write_error;
            }
        }
    }
    if(zipfile!=NULL && fclose(zipfile)!=0) {
        zipfile=NULL;
        goto write_error;
    }
    zipfile=NULL;
    printf("\n\nDone.\n");
    return 0;

write_error:
    fprintf(stderr,"\nd642zip: error writing output files.\n");
fail:
    if(zipfile!=NULL) fclose(zipfile);
    zipfile=NULL;
    return 1;
}

static int openfiles(int track,const char *base_name)
{
    int i,n;
    char part_name[PART_NAME_SIZE];
    static const byte first_header[4]={0xfe,0x03,0x21,0x21};
    static const byte next_header[2]={0x00,0x04};

    for(i=0;i<4;i++) {
        if(trk_lims[i]!=track)
            continue;
        if(zipfile!=NULL) {
            if(fclose(zipfile)!=0) {
                zipfile=NULL;
                return -1;
            }
            zipfile=NULL;
        }
        n=snprintf(part_name,sizeof(part_name),"%d!%s",i+1,base_name);
        if(n<0 || n>=(int)sizeof(part_name))
            return -1;
        zipfile=fopen(part_name,"wb");
        if(zipfile==NULL) {
            fprintf(stderr,"d642zip: cannot create '%s' (error %d).\n",
                    part_name,errno);
            return -1;
        }
        if(i==0) return write_data(first_header,sizeof(first_header));
        return write_data(next_header,sizeof(next_header));
    }
    return zipfile==NULL ? -1 : 0;
}

static int init_stuff(const char *name)
{
    int i;
    FILE *imgfile;
    size_t got;

    for(i=0;i<17;max_sector[i++]=20) {}
    for(i=17;i<24;max_sector[i++]=18) {}
    for(i=24;i<30;max_sector[i++]=17) {}
    for(i=30;i<35;max_sector[i++]=16) {}

    imgfile=fopen(name,"rb");
    if(imgfile==NULL) {
        fprintf(stderr,"d642zip: cannot open '%s' (error %d).\n",name,errno);
        return -1;
    }
    got=fread(image_buffer,1,sizeof(image_buffer),imgfile);
    if(fclose(imgfile)!=0 || got!=sizeof(image_buffer)) {
        fprintf(stderr,
                "d642zip: D64 image must contain at least %u bytes (read %u).\n",
                (unsigned)sizeof(image_buffer),(unsigned)got);
        return -1;
    }
    return 0;
}

static repeat_t rep_scan(const byte *sec_buf)
{
    int i,j,count;
    byte table[256];

    rle_len=D64_SECTOR_BYTES;
    num_repeats=0;
    for(i=0;i<D64_SECTOR_BYTES-1;i++) {
        count=0;
        while(i<D64_SECTOR_BYTES-1 && sec_buf[i]==sec_buf[i+1]) {
            i++;
            count++;
        }
        if(count>=3) {
            if(num_repeats>=REP_INFO_COUNT)
                return NONE;
            rep_info[num_repeats].startpos=i-count;
            rep_info[num_repeats].len=count+1;
            num_repeats++;
        }
    }
    if(num_repeats==0)
        return NONE;
    if(num_repeats==1 && rep_info[0].startpos==0 &&
       rep_info[0].len==D64_SECTOR_BYTES)
        return WHOLE;

    rle_len+=num_repeats*3;
    for(i=0;i<num_repeats;i++)
        rle_len-=rep_info[i].len;
    if(rle_len>253)
        return NONE;

    for(j=0;j<256;j++) table[j]=1;
    for(j=0;j<D64_SECTOR_BYTES;j++) table[sec_buf[j]]=0;
    for(j=0;j<256 && table[j]==0;j++) {}
    if(j>=256)
        return NONE;
    repchar=(byte)j;
    return VARIABLE;
}
