// Network Test
#include <stdio.h>
#include <stdlib.h>
#include <jtmos/network.h>
#include <jtmos/admin.h>
#include <string.h>

/* Build an IPv4 address without signed left-shift undefined behaviour. */
#define CIP(n1,n2,n3,n4) \
    ((unsigned)(n1) | ((unsigned)(n2)<<8) | \
     ((unsigned)(n3)<<16) | ((unsigned)(n4)<<24))

static int parse_decimal(const char *s, int *value)
{
    char *end;
    long v;

    if(s==NULL || value==NULL || *s=='\0') return 0;
    v=strtol(s,&end,10);
    if(end==s || *end!='\0') return 0;
    if(v < -2147483647L-1L || v > 2147483647L) return 0;
    *value=(int)v;
    return 1;
}

static void net_usage(void)
{
    printf("Usage: net restart|status\n");
    printf("       net [n1 n2 n3 n4 port]\n");
    printf("Example: net 195 74 0 47 1234\n");
}

int main(int argc, char **argv)
{
    int sh,ip1=0,ip2=0,ip3=0,ip4=0,port=0;
    int parsed;
    char str[256];

    printf("JTMOS net 1.2\n");

    /* System lifecycle actions are implemented by the kernel's existing
     * network owner rather than by opening a second NIC consumer here. */
    if(argc==2 && argv[1]!=NULL &&
       (!strcmp(argv[1],"restart") || !strcmp(argv[1],"reset")))
    {
        int rc=jtmos_smsh_builtin("internet restart");
        if(rc==-3) printf("net: network administration command is not exported by this kernel.\n");
        else if(rc==-2) printf("net: internet command is unavailable in this kernel build.\n");
        else if(rc<0) printf("net: restart failed (%d).\n",rc);
        return rc==0?0:1;
    }
    if(argc==2 && argv[1]!=NULL && !strcmp(argv[1],"status"))
    {
        int rc=jtmos_smsh_builtin("internet status");
        if(rc<0) printf("net: status failed (%d).\n",rc);
        return rc==0?0:1;
    }

    /* argc==1 is the normal bare `net` command.  Never touch argv[1]
     * unless it actually exists.  The old code compared the first optional argument
     * here and page-faulted at address 0. */
    if(argc==1)
    {
        printf("Example: 195 74 0 47 1234\n");
        printf("Enter IP (format: n1 n2 n3 n4 port): ");
        if(fgets(str,sizeof(str),stdin)==NULL)
        {
            printf("\nNo input.\n");
            return 1;
        }
        parsed=sscanf(str,"%d %d %d %d %d",
                      &ip1,&ip2,&ip3,&ip4,&port);
        if(parsed!=5)
        {
            printf("Invalid address/port input.\n");
            net_usage();
            return 1;
        }
    }
    else if(argc==6)
    {
        if(!parse_decimal(argv[1],&ip1) ||
           !parse_decimal(argv[2],&ip2) ||
           !parse_decimal(argv[3],&ip3) ||
           !parse_decimal(argv[4],&ip4) ||
           !parse_decimal(argv[5],&port))
        {
            printf("Invalid numeric argument.\n");
            net_usage();
            return 1;
        }
    }
    else
    {
        net_usage();
        return 1;
    }

    if(ip1<=0 || ip1>255 || ip2<0 || ip2>255 ||
       ip3<0 || ip3>255 || ip4<0 || ip4>255)
    {
        printf("Invalid IPv4 address: %d.%d.%d.%d\n",ip1,ip2,ip3,ip4);
        return 1;
    }
    if(port<=0 || port>65535)
    {
        printf("Invalid port.\n");
        return 1;
    }

    printf("Connecting to %d.%d.%d.%d:%d ... ",
           ip1,ip2,ip3,ip4,port);
    sh=OpenSocket(CIP(ip1,ip2,ip3,ip4),port);
    if(sh<0)
        printf("\nCould not connect.\n");
    else
    {
        printf("\nConnection established.\n");
        CloseSocket(sh);
    }

    return 0;
}
