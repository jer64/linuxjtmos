//==============================================================
// JTMOS Setup Program
// (C) 2003 by Jari Tuominen
//==============================================================
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <errno.h>
#include <conio.h>
#ifndef JTMOS
#include <jtmos/app_port.h>
#endif

static int make_directory(const char *name,mode_t mode)
{
    if(mkdir(name,mode)==0 || errno==EEXIST) return 0;
    printf("setup: cannot create directory '%s' (error %d).\n",name,errno);
    return -1;
}

int main(int argc, char **argv)
{
	textcolor(7); textbackground(BLUE);
	clrscr();

	// Report
	printf("\n");
	textbackground(RED);
	printf("  Welcome to JTMOS installation  \n");
	textbackground(BLUE);
	printf("\n");
	printf("Note: installation will erase hard disk's contents\n");
	printf("press [i] to format HD & install JTMOS\n");
	printf("press [ESC] to cancel installation\n");
	if(getch()!='i')
	{
		printf("> Cancelling installation.\n");
		sleep(2);
		exit(0);
	}
	printf("> Installing ");
	sleep(2);

	// Install
	clrscr();
	if(system("mkfs hda")!=0)
	{
		printf("setup: disk formatting failed; installation stopped.\n");
		return 2;
	}
	clrscr();
	printf("\n  Installing JTMOS core files\n");
	printf("  ===========================\n\n");
	printf("\n");
	printf("  This will take a moment please wait awhile ... \n\n");

	//
	printf("- directory structure creation\n");
	if(chdir("/hda")!=0 ||
	   make_directory("bin",0755)!=0 ||
	   make_directory("etc",0755)!=0 ||
	   make_directory("home",0755)!=0 ||
	   make_directory("root",0700)!=0 ||
	   make_directory("usr",0755)!=0 ||
	   make_directory("tmp",0777)!=0)
		return 3;

	// Copy files (I)
	printf("- copying files\n");

	// Install install.img & unz
	if(chdir("/hda/bin")!=0)
		return 3;
	if(system(":install -q -o /hda/bin")!=0)
	{
		printf("setup: cannot extract the installation image.\n");
		return 4;
	}
	printf("\n");

	// Unpack install.img.nz
	// Extract install.img archive
	if(chdir("/hda/bin")!=0 || system("unz")!=0)
	{
		printf("setup: final archive extraction failed.\n");
		return 5;
	}

	printf("Installation completed.\n"); sleep(1);
	return 0;
}
