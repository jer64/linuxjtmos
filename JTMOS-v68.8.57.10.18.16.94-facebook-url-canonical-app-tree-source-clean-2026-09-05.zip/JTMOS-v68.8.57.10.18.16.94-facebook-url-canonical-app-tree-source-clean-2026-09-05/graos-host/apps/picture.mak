# JTMOS V67 static ELF32 application
APPNAME=picture
include app-common.mk
