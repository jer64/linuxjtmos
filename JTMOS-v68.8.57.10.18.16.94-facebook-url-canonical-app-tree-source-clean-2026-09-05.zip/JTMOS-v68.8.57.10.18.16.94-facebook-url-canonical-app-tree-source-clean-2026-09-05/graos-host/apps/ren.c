/* ren.c - rename a file */
#include <stdio.h>
#include <string.h>

static void help(void)
{
    printf("Usage: ren OLDNAME NEWNAME\n");
    printf("Rename a file on the current JTMOS filesystem.\n");
}

int main(int argc, char **argv)
{
    if(argc == 2 && (!strcmp(argv[1], "-h") || !strcmp(argv[1], "--help") || !strcmp(argv[1], "/?"))) {
        help();
        return 0;
    }
    if(argc != 3) {
        help();
        return 1;
    }
    if(rename(argv[1], argv[2]) != 0) {
        printf("ren: cannot rename '%s' to '%s'\n", argv[1], argv[2]);
        return 1;
    }
    return 0;
}
