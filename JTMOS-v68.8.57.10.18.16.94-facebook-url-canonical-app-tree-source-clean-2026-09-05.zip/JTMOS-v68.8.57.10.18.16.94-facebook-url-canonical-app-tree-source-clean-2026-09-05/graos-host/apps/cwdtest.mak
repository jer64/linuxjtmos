# JTMOS V67 static ELF32 application
APPNAME=cwdtest
include app-common.mk
