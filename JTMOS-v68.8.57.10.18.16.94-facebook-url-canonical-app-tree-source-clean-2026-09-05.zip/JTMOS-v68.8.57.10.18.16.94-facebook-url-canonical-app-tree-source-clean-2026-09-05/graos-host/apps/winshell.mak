# JTMOS V67 static ELF32 application
APPNAME=winshell
include app-common.mk
