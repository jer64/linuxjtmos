#ifndef JTMOS_GRAOS_DEMO_H
#define JTMOS_GRAOS_DEMO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/process.h>

typedef struct JTMOS_GRAOS_DEMO {
    int wid;
    int width;
    int height;
    int closed;
    int focused;
    GRAOS_PIXEL *pixels;
} JTMOS_GRAOS_DEMO;

static int jtmos_demo_open(JTMOS_GRAOS_DEMO *d,const char *title,int width,int height)
{
    size_t bytes;
    if(!d || width<=0 || height<=0) return -1;
    memset(d,0,sizeof(*d));
    d->wid=-1; d->width=width; d->height=height; d->focused=1;
    if(connectGraos()!=0) {
        printf("%s: GraOS is not running.\n",title?title:"demo");
        return -1;
    }
    if((size_t)width>((size_t)-1)/(size_t)height ||
       (size_t)width*(size_t)height>((size_t)-1)/sizeof(GRAOS_PIXEL))
        return -2;
    bytes=(size_t)width*(size_t)height*sizeof(GRAOS_PIXEL);
    d->pixels=(GRAOS_PIXEL*)malloc(bytes);
    if(!d->pixels) return -2;
    memset(d->pixels,0,bytes);
    d->wid=createWindow(-1,-1,width,height+20,title?title:"JTMOS Demo",GRAOS_WINDOW_STANDARD);
    if(d->wid<0) { free(d->pixels); d->pixels=NULL; return -3; }
    if(addFrameBuffer(d->wid,d->pixels,0,0,width,height,GRAOS_BPP,GRAOS_SURFACE_BITMAP,0)<0) {
        closeWindow(d->wid); free(d->pixels); d->pixels=NULL; d->wid=-1; return -4;
    }
    if(refreshWindow(d->wid)<0) {
        closeWindow(d->wid); free(d->pixels); d->pixels=NULL; d->wid=-1; return -5;
    }
    return 0;
}

/* Returns one key code if available, 0 otherwise, and -1 when the window was
 * closed. Focus/blur are consumed here so animation clients can stop burning
 * CPU while another GraOS window is selected. */
static int jtmos_demo_poll(JTMOS_GRAOS_DEMO *d)
{
    GUICMD ev;
    int er,key=0;
    if(!d || d->closed) return -1;
    while((er=JtmosGraOSPollEvent(d->wid,&ev))>0) {
        if(ev.id==GRAOS_GSID_EXIT) { d->closed=1; return -1; }
        if(ev.id==GRAOS_GSID_WINDOW_FOCUS) { d->focused=1; continue; }
        if(ev.id==GRAOS_GSID_WINDOW_BLUR || ev.id==GRAOS_GSID_WINDOW_MINIMIZED) { d->focused=0; continue; }
        if(ev.id==GRAOS_GSID_WINDOW_RESTORED) { d->focused=1; continue; }
        if(ev.id==GRAOS_GSID_KEYPRESSED && key==0) key=ev.v[0];
    }
    if(er<0) {
        /* The server has gone away or already destroyed this window.  Mark it
         * closed so cleanup cannot close a newly reused numeric window id. */
        d->closed=1;
        return -1;
    }
    return key;
}

static int jtmos_demo_present(JTMOS_GRAOS_DEMO *d)
{
    if(!d || d->closed || d->wid<0) return -1;
    return refreshWindow(d->wid);
}

static void jtmos_demo_close(JTMOS_GRAOS_DEMO *d)
{
    if(!d) return;
    if(d->wid>=0 && !d->closed) closeWindow(d->wid);
    if(d->pixels) free(d->pixels);
    d->pixels=NULL; d->wid=-1; d->closed=1;
}

static void jtmos_demo_idle(unsigned long ms)
{
    SwitchToThread();
    if(ms) Sleep(ms);
}

static void jtmos_demo_fill(JTMOS_GRAOS_DEMO *d,GRAOS_PIXEL color)
{
    int i,n;
    if(!d || !d->pixels) return;
    n=d->width*d->height;
    for(i=0;i<n;i++) d->pixels[i]=color;
}

static void jtmos_demo_rect(JTMOS_GRAOS_DEMO *d,int x1,int y1,int x2,int y2,GRAOS_PIXEL color)
{
    int x,y,t;
    if(!d || !d->pixels) return;
    if(x1>x2) { t=x1; x1=x2; x2=t; }
    if(y1>y2) { t=y1; y1=y2; y2=t; }
    if(x1<0) x1=0;
    if(y1<0) y1=0;
    if(x2>=d->width) x2=d->width-1;
    if(y2>=d->height) y2=d->height-1;
    if(x1>x2 || y1>y2) return;
    for(y=y1;y<=y2;y++) for(x=x1;x<=x2;x++) d->pixels[y*d->width+x]=color;
}

#endif
