APPNAME=irqdma
include app-common.mk
