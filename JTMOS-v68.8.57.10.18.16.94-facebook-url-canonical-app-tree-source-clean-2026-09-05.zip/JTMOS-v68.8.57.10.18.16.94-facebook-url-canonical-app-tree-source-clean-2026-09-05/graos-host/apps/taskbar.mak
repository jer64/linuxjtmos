# JTMOS V67 static ELF32 application
APPNAME=taskbar
include app-common.mk
