APPNAME := linuxcore10
include app-common.mk
