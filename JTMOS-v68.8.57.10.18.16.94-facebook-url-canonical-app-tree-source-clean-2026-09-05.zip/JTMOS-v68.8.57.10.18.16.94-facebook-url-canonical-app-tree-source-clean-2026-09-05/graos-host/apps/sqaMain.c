#include <stdio.h>
#include <string.h>
#include "sqa.h"

#if defined(JTMOS_APPLICATION)
#include <jtmos/process.h>
SYSMEMREQ(APPRAM_2048K)
#endif

int sqa_main(int argc, char **argv)
{
    int i, rc;
    if(argc < 2) {
        printf("Squirrel Archive Extractor V65\n");
        printf("Usage: %s archive-or-device [-q] [-u file] [-o directory]\n",argv[0]);
        return 0;
    }
    quiet = 0;
    specific[0] = '\0';
    dstdir[0] = '\0';
    for(i=2;i<argc;++i) {
        if(strcmp(argv[i],"-q") == 0) quiet = 1;
        else if(strcmp(argv[i],"-u") == 0) {
            if(++i >= argc || strlen(argv[i]) >= sizeof(specific)) return 2;
            strcpy(specific,argv[i]);
        } else if(strcmp(argv[i],"-o") == 0) {
            if(++i >= argc || strlen(argv[i]) >= sizeof(dstdir)) return 2;
            strcpy(dstdir,argv[i]);
        } else {
            fprintf(stderr,"sqa: unknown option %s\n",argv[i]);
            return 2;
        }
    }
    seloffs = 0;
    rc = extract_archive(argv[1],specific);
    if(rc == 1) {
        seloffs = 640 * 1024;
        rc = extract_archive(argv[1],specific);
    }
    if(rc != 0 && !quiet) fprintf(stderr,"sqa: error %d\n",rc);
    return rc;
}

#ifndef JTMOSKERNEL
int main(int argc, char **argv) { return sqa_main(argc,argv); }
#endif
