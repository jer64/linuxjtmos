# JTMOS V67 static ELF32 application
APPNAME=clear
include app-common.mk
