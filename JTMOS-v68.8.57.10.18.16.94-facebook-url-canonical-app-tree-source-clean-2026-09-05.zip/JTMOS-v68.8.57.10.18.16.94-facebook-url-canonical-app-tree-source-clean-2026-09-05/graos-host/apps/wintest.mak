# JTMOS V67 static ELF32 application
APPNAME=wintest
include app-common.mk
