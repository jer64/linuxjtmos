// Process to Process talk demo
#include <stdio.h>
#include <string.h>
#include <jtmos/msgbox.h>
#ifndef JTMOS
#include <jtmos/app_port.h>
#endif
#define OTHER "listen"

//
int main(int argc, char **argv)
{
	int pid;
	MSG m,m2;
	char *say="Hello you process outhere!";
	char *reply="Hello to you as well!";

	// Enable our message box
	memset(&m, 0, sizeof(m));
	memset(&m2, 0, sizeof(m2));
	m.protocol = MB_PROTOCOL_POSTMAN;
	m2.protocol = MB_PROTOCOL_POSTMAN;
	startMessageBox();

#ifndef LISTEN
	// Look for listenning process
	if( (pid=GetThreadPID(OTHER))==-1 )
	{
		//
		printf("Process '%s' is not running.\n",
			OTHER);
		return 0;
	}

	//
	if(strlen(say)+1U>sizeof(m.buf)) return 1;
	memcpy(m.buf,say,strlen(say)+1U);
	m.amount = strlen(say)+1;
	sendMessage(&m, GetThreadPID(OTHER));
	printf("Message sent: '%s'\n", say);
#endif

#ifdef LISTEN
	// Get proper name for us
	IdentifyThread(GetCurrentThread(), OTHER);
#endif

	//
	printf("Waiting for message ... ");
	while( receiveMessage(&m)==0 )
		SwitchToThread();
	printf("\nI received message: '%s'\n",
		m.buf);

#ifdef LISTEN
	// Send a reply
	if(strlen(reply)+1U>sizeof(m2.buf)) return 1;
	memcpy(m2.buf,reply,strlen(reply)+1U);
	m2.amount = strlen(reply)+1;
	sendMessage(&m2, m.sndPID);
#endif

	//
	return 0;
}
