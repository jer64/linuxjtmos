/* cp.c - copy files */
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <jtmos/filefind.h>

#ifdef JTMOS
SYSMEMREQ(APPRAM_2048K)
#endif

static int verbose = 0;

static void normalize_lexical_path(char *out, size_t cap, const char *path)
{
    size_t n=0;
    const char *p=path;
    if(cap==0) return;
    while(p && p[0]=='.' && (p[1]=='/' || p[1]=='\\')) p+=2;
    while(p && *p && n+1<cap)
    {
        char c=*p++;
        if(c=='\\') c='/';
        if(c=='/' && n>0 && out[n-1]=='/') continue;
        if(c=='.' && n>0 && out[n-1]=='/' && (*p=='/' || *p=='\\'))
        { ++p; continue; }
        out[n++]=c;
    }
    while(n>1 && out[n-1]=='/') --n;
    out[n]=0;
}

static int same_lexical_path(const char *a, const char *b)
{
    char na[512],nb[512];
    normalize_lexical_path(na,sizeof(na),a);
    normalize_lexical_path(nb,sizeof(nb),b);
    return !strcmp(na,nb);
}

static int has_wildcards(const char *s)
{
    return s != NULL && (strchr(s, '*') != NULL || strchr(s, '?') != NULL);
}

static int wildcard_match(const char *pattern, const char *text)
{
    while(*pattern) {
        if(*pattern == '*') {
            while(*pattern == '*') ++pattern;
            if(!*pattern) return 1;
            while(*text) {
                if(wildcard_match(pattern, text)) return 1;
                ++text;
            }
            return 0;
        }
        if(*pattern == '?') {
            if(!*text) return 0;
            ++pattern;
            ++text;
            continue;
        }
        if(*pattern != *text) return 0;
        ++pattern;
        ++text;
    }
    return *text == 0;
}

static const char *base_name(const char *path)
{
    const char *p;
    const char *base = path;
    for(p = path; p && *p; ++p)
        if(*p == '/' || *p == '\\') base = p + 1;
    return base;
}

static int path_is_dir(const char *path)
{
    struct stat st;
    return path != NULL && stat(path, &st) == 0 && S_ISDIR(st.st_mode);
}

static int make_target(char *out, size_t outsz, const char *dst,
                       const char *src, int force_directory)
{
    size_t n;
    if(force_directory || path_is_dir(dst)) {
        n = strlen(dst);
        if(n && (dst[n-1] == '/' || dst[n-1] == '\\'))
            return snprintf(out, outsz, "%s%s", dst, base_name(src)) < (int)outsz ? 0 : 1;
        return snprintf(out, outsz, "%s/%s", dst, base_name(src)) < (int)outsz ? 0 : 1;
    }
    return snprintf(out, outsz, "%s", dst) < (int)outsz ? 0 : 1;
}

static int copy_exact(const char *src, const char *dst)
{
    FILE *in;
    FILE *out;
    unsigned char buf[8192];
    size_t got;
    int rc = 0;

    if(same_lexical_path(src, dst)) {
        printf("cp: '%s' and '%s' are the same file\n", src, dst);
        return 1;
    }
    in = fopen(src, "rb");
    if(in == NULL) {
        printf("cp: cannot open '%s'\n", src);
        return 1;
    }
    out = fopen(dst, "wb");
    if(out == NULL) {
        printf("cp: cannot create '%s'\n", dst);
        fclose(in);
        return 1;
    }

    while((got = fread(buf, 1U, sizeof(buf), in)) != 0U) {
        if(fwrite(buf, 1U, got, out) != got) {
            printf("cp: write error on '%s'\n", dst);
            rc = 1;
            break;
        }
        SwitchToThread();
    }
    if(ferror(in)) {
        printf("cp: read error on '%s'\n", src);
        rc = 1;
    }
    if(fclose(in) != 0) rc = 1;
    if(fclose(out) != 0) rc = 1;
    if(rc == 0 && verbose) printf("'%s' -> '%s'\n", src, dst);
    return rc;
}

static int copy_pattern(const char *pattern, const char *dst)
{
    FFBLK ff;
    int fd;
    int matched = 0;
    int rc = 0;
    char target[512];

    if(!path_is_dir(dst)) {
        printf("cp: destination '%s' must be a directory for wildcard copies\n", dst);
        return 1;
    }
    fd = findfirst("*", &ff);
    if(fd <= 0) {
        printf("cp: cannot list current directory\n");
        return 1;
    }
    for(;;) {
        if(ff.ff_fsize != -1 && !JTMFS_TYPE_IS_DIRECTORY(ff.ff_attrib) &&
           wildcard_match(pattern, ff.ff_name)) {
            ++matched;
            if(make_target(target, sizeof(target), dst, ff.ff_name, 1) != 0) {
                printf("cp: destination path too long for '%s'\n", ff.ff_name);
                rc = 1;
            } else if(copy_exact(ff.ff_name, target) != 0) {
                rc = 1;
            }
        }
        if(findnext(fd, &ff) != 0) break;
    }
    close(fd);
    if(!matched) {
        printf("cp: no files match '%s'\n", pattern);
        return 1;
    }
    return rc;
}

static void help(void)
{
    printf("Usage: cp [OPTIONS] SOURCE DEST\n");
    printf("Copy SOURCE to DEST. If DEST is a directory, keep SOURCE basename.\n");
    printf("Wildcards '*' and '?' are supported in the current directory.\n");
    printf("  -v, --verbose   show copied files\n");
    printf("  -h, --help      show this help\n");
}

int main(int argc, char **argv)
{
    const char *src = NULL;
    const char *dst = NULL;
    char target[512];
    int i;

    for(i = 1; i < argc; ++i) {
        if(!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help") || !strcmp(argv[i], "/?")) {
            help();
            return 0;
        }
        if(!strcmp(argv[i], "-v") || !strcmp(argv[i], "--verbose") || !strcmp(argv[i], "/v")) {
            verbose = 1;
            continue;
        }
        if(src == NULL) src = argv[i];
        else if(dst == NULL) dst = argv[i];
        else {
            printf("cp: too many arguments\n");
            return 1;
        }
    }

    if(src == NULL || dst == NULL) {
        help();
        return 1;
    }
    if(has_wildcards(src)) return copy_pattern(src, dst);
    if(make_target(target, sizeof(target), dst, src, 0) != 0) {
        printf("cp: destination path too long\n");
        return 1;
    }
    return copy_exact(src, target);
}
