# JTMOS V67 static ELF32 application
APPNAME=cp
include app-common.mk
