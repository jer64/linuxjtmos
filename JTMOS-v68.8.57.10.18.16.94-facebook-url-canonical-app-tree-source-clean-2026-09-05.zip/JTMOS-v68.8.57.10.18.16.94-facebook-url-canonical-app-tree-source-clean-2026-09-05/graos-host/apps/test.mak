# Historical JTMOS application placeholder.
APPNAME=test
.PHONY: default clean
default:
	@echo "test: source file is not present in the active libc/apps tree; target is archival only." >&2
	@false
clean:
	@rm -f test.o test.bin test.map
