# JTMOS V67 static ELF32 application
APPNAME=rm
include app-common.mk
