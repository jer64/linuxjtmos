# JTMOS V67 static ELF32 application
APPNAME=float_test
include app-common.mk
