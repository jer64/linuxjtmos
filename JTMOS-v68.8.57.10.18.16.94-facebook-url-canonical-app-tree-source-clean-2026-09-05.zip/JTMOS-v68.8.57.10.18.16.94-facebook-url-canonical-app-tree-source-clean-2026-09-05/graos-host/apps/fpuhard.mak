# JTMOS V67 static ELF32 application
APPNAME=fpuhard
include app-common.mk
