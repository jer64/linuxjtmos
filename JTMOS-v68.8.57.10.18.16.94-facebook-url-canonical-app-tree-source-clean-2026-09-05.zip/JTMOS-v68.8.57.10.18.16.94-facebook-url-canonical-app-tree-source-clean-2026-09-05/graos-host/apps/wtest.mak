# JTMOS V67 static ELF32 application
APPNAME=wtest
include app-common.mk
