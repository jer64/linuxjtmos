# JTMOS V67 static ELF32 application
APPNAME=snake
include app-common.mk
