/* nzipMain.c - command line front-end for nzip and unz. */
#include <stdio.h>
#include <string.h>
#include "nzip.h"

#ifdef UNCOMPRESS_ALL
#include "sqa.h"
#ifdef JTMOS_APPLICATION
#include <jtmos/file.h>
#include <jtmos/filefind.h>
#endif

static int has_nz_suffix(const char *s)
{
    size_t n;
    if(s == NULL) return 0;
    n = strlen(s);
    return n >= 3U && s[n-3U] == '.' && s[n-2U] == 'n' && s[n-1U] == 'z';
}

static int unz_one(const char *name)
{
    char out[512];
    int rc;
    if(!has_nz_suffix(name)) {
        fprintf(stderr,"unz: '%s' is not an .nz file\n",name ? name : "(null)");
        return 1;
    }
    if(nzip_output_name(out,sizeof(out),name) != 0) {
        fprintf(stderr,"unz: output name is too long\n");
        return 1;
    }
    printf("unz: decompressing %s\n",name);
    rc = nzip_uncompress(name,out);
    if(rc != 0) return rc;

    if(strlen(out) >= 4U && strcmp(out + strlen(out) - 4U,".img") == 0) {
        printf("unz: extracting Squirrel image %s\n",out);
        seloffs = 0;
        rc = extract_archive(out,"");
        if(rc != 0) {
            fprintf(stderr,"unz: SQA extraction failed (%d)\n",rc);
            return rc;
        }
        if(remove(out) == 0) printf("unz: removed staging image %s\n",out);
    }
    return 0;
}
#endif

int nzip_main(int argc, char **argv)
{
#ifdef UNCOMPRESS_ALL
    int fd, errors = 0, found = 0;
    FFBLK ff;
    printf("unz: JTMOS installer starting\n");
    if(argc > 2) {
        fprintf(stderr,"Usage: %s [archive.nz]\n",argv[0]);
        return 1;
    }
    if(argc == 2) return unz_one(argv[1]);

    if(fexist("install.img.nz")) return unz_one("install.img.nz");

    fd = findfirst("*",&ff);
    if(fd <= 0) {
        fprintf(stderr,"unz: install.img.nz not found and directory enumeration failed\n");
        return 1;
    }
    for(;;) {
        if(ff.ff_fsize >= 0 && has_nz_suffix(ff.ff_name)) {
            ++found;
            if(unz_one(ff.ff_name) != 0) ++errors;
        }
        if(findnext(fd,&ff)) break;
    }
    if(!found) {
        fprintf(stderr,"unz: no .nz files found\n");
        return 1;
    }
    return errors ? 1 : 0;
#else
    /* V16.71 default is NZIP2 fast LZ77.  Historical V1 codecs remain
     * selectable only for archive/recovery compatibility. */
    if(argc == 2) return nzip_compress_named_mode(argv[1],NZIP_MODE_AUTO);
    if(argc == 3 && strcmp(argv[1],"-d") == 0) return uncompress(argv[2]);
    if(argc == 3 && strcmp(argv[1],"--auto") == 0)
        return nzip_compress_named_mode(argv[2],NZIP_MODE_AUTO);
    if(argc == 3 && strcmp(argv[1],"--fast") == 0)
        return nzip_compress_named_mode(argv[2],NZIP_MODE_FAST);
    if(argc == 3 && strcmp(argv[1],"--legacy") == 0)
        return nzip_compress_named_mode(argv[2],NZIP_MODE_LEGACY);
    if(argc == 3 && strcmp(argv[1],"--bwt") == 0)
        return nzip_compress_named_mode(argv[2],NZIP_MODE_BWT);
    fprintf(stderr,"Usage: %s file\n"
                   "       %s --auto file\n"
                   "       %s --fast file\n"
                   "       %s --legacy file\n"
                   "       %s --bwt file\n"
                   "       %s -d file.nz\n",
            argv[0],argv[0],argv[0],argv[0],argv[0],argv[0]);
    return 1;
#endif
}

#ifndef JTMOSKERNEL
int main(int argc, char **argv)
{
    return nzip_main(argc,argv);
}
#endif
