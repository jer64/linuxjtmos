/* snake.c - GraOS windowed framebuffer Snake for JTMOS. */
#include <stdlib.h>
#include <conio.h>
#include <jtmos/process.h>
#include "graos_demo.h"
SYSMEMREQ(APPRAM_512K)

#define FB_W 320
#define FB_H 200
#define COLS 40
#define ROWS 22
#define CELL 8
#define MAX_SNAKE (COLS*ROWS)
#define DIR_UP 0
#define DIR_DOWN 1
#define DIR_LEFT 2
#define DIR_RIGHT 3

typedef struct { short x,y; } POINT;
static POINT body[MAX_SNAKE];
static int length,dir,foodx,foody,paused,dead;

static int occupied(int x,int y)
{
    int i; for(i=0;i<length;i++) if(body[i].x==x && body[i].y==y) return 1; return 0;
}
static int occupied_for_move(int x,int y,int grow)
{
    int i,limit=length-(grow?0:1);
    for(i=0;i<limit;i++) if(body[i].x==x && body[i].y==y) return 1;
    return 0;
}
static int put_food(void)
{
    int tries,x,y;
    for(tries=0;tries<MAX_SNAKE*2;tries++) {
        x=rand()%COLS; y=rand()%ROWS;
        if(!occupied(x,y)) { foodx=x; foody=y; return 1; }
    }
    /* A nearly full board can make random probing miss the final free cell.
     * Fall back to a deterministic scan before declaring victory. */
    for(y=0;y<ROWS;y++) for(x=0;x<COLS;x++) {
        if(!occupied(x,y)) { foodx=x; foody=y; return 1; }
    }
    return 0;
}
static void restart(void)
{
    int i; length=7; dir=DIR_RIGHT; paused=0; dead=0;
    for(i=0;i<length;i++){body[i].x=(short)(9-i);body[i].y=ROWS/2;}
    if(!put_food()) dead=2;
}
static void cell(JTMOS_GRAOS_DEMO *d,int x,int y,GRAOS_PIXEL c)
{
    int x1=x*CELL,y1=y*CELL;
    jtmos_demo_rect(d,x1+1,y1+1,x1+CELL-2,y1+CELL-2,c);
}
static void render(JTMOS_GRAOS_DEMO *d)
{
    int i;
    jtmos_demo_fill(d,GRAOS_RGB(8,12,18));
    for(i=0;i<COLS;i++) {
        jtmos_demo_rect(d,i*CELL,ROWS*CELL,i*CELL+CELL-1,ROWS*CELL+1,GRAOS_RGB(40,70,100));
    }
    cell(d,foodx,foody,GRAOS_RGB(255,190,40));
    for(i=length-1;i>=0;i--) cell(d,body[i].x,body[i].y,i==0?GRAOS_RGB(120,255,120):GRAOS_RGB(40,180,70));
    if(paused) jtmos_demo_rect(d,100,82,219,117,GRAOS_RGB(80,80,130));
    if(dead) {
        jtmos_demo_rect(d,70,76,249,123,
                        dead==2?GRAOS_RGB(30,140,60):GRAOS_RGB(150,30,30));
        jtmos_demo_rect(d,90,92,229,107,GRAOS_RGB(245,210,210));
    }
}
static void step(void)
{
    POINT h; int i,grow=0;
    if(paused || dead) return;
    h=body[0];
    if(dir==DIR_UP) h.y--; else if(dir==DIR_DOWN) h.y++; else if(dir==DIR_LEFT) h.x--; else h.x++;
    if(h.x==foodx && h.y==foody) grow=1;
    /* Moving onto the old tail cell is legal when the snake is not growing,
     * because that cell is vacated during this same step. */
    if(h.x<0 || h.x>=COLS || h.y<0 || h.y>=ROWS ||
       occupied_for_move(h.x,h.y,grow)) { dead=1; return; }
    if(grow && length<MAX_SNAKE) length++;
    for(i=length-1;i>0;i--) body[i]=body[i-1];
    body[0]=h;
    if(grow && !put_food()) dead=2;
}
static int handle_key(int key)
{
    if(key==27) return -1;
    if(key==' '){paused=!paused;return 0;}
    if((key=='r'||key=='R') && dead){restart();return 0;}
    if((key==JKEY_CURSOR_UP || key=='w'||key=='W') && dir!=DIR_DOWN) dir=DIR_UP;
    else if((key==JKEY_CURSOR_DOWN || key=='s'||key=='S') && dir!=DIR_UP) dir=DIR_DOWN;
    else if((key==JKEY_CURSOR_LEFT || key=='a'||key=='A') && dir!=DIR_RIGHT) dir=DIR_LEFT;
    else if((key==JKEY_CURSOR_RIGHT || key=='d'||key=='D') && dir!=DIR_LEFT) dir=DIR_RIGHT;
    return 0;
}
int main(void)
{
    JTMOS_GRAOS_DEMO d; int key; unsigned long last,now;
    if(jtmos_demo_open(&d,"Snake - arrows/WASD, Space pause, R restart, Esc close",FB_W,FB_H)!=0) return 1;
    srand((unsigned int)GetTickCount()); restart(); render(&d); jtmos_demo_present(&d); last=GetTickCount();
    for(;;) {
        key=jtmos_demo_poll(&d); if(key<0 || handle_key(key)<0) break;
        if(!d.focused){jtmos_demo_idle(30);last=GetTickCount();continue;}
        now=GetTickCount();
        if((unsigned long)(now-last)>=110UL) { last=now; step(); render(&d); if(jtmos_demo_present(&d)<0) break; }
        jtmos_demo_idle(10);
    }
    jtmos_demo_close(&d); return 0;
}
