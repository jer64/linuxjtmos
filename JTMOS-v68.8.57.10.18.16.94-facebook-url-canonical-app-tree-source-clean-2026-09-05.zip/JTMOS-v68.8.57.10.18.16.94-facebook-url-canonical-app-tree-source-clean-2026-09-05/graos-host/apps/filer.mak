# JTMOS V67 static ELF32 application
APPNAME=filer
include app-common.mk
