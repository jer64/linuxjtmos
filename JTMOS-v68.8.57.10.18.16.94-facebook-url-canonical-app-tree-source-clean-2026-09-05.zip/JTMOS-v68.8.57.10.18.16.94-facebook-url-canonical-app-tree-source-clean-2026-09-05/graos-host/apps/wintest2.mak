# JTMOS V67 static ELF32 application
APPNAME=wintest2
include app-common.mk
