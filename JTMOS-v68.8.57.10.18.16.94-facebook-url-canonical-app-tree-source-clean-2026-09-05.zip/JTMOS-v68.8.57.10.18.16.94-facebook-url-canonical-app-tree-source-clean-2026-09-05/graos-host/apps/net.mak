# JTMOS V67 static ELF32 application
APPNAME=net
include app-common.mk
