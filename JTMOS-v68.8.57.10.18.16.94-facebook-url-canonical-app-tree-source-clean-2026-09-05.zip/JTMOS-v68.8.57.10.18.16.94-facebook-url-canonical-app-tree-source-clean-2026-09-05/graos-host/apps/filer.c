/*
 * Filer - JTMOS / GraOS File Explorer
 *
 * Original Squirrel File Explorer (C) 2003 Jari Tuominen.
 * GraOS Explorer-style frontend / Linux host portability update, 2026.
 *
 * One source file is used in two modes:
 *   -DJTMOS : native JTMOS application using the GraOS/Postman ABI
 *   host    : Linux application using compat/apps_sdl2 + central GraOS
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <jtmos/graos.h>
#include <jtmos/filefind.h>

#ifdef JTMOS
#include <jtmos/process.h>
#include "gui/guiLaunchCompat.h"
#include <unistd.h>
#else
#include <jtmos/app_port.h>
#include <limits.h>
#include <sys/types.h>
#include <unistd.h>
#endif

/* V67.8.56.1: the Explorer file table plus the current 32-bit GraOS
 * framebuffer no longer fits in the historical 1 MiB process reservation.
 * Keep enough private heap for both allocations and normal directory work. */
SYSMEMREQ(APPRAM_4096K)

#define N_MAX_FILES 4000
#define FILER_NAME_MAX 96
#define EDIT_CMD_PATH "/bin/edit.bin"
#define FILER_HLP_PATH "/bin/filer.hlp"

/* Compact Explorer client; works on the 1024x768 GraOS desktop. */
#define VIEW_W 604
#define VIEW_H 408
#define TOOL_Y 4
#define TOOL_H 30
#define ADDR_Y 38
#define ADDR_H 28
#define BODY_Y 70
#define LEFT_W 126
#define LIST_X (LEFT_W + 4)
#define HEADER_H 22
#define ROW_Y (BODY_Y + HEADER_H)
#define ROW_H 18
#define STATUS_H 24
#define STATUS_Y (VIEW_H - STATUS_H)
#define VISIBLE_ROWS ((STATUS_Y - ROW_Y) / ROW_H)
#define FOLDER_ROW_H 22
#define FOLDER_FIRST_Y (BODY_Y + 27)
#define FOLDER_VISIBLE_ROWS ((STATUS_Y - FOLDER_FIRST_Y) / FOLDER_ROW_H)
#define N_MAX_FOLDER_LINKS 64

/* GraOS protocol IDs and surface/window flags are system-wide.  The native
 * build gets the canonical values from <jtmos/graosprotocol.h>.  The host
 * compatibility build still has a different historical wire ABI, but keeps
 * the same GRAOS_* namespace because these are GraOS protocol values, not
 * Filer-private IDs. */
#ifdef JTMOS
#define FILER_CREATE_H (VIEW_H + 38) /* native caption consumes 19 px top+bottom */
#else
#ifndef GRAOS_WINDOW_STANDARD
#define GRAOS_WINDOW_STANDARD 1
#endif
#ifndef GRAOS_SURFACE_BITMAP
#define GRAOS_SURFACE_BITMAP 1
#endif
#ifndef GRAOS_GSID_EXIT
#define GRAOS_GSID_EXIT 1
#endif
#ifndef GRAOS_GSID_KEYPRESSED
#define GRAOS_GSID_KEYPRESSED 2
#endif
#ifndef GRAOS_GSID_MOUSEBUTTON
#define GRAOS_GSID_MOUSEBUTTON 20
#endif
#define FILER_CREATE_H VIEW_H
#endif

/* Normalized key representation used internally (IBM scan code in high byte). */
#define FK_UP      0x4800
#define FK_DOWN    0x5000
#define FK_HOME    0x4700
#define FK_END     0x4f00
#define FK_PGUP    0x4900
#define FK_PGDN    0x5100
#define FK_INSERT  0x5200
#define FK_DELETE  0x5300
#define FK_F1      0x3b00
#define FK_F5      0x3f00
#define FK_F8      0x4200

/* Classic 16-colour VGA/GraOS palette indices. */
#define C_BLACK 0
#define C_BLUE 1
#define C_GREEN 2
#define C_CYAN 3
#define C_RED 4
#define C_MAGENTA 5
#define C_BROWN 6
#define C_LIGHTGRAY 7
#define C_DARKGRAY 8
#define C_LIGHTBLUE 9
#define C_LIGHTGREEN 10
#define C_LIGHTCYAN 11
#define C_LIGHTRED 12
#define C_LIGHTMAGENTA 13
#define C_YELLOW 14
#define C_WHITE 15

typedef struct {
    char name[FILER_NAME_MAX];
    int size;
    int type;       /* 2 = directory, 1 = file */
    char selected;  /* marked for a multi-file operation */
} DE;

typedef struct {
    DE file[N_MAX_FILES];
    int n_files;
    int n_selected;
    int sz_selected;
    int sz_all;
    int cursor;
    int scroll;
    int dirty;
    int help;
    int confirm_delete;
    int folder_index[N_MAX_FOLDER_LINKS];
    int n_folders;
    int folder_scroll;
    char cwd[256];
    char status[128];
} FILER;

/* V67.8.56.3: use the public GraOS event API.  Modern libc can
 * temporarily stash asynchronous events while it waits for a synchronous
 * GRAOS_GSID_RESPONSE, so applications must not bypass that queue with raw
 * receiveMessage() calls. */
static FILER *filer;
static GRAOS_PIXEL *pixels;
static int window_id = -1;
static int server_closed_window;

/* ------------------------------------------------------------------------- */
/* Tiny self-contained 5x7 renderer. It keeps Filer independent from private
 * GraOS server drawing symbols; only the public bitmap framebuffer API is
 * required on both JTMOS and Linux. */
static unsigned char glyph_row(unsigned char ch, int row)
{
    static const unsigned char digits[10][7] = {
        {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},
        {14,17,1,2,4,8,31},{30,1,1,14,1,1,30},
        {2,6,10,18,31,2,2},{31,16,16,30,1,1,30},
        {14,16,16,30,17,17,14},{31,1,2,4,8,8,8},
        {14,17,17,14,17,17,14},{14,17,17,15,1,1,14}
    };
    static const unsigned char upper[26][7] = {
        {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},
        {14,17,16,16,16,17,14},{30,17,17,17,17,17,30},
        {31,16,16,30,16,16,31},{31,16,16,30,16,16,16},
        {14,17,16,23,17,17,15},{17,17,17,31,17,17,17},
        {14,4,4,4,4,4,14},{7,2,2,2,18,18,12},
        {17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
        {17,27,21,21,17,17,17},{17,25,21,19,17,17,17},
        {14,17,17,17,17,17,14},{30,17,17,30,16,16,16},
        {14,17,17,17,21,18,13},{30,17,17,30,20,18,17},
        {15,16,16,14,1,1,30},{31,4,4,4,4,4,4},
        {17,17,17,17,17,17,14},{17,17,17,17,17,10,4},
        {17,17,17,21,21,21,10},{17,17,10,4,10,17,17},
        {17,17,10,4,4,4,4},{31,1,2,4,8,16,31}
    };
    if(row < 0 || row > 6) return 0;
    if(ch >= 'a' && ch <= 'z') ch = (unsigned char)(ch - 'a' + 'A');
    if(ch >= '0' && ch <= '9') return digits[ch-'0'][row];
    if(ch >= 'A' && ch <= 'Z') return upper[ch-'A'][row];
    switch(ch) {
        case ' ': return 0;
        case '.': return row==6 ? 4 : 0;
        case ',': return row==5 ? 4 : row==6 ? 8 : 0;
        case ':': return (row==2 || row==5) ? 4 : 0;
        case ';': return row==2 ? 4 : row==5 ? 4 : row==6 ? 8 : 0;
        case '-': return row==3 ? 14 : 0;
        case '_': return row==6 ? 31 : 0;
        case '+': return row==3 ? 31 : (row>=1 && row<=5 ? 4 : 0);
        case '=': return (row==2 || row==4) ? 31 : 0;
        case '/': return (unsigned char)(1u << (row<5 ? (4-row) : 0));
        case '\\': return (unsigned char)(1u << (row<5 ? row : 4));
        case '|': return 4;
        case '!': return row<5 ? 4 : row==6 ? 4 : 0;
        case '?': { static const unsigned char q[7]={14,17,1,2,4,0,4}; return q[row]; }
        case '(': return (row==0||row==6)?2:(row==1||row==5?4:8);
        case ')': return (row==0||row==6)?8:(row==1||row==5?4:2);
        case '[': return (row==0||row==6)?14:8;
        case ']': return (row==0||row==6)?14:2;
        case '<': return row==1?2:row==2?4:row==3?8:row==4?4:row==5?2:0;
        case '>': return row==1?8:row==2?4:row==3?2:row==4?4:row==5?8:0;
        case '#': return (row==2||row==4)?31:10;
        case '*': return row==2?21:row==3?14:row==4?21:0;
        case '%': return row==0?17:row==1?2:row==2?4:row==3?8:row==4?16:row==6?17:0;
        case '@': { static const unsigned char a[7]={14,17,23,21,23,16,14}; return a[row]; }
        case '$': { static const unsigned char d[7]={4,15,20,14,5,30,4}; return d[row]; }
        case '&': { static const unsigned char a[7]={12,18,20,8,21,18,13}; return a[row]; }
        case '\'': return row<2 ? 4 : 0;
        case '"': return row<2 ? 10 : 0;
        default: { static const unsigned char q[7]={14,17,1,2,4,0,4}; return q[row]; }
    }
}

static void fill_rect(int x,int y,int w,int h,BYTE color)
{
    int yy,x1=x,y1=y,x2=x+w,y2=y+h;
    if(!pixels || w<=0 || h<=0) return;
    if(x1<0) x1=0;
    if(y1<0) y1=0;
    if(x2>VIEW_W) x2=VIEW_W;
    if(y2>VIEW_H) y2=VIEW_H;
    if(x1>=x2 || y1>=y2) return;
    for(yy=y1; yy<y2; ++yy) {
        int xx; GRAOS_PIXEL p=JtmosMCGAColorToRGBA(color);
        for(xx=x1;xx<x2;xx++) pixels[yy*VIEW_W+xx]=p;
    }
}

static void line_h(int x,int y,int w,BYTE c){ fill_rect(x,y,w,1,c); }
static void line_v(int x,int y,int h,BYTE c){ fill_rect(x,y,1,h,c); }

static void bevel(int x,int y,int w,int h,int pressed)
{
    BYTE hi = pressed ? C_DARKGRAY : C_WHITE;
    BYTE lo = pressed ? C_WHITE : C_DARKGRAY;
    line_h(x,y,w,hi); line_v(x,y,h,hi);
    line_h(x,y+h-1,w,lo); line_v(x+w-1,y,h,lo);
}

static void draw_char(unsigned char ch,int x,int y,BYTE fg,BYTE bg)
{
    int r,c;
    fill_rect(x,y,8,8,bg);
    for(r=0;r<7;r++) {
        unsigned char bits=glyph_row(ch,r);
        for(c=0;c<5;c++)
            if(bits & (1u << (4-c))) {
                int px=x+c+1, py=y+r;
                if(px>=0&&px<VIEW_W&&py>=0&&py<VIEW_H)
                    pixels[py*VIEW_W+px]=JtmosMCGAColorToRGBA(fg);
            }
    }
}

static void draw_text_n(const char *s,int x,int y,int maxchars,BYTE fg,BYTE bg)
{
    int n=0;
    if(!s) return;
    while(*s && n<maxchars && x+8<=VIEW_W) {
        draw_char((unsigned char)*s,x,y,fg,bg);
        x+=8; ++s; ++n;
    }
}

static void draw_text(const char *s,int x,int y,BYTE fg,BYTE bg)
{
    draw_text_n(s,x,y,1024,fg,bg);
}

static void draw_folder_icon(int x,int y,int selected)
{
    BYTE body=selected?C_YELLOW:C_BROWN;
    fill_rect(x+1,y+3,7,3,body);
    fill_rect(x,y+6,14,9,body);
    line_h(x,y+6,14,C_YELLOW);
    line_v(x,y+6,9,C_YELLOW);
    line_h(x,y+14,14,C_DARKGRAY);
}

static void draw_file_icon(int x,int y,int selected)
{
    BYTE page=selected?C_WHITE:C_LIGHTGRAY;
    fill_rect(x+2,y+1,11,14,page);
    line_h(x+2,y+1,8,C_WHITE); line_v(x+2,y+1,14,C_WHITE);
    line_h(x+2,y+14,11,C_DARKGRAY); line_v(x+12,y+4,11,C_DARKGRAY);
    line_h(x+5,y+6,5,C_DARKGRAY); line_h(x+5,y+9,5,C_DARKGRAY);
}

/* ------------------------------------------------------------------------- */
static int ascii_lower(int c){ return (c>='A'&&c<='Z') ? c+('a'-'A') : c; }

static int namecmp_ci(const char *a,const char *b)
{
    int ca,cb;
    while(*a && *b) {
        ca=ascii_lower((unsigned char)*a++); cb=ascii_lower((unsigned char)*b++);
        if(ca!=cb) return ca-cb;
    }
    return (unsigned char)*a-(unsigned char)*b;
}

static int entry_cmp(const void *aa,const void *bb)
{
    const DE *a=(const DE*)aa,*b=(const DE*)bb;
    if(a->type==2 && b->type!=2) return -1;
    if(a->type!=2 && b->type==2) return 1;
    return namecmp_ci(a->name,b->name);
}

static int ends_ci(const char *s,const char *suffix)
{
    size_t a,b,i;
    if(!s||!suffix) return 0;
    a=strlen(s); b=strlen(suffix); if(a<b) return 0;
    for(i=0;i<b;i++) if(ascii_lower((unsigned char)s[a-b+i])!=ascii_lower((unsigned char)suffix[i])) return 0;
    return 1;
}

static int is_text_file(const char *n)
{
    return ends_ci(n,".txt")||ends_ci(n,".c")||ends_ci(n,".h")||
           ends_ci(n,".cpp")||ends_ci(n,".md")||ends_ci(n,".log")||
           ends_ci(n,".cfg")||ends_ci(n,".ini")||ends_ci(n,".doc")||
           ends_ci(n,".nfo")||ends_ci(n,".diz")||ends_ci(n,".mak");
}

static const char *type_name(const DE *d)
{
    if(d->type==2) return "Folder";
    if(ends_ci(d->name,".elf")||ends_ci(d->name,".bin")||ends_ci(d->name,".exe")||ends_ci(d->name,".com")) return "Program";
    if(is_text_file(d->name)) return "Text";
    return "File";
}

static void format_size(int size,char *out,int n)
{
    if(size>=1024*1024) snprintf(out,(size_t)n,"%d MB",size/(1024*1024));
    else if(size>=1024) snprintf(out,(size_t)n,"%d KB",size/1024);
    else snprintf(out,(size_t)n,"%d B",size);
}

static void set_status(const char *s)
{
    snprintf(filer->status,sizeof(filer->status),"%s",s?s:"");
    filer->dirty=1;
}

static void update_cwd(void)
{
    if(!getcwd(filer->cwd,sizeof(filer->cwd))) snprintf(filer->cwd,sizeof(filer->cwd),"/");
}

static int cwd_is_root(void)
{
    const char *p;
    if(!filer->cwd[0] || !strcmp(filer->cwd,"/")) return 1;
    p=strchr(filer->cwd,':');
    if(p && !strcmp(p+1,"/")) return 1;
    return 0;
}

static int visible_dir_entry(const FFBLK *ff)
{
    if(!ff || !ff->ff_name[0] || ff->ff_fsize==-1) return 0;
    if(!strcmp(ff->ff_name,".") || !strcmp(ff->ff_name,"..") || !strcmp(ff->ff_name,"/")) return 0;
    return 1;
}

static int ff_is_directory(const FFBLK *ff)
{
    return ff && JTMFS_TYPE_IS_DIRECTORY(ff->ff_attrib);
}

static void rebuild_folder_links(void)
{
    int i;
    filer->n_folders=0;
    for(i=0;i<filer->n_files && filer->n_folders<N_MAX_FOLDER_LINKS;i++)
        if(filer->file[i].type==2)
            filer->folder_index[filer->n_folders++]=i;
    if(filer->folder_scroll<0) filer->folder_scroll=0;
    if(filer->folder_scroll>=filer->n_folders) filer->folder_scroll=0;
}

static void clamp_cursor(void)
{
    if(filer->n_files<=0) { filer->cursor=0; filer->scroll=0; return; }
    if(filer->cursor<0) filer->cursor=0;
    if(filer->cursor>=filer->n_files) filer->cursor=filer->n_files-1;
    if(filer->scroll>filer->cursor) filer->scroll=filer->cursor;
    if(filer->cursor>=filer->scroll+VISIBLE_ROWS) filer->scroll=filer->cursor-VISIBLE_ROWS+1;
    if(filer->scroll<0) filer->scroll=0;
}

static int filer_read_dir(void)
{
    FFBLK ff;
    int fd,i=0;
    memset(filer->file,0,sizeof(filer->file));
    filer->n_selected=0; filer->sz_selected=0; filer->sz_all=0;

    fd=findfirst("*",&ff);
    if(fd>0) {
        for(;;) {
            if(visible_dir_entry(&ff) && i<N_MAX_FILES) {
                DE *d=&filer->file[i++];
                size_t nn=strlen(ff.ff_name);
                if(nn>=sizeof(d->name)) nn=sizeof(d->name)-1;
                memcpy(d->name,ff.ff_name,nn); d->name[nn]=0;
                d->type=ff_is_directory(&ff)?2:1;
                d->size=(d->type==1 && ff.ff_fsize>0)?ff.ff_fsize:0;
                filer->sz_all += d->size;
            }
            if(findnext(fd,&ff)) break;
        }
        close(fd); /* findfirst owns a descriptor; every refresh must release it. */
    } else {
        snprintf(filer->status,sizeof(filer->status),"Directory read failed (%d)",fd);
    }
    filer->n_files=i;
    if(i>1) qsort(filer->file,(size_t)i,sizeof(DE),entry_cmp);
    rebuild_folder_links();
    update_cwd(); clamp_cursor();
    if(fd>0) snprintf(filer->status,sizeof(filer->status),"%d item(s), %d folder(s), %d KB",filer->n_files,filer->n_folders,filer->sz_all/1024);
    filer->dirty=1;
    return fd>0?0:-1;
}

static void reset_view(void){ filer->cursor=0; filer->scroll=0; filer_read_dir(); }

static int navigate_to(const char *path)
{
    if(chdir(path)==0) { reset_view(); return 0; }
    set_status("Unable to open folder"); return -1;
}

static void toggle_mark(void)
{
    DE *d;
    if(filer->n_files<=0) return;
    d=&filer->file[filer->cursor];
    d->selected^=1;
    if(d->selected) { filer->n_selected++; filer->sz_selected+=d->size; }
    else { filer->n_selected--; filer->sz_selected-=d->size; }
    filer->dirty=1;
}

#ifndef JTMOS
static int host_launch(const char *program,const char *arg)
{
    char exe[PATH_MAX],path[PATH_MAX];
    char *slash; ssize_t n; pid_t p;
    path[0]=0;
    n=readlink("/proc/self/exe",exe,sizeof(exe)-1);
    if(n>0 && (size_t)n<sizeof(exe)) {
        exe[n]=0; slash=strrchr(exe,'/');
        if(slash) { *slash=0; if(snprintf(path,sizeof(path),"%s/%s",exe,program)>=(int)sizeof(path)) path[0]=0; }
    }
    p=fork(); if(p<0) return -1;
    if(p==0) {
        if(path[0]) {
            if(arg && *arg) execl(path,path,arg,(char*)NULL);
            else execl(path,path,(char*)NULL);
        }
        if(arg && *arg) execlp(program,program,arg,(char*)NULL);
        else execlp(program,program,(char*)NULL);
        _exit(127);
    }
    return (int)p;
}
#endif

static void edit_file(const char *name)
{
#ifdef JTMOS
    char cmd[320];
    int pid;
    snprintf(cmd,sizeof(cmd),"/bin/terminal.bin %s %s",EDIT_CMD_PATH,name);
    pid=graos_bgexec_command(cmd,filer->cwd);
    if(pid<=0) set_status("Unable to launch editor terminal");
    else set_status("Editor launched");
#else
    if(host_launch("edit",name)<0) set_status("Unable to launch editor");
#endif
}

static void run_file(const char *name)
{
#ifdef JTMOS
    if(ends_ci(name,".elf")||ends_ci(name,".bin")||ends_ci(name,".exe")||ends_ci(name,".com")) {
        int pid=graos_bgexec_command(name,filer->cwd);
        if(pid<=0) set_status("Unable to launch program");
        else set_status("Program launched");
    } else set_status("No program association for this file");
#else
    if(access(name,X_OK)==0) {
        char local[320]; pid_t p;
        snprintf(local,sizeof(local),"./%s",name);
        p=fork();
        if(p==0) { execl(local,local,(char*)NULL); _exit(127); }
        if(p<0) set_status("Unable to launch program");
    } else set_status("File is not executable on Linux");
#endif
}

static void open_current(void)
{
    DE *d;
    if(filer->n_files<=0) return;
    d=&filer->file[filer->cursor];
    if(d->type==2) navigate_to(d->name);
    else if(is_text_file(d->name)) edit_file(d->name);
    else run_file(d->name);
}

static int delete_target_count(void){ return filer->n_selected ? filer->n_selected : (filer->n_files?1:0); }

static void delete_targets(void)
{
    int i;
    if(filer->n_selected) {
        for(i=0;i<filer->n_files;i++) if(filer->file[i].selected) remove(filer->file[i].name);
    } else if(filer->n_files) remove(filer->file[filer->cursor].name);
    filer->confirm_delete=0;
    filer_read_dir(); clamp_cursor();
    set_status("Delete operation completed");
}

static void ask_delete(void)
{
    if(delete_target_count()<=0) return;
    filer->confirm_delete=1; filer->help=0; filer->dirty=1;
}

/* ------------------------------------------------------------------------- */
static void draw_button(int x,int w,const char *txt)
{
    fill_rect(x,TOOL_Y,w,TOOL_H,C_LIGHTGRAY); bevel(x,TOOL_Y,w,TOOL_H,0);
    draw_text(txt,x+6,TOOL_Y+11,C_BLACK,C_LIGHTGRAY);
}

static void render_main(void)
{
    int r,index,y;
    char tmp[96],sz[32];
    fill_rect(0,0,VIEW_W,VIEW_H,C_LIGHTGRAY);

    /* Toolbar */
    draw_button(6,56,"Back"); draw_button(66,56,"Root");
    draw_button(126,70,"Refresh"); draw_button(200,58,"Open");
    draw_button(262,58,"Mark"); draw_button(324,70,"Delete");
    draw_button(398,56,"Help");

    /* Address field */
    draw_text("Address",8,ADDR_Y+10,C_BLACK,C_LIGHTGRAY);
    fill_rect(70,ADDR_Y+4,VIEW_W-78,ADDR_H-8,C_WHITE);
    bevel(70,ADDR_Y+4,VIEW_W-78,ADDR_H-8,1);
    draw_text_n(filer->cwd,76,ADDR_Y+10,(VIEW_W-92)/8,C_BLACK,C_WHITE);

    /* Folder pane */
    fill_rect(4,BODY_Y,LEFT_W-8,STATUS_Y-BODY_Y,C_WHITE);
    bevel(4,BODY_Y,LEFT_W-8,STATUS_Y-BODY_Y,1);
    fill_rect(5,BODY_Y+1,LEFT_W-10,22,C_DARKGRAY);
    draw_text("Folders",12,BODY_Y+8,C_WHITE,C_DARKGRAY);
    {
        int fy=FOLDER_FIRST_Y, shown=0, fi;
        draw_folder_icon(13,fy+2,0);
        draw_text("Root /",34,fy+5,C_BLACK,C_WHITE);
        fy+=FOLDER_ROW_H; ++shown;
        if(!cwd_is_root() && shown<FOLDER_VISIBLE_ROWS) {
            draw_folder_icon(13,fy+2,0);
            draw_text("Up ..",34,fy+5,C_BLACK,C_WHITE);
            fy+=FOLDER_ROW_H; ++shown;
        }
        for(fi=filer->folder_scroll; fi<filer->n_folders && shown<FOLDER_VISIBLE_ROWS; ++fi,++shown,fy+=FOLDER_ROW_H) {
            int file_index=filer->folder_index[fi];
            draw_folder_icon(13,fy+2,0);
            draw_text_n(filer->file[file_index].name,34,fy+5,(LEFT_W-43)/8,C_BLACK,C_WHITE);
        }
        if(fi<filer->n_folders && shown>0)
            draw_text("...",LEFT_W-31,STATUS_Y-13,C_DARKGRAY,C_WHITE);
    }

    /* Details header */
    fill_rect(LIST_X,BODY_Y,VIEW_W-LIST_X-4,HEADER_H,C_LIGHTGRAY);
    bevel(LIST_X,BODY_Y,VIEW_W-LIST_X-4,HEADER_H,0);
    draw_text("Name",LIST_X+24,BODY_Y+7,C_BLACK,C_LIGHTGRAY);
    draw_text("Type",LIST_X+304,BODY_Y+7,C_BLACK,C_LIGHTGRAY);
    draw_text("Size",LIST_X+390,BODY_Y+7,C_BLACK,C_LIGHTGRAY);

    fill_rect(LIST_X,ROW_Y,VIEW_W-LIST_X-4,STATUS_Y-ROW_Y,C_WHITE);
    line_v(LIST_X+296,BODY_Y,STATUS_Y-BODY_Y,C_LIGHTGRAY);
    line_v(LIST_X+382,BODY_Y,STATUS_Y-BODY_Y,C_LIGHTGRAY);

    for(r=0;r<VISIBLE_ROWS;r++) {
        index=filer->scroll+r; y=ROW_Y+r*ROW_H;
        if(index>=filer->n_files) break;
        {
            DE *d=&filer->file[index];
            int active=(index==filer->cursor);
            BYTE bg=active?C_BLUE:C_WHITE;
            BYTE fg=active?C_WHITE:C_BLACK;
            fill_rect(LIST_X+1,y,VIEW_W-LIST_X-6,ROW_H,bg);
            if(d->type==2) draw_folder_icon(LIST_X+5,y+1,active);
            else draw_file_icon(LIST_X+5,y+1,active);
            if(d->selected) {
                fill_rect(LIST_X+21,y+5,7,7,active?C_YELLOW:C_RED);
                line_h(LIST_X+21,y+5,7,C_BLACK); line_v(LIST_X+21,y+5,7,C_BLACK);
            }
            draw_text_n(d->name,LIST_X+32,y+5,32,fg,bg);
            draw_text_n(type_name(d),LIST_X+304,y+5,9,fg,bg);
            if(d->type==1) { format_size(d->size,sz,sizeof(sz)); draw_text_n(sz,LIST_X+390,y+5,11,fg,bg); }
        }
    }

    /* Status bar */
    fill_rect(0,STATUS_Y,VIEW_W,STATUS_H,C_LIGHTGRAY);
    line_h(0,STATUS_Y,VIEW_W,C_WHITE);
    if(filer->n_selected)
        snprintf(tmp,sizeof(tmp),"%d item(s)  |  %d marked (%d KB)",filer->n_files,filer->n_selected,filer->sz_selected/1024);
    else snprintf(tmp,sizeof(tmp),"%d item(s)  |  %d KB",filer->n_files,filer->sz_all/1024);
    draw_text_n(tmp,8,STATUS_Y+8,44,C_BLACK,C_LIGHTGRAY);
    if(filer->status[0]) draw_text_n(filer->status,370,STATUS_Y+8,28,C_DARKGRAY,C_LIGHTGRAY);
}

static void render_help(void)
{
    int x=72,y=78,w=460,h=248;
    fill_rect(x,y,w,h,C_LIGHTGRAY); bevel(x,y,w,h,0);
    fill_rect(x+3,y+3,w-6,24,C_BLUE);
    draw_text("Filer Help",x+12,y+11,C_WHITE,C_BLUE);
    draw_text("Mouse: select a row, then Open/Mark/Delete.",x+16,y+43,C_BLACK,C_LIGHTGRAY);
    draw_text("Enter/Open   open folder, file or program",x+16,y+67,C_BLACK,C_LIGHTGRAY);
    draw_text("Backspace   parent folder",x+16,y+83,C_BLACK,C_LIGHTGRAY);
    draw_text("Arrows/PgUp/PgDn/Home/End   navigate",x+16,y+99,C_BLACK,C_LIGHTGRAY);
    draw_text("Insert/Space mark or unmark item",x+16,y+115,C_BLACK,C_LIGHTGRAY);
    draw_text("F5           refresh",x+16,y+131,C_BLACK,C_LIGHTGRAY);
    draw_text("F8/Delete    delete (with confirmation)",x+16,y+147,C_BLACK,C_LIGHTGRAY);
    draw_text("G            root directory",x+16,y+163,C_BLACK,C_LIGHTGRAY);
    draw_text("F1           close this help",x+16,y+179,C_BLACK,C_LIGHTGRAY);
    draw_text("Esc          close Filer",x+16,y+195,C_BLACK,C_LIGHTGRAY);
    draw_text("Click anywhere or press F1 to return.",x+16,y+219,C_BLUE,C_LIGHTGRAY);
}

static void render_confirm(void)
{
    int x=120,y=138,w=364,h=130;
    char msg[80];
    fill_rect(x,y,w,h,C_LIGHTGRAY); bevel(x,y,w,h,0);
    fill_rect(x+3,y+3,w-6,24,C_BLUE);
    draw_text("Confirm Delete",x+12,y+11,C_WHITE,C_BLUE);
    snprintf(msg,sizeof(msg),"Delete %d item(s)?",delete_target_count());
    draw_text(msg,x+24,y+48,C_BLACK,C_LIGHTGRAY);
    draw_text("This operation cannot be undone.",x+24,y+66,C_RED,C_LIGHTGRAY);
    fill_rect(x+70,y+91,82,26,C_LIGHTGRAY); bevel(x+70,y+91,82,26,0); draw_text("Yes",x+98,y+100,C_BLACK,C_LIGHTGRAY);
    fill_rect(x+208,y+91,82,26,C_LIGHTGRAY); bevel(x+208,y+91,82,26,0); draw_text("No",x+238,y+100,C_BLACK,C_LIGHTGRAY);
}

static void render(void)
{
    render_main();
    if(filer->help) render_help();
    if(filer->confirm_delete) render_confirm();
    refreshWindow(window_id);
    filer->dirty=0;
}

/* ------------------------------------------------------------------------- */
static int normalize_key(int k)
{
    /* Historical JTMOS used 0xFF00|scan; host/2026 headers use scan<<8. */
    if((k&0xff00)==0xff00) return (k&0xff)<<8;
    return k;
}

static void move_cursor(int delta)
{
    filer->cursor+=delta; clamp_cursor(); filer->dirty=1;
}

static void handle_key(int raw)
{
    int k=normalize_key(raw);
    if(filer->confirm_delete) {
        if(k=='y'||k=='Y'||k=='\n'||k=='\r') delete_targets();
        else if(k=='n'||k=='N'||k==27) { filer->confirm_delete=0; filer->dirty=1; }
        return;
    }
    if(filer->help) {
        if(k==FK_F1||k==27||k=='\n'||k=='\r') { filer->help=0; filer->dirty=1; }
        return;
    }
    switch(k) {
        case FK_UP: move_cursor(-1); break;
        case FK_DOWN: move_cursor(1); break;
        case FK_PGUP: move_cursor(-VISIBLE_ROWS); break;
        case FK_PGDN: move_cursor(VISIBLE_ROWS); break;
        case FK_HOME: filer->cursor=0; clamp_cursor(); filer->dirty=1; break;
        case FK_END: filer->cursor=filer->n_files?filer->n_files-1:0; clamp_cursor(); filer->dirty=1; break;
        case FK_INSERT: toggle_mark(); move_cursor(1); break;
        case FK_DELETE: case FK_F8: ask_delete(); break;
        case FK_F5: filer_read_dir(); break;
        case FK_F1: filer->help=1; filer->dirty=1; break;
        case 8: navigate_to(".."); break;
        case ' ': toggle_mark(); break;
        case 'g': case 'G': navigate_to("/"); break;
        case 'o': case 'O': case '\n': case '\r': open_current(); break;
        default: break;
    }
}

static int point_in(int x,int y,int rx,int ry,int rw,int rh)
{ return x>=rx&&y>=ry&&x<rx+rw&&y<ry+rh; }

static void handle_mouse(int x,int y,int button)
{
    int row,index;
    (void)button;
    if(filer->confirm_delete) {
        if(point_in(x,y,190,229,82,26)) delete_targets();
        else if(point_in(x,y,328,229,82,26)) { filer->confirm_delete=0; filer->dirty=1; }
        return;
    }
    if(filer->help) { filer->help=0; filer->dirty=1; return; }

    if(point_in(x,y,6,TOOL_Y,56,TOOL_H)) { navigate_to(".."); return; }
    if(point_in(x,y,66,TOOL_Y,56,TOOL_H)) { navigate_to("/"); return; }
    if(point_in(x,y,126,TOOL_Y,70,TOOL_H)) { filer_read_dir(); return; }
    if(point_in(x,y,200,TOOL_Y,58,TOOL_H)) { open_current(); return; }
    if(point_in(x,y,262,TOOL_Y,58,TOOL_H)) { toggle_mark(); return; }
    if(point_in(x,y,324,TOOL_Y,70,TOOL_H)) { ask_delete(); return; }
    if(point_in(x,y,398,TOOL_Y,56,TOOL_H)) { filer->help=1; filer->dirty=1; return; }

    if(point_in(x,y,8,FOLDER_FIRST_Y,LEFT_W-16,STATUS_Y-FOLDER_FIRST_Y)) {
        int slot=(y-FOLDER_FIRST_Y)/FOLDER_ROW_H;
        int base=1;
        if(slot==0) { navigate_to("/"); return; }
        if(!cwd_is_root()) {
            if(slot==1) { navigate_to(".."); return; }
            base=2;
        }
        {
            int fi=filer->folder_scroll + slot - base;
            if(fi>=0 && fi<filer->n_folders) {
                int file_index=filer->folder_index[fi];
                navigate_to(filer->file[file_index].name);
            }
        }
        return;
    }

    if(x>=LIST_X && y>=ROW_Y && y<STATUS_Y) {
        row=(y-ROW_Y)/ROW_H; index=filer->scroll+row;
        if(index>=0&&index<filer->n_files) { filer->cursor=index; clamp_cursor(); filer->dirty=1; }
    }
}

static int run_filer(void)
{
    GUICMD ev;
    int quit=0;
    int er;

    filer_read_dir();

    /* Paint once before polling so startup never depends on an event arriving. */
    if(filer->dirty) render();

    while(!quit) {
        while((er=JtmosGraOSPollEvent(window_id,&ev))>0) {
            /* A reused PID or another window owned by the same process must not
             * be able to terminate this window.  Server-polled events carry our
             * window_id, and direct notifications do as well. */
            if(ev.wid>=0 && ev.wid!=window_id)
                continue;

            if(ev.id==GRAOS_GSID_EXIT) {
                server_closed_window=1;
                quit=1;
                break;
            }
            if(ev.id==GRAOS_GSID_KEYPRESSED) {
                if(!filer->help && !filer->confirm_delete && ev.v[0]==27) {
                    quit=1;
                    break;
                }
                handle_key(ev.v[0]);
            } else if(ev.id==GRAOS_GSID_MOUSEBUTTON) {
                handle_mouse(ev.v[0],ev.v[1],ev.v[2]);
            }
        }
        if(er<0) {
            /* The old window id is no longer ours.  Never send CLOSE for it:
             * GraOS may already have reused the numeric id for another app. */
            server_closed_window=1;
            quit=1;
        }
        if(filer->dirty && !quit)
            render();
        SwitchToThread();
        Sleep(10);
    }
    return 0;
}

int main(int argc,char **argv)
{
    (void)argc; (void)argv;
    filer=(FILER*)malloc(sizeof(FILER));
    if(!filer) {
        printf("Filer: out of memory allocating file table (%lu bytes).\n",
               (unsigned long)sizeof(FILER));
        return 1;
    }
    pixels=(GRAOS_PIXEL*)malloc(VIEW_W*VIEW_H*sizeof(GRAOS_PIXEL));
    if(!pixels) {
        printf("Filer: out of memory allocating %d-bpp framebuffer (%lu bytes).\n",
               GRAOS_BPP,
               (unsigned long)(VIEW_W*VIEW_H*sizeof(GRAOS_PIXEL)));
        free(filer); filer=NULL;
        return 1;
    }
    memset(filer,0,sizeof(*filer)); fill_rect(0,0,VIEW_W,VIEW_H,C_LIGHTGRAY);
    filer->dirty=1;

    {
        int grc=connectGraos();
        if(grc!=0) {
            printf("Filer: cannot connect to GraOS (%d).\n",grc);
            free(pixels); pixels=NULL;
            free(filer); filer=NULL;
            return 2;
        }
    }
    window_id=createWindow(12,12,VIEW_W,FILER_CREATE_H,"JTMOS File Explorer",GRAOS_WINDOW_STANDARD);
    if(window_id<0) {
        printf("Filer: GraOS createWindow failed (%d).\n",window_id);
        free(pixels); pixels=NULL;
        free(filer); filer=NULL;
        return 2;
    }
#ifdef JTMOS
    /* Keep the full 604x408 Explorer framebuffer intact: the Label lives in
     * the otherwise unused right side of the native caption bar. */
    createLabel(window_id,430,6,160,8,7100,C_WHITE,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_RIGHT,"GraOS Label UI");
#endif
    if(addFrameBuffer(window_id,pixels,0,0,VIEW_W,VIEW_H,GRAOS_BPP,GRAOS_SURFACE_BITMAP,0)<0) {
        printf("Filer: GraOS addFrameBuffer failed.\n");
        closeWindow(window_id); window_id=-1;
        free(pixels); pixels=NULL;
        free(filer); filer=NULL;
        return 3;
    }

    run_filer();
    if(!server_closed_window) closeWindow(window_id);
    free(pixels); free(filer);
    return 0;
}
