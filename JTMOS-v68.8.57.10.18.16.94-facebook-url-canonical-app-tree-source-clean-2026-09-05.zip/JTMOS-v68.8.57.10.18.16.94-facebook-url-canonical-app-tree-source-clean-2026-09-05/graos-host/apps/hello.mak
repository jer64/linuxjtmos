# JTMOS V67 static ELF32 application
APPNAME=hello
include app-common.mk
