# JTMOS V67 static ELF32 application
APPNAME=runner
include app-common.mk
