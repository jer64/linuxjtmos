// editEditor.c - flicker-free editor UI/main loop
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include "edit.h"
#include "editEditor.h"

void OrderRefresh(void)
{
    ed.view.upd=1;
    ed.view.dirty_line=-1;
}

static void pad79(char *s)
{
    int n=(int)strlen(s);
    if(n>79) { s[79]=0; return; }
    while(n<79) s[n++]=' ';
    s[79]=0;
}

static void DrawChrome(const char *fname)
{
    static int first=1;
    char s[128];
    if(first)
    {
        textcolor(BLACK); textbackground(LIGHTGRAY);
        gotoxy(1,1);
        strcpy(s," File  Edit  Help       JTMOS Edit"); pad79(s); printf("%s",s);
        textcolor(BLACK); textbackground(LIGHTGRAY);
        gotoxy(1,25);
        strcpy(s," F1 Help  F2 Save  F3 Ins/Ovr  Home/End  Tab  Del  ^X/F10 Exit"); pad79(s); printf("%s",s);
        first=0;
    }
    textcolor(BLACK); textbackground(LIGHTGRAY);
    gotoxy(1,24);
    sprintf(s," %s%s   Ln %d  Col %d   %s ",ed.modified?"*":"",fname,
            GetWritePointY()+1,GetWritePointX()+1,ed.insertMode?"INS":"OVR");
    pad79(s); printf("%s",s);
}

static void DrawHelp(void)
{
    char s[81];
    int y;
    _setcursortype(_NOCURSOR);
    textcolor(WHITE); textbackground(BLUE);
    for(y=3;y<=14;y++) { gotoxy(8,y); memset(s,' ',64); s[64]=0; printf("%s",s); }
    gotoxy(10,4); printf("JTMOS Edit help");
    gotoxy(10,6); printf("F2 / Ctrl-O     Save file");
    gotoxy(10,7); printf("F3              Toggle Insert/Overwrite");
    gotoxy(10,8); printf("Tab             Next 8-column tab stop");
    gotoxy(10,9); printf("Home / End      Start/end of line");
    gotoxy(10,10); printf("Del / Backspace Delete text");
    gotoxy(10,11); printf("Enter           Split line");
    gotoxy(10,12); printf("Ctrl-X / F10    Exit");
    gotoxy(10,14); printf("Press any key to return");
    _setcursortype(_NORMALCURSOR);
    gotoxy(33,14);
    getch();
    OrderRefresh();
}

static int SaveNow(const char *fname)
{
    int r;
    _setcursortype(_NOCURSOR);
    r=EditorSave(fname);
    _setcursortype(_NORMALCURSOR);
    return r;
}

static int ConfirmExit(const char *fname)
{
    int k;
    char s[100];
    if(!ed.modified) return 1;
    _setcursortype(_NOCURSOR);
    textcolor(WHITE); textbackground(RED);
    gotoxy(1,24);
    strcpy(s," Save modified buffer? Y=yes N=no Esc=cancel "); pad79(s); printf("%s",s);
    _setcursortype(_NORMALCURSOR);
    gotoxy(ed.cursor.x,ed.cursor.y);
    k=getch();
    if(k=='y'||k=='Y') { SaveNow(fname); return 1; }
    if(k=='n'||k=='N') return 1;
    return 0;
}

int Editor(const char *fname)
{
    int key,y,len;
    clrscr();
    EditorInit();
    if(ed.buf[0]==NULL) return 1;
    EditorLoad(fname);
    OrderRefresh();

    while(1)
    {
        /* The physical/software cursor is disabled for all repaint work.  It is
           enabled exactly once at the final focused insertion point. */
        _setcursortype(_NOCURSOR);
        textcolor(COLOR1); textbackground(COLOR1B);
        UpdateEditBox();
        DrawChrome(fname);
        textcolor(COLOR1); textbackground(COLOR1B);
        gotoxy(ed.cursor.x,ed.cursor.y);
        _setcursortype(_NORMALCURSOR);

        key=getch();
        ed.ctrl=GetCTRL(); ed.alt=GetALT();

        if(key==JKEY_F1) { DrawHelp(); continue; }
        if(key==JKEY_F2 || (ed.ctrl && (key=='o'||key=='O'))) { SaveNow(fname); continue; }
        if(key==JKEY_F3 || key==JKEY_INSERT) { ed.insertMode=1-ed.insertMode; continue; }
        if(key==JKEY_F10 || (ed.ctrl && (key=='x'||key=='X')))
        {
            if(ConfirmExit(fname)) break;
            continue;
        }

        if(key==JKEY_CURSOR_UP) { CursorUp(); continue; }
        if(key==JKEY_CURSOR_DOWN) { CursorDown(); continue; }
        if(key==JKEY_CURSOR_LEFT) { CursorLeft(); continue; }
        if(key==JKEY_CURSOR_RIGHT) { CursorRight(); continue; }
        if(key==JKEY_PAGE_UP) { ed.cursor.x=1; ed.cursor.y=CURSOR_Y_MIN; ViewUp(EDIT_ROWS-2); continue; }
        if(key==JKEY_PAGE_DOWN) { ed.cursor.x=1; ed.cursor.y=CURSOR_Y_MIN; ViewDown(EDIT_ROWS-2); continue; }
        if(key==JKEY_HOME) { ed.cursor.x=CURSOR_X_MIN; continue; }
        if(key==JKEY_END)
        {
            y=GetWritePointY(); len=(int)strlen((char *)ed.buf[y]);
            if(len>79) len=79;
            ed.cursor.x=CURSOR_X_MIN+len;
            if(ed.cursor.x>CURSOR_X_MAX) ed.cursor.x=CURSOR_X_MAX;
            continue;
        }
        if(key==JKEY_DELETE) { DeleteAtCursor(); continue; }
        if(key=='\b' || key==JKEY_BACKSPACE) { BackspaceAtCursor(); continue; }
        if(key=='\r' || key=='\n') { SplitLine(); continue; }
        if(key=='\t') { InsertTab(); continue; }
        if((key&0xff00)==0 && key>=32 && key<127)
        {
            StoreChar(key);
            if(ed.cursor.x<CURSOR_X_MAX) ed.cursor.x++;
            continue;
        }
    }
    return 0;
}
