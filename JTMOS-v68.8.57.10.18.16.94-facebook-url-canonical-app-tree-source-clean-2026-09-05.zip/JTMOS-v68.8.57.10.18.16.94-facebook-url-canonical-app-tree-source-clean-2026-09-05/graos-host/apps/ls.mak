# JTMOS V67 static ELF32 application
APPNAME=ls
include app-common.mk
