/*
 * Stunt Circuit - a Stunt Car Racer inspired JTMOS game.
 *
 * The game intentionally keeps a Turbo C style programming model:
 *   graphics.h = 3D wire/polygon display on GraOS
 *   conio.h    = non-blocking keyboard control (kbhit/getch)
 *   dos.h      = frame pacing via delay()
 *
 * This is an original game and does not contain Stunt Car Racer assets/code.
 */
#include <graphics.h>
#include <conio.h>
#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#include <jtmos/process.h>
#include <jtsound.h>

/* 640x480 GraOS/BGI framebuffer + track/projection tables need far more
 * than the historical 256 KiB default application arena. */
SYSMEMREQ(APPRAM_4096K)

extern double sin(double);
extern double cos(double);
extern double sqrt(double);

#define PI 3.14159265358979323846
#define SCREEN_W 640
#define SCREEN_H 480
#define CX 320
#define HORIZON 176
#define FOCAL 430.0

#define TRACK_LEN 2048
#define TRACK_HALF 92.0
#define RAIL_HEIGHT 24.0
#define CAMERA_HEIGHT 72.0
#define CAMERA_BACK 44.0
#define DRAW_AHEAD 230
#define DRAW_STEP 2
#define DRAW_POINTS (DRAW_AHEAD / DRAW_STEP)
#define RACE_LAPS 3

#define FLAG_JUMP 1
#define FLAG_FINISH 2
#define FLAG_STEEP 4

typedef struct TrackPoint {
    double x,y,z;
    double tx,ty,tz;
    double rx,rz;
    double bend;
    unsigned flags;
} TrackPoint;

typedef struct ProjPoint {
    int valid;
    int lx,ly,rx,ry;
    int ltx,lty,rtx,rty;
    int cx,cy;
    double depth;
    int index;
} ProjPoint;

typedef struct Camera {
    double x,y,z;
    double fx,fy,fz;
    double rx,ry,rz;
    double ux,uy,uz;
} Camera;

typedef struct CarState {
    double pos;
    double lateral;
    double lateral_v;
    double speed;
    double air_y;
    double air_v;
    int airborne;
    int damage;
    int boost;
    int lap;
    unsigned long lap_start;
    unsigned long best_lap;
    int last_index;
} CarState;

static TrackPoint track[TRACK_LEN];
static ProjPoint projected[DRAW_POINTS + 2];
static CarState player;
static double ai_pos;
static double ai_speed;
static double ai_lateral;
static int ai_lap;
static int running=1;
static int paused=0;
static int throttle_hold,brake_hold,left_hold,right_hold,boost_hold;
static unsigned long race_start;
static int audio_ok;

static double dabs(double v){return v<0.0?-v:v;}
static double dmin(double a,double b){return a<b?a:b;}
static int wrapi(int i){while(i<0)i+=TRACK_LEN;while(i>=TRACK_LEN)i-=TRACK_LEN;return i;}

static double cyclic_distance(int a,int b)
{
    int d=a-b;
    if(d>TRACK_LEN/2)d-=TRACK_LEN;
    if(d<-TRACK_LEN/2)d+=TRACK_LEN;
    return (double)d;
}

static double smooth_hump(int i,int center,int width,double height)
{
    double d=cyclic_distance(i,center);
    double t;
    if(dabs(d)>width)return 0.0;
    t=(d+(double)width)/(double)(width*2);
    return height*(0.5-0.5*cos(t*2.0*PI));
}

static void build_track(void)
{
    int i,im,ip;
    double a,r;
    double dx,dy,dz,n,hx,hz,hn;

    for(i=0;i<TRACK_LEN;i++){
        a=2.0*PI*(double)i/(double)TRACK_LEN;
        r=3500.0 + 620.0*sin(2.0*a+0.25) + 330.0*sin(5.0*a-0.5);
        track[i].x=r*cos(a);
        track[i].z=r*sin(a);
        track[i].y=610.0 + 245.0*sin(3.0*a+0.3) + 105.0*sin(7.0*a-0.7);

        /* Four deliberately large roller-coaster crests. */
        track[i].y+=smooth_hump(i,260,38,210.0);
        track[i].y+=smooth_hump(i,760,44,255.0);
        track[i].y+=smooth_hump(i,1270,36,235.0);
        track[i].y+=smooth_hump(i,1745,48,275.0);
        track[i].flags=0;
    }

    for(i=0;i<TRACK_LEN;i++){
        im=wrapi(i-1);ip=wrapi(i+1);
        dx=track[ip].x-track[im].x;
        dy=track[ip].y-track[im].y;
        dz=track[ip].z-track[im].z;
        n=sqrt(dx*dx+dy*dy+dz*dz);
        if(n<0.0001)n=1.0;
        track[i].tx=dx/n;track[i].ty=dy/n;track[i].tz=dz/n;
        hx=track[i].tz;hz=-track[i].tx;
        hn=sqrt(hx*hx+hz*hz);if(hn<0.0001)hn=1.0;
        track[i].rx=hx/hn;track[i].rz=hz/hn;
    }
    for(i=0;i<TRACK_LEN;i++){
        ip=wrapi(i+2);
        track[i].bend=track[i].tx*track[ip].tz-track[i].tz*track[ip].tx;
    }

    for(i=0;i<4;i++)track[i].flags|=FLAG_FINISH;
    for(i=248;i<=266;i++)track[wrapi(i)].flags|=FLAG_JUMP|FLAG_STEEP;
    for(i=747;i<=766;i++)track[wrapi(i)].flags|=FLAG_JUMP|FLAG_STEEP;
    for(i=1258;i<=1277;i++)track[wrapi(i)].flags|=FLAG_JUMP|FLAG_STEEP;
    for(i=1730;i<=1751;i++)track[wrapi(i)].flags|=FLAG_JUMP|FLAG_STEEP;
}

static void normalize3(double *x,double *y,double *z)
{
    double n=sqrt((*x)*(*x)+(*y)*(*y)+(*z)*(*z));
    if(n<0.00001){*x=0;*y=0;*z=1;return;}
    *x/=n;*y/=n;*z/=n;
}

static void cross3(double ax,double ay,double az,double bx,double by,double bz,
                   double *x,double *y,double *z)
{
    *x=ay*bz-az*by;
    *y=az*bx-ax*bz;
    *z=ax*by-ay*bx;
}

static void sample_track(double pos,double *x,double *y,double *z,
                         double *tx,double *ty,double *tz,
                         double *rx,double *rz)
{
    int i=(int)pos;
    int j;
    double f=pos-(double)i;
    i=wrapi(i);j=wrapi(i+1);
    *x=track[i].x+(track[j].x-track[i].x)*f;
    *y=track[i].y+(track[j].y-track[i].y)*f;
    *z=track[i].z+(track[j].z-track[i].z)*f;
    *tx=track[i].tx+(track[j].tx-track[i].tx)*f;
    *ty=track[i].ty+(track[j].ty-track[i].ty)*f;
    *tz=track[i].tz+(track[j].tz-track[i].tz)*f;
    normalize3(tx,ty,tz);
    *rx=track[i].rx+(track[j].rx-track[i].rx)*f;
    *rz=track[i].rz+(track[j].rz-track[i].rz)*f;
    {double n=sqrt((*rx)*(*rx)+(*rz)*(*rz));if(n<0.0001)n=1;*rx/=n;*rz/=n;}
}

static void make_camera(Camera *c)
{
    double px,py,pz,tx,ty,tz,rrx,rrz;
    double ux,uy,uz;
    sample_track(player.pos,&px,&py,&pz,&tx,&ty,&tz,&rrx,&rrz);

    c->fx=tx;c->fy=ty;c->fz=tz;
    c->rx=rrx;c->ry=0.0;c->rz=rrz;
    cross3(c->fx,c->fy,c->fz,c->rx,c->ry,c->rz,&ux,&uy,&uz);
    normalize3(&ux,&uy,&uz);
    c->ux=ux;c->uy=uy;c->uz=uz;

    /* Third-person camera follows lateral motion and leaves enough track
     * visible beneath the car during large crests and jumps. */
    c->x=px+c->rx*player.lateral-c->fx*CAMERA_BACK+c->ux*CAMERA_HEIGHT;
    c->y=py-c->fy*CAMERA_BACK+c->uy*CAMERA_HEIGHT+player.air_y;
    c->z=pz+c->rz*player.lateral-c->fz*CAMERA_BACK+c->uz*CAMERA_HEIGHT;
}

static int project_xyz(const Camera *c,double x,double y,double z,int *sx,int *sy,double *depth)
{
    double dx=x-c->x,dy=y-c->y,dz=z-c->z;
    double cx=dx*c->rx+dy*c->ry+dz*c->rz;
    double cy=dx*c->ux+dy*c->uy+dz*c->uz;
    double cz=dx*c->fx+dy*c->fy+dz*c->fz;
    if(cz<16.0)return 0;
    *sx=CX+(int)(cx*FOCAL/cz);
    *sy=HORIZON-(int)(cy*FOCAL/cz);
    if(depth)*depth=cz;
    return 1;
}

static int project_track_point(const Camera *c,int idx,ProjPoint *p)
{
    TrackPoint *t=&track[idx];
    double lx=t->x-t->rx*TRACK_HALF;
    double lz=t->z-t->rz*TRACK_HALF;
    double rx=t->x+t->rx*TRACK_HALF;
    double rz=t->z+t->rz*TRACK_HALF;
    int ok=1;
    p->index=idx;
    ok&=project_xyz(c,lx,t->y,lz,&p->lx,&p->ly,&p->depth);
    ok&=project_xyz(c,rx,t->y,rz,&p->rx,&p->ry,0);
    ok&=project_xyz(c,lx,t->y+RAIL_HEIGHT,lz,&p->ltx,&p->lty,0);
    ok&=project_xyz(c,rx,t->y+RAIL_HEIGHT,rz,&p->rtx,&p->rty,0);
    ok&=project_xyz(c,t->x,t->y,t->z,&p->cx,&p->cy,0);
    p->valid=ok;
    return ok;
}

static void fill_quad(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4,int color)
{
    int q[8];
    q[0]=x1;q[1]=y1;q[2]=x2;q[3]=y2;q[4]=x3;q[5]=y3;q[6]=x4;q[7]=y4;
    setfillstyle(SOLID_FILL,color);
    fillpoly(4,q);
}

static void draw_background(void)
{
    int i,y;
    setfillstyle(SOLID_FILL,LIGHTBLUE);bar(0,0,SCREEN_W-1,HORIZON+58);
    setfillstyle(SOLID_FILL,BLUE);bar(0,HORIZON+59,SCREEN_W-1,SCREEN_H-1);

    /* Sun and a simple distant industrial/mountain skyline. */
    setfillstyle(SOLID_FILL,YELLOW);pieslice(525,72,0,360,23);
    setcolor(LIGHTGRAY);
    for(i=0;i<9;i++){
        int x=i*85-30;
        y=HORIZON+38-((i*31)%45);
        line(x,HORIZON+58,x+55,y);
        line(x+55,y,x+105,HORIZON+58);
    }
    setcolor(CYAN);line(0,HORIZON+59,SCREEN_W-1,HORIZON+59);
}

static void build_projection(const Camera *c)
{
    int k,idx,base=(int)player.pos;
    for(k=0;k<=DRAW_POINTS;k++){
        idx=wrapi(base+3+k*DRAW_STEP);
        project_track_point(c,idx,&projected[k]);
    }
}

static void draw_support(const Camera *c,const ProjPoint *p,int side)
{
    TrackPoint *t=&track[p->index];
    double x,z;
    int bx,by;
    if(side<0){x=t->x-t->rx*TRACK_HALF;z=t->z-t->rz*TRACK_HALF;}
    else{x=t->x+t->rx*TRACK_HALF;z=t->z+t->rz*TRACK_HALF;}
    if(!project_xyz(c,x,0.0,z,&bx,&by,0))return;
    if(by>SCREEN_H+280)by=SCREEN_H+280;
    if(by<-280)by=-280;
    if(bx>SCREEN_W+320)bx=SCREEN_W+320;
    if(bx<-320)bx=-320;
    setcolor(DARKGRAY);
    if(side<0)line(p->lx,p->ly,bx,by);else line(p->rx,p->ry,bx,by);
}

static void draw_finish_mark(const ProjPoint *a,const ProjPoint *b)
{
    int mx1=(a->lx+a->rx)/2;
    int my1=(a->ly+a->ry)/2;
    int mx2=(b->lx+b->rx)/2;
    int my2=(b->ly+b->ry)/2;
    setcolor(WHITE);line(a->lx,a->ly,a->rx,a->ry);
    setcolor(BLACK);line(a->lx+2,a->ly,a->rx-2,a->ry);
    setcolor(WHITE);line(mx1,my1,mx2,my2);
}

static void draw_track(const Camera *c)
{
    int k,color,idx;
    ProjPoint *a,*b;
    build_projection(c);

    /* Painter's algorithm: far track first, near track last. */
    for(k=DRAW_POINTS-1;k>=0;k--){
        a=&projected[k];b=&projected[k+1];
        if(!a->valid||!b->valid)continue;
        if((a->ly<-600&&b->ly<-600)||(a->ly>1000&&b->ly>1000))continue;
        idx=a->index;

        if((idx&31)==0){draw_support(c,a,-1);draw_support(c,a,1);}

        color=((idx/10)&1)?DARKGRAY:LIGHTGRAY;
        fill_quad(a->lx,a->ly,a->rx,a->ry,b->rx,b->ry,b->lx,b->ly,color);

        /* Bright edge strips make the narrow elevated road readable. */
        setcolor((idx&16)?WHITE:YELLOW);
        line(a->lx,a->ly,b->lx,b->ly);
        line(a->rx,a->ry,b->rx,b->ry);

        setcolor(LIGHTRED);
        line(a->ltx,a->lty,b->ltx,b->lty);
        line(a->rtx,a->rty,b->rtx,b->rty);
        if((idx&7)==0){
            line(a->lx,a->ly,a->ltx,a->lty);
            line(a->rx,a->ry,a->rtx,a->rty);
        }
        if(track[idx].flags&FLAG_FINISH)draw_finish_mark(a,b);
    }
}

static void draw_ai_car(const Camera *c)
{
    double x,y,z,tx,ty,tz,rrx,rrz;
    int sx,sy,w,h;
    double depth;
    int q[8];
    sample_track(ai_pos,&x,&y,&z,&tx,&ty,&tz,&rrx,&rrz);
    x+=rrx*ai_lateral;z+=rrz*ai_lateral;y+=18.0;
    if(!project_xyz(c,x,y,z,&sx,&sy,&depth))return;
    if(depth>2700.0)return;
    w=(int)(900.0/depth*24.0);if(w<3)w=3;if(w>72)w=72;
    h=w/2+2;
    q[0]=sx-w;q[1]=sy+h;
    q[2]=sx-w/2;q[3]=sy-h;
    q[4]=sx+w/2;q[5]=sy-h;
    q[6]=sx+w;q[7]=sy+h;
    setfillstyle(SOLID_FILL,LIGHTMAGENTA);fillpoly(4,q);
    setcolor(WHITE);line(sx-w,sy+h,sx+w,sy+h);
}

static void draw_player_car(void)
{
    int y=398-(int)(player.air_y*0.12);
    int steer=(int)(player.lateral_v*7.0);
    int q[8];
    if(steer<-15)steer=-15;
    if(steer>15)steer=15;

    setfillstyle(SOLID_FILL,BLACK);
    bar(205,y+35,245,y+69);bar(395,y+35,435,y+69);
    setfillstyle(SOLID_FILL,RED);
    q[0]=250+steer;q[1]=y+10;
    q[2]=390+steer;q[3]=y+10;
    q[4]=420;q[5]=y+62;
    q[6]=220;q[7]=y+62;
    fillpoly(4,q);
    setfillstyle(SOLID_FILL,LIGHTRED);bar(268+steer,y,372+steer,y+28);
    setcolor(WHITE);rectangle(268+steer,y,372+steer,y+28);
    setcolor(YELLOW);line(292+steer,y+4,348+steer,y+4);
    if(player.airborne){
        setcolor(WHITE);outtextxy(286,y-18,"AIRBORNE");
    }
}

static void format_time(unsigned long ms,char *buf)
{
    unsigned long sec=ms/1000UL;
    unsigned long min=sec/60UL;
    unsigned long cs=(ms%1000UL)/10UL;
    sec%=60UL;
    sprintf(buf,"%lu:%02lu.%02lu",min,sec,cs);
}

static void draw_hud(void)
{
    char s[96],t[32];
    unsigned long now=GetTickCount();
    int kmh=(int)(player.speed*42.0);
    int rank;
    double pd=(double)(player.lap-1)*TRACK_LEN+player.pos;
    double ad=(double)(ai_lap-1)*TRACK_LEN+ai_pos;
    rank=pd>=ad?1:2;

    setfillstyle(SOLID_FILL,BLACK);bar(0,0,SCREEN_W-1,34);
    setcolor(WHITE);
    sprintf(s,"STUNT CIRCUIT   SPEED %3d km/h   LAP %d/%d   POS %d/2",kmh,player.lap,RACE_LAPS,rank);
    outtextxy(8,7,s);
    format_time(now-player.lap_start,t);
    sprintf(s,"LAP %s",t);outtextxy(8,21,s);
    if(player.best_lap){format_time(player.best_lap,t);sprintf(s,"BEST %s",t);outtextxy(120,21,s);}

    setcolor(WHITE);outtextxy(408,21,"DAMAGE");rectangle(470,20,570,29);
    setfillstyle(SOLID_FILL,player.damage>70?LIGHTRED:(player.damage>35?YELLOW:LIGHTGREEN));
    if(player.damage>0)bar(472,22,472+(player.damage*96)/100,27);
    setcolor(CYAN);sprintf(s,"BOOST %3d",player.boost);outtextxy(576,21,s);
}

static void render_game(void)
{
    Camera c;
    make_camera(&c);
    draw_background();
    draw_track(&c);
    draw_ai_car(&c);
    draw_player_car();
    draw_hud();
    if(paused){
        setfillstyle(SOLID_FILL,BLACK);bar(228,192,412,265);
        setcolor(WHITE);rectangle(228,192,412,265);
        outtextxy(286,210,"PAUSED");
        outtextxy(248,235,"Press P to continue");
    }
    jtmos_graph_present();
}

static void clear_holds(void)
{
    throttle_hold=brake_hold=left_hold=right_hold=boost_hold=0;
}

static void reset_player(void)
{
    unsigned long now=GetTickCount();
    player.pos=8.0;
    player.lateral=0.0;
    player.lateral_v=0.0;
    player.speed=0.0;
    player.air_y=0.0;
    player.air_v=0.0;
    player.airborne=0;
    player.damage=0;
    player.boost=100;
    player.lap=1;
    player.lap_start=now;
    player.best_lap=0;
    player.last_index=(int)player.pos;
    ai_pos=24.0;ai_speed=2.55;ai_lateral=-26.0;ai_lap=1;
    race_start=now;
    clear_holds();
}

static void soft_reset_on_track(void)
{
    player.lateral=0.0;
    player.lateral_v=0.0;
    player.air_y=0.0;
    player.air_v=0.0;
    player.airborne=0;
    player.speed=dmin(player.speed,1.2);
}

static void sound_event(int f,int ms,int vol)
{
    if(audio_ok)jtsound_tone(f,ms,vol);
}

static void process_key(int c)
{
    if(c==27){running=0;return;}
    if(c=='p'||c=='P'){paused=!paused;clear_holds();return;}
    if(c=='r'||c=='R'){soft_reset_on_track();return;}
    if(c==JKEY_CURSOR_UP||c=='w'||c=='W')throttle_hold=12;
    if(c==JKEY_CURSOR_DOWN||c=='s'||c=='S')brake_hold=10;
    if(c==JKEY_CURSOR_LEFT||c=='a'||c=='A')left_hold=9;
    if(c==JKEY_CURSOR_RIGHT||c=='d'||c=='D')right_hold=9;
    if(c==' ')boost_hold=12;
}

static void poll_conio(void)
{
    int guard=64,c;
    while(guard--&&kbhit()){
        c=getch();
        if(c>0)process_key(c);
    }
}

static int crossed_jump(int oldidx,int newidx)
{
    int i=oldidx;
    int count=0;
    while(i!=newidx&&count<24){
        i=wrapi(i+1);count++;
        if(track[i].flags&FLAG_JUMP)return 1;
    }
    return (track[newidx].flags&FLAG_JUMP)!=0;
}

static void update_player(void)
{
    int idx,oldidx;
    double steer=0.0,accel=0.0,curve_force;
    unsigned long now;

    if(throttle_hold>0){accel+=0.050;throttle_hold--;}
    if(brake_hold>0){accel-=0.085;brake_hold--;}
    if(left_hold>0){steer-=1.0;left_hold--;}
    if(right_hold>0){steer+=1.0;right_hold--;}
    if(boost_hold>0)boost_hold--;

    player.speed+=accel;
    player.speed-=0.008+player.speed*0.0018;
    if(player.speed<0.0)player.speed=0.0;
    if(boost_hold>0&&player.boost>0&&player.speed>0.8){
        player.speed+=0.055;
        player.boost--;
    }
    if(player.speed>6.4)player.speed=6.4;

    idx=wrapi((int)player.pos);
    curve_force=track[idx].bend*player.speed*player.speed*16.0;
    player.lateral_v+=steer*(0.12+0.075*player.speed)+curve_force;
    player.lateral_v*=0.84;
    player.lateral+=player.lateral_v;

    if(dabs(player.lateral)>TRACK_HALF-13.0){
        player.speed*=0.982;
        if((idx&15)==0&&player.damage<100)player.damage++;
    }
    if(dabs(player.lateral)>TRACK_HALF+48.0){
        player.damage+=12;if(player.damage>100)player.damage=100;
        sound_event(135,180,220);
        soft_reset_on_track();
    }

    oldidx=wrapi((int)player.pos);
    player.pos+=player.speed;
    while(player.pos>=TRACK_LEN){
        player.pos-=TRACK_LEN;
        now=GetTickCount();
        if(player.lap<=RACE_LAPS){
            unsigned long lt=now-player.lap_start;
            if(player.best_lap==0||lt<player.best_lap)player.best_lap=lt;
        }
        player.lap++;
        player.lap_start=now;
        if(player.boost<80)player.boost+=20;else player.boost=100;
        sound_event(980,180,210);
    }
    idx=wrapi((int)player.pos);

    if(!player.airborne&&player.speed>2.4&&crossed_jump(oldidx,idx)){
        player.airborne=1;
        player.air_v=10.5+player.speed*1.4;
        sound_event(720,100,180);
    }
    if(player.airborne){
        player.air_y+=player.air_v;
        player.air_v-=0.72;
        if(player.air_y<=0.0&&player.air_v<0.0){
            player.air_y=0.0;player.air_v=0.0;player.airborne=0;
            sound_event(190,90,180);
            if(dabs(player.lateral)>TRACK_HALF-8.0){player.damage+=5;if(player.damage>100)player.damage=100;}
        }
    }
    player.last_index=idx;
}

static void update_ai(void)
{
    int idx=wrapi((int)ai_pos);
    double target=2.65;
    if(track[idx].flags&FLAG_STEEP)target=2.35;
    if((idx/96)&1)target+=0.18;
    ai_speed+=(target-ai_speed)*0.025;
    ai_pos+=ai_speed;
    while(ai_pos>=TRACK_LEN){ai_pos-=TRACK_LEN;ai_lap++;}
    ai_lateral=26.0*sin((double)idx*0.013);
}

static void update_audio(void)
{
    if(audio_ok)jtsound_update();
}

static int end_screen(int won)
{
    int c;
    char s[96],t[32];
    setfillstyle(SOLID_FILL,BLACK);bar(112,118,528,352);
    setcolor(WHITE);rectangle(112,118,528,352);
    settextstyle(DEFAULT_FONT,HORIZ_DIR,2);
    setcolor(won?LIGHTGREEN:LIGHTRED);
    outtextxy(won?222:244,150,won?"YOU WIN!":"RACE LOST");
    settextstyle(DEFAULT_FONT,HORIZ_DIR,1);
    setcolor(WHITE);
    sprintf(s,"Damage: %d%%",player.damage);outtextxy(242,206,s);
    if(player.best_lap){format_time(player.best_lap,t);sprintf(s,"Best lap: %s",t);outtextxy(242,224,s);}
    outtextxy(190,270,"ENTER = race again     ESC = quit");
    outtextxy(190,291,"R = reset car during a race");
    jtmos_graph_present();
    for(;;){
        c=getch();
        if(c==27)return 0;
        if(c==13||c=='r'||c=='R')return 1;
    }
}

static int title_screen(void)
{
    int c;
    cleardevice();
    setfillstyle(SOLID_FILL,BLUE);bar(0,0,SCREEN_W-1,SCREEN_H-1);
    setfillstyle(SOLID_FILL,DARKGRAY);bar(78,64,562,404);
    setcolor(WHITE);rectangle(78,64,562,404);
    settextstyle(DEFAULT_FONT,HORIZ_DIR,3);
    setcolor(YELLOW);outtextxy(128,95,"STUNT CIRCUIT");
    settextstyle(DEFAULT_FONT,HORIZ_DIR,1);
    setcolor(LIGHTCYAN);outtextxy(141,144,"A JTMOS Turbo C / conio 3D racing game");
    setcolor(WHITE);
    outtextxy(138,188,"UP / W       accelerator");
    outtextxy(138,208,"DOWN / S     brake");
    outtextxy(138,228,"LEFT / A     steer left");
    outtextxy(138,248,"RIGHT / D    steer right");
    outtextxy(138,268,"SPACE        turbo boost");
    outtextxy(138,288,"R            recover to track");
    outtextxy(138,308,"P            pause");
    outtextxy(138,328,"ESC          quit");
    setcolor(LIGHTGREEN);outtextxy(166,364,"Press ENTER to start the race");
    jtmos_graph_present();
    for(;;){c=getch();if(c==27)return 0;if(c==13||c==' ')return 1;}
}

int main(int argc,char **argv)
{
    int gd=DETECT,gm=VGAHI;
    int again=1;
    int won;
    unsigned long frame_start,elapsed;
    (void)argc;(void)argv;

    build_track();
    initgraph(&gd,&gm,"");
    {
        int ge=graphresult();
        if(ge!=grOk){
            printf("stuntcar: BGI init failed: %s\n",grapherrormsg(ge));
            printf("stuntcar: GraOS PID=%d, backend rc=%d\n",
                   GetThreadPID("guiserver"),jtmos_graph_backend_error());
            printf("stuntcar: run 'graos' (or 'pm find guiserver'), then retry.\n");
            printf("stuntcar: use 'bgidemo' to test the BGI/GraOS path separately.\n");
            return 1;
        }
    }
    jtmos_graph_autorefresh(0);
    audio_ok=(jtsound_init()==0);

    if(!title_screen()){running=0;again=0;}
    while(again&&running){
        reset_player();
        paused=0;
        while(running&&player.damage<100&&player.lap<=RACE_LAPS&&ai_lap<=RACE_LAPS){
            frame_start=GetTickCount();
            poll_conio();
            if(!paused){update_player();update_ai();}
            update_audio();
            render_game();
            elapsed=GetTickCount()-frame_start;
            if(elapsed<20UL)delay((unsigned)(20UL-elapsed));
        }
        if(!running)break;
        won=(player.lap>RACE_LAPS)&&(ai_lap<=RACE_LAPS);
        if(player.damage>=100)won=0;
        again=end_screen(won);
    }

    if(audio_ok)jtsound_shutdown();
    closegraph();
    return 0;
}
