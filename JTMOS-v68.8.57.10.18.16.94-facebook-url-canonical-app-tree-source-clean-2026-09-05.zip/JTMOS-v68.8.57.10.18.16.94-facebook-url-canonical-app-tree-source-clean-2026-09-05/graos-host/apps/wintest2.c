// wintest2.c - the bitmap test
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <jtmos/graos.h>

// Request 256K of RAM from the init process.
SYSMEMREQ(APPRAM_256K)

//
void render(GRAOS_PIXEL *buf, int width,int height,
	int frame)
{
	int x,y,ad,c,c2,c3,c4;
	BYTE pal[16]={
		0,8,7,14, 15,14,7,8,
		0,BLUE,GREEN,14, 15,14,GREEN,BLUE
		};

	//
	for(y=0; y<height; y++)
	{
		//
		ad = width*y;
	
		//
		for(x=0; x<width; x++)
		{
			//
			c = ((x+(frame<<4))&(y+(frame<<2)));
			if(c) c=4; else c=0;
			buf[ad+x] = JtmosMCGAColorToRGBA(pal[c+frame+(x*(x>>8)+y >> 8) & 15]);
		}
	}
}

//
void mainLoop(int wid)
{
	static MSG m;
	static GUICMD *cmd;
	static GRAOS_PIXEL *buf;
	static int frame;

	// Get GUICMD PTR
	cmd = (GUICMD*)m.buf;

	//
	buf = malloc(320*240*sizeof(GRAOS_PIXEL));
	//
	addFrameBuffer(wid,
		buf, 0,0,
		320,240, GRAOS_BPP,
		GRAOS_SURFACE_BITMAP, 0);	// type, terID
		// GRAOS_SURFACE_TERMINAL

	// Loop until get exit command
	for(frame=0; ; frame++)
	{
		//
		render(buf, 320,240, frame);

		// Get new message
		if( receiveMessage(&m) )
		{
			// Got new message
			if(cmd->id==GRAOS_GSID_EXIT)
				// We've been ordered to exit
				break;
		}

		// Send refresh request
		refreshWindow(wid);
		// Spare some CPU time
		sleep(1);
	//	SwitchToThread();
	}

	//
	free(buf);
}

// Test window system
int main(int arg, char **argv)
{
	int wid;

	// Get connected to graos (creates msgbox, etc.)
	connectGraos();

	// Create window
	wid = createWindow(32,32, 400,300, "wintest2 (with frame buffer)",
		GRAOS_WINDOW_STANDARD);
	createLabel(wid,20,268,360,16,7600,0,7,GRAOS_LABEL_ALIGN_CENTER,
		"Bitmap framebuffer + server-side Label");

	// Call main loop
	mainLoop(wid);

	// Exit
	return 0;
}

//


