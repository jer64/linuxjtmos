APPNAME=mkdir
include app-common.mk
