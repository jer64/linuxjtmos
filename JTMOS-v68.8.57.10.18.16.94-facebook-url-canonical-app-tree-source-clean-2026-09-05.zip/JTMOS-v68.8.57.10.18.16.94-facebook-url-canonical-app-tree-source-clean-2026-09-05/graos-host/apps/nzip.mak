# JTMOS V65 static ELF32 nzip compressor/decompressor
APPNAME=nzip
JTMOS_LIBC=../libc
CC?=gcc
LD?=ld
CFLAGS=-m32 -march=i486 -std=gnu89 -O2 -ffreestanding -fno-builtin -fno-stack-protector -fno-pie -fno-pic -fno-unwind-tables -fno-asynchronous-unwind-tables -nostdinc -Ulinux -U__linux -U__linux__ -DJTMOS=1 -DJTMOS_APPLICATION=1 -DJTMOS_LEGACY_SOURCE=1 -DCPU=i486 -I$(JTMOS_LIBC)/include
LDFLAGS=-m elf_i386 -static -z noexecstack -T $(JTMOS_LIBC)/jtmos_elf32.ld
CRT0=$(JTMOS_LIBC)/build/application/crt0.o
LIB=$(JTMOS_LIBC)/libcjtmos.a

.PHONY: default clean
default: $(APPNAME).bin

$(CRT0) $(LIB):
	$(MAKE) -C $(JTMOS_LIBC) application

nzip-app.o: nzip.c nzip.h
	$(CC) $(CFLAGS) -c nzip.c -o $@
nzipMain-app.o: nzipMain.c nzip.h
	$(CC) $(CFLAGS) -c nzipMain.c -o $@

$(APPNAME).bin: $(CRT0) $(LIB) nzip-app.o nzipMain-app.o
	$(LD) $(LDFLAGS) $(CRT0) nzip-app.o nzipMain-app.o $(LIB) -o $@

clean:
	rm -f nzip-app.o nzipMain-app.o nzip.bin nzip.map
