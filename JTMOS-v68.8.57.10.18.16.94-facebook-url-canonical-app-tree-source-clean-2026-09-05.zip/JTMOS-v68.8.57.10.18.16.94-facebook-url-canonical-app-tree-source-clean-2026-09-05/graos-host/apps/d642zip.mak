# JTMOS V67 static ELF32 application
APPNAME=d642zip
include app-common.mk
