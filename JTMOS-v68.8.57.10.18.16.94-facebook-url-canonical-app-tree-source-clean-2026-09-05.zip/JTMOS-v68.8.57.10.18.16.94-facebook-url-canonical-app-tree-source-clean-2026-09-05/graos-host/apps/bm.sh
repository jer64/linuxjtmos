#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
echo "apps/bm.sh: legacy flat-binary makefile regeneration is disabled."
exec make -C "$HERE" list
