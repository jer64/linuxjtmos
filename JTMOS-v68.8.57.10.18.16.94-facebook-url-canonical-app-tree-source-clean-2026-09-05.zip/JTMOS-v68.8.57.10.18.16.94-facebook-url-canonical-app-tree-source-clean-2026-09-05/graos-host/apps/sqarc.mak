# sqarc - Squirrel Archive Creator
APPNAME=sqarc
JTMOSSTDLIBCLOC=../libc/stlibc.o
STDSRC=../lib/stdapp.src
CC=gcc
CFLAGS=-Wall -w -c -O -march=i486 -DCPU=i586 -DJTMOS -I../include
LD=ld
LDFLAGS=-oformat=binary -Map $(APPNAME).map -T$(STDSRC) -L../lib -lcjtmos -o $(APPNAME).bin

default: linkit

linkit: application
	@echo ---: Linking out binary: sqarc.bin
	$(LD) $(JTMOSSTDLIBCLOC) sqarc.o $(LDFLAGS)

application:
	$(CC) $(CFLAGS) sqarc.c

clean:
	rm -f sqarc.o
