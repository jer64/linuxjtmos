# JTMOS GraOS JPEG image viewer
APPNAME=iview
APP_OBJS=iview/iview.o iview/jpegdec.o
APP_CFLAGS=-std=gnu89 -fwrapv
include app-common.mk
