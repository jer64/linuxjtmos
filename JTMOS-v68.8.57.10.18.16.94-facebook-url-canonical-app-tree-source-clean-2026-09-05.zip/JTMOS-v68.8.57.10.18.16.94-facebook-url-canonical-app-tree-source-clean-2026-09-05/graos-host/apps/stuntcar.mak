# JTMOS V67 static ELF32 application
APPNAME=stuntcar
include app-common.mk
