# JTMOS V67 static ELF32 application
APPNAME=bgidemo
include app-common.mk
