APPNAME=atapitest
include app-common.mk
