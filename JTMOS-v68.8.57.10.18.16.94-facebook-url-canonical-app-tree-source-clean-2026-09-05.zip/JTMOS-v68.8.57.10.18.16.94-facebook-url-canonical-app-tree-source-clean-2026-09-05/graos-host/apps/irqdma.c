/* JTMOS V65 userspace hardware ABI smoke/example.
 * Do not subscribe to an IRQ owned by an active kernel driver. */
#include <stdio.h>
#include <jtmos/irq.h>
#include <jtmos/dma.h>

int main(int argc,char **argv)
{
    jtmos_dma_buffer b;
    int rc;
    (void)argc; (void)argv;

    rc=jtmos_dma_alloc(16384,0,&b);
    if(rc<0) {
        printf("dma alloc failed: %d\n",rc);
        return 1;
    }
    printf("DMA handle=%lx user=%p phys=%lx bytes=%lu\n",
        b.handle,b.address,b.physical_address,b.size);
    ((unsigned char *)b.address)[0]=0x65;
    jtmos_dma_free(b.handle);
    return 0;
}
