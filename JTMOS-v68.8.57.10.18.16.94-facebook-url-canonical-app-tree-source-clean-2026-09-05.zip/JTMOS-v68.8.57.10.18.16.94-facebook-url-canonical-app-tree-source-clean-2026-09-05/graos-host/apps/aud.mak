# JTMOS V67 static ELF32 application
APPNAME=aud
include app-common.mk
