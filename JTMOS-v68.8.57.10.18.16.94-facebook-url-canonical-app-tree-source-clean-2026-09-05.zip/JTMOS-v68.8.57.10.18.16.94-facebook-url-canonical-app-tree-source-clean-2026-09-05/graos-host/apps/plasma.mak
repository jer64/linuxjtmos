# JTMOS V67 static ELF32 application
APPNAME=plasma
include app-common.mk
