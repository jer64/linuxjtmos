# JTMOS V67 static ELF32 application
APPNAME=vgaplasma
include app-common.mk
