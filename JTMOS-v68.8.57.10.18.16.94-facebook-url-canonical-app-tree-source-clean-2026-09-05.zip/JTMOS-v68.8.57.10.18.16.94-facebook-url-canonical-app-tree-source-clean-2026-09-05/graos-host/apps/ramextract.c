/* ramextract.c - extract DOSBOOT-staged UTILS.ISO from protected-mode RAM. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>

#ifdef JTMOS
SYSMEMREQ(APPRAM_2048K)
#endif

#define RAMEXTRACT_CHUNK 32768U

static long bootutils_size(void)
{
    return (long)scall(SYS_bootutils,0,0,0,0,0,0);
}

static int bootutils_read(unsigned long off, void *buf, unsigned long len)
{
    return (int)scall(SYS_bootutils,1,(DWORD)off,(DWORD)buf,(DWORD)len,0,0);
}

static void usage(void)
{
    printf("Usage: ramextract [OUTPUT]\n");
    printf("Extract DOSBOOT UTILS.ISO RAM bank; default OUTPUT is utils.iso.\n");
}

int main(int argc, char **argv)
{
    const char *outname="utils.iso";
    unsigned char *buf;
    unsigned long size,off=0;
    FILE *out;

    if(argc>2) { usage(); return 1; }
    if(argc==2) {
        if(!strcmp(argv[1],"-h") || !strcmp(argv[1],"--help")) { usage(); return 0; }
        outname=argv[1];
    }

    size=(unsigned long)bootutils_size();
    if(size==0) {
        fprintf(stderr,"ramextract: no valid DOSBOOT UTILS.ISO RAM bank\n");
        return 1;
    }

    buf=(unsigned char *)malloc(RAMEXTRACT_CHUNK);
    if(!buf) {
        fprintf(stderr,"ramextract: cannot allocate transfer buffer\n");
        return 1;
    }
    out=fopen(outname,"wb");
    if(!out) {
        fprintf(stderr,"ramextract: cannot create '%s'\n",outname);
        free(buf);
        return 1;
    }

    printf("ramextract: writing %lu bytes to %s\n",size,outname);
    while(off<size) {
        unsigned long want=size-off;
        int got;
        if(want>RAMEXTRACT_CHUNK) want=RAMEXTRACT_CHUNK;
        got=bootutils_read(off,buf,want);
        if(got<=0 || (unsigned long)got!=want) {
            fprintf(stderr,"ramextract: RAM read failed at offset %lu\n",off);
            fclose(out); free(buf); return 1;
        }
        if(fwrite(buf,1U,want,out)!=want) {
            fprintf(stderr,"ramextract: write failed at offset %lu\n",off);
            fclose(out); free(buf); return 1;
        }
        off+=want;
        SwitchToThread();
    }
    if(fclose(out)!=0) {
        fprintf(stderr,"ramextract: close failed for '%s'\n",outname);
        free(buf); return 1;
    }
    free(buf);
    printf("ramextract: done (%lu bytes)\n",size);
    return 0;
}
