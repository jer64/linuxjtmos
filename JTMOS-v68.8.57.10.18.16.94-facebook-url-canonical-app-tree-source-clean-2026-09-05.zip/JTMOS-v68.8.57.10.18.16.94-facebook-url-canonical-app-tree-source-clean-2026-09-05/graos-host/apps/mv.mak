# JTMOS V67 static ELF32 application
APPNAME=mv
include app-common.mk
