//----------------------------------------------------
// JTMOS Edit - small MS-DOS/PICO style text editor
// Original (C) 2003 by Jari Tuominen
// V67.8.57.10: flicker-free dirty-line redraw + real editing operations.
//----------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "edit.h"
#include "editEditor.h"

#ifdef JTMOS
SYSMEMREQ(APPRAM_1024K)
#endif

EDITOR ed;

static int line_length(int y)
{
    int n;
    if(y<0 || y>=MAX_LINES || ed.buf[y]==NULL) return 0;
    n=(int)strlen((char *)ed.buf[y]);
    if(n>MAX_PER_LINE-1) n=MAX_PER_LINE-1;
    return n;
}

void MarkLineDirty(int logical_y)
{
    if(logical_y<ed.view.y || logical_y>=ed.view.y+EDIT_ROWS) return;
    ed.view.dirty_line=logical_y;
}

void ViewUp(int much)
{
    int old=ed.view.y;
    ed.view.y-=much;
    if(ed.view.y<0) ed.view.y=0;
    if(ed.view.y!=old) ed.view.upd=1;
}

void ViewDown(int much)
{
    int maxview=MAX_LINES-EDIT_ROWS;
    int old=ed.view.y;
    if(maxview<0) maxview=0;
    ed.view.y+=much;
    if(ed.view.y>maxview) ed.view.y=maxview;
    if(ed.view.y!=old) ed.view.upd=1;
}

void CursorUp(void)
{
    if(ed.cursor.y>CURSOR_Y_MIN) ed.cursor.y--;
    else ViewUp(1);
}

void CursorDown(void)
{
    if(ed.cursor.y<CURSOR_Y_MAX) ed.cursor.y++;
    else ViewDown(1);
}

void CursorLeft(void)
{
    int y,len;
    if(ed.cursor.x>CURSOR_X_MIN) { ed.cursor.x--; return; }
    y=GetWritePointY();
    if(y<=0) return;
    CursorUp();
    len=line_length(y-1);
    ed.cursor.x=CURSOR_X_MIN+len;
    if(ed.cursor.x>CURSOR_X_MAX) ed.cursor.x=CURSOR_X_MAX;
}

void CursorRight(void)
{
    int y,len;
    y=GetWritePointY();
    len=line_length(y);
    if(ed.cursor.x<CURSOR_X_MIN+len && ed.cursor.x<CURSOR_X_MAX)
    {
        ed.cursor.x++;
        return;
    }
    if(y+1<ed.lines)
    {
        ed.cursor.x=CURSOR_X_MIN;
        CursorDown();
    }
    else if(ed.cursor.x<CURSOR_X_MAX)
        ed.cursor.x++;
}

void AffectLines(int x,int y)
{
    (void)x;
    if(y>=0 && y<MAX_LINES && y+1>ed.lines) ed.lines=y+1;
}

int GetWritePointY(void)
{
    int y=(ed.cursor.y-CURSOR_Y_MIN)+ed.view.y;
    if(y<0) y=0;
    if(y>=MAX_LINES) y=MAX_LINES-1;
    return y;
}

int GetWritePointX(void)
{
    int x=ed.cursor.x-CURSOR_X_MIN;
    if(x<0) x=0;
    if(x>=MAX_PER_LINE-1) x=MAX_PER_LINE-2;
    return x;
}

void StoreChar(int ch)
{
    int x,y,len,i;
    char *line;
    x=GetWritePointX(); y=GetWritePointY();
    AffectLines(x,y);
    line=(char *)ed.buf[y];
    len=line_length(y);

    if(x>len)
    {
        for(i=len;i<x && i<MAX_PER_LINE-1;i++) line[i]=' ';
        line[x]=0;
        len=x;
    }

    if(ed.insertMode && len<MAX_PER_LINE-1)
    {
        memmove(line+x+1,line+x,(size_t)(len-x+1));
        line[x]=(char)ch;
    }
    else
    {
        line[x]=(char)ch;
        if(x>=len) line[x+1]=0;
    }
    ed.modified=1;
    MarkLineDirty(y);
}

void DeleteAtCursor(void)
{
    int x,y,len;
    char *line;
    x=GetWritePointX(); y=GetWritePointY();
    line=(char *)ed.buf[y]; len=line_length(y);
    if(x>=len) return;
    memmove(line+x,line+x+1,(size_t)(len-x));
    ed.modified=1;
    MarkLineDirty(y);
}

void BackspaceAtCursor(void)
{
    int y;
    if(ed.cursor.x>CURSOR_X_MIN)
    {
        ed.cursor.x--;
        DeleteAtCursor();
        return;
    }
    /* At column zero join with previous line when it fits. */
    y=GetWritePointY();
    if(y>0 && y<ed.lines)
    {
        int prevlen=line_length(y-1),curlen=line_length(y),i;
        if(prevlen+curlen<=MAX_PER_LINE-1)
        {
            strcat((char *)ed.buf[y-1],(char *)ed.buf[y]);
            for(i=y;i<ed.lines-1;i++) strcpy((char *)ed.buf[i],(char *)ed.buf[i+1]);
            if(ed.lines>0) { ed.lines--; ed.buf[ed.lines][0]=0; }
            CursorUp();
            ed.cursor.x=CURSOR_X_MIN+prevlen;
            if(ed.cursor.x>CURSOR_X_MAX) ed.cursor.x=CURSOR_X_MAX;
            ed.modified=1;
            ed.view.upd=1;
        }
    }
}

void SplitLine(void)
{
    int x,y,i,len;
    char tail[MAX_PER_LINE];
    y=GetWritePointY(); x=GetWritePointX(); len=line_length(y);
    if(ed.lines>=MAX_LINES) return;
    if(x>len) x=len;
    strcpy(tail,(char *)ed.buf[y]+x);
    ed.buf[y][x]=0;
    for(i=ed.lines;i>y+1;i--) strcpy((char *)ed.buf[i],(char *)ed.buf[i-1]);
    strcpy((char *)ed.buf[y+1],tail);
    if(ed.lines<y+1) ed.lines=y+1;
    ed.lines++;
    ed.modified=1;
    ed.view.upd=1;
    ed.cursor.x=CURSOR_X_MIN;
    CursorDown();
}

void InsertTab(void)
{
    int x,n,i;
    x=GetWritePointX();
    n=TAB_WIDTH-(x%TAB_WIDTH);
    for(i=0;i<n && GetWritePointX()<MAX_PER_LINE-2;i++)
    {
        StoreChar(' ');
        if(ed.cursor.x<CURSOR_X_MAX) ed.cursor.x++;
    }
}

static void draw_line(int sy,int logical)
{
    char out[81];
    int i,n;
    memset(out,' ',80); out[80]=0;
    if(logical>=0 && logical<MAX_LINES)
    {
        n=line_length(logical);
        if(n>80) n=80;
        for(i=0;i<n;i++) out[i]=(char)ed.buf[logical][i];
    }
    gotoxy(1,sy);
    /* 80 chars is safe above the last row; it may advance logical cursor but
       hardware cursor is hidden during paint and restored once at the end. */
    printf("%s",out);
}

void UpdateEditBox(void)
{
    int sy,logical;
    if(ed.view.upd)
    {
        ed.view.upd=0;
        ed.view.dirty_line=-1;
        for(sy=CURSOR_Y_MIN;sy<=CURSOR_Y_MAX;sy++)
        {
            logical=ed.view.y+(sy-CURSOR_Y_MIN);
            draw_line(sy,logical);
        }
        return;
    }
    logical=ed.view.dirty_line;
    if(logical>=ed.view.y && logical<ed.view.y+EDIT_ROWS)
    {
        sy=CURSOR_Y_MIN+(logical-ed.view.y);
        draw_line(sy,logical);
    }
    ed.view.dirty_line=-1;
}

void EditorOnClose(void)
{
    _setcursortype(_NORMALCURSOR);
    textcolor(7); textbackground(BLACK); clrscr();
}

void EditorInit(void)
{
    int i,offs;
    BYTE *big;
    memset(&ed,0,sizeof(ed));
    big=(BYTE *)malloc(MAX_LINES*MAX_PER_LINE);
    if(big==NULL) return;
    for(i=0,offs=0;i<MAX_LINES;i++,offs+=MAX_PER_LINE)
    {
        ed.buf[i]=big+offs;
        ed.buf[i][0]=0;
    }
    ed.cursor.x=CURSOR_X_MIN;
    ed.cursor.y=CURSOR_Y_MIN;
    ed.insertMode=1;
    ed.view.dirty_line=-1;
    ed.lines=1;
}

int EditorSave(const char *fname)
{
    int y;
    FILE *f=fopen(fname,"wb");
    if(f==NULL) return 1;
    for(y=0;y<ed.lines;y++) fprintf(f,"%s\n",ed.buf[y]);
    fclose(f); ed.modified=0; return 0;
}

int EditorLoad(const char *fname)
{
    int line=0,i=0,ch,next,spaces,k;
    FILE *f=fopen(fname,"rb");
    if(f==NULL) { ed.lines=1; return 1; }
    ed.lines=0;
    while(line<MAX_LINES)
    {
        i=0; ed.buf[line][0]=0;
        while(i<MAX_PER_LINE-1)
        {
            ch=fgetc(f);
            if(ch==EOF || ch==0) goto done;
            if(ch=='\r')
            {
                next=fgetc(f);
                if(next!=EOF && next!='\n') ungetc(next,f);
                break;
            }
            if(ch=='\n') break;
            if(ch=='\t')
            {
                spaces=TAB_WIDTH-(i%TAB_WIDTH);
                for(k=0;k<spaces && i<MAX_PER_LINE-1;k++) ed.buf[line][i++]=' ';
            }
            else if(ch!='\b') ed.buf[line][i++]=(BYTE)ch;
        }
        ed.buf[line][i]=0;
        line++;
        if(ch==EOF || ch==0) break;
    }
done:
    if(i>0 || line==0) line++;
    if(line>MAX_LINES) line=MAX_LINES;
    ed.lines=line;
    fclose(f);
    return 0;
}

int main(int argc,char **argv)
{
    char fname[256];
    if(argc<2) strcpy(fname,"Untitled"); else { strncpy(fname,argv[1],255); fname[255]=0; }
    window(1,1,80,25); gotoxy(1,1);
    if(!Editor(fname)) EditorOnClose();
    return 0;
}
