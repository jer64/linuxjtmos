# JTMOS V67 static ELF32 application
APPNAME=val
include app-common.mk
