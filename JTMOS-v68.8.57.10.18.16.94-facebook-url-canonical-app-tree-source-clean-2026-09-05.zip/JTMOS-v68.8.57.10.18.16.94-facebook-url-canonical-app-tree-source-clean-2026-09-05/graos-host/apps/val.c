/* val.c - validate JTMOS executable files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jtmos/filefind.h>

#ifdef JTMOS
SYSMEMREQ(APPRAM_2048K)
#endif

static int verbose = 0;

static unsigned long le32(const unsigned char *p)
{
    return (unsigned long)p[0] |
           ((unsigned long)p[1] << 8) |
           ((unsigned long)p[2] << 16) |
           ((unsigned long)p[3] << 24);
}

static int is_elf32_jtmos(const unsigned char *buf, size_t len)
{
    if(len < 52U) return 0;
    if(buf[0] != 0x7f || buf[1] != 'E' || buf[2] != 'L' || buf[3] != 'F') return 0;
    if(buf[4] != 1U) return 0;             /* ELFCLASS32 */
    if(buf[5] != 1U) return 0;             /* little endian */
    if(buf[16] != 2U || buf[17] != 0U) return 0; /* ET_EXEC */
    if(buf[18] != 3U || buf[19] != 0U) return 0; /* EM_386 */
    if(le32(buf + 24) != 0x80004000UL) return 0; /* JTMOS Ring3 entry */
    return 1;
}

static int contains_bytes(const unsigned char *buf, size_t len, const char *needle)
{
    size_t i;
    size_t n = strlen(needle);
    if(n == 0U || len < n) return 0;
    for(i = 0U; i + n <= len; ++i)
        if(memcmp(buf + i, needle, n) == 0) return 1;
    return 0;
}

static int is_legacy_jtmos(const unsigned char *buf, size_t len)
{
    static const char first[] = "[JTMOS LIBC (C) 2002 Jari Tuominen]";
    static const char tail[] = "[VALID JTMOS EXECUTABLE BINARY FILE FCE2E37BE38BA000]";
    return contains_bytes(buf, len, first) && contains_bytes(buf, len, tail);
}

static int validate_file(const char *path)
{
    FILE *f;
    unsigned char header[64];
    unsigned char *all = NULL;
    size_t got;
    int length;
    int valid = 0;
    const char *kind = "unknown";

    f = fopen(path, "rb");
    if(f == NULL) {
        printf("val: cannot open '%s'\n", path);
        return 1;
    }
    length = fsizeof(path);
    if(length < 0) {
        printf("val: cannot determine size of '%s'\n", path);
        fclose(f);
        return 1;
    }

    got = fread(header, 1U, sizeof(header), f);
    if(is_elf32_jtmos(header, got)) {
        valid = 1;
        kind = "ELF32 Ring3";
    } else if(length > 0 && length <= 1024 * 1024) {
        all = (unsigned char *)malloc((size_t)length);
        if(all != NULL) {
            rewind(f);
            got = fread(all, 1U, (size_t)length, f);
            if(got == (size_t)length && is_legacy_jtmos(all, got)) {
                valid = 1;
                kind = "legacy flat binary";
            }
            free(all);
        }
    }
    fclose(f);

    if(valid) {
        if(verbose) printf("%s: valid JTMOS executable (%s, %d bytes)\n", path, kind, length);
        else printf("%s: valid JTMOS executable (%s)\n", path, kind);
        return 0;
    }
    printf("%s: not a recognized JTMOS executable\n", path);
    return 1;
}

static int has_wildcards(const char *s)
{
    return strchr(s, '*') != NULL || strchr(s, '?') != NULL;
}

static int wildcard_match(const char *pattern, const char *text)
{
    while(*pattern) {
        if(*pattern == '*') {
            while(*pattern == '*') ++pattern;
            if(!*pattern) return 1;
            while(*text) {
                if(wildcard_match(pattern, text)) return 1;
                ++text;
            }
            return 0;
        }
        if(*pattern == '?') {
            if(!*text) return 0;
            ++pattern;
            ++text;
            continue;
        }
        if(*pattern != *text) return 0;
        ++pattern;
        ++text;
    }
    return *text == 0;
}

static int validate_pattern(const char *pattern)
{
    FFBLK ff;
    int fd;
    int matches = 0;
    int rc = 0;

    if(!has_wildcards(pattern)) return validate_file(pattern);
    fd = findfirst("*", &ff);
    if(fd <= 0) {
        printf("val: cannot list current directory\n");
        return 1;
    }
    for(;;) {
        if(ff.ff_fsize != -1 && !JTMFS_TYPE_IS_DIRECTORY(ff.ff_attrib) &&
           wildcard_match(pattern, ff.ff_name)) {
            ++matches;
            if(validate_file(ff.ff_name) != 0) rc = 1;
        }
        if(findnext(fd, &ff) != 0) break;
    }
    close(fd);
    if(matches == 0) {
        printf("val: no files match '%s'\n", pattern);
        return 1;
    }
    return rc;
}

static void help(void)
{
    printf("Usage: val [OPTIONS] FILE [FILE ...]\n");
    printf("Validate current ELF32 JTMOS Ring3 executables and legacy flat binaries.\n");
    printf("  -v, --verbose   include type and file size\n");
    printf("  -h, --help      show this help\n");
}

int main(int argc, char **argv)
{
    int i;
    int files = 0;
    int rc = 0;

    if(argc < 2) {
        help();
        return 1;
    }
    for(i = 1; i < argc; ++i) {
        if(!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help") || !strcmp(argv[i], "/?")) {
            help();
            return 0;
        }
        if(!strcmp(argv[i], "-v") || !strcmp(argv[i], "--verbose") || !strcmp(argv[i], "/v")) {
            verbose = 1;
            continue;
        }
        ++files;
        if(validate_pattern(argv[i]) != 0) rc = 1;
    }
    if(files == 0) {
        printf("val: missing file operand\n");
        return 1;
    }
    return rc;
}
