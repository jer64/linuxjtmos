/* JTMOS/GraOS MPEG-1 Program Stream player with MP2 sound. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <jtmos/process.h>
#include <jtmos/graos.h>
#include <jtmos/audio.h>
#include "pl_mpeg.h"

SYSMEMREQ(APPRAM_12288K)
#define VIDEO_MAX_W 640
#define VIDEO_MAX_H 480
#define AUDIO_CHUNK 1152

typedef struct {
    int wid,width,height,samplerate,quit,paused,audio_ok,server_closed;
    unsigned long frames;
    GRAOS_PIXEL *pixels;
    BYTE pcm[AUDIO_CHUNK];
} PLAYER;

static int clamp255(int v){if(v<0)return 0;if(v>255)return 255;return v;}
static GRAOS_PIXEL rgb_rgba(int r,int g,int b)
{
    return GRAOS_RGB(clamp255(r),clamp255(g),clamp255(b));
}
static void poll_events(PLAYER *p)
{
    GUICMD ev;int r;
    while((r=JtmosGraOSPollEvent(p->wid,&ev))>0){
        if(ev.id==GRAOS_GSID_EXIT){p->quit=1;p->server_closed=1;}
        else if(ev.id==GRAOS_GSID_KEYPRESSED){
            if(ev.v[0]==27||ev.v[0]=='q'||ev.v[0]=='Q')p->quit=1;
            else if(ev.v[0]==' ')p->paused=!p->paused;
        }
    }
    if(r<0){p->quit=1;p->server_closed=1;}
}
static void video_callback(plm_t *mpeg,plm_frame_t *frame,void *user)
{
    PLAYER *p=(PLAYER*)user;unsigned int x,y,sx,sy,cx,cy;
    int yy,cb,cr,r,g,b;(void)mpeg;
    for(y=0;y<(unsigned int)p->height;y++){
        sy=(y*frame->height)/(unsigned int)p->height;cy=sy>>1;
        for(x=0;x<(unsigned int)p->width;x++){
            sx=(x*frame->width)/(unsigned int)p->width;cx=sx>>1;
            yy=(int)frame->y.data[sy*frame->y.width+sx]-16;
            cb=(int)frame->cb.data[cy*frame->cb.width+cx]-128;
            cr=(int)frame->cr.data[cy*frame->cr.width+cx]-128;
            if(yy<0)yy=0;
            r=(298*yy+409*cr+128)>>8;
            g=(298*yy-100*cb-208*cr+128)>>8;
            b=(298*yy+516*cb+128)>>8;
            p->pixels[y*p->width+x]=rgb_rgba(r,g,b);
        }
    }
    p->frames++;
    if(refreshWindow(p->wid)<0){p->quit=1;p->server_closed=1;return;}
    poll_events(p);
}
static void audio_callback(plm_t *mpeg,plm_samples_t *samples,void *user)
{
    PLAYER *p=(PLAYER*)user;unsigned int i;int value,offset,written;float mono;
    (void)mpeg;if(!p->audio_ok||p->quit)return;
    if(samples->count>AUDIO_CHUNK){p->audio_ok=0;return;}
    for(i=0;i<samples->count;i++){
        mono=(samples->interleaved[i*2]+samples->interleaved[i*2+1])*0.5f;
        value=(int)(mono*127.0f)+128;p->pcm[i]=(BYTE)clamp255(value);
    }
    offset=0;
    while(offset<(int)samples->count&&!p->quit){
        written=AudioWrite(p->pcm+offset,(int)samples->count-offset,
            AUDIO_FORMAT_U8_MONO,p->samplerate);
        if(written<0){p->audio_ok=0;break;}
        if(written==0){poll_events(p);usleep(1000);}else offset+=written;
    }
}
static void usage(const char *name)
{
    printf("JTMOS MPEG-1 video player with MP2 audio\n");
    printf("Usage: %s file.mpg [--mute] [--loop]\n",name);
    printf("Keys: Space pause/resume, Q or Esc quit\n");
    printf("Input: MPEG-1 Program Stream, MPEG-1 video, MPEG-1 Layer II audio.\n");
}
int main(int argc,char **argv)
{
    PLAYER p;plm_t *mpeg;unsigned long then,now;double dt;
    int mute=0,loop=0,i,source_w,source_h,fps100;
    if(argc<2){usage(argv[0]);return 1;}
    for(i=2;i<argc;i++){
        if(!strcmp(argv[i],"--mute"))mute=1;
        else if(!strcmp(argv[i],"--loop"))loop=1;
        else{usage(argv[0]);return 1;}
    }
    memset(&p,0,sizeof(p));mpeg=plm_create_with_filename(argv[1]);
    if(!mpeg){printf("mpeg1: cannot open or parse '%s'.\n",argv[1]);return 1;}
    source_w=plm_get_width(mpeg);source_h=plm_get_height(mpeg);
    if(source_w<=0||source_h<=0){printf("mpeg1: MPEG-1 video stream was not found.\n");plm_destroy(mpeg);return 1;}
    p.width=source_w>VIDEO_MAX_W?VIDEO_MAX_W:source_w;
    p.height=source_h>VIDEO_MAX_H?VIDEO_MAX_H:source_h;
    p.samplerate=plm_get_samplerate(mpeg);
    p.pixels=(GRAOS_PIXEL*)malloc((size_t)p.width*(size_t)p.height*sizeof(GRAOS_PIXEL));
    if(!p.pixels){printf("mpeg1: framebuffer allocation failed.\n");plm_destroy(mpeg);return 1;}
    { int px; for(px=0;px<p.width*p.height;px++) p.pixels[px]=GRAOS_RGB(0,0,0); }
    if(connectGraos()<0){printf("mpeg1: GraOS is not running.\n");free(p.pixels);plm_destroy(mpeg);return 1;}
    p.wid=createWindow(24,40,p.width+16,p.height+48,"JTMOS MPEG-1 Player",GRAOS_WINDOW_STANDARD);
    if(p.wid<0||addFrameBuffer(p.wid,p.pixels,0,0,p.width,p.height,GRAOS_BPP,GRAOS_SURFACE_BITMAP,0)<0){
        printf("mpeg1: cannot create GraOS video surface.\n");if(p.wid>=0)closeWindow(p.wid);free(p.pixels);plm_destroy(mpeg);return 1;
    }
    if(refreshWindow(p.wid)<0){closeWindow(p.wid);free(p.pixels);plm_destroy(mpeg);return 1;}
    p.audio_ok=!mute&&plm_get_num_audio_streams(mpeg)>0&&p.samplerate>=4000&&
        p.samplerate<=44100&&AudioInit()>=0;
    if(!p.audio_ok)plm_set_audio_enabled(mpeg,FALSE);
    else{AudioStop();plm_set_audio_lead_time(mpeg,0.12);}
    plm_set_loop(mpeg,loop);plm_set_video_decode_callback(mpeg,video_callback,&p);
    plm_set_audio_decode_callback(mpeg,audio_callback,&p);
    fps100=(int)(plm_get_framerate(mpeg)*100.0+0.5);
    printf("mpeg1: %dx%d %d.%02d fps, audio %s",source_w,source_h,
        fps100/100,fps100%100,p.audio_ok?"enabled":"disabled");
    if(p.audio_ok) printf(" at %d Hz",p.samplerate);
    printf(".\n");
    then=GetTickCount();
    while(!p.quit&&!plm_has_ended(mpeg)){
        poll_events(&p);now=GetTickCount();dt=(double)(now-then)/1000.0;then=now;
        if(!p.paused)plm_decode(mpeg,dt>0.25?0.25:dt);else usleep(10000);
        SwitchToThread();
    }
    AudioStop();
    if(!p.server_closed)closeWindow(p.wid);
    printf("mpeg1: stopped after %lu video frames.\n",p.frames);
    plm_destroy(mpeg);free(p.pixels);return 0;
}
