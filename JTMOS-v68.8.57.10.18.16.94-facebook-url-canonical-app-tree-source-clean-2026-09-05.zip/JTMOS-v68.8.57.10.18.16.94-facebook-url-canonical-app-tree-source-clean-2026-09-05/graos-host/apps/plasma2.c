/* plasma2.c - windowed GraOS variant of the historical 320x200 demo. */
#include <stdlib.h>
#include <jtmos/process.h>
#include "graos_demo.h"
SYSMEMREQ(APPRAM_512K)
#define W 320
#define H 200
static BYTE *sinus;
static void render(JTMOS_GRAOS_DEMO *d,unsigned long frame)
{
    int x,y; unsigned int idx,v;
    for(y=0;y<H;y++) for(x=0;x<W;x++) {
        idx=(unsigned int)(sinus[(x+frame)&65535]+sinus[(y+(frame>>1))&65535]+frame)&65535U;
        v=sinus[idx];
        d->pixels[y*W+x]=GRAOS_RGB(v,(v+(frame&63))&255,255-v);
    }
}
int main(void)
{
    JTMOS_GRAOS_DEMO d; unsigned long frame=0; int i,key;
    sinus=(BYTE*)malloc(65536); if(!sinus) return 1;
    for(i=0;i<65536;i++) sinus[i]=(BYTE)(((unsigned long)i*(unsigned long)i)>>8);
    if(jtmos_demo_open(&d,"Plasma II - Esc closes",W,H)!=0) { free(sinus); return 2; }
    for(;;) {
        key=jtmos_demo_poll(&d); if(key<0 || key==27) break;
        if(!d.focused) { jtmos_demo_idle(30); continue; }
        render(&d,frame++); if(jtmos_demo_present(&d)<0) break;
        jtmos_demo_idle(30);
    }
    jtmos_demo_close(&d); free(sinus); return 0;
}
