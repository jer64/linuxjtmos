/* mkdir.c - create directories */
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>

static void help(void)
{
    printf("Usage: mkdir DIRECTORY [DIRECTORY ...]\n");
    printf("Create one or more directories.\n");
}

int main(int argc, char **argv)
{
    int i;
    int rc = 0;

    if(argc < 2) {
        help();
        return 1;
    }
    if(!strcmp(argv[1], "-h") || !strcmp(argv[1], "--help")) {
        help();
        return 0;
    }
    for(i = 1; i < argc; ++i) {
        if(mkdir(argv[i], 0) != 0) {
            printf("mkdir: cannot create '%s'\n", argv[i]);
            rc = 1;
        }
    }
    return rc;
}
