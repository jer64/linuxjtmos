/* mv.c - move/rename a file, with copy+remove fallback */
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>

static void normalize_lexical_path(char *out, size_t cap, const char *path)
{
    size_t n=0;
    const char *p=path;
    if(cap==0) return;
    while(p && p[0]=='.' && (p[1]=='/' || p[1]=='\\')) p+=2;
    while(p && *p && n+1<cap)
    {
        char c=*p++;
        if(c=='\\') c='/';
        if(c=='/' && n>0 && out[n-1]=='/') continue;
        if(c=='.' && n>0 && out[n-1]=='/' && (*p=='/' || *p=='\\'))
        { ++p; continue; }
        out[n++]=c;
    }
    while(n>1 && out[n-1]=='/') --n;
    out[n]=0;
}

static int same_lexical_path(const char *a, const char *b)
{
    char na[512],nb[512];
    normalize_lexical_path(na,sizeof(na),a);
    normalize_lexical_path(nb,sizeof(nb),b);
    return !strcmp(na,nb);
}

static const char *base_name(const char *path)
{
    const char *p;
    const char *base = path;
    for(p = path; p && *p; ++p)
        if(*p == '/' || *p == '\\') base = p + 1;
    return base;
}

static int path_is_dir(const char *path)
{
    struct stat st;
    return path != NULL && stat(path, &st) == 0 && S_ISDIR(st.st_mode);
}

static int make_target(char *out, size_t outsz, const char *dst, const char *src)
{
    size_t n;
    if(path_is_dir(dst)) {
        n = strlen(dst);
        if(n && (dst[n-1] == '/' || dst[n-1] == '\\'))
            return snprintf(out, outsz, "%s%s", dst, base_name(src)) < (int)outsz ? 0 : 1;
        return snprintf(out, outsz, "%s/%s", dst, base_name(src)) < (int)outsz ? 0 : 1;
    }
    return snprintf(out, outsz, "%s", dst) < (int)outsz ? 0 : 1;
}

static int copy_file(const char *src, const char *dst)
{
    FILE *in;
    FILE *out;
    unsigned char buf[8192];
    size_t got;
    int rc = 0;

    in = fopen(src, "rb");
    if(in == NULL) return 1;
    out = fopen(dst, "wb");
    if(out == NULL) { fclose(in); return 1; }
    while((got = fread(buf, 1U, sizeof(buf), in)) != 0U) {
        if(fwrite(buf, 1U, got, out) != got) { rc = 1; break; }
        SwitchToThread();
    }
    if(ferror(in)) rc = 1;
    if(fclose(in) != 0) rc = 1;
    if(fclose(out) != 0) rc = 1;
    return rc;
}

static void help(void)
{
    printf("Usage: mv SOURCE DEST\n");
    printf("Move SOURCE to DEST. Cross-device moves fall back to copy+remove.\n");
}

int main(int argc, char **argv)
{
    char target[512];

    if(argc == 2 && (!strcmp(argv[1], "-h") || !strcmp(argv[1], "--help"))) {
        help();
        return 0;
    }
    if(argc != 3) {
        help();
        return 1;
    }
    if(make_target(target, sizeof(target), argv[2], argv[1]) != 0) {
        printf("mv: destination path too long\n");
        return 1;
    }
    if(same_lexical_path(argv[1], target)) return 0;

    if(rename(argv[1], target) == 0) return 0;

    /* JTMOS rename is same-filesystem only.  Preserve mv semantics across
       devices by copying first and removing the source only after success. */
    if(copy_file(argv[1], target) != 0) {
        remove(target);
        printf("mv: cannot move '%s' to '%s'\n", argv[1], target);
        return 1;
    }
    if(remove(argv[1]) != 0) {
        printf("mv: copied to '%s' but could not remove source '%s'\n", target, argv[1]);
        return 1;
    }
    return 0;
}
