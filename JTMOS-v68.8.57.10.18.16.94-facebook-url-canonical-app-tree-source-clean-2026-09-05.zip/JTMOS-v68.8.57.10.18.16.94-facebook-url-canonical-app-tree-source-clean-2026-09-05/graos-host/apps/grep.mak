# JTMOS V68 static ELF32 application
APPNAME=grep
include app-common.mk
