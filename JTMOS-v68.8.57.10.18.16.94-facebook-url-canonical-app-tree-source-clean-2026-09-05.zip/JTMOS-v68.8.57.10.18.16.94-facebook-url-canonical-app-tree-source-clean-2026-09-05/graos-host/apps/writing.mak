# JTMOS V67 static ELF32 application
APPNAME=writing
include app-common.mk
