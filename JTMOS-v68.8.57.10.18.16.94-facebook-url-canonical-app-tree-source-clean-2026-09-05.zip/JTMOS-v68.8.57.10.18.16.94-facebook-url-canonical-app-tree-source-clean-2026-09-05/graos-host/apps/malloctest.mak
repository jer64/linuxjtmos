# JTMOS V67 static ELF32 application
APPNAME=malloctest
include app-common.mk
