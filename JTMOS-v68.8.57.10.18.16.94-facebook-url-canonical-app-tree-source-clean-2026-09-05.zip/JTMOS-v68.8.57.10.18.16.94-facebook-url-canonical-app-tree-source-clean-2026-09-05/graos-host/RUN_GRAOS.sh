#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
if [ ! -x build/bin/graos ]; then
    make
fi
exec ./build/bin/graos "$@"
