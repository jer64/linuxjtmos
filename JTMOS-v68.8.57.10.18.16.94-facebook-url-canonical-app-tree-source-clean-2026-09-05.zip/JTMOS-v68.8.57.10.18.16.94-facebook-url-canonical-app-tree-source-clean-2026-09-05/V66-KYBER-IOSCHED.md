# JTMOS V66 - Kyber-inspired block I/O scheduler

Date: 2026-08-22

## Purpose

V66 adds a latency-oriented block I/O scheduling policy inspired by the Linux
Kyber I/O scheduler.  It is a clean-room JTMOS implementation adapted to the
existing synchronous block-device ABI.

Linux references used for the scheduling model:

- Linux kernel Kyber tunables documentation:
  https://www.kernel.org/doc/html/latest/block/kyber-iosched.html
- Linux `block/kyber-iosched.c`:
  https://github.com/torvalds/linux/blob/master/block/kyber-iosched.c

The JTMOS implementation does not copy Linux source code.

## What V66 implements

### Scheduling domains

JTMOS currently schedules two block-I/O domains:

- READ
- WRITE

The default latency targets are:

- reads: 2000 us (2 ms)
- writes: 10000 us (10 ms)

Those defaults follow the latency-oriented values used by Linux Kyber for read
and synchronous-write traffic.

### Admission control and fairness

The scheduler has a 64-request global request pool.  Sixteen entries (25%) are
reserved from write exhaustion so that reads retain admission capacity under a
write-heavy workload.

Initial/max software depths:

| Domain | Initial | Maximum | Batch |
| --- | ---: | ---: | ---: |
| READ | 16 | 48 | 16 |
| WRITE | 8 | 32 | 8 |

These depths are intentionally smaller than Linux Kyber's blk-mq limits because
JTMOS currently has a much smaller synchronous device layer.

### Latency feedback

JTMOS uses `PitGetUsec()` for latency accounting.  With the current PIT setup it
has approximately 215 us timing resolution, which is much more useful for SSD
latency feedback than the millisecond tick clock.

Each domain tracks eight latency buckets relative to its configured target.
The first four buckets are treated as good latency.  Periodically the scheduler
uses:

- p90 device/I/O latency to detect congestion;
- p99 total request latency to adjust domain depth.

The depth control follows the Kyber idea of scaling the token depth relative to
the observed p99/target ratio.  If read p99 exceeds its target, the write batch
is temporarily restricted to one request to protect interactive reads.

The adaptation window is 64 completions or one second, whichever gives useful
feedback first.  This is smaller than Linux's high-throughput blk-mq sampling
window and is deliberate for JTMOS's smaller request pool.

### Starvation protection

A queued request whose age reaches four times its domain target becomes an
expired request.  An expired domain takes precedence over normal batching.

### Physical queue sharing

Partition names such as `hda1`, `hda2`, etc. map to the parent `hda` scheduling
state.  This prevents partitions of the same physical disk from receiving
independent software queue limits.

### Ordering barriers

Before block-device FLUSH or UNMOUNT, a Kyber barrier first freezes new
admissions and drains already scheduled I/O. The device barrier is issued only
after the queue is empty, then admissions reopen. This prevents a concurrent
request from overtaking a filesystem flush/unmount boundary.

### Devices

Kyber is enabled automatically for fixed/fast-storage style device names:

- `hda`, `hdb`, `hdc`, `hdd` and their partitions;
- future `nvme...` names;
- future `sd...` and `vd...` names.

It deliberately bypasses floppy, `sys:`, RAM disk and similar devices.  Those
keep their historical direct synchronous path.

## SMSH control

Examples:

```
kyber status
kyber status hda
kyber on hda
kyber off hda
kyber target hda 2000 10000
kyber targetms hda 2 10
kyber reset hda
```

`target` is in microseconds and `targetms` is in milliseconds.

Status reports the current target, dynamic depths, queued/outstanding requests,
completion/error counts, running average/max latency and depth-adjustment count.

Disabling a queue stops new Kyber admissions and then drains requests that were
already admitted, so `kyber off` does not strand synchronous callers.

## Block API fixes made while integrating the scheduler

`readblocks()` and `writeblocks()` previously reused the same buffer address for
every block.  V66 advances the caller buffer by the device block size for each
block and stops at the first error.

`readblock1()`/`writeblock1()` validate the block before taking the direct-access
lock so invalid requests cannot leave that lock permanently held.

Block-device flushes are active again and Kyber-aware.

## Important limitation: this is not an NVMe driver

V66 does **not** claim native NVMe support.  The current `hda` backend is legacy
synchronous ATA/PIO.  Therefore the V66 scheduler can queue, order,
admission-control and measure competing requests before the existing driver,
but only one request per physical queue is submitted to the synchronous backend
at a time.

A future NVMe driver should retain the policy layer and replace the synchronous
`readblock1()`/`writeblock1()` dispatch backend with asynchronous submission and
completion queues.  That is the point where Kyber's software depths can map to
real hardware queue depth and deliver the full high-throughput NVMe benefit.

## Multitasking and early boot

The scheduler is bypassed before multitasking is active and while the PIT is in
storage-safe boot mode.  This preserves the old early-boot disk path.

Waiting Kyber callers use the existing JTMOS cooperative `SwitchToThread()`
mechanism so a request owner can complete while another caller is waiting.  The
actual legacy device call remains protected by JTMOS's direct-access lock.

## Build status

The modified scheduler/block/shell C objects compile with the normal JTMOS
32-bit freestanding GCC flags.  The modern LIBC application and kernel profile
checks also pass.

The build environment used to prepare this release has no NASM or QEMU, so the
complete kernel image was not freshly assembled or runtime-booted here.  Use
`make clean && make` and QEMU on the JTMOS development workstation for the final
runtime validation.
