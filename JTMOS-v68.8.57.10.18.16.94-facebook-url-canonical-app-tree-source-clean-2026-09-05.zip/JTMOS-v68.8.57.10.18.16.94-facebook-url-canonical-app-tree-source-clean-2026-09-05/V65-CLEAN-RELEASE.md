JTMOS V65 CLEAN RELEASE
=======================
Date: 2026-08-22

Build
-----
A normal release build is now intentionally one command:

    make

The default target builds the kernel and libc/apps, creates the compressed
install payload, creates the normal JTMOS boot image, and creates the separate
1.44 MiB extended utilities/demo floppy:

    jtm32.img
    utils1440.img

Explicit targets remain available:

    make image
    make utilsimage
    make packages
    make linkit       # compatibility alias for make image
    make clean
    make check

There is no kernel32 "imp" target or build stage in V65.

Compressed install / utilities design
-------------------------------------
The release uses the historical JTMOS formats rather than expanding every
program directly into the floppy image:

    install payload -> SQA install.img -> nzip -> install.img.nz

The normal sys: area and the extended utilities disk contain a small bootstrap
SQA with at least:

    unz.bin
    sqa.bin
    install.img.nz
    README.txt

The kernel SMSH keeps its built-in `sqa` command.  It also keeps the built-in
`nzip` command.  The external unz.bin helper is built with UNCOMPRESS_ALL and
performs both stages for an install image:

    install.img.nz -> install.img -> extracted SQA files

The temporary install.img is removed only after the SQA extractor reports
success.

Suggested RAM-disk demo flow from SMSH:

    cd ram
    copyall sys
    :unz install.img.nz

`copyall` is a kernel SMSH builtin, so the compressed package can bootstrap
without first needing cp.bin.  The same model can be used on hda after the
filesystem has been prepared.

Extended utilities disk
-----------------------
The dedicated image description is:

    jtm32-util.cfg

It builds:

    utils1440.img      exactly 1,474,560 bytes

The payload includes the curated V65 ELF32 utilities and demos, GraOS and its
resources, help/configuration files, the external driver/config artifacts that
exist in the tree, and an IRQ/DMA ABI demonstration program.  FDC, SB, GUS,
IDE and several other boot-critical drivers are still kernel-owned in V65;
the disk does not pretend that those have already been converted to external
ELF32 drivers.

RAM disk
--------
The old default RAM disk was 2,880 x 512-byte blocks = 1.44 MiB.  V65 uses a
preferred demo maximum of 65,536 blocks = 32 MiB and scales it according to
physical RAM so the kernel/processes retain memory:

    detected RAM    default RAM disk
    -----------     ----------------
       16 MiB             4 MiB
       32 MiB             8 MiB
       64 MiB            16 MiB
      128 MiB+           32 MiB

This provides enough room for the compressed package, temporary expanded SQA
image, and extracted demo files to coexist during installation/demo use on
normal emulator configurations.

SQA / nzip reliability fixes
----------------------------
The V65 release build also fixes old host-tool assumptions that mattered for
this packaging flow:

* host nzip uses explicit 8/16/32-bit stream types;
* nzip decoding reads little-endian words/dwords byte-wise instead of using
  unaligned pointer casts;
* host sqarc reduces a source path to the 30-character SQA basename before
  writing the fixed-size FE record (the old order could overwrite the offset);
* sqarc prefers boot32/nonsysdisk.bin and retains .biz as a legacy fallback;
* application SQA extraction validates descriptor offsets, reads/writes and
  checksums and returns an error to unz on failure;
* kernel SMSH sqarc likewise prefers the current nonsysdisk.bin filename.

Build requirements
------------------
On a Debian/Ubuntu development host install the normal 32-bit toolchain and
NASM.  The release expects GCC with -m32 support, GNU binutils, NASM, Perl and
GNU make.
