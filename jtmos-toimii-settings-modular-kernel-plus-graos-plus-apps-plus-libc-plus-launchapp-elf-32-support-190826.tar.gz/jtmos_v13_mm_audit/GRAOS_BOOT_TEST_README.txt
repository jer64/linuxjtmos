JTMOS / GraOS native boot test - 2026-08-19
============================================================

Purpose
-------
This tree contains a native JTMOS test boot path that starts GraOS as a
JTMOS application after kernel initialization.  It is intended for a
1.44 MB raw floppy image and does not require hd_jtmos.img.

Main fixes in this test branch
------------------------------
* Restored the native kernel shell tree.  The Linux/SDL2 GraOS host port
  that had been merged over kernel32/sh is preserved separately as
  graos-host/.
* Fixed the kernel build for current GCC: JTMOS define, gnu89, -fcommon,
  -fno-pie and source filtering in autogen.pl.
* Added GAS fallbacks for low-level objects that otherwise require NASM.
* Fixed JTMFS direct-file lseek() semantics and the accidental chdir()->
  deletefile() call.
* Initialized JTMFS only after the RAM block device exists.
* Initialized centralprocess before trying to launch an application.
* Removed the unconditional infinite BackupFailsafeSystem() call from the
  normal boot path.  Failsafe remains the error path.
* Added GraOSBootInstall()/GraOSBootStart().
* GraOS is built as a normal JTMOS application with the legacy executable
  identifiers and requests 2 MB application RAM.
* The GraOS runtime package contains graos.bin, taskbar.bin, winshell.bin,
  guifont.raw, mousecursor.raw, taskbar.raw, taskbar8.raw and background.raw.

Floppy layout
-------------
Sector 0..17     : original 9 KB JTMOS boot-loader area
Sector 18..1043  : legacy kernel loader area (57 x 18 sectors)
Sector 1044...   : GRAOSPK1 package

The boot loader checksum field at byte 501 is patched by the image builder
to match the first 512 KiB of the kernel-load area.  The native kernel is
kept below that limit; GraOS assets are deliberately NOT linked into the
kernel because doing so would cross the PC conventional-memory/VGA hole.

Boot flow
---------
BIOS -> JTMOS boot loader -> kernel32.bin -> drivers -> floppy + RAM disk ->
JTMFS format/mount -> unpack GRAOSPK1 into /bin -> centralprocess ->
/bin/graos.bin -> taskbar/winshell as GraOS applications.

Build
-----
From the source-tree root:

    ./scripts/build_graos_test.sh

This rebuilds the GraOS applications, native kernel, payload package and
GraOS-boot-test.img.  A SHA-256 file is produced next to the image.

Run with QEMU
-------------
Install QEMU on the host and run:

    ./run_graos_test_qemu.sh

or:

    qemu-system-i386 -m 64 -drive file=GraOS-boot-test.img,format=raw,if=floppy -boot a

Validation performed for this release
-------------------------------------
* native kernel compiles and links with GNU GCC/binutils in this environment
* kernel size remains below the legacy loader limit
* boot sector has the 55 AA signature
* boot checksum equals the checksum of the actual image kernel-load area
* GRAOSPK1 header and all 8 payload files round-trip byte-for-byte
* graos.bin/taskbar.bin/winshell.bin contain both the legacy JTMOS LIBC
  identification and VALID JTMOS EXECUTABLE marker

Runtime-test limitation
-----------------------
The build environment used to prepare this archive did not contain QEMU or
Bochs, so an actual BIOS/emulator screen boot could not be executed here.
The image itself, boot-loader layout, checksum, kernel link and embedded
runtime payload were validated as described above.
