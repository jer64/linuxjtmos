#!/bin/sh
set -eu
if [ $# -lt 2 ]; then
  echo "usage: $0 native|linux ROOT" >&2
  exit 2
fi
MODE=$1
ROOT=$2
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
case "$MODE" in
  native)
    patch -d "$ROOT" -p1 < "$HERE/patches/jtmos_native_graos_filer.patch"
    cp "$HERE/apps/filer.c" "$ROOT/libc/apps/filer.c"
    cp "$HERE/apps/filer.hlp" "$ROOT/libc/apps/filer.hlp"
    cp "$HERE/apps/filer.mak" "$ROOT/libc/apps/filer.mak"
    echo "Installed native sources. Build: cd '$ROOT/libc/apps' && make -f filer.mak"
    ;;
  linux)
    patch -d "$ROOT" -p1 < "$HERE/patches/linux_graos_filer.patch"
    cp "$HERE/apps/filer.c" "$ROOT/apps/filer.c"
    cp "$HERE/apps/filer.hlp" "$ROOT/apps/filer.hlp"
    cp "$HERE/apps/filer.mak" "$ROOT/apps/filer.mak"
    echo "Installed Linux GraOS sources. Build: make -C '$ROOT/compat/apps_sdl2' ../../build/bin/filer"
    ;;
  *) echo "mode must be native or linux" >&2; exit 2;;
esac
