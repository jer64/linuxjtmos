JTMOS / GraOS Filer - Explorer-style File Manager (2026)
=========================================================

This package upgrades the historical Squirrel/JTMOS Filer into a GraOS bitmap
application that uses the same filer.c on native JTMOS and on Linux GraOS/SDL2.

Main UI/features
----------------
* Classic Windows Explorer inspired "Details" layout.
* Toolbar: Back, Root, Refresh, Open, Mark, Delete, Help.
* Address/current-directory field.
* Folders pane: Root + /hda on JTMOS, Root + Home on Linux.
* Name / Type / Size detail columns.
* Folder/file icons, focused row, multi-file mark indicator and status bar.
* Mouse row selection through GSID_MOUSEBUTTON=20.
* Keyboard navigation: arrows, PgUp/PgDn, Home/End, Enter, Backspace.
* Insert/Space marks files; F5 refreshes; F8/Delete asks before deleting.
* Built-in help overlay, so F1 no longer needs to run the editor.
* Directories first and case-insensitive name sorting.
* Text/source files open in Edit.
* Native JTMOS recognizes .elf as well as legacy .bin/.exe/.com programs.
* 4000-entry directory database retained, with 96-byte filename storage.

Why the GraOS patches are included
----------------------------------
The current Linux GraOS server already sends keyboard and server-button events,
but did not send ordinary clicks inside an application's client bitmap. The
Linux patch adds GSID_MOUSEBUTTON (20) and forwards client-relative x/y/button.

The native JTMOS GraOS patch adds the same client-area pointer notification.
It also fixes the refreshed 2026 libc GraOS public ABI: its public header had
stale constants/packet layout and modern/graos_compat.c still contained ENOSYS
stubs. The replacement client talks to the native "guiserver" through JTMOS
message boxes. The patch also changes modern fexist() to SYS_fexist so directory
entries preserve the historical 1=file / 2=directory result required by Filer.

Native JTMOS installation
-------------------------
Assume ROOT is the JTMOS source root containing kernel32/ and libc/.

  cd ROOT
  patch -p1 < /path/to/patches/jtmos_native_graos_filer.patch
  cp /path/to/apps/filer.c   libc/apps/filer.c
  cp /path/to/apps/filer.hlp libc/apps/filer.hlp
  cp /path/to/apps/filer.mak libc/apps/filer.mak

Build the refreshed libc and Filer:

  cd ROOT/libc/apps
  make -f filer.mak

This creates filer.elf, a static i386 ET_EXEC application linked at 0x80004000.
The included bin/filer.elf is the artifact produced by that build in the test
environment, but rebuilding in your tree is recommended after applying patches.

Linux GraOS / SDL2 installation
-------------------------------
Use the current GraOS tree that contains apps/ and compat/apps_sdl2/:

  cd GRAOS_ROOT
  patch -p1 < /path/to/patches/linux_graos_filer.patch
  cp /path/to/apps/filer.c   apps/filer.c
  cp /path/to/apps/filer.hlp apps/filer.hlp
  cp /path/to/apps/filer.mak apps/filer.mak

Build:

  make -C compat/apps_sdl2 ../../build/bin/filer

Run the central GraOS server, then Filer:

  ./build/bin/graos &
  ./build/bin/filer

The Linux patch also adds Filer to compat/apps_sdl2/Makefile, adds it to the
applications dispatcher, and updates Control Panel's native launcher to prefer
NAME.elf before falling back to NAME.bin.

Notes
-----
* Filer draws its own 8-bit indexed bitmap and therefore does not depend on
  private server-side drawing functions.
* The native window is made 38 pixels taller than the framebuffer because the
  historical JTMOS GraOS API treats createWindow height as the outer window
  size while Linux GraOS treats it as client size.
* Mouse support needs the appropriate patch; keyboard operation still uses the
  established GraOS key message path.
* Native JTMOS kernel runtime/boot testing is still required on the real OS/QEMU.
