# JTMOS GraOS central IPC desktop (Linux/SDL2)

This tree keeps native JTMOS support while making the Linux port use a real
central GraOS process. The Linux applications no longer create their own SDL2
windows. `graos` owns SDL2, the desktop framebuffer, window z-order, focus,
mouse handling and keyboard dispatch.

## Build and run

```sh
make
./build/bin/graos
```

A manually started `graos` starts the ported taskbar by default. To start only
the desktop server:

```sh
./build/bin/graos --no-taskbar
```

Then launch applications from another shell, for example:

```sh
./build/bin/edit README
./build/bin/wintest2
./build/bin/winshell ./build/bin/sqsh
./build/bin/snake
```

Status and shutdown:

```sh
./build/bin/graosctl status
./build/bin/graosctl ping
./build/bin/graosctl shutdown
```

If an application is launched before `graos`, the Linux wrapper automatically
starts `build/bin/graos --auto`. Set `JTMOS_GRAOS_NO_AUTOSTART=1` to require a
manually running server.

## Architecture

```
application process
  |  createWindow/addFrameBuffer/refreshWindow
  |  printf/gotoxy/textcolor/getch
  v
libjtmosapps.a (GraOS + terminal wrappers)
  |
  | Unix-domain synchronous IPC
  v
central `graos` process
  |-- window manager / compositor
  |-- SDL2 desktop (only this process owns SDL video)
  |-- JTMOS term.c-compatible SCREEN engine
  |-- terminal keyboard FIFO
  |
  +-- Postman/PPCS -> asynchronous GSID_* events to applications
```

`MSG`/Postman remains the asynchronous application event path. The synchronous
GraOS wrapper RPC uses `/tmp/jtmos-graos-<uid>.sock`; this avoids mixing API
return values with an application's normal Postman event queue.

### Terminal applications

On Linux, the first console output automatically requests a remote terminal and
window. `printf`, `putch`, `clrscr`, `gotoxy`, `textcolor` and related wrappers
are translated into terminal operations. The central GraOS server applies them
to its `SCREEN` structure using the Linux port of JTMOS `term.c` logic, then
composites that terminal into the owning GraOS window.

Keyboard focus works in the opposite direction: SDL2 -> focused GraOS window ->
terminal keyboard FIFO -> `getch()` in the application.

`winshell` is special in the useful JTMOS way: it creates a server terminal,
spawns a child with that terminal ID, and adds that same terminal as a window
surface. The child therefore writes into the terminal displayed by the
`winshell` window rather than opening another SDL window.

### Bitmap applications

`TYPE_BITMAP_SCREEN` buffers remain normal pointers inside the application.
`refreshWindow()` copies their current pixels over GraOS IPC to the server-side
surface. VGA `setmode(0x13)` / `drawframe()` are also wrapped this way, so plasma
and picture-style programs are composited into the same desktop.

## JTMOS compatibility

The Linux compatibility implementation is under `compat/`. Native JTMOS source
and per-application `.mak` files remain present. Build native applications with:

```sh
make JTMOS=1
```

The public compatibility headers retain `#ifdef JTMOS` branches so the native
JTMOS ABI is not replaced by the Linux socket/SDL2 implementation.


## SMSH terminal integration

The GraOS Terminal continues to run SQSH as a normal terminal-attached process, but SQSH now exposes the restored System Maintenance Shell command set. See `SMSH_GRAOS_TERMINAL_INTEGRATION_2026.md`. Native input uses the existing terminal/getch path, not `fgets()` or pipes.
