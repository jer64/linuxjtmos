# JTMOS GraOS Filer - current 2026 static ELF32 application build
APPNAME := filer
JTMOS_LIBC ?= ../libc
include $(JTMOS_LIBC)/mk/jtmos-app.mk

.PHONY: default all libc clean legacy-bin

default all: $(APPNAME).elf

libc:
	$(MAKE) -C $(JTMOS_LIBC) application

$(APPNAME).o: $(APPNAME).c
	$(JTMOS_CC) $(JTMOS_APP_CFLAGS) -Wall -Wextra -c $< -o $@

$(APPNAME).elf: libc $(APPNAME).o
	$(JTMOS_LD) $(JTMOS_APP_LDFLAGS) $(JTMOS_CRT0) $(APPNAME).o $(JTMOS_LIB) -o $@
	@echo "Built JTMOS static ELF32 GraOS application: $@"

# Historical raw .bin target retained only for old pre-ELF JTMOS trees.
legacy-bin: $(APPNAME).o
	ld --oformat binary -Map $(APPNAME).map -T../lib/stdapp.src \
	  ../libc/stlibc.o $(APPNAME).o -L../lib -lcjtmos -o $(APPNAME).bin

clean:
	rm -f $(APPNAME).o $(APPNAME).elf $(APPNAME).bin $(APPNAME).map
