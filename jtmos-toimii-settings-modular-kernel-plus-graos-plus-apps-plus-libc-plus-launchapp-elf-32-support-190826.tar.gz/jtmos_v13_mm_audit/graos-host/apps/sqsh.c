// =======================================================================
// sqsh.c - Squirrel Shell 1.0 for JTMOS
// (C) 2002-2003 by Jari Tuominen(jari@vunet.org)
// =======================================================================
#include <stdio.h>
#include "sqsh.h"

#define SQSH_LINE_CAPACITY 4096
#define SQSH_ARG_SIZE       256
#ifndef JTMOS
#include <jtmos/app_port.h>
#endif

// Request 256K of RAM from the init process.
SYSMEMREQ(256)

//
int sqsh_special=0;

//
struct
{
	//
	char *cmdline;
	char path[512];
	char dev[512];

	//
	char **cmdpar;

	//
	char **script;
	int lines_script;
	char *tmp;

	//
	char script_run;
	int line_script;
}sqsh;

/*
 * Read one command line using the JTMOS terminal keyboard primitive.
 * JTMOS does not currently provide fgets()/pipe-backed stdio for the
 * interactive terminal, so do not make the shell depend on it.
 *
 * Return value: >=0 line length, -1 end-of-input, -2 overlong line.
 */
static int sqsh_readline(char *dst, int capacity)
{
    int key;
    int used = 0;
    int overflow = 0;

    if(dst == NULL || capacity < 2) return -1;
    dst[0] = 0;

    for(;;)
    {
        key = getch();

        if(key == '\r' || key == '\n')
        {
            putchar('\n');
            break;
        }

        /* Ctrl-D on an empty line is treated as end-of-input. */
        if(key == 4 && used == 0)
            return -1;

        if(key == '\b' || key == 127)
        {
            if(used > 0)
            {
                used--;
                dst[used] = 0;
                putchar('\b'); putchar(' '); putchar('\b');
            }
            continue;
        }

        /* ESC and non-printing extended keys are ignored by the line editor. */
        if(key == 27 || key < 32 || key > 255)
            continue;

        if(used < capacity-1)
        {
            dst[used++] = (char)key;
            dst[used] = 0;
            putchar(key);
        }
        else
        {
            overflow = 1;
        }
    }

    if(overflow)
    {
        printf("Command line is too long (maximum %d characters).\n", capacity-1);
        dst[0] = 0;
        return -2;
    }
    return used;
}

/* cexec() has intentionally different compatibility return conventions:
 * native JTMOS returns a non-zero PID on success, while the Linux/SDL2 shim
 * returns zero when system() succeeds.  Hide that difference here. */
static int sqsh_cexec_ok(const char *command)
{
    int result;
    if(command == NULL || !command[0]) return 0;
    result = cexec(command, sqsh.path);
#ifdef JTMOS
    return result != 0;
#else
    return result == 0;
#endif
}

/* Native applications are normally installed as NAME.bin.  First preserve
 * historical exact-name execution; if it fails, retry with .bin appended to
 * the first command word. */
static int sqsh_exec_external(const char *line)
{
    char command[SQSH_LINE_CAPACITY + 8];
    const char *p;
    const char *rest;
    int name_len;
    int rest_len;

    if(line == NULL || !line[0]) return 0;
    if(sqsh_cexec_ok(line)) return 1;

#ifdef JTMOS
    p = line;
    while(*p == ' ' || *p == '\t') p++;
    rest = p;
    while(*rest && *rest != ' ' && *rest != '\t') rest++;
    name_len = (int)(rest-p);
    rest_len = (int)strlen(rest);

    if(name_len <= 0 || name_len + 4 + rest_len >= (int)sizeof(command))
        return 0;

    /* Do not turn an explicitly named binary/path with an extension into
       foo.bin.bin. */
    {
        int i;
        int has_dot = 0;
        for(i=0; i<name_len; i++)
            if(p[i] == '.') { has_dot = 1; break; }
        if(has_dot) return 0;
    }

    memcpy(command, p, name_len);
    memcpy(command + name_len, ".bin", 4);
    memcpy(command + name_len + 4, rest, rest_len + 1);
    return sqsh_cexec_ok(command);
#else
    return 0;
#endif
}

static int sqsh_exec_alias(const char *program, const char *line)
{
    char command[SQSH_LINE_CAPACITY + 8];
    const char *rest;
    int plen;
    int rlen;

    if(program == NULL || line == NULL) return 0;
    rest = line;
    while(*rest == ' ' || *rest == '\t') rest++;
    while(*rest && *rest != ' ' && *rest != '\t') rest++;

    plen = (int)strlen(program);
    rlen = (int)strlen(rest);
    if(plen + rlen >= (int)sizeof(command)) return 0;
    memcpy(command, program, plen);
    memcpy(command + plen, rest, rlen + 1);
    return sqsh_exec_external(command);
}

static void sqsh_smsh_help(void)
{
    printf("JTMOS Terminal Shell / SMSH compatibility commands:\n");
    printf("  cd PATH | chdir PATH       change directory\n");
    printf("  ls [options] | dir         list directory\n");
    printf("  mkfs DEVICE | format DEVICE format JTMFS device\n");
    printf("  sqa ARCHIVE [options]      extract Squirrel archive\n");
    printf("  sqarc DIR ARCHIVE          create Squirrel archive (when installed)\n");
    printf("  nzip ...                   Peanut Zip pack/unpack\n");
    printf("  help | smsh                show this command list\n");
    printf("  exit | quit                leave terminal shell\n");
    printf("SQSH commands retained: load, list, save, echo, ver/version.\n");
}

// Load script
int loadscript(const char *fname)
{
	FILE *f;
	int i,i2,i3,i4,ch,bytes;

	// Open script file
	f=fopen(fname, "rb");
	if(f==NULL)
	{
		// Open error:
		return 1;
	}

	// Allocate script structure when neccesary
	if(sqsh.script==NULL)
	{
		sqsh.script = malloc(SCRIPT_MAX_LINES * sizeof(char *));
		if(sqsh.script==NULL) { fclose(f); return 1; }
		memset(sqsh.script, 0, SCRIPT_MAX_LINES * sizeof(char *));
	}
	// Receive whole script
	for(i=0,bytes=0; ; )
	{
		if(i >= SCRIPT_MAX_LINES)
		{
			printf("Script has more than %d lines; remaining lines ignored.\n", SCRIPT_MAX_LINES);
			break;
		}
		// Allocate one string for the line when neccesary
		if(sqsh.script[i]==NULL)
		{
			sqsh.script[i] = malloc(200);
			if(sqsh.script[i]==NULL) { fclose(f); return 1; }
		}

		// Get one line at once
		for(i2=0; i2<195; i2++)
		{
			bytes++;
			ch = fgetc(f);
			if(!ch || ch==EOF)break;
			if(ch==0xA)break;
			sqsh.script[i][i2] = ch;
		}
		sqsh.script[i][i2]=0;

		// Preprocess script line
		if( sqsh_parsecmd(sqsh.script[i], 1) )
		{
			// Parse error
			strcpy(sqsh.script[i], "# This line contained error(preprocessor).");
		}
		else
		{
			// Line was OK.
		}

		// End of script file?
		if(!ch || ch==EOF)break;

		//
		i++;
	}
	// Declare total amount of lines in the script. `i` is zero based.
	sqsh.lines_script = (i < SCRIPT_MAX_LINES) ? (i + 1) : SCRIPT_MAX_LINES;

	// Close script file stream.
	fclose(f);

//	printf("%d bytes processed.\n", bytes);
	// Request script to be ran now.
	sqsh.script_run=1;
	return 0;
}

//
void show_help_page(int argc, char **argv)
{
	printf("Squirrel Shell 1.0 for JTMOS\n");
	printf("    (C) 2002-2003 by Jari Tuominen\n");
	printf("\n");
	printf("Usage: %s [options] [files] [...]\n", argv[0]);
	printf("Options:\n");
	printf("          --help      shows help page(this)\n");
	printf("          --dir       specifies location to run at\n");
	printf("     e.g. --dir /\n");
}

//
void sqsh_allocate(void)
{
	int i;

	//
	sqsh.cmdline = malloc(SQSH_LINE_CAPACITY);
	sqsh.cmdpar = malloc((SQSH_MAX_WORDS+10)*sizeof(char *));

	//
	for(i=0; i<(SQSH_MAX_WORDS+10); i++)
	{
		sqsh.cmdpar[i] = malloc(SQSH_ARG_SIZE);
	}
}

// Change directory
void sqsh_cd(void)
{
	if(sqsh.cmdpar[1]==NULL || !sqsh.cmdpar[1][0])
	{
		printf("Usage: cd PATH\n");
		return;
	}
	if(chdir(sqsh.cmdpar[1])!=0)
		printf("Unable to change directory to '%s'.\n", sqsh.cmdpar[1]);
}

// Echo on terminal
void sqsh_echo(const char *cmdline)
{
	int i,i2,i3,i4, l;

	//
	l = strlen(cmdline);

	//
	for(i=0; i<l; i++)
	{
		if(cmdline[i]=='\"')
		{
			for(i2=i+1; i2<l; i2++)
			{
				if(cmdline[i2]=='\"')
				{
					printf("\n");
					break;
				}
				printf("%c", cmdline[i2]);
			}
			return;
		}
	}

	//
	printf("Usage: echo \"text inside here\"\n");
	printf("Quote -marks are required.\n");
}

//
void sqsh_list(void)
{
	int i;

	//
	printf("Script contains %d lines.\n", sqsh.lines_script);
	for(i=0; i<sqsh.lines_script; i++)
	{
		if( (i&15)==15 )	if(getch()==27)break;
		printf("Line %d: \"%s\"\n",  i, sqsh.script[i]);
	}
}

//
void sqsh_load(void)
{
}

//
void sqsh_save(void)
{
}

// 0	=	ok
// -1	=	exit request
// -2	=	invalid parameter
// -3	=	nothing to do
//
int sqsh_parsecmd(const char *s, int test)
{
	//
	int pid;

	// Detect bad arguments
	if(s==NULL)return -2;
	if(!strlen(s))return -3;

	// Make cmdpar argument split strings
	sqsh_process_cmdstring(s);

	// Detect remarked lines and skip these
	if( sqsh.cmdpar[0][0]=='#' )
	{
		// One remark line skipped :)
		return 0;
	}

	/* SMSH is integrated into this terminal shell.  Commands are available
	 * directly, while a bare `smsh` prints the maintenance command set. */
	if( !strcmp(sqsh.cmdpar[0], "smsh") || !strcmp(sqsh.cmdpar[0], "help") )
	{
		if(test==0) sqsh_smsh_help();
		return 0;
	}

	if( !strcmp(sqsh.cmdpar[0], "chdir") )
	{
		if(test==0) sqsh_cd();
		return 0;
	}

	if( !strcmp(sqsh.cmdpar[0], "dir") )
	{
		if(test==0 && !sqsh_exec_alias("ls", s)) return -2;
		return 0;
	}

	if( !strcmp(sqsh.cmdpar[0], "format") )
	{
		if(test==0 && !sqsh_exec_alias("mkfs", s)) return -2;
		return 0;
	}

	// List currently loaded script
	if( !strcmp(sqsh.cmdpar[0], "list") )
	{
		if(test==0)	sqsh_list();
		return 0;
	}

	// Load a script
	if( !strcmp(sqsh.cmdpar[0], "load") )
	{
		if(test==0)
		{
			printf("Loading script '%s'\n", sqsh.cmdpar[1]);
			loadscript(sqsh.cmdpar[1]);
		}
		return 0;
	}

	// Save a script
	if( !strcmp(sqsh.cmdpar[0], "save") )
	{
		if(test==0)
		{
			printf("Not implemented yet.\n");
		}
		return 0;
	}

	//
	if( !strcmp(sqsh.cmdpar[0], "cd") )
	{
		if(test==0)
		{
			sqsh_cd();
		}
		return 0;
	}

	//
	if( !strcmp(sqsh.cmdpar[0], "echo") )
	{
		if(test==0)
		{
			sqsh_echo(s);
		}
		return 0;
	}

	//
	if( !strcmp(sqsh.cmdpar[0], "ver")
		||
	    !strcmp(sqsh.cmdpar[0], "version") )
	{
		if(test==0)
		{
			sqsh_about();
		}
		return 0;
	}

	//
	if( !strcmp(sqsh.cmdpar[0], "exit") || !strcmp(sqsh.cmdpar[0], "quit") )
	{
		if(test==0)
			return -1;
			else
			return 0;
	}

	// Empty?
	if( !strcmp(sqsh.cmdpar[0], "")
		||
	    sqsh.cmdpar[0][0]==' ' )
		return -2;

	// Try external command. Native JTMOS also retries NAME as NAME.bin.
	if( !sqsh_exec_external(s) )return -2;
	return 0;
}

//
void sqsh_draw_prompt(void)
{
	//
	printf("[root@localhost %s]#", sqsh.path);
}

int sqsh_process_cmdstring(const char *s)
{
	int i;
	char *tmp;

	//
	for (i = 0; i < SQSH_MAX_WORDS; i++)
		strcpy (sqsh.cmdpar[i], "");

	//
	for (i = 0; i < SQSH_MAX_WORDS; i++)
	{
		// Get parameter #$(i)
		sptstr (sqsh.cmdpar[i], s, ' ', i, SQSH_MAX_WORDS-1);
		// Last parameter?
		if( !strlen(sqsh.cmdpar[i]) )
			break;
	}
	return i;
}

// SQSH shell prompt
void sqsh_prompt(void)
{
	char str[512],str2[512];
	int rv,testbin;

	//
	for(;;)
	{
retryagain:
		//
		SwitchToThread();

		// Get current path
		getcwd(sqsh.path, 250);

		//
		if(sqsh.script_run==2)
		{
			break;
		}

		//
		if(sqsh.script_run==1)
		{
			strcpy(sqsh.cmdline, sqsh.script[sqsh.line_script]);
			sqsh.line_script++;
			if( sqsh.line_script>=sqsh.lines_script )
			{
				// Last line of the script reached
				//sqsh.script_run=2;
				sqsh.script_run=0;
			}
		}
		else
		if(sqsh.script_run==0)
		{
			sqsh_draw_prompt();
			rv = sqsh_readline(sqsh.cmdline, SQSH_LINE_CAPACITY);
			if(rv == -1) goto outtahere;
			if(rv == -2) goto retryagain;
		}

		// Sanity check
		if( !strlen(sqsh.cmdline) )goto retryagain;
		testbin=0;
		// Copy the name to the temp buffer
		strcpy(str2, sqsh.cmdline);
		rv = sqsh_parsecmd(str2, 0);
		switch(rv)
		{
			// End of session.
			case -1:
			goto outtahere;
			// File not found
			case -2:
			printf("Bad command or file name '%s'\n",
				str2);
			break;
			//
			default:
			break;
		}
	}
////////////////////////////////////////////////////////////////////////////////
outtahere:
}

// Initialize SQSH
void sqsh_init(void)
{
	//
	strcpy(sqsh.path, "/");

	//
	sqsh_allocate();
}

// Bring up some info about the shell
void sqsh_about(void)
{
	printf(" .    .     _ _   \n");
	printf(" |\\__/|  .~    ~. \n");
	printf(" /  o `./      .' JTMOS Squirrel Shell 1.1 / SMSH \n");
	printf("{o__,   \\    {    \n");
	printf("  / .  . )    \\   (C) 2002-2003 by Jari Tuominen\n");
	printf("  `-` '-' \\    }  jari@vunet.org\n");
	printf(" .(   _(   )_.'  \n");
	printf("'---.~_ _ _|     \n");
}

// Start shell process itself
void sqsh_start(void)
{
	// Start prompt
	sqsh_prompt();
}

// Check sqsh start arguments for various options
int checkArgus(int argc, char **argv)
{
	if(argc>=2)
	{
		if(!strcmp(argv[1],"--dir"))
		{
			if(argc<3)
			{
				printf("--dir requires a path.\n");
				return 1;
			}
			chdir(argv[2]);
			return -1;
		}

		if(!strcmp(argv[1],"--help"))
		{
			show_help_page(argc, argv);
			return 1;
		}
	}
	return 0;
}

// This is done in boot up sequence
void bootseq(void)
{
	if( !loadscript("/etc/boot.sh") )return;
	if( !loadscript("/bin/boot.sh") )return;
	if( !loadscript("/usr/etc/boot.sh") )return;
	if( !loadscript("/boot.sh") )return;
	printf("Cannot find boot.sh -automation script, entering manual start up ...\n");
}

//
int main(int argc, char **argv)
{
	//
	memset(&sqsh, 0, sizeof(sqsh));

	// Initialize
	printf("\rSquirrel Shell is now initialising ...                   \r");
	sqsh_init();
	printf("\r                                                         \r");

	//
	sqsh.script_run=0;
	sqsh.lines_script=0;

	//
	if( (sqsh_special=checkArgus(argc,argv))==1 )
	{
		// Shell quits
		return 0;
	}

	// Handle sqsh_special==-1 here
	// -1 = load start up sequence
	if(sqsh_special==-1)bootseq();

	// Load script if one defined
	if(argc>=2 && argv[1] && argv[1][0] != '-')
		loadscript(argv[1]);

	// Shell starts
	sqsh_start();

	//
	return 0;
}

