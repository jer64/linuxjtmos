// terminal.c - GraOS terminal window running the JTMOS Squirrel Shell
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#ifndef JTMOS
#include <jtmos/app_port.h>
#include <limits.h>
#include <unistd.h>
#endif

SYSMEMREQ(APPRAM_256K)

static void shell_program(char *out, size_t outsz, int argc, char **argv)
{
    if(argc > 1 && argv[1] && argv[1][0]) {
        snprintf(out,outsz,"%s",argv[1]);
        return;
    }
#ifdef JTMOS
    snprintf(out,outsz,"sqsh.bin");
#else
    {
        char exe[PATH_MAX];
        char *slash;
        ssize_t n = readlink("/proc/self/exe",exe,sizeof(exe)-1);
        if(n > 0 && (size_t)n < sizeof(exe)) {
            exe[n]=0;
            slash=strrchr(exe,'/');
            if(slash) {
                *slash=0;
                if(snprintf(out,outsz,"%s/sqsh",exe) < (int)outsz) return;
            }
        }
        snprintf(out,outsz,"sqsh");
    }
#endif
}

int main(int argc, char **argv)
{
    MSG m;
    GUICMD *cmd=(GUICMD *)m.buf;
    int wid=-1,ter=-1,pid=0;
    char shell[512];

    if(connectGraos()!=0) return 1;
    ter=CreateTerminal();
    if(ter<0) return 2;

    shell_program(shell,sizeof(shell),argc,argv);
    pid=bgexecEx(shell,"/",ter);
    if(pid<=0) {
#ifndef JTMOS
        JtmosGraOSTermWrite(ter,"Unable to start shell.\n",23);
#else
        printf("Unable to start shell.\n");
#endif
    }

    wid=createWindow(-1,-1,624,208,"JTMOS Terminal",STANDARD_WINDOW);
    if(wid<0) goto done;
    if(addFrameBuffer(wid,NULL,0,0,78,25,8,TYPE_TERMINAL_EMULATION,ter)<0)
        goto done;
    refreshWindow(wid);

    for(;;) {
        while(receiveMessage(&m)) {
            if(cmd->id==GSID_EXIT) goto done;
            /* Keyboard is routed by graos directly into term.c FIFO. */
        }
        SwitchToThread();
        sleep(1);
    }

done:
    if(wid>=0) closeWindow(wid);
    if(pid>0) KillThread(pid);
#ifndef JTMOS
    if(ter>=0) JtmosGraOSFreeTerminal(ter);
#endif
    return 0;
}
