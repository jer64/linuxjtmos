//----------------------------------------------------------
// taskbar.c - GraOS taskbar + Start menu
//----------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#ifndef JTMOS
#include <jtmos/app_port.h>
#include <limits.h>
#include <sys/types.h>
#include <unistd.h>
#endif

SYSMEMREQ(APPRAM_256K)

#define TASKBAR_H           30
#define START_BUTTON_ID   1000
#define START_MENU_W       188
#define START_ITEM_H        28
#define START_MENU_ITEMS     6
#define START_MENU_H       (START_MENU_ITEMS * START_ITEM_H + 8)

#define MENU_TERMINAL      1101
#define MENU_FILER         1102
#define MENU_EDIT          1103
#define MENU_TOP           1104
#define MENU_CONTROL       1105
#define MENU_CLOSE         1199

static int start_menu_wid = -1;

static int launch_program(const char *name)
{
#ifdef JTMOS
    char cmd[160];
    if (!name || !*name) return -1;
    /* JTMOS applications are normally installed as .bin files. */
    snprintf(cmd, sizeof(cmd), "%s.bin", name);
    return cexec(cmd, "");
#else
    char exe[PATH_MAX], path[PATH_MAX];
    char *slash;
    ssize_t n;
    pid_t pid;

    if (!name || !*name) return -1;
    path[0] = 0;
    n = readlink("/proc/self/exe", exe, sizeof(exe)-1);
    if (n > 0 && (size_t)n < sizeof(exe)) {
        exe[n] = 0;
        slash = strrchr(exe, '/');
        if (slash) {
            *slash = 0;
            if (snprintf(path, sizeof(path), "%s/%s", exe, name) >= (int)sizeof(path))
                path[0] = 0;
        }
    }

    pid = fork();
    if (pid < 0) return -1;
    if (pid == 0) {
        unsetenv("JTMOS_GRAOS_TERMINAL");
        unsetenv("JTMOS_GRAOS_NO_AUTO_WINDOW");
        if (path[0]) execl(path, path, (char *)NULL);
        execlp(name, name, (char *)NULL);
        _exit(127);
    }
    return (int)pid;
#endif
}

int RenderTaskBar(BYTE *buf, int width,int height, int frame)
{
    int x,y,ad,i,fr;
    BYTE pal1[16]={
        0,8,7,14, 15,14,7,8,
        0,BLUE,CYAN,10, 15,10,CYAN,BLUE
    };

    fr = frame;
    for(i=0; i<2; i++) {
        for(y=i; y<height; y+=2) {
            ad = width*y;
            for(x=0; x<width; x++)
                buf[ad+x] = pal1[(((((x>>(i<<4))+y)>>2)+fr)&7) + (i<<3)];
        }
    }
    return 0;
}

static void close_start_menu(void)
{
    if(start_menu_wid >= 0) {
        closeWindow(start_menu_wid);
        start_menu_wid = -1;
    }
}

static void open_start_menu(void)
{
    int y = 480 - TASKBAR_H - START_MENU_H;
    int x = 0;
    int by = 4;

    if(start_menu_wid >= 0) {
        close_start_menu();
        return;
    }

    /* TASKBAR_WINDOW gives us a compact borderless popup surface. */
    start_menu_wid = createWindow(x,y,START_MENU_W,START_MENU_H,"",
                                  TASKBAR_WINDOW | WINDOW_AUTOCLEAR);
    if(start_menu_wid < 0) return;

    createButton(start_menu_wid,4,by,START_MENU_W-8,START_ITEM_H-2,
                 MENU_TERMINAL,"Terminal Shell"); by += START_ITEM_H;
    createButton(start_menu_wid,4,by,START_MENU_W-8,START_ITEM_H-2,
                 MENU_FILER,"File Manager"); by += START_ITEM_H;
    createButton(start_menu_wid,4,by,START_MENU_W-8,START_ITEM_H-2,
                 MENU_EDIT,"Text Editor"); by += START_ITEM_H;
    createButton(start_menu_wid,4,by,START_MENU_W-8,START_ITEM_H-2,
                 MENU_TOP,"Task Manager"); by += START_ITEM_H;
    createButton(start_menu_wid,4,by,START_MENU_W-8,START_ITEM_H-2,
                 MENU_CONTROL,"Control Panel"); by += START_ITEM_H;
    createButton(start_menu_wid,4,by,START_MENU_W-8,START_ITEM_H-2,
                 MENU_CLOSE,"Close Menu");
    refreshWindow(start_menu_wid);
}

static void handle_button(int id)
{
    switch(id) {
        case START_BUTTON_ID:
            open_start_menu();
            break;
        case MENU_TERMINAL:
            close_start_menu();
            launch_program("terminal");
            break;
        case MENU_FILER:
            close_start_menu();
            launch_program("filer");
            break;
        case MENU_EDIT:
            close_start_menu();
            launch_program("edit");
            break;
        case MENU_TOP:
            close_start_menu();
            launch_program("top");
            break;
        case MENU_CONTROL:
            close_start_menu();
            launch_program("controlpanel");
            break;
        case MENU_CLOSE:
            close_start_menu();
            break;
        default:
            break;
    }
}

void mainLoop(int wid)
{
    static MSG m;
    static GUICMD *cmd;
    static BYTE *buf;
    static int frame;

    cmd = (GUICMD *)m.buf;
    buf = malloc(640*TASKBAR_H);
    if(!buf) return;

    addFrameBuffer(wid,buf,76,0,640-76,TASKBAR_H,8,TYPE_BITMAP_SCREEN,0);
    createButton(wid,0,0,76,TASKBAR_H-1,START_BUTTON_ID,"Start");

    RenderTaskBar(buf,640-76,TASKBAR_H,0);
    refreshWindow(wid);

    for(frame=0; ; frame++) {
        while(receiveMessage(&m)) {
            switch(cmd->id) {
                case GSID_EXIT:
                    goto exitti;
                case GSID_BUTTON:
                    handle_button(cmd->v[0]);
                    break;
                case GSID_KEYPRESSED:
                default:
                    break;
            }
        }

        RenderTaskBar(buf,640-76,TASKBAR_H,frame);
        refreshWindow(wid);
        sleep(4);
        SwitchToThread();
    }

exitti:
    close_start_menu();
    free(buf);
}

int main(int argc, char **argv)
{
    int wid;
    (void)argc; (void)argv;
    connectGraos();
    wid = createWindow(0,480-TASKBAR_H,640,TASKBAR_H,"",
                       TASKBAR_WINDOW | WINDOW_AUTOCLEAR);
    if(wid < 0) return 1;
    mainLoop(wid);
    return 0;
}
