// sqarc.c - Squirrel Archive Creator application wrapper for SMSH/SQSH
#include <stdio.h>
#ifndef JTMOS
#include <jtmos/app_port.h>
#endif

/* Keep one implementation shared with kernel32/sh.  The included source has
 * separate native-JTMOS and POSIX/SDL2 branches. */
#include "../kernel32/sh/sqarc.c"

#ifdef JTMOS
SYSMEMREQ(APPRAM_1024K)
#endif

int main(int argc, char **argv)
{
    return sqarc_main(argc, argv);
}
