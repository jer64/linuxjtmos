#ifndef __INCLUDED_SQSH_H__
#define __INCLUDED_SQSH_H__

// ---- PREFERENCES --------------------------------
// Max. words
#define SQSH_MAX_WORDS          200
//
#define SCRIPT_MAX_LINES        500

// ---- FUNCTION PROTOTYPES ------------------------
int loadscript(const char *fname);

int sqsh_parsecmd(const char *s, int test);
int sqsh_process_cmdstring(const char *s);
void sqsh_about(void);
void sqsh_cd(void);

#endif
