#define _GNU_SOURCE
#include <jtmos/graos.h>
#include <jtmos/graos_ipc.h>
#include "jtmos_graos_ipc.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_CLIENT_FB 32

typedef struct {
    int used,wid,sid;
    BYTE *buf;
    int x,y,w,h,bpp,type,ter;
} CLIENT_FB;

static CLIENT_FB fb[MAX_CLIENT_FB];
static int connected;
static int console_terminal=-1;
static int console_window=-1;

static int call0(uint32_t op,int wid,int object,const int *v,
                 const void *payload,size_t payload_len,JTMOS_GRAOS_WIRE *out)
{
    JTMOS_GRAOS_WIRE req,resp;
    if(!connected && connectGraos()!=0) return -1;
    memset(&req,0,sizeof(req));
    req.magic=JTMOS_GRAOS_WIRE_MAGIC;
    req.version=JTMOS_GRAOS_WIRE_VERSION;
    req.op=op;
    req.payload_len=(uint32_t)payload_len;
    req.pid=(int32_t)getpid();
    req.wid=wid;
    req.object=object;
    if(v) memcpy(req.v,v,sizeof(req.v));
    if(jtmos_graos_client_call(&req,payload,&resp,NULL,0,NULL)!=0) return -1;
    if(out) *out=resp;
    return resp.status;
}

int connectGraos(void)
{
    if(connected) return 0;
    if(jtmos_graos_client_ensure()!=0) return 1;
    if(ActivateThreadMessageBox((int)getpid())!=0) return 2;
    connected=1;
    return 0;
}

int createWindow(int x,int y,int w,int h,const char *title,int flags)
{
    JTMOS_GRAOS_CREATE_WINDOW p;
    JTMOS_GRAOS_WIRE r;
    if(connectGraos()!=0) return -1;
    memset(&p,0,sizeof(p));
    p.x=x;p.y=y;p.w=w;p.h=h;p.flags=flags;
    snprintf(p.title,sizeof(p.title),"%s",title?title:"JTMOS application");
    if(call0(GRAOS_OP_CREATE_WINDOW,0,0,NULL,&p,sizeof(p),&r)!=0) return -1;
    return r.wid;
}

int closeWindow(int wid)
{
    return call0(GRAOS_OP_CLOSE_WINDOW,wid,0,NULL,NULL,0,NULL);
}

int addFrameBuffer(int wid,BYTE *buf,int x,int y,int w,int h,int bpp,int type,int terID)
{
    JTMOS_GRAOS_ADD_SURFACE p;
    JTMOS_GRAOS_WIRE r;
    int i;
    memset(&p,0,sizeof(p));
    p.x=x;p.y=y;p.w=w;p.h=h;p.bpp=bpp;p.type=type;p.terminal_id=terID;
    if(call0(GRAOS_OP_ADD_SURFACE,wid,0,NULL,&p,sizeof(p),&r)!=0) return -1;
    for(i=0;i<MAX_CLIENT_FB;i++) if(!fb[i].used){
        fb[i].used=1;fb[i].wid=wid;fb[i].sid=r.object;fb[i].buf=buf;
        fb[i].x=x;fb[i].y=y;fb[i].w=w;fb[i].h=h;fb[i].bpp=bpp;fb[i].type=type;fb[i].ter=terID;
        return r.object;
    }
    return -1;
}

int refreshWindow(int wid)
{
    int i;
    for(i=0;i<MAX_CLIENT_FB;i++) if(fb[i].used && fb[i].wid==wid && fb[i].type==TYPE_BITMAP_SCREEN && fb[i].buf){
        size_t bytes=(size_t)fb[i].w*(size_t)fb[i].h*(size_t)((fb[i].bpp+7)/8);
        if(bytes>JTMOS_GRAOS_MAX_PAYLOAD) return -1;
        if(call0(GRAOS_OP_UPDATE_SURFACE,wid,fb[i].sid,NULL,fb[i].buf,bytes,NULL)!=0) return -1;
    }
    return call0(GRAOS_OP_REFRESH_WINDOW,wid,0,NULL,NULL,0,NULL);
}

int createButton(int wid,int x,int y,int w,int h,int id,const char *text)
{
    JTMOS_GRAOS_BUTTON p;
    JTMOS_GRAOS_WIRE r;
    memset(&p,0,sizeof(p));p.x=x;p.y=y;p.w=w;p.h=h;p.id=id;
    snprintf(p.text,sizeof(p.text),"%s",text?text:"");
    return call0(GRAOS_OP_CREATE_BUTTON,wid,0,NULL,&p,sizeof(p),&r);
}

int CreateTerminal(void)
{
    JTMOS_GRAOS_WIRE r;
    if(connectGraos()!=0) return -1;
    if(call0(GRAOS_OP_CREATE_TERMINAL,0,0,NULL,NULL,0,&r)!=0) return -1;
    return r.object;
}

int JtmosGraOSFreeTerminal(int terID){return call0(GRAOS_OP_FREE_TERMINAL,0,terID,NULL,NULL,0,NULL);}

void OutTermKey(int terID,int key)
{
    int v[8]={0};v[0]=key;
    (void)call0(GRAOS_OP_TERM_PUTKEY,0,terID,v,NULL,0,NULL);
}

int JtmosGraOSTermWrite(int terID,const void *data,int len)
{
    if(!data||len<0) return -1;
    if((unsigned)len>JTMOS_GRAOS_MAX_PAYLOAD) return -1;
    return call0(GRAOS_OP_TERM_WRITE,0,terID,NULL,data,(size_t)len,NULL);
}
int JtmosGraOSTermClear(int terID){return call0(GRAOS_OP_TERM_CLEAR,0,terID,NULL,NULL,0,NULL);}
int JtmosGraOSTermGotoXY(int terID,int x,int y){int v[8]={x,y};return call0(GRAOS_OP_TERM_GOTOXY,0,terID,v,NULL,0,NULL);}
int JtmosGraOSTermColor(int terID,int c){int v[8]={c};return call0(GRAOS_OP_TERM_FG,0,terID,v,NULL,0,NULL);}
int JtmosGraOSTermBackground(int terID,int c){int v[8]={c};return call0(GRAOS_OP_TERM_BG,0,terID,v,NULL,0,NULL);}
int JtmosGraOSTermGetKey(int terID,int *mods)
{
    JTMOS_GRAOS_WIRE r;
    if(call0(GRAOS_OP_TERM_GETKEY,0,terID,NULL,NULL,0,&r)!=0) return -1;
    if(mods) *mods=r.v[1];
    return r.v[0];
}
int JtmosGraOSSetDesktopColor(int color)
{
    int v[8]={0};
    v[0]=color;
    return call0(GRAOS_OP_SET_DESKTOP_COLOR,0,0,v,NULL,0,NULL);
}

int JtmosGraOSSetPalette(int index,int r,int g,int b){int v[8]={index,r,g,b};return call0(GRAOS_OP_SET_PALETTE,0,0,v,NULL,0,NULL);}

static void proc_title(char *out,size_t n)
{
    FILE *f=fopen("/proc/self/comm","r");
    if(f&&fgets(out,(int)n,f)){out[strcspn(out,"\r\n")]=0;fclose(f);return;}
    if(f)fclose(f);
    snprintf(out,n,"JTMOS application");
}

int JtmosGraOSAutoConsole(const char *title,int cols,int rows)
{
    const char *attached=getenv("JTMOS_GRAOS_TERMINAL");
    char name[128];
    int t;
    if(connectGraos()!=0) return -1;
    if(console_terminal>=0) return console_terminal;
    if(attached&&*attached){
        t=atoi(attached);
        if(t>=0){console_terminal=t;return t;}
    }
    t=CreateTerminal();
    if(t<0)return -1;
    console_terminal=t;
    if(!getenv("JTMOS_GRAOS_NO_AUTO_WINDOW")){
        if(!title||!*title){proc_title(name,sizeof(name));title=name;}
        int view_rows=rows>55?55:rows;
        console_window=createWindow(-1,-1,cols*8,view_rows*8,title,STANDARD_WINDOW);
        if(console_window>=0)addFrameBuffer(console_window,NULL,0,0,cols,view_rows,8,TYPE_TERMINAL_EMULATION,t);
    }
    return t;
}

int JtmosGraOSCurrentConsoleTerminal(void){return console_terminal;}

int JtmosGraOSCreateVideoWindow(const char *title,int w,int h,BYTE *buf)
{
    int wid=createWindow(-1,-1,w,h,title?title:"JTMOS video",STANDARD_WINDOW);
    if(wid<0)return -1;
    if(addFrameBuffer(wid,buf,0,0,w,h,8,TYPE_BITMAP_SCREEN,0)<0)return -1;
    return wid;
}

void jtmos_graos_pump(void){ /* central graos owns SDL2 events */ }

int bgexecEx(const char *program,const char *cwd,int terminal_id)
{
    pid_t p=fork();
    if(p==0){
        char ter[32];
        snprintf(ter,sizeof(ter),"%d",terminal_id);
        setenv("JTMOS_GRAOS_TERMINAL",ter,1);
        setenv("JTMOS_GRAOS_NO_AUTO_WINDOW","1",1);
        if(cwd&&*cwd)chdir(cwd);
        execlp(program,program,(char*)NULL);
        _exit(127);
    }
    return p<0?-1:(int)p;
}
