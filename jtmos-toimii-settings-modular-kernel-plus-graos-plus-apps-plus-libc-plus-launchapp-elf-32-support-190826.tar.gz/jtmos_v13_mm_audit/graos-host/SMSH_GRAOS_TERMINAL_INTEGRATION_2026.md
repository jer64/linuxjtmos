# JTMOS GraOS Terminal + SMSH integration (2026-08-19)

This update restores the System Maintenance Shell command set to the current GraOS Terminal/SQSH package without replacing the newer central GraOS IPC architecture.

## What changed

- Restored the kernel maintenance-shell source overlay under `kernel32/sh/`.
- Kept the newer GraOS central server, Start menu, Terminal and Control Panel implementation unchanged.
- Integrated SMSH-compatible commands directly into `apps/sqsh.c`.
- Added native `.bin` fallback for bare JTMOS commands (`ls` -> `ls.bin`, etc.).
- Added `sqarc.bin` application build and a JTMOS-native SQARC520 archive creator.
- Fixed Linux/SDL2 versus native-JTMOS `cexec()` success-return differences.
- Replaced interactive `gets()` use in SQSH with a bounded `getch()` line editor.
- Made kernel SMSH use `getch()` in native JTMOS; `fgets()` is compiled only for host tests.
- Fixed SMSH `exit/quit` so the shell loop exits cleanly instead of terminating through the handler.
- Connected `format/mkfs` to `formatDrive()` in the native SMSH branch.
- Fixed SQSH script filenames containing `-` so they are not mistaken for command-line options.
- Fixed pointer-array allocation sizes for 64-bit host testing while preserving 32-bit JTMOS behavior.

## Terminal commands

SMSH compatibility commands available directly inside SQSH:

```text
cd PATH / chdir PATH
ls / dir
mkfs DEVICE / format DEVICE
sqa ARCHIVE.sqa [options]
sqarc DIRECTORY ARCHIVE.sqa
nzip ...
help / smsh
exit / quit
```

Historical SQSH `load`, `list`, `save`, `echo`, `ver` and `version` commands remain available.

## Input and pipes

JTMOS does not need `fgets()` or Unix pipes for the interactive shell. GraOS routes keyboard events to the server-side terminal FIFO, and the shell consumes them through JTMOS `getch()`. Both SQSH and SMSH now bound command-line input.

A future POSIX-style `pipe()` implementation should be added at the file-descriptor/VFS layer (`pipe()`, blocking `read()`, `write()`, close/refcounts and a ring buffer). It is intentionally not mixed into this shell restoration because the current terminal path already has a working FIFO transport and adding pipes would change kernel-wide fd semantics.

## Validation performed

- `kernel32/sh`: host SMSH build succeeded; scripted `help` + `exit` passed.
- `apps/sqarc`: created an SQARC520 archive and current `sqa` extracted it byte-for-byte correctly.
- `compat/apps_sdl2`: full `make check` passed.
- GraOS launch smoke: Taskbar + Terminal + Control Panel produced `windows=3`, `dynamic-terminals=1`.
- SQSH script containing `smsh` + `quit` displayed the integrated SMSH command set and exited successfully.

Native JTMOS compilation still requires the normal full JTMOS tree (`include/`, `lib/`, `libc/` and kernel build environment); this ZIP is an updated GraOS/source package and overlay, not a replacement SDK.
